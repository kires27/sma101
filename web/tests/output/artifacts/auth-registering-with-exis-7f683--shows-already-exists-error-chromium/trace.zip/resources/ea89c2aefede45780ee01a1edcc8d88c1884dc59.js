/**
 * Base error for Supabase Edge Function invocations.
 *
 * @example
 * ```ts
 * import { FunctionsError } from '@supabase/functions-js'
 *
 * throw new FunctionsError('Unexpected error invoking function', 'FunctionsError', {
 *   requestId: 'abc123',
 * })
 * ```
 */
export class FunctionsError extends Error {
    constructor(message, name = 'FunctionsError', context) {
        super(message);
        this.name = name;
        this.context = context;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            context: this.context,
        };
    }
}
/**
 * Error thrown when the network request to an Edge Function fails.
 *
 * @example
 * ```ts
 * import { FunctionsFetchError } from '@supabase/functions-js'
 *
 * throw new FunctionsFetchError({ requestId: 'abc123' })
 * ```
 */
export class FunctionsFetchError extends FunctionsError {
    constructor(context) {
        super('Failed to send a request to the Edge Function', 'FunctionsFetchError', context);
    }
}
/**
 * Error thrown when the Supabase relay cannot reach the Edge Function.
 *
 * @example
 * ```ts
 * import { FunctionsRelayError } from '@supabase/functions-js'
 *
 * throw new FunctionsRelayError({ region: 'us-east-1' })
 * ```
 */
export class FunctionsRelayError extends FunctionsError {
    constructor(context) {
        super('Relay Error invoking the Edge Function', 'FunctionsRelayError', context);
    }
}
/**
 * Error thrown when the Edge Function returns a non-2xx status code.
 *
 * @example
 * ```ts
 * import { FunctionsHttpError } from '@supabase/functions-js'
 *
 * throw new FunctionsHttpError({ status: 500 })
 * ```
 */
export class FunctionsHttpError extends FunctionsError {
    constructor(context) {
        super('Edge Function returned a non-2xx status code', 'FunctionsHttpError', context);
    }
}
// Define the enum for the 'region' property
export var FunctionRegion;
(function (FunctionRegion) {
    FunctionRegion["Any"] = "any";
    FunctionRegion["ApNortheast1"] = "ap-northeast-1";
    FunctionRegion["ApNortheast2"] = "ap-northeast-2";
    FunctionRegion["ApSouth1"] = "ap-south-1";
    FunctionRegion["ApSoutheast1"] = "ap-southeast-1";
    FunctionRegion["ApSoutheast2"] = "ap-southeast-2";
    FunctionRegion["CaCentral1"] = "ca-central-1";
    FunctionRegion["EuCentral1"] = "eu-central-1";
    FunctionRegion["EuWest1"] = "eu-west-1";
    FunctionRegion["EuWest2"] = "eu-west-2";
    FunctionRegion["EuWest3"] = "eu-west-3";
    FunctionRegion["SaEast1"] = "sa-east-1";
    FunctionRegion["UsEast1"] = "us-east-1";
    FunctionRegion["UsWest1"] = "us-west-1";
    FunctionRegion["UsWest2"] = "us-west-2";
})(FunctionRegion || (FunctionRegion = {}));
                                 
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHlwZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdHlwZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBaUJBOzs7Ozs7Ozs7OztHQVdHO0FBQ0gsTUFBTSxPQUFPLGNBQWUsU0FBUSxLQUFLO0lBRXZDLFlBQVksT0FBZSxFQUFFLElBQUksR0FBRyxnQkFBZ0IsRUFBRSxPQUFhO1FBQ2pFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUNkLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO1FBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFBO0lBQ3hCLENBQUM7SUFFRCxNQUFNO1FBQ0osT0FBTztZQUNMLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtZQUNmLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztZQUNyQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87U0FDdEIsQ0FBQTtJQUNILENBQUM7Q0FDRjtBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILE1BQU0sT0FBTyxtQkFBb0IsU0FBUSxjQUFjO0lBQ3JELFlBQVksT0FBWTtRQUN0QixLQUFLLENBQUMsK0NBQStDLEVBQUUscUJBQXFCLEVBQUUsT0FBTyxDQUFDLENBQUE7SUFDeEYsQ0FBQztDQUNGO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsTUFBTSxPQUFPLG1CQUFvQixTQUFRLGNBQWM7SUFDckQsWUFBWSxPQUFZO1FBQ3RCLEtBQUssQ0FBQyx3Q0FBd0MsRUFBRSxxQkFBcUIsRUFBRSxPQUFPLENBQUMsQ0FBQTtJQUNqRixDQUFDO0NBQ0Y7QUFFRDs7Ozs7Ozs7O0dBU0c7QUFDSCxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsY0FBYztJQUNwRCxZQUFZLE9BQVk7UUFDdEIsS0FBSyxDQUFDLDhDQUE4QyxFQUFFLG9CQUFvQixFQUFFLE9BQU8sQ0FBQyxDQUFBO0lBQ3RGLENBQUM7Q0FDRjtBQUNELDRDQUE0QztBQUM1QyxNQUFNLENBQU4sSUFBWSxjQWdCWDtBQWhCRCxXQUFZLGNBQWM7SUFDeEIsNkJBQVcsQ0FBQTtJQUNYLGlEQUErQixDQUFBO0lBQy9CLGlEQUErQixDQUFBO0lBQy9CLHlDQUF1QixDQUFBO0lBQ3ZCLGlEQUErQixDQUFBO0lBQy9CLGlEQUErQixDQUFBO0lBQy9CLDZDQUEyQixDQUFBO0lBQzNCLDZDQUEyQixDQUFBO0lBQzNCLHVDQUFxQixDQUFBO0lBQ3JCLHVDQUFxQixDQUFBO0lBQ3JCLHVDQUFxQixDQUFBO0lBQ3JCLHVDQUFxQixDQUFBO0lBQ3JCLHVDQUFxQixDQUFBO0lBQ3JCLHVDQUFxQixDQUFBO0lBQ3JCLHVDQUFxQixDQUFBO0FBQ3ZCLENBQUMsRUFoQlcsY0FBYyxLQUFkLGNBQWMsUUFnQnpCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHR5cGUgRmV0Y2ggPSB0eXBlb2YgZmV0Y2hcblxuLyoqXG4gKiBSZXNwb25zZSBmb3JtYXRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBGdW5jdGlvbnNSZXNwb25zZVN1Y2Nlc3M8VD4ge1xuICBkYXRhOiBUXG4gIGVycm9yOiBudWxsXG4gIHJlc3BvbnNlPzogUmVzcG9uc2Vcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRnVuY3Rpb25zUmVzcG9uc2VGYWlsdXJlIHtcbiAgZGF0YTogbnVsbFxuICBlcnJvcjogYW55XG4gIHJlc3BvbnNlPzogUmVzcG9uc2Vcbn1cbmV4cG9ydCB0eXBlIEZ1bmN0aW9uc1Jlc3BvbnNlPFQ+ID0gRnVuY3Rpb25zUmVzcG9uc2VTdWNjZXNzPFQ+IHwgRnVuY3Rpb25zUmVzcG9uc2VGYWlsdXJlXG5cbi8qKlxuICogQmFzZSBlcnJvciBmb3IgU3VwYWJhc2UgRWRnZSBGdW5jdGlvbiBpbnZvY2F0aW9ucy5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IEZ1bmN0aW9uc0Vycm9yIH0gZnJvbSAnQHN1cGFiYXNlL2Z1bmN0aW9ucy1qcydcbiAqXG4gKiB0aHJvdyBuZXcgRnVuY3Rpb25zRXJyb3IoJ1VuZXhwZWN0ZWQgZXJyb3IgaW52b2tpbmcgZnVuY3Rpb24nLCAnRnVuY3Rpb25zRXJyb3InLCB7XG4gKiAgIHJlcXVlc3RJZDogJ2FiYzEyMycsXG4gKiB9KVxuICogYGBgXG4gKi9cbmV4cG9ydCBjbGFzcyBGdW5jdGlvbnNFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29udGV4dDogYW55XG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZywgbmFtZSA9ICdGdW5jdGlvbnNFcnJvcicsIGNvbnRleHQ/OiBhbnkpIHtcbiAgICBzdXBlcihtZXNzYWdlKVxuICAgIHRoaXMubmFtZSA9IG5hbWVcbiAgICB0aGlzLmNvbnRleHQgPSBjb250ZXh0XG4gIH1cblxuICB0b0pTT04oKTogeyBuYW1lOiBzdHJpbmc7IG1lc3NhZ2U6IHN0cmluZzsgY29udGV4dDogYW55IH0ge1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBtZXNzYWdlOiB0aGlzLm1lc3NhZ2UsXG4gICAgICBjb250ZXh0OiB0aGlzLmNvbnRleHQsXG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogRXJyb3IgdGhyb3duIHdoZW4gdGhlIG5ldHdvcmsgcmVxdWVzdCB0byBhbiBFZGdlIEZ1bmN0aW9uIGZhaWxzLlxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgRnVuY3Rpb25zRmV0Y2hFcnJvciB9IGZyb20gJ0BzdXBhYmFzZS9mdW5jdGlvbnMtanMnXG4gKlxuICogdGhyb3cgbmV3IEZ1bmN0aW9uc0ZldGNoRXJyb3IoeyByZXF1ZXN0SWQ6ICdhYmMxMjMnIH0pXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNsYXNzIEZ1bmN0aW9uc0ZldGNoRXJyb3IgZXh0ZW5kcyBGdW5jdGlvbnNFcnJvciB7XG4gIGNvbnN0cnVjdG9yKGNvbnRleHQ6IGFueSkge1xuICAgIHN1cGVyKCdGYWlsZWQgdG8gc2VuZCBhIHJlcXVlc3QgdG8gdGhlIEVkZ2UgRnVuY3Rpb24nLCAnRnVuY3Rpb25zRmV0Y2hFcnJvcicsIGNvbnRleHQpXG4gIH1cbn1cblxuLyoqXG4gKiBFcnJvciB0aHJvd24gd2hlbiB0aGUgU3VwYWJhc2UgcmVsYXkgY2Fubm90IHJlYWNoIHRoZSBFZGdlIEZ1bmN0aW9uLlxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgRnVuY3Rpb25zUmVsYXlFcnJvciB9IGZyb20gJ0BzdXBhYmFzZS9mdW5jdGlvbnMtanMnXG4gKlxuICogdGhyb3cgbmV3IEZ1bmN0aW9uc1JlbGF5RXJyb3IoeyByZWdpb246ICd1cy1lYXN0LTEnIH0pXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNsYXNzIEZ1bmN0aW9uc1JlbGF5RXJyb3IgZXh0ZW5kcyBGdW5jdGlvbnNFcnJvciB7XG4gIGNvbnN0cnVjdG9yKGNvbnRleHQ6IGFueSkge1xuICAgIHN1cGVyKCdSZWxheSBFcnJvciBpbnZva2luZyB0aGUgRWRnZSBGdW5jdGlvbicsICdGdW5jdGlvbnNSZWxheUVycm9yJywgY29udGV4dClcbiAgfVxufVxuXG4vKipcbiAqIEVycm9yIHRocm93biB3aGVuIHRoZSBFZGdlIEZ1bmN0aW9uIHJldHVybnMgYSBub24tMnh4IHN0YXR1cyBjb2RlLlxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgRnVuY3Rpb25zSHR0cEVycm9yIH0gZnJvbSAnQHN1cGFiYXNlL2Z1bmN0aW9ucy1qcydcbiAqXG4gKiB0aHJvdyBuZXcgRnVuY3Rpb25zSHR0cEVycm9yKHsgc3RhdHVzOiA1MDAgfSlcbiAqIGBgYFxuICovXG5leHBvcnQgY2xhc3MgRnVuY3Rpb25zSHR0cEVycm9yIGV4dGVuZHMgRnVuY3Rpb25zRXJyb3Ige1xuICBjb25zdHJ1Y3Rvcihjb250ZXh0OiBhbnkpIHtcbiAgICBzdXBlcignRWRnZSBGdW5jdGlvbiByZXR1cm5lZCBhIG5vbi0yeHggc3RhdHVzIGNvZGUnLCAnRnVuY3Rpb25zSHR0cEVycm9yJywgY29udGV4dClcbiAgfVxufVxuLy8gRGVmaW5lIHRoZSBlbnVtIGZvciB0aGUgJ3JlZ2lvbicgcHJvcGVydHlcbmV4cG9ydCBlbnVtIEZ1bmN0aW9uUmVnaW9uIHtcbiAgQW55ID0gJ2FueScsXG4gIEFwTm9ydGhlYXN0MSA9ICdhcC1ub3J0aGVhc3QtMScsXG4gIEFwTm9ydGhlYXN0MiA9ICdhcC1ub3J0aGVhc3QtMicsXG4gIEFwU291dGgxID0gJ2FwLXNvdXRoLTEnLFxuICBBcFNvdXRoZWFzdDEgPSAnYXAtc291dGhlYXN0LTEnLFxuICBBcFNvdXRoZWFzdDIgPSAnYXAtc291dGhlYXN0LTInLFxuICBDYUNlbnRyYWwxID0gJ2NhLWNlbnRyYWwtMScsXG4gIEV1Q2VudHJhbDEgPSAnZXUtY2VudHJhbC0xJyxcbiAgRXVXZXN0MSA9ICdldS13ZXN0LTEnLFxuICBFdVdlc3QyID0gJ2V1LXdlc3QtMicsXG4gIEV1V2VzdDMgPSAnZXUtd2VzdC0zJyxcbiAgU2FFYXN0MSA9ICdzYS1lYXN0LTEnLFxuICBVc0Vhc3QxID0gJ3VzLWVhc3QtMScsXG4gIFVzV2VzdDEgPSAndXMtd2VzdC0xJyxcbiAgVXNXZXN0MiA9ICd1cy13ZXN0LTInLFxufVxuXG5leHBvcnQgdHlwZSBGdW5jdGlvbkludm9rZU9wdGlvbnMgPSB7XG4gIC8qKlxuICAgKiBPYmplY3QgcmVwcmVzZW50aW5nIHRoZSBoZWFkZXJzIHRvIHNlbmQgd2l0aCB0aGUgcmVxdWVzdC5cbiAgICovXG4gIGhlYWRlcnM/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9XG4gIC8qKlxuICAgKiBUaGUgSFRUUCB2ZXJiIG9mIHRoZSByZXF1ZXN0XG4gICAqL1xuICBtZXRob2Q/OiAnUE9TVCcgfCAnR0VUJyB8ICdQVVQnIHwgJ1BBVENIJyB8ICdERUxFVEUnXG4gIC8qKlxuICAgKiBUaGUgUmVnaW9uIHRvIGludm9rZSB0aGUgZnVuY3Rpb24gaW4uXG4gICAqL1xuICByZWdpb24/OiBGdW5jdGlvblJlZ2lvblxuICAvKipcbiAgICogVGhlIGJvZHkgb2YgdGhlIHJlcXVlc3QuXG4gICAqL1xuICBib2R5PzpcbiAgICB8IEZpbGVcbiAgICB8IEJsb2JcbiAgICB8IEFycmF5QnVmZmVyXG4gICAgfCBGb3JtRGF0YVxuICAgIHwgUmVhZGFibGVTdHJlYW08VWludDhBcnJheT5cbiAgICB8IFJlY29yZDxzdHJpbmcsIGFueT5cbiAgICB8IHN0cmluZ1xuICAvKipcbiAgICogVGhlIEFib3J0U2lnbmFsIHRvIHVzZSBmb3IgdGhlIHJlcXVlc3QuXG4gICAqICovXG4gIHNpZ25hbD86IEFib3J0U2lnbmFsXG4gIC8qKlxuICAgKiBUaGUgdGltZW91dCBmb3IgdGhlIHJlcXVlc3QgaW4gbWlsbGlzZWNvbmRzLlxuICAgKiBJZiB0aGUgZnVuY3Rpb24gdGFrZXMgbG9uZ2VyIHRoYW4gdGhpcywgdGhlIHJlcXVlc3Qgd2lsbCBiZSBhYm9ydGVkLlxuICAgKiAqL1xuICB0aW1lb3V0PzogbnVtYmVyXG59XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==