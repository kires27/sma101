/**
 * Utilities for creating WebSocket instances across runtimes.
 */
export class WebSocketFactory {
    /**
     * Static-only utility – prevent instantiation.
     */
    constructor() { }
    static detectEnvironment() {
        var _a;
        if (typeof WebSocket !== 'undefined') {
            return { type: 'native', wsConstructor: WebSocket };
        }
        const gt = globalThis;
        if (typeof globalThis !== 'undefined' && typeof gt.WebSocket !== 'undefined') {
            return { type: 'native', wsConstructor: gt.WebSocket };
        }
        const gl = typeof global !== 'undefined' ? global : undefined;
        if (gl && typeof gl.WebSocket !== 'undefined') {
            return { type: 'native', wsConstructor: gl.WebSocket };
        }
        if (typeof globalThis !== 'undefined' &&
            typeof gt.WebSocketPair !== 'undefined' &&
            typeof globalThis.WebSocket === 'undefined') {
            return {
                type: 'cloudflare',
                error: 'Cloudflare Workers detected. WebSocket clients are not supported in Cloudflare Workers.',
                workaround: 'Use Cloudflare Workers WebSocket API for server-side WebSocket handling, or deploy to a different runtime.',
            };
        }
        if ((typeof globalThis !== 'undefined' && gt.EdgeRuntime) ||
            (typeof navigator !== 'undefined' && ((_a = navigator.userAgent) === null || _a === void 0 ? void 0 : _a.includes('Vercel-Edge')))) {
            return {
                type: 'unsupported',
                error: 'Edge runtime detected (Vercel Edge/Netlify Edge). WebSockets are not supported in edge functions.',
                workaround: 'Use serverless functions or a different deployment target for WebSocket functionality.',
            };
        }
        // Use dynamic property access to avoid Next.js Edge Runtime static analysis warnings
        const _process = globalThis['process'];
        if (_process) {
            const processVersions = _process['versions'];
            if (processVersions && processVersions['node']) {
                // Remove 'v' prefix if present and parse the major version
                const versionString = processVersions['node'];
                const nodeVersion = parseInt(versionString.replace(/^v/, '').split('.')[0]);
                // Node.js 22+ should have native WebSocket
                if (nodeVersion >= 22) {
                    // Check if native WebSocket is available (should be in Node.js 22+)
                    if (typeof globalThis.WebSocket !== 'undefined') {
                        return { type: 'native', wsConstructor: globalThis.WebSocket };
                    }
                    // If not available, user needs to provide it
                    return {
                        type: 'unsupported',
                        error: `Node.js ${nodeVersion} detected but native WebSocket not found.`,
                        workaround: 'Provide a WebSocket implementation via the transport option.',
                    };
                }
                // Node.js < 22 doesn't have native WebSocket
                return {
                    type: 'unsupported',
                    error: `Node.js ${nodeVersion} detected without native WebSocket support.`,
                    workaround: 'For Node.js < 22, install "ws" package and provide it via the transport option:\n' +
                        'import ws from "ws"\n' +
                        'new RealtimeClient(url, { transport: ws })',
                };
            }
        }
        return {
            type: 'unsupported',
            error: 'Unknown JavaScript runtime without WebSocket support.',
            workaround: "Ensure you're running in a supported environment (browser, Node.js, Deno) or provide a custom WebSocket implementation.",
        };
    }
    /**
     * Returns the best available WebSocket constructor for the current runtime.
     *
     * @category Realtime
     *
     * @example Example with error handling
     * ```ts
     * try {
     *   const WS = WebSocketFactory.getWebSocketConstructor()
     *   const socket = new WS('wss://example.com/socket')
     * } catch (error) {
     *   console.error('WebSocket not available in this environment.', error)
     * }
     * ```
     */
    static getWebSocketConstructor() {
        const env = this.detectEnvironment();
        if (env.wsConstructor) {
            return env.wsConstructor;
        }
        let errorMessage = env.error || 'WebSocket not supported in this environment.';
        if (env.workaround) {
            errorMessage += `\n\nSuggested solution: ${env.workaround}`;
        }
        throw new Error(errorMessage);
    }
    /**
     * Detects whether the runtime can establish WebSocket connections.
     *
     * @category Realtime
     *
     * @example Example in a Node.js script
     * ```ts
     * if (!WebSocketFactory.isWebSocketSupported()) {
     *   console.error('WebSockets are required for this script.')
     *   process.exitCode = 1
     * }
     * ```
     */
    static isWebSocketSupported() {
        try {
            const env = this.detectEnvironment();
            return env.type === 'native' || env.type === 'ws';
        }
        catch (_a) {
            return false;
        }
    }
}
export default WebSocketFactory;
                                             
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2Vic29ja2V0LWZhY3RvcnkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvbGliL3dlYnNvY2tldC1mYWN0b3J5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXlEQTs7R0FFRztBQUNILE1BQU0sT0FBTyxnQkFBZ0I7SUFDM0I7O09BRUc7SUFDSCxnQkFBdUIsQ0FBQztJQUNoQixNQUFNLENBQUMsaUJBQWlCOztRQUM5QixJQUFJLE9BQU8sU0FBUyxLQUFLLFdBQVcsRUFBRSxDQUFDO1lBQ3JDLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsQ0FBQTtRQUNyRCxDQUFDO1FBRUQsTUFBTSxFQUFFLEdBQUcsVUFBZ0QsQ0FBQTtRQUMzRCxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUUsQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFLENBQUM7WUFDN0UsT0FBTyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLEVBQUUsQ0FBQyxTQUE2QixFQUFFLENBQUE7UUFDNUUsQ0FBQztRQUVELE1BQU0sRUFBRSxHQUNOLE9BQU8sTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUUsTUFBeUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFBO1FBQ3hGLElBQUksRUFBRSxJQUFJLE9BQU8sRUFBRSxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUM5QyxPQUFPLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsRUFBRSxDQUFDLFNBQTZCLEVBQUUsQ0FBQTtRQUM1RSxDQUFDO1FBRUQsSUFDRSxPQUFPLFVBQVUsS0FBSyxXQUFXO1lBQ2pDLE9BQU8sRUFBRSxDQUFDLGFBQWEsS0FBSyxXQUFXO1lBQ3ZDLE9BQU8sVUFBVSxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQzNDLENBQUM7WUFDRCxPQUFPO2dCQUNMLElBQUksRUFBRSxZQUFZO2dCQUNsQixLQUFLLEVBQ0gseUZBQXlGO2dCQUMzRixVQUFVLEVBQ1IsNEdBQTRHO2FBQy9HLENBQUE7UUFDSCxDQUFDO1FBRUQsSUFDRSxDQUFDLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDO1lBQ3JELENBQUMsT0FBTyxTQUFTLEtBQUssV0FBVyxLQUFJLE1BQUEsU0FBUyxDQUFDLFNBQVMsMENBQUUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFBLENBQUMsRUFDbEYsQ0FBQztZQUNELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLGFBQWE7Z0JBQ25CLEtBQUssRUFDSCxtR0FBbUc7Z0JBQ3JHLFVBQVUsRUFDUix3RkFBd0Y7YUFDM0YsQ0FBQTtRQUNILENBQUM7UUFFRCxxRkFBcUY7UUFDckYsTUFBTSxRQUFRLEdBQUksVUFBc0MsQ0FBQyxTQUFTLENBRXJELENBQUE7UUFDYixJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQ2IsTUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQzVDLElBQUksZUFBZSxJQUFJLGVBQWUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dCQUMvQywyREFBMkQ7Z0JBQzNELE1BQU0sYUFBYSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtnQkFDN0MsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO2dCQUUzRSwyQ0FBMkM7Z0JBQzNDLElBQUksV0FBVyxJQUFJLEVBQUUsRUFBRSxDQUFDO29CQUN0QixvRUFBb0U7b0JBQ3BFLElBQUksT0FBTyxVQUFVLENBQUMsU0FBUyxLQUFLLFdBQVcsRUFBRSxDQUFDO3dCQUNoRCxPQUFPLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsVUFBVSxDQUFDLFNBQVMsRUFBRSxDQUFBO29CQUNoRSxDQUFDO29CQUNELDZDQUE2QztvQkFDN0MsT0FBTzt3QkFDTCxJQUFJLEVBQUUsYUFBYTt3QkFDbkIsS0FBSyxFQUFFLFdBQVcsV0FBVywyQ0FBMkM7d0JBQ3hFLFVBQVUsRUFBRSw4REFBOEQ7cUJBQzNFLENBQUE7Z0JBQ0gsQ0FBQztnQkFFRCw2Q0FBNkM7Z0JBQzdDLE9BQU87b0JBQ0wsSUFBSSxFQUFFLGFBQWE7b0JBQ25CLEtBQUssRUFBRSxXQUFXLFdBQVcsNkNBQTZDO29CQUMxRSxVQUFVLEVBQ1IsbUZBQW1GO3dCQUNuRix1QkFBdUI7d0JBQ3ZCLDRDQUE0QztpQkFDL0MsQ0FBQTtZQUNILENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTztZQUNMLElBQUksRUFBRSxhQUFhO1lBQ25CLEtBQUssRUFBRSx1REFBdUQ7WUFDOUQsVUFBVSxFQUNSLHlIQUF5SDtTQUM1SCxDQUFBO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0ksTUFBTSxDQUFDLHVCQUF1QjtRQUNuQyxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtRQUNwQyxJQUFJLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN0QixPQUFPLEdBQUcsQ0FBQyxhQUFhLENBQUE7UUFDMUIsQ0FBQztRQUNELElBQUksWUFBWSxHQUFHLEdBQUcsQ0FBQyxLQUFLLElBQUksOENBQThDLENBQUE7UUFDOUUsSUFBSSxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDbkIsWUFBWSxJQUFJLDJCQUEyQixHQUFHLENBQUMsVUFBVSxFQUFFLENBQUE7UUFDN0QsQ0FBQztRQUNELE1BQU0sSUFBSSxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUE7SUFDL0IsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNJLE1BQU0sQ0FBQyxvQkFBb0I7UUFDaEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUE7WUFDcEMsT0FBTyxHQUFHLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxHQUFHLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQTtRQUNuRCxDQUFDO1FBQUMsV0FBTSxDQUFDO1lBQ1AsT0FBTyxLQUFLLENBQUE7UUFDZCxDQUFDO0lBQ0gsQ0FBQztDQUNGO0FBRUQsZUFBZSxnQkFBZ0IsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBpbnRlcmZhY2UgV2ViU29ja2V0TGlrZSB7XG4gIHJlYWRvbmx5IENPTk5FQ1RJTkc6IG51bWJlclxuICByZWFkb25seSBPUEVOOiBudW1iZXJcbiAgcmVhZG9ubHkgQ0xPU0lORzogbnVtYmVyXG4gIHJlYWRvbmx5IENMT1NFRDogbnVtYmVyXG4gIHJlYWRvbmx5IHJlYWR5U3RhdGU6IG51bWJlclxuICByZWFkb25seSB1cmw6IHN0cmluZ1xuICByZWFkb25seSBwcm90b2NvbDogc3RyaW5nXG5cbiAgLyoqXG4gICAqIENsb3NlcyB0aGUgc29ja2V0LCBvcHRpb25hbGx5IHByb3ZpZGluZyBhIGNsb3NlIGNvZGUgYW5kIHJlYXNvbi5cbiAgICovXG4gIGNsb3NlKGNvZGU/OiBudW1iZXIsIHJlYXNvbj86IHN0cmluZyk6IHZvaWRcbiAgLyoqXG4gICAqIFNlbmRzIGRhdGEgdGhyb3VnaCB0aGUgc29ja2V0IHVzaW5nIHRoZSB1bmRlcmx5aW5nIGltcGxlbWVudGF0aW9uLlxuICAgKi9cbiAgc2VuZChkYXRhOiBzdHJpbmcgfCBBcnJheUJ1ZmZlckxpa2UgfCBCbG9iIHwgQXJyYXlCdWZmZXJWaWV3KTogdm9pZFxuXG4gIG9ub3BlbjogKCh0aGlzOiBhbnksIGV2OiBFdmVudCkgPT4gYW55KSB8IG51bGxcbiAgb25tZXNzYWdlOiAoKHRoaXM6IGFueSwgZXY6IE1lc3NhZ2VFdmVudCkgPT4gYW55KSB8IG51bGxcbiAgb25jbG9zZTogKCh0aGlzOiBhbnksIGV2OiBDbG9zZUV2ZW50KSA9PiBhbnkpIHwgbnVsbFxuICBvbmVycm9yOiAoKHRoaXM6IGFueSwgZXY6IEV2ZW50KSA9PiBhbnkpIHwgbnVsbFxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYW4gZXZlbnQgbGlzdGVuZXIgb24gdGhlIHNvY2tldCAoY29tcGF0aWJsZSB3aXRoIGJyb3dzZXIgV2ViU29ja2V0IEFQSSkuXG4gICAqL1xuICBhZGRFdmVudExpc3RlbmVyKHR5cGU6IHN0cmluZywgbGlzdGVuZXI6IEV2ZW50TGlzdGVuZXIpOiB2b2lkXG4gIC8qKlxuICAgKiBSZW1vdmVzIGEgcHJldmlvdXNseSByZWdpc3RlcmVkIGV2ZW50IGxpc3RlbmVyLlxuICAgKi9cbiAgcmVtb3ZlRXZlbnRMaXN0ZW5lcih0eXBlOiBzdHJpbmcsIGxpc3RlbmVyOiBFdmVudExpc3RlbmVyKTogdm9pZFxuXG4gIC8vIEFkZCBhZGRpdGlvbmFsIHByb3BlcnRpZXMgdGhhdCBtYXkgZXhpc3Qgb24gV2ViU29ja2V0IGltcGxlbWVudGF0aW9uc1xuICBiaW5hcnlUeXBlPzogc3RyaW5nXG4gIGJ1ZmZlcmVkQW1vdW50PzogbnVtYmVyXG4gIGV4dGVuc2lvbnM/OiBzdHJpbmdcbiAgZGlzcGF0Y2hFdmVudD86IChldmVudDogRXZlbnQpID0+IGJvb2xlYW5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBXZWJTb2NrZXRFbnZpcm9ubWVudCB7XG4gIHR5cGU6ICduYXRpdmUnIHwgJ3dzJyB8ICdjbG91ZGZsYXJlJyB8ICd1bnN1cHBvcnRlZCdcbiAgLyoqIFdlYlNvY2tldCBjb25zdHJ1Y3RvciBmb3IgdGhpcyBlbnZpcm9ubWVudCwgaWYgYXZhaWxhYmxlLiAqL1xuICB3c0NvbnN0cnVjdG9yPzogdHlwZW9mIFdlYlNvY2tldFxuICBlcnJvcj86IHN0cmluZ1xuICB3b3JrYXJvdW5kPzogc3RyaW5nXG59XG5cbi8qKlxuICogRXh0ZW5kZWQgZ2xvYmFsVGhpcyB3aXRoIG9wdGlvbmFsIHJ1bnRpbWUtc3BlY2lmaWMgcHJvcGVydGllc1xuICogdGhhdCBtYXkgb3IgbWF5IG5vdCBleGlzdCBkZXBlbmRpbmcgb24gdGhlIGVudmlyb25tZW50LlxuICovXG5pbnRlcmZhY2UgUnVudGltZUdsb2JhbHMge1xuICBXZWJTb2NrZXQ/OiB7IG5ldyAodXJsOiBzdHJpbmcsIHByb3RvY29scz86IHN0cmluZyB8IHN0cmluZ1tdKTogV2ViU29ja2V0TGlrZSB9XG4gIFdlYlNvY2tldFBhaXI/OiB1bmtub3duXG4gIEVkZ2VSdW50aW1lPzogdW5rbm93blxufVxuXG4vKipcbiAqIFV0aWxpdGllcyBmb3IgY3JlYXRpbmcgV2ViU29ja2V0IGluc3RhbmNlcyBhY3Jvc3MgcnVudGltZXMuXG4gKi9cbmV4cG9ydCBjbGFzcyBXZWJTb2NrZXRGYWN0b3J5IHtcbiAgLyoqXG4gICAqIFN0YXRpYy1vbmx5IHV0aWxpdHkg4oCTIHByZXZlbnQgaW5zdGFudGlhdGlvbi5cbiAgICovXG4gIHByaXZhdGUgY29uc3RydWN0b3IoKSB7fVxuICBwcml2YXRlIHN0YXRpYyBkZXRlY3RFbnZpcm9ubWVudCgpOiBXZWJTb2NrZXRFbnZpcm9ubWVudCB7XG4gICAgaWYgKHR5cGVvZiBXZWJTb2NrZXQgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICByZXR1cm4geyB0eXBlOiAnbmF0aXZlJywgd3NDb25zdHJ1Y3RvcjogV2ViU29ja2V0IH1cbiAgICB9XG5cbiAgICBjb25zdCBndCA9IGdsb2JhbFRoaXMgYXMgdHlwZW9mIGdsb2JhbFRoaXMgJiBSdW50aW1lR2xvYmFsc1xuICAgIGlmICh0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGd0LldlYlNvY2tldCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHJldHVybiB7IHR5cGU6ICduYXRpdmUnLCB3c0NvbnN0cnVjdG9yOiBndC5XZWJTb2NrZXQgYXMgdHlwZW9mIFdlYlNvY2tldCB9XG4gICAgfVxuXG4gICAgY29uc3QgZ2wgPVxuICAgICAgdHlwZW9mIGdsb2JhbCAhPT0gJ3VuZGVmaW5lZCcgPyAoZ2xvYmFsIGFzIHR5cGVvZiBnbG9iYWwgJiBSdW50aW1lR2xvYmFscykgOiB1bmRlZmluZWRcbiAgICBpZiAoZ2wgJiYgdHlwZW9mIGdsLldlYlNvY2tldCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHJldHVybiB7IHR5cGU6ICduYXRpdmUnLCB3c0NvbnN0cnVjdG9yOiBnbC5XZWJTb2NrZXQgYXMgdHlwZW9mIFdlYlNvY2tldCB9XG4gICAgfVxuXG4gICAgaWYgKFxuICAgICAgdHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICB0eXBlb2YgZ3QuV2ViU29ja2V0UGFpciAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgIHR5cGVvZiBnbG9iYWxUaGlzLldlYlNvY2tldCA9PT0gJ3VuZGVmaW5lZCdcbiAgICApIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6ICdjbG91ZGZsYXJlJyxcbiAgICAgICAgZXJyb3I6XG4gICAgICAgICAgJ0Nsb3VkZmxhcmUgV29ya2VycyBkZXRlY3RlZC4gV2ViU29ja2V0IGNsaWVudHMgYXJlIG5vdCBzdXBwb3J0ZWQgaW4gQ2xvdWRmbGFyZSBXb3JrZXJzLicsXG4gICAgICAgIHdvcmthcm91bmQ6XG4gICAgICAgICAgJ1VzZSBDbG91ZGZsYXJlIFdvcmtlcnMgV2ViU29ja2V0IEFQSSBmb3Igc2VydmVyLXNpZGUgV2ViU29ja2V0IGhhbmRsaW5nLCBvciBkZXBsb3kgdG8gYSBkaWZmZXJlbnQgcnVudGltZS4nLFxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChcbiAgICAgICh0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gJ3VuZGVmaW5lZCcgJiYgZ3QuRWRnZVJ1bnRpbWUpIHx8XG4gICAgICAodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudD8uaW5jbHVkZXMoJ1ZlcmNlbC1FZGdlJykpXG4gICAgKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiAndW5zdXBwb3J0ZWQnLFxuICAgICAgICBlcnJvcjpcbiAgICAgICAgICAnRWRnZSBydW50aW1lIGRldGVjdGVkIChWZXJjZWwgRWRnZS9OZXRsaWZ5IEVkZ2UpLiBXZWJTb2NrZXRzIGFyZSBub3Qgc3VwcG9ydGVkIGluIGVkZ2UgZnVuY3Rpb25zLicsXG4gICAgICAgIHdvcmthcm91bmQ6XG4gICAgICAgICAgJ1VzZSBzZXJ2ZXJsZXNzIGZ1bmN0aW9ucyBvciBhIGRpZmZlcmVudCBkZXBsb3ltZW50IHRhcmdldCBmb3IgV2ViU29ja2V0IGZ1bmN0aW9uYWxpdHkuJyxcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBVc2UgZHluYW1pYyBwcm9wZXJ0eSBhY2Nlc3MgdG8gYXZvaWQgTmV4dC5qcyBFZGdlIFJ1bnRpbWUgc3RhdGljIGFuYWx5c2lzIHdhcm5pbmdzXG4gICAgY29uc3QgX3Byb2Nlc3MgPSAoZ2xvYmFsVGhpcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilbJ3Byb2Nlc3MnXSBhc1xuICAgICAgfCB7IHZlcnNpb25zPzogeyBub2RlPzogc3RyaW5nIH0gfVxuICAgICAgfCB1bmRlZmluZWRcbiAgICBpZiAoX3Byb2Nlc3MpIHtcbiAgICAgIGNvbnN0IHByb2Nlc3NWZXJzaW9ucyA9IF9wcm9jZXNzWyd2ZXJzaW9ucyddXG4gICAgICBpZiAocHJvY2Vzc1ZlcnNpb25zICYmIHByb2Nlc3NWZXJzaW9uc1snbm9kZSddKSB7XG4gICAgICAgIC8vIFJlbW92ZSAndicgcHJlZml4IGlmIHByZXNlbnQgYW5kIHBhcnNlIHRoZSBtYWpvciB2ZXJzaW9uXG4gICAgICAgIGNvbnN0IHZlcnNpb25TdHJpbmcgPSBwcm9jZXNzVmVyc2lvbnNbJ25vZGUnXVxuICAgICAgICBjb25zdCBub2RlVmVyc2lvbiA9IHBhcnNlSW50KHZlcnNpb25TdHJpbmcucmVwbGFjZSgvXnYvLCAnJykuc3BsaXQoJy4nKVswXSlcblxuICAgICAgICAvLyBOb2RlLmpzIDIyKyBzaG91bGQgaGF2ZSBuYXRpdmUgV2ViU29ja2V0XG4gICAgICAgIGlmIChub2RlVmVyc2lvbiA+PSAyMikge1xuICAgICAgICAgIC8vIENoZWNrIGlmIG5hdGl2ZSBXZWJTb2NrZXQgaXMgYXZhaWxhYmxlIChzaG91bGQgYmUgaW4gTm9kZS5qcyAyMispXG4gICAgICAgICAgaWYgKHR5cGVvZiBnbG9iYWxUaGlzLldlYlNvY2tldCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIHJldHVybiB7IHR5cGU6ICduYXRpdmUnLCB3c0NvbnN0cnVjdG9yOiBnbG9iYWxUaGlzLldlYlNvY2tldCB9XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIElmIG5vdCBhdmFpbGFibGUsIHVzZXIgbmVlZHMgdG8gcHJvdmlkZSBpdFxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB0eXBlOiAndW5zdXBwb3J0ZWQnLFxuICAgICAgICAgICAgZXJyb3I6IGBOb2RlLmpzICR7bm9kZVZlcnNpb259IGRldGVjdGVkIGJ1dCBuYXRpdmUgV2ViU29ja2V0IG5vdCBmb3VuZC5gLFxuICAgICAgICAgICAgd29ya2Fyb3VuZDogJ1Byb3ZpZGUgYSBXZWJTb2NrZXQgaW1wbGVtZW50YXRpb24gdmlhIHRoZSB0cmFuc3BvcnQgb3B0aW9uLicsXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gTm9kZS5qcyA8IDIyIGRvZXNuJ3QgaGF2ZSBuYXRpdmUgV2ViU29ja2V0XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdHlwZTogJ3Vuc3VwcG9ydGVkJyxcbiAgICAgICAgICBlcnJvcjogYE5vZGUuanMgJHtub2RlVmVyc2lvbn0gZGV0ZWN0ZWQgd2l0aG91dCBuYXRpdmUgV2ViU29ja2V0IHN1cHBvcnQuYCxcbiAgICAgICAgICB3b3JrYXJvdW5kOlxuICAgICAgICAgICAgJ0ZvciBOb2RlLmpzIDwgMjIsIGluc3RhbGwgXCJ3c1wiIHBhY2thZ2UgYW5kIHByb3ZpZGUgaXQgdmlhIHRoZSB0cmFuc3BvcnQgb3B0aW9uOlxcbicgK1xuICAgICAgICAgICAgJ2ltcG9ydCB3cyBmcm9tIFwid3NcIlxcbicgK1xuICAgICAgICAgICAgJ25ldyBSZWFsdGltZUNsaWVudCh1cmwsIHsgdHJhbnNwb3J0OiB3cyB9KScsXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgdHlwZTogJ3Vuc3VwcG9ydGVkJyxcbiAgICAgIGVycm9yOiAnVW5rbm93biBKYXZhU2NyaXB0IHJ1bnRpbWUgd2l0aG91dCBXZWJTb2NrZXQgc3VwcG9ydC4nLFxuICAgICAgd29ya2Fyb3VuZDpcbiAgICAgICAgXCJFbnN1cmUgeW91J3JlIHJ1bm5pbmcgaW4gYSBzdXBwb3J0ZWQgZW52aXJvbm1lbnQgKGJyb3dzZXIsIE5vZGUuanMsIERlbm8pIG9yIHByb3ZpZGUgYSBjdXN0b20gV2ViU29ja2V0IGltcGxlbWVudGF0aW9uLlwiLFxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBiZXN0IGF2YWlsYWJsZSBXZWJTb2NrZXQgY29uc3RydWN0b3IgZm9yIHRoZSBjdXJyZW50IHJ1bnRpbWUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKlxuICAgKiBAZXhhbXBsZSBFeGFtcGxlIHdpdGggZXJyb3IgaGFuZGxpbmdcbiAgICogYGBgdHNcbiAgICogdHJ5IHtcbiAgICogICBjb25zdCBXUyA9IFdlYlNvY2tldEZhY3RvcnkuZ2V0V2ViU29ja2V0Q29uc3RydWN0b3IoKVxuICAgKiAgIGNvbnN0IHNvY2tldCA9IG5ldyBXUygnd3NzOi8vZXhhbXBsZS5jb20vc29ja2V0JylcbiAgICogfSBjYXRjaCAoZXJyb3IpIHtcbiAgICogICBjb25zb2xlLmVycm9yKCdXZWJTb2NrZXQgbm90IGF2YWlsYWJsZSBpbiB0aGlzIGVudmlyb25tZW50LicsIGVycm9yKVxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBnZXRXZWJTb2NrZXRDb25zdHJ1Y3RvcigpOiB0eXBlb2YgV2ViU29ja2V0IHtcbiAgICBjb25zdCBlbnYgPSB0aGlzLmRldGVjdEVudmlyb25tZW50KClcbiAgICBpZiAoZW52LndzQ29uc3RydWN0b3IpIHtcbiAgICAgIHJldHVybiBlbnYud3NDb25zdHJ1Y3RvclxuICAgIH1cbiAgICBsZXQgZXJyb3JNZXNzYWdlID0gZW52LmVycm9yIHx8ICdXZWJTb2NrZXQgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50LidcbiAgICBpZiAoZW52Lndvcmthcm91bmQpIHtcbiAgICAgIGVycm9yTWVzc2FnZSArPSBgXFxuXFxuU3VnZ2VzdGVkIHNvbHV0aW9uOiAke2Vudi53b3JrYXJvdW5kfWBcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGVycm9yTWVzc2FnZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3RzIHdoZXRoZXIgdGhlIHJ1bnRpbWUgY2FuIGVzdGFibGlzaCBXZWJTb2NrZXQgY29ubmVjdGlvbnMuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKlxuICAgKiBAZXhhbXBsZSBFeGFtcGxlIGluIGEgTm9kZS5qcyBzY3JpcHRcbiAgICogYGBgdHNcbiAgICogaWYgKCFXZWJTb2NrZXRGYWN0b3J5LmlzV2ViU29ja2V0U3VwcG9ydGVkKCkpIHtcbiAgICogICBjb25zb2xlLmVycm9yKCdXZWJTb2NrZXRzIGFyZSByZXF1aXJlZCBmb3IgdGhpcyBzY3JpcHQuJylcbiAgICogICBwcm9jZXNzLmV4aXRDb2RlID0gMVxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBpc1dlYlNvY2tldFN1cHBvcnRlZCgpOiBib29sZWFuIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZW52ID0gdGhpcy5kZXRlY3RFbnZpcm9ubWVudCgpXG4gICAgICByZXR1cm4gZW52LnR5cGUgPT09ICduYXRpdmUnIHx8IGVudi50eXBlID09PSAnd3MnXG4gICAgfSBjYXRjaCB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgV2ViU29ja2V0RmFjdG9yeVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=