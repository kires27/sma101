import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Text.vue");import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
import { computed } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "Text",
  props: {
    variant: {
      type: String,
      default: "body",
      validator: (v) => [
        "hero",
        "h1",
        "h2",
        "h3",
        "body",
        "body-sm",
        "label"
      ].includes(v)
    },
    tone: {
      type: String,
      default: "tone",
      validator: (v) => ["tone", "muted", "green", "yellow", "red", "blue", "purple"].includes(v)
    },
    weight: {
      type: String,
      default: "normal",
      validator: (v) => ["light", "normal", "medium", "bold"].includes(v)
    },
    link: {
      type: Boolean,
      default: false
    }
  },
  setup(__props, { expose: __expose }) {
    __expose();
    const props = __props;
    const tag = computed(() => {
      switch (props.variant) {
        case "hero":
          return "h1";
        case "h1":
          return "h1";
        case "h2":
          return "h2";
        case "h3":
          return "h3";
        case "label":
          return "span";
        default:
          return "p";
      }
    });
    const __returned__ = { props, tag };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { renderSlot as _renderSlot, resolveDynamicComponent as _resolveDynamicComponent, mergeProps as _mergeProps, withCtx as _withCtx, openBlock as _openBlock, createBlock as _createBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return _openBlock(), _tracer(59,2,_createBlock(_resolveDynamicComponent($setup.tag), _mergeProps({
    class: [
      "text",
      `text--${$props.variant}`,
      `text--${$props.tone}`,
      $props.weight && `text--${$props.weight}`,
      $props.link && "text--link"
    ]
  }, _ctx.$attrs), {
    default: _withCtx(() => [
      _renderSlot(_ctx.$slots, "default", {}, void 0, true)
    ]),
    _: 3
    /* FORWARDED */
  }, 16, ["class"]));
}
import "/_nuxt/ui/Text.vue?vue&type=style&index=0&scoped=0941177f&lang.css";
_sfc_main.__hmrId = "0941177f";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
  if (!mod) return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ Object.assign(_export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-0941177f"], ["__file", "/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Text.vue"]]), { __name: "Text" });

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Text.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFDQSxTQUFTLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUV6QixVQUFNLFFBQVE7QUFvQ2QsVUFBTSxNQUFNLFNBQVMsTUFBTTtBQUN6QixjQUFRLE1BQU0sU0FBUztBQUFBLFFBQ3JCLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVDtBQUNFLGlCQUFPO0FBQUEsTUFDWDtBQUFBLElBQ0YsQ0FBQzs7Ozs7Ozs7b0NBSUMsYUFRWSx5QkFSSSxVQUFHLEdBQW5CLFlBUVk7QUFBQSxJQVJVLE9BQUs7QUFBQTtlQUE2QixjQUFPO0FBQUEsZUFBaUIsV0FBSTtBQUFBLE1BQVEsaUJBQU0sU0FBYSxhQUFNO0FBQUEsTUFBUSxlQUFJO0FBQUE7S0FNdEgsV0FBTTtBQUFBLHNCQUNmLE1BQVE7QUFBQSxNQUFSLFlBQVE7QUFBQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGV4dC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cCBsYW5nPVwidHNcIj5cbmltcG9ydCB7IGNvbXB1dGVkIH0gZnJvbSAndnVlJ1xuXG5jb25zdCBwcm9wcyA9IGRlZmluZVByb3BzKHtcbiAgdmFyaWFudDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBkZWZhdWx0OiAnYm9keScsXG4gICAgdmFsaWRhdG9yOiAodjogc3RyaW5nKSA9PlxuICAgICAgW1xuICAgICAgICAnaGVybycsXG4gICAgICAgICdoMScsXG4gICAgICAgICdoMicsXG4gICAgICAgICdoMycsXG4gICAgICAgICdib2R5JyxcbiAgICAgICAgJ2JvZHktc20nLFxuICAgICAgICAnbGFiZWwnLFxuICAgICAgXS5pbmNsdWRlcyh2KSxcbiAgfSxcblxuICB0b25lOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGRlZmF1bHQ6ICd0b25lJyxcbiAgICB2YWxpZGF0b3I6ICh2OiBzdHJpbmcpID0+XG4gICAgICBbJ3RvbmUnLCAnbXV0ZWQnLCAnZ3JlZW4nLCAneWVsbG93JywgJ3JlZCcsICdibHVlJywgJ3B1cnBsZSddLmluY2x1ZGVzKHYpLFxuICB9LFxuXG4gIHdlaWdodDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBkZWZhdWx0OiAnbm9ybWFsJyxcbiAgICB2YWxpZGF0b3I6ICh2OiBzdHJpbmcpID0+XG4gICAgICBbJ2xpZ2h0JywgJ25vcm1hbCcsICdtZWRpdW0nLCAnYm9sZCddLmluY2x1ZGVzKHYpLFxuICB9LFxuXG4gIGxpbms6IHtcbiAgICB0eXBlOiBCb29sZWFuLFxuICAgIGRlZmF1bHQ6IGZhbHNlLFxuICB9LFxufSlcblxuY29uc3QgdGFnID0gY29tcHV0ZWQoKCkgPT4ge1xuICBzd2l0Y2ggKHByb3BzLnZhcmlhbnQpIHtcbiAgICBjYXNlICdoZXJvJzpcbiAgICAgIHJldHVybiAnaDEnXG4gICAgY2FzZSAnaDEnOlxuICAgICAgcmV0dXJuICdoMSdcbiAgICBjYXNlICdoMic6XG4gICAgICByZXR1cm4gJ2gyJ1xuICAgIGNhc2UgJ2gzJzpcbiAgICAgIHJldHVybiAnaDMnXG4gICAgY2FzZSAnbGFiZWwnOlxuICAgICAgcmV0dXJuICdzcGFuJ1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gJ3AnXG4gIH1cbn0pXG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8Y29tcG9uZW50IDppcz1cInRhZ1wiIDpjbGFzcz1cIltcbiAgICAndGV4dCcsXG4gICAgYHRleHQtLSR7dmFyaWFudH1gLFxuICAgIGB0ZXh0LS0ke3RvbmV9YCxcbiAgICB3ZWlnaHQgJiYgYHRleHQtLSR7d2VpZ2h0fWAsXG4gICAgbGluayAmJiAndGV4dC0tbGluaycsXG4gIF1cIiB2LWJpbmQ9XCIkYXR0cnNcIj5cbiAgICA8c2xvdCAvPlxuICA8L2NvbXBvbmVudD5cbjwvdGVtcGxhdGU+XG5cbjxzdHlsZSBzY29wZWQ+XG4udGV4dCB7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1mYW1pbHk6IHZhcigtLWZvbnQtbWFpbik7XG59XG5cbi8qIC0tLS0tLS0tLS0gU2l6ZSAtLS0tLS0tLS0tICovXG5cbi50ZXh0LS1oZXJvIHtcbiAgZm9udC1zaXplOiA1MnB4O1xuICBsaW5lLWhlaWdodDogMS4xO1xuICBsZXR0ZXItc3BhY2luZzogLS4wM2VtO1xuICBmb250LXdlaWdodDogMzAwO1xuICBwYWRkaW5nOiAxLjVyZW0gMDtcbn1cblxuLnRleHQtLWgxIHtcbiAgZm9udC1zaXplOiA0NHB4O1xuICBsaW5lLWhlaWdodDogMS4xNTtcbiAgbGV0dGVyLXNwYWNpbmc6IC0uMDJlbTtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgcGFkZGluZzogOHB4IDA7XG59XG5cbi50ZXh0LS1oMiB7XG4gIGZvbnQtc2l6ZTogMjhweDtcbiAgbGluZS1oZWlnaHQ6IDEuMjtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbn1cblxuLnRleHQtLWgzIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMS4zO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG4udGV4dC0tYm9keSB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbGluZS1oZWlnaHQ6IDEuNztcbn1cblxuLnRleHQtLWJvZHktc20ge1xuICBmb250LXNpemU6IDEzcHg7XG4gIGxpbmUtaGVpZ2h0OiAxLjY7XG59XG5cbi50ZXh0LS1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgbGV0dGVyLXNwYWNpbmc6IC4xNWVtO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuXG4vKiAtLS0tLS0tLS0tIENvbG9yIC0tLS0tLS0tLS0gKi9cblxuLnRleHQtLXRvbmUge1xuICBjb2xvcjogdmFyKC0tZmcpO1xufVxuXG4udGV4dC0tbXV0ZWQge1xuICBjb2xvcjogdmFyKC0tZmctMik7XG59XG5cbi50ZXh0LS1ncmVlbiB7XG4gIGNvbG9yOiB2YXIoLS10ZWFsKTtcbn1cblxuLnRleHQtLXB1cnBsZSB7XG4gIGNvbG9yOiB2YXIoLS1wdXJwbGUpO1xufVxuXG4udGV4dC0teWVsbG93IHtcbiAgY29sb3I6IHZhcigtLWdvbGQpO1xufVxuXG4udGV4dC0tcmVkIHtcbiAgY29sb3I6IHZhcigtLXJvc2UpO1xufVxuXG4udGV4dC0tYmx1ZSB7XG4gIGNvbG9yOiB2YXIoLS1ibHVlKTtcbn1cblxuLyogLS0tLS0tLS0tLSBXZWlnaHQgLS0tLS0tLS0tLSAqL1xuXG4udGV4dC0tbGlnaHQge1xuICBmb250LXdlaWdodDogMzAwO1xufVxuXG4udGV4dC0tbm9ybWFsIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuLnRleHQtLW1lZGl1bSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi50ZXh0LS1ib2xkIHtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbn1cblxuLyogLS0tLS0tLS0tLSBMaW5rIC0tLS0tLS0tLS0gKi9cblxuLnRleHQtLWxpbmsge1xuICB0cmFuc2l0aW9uOiBmaWx0ZXIgdmFyKC0tdHJhbnNpdGlvbik7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLnRleHQtLWxpbms6aG92ZXIge1xuICBmaWx0ZXI6IGJyaWdodG5lc3MoMS4zKTtcbn1cblxuLyogLS0tLS0tLS0tLSBSaWNoIHRleHQgLS0tLS0tLS0tLSAqL1xuXG4udGV4dCA6ZGVlcChlbSkge1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG59XG5cbi50ZXh0IDpkZWVwKGEpIHtcbiAgY29sb3I6IGluaGVyaXQ7XG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xufVxuPC9zdHlsZT4iXSwiZmlsZSI6Ii9tbnQva2lyZS9QZXJzb25hbC9Qcm9ncmFtbWluZy9Qcm9qZWN0cy9NRUlDL3dlYi9hcHAvdWkvVGV4dC52dWUifQ==