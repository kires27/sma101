import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Section.vue");import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"

const _sfc_main = {
  __name: "Section",
  props: {
	/** Dot-grid background overlay */
	bgGrid: {
		type: Boolean,
		default: false,
	},
	width: {
		type: String,
		default: 'na',
		validator: (v) => ['na', 'sm', 'md', 'lg'].includes(v)
	},
	topMargin: {
		type: String,
		default: '',
		validator: (v) => ['', 'sm', 'md', 'lg'].includes(v)
	},
	bottomMargin: {
		type: String,
		default: '',
		validator: (v) => ['', 'sm', 'md', 'lg'].includes(v)
	},
},
  setup(__props, { expose: __expose }) {
  __expose();



const __returned__ = {  }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { renderSlot as _renderSlot, normalizeClass as _normalizeClass, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _tracer(27,1,_createElementBlock("section", {
    class: _normalizeClass([
		'section',
		{ 'bg-grid': $props.bgGrid },
		`section--width-${$props.width}`,
		`section--top-${$props.topMargin}`,
		`section--bottom-${$props.bottomMargin}`,
	])
  }, [
    _renderSlot(_ctx.$slots, "default", {}, undefined, true)
  ], 2 /* CLASS */)))
}


import "/_nuxt/ui/Section.vue?vue&type=style&index=0&scoped=b2719839&lang.css"

_sfc_main.__hmrId = "b2719839"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-b2719839"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Section.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Section.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQ0EwQkMsb0JBU1U7SUFUQSxLQUFLOztlQUFnQyxhQUFNO29CQUF3QixZQUFLO2tCQUFzQixnQkFBUztxQkFBeUIsbUJBQVk7OztJQVFySixZQUFRIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZWN0aW9uLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuZGVmaW5lUHJvcHMoe1xuXHQvKiogRG90LWdyaWQgYmFja2dyb3VuZCBvdmVybGF5ICovXG5cdGJnR3JpZDoge1xuXHRcdHR5cGU6IEJvb2xlYW4sXG5cdFx0ZGVmYXVsdDogZmFsc2UsXG5cdH0sXG5cdHdpZHRoOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGRlZmF1bHQ6ICduYScsXG5cdFx0dmFsaWRhdG9yOiAodikgPT4gWyduYScsICdzbScsICdtZCcsICdsZyddLmluY2x1ZGVzKHYpXG5cdH0sXG5cdHRvcE1hcmdpbjoge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRkZWZhdWx0OiAnJyxcblx0XHR2YWxpZGF0b3I6ICh2KSA9PiBbJycsICdzbScsICdtZCcsICdsZyddLmluY2x1ZGVzKHYpXG5cdH0sXG5cdGJvdHRvbU1hcmdpbjoge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRkZWZhdWx0OiAnJyxcblx0XHR2YWxpZGF0b3I6ICh2KSA9PiBbJycsICdzbScsICdtZCcsICdsZyddLmluY2x1ZGVzKHYpXG5cdH0sXG59KVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cblx0PHNlY3Rpb24gOmNsYXNzPVwiW1xuXHRcdCdzZWN0aW9uJyxcblx0XHR7ICdiZy1ncmlkJzogYmdHcmlkIH0sXG5cdFx0YHNlY3Rpb24tLXdpZHRoLSR7d2lkdGh9YCxcblx0XHRgc2VjdGlvbi0tdG9wLSR7dG9wTWFyZ2lufWAsXG5cdFx0YHNlY3Rpb24tLWJvdHRvbS0ke2JvdHRvbU1hcmdpbn1gLFxuXHRdXCI+XG5cblx0XHQ8c2xvdCAvPlxuXHQ8L3NlY3Rpb24+XG48L3RlbXBsYXRlPlxuXG48c3R5bGUgc2NvcGVkPlxuLnNlY3Rpb24ge1xuXHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdC8qIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1ib3JkZXIpOyAqL1xufVxuXG4uYmctZ3JpZDo6YmVmb3JlIHtcblx0Y29udGVudDogJyc7XG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0aW5zZXQ6IDA7XG5cdGJhY2tncm91bmQtaW1hZ2U6XG5cdFx0bGluZWFyLWdyYWRpZW50KHZhcigtLWJvcmRlcikgMXB4LCB0cmFuc3BhcmVudCAxcHgpLFxuXHRcdGxpbmVhci1ncmFkaWVudCg5MGRlZywgdmFyKC0tYm9yZGVyKSAxcHgsIHRyYW5zcGFyZW50IDFweCk7XG5cdGJhY2tncm91bmQtc2l6ZTogNjBweCA2MHB4O1xuXHRvcGFjaXR5OiAwLjg7XG5cdHBvaW50ZXItZXZlbnRzOiBub25lO1xuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tYm9yZGVyKTtcbn1cblxuLnNlY3Rpb24tLXdpZHRoLW5hIHtcblx0LyogcGFkZGluZy1pbmxpbmU6IDA7ICovXG59XG5cbi5zZWN0aW9uLS13aWR0aC1zbSB7XG5cdHdpZHRoOiAzMHJlbTtcblxufVxuXG4uc2VjdGlvbi0td2lkdGgtbWQge1xuXHR3aWR0aDogNTByZW07XG59XG5cbi5zZWN0aW9uLS13aWR0aC1sZyB7XG5cdC8qIHdpZHRoOiAxMDByZW07ICovXG5cdHdpZHRoOiBtaW4oNzByZW0sIDkwdncpO1xufVxuXG4uc2VjdGlvbi0tdG9wLXNtIHtcblx0bWFyZ2luLXRvcDogMnJlbTtcbn1cblxuLnNlY3Rpb24tLWJvdHRvbS1zbSB7XG5cdG1hcmdpbi1ib3R0b206IDJyZW07XG59XG5cbi5zZWN0aW9uLS10b3AtbWQge1xuXHRtYXJnaW4tdG9wOiA1cmVtO1xufVxuXG4uc2VjdGlvbi0tYm90dG9tLW1kIHtcblx0bWFyZ2luLWJvdHRvbTogNXJlbTtcbn1cblxuLnNlY3Rpb24tLXRvcC1sZyB7XG5cdG1hcmdpbi10b3A6IDhyZW07XG59XG5cbi5zZWN0aW9uLS1ib3R0b20tbGcge1xuXHRtYXJnaW4tYm90dG9tOiA4cmVtO1xufVxuPC9zdHlsZT5cbiJdLCJmaWxlIjoiL21udC9raXJlL1BlcnNvbmFsL1Byb2dyYW1taW5nL1Byb2plY3RzL01FSUMvd2ViL2FwcC91aS9TZWN0aW9uLnZ1ZSJ9