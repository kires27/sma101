/**
* @vue/runtime-dom v3.5.41
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
import { warn, BaseTransitionPropsValidators, h, BaseTransition, assertNumber, getCurrentInstance, onBeforeUpdate, queuePostFlushCb, onMounted, watch, onUnmounted, Fragment, Static, camelize, callWithAsyncErrorHandling, nextTick, unref, createVNode, defineComponent, useTransitionState, onUpdated, toRaw, getTransitionRawChildren, setTransitionHooks, resolveTransitionHooks, Text, createRenderer, isRuntimeOnly, createHydrationRenderer } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+runtime-core@3.5.41/node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js?v=583078ff";
export * from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+runtime-core@3.5.41/node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js?v=583078ff";
import { extend, isObject, toNumber, isArray, NOOP, normalizeCssVarValue, isString, hyphenate, capitalize, includeBooleanAttr, isSymbol, isSpecialBooleanAttr, isFunction, isOn, isModelListener, camelize as camelize$1, hasOwn, isPlainObject, EMPTY_OBJ, looseIndexOf, isSet, looseEqual, looseToNumber, invokeArrayFns, isHTMLTag, isSVGTag, isMathMLTag } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+shared@3.5.41/node_modules/@vue/shared/dist/shared.esm-bundler.js?v=583078ff";
let policy = void 0;
const tt = typeof window !== "undefined" && window.trustedTypes;
if (tt) {
  try {
    policy = /* @__PURE__ */ tt.createPolicy("vue", {
      createHTML: (val) => val
    });
  } catch (e) {
    warn(`Error creating trusted types policy: ${e}`);
  }
}
const unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
const svgNS = "http://www.w3.org/2000/svg";
const mathmlNS = "http://www.w3.org/1998/Math/MathML";
const doc = typeof document !== "undefined" ? document : null;
const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
const nodeOps = {
  insert: (child, parent, anchor) => {
    parent.insertBefore(child, anchor || null);
  },
  remove: (child) => {
    const parent = child.parentNode;
    if (parent) {
      parent.removeChild(child);
    }
  },
  createElement: (tag, namespace, is, props) => {
    const el = namespace === "svg" ? doc.createElementNS(svgNS, tag) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag) : is ? doc.createElement(tag, { is }) : doc.createElement(tag);
    if (tag === "select" && props && props.multiple != null) {
      el.setAttribute("multiple", props.multiple);
    }
    return el;
  },
  createText: (text) => doc.createTextNode(text),
  createComment: (text) => doc.createComment(text),
  setText: (node, text) => {
    node.nodeValue = text;
  },
  setElementText: (el, text) => {
    el.textContent = text;
  },
  parentNode: (node) => node.parentNode,
  nextSibling: (node) => node.nextSibling,
  querySelector: (selector) => doc.querySelector(selector),
  setScopeId(el, id) {
    el.setAttribute(id, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(content, parent, anchor, namespace, start, end) {
    const before = anchor ? anchor.previousSibling : parent.lastChild;
    if (start && (start === end || start.nextSibling)) {
      while (true) {
        parent.insertBefore(start.cloneNode(true), anchor);
        if (start === end || !(start = start.nextSibling)) break;
      }
    } else {
      templateContainer.innerHTML = unsafeToTrustedHTML(
        namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content
      );
      const template = templateContainer.content;
      if (namespace === "svg" || namespace === "mathml") {
        const wrapper = template.firstChild;
        while (wrapper.firstChild) {
          template.appendChild(wrapper.firstChild);
        }
        template.removeChild(wrapper);
      }
      parent.insertBefore(template, anchor);
    }
    return [
      // first
      before ? before.nextSibling : parent.firstChild,
      // last
      anchor ? anchor.previousSibling : parent.lastChild
    ];
  }
};
const TRANSITION = "transition";
const ANIMATION = "animation";
const vtcKey = /* @__PURE__ */ Symbol("_vtc");
const DOMTransitionPropsValidators = {
  name: String,
  type: String,
  css: {
    type: Boolean,
    default: true
  },
  duration: [String, Number, Object],
  enterFromClass: String,
  enterActiveClass: String,
  enterToClass: String,
  appearFromClass: String,
  appearActiveClass: String,
  appearToClass: String,
  leaveFromClass: String,
  leaveActiveClass: String,
  leaveToClass: String
};
const TransitionPropsValidators = /* @__PURE__ */ extend(
  {},
  BaseTransitionPropsValidators,
  DOMTransitionPropsValidators
);
const decorate$1 = (t) => {
  t.displayName = "Transition";
  t.props = TransitionPropsValidators;
  return t;
};
const Transition = /* @__PURE__ */ decorate$1(
  (props, { slots }) => h(BaseTransition, resolveTransitionProps(props), slots)
);
const callHook = (hook, args = []) => {
  if (isArray(hook)) {
    hook.forEach((h2) => h2(...args));
  } else if (hook) {
    hook(...args);
  }
};
const hasExplicitCallback = (hook) => {
  return hook ? isArray(hook) ? hook.some((h2) => h2.length > 1) : hook.length > 1 : false;
};
function resolveTransitionProps(rawProps) {
  const baseProps = {};
  for (const key in rawProps) {
    if (!(key in DOMTransitionPropsValidators)) {
      baseProps[key] = rawProps[key];
    }
  }
  if (rawProps.css === false) {
    return baseProps;
  }
  const {
    name = "v",
    type,
    duration,
    enterFromClass = `${name}-enter-from`,
    enterActiveClass = `${name}-enter-active`,
    enterToClass = `${name}-enter-to`,
    appearFromClass = enterFromClass,
    appearActiveClass = enterActiveClass,
    appearToClass = enterToClass,
    leaveFromClass = `${name}-leave-from`,
    leaveActiveClass = `${name}-leave-active`,
    leaveToClass = `${name}-leave-to`
  } = rawProps;
  const durations = normalizeDuration(duration);
  const enterDuration = durations && durations[0];
  const leaveDuration = durations && durations[1];
  const {
    onBeforeEnter,
    onEnter,
    onEnterCancelled,
    onLeave,
    onLeaveCancelled,
    onBeforeAppear = onBeforeEnter,
    onAppear = onEnter,
    onAppearCancelled = onEnterCancelled
  } = baseProps;
  const finishEnter = (el, isAppear, done, isCancelled) => {
    el._enterCancelled = isCancelled;
    removeTransitionClass(el, isAppear ? appearToClass : enterToClass);
    removeTransitionClass(el, isAppear ? appearActiveClass : enterActiveClass);
    done && done();
  };
  const finishLeave = (el, done) => {
    el._isLeaving = false;
    removeTransitionClass(el, leaveFromClass);
    removeTransitionClass(el, leaveToClass);
    removeTransitionClass(el, leaveActiveClass);
    done && done();
  };
  const makeEnterHook = (isAppear) => {
    return (el, done) => {
      const hook = isAppear ? onAppear : onEnter;
      const resolve = () => finishEnter(el, isAppear, done);
      callHook(hook, [el, resolve]);
      nextFrame(() => {
        removeTransitionClass(el, isAppear ? appearFromClass : enterFromClass);
        addTransitionClass(el, isAppear ? appearToClass : enterToClass);
        if (!hasExplicitCallback(hook)) {
          whenTransitionEnds(el, type, enterDuration, resolve);
        }
      });
    };
  };
  return extend(baseProps, {
    onBeforeEnter(el) {
      callHook(onBeforeEnter, [el]);
      addTransitionClass(el, enterFromClass);
      addTransitionClass(el, enterActiveClass);
    },
    onBeforeAppear(el) {
      callHook(onBeforeAppear, [el]);
      addTransitionClass(el, appearFromClass);
      addTransitionClass(el, appearActiveClass);
    },
    onEnter: makeEnterHook(false),
    onAppear: makeEnterHook(true),
    onLeave(el, done) {
      el._isLeaving = true;
      const resolve = () => finishLeave(el, done);
      addTransitionClass(el, leaveFromClass);
      if (!el._enterCancelled) {
        forceReflow(el);
        addTransitionClass(el, leaveActiveClass);
      } else {
        addTransitionClass(el, leaveActiveClass);
        forceReflow(el);
      }
      nextFrame(() => {
        if (!el._isLeaving) {
          return;
        }
        removeTransitionClass(el, leaveFromClass);
        addTransitionClass(el, leaveToClass);
        if (!hasExplicitCallback(onLeave)) {
          whenTransitionEnds(el, type, leaveDuration, resolve);
        }
      });
      callHook(onLeave, [el, resolve]);
    },
    onEnterCancelled(el) {
      finishEnter(el, false, void 0, true);
      callHook(onEnterCancelled, [el]);
    },
    onAppearCancelled(el) {
      finishEnter(el, true, void 0, true);
      callHook(onAppearCancelled, [el]);
    },
    onLeaveCancelled(el) {
      finishLeave(el);
      callHook(onLeaveCancelled, [el]);
    }
  });
}
function normalizeDuration(duration) {
  if (duration == null) {
    return null;
  } else if (isObject(duration)) {
    return [NumberOf(duration.enter), NumberOf(duration.leave)];
  } else {
    const n = NumberOf(duration);
    return [n, n];
  }
}
function NumberOf(val) {
  const res = toNumber(val);
  if (true) {
    assertNumber(res, "<transition> explicit duration");
  }
  return res;
}
function addTransitionClass(el, cls) {
  cls.split(/\s+/).forEach((c) => c && el.classList.add(c));
  (el[vtcKey] || (el[vtcKey] = /* @__PURE__ */ new Set())).add(cls);
}
function removeTransitionClass(el, cls) {
  cls.split(/\s+/).forEach((c) => c && el.classList.remove(c));
  const _vtc = el[vtcKey];
  if (_vtc) {
    _vtc.delete(cls);
    if (!_vtc.size) {
      el[vtcKey] = void 0;
    }
  }
}
function nextFrame(cb) {
  requestAnimationFrame(() => {
    requestAnimationFrame(cb);
  });
}
let endId = 0;
function whenTransitionEnds(el, expectedType, explicitTimeout, resolve) {
  const id = el._endId = ++endId;
  const resolveIfNotStale = () => {
    if (id === el._endId) {
      resolve();
    }
  };
  if (explicitTimeout != null) {
    return setTimeout(resolveIfNotStale, explicitTimeout);
  }
  const { type, timeout, propCount } = getTransitionInfo(el, expectedType);
  if (!type) {
    return resolve();
  }
  const endEvent = type + "end";
  let ended = 0;
  const end = () => {
    el.removeEventListener(endEvent, onEnd);
    resolveIfNotStale();
  };
  const onEnd = (e) => {
    if (e.target === el && ++ended >= propCount) {
      end();
    }
  };
  setTimeout(() => {
    if (ended < propCount) {
      end();
    }
  }, timeout + 1);
  el.addEventListener(endEvent, onEnd);
}
function getTransitionInfo(el, expectedType) {
  const styles = window.getComputedStyle(el);
  const getStyleProperties = (key) => (styles[key] || "").split(", ");
  const transitionDelays = getStyleProperties(`${TRANSITION}Delay`);
  const transitionDurations = getStyleProperties(`${TRANSITION}Duration`);
  const transitionTimeout = getTimeout(transitionDelays, transitionDurations);
  const animationDelays = getStyleProperties(`${ANIMATION}Delay`);
  const animationDurations = getStyleProperties(`${ANIMATION}Duration`);
  const animationTimeout = getTimeout(animationDelays, animationDurations);
  let type = null;
  let timeout = 0;
  let propCount = 0;
  if (expectedType === TRANSITION) {
    if (transitionTimeout > 0) {
      type = TRANSITION;
      timeout = transitionTimeout;
      propCount = transitionDurations.length;
    }
  } else if (expectedType === ANIMATION) {
    if (animationTimeout > 0) {
      type = ANIMATION;
      timeout = animationTimeout;
      propCount = animationDurations.length;
    }
  } else {
    timeout = Math.max(transitionTimeout, animationTimeout);
    type = timeout > 0 ? transitionTimeout > animationTimeout ? TRANSITION : ANIMATION : null;
    propCount = type ? type === TRANSITION ? transitionDurations.length : animationDurations.length : 0;
  }
  const hasTransform = type === TRANSITION && /\b(?:transform|all)(?:,|$)/.test(
    getStyleProperties(`${TRANSITION}Property`).toString()
  );
  return {
    type,
    timeout,
    propCount,
    hasTransform
  };
}
function getTimeout(delays, durations) {
  while (delays.length < durations.length) {
    delays = delays.concat(delays);
  }
  return Math.max(...durations.map((d, i) => toMs(d) + toMs(delays[i])));
}
function toMs(s) {
  if (s === "auto") return 0;
  return Number(s.slice(0, -1).replace(",", ".")) * 1e3;
}
function forceReflow(el) {
  const targetDocument = el ? el.ownerDocument : document;
  return targetDocument.body.offsetHeight;
}
function patchClass(el, value, isSVG) {
  const transitionClasses = el[vtcKey];
  if (transitionClasses) {
    value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
  }
  if (value == null) {
    el.removeAttribute("class");
  } else if (isSVG) {
    el.setAttribute("class", value);
  } else {
    el.className = value;
  }
}
const vShowOriginalDisplay = /* @__PURE__ */ Symbol("_vod");
const vShowHidden = /* @__PURE__ */ Symbol("_vsh");
const vShow = {
  // used for prop mismatch check during hydration
  name: "show",
  beforeMount(el, { value }, { transition }) {
    el[vShowOriginalDisplay] = el.style.display === "none" ? "" : el.style.display;
    if (transition && value) {
      transition.beforeEnter(el);
    } else {
      setDisplay(el, value);
    }
  },
  mounted(el, { value }, { transition }) {
    if (transition && value) {
      transition.enter(el);
    }
  },
  updated(el, { value, oldValue }, { transition }) {
    if (!value === !oldValue) return;
    if (transition) {
      if (value) {
        transition.beforeEnter(el);
        setDisplay(el, true);
        transition.enter(el);
      } else {
        transition.leave(el, () => {
          setDisplay(el, false);
        });
      }
    } else {
      setDisplay(el, value);
    }
  },
  beforeUnmount(el, { value }) {
    setDisplay(el, value);
  }
};
function setDisplay(el, value) {
  el.style.display = value ? el[vShowOriginalDisplay] : "none";
  el[vShowHidden] = !value;
}
function initVShowForSSR() {
  vShow.getSSRProps = ({ value }) => {
    if (!value) {
      return { style: { display: "none" } };
    }
  };
}
const CSS_VAR_TEXT = /* @__PURE__ */ Symbol(true ? "CSS_VAR_TEXT" : "");
function useCssVars(getter) {
  const instance = getCurrentInstance();
  if (!instance) {
    warn(`useCssVars is called without current active component instance.`);
    return;
  }
  const updateTeleports = instance.ut = (vars = getter(instance.proxy)) => {
    Array.from(
      document.querySelectorAll(`[data-v-owner="${instance.uid}"]`)
    ).forEach((node) => setVarsOnNode(node, vars));
  };
  if (true) {
    instance.getCssVars = () => getter(instance.proxy);
  }
  const setVars = () => {
    const vars = getter(instance.proxy);
    if (instance.ce) {
      setVarsOnNode(instance.ce, vars);
    } else {
      setVarsOnVNode(instance.subTree, vars);
    }
    updateTeleports(vars);
  };
  onBeforeUpdate(() => {
    queuePostFlushCb(setVars);
  });
  onMounted(() => {
    watch(setVars, NOOP, { flush: "post" });
    const ob = new MutationObserver(setVars);
    ob.observe(instance.subTree.el.parentNode, { childList: true });
    onUnmounted(() => ob.disconnect());
  });
}
function setVarsOnVNode(vnode, vars) {
  if (vnode.shapeFlag & 128) {
    const suspense = vnode.suspense;
    vnode = suspense.activeBranch;
    if (suspense.pendingBranch && !suspense.isHydrating) {
      suspense.effects.push(() => {
        setVarsOnVNode(suspense.activeBranch, vars);
      });
    }
  }
  while (vnode.component) {
    vnode = vnode.component.subTree;
  }
  if (vnode.shapeFlag & 1 && vnode.el) {
    setVarsOnNode(vnode.el, vars);
  } else if (vnode.type === Fragment) {
    vnode.children.forEach((c) => setVarsOnVNode(c, vars));
  } else if (vnode.type === Static) {
    let { el, anchor } = vnode;
    while (el) {
      setVarsOnNode(el, vars);
      if (el === anchor) break;
      el = el.nextSibling;
    }
  }
}
function setVarsOnNode(el, vars) {
  if (el.nodeType === 1) {
    const style = el.style;
    let cssText = "";
    for (const key in vars) {
      const value = normalizeCssVarValue(vars[key]);
      style.setProperty(`--${key}`, value);
      cssText += `--${key}: ${value};`;
    }
    style[CSS_VAR_TEXT] = cssText;
  }
}
const displayRE = /(?:^|;)\s*display\s*:/;
function patchStyle(el, prev, next) {
  const style = el.style;
  const isCssString = isString(next);
  let hasControlledDisplay = false;
  if (next && !isCssString) {
    if (prev) {
      if (!isString(prev)) {
        for (const key in prev) {
          if (next[key] == null) {
            setStyle(style, key, "");
          }
        }
      } else {
        for (const prevStyle of prev.split(";")) {
          const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
          if (next[key] == null) {
            setStyle(style, key, "");
          }
        }
      }
    }
    for (const key in next) {
      if (key === "display") {
        hasControlledDisplay = true;
      }
      const value = next[key];
      if (value != null) {
        if (!shouldPreserveTextareaResizeStyle(
          el,
          key,
          !isString(prev) && prev ? prev[key] : void 0,
          value
        )) {
          setStyle(style, key, value);
        }
      } else {
        setStyle(style, key, "");
      }
    }
  } else {
    if (isCssString) {
      if (prev !== next) {
        const cssVarText = style[CSS_VAR_TEXT];
        if (cssVarText) {
          next += ";" + cssVarText;
        }
        style.cssText = next;
        hasControlledDisplay = displayRE.test(next);
      }
    } else if (prev) {
      el.removeAttribute("style");
    }
  }
  if (vShowOriginalDisplay in el) {
    el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
    if (el[vShowHidden]) {
      style.display = "none";
    }
  }
}
const semicolonRE = /[^\\];\s*$/;
const importantRE = /\s*!important$/;
function setStyle(style, name, val) {
  if (isArray(val)) {
    val.forEach((v) => setStyle(style, name, v));
  } else {
    if (val == null) val = "";
    if (true) {
      if (semicolonRE.test(val)) {
        warn(
          `Unexpected semicolon at the end of '${name}' style value: '${val}'`
        );
      }
    }
    if (name.startsWith("--")) {
      style.setProperty(name, val);
    } else {
      const prefixed = autoPrefix(style, name);
      if (importantRE.test(val)) {
        style.setProperty(
          hyphenate(prefixed),
          val.replace(importantRE, ""),
          "important"
        );
      } else {
        style[prefixed] = val;
      }
    }
  }
}
const prefixes = ["Webkit", "Moz", "ms"];
const prefixCache = {};
function autoPrefix(style, rawName) {
  const cached = prefixCache[rawName];
  if (cached) {
    return cached;
  }
  let name = camelize(rawName);
  if (name !== "filter" && name in style) {
    return prefixCache[rawName] = name;
  }
  name = capitalize(name);
  for (let i = 0; i < prefixes.length; i++) {
    const prefixed = prefixes[i] + name;
    if (prefixed in style) {
      return prefixCache[rawName] = prefixed;
    }
  }
  return rawName;
}
function shouldPreserveTextareaResizeStyle(el, key, prev, next) {
  return el.tagName === "TEXTAREA" && (key === "width" || key === "height") && isString(next) && prev === next;
}
const xlinkNS = "http://www.w3.org/1999/xlink";
function patchAttr(el, key, value, isSVG, instance, isBoolean = isSpecialBooleanAttr(key)) {
  if (isSVG && key.startsWith("xlink:")) {
    if (value == null) {
      el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
    } else {
      el.setAttributeNS(xlinkNS, key, value);
    }
  } else {
    if (value == null || isBoolean && !includeBooleanAttr(value)) {
      el.removeAttribute(key);
    } else {
      el.setAttribute(
        key,
        isBoolean ? "" : isSymbol(value) ? String(value) : value
      );
    }
  }
}
function patchDOMProp(el, key, value, parentComponent, attrName) {
  if (key === "innerHTML" || key === "textContent") {
    if (value != null) {
      el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
    }
    return;
  }
  const tag = el.tagName;
  if (key === "value" && tag !== "PROGRESS" && // custom elements may use _value internally
  !tag.includes("-")) {
    const oldValue = tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
    const newValue = value == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      el.type === "checkbox" ? "on" : ""
    ) : String(value);
    if (oldValue !== newValue || !("_value" in el)) {
      el.value = newValue;
    }
    if (value == null) {
      el.removeAttribute(key);
    }
    el._value = value;
    return;
  }
  let needRemove = false;
  if (value === "" || value == null) {
    const type = typeof el[key];
    if (type === "boolean") {
      value = includeBooleanAttr(value);
    } else if (value == null && type === "string") {
      value = "";
      needRemove = true;
    } else if (type === "number") {
      value = 0;
      needRemove = true;
    }
  }
  try {
    el[key] = value;
  } catch (e) {
    if (!needRemove) {
      warn(
        `Failed setting prop "${key}" on <${tag.toLowerCase()}>: value ${value} is invalid.`,
        e
      );
    }
  }
  needRemove && el.removeAttribute(attrName || key);
}
function addEventListener(el, event, handler, options) {
  el.addEventListener(event, handler, options);
}
function removeEventListener(el, event, handler, options) {
  el.removeEventListener(event, handler, options);
}
const veiKey = /* @__PURE__ */ Symbol("_vei");
function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
  const invokers = el[veiKey] || (el[veiKey] = {});
  const existingInvoker = invokers[rawName];
  if (nextValue && existingInvoker) {
    existingInvoker.value = true ? sanitizeEventValue(nextValue, rawName) : nextValue;
  } else {
    const [name, options] = parseName(rawName);
    if (nextValue) {
      const invoker = invokers[rawName] = createInvoker(
        true ? sanitizeEventValue(nextValue, rawName) : nextValue,
        instance
      );
      addEventListener(el, name, invoker, options);
    } else if (existingInvoker) {
      removeEventListener(el, name, existingInvoker, options);
      invokers[rawName] = void 0;
    }
  }
}
const optionsModifierRE = /(Once|Passive|Capture)$/;
const optionsModifierEventRE = /^on:?(?:Once|Passive|Capture)$/;
function parseName(name) {
  let options;
  let m;
  while ((m = name.match(optionsModifierRE)) && !optionsModifierEventRE.test(name)) {
    if (!options) options = {};
    name = name.slice(0, name.length - m[1].length);
    options[m[1].toLowerCase()] = true;
  }
  const event = name[2] === ":" ? name.slice(3) : hyphenate(name.slice(2));
  return [event, options];
}
let cachedNow = 0;
const p = /* @__PURE__ */ Promise.resolve();
const getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
function createInvoker(initialValue, instance) {
  const invoker = (e) => {
    if (!e._vts) {
      e._vts = Date.now();
    } else if (e._vts <= invoker.attached) {
      return;
    }
    const value = invoker.value;
    if (isArray(value)) {
      const originalStop = e.stopImmediatePropagation;
      e.stopImmediatePropagation = () => {
        originalStop.call(e);
        e._stopped = true;
      };
      const handlers = value.slice();
      const args = [e];
      for (let i = 0; i < handlers.length; i++) {
        if (e._stopped) {
          break;
        }
        const handler = handlers[i];
        if (handler) {
          callWithAsyncErrorHandling(
            handler,
            instance,
            5,
            args
          );
        }
      }
    } else {
      callWithAsyncErrorHandling(
        value,
        instance,
        5,
        [e]
      );
    }
  };
  invoker.value = initialValue;
  invoker.attached = getNow();
  return invoker;
}
function sanitizeEventValue(value, propName) {
  if (isFunction(value) || isArray(value)) {
    return value;
  }
  warn(
    `Wrong type passed as event handler to ${propName} - did you forget @ or : in front of your prop?
Expected function or array of functions, received type ${typeof value}.`
  );
  return NOOP;
}
const isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // lowercase letter
key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
const patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
  const isSVG = namespace === "svg";
  if (key === "class") {
    patchClass(el, nextValue, isSVG);
  } else if (key === "style") {
    patchStyle(el, prevValue, nextValue);
  } else if (isOn(key)) {
    if (!isModelListener(key)) {
      patchEvent(el, key, prevValue, nextValue, parentComponent);
    }
  } else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
    patchDOMProp(el, key, nextValue);
    if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) {
      patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
    }
  } else if (
    // #11081 force set props for possible async custom element
    el._isVueCE && // #12408 check if it's declared prop or it's async custom element
    (shouldSetAsPropForVueCE(el, key) || // @ts-expect-error _def is private
    el._def.__asyncLoader && (/[A-Z]/.test(key) || !isString(nextValue)))
  ) {
    patchDOMProp(el, camelize$1(key), nextValue, parentComponent, key);
  } else {
    if (key === "true-value") {
      el._trueValue = nextValue;
    } else if (key === "false-value") {
      el._falseValue = nextValue;
    }
    patchAttr(el, key, nextValue, isSVG);
  }
};
function shouldSetAsProp(el, key, value, isSVG) {
  if (isSVG) {
    if (key === "innerHTML" || key === "textContent") {
      return true;
    }
    if (key in el && isNativeOn(key) && isFunction(value)) {
      return true;
    }
    return false;
  }
  if (key === "spellcheck" || key === "draggable" || key === "translate" || key === "autocorrect") {
    return false;
  }
  if (key === "sandbox" && el.tagName === "IFRAME") {
    return false;
  }
  if (key === "form") {
    return false;
  }
  if (key === "list" && el.tagName === "INPUT") {
    return false;
  }
  if (key === "type" && el.tagName === "TEXTAREA") {
    return false;
  }
  if (key === "width" || key === "height") {
    const tag = el.tagName;
    if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") {
      return false;
    }
  }
  if (isNativeOn(key) && isString(value)) {
    return false;
  }
  return key in el;
}
function shouldSetAsPropForVueCE(el, key) {
  const props = (
    // @ts-expect-error _def is private
    el._def.props
  );
  if (!props) {
    return false;
  }
  const camelKey = camelize$1(key);
  return Array.isArray(props) ? props.some((prop) => camelize$1(prop) === camelKey) : Object.keys(props).some((prop) => camelize$1(prop) === camelKey);
}
const REMOVAL = {};
// @__NO_SIDE_EFFECTS__
function defineCustomElement(options, extraOptions, _createApp) {
  let Comp = defineComponent(options, extraOptions);
  if (isPlainObject(Comp)) Comp = extend({}, Comp, extraOptions);
  class VueCustomElement extends VueElement {
    constructor(initialProps) {
      super(Comp, initialProps, _createApp);
    }
  }
  VueCustomElement.def = Comp;
  return VueCustomElement;
}
const defineSSRCustomElement = (/* @__NO_SIDE_EFFECTS__ */ (options, extraOptions) => {
  return /* @__PURE__ */ defineCustomElement(options, extraOptions, createSSRApp);
});
const BaseClass = typeof HTMLElement !== "undefined" ? HTMLElement : class {
};
class VueElement extends BaseClass {
  constructor(_def, _props = {}, _createApp = createApp) {
    super();
    this._def = _def;
    this._props = _props;
    this._createApp = _createApp;
    this._isVueCE = true;
    this._instance = null;
    this._app = null;
    this._nonce = this._def.nonce;
    this._connected = false;
    this._resolved = false;
    this._patching = false;
    this._dirty = false;
    this._numberProps = null;
    this._styleChildren = /* @__PURE__ */ new WeakSet();
    this._styleAnchors = /* @__PURE__ */ new WeakMap();
    this._ob = null;
    if (this.shadowRoot && _createApp !== createApp) {
      this._root = this.shadowRoot;
    } else {
      if (this.shadowRoot) {
        warn(
          `Custom element has pre-rendered declarative shadow root but is not defined as hydratable. Use \`defineSSRCustomElement\`.`
        );
      }
      if (_def.shadowRoot !== false) {
        this.attachShadow(
          extend({}, _def.shadowRootOptions, {
            mode: "open"
          })
        );
        this._root = this.shadowRoot;
      } else {
        this._root = this;
      }
    }
  }
  connectedCallback() {
    if (!this.isConnected) return;
    if (!this.shadowRoot && !this._resolved) {
      this._parseSlots();
    }
    this._connected = true;
    let parent = this;
    while (parent = parent && // #12479 should check assignedSlot first to get correct parent
    (parent.assignedSlot || parent.parentNode || parent.host)) {
      if (parent instanceof VueElement) {
        this._parent = parent;
        break;
      }
    }
    if (!this._instance) {
      if (this._resolved) {
        this._mount(this._def);
      } else {
        if (parent && parent._pendingResolve) {
          this._pendingResolve = parent._pendingResolve.then(() => {
            this._pendingResolve = void 0;
            if (this.isConnected) {
              return this._resolveDef();
            }
          });
        } else {
          this._resolveDef();
        }
      }
    }
  }
  _setParent(parent = this._parent) {
    if (parent) {
      this._instance.parent = parent._instance;
      this._inheritParentContext(parent);
    }
  }
  _inheritParentContext(parent = this._parent) {
    if (parent && this._app) {
      Object.setPrototypeOf(
        this._app._context.provides,
        parent._instance.provides
      );
    }
  }
  disconnectedCallback() {
    this._connected = false;
    nextTick(() => {
      if (!this._connected) {
        if (this._ob) {
          this._ob.disconnect();
          this._ob = null;
        }
        this._app && this._app.unmount();
        if (this._instance) this._instance.ce = void 0;
        this._app = this._instance = null;
        if (this._teleportTargets) {
          this._teleportTargets.clear();
          this._teleportTargets = void 0;
        }
      }
    });
  }
  _processMutations(mutations) {
    for (const m of mutations) {
      this._setAttr(m.attributeName);
    }
  }
  /**
   * resolve inner component definition (handle possible async component)
   */
  _resolveDef() {
    if (this._pendingResolve) {
      return this._pendingResolve;
    }
    for (let i = 0; i < this.attributes.length; i++) {
      this._setAttr(this.attributes[i].name);
    }
    this._ob = new MutationObserver(this._processMutations.bind(this));
    this._ob.observe(this, { attributes: true });
    const resolve = (def, isAsync = false) => {
      this._resolved = true;
      this._pendingResolve = void 0;
      const { props, styles } = def;
      let numberProps;
      if (props && !isArray(props)) {
        for (const key in props) {
          const opt = props[key];
          if (opt === Number || opt && opt.type === Number) {
            if (key in this._props) {
              this._props[key] = toNumber(this._props[key]);
            }
            (numberProps || (numberProps = /* @__PURE__ */ Object.create(null)))[camelize$1(key)] = true;
          }
        }
      }
      this._numberProps = numberProps;
      this._resolveProps(def);
      if (this.shadowRoot) {
        this._applyStyles(styles);
      } else if (styles) {
        warn(
          "Custom element style injection is not supported when using shadowRoot: false"
        );
      }
      this._mount(def);
    };
    const asyncDef = this._def.__asyncLoader;
    if (asyncDef) {
      this._pendingResolve = asyncDef().then((def) => {
        def.configureApp = this._def.configureApp;
        resolve(this._def = def, true);
      });
      return this._pendingResolve;
    } else {
      resolve(this._def);
    }
  }
  _mount(def) {
    if (!def.name) {
      def.name = "VueElement";
    }
    this._app = this._createApp(def);
    this._inheritParentContext();
    if (def.configureApp) {
      def.configureApp(this._app);
    }
    this._app._ceVNode = this._createVNode();
    this._app.mount(this._root);
    const exposed = this._instance && this._instance.exposed;
    if (!exposed) return;
    for (const key in exposed) {
      if (!hasOwn(this, key)) {
        Object.defineProperty(this, key, {
          // unwrap ref to be consistent with public instance behavior
          get: () => unref(exposed[key])
        });
      } else if (true) {
        warn(`Exposed property "${key}" already exists on custom element.`);
      }
    }
  }
  _resolveProps(def) {
    const { props } = def;
    const declaredPropKeys = isArray(props) ? props : Object.keys(props || {});
    for (const key of Object.keys(this)) {
      if (key[0] !== "_" && declaredPropKeys.includes(key)) {
        this._setProp(key, this[key]);
      }
    }
    for (const key of declaredPropKeys.map(camelize$1)) {
      if (key in Object.getPrototypeOf(this)) {
        warn(
          `Custom element prop "${key}" conflicts with an existing property on the element and will overwrite it.`
        );
      }
      Object.defineProperty(this, key, {
        get() {
          return this._getProp(key);
        },
        set(val) {
          this._setProp(key, val, true, !this._patching);
        }
      });
    }
  }
  _setAttr(key) {
    if (key.startsWith("data-v-")) return;
    const has = this.hasAttribute(key);
    let value = has ? this.getAttribute(key) : REMOVAL;
    const camelKey = camelize$1(key);
    if (has && this._numberProps && this._numberProps[camelKey]) {
      value = toNumber(value);
    }
    this._setProp(camelKey, value, false, true);
  }
  /**
   * @internal
   */
  _getProp(key) {
    return this._props[key];
  }
  /**
   * @internal
   */
  _setProp(key, val, shouldReflect = true, shouldUpdate = false) {
    if (val !== this._props[key]) {
      this._dirty = true;
      if (val === REMOVAL) {
        delete this._props[key];
      } else {
        this._props[key] = val;
        if (key === "key" && this._app) {
          this._app._ceVNode.key = val;
        }
      }
      if (shouldUpdate && this._instance) {
        this._update();
      }
      if (shouldReflect) {
        const ob = this._ob;
        if (ob) {
          this._processMutations(ob.takeRecords());
          ob.disconnect();
        }
        if (val === true) {
          this.setAttribute(hyphenate(key), "");
        } else if (typeof val === "string" || typeof val === "number") {
          this.setAttribute(hyphenate(key), val + "");
        } else if (!val) {
          this.removeAttribute(hyphenate(key));
        }
        ob && ob.observe(this, { attributes: true });
      }
    }
  }
  _update() {
    const vnode = this._createVNode();
    if (this._app) vnode.appContext = this._app._context;
    render(vnode, this._root);
  }
  _createVNode() {
    const baseProps = {};
    if (!this.shadowRoot) {
      baseProps.onVnodeMounted = baseProps.onVnodeUpdated = this._renderSlots.bind(this);
    }
    const vnode = createVNode(this._def, extend(baseProps, this._props));
    if (!this._instance) {
      vnode.ce = (instance) => {
        this._instance = instance;
        instance.ce = this;
        instance.isCE = true;
        if (true) {
          instance.ceReload = (newStyles) => {
            if (this._styles) {
              this._styles.forEach((s) => this._root.removeChild(s));
              this._styles.length = 0;
            }
            this._styleAnchors.delete(this._def);
            this._applyStyles(newStyles);
            this._instance = null;
            this._update();
          };
        }
        const dispatch = (event, args) => {
          this.dispatchEvent(
            new CustomEvent(
              event,
              isPlainObject(args[0]) ? extend({ detail: args }, args[0]) : { detail: args }
            )
          );
        };
        instance.emit = (event, ...args) => {
          dispatch(event, args);
          if (hyphenate(event) !== event) {
            dispatch(hyphenate(event), args);
          }
        };
        this._setParent();
      };
    }
    return vnode;
  }
  _applyStyles(styles, owner, parentComp) {
    if (!styles) return;
    if (owner) {
      if (owner === this._def || this._styleChildren.has(owner)) {
        return;
      }
      this._styleChildren.add(owner);
    }
    const nonce = this._nonce;
    const root = this.shadowRoot;
    const insertionAnchor = parentComp ? this._getStyleAnchor(parentComp) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(root);
    let last = null;
    for (let i = styles.length - 1; i >= 0; i--) {
      const s = document.createElement("style");
      if (nonce) s.setAttribute("nonce", nonce);
      s.textContent = styles[i];
      root.insertBefore(s, last || insertionAnchor);
      last = s;
      if (i === 0) {
        if (!parentComp) this._styleAnchors.set(this._def, s);
        if (owner) this._styleAnchors.set(owner, s);
      }
      if (true) {
        if (owner) {
          if (owner.__hmrId) {
            if (!this._childStyles) this._childStyles = /* @__PURE__ */ new Map();
            let entry = this._childStyles.get(owner.__hmrId);
            if (!entry) {
              this._childStyles.set(owner.__hmrId, entry = []);
            }
            entry.push(s);
          }
        } else {
          (this._styles || (this._styles = [])).push(s);
        }
      }
    }
  }
  _getStyleAnchor(comp) {
    if (!comp) {
      return null;
    }
    const anchor = this._styleAnchors.get(comp);
    if (anchor && anchor.parentNode === this.shadowRoot) {
      return anchor;
    }
    if (anchor) {
      this._styleAnchors.delete(comp);
    }
    return null;
  }
  _getRootStyleInsertionAnchor(root) {
    for (let i = 0; i < root.childNodes.length; i++) {
      const node = root.childNodes[i];
      if (!(node instanceof HTMLStyleElement)) {
        return node;
      }
    }
    return null;
  }
  /**
   * Only called when shadowRoot is false
   */
  _parseSlots() {
    const slots = this._slots = {};
    let n;
    while (n = this.firstChild) {
      const slotName = n.nodeType === 1 && n.getAttribute("slot") || "default";
      (slots[slotName] || (slots[slotName] = [])).push(n);
      this.removeChild(n);
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _renderSlots() {
    const outlets = this._getSlots();
    const scopeId = this._instance.type.__scopeId;
    for (let i = 0; i < outlets.length; i++) {
      const o = outlets[i];
      const slotName = o.getAttribute("name") || "default";
      const content = this._slots[slotName];
      const parent = o.parentNode;
      if (content) {
        for (const n of content) {
          if (scopeId && n.nodeType === 1) {
            const id = scopeId + "-s";
            const walker = document.createTreeWalker(n, 1);
            n.setAttribute(id, "");
            let child;
            while (child = walker.nextNode()) {
              child.setAttribute(id, "");
            }
          }
          parent.insertBefore(n, o);
        }
      } else {
        while (o.firstChild) parent.insertBefore(o.firstChild, o);
      }
      parent.removeChild(o);
    }
  }
  /**
   * @internal
   */
  _getSlots() {
    const roots = [this];
    if (this._teleportTargets) {
      roots.push(...this._teleportTargets);
    }
    const slots = /* @__PURE__ */ new Set();
    for (const root of roots) {
      const found = root.querySelectorAll("slot");
      for (let i = 0; i < found.length; i++) {
        slots.add(found[i]);
      }
    }
    return Array.from(slots);
  }
  /**
   * @internal
   */
  _injectChildStyle(comp, parentComp) {
    this._applyStyles(comp.styles, comp, parentComp);
  }
  /**
   * @internal
   */
  _beginPatch() {
    this._patching = true;
    this._dirty = false;
  }
  /**
   * @internal
   */
  _endPatch() {
    this._patching = false;
    if (this._dirty && this._instance) {
      this._update();
    }
  }
  /**
   * @internal
   */
  _hasShadowRoot() {
    return this._def.shadowRoot !== false;
  }
  /**
   * @internal
   */
  _removeChildStyle(comp) {
    if (true) {
      this._styleChildren.delete(comp);
      this._styleAnchors.delete(comp);
      if (this._childStyles && comp.__hmrId) {
        const oldStyles = this._childStyles.get(comp.__hmrId);
        if (oldStyles) {
          oldStyles.forEach((s) => this._root.removeChild(s));
          oldStyles.length = 0;
        }
      }
    }
  }
}
function useHost(caller) {
  const instance = getCurrentInstance();
  const el = instance && instance.ce;
  if (el) {
    return el;
  } else if (true) {
    if (!instance) {
      warn(
        `${caller || "useHost"} called without an active component instance.`
      );
    } else {
      warn(
        `${caller || "useHost"} can only be used in components defined via defineCustomElement.`
      );
    }
  }
  return null;
}
function useShadowRoot() {
  const el = true ? useHost("useShadowRoot") : useHost();
  return el && el.shadowRoot;
}
function useCssModule(name = "$style") {
  {
    const instance = getCurrentInstance();
    if (!instance) {
      warn(`useCssModule must be called inside setup()`);
      return EMPTY_OBJ;
    }
    const modules = instance.type.__cssModules;
    if (!modules) {
      warn(`Current instance does not have CSS modules injected.`);
      return EMPTY_OBJ;
    }
    const mod = modules[name];
    if (!mod) {
      warn(`Current instance does not have CSS module named "${name}".`);
      return EMPTY_OBJ;
    }
    return mod;
  }
}
const positionMap = /* @__PURE__ */ new WeakMap();
const newPositionMap = /* @__PURE__ */ new WeakMap();
const moveCbKey = /* @__PURE__ */ Symbol("_moveCb");
const enterCbKey = /* @__PURE__ */ Symbol("_enterCb");
const decorate = (t) => {
  delete t.props.mode;
  return t;
};
const TransitionGroupImpl = /* @__PURE__ */ decorate({
  name: "TransitionGroup",
  props: /* @__PURE__ */ extend({}, TransitionPropsValidators, {
    tag: String,
    moveClass: String
  }),
  setup(props, { slots }) {
    const instance = getCurrentInstance();
    const state = useTransitionState();
    let prevChildren;
    let children;
    onUpdated(() => {
      if (!prevChildren.length) {
        return;
      }
      const moveClass = props.moveClass || `${props.name || "v"}-move`;
      if (!hasCSSTransform(
        prevChildren[0].el,
        instance.vnode.el,
        moveClass
      )) {
        prevChildren = [];
        return;
      }
      prevChildren.forEach(callPendingCbs);
      prevChildren.forEach(recordPosition);
      const movedChildren = prevChildren.filter(applyTranslation);
      forceReflow(instance.vnode.el);
      movedChildren.forEach((c) => {
        const el = c.el;
        const style = el.style;
        addTransitionClass(el, moveClass);
        style.transform = style.webkitTransform = style.transitionDuration = "";
        const cb = el[moveCbKey] = (e) => {
          if (e && e.target !== el) {
            return;
          }
          if (!e || e.propertyName.endsWith("transform")) {
            el.removeEventListener("transitionend", cb);
            el[moveCbKey] = null;
            removeTransitionClass(el, moveClass);
          }
        };
        el.addEventListener("transitionend", cb);
      });
      prevChildren = [];
    });
    return () => {
      const rawProps = toRaw(props);
      const cssTransitionProps = resolveTransitionProps(rawProps);
      let tag = rawProps.tag || Fragment;
      prevChildren = [];
      if (children) {
        for (let i = 0; i < children.length; i++) {
          const child = children[i];
          if (child.el && child.el instanceof Element && // Hidden v-show nodes have no previous layout box to animate from.
          !child.el[vShowHidden]) {
            prevChildren.push(child);
            setTransitionHooks(
              child,
              resolveTransitionHooks(
                child,
                cssTransitionProps,
                state,
                instance
              )
            );
            positionMap.set(child, getPosition(child.el));
          }
        }
      }
      children = slots.default ? getTransitionRawChildren(slots.default()) : [];
      for (let i = 0; i < children.length; i++) {
        const child = children[i];
        if (child.key != null) {
          setTransitionHooks(
            child,
            resolveTransitionHooks(child, cssTransitionProps, state, instance)
          );
        } else if (child.type !== Text) {
          warn(`<TransitionGroup> children must be keyed.`);
        }
      }
      return createVNode(tag, null, children);
    };
  }
});
const TransitionGroup = TransitionGroupImpl;
function callPendingCbs(c) {
  const el = c.el;
  if (el[moveCbKey]) {
    el[moveCbKey]();
  }
  if (el[enterCbKey]) {
    el[enterCbKey]();
  }
}
function recordPosition(c) {
  newPositionMap.set(c, getPosition(c.el));
}
function applyTranslation(c) {
  const oldPos = positionMap.get(c);
  const newPos = newPositionMap.get(c);
  const dx = oldPos.left - newPos.left;
  const dy = oldPos.top - newPos.top;
  if (dx || dy) {
    const el = c.el;
    const s = el.style;
    const rect = el.getBoundingClientRect();
    let scaleX = 1;
    let scaleY = 1;
    if (el.offsetWidth) scaleX = rect.width / el.offsetWidth;
    if (el.offsetHeight) scaleY = rect.height / el.offsetHeight;
    if (!Number.isFinite(scaleX) || scaleX === 0) scaleX = 1;
    if (!Number.isFinite(scaleY) || scaleY === 0) scaleY = 1;
    if (Math.abs(scaleX - 1) < 0.01) scaleX = 1;
    if (Math.abs(scaleY - 1) < 0.01) scaleY = 1;
    s.transform = s.webkitTransform = `translate(${dx / scaleX}px,${dy / scaleY}px)`;
    s.transitionDuration = "0s";
    return c;
  }
}
function getPosition(el) {
  const rect = el.getBoundingClientRect();
  return {
    left: rect.left,
    top: rect.top
  };
}
function hasCSSTransform(el, root, moveClass) {
  const clone = el.cloneNode();
  const _vtc = el[vtcKey];
  if (_vtc) {
    _vtc.forEach((cls) => {
      cls.split(/\s+/).forEach((c) => c && clone.classList.remove(c));
    });
  }
  moveClass.split(/\s+/).forEach((c) => c && clone.classList.add(c));
  clone.style.display = "none";
  const container = root.nodeType === 1 ? root : root.parentNode;
  container.appendChild(clone);
  const { hasTransform } = getTransitionInfo(clone);
  container.removeChild(clone);
  return hasTransform;
}
const getModelAssigner = (vnode) => {
  const fn = vnode.props["onUpdate:modelValue"] || false;
  return isArray(fn) ? (value) => invokeArrayFns(fn, value) : fn;
};
function onCompositionStart(e) {
  e.target.composing = true;
}
function onCompositionEnd(e) {
  const target = e.target;
  if (target.composing) {
    target.composing = false;
    target.dispatchEvent(new Event("input"));
  }
}
const assignKey = /* @__PURE__ */ Symbol("_assign");
const initialValueKey = /* @__PURE__ */ Symbol("_initialValue");
function castValue(value, trim, number) {
  if (trim) value = value.trim();
  if (number) value = looseToNumber(value);
  return value;
}
const vModelText = {
  created(el, { modifiers: { lazy, trim, number } }, vnode) {
    if (el.parentNode) {
      if (el.type === "text") {
        el[initialValueKey] = el.defaultValue.replace(/[\r\n]/g, "");
      } else if (el.type === "textarea") {
        el[initialValueKey] = el.defaultValue.replace(/\r\n?/g, "\n");
      }
    }
    el[assignKey] = getModelAssigner(vnode);
    const castToNumber = number || vnode.props && vnode.props.type === "number";
    addEventListener(el, lazy ? "change" : "input", (e) => {
      if (e.target.composing) return;
      el[assignKey](castValue(el.value, trim, castToNumber));
    });
    if (trim || castToNumber) {
      addEventListener(el, "change", () => {
        el.value = castValue(el.value, trim, castToNumber);
      });
    }
    if (!lazy) {
      addEventListener(el, "compositionstart", onCompositionStart);
      addEventListener(el, "compositionend", onCompositionEnd);
      addEventListener(el, "change", onCompositionEnd);
    }
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(el, { value, modifiers: { trim, number } }) {
    const newValue = value == null ? "" : value;
    const initialValue = el[initialValueKey];
    delete el[initialValueKey];
    if (initialValue !== void 0 && (el.type === "text" || el.type === "textarea") && el.value !== initialValue) {
      el[assignKey](castValue(el.value, trim, number));
    } else {
      el.value = newValue;
    }
  },
  beforeUpdate(el, { value, oldValue, modifiers: { lazy, trim, number } }, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    if (el.composing) return;
    const elValue = (number || el.type === "number") && !/^0\d/.test(el.value) ? looseToNumber(el.value) : el.value;
    const newValue = value == null ? "" : value;
    if (elValue === newValue) {
      return;
    }
    const rootNode = el.getRootNode();
    if ((rootNode instanceof Document || rootNode instanceof ShadowRoot) && rootNode.activeElement === el && el.type !== "range") {
      if (lazy && value === oldValue) {
        return;
      }
      if (trim && el.value.trim() === newValue) {
        return;
      }
    }
    el.value = newValue;
  }
};
const vModelCheckbox = {
  // #4096 array checkboxes need to be deep traversed
  deep: true,
  created(el, _, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    addEventListener(el, "change", () => {
      const modelValue = el._modelValue;
      const elementValue = getValue(el);
      const checked = el.checked;
      const assign = el[assignKey];
      if (isArray(modelValue)) {
        const index = looseIndexOf(modelValue, elementValue);
        const found = index !== -1;
        if (checked && !found) {
          assign(modelValue.concat(elementValue));
        } else if (!checked && found) {
          const filtered = [...modelValue];
          filtered.splice(index, 1);
          assign(filtered);
        }
      } else if (isSet(modelValue)) {
        const cloned = new Set(modelValue);
        if (checked) {
          cloned.add(elementValue);
        } else {
          cloned.delete(elementValue);
        }
        assign(cloned);
      } else {
        assign(getCheckboxValue(el, checked));
      }
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: setChecked,
  beforeUpdate(el, binding, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    setChecked(el, binding, vnode);
  }
};
function setChecked(el, { value, oldValue }, vnode) {
  el._modelValue = value;
  let checked;
  if (isArray(value)) {
    checked = looseIndexOf(value, vnode.props.value) > -1;
  } else if (isSet(value)) {
    checked = value.has(vnode.props.value);
  } else {
    if (value === oldValue) return;
    checked = looseEqual(value, getCheckboxValue(el, true));
  }
  if (el.checked !== checked) {
    el.checked = checked;
  }
}
const vModelRadio = {
  created(el, { value }, vnode) {
    el.checked = looseEqual(value, vnode.props.value);
    el[assignKey] = getModelAssigner(vnode);
    addEventListener(el, "change", () => {
      el[assignKey](getValue(el));
    });
  },
  beforeUpdate(el, { value, oldValue }, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    if (value !== oldValue) {
      el.checked = looseEqual(value, vnode.props.value);
    }
  }
};
const vModelSelect = {
  // <select multiple> value need to be deep traversed
  deep: true,
  created(el, { value, modifiers: { number } }, vnode) {
    el._modelValue = value;
    addEventListener(el, "change", () => {
      const selectedVal = Array.prototype.filter.call(el.options, (o) => o.selected).map(
        (o) => number ? looseToNumber(getValue(o)) : getValue(o)
      );
      el[assignKey](
        el.multiple ? isSet(el._modelValue) ? new Set(selectedVal) : selectedVal : selectedVal[0]
      );
      el._assigning = true;
      nextTick(() => {
        el._assigning = false;
      });
    });
    el[assignKey] = getModelAssigner(vnode);
  },
  // set value in mounted & updated because <select> relies on its children
  // <option>s.
  mounted(el, { value }) {
    setSelected(el, value);
  },
  beforeUpdate(el, { value }, vnode) {
    el._modelValue = value;
    el[assignKey] = getModelAssigner(vnode);
  },
  updated(el, { value }) {
    if (!el._assigning) {
      setSelected(el, value);
    }
  }
};
function setSelected(el, value) {
  const isMultiple = el.multiple;
  const isArrayValue = isArray(value);
  if (isMultiple && !isArrayValue && !isSet(value)) {
    warn(
      `<select multiple v-model> expects an Array or Set value for its binding, but got ${Object.prototype.toString.call(value).slice(8, -1)}.`
    );
    return;
  }
  for (let i = 0, l = el.options.length; i < l; i++) {
    const option = el.options[i];
    const optionValue = getValue(option);
    if (isMultiple) {
      if (isArrayValue) {
        const optionType = typeof optionValue;
        if (optionType === "string" || optionType === "number") {
          option.selected = value.some((v) => String(v) === String(optionValue));
        } else {
          option.selected = looseIndexOf(value, optionValue) > -1;
        }
      } else {
        option.selected = value.has(optionValue);
      }
    } else if (looseEqual(getValue(option), value)) {
      if (el.selectedIndex !== i) el.selectedIndex = i;
      return;
    }
  }
  if (!isMultiple && el.selectedIndex !== -1) {
    el.selectedIndex = -1;
  }
}
function getValue(el) {
  return "_value" in el ? el._value : el.value;
}
function getCheckboxValue(el, checked) {
  const key = checked ? "_trueValue" : "_falseValue";
  return key in el ? el[key] : checked;
}
const vModelDynamic = {
  created(el, binding, vnode) {
    callModelHook(el, binding, vnode, null, "created");
  },
  mounted(el, binding, vnode) {
    callModelHook(el, binding, vnode, null, "mounted");
  },
  beforeUpdate(el, binding, vnode, prevVNode) {
    callModelHook(el, binding, vnode, prevVNode, "beforeUpdate");
  },
  updated(el, binding, vnode, prevVNode) {
    callModelHook(el, binding, vnode, prevVNode, "updated");
  }
};
function resolveDynamicModel(tagName, type) {
  switch (tagName) {
    case "SELECT":
      return vModelSelect;
    case "TEXTAREA":
      return vModelText;
    default:
      switch (type) {
        case "checkbox":
          return vModelCheckbox;
        case "radio":
          return vModelRadio;
        default:
          return vModelText;
      }
  }
}
function callModelHook(el, binding, vnode, prevVNode, hook) {
  const modelToUse = resolveDynamicModel(
    el.tagName,
    vnode.props && vnode.props.type
  );
  const fn = modelToUse[hook];
  fn && fn(el, binding, vnode, prevVNode);
}
function initVModelForSSR() {
  vModelText.getSSRProps = ({ value }) => ({ value });
  vModelRadio.getSSRProps = ({ value }, vnode) => {
    if (vnode.props && looseEqual(vnode.props.value, value)) {
      return { checked: true };
    }
  };
  vModelCheckbox.getSSRProps = ({ value }, vnode) => {
    if (isArray(value)) {
      if (vnode.props && looseIndexOf(value, vnode.props.value) > -1) {
        return { checked: true };
      }
    } else if (isSet(value)) {
      if (vnode.props && value.has(vnode.props.value)) {
        return { checked: true };
      }
    } else if (value) {
      return { checked: true };
    }
  };
  vModelDynamic.getSSRProps = (binding, vnode) => {
    if (typeof vnode.type !== "string") {
      return;
    }
    const modelToUse = resolveDynamicModel(
      // resolveDynamicModel expects an uppercase tag name, but vnode.type is lowercase
      vnode.type.toUpperCase(),
      vnode.props && vnode.props.type
    );
    if (modelToUse.getSSRProps) {
      return modelToUse.getSSRProps(binding, vnode);
    }
  };
}
const systemModifiers = ["ctrl", "shift", "alt", "meta"];
const modifierGuards = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
};
const withModifiers = (fn, modifiers) => {
  if (!fn) return fn;
  const cache = fn._withMods || (fn._withMods = {});
  const cacheKey = modifiers.join(".");
  return cache[cacheKey] || (cache[cacheKey] = ((event, ...args) => {
    for (let i = 0; i < modifiers.length; i++) {
      const guard = modifierGuards[modifiers[i]];
      if (guard && guard(event, modifiers)) return;
    }
    return fn(event, ...args);
  }));
};
const keyNames = {
  esc: "escape",
  space: " ",
  up: "arrow-up",
  left: "arrow-left",
  right: "arrow-right",
  down: "arrow-down",
  delete: "backspace"
};
const withKeys = (fn, modifiers) => {
  const cache = fn._withKeys || (fn._withKeys = {});
  const cacheKey = modifiers.join(".");
  return cache[cacheKey] || (cache[cacheKey] = ((event) => {
    if (!("key" in event)) {
      return;
    }
    const eventKey = hyphenate(event.key);
    if (modifiers.some(
      (k) => k === eventKey || keyNames[k] === eventKey
    )) {
      return fn(event);
    }
  }));
};
const rendererOptions = /* @__PURE__ */ extend({ patchProp }, nodeOps);
let renderer;
let enabledHydration = false;
function ensureRenderer() {
  return renderer || (renderer = createRenderer(rendererOptions));
}
function ensureHydrationRenderer() {
  renderer = enabledHydration ? renderer : createHydrationRenderer(rendererOptions);
  enabledHydration = true;
  return renderer;
}
const render = ((...args) => {
  ensureRenderer().render(...args);
});
const hydrate = ((...args) => {
  ensureHydrationRenderer().hydrate(...args);
});
const createApp = ((...args) => {
  const app = ensureRenderer().createApp(...args);
  if (true) {
    injectNativeTagCheck(app);
    injectCompilerOptionsCheck(app);
  }
  const { mount } = app;
  app.mount = (containerOrSelector) => {
    const container = normalizeContainer(containerOrSelector);
    if (!container) return;
    const component = app._component;
    if (!isFunction(component) && !component.render && !component.template) {
      component.template = container.innerHTML;
    }
    if (container.nodeType === 1) {
      container.textContent = "";
    }
    const proxy = mount(container, false, resolveRootNamespace(container));
    if (container instanceof Element) {
      container.removeAttribute("v-cloak");
      container.setAttribute("data-v-app", "");
    }
    return proxy;
  };
  return app;
});
const createSSRApp = ((...args) => {
  const app = ensureHydrationRenderer().createApp(...args);
  if (true) {
    injectNativeTagCheck(app);
    injectCompilerOptionsCheck(app);
  }
  const { mount } = app;
  app.mount = (containerOrSelector) => {
    const container = normalizeContainer(containerOrSelector);
    if (container) {
      return mount(container, true, resolveRootNamespace(container));
    }
  };
  return app;
});
function resolveRootNamespace(container) {
  if (container instanceof SVGElement) {
    return "svg";
  }
  if (typeof MathMLElement === "function" && container instanceof MathMLElement) {
    return "mathml";
  }
}
function injectNativeTagCheck(app) {
  Object.defineProperty(app.config, "isNativeTag", {
    value: (tag) => isHTMLTag(tag) || isSVGTag(tag) || isMathMLTag(tag),
    writable: false
  });
}
function injectCompilerOptionsCheck(app) {
  if (isRuntimeOnly()) {
    const isCustomElement = app.config.isCustomElement;
    Object.defineProperty(app.config, "isCustomElement", {
      get() {
        return isCustomElement;
      },
      set() {
        warn(
          `The \`isCustomElement\` config option is deprecated. Use \`compilerOptions.isCustomElement\` instead.`
        );
      }
    });
    const compilerOptions = app.config.compilerOptions;
    const msg = `The \`compilerOptions\` config option is only respected when using a build of Vue.js that includes the runtime compiler (aka "full build"). Since you are using the runtime-only build, \`compilerOptions\` must be passed to \`@vue/compiler-dom\` in the build setup instead.
- For vue-loader: pass it via vue-loader's \`compilerOptions\` loader option.
- For vue-cli: see https://cli.vuejs.org/guide/webpack.html#modifying-options-of-a-loader
- For vite: pass it via @vitejs/plugin-vue options. See https://github.com/vitejs/vite-plugin-vue/tree/main/packages/plugin-vue#example-for-passing-options-to-vuecompiler-sfc`;
    Object.defineProperty(app.config, "compilerOptions", {
      get() {
        warn(msg);
        return compilerOptions;
      },
      set() {
        warn(msg);
      }
    });
  }
}
function normalizeContainer(container) {
  if (isString(container)) {
    const res = document.querySelector(container);
    if (!res) {
      warn(
        `Failed to mount app: mount target selector "${container}" returned null.`
      );
    }
    return res;
  }
  if (window.ShadowRoot && container instanceof window.ShadowRoot && container.mode === "closed") {
    warn(
      `mounting on a ShadowRoot with \`{mode: "closed"}\` may lead to unpredictable bugs`
    );
  }
  return container;
}
let ssrDirectiveInitialized = false;
const initDirectivesForSSR = () => {
  if (!ssrDirectiveInitialized) {
    ssrDirectiveInitialized = true;
    initVModelForSSR();
    initVShowForSSR();
  }
};
export { Transition, TransitionGroup, VueElement, createApp, createSSRApp, defineCustomElement, defineSSRCustomElement, hydrate, initDirectivesForSSR, nodeOps, patchProp, render, useCssModule, useCssVars, useHost, useShadowRoot, vModelCheckbox, vModelDynamic, vModelRadio, vModelSelect, vModelText, vShow, withKeys, withModifiers };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJ1bnRpbWUtZG9tLmVzbS1idW5kbGVyLmpzP3Y9NTgzMDc4ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4qIEB2dWUvcnVudGltZS1kb20gdjMuNS40MVxuKiAoYykgMjAxOC1wcmVzZW50IFl1eGkgKEV2YW4pIFlvdSBhbmQgVnVlIGNvbnRyaWJ1dG9yc1xuKiBAbGljZW5zZSBNSVRcbioqL1xuaW1wb3J0IHsgd2FybiwgQmFzZVRyYW5zaXRpb25Qcm9wc1ZhbGlkYXRvcnMsIGgsIEJhc2VUcmFuc2l0aW9uLCBhc3NlcnROdW1iZXIsIGdldEN1cnJlbnRJbnN0YW5jZSwgb25CZWZvcmVVcGRhdGUsIHF1ZXVlUG9zdEZsdXNoQ2IsIG9uTW91bnRlZCwgd2F0Y2gsIG9uVW5tb3VudGVkLCBGcmFnbWVudCwgU3RhdGljLCBjYW1lbGl6ZSwgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcsIG5leHRUaWNrLCB1bnJlZiwgY3JlYXRlVk5vZGUsIGRlZmluZUNvbXBvbmVudCwgdXNlVHJhbnNpdGlvblN0YXRlLCBvblVwZGF0ZWQsIHRvUmF3LCBnZXRUcmFuc2l0aW9uUmF3Q2hpbGRyZW4sIHNldFRyYW5zaXRpb25Ib29rcywgcmVzb2x2ZVRyYW5zaXRpb25Ib29rcywgVGV4dCwgY3JlYXRlUmVuZGVyZXIsIGlzUnVudGltZU9ubHksIGNyZWF0ZUh5ZHJhdGlvblJlbmRlcmVyIH0gZnJvbSAnQHZ1ZS9ydW50aW1lLWNvcmUnO1xuZXhwb3J0ICogZnJvbSAnQHZ1ZS9ydW50aW1lLWNvcmUnO1xuaW1wb3J0IHsgZXh0ZW5kLCBpc09iamVjdCwgdG9OdW1iZXIsIGlzQXJyYXksIE5PT1AsIG5vcm1hbGl6ZUNzc1ZhclZhbHVlLCBpc1N0cmluZywgaHlwaGVuYXRlLCBjYXBpdGFsaXplLCBpbmNsdWRlQm9vbGVhbkF0dHIsIGlzU3ltYm9sLCBpc1NwZWNpYWxCb29sZWFuQXR0ciwgaXNGdW5jdGlvbiwgaXNPbiwgaXNNb2RlbExpc3RlbmVyLCBjYW1lbGl6ZSBhcyBjYW1lbGl6ZSQxLCBoYXNPd24sIGlzUGxhaW5PYmplY3QsIEVNUFRZX09CSiwgbG9vc2VJbmRleE9mLCBpc1NldCwgbG9vc2VFcXVhbCwgbG9vc2VUb051bWJlciwgaW52b2tlQXJyYXlGbnMsIGlzSFRNTFRhZywgaXNTVkdUYWcsIGlzTWF0aE1MVGFnIH0gZnJvbSAnQHZ1ZS9zaGFyZWQnO1xuXG5sZXQgcG9saWN5ID0gdm9pZCAwO1xuY29uc3QgdHQgPSB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy50cnVzdGVkVHlwZXM7XG5pZiAodHQpIHtcbiAgdHJ5IHtcbiAgICBwb2xpY3kgPSAvKiBAX19QVVJFX18gKi8gdHQuY3JlYXRlUG9saWN5KFwidnVlXCIsIHtcbiAgICAgIGNyZWF0ZUhUTUw6ICh2YWwpID0+IHZhbFxuICAgIH0pO1xuICB9IGNhdGNoIChlKSB7XG4gICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuKGBFcnJvciBjcmVhdGluZyB0cnVzdGVkIHR5cGVzIHBvbGljeTogJHtlfWApO1xuICB9XG59XG5jb25zdCB1bnNhZmVUb1RydXN0ZWRIVE1MID0gcG9saWN5ID8gKHZhbCkgPT4gcG9saWN5LmNyZWF0ZUhUTUwodmFsKSA6ICh2YWwpID0+IHZhbDtcbmNvbnN0IHN2Z05TID0gXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiO1xuY29uc3QgbWF0aG1sTlMgPSBcImh0dHA6Ly93d3cudzMub3JnLzE5OTgvTWF0aC9NYXRoTUxcIjtcbmNvbnN0IGRvYyA9IHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiA/IGRvY3VtZW50IDogbnVsbDtcbmNvbnN0IHRlbXBsYXRlQ29udGFpbmVyID0gZG9jICYmIC8qIEBfX1BVUkVfXyAqLyBkb2MuY3JlYXRlRWxlbWVudChcInRlbXBsYXRlXCIpO1xuY29uc3Qgbm9kZU9wcyA9IHtcbiAgaW5zZXJ0OiAoY2hpbGQsIHBhcmVudCwgYW5jaG9yKSA9PiB7XG4gICAgcGFyZW50Lmluc2VydEJlZm9yZShjaGlsZCwgYW5jaG9yIHx8IG51bGwpO1xuICB9LFxuICByZW1vdmU6IChjaGlsZCkgPT4ge1xuICAgIGNvbnN0IHBhcmVudCA9IGNoaWxkLnBhcmVudE5vZGU7XG4gICAgaWYgKHBhcmVudCkge1xuICAgICAgcGFyZW50LnJlbW92ZUNoaWxkKGNoaWxkKTtcbiAgICB9XG4gIH0sXG4gIGNyZWF0ZUVsZW1lbnQ6ICh0YWcsIG5hbWVzcGFjZSwgaXMsIHByb3BzKSA9PiB7XG4gICAgY29uc3QgZWwgPSBuYW1lc3BhY2UgPT09IFwic3ZnXCIgPyBkb2MuY3JlYXRlRWxlbWVudE5TKHN2Z05TLCB0YWcpIDogbmFtZXNwYWNlID09PSBcIm1hdGhtbFwiID8gZG9jLmNyZWF0ZUVsZW1lbnROUyhtYXRobWxOUywgdGFnKSA6IGlzID8gZG9jLmNyZWF0ZUVsZW1lbnQodGFnLCB7IGlzIH0pIDogZG9jLmNyZWF0ZUVsZW1lbnQodGFnKTtcbiAgICBpZiAodGFnID09PSBcInNlbGVjdFwiICYmIHByb3BzICYmIHByb3BzLm11bHRpcGxlICE9IG51bGwpIHtcbiAgICAgIGVsLnNldEF0dHJpYnV0ZShcIm11bHRpcGxlXCIsIHByb3BzLm11bHRpcGxlKTtcbiAgICB9XG4gICAgcmV0dXJuIGVsO1xuICB9LFxuICBjcmVhdGVUZXh0OiAodGV4dCkgPT4gZG9jLmNyZWF0ZVRleHROb2RlKHRleHQpLFxuICBjcmVhdGVDb21tZW50OiAodGV4dCkgPT4gZG9jLmNyZWF0ZUNvbW1lbnQodGV4dCksXG4gIHNldFRleHQ6IChub2RlLCB0ZXh0KSA9PiB7XG4gICAgbm9kZS5ub2RlVmFsdWUgPSB0ZXh0O1xuICB9LFxuICBzZXRFbGVtZW50VGV4dDogKGVsLCB0ZXh0KSA9PiB7XG4gICAgZWwudGV4dENvbnRlbnQgPSB0ZXh0O1xuICB9LFxuICBwYXJlbnROb2RlOiAobm9kZSkgPT4gbm9kZS5wYXJlbnROb2RlLFxuICBuZXh0U2libGluZzogKG5vZGUpID0+IG5vZGUubmV4dFNpYmxpbmcsXG4gIHF1ZXJ5U2VsZWN0b3I6IChzZWxlY3RvcikgPT4gZG9jLnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpLFxuICBzZXRTY29wZUlkKGVsLCBpZCkge1xuICAgIGVsLnNldEF0dHJpYnV0ZShpZCwgXCJcIik7XG4gIH0sXG4gIC8vIF9fVU5TQUZFX19cbiAgLy8gUmVhc29uOiBpbm5lckhUTUwuXG4gIC8vIFN0YXRpYyBjb250ZW50IGhlcmUgY2FuIG9ubHkgY29tZSBmcm9tIGNvbXBpbGVkIHRlbXBsYXRlcy5cbiAgLy8gQXMgbG9uZyBhcyB0aGUgdXNlciBvbmx5IHVzZXMgdHJ1c3RlZCB0ZW1wbGF0ZXMsIHRoaXMgaXMgc2FmZS5cbiAgaW5zZXJ0U3RhdGljQ29udGVudChjb250ZW50LCBwYXJlbnQsIGFuY2hvciwgbmFtZXNwYWNlLCBzdGFydCwgZW5kKSB7XG4gICAgY29uc3QgYmVmb3JlID0gYW5jaG9yID8gYW5jaG9yLnByZXZpb3VzU2libGluZyA6IHBhcmVudC5sYXN0Q2hpbGQ7XG4gICAgaWYgKHN0YXJ0ICYmIChzdGFydCA9PT0gZW5kIHx8IHN0YXJ0Lm5leHRTaWJsaW5nKSkge1xuICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgcGFyZW50Lmluc2VydEJlZm9yZShzdGFydC5jbG9uZU5vZGUodHJ1ZSksIGFuY2hvcik7XG4gICAgICAgIGlmIChzdGFydCA9PT0gZW5kIHx8ICEoc3RhcnQgPSBzdGFydC5uZXh0U2libGluZykpIGJyZWFrO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0ZW1wbGF0ZUNvbnRhaW5lci5pbm5lckhUTUwgPSB1bnNhZmVUb1RydXN0ZWRIVE1MKFxuICAgICAgICBuYW1lc3BhY2UgPT09IFwic3ZnXCIgPyBgPHN2Zz4ke2NvbnRlbnR9PC9zdmc+YCA6IG5hbWVzcGFjZSA9PT0gXCJtYXRobWxcIiA/IGA8bWF0aD4ke2NvbnRlbnR9PC9tYXRoPmAgOiBjb250ZW50XG4gICAgICApO1xuICAgICAgY29uc3QgdGVtcGxhdGUgPSB0ZW1wbGF0ZUNvbnRhaW5lci5jb250ZW50O1xuICAgICAgaWYgKG5hbWVzcGFjZSA9PT0gXCJzdmdcIiB8fCBuYW1lc3BhY2UgPT09IFwibWF0aG1sXCIpIHtcbiAgICAgICAgY29uc3Qgd3JhcHBlciA9IHRlbXBsYXRlLmZpcnN0Q2hpbGQ7XG4gICAgICAgIHdoaWxlICh3cmFwcGVyLmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgICB0ZW1wbGF0ZS5hcHBlbmRDaGlsZCh3cmFwcGVyLmZpcnN0Q2hpbGQpO1xuICAgICAgICB9XG4gICAgICAgIHRlbXBsYXRlLnJlbW92ZUNoaWxkKHdyYXBwZXIpO1xuICAgICAgfVxuICAgICAgcGFyZW50Lmluc2VydEJlZm9yZSh0ZW1wbGF0ZSwgYW5jaG9yKTtcbiAgICB9XG4gICAgcmV0dXJuIFtcbiAgICAgIC8vIGZpcnN0XG4gICAgICBiZWZvcmUgPyBiZWZvcmUubmV4dFNpYmxpbmcgOiBwYXJlbnQuZmlyc3RDaGlsZCxcbiAgICAgIC8vIGxhc3RcbiAgICAgIGFuY2hvciA/IGFuY2hvci5wcmV2aW91c1NpYmxpbmcgOiBwYXJlbnQubGFzdENoaWxkXG4gICAgXTtcbiAgfVxufTtcblxuY29uc3QgVFJBTlNJVElPTiA9IFwidHJhbnNpdGlvblwiO1xuY29uc3QgQU5JTUFUSU9OID0gXCJhbmltYXRpb25cIjtcbmNvbnN0IHZ0Y0tleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfdnRjXCIpO1xuY29uc3QgRE9NVHJhbnNpdGlvblByb3BzVmFsaWRhdG9ycyA9IHtcbiAgbmFtZTogU3RyaW5nLFxuICB0eXBlOiBTdHJpbmcsXG4gIGNzczoge1xuICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgZGVmYXVsdDogdHJ1ZVxuICB9LFxuICBkdXJhdGlvbjogW1N0cmluZywgTnVtYmVyLCBPYmplY3RdLFxuICBlbnRlckZyb21DbGFzczogU3RyaW5nLFxuICBlbnRlckFjdGl2ZUNsYXNzOiBTdHJpbmcsXG4gIGVudGVyVG9DbGFzczogU3RyaW5nLFxuICBhcHBlYXJGcm9tQ2xhc3M6IFN0cmluZyxcbiAgYXBwZWFyQWN0aXZlQ2xhc3M6IFN0cmluZyxcbiAgYXBwZWFyVG9DbGFzczogU3RyaW5nLFxuICBsZWF2ZUZyb21DbGFzczogU3RyaW5nLFxuICBsZWF2ZUFjdGl2ZUNsYXNzOiBTdHJpbmcsXG4gIGxlYXZlVG9DbGFzczogU3RyaW5nXG59O1xuY29uc3QgVHJhbnNpdGlvblByb3BzVmFsaWRhdG9ycyA9IC8qIEBfX1BVUkVfXyAqLyBleHRlbmQoXG4gIHt9LFxuICBCYXNlVHJhbnNpdGlvblByb3BzVmFsaWRhdG9ycyxcbiAgRE9NVHJhbnNpdGlvblByb3BzVmFsaWRhdG9yc1xuKTtcbmNvbnN0IGRlY29yYXRlJDEgPSAodCkgPT4ge1xuICB0LmRpc3BsYXlOYW1lID0gXCJUcmFuc2l0aW9uXCI7XG4gIHQucHJvcHMgPSBUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzO1xuICByZXR1cm4gdDtcbn07XG5jb25zdCBUcmFuc2l0aW9uID0gLyogQF9fUFVSRV9fICovIGRlY29yYXRlJDEoXG4gIChwcm9wcywgeyBzbG90cyB9KSA9PiBoKEJhc2VUcmFuc2l0aW9uLCByZXNvbHZlVHJhbnNpdGlvblByb3BzKHByb3BzKSwgc2xvdHMpXG4pO1xuY29uc3QgY2FsbEhvb2sgPSAoaG9vaywgYXJncyA9IFtdKSA9PiB7XG4gIGlmIChpc0FycmF5KGhvb2spKSB7XG4gICAgaG9vay5mb3JFYWNoKChoMikgPT4gaDIoLi4uYXJncykpO1xuICB9IGVsc2UgaWYgKGhvb2spIHtcbiAgICBob29rKC4uLmFyZ3MpO1xuICB9XG59O1xuY29uc3QgaGFzRXhwbGljaXRDYWxsYmFjayA9IChob29rKSA9PiB7XG4gIHJldHVybiBob29rID8gaXNBcnJheShob29rKSA/IGhvb2suc29tZSgoaDIpID0+IGgyLmxlbmd0aCA+IDEpIDogaG9vay5sZW5ndGggPiAxIDogZmFsc2U7XG59O1xuZnVuY3Rpb24gcmVzb2x2ZVRyYW5zaXRpb25Qcm9wcyhyYXdQcm9wcykge1xuICBjb25zdCBiYXNlUHJvcHMgPSB7fTtcbiAgZm9yIChjb25zdCBrZXkgaW4gcmF3UHJvcHMpIHtcbiAgICBpZiAoIShrZXkgaW4gRE9NVHJhbnNpdGlvblByb3BzVmFsaWRhdG9ycykpIHtcbiAgICAgIGJhc2VQcm9wc1trZXldID0gcmF3UHJvcHNba2V5XTtcbiAgICB9XG4gIH1cbiAgaWYgKHJhd1Byb3BzLmNzcyA9PT0gZmFsc2UpIHtcbiAgICByZXR1cm4gYmFzZVByb3BzO1xuICB9XG4gIGNvbnN0IHtcbiAgICBuYW1lID0gXCJ2XCIsXG4gICAgdHlwZSxcbiAgICBkdXJhdGlvbixcbiAgICBlbnRlckZyb21DbGFzcyA9IGAke25hbWV9LWVudGVyLWZyb21gLFxuICAgIGVudGVyQWN0aXZlQ2xhc3MgPSBgJHtuYW1lfS1lbnRlci1hY3RpdmVgLFxuICAgIGVudGVyVG9DbGFzcyA9IGAke25hbWV9LWVudGVyLXRvYCxcbiAgICBhcHBlYXJGcm9tQ2xhc3MgPSBlbnRlckZyb21DbGFzcyxcbiAgICBhcHBlYXJBY3RpdmVDbGFzcyA9IGVudGVyQWN0aXZlQ2xhc3MsXG4gICAgYXBwZWFyVG9DbGFzcyA9IGVudGVyVG9DbGFzcyxcbiAgICBsZWF2ZUZyb21DbGFzcyA9IGAke25hbWV9LWxlYXZlLWZyb21gLFxuICAgIGxlYXZlQWN0aXZlQ2xhc3MgPSBgJHtuYW1lfS1sZWF2ZS1hY3RpdmVgLFxuICAgIGxlYXZlVG9DbGFzcyA9IGAke25hbWV9LWxlYXZlLXRvYFxuICB9ID0gcmF3UHJvcHM7XG4gIGNvbnN0IGR1cmF0aW9ucyA9IG5vcm1hbGl6ZUR1cmF0aW9uKGR1cmF0aW9uKTtcbiAgY29uc3QgZW50ZXJEdXJhdGlvbiA9IGR1cmF0aW9ucyAmJiBkdXJhdGlvbnNbMF07XG4gIGNvbnN0IGxlYXZlRHVyYXRpb24gPSBkdXJhdGlvbnMgJiYgZHVyYXRpb25zWzFdO1xuICBjb25zdCB7XG4gICAgb25CZWZvcmVFbnRlcixcbiAgICBvbkVudGVyLFxuICAgIG9uRW50ZXJDYW5jZWxsZWQsXG4gICAgb25MZWF2ZSxcbiAgICBvbkxlYXZlQ2FuY2VsbGVkLFxuICAgIG9uQmVmb3JlQXBwZWFyID0gb25CZWZvcmVFbnRlcixcbiAgICBvbkFwcGVhciA9IG9uRW50ZXIsXG4gICAgb25BcHBlYXJDYW5jZWxsZWQgPSBvbkVudGVyQ2FuY2VsbGVkXG4gIH0gPSBiYXNlUHJvcHM7XG4gIGNvbnN0IGZpbmlzaEVudGVyID0gKGVsLCBpc0FwcGVhciwgZG9uZSwgaXNDYW5jZWxsZWQpID0+IHtcbiAgICBlbC5fZW50ZXJDYW5jZWxsZWQgPSBpc0NhbmNlbGxlZDtcbiAgICByZW1vdmVUcmFuc2l0aW9uQ2xhc3MoZWwsIGlzQXBwZWFyID8gYXBwZWFyVG9DbGFzcyA6IGVudGVyVG9DbGFzcyk7XG4gICAgcmVtb3ZlVHJhbnNpdGlvbkNsYXNzKGVsLCBpc0FwcGVhciA/IGFwcGVhckFjdGl2ZUNsYXNzIDogZW50ZXJBY3RpdmVDbGFzcyk7XG4gICAgZG9uZSAmJiBkb25lKCk7XG4gIH07XG4gIGNvbnN0IGZpbmlzaExlYXZlID0gKGVsLCBkb25lKSA9PiB7XG4gICAgZWwuX2lzTGVhdmluZyA9IGZhbHNlO1xuICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgbGVhdmVGcm9tQ2xhc3MpO1xuICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgbGVhdmVUb0NsYXNzKTtcbiAgICByZW1vdmVUcmFuc2l0aW9uQ2xhc3MoZWwsIGxlYXZlQWN0aXZlQ2xhc3MpO1xuICAgIGRvbmUgJiYgZG9uZSgpO1xuICB9O1xuICBjb25zdCBtYWtlRW50ZXJIb29rID0gKGlzQXBwZWFyKSA9PiB7XG4gICAgcmV0dXJuIChlbCwgZG9uZSkgPT4ge1xuICAgICAgY29uc3QgaG9vayA9IGlzQXBwZWFyID8gb25BcHBlYXIgOiBvbkVudGVyO1xuICAgICAgY29uc3QgcmVzb2x2ZSA9ICgpID0+IGZpbmlzaEVudGVyKGVsLCBpc0FwcGVhciwgZG9uZSk7XG4gICAgICBjYWxsSG9vayhob29rLCBbZWwsIHJlc29sdmVdKTtcbiAgICAgIG5leHRGcmFtZSgoKSA9PiB7XG4gICAgICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgaXNBcHBlYXIgPyBhcHBlYXJGcm9tQ2xhc3MgOiBlbnRlckZyb21DbGFzcyk7XG4gICAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgaXNBcHBlYXIgPyBhcHBlYXJUb0NsYXNzIDogZW50ZXJUb0NsYXNzKTtcbiAgICAgICAgaWYgKCFoYXNFeHBsaWNpdENhbGxiYWNrKGhvb2spKSB7XG4gICAgICAgICAgd2hlblRyYW5zaXRpb25FbmRzKGVsLCB0eXBlLCBlbnRlckR1cmF0aW9uLCByZXNvbHZlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgfTtcbiAgcmV0dXJuIGV4dGVuZChiYXNlUHJvcHMsIHtcbiAgICBvbkJlZm9yZUVudGVyKGVsKSB7XG4gICAgICBjYWxsSG9vayhvbkJlZm9yZUVudGVyLCBbZWxdKTtcbiAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgZW50ZXJGcm9tQ2xhc3MpO1xuICAgICAgYWRkVHJhbnNpdGlvbkNsYXNzKGVsLCBlbnRlckFjdGl2ZUNsYXNzKTtcbiAgICB9LFxuICAgIG9uQmVmb3JlQXBwZWFyKGVsKSB7XG4gICAgICBjYWxsSG9vayhvbkJlZm9yZUFwcGVhciwgW2VsXSk7XG4gICAgICBhZGRUcmFuc2l0aW9uQ2xhc3MoZWwsIGFwcGVhckZyb21DbGFzcyk7XG4gICAgICBhZGRUcmFuc2l0aW9uQ2xhc3MoZWwsIGFwcGVhckFjdGl2ZUNsYXNzKTtcbiAgICB9LFxuICAgIG9uRW50ZXI6IG1ha2VFbnRlckhvb2soZmFsc2UpLFxuICAgIG9uQXBwZWFyOiBtYWtlRW50ZXJIb29rKHRydWUpLFxuICAgIG9uTGVhdmUoZWwsIGRvbmUpIHtcbiAgICAgIGVsLl9pc0xlYXZpbmcgPSB0cnVlO1xuICAgICAgY29uc3QgcmVzb2x2ZSA9ICgpID0+IGZpbmlzaExlYXZlKGVsLCBkb25lKTtcbiAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgbGVhdmVGcm9tQ2xhc3MpO1xuICAgICAgaWYgKCFlbC5fZW50ZXJDYW5jZWxsZWQpIHtcbiAgICAgICAgZm9yY2VSZWZsb3coZWwpO1xuICAgICAgICBhZGRUcmFuc2l0aW9uQ2xhc3MoZWwsIGxlYXZlQWN0aXZlQ2xhc3MpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYWRkVHJhbnNpdGlvbkNsYXNzKGVsLCBsZWF2ZUFjdGl2ZUNsYXNzKTtcbiAgICAgICAgZm9yY2VSZWZsb3coZWwpO1xuICAgICAgfVxuICAgICAgbmV4dEZyYW1lKCgpID0+IHtcbiAgICAgICAgaWYgKCFlbC5faXNMZWF2aW5nKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgbGVhdmVGcm9tQ2xhc3MpO1xuICAgICAgICBhZGRUcmFuc2l0aW9uQ2xhc3MoZWwsIGxlYXZlVG9DbGFzcyk7XG4gICAgICAgIGlmICghaGFzRXhwbGljaXRDYWxsYmFjayhvbkxlYXZlKSkge1xuICAgICAgICAgIHdoZW5UcmFuc2l0aW9uRW5kcyhlbCwgdHlwZSwgbGVhdmVEdXJhdGlvbiwgcmVzb2x2ZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgY2FsbEhvb2sob25MZWF2ZSwgW2VsLCByZXNvbHZlXSk7XG4gICAgfSxcbiAgICBvbkVudGVyQ2FuY2VsbGVkKGVsKSB7XG4gICAgICBmaW5pc2hFbnRlcihlbCwgZmFsc2UsIHZvaWQgMCwgdHJ1ZSk7XG4gICAgICBjYWxsSG9vayhvbkVudGVyQ2FuY2VsbGVkLCBbZWxdKTtcbiAgICB9LFxuICAgIG9uQXBwZWFyQ2FuY2VsbGVkKGVsKSB7XG4gICAgICBmaW5pc2hFbnRlcihlbCwgdHJ1ZSwgdm9pZCAwLCB0cnVlKTtcbiAgICAgIGNhbGxIb29rKG9uQXBwZWFyQ2FuY2VsbGVkLCBbZWxdKTtcbiAgICB9LFxuICAgIG9uTGVhdmVDYW5jZWxsZWQoZWwpIHtcbiAgICAgIGZpbmlzaExlYXZlKGVsKTtcbiAgICAgIGNhbGxIb29rKG9uTGVhdmVDYW5jZWxsZWQsIFtlbF0pO1xuICAgIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVEdXJhdGlvbihkdXJhdGlvbikge1xuICBpZiAoZHVyYXRpb24gPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9IGVsc2UgaWYgKGlzT2JqZWN0KGR1cmF0aW9uKSkge1xuICAgIHJldHVybiBbTnVtYmVyT2YoZHVyYXRpb24uZW50ZXIpLCBOdW1iZXJPZihkdXJhdGlvbi5sZWF2ZSldO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IG4gPSBOdW1iZXJPZihkdXJhdGlvbik7XG4gICAgcmV0dXJuIFtuLCBuXTtcbiAgfVxufVxuZnVuY3Rpb24gTnVtYmVyT2YodmFsKSB7XG4gIGNvbnN0IHJlcyA9IHRvTnVtYmVyKHZhbCk7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgYXNzZXJ0TnVtYmVyKHJlcywgXCI8dHJhbnNpdGlvbj4gZXhwbGljaXQgZHVyYXRpb25cIik7XG4gIH1cbiAgcmV0dXJuIHJlcztcbn1cbmZ1bmN0aW9uIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgY2xzKSB7XG4gIGNscy5zcGxpdCgvXFxzKy8pLmZvckVhY2goKGMpID0+IGMgJiYgZWwuY2xhc3NMaXN0LmFkZChjKSk7XG4gIChlbFt2dGNLZXldIHx8IChlbFt2dGNLZXldID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSkpLmFkZChjbHMpO1xufVxuZnVuY3Rpb24gcmVtb3ZlVHJhbnNpdGlvbkNsYXNzKGVsLCBjbHMpIHtcbiAgY2xzLnNwbGl0KC9cXHMrLykuZm9yRWFjaCgoYykgPT4gYyAmJiBlbC5jbGFzc0xpc3QucmVtb3ZlKGMpKTtcbiAgY29uc3QgX3Z0YyA9IGVsW3Z0Y0tleV07XG4gIGlmIChfdnRjKSB7XG4gICAgX3Z0Yy5kZWxldGUoY2xzKTtcbiAgICBpZiAoIV92dGMuc2l6ZSkge1xuICAgICAgZWxbdnRjS2V5XSA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIG5leHRGcmFtZShjYikge1xuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZShjYik7XG4gIH0pO1xufVxubGV0IGVuZElkID0gMDtcbmZ1bmN0aW9uIHdoZW5UcmFuc2l0aW9uRW5kcyhlbCwgZXhwZWN0ZWRUeXBlLCBleHBsaWNpdFRpbWVvdXQsIHJlc29sdmUpIHtcbiAgY29uc3QgaWQgPSBlbC5fZW5kSWQgPSArK2VuZElkO1xuICBjb25zdCByZXNvbHZlSWZOb3RTdGFsZSA9ICgpID0+IHtcbiAgICBpZiAoaWQgPT09IGVsLl9lbmRJZCkge1xuICAgICAgcmVzb2x2ZSgpO1xuICAgIH1cbiAgfTtcbiAgaWYgKGV4cGxpY2l0VGltZW91dCAhPSBudWxsKSB7XG4gICAgcmV0dXJuIHNldFRpbWVvdXQocmVzb2x2ZUlmTm90U3RhbGUsIGV4cGxpY2l0VGltZW91dCk7XG4gIH1cbiAgY29uc3QgeyB0eXBlLCB0aW1lb3V0LCBwcm9wQ291bnQgfSA9IGdldFRyYW5zaXRpb25JbmZvKGVsLCBleHBlY3RlZFR5cGUpO1xuICBpZiAoIXR5cGUpIHtcbiAgICByZXR1cm4gcmVzb2x2ZSgpO1xuICB9XG4gIGNvbnN0IGVuZEV2ZW50ID0gdHlwZSArIFwiZW5kXCI7XG4gIGxldCBlbmRlZCA9IDA7XG4gIGNvbnN0IGVuZCA9ICgpID0+IHtcbiAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKGVuZEV2ZW50LCBvbkVuZCk7XG4gICAgcmVzb2x2ZUlmTm90U3RhbGUoKTtcbiAgfTtcbiAgY29uc3Qgb25FbmQgPSAoZSkgPT4ge1xuICAgIGlmIChlLnRhcmdldCA9PT0gZWwgJiYgKytlbmRlZCA+PSBwcm9wQ291bnQpIHtcbiAgICAgIGVuZCgpO1xuICAgIH1cbiAgfTtcbiAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgaWYgKGVuZGVkIDwgcHJvcENvdW50KSB7XG4gICAgICBlbmQoKTtcbiAgICB9XG4gIH0sIHRpbWVvdXQgKyAxKTtcbiAgZWwuYWRkRXZlbnRMaXN0ZW5lcihlbmRFdmVudCwgb25FbmQpO1xufVxuZnVuY3Rpb24gZ2V0VHJhbnNpdGlvbkluZm8oZWwsIGV4cGVjdGVkVHlwZSkge1xuICBjb25zdCBzdHlsZXMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gIGNvbnN0IGdldFN0eWxlUHJvcGVydGllcyA9IChrZXkpID0+IChzdHlsZXNba2V5XSB8fCBcIlwiKS5zcGxpdChcIiwgXCIpO1xuICBjb25zdCB0cmFuc2l0aW9uRGVsYXlzID0gZ2V0U3R5bGVQcm9wZXJ0aWVzKGAke1RSQU5TSVRJT059RGVsYXlgKTtcbiAgY29uc3QgdHJhbnNpdGlvbkR1cmF0aW9ucyA9IGdldFN0eWxlUHJvcGVydGllcyhgJHtUUkFOU0lUSU9OfUR1cmF0aW9uYCk7XG4gIGNvbnN0IHRyYW5zaXRpb25UaW1lb3V0ID0gZ2V0VGltZW91dCh0cmFuc2l0aW9uRGVsYXlzLCB0cmFuc2l0aW9uRHVyYXRpb25zKTtcbiAgY29uc3QgYW5pbWF0aW9uRGVsYXlzID0gZ2V0U3R5bGVQcm9wZXJ0aWVzKGAke0FOSU1BVElPTn1EZWxheWApO1xuICBjb25zdCBhbmltYXRpb25EdXJhdGlvbnMgPSBnZXRTdHlsZVByb3BlcnRpZXMoYCR7QU5JTUFUSU9OfUR1cmF0aW9uYCk7XG4gIGNvbnN0IGFuaW1hdGlvblRpbWVvdXQgPSBnZXRUaW1lb3V0KGFuaW1hdGlvbkRlbGF5cywgYW5pbWF0aW9uRHVyYXRpb25zKTtcbiAgbGV0IHR5cGUgPSBudWxsO1xuICBsZXQgdGltZW91dCA9IDA7XG4gIGxldCBwcm9wQ291bnQgPSAwO1xuICBpZiAoZXhwZWN0ZWRUeXBlID09PSBUUkFOU0lUSU9OKSB7XG4gICAgaWYgKHRyYW5zaXRpb25UaW1lb3V0ID4gMCkge1xuICAgICAgdHlwZSA9IFRSQU5TSVRJT047XG4gICAgICB0aW1lb3V0ID0gdHJhbnNpdGlvblRpbWVvdXQ7XG4gICAgICBwcm9wQ291bnQgPSB0cmFuc2l0aW9uRHVyYXRpb25zLmxlbmd0aDtcbiAgICB9XG4gIH0gZWxzZSBpZiAoZXhwZWN0ZWRUeXBlID09PSBBTklNQVRJT04pIHtcbiAgICBpZiAoYW5pbWF0aW9uVGltZW91dCA+IDApIHtcbiAgICAgIHR5cGUgPSBBTklNQVRJT047XG4gICAgICB0aW1lb3V0ID0gYW5pbWF0aW9uVGltZW91dDtcbiAgICAgIHByb3BDb3VudCA9IGFuaW1hdGlvbkR1cmF0aW9ucy5sZW5ndGg7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHRpbWVvdXQgPSBNYXRoLm1heCh0cmFuc2l0aW9uVGltZW91dCwgYW5pbWF0aW9uVGltZW91dCk7XG4gICAgdHlwZSA9IHRpbWVvdXQgPiAwID8gdHJhbnNpdGlvblRpbWVvdXQgPiBhbmltYXRpb25UaW1lb3V0ID8gVFJBTlNJVElPTiA6IEFOSU1BVElPTiA6IG51bGw7XG4gICAgcHJvcENvdW50ID0gdHlwZSA/IHR5cGUgPT09IFRSQU5TSVRJT04gPyB0cmFuc2l0aW9uRHVyYXRpb25zLmxlbmd0aCA6IGFuaW1hdGlvbkR1cmF0aW9ucy5sZW5ndGggOiAwO1xuICB9XG4gIGNvbnN0IGhhc1RyYW5zZm9ybSA9IHR5cGUgPT09IFRSQU5TSVRJT04gJiYgL1xcYig/OnRyYW5zZm9ybXxhbGwpKD86LHwkKS8udGVzdChcbiAgICBnZXRTdHlsZVByb3BlcnRpZXMoYCR7VFJBTlNJVElPTn1Qcm9wZXJ0eWApLnRvU3RyaW5nKClcbiAgKTtcbiAgcmV0dXJuIHtcbiAgICB0eXBlLFxuICAgIHRpbWVvdXQsXG4gICAgcHJvcENvdW50LFxuICAgIGhhc1RyYW5zZm9ybVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0VGltZW91dChkZWxheXMsIGR1cmF0aW9ucykge1xuICB3aGlsZSAoZGVsYXlzLmxlbmd0aCA8IGR1cmF0aW9ucy5sZW5ndGgpIHtcbiAgICBkZWxheXMgPSBkZWxheXMuY29uY2F0KGRlbGF5cyk7XG4gIH1cbiAgcmV0dXJuIE1hdGgubWF4KC4uLmR1cmF0aW9ucy5tYXAoKGQsIGkpID0+IHRvTXMoZCkgKyB0b01zKGRlbGF5c1tpXSkpKTtcbn1cbmZ1bmN0aW9uIHRvTXMocykge1xuICBpZiAocyA9PT0gXCJhdXRvXCIpIHJldHVybiAwO1xuICByZXR1cm4gTnVtYmVyKHMuc2xpY2UoMCwgLTEpLnJlcGxhY2UoXCIsXCIsIFwiLlwiKSkgKiAxZTM7XG59XG5mdW5jdGlvbiBmb3JjZVJlZmxvdyhlbCkge1xuICBjb25zdCB0YXJnZXREb2N1bWVudCA9IGVsID8gZWwub3duZXJEb2N1bWVudCA6IGRvY3VtZW50O1xuICByZXR1cm4gdGFyZ2V0RG9jdW1lbnQuYm9keS5vZmZzZXRIZWlnaHQ7XG59XG5cbmZ1bmN0aW9uIHBhdGNoQ2xhc3MoZWwsIHZhbHVlLCBpc1NWRykge1xuICBjb25zdCB0cmFuc2l0aW9uQ2xhc3NlcyA9IGVsW3Z0Y0tleV07XG4gIGlmICh0cmFuc2l0aW9uQ2xhc3Nlcykge1xuICAgIHZhbHVlID0gKHZhbHVlID8gW3ZhbHVlLCAuLi50cmFuc2l0aW9uQ2xhc3Nlc10gOiBbLi4udHJhbnNpdGlvbkNsYXNzZXNdKS5qb2luKFwiIFwiKTtcbiAgfVxuICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgIGVsLnJlbW92ZUF0dHJpYnV0ZShcImNsYXNzXCIpO1xuICB9IGVsc2UgaWYgKGlzU1ZHKSB7XG4gICAgZWwuc2V0QXR0cmlidXRlKFwiY2xhc3NcIiwgdmFsdWUpO1xuICB9IGVsc2Uge1xuICAgIGVsLmNsYXNzTmFtZSA9IHZhbHVlO1xuICB9XG59XG5cbmNvbnN0IHZTaG93T3JpZ2luYWxEaXNwbGF5ID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcIl92b2RcIik7XG5jb25zdCB2U2hvd0hpZGRlbiA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfdnNoXCIpO1xuY29uc3QgdlNob3cgPSB7XG4gIC8vIHVzZWQgZm9yIHByb3AgbWlzbWF0Y2ggY2hlY2sgZHVyaW5nIGh5ZHJhdGlvblxuICBuYW1lOiBcInNob3dcIixcbiAgYmVmb3JlTW91bnQoZWwsIHsgdmFsdWUgfSwgeyB0cmFuc2l0aW9uIH0pIHtcbiAgICBlbFt2U2hvd09yaWdpbmFsRGlzcGxheV0gPSBlbC5zdHlsZS5kaXNwbGF5ID09PSBcIm5vbmVcIiA/IFwiXCIgOiBlbC5zdHlsZS5kaXNwbGF5O1xuICAgIGlmICh0cmFuc2l0aW9uICYmIHZhbHVlKSB7XG4gICAgICB0cmFuc2l0aW9uLmJlZm9yZUVudGVyKGVsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0RGlzcGxheShlbCwgdmFsdWUpO1xuICAgIH1cbiAgfSxcbiAgbW91bnRlZChlbCwgeyB2YWx1ZSB9LCB7IHRyYW5zaXRpb24gfSkge1xuICAgIGlmICh0cmFuc2l0aW9uICYmIHZhbHVlKSB7XG4gICAgICB0cmFuc2l0aW9uLmVudGVyKGVsKTtcbiAgICB9XG4gIH0sXG4gIHVwZGF0ZWQoZWwsIHsgdmFsdWUsIG9sZFZhbHVlIH0sIHsgdHJhbnNpdGlvbiB9KSB7XG4gICAgaWYgKCF2YWx1ZSA9PT0gIW9sZFZhbHVlKSByZXR1cm47XG4gICAgaWYgKHRyYW5zaXRpb24pIHtcbiAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICB0cmFuc2l0aW9uLmJlZm9yZUVudGVyKGVsKTtcbiAgICAgICAgc2V0RGlzcGxheShlbCwgdHJ1ZSk7XG4gICAgICAgIHRyYW5zaXRpb24uZW50ZXIoZWwpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdHJhbnNpdGlvbi5sZWF2ZShlbCwgKCkgPT4ge1xuICAgICAgICAgIHNldERpc3BsYXkoZWwsIGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldERpc3BsYXkoZWwsIHZhbHVlKTtcbiAgICB9XG4gIH0sXG4gIGJlZm9yZVVubW91bnQoZWwsIHsgdmFsdWUgfSkge1xuICAgIHNldERpc3BsYXkoZWwsIHZhbHVlKTtcbiAgfVxufTtcbmZ1bmN0aW9uIHNldERpc3BsYXkoZWwsIHZhbHVlKSB7XG4gIGVsLnN0eWxlLmRpc3BsYXkgPSB2YWx1ZSA/IGVsW3ZTaG93T3JpZ2luYWxEaXNwbGF5XSA6IFwibm9uZVwiO1xuICBlbFt2U2hvd0hpZGRlbl0gPSAhdmFsdWU7XG59XG5mdW5jdGlvbiBpbml0VlNob3dGb3JTU1IoKSB7XG4gIHZTaG93LmdldFNTUlByb3BzID0gKHsgdmFsdWUgfSkgPT4ge1xuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHJldHVybiB7IHN0eWxlOiB7IGRpc3BsYXk6IFwibm9uZVwiIH0gfTtcbiAgICB9XG4gIH07XG59XG5cbmNvbnN0IENTU19WQVJfVEVYVCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IFwiQ1NTX1ZBUl9URVhUXCIgOiBcIlwiKTtcbmZ1bmN0aW9uIHVzZUNzc1ZhcnMoZ2V0dGVyKSB7XG4gIGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGlmICghaW5zdGFuY2UpIHtcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4oYHVzZUNzc1ZhcnMgaXMgY2FsbGVkIHdpdGhvdXQgY3VycmVudCBhY3RpdmUgY29tcG9uZW50IGluc3RhbmNlLmApO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB1cGRhdGVUZWxlcG9ydHMgPSBpbnN0YW5jZS51dCA9ICh2YXJzID0gZ2V0dGVyKGluc3RhbmNlLnByb3h5KSkgPT4ge1xuICAgIEFycmF5LmZyb20oXG4gICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKGBbZGF0YS12LW93bmVyPVwiJHtpbnN0YW5jZS51aWR9XCJdYClcbiAgICApLmZvckVhY2goKG5vZGUpID0+IHNldFZhcnNPbk5vZGUobm9kZSwgdmFycykpO1xuICB9O1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGluc3RhbmNlLmdldENzc1ZhcnMgPSAoKSA9PiBnZXR0ZXIoaW5zdGFuY2UucHJveHkpO1xuICB9XG4gIGNvbnN0IHNldFZhcnMgPSAoKSA9PiB7XG4gICAgY29uc3QgdmFycyA9IGdldHRlcihpbnN0YW5jZS5wcm94eSk7XG4gICAgaWYgKGluc3RhbmNlLmNlKSB7XG4gICAgICBzZXRWYXJzT25Ob2RlKGluc3RhbmNlLmNlLCB2YXJzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0VmFyc09uVk5vZGUoaW5zdGFuY2Uuc3ViVHJlZSwgdmFycyk7XG4gICAgfVxuICAgIHVwZGF0ZVRlbGVwb3J0cyh2YXJzKTtcbiAgfTtcbiAgb25CZWZvcmVVcGRhdGUoKCkgPT4ge1xuICAgIHF1ZXVlUG9zdEZsdXNoQ2Ioc2V0VmFycyk7XG4gIH0pO1xuICBvbk1vdW50ZWQoKCkgPT4ge1xuICAgIHdhdGNoKHNldFZhcnMsIE5PT1AsIHsgZmx1c2g6IFwicG9zdFwiIH0pO1xuICAgIGNvbnN0IG9iID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoc2V0VmFycyk7XG4gICAgb2Iub2JzZXJ2ZShpbnN0YW5jZS5zdWJUcmVlLmVsLnBhcmVudE5vZGUsIHsgY2hpbGRMaXN0OiB0cnVlIH0pO1xuICAgIG9uVW5tb3VudGVkKCgpID0+IG9iLmRpc2Nvbm5lY3QoKSk7XG4gIH0pO1xufVxuZnVuY3Rpb24gc2V0VmFyc09uVk5vZGUodm5vZGUsIHZhcnMpIHtcbiAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDEyOCkge1xuICAgIGNvbnN0IHN1c3BlbnNlID0gdm5vZGUuc3VzcGVuc2U7XG4gICAgdm5vZGUgPSBzdXNwZW5zZS5hY3RpdmVCcmFuY2g7XG4gICAgaWYgKHN1c3BlbnNlLnBlbmRpbmdCcmFuY2ggJiYgIXN1c3BlbnNlLmlzSHlkcmF0aW5nKSB7XG4gICAgICBzdXNwZW5zZS5lZmZlY3RzLnB1c2goKCkgPT4ge1xuICAgICAgICBzZXRWYXJzT25WTm9kZShzdXNwZW5zZS5hY3RpdmVCcmFuY2gsIHZhcnMpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHdoaWxlICh2bm9kZS5jb21wb25lbnQpIHtcbiAgICB2bm9kZSA9IHZub2RlLmNvbXBvbmVudC5zdWJUcmVlO1xuICB9XG4gIGlmICh2bm9kZS5zaGFwZUZsYWcgJiAxICYmIHZub2RlLmVsKSB7XG4gICAgc2V0VmFyc09uTm9kZSh2bm9kZS5lbCwgdmFycyk7XG4gIH0gZWxzZSBpZiAodm5vZGUudHlwZSA9PT0gRnJhZ21lbnQpIHtcbiAgICB2bm9kZS5jaGlsZHJlbi5mb3JFYWNoKChjKSA9PiBzZXRWYXJzT25WTm9kZShjLCB2YXJzKSk7XG4gIH0gZWxzZSBpZiAodm5vZGUudHlwZSA9PT0gU3RhdGljKSB7XG4gICAgbGV0IHsgZWwsIGFuY2hvciB9ID0gdm5vZGU7XG4gICAgd2hpbGUgKGVsKSB7XG4gICAgICBzZXRWYXJzT25Ob2RlKGVsLCB2YXJzKTtcbiAgICAgIGlmIChlbCA9PT0gYW5jaG9yKSBicmVhaztcbiAgICAgIGVsID0gZWwubmV4dFNpYmxpbmc7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBzZXRWYXJzT25Ob2RlKGVsLCB2YXJzKSB7XG4gIGlmIChlbC5ub2RlVHlwZSA9PT0gMSkge1xuICAgIGNvbnN0IHN0eWxlID0gZWwuc3R5bGU7XG4gICAgbGV0IGNzc1RleHQgPSBcIlwiO1xuICAgIGZvciAoY29uc3Qga2V5IGluIHZhcnMpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gbm9ybWFsaXplQ3NzVmFyVmFsdWUodmFyc1trZXldKTtcbiAgICAgIHN0eWxlLnNldFByb3BlcnR5KGAtLSR7a2V5fWAsIHZhbHVlKTtcbiAgICAgIGNzc1RleHQgKz0gYC0tJHtrZXl9OiAke3ZhbHVlfTtgO1xuICAgIH1cbiAgICBzdHlsZVtDU1NfVkFSX1RFWFRdID0gY3NzVGV4dDtcbiAgfVxufVxuXG5jb25zdCBkaXNwbGF5UkUgPSAvKD86Xnw7KVxccypkaXNwbGF5XFxzKjovO1xuZnVuY3Rpb24gcGF0Y2hTdHlsZShlbCwgcHJldiwgbmV4dCkge1xuICBjb25zdCBzdHlsZSA9IGVsLnN0eWxlO1xuICBjb25zdCBpc0Nzc1N0cmluZyA9IGlzU3RyaW5nKG5leHQpO1xuICBsZXQgaGFzQ29udHJvbGxlZERpc3BsYXkgPSBmYWxzZTtcbiAgaWYgKG5leHQgJiYgIWlzQ3NzU3RyaW5nKSB7XG4gICAgaWYgKHByZXYpIHtcbiAgICAgIGlmICghaXNTdHJpbmcocHJldikpIHtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gcHJldikge1xuICAgICAgICAgIGlmIChuZXh0W2tleV0gPT0gbnVsbCkge1xuICAgICAgICAgICAgc2V0U3R5bGUoc3R5bGUsIGtleSwgXCJcIik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmb3IgKGNvbnN0IHByZXZTdHlsZSBvZiBwcmV2LnNwbGl0KFwiO1wiKSkge1xuICAgICAgICAgIGNvbnN0IGtleSA9IHByZXZTdHlsZS5zbGljZSgwLCBwcmV2U3R5bGUuaW5kZXhPZihcIjpcIikpLnRyaW0oKTtcbiAgICAgICAgICBpZiAobmV4dFtrZXldID09IG51bGwpIHtcbiAgICAgICAgICAgIHNldFN0eWxlKHN0eWxlLCBrZXksIFwiXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleSBpbiBuZXh0KSB7XG4gICAgICBpZiAoa2V5ID09PSBcImRpc3BsYXlcIikge1xuICAgICAgICBoYXNDb250cm9sbGVkRGlzcGxheSA9IHRydWU7XG4gICAgICB9XG4gICAgICBjb25zdCB2YWx1ZSA9IG5leHRba2V5XTtcbiAgICAgIGlmICh2YWx1ZSAhPSBudWxsKSB7XG4gICAgICAgIGlmICghc2hvdWxkUHJlc2VydmVUZXh0YXJlYVJlc2l6ZVN0eWxlKFxuICAgICAgICAgIGVsLFxuICAgICAgICAgIGtleSxcbiAgICAgICAgICAhaXNTdHJpbmcocHJldikgJiYgcHJldiA/IHByZXZba2V5XSA6IHZvaWQgMCxcbiAgICAgICAgICB2YWx1ZVxuICAgICAgICApKSB7XG4gICAgICAgICAgc2V0U3R5bGUoc3R5bGUsIGtleSwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRTdHlsZShzdHlsZSwga2V5LCBcIlwiKTtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKGlzQ3NzU3RyaW5nKSB7XG4gICAgICBpZiAocHJldiAhPT0gbmV4dCkge1xuICAgICAgICBjb25zdCBjc3NWYXJUZXh0ID0gc3R5bGVbQ1NTX1ZBUl9URVhUXTtcbiAgICAgICAgaWYgKGNzc1ZhclRleHQpIHtcbiAgICAgICAgICBuZXh0ICs9IFwiO1wiICsgY3NzVmFyVGV4dDtcbiAgICAgICAgfVxuICAgICAgICBzdHlsZS5jc3NUZXh0ID0gbmV4dDtcbiAgICAgICAgaGFzQ29udHJvbGxlZERpc3BsYXkgPSBkaXNwbGF5UkUudGVzdChuZXh0KTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHByZXYpIHtcbiAgICAgIGVsLnJlbW92ZUF0dHJpYnV0ZShcInN0eWxlXCIpO1xuICAgIH1cbiAgfVxuICBpZiAodlNob3dPcmlnaW5hbERpc3BsYXkgaW4gZWwpIHtcbiAgICBlbFt2U2hvd09yaWdpbmFsRGlzcGxheV0gPSBoYXNDb250cm9sbGVkRGlzcGxheSA/IHN0eWxlLmRpc3BsYXkgOiBcIlwiO1xuICAgIGlmIChlbFt2U2hvd0hpZGRlbl0pIHtcbiAgICAgIHN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICB9XG4gIH1cbn1cbmNvbnN0IHNlbWljb2xvblJFID0gL1teXFxcXF07XFxzKiQvO1xuY29uc3QgaW1wb3J0YW50UkUgPSAvXFxzKiFpbXBvcnRhbnQkLztcbmZ1bmN0aW9uIHNldFN0eWxlKHN0eWxlLCBuYW1lLCB2YWwpIHtcbiAgaWYgKGlzQXJyYXkodmFsKSkge1xuICAgIHZhbC5mb3JFYWNoKCh2KSA9PiBzZXRTdHlsZShzdHlsZSwgbmFtZSwgdikpO1xuICB9IGVsc2Uge1xuICAgIGlmICh2YWwgPT0gbnVsbCkgdmFsID0gXCJcIjtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgaWYgKHNlbWljb2xvblJFLnRlc3QodmFsKSkge1xuICAgICAgICB3YXJuKFxuICAgICAgICAgIGBVbmV4cGVjdGVkIHNlbWljb2xvbiBhdCB0aGUgZW5kIG9mICcke25hbWV9JyBzdHlsZSB2YWx1ZTogJyR7dmFsfSdgXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChuYW1lLnN0YXJ0c1dpdGgoXCItLVwiKSkge1xuICAgICAgc3R5bGUuc2V0UHJvcGVydHkobmFtZSwgdmFsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgcHJlZml4ZWQgPSBhdXRvUHJlZml4KHN0eWxlLCBuYW1lKTtcbiAgICAgIGlmIChpbXBvcnRhbnRSRS50ZXN0KHZhbCkpIHtcbiAgICAgICAgc3R5bGUuc2V0UHJvcGVydHkoXG4gICAgICAgICAgaHlwaGVuYXRlKHByZWZpeGVkKSxcbiAgICAgICAgICB2YWwucmVwbGFjZShpbXBvcnRhbnRSRSwgXCJcIiksXG4gICAgICAgICAgXCJpbXBvcnRhbnRcIlxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3R5bGVbcHJlZml4ZWRdID0gdmFsO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuY29uc3QgcHJlZml4ZXMgPSBbXCJXZWJraXRcIiwgXCJNb3pcIiwgXCJtc1wiXTtcbmNvbnN0IHByZWZpeENhY2hlID0ge307XG5mdW5jdGlvbiBhdXRvUHJlZml4KHN0eWxlLCByYXdOYW1lKSB7XG4gIGNvbnN0IGNhY2hlZCA9IHByZWZpeENhY2hlW3Jhd05hbWVdO1xuICBpZiAoY2FjaGVkKSB7XG4gICAgcmV0dXJuIGNhY2hlZDtcbiAgfVxuICBsZXQgbmFtZSA9IGNhbWVsaXplKHJhd05hbWUpO1xuICBpZiAobmFtZSAhPT0gXCJmaWx0ZXJcIiAmJiBuYW1lIGluIHN0eWxlKSB7XG4gICAgcmV0dXJuIHByZWZpeENhY2hlW3Jhd05hbWVdID0gbmFtZTtcbiAgfVxuICBuYW1lID0gY2FwaXRhbGl6ZShuYW1lKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmVmaXhlcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHByZWZpeGVkID0gcHJlZml4ZXNbaV0gKyBuYW1lO1xuICAgIGlmIChwcmVmaXhlZCBpbiBzdHlsZSkge1xuICAgICAgcmV0dXJuIHByZWZpeENhY2hlW3Jhd05hbWVdID0gcHJlZml4ZWQ7XG4gICAgfVxuICB9XG4gIHJldHVybiByYXdOYW1lO1xufVxuZnVuY3Rpb24gc2hvdWxkUHJlc2VydmVUZXh0YXJlYVJlc2l6ZVN0eWxlKGVsLCBrZXksIHByZXYsIG5leHQpIHtcbiAgcmV0dXJuIGVsLnRhZ05hbWUgPT09IFwiVEVYVEFSRUFcIiAmJiAoa2V5ID09PSBcIndpZHRoXCIgfHwga2V5ID09PSBcImhlaWdodFwiKSAmJiBpc1N0cmluZyhuZXh0KSAmJiBwcmV2ID09PSBuZXh0O1xufVxuXG5jb25zdCB4bGlua05TID0gXCJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rXCI7XG5mdW5jdGlvbiBwYXRjaEF0dHIoZWwsIGtleSwgdmFsdWUsIGlzU1ZHLCBpbnN0YW5jZSwgaXNCb29sZWFuID0gaXNTcGVjaWFsQm9vbGVhbkF0dHIoa2V5KSkge1xuICBpZiAoaXNTVkcgJiYga2V5LnN0YXJ0c1dpdGgoXCJ4bGluazpcIikpIHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgICAgZWwucmVtb3ZlQXR0cmlidXRlTlMoeGxpbmtOUywga2V5LnNsaWNlKDYsIGtleS5sZW5ndGgpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWwuc2V0QXR0cmlidXRlTlMoeGxpbmtOUywga2V5LCB2YWx1ZSk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsIHx8IGlzQm9vbGVhbiAmJiAhaW5jbHVkZUJvb2xlYW5BdHRyKHZhbHVlKSkge1xuICAgICAgZWwucmVtb3ZlQXR0cmlidXRlKGtleSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGVsLnNldEF0dHJpYnV0ZShcbiAgICAgICAga2V5LFxuICAgICAgICBpc0Jvb2xlYW4gPyBcIlwiIDogaXNTeW1ib2wodmFsdWUpID8gU3RyaW5nKHZhbHVlKSA6IHZhbHVlXG4gICAgICApO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBwYXRjaERPTVByb3AoZWwsIGtleSwgdmFsdWUsIHBhcmVudENvbXBvbmVudCwgYXR0ck5hbWUpIHtcbiAgaWYgKGtleSA9PT0gXCJpbm5lckhUTUxcIiB8fCBrZXkgPT09IFwidGV4dENvbnRlbnRcIikge1xuICAgIGlmICh2YWx1ZSAhPSBudWxsKSB7XG4gICAgICBlbFtrZXldID0ga2V5ID09PSBcImlubmVySFRNTFwiID8gdW5zYWZlVG9UcnVzdGVkSFRNTCh2YWx1ZSkgOiB2YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHRhZyA9IGVsLnRhZ05hbWU7XG4gIGlmIChrZXkgPT09IFwidmFsdWVcIiAmJiB0YWcgIT09IFwiUFJPR1JFU1NcIiAmJiAvLyBjdXN0b20gZWxlbWVudHMgbWF5IHVzZSBfdmFsdWUgaW50ZXJuYWxseVxuICAhdGFnLmluY2x1ZGVzKFwiLVwiKSkge1xuICAgIGNvbnN0IG9sZFZhbHVlID0gdGFnID09PSBcIk9QVElPTlwiID8gZWwuZ2V0QXR0cmlidXRlKFwidmFsdWVcIikgfHwgXCJcIiA6IGVsLnZhbHVlO1xuICAgIGNvbnN0IG5ld1ZhbHVlID0gdmFsdWUgPT0gbnVsbCA/IChcbiAgICAgIC8vICMxMTY0NzogdmFsdWUgc2hvdWxkIGJlIHNldCBhcyBlbXB0eSBzdHJpbmcgZm9yIG51bGwgYW5kIHVuZGVmaW5lZCxcbiAgICAgIC8vIGJ1dCA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCI+IHNob3VsZCBiZSBzZXQgYXMgJ29uJy5cbiAgICAgIGVsLnR5cGUgPT09IFwiY2hlY2tib3hcIiA/IFwib25cIiA6IFwiXCJcbiAgICApIDogU3RyaW5nKHZhbHVlKTtcbiAgICBpZiAob2xkVmFsdWUgIT09IG5ld1ZhbHVlIHx8ICEoXCJfdmFsdWVcIiBpbiBlbCkpIHtcbiAgICAgIGVsLnZhbHVlID0gbmV3VmFsdWU7XG4gICAgfVxuICAgIGlmICh2YWx1ZSA9PSBudWxsKSB7XG4gICAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoa2V5KTtcbiAgICB9XG4gICAgZWwuX3ZhbHVlID0gdmFsdWU7XG4gICAgcmV0dXJuO1xuICB9XG4gIGxldCBuZWVkUmVtb3ZlID0gZmFsc2U7XG4gIGlmICh2YWx1ZSA9PT0gXCJcIiB8fCB2YWx1ZSA9PSBudWxsKSB7XG4gICAgY29uc3QgdHlwZSA9IHR5cGVvZiBlbFtrZXldO1xuICAgIGlmICh0eXBlID09PSBcImJvb2xlYW5cIikge1xuICAgICAgdmFsdWUgPSBpbmNsdWRlQm9vbGVhbkF0dHIodmFsdWUpO1xuICAgIH0gZWxzZSBpZiAodmFsdWUgPT0gbnVsbCAmJiB0eXBlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB2YWx1ZSA9IFwiXCI7XG4gICAgICBuZWVkUmVtb3ZlID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHZhbHVlID0gMDtcbiAgICAgIG5lZWRSZW1vdmUgPSB0cnVlO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGVsW2tleV0gPSB2YWx1ZTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFuZWVkUmVtb3ZlKSB7XG4gICAgICB3YXJuKFxuICAgICAgICBgRmFpbGVkIHNldHRpbmcgcHJvcCBcIiR7a2V5fVwiIG9uIDwke3RhZy50b0xvd2VyQ2FzZSgpfT46IHZhbHVlICR7dmFsdWV9IGlzIGludmFsaWQuYCxcbiAgICAgICAgZVxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgbmVlZFJlbW92ZSAmJiBlbC5yZW1vdmVBdHRyaWJ1dGUoYXR0ck5hbWUgfHwga2V5KTtcbn1cblxuZnVuY3Rpb24gYWRkRXZlbnRMaXN0ZW5lcihlbCwgZXZlbnQsIGhhbmRsZXIsIG9wdGlvbnMpIHtcbiAgZWwuYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgaGFuZGxlciwgb3B0aW9ucyk7XG59XG5mdW5jdGlvbiByZW1vdmVFdmVudExpc3RlbmVyKGVsLCBldmVudCwgaGFuZGxlciwgb3B0aW9ucykge1xuICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCBoYW5kbGVyLCBvcHRpb25zKTtcbn1cbmNvbnN0IHZlaUtleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfdmVpXCIpO1xuZnVuY3Rpb24gcGF0Y2hFdmVudChlbCwgcmF3TmFtZSwgcHJldlZhbHVlLCBuZXh0VmFsdWUsIGluc3RhbmNlID0gbnVsbCkge1xuICBjb25zdCBpbnZva2VycyA9IGVsW3ZlaUtleV0gfHwgKGVsW3ZlaUtleV0gPSB7fSk7XG4gIGNvbnN0IGV4aXN0aW5nSW52b2tlciA9IGludm9rZXJzW3Jhd05hbWVdO1xuICBpZiAobmV4dFZhbHVlICYmIGV4aXN0aW5nSW52b2tlcikge1xuICAgIGV4aXN0aW5nSW52b2tlci52YWx1ZSA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzYW5pdGl6ZUV2ZW50VmFsdWUobmV4dFZhbHVlLCByYXdOYW1lKSA6IG5leHRWYWx1ZTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBbbmFtZSwgb3B0aW9uc10gPSBwYXJzZU5hbWUocmF3TmFtZSk7XG4gICAgaWYgKG5leHRWYWx1ZSkge1xuICAgICAgY29uc3QgaW52b2tlciA9IGludm9rZXJzW3Jhd05hbWVdID0gY3JlYXRlSW52b2tlcihcbiAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNhbml0aXplRXZlbnRWYWx1ZShuZXh0VmFsdWUsIHJhd05hbWUpIDogbmV4dFZhbHVlLFxuICAgICAgICBpbnN0YW5jZVxuICAgICAgKTtcbiAgICAgIGFkZEV2ZW50TGlzdGVuZXIoZWwsIG5hbWUsIGludm9rZXIsIG9wdGlvbnMpO1xuICAgIH0gZWxzZSBpZiAoZXhpc3RpbmdJbnZva2VyKSB7XG4gICAgICByZW1vdmVFdmVudExpc3RlbmVyKGVsLCBuYW1lLCBleGlzdGluZ0ludm9rZXIsIG9wdGlvbnMpO1xuICAgICAgaW52b2tlcnNbcmF3TmFtZV0gPSB2b2lkIDA7XG4gICAgfVxuICB9XG59XG5jb25zdCBvcHRpb25zTW9kaWZpZXJSRSA9IC8oT25jZXxQYXNzaXZlfENhcHR1cmUpJC87XG5jb25zdCBvcHRpb25zTW9kaWZpZXJFdmVudFJFID0gL15vbjo/KD86T25jZXxQYXNzaXZlfENhcHR1cmUpJC87XG5mdW5jdGlvbiBwYXJzZU5hbWUobmFtZSkge1xuICBsZXQgb3B0aW9ucztcbiAgbGV0IG07XG4gIHdoaWxlICgobSA9IG5hbWUubWF0Y2gob3B0aW9uc01vZGlmaWVyUkUpKSAmJiAhb3B0aW9uc01vZGlmaWVyRXZlbnRSRS50ZXN0KG5hbWUpKSB7XG4gICAgaWYgKCFvcHRpb25zKSBvcHRpb25zID0ge307XG4gICAgbmFtZSA9IG5hbWUuc2xpY2UoMCwgbmFtZS5sZW5ndGggLSBtWzFdLmxlbmd0aCk7XG4gICAgb3B0aW9uc1ttWzFdLnRvTG93ZXJDYXNlKCldID0gdHJ1ZTtcbiAgfVxuICBjb25zdCBldmVudCA9IG5hbWVbMl0gPT09IFwiOlwiID8gbmFtZS5zbGljZSgzKSA6IGh5cGhlbmF0ZShuYW1lLnNsaWNlKDIpKTtcbiAgcmV0dXJuIFtldmVudCwgb3B0aW9uc107XG59XG5sZXQgY2FjaGVkTm93ID0gMDtcbmNvbnN0IHAgPSAvKiBAX19QVVJFX18gKi8gUHJvbWlzZS5yZXNvbHZlKCk7XG5jb25zdCBnZXROb3cgPSAoKSA9PiBjYWNoZWROb3cgfHwgKHAudGhlbigoKSA9PiBjYWNoZWROb3cgPSAwKSwgY2FjaGVkTm93ID0gRGF0ZS5ub3coKSk7XG5mdW5jdGlvbiBjcmVhdGVJbnZva2VyKGluaXRpYWxWYWx1ZSwgaW5zdGFuY2UpIHtcbiAgY29uc3QgaW52b2tlciA9IChlKSA9PiB7XG4gICAgaWYgKCFlLl92dHMpIHtcbiAgICAgIGUuX3Z0cyA9IERhdGUubm93KCk7XG4gICAgfSBlbHNlIGlmIChlLl92dHMgPD0gaW52b2tlci5hdHRhY2hlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB2YWx1ZSA9IGludm9rZXIudmFsdWU7XG4gICAgaWYgKGlzQXJyYXkodmFsdWUpKSB7XG4gICAgICBjb25zdCBvcmlnaW5hbFN0b3AgPSBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbjtcbiAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uID0gKCkgPT4ge1xuICAgICAgICBvcmlnaW5hbFN0b3AuY2FsbChlKTtcbiAgICAgICAgZS5fc3RvcHBlZCA9IHRydWU7XG4gICAgICB9O1xuICAgICAgY29uc3QgaGFuZGxlcnMgPSB2YWx1ZS5zbGljZSgpO1xuICAgICAgY29uc3QgYXJncyA9IFtlXTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaGFuZGxlcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKGUuX3N0b3BwZWQpIHtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBoYW5kbGVyID0gaGFuZGxlcnNbaV07XG4gICAgICAgIGlmIChoYW5kbGVyKSB7XG4gICAgICAgICAgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoXG4gICAgICAgICAgICBoYW5kbGVyLFxuICAgICAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgICAgICA1LFxuICAgICAgICAgICAgYXJnc1xuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoXG4gICAgICAgIHZhbHVlLFxuICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgNSxcbiAgICAgICAgW2VdXG4gICAgICApO1xuICAgIH1cbiAgfTtcbiAgaW52b2tlci52YWx1ZSA9IGluaXRpYWxWYWx1ZTtcbiAgaW52b2tlci5hdHRhY2hlZCA9IGdldE5vdygpO1xuICByZXR1cm4gaW52b2tlcjtcbn1cbmZ1bmN0aW9uIHNhbml0aXplRXZlbnRWYWx1ZSh2YWx1ZSwgcHJvcE5hbWUpIHtcbiAgaWYgKGlzRnVuY3Rpb24odmFsdWUpIHx8IGlzQXJyYXkodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHdhcm4oXG4gICAgYFdyb25nIHR5cGUgcGFzc2VkIGFzIGV2ZW50IGhhbmRsZXIgdG8gJHtwcm9wTmFtZX0gLSBkaWQgeW91IGZvcmdldCBAIG9yIDogaW4gZnJvbnQgb2YgeW91ciBwcm9wP1xuRXhwZWN0ZWQgZnVuY3Rpb24gb3IgYXJyYXkgb2YgZnVuY3Rpb25zLCByZWNlaXZlZCB0eXBlICR7dHlwZW9mIHZhbHVlfS5gXG4gICk7XG4gIHJldHVybiBOT09QO1xufVxuXG5jb25zdCBpc05hdGl2ZU9uID0gKGtleSkgPT4ga2V5LmNoYXJDb2RlQXQoMCkgPT09IDExMSAmJiBrZXkuY2hhckNvZGVBdCgxKSA9PT0gMTEwICYmIC8vIGxvd2VyY2FzZSBsZXR0ZXJcbmtleS5jaGFyQ29kZUF0KDIpID4gOTYgJiYga2V5LmNoYXJDb2RlQXQoMikgPCAxMjM7XG5jb25zdCBwYXRjaFByb3AgPSAoZWwsIGtleSwgcHJldlZhbHVlLCBuZXh0VmFsdWUsIG5hbWVzcGFjZSwgcGFyZW50Q29tcG9uZW50KSA9PiB7XG4gIGNvbnN0IGlzU1ZHID0gbmFtZXNwYWNlID09PSBcInN2Z1wiO1xuICBpZiAoa2V5ID09PSBcImNsYXNzXCIpIHtcbiAgICBwYXRjaENsYXNzKGVsLCBuZXh0VmFsdWUsIGlzU1ZHKTtcbiAgfSBlbHNlIGlmIChrZXkgPT09IFwic3R5bGVcIikge1xuICAgIHBhdGNoU3R5bGUoZWwsIHByZXZWYWx1ZSwgbmV4dFZhbHVlKTtcbiAgfSBlbHNlIGlmIChpc09uKGtleSkpIHtcbiAgICBpZiAoIWlzTW9kZWxMaXN0ZW5lcihrZXkpKSB7XG4gICAgICBwYXRjaEV2ZW50KGVsLCBrZXksIHByZXZWYWx1ZSwgbmV4dFZhbHVlLCBwYXJlbnRDb21wb25lbnQpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChrZXlbMF0gPT09IFwiLlwiID8gKGtleSA9IGtleS5zbGljZSgxKSwgdHJ1ZSkgOiBrZXlbMF0gPT09IFwiXlwiID8gKGtleSA9IGtleS5zbGljZSgxKSwgZmFsc2UpIDogc2hvdWxkU2V0QXNQcm9wKGVsLCBrZXksIG5leHRWYWx1ZSwgaXNTVkcpKSB7XG4gICAgcGF0Y2hET01Qcm9wKGVsLCBrZXksIG5leHRWYWx1ZSk7XG4gICAgaWYgKCFlbC50YWdOYW1lLmluY2x1ZGVzKFwiLVwiKSAmJiAoa2V5ID09PSBcInZhbHVlXCIgfHwga2V5ID09PSBcImNoZWNrZWRcIiB8fCBrZXkgPT09IFwic2VsZWN0ZWRcIikpIHtcbiAgICAgIHBhdGNoQXR0cihlbCwga2V5LCBuZXh0VmFsdWUsIGlzU1ZHLCBwYXJlbnRDb21wb25lbnQsIGtleSAhPT0gXCJ2YWx1ZVwiKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoXG4gICAgLy8gIzExMDgxIGZvcmNlIHNldCBwcm9wcyBmb3IgcG9zc2libGUgYXN5bmMgY3VzdG9tIGVsZW1lbnRcbiAgICBlbC5faXNWdWVDRSAmJiAvLyAjMTI0MDggY2hlY2sgaWYgaXQncyBkZWNsYXJlZCBwcm9wIG9yIGl0J3MgYXN5bmMgY3VzdG9tIGVsZW1lbnRcbiAgICAoc2hvdWxkU2V0QXNQcm9wRm9yVnVlQ0UoZWwsIGtleSkgfHwgLy8gQHRzLWV4cGVjdC1lcnJvciBfZGVmIGlzIHByaXZhdGVcbiAgICBlbC5fZGVmLl9fYXN5bmNMb2FkZXIgJiYgKC9bQS1aXS8udGVzdChrZXkpIHx8ICFpc1N0cmluZyhuZXh0VmFsdWUpKSlcbiAgKSB7XG4gICAgcGF0Y2hET01Qcm9wKGVsLCBjYW1lbGl6ZSQxKGtleSksIG5leHRWYWx1ZSwgcGFyZW50Q29tcG9uZW50LCBrZXkpO1xuICB9IGVsc2Uge1xuICAgIGlmIChrZXkgPT09IFwidHJ1ZS12YWx1ZVwiKSB7XG4gICAgICBlbC5fdHJ1ZVZhbHVlID0gbmV4dFZhbHVlO1xuICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcImZhbHNlLXZhbHVlXCIpIHtcbiAgICAgIGVsLl9mYWxzZVZhbHVlID0gbmV4dFZhbHVlO1xuICAgIH1cbiAgICBwYXRjaEF0dHIoZWwsIGtleSwgbmV4dFZhbHVlLCBpc1NWRyk7XG4gIH1cbn07XG5mdW5jdGlvbiBzaG91bGRTZXRBc1Byb3AoZWwsIGtleSwgdmFsdWUsIGlzU1ZHKSB7XG4gIGlmIChpc1NWRykge1xuICAgIGlmIChrZXkgPT09IFwiaW5uZXJIVE1MXCIgfHwga2V5ID09PSBcInRleHRDb250ZW50XCIpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoa2V5IGluIGVsICYmIGlzTmF0aXZlT24oa2V5KSAmJiBpc0Z1bmN0aW9uKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoa2V5ID09PSBcInNwZWxsY2hlY2tcIiB8fCBrZXkgPT09IFwiZHJhZ2dhYmxlXCIgfHwga2V5ID09PSBcInRyYW5zbGF0ZVwiIHx8IGtleSA9PT0gXCJhdXRvY29ycmVjdFwiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChrZXkgPT09IFwic2FuZGJveFwiICYmIGVsLnRhZ05hbWUgPT09IFwiSUZSQU1FXCIpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGtleSA9PT0gXCJmb3JtXCIpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGtleSA9PT0gXCJsaXN0XCIgJiYgZWwudGFnTmFtZSA9PT0gXCJJTlBVVFwiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChrZXkgPT09IFwidHlwZVwiICYmIGVsLnRhZ05hbWUgPT09IFwiVEVYVEFSRUFcIikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoa2V5ID09PSBcIndpZHRoXCIgfHwga2V5ID09PSBcImhlaWdodFwiKSB7XG4gICAgY29uc3QgdGFnID0gZWwudGFnTmFtZTtcbiAgICBpZiAodGFnID09PSBcIklNR1wiIHx8IHRhZyA9PT0gXCJWSURFT1wiIHx8IHRhZyA9PT0gXCJDQU5WQVNcIiB8fCB0YWcgPT09IFwiU09VUkNFXCIpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgaWYgKGlzTmF0aXZlT24oa2V5KSAmJiBpc1N0cmluZyh2YWx1ZSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIGtleSBpbiBlbDtcbn1cbmZ1bmN0aW9uIHNob3VsZFNldEFzUHJvcEZvclZ1ZUNFKGVsLCBrZXkpIHtcbiAgY29uc3QgcHJvcHMgPSAoXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciBfZGVmIGlzIHByaXZhdGVcbiAgICBlbC5fZGVmLnByb3BzXG4gICk7XG4gIGlmICghcHJvcHMpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgY2FtZWxLZXkgPSBjYW1lbGl6ZSQxKGtleSk7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHByb3BzKSA/IHByb3BzLnNvbWUoKHByb3ApID0+IGNhbWVsaXplJDEocHJvcCkgPT09IGNhbWVsS2V5KSA6IE9iamVjdC5rZXlzKHByb3BzKS5zb21lKChwcm9wKSA9PiBjYW1lbGl6ZSQxKHByb3ApID09PSBjYW1lbEtleSk7XG59XG5cbmNvbnN0IFJFTU9WQUwgPSB7fTtcbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBkZWZpbmVDdXN0b21FbGVtZW50KG9wdGlvbnMsIGV4dHJhT3B0aW9ucywgX2NyZWF0ZUFwcCkge1xuICBsZXQgQ29tcCA9IGRlZmluZUNvbXBvbmVudChvcHRpb25zLCBleHRyYU9wdGlvbnMpO1xuICBpZiAoaXNQbGFpbk9iamVjdChDb21wKSkgQ29tcCA9IGV4dGVuZCh7fSwgQ29tcCwgZXh0cmFPcHRpb25zKTtcbiAgY2xhc3MgVnVlQ3VzdG9tRWxlbWVudCBleHRlbmRzIFZ1ZUVsZW1lbnQge1xuICAgIGNvbnN0cnVjdG9yKGluaXRpYWxQcm9wcykge1xuICAgICAgc3VwZXIoQ29tcCwgaW5pdGlhbFByb3BzLCBfY3JlYXRlQXBwKTtcbiAgICB9XG4gIH1cbiAgVnVlQ3VzdG9tRWxlbWVudC5kZWYgPSBDb21wO1xuICByZXR1cm4gVnVlQ3VzdG9tRWxlbWVudDtcbn1cbmNvbnN0IGRlZmluZVNTUkN1c3RvbUVsZW1lbnQgPSAoLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi8gKG9wdGlvbnMsIGV4dHJhT3B0aW9ucykgPT4ge1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGRlZmluZUN1c3RvbUVsZW1lbnQob3B0aW9ucywgZXh0cmFPcHRpb25zLCBjcmVhdGVTU1JBcHApO1xufSk7XG5jb25zdCBCYXNlQ2xhc3MgPSB0eXBlb2YgSFRNTEVsZW1lbnQgIT09IFwidW5kZWZpbmVkXCIgPyBIVE1MRWxlbWVudCA6IGNsYXNzIHtcbn07XG5jbGFzcyBWdWVFbGVtZW50IGV4dGVuZHMgQmFzZUNsYXNzIHtcbiAgY29uc3RydWN0b3IoX2RlZiwgX3Byb3BzID0ge30sIF9jcmVhdGVBcHAgPSBjcmVhdGVBcHApIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2RlZiA9IF9kZWY7XG4gICAgdGhpcy5fcHJvcHMgPSBfcHJvcHM7XG4gICAgdGhpcy5fY3JlYXRlQXBwID0gX2NyZWF0ZUFwcDtcbiAgICB0aGlzLl9pc1Z1ZUNFID0gdHJ1ZTtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9pbnN0YW5jZSA9IG51bGw7XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fYXBwID0gbnVsbDtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9ub25jZSA9IHRoaXMuX2RlZi5ub25jZTtcbiAgICB0aGlzLl9jb25uZWN0ZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9yZXNvbHZlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3BhdGNoaW5nID0gZmFsc2U7XG4gICAgdGhpcy5fZGlydHkgPSBmYWxzZTtcbiAgICB0aGlzLl9udW1iZXJQcm9wcyA9IG51bGw7XG4gICAgdGhpcy5fc3R5bGVDaGlsZHJlbiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha1NldCgpO1xuICAgIHRoaXMuX3N0eWxlQW5jaG9ycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICAgIHRoaXMuX29iID0gbnVsbDtcbiAgICBpZiAodGhpcy5zaGFkb3dSb290ICYmIF9jcmVhdGVBcHAgIT09IGNyZWF0ZUFwcCkge1xuICAgICAgdGhpcy5fcm9vdCA9IHRoaXMuc2hhZG93Um9vdDtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdGhpcy5zaGFkb3dSb290KSB7XG4gICAgICAgIHdhcm4oXG4gICAgICAgICAgYEN1c3RvbSBlbGVtZW50IGhhcyBwcmUtcmVuZGVyZWQgZGVjbGFyYXRpdmUgc2hhZG93IHJvb3QgYnV0IGlzIG5vdCBkZWZpbmVkIGFzIGh5ZHJhdGFibGUuIFVzZSBcXGBkZWZpbmVTU1JDdXN0b21FbGVtZW50XFxgLmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChfZGVmLnNoYWRvd1Jvb3QgIT09IGZhbHNlKSB7XG4gICAgICAgIHRoaXMuYXR0YWNoU2hhZG93KFxuICAgICAgICAgIGV4dGVuZCh7fSwgX2RlZi5zaGFkb3dSb290T3B0aW9ucywge1xuICAgICAgICAgICAgbW9kZTogXCJvcGVuXCJcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgICB0aGlzLl9yb290ID0gdGhpcy5zaGFkb3dSb290O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fcm9vdCA9IHRoaXM7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge1xuICAgIGlmICghdGhpcy5pc0Nvbm5lY3RlZCkgcmV0dXJuO1xuICAgIGlmICghdGhpcy5zaGFkb3dSb290ICYmICF0aGlzLl9yZXNvbHZlZCkge1xuICAgICAgdGhpcy5fcGFyc2VTbG90cygpO1xuICAgIH1cbiAgICB0aGlzLl9jb25uZWN0ZWQgPSB0cnVlO1xuICAgIGxldCBwYXJlbnQgPSB0aGlzO1xuICAgIHdoaWxlIChwYXJlbnQgPSBwYXJlbnQgJiYgLy8gIzEyNDc5IHNob3VsZCBjaGVjayBhc3NpZ25lZFNsb3QgZmlyc3QgdG8gZ2V0IGNvcnJlY3QgcGFyZW50XG4gICAgKHBhcmVudC5hc3NpZ25lZFNsb3QgfHwgcGFyZW50LnBhcmVudE5vZGUgfHwgcGFyZW50Lmhvc3QpKSB7XG4gICAgICBpZiAocGFyZW50IGluc3RhbmNlb2YgVnVlRWxlbWVudCkge1xuICAgICAgICB0aGlzLl9wYXJlbnQgPSBwYXJlbnQ7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXRoaXMuX2luc3RhbmNlKSB7XG4gICAgICBpZiAodGhpcy5fcmVzb2x2ZWQpIHtcbiAgICAgICAgdGhpcy5fbW91bnQodGhpcy5fZGVmKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChwYXJlbnQgJiYgcGFyZW50Ll9wZW5kaW5nUmVzb2x2ZSkge1xuICAgICAgICAgIHRoaXMuX3BlbmRpbmdSZXNvbHZlID0gcGFyZW50Ll9wZW5kaW5nUmVzb2x2ZS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuX3BlbmRpbmdSZXNvbHZlID0gdm9pZCAwO1xuICAgICAgICAgICAgaWYgKHRoaXMuaXNDb25uZWN0ZWQpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3Jlc29sdmVEZWYoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLl9yZXNvbHZlRGVmKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgX3NldFBhcmVudChwYXJlbnQgPSB0aGlzLl9wYXJlbnQpIHtcbiAgICBpZiAocGFyZW50KSB7XG4gICAgICB0aGlzLl9pbnN0YW5jZS5wYXJlbnQgPSBwYXJlbnQuX2luc3RhbmNlO1xuICAgICAgdGhpcy5faW5oZXJpdFBhcmVudENvbnRleHQocGFyZW50KTtcbiAgICB9XG4gIH1cbiAgX2luaGVyaXRQYXJlbnRDb250ZXh0KHBhcmVudCA9IHRoaXMuX3BhcmVudCkge1xuICAgIGlmIChwYXJlbnQgJiYgdGhpcy5fYXBwKSB7XG4gICAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YoXG4gICAgICAgIHRoaXMuX2FwcC5fY29udGV4dC5wcm92aWRlcyxcbiAgICAgICAgcGFyZW50Ll9pbnN0YW5jZS5wcm92aWRlc1xuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgdGhpcy5fY29ubmVjdGVkID0gZmFsc2U7XG4gICAgbmV4dFRpY2soKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgICAgaWYgKHRoaXMuX29iKSB7XG4gICAgICAgICAgdGhpcy5fb2IuZGlzY29ubmVjdCgpO1xuICAgICAgICAgIHRoaXMuX29iID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9hcHAgJiYgdGhpcy5fYXBwLnVubW91bnQoKTtcbiAgICAgICAgaWYgKHRoaXMuX2luc3RhbmNlKSB0aGlzLl9pbnN0YW5jZS5jZSA9IHZvaWQgMDtcbiAgICAgICAgdGhpcy5fYXBwID0gdGhpcy5faW5zdGFuY2UgPSBudWxsO1xuICAgICAgICBpZiAodGhpcy5fdGVsZXBvcnRUYXJnZXRzKSB7XG4gICAgICAgICAgdGhpcy5fdGVsZXBvcnRUYXJnZXRzLmNsZWFyKCk7XG4gICAgICAgICAgdGhpcy5fdGVsZXBvcnRUYXJnZXRzID0gdm9pZCAwO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgX3Byb2Nlc3NNdXRhdGlvbnMobXV0YXRpb25zKSB7XG4gICAgZm9yIChjb25zdCBtIG9mIG11dGF0aW9ucykge1xuICAgICAgdGhpcy5fc2V0QXR0cihtLmF0dHJpYnV0ZU5hbWUpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogcmVzb2x2ZSBpbm5lciBjb21wb25lbnQgZGVmaW5pdGlvbiAoaGFuZGxlIHBvc3NpYmxlIGFzeW5jIGNvbXBvbmVudClcbiAgICovXG4gIF9yZXNvbHZlRGVmKCkge1xuICAgIGlmICh0aGlzLl9wZW5kaW5nUmVzb2x2ZSkge1xuICAgICAgcmV0dXJuIHRoaXMuX3BlbmRpbmdSZXNvbHZlO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuYXR0cmlidXRlcy5sZW5ndGg7IGkrKykge1xuICAgICAgdGhpcy5fc2V0QXR0cih0aGlzLmF0dHJpYnV0ZXNbaV0ubmFtZSk7XG4gICAgfVxuICAgIHRoaXMuX29iID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIodGhpcy5fcHJvY2Vzc011dGF0aW9ucy5iaW5kKHRoaXMpKTtcbiAgICB0aGlzLl9vYi5vYnNlcnZlKHRoaXMsIHsgYXR0cmlidXRlczogdHJ1ZSB9KTtcbiAgICBjb25zdCByZXNvbHZlID0gKGRlZiwgaXNBc3luYyA9IGZhbHNlKSA9PiB7XG4gICAgICB0aGlzLl9yZXNvbHZlZCA9IHRydWU7XG4gICAgICB0aGlzLl9wZW5kaW5nUmVzb2x2ZSA9IHZvaWQgMDtcbiAgICAgIGNvbnN0IHsgcHJvcHMsIHN0eWxlcyB9ID0gZGVmO1xuICAgICAgbGV0IG51bWJlclByb3BzO1xuICAgICAgaWYgKHByb3BzICYmICFpc0FycmF5KHByb3BzKSkge1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBwcm9wcykge1xuICAgICAgICAgIGNvbnN0IG9wdCA9IHByb3BzW2tleV07XG4gICAgICAgICAgaWYgKG9wdCA9PT0gTnVtYmVyIHx8IG9wdCAmJiBvcHQudHlwZSA9PT0gTnVtYmVyKSB7XG4gICAgICAgICAgICBpZiAoa2V5IGluIHRoaXMuX3Byb3BzKSB7XG4gICAgICAgICAgICAgIHRoaXMuX3Byb3BzW2tleV0gPSB0b051bWJlcih0aGlzLl9wcm9wc1trZXldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIChudW1iZXJQcm9wcyB8fCAobnVtYmVyUHJvcHMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKSkpW2NhbWVsaXplJDEoa2V5KV0gPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5fbnVtYmVyUHJvcHMgPSBudW1iZXJQcm9wcztcbiAgICAgIHRoaXMuX3Jlc29sdmVQcm9wcyhkZWYpO1xuICAgICAgaWYgKHRoaXMuc2hhZG93Um9vdCkge1xuICAgICAgICB0aGlzLl9hcHBseVN0eWxlcyhzdHlsZXMpO1xuICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHN0eWxlcykge1xuICAgICAgICB3YXJuKFxuICAgICAgICAgIFwiQ3VzdG9tIGVsZW1lbnQgc3R5bGUgaW5qZWN0aW9uIGlzIG5vdCBzdXBwb3J0ZWQgd2hlbiB1c2luZyBzaGFkb3dSb290OiBmYWxzZVwiXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICB0aGlzLl9tb3VudChkZWYpO1xuICAgIH07XG4gICAgY29uc3QgYXN5bmNEZWYgPSB0aGlzLl9kZWYuX19hc3luY0xvYWRlcjtcbiAgICBpZiAoYXN5bmNEZWYpIHtcbiAgICAgIHRoaXMuX3BlbmRpbmdSZXNvbHZlID0gYXN5bmNEZWYoKS50aGVuKChkZWYpID0+IHtcbiAgICAgICAgZGVmLmNvbmZpZ3VyZUFwcCA9IHRoaXMuX2RlZi5jb25maWd1cmVBcHA7XG4gICAgICAgIHJlc29sdmUodGhpcy5fZGVmID0gZGVmLCB0cnVlKTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHRoaXMuX3BlbmRpbmdSZXNvbHZlO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXNvbHZlKHRoaXMuX2RlZik7XG4gICAgfVxuICB9XG4gIF9tb3VudChkZWYpIHtcbiAgICBpZiAoKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSAmJiAhZGVmLm5hbWUpIHtcbiAgICAgIGRlZi5uYW1lID0gXCJWdWVFbGVtZW50XCI7XG4gICAgfVxuICAgIHRoaXMuX2FwcCA9IHRoaXMuX2NyZWF0ZUFwcChkZWYpO1xuICAgIHRoaXMuX2luaGVyaXRQYXJlbnRDb250ZXh0KCk7XG4gICAgaWYgKGRlZi5jb25maWd1cmVBcHApIHtcbiAgICAgIGRlZi5jb25maWd1cmVBcHAodGhpcy5fYXBwKTtcbiAgICB9XG4gICAgdGhpcy5fYXBwLl9jZVZOb2RlID0gdGhpcy5fY3JlYXRlVk5vZGUoKTtcbiAgICB0aGlzLl9hcHAubW91bnQodGhpcy5fcm9vdCk7XG4gICAgY29uc3QgZXhwb3NlZCA9IHRoaXMuX2luc3RhbmNlICYmIHRoaXMuX2luc3RhbmNlLmV4cG9zZWQ7XG4gICAgaWYgKCFleHBvc2VkKSByZXR1cm47XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZXhwb3NlZCkge1xuICAgICAgaWYgKCFoYXNPd24odGhpcywga2V5KSkge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywga2V5LCB7XG4gICAgICAgICAgLy8gdW53cmFwIHJlZiB0byBiZSBjb25zaXN0ZW50IHdpdGggcHVibGljIGluc3RhbmNlIGJlaGF2aW9yXG4gICAgICAgICAgZ2V0OiAoKSA9PiB1bnJlZihleHBvc2VkW2tleV0pXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIHdhcm4oYEV4cG9zZWQgcHJvcGVydHkgXCIke2tleX1cIiBhbHJlYWR5IGV4aXN0cyBvbiBjdXN0b20gZWxlbWVudC5gKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgX3Jlc29sdmVQcm9wcyhkZWYpIHtcbiAgICBjb25zdCB7IHByb3BzIH0gPSBkZWY7XG4gICAgY29uc3QgZGVjbGFyZWRQcm9wS2V5cyA9IGlzQXJyYXkocHJvcHMpID8gcHJvcHMgOiBPYmplY3Qua2V5cyhwcm9wcyB8fCB7fSk7XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXModGhpcykpIHtcbiAgICAgIGlmIChrZXlbMF0gIT09IFwiX1wiICYmIGRlY2xhcmVkUHJvcEtleXMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgICB0aGlzLl9zZXRQcm9wKGtleSwgdGhpc1trZXldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgb2YgZGVjbGFyZWRQcm9wS2V5cy5tYXAoY2FtZWxpemUkMSkpIHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGtleSBpbiBPYmplY3QuZ2V0UHJvdG90eXBlT2YodGhpcykpIHtcbiAgICAgICAgd2FybihcbiAgICAgICAgICBgQ3VzdG9tIGVsZW1lbnQgcHJvcCBcIiR7a2V5fVwiIGNvbmZsaWN0cyB3aXRoIGFuIGV4aXN0aW5nIHByb3BlcnR5IG9uIHRoZSBlbGVtZW50IGFuZCB3aWxsIG92ZXJ3cml0ZSBpdC5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywga2V5LCB7XG4gICAgICAgIGdldCgpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0UHJvcChrZXkpO1xuICAgICAgICB9LFxuICAgICAgICBzZXQodmFsKSB7XG4gICAgICAgICAgdGhpcy5fc2V0UHJvcChrZXksIHZhbCwgdHJ1ZSwgIXRoaXMuX3BhdGNoaW5nKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIF9zZXRBdHRyKGtleSkge1xuICAgIGlmIChrZXkuc3RhcnRzV2l0aChcImRhdGEtdi1cIikpIHJldHVybjtcbiAgICBjb25zdCBoYXMgPSB0aGlzLmhhc0F0dHJpYnV0ZShrZXkpO1xuICAgIGxldCB2YWx1ZSA9IGhhcyA/IHRoaXMuZ2V0QXR0cmlidXRlKGtleSkgOiBSRU1PVkFMO1xuICAgIGNvbnN0IGNhbWVsS2V5ID0gY2FtZWxpemUkMShrZXkpO1xuICAgIGlmIChoYXMgJiYgdGhpcy5fbnVtYmVyUHJvcHMgJiYgdGhpcy5fbnVtYmVyUHJvcHNbY2FtZWxLZXldKSB7XG4gICAgICB2YWx1ZSA9IHRvTnVtYmVyKHZhbHVlKTtcbiAgICB9XG4gICAgdGhpcy5fc2V0UHJvcChjYW1lbEtleSwgdmFsdWUsIGZhbHNlLCB0cnVlKTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfZ2V0UHJvcChrZXkpIHtcbiAgICByZXR1cm4gdGhpcy5fcHJvcHNba2V5XTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfc2V0UHJvcChrZXksIHZhbCwgc2hvdWxkUmVmbGVjdCA9IHRydWUsIHNob3VsZFVwZGF0ZSA9IGZhbHNlKSB7XG4gICAgaWYgKHZhbCAhPT0gdGhpcy5fcHJvcHNba2V5XSkge1xuICAgICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgICAgaWYgKHZhbCA9PT0gUkVNT1ZBTCkge1xuICAgICAgICBkZWxldGUgdGhpcy5fcHJvcHNba2V5XTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3Byb3BzW2tleV0gPSB2YWw7XG4gICAgICAgIGlmIChrZXkgPT09IFwia2V5XCIgJiYgdGhpcy5fYXBwKSB7XG4gICAgICAgICAgdGhpcy5fYXBwLl9jZVZOb2RlLmtleSA9IHZhbDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHNob3VsZFVwZGF0ZSAmJiB0aGlzLl9pbnN0YW5jZSkge1xuICAgICAgICB0aGlzLl91cGRhdGUoKTtcbiAgICAgIH1cbiAgICAgIGlmIChzaG91bGRSZWZsZWN0KSB7XG4gICAgICAgIGNvbnN0IG9iID0gdGhpcy5fb2I7XG4gICAgICAgIGlmIChvYikge1xuICAgICAgICAgIHRoaXMuX3Byb2Nlc3NNdXRhdGlvbnMob2IudGFrZVJlY29yZHMoKSk7XG4gICAgICAgICAgb2IuZGlzY29ubmVjdCgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWwgPT09IHRydWUpIHtcbiAgICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZShoeXBoZW5hdGUoa2V5KSwgXCJcIik7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgdmFsID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgdGhpcy5zZXRBdHRyaWJ1dGUoaHlwaGVuYXRlKGtleSksIHZhbCArIFwiXCIpO1xuICAgICAgICB9IGVsc2UgaWYgKCF2YWwpIHtcbiAgICAgICAgICB0aGlzLnJlbW92ZUF0dHJpYnV0ZShoeXBoZW5hdGUoa2V5KSk7XG4gICAgICAgIH1cbiAgICAgICAgb2IgJiYgb2Iub2JzZXJ2ZSh0aGlzLCB7IGF0dHJpYnV0ZXM6IHRydWUgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF91cGRhdGUoKSB7XG4gICAgY29uc3Qgdm5vZGUgPSB0aGlzLl9jcmVhdGVWTm9kZSgpO1xuICAgIGlmICh0aGlzLl9hcHApIHZub2RlLmFwcENvbnRleHQgPSB0aGlzLl9hcHAuX2NvbnRleHQ7XG4gICAgcmVuZGVyKHZub2RlLCB0aGlzLl9yb290KTtcbiAgfVxuICBfY3JlYXRlVk5vZGUoKSB7XG4gICAgY29uc3QgYmFzZVByb3BzID0ge307XG4gICAgaWYgKCF0aGlzLnNoYWRvd1Jvb3QpIHtcbiAgICAgIGJhc2VQcm9wcy5vblZub2RlTW91bnRlZCA9IGJhc2VQcm9wcy5vblZub2RlVXBkYXRlZCA9IHRoaXMuX3JlbmRlclNsb3RzLmJpbmQodGhpcyk7XG4gICAgfVxuICAgIGNvbnN0IHZub2RlID0gY3JlYXRlVk5vZGUodGhpcy5fZGVmLCBleHRlbmQoYmFzZVByb3BzLCB0aGlzLl9wcm9wcykpO1xuICAgIGlmICghdGhpcy5faW5zdGFuY2UpIHtcbiAgICAgIHZub2RlLmNlID0gKGluc3RhbmNlKSA9PiB7XG4gICAgICAgIHRoaXMuX2luc3RhbmNlID0gaW5zdGFuY2U7XG4gICAgICAgIGluc3RhbmNlLmNlID0gdGhpcztcbiAgICAgICAgaW5zdGFuY2UuaXNDRSA9IHRydWU7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgaW5zdGFuY2UuY2VSZWxvYWQgPSAobmV3U3R5bGVzKSA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5fc3R5bGVzKSB7XG4gICAgICAgICAgICAgIHRoaXMuX3N0eWxlcy5mb3JFYWNoKChzKSA9PiB0aGlzLl9yb290LnJlbW92ZUNoaWxkKHMpKTtcbiAgICAgICAgICAgICAgdGhpcy5fc3R5bGVzLmxlbmd0aCA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9zdHlsZUFuY2hvcnMuZGVsZXRlKHRoaXMuX2RlZik7XG4gICAgICAgICAgICB0aGlzLl9hcHBseVN0eWxlcyhuZXdTdHlsZXMpO1xuICAgICAgICAgICAgdGhpcy5faW5zdGFuY2UgPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5fdXBkYXRlKCk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkaXNwYXRjaCA9IChldmVudCwgYXJncykgPT4ge1xuICAgICAgICAgIHRoaXMuZGlzcGF0Y2hFdmVudChcbiAgICAgICAgICAgIG5ldyBDdXN0b21FdmVudChcbiAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgIGlzUGxhaW5PYmplY3QoYXJnc1swXSkgPyBleHRlbmQoeyBkZXRhaWw6IGFyZ3MgfSwgYXJnc1swXSkgOiB7IGRldGFpbDogYXJncyB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgfTtcbiAgICAgICAgaW5zdGFuY2UuZW1pdCA9IChldmVudCwgLi4uYXJncykgPT4ge1xuICAgICAgICAgIGRpc3BhdGNoKGV2ZW50LCBhcmdzKTtcbiAgICAgICAgICBpZiAoaHlwaGVuYXRlKGV2ZW50KSAhPT0gZXZlbnQpIHtcbiAgICAgICAgICAgIGRpc3BhdGNoKGh5cGhlbmF0ZShldmVudCksIGFyZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5fc2V0UGFyZW50KCk7XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdm5vZGU7XG4gIH1cbiAgX2FwcGx5U3R5bGVzKHN0eWxlcywgb3duZXIsIHBhcmVudENvbXApIHtcbiAgICBpZiAoIXN0eWxlcykgcmV0dXJuO1xuICAgIGlmIChvd25lcikge1xuICAgICAgaWYgKG93bmVyID09PSB0aGlzLl9kZWYgfHwgdGhpcy5fc3R5bGVDaGlsZHJlbi5oYXMob3duZXIpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRoaXMuX3N0eWxlQ2hpbGRyZW4uYWRkKG93bmVyKTtcbiAgICB9XG4gICAgY29uc3Qgbm9uY2UgPSB0aGlzLl9ub25jZTtcbiAgICBjb25zdCByb290ID0gdGhpcy5zaGFkb3dSb290O1xuICAgIGNvbnN0IGluc2VydGlvbkFuY2hvciA9IHBhcmVudENvbXAgPyB0aGlzLl9nZXRTdHlsZUFuY2hvcihwYXJlbnRDb21wKSB8fCB0aGlzLl9nZXRTdHlsZUFuY2hvcih0aGlzLl9kZWYpIDogdGhpcy5fZ2V0Um9vdFN0eWxlSW5zZXJ0aW9uQW5jaG9yKHJvb3QpO1xuICAgIGxldCBsYXN0ID0gbnVsbDtcbiAgICBmb3IgKGxldCBpID0gc3R5bGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBjb25zdCBzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIpO1xuICAgICAgaWYgKG5vbmNlKSBzLnNldEF0dHJpYnV0ZShcIm5vbmNlXCIsIG5vbmNlKTtcbiAgICAgIHMudGV4dENvbnRlbnQgPSBzdHlsZXNbaV07XG4gICAgICByb290Lmluc2VydEJlZm9yZShzLCBsYXN0IHx8IGluc2VydGlvbkFuY2hvcik7XG4gICAgICBsYXN0ID0gcztcbiAgICAgIGlmIChpID09PSAwKSB7XG4gICAgICAgIGlmICghcGFyZW50Q29tcCkgdGhpcy5fc3R5bGVBbmNob3JzLnNldCh0aGlzLl9kZWYsIHMpO1xuICAgICAgICBpZiAob3duZXIpIHRoaXMuX3N0eWxlQW5jaG9ycy5zZXQob3duZXIsIHMpO1xuICAgICAgfVxuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgaWYgKG93bmVyKSB7XG4gICAgICAgICAgaWYgKG93bmVyLl9faG1ySWQpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5fY2hpbGRTdHlsZXMpIHRoaXMuX2NoaWxkU3R5bGVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICAgICAgICAgIGxldCBlbnRyeSA9IHRoaXMuX2NoaWxkU3R5bGVzLmdldChvd25lci5fX2htcklkKTtcbiAgICAgICAgICAgIGlmICghZW50cnkpIHtcbiAgICAgICAgICAgICAgdGhpcy5fY2hpbGRTdHlsZXMuc2V0KG93bmVyLl9faG1ySWQsIGVudHJ5ID0gW10pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZW50cnkucHVzaChzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgKHRoaXMuX3N0eWxlcyB8fCAodGhpcy5fc3R5bGVzID0gW10pKS5wdXNoKHMpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF9nZXRTdHlsZUFuY2hvcihjb21wKSB7XG4gICAgaWYgKCFjb21wKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgYW5jaG9yID0gdGhpcy5fc3R5bGVBbmNob3JzLmdldChjb21wKTtcbiAgICBpZiAoYW5jaG9yICYmIGFuY2hvci5wYXJlbnROb2RlID09PSB0aGlzLnNoYWRvd1Jvb3QpIHtcbiAgICAgIHJldHVybiBhbmNob3I7XG4gICAgfVxuICAgIGlmIChhbmNob3IpIHtcbiAgICAgIHRoaXMuX3N0eWxlQW5jaG9ycy5kZWxldGUoY29tcCk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIF9nZXRSb290U3R5bGVJbnNlcnRpb25BbmNob3Iocm9vdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcm9vdC5jaGlsZE5vZGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBub2RlID0gcm9vdC5jaGlsZE5vZGVzW2ldO1xuICAgICAgaWYgKCEobm9kZSBpbnN0YW5jZW9mIEhUTUxTdHlsZUVsZW1lbnQpKSB7XG4gICAgICAgIHJldHVybiBub2RlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICAvKipcbiAgICogT25seSBjYWxsZWQgd2hlbiBzaGFkb3dSb290IGlzIGZhbHNlXG4gICAqL1xuICBfcGFyc2VTbG90cygpIHtcbiAgICBjb25zdCBzbG90cyA9IHRoaXMuX3Nsb3RzID0ge307XG4gICAgbGV0IG47XG4gICAgd2hpbGUgKG4gPSB0aGlzLmZpcnN0Q2hpbGQpIHtcbiAgICAgIGNvbnN0IHNsb3ROYW1lID0gbi5ub2RlVHlwZSA9PT0gMSAmJiBuLmdldEF0dHJpYnV0ZShcInNsb3RcIikgfHwgXCJkZWZhdWx0XCI7XG4gICAgICAoc2xvdHNbc2xvdE5hbWVdIHx8IChzbG90c1tzbG90TmFtZV0gPSBbXSkpLnB1c2gobik7XG4gICAgICB0aGlzLnJlbW92ZUNoaWxkKG4pO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogT25seSBjYWxsZWQgd2hlbiBzaGFkb3dSb290IGlzIGZhbHNlXG4gICAqL1xuICBfcmVuZGVyU2xvdHMoKSB7XG4gICAgY29uc3Qgb3V0bGV0cyA9IHRoaXMuX2dldFNsb3RzKCk7XG4gICAgY29uc3Qgc2NvcGVJZCA9IHRoaXMuX2luc3RhbmNlLnR5cGUuX19zY29wZUlkO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3V0bGV0cy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgbyA9IG91dGxldHNbaV07XG4gICAgICBjb25zdCBzbG90TmFtZSA9IG8uZ2V0QXR0cmlidXRlKFwibmFtZVwiKSB8fCBcImRlZmF1bHRcIjtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSB0aGlzLl9zbG90c1tzbG90TmFtZV07XG4gICAgICBjb25zdCBwYXJlbnQgPSBvLnBhcmVudE5vZGU7XG4gICAgICBpZiAoY29udGVudCkge1xuICAgICAgICBmb3IgKGNvbnN0IG4gb2YgY29udGVudCkge1xuICAgICAgICAgIGlmIChzY29wZUlkICYmIG4ubm9kZVR5cGUgPT09IDEpIHtcbiAgICAgICAgICAgIGNvbnN0IGlkID0gc2NvcGVJZCArIFwiLXNcIjtcbiAgICAgICAgICAgIGNvbnN0IHdhbGtlciA9IGRvY3VtZW50LmNyZWF0ZVRyZWVXYWxrZXIobiwgMSk7XG4gICAgICAgICAgICBuLnNldEF0dHJpYnV0ZShpZCwgXCJcIik7XG4gICAgICAgICAgICBsZXQgY2hpbGQ7XG4gICAgICAgICAgICB3aGlsZSAoY2hpbGQgPSB3YWxrZXIubmV4dE5vZGUoKSkge1xuICAgICAgICAgICAgICBjaGlsZC5zZXRBdHRyaWJ1dGUoaWQsIFwiXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKG4sIG8pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB3aGlsZSAoby5maXJzdENoaWxkKSBwYXJlbnQuaW5zZXJ0QmVmb3JlKG8uZmlyc3RDaGlsZCwgbyk7XG4gICAgICB9XG4gICAgICBwYXJlbnQucmVtb3ZlQ2hpbGQobyk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIF9nZXRTbG90cygpIHtcbiAgICBjb25zdCByb290cyA9IFt0aGlzXTtcbiAgICBpZiAodGhpcy5fdGVsZXBvcnRUYXJnZXRzKSB7XG4gICAgICByb290cy5wdXNoKC4uLnRoaXMuX3RlbGVwb3J0VGFyZ2V0cyk7XG4gICAgfVxuICAgIGNvbnN0IHNsb3RzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgICBmb3IgKGNvbnN0IHJvb3Qgb2Ygcm9vdHMpIHtcbiAgICAgIGNvbnN0IGZvdW5kID0gcm9vdC5xdWVyeVNlbGVjdG9yQWxsKFwic2xvdFwiKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm91bmQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgc2xvdHMuYWRkKGZvdW5kW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIEFycmF5LmZyb20oc2xvdHMpO1xuICB9XG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIF9pbmplY3RDaGlsZFN0eWxlKGNvbXAsIHBhcmVudENvbXApIHtcbiAgICB0aGlzLl9hcHBseVN0eWxlcyhjb21wLnN0eWxlcywgY29tcCwgcGFyZW50Q29tcCk7XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX2JlZ2luUGF0Y2goKSB7XG4gICAgdGhpcy5fcGF0Y2hpbmcgPSB0cnVlO1xuICAgIHRoaXMuX2RpcnR5ID0gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX2VuZFBhdGNoKCkge1xuICAgIHRoaXMuX3BhdGNoaW5nID0gZmFsc2U7XG4gICAgaWYgKHRoaXMuX2RpcnR5ICYmIHRoaXMuX2luc3RhbmNlKSB7XG4gICAgICB0aGlzLl91cGRhdGUoKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX2hhc1NoYWRvd1Jvb3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RlZi5zaGFkb3dSb290ICE9PSBmYWxzZTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfcmVtb3ZlQ2hpbGRTdHlsZShjb21wKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHRoaXMuX3N0eWxlQ2hpbGRyZW4uZGVsZXRlKGNvbXApO1xuICAgICAgdGhpcy5fc3R5bGVBbmNob3JzLmRlbGV0ZShjb21wKTtcbiAgICAgIGlmICh0aGlzLl9jaGlsZFN0eWxlcyAmJiBjb21wLl9faG1ySWQpIHtcbiAgICAgICAgY29uc3Qgb2xkU3R5bGVzID0gdGhpcy5fY2hpbGRTdHlsZXMuZ2V0KGNvbXAuX19obXJJZCk7XG4gICAgICAgIGlmIChvbGRTdHlsZXMpIHtcbiAgICAgICAgICBvbGRTdHlsZXMuZm9yRWFjaCgocykgPT4gdGhpcy5fcm9vdC5yZW1vdmVDaGlsZChzKSk7XG4gICAgICAgICAgb2xkU3R5bGVzLmxlbmd0aCA9IDA7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHVzZUhvc3QoY2FsbGVyKSB7XG4gIGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGNvbnN0IGVsID0gaW5zdGFuY2UgJiYgaW5zdGFuY2UuY2U7XG4gIGlmIChlbCkge1xuICAgIHJldHVybiBlbDtcbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgaWYgKCFpbnN0YW5jZSkge1xuICAgICAgd2FybihcbiAgICAgICAgYCR7Y2FsbGVyIHx8IFwidXNlSG9zdFwifSBjYWxsZWQgd2l0aG91dCBhbiBhY3RpdmUgY29tcG9uZW50IGluc3RhbmNlLmBcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHdhcm4oXG4gICAgICAgIGAke2NhbGxlciB8fCBcInVzZUhvc3RcIn0gY2FuIG9ubHkgYmUgdXNlZCBpbiBjb21wb25lbnRzIGRlZmluZWQgdmlhIGRlZmluZUN1c3RvbUVsZW1lbnQuYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiB1c2VTaGFkb3dSb290KCkge1xuICBjb25zdCBlbCA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyB1c2VIb3N0KFwidXNlU2hhZG93Um9vdFwiKSA6IHVzZUhvc3QoKTtcbiAgcmV0dXJuIGVsICYmIGVsLnNoYWRvd1Jvb3Q7XG59XG5cbmZ1bmN0aW9uIHVzZUNzc01vZHVsZShuYW1lID0gXCIkc3R5bGVcIikge1xuICB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICBpZiAoIWluc3RhbmNlKSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4oYHVzZUNzc01vZHVsZSBtdXN0IGJlIGNhbGxlZCBpbnNpZGUgc2V0dXAoKWApO1xuICAgICAgcmV0dXJuIEVNUFRZX09CSjtcbiAgICB9XG4gICAgY29uc3QgbW9kdWxlcyA9IGluc3RhbmNlLnR5cGUuX19jc3NNb2R1bGVzO1xuICAgIGlmICghbW9kdWxlcykge1xuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuKGBDdXJyZW50IGluc3RhbmNlIGRvZXMgbm90IGhhdmUgQ1NTIG1vZHVsZXMgaW5qZWN0ZWQuYCk7XG4gICAgICByZXR1cm4gRU1QVFlfT0JKO1xuICAgIH1cbiAgICBjb25zdCBtb2QgPSBtb2R1bGVzW25hbWVdO1xuICAgIGlmICghbW9kKSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4oYEN1cnJlbnQgaW5zdGFuY2UgZG9lcyBub3QgaGF2ZSBDU1MgbW9kdWxlIG5hbWVkIFwiJHtuYW1lfVwiLmApO1xuICAgICAgcmV0dXJuIEVNUFRZX09CSjtcbiAgICB9XG4gICAgcmV0dXJuIG1vZDtcbiAgfVxufVxuXG5jb25zdCBwb3NpdGlvbk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuY29uc3QgbmV3UG9zaXRpb25NYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IG1vdmVDYktleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfbW92ZUNiXCIpO1xuY29uc3QgZW50ZXJDYktleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfZW50ZXJDYlwiKTtcbmNvbnN0IGRlY29yYXRlID0gKHQpID0+IHtcbiAgZGVsZXRlIHQucHJvcHMubW9kZTtcbiAgcmV0dXJuIHQ7XG59O1xuY29uc3QgVHJhbnNpdGlvbkdyb3VwSW1wbCA9IC8qIEBfX1BVUkVfXyAqLyBkZWNvcmF0ZSh7XG4gIG5hbWU6IFwiVHJhbnNpdGlvbkdyb3VwXCIsXG4gIHByb3BzOiAvKiBAX19QVVJFX18gKi8gZXh0ZW5kKHt9LCBUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzLCB7XG4gICAgdGFnOiBTdHJpbmcsXG4gICAgbW92ZUNsYXNzOiBTdHJpbmdcbiAgfSksXG4gIHNldHVwKHByb3BzLCB7IHNsb3RzIH0pIHtcbiAgICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIGNvbnN0IHN0YXRlID0gdXNlVHJhbnNpdGlvblN0YXRlKCk7XG4gICAgbGV0IHByZXZDaGlsZHJlbjtcbiAgICBsZXQgY2hpbGRyZW47XG4gICAgb25VcGRhdGVkKCgpID0+IHtcbiAgICAgIGlmICghcHJldkNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBtb3ZlQ2xhc3MgPSBwcm9wcy5tb3ZlQ2xhc3MgfHwgYCR7cHJvcHMubmFtZSB8fCBcInZcIn0tbW92ZWA7XG4gICAgICBpZiAoIWhhc0NTU1RyYW5zZm9ybShcbiAgICAgICAgcHJldkNoaWxkcmVuWzBdLmVsLFxuICAgICAgICBpbnN0YW5jZS52bm9kZS5lbCxcbiAgICAgICAgbW92ZUNsYXNzXG4gICAgICApKSB7XG4gICAgICAgIHByZXZDaGlsZHJlbiA9IFtdO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBwcmV2Q2hpbGRyZW4uZm9yRWFjaChjYWxsUGVuZGluZ0Nicyk7XG4gICAgICBwcmV2Q2hpbGRyZW4uZm9yRWFjaChyZWNvcmRQb3NpdGlvbik7XG4gICAgICBjb25zdCBtb3ZlZENoaWxkcmVuID0gcHJldkNoaWxkcmVuLmZpbHRlcihhcHBseVRyYW5zbGF0aW9uKTtcbiAgICAgIGZvcmNlUmVmbG93KGluc3RhbmNlLnZub2RlLmVsKTtcbiAgICAgIG1vdmVkQ2hpbGRyZW4uZm9yRWFjaCgoYykgPT4ge1xuICAgICAgICBjb25zdCBlbCA9IGMuZWw7XG4gICAgICAgIGNvbnN0IHN0eWxlID0gZWwuc3R5bGU7XG4gICAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgbW92ZUNsYXNzKTtcbiAgICAgICAgc3R5bGUudHJhbnNmb3JtID0gc3R5bGUud2Via2l0VHJhbnNmb3JtID0gc3R5bGUudHJhbnNpdGlvbkR1cmF0aW9uID0gXCJcIjtcbiAgICAgICAgY29uc3QgY2IgPSBlbFttb3ZlQ2JLZXldID0gKGUpID0+IHtcbiAgICAgICAgICBpZiAoZSAmJiBlLnRhcmdldCAhPT0gZWwpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFlIHx8IGUucHJvcGVydHlOYW1lLmVuZHNXaXRoKFwidHJhbnNmb3JtXCIpKSB7XG4gICAgICAgICAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKFwidHJhbnNpdGlvbmVuZFwiLCBjYik7XG4gICAgICAgICAgICBlbFttb3ZlQ2JLZXldID0gbnVsbDtcbiAgICAgICAgICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgbW92ZUNsYXNzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoXCJ0cmFuc2l0aW9uZW5kXCIsIGNiKTtcbiAgICAgIH0pO1xuICAgICAgcHJldkNoaWxkcmVuID0gW107XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNvbnN0IHJhd1Byb3BzID0gdG9SYXcocHJvcHMpO1xuICAgICAgY29uc3QgY3NzVHJhbnNpdGlvblByb3BzID0gcmVzb2x2ZVRyYW5zaXRpb25Qcm9wcyhyYXdQcm9wcyk7XG4gICAgICBsZXQgdGFnID0gcmF3UHJvcHMudGFnIHx8IEZyYWdtZW50O1xuICAgICAgcHJldkNoaWxkcmVuID0gW107XG4gICAgICBpZiAoY2hpbGRyZW4pIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgICAgICAgaWYgKGNoaWxkLmVsICYmIGNoaWxkLmVsIGluc3RhbmNlb2YgRWxlbWVudCAmJiAvLyBIaWRkZW4gdi1zaG93IG5vZGVzIGhhdmUgbm8gcHJldmlvdXMgbGF5b3V0IGJveCB0byBhbmltYXRlIGZyb20uXG4gICAgICAgICAgIWNoaWxkLmVsW3ZTaG93SGlkZGVuXSkge1xuICAgICAgICAgICAgcHJldkNoaWxkcmVuLnB1c2goY2hpbGQpO1xuICAgICAgICAgICAgc2V0VHJhbnNpdGlvbkhvb2tzKFxuICAgICAgICAgICAgICBjaGlsZCxcbiAgICAgICAgICAgICAgcmVzb2x2ZVRyYW5zaXRpb25Ib29rcyhcbiAgICAgICAgICAgICAgICBjaGlsZCxcbiAgICAgICAgICAgICAgICBjc3NUcmFuc2l0aW9uUHJvcHMsXG4gICAgICAgICAgICAgICAgc3RhdGUsXG4gICAgICAgICAgICAgICAgaW5zdGFuY2VcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHBvc2l0aW9uTWFwLnNldChjaGlsZCwgZ2V0UG9zaXRpb24oY2hpbGQuZWwpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNoaWxkcmVuID0gc2xvdHMuZGVmYXVsdCA/IGdldFRyYW5zaXRpb25SYXdDaGlsZHJlbihzbG90cy5kZWZhdWx0KCkpIDogW107XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgICAgIGlmIChjaGlsZC5rZXkgIT0gbnVsbCkge1xuICAgICAgICAgIHNldFRyYW5zaXRpb25Ib29rcyhcbiAgICAgICAgICAgIGNoaWxkLFxuICAgICAgICAgICAgcmVzb2x2ZVRyYW5zaXRpb25Ib29rcyhjaGlsZCwgY3NzVHJhbnNpdGlvblByb3BzLCBzdGF0ZSwgaW5zdGFuY2UpXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGNoaWxkLnR5cGUgIT09IFRleHQpIHtcbiAgICAgICAgICB3YXJuKGA8VHJhbnNpdGlvbkdyb3VwPiBjaGlsZHJlbiBtdXN0IGJlIGtleWVkLmApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY3JlYXRlVk5vZGUodGFnLCBudWxsLCBjaGlsZHJlbik7XG4gICAgfTtcbiAgfVxufSk7XG5jb25zdCBUcmFuc2l0aW9uR3JvdXAgPSBUcmFuc2l0aW9uR3JvdXBJbXBsO1xuZnVuY3Rpb24gY2FsbFBlbmRpbmdDYnMoYykge1xuICBjb25zdCBlbCA9IGMuZWw7XG4gIGlmIChlbFttb3ZlQ2JLZXldKSB7XG4gICAgZWxbbW92ZUNiS2V5XSgpO1xuICB9XG4gIGlmIChlbFtlbnRlckNiS2V5XSkge1xuICAgIGVsW2VudGVyQ2JLZXldKCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlY29yZFBvc2l0aW9uKGMpIHtcbiAgbmV3UG9zaXRpb25NYXAuc2V0KGMsIGdldFBvc2l0aW9uKGMuZWwpKTtcbn1cbmZ1bmN0aW9uIGFwcGx5VHJhbnNsYXRpb24oYykge1xuICBjb25zdCBvbGRQb3MgPSBwb3NpdGlvbk1hcC5nZXQoYyk7XG4gIGNvbnN0IG5ld1BvcyA9IG5ld1Bvc2l0aW9uTWFwLmdldChjKTtcbiAgY29uc3QgZHggPSBvbGRQb3MubGVmdCAtIG5ld1Bvcy5sZWZ0O1xuICBjb25zdCBkeSA9IG9sZFBvcy50b3AgLSBuZXdQb3MudG9wO1xuICBpZiAoZHggfHwgZHkpIHtcbiAgICBjb25zdCBlbCA9IGMuZWw7XG4gICAgY29uc3QgcyA9IGVsLnN0eWxlO1xuICAgIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBsZXQgc2NhbGVYID0gMTtcbiAgICBsZXQgc2NhbGVZID0gMTtcbiAgICBpZiAoZWwub2Zmc2V0V2lkdGgpIHNjYWxlWCA9IHJlY3Qud2lkdGggLyBlbC5vZmZzZXRXaWR0aDtcbiAgICBpZiAoZWwub2Zmc2V0SGVpZ2h0KSBzY2FsZVkgPSByZWN0LmhlaWdodCAvIGVsLm9mZnNldEhlaWdodDtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShzY2FsZVgpIHx8IHNjYWxlWCA9PT0gMCkgc2NhbGVYID0gMTtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShzY2FsZVkpIHx8IHNjYWxlWSA9PT0gMCkgc2NhbGVZID0gMTtcbiAgICBpZiAoTWF0aC5hYnMoc2NhbGVYIC0gMSkgPCAwLjAxKSBzY2FsZVggPSAxO1xuICAgIGlmIChNYXRoLmFicyhzY2FsZVkgLSAxKSA8IDAuMDEpIHNjYWxlWSA9IDE7XG4gICAgcy50cmFuc2Zvcm0gPSBzLndlYmtpdFRyYW5zZm9ybSA9IGB0cmFuc2xhdGUoJHtkeCAvIHNjYWxlWH1weCwke2R5IC8gc2NhbGVZfXB4KWA7XG4gICAgcy50cmFuc2l0aW9uRHVyYXRpb24gPSBcIjBzXCI7XG4gICAgcmV0dXJuIGM7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFBvc2l0aW9uKGVsKSB7XG4gIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgcmV0dXJuIHtcbiAgICBsZWZ0OiByZWN0LmxlZnQsXG4gICAgdG9wOiByZWN0LnRvcFxuICB9O1xufVxuZnVuY3Rpb24gaGFzQ1NTVHJhbnNmb3JtKGVsLCByb290LCBtb3ZlQ2xhc3MpIHtcbiAgY29uc3QgY2xvbmUgPSBlbC5jbG9uZU5vZGUoKTtcbiAgY29uc3QgX3Z0YyA9IGVsW3Z0Y0tleV07XG4gIGlmIChfdnRjKSB7XG4gICAgX3Z0Yy5mb3JFYWNoKChjbHMpID0+IHtcbiAgICAgIGNscy5zcGxpdCgvXFxzKy8pLmZvckVhY2goKGMpID0+IGMgJiYgY2xvbmUuY2xhc3NMaXN0LnJlbW92ZShjKSk7XG4gICAgfSk7XG4gIH1cbiAgbW92ZUNsYXNzLnNwbGl0KC9cXHMrLykuZm9yRWFjaCgoYykgPT4gYyAmJiBjbG9uZS5jbGFzc0xpc3QuYWRkKGMpKTtcbiAgY2xvbmUuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICBjb25zdCBjb250YWluZXIgPSByb290Lm5vZGVUeXBlID09PSAxID8gcm9vdCA6IHJvb3QucGFyZW50Tm9kZTtcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKGNsb25lKTtcbiAgY29uc3QgeyBoYXNUcmFuc2Zvcm0gfSA9IGdldFRyYW5zaXRpb25JbmZvKGNsb25lKTtcbiAgY29udGFpbmVyLnJlbW92ZUNoaWxkKGNsb25lKTtcbiAgcmV0dXJuIGhhc1RyYW5zZm9ybTtcbn1cblxuY29uc3QgZ2V0TW9kZWxBc3NpZ25lciA9ICh2bm9kZSkgPT4ge1xuICBjb25zdCBmbiA9IHZub2RlLnByb3BzW1wib25VcGRhdGU6bW9kZWxWYWx1ZVwiXSB8fCBmYWxzZTtcbiAgcmV0dXJuIGlzQXJyYXkoZm4pID8gKHZhbHVlKSA9PiBpbnZva2VBcnJheUZucyhmbiwgdmFsdWUpIDogZm47XG59O1xuZnVuY3Rpb24gb25Db21wb3NpdGlvblN0YXJ0KGUpIHtcbiAgZS50YXJnZXQuY29tcG9zaW5nID0gdHJ1ZTtcbn1cbmZ1bmN0aW9uIG9uQ29tcG9zaXRpb25FbmQoZSkge1xuICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldDtcbiAgaWYgKHRhcmdldC5jb21wb3NpbmcpIHtcbiAgICB0YXJnZXQuY29tcG9zaW5nID0gZmFsc2U7XG4gICAgdGFyZ2V0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIikpO1xuICB9XG59XG5jb25zdCBhc3NpZ25LZXkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwiX2Fzc2lnblwiKTtcbmNvbnN0IGluaXRpYWxWYWx1ZUtleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfaW5pdGlhbFZhbHVlXCIpO1xuZnVuY3Rpb24gY2FzdFZhbHVlKHZhbHVlLCB0cmltLCBudW1iZXIpIHtcbiAgaWYgKHRyaW0pIHZhbHVlID0gdmFsdWUudHJpbSgpO1xuICBpZiAobnVtYmVyKSB2YWx1ZSA9IGxvb3NlVG9OdW1iZXIodmFsdWUpO1xuICByZXR1cm4gdmFsdWU7XG59XG5jb25zdCB2TW9kZWxUZXh0ID0ge1xuICBjcmVhdGVkKGVsLCB7IG1vZGlmaWVyczogeyBsYXp5LCB0cmltLCBudW1iZXIgfSB9LCB2bm9kZSkge1xuICAgIGlmIChlbC5wYXJlbnROb2RlKSB7XG4gICAgICBpZiAoZWwudHlwZSA9PT0gXCJ0ZXh0XCIpIHtcbiAgICAgICAgZWxbaW5pdGlhbFZhbHVlS2V5XSA9IGVsLmRlZmF1bHRWYWx1ZS5yZXBsYWNlKC9bXFxyXFxuXS9nLCBcIlwiKTtcbiAgICAgIH0gZWxzZSBpZiAoZWwudHlwZSA9PT0gXCJ0ZXh0YXJlYVwiKSB7XG4gICAgICAgIGVsW2luaXRpYWxWYWx1ZUtleV0gPSBlbC5kZWZhdWx0VmFsdWUucmVwbGFjZSgvXFxyXFxuPy9nLCBcIlxcblwiKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZWxbYXNzaWduS2V5XSA9IGdldE1vZGVsQXNzaWduZXIodm5vZGUpO1xuICAgIGNvbnN0IGNhc3RUb051bWJlciA9IG51bWJlciB8fCB2bm9kZS5wcm9wcyAmJiB2bm9kZS5wcm9wcy50eXBlID09PSBcIm51bWJlclwiO1xuICAgIGFkZEV2ZW50TGlzdGVuZXIoZWwsIGxhenkgPyBcImNoYW5nZVwiIDogXCJpbnB1dFwiLCAoZSkgPT4ge1xuICAgICAgaWYgKGUudGFyZ2V0LmNvbXBvc2luZykgcmV0dXJuO1xuICAgICAgZWxbYXNzaWduS2V5XShjYXN0VmFsdWUoZWwudmFsdWUsIHRyaW0sIGNhc3RUb051bWJlcikpO1xuICAgIH0pO1xuICAgIGlmICh0cmltIHx8IGNhc3RUb051bWJlcikge1xuICAgICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgXCJjaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgICBlbC52YWx1ZSA9IGNhc3RWYWx1ZShlbC52YWx1ZSwgdHJpbSwgY2FzdFRvTnVtYmVyKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoIWxhenkpIHtcbiAgICAgIGFkZEV2ZW50TGlzdGVuZXIoZWwsIFwiY29tcG9zaXRpb25zdGFydFwiLCBvbkNvbXBvc2l0aW9uU3RhcnQpO1xuICAgICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgXCJjb21wb3NpdGlvbmVuZFwiLCBvbkNvbXBvc2l0aW9uRW5kKTtcbiAgICAgIGFkZEV2ZW50TGlzdGVuZXIoZWwsIFwiY2hhbmdlXCIsIG9uQ29tcG9zaXRpb25FbmQpO1xuICAgIH1cbiAgfSxcbiAgLy8gc2V0IHZhbHVlIG9uIG1vdW50ZWQgc28gaXQncyBhZnRlciBtaW4vbWF4IGZvciB0eXBlPVwicmFuZ2VcIlxuICBtb3VudGVkKGVsLCB7IHZhbHVlLCBtb2RpZmllcnM6IHsgdHJpbSwgbnVtYmVyIH0gfSkge1xuICAgIGNvbnN0IG5ld1ZhbHVlID0gdmFsdWUgPT0gbnVsbCA/IFwiXCIgOiB2YWx1ZTtcbiAgICBjb25zdCBpbml0aWFsVmFsdWUgPSBlbFtpbml0aWFsVmFsdWVLZXldO1xuICAgIGRlbGV0ZSBlbFtpbml0aWFsVmFsdWVLZXldO1xuICAgIGlmIChpbml0aWFsVmFsdWUgIT09IHZvaWQgMCAmJiAoZWwudHlwZSA9PT0gXCJ0ZXh0XCIgfHwgZWwudHlwZSA9PT0gXCJ0ZXh0YXJlYVwiKSAmJiBlbC52YWx1ZSAhPT0gaW5pdGlhbFZhbHVlKSB7XG4gICAgICBlbFthc3NpZ25LZXldKGNhc3RWYWx1ZShlbC52YWx1ZSwgdHJpbSwgbnVtYmVyKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGVsLnZhbHVlID0gbmV3VmFsdWU7XG4gICAgfVxuICB9LFxuICBiZWZvcmVVcGRhdGUoZWwsIHsgdmFsdWUsIG9sZFZhbHVlLCBtb2RpZmllcnM6IHsgbGF6eSwgdHJpbSwgbnVtYmVyIH0gfSwgdm5vZGUpIHtcbiAgICBlbFthc3NpZ25LZXldID0gZ2V0TW9kZWxBc3NpZ25lcih2bm9kZSk7XG4gICAgaWYgKGVsLmNvbXBvc2luZykgcmV0dXJuO1xuICAgIGNvbnN0IGVsVmFsdWUgPSAobnVtYmVyIHx8IGVsLnR5cGUgPT09IFwibnVtYmVyXCIpICYmICEvXjBcXGQvLnRlc3QoZWwudmFsdWUpID8gbG9vc2VUb051bWJlcihlbC52YWx1ZSkgOiBlbC52YWx1ZTtcbiAgICBjb25zdCBuZXdWYWx1ZSA9IHZhbHVlID09IG51bGwgPyBcIlwiIDogdmFsdWU7XG4gICAgaWYgKGVsVmFsdWUgPT09IG5ld1ZhbHVlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJvb3ROb2RlID0gZWwuZ2V0Um9vdE5vZGUoKTtcbiAgICBpZiAoKHJvb3ROb2RlIGluc3RhbmNlb2YgRG9jdW1lbnQgfHwgcm9vdE5vZGUgaW5zdGFuY2VvZiBTaGFkb3dSb290KSAmJiByb290Tm9kZS5hY3RpdmVFbGVtZW50ID09PSBlbCAmJiBlbC50eXBlICE9PSBcInJhbmdlXCIpIHtcbiAgICAgIGlmIChsYXp5ICYmIHZhbHVlID09PSBvbGRWYWx1ZSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodHJpbSAmJiBlbC52YWx1ZS50cmltKCkgPT09IG5ld1ZhbHVlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gICAgZWwudmFsdWUgPSBuZXdWYWx1ZTtcbiAgfVxufTtcbmNvbnN0IHZNb2RlbENoZWNrYm94ID0ge1xuICAvLyAjNDA5NiBhcnJheSBjaGVja2JveGVzIG5lZWQgdG8gYmUgZGVlcCB0cmF2ZXJzZWRcbiAgZGVlcDogdHJ1ZSxcbiAgY3JlYXRlZChlbCwgXywgdm5vZGUpIHtcbiAgICBlbFthc3NpZ25LZXldID0gZ2V0TW9kZWxBc3NpZ25lcih2bm9kZSk7XG4gICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgXCJjaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgY29uc3QgbW9kZWxWYWx1ZSA9IGVsLl9tb2RlbFZhbHVlO1xuICAgICAgY29uc3QgZWxlbWVudFZhbHVlID0gZ2V0VmFsdWUoZWwpO1xuICAgICAgY29uc3QgY2hlY2tlZCA9IGVsLmNoZWNrZWQ7XG4gICAgICBjb25zdCBhc3NpZ24gPSBlbFthc3NpZ25LZXldO1xuICAgICAgaWYgKGlzQXJyYXkobW9kZWxWYWx1ZSkpIHtcbiAgICAgICAgY29uc3QgaW5kZXggPSBsb29zZUluZGV4T2YobW9kZWxWYWx1ZSwgZWxlbWVudFZhbHVlKTtcbiAgICAgICAgY29uc3QgZm91bmQgPSBpbmRleCAhPT0gLTE7XG4gICAgICAgIGlmIChjaGVja2VkICYmICFmb3VuZCkge1xuICAgICAgICAgIGFzc2lnbihtb2RlbFZhbHVlLmNvbmNhdChlbGVtZW50VmFsdWUpKTtcbiAgICAgICAgfSBlbHNlIGlmICghY2hlY2tlZCAmJiBmb3VuZCkge1xuICAgICAgICAgIGNvbnN0IGZpbHRlcmVkID0gWy4uLm1vZGVsVmFsdWVdO1xuICAgICAgICAgIGZpbHRlcmVkLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgYXNzaWduKGZpbHRlcmVkKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChpc1NldChtb2RlbFZhbHVlKSkge1xuICAgICAgICBjb25zdCBjbG9uZWQgPSBuZXcgU2V0KG1vZGVsVmFsdWUpO1xuICAgICAgICBpZiAoY2hlY2tlZCkge1xuICAgICAgICAgIGNsb25lZC5hZGQoZWxlbWVudFZhbHVlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjbG9uZWQuZGVsZXRlKGVsZW1lbnRWYWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgYXNzaWduKGNsb25lZCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhc3NpZ24oZ2V0Q2hlY2tib3hWYWx1ZShlbCwgY2hlY2tlZCkpO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICAvLyBzZXQgaW5pdGlhbCBjaGVja2VkIG9uIG1vdW50IHRvIHdhaXQgZm9yIHRydWUtdmFsdWUvZmFsc2UtdmFsdWVcbiAgbW91bnRlZDogc2V0Q2hlY2tlZCxcbiAgYmVmb3JlVXBkYXRlKGVsLCBiaW5kaW5nLCB2bm9kZSkge1xuICAgIGVsW2Fzc2lnbktleV0gPSBnZXRNb2RlbEFzc2lnbmVyKHZub2RlKTtcbiAgICBzZXRDaGVja2VkKGVsLCBiaW5kaW5nLCB2bm9kZSk7XG4gIH1cbn07XG5mdW5jdGlvbiBzZXRDaGVja2VkKGVsLCB7IHZhbHVlLCBvbGRWYWx1ZSB9LCB2bm9kZSkge1xuICBlbC5fbW9kZWxWYWx1ZSA9IHZhbHVlO1xuICBsZXQgY2hlY2tlZDtcbiAgaWYgKGlzQXJyYXkodmFsdWUpKSB7XG4gICAgY2hlY2tlZCA9IGxvb3NlSW5kZXhPZih2YWx1ZSwgdm5vZGUucHJvcHMudmFsdWUpID4gLTE7XG4gIH0gZWxzZSBpZiAoaXNTZXQodmFsdWUpKSB7XG4gICAgY2hlY2tlZCA9IHZhbHVlLmhhcyh2bm9kZS5wcm9wcy52YWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgaWYgKHZhbHVlID09PSBvbGRWYWx1ZSkgcmV0dXJuO1xuICAgIGNoZWNrZWQgPSBsb29zZUVxdWFsKHZhbHVlLCBnZXRDaGVja2JveFZhbHVlKGVsLCB0cnVlKSk7XG4gIH1cbiAgaWYgKGVsLmNoZWNrZWQgIT09IGNoZWNrZWQpIHtcbiAgICBlbC5jaGVja2VkID0gY2hlY2tlZDtcbiAgfVxufVxuY29uc3Qgdk1vZGVsUmFkaW8gPSB7XG4gIGNyZWF0ZWQoZWwsIHsgdmFsdWUgfSwgdm5vZGUpIHtcbiAgICBlbC5jaGVja2VkID0gbG9vc2VFcXVhbCh2YWx1ZSwgdm5vZGUucHJvcHMudmFsdWUpO1xuICAgIGVsW2Fzc2lnbktleV0gPSBnZXRNb2RlbEFzc2lnbmVyKHZub2RlKTtcbiAgICBhZGRFdmVudExpc3RlbmVyKGVsLCBcImNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICBlbFthc3NpZ25LZXldKGdldFZhbHVlKGVsKSk7XG4gICAgfSk7XG4gIH0sXG4gIGJlZm9yZVVwZGF0ZShlbCwgeyB2YWx1ZSwgb2xkVmFsdWUgfSwgdm5vZGUpIHtcbiAgICBlbFthc3NpZ25LZXldID0gZ2V0TW9kZWxBc3NpZ25lcih2bm9kZSk7XG4gICAgaWYgKHZhbHVlICE9PSBvbGRWYWx1ZSkge1xuICAgICAgZWwuY2hlY2tlZCA9IGxvb3NlRXF1YWwodmFsdWUsIHZub2RlLnByb3BzLnZhbHVlKTtcbiAgICB9XG4gIH1cbn07XG5jb25zdCB2TW9kZWxTZWxlY3QgPSB7XG4gIC8vIDxzZWxlY3QgbXVsdGlwbGU+IHZhbHVlIG5lZWQgdG8gYmUgZGVlcCB0cmF2ZXJzZWRcbiAgZGVlcDogdHJ1ZSxcbiAgY3JlYXRlZChlbCwgeyB2YWx1ZSwgbW9kaWZpZXJzOiB7IG51bWJlciB9IH0sIHZub2RlKSB7XG4gICAgZWwuX21vZGVsVmFsdWUgPSB2YWx1ZTtcbiAgICBhZGRFdmVudExpc3RlbmVyKGVsLCBcImNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICBjb25zdCBzZWxlY3RlZFZhbCA9IEFycmF5LnByb3RvdHlwZS5maWx0ZXIuY2FsbChlbC5vcHRpb25zLCAobykgPT4gby5zZWxlY3RlZCkubWFwKFxuICAgICAgICAobykgPT4gbnVtYmVyID8gbG9vc2VUb051bWJlcihnZXRWYWx1ZShvKSkgOiBnZXRWYWx1ZShvKVxuICAgICAgKTtcbiAgICAgIGVsW2Fzc2lnbktleV0oXG4gICAgICAgIGVsLm11bHRpcGxlID8gaXNTZXQoZWwuX21vZGVsVmFsdWUpID8gbmV3IFNldChzZWxlY3RlZFZhbCkgOiBzZWxlY3RlZFZhbCA6IHNlbGVjdGVkVmFsWzBdXG4gICAgICApO1xuICAgICAgZWwuX2Fzc2lnbmluZyA9IHRydWU7XG4gICAgICBuZXh0VGljaygoKSA9PiB7XG4gICAgICAgIGVsLl9hc3NpZ25pbmcgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIGVsW2Fzc2lnbktleV0gPSBnZXRNb2RlbEFzc2lnbmVyKHZub2RlKTtcbiAgfSxcbiAgLy8gc2V0IHZhbHVlIGluIG1vdW50ZWQgJiB1cGRhdGVkIGJlY2F1c2UgPHNlbGVjdD4gcmVsaWVzIG9uIGl0cyBjaGlsZHJlblxuICAvLyA8b3B0aW9uPnMuXG4gIG1vdW50ZWQoZWwsIHsgdmFsdWUgfSkge1xuICAgIHNldFNlbGVjdGVkKGVsLCB2YWx1ZSk7XG4gIH0sXG4gIGJlZm9yZVVwZGF0ZShlbCwgeyB2YWx1ZSB9LCB2bm9kZSkge1xuICAgIGVsLl9tb2RlbFZhbHVlID0gdmFsdWU7XG4gICAgZWxbYXNzaWduS2V5XSA9IGdldE1vZGVsQXNzaWduZXIodm5vZGUpO1xuICB9LFxuICB1cGRhdGVkKGVsLCB7IHZhbHVlIH0pIHtcbiAgICBpZiAoIWVsLl9hc3NpZ25pbmcpIHtcbiAgICAgIHNldFNlbGVjdGVkKGVsLCB2YWx1ZSk7XG4gICAgfVxuICB9XG59O1xuZnVuY3Rpb24gc2V0U2VsZWN0ZWQoZWwsIHZhbHVlKSB7XG4gIGNvbnN0IGlzTXVsdGlwbGUgPSBlbC5tdWx0aXBsZTtcbiAgY29uc3QgaXNBcnJheVZhbHVlID0gaXNBcnJheSh2YWx1ZSk7XG4gIGlmIChpc011bHRpcGxlICYmICFpc0FycmF5VmFsdWUgJiYgIWlzU2V0KHZhbHVlKSkge1xuICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgd2FybihcbiAgICAgIGA8c2VsZWN0IG11bHRpcGxlIHYtbW9kZWw+IGV4cGVjdHMgYW4gQXJyYXkgb3IgU2V0IHZhbHVlIGZvciBpdHMgYmluZGluZywgYnV0IGdvdCAke09iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWx1ZSkuc2xpY2UoOCwgLTEpfS5gXG4gICAgKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChsZXQgaSA9IDAsIGwgPSBlbC5vcHRpb25zLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgIGNvbnN0IG9wdGlvbiA9IGVsLm9wdGlvbnNbaV07XG4gICAgY29uc3Qgb3B0aW9uVmFsdWUgPSBnZXRWYWx1ZShvcHRpb24pO1xuICAgIGlmIChpc011bHRpcGxlKSB7XG4gICAgICBpZiAoaXNBcnJheVZhbHVlKSB7XG4gICAgICAgIGNvbnN0IG9wdGlvblR5cGUgPSB0eXBlb2Ygb3B0aW9uVmFsdWU7XG4gICAgICAgIGlmIChvcHRpb25UeXBlID09PSBcInN0cmluZ1wiIHx8IG9wdGlvblR5cGUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSB2YWx1ZS5zb21lKCh2KSA9PiBTdHJpbmcodikgPT09IFN0cmluZyhvcHRpb25WYWx1ZSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IGxvb3NlSW5kZXhPZih2YWx1ZSwgb3B0aW9uVmFsdWUpID4gLTE7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IHZhbHVlLmhhcyhvcHRpb25WYWx1ZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChsb29zZUVxdWFsKGdldFZhbHVlKG9wdGlvbiksIHZhbHVlKSkge1xuICAgICAgaWYgKGVsLnNlbGVjdGVkSW5kZXggIT09IGkpIGVsLnNlbGVjdGVkSW5kZXggPSBpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgfVxuICBpZiAoIWlzTXVsdGlwbGUgJiYgZWwuc2VsZWN0ZWRJbmRleCAhPT0gLTEpIHtcbiAgICBlbC5zZWxlY3RlZEluZGV4ID0gLTE7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFZhbHVlKGVsKSB7XG4gIHJldHVybiBcIl92YWx1ZVwiIGluIGVsID8gZWwuX3ZhbHVlIDogZWwudmFsdWU7XG59XG5mdW5jdGlvbiBnZXRDaGVja2JveFZhbHVlKGVsLCBjaGVja2VkKSB7XG4gIGNvbnN0IGtleSA9IGNoZWNrZWQgPyBcIl90cnVlVmFsdWVcIiA6IFwiX2ZhbHNlVmFsdWVcIjtcbiAgcmV0dXJuIGtleSBpbiBlbCA/IGVsW2tleV0gOiBjaGVja2VkO1xufVxuY29uc3Qgdk1vZGVsRHluYW1pYyA9IHtcbiAgY3JlYXRlZChlbCwgYmluZGluZywgdm5vZGUpIHtcbiAgICBjYWxsTW9kZWxIb29rKGVsLCBiaW5kaW5nLCB2bm9kZSwgbnVsbCwgXCJjcmVhdGVkXCIpO1xuICB9LFxuICBtb3VudGVkKGVsLCBiaW5kaW5nLCB2bm9kZSkge1xuICAgIGNhbGxNb2RlbEhvb2soZWwsIGJpbmRpbmcsIHZub2RlLCBudWxsLCBcIm1vdW50ZWRcIik7XG4gIH0sXG4gIGJlZm9yZVVwZGF0ZShlbCwgYmluZGluZywgdm5vZGUsIHByZXZWTm9kZSkge1xuICAgIGNhbGxNb2RlbEhvb2soZWwsIGJpbmRpbmcsIHZub2RlLCBwcmV2Vk5vZGUsIFwiYmVmb3JlVXBkYXRlXCIpO1xuICB9LFxuICB1cGRhdGVkKGVsLCBiaW5kaW5nLCB2bm9kZSwgcHJldlZOb2RlKSB7XG4gICAgY2FsbE1vZGVsSG9vayhlbCwgYmluZGluZywgdm5vZGUsIHByZXZWTm9kZSwgXCJ1cGRhdGVkXCIpO1xuICB9XG59O1xuZnVuY3Rpb24gcmVzb2x2ZUR5bmFtaWNNb2RlbCh0YWdOYW1lLCB0eXBlKSB7XG4gIHN3aXRjaCAodGFnTmFtZSkge1xuICAgIGNhc2UgXCJTRUxFQ1RcIjpcbiAgICAgIHJldHVybiB2TW9kZWxTZWxlY3Q7XG4gICAgY2FzZSBcIlRFWFRBUkVBXCI6XG4gICAgICByZXR1cm4gdk1vZGVsVGV4dDtcbiAgICBkZWZhdWx0OlxuICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgIGNhc2UgXCJjaGVja2JveFwiOlxuICAgICAgICAgIHJldHVybiB2TW9kZWxDaGVja2JveDtcbiAgICAgICAgY2FzZSBcInJhZGlvXCI6XG4gICAgICAgICAgcmV0dXJuIHZNb2RlbFJhZGlvO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHJldHVybiB2TW9kZWxUZXh0O1xuICAgICAgfVxuICB9XG59XG5mdW5jdGlvbiBjYWxsTW9kZWxIb29rKGVsLCBiaW5kaW5nLCB2bm9kZSwgcHJldlZOb2RlLCBob29rKSB7XG4gIGNvbnN0IG1vZGVsVG9Vc2UgPSByZXNvbHZlRHluYW1pY01vZGVsKFxuICAgIGVsLnRhZ05hbWUsXG4gICAgdm5vZGUucHJvcHMgJiYgdm5vZGUucHJvcHMudHlwZVxuICApO1xuICBjb25zdCBmbiA9IG1vZGVsVG9Vc2VbaG9va107XG4gIGZuICYmIGZuKGVsLCBiaW5kaW5nLCB2bm9kZSwgcHJldlZOb2RlKTtcbn1cbmZ1bmN0aW9uIGluaXRWTW9kZWxGb3JTU1IoKSB7XG4gIHZNb2RlbFRleHQuZ2V0U1NSUHJvcHMgPSAoeyB2YWx1ZSB9KSA9PiAoeyB2YWx1ZSB9KTtcbiAgdk1vZGVsUmFkaW8uZ2V0U1NSUHJvcHMgPSAoeyB2YWx1ZSB9LCB2bm9kZSkgPT4ge1xuICAgIGlmICh2bm9kZS5wcm9wcyAmJiBsb29zZUVxdWFsKHZub2RlLnByb3BzLnZhbHVlLCB2YWx1ZSkpIHtcbiAgICAgIHJldHVybiB7IGNoZWNrZWQ6IHRydWUgfTtcbiAgICB9XG4gIH07XG4gIHZNb2RlbENoZWNrYm94LmdldFNTUlByb3BzID0gKHsgdmFsdWUgfSwgdm5vZGUpID0+IHtcbiAgICBpZiAoaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIGlmICh2bm9kZS5wcm9wcyAmJiBsb29zZUluZGV4T2YodmFsdWUsIHZub2RlLnByb3BzLnZhbHVlKSA+IC0xKSB7XG4gICAgICAgIHJldHVybiB7IGNoZWNrZWQ6IHRydWUgfTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGlzU2V0KHZhbHVlKSkge1xuICAgICAgaWYgKHZub2RlLnByb3BzICYmIHZhbHVlLmhhcyh2bm9kZS5wcm9wcy52YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHsgY2hlY2tlZDogdHJ1ZSB9O1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodmFsdWUpIHtcbiAgICAgIHJldHVybiB7IGNoZWNrZWQ6IHRydWUgfTtcbiAgICB9XG4gIH07XG4gIHZNb2RlbER5bmFtaWMuZ2V0U1NSUHJvcHMgPSAoYmluZGluZywgdm5vZGUpID0+IHtcbiAgICBpZiAodHlwZW9mIHZub2RlLnR5cGUgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbW9kZWxUb1VzZSA9IHJlc29sdmVEeW5hbWljTW9kZWwoXG4gICAgICAvLyByZXNvbHZlRHluYW1pY01vZGVsIGV4cGVjdHMgYW4gdXBwZXJjYXNlIHRhZyBuYW1lLCBidXQgdm5vZGUudHlwZSBpcyBsb3dlcmNhc2VcbiAgICAgIHZub2RlLnR5cGUudG9VcHBlckNhc2UoKSxcbiAgICAgIHZub2RlLnByb3BzICYmIHZub2RlLnByb3BzLnR5cGVcbiAgICApO1xuICAgIGlmIChtb2RlbFRvVXNlLmdldFNTUlByb3BzKSB7XG4gICAgICByZXR1cm4gbW9kZWxUb1VzZS5nZXRTU1JQcm9wcyhiaW5kaW5nLCB2bm9kZSk7XG4gICAgfVxuICB9O1xufVxuXG5jb25zdCBzeXN0ZW1Nb2RpZmllcnMgPSBbXCJjdHJsXCIsIFwic2hpZnRcIiwgXCJhbHRcIiwgXCJtZXRhXCJdO1xuY29uc3QgbW9kaWZpZXJHdWFyZHMgPSB7XG4gIHN0b3A6IChlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpLFxuICBwcmV2ZW50OiAoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpLFxuICBzZWxmOiAoZSkgPT4gZS50YXJnZXQgIT09IGUuY3VycmVudFRhcmdldCxcbiAgY3RybDogKGUpID0+ICFlLmN0cmxLZXksXG4gIHNoaWZ0OiAoZSkgPT4gIWUuc2hpZnRLZXksXG4gIGFsdDogKGUpID0+ICFlLmFsdEtleSxcbiAgbWV0YTogKGUpID0+ICFlLm1ldGFLZXksXG4gIGxlZnQ6IChlKSA9PiBcImJ1dHRvblwiIGluIGUgJiYgZS5idXR0b24gIT09IDAsXG4gIG1pZGRsZTogKGUpID0+IFwiYnV0dG9uXCIgaW4gZSAmJiBlLmJ1dHRvbiAhPT0gMSxcbiAgcmlnaHQ6IChlKSA9PiBcImJ1dHRvblwiIGluIGUgJiYgZS5idXR0b24gIT09IDIsXG4gIGV4YWN0OiAoZSwgbW9kaWZpZXJzKSA9PiBzeXN0ZW1Nb2RpZmllcnMuc29tZSgobSkgPT4gZVtgJHttfUtleWBdICYmICFtb2RpZmllcnMuaW5jbHVkZXMobSkpXG59O1xuY29uc3Qgd2l0aE1vZGlmaWVycyA9IChmbiwgbW9kaWZpZXJzKSA9PiB7XG4gIGlmICghZm4pIHJldHVybiBmbjtcbiAgY29uc3QgY2FjaGUgPSBmbi5fd2l0aE1vZHMgfHwgKGZuLl93aXRoTW9kcyA9IHt9KTtcbiAgY29uc3QgY2FjaGVLZXkgPSBtb2RpZmllcnMuam9pbihcIi5cIik7XG4gIHJldHVybiBjYWNoZVtjYWNoZUtleV0gfHwgKGNhY2hlW2NhY2hlS2V5XSA9ICgoZXZlbnQsIC4uLmFyZ3MpID0+IHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1vZGlmaWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgZ3VhcmQgPSBtb2RpZmllckd1YXJkc1ttb2RpZmllcnNbaV1dO1xuICAgICAgaWYgKGd1YXJkICYmIGd1YXJkKGV2ZW50LCBtb2RpZmllcnMpKSByZXR1cm47XG4gICAgfVxuICAgIHJldHVybiBmbihldmVudCwgLi4uYXJncyk7XG4gIH0pKTtcbn07XG5jb25zdCBrZXlOYW1lcyA9IHtcbiAgZXNjOiBcImVzY2FwZVwiLFxuICBzcGFjZTogXCIgXCIsXG4gIHVwOiBcImFycm93LXVwXCIsXG4gIGxlZnQ6IFwiYXJyb3ctbGVmdFwiLFxuICByaWdodDogXCJhcnJvdy1yaWdodFwiLFxuICBkb3duOiBcImFycm93LWRvd25cIixcbiAgZGVsZXRlOiBcImJhY2tzcGFjZVwiXG59O1xuY29uc3Qgd2l0aEtleXMgPSAoZm4sIG1vZGlmaWVycykgPT4ge1xuICBjb25zdCBjYWNoZSA9IGZuLl93aXRoS2V5cyB8fCAoZm4uX3dpdGhLZXlzID0ge30pO1xuICBjb25zdCBjYWNoZUtleSA9IG1vZGlmaWVycy5qb2luKFwiLlwiKTtcbiAgcmV0dXJuIGNhY2hlW2NhY2hlS2V5XSB8fCAoY2FjaGVbY2FjaGVLZXldID0gKChldmVudCkgPT4ge1xuICAgIGlmICghKFwia2V5XCIgaW4gZXZlbnQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGV2ZW50S2V5ID0gaHlwaGVuYXRlKGV2ZW50LmtleSk7XG4gICAgaWYgKG1vZGlmaWVycy5zb21lKFxuICAgICAgKGspID0+IGsgPT09IGV2ZW50S2V5IHx8IGtleU5hbWVzW2tdID09PSBldmVudEtleVxuICAgICkpIHtcbiAgICAgIHJldHVybiBmbihldmVudCk7XG4gICAgfVxuICB9KSk7XG59O1xuXG5jb25zdCByZW5kZXJlck9wdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gZXh0ZW5kKHsgcGF0Y2hQcm9wIH0sIG5vZGVPcHMpO1xubGV0IHJlbmRlcmVyO1xubGV0IGVuYWJsZWRIeWRyYXRpb24gPSBmYWxzZTtcbmZ1bmN0aW9uIGVuc3VyZVJlbmRlcmVyKCkge1xuICByZXR1cm4gcmVuZGVyZXIgfHwgKHJlbmRlcmVyID0gY3JlYXRlUmVuZGVyZXIocmVuZGVyZXJPcHRpb25zKSk7XG59XG5mdW5jdGlvbiBlbnN1cmVIeWRyYXRpb25SZW5kZXJlcigpIHtcbiAgcmVuZGVyZXIgPSBlbmFibGVkSHlkcmF0aW9uID8gcmVuZGVyZXIgOiBjcmVhdGVIeWRyYXRpb25SZW5kZXJlcihyZW5kZXJlck9wdGlvbnMpO1xuICBlbmFibGVkSHlkcmF0aW9uID0gdHJ1ZTtcbiAgcmV0dXJuIHJlbmRlcmVyO1xufVxuY29uc3QgcmVuZGVyID0gKCguLi5hcmdzKSA9PiB7XG4gIGVuc3VyZVJlbmRlcmVyKCkucmVuZGVyKC4uLmFyZ3MpO1xufSk7XG5jb25zdCBoeWRyYXRlID0gKCguLi5hcmdzKSA9PiB7XG4gIGVuc3VyZUh5ZHJhdGlvblJlbmRlcmVyKCkuaHlkcmF0ZSguLi5hcmdzKTtcbn0pO1xuY29uc3QgY3JlYXRlQXBwID0gKCguLi5hcmdzKSA9PiB7XG4gIGNvbnN0IGFwcCA9IGVuc3VyZVJlbmRlcmVyKCkuY3JlYXRlQXBwKC4uLmFyZ3MpO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGluamVjdE5hdGl2ZVRhZ0NoZWNrKGFwcCk7XG4gICAgaW5qZWN0Q29tcGlsZXJPcHRpb25zQ2hlY2soYXBwKTtcbiAgfVxuICBjb25zdCB7IG1vdW50IH0gPSBhcHA7XG4gIGFwcC5tb3VudCA9IChjb250YWluZXJPclNlbGVjdG9yKSA9PiB7XG4gICAgY29uc3QgY29udGFpbmVyID0gbm9ybWFsaXplQ29udGFpbmVyKGNvbnRhaW5lck9yU2VsZWN0b3IpO1xuICAgIGlmICghY29udGFpbmVyKSByZXR1cm47XG4gICAgY29uc3QgY29tcG9uZW50ID0gYXBwLl9jb21wb25lbnQ7XG4gICAgaWYgKCFpc0Z1bmN0aW9uKGNvbXBvbmVudCkgJiYgIWNvbXBvbmVudC5yZW5kZXIgJiYgIWNvbXBvbmVudC50ZW1wbGF0ZSkge1xuICAgICAgY29tcG9uZW50LnRlbXBsYXRlID0gY29udGFpbmVyLmlubmVySFRNTDtcbiAgICB9XG4gICAgaWYgKGNvbnRhaW5lci5ub2RlVHlwZSA9PT0gMSkge1xuICAgICAgY29udGFpbmVyLnRleHRDb250ZW50ID0gXCJcIjtcbiAgICB9XG4gICAgY29uc3QgcHJveHkgPSBtb3VudChjb250YWluZXIsIGZhbHNlLCByZXNvbHZlUm9vdE5hbWVzcGFjZShjb250YWluZXIpKTtcbiAgICBpZiAoY29udGFpbmVyIGluc3RhbmNlb2YgRWxlbWVudCkge1xuICAgICAgY29udGFpbmVyLnJlbW92ZUF0dHJpYnV0ZShcInYtY2xvYWtcIik7XG4gICAgICBjb250YWluZXIuc2V0QXR0cmlidXRlKFwiZGF0YS12LWFwcFwiLCBcIlwiKTtcbiAgICB9XG4gICAgcmV0dXJuIHByb3h5O1xuICB9O1xuICByZXR1cm4gYXBwO1xufSk7XG5jb25zdCBjcmVhdGVTU1JBcHAgPSAoKC4uLmFyZ3MpID0+IHtcbiAgY29uc3QgYXBwID0gZW5zdXJlSHlkcmF0aW9uUmVuZGVyZXIoKS5jcmVhdGVBcHAoLi4uYXJncyk7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgaW5qZWN0TmF0aXZlVGFnQ2hlY2soYXBwKTtcbiAgICBpbmplY3RDb21waWxlck9wdGlvbnNDaGVjayhhcHApO1xuICB9XG4gIGNvbnN0IHsgbW91bnQgfSA9IGFwcDtcbiAgYXBwLm1vdW50ID0gKGNvbnRhaW5lck9yU2VsZWN0b3IpID0+IHtcbiAgICBjb25zdCBjb250YWluZXIgPSBub3JtYWxpemVDb250YWluZXIoY29udGFpbmVyT3JTZWxlY3Rvcik7XG4gICAgaWYgKGNvbnRhaW5lcikge1xuICAgICAgcmV0dXJuIG1vdW50KGNvbnRhaW5lciwgdHJ1ZSwgcmVzb2x2ZVJvb3ROYW1lc3BhY2UoY29udGFpbmVyKSk7XG4gICAgfVxuICB9O1xuICByZXR1cm4gYXBwO1xufSk7XG5mdW5jdGlvbiByZXNvbHZlUm9vdE5hbWVzcGFjZShjb250YWluZXIpIHtcbiAgaWYgKGNvbnRhaW5lciBpbnN0YW5jZW9mIFNWR0VsZW1lbnQpIHtcbiAgICByZXR1cm4gXCJzdmdcIjtcbiAgfVxuICBpZiAodHlwZW9mIE1hdGhNTEVsZW1lbnQgPT09IFwiZnVuY3Rpb25cIiAmJiBjb250YWluZXIgaW5zdGFuY2VvZiBNYXRoTUxFbGVtZW50KSB7XG4gICAgcmV0dXJuIFwibWF0aG1sXCI7XG4gIH1cbn1cbmZ1bmN0aW9uIGluamVjdE5hdGl2ZVRhZ0NoZWNrKGFwcCkge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYXBwLmNvbmZpZywgXCJpc05hdGl2ZVRhZ1wiLCB7XG4gICAgdmFsdWU6ICh0YWcpID0+IGlzSFRNTFRhZyh0YWcpIHx8IGlzU1ZHVGFnKHRhZykgfHwgaXNNYXRoTUxUYWcodGFnKSxcbiAgICB3cml0YWJsZTogZmFsc2VcbiAgfSk7XG59XG5mdW5jdGlvbiBpbmplY3RDb21waWxlck9wdGlvbnNDaGVjayhhcHApIHtcbiAgaWYgKGlzUnVudGltZU9ubHkoKSkge1xuICAgIGNvbnN0IGlzQ3VzdG9tRWxlbWVudCA9IGFwcC5jb25maWcuaXNDdXN0b21FbGVtZW50O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShhcHAuY29uZmlnLCBcImlzQ3VzdG9tRWxlbWVudFwiLCB7XG4gICAgICBnZXQoKSB7XG4gICAgICAgIHJldHVybiBpc0N1c3RvbUVsZW1lbnQ7XG4gICAgICB9LFxuICAgICAgc2V0KCkge1xuICAgICAgICB3YXJuKFxuICAgICAgICAgIGBUaGUgXFxgaXNDdXN0b21FbGVtZW50XFxgIGNvbmZpZyBvcHRpb24gaXMgZGVwcmVjYXRlZC4gVXNlIFxcYGNvbXBpbGVyT3B0aW9ucy5pc0N1c3RvbUVsZW1lbnRcXGAgaW5zdGVhZC5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgY29tcGlsZXJPcHRpb25zID0gYXBwLmNvbmZpZy5jb21waWxlck9wdGlvbnM7XG4gICAgY29uc3QgbXNnID0gYFRoZSBcXGBjb21waWxlck9wdGlvbnNcXGAgY29uZmlnIG9wdGlvbiBpcyBvbmx5IHJlc3BlY3RlZCB3aGVuIHVzaW5nIGEgYnVpbGQgb2YgVnVlLmpzIHRoYXQgaW5jbHVkZXMgdGhlIHJ1bnRpbWUgY29tcGlsZXIgKGFrYSBcImZ1bGwgYnVpbGRcIikuIFNpbmNlIHlvdSBhcmUgdXNpbmcgdGhlIHJ1bnRpbWUtb25seSBidWlsZCwgXFxgY29tcGlsZXJPcHRpb25zXFxgIG11c3QgYmUgcGFzc2VkIHRvIFxcYEB2dWUvY29tcGlsZXItZG9tXFxgIGluIHRoZSBidWlsZCBzZXR1cCBpbnN0ZWFkLlxuLSBGb3IgdnVlLWxvYWRlcjogcGFzcyBpdCB2aWEgdnVlLWxvYWRlcidzIFxcYGNvbXBpbGVyT3B0aW9uc1xcYCBsb2FkZXIgb3B0aW9uLlxuLSBGb3IgdnVlLWNsaTogc2VlIGh0dHBzOi8vY2xpLnZ1ZWpzLm9yZy9ndWlkZS93ZWJwYWNrLmh0bWwjbW9kaWZ5aW5nLW9wdGlvbnMtb2YtYS1sb2FkZXJcbi0gRm9yIHZpdGU6IHBhc3MgaXQgdmlhIEB2aXRlanMvcGx1Z2luLXZ1ZSBvcHRpb25zLiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3ZpdGVqcy92aXRlLXBsdWdpbi12dWUvdHJlZS9tYWluL3BhY2thZ2VzL3BsdWdpbi12dWUjZXhhbXBsZS1mb3ItcGFzc2luZy1vcHRpb25zLXRvLXZ1ZWNvbXBpbGVyLXNmY2A7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGFwcC5jb25maWcsIFwiY29tcGlsZXJPcHRpb25zXCIsIHtcbiAgICAgIGdldCgpIHtcbiAgICAgICAgd2Fybihtc2cpO1xuICAgICAgICByZXR1cm4gY29tcGlsZXJPcHRpb25zO1xuICAgICAgfSxcbiAgICAgIHNldCgpIHtcbiAgICAgICAgd2Fybihtc2cpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG5mdW5jdGlvbiBub3JtYWxpemVDb250YWluZXIoY29udGFpbmVyKSB7XG4gIGlmIChpc1N0cmluZyhjb250YWluZXIpKSB7XG4gICAgY29uc3QgcmVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihjb250YWluZXIpO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFyZXMpIHtcbiAgICAgIHdhcm4oXG4gICAgICAgIGBGYWlsZWQgdG8gbW91bnQgYXBwOiBtb3VudCB0YXJnZXQgc2VsZWN0b3IgXCIke2NvbnRhaW5lcn1cIiByZXR1cm5lZCBudWxsLmBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiByZXM7XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgd2luZG93LlNoYWRvd1Jvb3QgJiYgY29udGFpbmVyIGluc3RhbmNlb2Ygd2luZG93LlNoYWRvd1Jvb3QgJiYgY29udGFpbmVyLm1vZGUgPT09IFwiY2xvc2VkXCIpIHtcbiAgICB3YXJuKFxuICAgICAgYG1vdW50aW5nIG9uIGEgU2hhZG93Um9vdCB3aXRoIFxcYHttb2RlOiBcImNsb3NlZFwifVxcYCBtYXkgbGVhZCB0byB1bnByZWRpY3RhYmxlIGJ1Z3NgXG4gICAgKTtcbiAgfVxuICByZXR1cm4gY29udGFpbmVyO1xufVxubGV0IHNzckRpcmVjdGl2ZUluaXRpYWxpemVkID0gZmFsc2U7XG5jb25zdCBpbml0RGlyZWN0aXZlc0ZvclNTUiA9ICgpID0+IHtcbiAgaWYgKCFzc3JEaXJlY3RpdmVJbml0aWFsaXplZCkge1xuICAgIHNzckRpcmVjdGl2ZUluaXRpYWxpemVkID0gdHJ1ZTtcbiAgICBpbml0Vk1vZGVsRm9yU1NSKCk7XG4gICAgaW5pdFZTaG93Rm9yU1NSKCk7XG4gIH1cbn0gO1xuXG5leHBvcnQgeyBUcmFuc2l0aW9uLCBUcmFuc2l0aW9uR3JvdXAsIFZ1ZUVsZW1lbnQsIGNyZWF0ZUFwcCwgY3JlYXRlU1NSQXBwLCBkZWZpbmVDdXN0b21FbGVtZW50LCBkZWZpbmVTU1JDdXN0b21FbGVtZW50LCBoeWRyYXRlLCBpbml0RGlyZWN0aXZlc0ZvclNTUiwgbm9kZU9wcywgcGF0Y2hQcm9wLCByZW5kZXIsIHVzZUNzc01vZHVsZSwgdXNlQ3NzVmFycywgdXNlSG9zdCwgdXNlU2hhZG93Um9vdCwgdk1vZGVsQ2hlY2tib3gsIHZNb2RlbER5bmFtaWMsIHZNb2RlbFJhZGlvLCB2TW9kZWxTZWxlY3QsIHZNb2RlbFRleHQsIHZTaG93LCB3aXRoS2V5cywgd2l0aE1vZGlmaWVycyB9O1xuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS0EsU0FBUyxNQUFNLCtCQUErQixHQUFHLGdCQUFnQixjQUFjLG9CQUFvQixnQkFBZ0Isa0JBQWtCLFdBQVcsT0FBTyxhQUFhLFVBQVUsUUFBUSxVQUFVLDRCQUE0QixVQUFVLE9BQU8sYUFBYSxpQkFBaUIsb0JBQW9CLFdBQVcsT0FBTywwQkFBMEIsb0JBQW9CLHdCQUF3QixNQUFNLGdCQUFnQixlQUFlLCtCQUErQjtBQUMzYixjQUFjO0FBQ2QsU0FBUyxRQUFRLFVBQVUsVUFBVSxTQUFTLE1BQU0sc0JBQXNCLFVBQVUsV0FBVyxZQUFZLG9CQUFvQixVQUFVLHNCQUFzQixZQUFZLE1BQU0saUJBQWlCLFlBQVksWUFBWSxRQUFRLGVBQWUsV0FBVyxjQUFjLE9BQU8sWUFBWSxlQUFlLGdCQUFnQixXQUFXLFVBQVUsbUJBQW1CO0FBRXBXLElBQUksU0FBUztBQUNiLE1BQU0sS0FBSyxPQUFPLFdBQVcsZUFBZSxPQUFPO0FBQ25ELElBQUksSUFBSTtBQUNOLE1BQUk7QUFDRixhQUF5QixtQkFBRyxhQUFhLE9BQU87QUFBQSxNQUM5QyxZQUFZLENBQUMsUUFBUTtBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsR0FBRztBQUNWLElBQTZDLEtBQUssd0NBQXdDLENBQUMsRUFBRTtBQUFBLEVBQy9GO0FBQ0Y7QUFDQSxNQUFNLHNCQUFzQixTQUFTLENBQUMsUUFBUSxPQUFPLFdBQVcsR0FBRyxJQUFJLENBQUMsUUFBUTtBQUNoRixNQUFNLFFBQVE7QUFDZCxNQUFNLFdBQVc7QUFDakIsTUFBTSxNQUFNLE9BQU8sYUFBYSxjQUFjLFdBQVc7QUFDekQsTUFBTSxvQkFBb0IsT0FBdUIsb0JBQUksY0FBYyxVQUFVO0FBQzdFLE1BQU0sVUFBVTtBQUFBLEVBQ2QsUUFBUSxDQUFDLE9BQU8sUUFBUSxXQUFXO0FBQ2pDLFdBQU8sYUFBYSxPQUFPLFVBQVUsSUFBSTtBQUFBLEVBQzNDO0FBQUEsRUFDQSxRQUFRLENBQUMsVUFBVTtBQUNqQixVQUFNLFNBQVMsTUFBTTtBQUNyQixRQUFJLFFBQVE7QUFDVixhQUFPLFlBQVksS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsZUFBZSxDQUFDLEtBQUssV0FBVyxJQUFJLFVBQVU7QUFDNUMsVUFBTSxLQUFLLGNBQWMsUUFBUSxJQUFJLGdCQUFnQixPQUFPLEdBQUcsSUFBSSxjQUFjLFdBQVcsSUFBSSxnQkFBZ0IsVUFBVSxHQUFHLElBQUksS0FBSyxJQUFJLGNBQWMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxJQUFJLElBQUksY0FBYyxHQUFHO0FBQzVMLFFBQUksUUFBUSxZQUFZLFNBQVMsTUFBTSxZQUFZLE1BQU07QUFDdkQsU0FBRyxhQUFhLFlBQVksTUFBTSxRQUFRO0FBQUEsSUFDNUM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsWUFBWSxDQUFDLFNBQVMsSUFBSSxlQUFlLElBQUk7QUFBQSxFQUM3QyxlQUFlLENBQUMsU0FBUyxJQUFJLGNBQWMsSUFBSTtBQUFBLEVBQy9DLFNBQVMsQ0FBQyxNQUFNLFNBQVM7QUFDdkIsU0FBSyxZQUFZO0FBQUEsRUFDbkI7QUFBQSxFQUNBLGdCQUFnQixDQUFDLElBQUksU0FBUztBQUM1QixPQUFHLGNBQWM7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsWUFBWSxDQUFDLFNBQVMsS0FBSztBQUFBLEVBQzNCLGFBQWEsQ0FBQyxTQUFTLEtBQUs7QUFBQSxFQUM1QixlQUFlLENBQUMsYUFBYSxJQUFJLGNBQWMsUUFBUTtBQUFBLEVBQ3ZELFdBQVcsSUFBSSxJQUFJO0FBQ2pCLE9BQUcsYUFBYSxJQUFJLEVBQUU7QUFBQSxFQUN4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxvQkFBb0IsU0FBUyxRQUFRLFFBQVEsV0FBVyxPQUFPLEtBQUs7QUFDbEUsVUFBTSxTQUFTLFNBQVMsT0FBTyxrQkFBa0IsT0FBTztBQUN4RCxRQUFJLFVBQVUsVUFBVSxPQUFPLE1BQU0sY0FBYztBQUNqRCxhQUFPLE1BQU07QUFDWCxlQUFPLGFBQWEsTUFBTSxVQUFVLElBQUksR0FBRyxNQUFNO0FBQ2pELFlBQUksVUFBVSxPQUFPLEVBQUUsUUFBUSxNQUFNLGFBQWM7QUFBQSxNQUNyRDtBQUFBLElBQ0YsT0FBTztBQUNMLHdCQUFrQixZQUFZO0FBQUEsUUFDNUIsY0FBYyxRQUFRLFFBQVEsT0FBTyxXQUFXLGNBQWMsV0FBVyxTQUFTLE9BQU8sWUFBWTtBQUFBLE1BQ3ZHO0FBQ0EsWUFBTSxXQUFXLGtCQUFrQjtBQUNuQyxVQUFJLGNBQWMsU0FBUyxjQUFjLFVBQVU7QUFDakQsY0FBTSxVQUFVLFNBQVM7QUFDekIsZUFBTyxRQUFRLFlBQVk7QUFDekIsbUJBQVMsWUFBWSxRQUFRLFVBQVU7QUFBQSxRQUN6QztBQUNBLGlCQUFTLFlBQVksT0FBTztBQUFBLE1BQzlCO0FBQ0EsYUFBTyxhQUFhLFVBQVUsTUFBTTtBQUFBLElBQ3RDO0FBQ0EsV0FBTztBQUFBO0FBQUEsTUFFTCxTQUFTLE9BQU8sY0FBYyxPQUFPO0FBQUE7QUFBQSxNQUVyQyxTQUFTLE9BQU8sa0JBQWtCLE9BQU87QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLE1BQU0sYUFBYTtBQUNuQixNQUFNLFlBQVk7QUFDbEIsTUFBTSxTQUF5Qix1QkFBTyxNQUFNO0FBQzVDLE1BQU0sK0JBQStCO0FBQUEsRUFDbkMsTUFBTTtBQUFBLEVBQ04sTUFBTTtBQUFBLEVBQ04sS0FBSztBQUFBLElBQ0gsTUFBTTtBQUFBLElBQ04sU0FBUztBQUFBLEVBQ1g7QUFBQSxFQUNBLFVBQVUsQ0FBQyxRQUFRLFFBQVEsTUFBTTtBQUFBLEVBQ2pDLGdCQUFnQjtBQUFBLEVBQ2hCLGtCQUFrQjtBQUFBLEVBQ2xCLGNBQWM7QUFBQSxFQUNkLGlCQUFpQjtBQUFBLEVBQ2pCLG1CQUFtQjtBQUFBLEVBQ25CLGVBQWU7QUFBQSxFQUNmLGdCQUFnQjtBQUFBLEVBQ2hCLGtCQUFrQjtBQUFBLEVBQ2xCLGNBQWM7QUFDaEI7QUFDQSxNQUFNLDRCQUE0QztBQUFBLEVBQ2hELENBQUM7QUFBQSxFQUNEO0FBQUEsRUFDQTtBQUNGO0FBQ0EsTUFBTSxhQUFhLENBQUMsTUFBTTtBQUN4QixJQUFFLGNBQWM7QUFDaEIsSUFBRSxRQUFRO0FBQ1YsU0FBTztBQUNUO0FBQ0EsTUFBTSxhQUE2QjtBQUFBLEVBQ2pDLENBQUMsT0FBTyxFQUFFLE1BQU0sTUFBTSxFQUFFLGdCQUFnQix1QkFBdUIsS0FBSyxHQUFHLEtBQUs7QUFDOUU7QUFDQSxNQUFNLFdBQVcsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxNQUFNO0FBQ3BDLE1BQUksUUFBUSxJQUFJLEdBQUc7QUFDakIsU0FBSyxRQUFRLENBQUMsT0FBTyxHQUFHLEdBQUcsSUFBSSxDQUFDO0FBQUEsRUFDbEMsV0FBVyxNQUFNO0FBQ2YsU0FBSyxHQUFHLElBQUk7QUFBQSxFQUNkO0FBQ0Y7QUFDQSxNQUFNLHNCQUFzQixDQUFDLFNBQVM7QUFDcEMsU0FBTyxPQUFPLFFBQVEsSUFBSSxJQUFJLEtBQUssS0FBSyxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUNyRjtBQUNBLFNBQVMsdUJBQXVCLFVBQVU7QUFDeEMsUUFBTSxZQUFZLENBQUM7QUFDbkIsYUFBVyxPQUFPLFVBQVU7QUFDMUIsUUFBSSxFQUFFLE9BQU8sK0JBQStCO0FBQzFDLGdCQUFVLEdBQUcsSUFBSSxTQUFTLEdBQUc7QUFBQSxJQUMvQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFNBQVMsUUFBUSxPQUFPO0FBQzFCLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTTtBQUFBLElBQ0osT0FBTztBQUFBLElBQ1A7QUFBQSxJQUNBO0FBQUEsSUFDQSxpQkFBaUIsR0FBRyxJQUFJO0FBQUEsSUFDeEIsbUJBQW1CLEdBQUcsSUFBSTtBQUFBLElBQzFCLGVBQWUsR0FBRyxJQUFJO0FBQUEsSUFDdEIsa0JBQWtCO0FBQUEsSUFDbEIsb0JBQW9CO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsSUFDaEIsaUJBQWlCLEdBQUcsSUFBSTtBQUFBLElBQ3hCLG1CQUFtQixHQUFHLElBQUk7QUFBQSxJQUMxQixlQUFlLEdBQUcsSUFBSTtBQUFBLEVBQ3hCLElBQUk7QUFDSixRQUFNLFlBQVksa0JBQWtCLFFBQVE7QUFDNUMsUUFBTSxnQkFBZ0IsYUFBYSxVQUFVLENBQUM7QUFDOUMsUUFBTSxnQkFBZ0IsYUFBYSxVQUFVLENBQUM7QUFDOUMsUUFBTTtBQUFBLElBQ0o7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxJQUNqQixXQUFXO0FBQUEsSUFDWCxvQkFBb0I7QUFBQSxFQUN0QixJQUFJO0FBQ0osUUFBTSxjQUFjLENBQUMsSUFBSSxVQUFVLE1BQU0sZ0JBQWdCO0FBQ3ZELE9BQUcsa0JBQWtCO0FBQ3JCLDBCQUFzQixJQUFJLFdBQVcsZ0JBQWdCLFlBQVk7QUFDakUsMEJBQXNCLElBQUksV0FBVyxvQkFBb0IsZ0JBQWdCO0FBQ3pFLFlBQVEsS0FBSztBQUFBLEVBQ2Y7QUFDQSxRQUFNLGNBQWMsQ0FBQyxJQUFJLFNBQVM7QUFDaEMsT0FBRyxhQUFhO0FBQ2hCLDBCQUFzQixJQUFJLGNBQWM7QUFDeEMsMEJBQXNCLElBQUksWUFBWTtBQUN0QywwQkFBc0IsSUFBSSxnQkFBZ0I7QUFDMUMsWUFBUSxLQUFLO0FBQUEsRUFDZjtBQUNBLFFBQU0sZ0JBQWdCLENBQUMsYUFBYTtBQUNsQyxXQUFPLENBQUMsSUFBSSxTQUFTO0FBQ25CLFlBQU0sT0FBTyxXQUFXLFdBQVc7QUFDbkMsWUFBTSxVQUFVLE1BQU0sWUFBWSxJQUFJLFVBQVUsSUFBSTtBQUNwRCxlQUFTLE1BQU0sQ0FBQyxJQUFJLE9BQU8sQ0FBQztBQUM1QixnQkFBVSxNQUFNO0FBQ2QsOEJBQXNCLElBQUksV0FBVyxrQkFBa0IsY0FBYztBQUNyRSwyQkFBbUIsSUFBSSxXQUFXLGdCQUFnQixZQUFZO0FBQzlELFlBQUksQ0FBQyxvQkFBb0IsSUFBSSxHQUFHO0FBQzlCLDZCQUFtQixJQUFJLE1BQU0sZUFBZSxPQUFPO0FBQUEsUUFDckQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNBLFNBQU8sT0FBTyxXQUFXO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQ2hCLGVBQVMsZUFBZSxDQUFDLEVBQUUsQ0FBQztBQUM1Qix5QkFBbUIsSUFBSSxjQUFjO0FBQ3JDLHlCQUFtQixJQUFJLGdCQUFnQjtBQUFBLElBQ3pDO0FBQUEsSUFDQSxlQUFlLElBQUk7QUFDakIsZUFBUyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUM7QUFDN0IseUJBQW1CLElBQUksZUFBZTtBQUN0Qyx5QkFBbUIsSUFBSSxpQkFBaUI7QUFBQSxJQUMxQztBQUFBLElBQ0EsU0FBUyxjQUFjLEtBQUs7QUFBQSxJQUM1QixVQUFVLGNBQWMsSUFBSTtBQUFBLElBQzVCLFFBQVEsSUFBSSxNQUFNO0FBQ2hCLFNBQUcsYUFBYTtBQUNoQixZQUFNLFVBQVUsTUFBTSxZQUFZLElBQUksSUFBSTtBQUMxQyx5QkFBbUIsSUFBSSxjQUFjO0FBQ3JDLFVBQUksQ0FBQyxHQUFHLGlCQUFpQjtBQUN2QixvQkFBWSxFQUFFO0FBQ2QsMkJBQW1CLElBQUksZ0JBQWdCO0FBQUEsTUFDekMsT0FBTztBQUNMLDJCQUFtQixJQUFJLGdCQUFnQjtBQUN2QyxvQkFBWSxFQUFFO0FBQUEsTUFDaEI7QUFDQSxnQkFBVSxNQUFNO0FBQ2QsWUFBSSxDQUFDLEdBQUcsWUFBWTtBQUNsQjtBQUFBLFFBQ0Y7QUFDQSw4QkFBc0IsSUFBSSxjQUFjO0FBQ3hDLDJCQUFtQixJQUFJLFlBQVk7QUFDbkMsWUFBSSxDQUFDLG9CQUFvQixPQUFPLEdBQUc7QUFDakMsNkJBQW1CLElBQUksTUFBTSxlQUFlLE9BQU87QUFBQSxRQUNyRDtBQUFBLE1BQ0YsQ0FBQztBQUNELGVBQVMsU0FBUyxDQUFDLElBQUksT0FBTyxDQUFDO0FBQUEsSUFDakM7QUFBQSxJQUNBLGlCQUFpQixJQUFJO0FBQ25CLGtCQUFZLElBQUksT0FBTyxRQUFRLElBQUk7QUFDbkMsZUFBUyxrQkFBa0IsQ0FBQyxFQUFFLENBQUM7QUFBQSxJQUNqQztBQUFBLElBQ0Esa0JBQWtCLElBQUk7QUFDcEIsa0JBQVksSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUNsQyxlQUFTLG1CQUFtQixDQUFDLEVBQUUsQ0FBQztBQUFBLElBQ2xDO0FBQUEsSUFDQSxpQkFBaUIsSUFBSTtBQUNuQixrQkFBWSxFQUFFO0FBQ2QsZUFBUyxrQkFBa0IsQ0FBQyxFQUFFLENBQUM7QUFBQSxJQUNqQztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVTtBQUNuQyxNQUFJLFlBQVksTUFBTTtBQUNwQixXQUFPO0FBQUEsRUFDVCxXQUFXLFNBQVMsUUFBUSxHQUFHO0FBQzdCLFdBQU8sQ0FBQyxTQUFTLFNBQVMsS0FBSyxHQUFHLFNBQVMsU0FBUyxLQUFLLENBQUM7QUFBQSxFQUM1RCxPQUFPO0FBQ0wsVUFBTSxJQUFJLFNBQVMsUUFBUTtBQUMzQixXQUFPLENBQUMsR0FBRyxDQUFDO0FBQUEsRUFDZDtBQUNGO0FBQ0EsU0FBUyxTQUFTLEtBQUs7QUFDckIsUUFBTSxNQUFNLFNBQVMsR0FBRztBQUN4QixNQUFJLE1BQTJDO0FBQzdDLGlCQUFhLEtBQUssZ0NBQWdDO0FBQUEsRUFDcEQ7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLG1CQUFtQixJQUFJLEtBQUs7QUFDbkMsTUFBSSxNQUFNLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTSxLQUFLLEdBQUcsVUFBVSxJQUFJLENBQUMsQ0FBQztBQUN4RCxHQUFDLEdBQUcsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFvQixvQkFBSSxJQUFJLElBQUksSUFBSSxHQUFHO0FBQ2xFO0FBQ0EsU0FBUyxzQkFBc0IsSUFBSSxLQUFLO0FBQ3RDLE1BQUksTUFBTSxLQUFLLEVBQUUsUUFBUSxDQUFDLE1BQU0sS0FBSyxHQUFHLFVBQVUsT0FBTyxDQUFDLENBQUM7QUFDM0QsUUFBTSxPQUFPLEdBQUcsTUFBTTtBQUN0QixNQUFJLE1BQU07QUFDUixTQUFLLE9BQU8sR0FBRztBQUNmLFFBQUksQ0FBQyxLQUFLLE1BQU07QUFDZCxTQUFHLE1BQU0sSUFBSTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLFVBQVUsSUFBSTtBQUNyQix3QkFBc0IsTUFBTTtBQUMxQiwwQkFBc0IsRUFBRTtBQUFBLEVBQzFCLENBQUM7QUFDSDtBQUNBLElBQUksUUFBUTtBQUNaLFNBQVMsbUJBQW1CLElBQUksY0FBYyxpQkFBaUIsU0FBUztBQUN0RSxRQUFNLEtBQUssR0FBRyxTQUFTLEVBQUU7QUFDekIsUUFBTSxvQkFBb0IsTUFBTTtBQUM5QixRQUFJLE9BQU8sR0FBRyxRQUFRO0FBQ3BCLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUksbUJBQW1CLE1BQU07QUFDM0IsV0FBTyxXQUFXLG1CQUFtQixlQUFlO0FBQUEsRUFDdEQ7QUFDQSxRQUFNLEVBQUUsTUFBTSxTQUFTLFVBQVUsSUFBSSxrQkFBa0IsSUFBSSxZQUFZO0FBQ3ZFLE1BQUksQ0FBQyxNQUFNO0FBQ1QsV0FBTyxRQUFRO0FBQUEsRUFDakI7QUFDQSxRQUFNLFdBQVcsT0FBTztBQUN4QixNQUFJLFFBQVE7QUFDWixRQUFNLE1BQU0sTUFBTTtBQUNoQixPQUFHLG9CQUFvQixVQUFVLEtBQUs7QUFDdEMsc0JBQWtCO0FBQUEsRUFDcEI7QUFDQSxRQUFNLFFBQVEsQ0FBQyxNQUFNO0FBQ25CLFFBQUksRUFBRSxXQUFXLE1BQU0sRUFBRSxTQUFTLFdBQVc7QUFDM0MsVUFBSTtBQUFBLElBQ047QUFBQSxFQUNGO0FBQ0EsYUFBVyxNQUFNO0FBQ2YsUUFBSSxRQUFRLFdBQVc7QUFDckIsVUFBSTtBQUFBLElBQ047QUFBQSxFQUNGLEdBQUcsVUFBVSxDQUFDO0FBQ2QsS0FBRyxpQkFBaUIsVUFBVSxLQUFLO0FBQ3JDO0FBQ0EsU0FBUyxrQkFBa0IsSUFBSSxjQUFjO0FBQzNDLFFBQU0sU0FBUyxPQUFPLGlCQUFpQixFQUFFO0FBQ3pDLFFBQU0scUJBQXFCLENBQUMsU0FBUyxPQUFPLEdBQUcsS0FBSyxJQUFJLE1BQU0sSUFBSTtBQUNsRSxRQUFNLG1CQUFtQixtQkFBbUIsR0FBRyxVQUFVLE9BQU87QUFDaEUsUUFBTSxzQkFBc0IsbUJBQW1CLEdBQUcsVUFBVSxVQUFVO0FBQ3RFLFFBQU0sb0JBQW9CLFdBQVcsa0JBQWtCLG1CQUFtQjtBQUMxRSxRQUFNLGtCQUFrQixtQkFBbUIsR0FBRyxTQUFTLE9BQU87QUFDOUQsUUFBTSxxQkFBcUIsbUJBQW1CLEdBQUcsU0FBUyxVQUFVO0FBQ3BFLFFBQU0sbUJBQW1CLFdBQVcsaUJBQWlCLGtCQUFrQjtBQUN2RSxNQUFJLE9BQU87QUFDWCxNQUFJLFVBQVU7QUFDZCxNQUFJLFlBQVk7QUFDaEIsTUFBSSxpQkFBaUIsWUFBWTtBQUMvQixRQUFJLG9CQUFvQixHQUFHO0FBQ3pCLGFBQU87QUFDUCxnQkFBVTtBQUNWLGtCQUFZLG9CQUFvQjtBQUFBLElBQ2xDO0FBQUEsRUFDRixXQUFXLGlCQUFpQixXQUFXO0FBQ3JDLFFBQUksbUJBQW1CLEdBQUc7QUFDeEIsYUFBTztBQUNQLGdCQUFVO0FBQ1Ysa0JBQVksbUJBQW1CO0FBQUEsSUFDakM7QUFBQSxFQUNGLE9BQU87QUFDTCxjQUFVLEtBQUssSUFBSSxtQkFBbUIsZ0JBQWdCO0FBQ3RELFdBQU8sVUFBVSxJQUFJLG9CQUFvQixtQkFBbUIsYUFBYSxZQUFZO0FBQ3JGLGdCQUFZLE9BQU8sU0FBUyxhQUFhLG9CQUFvQixTQUFTLG1CQUFtQixTQUFTO0FBQUEsRUFDcEc7QUFDQSxRQUFNLGVBQWUsU0FBUyxjQUFjLDZCQUE2QjtBQUFBLElBQ3ZFLG1CQUFtQixHQUFHLFVBQVUsVUFBVSxFQUFFLFNBQVM7QUFBQSxFQUN2RDtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxXQUFXLFFBQVEsV0FBVztBQUNyQyxTQUFPLE9BQU8sU0FBUyxVQUFVLFFBQVE7QUFDdkMsYUFBUyxPQUFPLE9BQU8sTUFBTTtBQUFBLEVBQy9CO0FBQ0EsU0FBTyxLQUFLLElBQUksR0FBRyxVQUFVLElBQUksQ0FBQyxHQUFHLE1BQU0sS0FBSyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkU7QUFDQSxTQUFTLEtBQUssR0FBRztBQUNmLE1BQUksTUFBTSxPQUFRLFFBQU87QUFDekIsU0FBTyxPQUFPLEVBQUUsTUFBTSxHQUFHLEVBQUUsRUFBRSxRQUFRLEtBQUssR0FBRyxDQUFDLElBQUk7QUFDcEQ7QUFDQSxTQUFTLFlBQVksSUFBSTtBQUN2QixRQUFNLGlCQUFpQixLQUFLLEdBQUcsZ0JBQWdCO0FBQy9DLFNBQU8sZUFBZSxLQUFLO0FBQzdCO0FBRUEsU0FBUyxXQUFXLElBQUksT0FBTyxPQUFPO0FBQ3BDLFFBQU0sb0JBQW9CLEdBQUcsTUFBTTtBQUNuQyxNQUFJLG1CQUFtQjtBQUNyQixhQUFTLFFBQVEsQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLElBQUksQ0FBQyxHQUFHLGlCQUFpQixHQUFHLEtBQUssR0FBRztBQUFBLEVBQ25GO0FBQ0EsTUFBSSxTQUFTLE1BQU07QUFDakIsT0FBRyxnQkFBZ0IsT0FBTztBQUFBLEVBQzVCLFdBQVcsT0FBTztBQUNoQixPQUFHLGFBQWEsU0FBUyxLQUFLO0FBQUEsRUFDaEMsT0FBTztBQUNMLE9BQUcsWUFBWTtBQUFBLEVBQ2pCO0FBQ0Y7QUFFQSxNQUFNLHVCQUF1Qyx1QkFBTyxNQUFNO0FBQzFELE1BQU0sY0FBOEIsdUJBQU8sTUFBTTtBQUNqRCxNQUFNLFFBQVE7QUFBQTtBQUFBLEVBRVosTUFBTTtBQUFBLEVBQ04sWUFBWSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsV0FBVyxHQUFHO0FBQ3pDLE9BQUcsb0JBQW9CLElBQUksR0FBRyxNQUFNLFlBQVksU0FBUyxLQUFLLEdBQUcsTUFBTTtBQUN2RSxRQUFJLGNBQWMsT0FBTztBQUN2QixpQkFBVyxZQUFZLEVBQUU7QUFBQSxJQUMzQixPQUFPO0FBQ0wsaUJBQVcsSUFBSSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBQUEsRUFDQSxRQUFRLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxXQUFXLEdBQUc7QUFDckMsUUFBSSxjQUFjLE9BQU87QUFDdkIsaUJBQVcsTUFBTSxFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQUEsRUFDQSxRQUFRLElBQUksRUFBRSxPQUFPLFNBQVMsR0FBRyxFQUFFLFdBQVcsR0FBRztBQUMvQyxRQUFJLENBQUMsVUFBVSxDQUFDLFNBQVU7QUFDMUIsUUFBSSxZQUFZO0FBQ2QsVUFBSSxPQUFPO0FBQ1QsbUJBQVcsWUFBWSxFQUFFO0FBQ3pCLG1CQUFXLElBQUksSUFBSTtBQUNuQixtQkFBVyxNQUFNLEVBQUU7QUFBQSxNQUNyQixPQUFPO0FBQ0wsbUJBQVcsTUFBTSxJQUFJLE1BQU07QUFDekIscUJBQVcsSUFBSSxLQUFLO0FBQUEsUUFDdEIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLE9BQU87QUFDTCxpQkFBVyxJQUFJLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLGNBQWMsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUMzQixlQUFXLElBQUksS0FBSztBQUFBLEVBQ3RCO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsSUFBSSxPQUFPO0FBQzdCLEtBQUcsTUFBTSxVQUFVLFFBQVEsR0FBRyxvQkFBb0IsSUFBSTtBQUN0RCxLQUFHLFdBQVcsSUFBSSxDQUFDO0FBQ3JCO0FBQ0EsU0FBUyxrQkFBa0I7QUFDekIsUUFBTSxjQUFjLENBQUMsRUFBRSxNQUFNLE1BQU07QUFDakMsUUFBSSxDQUFDLE9BQU87QUFDVixhQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsT0FBTyxFQUFFO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxNQUFNLGVBQStCLHVCQUFPLE9BQTRDLGlCQUFpQixFQUFFO0FBQzNHLFNBQVMsV0FBVyxRQUFRO0FBQzFCLFFBQU0sV0FBVyxtQkFBbUI7QUFDcEMsTUFBSSxDQUFDLFVBQVU7QUFDYixJQUE2QyxLQUFLLGlFQUFpRTtBQUNuSDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGtCQUFrQixTQUFTLEtBQUssQ0FBQyxPQUFPLE9BQU8sU0FBUyxLQUFLLE1BQU07QUFDdkUsVUFBTTtBQUFBLE1BQ0osU0FBUyxpQkFBaUIsa0JBQWtCLFNBQVMsR0FBRyxJQUFJO0FBQUEsSUFDOUQsRUFBRSxRQUFRLENBQUMsU0FBUyxjQUFjLE1BQU0sSUFBSSxDQUFDO0FBQUEsRUFDL0M7QUFDQSxNQUFJLE1BQTJDO0FBQzdDLGFBQVMsYUFBYSxNQUFNLE9BQU8sU0FBUyxLQUFLO0FBQUEsRUFDbkQ7QUFDQSxRQUFNLFVBQVUsTUFBTTtBQUNwQixVQUFNLE9BQU8sT0FBTyxTQUFTLEtBQUs7QUFDbEMsUUFBSSxTQUFTLElBQUk7QUFDZixvQkFBYyxTQUFTLElBQUksSUFBSTtBQUFBLElBQ2pDLE9BQU87QUFDTCxxQkFBZSxTQUFTLFNBQVMsSUFBSTtBQUFBLElBQ3ZDO0FBQ0Esb0JBQWdCLElBQUk7QUFBQSxFQUN0QjtBQUNBLGlCQUFlLE1BQU07QUFDbkIscUJBQWlCLE9BQU87QUFBQSxFQUMxQixDQUFDO0FBQ0QsWUFBVSxNQUFNO0FBQ2QsVUFBTSxTQUFTLE1BQU0sRUFBRSxPQUFPLE9BQU8sQ0FBQztBQUN0QyxVQUFNLEtBQUssSUFBSSxpQkFBaUIsT0FBTztBQUN2QyxPQUFHLFFBQVEsU0FBUyxRQUFRLEdBQUcsWUFBWSxFQUFFLFdBQVcsS0FBSyxDQUFDO0FBQzlELGdCQUFZLE1BQU0sR0FBRyxXQUFXLENBQUM7QUFBQSxFQUNuQyxDQUFDO0FBQ0g7QUFDQSxTQUFTLGVBQWUsT0FBTyxNQUFNO0FBQ25DLE1BQUksTUFBTSxZQUFZLEtBQUs7QUFDekIsVUFBTSxXQUFXLE1BQU07QUFDdkIsWUFBUSxTQUFTO0FBQ2pCLFFBQUksU0FBUyxpQkFBaUIsQ0FBQyxTQUFTLGFBQWE7QUFDbkQsZUFBUyxRQUFRLEtBQUssTUFBTTtBQUMxQix1QkFBZSxTQUFTLGNBQWMsSUFBSTtBQUFBLE1BQzVDLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNBLFNBQU8sTUFBTSxXQUFXO0FBQ3RCLFlBQVEsTUFBTSxVQUFVO0FBQUEsRUFDMUI7QUFDQSxNQUFJLE1BQU0sWUFBWSxLQUFLLE1BQU0sSUFBSTtBQUNuQyxrQkFBYyxNQUFNLElBQUksSUFBSTtBQUFBLEVBQzlCLFdBQVcsTUFBTSxTQUFTLFVBQVU7QUFDbEMsVUFBTSxTQUFTLFFBQVEsQ0FBQyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUM7QUFBQSxFQUN2RCxXQUFXLE1BQU0sU0FBUyxRQUFRO0FBQ2hDLFFBQUksRUFBRSxJQUFJLE9BQU8sSUFBSTtBQUNyQixXQUFPLElBQUk7QUFDVCxvQkFBYyxJQUFJLElBQUk7QUFDdEIsVUFBSSxPQUFPLE9BQVE7QUFDbkIsV0FBSyxHQUFHO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsY0FBYyxJQUFJLE1BQU07QUFDL0IsTUFBSSxHQUFHLGFBQWEsR0FBRztBQUNyQixVQUFNLFFBQVEsR0FBRztBQUNqQixRQUFJLFVBQVU7QUFDZCxlQUFXLE9BQU8sTUFBTTtBQUN0QixZQUFNLFFBQVEscUJBQXFCLEtBQUssR0FBRyxDQUFDO0FBQzVDLFlBQU0sWUFBWSxLQUFLLEdBQUcsSUFBSSxLQUFLO0FBQ25DLGlCQUFXLEtBQUssR0FBRyxLQUFLLEtBQUs7QUFBQSxJQUMvQjtBQUNBLFVBQU0sWUFBWSxJQUFJO0FBQUEsRUFDeEI7QUFDRjtBQUVBLE1BQU0sWUFBWTtBQUNsQixTQUFTLFdBQVcsSUFBSSxNQUFNLE1BQU07QUFDbEMsUUFBTSxRQUFRLEdBQUc7QUFDakIsUUFBTSxjQUFjLFNBQVMsSUFBSTtBQUNqQyxNQUFJLHVCQUF1QjtBQUMzQixNQUFJLFFBQVEsQ0FBQyxhQUFhO0FBQ3hCLFFBQUksTUFBTTtBQUNSLFVBQUksQ0FBQyxTQUFTLElBQUksR0FBRztBQUNuQixtQkFBVyxPQUFPLE1BQU07QUFDdEIsY0FBSSxLQUFLLEdBQUcsS0FBSyxNQUFNO0FBQ3JCLHFCQUFTLE9BQU8sS0FBSyxFQUFFO0FBQUEsVUFDekI7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsbUJBQVcsYUFBYSxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQ3ZDLGdCQUFNLE1BQU0sVUFBVSxNQUFNLEdBQUcsVUFBVSxRQUFRLEdBQUcsQ0FBQyxFQUFFLEtBQUs7QUFDNUQsY0FBSSxLQUFLLEdBQUcsS0FBSyxNQUFNO0FBQ3JCLHFCQUFTLE9BQU8sS0FBSyxFQUFFO0FBQUEsVUFDekI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxlQUFXLE9BQU8sTUFBTTtBQUN0QixVQUFJLFFBQVEsV0FBVztBQUNyQiwrQkFBdUI7QUFBQSxNQUN6QjtBQUNBLFlBQU0sUUFBUSxLQUFLLEdBQUc7QUFDdEIsVUFBSSxTQUFTLE1BQU07QUFDakIsWUFBSSxDQUFDO0FBQUEsVUFDSDtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsU0FBUyxJQUFJLEtBQUssT0FBTyxLQUFLLEdBQUcsSUFBSTtBQUFBLFVBQ3RDO0FBQUEsUUFDRixHQUFHO0FBQ0QsbUJBQVMsT0FBTyxLQUFLLEtBQUs7QUFBQSxRQUM1QjtBQUFBLE1BQ0YsT0FBTztBQUNMLGlCQUFTLE9BQU8sS0FBSyxFQUFFO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQUEsRUFDRixPQUFPO0FBQ0wsUUFBSSxhQUFhO0FBQ2YsVUFBSSxTQUFTLE1BQU07QUFDakIsY0FBTSxhQUFhLE1BQU0sWUFBWTtBQUNyQyxZQUFJLFlBQVk7QUFDZCxrQkFBUSxNQUFNO0FBQUEsUUFDaEI7QUFDQSxjQUFNLFVBQVU7QUFDaEIsK0JBQXVCLFVBQVUsS0FBSyxJQUFJO0FBQUEsTUFDNUM7QUFBQSxJQUNGLFdBQVcsTUFBTTtBQUNmLFNBQUcsZ0JBQWdCLE9BQU87QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLHdCQUF3QixJQUFJO0FBQzlCLE9BQUcsb0JBQW9CLElBQUksdUJBQXVCLE1BQU0sVUFBVTtBQUNsRSxRQUFJLEdBQUcsV0FBVyxHQUFHO0FBQ25CLFlBQU0sVUFBVTtBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxjQUFjO0FBQ3BCLE1BQU0sY0FBYztBQUNwQixTQUFTLFNBQVMsT0FBTyxNQUFNLEtBQUs7QUFDbEMsTUFBSSxRQUFRLEdBQUcsR0FBRztBQUNoQixRQUFJLFFBQVEsQ0FBQyxNQUFNLFNBQVMsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzdDLE9BQU87QUFDTCxRQUFJLE9BQU8sS0FBTSxPQUFNO0FBQ3ZCLFFBQUksTUFBMkM7QUFDN0MsVUFBSSxZQUFZLEtBQUssR0FBRyxHQUFHO0FBQ3pCO0FBQUEsVUFDRSx1Q0FBdUMsSUFBSSxtQkFBbUIsR0FBRztBQUFBLFFBQ25FO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFJLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFDekIsWUFBTSxZQUFZLE1BQU0sR0FBRztBQUFBLElBQzdCLE9BQU87QUFDTCxZQUFNLFdBQVcsV0FBVyxPQUFPLElBQUk7QUFDdkMsVUFBSSxZQUFZLEtBQUssR0FBRyxHQUFHO0FBQ3pCLGNBQU07QUFBQSxVQUNKLFVBQVUsUUFBUTtBQUFBLFVBQ2xCLElBQUksUUFBUSxhQUFhLEVBQUU7QUFBQSxVQUMzQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLE1BQU0sV0FBVyxDQUFDLFVBQVUsT0FBTyxJQUFJO0FBQ3ZDLE1BQU0sY0FBYyxDQUFDO0FBQ3JCLFNBQVMsV0FBVyxPQUFPLFNBQVM7QUFDbEMsUUFBTSxTQUFTLFlBQVksT0FBTztBQUNsQyxNQUFJLFFBQVE7QUFDVixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksT0FBTyxTQUFTLE9BQU87QUFDM0IsTUFBSSxTQUFTLFlBQVksUUFBUSxPQUFPO0FBQ3RDLFdBQU8sWUFBWSxPQUFPLElBQUk7QUFBQSxFQUNoQztBQUNBLFNBQU8sV0FBVyxJQUFJO0FBQ3RCLFdBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDeEMsVUFBTSxXQUFXLFNBQVMsQ0FBQyxJQUFJO0FBQy9CLFFBQUksWUFBWSxPQUFPO0FBQ3JCLGFBQU8sWUFBWSxPQUFPLElBQUk7QUFBQSxJQUNoQztBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGtDQUFrQyxJQUFJLEtBQUssTUFBTSxNQUFNO0FBQzlELFNBQU8sR0FBRyxZQUFZLGVBQWUsUUFBUSxXQUFXLFFBQVEsYUFBYSxTQUFTLElBQUksS0FBSyxTQUFTO0FBQzFHO0FBRUEsTUFBTSxVQUFVO0FBQ2hCLFNBQVMsVUFBVSxJQUFJLEtBQUssT0FBTyxPQUFPLFVBQVUsWUFBWSxxQkFBcUIsR0FBRyxHQUFHO0FBQ3pGLE1BQUksU0FBUyxJQUFJLFdBQVcsUUFBUSxHQUFHO0FBQ3JDLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFNBQUcsa0JBQWtCLFNBQVMsSUFBSSxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUM7QUFBQSxJQUN4RCxPQUFPO0FBQ0wsU0FBRyxlQUFlLFNBQVMsS0FBSyxLQUFLO0FBQUEsSUFDdkM7QUFBQSxFQUNGLE9BQU87QUFDTCxRQUFJLFNBQVMsUUFBUSxhQUFhLENBQUMsbUJBQW1CLEtBQUssR0FBRztBQUM1RCxTQUFHLGdCQUFnQixHQUFHO0FBQUEsSUFDeEIsT0FBTztBQUNMLFNBQUc7QUFBQSxRQUNEO0FBQUEsUUFDQSxZQUFZLEtBQUssU0FBUyxLQUFLLElBQUksT0FBTyxLQUFLLElBQUk7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsSUFBSSxLQUFLLE9BQU8saUJBQWlCLFVBQVU7QUFDL0QsTUFBSSxRQUFRLGVBQWUsUUFBUSxlQUFlO0FBQ2hELFFBQUksU0FBUyxNQUFNO0FBQ2pCLFNBQUcsR0FBRyxJQUFJLFFBQVEsY0FBYyxvQkFBb0IsS0FBSyxJQUFJO0FBQUEsSUFDL0Q7QUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE1BQU0sR0FBRztBQUNmLE1BQUksUUFBUSxXQUFXLFFBQVE7QUFBQSxFQUMvQixDQUFDLElBQUksU0FBUyxHQUFHLEdBQUc7QUFDbEIsVUFBTSxXQUFXLFFBQVEsV0FBVyxHQUFHLGFBQWEsT0FBTyxLQUFLLEtBQUssR0FBRztBQUN4RSxVQUFNLFdBQVcsU0FBUztBQUFBO0FBQUE7QUFBQSxNQUd4QixHQUFHLFNBQVMsYUFBYSxPQUFPO0FBQUEsUUFDOUIsT0FBTyxLQUFLO0FBQ2hCLFFBQUksYUFBYSxZQUFZLEVBQUUsWUFBWSxLQUFLO0FBQzlDLFNBQUcsUUFBUTtBQUFBLElBQ2I7QUFDQSxRQUFJLFNBQVMsTUFBTTtBQUNqQixTQUFHLGdCQUFnQixHQUFHO0FBQUEsSUFDeEI7QUFDQSxPQUFHLFNBQVM7QUFDWjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGFBQWE7QUFDakIsTUFBSSxVQUFVLE1BQU0sU0FBUyxNQUFNO0FBQ2pDLFVBQU0sT0FBTyxPQUFPLEdBQUcsR0FBRztBQUMxQixRQUFJLFNBQVMsV0FBVztBQUN0QixjQUFRLG1CQUFtQixLQUFLO0FBQUEsSUFDbEMsV0FBVyxTQUFTLFFBQVEsU0FBUyxVQUFVO0FBQzdDLGNBQVE7QUFDUixtQkFBYTtBQUFBLElBQ2YsV0FBVyxTQUFTLFVBQVU7QUFDNUIsY0FBUTtBQUNSLG1CQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsT0FBRyxHQUFHLElBQUk7QUFBQSxFQUNaLFNBQVMsR0FBRztBQUNWLFFBQWlELENBQUMsWUFBWTtBQUM1RDtBQUFBLFFBQ0Usd0JBQXdCLEdBQUcsU0FBUyxJQUFJLFlBQVksQ0FBQyxZQUFZLEtBQUs7QUFBQSxRQUN0RTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLGdCQUFjLEdBQUcsZ0JBQWdCLFlBQVksR0FBRztBQUNsRDtBQUVBLFNBQVMsaUJBQWlCLElBQUksT0FBTyxTQUFTLFNBQVM7QUFDckQsS0FBRyxpQkFBaUIsT0FBTyxTQUFTLE9BQU87QUFDN0M7QUFDQSxTQUFTLG9CQUFvQixJQUFJLE9BQU8sU0FBUyxTQUFTO0FBQ3hELEtBQUcsb0JBQW9CLE9BQU8sU0FBUyxPQUFPO0FBQ2hEO0FBQ0EsTUFBTSxTQUF5Qix1QkFBTyxNQUFNO0FBQzVDLFNBQVMsV0FBVyxJQUFJLFNBQVMsV0FBVyxXQUFXLFdBQVcsTUFBTTtBQUN0RSxRQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztBQUM5QyxRQUFNLGtCQUFrQixTQUFTLE9BQU87QUFDeEMsTUFBSSxhQUFhLGlCQUFpQjtBQUNoQyxvQkFBZ0IsUUFBUSxPQUE0QyxtQkFBbUIsV0FBVyxPQUFPLElBQUk7QUFBQSxFQUMvRyxPQUFPO0FBQ0wsVUFBTSxDQUFDLE1BQU0sT0FBTyxJQUFJLFVBQVUsT0FBTztBQUN6QyxRQUFJLFdBQVc7QUFDYixZQUFNLFVBQVUsU0FBUyxPQUFPLElBQUk7QUFBQSxRQUNsQyxPQUE0QyxtQkFBbUIsV0FBVyxPQUFPLElBQUk7QUFBQSxRQUNyRjtBQUFBLE1BQ0Y7QUFDQSx1QkFBaUIsSUFBSSxNQUFNLFNBQVMsT0FBTztBQUFBLElBQzdDLFdBQVcsaUJBQWlCO0FBQzFCLDBCQUFvQixJQUFJLE1BQU0saUJBQWlCLE9BQU87QUFDdEQsZUFBUyxPQUFPLElBQUk7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0seUJBQXlCO0FBQy9CLFNBQVMsVUFBVSxNQUFNO0FBQ3ZCLE1BQUk7QUFDSixNQUFJO0FBQ0osVUFBUSxJQUFJLEtBQUssTUFBTSxpQkFBaUIsTUFBTSxDQUFDLHVCQUF1QixLQUFLLElBQUksR0FBRztBQUNoRixRQUFJLENBQUMsUUFBUyxXQUFVLENBQUM7QUFDekIsV0FBTyxLQUFLLE1BQU0sR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDLEVBQUUsTUFBTTtBQUM5QyxZQUFRLEVBQUUsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJO0FBQUEsRUFDaEM7QUFDQSxRQUFNLFFBQVEsS0FBSyxDQUFDLE1BQU0sTUFBTSxLQUFLLE1BQU0sQ0FBQyxJQUFJLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQztBQUN2RSxTQUFPLENBQUMsT0FBTyxPQUFPO0FBQ3hCO0FBQ0EsSUFBSSxZQUFZO0FBQ2hCLE1BQU0sSUFBb0Isd0JBQVEsUUFBUTtBQUMxQyxNQUFNLFNBQVMsTUFBTSxjQUFjLEVBQUUsS0FBSyxNQUFNLFlBQVksQ0FBQyxHQUFHLFlBQVksS0FBSyxJQUFJO0FBQ3JGLFNBQVMsY0FBYyxjQUFjLFVBQVU7QUFDN0MsUUFBTSxVQUFVLENBQUMsTUFBTTtBQUNyQixRQUFJLENBQUMsRUFBRSxNQUFNO0FBQ1gsUUFBRSxPQUFPLEtBQUssSUFBSTtBQUFBLElBQ3BCLFdBQVcsRUFBRSxRQUFRLFFBQVEsVUFBVTtBQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLFFBQVEsUUFBUTtBQUN0QixRQUFJLFFBQVEsS0FBSyxHQUFHO0FBQ2xCLFlBQU0sZUFBZSxFQUFFO0FBQ3ZCLFFBQUUsMkJBQTJCLE1BQU07QUFDakMscUJBQWEsS0FBSyxDQUFDO0FBQ25CLFVBQUUsV0FBVztBQUFBLE1BQ2Y7QUFDQSxZQUFNLFdBQVcsTUFBTSxNQUFNO0FBQzdCLFlBQU0sT0FBTyxDQUFDLENBQUM7QUFDZixlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3hDLFlBQUksRUFBRSxVQUFVO0FBQ2Q7QUFBQSxRQUNGO0FBQ0EsY0FBTSxVQUFVLFNBQVMsQ0FBQztBQUMxQixZQUFJLFNBQVM7QUFDWDtBQUFBLFlBQ0U7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLE9BQU87QUFDTDtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsQ0FBQyxDQUFDO0FBQUEsTUFDSjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsVUFBUSxRQUFRO0FBQ2hCLFVBQVEsV0FBVyxPQUFPO0FBQzFCLFNBQU87QUFDVDtBQUNBLFNBQVMsbUJBQW1CLE9BQU8sVUFBVTtBQUMzQyxNQUFJLFdBQVcsS0FBSyxLQUFLLFFBQVEsS0FBSyxHQUFHO0FBQ3ZDLFdBQU87QUFBQSxFQUNUO0FBQ0E7QUFBQSxJQUNFLHlDQUF5QyxRQUFRO0FBQUEseURBQ0ksT0FBTyxLQUFLO0FBQUEsRUFDbkU7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxNQUFNLGFBQWEsQ0FBQyxRQUFRLElBQUksV0FBVyxDQUFDLE1BQU0sT0FBTyxJQUFJLFdBQVcsQ0FBQyxNQUFNO0FBQy9FLElBQUksV0FBVyxDQUFDLElBQUksTUFBTSxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzlDLE1BQU0sWUFBWSxDQUFDLElBQUksS0FBSyxXQUFXLFdBQVcsV0FBVyxvQkFBb0I7QUFDL0UsUUFBTSxRQUFRLGNBQWM7QUFDNUIsTUFBSSxRQUFRLFNBQVM7QUFDbkIsZUFBVyxJQUFJLFdBQVcsS0FBSztBQUFBLEVBQ2pDLFdBQVcsUUFBUSxTQUFTO0FBQzFCLGVBQVcsSUFBSSxXQUFXLFNBQVM7QUFBQSxFQUNyQyxXQUFXLEtBQUssR0FBRyxHQUFHO0FBQ3BCLFFBQUksQ0FBQyxnQkFBZ0IsR0FBRyxHQUFHO0FBQ3pCLGlCQUFXLElBQUksS0FBSyxXQUFXLFdBQVcsZUFBZTtBQUFBLElBQzNEO0FBQUEsRUFDRixXQUFXLElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxJQUFJLE1BQU0sQ0FBQyxHQUFHLFFBQVEsSUFBSSxDQUFDLE1BQU0sT0FBTyxNQUFNLElBQUksTUFBTSxDQUFDLEdBQUcsU0FBUyxnQkFBZ0IsSUFBSSxLQUFLLFdBQVcsS0FBSyxHQUFHO0FBQ2xKLGlCQUFhLElBQUksS0FBSyxTQUFTO0FBQy9CLFFBQUksQ0FBQyxHQUFHLFFBQVEsU0FBUyxHQUFHLE1BQU0sUUFBUSxXQUFXLFFBQVEsYUFBYSxRQUFRLGFBQWE7QUFDN0YsZ0JBQVUsSUFBSSxLQUFLLFdBQVcsT0FBTyxpQkFBaUIsUUFBUSxPQUFPO0FBQUEsSUFDdkU7QUFBQSxFQUNGO0FBQUE7QUFBQSxJQUVFLEdBQUc7QUFBQSxLQUNGLHdCQUF3QixJQUFJLEdBQUc7QUFBQSxJQUNoQyxHQUFHLEtBQUssa0JBQWtCLFFBQVEsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLFNBQVM7QUFBQSxJQUNsRTtBQUNBLGlCQUFhLElBQUksV0FBVyxHQUFHLEdBQUcsV0FBVyxpQkFBaUIsR0FBRztBQUFBLEVBQ25FLE9BQU87QUFDTCxRQUFJLFFBQVEsY0FBYztBQUN4QixTQUFHLGFBQWE7QUFBQSxJQUNsQixXQUFXLFFBQVEsZUFBZTtBQUNoQyxTQUFHLGNBQWM7QUFBQSxJQUNuQjtBQUNBLGNBQVUsSUFBSSxLQUFLLFdBQVcsS0FBSztBQUFBLEVBQ3JDO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixJQUFJLEtBQUssT0FBTyxPQUFPO0FBQzlDLE1BQUksT0FBTztBQUNULFFBQUksUUFBUSxlQUFlLFFBQVEsZUFBZTtBQUNoRCxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksT0FBTyxNQUFNLFdBQVcsR0FBRyxLQUFLLFdBQVcsS0FBSyxHQUFHO0FBQ3JELGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFFBQVEsZ0JBQWdCLFFBQVEsZUFBZSxRQUFRLGVBQWUsUUFBUSxlQUFlO0FBQy9GLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxRQUFRLGFBQWEsR0FBRyxZQUFZLFVBQVU7QUFDaEQsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFFBQVEsUUFBUTtBQUNsQixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksUUFBUSxVQUFVLEdBQUcsWUFBWSxTQUFTO0FBQzVDLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxRQUFRLFVBQVUsR0FBRyxZQUFZLFlBQVk7QUFDL0MsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFFBQVEsV0FBVyxRQUFRLFVBQVU7QUFDdkMsVUFBTSxNQUFNLEdBQUc7QUFDZixRQUFJLFFBQVEsU0FBUyxRQUFRLFdBQVcsUUFBUSxZQUFZLFFBQVEsVUFBVTtBQUM1RSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsR0FBRyxLQUFLLFNBQVMsS0FBSyxHQUFHO0FBQ3RDLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTyxPQUFPO0FBQ2hCO0FBQ0EsU0FBUyx3QkFBd0IsSUFBSSxLQUFLO0FBQ3hDLFFBQU07QUFBQTtBQUFBLElBRUosR0FBRyxLQUFLO0FBQUE7QUFFVixNQUFJLENBQUMsT0FBTztBQUNWLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxXQUFXLFdBQVcsR0FBRztBQUMvQixTQUFPLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxLQUFLLENBQUMsU0FBUyxXQUFXLElBQUksTUFBTSxRQUFRLElBQUksT0FBTyxLQUFLLEtBQUssRUFBRSxLQUFLLENBQUMsU0FBUyxXQUFXLElBQUksTUFBTSxRQUFRO0FBQ3JKO0FBRUEsTUFBTSxVQUFVLENBQUM7QUFBQTtBQUVqQixTQUFTLG9CQUFvQixTQUFTLGNBQWMsWUFBWTtBQUM5RCxNQUFJLE9BQU8sZ0JBQWdCLFNBQVMsWUFBWTtBQUNoRCxNQUFJLGNBQWMsSUFBSSxFQUFHLFFBQU8sT0FBTyxDQUFDLEdBQUcsTUFBTSxZQUFZO0FBQUEsRUFDN0QsTUFBTSx5QkFBeUIsV0FBVztBQUFBLElBQ3hDLFlBQVksY0FBYztBQUN4QixZQUFNLE1BQU0sY0FBYyxVQUFVO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBQ0EsbUJBQWlCLE1BQU07QUFDdkIsU0FBTztBQUNUO0FBQ0EsTUFBTSxxREFBcUQsQ0FBQyxTQUFTLGlCQUFpQjtBQUNwRixTQUF1QixvQ0FBb0IsU0FBUyxjQUFjLFlBQVk7QUFDaEY7QUFDQSxNQUFNLFlBQVksT0FBTyxnQkFBZ0IsY0FBYyxjQUFjLE1BQU07QUFDM0U7QUFDQSxNQUFNLG1CQUFtQixVQUFVO0FBQUEsRUFDakMsWUFBWSxNQUFNLFNBQVMsQ0FBQyxHQUFHLGFBQWEsV0FBVztBQUNyRCxVQUFNO0FBQ04sU0FBSyxPQUFPO0FBQ1osU0FBSyxTQUFTO0FBQ2QsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUloQixTQUFLLFlBQVk7QUFJakIsU0FBSyxPQUFPO0FBSVosU0FBSyxTQUFTLEtBQUssS0FBSztBQUN4QixTQUFLLGFBQWE7QUFDbEIsU0FBSyxZQUFZO0FBQ2pCLFNBQUssWUFBWTtBQUNqQixTQUFLLFNBQVM7QUFDZCxTQUFLLGVBQWU7QUFDcEIsU0FBSyxpQkFBaUMsb0JBQUksUUFBUTtBQUNsRCxTQUFLLGdCQUFnQyxvQkFBSSxRQUFRO0FBQ2pELFNBQUssTUFBTTtBQUNYLFFBQUksS0FBSyxjQUFjLGVBQWUsV0FBVztBQUMvQyxXQUFLLFFBQVEsS0FBSztBQUFBLElBQ3BCLE9BQU87QUFDTCxVQUFpRCxLQUFLLFlBQVk7QUFDaEU7QUFBQSxVQUNFO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssZUFBZSxPQUFPO0FBQzdCLGFBQUs7QUFBQSxVQUNILE9BQU8sQ0FBQyxHQUFHLEtBQUssbUJBQW1CO0FBQUEsWUFDakMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFDQSxhQUFLLFFBQVEsS0FBSztBQUFBLE1BQ3BCLE9BQU87QUFDTCxhQUFLLFFBQVE7QUFBQSxNQUNmO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLG9CQUFvQjtBQUNsQixRQUFJLENBQUMsS0FBSyxZQUFhO0FBQ3ZCLFFBQUksQ0FBQyxLQUFLLGNBQWMsQ0FBQyxLQUFLLFdBQVc7QUFDdkMsV0FBSyxZQUFZO0FBQUEsSUFDbkI7QUFDQSxTQUFLLGFBQWE7QUFDbEIsUUFBSSxTQUFTO0FBQ2IsV0FBTyxTQUFTO0FBQUEsS0FDZixPQUFPLGdCQUFnQixPQUFPLGNBQWMsT0FBTyxPQUFPO0FBQ3pELFVBQUksa0JBQWtCLFlBQVk7QUFDaEMsYUFBSyxVQUFVO0FBQ2Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxLQUFLLFdBQVc7QUFDbkIsVUFBSSxLQUFLLFdBQVc7QUFDbEIsYUFBSyxPQUFPLEtBQUssSUFBSTtBQUFBLE1BQ3ZCLE9BQU87QUFDTCxZQUFJLFVBQVUsT0FBTyxpQkFBaUI7QUFDcEMsZUFBSyxrQkFBa0IsT0FBTyxnQkFBZ0IsS0FBSyxNQUFNO0FBQ3ZELGlCQUFLLGtCQUFrQjtBQUN2QixnQkFBSSxLQUFLLGFBQWE7QUFDcEIscUJBQU8sS0FBSyxZQUFZO0FBQUEsWUFDMUI7QUFBQSxVQUNGLENBQUM7QUFBQSxRQUNILE9BQU87QUFDTCxlQUFLLFlBQVk7QUFBQSxRQUNuQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVyxTQUFTLEtBQUssU0FBUztBQUNoQyxRQUFJLFFBQVE7QUFDVixXQUFLLFVBQVUsU0FBUyxPQUFPO0FBQy9CLFdBQUssc0JBQXNCLE1BQU07QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFBQSxFQUNBLHNCQUFzQixTQUFTLEtBQUssU0FBUztBQUMzQyxRQUFJLFVBQVUsS0FBSyxNQUFNO0FBQ3ZCLGFBQU87QUFBQSxRQUNMLEtBQUssS0FBSyxTQUFTO0FBQUEsUUFDbkIsT0FBTyxVQUFVO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsdUJBQXVCO0FBQ3JCLFNBQUssYUFBYTtBQUNsQixhQUFTLE1BQU07QUFDYixVQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLFlBQUksS0FBSyxLQUFLO0FBQ1osZUFBSyxJQUFJLFdBQVc7QUFDcEIsZUFBSyxNQUFNO0FBQUEsUUFDYjtBQUNBLGFBQUssUUFBUSxLQUFLLEtBQUssUUFBUTtBQUMvQixZQUFJLEtBQUssVUFBVyxNQUFLLFVBQVUsS0FBSztBQUN4QyxhQUFLLE9BQU8sS0FBSyxZQUFZO0FBQzdCLFlBQUksS0FBSyxrQkFBa0I7QUFDekIsZUFBSyxpQkFBaUIsTUFBTTtBQUM1QixlQUFLLG1CQUFtQjtBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUNBLGtCQUFrQixXQUFXO0FBQzNCLGVBQVcsS0FBSyxXQUFXO0FBQ3pCLFdBQUssU0FBUyxFQUFFLGFBQWE7QUFBQSxJQUMvQjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLGNBQWM7QUFDWixRQUFJLEtBQUssaUJBQWlCO0FBQ3hCLGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFDQSxhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssV0FBVyxRQUFRLEtBQUs7QUFDL0MsV0FBSyxTQUFTLEtBQUssV0FBVyxDQUFDLEVBQUUsSUFBSTtBQUFBLElBQ3ZDO0FBQ0EsU0FBSyxNQUFNLElBQUksaUJBQWlCLEtBQUssa0JBQWtCLEtBQUssSUFBSSxDQUFDO0FBQ2pFLFNBQUssSUFBSSxRQUFRLE1BQU0sRUFBRSxZQUFZLEtBQUssQ0FBQztBQUMzQyxVQUFNLFVBQVUsQ0FBQyxLQUFLLFVBQVUsVUFBVTtBQUN4QyxXQUFLLFlBQVk7QUFDakIsV0FBSyxrQkFBa0I7QUFDdkIsWUFBTSxFQUFFLE9BQU8sT0FBTyxJQUFJO0FBQzFCLFVBQUk7QUFDSixVQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssR0FBRztBQUM1QixtQkFBVyxPQUFPLE9BQU87QUFDdkIsZ0JBQU0sTUFBTSxNQUFNLEdBQUc7QUFDckIsY0FBSSxRQUFRLFVBQVUsT0FBTyxJQUFJLFNBQVMsUUFBUTtBQUNoRCxnQkFBSSxPQUFPLEtBQUssUUFBUTtBQUN0QixtQkFBSyxPQUFPLEdBQUcsSUFBSSxTQUFTLEtBQUssT0FBTyxHQUFHLENBQUM7QUFBQSxZQUM5QztBQUNBLGFBQUMsZ0JBQWdCLGNBQThCLHVCQUFPLE9BQU8sSUFBSSxJQUFJLFdBQVcsR0FBRyxDQUFDLElBQUk7QUFBQSxVQUMxRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsV0FBSyxlQUFlO0FBQ3BCLFdBQUssY0FBYyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxZQUFZO0FBQ25CLGFBQUssYUFBYSxNQUFNO0FBQUEsTUFDMUIsV0FBd0QsUUFBUTtBQUM5RDtBQUFBLFVBQ0U7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFdBQUssT0FBTyxHQUFHO0FBQUEsSUFDakI7QUFDQSxVQUFNLFdBQVcsS0FBSyxLQUFLO0FBQzNCLFFBQUksVUFBVTtBQUNaLFdBQUssa0JBQWtCLFNBQVMsRUFBRSxLQUFLLENBQUMsUUFBUTtBQUM5QyxZQUFJLGVBQWUsS0FBSyxLQUFLO0FBQzdCLGdCQUFRLEtBQUssT0FBTyxLQUFLLElBQUk7QUFBQSxNQUMvQixDQUFDO0FBQ0QsYUFBTyxLQUFLO0FBQUEsSUFDZCxPQUFPO0FBQ0wsY0FBUSxLQUFLLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE9BQU8sS0FBSztBQUNWLFFBQTRFLENBQUMsSUFBSSxNQUFNO0FBQ3JGLFVBQUksT0FBTztBQUFBLElBQ2I7QUFDQSxTQUFLLE9BQU8sS0FBSyxXQUFXLEdBQUc7QUFDL0IsU0FBSyxzQkFBc0I7QUFDM0IsUUFBSSxJQUFJLGNBQWM7QUFDcEIsVUFBSSxhQUFhLEtBQUssSUFBSTtBQUFBLElBQzVCO0FBQ0EsU0FBSyxLQUFLLFdBQVcsS0FBSyxhQUFhO0FBQ3ZDLFNBQUssS0FBSyxNQUFNLEtBQUssS0FBSztBQUMxQixVQUFNLFVBQVUsS0FBSyxhQUFhLEtBQUssVUFBVTtBQUNqRCxRQUFJLENBQUMsUUFBUztBQUNkLGVBQVcsT0FBTyxTQUFTO0FBQ3pCLFVBQUksQ0FBQyxPQUFPLE1BQU0sR0FBRyxHQUFHO0FBQ3RCLGVBQU8sZUFBZSxNQUFNLEtBQUs7QUFBQTtBQUFBLFVBRS9CLEtBQUssTUFBTSxNQUFNLFFBQVEsR0FBRyxDQUFDO0FBQUEsUUFDL0IsQ0FBQztBQUFBLE1BQ0gsV0FBVyxNQUEyQztBQUNwRCxhQUFLLHFCQUFxQixHQUFHLHFDQUFxQztBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLGNBQWMsS0FBSztBQUNqQixVQUFNLEVBQUUsTUFBTSxJQUFJO0FBQ2xCLFVBQU0sbUJBQW1CLFFBQVEsS0FBSyxJQUFJLFFBQVEsT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQ3pFLGVBQVcsT0FBTyxPQUFPLEtBQUssSUFBSSxHQUFHO0FBQ25DLFVBQUksSUFBSSxDQUFDLE1BQU0sT0FBTyxpQkFBaUIsU0FBUyxHQUFHLEdBQUc7QUFDcEQsYUFBSyxTQUFTLEtBQUssS0FBSyxHQUFHLENBQUM7QUFBQSxNQUM5QjtBQUFBLElBQ0Y7QUFDQSxlQUFXLE9BQU8saUJBQWlCLElBQUksVUFBVSxHQUFHO0FBQ2xELFVBQWlELE9BQU8sT0FBTyxlQUFlLElBQUksR0FBRztBQUNuRjtBQUFBLFVBQ0Usd0JBQXdCLEdBQUc7QUFBQSxRQUM3QjtBQUFBLE1BQ0Y7QUFDQSxhQUFPLGVBQWUsTUFBTSxLQUFLO0FBQUEsUUFDL0IsTUFBTTtBQUNKLGlCQUFPLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUI7QUFBQSxRQUNBLElBQUksS0FBSztBQUNQLGVBQUssU0FBUyxLQUFLLEtBQUssTUFBTSxDQUFDLEtBQUssU0FBUztBQUFBLFFBQy9DO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFNBQVMsS0FBSztBQUNaLFFBQUksSUFBSSxXQUFXLFNBQVMsRUFBRztBQUMvQixVQUFNLE1BQU0sS0FBSyxhQUFhLEdBQUc7QUFDakMsUUFBSSxRQUFRLE1BQU0sS0FBSyxhQUFhLEdBQUcsSUFBSTtBQUMzQyxVQUFNLFdBQVcsV0FBVyxHQUFHO0FBQy9CLFFBQUksT0FBTyxLQUFLLGdCQUFnQixLQUFLLGFBQWEsUUFBUSxHQUFHO0FBQzNELGNBQVEsU0FBUyxLQUFLO0FBQUEsSUFDeEI7QUFDQSxTQUFLLFNBQVMsVUFBVSxPQUFPLE9BQU8sSUFBSTtBQUFBLEVBQzVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxTQUFTLEtBQUs7QUFDWixXQUFPLEtBQUssT0FBTyxHQUFHO0FBQUEsRUFDeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFNBQVMsS0FBSyxLQUFLLGdCQUFnQixNQUFNLGVBQWUsT0FBTztBQUM3RCxRQUFJLFFBQVEsS0FBSyxPQUFPLEdBQUcsR0FBRztBQUM1QixXQUFLLFNBQVM7QUFDZCxVQUFJLFFBQVEsU0FBUztBQUNuQixlQUFPLEtBQUssT0FBTyxHQUFHO0FBQUEsTUFDeEIsT0FBTztBQUNMLGFBQUssT0FBTyxHQUFHLElBQUk7QUFDbkIsWUFBSSxRQUFRLFNBQVMsS0FBSyxNQUFNO0FBQzlCLGVBQUssS0FBSyxTQUFTLE1BQU07QUFBQSxRQUMzQjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLGdCQUFnQixLQUFLLFdBQVc7QUFDbEMsYUFBSyxRQUFRO0FBQUEsTUFDZjtBQUNBLFVBQUksZUFBZTtBQUNqQixjQUFNLEtBQUssS0FBSztBQUNoQixZQUFJLElBQUk7QUFDTixlQUFLLGtCQUFrQixHQUFHLFlBQVksQ0FBQztBQUN2QyxhQUFHLFdBQVc7QUFBQSxRQUNoQjtBQUNBLFlBQUksUUFBUSxNQUFNO0FBQ2hCLGVBQUssYUFBYSxVQUFVLEdBQUcsR0FBRyxFQUFFO0FBQUEsUUFDdEMsV0FBVyxPQUFPLFFBQVEsWUFBWSxPQUFPLFFBQVEsVUFBVTtBQUM3RCxlQUFLLGFBQWEsVUFBVSxHQUFHLEdBQUcsTUFBTSxFQUFFO0FBQUEsUUFDNUMsV0FBVyxDQUFDLEtBQUs7QUFDZixlQUFLLGdCQUFnQixVQUFVLEdBQUcsQ0FBQztBQUFBLFFBQ3JDO0FBQ0EsY0FBTSxHQUFHLFFBQVEsTUFBTSxFQUFFLFlBQVksS0FBSyxDQUFDO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsVUFBVTtBQUNSLFVBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsUUFBSSxLQUFLLEtBQU0sT0FBTSxhQUFhLEtBQUssS0FBSztBQUM1QyxXQUFPLE9BQU8sS0FBSyxLQUFLO0FBQUEsRUFDMUI7QUFBQSxFQUNBLGVBQWU7QUFDYixVQUFNLFlBQVksQ0FBQztBQUNuQixRQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLGdCQUFVLGlCQUFpQixVQUFVLGlCQUFpQixLQUFLLGFBQWEsS0FBSyxJQUFJO0FBQUEsSUFDbkY7QUFDQSxVQUFNLFFBQVEsWUFBWSxLQUFLLE1BQU0sT0FBTyxXQUFXLEtBQUssTUFBTSxDQUFDO0FBQ25FLFFBQUksQ0FBQyxLQUFLLFdBQVc7QUFDbkIsWUFBTSxLQUFLLENBQUMsYUFBYTtBQUN2QixhQUFLLFlBQVk7QUFDakIsaUJBQVMsS0FBSztBQUNkLGlCQUFTLE9BQU87QUFDaEIsWUFBSSxNQUEyQztBQUM3QyxtQkFBUyxXQUFXLENBQUMsY0FBYztBQUNqQyxnQkFBSSxLQUFLLFNBQVM7QUFDaEIsbUJBQUssUUFBUSxRQUFRLENBQUMsTUFBTSxLQUFLLE1BQU0sWUFBWSxDQUFDLENBQUM7QUFDckQsbUJBQUssUUFBUSxTQUFTO0FBQUEsWUFDeEI7QUFDQSxpQkFBSyxjQUFjLE9BQU8sS0FBSyxJQUFJO0FBQ25DLGlCQUFLLGFBQWEsU0FBUztBQUMzQixpQkFBSyxZQUFZO0FBQ2pCLGlCQUFLLFFBQVE7QUFBQSxVQUNmO0FBQUEsUUFDRjtBQUNBLGNBQU0sV0FBVyxDQUFDLE9BQU8sU0FBUztBQUNoQyxlQUFLO0FBQUEsWUFDSCxJQUFJO0FBQUEsY0FDRjtBQUFBLGNBQ0EsY0FBYyxLQUFLLENBQUMsQ0FBQyxJQUFJLE9BQU8sRUFBRSxRQUFRLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxLQUFLO0FBQUEsWUFDOUU7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLGlCQUFTLE9BQU8sQ0FBQyxVQUFVLFNBQVM7QUFDbEMsbUJBQVMsT0FBTyxJQUFJO0FBQ3BCLGNBQUksVUFBVSxLQUFLLE1BQU0sT0FBTztBQUM5QixxQkFBUyxVQUFVLEtBQUssR0FBRyxJQUFJO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBQ0EsYUFBSyxXQUFXO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLGFBQWEsUUFBUSxPQUFPLFlBQVk7QUFDdEMsUUFBSSxDQUFDLE9BQVE7QUFDYixRQUFJLE9BQU87QUFDVCxVQUFJLFVBQVUsS0FBSyxRQUFRLEtBQUssZUFBZSxJQUFJLEtBQUssR0FBRztBQUN6RDtBQUFBLE1BQ0Y7QUFDQSxXQUFLLGVBQWUsSUFBSSxLQUFLO0FBQUEsSUFDL0I7QUFDQSxVQUFNLFFBQVEsS0FBSztBQUNuQixVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLGtCQUFrQixhQUFhLEtBQUssZ0JBQWdCLFVBQVUsS0FBSyxLQUFLLGdCQUFnQixLQUFLLElBQUksSUFBSSxLQUFLLDZCQUE2QixJQUFJO0FBQ2pKLFFBQUksT0FBTztBQUNYLGFBQVMsSUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUMzQyxZQUFNLElBQUksU0FBUyxjQUFjLE9BQU87QUFDeEMsVUFBSSxNQUFPLEdBQUUsYUFBYSxTQUFTLEtBQUs7QUFDeEMsUUFBRSxjQUFjLE9BQU8sQ0FBQztBQUN4QixXQUFLLGFBQWEsR0FBRyxRQUFRLGVBQWU7QUFDNUMsYUFBTztBQUNQLFVBQUksTUFBTSxHQUFHO0FBQ1gsWUFBSSxDQUFDLFdBQVksTUFBSyxjQUFjLElBQUksS0FBSyxNQUFNLENBQUM7QUFDcEQsWUFBSSxNQUFPLE1BQUssY0FBYyxJQUFJLE9BQU8sQ0FBQztBQUFBLE1BQzVDO0FBQ0EsVUFBSSxNQUEyQztBQUM3QyxZQUFJLE9BQU87QUFDVCxjQUFJLE1BQU0sU0FBUztBQUNqQixnQkFBSSxDQUFDLEtBQUssYUFBYyxNQUFLLGVBQStCLG9CQUFJLElBQUk7QUFDcEUsZ0JBQUksUUFBUSxLQUFLLGFBQWEsSUFBSSxNQUFNLE9BQU87QUFDL0MsZ0JBQUksQ0FBQyxPQUFPO0FBQ1YsbUJBQUssYUFBYSxJQUFJLE1BQU0sU0FBUyxRQUFRLENBQUMsQ0FBQztBQUFBLFlBQ2pEO0FBQ0Esa0JBQU0sS0FBSyxDQUFDO0FBQUEsVUFDZDtBQUFBLFFBQ0YsT0FBTztBQUNMLFdBQUMsS0FBSyxZQUFZLEtBQUssVUFBVSxDQUFDLElBQUksS0FBSyxDQUFDO0FBQUEsUUFDOUM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLGdCQUFnQixNQUFNO0FBQ3BCLFFBQUksQ0FBQyxNQUFNO0FBQ1QsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLFNBQVMsS0FBSyxjQUFjLElBQUksSUFBSTtBQUMxQyxRQUFJLFVBQVUsT0FBTyxlQUFlLEtBQUssWUFBWTtBQUNuRCxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksUUFBUTtBQUNWLFdBQUssY0FBYyxPQUFPLElBQUk7QUFBQSxJQUNoQztBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSw2QkFBNkIsTUFBTTtBQUNqQyxhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssV0FBVyxRQUFRLEtBQUs7QUFDL0MsWUFBTSxPQUFPLEtBQUssV0FBVyxDQUFDO0FBQzlCLFVBQUksRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQ3ZDLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxjQUFjO0FBQ1osVUFBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLFFBQUk7QUFDSixXQUFPLElBQUksS0FBSyxZQUFZO0FBQzFCLFlBQU0sV0FBVyxFQUFFLGFBQWEsS0FBSyxFQUFFLGFBQWEsTUFBTSxLQUFLO0FBQy9ELE9BQUMsTUFBTSxRQUFRLE1BQU0sTUFBTSxRQUFRLElBQUksQ0FBQyxJQUFJLEtBQUssQ0FBQztBQUNsRCxXQUFLLFlBQVksQ0FBQztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsZUFBZTtBQUNiLFVBQU0sVUFBVSxLQUFLLFVBQVU7QUFDL0IsVUFBTSxVQUFVLEtBQUssVUFBVSxLQUFLO0FBQ3BDLGFBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7QUFDdkMsWUFBTSxJQUFJLFFBQVEsQ0FBQztBQUNuQixZQUFNLFdBQVcsRUFBRSxhQUFhLE1BQU0sS0FBSztBQUMzQyxZQUFNLFVBQVUsS0FBSyxPQUFPLFFBQVE7QUFDcEMsWUFBTSxTQUFTLEVBQUU7QUFDakIsVUFBSSxTQUFTO0FBQ1gsbUJBQVcsS0FBSyxTQUFTO0FBQ3ZCLGNBQUksV0FBVyxFQUFFLGFBQWEsR0FBRztBQUMvQixrQkFBTSxLQUFLLFVBQVU7QUFDckIsa0JBQU0sU0FBUyxTQUFTLGlCQUFpQixHQUFHLENBQUM7QUFDN0MsY0FBRSxhQUFhLElBQUksRUFBRTtBQUNyQixnQkFBSTtBQUNKLG1CQUFPLFFBQVEsT0FBTyxTQUFTLEdBQUc7QUFDaEMsb0JBQU0sYUFBYSxJQUFJLEVBQUU7QUFBQSxZQUMzQjtBQUFBLFVBQ0Y7QUFDQSxpQkFBTyxhQUFhLEdBQUcsQ0FBQztBQUFBLFFBQzFCO0FBQUEsTUFDRixPQUFPO0FBQ0wsZUFBTyxFQUFFLFdBQVksUUFBTyxhQUFhLEVBQUUsWUFBWSxDQUFDO0FBQUEsTUFDMUQ7QUFDQSxhQUFPLFlBQVksQ0FBQztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsWUFBWTtBQUNWLFVBQU0sUUFBUSxDQUFDLElBQUk7QUFDbkIsUUFBSSxLQUFLLGtCQUFrQjtBQUN6QixZQUFNLEtBQUssR0FBRyxLQUFLLGdCQUFnQjtBQUFBLElBQ3JDO0FBQ0EsVUFBTSxRQUF3QixvQkFBSSxJQUFJO0FBQ3RDLGVBQVcsUUFBUSxPQUFPO0FBQ3hCLFlBQU0sUUFBUSxLQUFLLGlCQUFpQixNQUFNO0FBQzFDLGVBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDckMsY0FBTSxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0EsV0FBTyxNQUFNLEtBQUssS0FBSztBQUFBLEVBQ3pCO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxrQkFBa0IsTUFBTSxZQUFZO0FBQ2xDLFNBQUssYUFBYSxLQUFLLFFBQVEsTUFBTSxVQUFVO0FBQUEsRUFDakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLGNBQWM7QUFDWixTQUFLLFlBQVk7QUFDakIsU0FBSyxTQUFTO0FBQUEsRUFDaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFlBQVk7QUFDVixTQUFLLFlBQVk7QUFDakIsUUFBSSxLQUFLLFVBQVUsS0FBSyxXQUFXO0FBQ2pDLFdBQUssUUFBUTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxpQkFBaUI7QUFDZixXQUFPLEtBQUssS0FBSyxlQUFlO0FBQUEsRUFDbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLGtCQUFrQixNQUFNO0FBQ3RCLFFBQUksTUFBMkM7QUFDN0MsV0FBSyxlQUFlLE9BQU8sSUFBSTtBQUMvQixXQUFLLGNBQWMsT0FBTyxJQUFJO0FBQzlCLFVBQUksS0FBSyxnQkFBZ0IsS0FBSyxTQUFTO0FBQ3JDLGNBQU0sWUFBWSxLQUFLLGFBQWEsSUFBSSxLQUFLLE9BQU87QUFDcEQsWUFBSSxXQUFXO0FBQ2Isb0JBQVUsUUFBUSxDQUFDLE1BQU0sS0FBSyxNQUFNLFlBQVksQ0FBQyxDQUFDO0FBQ2xELG9CQUFVLFNBQVM7QUFBQSxRQUNyQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxRQUFRLFFBQVE7QUFDdkIsUUFBTSxXQUFXLG1CQUFtQjtBQUNwQyxRQUFNLEtBQUssWUFBWSxTQUFTO0FBQ2hDLE1BQUksSUFBSTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsTUFBMkM7QUFDcEQsUUFBSSxDQUFDLFVBQVU7QUFDYjtBQUFBLFFBQ0UsR0FBRyxVQUFVLFNBQVM7QUFBQSxNQUN4QjtBQUFBLElBQ0YsT0FBTztBQUNMO0FBQUEsUUFDRSxHQUFHLFVBQVUsU0FBUztBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQjtBQUN2QixRQUFNLEtBQUssT0FBNEMsUUFBUSxlQUFlLElBQUksUUFBUTtBQUMxRixTQUFPLE1BQU0sR0FBRztBQUNsQjtBQUVBLFNBQVMsYUFBYSxPQUFPLFVBQVU7QUFDckM7QUFDRSxVQUFNLFdBQVcsbUJBQW1CO0FBQ3BDLFFBQUksQ0FBQyxVQUFVO0FBQ2IsTUFBNkMsS0FBSyw0Q0FBNEM7QUFDOUYsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLFVBQVUsU0FBUyxLQUFLO0FBQzlCLFFBQUksQ0FBQyxTQUFTO0FBQ1osTUFBNkMsS0FBSyxzREFBc0Q7QUFDeEcsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLE1BQU0sUUFBUSxJQUFJO0FBQ3hCLFFBQUksQ0FBQyxLQUFLO0FBQ1IsTUFBNkMsS0FBSyxvREFBb0QsSUFBSSxJQUFJO0FBQzlHLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLE1BQU0sY0FBOEIsb0JBQUksUUFBUTtBQUNoRCxNQUFNLGlCQUFpQyxvQkFBSSxRQUFRO0FBQ25ELE1BQU0sWUFBNEIsdUJBQU8sU0FBUztBQUNsRCxNQUFNLGFBQTZCLHVCQUFPLFVBQVU7QUFDcEQsTUFBTSxXQUFXLENBQUMsTUFBTTtBQUN0QixTQUFPLEVBQUUsTUFBTTtBQUNmLFNBQU87QUFDVDtBQUNBLE1BQU0sc0JBQXNDLHlCQUFTO0FBQUEsRUFDbkQsTUFBTTtBQUFBLEVBQ04sT0FBdUIsdUJBQU8sQ0FBQyxHQUFHLDJCQUEyQjtBQUFBLElBQzNELEtBQUs7QUFBQSxJQUNMLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFBQSxFQUNELE1BQU0sT0FBTyxFQUFFLE1BQU0sR0FBRztBQUN0QixVQUFNLFdBQVcsbUJBQW1CO0FBQ3BDLFVBQU0sUUFBUSxtQkFBbUI7QUFDakMsUUFBSTtBQUNKLFFBQUk7QUFDSixjQUFVLE1BQU07QUFDZCxVQUFJLENBQUMsYUFBYSxRQUFRO0FBQ3hCO0FBQUEsTUFDRjtBQUNBLFlBQU0sWUFBWSxNQUFNLGFBQWEsR0FBRyxNQUFNLFFBQVEsR0FBRztBQUN6RCxVQUFJLENBQUM7QUFBQSxRQUNILGFBQWEsQ0FBQyxFQUFFO0FBQUEsUUFDaEIsU0FBUyxNQUFNO0FBQUEsUUFDZjtBQUFBLE1BQ0YsR0FBRztBQUNELHVCQUFlLENBQUM7QUFDaEI7QUFBQSxNQUNGO0FBQ0EsbUJBQWEsUUFBUSxjQUFjO0FBQ25DLG1CQUFhLFFBQVEsY0FBYztBQUNuQyxZQUFNLGdCQUFnQixhQUFhLE9BQU8sZ0JBQWdCO0FBQzFELGtCQUFZLFNBQVMsTUFBTSxFQUFFO0FBQzdCLG9CQUFjLFFBQVEsQ0FBQyxNQUFNO0FBQzNCLGNBQU0sS0FBSyxFQUFFO0FBQ2IsY0FBTSxRQUFRLEdBQUc7QUFDakIsMkJBQW1CLElBQUksU0FBUztBQUNoQyxjQUFNLFlBQVksTUFBTSxrQkFBa0IsTUFBTSxxQkFBcUI7QUFDckUsY0FBTSxLQUFLLEdBQUcsU0FBUyxJQUFJLENBQUMsTUFBTTtBQUNoQyxjQUFJLEtBQUssRUFBRSxXQUFXLElBQUk7QUFDeEI7QUFBQSxVQUNGO0FBQ0EsY0FBSSxDQUFDLEtBQUssRUFBRSxhQUFhLFNBQVMsV0FBVyxHQUFHO0FBQzlDLGVBQUcsb0JBQW9CLGlCQUFpQixFQUFFO0FBQzFDLGVBQUcsU0FBUyxJQUFJO0FBQ2hCLGtDQUFzQixJQUFJLFNBQVM7QUFBQSxVQUNyQztBQUFBLFFBQ0Y7QUFDQSxXQUFHLGlCQUFpQixpQkFBaUIsRUFBRTtBQUFBLE1BQ3pDLENBQUM7QUFDRCxxQkFBZSxDQUFDO0FBQUEsSUFDbEIsQ0FBQztBQUNELFdBQU8sTUFBTTtBQUNYLFlBQU0sV0FBVyxNQUFNLEtBQUs7QUFDNUIsWUFBTSxxQkFBcUIsdUJBQXVCLFFBQVE7QUFDMUQsVUFBSSxNQUFNLFNBQVMsT0FBTztBQUMxQixxQkFBZSxDQUFDO0FBQ2hCLFVBQUksVUFBVTtBQUNaLGlCQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3hDLGdCQUFNLFFBQVEsU0FBUyxDQUFDO0FBQ3hCLGNBQUksTUFBTSxNQUFNLE1BQU0sY0FBYztBQUFBLFVBQ3BDLENBQUMsTUFBTSxHQUFHLFdBQVcsR0FBRztBQUN0Qix5QkFBYSxLQUFLLEtBQUs7QUFDdkI7QUFBQSxjQUNFO0FBQUEsY0FDQTtBQUFBLGdCQUNFO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFDQSx3QkFBWSxJQUFJLE9BQU8sWUFBWSxNQUFNLEVBQUUsQ0FBQztBQUFBLFVBQzlDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxNQUFNLFVBQVUseUJBQXlCLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQztBQUN4RSxlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3hDLGNBQU0sUUFBUSxTQUFTLENBQUM7QUFDeEIsWUFBSSxNQUFNLE9BQU8sTUFBTTtBQUNyQjtBQUFBLFlBQ0U7QUFBQSxZQUNBLHVCQUF1QixPQUFPLG9CQUFvQixPQUFPLFFBQVE7QUFBQSxVQUNuRTtBQUFBLFFBQ0YsV0FBd0QsTUFBTSxTQUFTLE1BQU07QUFDM0UsZUFBSywyQ0FBMkM7QUFBQSxRQUNsRDtBQUFBLE1BQ0Y7QUFDQSxhQUFPLFlBQVksS0FBSyxNQUFNLFFBQVE7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsTUFBTSxrQkFBa0I7QUFDeEIsU0FBUyxlQUFlLEdBQUc7QUFDekIsUUFBTSxLQUFLLEVBQUU7QUFDYixNQUFJLEdBQUcsU0FBUyxHQUFHO0FBQ2pCLE9BQUcsU0FBUyxFQUFFO0FBQUEsRUFDaEI7QUFDQSxNQUFJLEdBQUcsVUFBVSxHQUFHO0FBQ2xCLE9BQUcsVUFBVSxFQUFFO0FBQUEsRUFDakI7QUFDRjtBQUNBLFNBQVMsZUFBZSxHQUFHO0FBQ3pCLGlCQUFlLElBQUksR0FBRyxZQUFZLEVBQUUsRUFBRSxDQUFDO0FBQ3pDO0FBQ0EsU0FBUyxpQkFBaUIsR0FBRztBQUMzQixRQUFNLFNBQVMsWUFBWSxJQUFJLENBQUM7QUFDaEMsUUFBTSxTQUFTLGVBQWUsSUFBSSxDQUFDO0FBQ25DLFFBQU0sS0FBSyxPQUFPLE9BQU8sT0FBTztBQUNoQyxRQUFNLEtBQUssT0FBTyxNQUFNLE9BQU87QUFDL0IsTUFBSSxNQUFNLElBQUk7QUFDWixVQUFNLEtBQUssRUFBRTtBQUNiLFVBQU0sSUFBSSxHQUFHO0FBQ2IsVUFBTSxPQUFPLEdBQUcsc0JBQXNCO0FBQ3RDLFFBQUksU0FBUztBQUNiLFFBQUksU0FBUztBQUNiLFFBQUksR0FBRyxZQUFhLFVBQVMsS0FBSyxRQUFRLEdBQUc7QUFDN0MsUUFBSSxHQUFHLGFBQWMsVUFBUyxLQUFLLFNBQVMsR0FBRztBQUMvQyxRQUFJLENBQUMsT0FBTyxTQUFTLE1BQU0sS0FBSyxXQUFXLEVBQUcsVUFBUztBQUN2RCxRQUFJLENBQUMsT0FBTyxTQUFTLE1BQU0sS0FBSyxXQUFXLEVBQUcsVUFBUztBQUN2RCxRQUFJLEtBQUssSUFBSSxTQUFTLENBQUMsSUFBSSxLQUFNLFVBQVM7QUFDMUMsUUFBSSxLQUFLLElBQUksU0FBUyxDQUFDLElBQUksS0FBTSxVQUFTO0FBQzFDLE1BQUUsWUFBWSxFQUFFLGtCQUFrQixhQUFhLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTTtBQUMzRSxNQUFFLHFCQUFxQjtBQUN2QixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUyxZQUFZLElBQUk7QUFDdkIsUUFBTSxPQUFPLEdBQUcsc0JBQXNCO0FBQ3RDLFNBQU87QUFBQSxJQUNMLE1BQU0sS0FBSztBQUFBLElBQ1gsS0FBSyxLQUFLO0FBQUEsRUFDWjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsSUFBSSxNQUFNLFdBQVc7QUFDNUMsUUFBTSxRQUFRLEdBQUcsVUFBVTtBQUMzQixRQUFNLE9BQU8sR0FBRyxNQUFNO0FBQ3RCLE1BQUksTUFBTTtBQUNSLFNBQUssUUFBUSxDQUFDLFFBQVE7QUFDcEIsVUFBSSxNQUFNLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTSxLQUFLLE1BQU0sVUFBVSxPQUFPLENBQUMsQ0FBQztBQUFBLElBQ2hFLENBQUM7QUFBQSxFQUNIO0FBQ0EsWUFBVSxNQUFNLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTSxLQUFLLE1BQU0sVUFBVSxJQUFJLENBQUMsQ0FBQztBQUNqRSxRQUFNLE1BQU0sVUFBVTtBQUN0QixRQUFNLFlBQVksS0FBSyxhQUFhLElBQUksT0FBTyxLQUFLO0FBQ3BELFlBQVUsWUFBWSxLQUFLO0FBQzNCLFFBQU0sRUFBRSxhQUFhLElBQUksa0JBQWtCLEtBQUs7QUFDaEQsWUFBVSxZQUFZLEtBQUs7QUFDM0IsU0FBTztBQUNUO0FBRUEsTUFBTSxtQkFBbUIsQ0FBQyxVQUFVO0FBQ2xDLFFBQU0sS0FBSyxNQUFNLE1BQU0scUJBQXFCLEtBQUs7QUFDakQsU0FBTyxRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVUsZUFBZSxJQUFJLEtBQUssSUFBSTtBQUM5RDtBQUNBLFNBQVMsbUJBQW1CLEdBQUc7QUFDN0IsSUFBRSxPQUFPLFlBQVk7QUFDdkI7QUFDQSxTQUFTLGlCQUFpQixHQUFHO0FBQzNCLFFBQU0sU0FBUyxFQUFFO0FBQ2pCLE1BQUksT0FBTyxXQUFXO0FBQ3BCLFdBQU8sWUFBWTtBQUNuQixXQUFPLGNBQWMsSUFBSSxNQUFNLE9BQU8sQ0FBQztBQUFBLEVBQ3pDO0FBQ0Y7QUFDQSxNQUFNLFlBQTRCLHVCQUFPLFNBQVM7QUFDbEQsTUFBTSxrQkFBa0MsdUJBQU8sZUFBZTtBQUM5RCxTQUFTLFVBQVUsT0FBTyxNQUFNLFFBQVE7QUFDdEMsTUFBSSxLQUFNLFNBQVEsTUFBTSxLQUFLO0FBQzdCLE1BQUksT0FBUSxTQUFRLGNBQWMsS0FBSztBQUN2QyxTQUFPO0FBQ1Q7QUFDQSxNQUFNLGFBQWE7QUFBQSxFQUNqQixRQUFRLElBQUksRUFBRSxXQUFXLEVBQUUsTUFBTSxNQUFNLE9BQU8sRUFBRSxHQUFHLE9BQU87QUFDeEQsUUFBSSxHQUFHLFlBQVk7QUFDakIsVUFBSSxHQUFHLFNBQVMsUUFBUTtBQUN0QixXQUFHLGVBQWUsSUFBSSxHQUFHLGFBQWEsUUFBUSxXQUFXLEVBQUU7QUFBQSxNQUM3RCxXQUFXLEdBQUcsU0FBUyxZQUFZO0FBQ2pDLFdBQUcsZUFBZSxJQUFJLEdBQUcsYUFBYSxRQUFRLFVBQVUsSUFBSTtBQUFBLE1BQzlEO0FBQUEsSUFDRjtBQUNBLE9BQUcsU0FBUyxJQUFJLGlCQUFpQixLQUFLO0FBQ3RDLFVBQU0sZUFBZSxVQUFVLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUztBQUNuRSxxQkFBaUIsSUFBSSxPQUFPLFdBQVcsU0FBUyxDQUFDLE1BQU07QUFDckQsVUFBSSxFQUFFLE9BQU8sVUFBVztBQUN4QixTQUFHLFNBQVMsRUFBRSxVQUFVLEdBQUcsT0FBTyxNQUFNLFlBQVksQ0FBQztBQUFBLElBQ3ZELENBQUM7QUFDRCxRQUFJLFFBQVEsY0FBYztBQUN4Qix1QkFBaUIsSUFBSSxVQUFVLE1BQU07QUFDbkMsV0FBRyxRQUFRLFVBQVUsR0FBRyxPQUFPLE1BQU0sWUFBWTtBQUFBLE1BQ25ELENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSSxDQUFDLE1BQU07QUFDVCx1QkFBaUIsSUFBSSxvQkFBb0Isa0JBQWtCO0FBQzNELHVCQUFpQixJQUFJLGtCQUFrQixnQkFBZ0I7QUFDdkQsdUJBQWlCLElBQUksVUFBVSxnQkFBZ0I7QUFBQSxJQUNqRDtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBRUEsUUFBUSxJQUFJLEVBQUUsT0FBTyxXQUFXLEVBQUUsTUFBTSxPQUFPLEVBQUUsR0FBRztBQUNsRCxVQUFNLFdBQVcsU0FBUyxPQUFPLEtBQUs7QUFDdEMsVUFBTSxlQUFlLEdBQUcsZUFBZTtBQUN2QyxXQUFPLEdBQUcsZUFBZTtBQUN6QixRQUFJLGlCQUFpQixXQUFXLEdBQUcsU0FBUyxVQUFVLEdBQUcsU0FBUyxlQUFlLEdBQUcsVUFBVSxjQUFjO0FBQzFHLFNBQUcsU0FBUyxFQUFFLFVBQVUsR0FBRyxPQUFPLE1BQU0sTUFBTSxDQUFDO0FBQUEsSUFDakQsT0FBTztBQUNMLFNBQUcsUUFBUTtBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQUEsRUFDQSxhQUFhLElBQUksRUFBRSxPQUFPLFVBQVUsV0FBVyxFQUFFLE1BQU0sTUFBTSxPQUFPLEVBQUUsR0FBRyxPQUFPO0FBQzlFLE9BQUcsU0FBUyxJQUFJLGlCQUFpQixLQUFLO0FBQ3RDLFFBQUksR0FBRyxVQUFXO0FBQ2xCLFVBQU0sV0FBVyxVQUFVLEdBQUcsU0FBUyxhQUFhLENBQUMsT0FBTyxLQUFLLEdBQUcsS0FBSyxJQUFJLGNBQWMsR0FBRyxLQUFLLElBQUksR0FBRztBQUMxRyxVQUFNLFdBQVcsU0FBUyxPQUFPLEtBQUs7QUFDdEMsUUFBSSxZQUFZLFVBQVU7QUFDeEI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxXQUFXLEdBQUcsWUFBWTtBQUNoQyxTQUFLLG9CQUFvQixZQUFZLG9CQUFvQixlQUFlLFNBQVMsa0JBQWtCLE1BQU0sR0FBRyxTQUFTLFNBQVM7QUFDNUgsVUFBSSxRQUFRLFVBQVUsVUFBVTtBQUM5QjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFFBQVEsR0FBRyxNQUFNLEtBQUssTUFBTSxVQUFVO0FBQ3hDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxPQUFHLFFBQVE7QUFBQSxFQUNiO0FBQ0Y7QUFDQSxNQUFNLGlCQUFpQjtBQUFBO0FBQUEsRUFFckIsTUFBTTtBQUFBLEVBQ04sUUFBUSxJQUFJLEdBQUcsT0FBTztBQUNwQixPQUFHLFNBQVMsSUFBSSxpQkFBaUIsS0FBSztBQUN0QyxxQkFBaUIsSUFBSSxVQUFVLE1BQU07QUFDbkMsWUFBTSxhQUFhLEdBQUc7QUFDdEIsWUFBTSxlQUFlLFNBQVMsRUFBRTtBQUNoQyxZQUFNLFVBQVUsR0FBRztBQUNuQixZQUFNLFNBQVMsR0FBRyxTQUFTO0FBQzNCLFVBQUksUUFBUSxVQUFVLEdBQUc7QUFDdkIsY0FBTSxRQUFRLGFBQWEsWUFBWSxZQUFZO0FBQ25ELGNBQU0sUUFBUSxVQUFVO0FBQ3hCLFlBQUksV0FBVyxDQUFDLE9BQU87QUFDckIsaUJBQU8sV0FBVyxPQUFPLFlBQVksQ0FBQztBQUFBLFFBQ3hDLFdBQVcsQ0FBQyxXQUFXLE9BQU87QUFDNUIsZ0JBQU0sV0FBVyxDQUFDLEdBQUcsVUFBVTtBQUMvQixtQkFBUyxPQUFPLE9BQU8sQ0FBQztBQUN4QixpQkFBTyxRQUFRO0FBQUEsUUFDakI7QUFBQSxNQUNGLFdBQVcsTUFBTSxVQUFVLEdBQUc7QUFDNUIsY0FBTSxTQUFTLElBQUksSUFBSSxVQUFVO0FBQ2pDLFlBQUksU0FBUztBQUNYLGlCQUFPLElBQUksWUFBWTtBQUFBLFFBQ3pCLE9BQU87QUFDTCxpQkFBTyxPQUFPLFlBQVk7QUFBQSxRQUM1QjtBQUNBLGVBQU8sTUFBTTtBQUFBLE1BQ2YsT0FBTztBQUNMLGVBQU8saUJBQWlCLElBQUksT0FBTyxDQUFDO0FBQUEsTUFDdEM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQSxFQUVBLFNBQVM7QUFBQSxFQUNULGFBQWEsSUFBSSxTQUFTLE9BQU87QUFDL0IsT0FBRyxTQUFTLElBQUksaUJBQWlCLEtBQUs7QUFDdEMsZUFBVyxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQy9CO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsSUFBSSxFQUFFLE9BQU8sU0FBUyxHQUFHLE9BQU87QUFDbEQsS0FBRyxjQUFjO0FBQ2pCLE1BQUk7QUFDSixNQUFJLFFBQVEsS0FBSyxHQUFHO0FBQ2xCLGNBQVUsYUFBYSxPQUFPLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxFQUNyRCxXQUFXLE1BQU0sS0FBSyxHQUFHO0FBQ3ZCLGNBQVUsTUFBTSxJQUFJLE1BQU0sTUFBTSxLQUFLO0FBQUEsRUFDdkMsT0FBTztBQUNMLFFBQUksVUFBVSxTQUFVO0FBQ3hCLGNBQVUsV0FBVyxPQUFPLGlCQUFpQixJQUFJLElBQUksQ0FBQztBQUFBLEVBQ3hEO0FBQ0EsTUFBSSxHQUFHLFlBQVksU0FBUztBQUMxQixPQUFHLFVBQVU7QUFBQSxFQUNmO0FBQ0Y7QUFDQSxNQUFNLGNBQWM7QUFBQSxFQUNsQixRQUFRLElBQUksRUFBRSxNQUFNLEdBQUcsT0FBTztBQUM1QixPQUFHLFVBQVUsV0FBVyxPQUFPLE1BQU0sTUFBTSxLQUFLO0FBQ2hELE9BQUcsU0FBUyxJQUFJLGlCQUFpQixLQUFLO0FBQ3RDLHFCQUFpQixJQUFJLFVBQVUsTUFBTTtBQUNuQyxTQUFHLFNBQVMsRUFBRSxTQUFTLEVBQUUsQ0FBQztBQUFBLElBQzVCLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFDQSxhQUFhLElBQUksRUFBRSxPQUFPLFNBQVMsR0FBRyxPQUFPO0FBQzNDLE9BQUcsU0FBUyxJQUFJLGlCQUFpQixLQUFLO0FBQ3RDLFFBQUksVUFBVSxVQUFVO0FBQ3RCLFNBQUcsVUFBVSxXQUFXLE9BQU8sTUFBTSxNQUFNLEtBQUs7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDRjtBQUNBLE1BQU0sZUFBZTtBQUFBO0FBQUEsRUFFbkIsTUFBTTtBQUFBLEVBQ04sUUFBUSxJQUFJLEVBQUUsT0FBTyxXQUFXLEVBQUUsT0FBTyxFQUFFLEdBQUcsT0FBTztBQUNuRCxPQUFHLGNBQWM7QUFDakIscUJBQWlCLElBQUksVUFBVSxNQUFNO0FBQ25DLFlBQU0sY0FBYyxNQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUU7QUFBQSxRQUM3RSxDQUFDLE1BQU0sU0FBUyxjQUFjLFNBQVMsQ0FBQyxDQUFDLElBQUksU0FBUyxDQUFDO0FBQUEsTUFDekQ7QUFDQSxTQUFHLFNBQVM7QUFBQSxRQUNWLEdBQUcsV0FBVyxNQUFNLEdBQUcsV0FBVyxJQUFJLElBQUksSUFBSSxXQUFXLElBQUksY0FBYyxZQUFZLENBQUM7QUFBQSxNQUMxRjtBQUNBLFNBQUcsYUFBYTtBQUNoQixlQUFTLE1BQU07QUFDYixXQUFHLGFBQWE7QUFBQSxNQUNsQixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQ0QsT0FBRyxTQUFTLElBQUksaUJBQWlCLEtBQUs7QUFBQSxFQUN4QztBQUFBO0FBQUE7QUFBQSxFQUdBLFFBQVEsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUNyQixnQkFBWSxJQUFJLEtBQUs7QUFBQSxFQUN2QjtBQUFBLEVBQ0EsYUFBYSxJQUFJLEVBQUUsTUFBTSxHQUFHLE9BQU87QUFDakMsT0FBRyxjQUFjO0FBQ2pCLE9BQUcsU0FBUyxJQUFJLGlCQUFpQixLQUFLO0FBQUEsRUFDeEM7QUFBQSxFQUNBLFFBQVEsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUNyQixRQUFJLENBQUMsR0FBRyxZQUFZO0FBQ2xCLGtCQUFZLElBQUksS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxZQUFZLElBQUksT0FBTztBQUM5QixRQUFNLGFBQWEsR0FBRztBQUN0QixRQUFNLGVBQWUsUUFBUSxLQUFLO0FBQ2xDLE1BQUksY0FBYyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxHQUFHO0FBQ2hELElBQTZDO0FBQUEsTUFDM0Msb0ZBQW9GLE9BQU8sVUFBVSxTQUFTLEtBQUssS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxJQUN4STtBQUNBO0FBQUEsRUFDRjtBQUNBLFdBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLFFBQVEsSUFBSSxHQUFHLEtBQUs7QUFDakQsVUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDO0FBQzNCLFVBQU0sY0FBYyxTQUFTLE1BQU07QUFDbkMsUUFBSSxZQUFZO0FBQ2QsVUFBSSxjQUFjO0FBQ2hCLGNBQU0sYUFBYSxPQUFPO0FBQzFCLFlBQUksZUFBZSxZQUFZLGVBQWUsVUFBVTtBQUN0RCxpQkFBTyxXQUFXLE1BQU0sS0FBSyxDQUFDLE1BQU0sT0FBTyxDQUFDLE1BQU0sT0FBTyxXQUFXLENBQUM7QUFBQSxRQUN2RSxPQUFPO0FBQ0wsaUJBQU8sV0FBVyxhQUFhLE9BQU8sV0FBVyxJQUFJO0FBQUEsUUFDdkQ7QUFBQSxNQUNGLE9BQU87QUFDTCxlQUFPLFdBQVcsTUFBTSxJQUFJLFdBQVc7QUFBQSxNQUN6QztBQUFBLElBQ0YsV0FBVyxXQUFXLFNBQVMsTUFBTSxHQUFHLEtBQUssR0FBRztBQUM5QyxVQUFJLEdBQUcsa0JBQWtCLEVBQUcsSUFBRyxnQkFBZ0I7QUFDL0M7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxjQUFjLEdBQUcsa0JBQWtCLElBQUk7QUFDMUMsT0FBRyxnQkFBZ0I7QUFBQSxFQUNyQjtBQUNGO0FBQ0EsU0FBUyxTQUFTLElBQUk7QUFDcEIsU0FBTyxZQUFZLEtBQUssR0FBRyxTQUFTLEdBQUc7QUFDekM7QUFDQSxTQUFTLGlCQUFpQixJQUFJLFNBQVM7QUFDckMsUUFBTSxNQUFNLFVBQVUsZUFBZTtBQUNyQyxTQUFPLE9BQU8sS0FBSyxHQUFHLEdBQUcsSUFBSTtBQUMvQjtBQUNBLE1BQU0sZ0JBQWdCO0FBQUEsRUFDcEIsUUFBUSxJQUFJLFNBQVMsT0FBTztBQUMxQixrQkFBYyxJQUFJLFNBQVMsT0FBTyxNQUFNLFNBQVM7QUFBQSxFQUNuRDtBQUFBLEVBQ0EsUUFBUSxJQUFJLFNBQVMsT0FBTztBQUMxQixrQkFBYyxJQUFJLFNBQVMsT0FBTyxNQUFNLFNBQVM7QUFBQSxFQUNuRDtBQUFBLEVBQ0EsYUFBYSxJQUFJLFNBQVMsT0FBTyxXQUFXO0FBQzFDLGtCQUFjLElBQUksU0FBUyxPQUFPLFdBQVcsY0FBYztBQUFBLEVBQzdEO0FBQUEsRUFDQSxRQUFRLElBQUksU0FBUyxPQUFPLFdBQVc7QUFDckMsa0JBQWMsSUFBSSxTQUFTLE9BQU8sV0FBVyxTQUFTO0FBQUEsRUFDeEQ7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLFNBQVMsTUFBTTtBQUMxQyxVQUFRLFNBQVM7QUFBQSxJQUNmLEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1Q7QUFDRSxjQUFRLE1BQU07QUFBQSxRQUNaLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVDtBQUNFLGlCQUFPO0FBQUEsTUFDWDtBQUFBLEVBQ0o7QUFDRjtBQUNBLFNBQVMsY0FBYyxJQUFJLFNBQVMsT0FBTyxXQUFXLE1BQU07QUFDMUQsUUFBTSxhQUFhO0FBQUEsSUFDakIsR0FBRztBQUFBLElBQ0gsTUFBTSxTQUFTLE1BQU0sTUFBTTtBQUFBLEVBQzdCO0FBQ0EsUUFBTSxLQUFLLFdBQVcsSUFBSTtBQUMxQixRQUFNLEdBQUcsSUFBSSxTQUFTLE9BQU8sU0FBUztBQUN4QztBQUNBLFNBQVMsbUJBQW1CO0FBQzFCLGFBQVcsY0FBYyxDQUFDLEVBQUUsTUFBTSxPQUFPLEVBQUUsTUFBTTtBQUNqRCxjQUFZLGNBQWMsQ0FBQyxFQUFFLE1BQU0sR0FBRyxVQUFVO0FBQzlDLFFBQUksTUFBTSxTQUFTLFdBQVcsTUFBTSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQ3ZELGFBQU8sRUFBRSxTQUFTLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSxpQkFBZSxjQUFjLENBQUMsRUFBRSxNQUFNLEdBQUcsVUFBVTtBQUNqRCxRQUFJLFFBQVEsS0FBSyxHQUFHO0FBQ2xCLFVBQUksTUFBTSxTQUFTLGFBQWEsT0FBTyxNQUFNLE1BQU0sS0FBSyxJQUFJLElBQUk7QUFDOUQsZUFBTyxFQUFFLFNBQVMsS0FBSztBQUFBLE1BQ3pCO0FBQUEsSUFDRixXQUFXLE1BQU0sS0FBSyxHQUFHO0FBQ3ZCLFVBQUksTUFBTSxTQUFTLE1BQU0sSUFBSSxNQUFNLE1BQU0sS0FBSyxHQUFHO0FBQy9DLGVBQU8sRUFBRSxTQUFTLEtBQUs7QUFBQSxNQUN6QjtBQUFBLElBQ0YsV0FBVyxPQUFPO0FBQ2hCLGFBQU8sRUFBRSxTQUFTLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSxnQkFBYyxjQUFjLENBQUMsU0FBUyxVQUFVO0FBQzlDLFFBQUksT0FBTyxNQUFNLFNBQVMsVUFBVTtBQUNsQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWE7QUFBQTtBQUFBLE1BRWpCLE1BQU0sS0FBSyxZQUFZO0FBQUEsTUFDdkIsTUFBTSxTQUFTLE1BQU0sTUFBTTtBQUFBLElBQzdCO0FBQ0EsUUFBSSxXQUFXLGFBQWE7QUFDMUIsYUFBTyxXQUFXLFlBQVksU0FBUyxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxNQUFNLGtCQUFrQixDQUFDLFFBQVEsU0FBUyxPQUFPLE1BQU07QUFDdkQsTUFBTSxpQkFBaUI7QUFBQSxFQUNyQixNQUFNLENBQUMsTUFBTSxFQUFFLGdCQUFnQjtBQUFBLEVBQy9CLFNBQVMsQ0FBQyxNQUFNLEVBQUUsZUFBZTtBQUFBLEVBQ2pDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFO0FBQUEsRUFDNUIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQUEsRUFDaEIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQUEsRUFDakIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQUEsRUFDZixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFBQSxFQUNoQixNQUFNLENBQUMsTUFBTSxZQUFZLEtBQUssRUFBRSxXQUFXO0FBQUEsRUFDM0MsUUFBUSxDQUFDLE1BQU0sWUFBWSxLQUFLLEVBQUUsV0FBVztBQUFBLEVBQzdDLE9BQU8sQ0FBQyxNQUFNLFlBQVksS0FBSyxFQUFFLFdBQVc7QUFBQSxFQUM1QyxPQUFPLENBQUMsR0FBRyxjQUFjLGdCQUFnQixLQUFLLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxLQUFLLEtBQUssQ0FBQyxVQUFVLFNBQVMsQ0FBQyxDQUFDO0FBQzdGO0FBQ0EsTUFBTSxnQkFBZ0IsQ0FBQyxJQUFJLGNBQWM7QUFDdkMsTUFBSSxDQUFDLEdBQUksUUFBTztBQUNoQixRQUFNLFFBQVEsR0FBRyxjQUFjLEdBQUcsWUFBWSxDQUFDO0FBQy9DLFFBQU0sV0FBVyxVQUFVLEtBQUssR0FBRztBQUNuQyxTQUFPLE1BQU0sUUFBUSxNQUFNLE1BQU0sUUFBUSxLQUFLLENBQUMsVUFBVSxTQUFTO0FBQ2hFLGFBQVMsSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7QUFDekMsWUFBTSxRQUFRLGVBQWUsVUFBVSxDQUFDLENBQUM7QUFDekMsVUFBSSxTQUFTLE1BQU0sT0FBTyxTQUFTLEVBQUc7QUFBQSxJQUN4QztBQUNBLFdBQU8sR0FBRyxPQUFPLEdBQUcsSUFBSTtBQUFBLEVBQzFCO0FBQ0Y7QUFDQSxNQUFNLFdBQVc7QUFBQSxFQUNmLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLElBQUk7QUFBQSxFQUNKLE1BQU07QUFBQSxFQUNOLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQSxFQUNOLFFBQVE7QUFDVjtBQUNBLE1BQU0sV0FBVyxDQUFDLElBQUksY0FBYztBQUNsQyxRQUFNLFFBQVEsR0FBRyxjQUFjLEdBQUcsWUFBWSxDQUFDO0FBQy9DLFFBQU0sV0FBVyxVQUFVLEtBQUssR0FBRztBQUNuQyxTQUFPLE1BQU0sUUFBUSxNQUFNLE1BQU0sUUFBUSxLQUFLLENBQUMsVUFBVTtBQUN2RCxRQUFJLEVBQUUsU0FBUyxRQUFRO0FBQ3JCO0FBQUEsSUFDRjtBQUNBLFVBQU0sV0FBVyxVQUFVLE1BQU0sR0FBRztBQUNwQyxRQUFJLFVBQVU7QUFBQSxNQUNaLENBQUMsTUFBTSxNQUFNLFlBQVksU0FBUyxDQUFDLE1BQU07QUFBQSxJQUMzQyxHQUFHO0FBQ0QsYUFBTyxHQUFHLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLE1BQU0sa0JBQWtDLHVCQUFPLEVBQUUsVUFBVSxHQUFHLE9BQU87QUFDckUsSUFBSTtBQUNKLElBQUksbUJBQW1CO0FBQ3ZCLFNBQVMsaUJBQWlCO0FBQ3hCLFNBQU8sYUFBYSxXQUFXLGVBQWUsZUFBZTtBQUMvRDtBQUNBLFNBQVMsMEJBQTBCO0FBQ2pDLGFBQVcsbUJBQW1CLFdBQVcsd0JBQXdCLGVBQWU7QUFDaEYscUJBQW1CO0FBQ25CLFNBQU87QUFDVDtBQUNBLE1BQU0sVUFBVSxJQUFJLFNBQVM7QUFDM0IsaUJBQWUsRUFBRSxPQUFPLEdBQUcsSUFBSTtBQUNqQztBQUNBLE1BQU0sV0FBVyxJQUFJLFNBQVM7QUFDNUIsMEJBQXdCLEVBQUUsUUFBUSxHQUFHLElBQUk7QUFDM0M7QUFDQSxNQUFNLGFBQWEsSUFBSSxTQUFTO0FBQzlCLFFBQU0sTUFBTSxlQUFlLEVBQUUsVUFBVSxHQUFHLElBQUk7QUFDOUMsTUFBSSxNQUEyQztBQUM3Qyx5QkFBcUIsR0FBRztBQUN4QiwrQkFBMkIsR0FBRztBQUFBLEVBQ2hDO0FBQ0EsUUFBTSxFQUFFLE1BQU0sSUFBSTtBQUNsQixNQUFJLFFBQVEsQ0FBQyx3QkFBd0I7QUFDbkMsVUFBTSxZQUFZLG1CQUFtQixtQkFBbUI7QUFDeEQsUUFBSSxDQUFDLFVBQVc7QUFDaEIsVUFBTSxZQUFZLElBQUk7QUFDdEIsUUFBSSxDQUFDLFdBQVcsU0FBUyxLQUFLLENBQUMsVUFBVSxVQUFVLENBQUMsVUFBVSxVQUFVO0FBQ3RFLGdCQUFVLFdBQVcsVUFBVTtBQUFBLElBQ2pDO0FBQ0EsUUFBSSxVQUFVLGFBQWEsR0FBRztBQUM1QixnQkFBVSxjQUFjO0FBQUEsSUFDMUI7QUFDQSxVQUFNLFFBQVEsTUFBTSxXQUFXLE9BQU8scUJBQXFCLFNBQVMsQ0FBQztBQUNyRSxRQUFJLHFCQUFxQixTQUFTO0FBQ2hDLGdCQUFVLGdCQUFnQixTQUFTO0FBQ25DLGdCQUFVLGFBQWEsY0FBYyxFQUFFO0FBQUEsSUFDekM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU87QUFDVDtBQUNBLE1BQU0sZ0JBQWdCLElBQUksU0FBUztBQUNqQyxRQUFNLE1BQU0sd0JBQXdCLEVBQUUsVUFBVSxHQUFHLElBQUk7QUFDdkQsTUFBSSxNQUEyQztBQUM3Qyx5QkFBcUIsR0FBRztBQUN4QiwrQkFBMkIsR0FBRztBQUFBLEVBQ2hDO0FBQ0EsUUFBTSxFQUFFLE1BQU0sSUFBSTtBQUNsQixNQUFJLFFBQVEsQ0FBQyx3QkFBd0I7QUFDbkMsVUFBTSxZQUFZLG1CQUFtQixtQkFBbUI7QUFDeEQsUUFBSSxXQUFXO0FBQ2IsYUFBTyxNQUFNLFdBQVcsTUFBTSxxQkFBcUIsU0FBUyxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxxQkFBcUIsV0FBVztBQUN2QyxNQUFJLHFCQUFxQixZQUFZO0FBQ25DLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxPQUFPLGtCQUFrQixjQUFjLHFCQUFxQixlQUFlO0FBQzdFLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixLQUFLO0FBQ2pDLFNBQU8sZUFBZSxJQUFJLFFBQVEsZUFBZTtBQUFBLElBQy9DLE9BQU8sQ0FBQyxRQUFRLFVBQVUsR0FBRyxLQUFLLFNBQVMsR0FBRyxLQUFLLFlBQVksR0FBRztBQUFBLElBQ2xFLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDSDtBQUNBLFNBQVMsMkJBQTJCLEtBQUs7QUFDdkMsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxrQkFBa0IsSUFBSSxPQUFPO0FBQ25DLFdBQU8sZUFBZSxJQUFJLFFBQVEsbUJBQW1CO0FBQUEsTUFDbkQsTUFBTTtBQUNKLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFDQSxNQUFNO0FBQ0o7QUFBQSxVQUNFO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFDRCxVQUFNLGtCQUFrQixJQUFJLE9BQU87QUFDbkMsVUFBTSxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBSVosV0FBTyxlQUFlLElBQUksUUFBUSxtQkFBbUI7QUFBQSxNQUNuRCxNQUFNO0FBQ0osYUFBSyxHQUFHO0FBQ1IsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBLE1BQU07QUFDSixhQUFLLEdBQUc7QUFBQSxNQUNWO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsV0FBVztBQUNyQyxNQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxTQUFTLGNBQWMsU0FBUztBQUM1QyxRQUFpRCxDQUFDLEtBQUs7QUFDckQ7QUFBQSxRQUNFLCtDQUErQyxTQUFTO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFpRCxPQUFPLGNBQWMscUJBQXFCLE9BQU8sY0FBYyxVQUFVLFNBQVMsVUFBVTtBQUMzSTtBQUFBLE1BQ0U7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLElBQUksMEJBQTBCO0FBQzlCLE1BQU0sdUJBQXVCLE1BQU07QUFDakMsTUFBSSxDQUFDLHlCQUF5QjtBQUM1Qiw4QkFBMEI7QUFDMUIscUJBQWlCO0FBQ2pCLG9CQUFnQjtBQUFBLEVBQ2xCO0FBQ0Y7QUFFQSxTQUFTLFlBQVksaUJBQWlCLFlBQVksV0FBVyxjQUFjLHFCQUFxQix3QkFBd0IsU0FBUyxzQkFBc0IsU0FBUyxXQUFXLFFBQVEsY0FBYyxZQUFZLFNBQVMsZUFBZSxnQkFBZ0IsZUFBZSxhQUFhLGNBQWMsWUFBWSxPQUFPLFVBQVU7IiwibmFtZXMiOltdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19