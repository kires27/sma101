import GoTrueAdminApi from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/GoTrueAdminApi.js?v=583078ff";
import { AUTO_REFRESH_TICK_DURATION_MS, AUTO_REFRESH_TICK_THRESHOLD, DEFAULT_HEADERS, EXPIRY_MARGIN_MS, GOTRUE_URL, JWKS_TTL, STORAGE_KEY, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/constants.js?v=583078ff";
import { AuthImplicitGrantRedirectError, AuthInvalidCredentialsError, AuthInvalidJwtError, AuthInvalidTokenResponseError, AuthPKCECodeVerifierMissingError, AuthPKCEGrantCodeExchangeError, AuthRefreshDiscardedError, AuthSessionMissingError, AuthUnknownError, isAuthApiError, isAuthError, isAuthImplicitGrantRedirectError, isAuthRefreshDiscardedError, isAuthRetryableFetchError, isAuthSessionMissingError, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/errors.js?v=583078ff";
import { _request, _sessionResponse, _sessionResponsePassword, _ssoResponse, _userResponse, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/fetch.js?v=583078ff";
import { assertPasskeyExperimentalEnabled, decodeJWT, deepClone, Deferred, generateCallbackId, getAlgorithm, getCodeChallengeAndMethod, getItemAsync, insecureUserWarningProxy, isBrowser, parseParametersFromURL, removeItemAsync, resolveFetch, retryable, setItemAsync, sleep, supportsLocalStorage, userNotAvailableProxy, validateExp, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/helpers.js?v=583078ff";
import { memoryLocalStorageAdapter } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/local-storage.js?v=583078ff";
import { LockAcquireTimeoutError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/locks.js?v=583078ff";
import { polyfillGlobalThis } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/polyfills.js?v=583078ff";
import { version } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/version.js?v=583078ff";
import { bytesToBase64URL, stringToUint8Array } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/base64url.js?v=583078ff";
import { createSiweMessage, fromHex, getAddress, toHex, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/web3/ethereum.js?v=583078ff";
import { createCredential, deserializeCredentialCreationOptions, deserializeCredentialRequestOptions, getCredential, serializeCredentialCreationResponse, serializeCredentialRequestResponse, browserSupportsWebAuthn, webAuthnAbortService, WebAuthnApi, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/webauthn.js?v=583078ff";
polyfillGlobalThis(); // Make "globalThis" available
const DEFAULT_OPTIONS = {
    url: GOTRUE_URL,
    storageKey: STORAGE_KEY,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    headers: DEFAULT_HEADERS,
    flowType: 'implicit',
    debug: false,
    hasCustomAuthorizationHeader: false,
    throwOnError: false,
    lockAcquireTimeout: 5000, // 5 seconds. Only used when a custom `lock` is supplied. TODO(v3): remove.
    skipAutoInitialize: false,
    experimental: {},
};
/**
 * No-op lock used internally as a placeholder. Kept so older test setups that
 * inject this exact reference do not break; new code never sees it because
 * `this.lock` stays `null` when no custom lock is supplied (lockless path).
 * TODO(v3): remove with the legacy lock path.
 */
async function lockNoOp(name, acquireTimeout, fn) {
    return await fn();
}
/**
 * Caches JWKS values for all clients created in the same environment. This is
 * especially useful for shared-memory execution environments such as Vercel's
 * Fluid Compute, AWS Lambda or Supabase's Edge Functions. Regardless of how
 * many clients are created, if they share the same storage key they will use
 * the same JWKS cache, significantly speeding up getClaims() with asymmetric
 * JWTs.
 */
const GLOBAL_JWKS = {};
class GoTrueClient {
    /**
     * The JWKS used for verifying asymmetric JWTs
     */
    get jwks() {
        var _a, _b;
        return (_b = (_a = GLOBAL_JWKS[this.storageKey]) === null || _a === void 0 ? void 0 : _a.jwks) !== null && _b !== void 0 ? _b : { keys: [] };
    }
    set jwks(value) {
        GLOBAL_JWKS[this.storageKey] = Object.assign(Object.assign({}, GLOBAL_JWKS[this.storageKey]), { jwks: value });
    }
    get jwks_cached_at() {
        var _a, _b;
        return (_b = (_a = GLOBAL_JWKS[this.storageKey]) === null || _a === void 0 ? void 0 : _a.cachedAt) !== null && _b !== void 0 ? _b : Number.MIN_SAFE_INTEGER;
    }
    set jwks_cached_at(value) {
        GLOBAL_JWKS[this.storageKey] = Object.assign(Object.assign({}, GLOBAL_JWKS[this.storageKey]), { cachedAt: value });
    }
    /**
     * Create a new client for use in the browser.
     *
     * @example Using supabase-js (recommended)
     * ```ts
     * import { createClient } from '@supabase/supabase-js'
     *
     * const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
     * const { data, error } = await supabase.auth.getUser()
     * ```
     *
     * @example Standalone import for bundle-sensitive environments
     * ```ts
     * import { GoTrueClient } from '@supabase/auth-js'
     *
     * const auth = new GoTrueClient({
     *   url: 'https://xyzcompany.supabase.co/auth/v1',
     *   headers: { apikey: 'your-publishable-key' },
     *   storageKey: 'supabase-auth',
     * })
     * ```
     */
    constructor(options) {
        var _a, _b, _c;
        /**
         * @experimental
         */
        this.userStorage = null;
        this.memoryStorage = null;
        this.stateChangeEmitters = new Map();
        this.autoRefreshTicker = null;
        this.autoRefreshTickTimeout = null;
        this.visibilityChangedCallback = null;
        this.refreshingDeferred = null;
        /**
         * Monotonic counter incremented at the top of `_removeSession`, before any
         * `await`. The commit guard inside `_callRefreshToken` captures this value
         * before `_saveSession` and re-checks it after, so a `signOut` that
         * interleaves inside `_saveSession`'s storage-write awaits is still caught
         * (the post-fetch storage snapshot alone misses that window).
         */
        this._sessionRemovalEpoch = 0;
        /**
         * Keeps track of the async client initialization.
         * When null or not yet resolved the auth state is `unknown`
         * Once resolved the auth state is known and it's safe to call any further client methods.
         * Keep extra care to never reject or throw uncaught errors
         */
        this.initializePromise = null;
        this.detectSessionInUrl = true;
        this.hasCustomAuthorizationHeader = false;
        this.suppressGetSessionWarning = false;
        /**
         * Custom lock function passed via `settings.lock`. When non-null, every auth
         * operation runs inside `_acquireLock`. When null (the default), the client
         * uses its lockless coordination (refresh single-flight + commit guard).
         * TODO(v3): remove along with the legacy lock path.
         */
        this.lock = null;
        this.lockAcquired = false;
        this.pendingInLock = [];
        /**
         * Used to broadcast state change events to other tabs listening.
         */
        this.broadcastChannel = null;
        this.logger = console.log;
        const settings = Object.assign(Object.assign({}, DEFAULT_OPTIONS), options);
        this.storageKey = settings.storageKey;
        this.instanceID = (_a = GoTrueClient.nextInstanceID[this.storageKey]) !== null && _a !== void 0 ? _a : 0;
        GoTrueClient.nextInstanceID[this.storageKey] = this.instanceID + 1;
        this.logDebugMessages = !!settings.debug;
        if (typeof settings.debug === 'function') {
            this.logger = settings.debug;
        }
        if (this.instanceID > 0 && isBrowser()) {
            const message = `${this._logPrefix()} Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.`;
            console.warn(message);
            if (this.logDebugMessages) {
                console.trace(message);
            }
        }
        this.persistSession = settings.persistSession;
        this.autoRefreshToken = settings.autoRefreshToken;
        this.experimental = (_b = settings.experimental) !== null && _b !== void 0 ? _b : {};
        this.admin = new GoTrueAdminApi({
            url: settings.url,
            headers: settings.headers,
            fetch: settings.fetch,
            experimental: this.experimental,
        });
        this.url = settings.url;
        this.headers = settings.headers;
        this.fetch = resolveFetch(settings.fetch);
        this.detectSessionInUrl = settings.detectSessionInUrl;
        this.flowType = settings.flowType;
        this.hasCustomAuthorizationHeader = settings.hasCustomAuthorizationHeader;
        this.throwOnError = settings.throwOnError;
        // Always wire `lockAcquireTimeout` even on the lockless path: consumers
        // (including supabase-js tests) read it off the client to verify option
        // flow-through.
        this.lockAcquireTimeout = settings.lockAcquireTimeout;
        // TODO(v3): remove. Legacy opt-in path preserved for backwards
        // compatibility with callers passing a custom `lock` (typically React
        // Native `processLock` or Node multi-process setups). When `settings.lock`
        // is null the client uses its lockless coordination — no `navigator.locks`
        // by default, no implicit `processLock`.
        if (settings.lock != null) {
            this.lock = settings.lock;
        }
        if (!this.jwks) {
            this.jwks = { keys: [] };
            this.jwks_cached_at = Number.MIN_SAFE_INTEGER;
        }
        this.mfa = {
            verify: this._verify.bind(this),
            enroll: this._enroll.bind(this),
            unenroll: this._unenroll.bind(this),
            challenge: this._challenge.bind(this),
            listFactors: this._listFactors.bind(this),
            challengeAndVerify: this._challengeAndVerify.bind(this),
            getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this),
            webauthn: new WebAuthnApi(this),
        };
        this.oauth = {
            getAuthorizationDetails: this._getAuthorizationDetails.bind(this),
            approveAuthorization: this._approveAuthorization.bind(this),
            denyAuthorization: this._denyAuthorization.bind(this),
            listGrants: this._listOAuthGrants.bind(this),
            revokeGrant: this._revokeOAuthGrant.bind(this),
        };
        this.passkey = {
            startRegistration: this._startPasskeyRegistration.bind(this),
            verifyRegistration: this._verifyPasskeyRegistration.bind(this),
            startAuthentication: this._startPasskeyAuthentication.bind(this),
            verifyAuthentication: this._verifyPasskeyAuthentication.bind(this),
            list: this._listPasskeys.bind(this),
            update: this._updatePasskey.bind(this),
            delete: this._deletePasskey.bind(this),
        };
        if (this.persistSession) {
            if (settings.storage) {
                this.storage = settings.storage;
            }
            else {
                if (supportsLocalStorage()) {
                    this.storage = globalThis.localStorage;
                }
                else {
                    this.memoryStorage = {};
                    this.storage = memoryLocalStorageAdapter(this.memoryStorage);
                }
            }
            if (settings.userStorage) {
                this.userStorage = settings.userStorage;
            }
        }
        else {
            this.memoryStorage = {};
            this.storage = memoryLocalStorageAdapter(this.memoryStorage);
        }
        if (isBrowser() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
            try {
                this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey);
            }
            catch (e) {
                console.error('Failed to create a new BroadcastChannel, multi-tab state changes will not be available', e);
            }
            (_c = this.broadcastChannel) === null || _c === void 0 ? void 0 : _c.addEventListener('message', async (event) => {
                this._debug('received broadcast notification from other tab or client', event);
                try {
                    await this._notifyAllSubscribers(event.data.event, event.data.session, false); // broadcast = false so we don't get an endless loop of messages
                }
                catch (error) {
                    this._debug('#broadcastChannel', 'error', error);
                }
            });
        }
        // Only auto-initialize if not explicitly disabled. Skipped in SSR contexts
        // where initialization timing must be controlled. All public methods have
        // lazy initialization, so the client remains fully functional.
        if (!settings.skipAutoInitialize) {
            this.initialize().catch((error) => {
                this._debug('#initialize()', 'error', error);
            });
        }
    }
    /**
     * Returns whether error throwing mode is enabled for this client.
     */
    isThrowOnErrorEnabled() {
        return this.throwOnError;
    }
    /**
     * Centralizes return handling with optional error throwing. When `throwOnError` is enabled
     * and the provided result contains a non-nullish error, the error is thrown instead of
     * being returned. This ensures consistent behavior across all public API methods.
     */
    _returnResult(result) {
        if (this.throwOnError && result && result.error) {
            throw result.error;
        }
        return result;
    }
    _logPrefix() {
        return ('GoTrueClient@' +
            `${this.storageKey}:${this.instanceID} (${version}) ${new Date().toISOString()}`);
    }
    _debug(...args) {
        if (this.logDebugMessages) {
            this.logger(this._logPrefix(), ...args);
        }
        return this;
    }
    /**
     * Initialize the auth client by loading the session from storage or
     * detecting it from the URL after an OAuth, magic-link, or password-recovery
     * redirect.
     *
     * **Most callers do not need to invoke this directly.** The client calls it
     * automatically during construction, and to react to sign-in events (including
     * post-redirect events) you should subscribe to `onAuthStateChange` rather
     * than awaiting `initialize()`.
     *
     * You only need to call it manually when you have opted out of the automatic
     * call by passing `skipAutoInitialize: true` — for example, in an SSR context
     * where you need to control initialization timing. In that case, awaiting
     * `initialize()` returns the resolved session result (or any error encountered
     * while detecting it from the URL).
     *
     * @category Auth
     */
    async initialize() {
        if (this.initializePromise) {
            return await this.initializePromise;
        }
        this.initializePromise = (async () => {
            if (this.lock != null) {
                // TODO(v3): remove legacy lock path
                return await this._acquireLock(this.lockAcquireTimeout, async () => {
                    return await this._initialize();
                });
            }
            return await this._initialize();
        })();
        return await this.initializePromise;
    }
    /**
     * IMPORTANT:
     * 1. Never throw in this method, as it is called from the constructor
     * 2. Never return a session from this method as it would be cached over
     *    the whole lifetime of the client
     */
    async _initialize() {
        var _a;
        try {
            let params = {};
            let callbackUrlType = 'none';
            if (isBrowser()) {
                params = parseParametersFromURL(window.location.href);
                if (this._isImplicitGrantCallback(params)) {
                    callbackUrlType = 'implicit';
                }
                else if (await this._isPKCECallback(params)) {
                    callbackUrlType = 'pkce';
                }
            }
            /**
             * Attempt to get the session from the URL only if these conditions are fulfilled
             *
             * Note: If the URL isn't one of the callback url types (implicit or pkce),
             * then there could be an existing session so we don't want to prematurely remove it
             */
            if (isBrowser() && this.detectSessionInUrl && callbackUrlType !== 'none') {
                const { data, error } = await this._getSessionFromURL(params, callbackUrlType);
                if (error) {
                    this._debug('#_initialize()', 'error detecting session from URL', error);
                    if (isAuthImplicitGrantRedirectError(error)) {
                        const errorCode = (_a = error.details) === null || _a === void 0 ? void 0 : _a.code;
                        if (errorCode === 'identity_already_exists' ||
                            errorCode === 'identity_not_found' ||
                            errorCode === 'single_identity_not_deletable') {
                            return { error };
                        }
                    }
                    // Don't remove existing session on URL login failure.
                    // A failed attempt (e.g. reused magic link) shouldn't invalidate a valid session.
                    return { error };
                }
                const { session, redirectType } = data;
                this._debug('#_initialize()', 'detected session in URL', session, 'redirect type', redirectType);
                await this._saveSession(session);
                setTimeout(async () => {
                    if (redirectType === 'recovery') {
                        await this._notifyAllSubscribers('PASSWORD_RECOVERY', session);
                    }
                    else {
                        await this._notifyAllSubscribers('SIGNED_IN', session);
                    }
                }, 0);
                return { error: null };
            }
            // no login attempt via callback url try to recover session from storage
            await this._recoverAndRefresh();
            return { error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ error });
            }
            return this._returnResult({
                error: new AuthUnknownError('Unexpected error during initialization', error),
            });
        }
        finally {
            await this._handleVisibilityChange();
            this._debug('#_initialize()', 'end');
        }
    }
    /**
     * Creates a new anonymous user.
     *
     * @returns A session where the is_anonymous claim in the access token JWT set to true
     *
     * @category Auth
     *
     * @remarks
     * - Returns an anonymous user
     * - It is recommended to set up captcha for anonymous sign-ins to prevent abuse. You can pass in the captcha token in the `options` param.
     *
     * @example Create an anonymous user
     * ```js
     * const { data, error } = await supabase.auth.signInAnonymously({
     *   options: {
     *     captchaToken
     *   }
     * });
     * ```
     *
     * @exampleResponse Create an anonymous user
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "",
     *       "phone": "",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {},
     *       "user_metadata": {},
     *       "identities": [],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": true
     *     },
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "token_type": "bearer",
     *       "expires_in": 3600,
     *       "expires_at": 1700000000,
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "email": "",
     *         "phone": "",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "app_metadata": {},
     *         "user_metadata": {},
     *         "identities": [],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z",
     *         "is_anonymous": true
     *       }
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Create an anonymous user with custom user metadata
     * ```js
     * const { data, error } = await supabase.auth.signInAnonymously({
     *   options: {
     *     data
     *   }
     * })
     * ```
     */
    async signInAnonymously(credentials) {
        var _a, _b, _c;
        try {
            const res = await _request(this.fetch, 'POST', `${this.url}/signup`, {
                headers: this.headers,
                body: {
                    data: (_b = (_a = credentials === null || credentials === void 0 ? void 0 : credentials.options) === null || _a === void 0 ? void 0 : _a.data) !== null && _b !== void 0 ? _b : {},
                    gotrue_meta_security: { captcha_token: (_c = credentials === null || credentials === void 0 ? void 0 : credentials.options) === null || _c === void 0 ? void 0 : _c.captchaToken },
                },
                xform: _sessionResponse,
            });
            const { data, error } = res;
            if (error || !data) {
                return this._returnResult({ data: { user: null, session: null }, error: error });
            }
            const session = data.session;
            const user = data.user;
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers('SIGNED_IN', session);
            }
            return this._returnResult({ data: { user, session }, error: null });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Creates a new user.
     *
     * Be aware that if a user account exists in the system you may get back an
     * error message that attempts to hide this information from the user.
     * This method has support for PKCE via email signups. The PKCE flow cannot be used when autoconfirm is enabled.
     *
     * @returns A logged-in session if the server has "autoconfirm" ON
     * @returns A user if the server has "autoconfirm" OFF
     *
     * @category Auth
     *
     * @remarks
     * - By default, the user needs to verify their email address before logging in. To turn this off, disable **Confirm email** in [your project](/dashboard/project/_/auth/providers).
     * - **Confirm email** determines if users need to confirm their email address after signing up.
     *   - If **Confirm email** is enabled, a `user` is returned but `session` is null.
     *   - If **Confirm email** is disabled, both a `user` and a `session` are returned.
     * - When the user confirms their email address, they are redirected to the [`SITE_URL`](/docs/guides/auth/redirect-urls#use-wildcards-in-redirect-urls) by default. You can modify your `SITE_URL` or add additional redirect URLs in [your project](/dashboard/project/_/auth/url-configuration).
     * - If signUp() is called for an existing confirmed user:
     *   - When both **Confirm email** and **Confirm phone** (even when phone provider is disabled) are enabled in [your project](/dashboard/project/_/auth/providers), an obfuscated/fake user object is returned.
     *   - When either **Confirm email** or **Confirm phone** (even when phone provider is disabled) is disabled, the error message, `User already registered` is returned.
     * - To fetch the currently logged-in user, refer to [`getUser()`](/docs/reference/javascript/auth-getuser).
     *
     * @example Sign up with an email and password
     * ```js
     * const { data, error } = await supabase.auth.signUp({
     *   email: 'example@email.com',
     *   password: 'example-password',
     * })
     * ```
     *
     * @exampleResponse Sign up with an email and password
     * ```json
     * // Some fields may be null if "confirm email" is enabled.
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {},
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z"
     *     },
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "token_type": "bearer",
     *       "expires_in": 3600,
     *       "expires_at": 1700000000,
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "email": "example@email.com",
     *         "email_confirmed_at": "2024-01-01T00:00:00Z",
     *         "phone": "",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "app_metadata": {
     *           "provider": "email",
     *           "providers": [
     *             "email"
     *           ]
     *         },
     *         "user_metadata": {},
     *         "identities": [
     *           {
     *             "identity_id": "22222222-2222-2222-2222-222222222222",
     *             "id": "11111111-1111-1111-1111-111111111111",
     *             "user_id": "11111111-1111-1111-1111-111111111111",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": false,
     *               "phone_verified": false,
     *               "sub": "11111111-1111-1111-1111-111111111111"
     *             },
     *             "provider": "email",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "example@email.com"
     *           }
     *         ],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z"
     *       }
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Sign up with a phone number and password (SMS)
     * ```js
     * const { data, error } = await supabase.auth.signUp({
     *   phone: '123456789',
     *   password: 'example-password',
     *   options: {
     *     channel: 'sms'
     *   }
     * })
     * ```
     *
     * @exampleDescription Sign up with a phone number and password (whatsapp)
     * The user will be sent a WhatsApp message which contains a OTP. By default, a given user can only request a OTP once every 60 seconds. Note that a user will need to have a valid WhatsApp account that is linked to Twilio in order to use this feature.
     *
     * @example Sign up with a phone number and password (whatsapp)
     * ```js
     * const { data, error } = await supabase.auth.signUp({
     *   phone: '123456789',
     *   password: 'example-password',
     *   options: {
     *     channel: 'whatsapp'
     *   }
     * })
     * ```
     *
     * @example Sign up with additional user metadata
     * ```js
     * const { data, error } = await supabase.auth.signUp(
     *   {
     *     email: 'example@email.com',
     *     password: 'example-password',
     *     options: {
     *       data: {
     *         first_name: 'John',
     *         age: 27,
     *       }
     *     }
     *   }
     * )
     * ```
     *
     * @exampleDescription Sign up with a redirect URL
     * - See [redirect URLs and wildcards](/docs/guides/auth/redirect-urls#use-wildcards-in-redirect-urls) to add additional redirect URLs to your project.
     *
     * @example Sign up with a redirect URL
     * ```js
     * const { data, error } = await supabase.auth.signUp(
     *   {
     *     email: 'example@email.com',
     *     password: 'example-password',
     *     options: {
     *       emailRedirectTo: 'https://example.com/welcome'
     *     }
     *   }
     * )
     * ```
     */
    async signUp(credentials) {
        var _a, _b, _c;
        try {
            let res;
            if ('email' in credentials) {
                const { email, password, options } = credentials;
                let codeChallenge = null;
                let codeChallengeMethod = null;
                if (this.flowType === 'pkce') {
                    ;
                    [codeChallenge, codeChallengeMethod] = await getCodeChallengeAndMethod(this.storage, this.storageKey);
                }
                res = await _request(this.fetch, 'POST', `${this.url}/signup`, {
                    headers: this.headers,
                    redirectTo: options === null || options === void 0 ? void 0 : options.emailRedirectTo,
                    body: {
                        email,
                        password,
                        data: (_a = options === null || options === void 0 ? void 0 : options.data) !== null && _a !== void 0 ? _a : {},
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                        code_challenge: codeChallenge,
                        code_challenge_method: codeChallengeMethod,
                    },
                    xform: _sessionResponse,
                });
            }
            else if ('phone' in credentials) {
                const { phone, password, options } = credentials;
                res = await _request(this.fetch, 'POST', `${this.url}/signup`, {
                    headers: this.headers,
                    body: {
                        phone,
                        password,
                        data: (_b = options === null || options === void 0 ? void 0 : options.data) !== null && _b !== void 0 ? _b : {},
                        channel: (_c = options === null || options === void 0 ? void 0 : options.channel) !== null && _c !== void 0 ? _c : 'sms',
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                    },
                    xform: _sessionResponse,
                });
            }
            else {
                throw new AuthInvalidCredentialsError('You must provide either an email or phone number and a password');
            }
            const { data, error } = res;
            if (error || !data) {
                await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
                return this._returnResult({ data: { user: null, session: null }, error: error });
            }
            const session = data.session;
            const user = data.user;
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers('SIGNED_IN', session);
            }
            return this._returnResult({ data: { user, session }, error: null });
        }
        catch (error) {
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Log in an existing user with an email and password or phone and password.
     *
     * Be aware that you may get back an error message that will not distinguish
     * between the cases where the account does not exist or that the
     * email/phone and password combination is wrong or that the account can only
     * be accessed via social login.
     *
     * @category Auth
     *
     * @remarks
     * - Requires either an email and password or a phone number and password.
     *
     * @example Sign in with email and password
     * ```js
     * const { data, error } = await supabase.auth.signInWithPassword({
     *   email: 'example@email.com',
     *   password: 'example-password',
     * })
     * ```
     *
     * @exampleResponse Sign in with email and password
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {},
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z"
     *     },
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "token_type": "bearer",
     *       "expires_in": 3600,
     *       "expires_at": 1700000000,
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "email": "example@email.com",
     *         "email_confirmed_at": "2024-01-01T00:00:00Z",
     *         "phone": "",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "app_metadata": {
     *           "provider": "email",
     *           "providers": [
     *             "email"
     *           ]
     *         },
     *         "user_metadata": {},
     *         "identities": [
     *           {
     *             "identity_id": "22222222-2222-2222-2222-222222222222",
     *             "id": "11111111-1111-1111-1111-111111111111",
     *             "user_id": "11111111-1111-1111-1111-111111111111",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": false,
     *               "phone_verified": false,
     *               "sub": "11111111-1111-1111-1111-111111111111"
     *             },
     *             "provider": "email",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "example@email.com"
     *           }
     *         ],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z"
     *       }
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Sign in with phone and password
     * ```js
     * const { data, error } = await supabase.auth.signInWithPassword({
     *   phone: '+13334445555',
     *   password: 'some-password',
     * })
     * ```
     *
     * @exampleDescription Handling errors
     * Log the full `error` object so fields like `code`, `status`, and `name` aren't hidden. The `error.code` (e.g. `'invalid_credentials'`, `'email_not_confirmed'`) is often more useful for branching than `error.message`, and the full object surfaces both.
     *
     * @example Handling errors
     * ```js
     * const { data, error } = await supabase.auth.signInWithPassword({
     *   email: 'example@email.com',
     *   password: 'example-password',
     * })
     * if (error) {
     *   console.error(error)
     *   return
     * }
     * ```
     */
    async signInWithPassword(credentials) {
        try {
            let res;
            if ('email' in credentials) {
                const { email, password, options } = credentials;
                res = await _request(this.fetch, 'POST', `${this.url}/token?grant_type=password`, {
                    headers: this.headers,
                    body: {
                        email,
                        password,
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                    },
                    xform: _sessionResponsePassword,
                });
            }
            else if ('phone' in credentials) {
                const { phone, password, options } = credentials;
                res = await _request(this.fetch, 'POST', `${this.url}/token?grant_type=password`, {
                    headers: this.headers,
                    body: {
                        phone,
                        password,
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                    },
                    xform: _sessionResponsePassword,
                });
            }
            else {
                throw new AuthInvalidCredentialsError('You must provide either an email or phone number and a password');
            }
            const { data, error } = res;
            if (error) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            else if (!data || !data.session || !data.user) {
                const invalidTokenError = new AuthInvalidTokenResponseError();
                return this._returnResult({ data: { user: null, session: null }, error: invalidTokenError });
            }
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers('SIGNED_IN', data.session);
            }
            return this._returnResult({
                data: Object.assign({ user: data.user, session: data.session }, (data.weak_password ? { weakPassword: data.weak_password } : null)),
                error,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Log in an existing user via a third-party provider.
     * This method supports the PKCE flow.
     *
     * @category Auth
     *
     * @remarks
     * - This method is used for signing in using [Social Login (OAuth) providers](/docs/guides/auth#configure-third-party-providers).
     * - It works by redirecting your application to the provider's authorization screen, before bringing back the user to your app.
     *
     * @example Sign in using a third-party provider
     * ```js
     * const { data, error } = await supabase.auth.signInWithOAuth({
     *   provider: 'github'
     * })
     * ```
     *
     * @exampleResponse Sign in using a third-party provider
     * ```json
     * {
     *   data: {
     *     provider: 'github',
     *     url: <PROVIDER_URL_TO_REDIRECT_TO>
     *   },
     *   error: null
     * }
     * ```
     *
     * @exampleDescription Sign in using a third-party provider with redirect
     * - When the OAuth provider successfully authenticates the user, they are redirected to the URL specified in the `redirectTo` parameter. This parameter defaults to the [`SITE_URL`](/docs/guides/auth/redirect-urls#use-wildcards-in-redirect-urls). It does not redirect the user immediately after invoking this method.
     * - See [redirect URLs and wildcards](/docs/guides/auth/redirect-urls#use-wildcards-in-redirect-urls) to add additional redirect URLs to your project.
     *
     * @example Sign in using a third-party provider with redirect
     * ```js
     * const { data, error } = await supabase.auth.signInWithOAuth({
     *   provider: 'github',
     *   options: {
     *     redirectTo: 'https://example.com/welcome'
     *   }
     * })
     * ```
     *
     * @exampleDescription Sign in with scopes and access provider tokens
     * If you need additional access from an OAuth provider, in order to access provider specific APIs in the name of the user, you can do this by passing in the scopes the user should authorize for your application. Note that the `scopes` option takes in **a space-separated list** of scopes.
     *
     * Because OAuth sign-in often includes redirects, you should register an `onAuthStateChange` callback immediately after you create the Supabase client. This callback will listen for the presence of `provider_token` and `provider_refresh_token` properties on the `session` object and store them in local storage. The client library will emit these values **only once** immediately after the user signs in. You can then access them by looking them up in local storage, or send them to your backend servers for further processing.
     *
     * Finally, make sure you remove them from local storage on the `SIGNED_OUT` event. If the OAuth provider supports token revocation, make sure you call those APIs either from the frontend or schedule them to be called on the backend.
     *
     * @example Sign in with scopes and access provider tokens
     * ```js
     * // Register this immediately after calling createClient!
     * // Because signInWithOAuth causes a redirect, you need to fetch the
     * // provider tokens from the callback.
     * supabase.auth.onAuthStateChange((event, session) => {
     *   if (session && session.provider_token) {
     *     window.localStorage.setItem('oauth_provider_token', session.provider_token)
     *   }
     *
     *   if (session && session.provider_refresh_token) {
     *     window.localStorage.setItem('oauth_provider_refresh_token', session.provider_refresh_token)
     *   }
     *
     *   if (event === 'SIGNED_OUT') {
     *     window.localStorage.removeItem('oauth_provider_token')
     *     window.localStorage.removeItem('oauth_provider_refresh_token')
     *   }
     * })
     *
     * // Call this on your Sign in with GitHub button to initiate OAuth
     * // with GitHub with the requested elevated scopes.
     * await supabase.auth.signInWithOAuth({
     *   provider: 'github',
     *   options: {
     *     scopes: 'repo gist notifications'
     *   }
     * })
     * ```
     */
    async signInWithOAuth(credentials) {
        var _a, _b, _c, _d;
        return await this._handleProviderSignIn(credentials.provider, {
            redirectTo: (_a = credentials.options) === null || _a === void 0 ? void 0 : _a.redirectTo,
            scopes: (_b = credentials.options) === null || _b === void 0 ? void 0 : _b.scopes,
            queryParams: (_c = credentials.options) === null || _c === void 0 ? void 0 : _c.queryParams,
            skipBrowserRedirect: (_d = credentials.options) === null || _d === void 0 ? void 0 : _d.skipBrowserRedirect,
        });
    }
    /**
     * Log in an existing user by exchanging an Auth Code issued during the PKCE flow.
     *
     * @category Auth
     *
     * @remarks
     * - Used when `flowType` is set to `pkce` in client options.
     *
     * @example Exchange Auth Code
     * ```js
     * supabase.auth.exchangeCodeForSession('34e770dd-9ff9-416c-87fa-43b31d7ef225')
     * ```
     *
     * @exampleResponse Exchange Auth Code
     * ```json
     * {
     *   "data": {
     *     session: {
     *       access_token: '<ACCESS_TOKEN>',
     *       token_type: 'bearer',
     *       expires_in: 3600,
     *       expires_at: 1700000000,
     *       refresh_token: '<REFRESH_TOKEN>',
     *       user: {
     *         id: '11111111-1111-1111-1111-111111111111',
     *         aud: 'authenticated',
     *         role: 'authenticated',
     *         email: 'example@email.com'
     *         email_confirmed_at: '2024-01-01T00:00:00Z',
     *         phone: '',
     *         confirmation_sent_at: '2024-01-01T00:00:00Z',
     *         confirmed_at: '2024-01-01T00:00:00Z',
     *         last_sign_in_at: '2024-01-01T00:00:00Z',
     *         app_metadata: {
     *           "provider": "email",
     *           "providers": [
     *             "email",
     *             "<OTHER_PROVIDER>"
     *           ]
     *         },
     *         user_metadata: {
     *           email: 'email@email.com',
     *           email_verified: true,
     *           full_name: 'User Name',
     *           iss: '<ISS>',
     *           name: 'User Name',
     *           phone_verified: false,
     *           provider_id: '<PROVIDER_ID>',
     *           sub: '<SUB>'
     *         },
     *         identities: [
     *           {
     *             "identity_id": "22222222-2222-2222-2222-222222222222",
     *             "id": "11111111-1111-1111-1111-111111111111",
     *             "user_id": "11111111-1111-1111-1111-111111111111",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": false,
     *               "phone_verified": false,
     *               "sub": "11111111-1111-1111-1111-111111111111"
     *             },
     *             "provider": "email",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "email@example.com"
     *           },
     *           {
     *             "identity_id": "33333333-3333-3333-3333-333333333333",
     *             "id": "<ID>",
     *             "user_id": "<USER_ID>",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": true,
     *               "full_name": "User Name",
     *               "iss": "<ISS>",
     *               "name": "User Name",
     *               "phone_verified": false,
     *               "provider_id": "<PROVIDER_ID>",
     *               "sub": "<SUB>"
     *             },
     *             "provider": "<PROVIDER>",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "example@email.com"
     *           }
     *         ],
     *         created_at: '2024-01-01T00:00:00Z',
     *         updated_at: '2024-01-01T00:00:00Z',
     *         is_anonymous: false
     *       },
     *       provider_token: '<PROVIDER_TOKEN>',
     *       provider_refresh_token: '<PROVIDER_REFRESH_TOKEN>'
     *     },
     *     user: {
     *       id: '11111111-1111-1111-1111-111111111111',
     *       aud: 'authenticated',
     *       role: 'authenticated',
     *       email: 'example@email.com',
     *       email_confirmed_at: '2024-01-01T00:00:00Z',
     *       phone: '',
     *       confirmation_sent_at: '2024-01-01T00:00:00Z',
     *       confirmed_at: '2024-01-01T00:00:00Z',
     *       last_sign_in_at: '2024-01-01T00:00:00Z',
     *       app_metadata: {
     *         provider: 'email',
     *         providers: [
     *           "email",
     *           "<OTHER_PROVIDER>"
     *         ]
     *       },
     *       user_metadata: {
     *         email: 'email@email.com',
     *         email_verified: true,
     *         full_name: 'User Name',
     *         iss: '<ISS>',
     *         name: 'User Name',
     *         phone_verified: false,
     *         provider_id: '<PROVIDER_ID>',
     *         sub: '<SUB>'
     *       },
     *       identities: [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "email@example.com"
     *         },
     *         {
     *           "identity_id": "33333333-3333-3333-3333-333333333333",
     *           "id": "<ID>",
     *           "user_id": "<USER_ID>",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": true,
     *             "full_name": "User Name",
     *             "iss": "<ISS>",
     *             "name": "User Name",
     *             "phone_verified": false,
     *             "provider_id": "<PROVIDER_ID>",
     *             "sub": "<SUB>"
     *           },
     *           "provider": "<PROVIDER>",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       created_at: '2024-01-01T00:00:00Z',
     *       updated_at: '2024-01-01T00:00:00Z',
     *       is_anonymous: false
     *     },
     *     redirectType: null
     *   },
     *   "error": null
     * }
     * ```
     */
    async exchangeCodeForSession(authCode) {
        await this.initializePromise;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return this._acquireLock(this.lockAcquireTimeout, async () => {
                return this._exchangeCodeForSession(authCode);
            });
        }
        return this._exchangeCodeForSession(authCode);
    }
    /**
     * Signs in a user by verifying a message signed by the user's private key.
     * Supports Ethereum (via Sign-In-With-Ethereum) & Solana (Sign-In-With-Solana) standards,
     * both of which derive from the EIP-4361 standard
     * With slight variation on Solana's side.
     * @reference https://eips.ethereum.org/EIPS/eip-4361
     *
     * @category Auth
     *
     * @remarks
     * - Uses a Web3 (Ethereum, Solana) wallet to sign a user in.
     * - Read up on the [potential for abuse](/docs/guides/auth/auth-web3#potential-for-abuse) before using it.
     *
     * @example Sign in with Solana or Ethereum (Window API)
     * ```js
     *   // uses window.ethereum for the wallet
     *   const { data, error } = await supabase.auth.signInWithWeb3({
     *     chain: 'ethereum',
     *     statement: 'I accept the Terms of Service at https://example.com/tos'
     *   })
     *
     *   // uses window.solana for the wallet
     *   const { data, error } = await supabase.auth.signInWithWeb3({
     *     chain: 'solana',
     *     statement: 'I accept the Terms of Service at https://example.com/tos'
     *   })
     * ```
     *
     * @example Sign in with Ethereum (Message and Signature)
     * ```js
     *   const { data, error } = await supabase.auth.signInWithWeb3({
     *     chain: 'ethereum',
     *     message: '<sign in with ethereum message>',
     *     signature: '<hex of the ethereum signature over the message>',
     *   })
     * ```
     *
     * @example Sign in with Solana (Brave)
     * ```js
     *   const { data, error } = await supabase.auth.signInWithWeb3({
     *     chain: 'solana',
     *     statement: 'I accept the Terms of Service at https://example.com/tos',
     *     wallet: window.braveSolana
     *   })
     * ```
     *
     * @example Sign in with Solana (Wallet Adapter)
     * ```jsx
     *   function SignInButton() {
     *   const wallet = useWallet()
     *
     *   return (
     *     <>
     *       {wallet.connected ? (
     *         <button
     *           onClick={() => {
     *             supabase.auth.signInWithWeb3({
     *               chain: 'solana',
     *               statement: 'I accept the Terms of Service at https://example.com/tos',
     *               wallet,
     *             })
     *           }}
     *         >
     *           Sign in with Solana
     *         </button>
     *       ) : (
     *         <WalletMultiButton />
     *       )}
     *     </>
     *   )
     * }
     *
     * function App() {
     *   const endpoint = clusterApiUrl('devnet')
     *   const wallets = useMemo(() => [], [])
     *
     *   return (
     *     <ConnectionProvider endpoint={endpoint}>
     *       <WalletProvider wallets={wallets}>
     *         <WalletModalProvider>
     *           <SignInButton />
     *         </WalletModalProvider>
     *       </WalletProvider>
     *     </ConnectionProvider>
     *   )
     * }
     * ```
     */
    async signInWithWeb3(credentials) {
        const { chain } = credentials;
        switch (chain) {
            case 'ethereum':
                return await this.signInWithEthereum(credentials);
            case 'solana':
                return await this.signInWithSolana(credentials);
            default:
                throw new Error(`@supabase/auth-js: Unsupported chain "${chain}"`);
        }
    }
    async signInWithEthereum(credentials) {
        var _a, _b, _c, _d, _f, _g, _h, _j, _k, _l, _m;
        // TODO: flatten type
        let message;
        let signature;
        if ('message' in credentials) {
            message = credentials.message;
            signature = credentials.signature;
        }
        else {
            const { chain, wallet, statement, options } = credentials;
            let resolvedWallet;
            if (!isBrowser()) {
                if (typeof wallet !== 'object' || !(options === null || options === void 0 ? void 0 : options.url)) {
                    throw new Error('@supabase/auth-js: Both wallet and url must be specified in non-browser environments.');
                }
                resolvedWallet = wallet;
            }
            else if (typeof wallet === 'object') {
                resolvedWallet = wallet;
            }
            else {
                const windowAny = window;
                if ('ethereum' in windowAny &&
                    typeof windowAny.ethereum === 'object' &&
                    'request' in windowAny.ethereum &&
                    typeof windowAny.ethereum.request === 'function') {
                    resolvedWallet = windowAny.ethereum;
                }
                else {
                    throw new Error(`@supabase/auth-js: No compatible Ethereum wallet interface on the window object (window.ethereum) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'ethereum', wallet: resolvedUserWallet }) instead.`);
                }
            }
            const url = new URL((_a = options === null || options === void 0 ? void 0 : options.url) !== null && _a !== void 0 ? _a : window.location.href);
            const accounts = await resolvedWallet
                .request({
                method: 'eth_requestAccounts',
            })
                .then((accs) => accs)
                .catch(() => {
                throw new Error(`@supabase/auth-js: Wallet method eth_requestAccounts is missing or invalid`);
            });
            if (!accounts || accounts.length === 0) {
                throw new Error(`@supabase/auth-js: No accounts available. Please ensure the wallet is connected.`);
            }
            const address = getAddress(accounts[0]);
            let chainId = (_b = options === null || options === void 0 ? void 0 : options.signInWithEthereum) === null || _b === void 0 ? void 0 : _b.chainId;
            if (!chainId) {
                const chainIdHex = await resolvedWallet.request({
                    method: 'eth_chainId',
                });
                chainId = fromHex(chainIdHex);
            }
            const siweMessage = {
                domain: url.host,
                address: address,
                statement: statement,
                uri: url.href,
                version: '1',
                chainId: chainId,
                nonce: (_c = options === null || options === void 0 ? void 0 : options.signInWithEthereum) === null || _c === void 0 ? void 0 : _c.nonce,
                issuedAt: (_f = (_d = options === null || options === void 0 ? void 0 : options.signInWithEthereum) === null || _d === void 0 ? void 0 : _d.issuedAt) !== null && _f !== void 0 ? _f : new Date(),
                expirationTime: (_g = options === null || options === void 0 ? void 0 : options.signInWithEthereum) === null || _g === void 0 ? void 0 : _g.expirationTime,
                notBefore: (_h = options === null || options === void 0 ? void 0 : options.signInWithEthereum) === null || _h === void 0 ? void 0 : _h.notBefore,
                requestId: (_j = options === null || options === void 0 ? void 0 : options.signInWithEthereum) === null || _j === void 0 ? void 0 : _j.requestId,
                resources: (_k = options === null || options === void 0 ? void 0 : options.signInWithEthereum) === null || _k === void 0 ? void 0 : _k.resources,
            };
            message = createSiweMessage(siweMessage);
            // Sign message
            signature = (await resolvedWallet.request({
                method: 'personal_sign',
                params: [toHex(message), address],
            }));
        }
        try {
            const { data, error } = await _request(this.fetch, 'POST', `${this.url}/token?grant_type=web3`, {
                headers: this.headers,
                body: Object.assign({ chain: 'ethereum', message,
                    signature }, (((_l = credentials.options) === null || _l === void 0 ? void 0 : _l.captchaToken)
                    ? { gotrue_meta_security: { captcha_token: (_m = credentials.options) === null || _m === void 0 ? void 0 : _m.captchaToken } }
                    : null)),
                xform: _sessionResponse,
            });
            if (error) {
                throw error;
            }
            if (!data || !data.session || !data.user) {
                const invalidTokenError = new AuthInvalidTokenResponseError();
                return this._returnResult({ data: { user: null, session: null }, error: invalidTokenError });
            }
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers('SIGNED_IN', data.session);
            }
            return this._returnResult({ data: Object.assign({}, data), error });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    async signInWithSolana(credentials) {
        var _a, _b, _c, _d, _f, _g, _h, _j, _k, _l, _m, _o;
        let message;
        let signature;
        if ('message' in credentials) {
            message = credentials.message;
            signature = credentials.signature;
        }
        else {
            const { chain, wallet, statement, options } = credentials;
            let resolvedWallet;
            if (!isBrowser()) {
                if (typeof wallet !== 'object' || !(options === null || options === void 0 ? void 0 : options.url)) {
                    throw new Error('@supabase/auth-js: Both wallet and url must be specified in non-browser environments.');
                }
                resolvedWallet = wallet;
            }
            else if (typeof wallet === 'object') {
                resolvedWallet = wallet;
            }
            else {
                const windowAny = window;
                if ('solana' in windowAny &&
                    typeof windowAny.solana === 'object' &&
                    (('signIn' in windowAny.solana && typeof windowAny.solana.signIn === 'function') ||
                        ('signMessage' in windowAny.solana &&
                            typeof windowAny.solana.signMessage === 'function'))) {
                    resolvedWallet = windowAny.solana;
                }
                else {
                    throw new Error(`@supabase/auth-js: No compatible Solana wallet interface on the window object (window.solana) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'solana', wallet: resolvedUserWallet }) instead.`);
                }
            }
            const url = new URL((_a = options === null || options === void 0 ? void 0 : options.url) !== null && _a !== void 0 ? _a : window.location.href);
            if ('signIn' in resolvedWallet && resolvedWallet.signIn) {
                const output = await resolvedWallet.signIn(Object.assign(Object.assign(Object.assign({ issuedAt: new Date().toISOString() }, options === null || options === void 0 ? void 0 : options.signInWithSolana), { 
                    // non-overridable properties
                    version: '1', domain: url.host, uri: url.href }), (statement ? { statement } : null)));
                let outputToProcess;
                if (Array.isArray(output) && output[0] && typeof output[0] === 'object') {
                    outputToProcess = output[0];
                }
                else if (output &&
                    typeof output === 'object' &&
                    'signedMessage' in output &&
                    'signature' in output) {
                    outputToProcess = output;
                }
                else {
                    throw new Error('@supabase/auth-js: Wallet method signIn() returned unrecognized value');
                }
                if ('signedMessage' in outputToProcess &&
                    'signature' in outputToProcess &&
                    (typeof outputToProcess.signedMessage === 'string' ||
                        outputToProcess.signedMessage instanceof Uint8Array) &&
                    outputToProcess.signature instanceof Uint8Array) {
                    message =
                        typeof outputToProcess.signedMessage === 'string'
                            ? outputToProcess.signedMessage
                            : new TextDecoder().decode(outputToProcess.signedMessage);
                    signature = outputToProcess.signature;
                }
                else {
                    throw new Error('@supabase/auth-js: Wallet method signIn() API returned object without signedMessage and signature fields');
                }
            }
            else {
                if (!('signMessage' in resolvedWallet) ||
                    typeof resolvedWallet.signMessage !== 'function' ||
                    !('publicKey' in resolvedWallet) ||
                    typeof resolvedWallet !== 'object' ||
                    !resolvedWallet.publicKey ||
                    !('toBase58' in resolvedWallet.publicKey) ||
                    typeof resolvedWallet.publicKey.toBase58 !== 'function') {
                    throw new Error('@supabase/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API');
                }
                message = [
                    `${url.host} wants you to sign in with your Solana account:`,
                    resolvedWallet.publicKey.toBase58(),
                    ...(statement ? ['', statement, ''] : ['']),
                    'Version: 1',
                    `URI: ${url.href}`,
                    `Issued At: ${(_c = (_b = options === null || options === void 0 ? void 0 : options.signInWithSolana) === null || _b === void 0 ? void 0 : _b.issuedAt) !== null && _c !== void 0 ? _c : new Date().toISOString()}`,
                    ...(((_d = options === null || options === void 0 ? void 0 : options.signInWithSolana) === null || _d === void 0 ? void 0 : _d.notBefore)
                        ? [`Not Before: ${options.signInWithSolana.notBefore}`]
                        : []),
                    ...(((_f = options === null || options === void 0 ? void 0 : options.signInWithSolana) === null || _f === void 0 ? void 0 : _f.expirationTime)
                        ? [`Expiration Time: ${options.signInWithSolana.expirationTime}`]
                        : []),
                    ...(((_g = options === null || options === void 0 ? void 0 : options.signInWithSolana) === null || _g === void 0 ? void 0 : _g.chainId)
                        ? [`Chain ID: ${options.signInWithSolana.chainId}`]
                        : []),
                    ...(((_h = options === null || options === void 0 ? void 0 : options.signInWithSolana) === null || _h === void 0 ? void 0 : _h.nonce) ? [`Nonce: ${options.signInWithSolana.nonce}`] : []),
                    ...(((_j = options === null || options === void 0 ? void 0 : options.signInWithSolana) === null || _j === void 0 ? void 0 : _j.requestId)
                        ? [`Request ID: ${options.signInWithSolana.requestId}`]
                        : []),
                    ...(((_l = (_k = options === null || options === void 0 ? void 0 : options.signInWithSolana) === null || _k === void 0 ? void 0 : _k.resources) === null || _l === void 0 ? void 0 : _l.length)
                        ? [
                            'Resources',
                            ...options.signInWithSolana.resources.map((resource) => `- ${resource}`),
                        ]
                        : []),
                ].join('\n');
                const maybeSignature = await resolvedWallet.signMessage(new TextEncoder().encode(message), 'utf8');
                if (!maybeSignature || !(maybeSignature instanceof Uint8Array)) {
                    throw new Error('@supabase/auth-js: Wallet signMessage() API returned an recognized value');
                }
                signature = maybeSignature;
            }
        }
        try {
            const { data, error } = await _request(this.fetch, 'POST', `${this.url}/token?grant_type=web3`, {
                headers: this.headers,
                body: Object.assign({ chain: 'solana', message, signature: bytesToBase64URL(signature) }, (((_m = credentials.options) === null || _m === void 0 ? void 0 : _m.captchaToken)
                    ? { gotrue_meta_security: { captcha_token: (_o = credentials.options) === null || _o === void 0 ? void 0 : _o.captchaToken } }
                    : null)),
                xform: _sessionResponse,
            });
            if (error) {
                throw error;
            }
            if (!data || !data.session || !data.user) {
                const invalidTokenError = new AuthInvalidTokenResponseError();
                return this._returnResult({ data: { user: null, session: null }, error: invalidTokenError });
            }
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers('SIGNED_IN', data.session);
            }
            return this._returnResult({ data: Object.assign({}, data), error });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    async _exchangeCodeForSession(authCode) {
        const storageItem = await getItemAsync(this.storage, `${this.storageKey}-code-verifier`);
        const [codeVerifier, redirectType] = (storageItem !== null && storageItem !== void 0 ? storageItem : '').split('/');
        try {
            if (!codeVerifier && this.flowType === 'pkce') {
                throw new AuthPKCECodeVerifierMissingError();
            }
            const { data, error } = await _request(this.fetch, 'POST', `${this.url}/token?grant_type=pkce`, {
                headers: this.headers,
                body: {
                    auth_code: authCode,
                    code_verifier: codeVerifier,
                },
                xform: _sessionResponse,
            });
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (error) {
                throw error;
            }
            if (!data || !data.session || !data.user) {
                const invalidTokenError = new AuthInvalidTokenResponseError();
                return this._returnResult({
                    data: { user: null, session: null, redirectType: null },
                    error: invalidTokenError,
                });
            }
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers(redirectType === 'recovery' ? 'PASSWORD_RECOVERY' : 'SIGNED_IN', data.session);
            }
            return this._returnResult({ data: Object.assign(Object.assign({}, data), { redirectType: redirectType !== null && redirectType !== void 0 ? redirectType : null }), error });
        }
        catch (error) {
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (isAuthError(error)) {
                return this._returnResult({
                    data: { user: null, session: null, redirectType: null },
                    error,
                });
            }
            throw error;
        }
    }
    /**
     * Allows signing in with an OIDC ID token. The authentication provider used
     * should be enabled and configured.
     *
     * @category Auth
     *
     * @remarks
     * - Use an ID token to sign in.
     * - Especially useful when implementing sign in using native platform dialogs in mobile or desktop apps using Sign in with Apple or Sign in with Google on iOS and Android.
     * - You can also use Google's [One Tap](https://developers.google.com/identity/gsi/web/guides/display-google-one-tap) and [Automatic sign-in](https://developers.google.com/identity/gsi/web/guides/automatic-sign-in-sign-out) via this API.
     *
     * @example Sign In using ID Token
     * ```js
     * const { data, error } = await supabase.auth.signInWithIdToken({
     *   provider: 'google',
     *   token: 'your-id-token'
     * })
     * ```
     *
     * @exampleResponse Sign In using ID Token
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         ...
     *       },
     *       "user_metadata": {
     *         ...
     *       },
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "provider": "google",
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *     },
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "token_type": "bearer",
     *       "expires_in": 3600,
     *       "expires_at": 1700000000,
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "app_metadata": {
     *           ...
     *         },
     *         "user_metadata": {
     *           ...
     *         },
     *         "identities": [
     *           {
     *             "identity_id": "22222222-2222-2222-2222-222222222222",
     *             "provider": "google",
     *           }
     *         ],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z",
     *       }
     *     }
     *   },
     *   "error": null
     * }
     * ```
     */
    async signInWithIdToken(credentials) {
        try {
            const { options, provider, token, access_token, nonce } = credentials;
            const res = await _request(this.fetch, 'POST', `${this.url}/token?grant_type=id_token`, {
                headers: this.headers,
                body: {
                    provider,
                    id_token: token,
                    access_token,
                    nonce,
                    gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                },
                xform: _sessionResponse,
            });
            const { data, error } = res;
            if (error) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            else if (!data || !data.session || !data.user) {
                const invalidTokenError = new AuthInvalidTokenResponseError();
                return this._returnResult({ data: { user: null, session: null }, error: invalidTokenError });
            }
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers('SIGNED_IN', data.session);
            }
            return this._returnResult({ data, error });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Log in a user using magiclink or a one-time password (OTP).
     *
     * If the `{{ .ConfirmationURL }}` variable is specified in the email template, a magiclink will be sent.
     * If the `{{ .Token }}` variable is specified in the email template, an OTP will be sent.
     * If you're using phone sign-ins, only an OTP will be sent. You won't be able to send a magiclink for phone sign-ins.
     *
     * Be aware that you may get back an error message that will not distinguish
     * between the cases where the account does not exist or, that the account
     * can only be accessed via social login.
     *
     * Do note that you will need to configure a Whatsapp sender on Twilio
     * if you are using phone sign in with the 'whatsapp' channel. The whatsapp
     * channel is not supported on other providers
     * at this time.
     * This method supports PKCE when an email is passed.
     *
     * @category Auth
     *
     * @remarks
     * - Requires either an email or phone number.
     * - This method is used for passwordless sign-ins where a OTP is sent to the user's email or phone number.
     * - If the user doesn't exist, `signInWithOtp()` will signup the user instead. To restrict this behavior, you can set `shouldCreateUser` in `SignInWithPasswordlessCredentials.options` to `false`.
     * - If you're using an email, you can configure whether you want the user to receive a magiclink or a OTP.
     * - If you're using phone, you can configure whether you want the user to receive a OTP.
     * - The magic link's destination URL is determined by the [`SITE_URL`](/docs/guides/auth/redirect-urls#use-wildcards-in-redirect-urls).
     * - See [redirect URLs and wildcards](/docs/guides/auth/redirect-urls#use-wildcards-in-redirect-urls) to add additional redirect URLs to your project.
     * - Magic links and OTPs share the same implementation. To send users a one-time code instead of a magic link, [modify the magic link email template](/dashboard/project/_/auth/templates) to include `{{ .Token }}` instead of `{{ .ConfirmationURL }}`.
     * - See our [Twilio Phone Auth Guide](/docs/guides/auth/phone-login?showSMSProvider=Twilio) for details about configuring WhatsApp sign in.
     *
     * @exampleDescription Sign in with email
     * The user will be sent an email which contains either a magiclink or a OTP or both. By default, a given user can only request a OTP once every 60 seconds.
     *
     * @example Sign in with email
     * ```js
     * const { data, error } = await supabase.auth.signInWithOtp({
     *   email: 'example@email.com',
     *   options: {
     *     emailRedirectTo: 'https://example.com/welcome'
     *   }
     * })
     * ```
     *
     * @exampleResponse Sign in with email
     * ```json
     * {
     *   "data": {
     *     "user": null,
     *     "session": null
     *   },
     *   "error": null
     * }
     * ```
     *
     * @exampleDescription Sign in with SMS OTP
     * The user will be sent a SMS which contains a OTP. By default, a given user can only request a OTP once every 60 seconds.
     *
     * @example Sign in with SMS OTP
     * ```js
     * const { data, error } = await supabase.auth.signInWithOtp({
     *   phone: '+13334445555',
     * })
     * ```
     *
     * @exampleDescription Sign in with WhatsApp OTP
     * The user will be sent a WhatsApp message which contains a OTP. By default, a given user can only request a OTP once every 60 seconds. Note that a user will need to have a valid WhatsApp account that is linked to Twilio in order to use this feature.
     *
     * @example Sign in with WhatsApp OTP
     * ```js
     * const { data, error } = await supabase.auth.signInWithOtp({
     *   phone: '+13334445555',
     *   options: {
     *     channel:'whatsapp',
     *   }
     * })
     * ```
     */
    async signInWithOtp(credentials) {
        var _a, _b, _c, _d, _f;
        try {
            if ('email' in credentials) {
                const { email, options } = credentials;
                let codeChallenge = null;
                let codeChallengeMethod = null;
                if (this.flowType === 'pkce') {
                    ;
                    [codeChallenge, codeChallengeMethod] = await getCodeChallengeAndMethod(this.storage, this.storageKey);
                }
                const { error } = await _request(this.fetch, 'POST', `${this.url}/otp`, {
                    headers: this.headers,
                    body: {
                        email,
                        data: (_a = options === null || options === void 0 ? void 0 : options.data) !== null && _a !== void 0 ? _a : {},
                        create_user: (_b = options === null || options === void 0 ? void 0 : options.shouldCreateUser) !== null && _b !== void 0 ? _b : true,
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                        code_challenge: codeChallenge,
                        code_challenge_method: codeChallengeMethod,
                    },
                    redirectTo: options === null || options === void 0 ? void 0 : options.emailRedirectTo,
                });
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            if ('phone' in credentials) {
                const { phone, options } = credentials;
                const { data, error } = await _request(this.fetch, 'POST', `${this.url}/otp`, {
                    headers: this.headers,
                    body: {
                        phone,
                        data: (_c = options === null || options === void 0 ? void 0 : options.data) !== null && _c !== void 0 ? _c : {},
                        create_user: (_d = options === null || options === void 0 ? void 0 : options.shouldCreateUser) !== null && _d !== void 0 ? _d : true,
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                        channel: (_f = options === null || options === void 0 ? void 0 : options.channel) !== null && _f !== void 0 ? _f : 'sms',
                    },
                });
                return this._returnResult({
                    data: { user: null, session: null, messageId: data === null || data === void 0 ? void 0 : data.message_id },
                    error,
                });
            }
            throw new AuthInvalidCredentialsError('You must provide either an email or phone number.');
        }
        catch (error) {
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Log in a user given a User supplied OTP or TokenHash received through mobile or email.
     *
     * @category Auth
     *
     * @remarks
     * - The `verifyOtp` method takes in different verification types.
     * - If a phone number is used, the type can either be:
     *   1. `sms` – Used when verifying a one-time password (OTP) sent via SMS during sign-up or sign-in.
     *   2. `phone_change` – Used when verifying an OTP sent to a new phone number during a phone number update process.
     * - If an email address is used, the type can be one of the following (note: `signup` and `magiclink` types are deprecated):
     *   1. `email` – Used when verifying an OTP sent to the user's email during sign-up or sign-in.
     *   2. `recovery` – Used when verifying an OTP sent for account recovery, typically after a password reset request.
     *   3. `invite` – Used when verifying an OTP sent as part of an invitation to join a project or organization.
     *   4. `email_change` – Used when verifying an OTP sent to a new email address during an email update process.
     * - The verification type used should be determined based on the corresponding auth method called before `verifyOtp` to sign up / sign-in a user.
     * - The `TokenHash` is contained in the [email templates](/docs/guides/auth/auth-email-templates) and can be used to sign in.  You may wish to use the hash for the PKCE flow for Server Side Auth. Read [the Password-based Auth guide](/docs/guides/auth/passwords) for more details.
     *
     * @example Verify Signup One-Time Password (OTP)
     * ```js
     * const { data, error } = await supabase.auth.verifyOtp({ email, token, type: 'email'})
     * ```
     *
     * @exampleResponse Verify Signup One-Time Password (OTP)
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "confirmed_at": "2024-01-01T00:00:00Z",
     *       "recovery_sent_at": "2024-01-01T00:00:00Z",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {
     *         "email": "example@email.com",
     *         "email_verified": false,
     *         "phone_verified": false,
     *         "sub": "11111111-1111-1111-1111-111111111111"
     *       },
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     },
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "token_type": "bearer",
     *       "expires_in": 3600,
     *       "expires_at": 1700000000,
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "email": "example@email.com",
     *         "email_confirmed_at": "2024-01-01T00:00:00Z",
     *         "phone": "",
     *         "confirmed_at": "2024-01-01T00:00:00Z",
     *         "recovery_sent_at": "2024-01-01T00:00:00Z",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "app_metadata": {
     *           "provider": "email",
     *           "providers": [
     *             "email"
     *           ]
     *         },
     *         "user_metadata": {
     *           "email": "example@email.com",
     *           "email_verified": false,
     *           "phone_verified": false,
     *           "sub": "11111111-1111-1111-1111-111111111111"
     *         },
     *         "identities": [
     *           {
     *             "identity_id": "22222222-2222-2222-2222-222222222222",
     *             "id": "11111111-1111-1111-1111-111111111111",
     *             "user_id": "11111111-1111-1111-1111-111111111111",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": false,
     *               "phone_verified": false,
     *               "sub": "11111111-1111-1111-1111-111111111111"
     *             },
     *             "provider": "email",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "example@email.com"
     *           }
     *         ],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z",
     *         "is_anonymous": false
     *       }
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Verify SMS One-Time Password (OTP)
     * ```js
     * const { data, error } = await supabase.auth.verifyOtp({ phone, token, type: 'sms'})
     * ```
     *
     * @example Verify Email Auth (Token Hash)
     * ```js
     * const { data, error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: 'email'})
     * ```
     */
    async verifyOtp(params) {
        var _a, _b;
        try {
            let redirectTo = undefined;
            let captchaToken = undefined;
            if ('options' in params) {
                redirectTo = (_a = params.options) === null || _a === void 0 ? void 0 : _a.redirectTo;
                captchaToken = (_b = params.options) === null || _b === void 0 ? void 0 : _b.captchaToken;
            }
            const { data, error } = await _request(this.fetch, 'POST', `${this.url}/verify`, {
                headers: this.headers,
                body: Object.assign(Object.assign({}, params), { gotrue_meta_security: { captcha_token: captchaToken } }),
                redirectTo,
                xform: _sessionResponse,
            });
            if (error) {
                throw error;
            }
            if (!data) {
                const tokenVerificationError = new Error('An error occurred on token verification.');
                throw tokenVerificationError;
            }
            const session = data.session;
            const user = data.user;
            if (session === null || session === void 0 ? void 0 : session.access_token) {
                await this._saveSession(session);
                await this._notifyAllSubscribers(params.type == 'recovery' ? 'PASSWORD_RECOVERY' : 'SIGNED_IN', session);
            }
            return this._returnResult({ data: { user, session }, error: null });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Attempts a single-sign on using an enterprise Identity Provider. A
     * successful SSO attempt will redirect the current page to the identity
     * provider authorization page. The redirect URL is implementation and SSO
     * protocol specific.
     *
     * You can use it by providing a SSO domain. Typically you can extract this
     * domain by asking users for their email address. If this domain is
     * registered on the Auth instance the redirect will use that organization's
     * currently active SSO Identity Provider for the login.
     *
     * If you have built an organization-specific login page, you can use the
     * organization's SSO Identity Provider UUID directly instead.
     *
     * @category Auth
     *
     * @remarks
     * - Before you can call this method you need to [establish a connection](/docs/guides/auth/sso/auth-sso-saml#managing-saml-20-connections) to an identity provider. Use the [CLI commands](/docs/reference/cli/supabase-sso) to do this.
     * - If you've associated an email domain to the identity provider, you can use the `domain` property to start a sign-in flow.
     * - In case you need to use a different way to start the authentication flow with an identity provider, you can use the `providerId` property. For example:
     *     - Mapping specific user email addresses with an identity provider.
     *     - Using different hints to identity the identity provider to be used by the user, like a company-specific page, IP address or other tracking information.
     *
     * @example Sign in with email domain
     * ```js
     *   // You can extract the user's email domain and use it to trigger the
     *   // authentication flow with the correct identity provider.
     *
     *   const { data, error } = await supabase.auth.signInWithSSO({
     *     domain: 'company.com'
     *   })
     *
     *   if (data?.url) {
     *     // redirect the user to the identity provider's authentication flow
     *     window.location.href = data.url
     *   }
     * ```
     *
     * @example Sign in with provider UUID
     * ```js
     *   // Useful when you need to map a user's sign in request according
     *   // to different rules that can't use email domains.
     *
     *   const { data, error } = await supabase.auth.signInWithSSO({
     *     providerId: '21648a9d-8d5a-4555-a9d1-d6375dc14e92'
     *   })
     *
     *   if (data?.url) {
     *     // redirect the user to the identity provider's authentication flow
     *     window.location.href = data.url
     *   }
     * ```
     */
    async signInWithSSO(params) {
        var _a, _b, _c, _d, _f;
        try {
            let codeChallenge = null;
            let codeChallengeMethod = null;
            if (this.flowType === 'pkce') {
                ;
                [codeChallenge, codeChallengeMethod] = await getCodeChallengeAndMethod(this.storage, this.storageKey);
            }
            const result = await _request(this.fetch, 'POST', `${this.url}/sso`, {
                body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, ('providerId' in params ? { provider_id: params.providerId } : null)), ('domain' in params ? { domain: params.domain } : null)), { redirect_to: (_b = (_a = params.options) === null || _a === void 0 ? void 0 : _a.redirectTo) !== null && _b !== void 0 ? _b : undefined }), (((_c = params === null || params === void 0 ? void 0 : params.options) === null || _c === void 0 ? void 0 : _c.captchaToken)
                    ? { gotrue_meta_security: { captcha_token: params.options.captchaToken } }
                    : null)), { skip_http_redirect: true, code_challenge: codeChallenge, code_challenge_method: codeChallengeMethod }),
                headers: this.headers,
                xform: _ssoResponse,
            });
            // Automatically redirect in browser unless skipBrowserRedirect is true
            if (((_d = result.data) === null || _d === void 0 ? void 0 : _d.url) && isBrowser() && !((_f = params.options) === null || _f === void 0 ? void 0 : _f.skipBrowserRedirect)) {
                window.location.assign(result.data.url);
            }
            return this._returnResult(result);
        }
        catch (error) {
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Sends a reauthentication OTP to the user's email or phone number.
     * Requires the user to be signed-in.
     *
     * @category Auth
     *
     * @remarks
     * - This method is used together with `updateUser()` when a user's password needs to be updated.
     * - If you require your user to reauthenticate before updating their password, you need to enable the **Secure password change** option in your [project's email provider settings](/dashboard/project/_/auth/providers).
     * - A user is only require to reauthenticate before updating their password if **Secure password change** is enabled and the user **hasn't recently signed in**. A user is deemed recently signed in if the session was created in the last 24 hours.
     * - This method will send a nonce to the user's email. If the user doesn't have a confirmed email address, the method will send the nonce to the user's confirmed phone number instead.
     * - After receiving the OTP, include it as the `nonce` in your `updateUser()` call to finalize the password change.
     *
     * @exampleDescription Send reauthentication nonce
     * Sends a reauthentication nonce to the user's email or phone number.
     *
     * @example Send reauthentication nonce
     * ```js
     * const { error } = await supabase.auth.reauthenticate()
     * ```
     */
    async reauthenticate() {
        await this.initializePromise;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return await this._acquireLock(this.lockAcquireTimeout, async () => {
                return await this._reauthenticate();
            });
        }
        return await this._reauthenticate();
    }
    async _reauthenticate() {
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError)
                    throw sessionError;
                if (!session)
                    throw new AuthSessionMissingError();
                const { error } = await _request(this.fetch, 'GET', `${this.url}/reauthenticate`, {
                    headers: this.headers,
                    jwt: session.access_token,
                });
                return this._returnResult({ data: { user: null, session: null }, error });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Resends an existing signup confirmation email, email change email, SMS OTP or phone change OTP.
     *
     * @category Auth
     *
     * @remarks
     * - Resends a signup confirmation, email change or phone change email to the user.
     * - Passwordless sign-ins can be resent by calling the `signInWithOtp()` method again.
     * - Password recovery emails can be resent by calling the `resetPasswordForEmail()` method again.
     * - This method will only resend an email or phone OTP to the user if there was an initial signup, email change or phone change request being made(note: For existing users signing in with OTP, you should use `signInWithOtp()` again to resend the OTP).
     * - You can specify a redirect url when you resend an email link using the `emailRedirectTo` option.
     *
     * @exampleDescription Resend an email signup confirmation
     * Resends the email signup confirmation to the user
     *
     * @example Resend an email signup confirmation
     * ```js
     * const { error } = await supabase.auth.resend({
     *   type: 'signup',
     *   email: 'email@example.com',
     *   options: {
     *     emailRedirectTo: 'https://example.com/welcome'
     *   }
     * })
     * ```
     *
     * @exampleDescription Resend a phone signup confirmation
     * Resends the phone signup confirmation email to the user
     *
     * @example Resend a phone signup confirmation
     * ```js
     * const { error } = await supabase.auth.resend({
     *   type: 'sms',
     *   phone: '1234567890'
     * })
     * ```
     *
     * @exampleDescription Resend email change email
     * Resends the email change email to the user
     *
     * @example Resend email change email
     * ```js
     * const { error } = await supabase.auth.resend({
     *   type: 'email_change',
     *   email: 'email@example.com'
     * })
     * ```
     *
     * @exampleDescription Resend phone change OTP
     * Resends the phone change OTP to the user
     *
     * @example Resend phone change OTP
     * ```js
     * const { error } = await supabase.auth.resend({
     *   type: 'phone_change',
     *   phone: '1234567890'
     * })
     * ```
     */
    async resend(credentials) {
        try {
            const endpoint = `${this.url}/resend`;
            if ('email' in credentials) {
                const { email, type, options } = credentials;
                let codeChallenge = null;
                let codeChallengeMethod = null;
                if (this.flowType === 'pkce') {
                    ;
                    [codeChallenge, codeChallengeMethod] = await getCodeChallengeAndMethod(this.storage, this.storageKey);
                }
                const { error } = await _request(this.fetch, 'POST', endpoint, {
                    headers: this.headers,
                    body: {
                        email,
                        type,
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                        code_challenge: codeChallenge,
                        code_challenge_method: codeChallengeMethod,
                    },
                    redirectTo: options === null || options === void 0 ? void 0 : options.emailRedirectTo,
                });
                if (error) {
                    await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
                }
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            else if ('phone' in credentials) {
                const { phone, type, options } = credentials;
                const { data, error } = await _request(this.fetch, 'POST', endpoint, {
                    headers: this.headers,
                    body: {
                        phone,
                        type,
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                    },
                });
                return this._returnResult({
                    data: { user: null, session: null, messageId: data === null || data === void 0 ? void 0 : data.message_id },
                    error,
                });
            }
            throw new AuthInvalidCredentialsError('You must provide either an email or phone number and a type');
        }
        catch (error) {
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Returns the session, refreshing it if necessary.
     *
     * The session returned can be null if the session is not detected which can happen in the event a user is not signed-in or has logged out.
     *
     * **IMPORTANT:** This method loads values directly from the storage attached
     * to the client. If that storage is based on request cookies for example,
     * the values in it may not be authentic and therefore it's strongly advised
     * against using this method and its results in such circumstances. A warning
     * will be emitted if this is detected. Use {@link #getUser()} instead.
     *
     * @category Auth
     *
     * @remarks
     * - Since the introduction of [asymmetric JWT signing keys](/docs/guides/auth/signing-keys), this method is considered low-level and we encourage you to use `getClaims()` or `getUser()` instead.
     * - Retrieves the current [user session](/docs/guides/auth/sessions) from the storage medium (local storage, cookies).
     * - The session contains an access token (signed JWT), a refresh token and the user object.
     * - If the session's access token is expired or is about to expire, this method will use the refresh token to refresh the session.
     * - When using in a browser, or you've called `startAutoRefresh()` in your environment (React Native, etc.) this function always returns a valid access token without refreshing the session itself, as this is done in the background. This function returns very fast.
     * - **IMPORTANT SECURITY NOTICE:** If using an insecure storage medium, such as cookies or request headers, the user object returned by this function **must not be trusted**. Always verify the JWT using `getClaims()` or your own JWT verification library to securely establish the user's identity and access. You can also use `getUser()` to fetch the user object directly from the Auth server for this purpose.
     * - Cross-tab refresh races are handled by the GoTrue server (the rotated token from the first tab is returned to subsequent tabs via the parent-of-active mechanism), so no client-side serialization is needed.
     *
     * @example Get the session data
     * ```js
     * const { data, error } = await supabase.auth.getSession()
     * ```
     *
     * @exampleResponse Get the session data
     * ```json
     * {
     *   "data": {
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "token_type": "bearer",
     *       "expires_in": 3600,
     *       "expires_at": 1700000000,
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "email": "example@email.com",
     *         "email_confirmed_at": "2024-01-01T00:00:00Z",
     *         "phone": "",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "app_metadata": {
     *           "provider": "email",
     *           "providers": [
     *             "email"
     *           ]
     *         },
     *         "user_metadata": {
     *           "email": "example@email.com",
     *           "email_verified": false,
     *           "phone_verified": false,
     *           "sub": "11111111-1111-1111-1111-111111111111"
     *         },
     *         "identities": [
     *           {
     *             "identity_id": "22222222-2222-2222-2222-222222222222",
     *             "id": "11111111-1111-1111-1111-111111111111",
     *             "user_id": "11111111-1111-1111-1111-111111111111",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": false,
     *               "phone_verified": false,
     *               "sub": "11111111-1111-1111-1111-111111111111"
     *             },
     *             "provider": "email",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "example@email.com"
     *           }
     *         ],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z",
     *         "is_anonymous": false
     *       }
     *     }
     *   },
     *   "error": null
     * }
     * ```
     */
    async getSession() {
        await this.initializePromise;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return await this._acquireLock(this.lockAcquireTimeout, async () => {
                return this._useSession(async (result) => {
                    return result;
                });
            });
        }
        return await this._useSession(async (result) => {
            return result;
        });
    }
    /**
     * Acquires a global lock based on the storage key.
     *
     * TODO(v3): remove along with the legacy lock path. Only called when
     * `this.lock` is non-null (custom lock supplied via constructor). The
     * default lockless path bypasses this entirely.
     */
    async _acquireLock(acquireTimeout, fn) {
        this._debug('#_acquireLock', 'begin', acquireTimeout);
        try {
            if (this.lockAcquired) {
                const last = this.pendingInLock.length
                    ? this.pendingInLock[this.pendingInLock.length - 1]
                    : Promise.resolve();
                const result = (async () => {
                    await last;
                    return await fn();
                })();
                this.pendingInLock.push((async () => {
                    try {
                        await result;
                    }
                    catch (_e) {
                        // we just care if it finished
                    }
                })());
                return result;
            }
            return await this.lock(`lock:${this.storageKey}`, acquireTimeout, async () => {
                this._debug('#_acquireLock', 'lock acquired for storage key', this.storageKey);
                try {
                    this.lockAcquired = true;
                    const result = fn();
                    this.pendingInLock.push((async () => {
                        try {
                            await result;
                        }
                        catch (e) {
                            // we just care if it finished
                        }
                    })());
                    await result;
                    // keep draining the queue until there's nothing to wait on
                    while (this.pendingInLock.length) {
                        const waitOn = [...this.pendingInLock];
                        await Promise.all(waitOn);
                        this.pendingInLock.splice(0, waitOn.length);
                    }
                    return await result;
                }
                finally {
                    this._debug('#_acquireLock', 'lock released for storage key', this.storageKey);
                    this.lockAcquired = false;
                }
            });
        }
        finally {
            this._debug('#_acquireLock', 'end');
        }
    }
    /**
     * Use instead of {@link #getSession} inside the library. Loads the session
     * via `__loadSession` (which may trigger a refresh if the access token is
     * within the expiry margin) and runs `fn` with the result.
     */
    async _useSession(fn) {
        this._debug('#_useSession', 'begin');
        try {
            // Concurrent callers may both reach __loadSession; storage reads are
            // idempotent, and the only write path inside it (refresh) is
            // single-flighted downstream by `refreshingDeferred` in
            // `_callRefreshToken`. No serialization is needed at this layer.
            const result = await this.__loadSession();
            return await fn(result);
        }
        finally {
            this._debug('#_useSession', 'end');
        }
    }
    /**
     * NEVER USE DIRECTLY!
     *
     * Always use {@link #_useSession}.
     */
    async __loadSession() {
        this._debug('#__loadSession()', 'begin');
        if (this.lock != null && !this.lockAcquired) {
            // TODO(v3): remove. Only meaningful on the legacy lock path.
            this._debug('#__loadSession()', 'used outside of an acquired lock!', new Error().stack);
        }
        try {
            let currentSession = null;
            const maybeSession = await getItemAsync(this.storage, this.storageKey);
            this._debug('#getSession()', 'session from storage', maybeSession);
            if (maybeSession !== null) {
                if (this._isValidSession(maybeSession)) {
                    currentSession = maybeSession;
                }
                else {
                    this._debug('#getSession()', 'session from storage is not valid');
                    await this._removeSession();
                }
            }
            if (!currentSession) {
                return { data: { session: null }, error: null };
            }
            // A session is considered expired before the access token _actually_
            // expires. When the autoRefreshToken option is off (or when the tab is
            // in the background), very eager users of getSession() -- like
            // realtime-js -- might send a valid JWT which will expire by the time it
            // reaches the server.
            const hasExpired = currentSession.expires_at
                ? currentSession.expires_at * 1000 - Date.now() < EXPIRY_MARGIN_MS
                : false;
            this._debug('#__loadSession()', `session has${hasExpired ? '' : ' not'} expired`, 'expires_at', currentSession.expires_at);
            if (!hasExpired) {
                if (this.userStorage) {
                    const maybeUser = (await getItemAsync(this.userStorage, this.storageKey + '-user'));
                    if (maybeUser === null || maybeUser === void 0 ? void 0 : maybeUser.user) {
                        currentSession.user = maybeUser.user;
                    }
                    else {
                        currentSession.user = userNotAvailableProxy();
                    }
                }
                // Wrap the user object with a warning proxy on the server
                // This warns when properties of the user are accessed, not when session.user itself is accessed
                if (this.storage.isServer &&
                    currentSession.user &&
                    !currentSession.user.__isUserNotAvailableProxy) {
                    const suppressWarningRef = { value: this.suppressGetSessionWarning };
                    currentSession.user = insecureUserWarningProxy(currentSession.user, suppressWarningRef);
                    // Update the client-level suppression flag when the proxy suppresses the warning
                    if (suppressWarningRef.value) {
                        this.suppressGetSessionWarning = true;
                    }
                }
                return { data: { session: currentSession }, error: null };
            }
            const { data: session, error } = await this._callRefreshToken(currentSession.refresh_token);
            if (error) {
                return this._returnResult({ data: { session: null }, error });
            }
            return this._returnResult({ data: { session }, error: null });
        }
        finally {
            this._debug('#__loadSession()', 'end');
        }
    }
    /**
     * Gets the current user details if there is an existing session. This method
     * performs a network request to the Supabase Auth server, so the returned
     * value is authentic and can be used to base authorization rules on.
     *
     * @param jwt Takes in an optional access token JWT. If no JWT is provided, the JWT from the current session is used.
     *
     * @category Auth
     *
     * @remarks
     * - This method fetches the user object from the database instead of local session.
     * - This method is useful for checking if the user is authorized because it validates the user's access token JWT on the server.
     * - Should always be used when checking for user authorization on the server. On the client, you can instead use `getSession().session.user` for faster results. `getSession` is insecure on the server.
     *
     * @example Get the logged in user with the current existing session
     * ```js
     * const { data: { user } } = await supabase.auth.getUser()
     * ```
     *
     * @exampleResponse Get the logged in user with the current existing session
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "confirmed_at": "2024-01-01T00:00:00Z",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {
     *         "email": "example@email.com",
     *         "email_verified": false,
     *         "phone_verified": false,
     *         "sub": "11111111-1111-1111-1111-111111111111"
     *       },
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Get the logged in user with a custom access token jwt
     * ```js
     * const { data: { user } } = await supabase.auth.getUser(jwt)
     * ```
     */
    async getUser(jwt) {
        if (jwt) {
            return await this._getUser(jwt);
        }
        await this.initializePromise;
        let result;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            result = await this._acquireLock(this.lockAcquireTimeout, async () => {
                return await this._getUser();
            });
        }
        else {
            result = await this._getUser();
        }
        if (result.data.user) {
            this.suppressGetSessionWarning = true;
        }
        return result;
    }
    async _getUser(jwt) {
        try {
            if (jwt) {
                return await _request(this.fetch, 'GET', `${this.url}/user`, {
                    headers: this.headers,
                    jwt: jwt,
                    xform: _userResponse,
                });
            }
            return await this._useSession(async (result) => {
                var _a, _b, _c;
                const { data, error } = result;
                if (error) {
                    throw error;
                }
                // returns an error if there is no access_token or custom authorization header
                if (!((_a = data.session) === null || _a === void 0 ? void 0 : _a.access_token) && !this.hasCustomAuthorizationHeader) {
                    return { data: { user: null }, error: new AuthSessionMissingError() };
                }
                return await _request(this.fetch, 'GET', `${this.url}/user`, {
                    headers: this.headers,
                    jwt: (_c = (_b = data.session) === null || _b === void 0 ? void 0 : _b.access_token) !== null && _c !== void 0 ? _c : undefined,
                    xform: _userResponse,
                });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                if (isAuthSessionMissingError(error)) {
                    // JWT contains a `session_id` which does not correspond to an active
                    // session in the database, indicating the user is signed out.
                    await this._removeSession();
                    await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
                }
                return this._returnResult({ data: { user: null }, error });
            }
            throw error;
        }
    }
    /**
     * Updates user data for a logged in user.
     *
     * @category Auth
     *
     * @remarks
     * - In order to use the `updateUser()` method, the user needs to be signed in first.
     * - By default, email updates sends a confirmation link to both the user's current and new email.
     * To only send a confirmation link to the user's new email, disable **Secure email change** in your project's [email auth provider settings](/dashboard/project/_/auth/providers).
     *
     * @exampleDescription Update the email for an authenticated user
     * Sends a "Confirm Email Change" email to the new address. If **Secure Email Change** is enabled (default), confirmation is also required from the **old email** before the change is applied. To skip dual confirmation and apply the change after only the new email is verified, disable **Secure Email Change** in the [Email Auth Provider settings](/dashboard/project/_/auth/providers?provider=Email).
     *
     * @example Update the email for an authenticated user
     * ```js
     * const { data, error } = await supabase.auth.updateUser({
     *   email: 'new@email.com'
     * })
     * ```
     *
     * @exampleResponse Update the email for an authenticated user
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "confirmed_at": "2024-01-01T00:00:00Z",
     *       "new_email": "new@email.com",
     *       "email_change_sent_at": "2024-01-01T00:00:00Z",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {
     *         "email": "example@email.com",
     *         "email_verified": false,
     *         "phone_verified": false,
     *         "sub": "11111111-1111-1111-1111-111111111111"
     *       },
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @exampleDescription Update the phone number for an authenticated user
     * Sends a one-time password (OTP) to the new phone number.
     *
     * @example Update the phone number for an authenticated user
     * ```js
     * const { data, error } = await supabase.auth.updateUser({
     *   phone: '123456789'
     * })
     * ```
     *
     * @example Update the password for an authenticated user
     * ```js
     * const { data, error } = await supabase.auth.updateUser({
     *   password: 'new password'
     * })
     * ```
     *
     * @exampleDescription Update the user's metadata
     * Updates the user's custom metadata.
     *
     * **Note**: The `data` field maps to the `auth.users.raw_user_meta_data` column in your Supabase database. When calling `getUser()`, the data will be available as `user.user_metadata`.
     *
     * @example Update the user's metadata
     * ```js
     * const { data, error } = await supabase.auth.updateUser({
     *   data: { hello: 'world' }
     * })
     * ```
     *
     * @exampleDescription Update the user's password with a nonce
     * If **Secure password change** is enabled in your [project's email provider settings](/dashboard/project/_/auth/providers), updating the user's password would require a nonce if the user **hasn't recently signed in**. The nonce is sent to the user's email or phone number. A user is deemed recently signed in if the session was created in the last 24 hours.
     *
     * @example Update the user's password with a nonce
     * ```js
     * const { data, error } = await supabase.auth.updateUser({
     *   password: 'new password',
     *   nonce: '123456'
     * })
     * ```
     */
    async updateUser(attributes, options = {}) {
        await this.initializePromise;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return await this._acquireLock(this.lockAcquireTimeout, async () => {
                return await this._updateUser(attributes, options);
            });
        }
        return await this._updateUser(attributes, options);
    }
    async _updateUser(attributes, options = {}) {
        try {
            return await this._useSession(async (result) => {
                const { data: sessionData, error: sessionError } = result;
                if (sessionError) {
                    throw sessionError;
                }
                if (!sessionData.session) {
                    throw new AuthSessionMissingError();
                }
                const session = sessionData.session;
                let codeChallenge = null;
                let codeChallengeMethod = null;
                if (this.flowType === 'pkce' && attributes.email != null) {
                    ;
                    [codeChallenge, codeChallengeMethod] = await getCodeChallengeAndMethod(this.storage, this.storageKey);
                }
                const { data, error: userError } = await _request(this.fetch, 'PUT', `${this.url}/user`, {
                    headers: this.headers,
                    redirectTo: options === null || options === void 0 ? void 0 : options.emailRedirectTo,
                    body: Object.assign(Object.assign({}, attributes), { code_challenge: codeChallenge, code_challenge_method: codeChallengeMethod }),
                    jwt: session.access_token,
                    xform: _userResponse,
                });
                if (userError) {
                    throw userError;
                }
                session.user = data.user;
                await this._saveSession(session);
                await this._notifyAllSubscribers('USER_UPDATED', session);
                return this._returnResult({ data: { user: session.user }, error: null });
            });
        }
        catch (error) {
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null }, error });
            }
            throw error;
        }
    }
    /**
     * Sets the session data from the current session. If the current session is expired, setSession will take care of refreshing it to obtain a new session.
     * If the refresh token or access token in the current session is invalid, an error will be thrown.
     * @param currentSession The current session that minimally contains an access token and refresh token.
     *
     * @category Auth
     *
     * @remarks
     * - This method sets the session using an `access_token` and `refresh_token`.
     * - If successful, a `SIGNED_IN` event is emitted.
     *
     * @exampleDescription Set the session
     * Sets the session data from an access_token and refresh_token, then returns an auth response or error.
     *
     * @example Set the session
     * ```js
     *   const { data, error } = await supabase.auth.setSession({
     *     access_token,
     *     refresh_token
     *   })
     * ```
     *
     * @exampleResponse Set the session
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "confirmed_at": "2024-01-01T00:00:00Z",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {
     *         "email": "example@email.com",
     *         "email_verified": false,
     *         "phone_verified": false,
     *         "sub": "11111111-1111-1111-1111-111111111111"
     *       },
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     },
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "email": "example@email.com",
     *         "email_confirmed_at": "2024-01-01T00:00:00Z",
     *         "phone": "",
     *         "confirmed_at": "2024-01-01T00:00:00Z",
     *         "last_sign_in_at": "11111111-1111-1111-1111-111111111111",
     *         "app_metadata": {
     *           "provider": "email",
     *           "providers": [
     *             "email"
     *           ]
     *         },
     *         "user_metadata": {
     *           "email": "example@email.com",
     *           "email_verified": false,
     *           "phone_verified": false,
     *           "sub": "11111111-1111-1111-1111-111111111111"
     *         },
     *         "identities": [
     *           {
     *             "identity_id": "2024-01-01T00:00:00Z",
     *             "id": "11111111-1111-1111-1111-111111111111",
     *             "user_id": "11111111-1111-1111-1111-111111111111",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": false,
     *               "phone_verified": false,
     *               "sub": "11111111-1111-1111-1111-111111111111"
     *             },
     *             "provider": "email",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "example@email.com"
     *           }
     *         ],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z",
     *         "is_anonymous": false
     *       },
     *       "token_type": "bearer",
     *       "expires_in": 3500,
     *       "expires_at": 1700000000
     *     }
     *   },
     *   "error": null
     * }
     * ```
     */
    async setSession(currentSession) {
        await this.initializePromise;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return await this._acquireLock(this.lockAcquireTimeout, async () => {
                return await this._setSession(currentSession);
            });
        }
        return await this._setSession(currentSession);
    }
    async _setSession(currentSession) {
        try {
            if (!currentSession.access_token || !currentSession.refresh_token) {
                throw new AuthSessionMissingError();
            }
            const timeNow = Date.now() / 1000;
            let expiresAt = timeNow;
            let hasExpired = true;
            let session = null;
            const { payload } = decodeJWT(currentSession.access_token);
            if (payload.exp) {
                expiresAt = payload.exp;
                hasExpired = expiresAt <= timeNow;
            }
            if (hasExpired) {
                const { data: refreshedSession, error } = await this._callRefreshToken(currentSession.refresh_token);
                if (error) {
                    return this._returnResult({ data: { user: null, session: null }, error: error });
                }
                if (!refreshedSession) {
                    return { data: { user: null, session: null }, error: null };
                }
                session = refreshedSession;
            }
            else {
                const { data, error } = await this._getUser(currentSession.access_token);
                if (error) {
                    return this._returnResult({ data: { user: null, session: null }, error });
                }
                session = {
                    access_token: currentSession.access_token,
                    refresh_token: currentSession.refresh_token,
                    user: data.user,
                    token_type: 'bearer',
                    expires_in: expiresAt - timeNow,
                    expires_at: expiresAt,
                };
                await this._saveSession(session);
                await this._notifyAllSubscribers('SIGNED_IN', session);
            }
            return this._returnResult({ data: { user: session.user, session }, error: null });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { session: null, user: null }, error });
            }
            throw error;
        }
    }
    /**
     * Returns a new session, regardless of expiry status.
     * Takes in an optional current session. If not passed in, then refreshSession() will attempt to retrieve it from getSession().
     * If the current session's refresh token is invalid, an error will be thrown.
     * @param currentSession The current session. If passed in, it must contain a refresh token.
     *
     * @category Auth
     *
     * @remarks
     * - This method will refresh and return a new session whether the current one is expired or not.
     *
     * @example Refresh session using the current session
     * ```js
     * const { data, error } = await supabase.auth.refreshSession()
     * const { session, user } = data
     * ```
     *
     * @exampleResponse Refresh session using the current session
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "confirmed_at": "2024-01-01T00:00:00Z",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {
     *         "email": "example@email.com",
     *         "email_verified": false,
     *         "phone_verified": false,
     *         "sub": "11111111-1111-1111-1111-111111111111"
     *       },
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     },
     *     "session": {
     *       "access_token": "<ACCESS_TOKEN>",
     *       "token_type": "bearer",
     *       "expires_in": 3600,
     *       "expires_at": 1700000000,
     *       "refresh_token": "<REFRESH_TOKEN>",
     *       "user": {
     *         "id": "11111111-1111-1111-1111-111111111111",
     *         "aud": "authenticated",
     *         "role": "authenticated",
     *         "email": "example@email.com",
     *         "email_confirmed_at": "2024-01-01T00:00:00Z",
     *         "phone": "",
     *         "confirmed_at": "2024-01-01T00:00:00Z",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "app_metadata": {
     *           "provider": "email",
     *           "providers": [
     *             "email"
     *           ]
     *         },
     *         "user_metadata": {
     *           "email": "example@email.com",
     *           "email_verified": false,
     *           "phone_verified": false,
     *           "sub": "11111111-1111-1111-1111-111111111111"
     *         },
     *         "identities": [
     *           {
     *             "identity_id": "22222222-2222-2222-2222-222222222222",
     *             "id": "11111111-1111-1111-1111-111111111111",
     *             "user_id": "11111111-1111-1111-1111-111111111111",
     *             "identity_data": {
     *               "email": "example@email.com",
     *               "email_verified": false,
     *               "phone_verified": false,
     *               "sub": "11111111-1111-1111-1111-111111111111"
     *             },
     *             "provider": "email",
     *             "last_sign_in_at": "2024-01-01T00:00:00Z",
     *             "created_at": "2024-01-01T00:00:00Z",
     *             "updated_at": "2024-01-01T00:00:00Z",
     *             "email": "example@email.com"
     *           }
     *         ],
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z",
     *         "is_anonymous": false
     *       }
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Refresh session using a refresh token
     * ```js
     * const { data, error } = await supabase.auth.refreshSession({ refresh_token })
     * const { session, user } = data
     * ```
     */
    async refreshSession(currentSession) {
        await this.initializePromise;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return await this._acquireLock(this.lockAcquireTimeout, async () => {
                return await this._refreshSession(currentSession);
            });
        }
        return await this._refreshSession(currentSession);
    }
    async _refreshSession(currentSession) {
        try {
            return await this._useSession(async (result) => {
                var _a;
                if (!currentSession) {
                    const { data, error } = result;
                    if (error) {
                        throw error;
                    }
                    currentSession = (_a = data.session) !== null && _a !== void 0 ? _a : undefined;
                }
                if (!(currentSession === null || currentSession === void 0 ? void 0 : currentSession.refresh_token)) {
                    throw new AuthSessionMissingError();
                }
                const { data: session, error } = await this._callRefreshToken(currentSession.refresh_token);
                if (error) {
                    return this._returnResult({ data: { user: null, session: null }, error: error });
                }
                if (!session) {
                    return this._returnResult({ data: { user: null, session: null }, error: null });
                }
                return this._returnResult({ data: { user: session.user, session }, error: null });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { user: null, session: null }, error });
            }
            throw error;
        }
    }
    /**
     * Gets the session data from a URL string
     */
    async _getSessionFromURL(params, callbackUrlType) {
        var _a;
        try {
            if (!isBrowser())
                throw new AuthImplicitGrantRedirectError('No browser detected.');
            // If there's an error in the URL, it doesn't matter what flow it is, we just return the error.
            if (params.error || params.error_description || params.error_code) {
                // The error class returned implies that the redirect is from an implicit grant flow
                // but it could also be from a redirect error from a PKCE flow.
                throw new AuthImplicitGrantRedirectError(params.error_description || 'Error in URL with unspecified error_description', {
                    error: params.error || 'unspecified_error',
                    code: params.error_code || 'unspecified_code',
                });
            }
            // Checks for mismatches between the flowType initialised in the client and the URL parameters
            switch (callbackUrlType) {
                case 'implicit':
                    if (this.flowType === 'pkce') {
                        throw new AuthPKCEGrantCodeExchangeError('Not a valid PKCE flow url.');
                    }
                    break;
                case 'pkce':
                    if (this.flowType === 'implicit') {
                        throw new AuthImplicitGrantRedirectError('Not a valid implicit grant flow url.');
                    }
                    break;
                default:
                // there's no mismatch so we continue
            }
            // Since this is a redirect for PKCE, we attempt to retrieve the code from the URL for the code exchange
            if (callbackUrlType === 'pkce') {
                this._debug('#_initialize()', 'begin', 'is PKCE flow', true);
                if (!params.code)
                    throw new AuthPKCEGrantCodeExchangeError('No code detected.');
                const { data, error } = await this._exchangeCodeForSession(params.code);
                if (error)
                    throw error;
                const url = new URL(window.location.href);
                url.searchParams.delete('code');
                window.history.replaceState(window.history.state, '', url.toString());
                return {
                    data: { session: data.session, redirectType: (_a = data.redirectType) !== null && _a !== void 0 ? _a : null },
                    error: null,
                };
            }
            const { provider_token, provider_refresh_token, access_token, refresh_token, expires_in, expires_at, token_type, } = params;
            if (!access_token || !expires_in || !refresh_token || !token_type) {
                throw new AuthImplicitGrantRedirectError('No session defined in URL');
            }
            const timeNow = Math.round(Date.now() / 1000);
            const expiresIn = parseInt(expires_in);
            let expiresAt = timeNow + expiresIn;
            if (expires_at) {
                expiresAt = parseInt(expires_at);
            }
            const actuallyExpiresIn = expiresAt - timeNow;
            if (actuallyExpiresIn * 1000 <= AUTO_REFRESH_TICK_DURATION_MS) {
                console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${actuallyExpiresIn}s, should have been closer to ${expiresIn}s`);
            }
            const issuedAt = expiresAt - expiresIn;
            if (timeNow - issuedAt >= 120) {
                console.warn('@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale', issuedAt, expiresAt, timeNow);
            }
            else if (timeNow - issuedAt < 0) {
                console.warn('@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew', issuedAt, expiresAt, timeNow);
            }
            const { data, error } = await this._getUser(access_token);
            if (error)
                throw error;
            const session = {
                provider_token,
                provider_refresh_token,
                access_token,
                expires_in: expiresIn,
                expires_at: expiresAt,
                refresh_token,
                token_type: token_type,
                user: data.user,
            };
            // Remove tokens from URL
            window.location.hash = '';
            this._debug('#_getSessionFromURL()', 'clearing window.location.hash');
            return this._returnResult({ data: { session, redirectType: params.type }, error: null });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { session: null, redirectType: null }, error });
            }
            throw error;
        }
    }
    /**
     * Checks if the current URL contains parameters given by an implicit oauth grant flow (https://www.rfc-editor.org/rfc/rfc6749.html#section-4.2)
     *
     * If `detectSessionInUrl` is a function, it will be called with the URL and params to determine
     * if the URL should be processed as a Supabase auth callback. This allows users to exclude
     * URLs from other OAuth providers (e.g., Facebook Login) that also return access_token in the fragment.
     */
    _isImplicitGrantCallback(params) {
        if (typeof this.detectSessionInUrl === 'function') {
            return this.detectSessionInUrl(new URL(window.location.href), params);
        }
        return Boolean(params.access_token || params.error || params.error_description || params.error_code);
    }
    /**
     * Checks if the current URL and backing storage contain parameters given by a PKCE flow
     */
    async _isPKCECallback(params) {
        const currentStorageContent = await getItemAsync(this.storage, `${this.storageKey}-code-verifier`);
        return !!(params.code && currentStorageContent);
    }
    /**
     * Inside a browser context, `signOut()` will remove the logged in user from the browser session and log them out - removing all items from localstorage and then trigger a `"SIGNED_OUT"` event.
     *
     * For server-side management, you can revoke all refresh tokens for a user by passing a user's JWT through to `auth.api.signOut(JWT: string)`.
     * There is no way to revoke a user's access token jwt until it expires. It is recommended to set a shorter expiry on the jwt for this reason.
     *
     * If using `others` scope, no `SIGNED_OUT` event is fired!
     *
     * **Warning:** the default `scope` is `'global'`. This signs the user out of
     * **every device they are currently signed in on**, not just the current
     * tab/session. If you only want to sign the user out of the current session
     * (the behavior most other auth libraries default to), pass
     * `{ scope: 'local' }` explicitly.
     *
     * @category Auth
     *
     * @remarks
     * - In order to use the `signOut()` method, the user needs to be signed in first.
     * - By default, `signOut()` uses the **global** scope, which signs out the user
     *   on every device they are signed in on (not just the current one). Pass
     *   `{ scope: 'local' }` to only sign out the current session. This is
     *   usually what apps want on a "Sign out" button, especially when users
     *   sign in from multiple devices and do not expect signing out of one to
     *   terminate the others.
     * - Since Supabase Auth uses JWTs for authentication, the access token JWT will be valid until it's expired. When the user signs out, Supabase revokes the refresh token and deletes the JWT from the client-side. This does not revoke the JWT and it will still be valid until it expires.
     *
     * @example Sign out of every device (global – default)
     * ```js
     * const { error } = await supabase.auth.signOut()
     * ```
     *
     * @example Sign out only the current session (recommended for most apps)
     * ```js
     * const { error } = await supabase.auth.signOut({ scope: 'local' })
     * ```
     *
     * @example Sign out of all other sessions, keep the current one
     * ```js
     * const { error } = await supabase.auth.signOut({ scope: 'others' })
     * ```
     */
    async signOut(options = { scope: 'global' }) {
        await this.initializePromise;
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return await this._acquireLock(this.lockAcquireTimeout, async () => {
                return await this._signOut(options);
            });
        }
        return await this._signOut(options);
    }
    async _signOut({ scope } = { scope: 'global' }) {
        return await this._useSession(async (result) => {
            var _a;
            const { data, error: sessionError } = result;
            if (sessionError && !isAuthSessionMissingError(sessionError)) {
                return this._returnResult({ error: sessionError });
            }
            const accessToken = (_a = data.session) === null || _a === void 0 ? void 0 : _a.access_token;
            if (accessToken) {
                const { error } = await this.admin.signOut(accessToken, scope);
                if (error) {
                    // ignore 404s since user might not exist anymore
                    // ignore 401s since an invalid or expired JWT should sign out the current session
                    if (!((isAuthApiError(error) &&
                        (error.status === 404 || error.status === 401 || error.status === 403)) ||
                        isAuthSessionMissingError(error))) {
                        return this._returnResult({ error });
                    }
                }
            }
            if (scope !== 'others') {
                await this._removeSession();
                await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            }
            return this._returnResult({ error: null });
        });
    }
    /**  *
     * @category Auth
     *
     * @remarks
     * - Subscribes to important events occurring on the user's session.
     * - Use on the frontend/client. It is less useful on the server.
     * - Events are emitted across tabs to keep your application's UI up-to-date. Some events can fire very frequently, based on the number of tabs open. Use a quick and efficient callback function, and defer or debounce as many operations as you can to be performed outside of the callback.
     * - Callbacks can be `async` and can safely call other Supabase auth methods (`getUser`, `setSession`, etc.) from inside the callback.
     * - Keep callbacks quick. Events are awaited in order, so a slow callback delays subsequent events to subscribers in this tab.
     * - Emitted events:
     *   - `INITIAL_SESSION`
     *     - Emitted right after the Supabase client is constructed and the initial session from storage is loaded.
     *   - `SIGNED_IN`
     *     - Emitted each time a user session is confirmed or re-established, including on user sign in and when refocusing a tab.
     *     - Avoid making assumptions as to when this event is fired, this may occur even when the user is already signed in. Instead, check the user object attached to the event to see if a new user has signed in and update your application's UI.
     *     - This event can fire very frequently depending on the number of tabs open in your application.
     *   - `SIGNED_OUT`
     *     - Emitted when the user signs out. This can be after:
     *       - A call to `supabase.auth.signOut()`.
     *       - After the user's session has expired for any reason:
     *         - User has signed out on another device.
     *         - The session has reached its timebox limit or inactivity timeout.
     *         - User has signed in on another device with single session per user enabled.
     *         - Check the [User Sessions](/docs/guides/auth/sessions) docs for more information.
     *     - Use this to clean up any local storage your application has associated with the user.
     *   - `TOKEN_REFRESHED`
     *     - Emitted each time a new access and refresh token are fetched for the signed in user.
     *     - It's best practice and highly recommended to extract the access token (JWT) and store it in memory for further use in your application.
     *       - Avoid frequent calls to `supabase.auth.getSession()` for the same purpose.
     *     - There is a background process that keeps track of when the session should be refreshed so you will always receive valid tokens by listening to this event.
     *     - The frequency of this event is related to the JWT expiry limit configured on your project.
     *   - `USER_UPDATED`
     *     - Emitted each time the `supabase.auth.updateUser()` method finishes successfully. Listen to it to update your application's UI based on new profile information.
     *   - `PASSWORD_RECOVERY`
     *     - Emitted instead of the `SIGNED_IN` event when the user lands on a page that includes a password recovery link in the URL.
     *     - Use it to show a UI to the user where they can [reset their password](/docs/guides/auth/passwords#resetting-a-users-password-forgot-password).
     *
     * @example Listen to auth changes
     * ```js
     * const { data } = supabase.auth.onAuthStateChange((event, session) => {
     *   console.log(event, session)
     *
     *   if (event === 'INITIAL_SESSION') {
     *     // handle initial session
     *   } else if (event === 'SIGNED_IN') {
     *     // handle sign in event
     *   } else if (event === 'SIGNED_OUT') {
     *     // handle sign out event
     *   } else if (event === 'PASSWORD_RECOVERY') {
     *     // handle password recovery event
     *   } else if (event === 'TOKEN_REFRESHED') {
     *     // handle token refreshed event
     *   } else if (event === 'USER_UPDATED') {
     *     // handle user updated event
     *   }
     * })
     *
     * // call unsubscribe to remove the callback
     * data.subscription.unsubscribe()
     * ```
     *
     * @exampleDescription Listen to sign out
     * Make sure you clear out any local data, such as local and session storage, after the client library has detected the user's sign out.
     *
     * @example Listen to sign out
     * ```js
     * supabase.auth.onAuthStateChange((event, session) => {
     *   if (event === 'SIGNED_OUT') {
     *     console.log('SIGNED_OUT', session)
     *
     *     // clear local and session storage
     *     [
     *       window.localStorage,
     *       window.sessionStorage,
     *     ].forEach((storage) => {
     *       Object.entries(storage)
     *         .forEach(([key]) => {
     *           storage.removeItem(key)
     *         })
     *     })
     *   }
     * })
     * ```
     *
     * @exampleDescription Store OAuth provider tokens on sign in
     * When using [OAuth (Social Login)](/docs/guides/auth/social-login) you sometimes wish to get access to the provider's access token and refresh token, in order to call provider APIs in the name of the user.
     *
     * For example, if you are using [Sign in with Google](/docs/guides/auth/social-login/auth-google) you may want to use the provider token to call Google APIs on behalf of the user. Supabase Auth does not keep track of the provider access and refresh token, but does return them for you once, immediately after sign in. You can use the `onAuthStateChange` method to listen for the presence of the provider tokens and store them in local storage. You can further send them to your server's APIs for use on the backend.
     *
     * Finally, make sure you remove them from local storage on the `SIGNED_OUT` event. If the OAuth provider supports token revocation, make sure you call those APIs either from the frontend or schedule them to be called on the backend.
     *
     * @example Store OAuth provider tokens on sign in
     * ```js
     * // Register this immediately after calling createClient!
     * // Because signInWithOAuth causes a redirect, you need to fetch the
     * // provider tokens from the callback.
     * supabase.auth.onAuthStateChange((event, session) => {
     *   if (session && session.provider_token) {
     *     window.localStorage.setItem('oauth_provider_token', session.provider_token)
     *   }
     *
     *   if (session && session.provider_refresh_token) {
     *     window.localStorage.setItem('oauth_provider_refresh_token', session.provider_refresh_token)
     *   }
     *
     *   if (event === 'SIGNED_OUT') {
     *     window.localStorage.removeItem('oauth_provider_token')
     *     window.localStorage.removeItem('oauth_provider_refresh_token')
     *   }
     * })
     * ```
     *
     * @exampleDescription Use React Context for the User's session
     * Instead of relying on `supabase.auth.getSession()` within your React components, you can use a [React Context](https://react.dev/reference/react/createContext) to store the latest session information from the `onAuthStateChange` callback and access it that way.
     *
     * @example Use React Context for the User's session
     * ```js
     * const SessionContext = React.createContext(null)
     *
     * function main() {
     *   const [session, setSession] = React.useState(null)
     *
     *   React.useEffect(() => {
     *     const {data: { subscription }} = supabase.auth.onAuthStateChange(
     *       (event, session) => {
     *         if (event === 'SIGNED_OUT') {
     *           setSession(null)
     *         } else if (session) {
     *           setSession(session)
     *         }
     *       })
     *
     *     return () => {
     *       subscription.unsubscribe()
     *     }
     *   }, [])
     *
     *   return (
     *     <SessionContext.Provider value={session}>
     *       <App />
     *     </SessionContext.Provider>
     *   )
     * }
     * ```
     *
     * @example Listen to password recovery events
     * ```js
     * supabase.auth.onAuthStateChange((event, session) => {
     *   if (event === 'PASSWORD_RECOVERY') {
     *     console.log('PASSWORD_RECOVERY', session)
     *     // show screen to update user's password
     *     showPasswordResetScreen(true)
     *   }
     * })
     * ```
     *
     * @example Listen to sign in
     * ```js
     * supabase.auth.onAuthStateChange((event, session) => {
     *   if (event === 'SIGNED_IN') console.log('SIGNED_IN', session)
     * })
     * ```
     *
     * @example Listen to token refresh
     * ```js
     * supabase.auth.onAuthStateChange((event, session) => {
     *   if (event === 'TOKEN_REFRESHED') console.log('TOKEN_REFRESHED', session)
     * })
     * ```
     *
     * @example Listen to user updates
     * ```js
     * supabase.auth.onAuthStateChange((event, session) => {
     *   if (event === 'USER_UPDATED') console.log('USER_UPDATED', session)
     * })
     * ```
     */
    onAuthStateChange(callback) {
        const id = generateCallbackId();
        const subscription = {
            id,
            callback,
            unsubscribe: () => {
                this._debug('#unsubscribe()', 'state change callback with id removed', id);
                this.stateChangeEmitters.delete(id);
            },
        };
        this._debug('#onAuthStateChange()', 'registered callback with id', id);
        this.stateChangeEmitters.set(id, subscription);
        (async () => {
            await this.initializePromise;
            if (this.lock != null) {
                // TODO(v3): remove legacy lock path
                await this._acquireLock(this.lockAcquireTimeout, async () => {
                    this._emitInitialSession(id);
                });
            }
            else {
                await this._emitInitialSession(id);
            }
        })();
        return { data: { subscription } };
    }
    async _emitInitialSession(id) {
        return await this._useSession(async (result) => {
            var _a, _b;
            try {
                const { data: { session }, error, } = result;
                if (error)
                    throw error;
                await ((_a = this.stateChangeEmitters.get(id)) === null || _a === void 0 ? void 0 : _a.callback('INITIAL_SESSION', session));
                this._debug('INITIAL_SESSION', 'callback id', id, 'session', session);
            }
            catch (err) {
                await ((_b = this.stateChangeEmitters.get(id)) === null || _b === void 0 ? void 0 : _b.callback('INITIAL_SESSION', null));
                this._debug('INITIAL_SESSION', 'callback id', id, 'error', err);
                if (isAuthSessionMissingError(err)) {
                    console.warn(err);
                }
                else {
                    console.error(err);
                }
            }
        });
    }
    /**
     * Sends a password reset request to an email address. This method supports the PKCE flow.
     *
     * @param email The email address of the user.
     * @param options.redirectTo The URL to send the user to after they click the password reset link.
     * @param options.captchaToken Verification token received when the user completes the captcha on the site.
     *
     * @category Auth
     *
     * @remarks
     * - The password reset flow consist of 2 broad steps: (i) Allow the user to login via the password reset link; (ii) Update the user's password.
     * - The `resetPasswordForEmail()` only sends a password reset link to the user's email.
     * To update the user's password, see [`updateUser()`](/docs/reference/javascript/auth-updateuser).
     * - A `PASSWORD_RECOVERY` event will be emitted when the password recovery link is clicked.
     * You can use [`onAuthStateChange()`](/docs/reference/javascript/auth-onauthstatechange) to listen and invoke a callback function on these events.
     * - When the user clicks the reset link in the email they are redirected back to your application.
     * You can configure the URL that the user is redirected to with the `redirectTo` parameter.
     * See [redirect URLs and wildcards](/docs/guides/auth/redirect-urls#use-wildcards-in-redirect-urls) to add additional redirect URLs to your project.
     * - After the user has been redirected successfully, prompt them for a new password and call `updateUser()`:
     * ```js
     * const { data, error } = await supabase.auth.updateUser({
     *   password: new_password
     * })
     * ```
     *
     * @example Reset password
     * ```js
     * const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
     *   redirectTo: 'https://example.com/update-password',
     * })
     * ```
     *
     * @exampleResponse Reset password
     * ```json
     * {
     *   data: {}
     *   error: null
     * }
     * ```
     *
     * @example Reset password (React)
     * ```js
     * /**
     *  * Step 1: Send the user an email to get a password reset token.
     *  * This email contains a link which sends the user back to your application.
     *  *\/
     * const { data, error } = await supabase.auth
     *   .resetPasswordForEmail('user@email.com')
     *
     * /**
     *  * Step 2: Once the user is redirected back to your application,
     *  * ask the user to reset their password.
     *  *\/
     *  useEffect(() => {
     *    supabase.auth.onAuthStateChange(async (event, session) => {
     *      if (event == "PASSWORD_RECOVERY") {
     *        const newPassword = prompt("What would you like your new password to be?");
     *        const { data, error } = await supabase.auth
     *          .updateUser({ password: newPassword })
     *
     *        if (data) alert("Password updated successfully!")
     *        if (error) alert("There was an error updating your password.")
     *      }
     *    })
     *  }, [])
     * ```
     */
    async resetPasswordForEmail(email, options = {}) {
        let codeChallenge = null;
        let codeChallengeMethod = null;
        if (this.flowType === 'pkce') {
            ;
            [codeChallenge, codeChallengeMethod] = await getCodeChallengeAndMethod(this.storage, this.storageKey, true // isPasswordRecovery
            );
        }
        try {
            return await _request(this.fetch, 'POST', `${this.url}/recover`, {
                body: {
                    email,
                    code_challenge: codeChallenge,
                    code_challenge_method: codeChallengeMethod,
                    gotrue_meta_security: { captcha_token: options.captchaToken },
                },
                headers: this.headers,
                redirectTo: options.redirectTo,
            });
        }
        catch (error) {
            await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Gets all the identities linked to a user.
     *
     * @category Auth
     *
     * @remarks
     * - The user needs to be signed in to call `getUserIdentities()`.
     *
     * @example Returns a list of identities linked to the user
     * ```js
     * const { data, error } = await supabase.auth.getUserIdentities()
     * ```
     *
     * @exampleResponse Returns a list of identities linked to the user
     * ```json
     * {
     *   "data": {
     *     "identities": [
     *       {
     *         "identity_id": "22222222-2222-2222-2222-222222222222",
     *         "id": "2024-01-01T00:00:00Z",
     *         "user_id": "2024-01-01T00:00:00Z",
     *         "identity_data": {
     *           "email": "example@email.com",
     *           "email_verified": false,
     *           "phone_verified": false,
     *           "sub": "11111111-1111-1111-1111-111111111111"
     *         },
     *         "provider": "email",
     *         "last_sign_in_at": "2024-01-01T00:00:00Z",
     *         "created_at": "2024-01-01T00:00:00Z",
     *         "updated_at": "2024-01-01T00:00:00Z",
     *         "email": "example@email.com"
     *       }
     *     ]
     *   },
     *   "error": null
     * }
     * ```
     */
    async getUserIdentities() {
        var _a;
        try {
            const { data, error } = await this.getUser();
            if (error)
                throw error;
            return this._returnResult({ data: { identities: (_a = data.user.identities) !== null && _a !== void 0 ? _a : [] }, error: null });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**  *
     * @category Auth
     *
     * @remarks
     * - The **Enable Manual Linking** option must be enabled from your [project's authentication settings](/dashboard/project/_/auth/providers).
     * - The user needs to be signed in to call `linkIdentity()`.
     * - If the candidate identity is already linked to the existing user or another user, `linkIdentity()` will fail.
     * - If `linkIdentity` is run in the browser, the user is automatically redirected to the returned URL. On the server, you should handle the redirect.
     *
     * @example Link an identity to a user
     * ```js
     * const { data, error } = await supabase.auth.linkIdentity({
     *   provider: 'github'
     * })
     * ```
     *
     * @exampleResponse Link an identity to a user
     * ```json
     * {
     *   data: {
     *     provider: 'github',
     *     url: <PROVIDER_URL_TO_REDIRECT_TO>
     *   },
     *   error: null
     * }
     * ```
     */
    async linkIdentity(credentials) {
        if ('token' in credentials) {
            return this.linkIdentityIdToken(credentials);
        }
        return this.linkIdentityOAuth(credentials);
    }
    async linkIdentityOAuth(credentials) {
        var _a;
        try {
            const { data, error } = await this._useSession(async (result) => {
                var _a, _b, _c, _d, _f;
                const { data, error } = result;
                if (error)
                    throw error;
                const url = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, credentials.provider, {
                    redirectTo: (_a = credentials.options) === null || _a === void 0 ? void 0 : _a.redirectTo,
                    scopes: (_b = credentials.options) === null || _b === void 0 ? void 0 : _b.scopes,
                    queryParams: (_c = credentials.options) === null || _c === void 0 ? void 0 : _c.queryParams,
                    skipBrowserRedirect: true,
                });
                return await _request(this.fetch, 'GET', url, {
                    headers: this.headers,
                    jwt: (_f = (_d = data.session) === null || _d === void 0 ? void 0 : _d.access_token) !== null && _f !== void 0 ? _f : undefined,
                });
            });
            if (error)
                throw error;
            if (isBrowser() && !((_a = credentials.options) === null || _a === void 0 ? void 0 : _a.skipBrowserRedirect)) {
                window.location.assign(data === null || data === void 0 ? void 0 : data.url);
            }
            return this._returnResult({
                data: { provider: credentials.provider, url: data === null || data === void 0 ? void 0 : data.url },
                error: null,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: { provider: credentials.provider, url: null }, error });
            }
            throw error;
        }
    }
    async linkIdentityIdToken(credentials) {
        return await this._useSession(async (result) => {
            var _a;
            try {
                const { error: sessionError, data: { session }, } = result;
                if (sessionError)
                    throw sessionError;
                const { options, provider, token, access_token, nonce } = credentials;
                const res = await _request(this.fetch, 'POST', `${this.url}/token?grant_type=id_token`, {
                    headers: this.headers,
                    jwt: (_a = session === null || session === void 0 ? void 0 : session.access_token) !== null && _a !== void 0 ? _a : undefined,
                    body: {
                        provider,
                        id_token: token,
                        access_token,
                        nonce,
                        link_identity: true,
                        gotrue_meta_security: { captcha_token: options === null || options === void 0 ? void 0 : options.captchaToken },
                    },
                    xform: _sessionResponse,
                });
                const { data, error } = res;
                if (error) {
                    return this._returnResult({ data: { user: null, session: null }, error });
                }
                else if (!data || !data.session || !data.user) {
                    return this._returnResult({
                        data: { user: null, session: null },
                        error: new AuthInvalidTokenResponseError(),
                    });
                }
                if (data.session) {
                    await this._saveSession(data.session);
                    await this._notifyAllSubscribers('USER_UPDATED', data.session);
                }
                return this._returnResult({ data, error });
            }
            catch (error) {
                await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
                if (isAuthError(error)) {
                    return this._returnResult({ data: { user: null, session: null }, error });
                }
                throw error;
            }
        });
    }
    /**
     * Unlinks an identity from a user by deleting it. The user will no longer be able to sign in with that identity once it's unlinked.
     *
     * @category Auth
     *
     * @remarks
     * - The **Enable Manual Linking** option must be enabled from your [project's authentication settings](/dashboard/project/_/auth/providers).
     * - The user needs to be signed in to call `unlinkIdentity()`.
     * - The user must have at least 2 identities in order to unlink an identity.
     * - The identity to be unlinked must belong to the user.
     *
     * @example Unlink an identity
     * ```js
     * // retrieve all identities linked to a user
     * const identities = await supabase.auth.getUserIdentities()
     *
     * // find the google identity
     * const googleIdentity = identities.find(
     *   identity => identity.provider === 'google'
     * )
     *
     * // unlink the google identity
     * const { error } = await supabase.auth.unlinkIdentity(googleIdentity)
     * ```
     */
    async unlinkIdentity(identity) {
        try {
            return await this._useSession(async (result) => {
                var _a, _b;
                const { data, error } = result;
                if (error) {
                    throw error;
                }
                return await _request(this.fetch, 'DELETE', `${this.url}/user/identities/${identity.identity_id}`, {
                    headers: this.headers,
                    jwt: (_b = (_a = data.session) === null || _a === void 0 ? void 0 : _a.access_token) !== null && _b !== void 0 ? _b : undefined,
                });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Generates a new JWT.
     * @param refreshToken A valid refresh token that was returned on login.
     */
    async _refreshAccessToken(refreshToken) {
        // Refresh tokens are long-lived bearer credentials; do NOT include any
        // fragment of the token in the debug tag, even when `debug: true` is
        // enabled (logs may be forwarded to third-party services).
        const debugName = `#_refreshAccessToken()`;
        this._debug(debugName, 'begin');
        try {
            const startedAt = Date.now();
            // will attempt to refresh the token with exponential backoff
            return await retryable(async (attempt) => {
                if (attempt > 0) {
                    await sleep(200 * Math.pow(2, attempt - 1)); // 200, 400, 800, ...
                }
                this._debug(debugName, 'refreshing attempt', attempt);
                return await _request(this.fetch, 'POST', `${this.url}/token?grant_type=refresh_token`, {
                    body: { refresh_token: refreshToken },
                    headers: this.headers,
                    xform: _sessionResponse,
                });
            }, (attempt, error) => {
                const nextBackOffInterval = 200 * Math.pow(2, attempt);
                return (error &&
                    isAuthRetryableFetchError(error) &&
                    // retryable only if the request can be sent before the backoff overflows the tick duration
                    Date.now() + nextBackOffInterval - startedAt < AUTO_REFRESH_TICK_DURATION_MS);
            });
        }
        catch (error) {
            this._debug(debugName, 'error', error);
            if (isAuthError(error)) {
                return this._returnResult({ data: { session: null, user: null }, error });
            }
            throw error;
        }
        finally {
            this._debug(debugName, 'end');
        }
    }
    _isValidSession(maybeSession) {
        const isValidSession = typeof maybeSession === 'object' &&
            maybeSession !== null &&
            'access_token' in maybeSession &&
            'refresh_token' in maybeSession &&
            'expires_at' in maybeSession;
        return isValidSession;
    }
    async _handleProviderSignIn(provider, options) {
        const url = await this._getUrlForProvider(`${this.url}/authorize`, provider, {
            redirectTo: options.redirectTo,
            scopes: options.scopes,
            queryParams: options.queryParams,
        });
        this._debug('#_handleProviderSignIn()', 'provider', provider, 'options', options, 'url', url);
        // try to open on the browser
        if (isBrowser() && !options.skipBrowserRedirect) {
            window.location.assign(url);
        }
        return { data: { provider, url }, error: null };
    }
    /**
     * Recovers the session from LocalStorage and refreshes the token
     * Note: this method is async to accommodate for AsyncStorage e.g. in React native.
     */
    async _recoverAndRefresh() {
        var _a, _b;
        const debugName = '#_recoverAndRefresh()';
        this._debug(debugName, 'begin');
        try {
            const currentSession = (await getItemAsync(this.storage, this.storageKey));
            if (currentSession && this.userStorage) {
                let maybeUser = (await getItemAsync(this.userStorage, this.storageKey + '-user'));
                if (!this.storage.isServer && Object.is(this.storage, this.userStorage) && !maybeUser) {
                    // storage and userStorage are the same storage medium, for example
                    // window.localStorage if userStorage does not have the user from
                    // storage stored, store it first thereby migrating the user object
                    // from storage -> userStorage
                    maybeUser = { user: currentSession.user };
                    await setItemAsync(this.userStorage, this.storageKey + '-user', maybeUser);
                }
                currentSession.user = (_a = maybeUser === null || maybeUser === void 0 ? void 0 : maybeUser.user) !== null && _a !== void 0 ? _a : userNotAvailableProxy();
            }
            else if (currentSession && !currentSession.user) {
                // user storage is not set, let's check if it was previously enabled so
                // we bring back the storage as it should be
                if (!currentSession.user) {
                    // test if userStorage was previously enabled and the storage medium was the same, to move the user back under the same key
                    const separateUser = (await getItemAsync(this.storage, this.storageKey + '-user'));
                    if (separateUser && (separateUser === null || separateUser === void 0 ? void 0 : separateUser.user)) {
                        currentSession.user = separateUser.user;
                        await removeItemAsync(this.storage, this.storageKey + '-user');
                        await setItemAsync(this.storage, this.storageKey, currentSession);
                    }
                    else {
                        currentSession.user = userNotAvailableProxy();
                    }
                }
            }
            this._debug(debugName, 'session from storage', currentSession);
            if (!this._isValidSession(currentSession)) {
                this._debug(debugName, 'session is not valid');
                if (currentSession !== null) {
                    await this._removeSession();
                }
                return;
            }
            const expiresWithMargin = ((_b = currentSession.expires_at) !== null && _b !== void 0 ? _b : Infinity) * 1000 - Date.now() < EXPIRY_MARGIN_MS;
            this._debug(debugName, `session has${expiresWithMargin ? '' : ' not'} expired with margin of ${EXPIRY_MARGIN_MS}s`);
            if (expiresWithMargin) {
                if (this.autoRefreshToken && currentSession.refresh_token) {
                    const { error } = await this._callRefreshToken(currentSession.refresh_token);
                    if (error) {
                        // AuthRefreshDiscardedError means a concurrent signOut already
                        // cleared storage and fired SIGNED_OUT. Don't run _removeSession
                        // again here, or we'll emit a duplicate SIGNED_OUT.
                        if (isAuthRefreshDiscardedError(error)) {
                            this._debug(debugName, 'refresh discarded by commit guard', error);
                        }
                        else {
                            this._debug(debugName, 'refresh failed', error);
                            if (!isAuthRetryableFetchError(error)) {
                                this._debug(debugName, 'refresh failed with a non-retryable error, removing the session', error);
                                await this._removeSession();
                            }
                        }
                    }
                }
            }
            else if (currentSession.user &&
                currentSession.user.__isUserNotAvailableProxy === true) {
                // If we have a proxy user, try to get the real user data
                try {
                    const { data, error: userError } = await this._getUser(currentSession.access_token);
                    if (!userError && (data === null || data === void 0 ? void 0 : data.user)) {
                        currentSession.user = data.user;
                        await this._saveSession(currentSession);
                        await this._notifyAllSubscribers('SIGNED_IN', currentSession);
                    }
                    else {
                        this._debug(debugName, 'could not get user data, skipping SIGNED_IN notification');
                    }
                }
                catch (getUserError) {
                    console.error('Error getting user data:', getUserError);
                    this._debug(debugName, 'error getting user data, skipping SIGNED_IN notification', getUserError);
                }
            }
            else {
                // no need to persist currentSession again, as we just loaded it from
                // local storage; persisting it again may overwrite a value saved by
                // another client with access to the same local storage
                await this._notifyAllSubscribers('SIGNED_IN', currentSession);
            }
        }
        catch (err) {
            this._debug(debugName, 'error', err);
            console.error(err);
            return;
        }
        finally {
            this._debug(debugName, 'end');
        }
    }
    async _callRefreshToken(refreshToken) {
        var _a, _b;
        if (!refreshToken) {
            throw new AuthSessionMissingError();
        }
        // refreshing is already in progress
        if (this.refreshingDeferred) {
            return this.refreshingDeferred.promise;
        }
        // Refresh tokens are long-lived bearer credentials; do NOT include any
        // fragment of the token in the debug tag, even when `debug: true` is
        // enabled (logs may be forwarded to third-party services).
        const debugName = `#_callRefreshToken()`;
        this._debug(debugName, 'begin');
        try {
            this.refreshingDeferred = new Deferred();
            // Snapshot storage before the fetch. The commit guard discards the
            // rotated tokens only when a non-null pre-fetch snapshot changed under
            // us — typical case: a concurrent `signOut` ran `_removeSession`, or
            // another tab's refresh rewrote the slot. Callers passing
            // externally-sourced tokens (SSR cookie handoff, multi-account
            // switching, `setSession`/`refreshSession({ refresh_token })`) may
            // start from a null snapshot OR from a non-null snapshot whose
            // refresh_token differs from the one they're hydrating; in both
            // cases the guard fires only when storage was *modified between
            // snapshots*, not when the input token disagrees with what's stored.
            const storedAtStart = (await getItemAsync(this.storage, this.storageKey));
            const { data, error } = await this._refreshAccessToken(refreshToken);
            if (error)
                throw error;
            if (!data.session)
                throw new AuthSessionMissingError();
            const storedAfter = (await getItemAsync(this.storage, this.storageKey));
            const storageChangedUnderUs = storedAtStart !== null &&
                (storedAfter === null || storedAfter.refresh_token !== storedAtStart.refresh_token);
            if (storageChangedUnderUs) {
                this._debug(debugName, 'commit guard: storage changed since refresh started, discarding rotated tokens', {
                    // Presence indicators only — never log refresh token fragments,
                    // even partial. Logs may be forwarded to third-party services.
                    startedWith: 'present',
                    nowHolds: storedAfter ? 'replaced' : 'cleared',
                });
                const discarded = {
                    data: null,
                    error: new AuthRefreshDiscardedError(),
                };
                this.refreshingDeferred.resolve(discarded);
                return discarded;
            }
            // Second leg of the commit guard: close the TOCTOU window between the
            // synchronous `storageChangedUnderUs` check and the actual storage
            // writes inside `_saveSession`. A concurrent `signOut → _removeSession`
            // can land inside `_saveSession`'s `await setItemAsync(...)` yields and
            // clear storage just before we overwrite it. Capture the epoch BEFORE
            // the save and re-check after; if it advanced, undo the write directly
            // (do NOT call `_removeSession` — that would emit a duplicate
            // SIGNED_OUT for the concurrent signOut that already fired one).
            const epochBeforeSave = this._sessionRemovalEpoch;
            await this._saveSession(data.session);
            if (this._sessionRemovalEpoch !== epochBeforeSave) {
                this._debug(debugName, 'commit guard (post-save): _removeSession ran during _saveSession, undoing write');
                await removeItemAsync(this.storage, this.storageKey);
                if (this.userStorage) {
                    await removeItemAsync(this.userStorage, this.storageKey + '-user');
                }
                const discarded = {
                    data: null,
                    error: new AuthRefreshDiscardedError(),
                };
                this.refreshingDeferred.resolve(discarded);
                return discarded;
            }
            await this._notifyAllSubscribers('TOKEN_REFRESHED', data.session);
            const result = { data: data.session, error: null };
            this.refreshingDeferred.resolve(result);
            return result;
        }
        catch (error) {
            this._debug(debugName, 'error', error);
            if (isAuthError(error)) {
                const result = { data: null, error };
                if (!isAuthRetryableFetchError(error)) {
                    await this._removeSession();
                }
                (_a = this.refreshingDeferred) === null || _a === void 0 ? void 0 : _a.resolve(result);
                return result;
            }
            (_b = this.refreshingDeferred) === null || _b === void 0 ? void 0 : _b.reject(error);
            throw error;
        }
        finally {
            this.refreshingDeferred = null;
            this._debug(debugName, 'end');
        }
    }
    async _notifyAllSubscribers(event, session, broadcast = true) {
        const debugName = `#_notifyAllSubscribers(${event})`;
        this._debug(debugName, 'begin', session, `broadcast = ${broadcast}`);
        try {
            if (this.broadcastChannel && broadcast) {
                this.broadcastChannel.postMessage({ event, session });
            }
            const errors = [];
            const promises = Array.from(this.stateChangeEmitters.values()).map(async (x) => {
                try {
                    await x.callback(event, session);
                }
                catch (e) {
                    errors.push(e);
                }
            });
            await Promise.all(promises);
            if (errors.length > 0) {
                for (let i = 0; i < errors.length; i += 1) {
                    console.error(errors[i]);
                }
                throw errors[0];
            }
        }
        finally {
            this._debug(debugName, 'end');
        }
    }
    /**
     * set currentSession and currentUser
     * process to _startAutoRefreshToken if possible
     */
    async _saveSession(session) {
        this._debug('#_saveSession()', session);
        // _saveSession is always called whenever a new session has been acquired
        // so we can safely suppress the warning returned by future getSession calls
        this.suppressGetSessionWarning = true;
        await removeItemAsync(this.storage, `${this.storageKey}-code-verifier`);
        // Create a shallow copy to work with, to avoid mutating the original session object if it's used elsewhere
        const sessionToProcess = Object.assign({}, session);
        const userIsProxy = sessionToProcess.user && sessionToProcess.user.__isUserNotAvailableProxy === true;
        if (this.userStorage) {
            if (!userIsProxy && sessionToProcess.user) {
                // If it's a real user object, save it to userStorage.
                await setItemAsync(this.userStorage, this.storageKey + '-user', {
                    user: sessionToProcess.user,
                });
            }
            else if (userIsProxy) {
                // If it's the proxy, it means user was not found in userStorage.
                // We should ensure no stale user data for this key exists in userStorage if we were to save null,
                // or simply not save the proxy. For now, we don't save the proxy here.
                // If there's a need to clear userStorage if user becomes proxy, that logic would go here.
            }
            // Prepare the main session data for primary storage: remove the user property before cloning
            // This is important because the original session.user might be the proxy
            const mainSessionData = Object.assign({}, sessionToProcess);
            delete mainSessionData.user; // Remove user (real or proxy) before cloning for main storage
            const clonedMainSessionData = deepClone(mainSessionData);
            await setItemAsync(this.storage, this.storageKey, clonedMainSessionData);
        }
        else {
            // No userStorage is configured.
            // In this case, session.user should ideally not be a proxy.
            // If it were, structuredClone would fail. This implies an issue elsewhere if user is a proxy here
            const clonedSession = deepClone(sessionToProcess); // sessionToProcess still has its original user property
            await setItemAsync(this.storage, this.storageKey, clonedSession);
        }
    }
    async _removeSession() {
        // Bump synchronously, BEFORE any `await`, so that `_callRefreshToken`'s
        // post-save check sees the increment whenever this method has started —
        // even if it hasn't finished. Pairs with the epoch check in
        // `_callRefreshToken`. See `_sessionRemovalEpoch` field doc.
        this._sessionRemovalEpoch += 1;
        this._debug('#_removeSession()');
        this.suppressGetSessionWarning = false;
        await removeItemAsync(this.storage, this.storageKey);
        await removeItemAsync(this.storage, this.storageKey + '-code-verifier');
        await removeItemAsync(this.storage, this.storageKey + '-user');
        if (this.userStorage) {
            await removeItemAsync(this.userStorage, this.storageKey + '-user');
        }
        await this._notifyAllSubscribers('SIGNED_OUT', null);
    }
    /**
     * Removes any registered visibilitychange callback.
     *
     * {@see #startAutoRefresh}
     * {@see #stopAutoRefresh}
     */
    _removeVisibilityChangedCallback() {
        this._debug('#_removeVisibilityChangedCallback()');
        const callback = this.visibilityChangedCallback;
        this.visibilityChangedCallback = null;
        try {
            if (callback && isBrowser() && (window === null || window === void 0 ? void 0 : window.removeEventListener)) {
                window.removeEventListener('visibilitychange', callback);
            }
        }
        catch (e) {
            console.error('removing visibilitychange callback failed', e);
        }
    }
    /**
     * This is the private implementation of {@link #startAutoRefresh}. Use this
     * within the library.
     */
    async _startAutoRefresh() {
        await this._stopAutoRefresh();
        this._debug('#_startAutoRefresh()');
        const ticker = setInterval(() => this._autoRefreshTokenTick(), AUTO_REFRESH_TICK_DURATION_MS);
        this.autoRefreshTicker = ticker;
        if (ticker && typeof ticker === 'object' && typeof ticker.unref === 'function') {
            // ticker is a NodeJS Timeout object that has an `unref` method
            // https://nodejs.org/api/timers.html#timeoutunref
            // When auto refresh is used in NodeJS (like for testing) the
            // `setInterval` is preventing the process from being marked as
            // finished and tests run endlessly. This can be prevented by calling
            // `unref()` on the returned object.
            ticker.unref();
            // @ts-expect-error TS has no context of Deno
        }
        else if (typeof Deno !== 'undefined' && typeof Deno.unrefTimer === 'function') {
            // similar like for NodeJS, but with the Deno API
            // https://deno.land/api@latest?unstable&s=Deno.unrefTimer
            // @ts-expect-error TS has no context of Deno
            Deno.unrefTimer(ticker);
        }
        // run the tick immediately, but in the next pass of the event loop so that
        // #_initialize can be allowed to complete without recursively waiting on
        // itself
        const timeout = setTimeout(async () => {
            await this.initializePromise;
            await this._autoRefreshTokenTick();
        }, 0);
        this.autoRefreshTickTimeout = timeout;
        if (timeout && typeof timeout === 'object' && typeof timeout.unref === 'function') {
            timeout.unref();
            // @ts-expect-error TS has no context of Deno
        }
        else if (typeof Deno !== 'undefined' && typeof Deno.unrefTimer === 'function') {
            // @ts-expect-error TS has no context of Deno
            Deno.unrefTimer(timeout);
        }
    }
    /**
     * This is the private implementation of {@link #stopAutoRefresh}. Use this
     * within the library.
     */
    async _stopAutoRefresh() {
        this._debug('#_stopAutoRefresh()');
        const ticker = this.autoRefreshTicker;
        this.autoRefreshTicker = null;
        if (ticker) {
            clearInterval(ticker);
        }
        const timeout = this.autoRefreshTickTimeout;
        this.autoRefreshTickTimeout = null;
        if (timeout) {
            clearTimeout(timeout);
        }
    }
    /**
     * Starts an auto-refresh process in the background. The session is checked
     * every few seconds. Close to the time of expiration a process is started to
     * refresh the session. If refreshing fails it will be retried for as long as
     * necessary.
     *
     * If you set the {@link GoTrueClientOptions#autoRefreshToken} you don't need
     * to call this function, it will be called for you.
     *
     * On browsers the refresh process works only when the tab/window is in the
     * foreground to conserve resources as well as prevent race conditions and
     * flooding auth with requests. If you call this method any managed
     * visibility change callback will be removed and you must manage visibility
     * changes on your own.
     *
     * On non-browser platforms the refresh process works *continuously* in the
     * background, which may not be desirable. You should hook into your
     * platform's foreground indication mechanism and call these methods
     * appropriately to conserve resources.
     *
     * {@see #stopAutoRefresh}
     *
     * @category Auth
     *
     * @remarks
     * - Only useful in non-browser environments such as React Native or Electron.
     * - The Supabase Auth library automatically starts and stops proactively refreshing the session when a tab is focused or not.
     * - On non-browser platforms, such as mobile or desktop apps built with web technologies, the library is not able to effectively determine whether the application is _focused_ or not.
     * - To give this hint to the application, you should be calling this method when the app is in focus and calling `supabase.auth.stopAutoRefresh()` when it's out of focus.
     *
     * @example Start and stop auto refresh in React Native
     * ```js
     * import { AppState } from 'react-native'
     *
     * // make sure you register this only once!
     * AppState.addEventListener('change', (state) => {
     *   if (state === 'active') {
     *     supabase.auth.startAutoRefresh()
     *   } else {
     *     supabase.auth.stopAutoRefresh()
     *   }
     * })
     * ```
     */
    async startAutoRefresh() {
        this._removeVisibilityChangedCallback();
        await this._startAutoRefresh();
    }
    /**
     * Stops an active auto refresh process running in the background (if any).
     *
     * If you call this method any managed visibility change callback will be
     * removed and you must manage visibility changes on your own.
     *
     * See {@link #startAutoRefresh} for more details.
     *
     * @category Auth
     *
     * @remarks
     * - Only useful in non-browser environments such as React Native or Electron.
     * - The Supabase Auth library automatically starts and stops proactively refreshing the session when a tab is focused or not.
     * - On non-browser platforms, such as mobile or desktop apps built with web technologies, the library is not able to effectively determine whether the application is _focused_ or not.
     * - When your application goes in the background or out of focus, call this method to stop the proactive refreshing of the session.
     *
     * @example Start and stop auto refresh in React Native
     * ```js
     * import { AppState } from 'react-native'
     *
     * // make sure you register this only once!
     * AppState.addEventListener('change', (state) => {
     *   if (state === 'active') {
     *     supabase.auth.startAutoRefresh()
     *   } else {
     *     supabase.auth.stopAutoRefresh()
     *   }
     * })
     * ```
     */
    async stopAutoRefresh() {
        this._removeVisibilityChangedCallback();
        await this._stopAutoRefresh();
    }
    /**
     * Tears down the client's background work: stops the auto-refresh interval,
     * removes the `visibilitychange` listener, closes the cross-tab
     * `BroadcastChannel`, and clears registered `onAuthStateChange` subscribers.
     *
     * Call this from cleanup hooks when the client is being replaced before
     * its JS realm is destroyed. React Strict Mode and HMR are the common
     * cases. Any in-flight `fetch` calls continue to completion and may still
     * write to storage; dispose doesn't abort them or erase storage.
     *
     * Lifecycle caveat: because in-flight refreshes are not aborted, a
     * disposed instance can still persist a rotated session to storage after
     * `dispose()` returns. A subsequent `createClient` against the same
     * `storageKey` will pick up that session on its next read. If you need
     * strict isolation between client lifecycles, await any pending auth
     * operation before calling `dispose()` (or change the `storageKey` for
     * the replacement client).
     *
     * Safe to call repeatedly.
     *
     * @category Auth
     *
     * @example Cleanup on React unmount
     * ```ts
     * useEffect(() => {
     *   const client = createClient(...)
     *   return () => { client.auth.dispose() }
     * }, [])
     * ```
     */
    async dispose() {
        var _a;
        this._removeVisibilityChangedCallback();
        await this._stopAutoRefresh();
        (_a = this.broadcastChannel) === null || _a === void 0 ? void 0 : _a.close();
        this.broadcastChannel = null;
        this.stateChangeEmitters.clear();
    }
    /**
     * Runs the auto refresh token tick.
     */
    async _autoRefreshTokenTick() {
        this._debug('#_autoRefreshTokenTick()', 'begin');
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path. Uses `_acquireLock(0, ...)` which
            // throws `LockAcquireTimeoutError` immediately if the lock is held —
            // that's the fail-fast skip path that lets the tick bail out instead
            // of queuing behind a long-running operation.
            try {
                await this._acquireLock(0, async () => {
                    try {
                        const now = Date.now();
                        try {
                            return await this._useSession(async (result) => {
                                const { data: { session }, } = result;
                                if (!session || !session.refresh_token || !session.expires_at) {
                                    this._debug('#_autoRefreshTokenTick()', 'no session');
                                    return;
                                }
                                const expiresInTicks = Math.floor((session.expires_at * 1000 - now) / AUTO_REFRESH_TICK_DURATION_MS);
                                this._debug('#_autoRefreshTokenTick()', `access token expires in ${expiresInTicks} ticks, a tick lasts ${AUTO_REFRESH_TICK_DURATION_MS}ms, refresh threshold is ${AUTO_REFRESH_TICK_THRESHOLD} ticks`);
                                if (expiresInTicks <= AUTO_REFRESH_TICK_THRESHOLD) {
                                    await this._callRefreshToken(session.refresh_token);
                                }
                            });
                        }
                        catch (e) {
                            console.error('Auto refresh tick failed with error. This is likely a transient error.', e);
                        }
                    }
                    finally {
                        this._debug('#_autoRefreshTokenTick()', 'end');
                    }
                });
            }
            catch (e) {
                if (e instanceof LockAcquireTimeoutError) {
                    this._debug('auto refresh token tick lock not available');
                }
                else {
                    throw e;
                }
            }
            return;
        }
        // Lockless default: skip if a refresh is already in flight.
        // `_callRefreshToken` also dedupes via the same field; this is just a
        // fast-path skip to avoid an unnecessary storage read.
        if (this.refreshingDeferred !== null) {
            this._debug('#_autoRefreshTokenTick()', 'refresh already in flight, skipping');
            return;
        }
        try {
            const now = Date.now();
            try {
                await this._useSession(async (result) => {
                    const { data: { session }, } = result;
                    if (!session || !session.refresh_token || !session.expires_at) {
                        this._debug('#_autoRefreshTokenTick()', 'no session');
                        return;
                    }
                    // session will expire in this many ticks (or has already expired if <= 0)
                    const expiresInTicks = Math.floor((session.expires_at * 1000 - now) / AUTO_REFRESH_TICK_DURATION_MS);
                    this._debug('#_autoRefreshTokenTick()', `access token expires in ${expiresInTicks} ticks, a tick lasts ${AUTO_REFRESH_TICK_DURATION_MS}ms, refresh threshold is ${AUTO_REFRESH_TICK_THRESHOLD} ticks`);
                    if (expiresInTicks <= AUTO_REFRESH_TICK_THRESHOLD) {
                        await this._callRefreshToken(session.refresh_token);
                    }
                });
            }
            catch (e) {
                console.error('Auto refresh tick failed with error. This is likely a transient error.', e);
            }
        }
        finally {
            this._debug('#_autoRefreshTokenTick()', 'end');
        }
    }
    /**
     * Registers callbacks on the browser / platform, which in-turn run
     * algorithms when the browser window/tab are in foreground. On non-browser
     * platforms it assumes always foreground.
     */
    async _handleVisibilityChange() {
        this._debug('#_handleVisibilityChange()');
        if (!isBrowser() || !(window === null || window === void 0 ? void 0 : window.addEventListener)) {
            if (this.autoRefreshToken) {
                // in non-browser environments the refresh token ticker runs always
                this.startAutoRefresh();
            }
            return false;
        }
        try {
            this.visibilityChangedCallback = async () => {
                try {
                    await this._onVisibilityChanged(false);
                }
                catch (error) {
                    this._debug('#visibilityChangedCallback', 'error', error);
                }
            };
            window === null || window === void 0 ? void 0 : window.addEventListener('visibilitychange', this.visibilityChangedCallback);
            // now immediately call the visbility changed callback to setup with the
            // current visbility state
            await this._onVisibilityChanged(true); // initial call
        }
        catch (error) {
            console.error('_handleVisibilityChange', error);
        }
    }
    /**
     * Callback registered with `window.addEventListener('visibilitychange')`.
     */
    async _onVisibilityChanged(calledFromInitialize) {
        const methodName = `#_onVisibilityChanged(${calledFromInitialize})`;
        this._debug(methodName, 'visibilityState', document.visibilityState);
        if (document.visibilityState === 'visible') {
            if (this.autoRefreshToken) {
                // in browser environments the refresh token ticker runs only on focused tabs
                // which prevents race conditions
                this._startAutoRefresh();
            }
            if (!calledFromInitialize) {
                // called when the visibility has changed, i.e. the browser
                // transitioned from hidden -> visible so we need to see if the session
                // should be recovered
                await this.initializePromise;
                if (this.lock != null) {
                    // TODO(v3): remove legacy lock path
                    await this._acquireLock(this.lockAcquireTimeout, async () => {
                        if (document.visibilityState !== 'visible') {
                            this._debug(methodName, 'acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting');
                            return;
                        }
                        await this._recoverAndRefresh();
                    });
                }
                else {
                    if (document.visibilityState !== 'visible') {
                        this._debug(methodName, 'visibilityState is no longer visible, skipping recovery');
                        return;
                    }
                    // recover the session
                    await this._recoverAndRefresh();
                }
            }
        }
        else if (document.visibilityState === 'hidden') {
            if (this.autoRefreshToken) {
                this._stopAutoRefresh();
            }
        }
    }
    /**
     * Generates the relevant login URL for a third-party provider.
     * @param options.redirectTo A URL or mobile address to send the user to after they are confirmed.
     * @param options.scopes A space-separated list of scopes granted to the OAuth application.
     * @param options.queryParams An object of key-value pairs containing query parameters granted to the OAuth application.
     */
    async _getUrlForProvider(url, provider, options) {
        const urlParams = [`provider=${encodeURIComponent(provider)}`];
        if (options === null || options === void 0 ? void 0 : options.redirectTo) {
            urlParams.push(`redirect_to=${encodeURIComponent(options.redirectTo)}`);
        }
        if (options === null || options === void 0 ? void 0 : options.scopes) {
            urlParams.push(`scopes=${encodeURIComponent(options.scopes)}`);
        }
        if (this.flowType === 'pkce') {
            const [codeChallenge, codeChallengeMethod] = await getCodeChallengeAndMethod(this.storage, this.storageKey);
            const flowParams = new URLSearchParams({
                code_challenge: `${encodeURIComponent(codeChallenge)}`,
                code_challenge_method: `${encodeURIComponent(codeChallengeMethod)}`,
            });
            urlParams.push(flowParams.toString());
        }
        if (options === null || options === void 0 ? void 0 : options.queryParams) {
            const query = new URLSearchParams(options.queryParams);
            urlParams.push(query.toString());
        }
        if (options === null || options === void 0 ? void 0 : options.skipBrowserRedirect) {
            urlParams.push(`skip_http_redirect=${options.skipBrowserRedirect}`);
        }
        return `${url}?${urlParams.join('&')}`;
    }
    async _unenroll(params) {
        try {
            return await this._useSession(async (result) => {
                var _a;
                const { data: sessionData, error: sessionError } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                return await _request(this.fetch, 'DELETE', `${this.url}/factors/${params.factorId}`, {
                    headers: this.headers,
                    jwt: (_a = sessionData === null || sessionData === void 0 ? void 0 : sessionData.session) === null || _a === void 0 ? void 0 : _a.access_token,
                });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    async _enroll(params) {
        try {
            return await this._useSession(async (result) => {
                var _a, _b;
                const { data: sessionData, error: sessionError } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                const body = Object.assign({ friendly_name: params.friendlyName, factor_type: params.factorType }, (params.factorType === 'phone'
                    ? { phone: params.phone }
                    : params.factorType === 'totp'
                        ? { issuer: params.issuer }
                        : {}));
                const { data, error } = (await _request(this.fetch, 'POST', `${this.url}/factors`, {
                    body,
                    headers: this.headers,
                    jwt: (_a = sessionData === null || sessionData === void 0 ? void 0 : sessionData.session) === null || _a === void 0 ? void 0 : _a.access_token,
                }));
                if (error) {
                    return this._returnResult({ data: null, error });
                }
                if (params.factorType === 'totp' && data.type === 'totp' && ((_b = data === null || data === void 0 ? void 0 : data.totp) === null || _b === void 0 ? void 0 : _b.qr_code)) {
                    data.totp.qr_code = `data:image/svg+xml;utf-8,${data.totp.qr_code}`;
                }
                return this._returnResult({ data, error: null });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    async _verify(params) {
        const run = async () => {
            try {
                return await this._useSession(async (result) => {
                    var _a;
                    const { data: sessionData, error: sessionError } = result;
                    if (sessionError) {
                        return this._returnResult({ data: null, error: sessionError });
                    }
                    const body = Object.assign({ challenge_id: params.challengeId }, ('webauthn' in params
                        ? {
                            webauthn: Object.assign(Object.assign({}, params.webauthn), { credential_response: params.webauthn.type === 'create'
                                    ? serializeCredentialCreationResponse(params.webauthn.credential_response)
                                    : serializeCredentialRequestResponse(params.webauthn.credential_response) }),
                        }
                        : { code: params.code }));
                    const { data, error } = await _request(this.fetch, 'POST', `${this.url}/factors/${params.factorId}/verify`, {
                        body,
                        headers: this.headers,
                        jwt: (_a = sessionData === null || sessionData === void 0 ? void 0 : sessionData.session) === null || _a === void 0 ? void 0 : _a.access_token,
                    });
                    if (error) {
                        return this._returnResult({ data: null, error });
                    }
                    await this._saveSession(Object.assign({ expires_at: Math.round(Date.now() / 1000) + data.expires_in }, data));
                    await this._notifyAllSubscribers('MFA_CHALLENGE_VERIFIED', data);
                    return this._returnResult({ data, error });
                });
            }
            catch (error) {
                if (isAuthError(error)) {
                    return this._returnResult({ data: null, error });
                }
                throw error;
            }
        };
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return this._acquireLock(this.lockAcquireTimeout, run);
        }
        return run();
    }
    async _challenge(params) {
        const run = async () => {
            try {
                return await this._useSession(async (result) => {
                    var _a;
                    const { data: sessionData, error: sessionError } = result;
                    if (sessionError) {
                        return this._returnResult({ data: null, error: sessionError });
                    }
                    const response = (await _request(this.fetch, 'POST', `${this.url}/factors/${params.factorId}/challenge`, {
                        body: params,
                        headers: this.headers,
                        jwt: (_a = sessionData === null || sessionData === void 0 ? void 0 : sessionData.session) === null || _a === void 0 ? void 0 : _a.access_token,
                    }));
                    if (response.error) {
                        return response;
                    }
                    const { data } = response;
                    if (data.type !== 'webauthn') {
                        return { data, error: null };
                    }
                    switch (data.webauthn.type) {
                        case 'create':
                            return {
                                data: Object.assign(Object.assign({}, data), { webauthn: Object.assign(Object.assign({}, data.webauthn), { credential_options: Object.assign(Object.assign({}, data.webauthn.credential_options), { publicKey: deserializeCredentialCreationOptions(data.webauthn.credential_options.publicKey) }) }) }),
                                error: null,
                            };
                        case 'request':
                            return {
                                data: Object.assign(Object.assign({}, data), { webauthn: Object.assign(Object.assign({}, data.webauthn), { credential_options: Object.assign(Object.assign({}, data.webauthn.credential_options), { publicKey: deserializeCredentialRequestOptions(data.webauthn.credential_options.publicKey) }) }) }),
                                error: null,
                            };
                    }
                });
            }
            catch (error) {
                if (isAuthError(error)) {
                    return this._returnResult({ data: null, error });
                }
                throw error;
            }
        };
        if (this.lock != null) {
            // TODO(v3): remove legacy lock path
            return this._acquireLock(this.lockAcquireTimeout, run);
        }
        return run();
    }
    /**
     * {@see GoTrueMFAApi#challengeAndVerify}
     */
    async _challengeAndVerify(params) {
        const { data: challengeData, error: challengeError } = await this._challenge({
            factorId: params.factorId,
        });
        if (challengeError) {
            return this._returnResult({ data: null, error: challengeError });
        }
        return await this._verify({
            factorId: params.factorId,
            challengeId: challengeData.id,
            code: params.code,
        });
    }
    /**
     * {@see GoTrueMFAApi#listFactors}
     */
    async _listFactors() {
        var _a;
        const { data: { user }, error: userError, } = await this.getUser();
        if (userError) {
            return { data: null, error: userError };
        }
        const data = {
            all: [],
            phone: [],
            totp: [],
            webauthn: [],
        };
        // loop over the factors ONCE
        for (const factor of (_a = user === null || user === void 0 ? void 0 : user.factors) !== null && _a !== void 0 ? _a : []) {
            data.all.push(factor);
            if (factor.status === 'verified') {
                ;
                data[factor.factor_type].push(factor);
            }
        }
        return {
            data,
            error: null,
        };
    }
    /**
     * {@see GoTrueMFAApi#getAuthenticatorAssuranceLevel}
     */
    async _getAuthenticatorAssuranceLevel(jwt) {
        var _a, _b, _c, _d;
        if (jwt) {
            try {
                const { payload } = decodeJWT(jwt);
                let currentLevel = null;
                if (payload.aal) {
                    currentLevel = payload.aal;
                }
                let nextLevel = currentLevel;
                const { data: { user }, error: userError, } = await this.getUser(jwt);
                if (userError) {
                    return this._returnResult({ data: null, error: userError });
                }
                const verifiedFactors = (_b = (_a = user === null || user === void 0 ? void 0 : user.factors) === null || _a === void 0 ? void 0 : _a.filter((factor) => factor.status === 'verified')) !== null && _b !== void 0 ? _b : [];
                if (verifiedFactors.length > 0) {
                    nextLevel = 'aal2';
                }
                const currentAuthenticationMethods = payload.amr || [];
                return { data: { currentLevel, nextLevel, currentAuthenticationMethods }, error: null };
            }
            catch (error) {
                if (isAuthError(error)) {
                    return this._returnResult({ data: null, error });
                }
                throw error;
            }
        }
        const { data: { session }, error: sessionError, } = await this.getSession();
        if (sessionError) {
            return this._returnResult({ data: null, error: sessionError });
        }
        if (!session) {
            return {
                data: { currentLevel: null, nextLevel: null, currentAuthenticationMethods: [] },
                error: null,
            };
        }
        const { payload } = decodeJWT(session.access_token);
        let currentLevel = null;
        if (payload.aal) {
            currentLevel = payload.aal;
        }
        let nextLevel = currentLevel;
        const verifiedFactors = (_d = (_c = session.user.factors) === null || _c === void 0 ? void 0 : _c.filter((factor) => factor.status === 'verified')) !== null && _d !== void 0 ? _d : [];
        if (verifiedFactors.length > 0) {
            nextLevel = 'aal2';
        }
        const currentAuthenticationMethods = payload.amr || [];
        return { data: { currentLevel, nextLevel, currentAuthenticationMethods }, error: null };
    }
    /**
     * Retrieves details about an OAuth authorization request.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     *
     * Returns authorization details including client info, scopes, and user information.
     * If the response includes only a redirect_url field, it means consent was already given - the caller
     * should handle the redirect manually if needed.
     */
    async _getAuthorizationDetails(authorizationId) {
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                return await _request(this.fetch, 'GET', `${this.url}/oauth/authorizations/${authorizationId}`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    xform: (data) => ({ data, error: null }),
                });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Approves an OAuth authorization request.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     */
    async _approveAuthorization(authorizationId, options) {
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                const response = await _request(this.fetch, 'POST', `${this.url}/oauth/authorizations/${authorizationId}/consent`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    body: { action: 'approve' },
                    xform: (data) => ({ data, error: null }),
                });
                if (response.data && response.data.redirect_url) {
                    // Automatically redirect in browser unless skipBrowserRedirect is true
                    if (isBrowser() && !(options === null || options === void 0 ? void 0 : options.skipBrowserRedirect)) {
                        window.location.assign(response.data.redirect_url);
                    }
                }
                return response;
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Denies an OAuth authorization request.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     */
    async _denyAuthorization(authorizationId, options) {
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                const response = await _request(this.fetch, 'POST', `${this.url}/oauth/authorizations/${authorizationId}/consent`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    body: { action: 'deny' },
                    xform: (data) => ({ data, error: null }),
                });
                if (response.data && response.data.redirect_url) {
                    // Automatically redirect in browser unless skipBrowserRedirect is true
                    if (isBrowser() && !(options === null || options === void 0 ? void 0 : options.skipBrowserRedirect)) {
                        window.location.assign(response.data.redirect_url);
                    }
                }
                return response;
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Lists all OAuth grants that the authenticated user has authorized.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     */
    async _listOAuthGrants() {
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                return await _request(this.fetch, 'GET', `${this.url}/user/oauth/grants`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    xform: (data) => ({ data, error: null }),
                });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Revokes a user's OAuth grant for a specific client.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     */
    async _revokeOAuthGrant(options) {
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                await _request(this.fetch, 'DELETE', `${this.url}/user/oauth/grants`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    query: { client_id: options.clientId },
                    noResolveJson: true,
                });
                return { data: {}, error: null };
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    async fetchJwk(kid, jwks = { keys: [] }) {
        // try fetching from the supplied jwks
        let jwk = jwks.keys.find((key) => key.kid === kid);
        if (jwk) {
            return jwk;
        }
        const now = Date.now();
        // try fetching from cache
        jwk = this.jwks.keys.find((key) => key.kid === kid);
        // jwk exists and jwks isn't stale
        if (jwk && this.jwks_cached_at + JWKS_TTL > now) {
            return jwk;
        }
        // jwk isn't cached in memory so we need to fetch it from the well-known endpoint
        const { data, error } = await _request(this.fetch, 'GET', `${this.url}/.well-known/jwks.json`, {
            headers: this.headers,
        });
        if (error) {
            throw error;
        }
        if (!data.keys || data.keys.length === 0) {
            return null;
        }
        this.jwks = data;
        this.jwks_cached_at = now;
        // Find the signing key
        jwk = data.keys.find((key) => key.kid === kid);
        if (!jwk) {
            return null;
        }
        return jwk;
    }
    /**
     * Extracts the JWT claims present in the access token by first verifying the
     * JWT against the server's JSON Web Key Set endpoint
     * `/.well-known/jwks.json` which is often cached, resulting in significantly
     * faster responses. Prefer this method over {@link #getUser} which always
     * sends a request to the Auth server for each JWT.
     *
     * If the project is not using an asymmetric JWT signing key (like ECC or
     * RSA) it always sends a request to the Auth server (similar to {@link
     * #getUser}) to verify the JWT.
     *
     * @param jwt An optional specific JWT you wish to verify, not the one you
     *            can obtain from {@link #getSession}.
     * @param options Various additional options that allow you to customize the
     *                behavior of this method.
     *
     * @category Auth
     *
     * @remarks
     * - Parses the user's [access token](/docs/guides/auth/sessions#access-token-jwt-claims) as a [JSON Web Token (JWT)](/docs/guides/auth/jwts) and returns its components if valid and not expired.
     * - If your project is using asymmetric JWT signing keys, then the verification is done locally usually without a network request using the [WebCrypto API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Crypto_API).
     * - A network request is sent to your project's JWT signing key discovery endpoint `https://project-id.supabase.co/auth/v1/.well-known/jwks.json`, which is cached locally. If your environment is ephemeral, such as a Lambda function that is destroyed after every request, a network request will be sent for each new invocation. Supabase provides a network-edge cache providing fast responses for these situations.
     * - If the user's access token is about to expire when calling this function, the user's session will first be refreshed before validating the JWT.
     * - If your project is using a symmetric secret to sign the JWT, it always sends a request similar to `getUser()` to validate the JWT at the server before returning the decoded token. This is also used if the WebCrypto API is not available in the environment. Make sure you polyfill it in such situations.
     * - The returned claims can be customized per project using the [Custom Access Token Hook](/docs/guides/auth/auth-hooks/custom-access-token-hook).
     *
     * @example Get JWT claims, header and signature
     * ```js
     * const { data, error } = await supabase.auth.getClaims()
     * ```
     *
     * @exampleResponse Get JWT claims, header and signature
     * ```json
     * {
     *   "data": {
     *     "claims": {
     *       "aal": "aal1",
     *       "amr": [{
     *         "method": "email",
     *         "timestamp": 1715766000
     *       }],
     *       "app_metadata": {},
     *       "aud": "authenticated",
     *       "email": "example@email.com",
     *       "exp": 1715769600,
     *       "iat": 1715766000,
     *       "is_anonymous": false,
     *       "iss": "https://project-id.supabase.co/auth/v1",
     *       "phone": "+13334445555",
     *       "role": "authenticated",
     *       "session_id": "11111111-1111-1111-1111-111111111111",
     *       "sub": "11111111-1111-1111-1111-111111111111",
     *       "user_metadata": {}
     *     },
     *     "header": {
     *       "alg": "RS256",
     *       "typ": "JWT",
     *       "kid": "11111111-1111-1111-1111-111111111111"
     *     },
     *     "signature": [/** Uint8Array *\/],
     *   },
     *   "error": null
     * }
     * ```
     */
    async getClaims(jwt, options = {}) {
        try {
            let token = jwt;
            if (!token) {
                const { data, error } = await this.getSession();
                if (error || !data.session) {
                    return this._returnResult({ data: null, error });
                }
                token = data.session.access_token;
            }
            const { header, payload, signature, raw: { header: rawHeader, payload: rawPayload }, } = decodeJWT(token);
            if (!(options === null || options === void 0 ? void 0 : options.allowExpired)) {
                // Reject expired JWTs should only happen if jwt argument was passed.
                // Rethrow as AuthInvalidJwtError so the outer catch converts it to { data, error }.
                try {
                    validateExp(payload.exp);
                }
                catch (e) {
                    throw new AuthInvalidJwtError(e instanceof Error ? e.message : 'JWT validation failed');
                }
            }
            const signingKey = !header.alg ||
                header.alg.startsWith('HS') ||
                !header.kid ||
                !('crypto' in globalThis && 'subtle' in globalThis.crypto)
                ? null
                : await this.fetchJwk(header.kid, (options === null || options === void 0 ? void 0 : options.keys) ? { keys: options.keys } : options === null || options === void 0 ? void 0 : options.jwks);
            // If symmetric algorithm or WebCrypto API is unavailable, fallback to getUser()
            if (!signingKey) {
                const { error } = await this.getUser(token);
                if (error) {
                    throw error;
                }
                // getUser succeeds so the claims in the JWT can be trusted
                return {
                    data: {
                        claims: payload,
                        header,
                        signature,
                    },
                    error: null,
                };
            }
            const algorithm = getAlgorithm(header.alg);
            // Convert JWK to CryptoKey
            const publicKey = await crypto.subtle.importKey('jwk', signingKey, algorithm, true, [
                'verify',
            ]);
            // Verify the signature
            const isValid = await crypto.subtle.verify(algorithm, publicKey, signature, stringToUint8Array(`${rawHeader}.${rawPayload}`));
            if (!isValid) {
                throw new AuthInvalidJwtError('Invalid JWT signature');
            }
            // If verification succeeds, decode and return claims
            return {
                data: {
                    claims: payload,
                    header,
                    signature,
                },
                error: null,
            };
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    // --- Passkey Methods ---
    /**
     * Sign in with a passkey. Handles the full WebAuthn ceremony:
     * 1. Fetches authentication challenge from server
     * 2. Prompts user via navigator.credentials.get()
     * 3. Verifies credential with server and creates session
     *
     * Requires `auth.experimental.passkey: true`.
     *
     * @category Auth
     */
    async signInWithPasskey(credentials) {
        var _a, _b, _c;
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            if (!browserSupportsWebAuthn()) {
                return this._returnResult({
                    data: null,
                    error: new AuthUnknownError('Browser does not support WebAuthn', null),
                });
            }
            // 1. Get challenge options from server
            const { data: options, error: optionsError } = await this._startPasskeyAuthentication({
                options: { captchaToken: (_a = credentials === null || credentials === void 0 ? void 0 : credentials.options) === null || _a === void 0 ? void 0 : _a.captchaToken },
            });
            if (optionsError || !options) {
                return this._returnResult({ data: null, error: optionsError });
            }
            // 2. Deserialize and prompt user via browser WebAuthn API
            const publicKeyOptions = deserializeCredentialRequestOptions(options.options);
            const signal = (_c = (_b = credentials === null || credentials === void 0 ? void 0 : credentials.options) === null || _b === void 0 ? void 0 : _b.signal) !== null && _c !== void 0 ? _c : webAuthnAbortService.createNewAbortSignal();
            const { data: credential, error: credentialError } = await getCredential({
                publicKey: publicKeyOptions,
                signal,
            });
            if (credentialError || !credential) {
                return this._returnResult({
                    data: null,
                    error: credentialError !== null && credentialError !== void 0 ? credentialError : new AuthUnknownError('WebAuthn ceremony failed', null),
                });
            }
            // 3. Serialize and verify with server
            const serialized = serializeCredentialRequestResponse(credential);
            return this._verifyPasskeyAuthentication({
                challengeId: options.challenge_id,
                credential: serialized,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Register a passkey for the current authenticated user. Handles the full WebAuthn ceremony:
     * 1. Fetches registration challenge from server
     * 2. Prompts user via navigator.credentials.create()
     * 3. Verifies credential with server
     *
     * Requires an active session. Requires `auth.experimental.passkey: true`.
     *
     * @category Auth
     */
    async registerPasskey(credentials) {
        var _a, _b;
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            if (!browserSupportsWebAuthn()) {
                return this._returnResult({
                    data: null,
                    error: new AuthUnknownError('Browser does not support WebAuthn', null),
                });
            }
            // 1. Get challenge options from server
            const { data: options, error: optionsError } = await this._startPasskeyRegistration();
            if (optionsError || !options) {
                return this._returnResult({ data: null, error: optionsError });
            }
            // 2. Deserialize and prompt user via browser WebAuthn API
            const publicKeyOptions = deserializeCredentialCreationOptions(options.options);
            const signal = (_b = (_a = credentials === null || credentials === void 0 ? void 0 : credentials.options) === null || _a === void 0 ? void 0 : _a.signal) !== null && _b !== void 0 ? _b : webAuthnAbortService.createNewAbortSignal();
            const { data: credential, error: credentialError } = await createCredential({
                publicKey: publicKeyOptions,
                signal,
            });
            if (credentialError || !credential) {
                return this._returnResult({
                    data: null,
                    error: credentialError !== null && credentialError !== void 0 ? credentialError : new AuthUnknownError('WebAuthn ceremony failed', null),
                });
            }
            // 3. Serialize and verify with server
            const serialized = serializeCredentialCreationResponse(credential);
            return this._verifyPasskeyRegistration({
                challengeId: options.challenge_id,
                credential: serialized,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Start passkey registration for the current authenticated user.
     * Returns WebAuthn credential creation options to pass to navigator.credentials.create().
     */
    async _startPasskeyRegistration() {
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                const { data, error } = await _request(this.fetch, 'POST', `${this.url}/passkeys/registration/options`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    body: {},
                });
                if (error) {
                    return this._returnResult({ data: null, error });
                }
                return this._returnResult({ data, error: null });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Verify passkey registration with the credential response.
     * The credentialResponse should be the serialized output of navigator.credentials.create().
     */
    async _verifyPasskeyRegistration(params) {
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                const { data, error } = await _request(this.fetch, 'POST', `${this.url}/passkeys/registration/verify`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    body: {
                        challenge_id: params.challengeId,
                        credential: params.credential,
                    },
                });
                if (error) {
                    return this._returnResult({ data: null, error });
                }
                return this._returnResult({ data, error: null });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Start passkey authentication.
     * Returns WebAuthn credential request options to pass to navigator.credentials.get().
     */
    async _startPasskeyAuthentication(params) {
        var _a;
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            const { data, error } = await _request(this.fetch, 'POST', `${this.url}/passkeys/authentication/options`, {
                headers: this.headers,
                body: {
                    gotrue_meta_security: { captcha_token: (_a = params === null || params === void 0 ? void 0 : params.options) === null || _a === void 0 ? void 0 : _a.captchaToken },
                },
            });
            if (error) {
                return this._returnResult({ data: null, error });
            }
            return this._returnResult({ data, error: null });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Verify passkey authentication and create a session.
     * The credential should be the serialized output of navigator.credentials.get().
     */
    async _verifyPasskeyAuthentication(params) {
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            const { data, error } = await _request(this.fetch, 'POST', `${this.url}/passkeys/authentication/verify`, {
                headers: this.headers,
                body: {
                    challenge_id: params.challengeId,
                    credential: params.credential,
                },
                xform: _sessionResponse,
            });
            if (error) {
                return this._returnResult({ data: null, error });
            }
            if (data.session) {
                await this._saveSession(data.session);
                await this._notifyAllSubscribers('SIGNED_IN', data.session);
            }
            return this._returnResult({ data, error: null });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * List all passkeys for the current user.
     */
    async _listPasskeys() {
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                const { data, error } = await _request(this.fetch, 'GET', `${this.url}/passkeys`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    xform: (data) => ({ data, error: null }),
                });
                if (error) {
                    return this._returnResult({ data: null, error });
                }
                return this._returnResult({ data, error: null });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Update a passkey.
     */
    async _updatePasskey(params) {
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                const { data, error } = await _request(this.fetch, 'PATCH', `${this.url}/passkeys/${params.passkeyId}`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    body: { friendly_name: params.friendlyName },
                });
                if (error) {
                    return this._returnResult({ data: null, error });
                }
                return this._returnResult({ data, error: null });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
    /**
     * Delete a passkey.
     */
    async _deletePasskey(params) {
        assertPasskeyExperimentalEnabled(this.experimental);
        try {
            return await this._useSession(async (result) => {
                const { data: { session }, error: sessionError, } = result;
                if (sessionError) {
                    return this._returnResult({ data: null, error: sessionError });
                }
                if (!session) {
                    return this._returnResult({ data: null, error: new AuthSessionMissingError() });
                }
                const { error } = await _request(this.fetch, 'DELETE', `${this.url}/passkeys/${params.passkeyId}`, {
                    headers: this.headers,
                    jwt: session.access_token,
                    noResolveJson: true,
                });
                if (error) {
                    return this._returnResult({ data: null, error });
                }
                return this._returnResult({ data: null, error: null });
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return this._returnResult({ data: null, error });
            }
            throw error;
        }
    }
}
GoTrueClient.nextInstanceID = {};
export default GoTrueClient;
                                        
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR29UcnVlQ2xpZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL0dvVHJ1ZUNsaWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLGNBQWMsTUFBTSxrQkFBa0IsQ0FBQTtBQUM3QyxPQUFPLEVBQ0wsNkJBQTZCLEVBQzdCLDJCQUEyQixFQUMzQixlQUFlLEVBQ2YsZ0JBQWdCLEVBQ2hCLFVBQVUsRUFDVixRQUFRLEVBQ1IsV0FBVyxHQUNaLE1BQU0saUJBQWlCLENBQUE7QUFDeEIsT0FBTyxFQUVMLDhCQUE4QixFQUM5QiwyQkFBMkIsRUFDM0IsbUJBQW1CLEVBQ25CLDZCQUE2QixFQUM3QixnQ0FBZ0MsRUFDaEMsOEJBQThCLEVBQzlCLHlCQUF5QixFQUN6Qix1QkFBdUIsRUFDdkIsZ0JBQWdCLEVBQ2hCLGNBQWMsRUFDZCxXQUFXLEVBQ1gsZ0NBQWdDLEVBQ2hDLDJCQUEyQixFQUMzQix5QkFBeUIsRUFDekIseUJBQXlCLEdBQzFCLE1BQU0sY0FBYyxDQUFBO0FBQ3JCLE9BQU8sRUFFTCxRQUFRLEVBQ1IsZ0JBQWdCLEVBQ2hCLHdCQUF3QixFQUN4QixZQUFZLEVBQ1osYUFBYSxHQUNkLE1BQU0sYUFBYSxDQUFBO0FBQ3BCLE9BQU8sRUFDTCxnQ0FBZ0MsRUFDaEMsU0FBUyxFQUNULFNBQVMsRUFDVCxRQUFRLEVBQ1Isa0JBQWtCLEVBQ2xCLFlBQVksRUFDWix5QkFBeUIsRUFDekIsWUFBWSxFQUNaLHdCQUF3QixFQUN4QixTQUFTLEVBQ1Qsc0JBQXNCLEVBQ3RCLGVBQWUsRUFDZixZQUFZLEVBQ1osU0FBUyxFQUNULFlBQVksRUFDWixLQUFLLEVBQ0wsb0JBQW9CLEVBQ3BCLHFCQUFxQixFQUNyQixXQUFXLEdBQ1osTUFBTSxlQUFlLENBQUE7QUFDdEIsT0FBTyxFQUFFLHlCQUF5QixFQUFFLE1BQU0scUJBQXFCLENBQUE7QUFDL0QsT0FBTyxFQUFFLHVCQUF1QixFQUFpQixNQUFNLGFBQWEsQ0FBQTtBQUNwRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQTtBQUNwRCxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sZUFBZSxDQUFBO0FBRXZDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGlCQUFpQixDQUFBO0FBZ0d0RSxPQUFPLEVBQ0wsaUJBQWlCLEVBQ2pCLE9BQU8sRUFDUCxVQUFVLEVBR1YsS0FBSyxHQUNOLE1BQU0scUJBQXFCLENBQUE7QUFDNUIsT0FBTyxFQUNMLGdCQUFnQixFQUNoQixvQ0FBb0MsRUFDcEMsbUNBQW1DLEVBQ25DLGFBQWEsRUFDYixtQ0FBbUMsRUFDbkMsa0NBQWtDLEVBQ2xDLHVCQUF1QixFQUN2QixvQkFBb0IsRUFDcEIsV0FBVyxHQUNaLE1BQU0sZ0JBQWdCLENBQUE7QUFPdkIsa0JBQWtCLEVBQUUsQ0FBQSxDQUFDLDhCQUE4QjtBQUVuRCxNQUFNLGVBQWUsR0FHakI7SUFDRixHQUFHLEVBQUUsVUFBVTtJQUNmLFVBQVUsRUFBRSxXQUFXO0lBQ3ZCLGdCQUFnQixFQUFFLElBQUk7SUFDdEIsY0FBYyxFQUFFLElBQUk7SUFDcEIsa0JBQWtCLEVBQUUsSUFBSTtJQUN4QixPQUFPLEVBQUUsZUFBZTtJQUN4QixRQUFRLEVBQUUsVUFBVTtJQUNwQixLQUFLLEVBQUUsS0FBSztJQUNaLDRCQUE0QixFQUFFLEtBQUs7SUFDbkMsWUFBWSxFQUFFLEtBQUs7SUFDbkIsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLDJFQUEyRTtJQUNyRyxrQkFBa0IsRUFBRSxLQUFLO0lBQ3pCLFlBQVksRUFBRSxFQUFFO0NBQ2pCLENBQUE7QUFFRDs7Ozs7R0FLRztBQUNILEtBQUssVUFBVSxRQUFRLENBQUksSUFBWSxFQUFFLGNBQXNCLEVBQUUsRUFBb0I7SUFDbkYsT0FBTyxNQUFNLEVBQUUsRUFBRSxDQUFBO0FBQ25CLENBQUM7QUFFRDs7Ozs7OztHQU9HO0FBQ0gsTUFBTSxXQUFXLEdBQTBFLEVBQUUsQ0FBQTtBQUU3RixNQUFxQixZQUFZO0lBa0MvQjs7T0FFRztJQUNILElBQWMsSUFBSTs7UUFDaEIsT0FBTyxNQUFBLE1BQUEsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsMENBQUUsSUFBSSxtQ0FBSSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQTtJQUMzRCxDQUFDO0lBRUQsSUFBYyxJQUFJLENBQUMsS0FBc0I7UUFDdkMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsbUNBQVEsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBRSxJQUFJLEVBQUUsS0FBSyxHQUFFLENBQUE7SUFDakYsQ0FBQztJQUVELElBQWMsY0FBYzs7UUFDMUIsT0FBTyxNQUFBLE1BQUEsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsMENBQUUsUUFBUSxtQ0FBSSxNQUFNLENBQUMsZ0JBQWdCLENBQUE7SUFDMUUsQ0FBQztJQUVELElBQWMsY0FBYyxDQUFDLEtBQWE7UUFDeEMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsbUNBQVEsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBRSxRQUFRLEVBQUUsS0FBSyxHQUFFLENBQUE7SUFDckYsQ0FBQztJQW9FRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BcUJHO0lBQ0gsWUFBWSxPQUE0Qjs7UUFyRnhDOztXQUVHO1FBQ08sZ0JBQVcsR0FBNEIsSUFBSSxDQUFBO1FBQzNDLGtCQUFhLEdBQXFDLElBQUksQ0FBQTtRQUN0RCx3QkFBbUIsR0FBdUMsSUFBSSxHQUFHLEVBQUUsQ0FBQTtRQUNuRSxzQkFBaUIsR0FBMEMsSUFBSSxDQUFBO1FBQy9ELDJCQUFzQixHQUF5QyxJQUFJLENBQUE7UUFDbkUsOEJBQXlCLEdBQWdDLElBQUksQ0FBQTtRQUM3RCx1QkFBa0IsR0FBNEMsSUFBSSxDQUFBO1FBQzVFOzs7Ozs7V0FNRztRQUNPLHlCQUFvQixHQUFHLENBQUMsQ0FBQTtRQUNsQzs7Ozs7V0FLRztRQUNPLHNCQUFpQixHQUFxQyxJQUFJLENBQUE7UUFDMUQsdUJBQWtCLEdBRTJDLElBQUksQ0FBQTtRQUtqRSxpQ0FBNEIsR0FBRyxLQUFLLENBQUE7UUFDcEMsOEJBQXlCLEdBQUcsS0FBSyxDQUFBO1FBRTNDOzs7OztXQUtHO1FBQ08sU0FBSSxHQUFvQixJQUFJLENBQUE7UUFDNUIsaUJBQVksR0FBRyxLQUFLLENBQUE7UUFDcEIsa0JBQWEsR0FBbUIsRUFBRSxDQUFBO1FBWTVDOztXQUVHO1FBQ08scUJBQWdCLEdBQTRCLElBQUksQ0FBQTtRQUdoRCxXQUFNLEdBQThDLE9BQU8sQ0FBQyxHQUFHLENBQUE7UUF5QnZFLE1BQU0sUUFBUSxtQ0FBUSxlQUFlLEdBQUssT0FBTyxDQUFFLENBQUE7UUFDbkQsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFBO1FBRXJDLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBQSxZQUFZLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsbUNBQUksQ0FBQyxDQUFBO1FBQ25FLFlBQVksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFBO1FBRWxFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQTtRQUN4QyxJQUFJLE9BQU8sUUFBUSxDQUFDLEtBQUssS0FBSyxVQUFVLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUE7UUFDOUIsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLElBQUksU0FBUyxFQUFFLEVBQUUsQ0FBQztZQUN2QyxNQUFNLE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsK01BQStNLENBQUE7WUFDblAsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUNyQixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUMxQixPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQ3hCLENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFBO1FBQzdDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUE7UUFDakQsSUFBSSxDQUFDLFlBQVksR0FBRyxNQUFBLFFBQVEsQ0FBQyxZQUFZLG1DQUFJLEVBQUUsQ0FBQTtRQUMvQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksY0FBYyxDQUFDO1lBQzlCLEdBQUcsRUFBRSxRQUFRLENBQUMsR0FBRztZQUNqQixPQUFPLEVBQUUsUUFBUSxDQUFDLE9BQU87WUFDekIsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFLO1lBQ3JCLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtTQUNoQyxDQUFDLENBQUE7UUFFRixJQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUE7UUFDdkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFBO1FBQy9CLElBQUksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUN6QyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGtCQUFrQixDQUFBO1FBQ3JELElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQTtRQUNqQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsUUFBUSxDQUFDLDRCQUE0QixDQUFBO1FBQ3pFLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQTtRQUV6Qyx3RUFBd0U7UUFDeEUsd0VBQXdFO1FBQ3hFLGdCQUFnQjtRQUNoQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGtCQUFrQixDQUFBO1FBRXJELCtEQUErRDtRQUMvRCxzRUFBc0U7UUFDdEUsMkVBQTJFO1FBQzNFLDJFQUEyRTtRQUMzRSx5Q0FBeUM7UUFDekMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQTtRQUMzQixDQUFDO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUE7WUFDeEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUE7UUFDL0MsQ0FBQztRQUVELElBQUksQ0FBQyxHQUFHLEdBQUc7WUFDVCxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQy9CLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDL0IsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNuQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3JDLFdBQVcsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDekMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDdkQsOEJBQThCLEVBQUUsSUFBSSxDQUFDLCtCQUErQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDL0UsUUFBUSxFQUFFLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQztTQUNoQyxDQUFBO1FBRUQsSUFBSSxDQUFDLEtBQUssR0FBRztZQUNYLHVCQUF1QixFQUFFLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2pFLG9CQUFvQixFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQzNELGlCQUFpQixFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3JELFVBQVUsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUM1QyxXQUFXLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDL0MsQ0FBQTtRQUVELElBQUksQ0FBQyxPQUFPLEdBQUc7WUFDYixpQkFBaUIsRUFBRSxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUM1RCxrQkFBa0IsRUFBRSxJQUFJLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUM5RCxtQkFBbUIsRUFBRSxJQUFJLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNoRSxvQkFBb0IsRUFBRSxJQUFJLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNsRSxJQUFJLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ25DLE1BQU0sRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDdEMsTUFBTSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUN2QyxDQUFBO1FBRUQsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDeEIsSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQTtZQUNqQyxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxvQkFBb0IsRUFBRSxFQUFFLENBQUM7b0JBQzNCLElBQUksQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLFlBQVksQ0FBQTtnQkFDeEMsQ0FBQztxQkFBTSxDQUFDO29CQUNOLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFBO29CQUN2QixJQUFJLENBQUMsT0FBTyxHQUFHLHlCQUF5QixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQTtnQkFDOUQsQ0FBQztZQUNILENBQUM7WUFFRCxJQUFJLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFBO1lBQ3pDLENBQUM7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFBO1lBQ3ZCLElBQUksQ0FBQyxPQUFPLEdBQUcseUJBQXlCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFBO1FBQzlELENBQUM7UUFFRCxJQUFJLFNBQVMsRUFBRSxJQUFJLFVBQVUsQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUN6RixJQUFJLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksVUFBVSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtZQUMxRSxDQUFDO1lBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztnQkFDWCxPQUFPLENBQUMsS0FBSyxDQUNYLHdGQUF3RixFQUN4RixDQUFDLENBQ0YsQ0FBQTtZQUNILENBQUM7WUFFRCxNQUFBLElBQUksQ0FBQyxnQkFBZ0IsMENBQUUsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDakUsSUFBSSxDQUFDLE1BQU0sQ0FBQywwREFBMEQsRUFBRSxLQUFLLENBQUMsQ0FBQTtnQkFFOUUsSUFBSSxDQUFDO29CQUNILE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFBLENBQUMsZ0VBQWdFO2dCQUNoSixDQUFDO2dCQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7b0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUE7Z0JBQ2xELENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCwyRUFBMkU7UUFDM0UsMEVBQTBFO1FBQzFFLCtEQUErRDtRQUMvRCxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixFQUFFLENBQUM7WUFDakMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFO2dCQUNoQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUE7WUFDOUMsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0kscUJBQXFCO1FBQzFCLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQTtJQUMxQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGFBQWEsQ0FBMkIsTUFBUztRQUN2RCxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNoRCxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUE7UUFDcEIsQ0FBQztRQUNELE9BQU8sTUFBTSxDQUFBO0lBQ2YsQ0FBQztJQUVPLFVBQVU7UUFDaEIsT0FBTyxDQUNMLGVBQWU7WUFDZixHQUFHLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUNqRixDQUFBO0lBQ0gsQ0FBQztJQUVPLE1BQU0sQ0FBQyxHQUFHLElBQVc7UUFDM0IsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUMxQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFBO1FBQ3pDLENBQUM7UUFFRCxPQUFPLElBQUksQ0FBQTtJQUNiLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FpQkc7SUFDSCxLQUFLLENBQUMsVUFBVTtRQUNkLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDM0IsT0FBTyxNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FBQTtRQUNyQyxDQUFDO1FBRUQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsS0FBSyxJQUFJLEVBQUU7WUFDbkMsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUN0QixvQ0FBb0M7Z0JBQ3BDLE9BQU8sTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLElBQUksRUFBRTtvQkFDakUsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQTtnQkFDakMsQ0FBQyxDQUFDLENBQUE7WUFDSixDQUFDO1lBQ0QsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQTtRQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRUosT0FBTyxNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FBQTtJQUNyQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxLQUFLLENBQUMsV0FBVzs7UUFDdkIsSUFBSSxDQUFDO1lBQ0gsSUFBSSxNQUFNLEdBQW9DLEVBQUUsQ0FBQTtZQUNoRCxJQUFJLGVBQWUsR0FBRyxNQUFNLENBQUE7WUFFNUIsSUFBSSxTQUFTLEVBQUUsRUFBRSxDQUFDO2dCQUNoQixNQUFNLEdBQUcsc0JBQXNCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQTtnQkFDckQsSUFBSSxJQUFJLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDMUMsZUFBZSxHQUFHLFVBQVUsQ0FBQTtnQkFDOUIsQ0FBQztxQkFBTSxJQUFJLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUM5QyxlQUFlLEdBQUcsTUFBTSxDQUFBO2dCQUMxQixDQUFDO1lBQ0gsQ0FBQztZQUVEOzs7OztlQUtHO1lBQ0gsSUFBSSxTQUFTLEVBQUUsSUFBSSxJQUFJLENBQUMsa0JBQWtCLElBQUksZUFBZSxLQUFLLE1BQU0sRUFBRSxDQUFDO2dCQUN6RSxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxlQUFlLENBQUMsQ0FBQTtnQkFDOUUsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGtDQUFrQyxFQUFFLEtBQUssQ0FBQyxDQUFBO29CQUV4RSxJQUFJLGdDQUFnQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7d0JBQzVDLE1BQU0sU0FBUyxHQUFHLE1BQUEsS0FBSyxDQUFDLE9BQU8sMENBQUUsSUFBSSxDQUFBO3dCQUNyQyxJQUNFLFNBQVMsS0FBSyx5QkFBeUI7NEJBQ3ZDLFNBQVMsS0FBSyxvQkFBb0I7NEJBQ2xDLFNBQVMsS0FBSywrQkFBK0IsRUFDN0MsQ0FBQzs0QkFDRCxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUE7d0JBQ2xCLENBQUM7b0JBQ0gsQ0FBQztvQkFFRCxzREFBc0Q7b0JBQ3RELGtGQUFrRjtvQkFFbEYsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUFBO2dCQUNsQixDQUFDO2dCQUVELE1BQU0sRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFBO2dCQUV0QyxJQUFJLENBQUMsTUFBTSxDQUNULGdCQUFnQixFQUNoQix5QkFBeUIsRUFDekIsT0FBTyxFQUNQLGVBQWUsRUFDZixZQUFZLENBQ2IsQ0FBQTtnQkFFRCxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUE7Z0JBRWhDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRTtvQkFDcEIsSUFBSSxZQUFZLEtBQUssVUFBVSxFQUFFLENBQUM7d0JBQ2hDLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLG1CQUFtQixFQUFFLE9BQU8sQ0FBQyxDQUFBO29CQUNoRSxDQUFDO3lCQUFNLENBQUM7d0JBQ04sTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFBO29CQUN4RCxDQUFDO2dCQUNILENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtnQkFFTCxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO1lBQ3hCLENBQUM7WUFDRCx3RUFBd0U7WUFDeEUsTUFBTSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQTtZQUMvQixPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO1FBQ3hCLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUN0QyxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUN4QixLQUFLLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyx3Q0FBd0MsRUFBRSxLQUFLLENBQUM7YUFDN0UsQ0FBQyxDQUFBO1FBQ0osQ0FBQztnQkFBUyxDQUFDO1lBQ1QsTUFBTSxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQTtZQUNwQyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3RDLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXdFRztJQUNILEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxXQUEwQzs7UUFDaEUsSUFBSSxDQUFDO1lBQ0gsTUFBTSxHQUFHLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxTQUFTLEVBQUU7Z0JBQ25FLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsSUFBSSxFQUFFO29CQUNKLElBQUksRUFBRSxNQUFBLE1BQUEsV0FBVyxhQUFYLFdBQVcsdUJBQVgsV0FBVyxDQUFFLE9BQU8sMENBQUUsSUFBSSxtQ0FBSSxFQUFFO29CQUN0QyxvQkFBb0IsRUFBRSxFQUFFLGFBQWEsRUFBRSxNQUFBLFdBQVcsYUFBWCxXQUFXLHVCQUFYLFdBQVcsQ0FBRSxPQUFPLDBDQUFFLFlBQVksRUFBRTtpQkFDNUU7Z0JBQ0QsS0FBSyxFQUFFLGdCQUFnQjthQUN4QixDQUFDLENBQUE7WUFDRixNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQTtZQUUzQixJQUFJLEtBQUssSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNuQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRixDQUFDO1lBQ0QsTUFBTSxPQUFPLEdBQW1CLElBQUksQ0FBQyxPQUFPLENBQUE7WUFDNUMsTUFBTSxJQUFJLEdBQWdCLElBQUksQ0FBQyxJQUFJLENBQUE7WUFFbkMsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2pCLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7Z0JBQ3JDLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQTtZQUN4RCxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ3JFLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUMzRSxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWdMRztJQUNILEtBQUssQ0FBQyxNQUFNLENBQUMsV0FBMEM7O1FBQ3JELElBQUksQ0FBQztZQUNILElBQUksR0FBaUIsQ0FBQTtZQUNyQixJQUFJLE9BQU8sSUFBSSxXQUFXLEVBQUUsQ0FBQztnQkFDM0IsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEdBQUcsV0FBVyxDQUFBO2dCQUNoRCxJQUFJLGFBQWEsR0FBa0IsSUFBSSxDQUFBO2dCQUN2QyxJQUFJLG1CQUFtQixHQUFrQixJQUFJLENBQUE7Z0JBQzdDLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxNQUFNLEVBQUUsQ0FBQztvQkFDN0IsQ0FBQztvQkFBQSxDQUFDLGFBQWEsRUFBRSxtQkFBbUIsQ0FBQyxHQUFHLE1BQU0seUJBQXlCLENBQ3JFLElBQUksQ0FBQyxPQUFPLEVBQ1osSUFBSSxDQUFDLFVBQVUsQ0FDaEIsQ0FBQTtnQkFDSCxDQUFDO2dCQUNELEdBQUcsR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLFNBQVMsRUFBRTtvQkFDN0QsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixVQUFVLEVBQUUsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGVBQWU7b0JBQ3BDLElBQUksRUFBRTt3QkFDSixLQUFLO3dCQUNMLFFBQVE7d0JBQ1IsSUFBSSxFQUFFLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLElBQUksbUNBQUksRUFBRTt3QkFDekIsb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFlBQVksRUFBRTt3QkFDOUQsY0FBYyxFQUFFLGFBQWE7d0JBQzdCLHFCQUFxQixFQUFFLG1CQUFtQjtxQkFDM0M7b0JBQ0QsS0FBSyxFQUFFLGdCQUFnQjtpQkFDeEIsQ0FBQyxDQUFBO1lBQ0osQ0FBQztpQkFBTSxJQUFJLE9BQU8sSUFBSSxXQUFXLEVBQUUsQ0FBQztnQkFDbEMsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEdBQUcsV0FBVyxDQUFBO2dCQUNoRCxHQUFHLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxTQUFTLEVBQUU7b0JBQzdELE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsSUFBSSxFQUFFO3dCQUNKLEtBQUs7d0JBQ0wsUUFBUTt3QkFDUixJQUFJLEVBQUUsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsSUFBSSxtQ0FBSSxFQUFFO3dCQUN6QixPQUFPLEVBQUUsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsT0FBTyxtQ0FBSSxLQUFLO3dCQUNsQyxvQkFBb0IsRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsWUFBWSxFQUFFO3FCQUMvRDtvQkFDRCxLQUFLLEVBQUUsZ0JBQWdCO2lCQUN4QixDQUFDLENBQUE7WUFDSixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxJQUFJLDJCQUEyQixDQUNuQyxpRUFBaUUsQ0FDbEUsQ0FBQTtZQUNILENBQUM7WUFFRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQTtZQUUzQixJQUFJLEtBQUssSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNuQixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtnQkFDdkUsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbEYsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFtQixJQUFJLENBQUMsT0FBTyxDQUFBO1lBQzVDLE1BQU0sSUFBSSxHQUFnQixJQUFJLENBQUMsSUFBSSxDQUFBO1lBRW5DLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNqQixNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO2dCQUNyQyxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUE7WUFDeEQsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtRQUNyRSxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxnQkFBZ0IsQ0FBQyxDQUFBO1lBQ3ZFLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDM0UsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FtSUc7SUFDSCxLQUFLLENBQUMsa0JBQWtCLENBQ3RCLFdBQTBDO1FBRTFDLElBQUksQ0FBQztZQUNILElBQUksR0FBeUIsQ0FBQTtZQUM3QixJQUFJLE9BQU8sSUFBSSxXQUFXLEVBQUUsQ0FBQztnQkFDM0IsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEdBQUcsV0FBVyxDQUFBO2dCQUNoRCxHQUFHLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyw0QkFBNEIsRUFBRTtvQkFDaEYsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixJQUFJLEVBQUU7d0JBQ0osS0FBSzt3QkFDTCxRQUFRO3dCQUNSLG9CQUFvQixFQUFFLEVBQUUsYUFBYSxFQUFFLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxZQUFZLEVBQUU7cUJBQy9EO29CQUNELEtBQUssRUFBRSx3QkFBd0I7aUJBQ2hDLENBQUMsQ0FBQTtZQUNKLENBQUM7aUJBQU0sSUFBSSxPQUFPLElBQUksV0FBVyxFQUFFLENBQUM7Z0JBQ2xDLE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxHQUFHLFdBQVcsQ0FBQTtnQkFDaEQsR0FBRyxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsNEJBQTRCLEVBQUU7b0JBQ2hGLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsSUFBSSxFQUFFO3dCQUNKLEtBQUs7d0JBQ0wsUUFBUTt3QkFDUixvQkFBb0IsRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsWUFBWSxFQUFFO3FCQUMvRDtvQkFDRCxLQUFLLEVBQUUsd0JBQXdCO2lCQUNoQyxDQUFDLENBQUE7WUFDSixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxJQUFJLDJCQUEyQixDQUNuQyxpRUFBaUUsQ0FDbEUsQ0FBQTtZQUNILENBQUM7WUFDRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQTtZQUUzQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUNWLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDM0UsQ0FBQztpQkFBTSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDaEQsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLDZCQUE2QixFQUFFLENBQUE7Z0JBQzdELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUE7WUFDOUYsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNqQixNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO2dCQUNyQyxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQzdELENBQUM7WUFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7Z0JBQ3hCLElBQUksa0JBQ0YsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQ2YsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLElBQ2xCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FDdEU7Z0JBQ0QsS0FBSzthQUNOLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUMzRSxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E4RUc7SUFDSCxLQUFLLENBQUMsZUFBZSxDQUFDLFdBQXVDOztRQUMzRCxPQUFPLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUU7WUFDNUQsVUFBVSxFQUFFLE1BQUEsV0FBVyxDQUFDLE9BQU8sMENBQUUsVUFBVTtZQUMzQyxNQUFNLEVBQUUsTUFBQSxXQUFXLENBQUMsT0FBTywwQ0FBRSxNQUFNO1lBQ25DLFdBQVcsRUFBRSxNQUFBLFdBQVcsQ0FBQyxPQUFPLDBDQUFFLFdBQVc7WUFDN0MsbUJBQW1CLEVBQUUsTUFBQSxXQUFXLENBQUMsT0FBTywwQ0FBRSxtQkFBbUI7U0FDOUQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BeUtHO0lBQ0gsS0FBSyxDQUFDLHNCQUFzQixDQUFDLFFBQWdCO1FBQzNDLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFBO1FBRTVCLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUN0QixvQ0FBb0M7WUFDcEMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDM0QsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUE7WUFDL0MsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDL0MsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0F1Rkc7SUFDSCxLQUFLLENBQUMsY0FBYyxDQUFDLFdBQTRCO1FBTy9DLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUE7UUFFN0IsUUFBUSxLQUFLLEVBQUUsQ0FBQztZQUNkLEtBQUssVUFBVTtnQkFDYixPQUFPLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxDQUFBO1lBQ25ELEtBQUssUUFBUTtnQkFDWCxPQUFPLE1BQU0sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFBO1lBQ2pEO2dCQUNFLE1BQU0sSUFBSSxLQUFLLENBQUMseUNBQXlDLEtBQUssR0FBRyxDQUFDLENBQUE7UUFDdEUsQ0FBQztJQUNILENBQUM7SUFFTyxLQUFLLENBQUMsa0JBQWtCLENBQzlCLFdBQW9DOztRQUtwQyxxQkFBcUI7UUFDckIsSUFBSSxPQUFlLENBQUE7UUFDbkIsSUFBSSxTQUFjLENBQUE7UUFFbEIsSUFBSSxTQUFTLElBQUksV0FBVyxFQUFFLENBQUM7WUFDN0IsT0FBTyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUE7WUFDN0IsU0FBUyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUE7UUFDbkMsQ0FBQzthQUFNLENBQUM7WUFDTixNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEdBQUcsV0FBVyxDQUFBO1lBRXpELElBQUksY0FBOEIsQ0FBQTtZQUVsQyxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQztnQkFDakIsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRLElBQUksQ0FBQyxDQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxHQUFHLENBQUEsRUFBRSxDQUFDO29CQUNoRCxNQUFNLElBQUksS0FBSyxDQUNiLHVGQUF1RixDQUN4RixDQUFBO2dCQUNILENBQUM7Z0JBRUQsY0FBYyxHQUFHLE1BQU0sQ0FBQTtZQUN6QixDQUFDO2lCQUFNLElBQUksT0FBTyxNQUFNLEtBQUssUUFBUSxFQUFFLENBQUM7Z0JBQ3RDLGNBQWMsR0FBRyxNQUFNLENBQUE7WUFDekIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE1BQU0sU0FBUyxHQUFHLE1BQWEsQ0FBQTtnQkFFL0IsSUFDRSxVQUFVLElBQUksU0FBUztvQkFDdkIsT0FBTyxTQUFTLENBQUMsUUFBUSxLQUFLLFFBQVE7b0JBQ3RDLFNBQVMsSUFBSSxTQUFTLENBQUMsUUFBUTtvQkFDL0IsT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sS0FBSyxVQUFVLEVBQ2hELENBQUM7b0JBQ0QsY0FBYyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUE7Z0JBQ3JDLENBQUM7cUJBQU0sQ0FBQztvQkFDTixNQUFNLElBQUksS0FBSyxDQUNiLDZUQUE2VCxDQUM5VCxDQUFBO2dCQUNILENBQUM7WUFDSCxDQUFDO1lBRUQsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsR0FBRyxtQ0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFBO1lBRXpELE1BQU0sUUFBUSxHQUFHLE1BQU0sY0FBYztpQkFDbEMsT0FBTyxDQUFDO2dCQUNQLE1BQU0sRUFBRSxxQkFBcUI7YUFDOUIsQ0FBQztpQkFDRCxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQWdCLENBQUM7aUJBQ2hDLEtBQUssQ0FBQyxHQUFHLEVBQUU7Z0JBQ1YsTUFBTSxJQUFJLEtBQUssQ0FDYiw0RUFBNEUsQ0FDN0UsQ0FBQTtZQUNILENBQUMsQ0FBQyxDQUFBO1lBRUosSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QyxNQUFNLElBQUksS0FBSyxDQUNiLGtGQUFrRixDQUNuRixDQUFBO1lBQ0gsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUV2QyxJQUFJLE9BQU8sR0FBRyxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxrQkFBa0IsMENBQUUsT0FBTyxDQUFBO1lBQ2xELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDYixNQUFNLFVBQVUsR0FBRyxNQUFNLGNBQWMsQ0FBQyxPQUFPLENBQUM7b0JBQzlDLE1BQU0sRUFBRSxhQUFhO2lCQUN0QixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFpQixDQUFDLENBQUE7WUFDdEMsQ0FBQztZQUVELE1BQU0sV0FBVyxHQUFnQjtnQkFDL0IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO2dCQUNoQixPQUFPLEVBQUUsT0FBTztnQkFDaEIsU0FBUyxFQUFFLFNBQVM7Z0JBQ3BCLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSTtnQkFDYixPQUFPLEVBQUUsR0FBRztnQkFDWixPQUFPLEVBQUUsT0FBTztnQkFDaEIsS0FBSyxFQUFFLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGtCQUFrQiwwQ0FBRSxLQUFLO2dCQUN6QyxRQUFRLEVBQUUsTUFBQSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxrQkFBa0IsMENBQUUsUUFBUSxtQ0FBSSxJQUFJLElBQUksRUFBRTtnQkFDN0QsY0FBYyxFQUFFLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGtCQUFrQiwwQ0FBRSxjQUFjO2dCQUMzRCxTQUFTLEVBQUUsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsa0JBQWtCLDBDQUFFLFNBQVM7Z0JBQ2pELFNBQVMsRUFBRSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxrQkFBa0IsMENBQUUsU0FBUztnQkFDakQsU0FBUyxFQUFFLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGtCQUFrQiwwQ0FBRSxTQUFTO2FBQ2xELENBQUE7WUFFRCxPQUFPLEdBQUcsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUE7WUFFeEMsZUFBZTtZQUNmLFNBQVMsR0FBRyxDQUFDLE1BQU0sY0FBYyxDQUFDLE9BQU8sQ0FBQztnQkFDeEMsTUFBTSxFQUFFLGVBQWU7Z0JBQ3ZCLE1BQU0sRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUM7YUFDbEMsQ0FBQyxDQUFRLENBQUE7UUFDWixDQUFDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FDcEMsSUFBSSxDQUFDLEtBQUssRUFDVixNQUFNLEVBQ04sR0FBRyxJQUFJLENBQUMsR0FBRyx3QkFBd0IsRUFDbkM7Z0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixJQUFJLGtCQUNGLEtBQUssRUFBRSxVQUFVLEVBQ2pCLE9BQU87b0JBQ1AsU0FBUyxJQUNOLENBQUMsQ0FBQSxNQUFBLFdBQVcsQ0FBQyxPQUFPLDBDQUFFLFlBQVk7b0JBQ25DLENBQUMsQ0FBQyxFQUFFLG9CQUFvQixFQUFFLEVBQUUsYUFBYSxFQUFFLE1BQUEsV0FBVyxDQUFDLE9BQU8sMENBQUUsWUFBWSxFQUFFLEVBQUU7b0JBQ2hGLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FDVjtnQkFDRCxLQUFLLEVBQUUsZ0JBQWdCO2FBQ3hCLENBQ0YsQ0FBQTtZQUNELElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ1YsTUFBTSxLQUFLLENBQUE7WUFDYixDQUFDO1lBQ0QsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3pDLE1BQU0saUJBQWlCLEdBQUcsSUFBSSw2QkFBNkIsRUFBRSxDQUFBO2dCQUM3RCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO1lBQzlGLENBQUM7WUFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDakIsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDckMsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUM3RCxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxvQkFBTyxJQUFJLENBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1FBQ3pELENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUMzRSxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVPLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFrQzs7UUFDL0QsSUFBSSxPQUFlLENBQUE7UUFDbkIsSUFBSSxTQUFxQixDQUFBO1FBRXpCLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQzdCLE9BQU8sR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFBO1lBQzdCLFNBQVMsR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFBO1FBQ25DLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxHQUFHLFdBQVcsQ0FBQTtZQUV6RCxJQUFJLGNBQTRCLENBQUE7WUFFaEMsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUM7Z0JBQ2pCLElBQUksT0FBTyxNQUFNLEtBQUssUUFBUSxJQUFJLENBQUMsQ0FBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsR0FBRyxDQUFBLEVBQUUsQ0FBQztvQkFDaEQsTUFBTSxJQUFJLEtBQUssQ0FDYix1RkFBdUYsQ0FDeEYsQ0FBQTtnQkFDSCxDQUFDO2dCQUVELGNBQWMsR0FBRyxNQUFNLENBQUE7WUFDekIsQ0FBQztpQkFBTSxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUN0QyxjQUFjLEdBQUcsTUFBTSxDQUFBO1lBQ3pCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLFNBQVMsR0FBRyxNQUFhLENBQUE7Z0JBRS9CLElBQ0UsUUFBUSxJQUFJLFNBQVM7b0JBQ3JCLE9BQU8sU0FBUyxDQUFDLE1BQU0sS0FBSyxRQUFRO29CQUNwQyxDQUFDLENBQUMsUUFBUSxJQUFJLFNBQVMsQ0FBQyxNQUFNLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxVQUFVLENBQUM7d0JBQzlFLENBQUMsYUFBYSxJQUFJLFNBQVMsQ0FBQyxNQUFNOzRCQUNoQyxPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxDQUFDLEVBQ3hELENBQUM7b0JBQ0QsY0FBYyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUE7Z0JBQ25DLENBQUM7cUJBQU0sQ0FBQztvQkFDTixNQUFNLElBQUksS0FBSyxDQUNiLHVUQUF1VCxDQUN4VCxDQUFBO2dCQUNILENBQUM7WUFDSCxDQUFDO1lBRUQsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsR0FBRyxtQ0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFBO1lBRXpELElBQUksUUFBUSxJQUFJLGNBQWMsSUFBSSxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ3hELE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLE1BQU0sNkNBQ3hDLFFBQVEsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxJQUUvQixPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsZ0JBQWdCO29CQUU1Qiw2QkFBNkI7b0JBQzdCLE9BQU8sRUFBRSxHQUFHLEVBQ1osTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJLEVBQ2hCLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxLQUVWLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFDckMsQ0FBQTtnQkFFRixJQUFJLGVBQW9CLENBQUE7Z0JBRXhCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFLENBQUM7b0JBQ3hFLGVBQWUsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQzdCLENBQUM7cUJBQU0sSUFDTCxNQUFNO29CQUNOLE9BQU8sTUFBTSxLQUFLLFFBQVE7b0JBQzFCLGVBQWUsSUFBSSxNQUFNO29CQUN6QixXQUFXLElBQUksTUFBTSxFQUNyQixDQUFDO29CQUNELGVBQWUsR0FBRyxNQUFNLENBQUE7Z0JBQzFCLENBQUM7cUJBQU0sQ0FBQztvQkFDTixNQUFNLElBQUksS0FBSyxDQUFDLHVFQUF1RSxDQUFDLENBQUE7Z0JBQzFGLENBQUM7Z0JBRUQsSUFDRSxlQUFlLElBQUksZUFBZTtvQkFDbEMsV0FBVyxJQUFJLGVBQWU7b0JBQzlCLENBQUMsT0FBTyxlQUFlLENBQUMsYUFBYSxLQUFLLFFBQVE7d0JBQ2hELGVBQWUsQ0FBQyxhQUFhLFlBQVksVUFBVSxDQUFDO29CQUN0RCxlQUFlLENBQUMsU0FBUyxZQUFZLFVBQVUsRUFDL0MsQ0FBQztvQkFDRCxPQUFPO3dCQUNMLE9BQU8sZUFBZSxDQUFDLGFBQWEsS0FBSyxRQUFROzRCQUMvQyxDQUFDLENBQUMsZUFBZSxDQUFDLGFBQWE7NEJBQy9CLENBQUMsQ0FBQyxJQUFJLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUE7b0JBQzdELFNBQVMsR0FBRyxlQUFlLENBQUMsU0FBUyxDQUFBO2dCQUN2QyxDQUFDO3FCQUFNLENBQUM7b0JBQ04sTUFBTSxJQUFJLEtBQUssQ0FDYiwwR0FBMEcsQ0FDM0csQ0FBQTtnQkFDSCxDQUFDO1lBQ0gsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQ0UsQ0FBQyxDQUFDLGFBQWEsSUFBSSxjQUFjLENBQUM7b0JBQ2xDLE9BQU8sY0FBYyxDQUFDLFdBQVcsS0FBSyxVQUFVO29CQUNoRCxDQUFDLENBQUMsV0FBVyxJQUFJLGNBQWMsQ0FBQztvQkFDaEMsT0FBTyxjQUFjLEtBQUssUUFBUTtvQkFDbEMsQ0FBQyxjQUFjLENBQUMsU0FBUztvQkFDekIsQ0FBQyxDQUFDLFVBQVUsSUFBSSxjQUFjLENBQUMsU0FBUyxDQUFDO29CQUN6QyxPQUFPLGNBQWMsQ0FBQyxTQUFTLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFDdkQsQ0FBQztvQkFDRCxNQUFNLElBQUksS0FBSyxDQUNiLGlHQUFpRyxDQUNsRyxDQUFBO2dCQUNILENBQUM7Z0JBRUQsT0FBTyxHQUFHO29CQUNSLEdBQUcsR0FBRyxDQUFDLElBQUksaURBQWlEO29CQUM1RCxjQUFjLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRTtvQkFDbkMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUMzQyxZQUFZO29CQUNaLFFBQVEsR0FBRyxDQUFDLElBQUksRUFBRTtvQkFDbEIsY0FBYyxNQUFBLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGdCQUFnQiwwQ0FBRSxRQUFRLG1DQUFJLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLEVBQUU7b0JBQy9FLEdBQUcsQ0FBQyxDQUFBLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGdCQUFnQiwwQ0FBRSxTQUFTO3dCQUN0QyxDQUFDLENBQUMsQ0FBQyxlQUFlLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQzt3QkFDdkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQztvQkFDUCxHQUFHLENBQUMsQ0FBQSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxnQkFBZ0IsMENBQUUsY0FBYzt3QkFDM0MsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUUsQ0FBQzt3QkFDakUsQ0FBQyxDQUFDLEVBQUUsQ0FBQztvQkFDUCxHQUFHLENBQUMsQ0FBQSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxnQkFBZ0IsMENBQUUsT0FBTzt3QkFDcEMsQ0FBQyxDQUFDLENBQUMsYUFBYSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLENBQUM7d0JBQ25ELENBQUMsQ0FBQyxFQUFFLENBQUM7b0JBQ1AsR0FBRyxDQUFDLENBQUEsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsZ0JBQWdCLDBDQUFFLEtBQUssRUFBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7b0JBQ3pGLEdBQUcsQ0FBQyxDQUFBLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGdCQUFnQiwwQ0FBRSxTQUFTO3dCQUN0QyxDQUFDLENBQUMsQ0FBQyxlQUFlLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQzt3QkFDdkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQztvQkFDUCxHQUFHLENBQUMsQ0FBQSxNQUFBLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGdCQUFnQiwwQ0FBRSxTQUFTLDBDQUFFLE1BQU07d0JBQzlDLENBQUMsQ0FBQzs0QkFDRSxXQUFXOzRCQUNYLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLEtBQUssUUFBUSxFQUFFLENBQUM7eUJBQ3pFO3dCQUNILENBQUMsQ0FBQyxFQUFFLENBQUM7aUJBQ1IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7Z0JBRVosTUFBTSxjQUFjLEdBQUcsTUFBTSxjQUFjLENBQUMsV0FBVyxDQUNyRCxJQUFJLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFDakMsTUFBTSxDQUNQLENBQUE7Z0JBRUQsSUFBSSxDQUFDLGNBQWMsSUFBSSxDQUFDLENBQUMsY0FBYyxZQUFZLFVBQVUsQ0FBQyxFQUFFLENBQUM7b0JBQy9ELE1BQU0sSUFBSSxLQUFLLENBQ2IsMEVBQTBFLENBQzNFLENBQUE7Z0JBQ0gsQ0FBQztnQkFFRCxTQUFTLEdBQUcsY0FBYyxDQUFBO1lBQzVCLENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FDcEMsSUFBSSxDQUFDLEtBQUssRUFDVixNQUFNLEVBQ04sR0FBRyxJQUFJLENBQUMsR0FBRyx3QkFBd0IsRUFDbkM7Z0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixJQUFJLGtCQUNGLEtBQUssRUFBRSxRQUFRLEVBQ2YsT0FBTyxFQUNQLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFFbkMsQ0FBQyxDQUFBLE1BQUEsV0FBVyxDQUFDLE9BQU8sMENBQUUsWUFBWTtvQkFDbkMsQ0FBQyxDQUFDLEVBQUUsb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsTUFBQSxXQUFXLENBQUMsT0FBTywwQ0FBRSxZQUFZLEVBQUUsRUFBRTtvQkFDaEYsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUNWO2dCQUNELEtBQUssRUFBRSxnQkFBZ0I7YUFDeEIsQ0FDRixDQUFBO1lBQ0QsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDVixNQUFNLEtBQUssQ0FBQTtZQUNiLENBQUM7WUFDRCxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLDZCQUE2QixFQUFFLENBQUE7Z0JBQzdELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUE7WUFDOUYsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNqQixNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO2dCQUNyQyxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQzdELENBQUM7WUFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLG9CQUFPLElBQUksQ0FBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7UUFDekQsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNFLENBQUM7WUFFRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRU8sS0FBSyxDQUFDLHVCQUF1QixDQUFDLFFBQWdCO1FBT3BELE1BQU0sV0FBVyxHQUFHLE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxnQkFBZ0IsQ0FBQyxDQUFBO1FBQ3hGLE1BQU0sQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLEdBQUksQ0FBQyxXQUFXLGFBQVgsV0FBVyxjQUFYLFdBQVcsR0FBSSxFQUFFLENBQVksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7UUFFL0UsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDO2dCQUM5QyxNQUFNLElBQUksZ0NBQWdDLEVBQUUsQ0FBQTtZQUM5QyxDQUFDO1lBRUQsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FDcEMsSUFBSSxDQUFDLEtBQUssRUFDVixNQUFNLEVBQ04sR0FBRyxJQUFJLENBQUMsR0FBRyx3QkFBd0IsRUFDbkM7Z0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixJQUFJLEVBQUU7b0JBQ0osU0FBUyxFQUFFLFFBQVE7b0JBQ25CLGFBQWEsRUFBRSxZQUFZO2lCQUM1QjtnQkFDRCxLQUFLLEVBQUUsZ0JBQWdCO2FBQ3hCLENBQ0YsQ0FBQTtZQUNELE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxnQkFBZ0IsQ0FBQyxDQUFBO1lBQ3ZFLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ1YsTUFBTSxLQUFLLENBQUE7WUFDYixDQUFDO1lBQ0QsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3pDLE1BQU0saUJBQWlCLEdBQUcsSUFBSSw2QkFBNkIsRUFBRSxDQUFBO2dCQUM3RCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQ3hCLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFO29CQUN2RCxLQUFLLEVBQUUsaUJBQWlCO2lCQUN6QixDQUFDLENBQUE7WUFDSixDQUFDO1lBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2pCLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7Z0JBQ3JDLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUM5QixZQUFZLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUMvRCxJQUFJLENBQUMsT0FBTyxDQUNiLENBQUE7WUFDSCxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxrQ0FBTyxJQUFJLEtBQUUsWUFBWSxFQUFFLFlBQVksYUFBWixZQUFZLGNBQVosWUFBWSxHQUFJLElBQUksR0FBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7UUFDN0YsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtZQUN2RSxJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQ3hCLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFO29CQUN2RCxLQUFLO2lCQUNOLENBQUMsQ0FBQTtZQUNKLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BMEVHO0lBQ0gsS0FBSyxDQUFDLGlCQUFpQixDQUFDLFdBQXlDO1FBQy9ELElBQUksQ0FBQztZQUNILE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEdBQUcsV0FBVyxDQUFBO1lBRXJFLE1BQU0sR0FBRyxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsNEJBQTRCLEVBQUU7Z0JBQ3RGLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsSUFBSSxFQUFFO29CQUNKLFFBQVE7b0JBQ1IsUUFBUSxFQUFFLEtBQUs7b0JBQ2YsWUFBWTtvQkFDWixLQUFLO29CQUNMLG9CQUFvQixFQUFFLEVBQUUsYUFBYSxFQUFFLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxZQUFZLEVBQUU7aUJBQy9EO2dCQUNELEtBQUssRUFBRSxnQkFBZ0I7YUFDeEIsQ0FBQyxDQUFBO1lBRUYsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxHQUFHLENBQUE7WUFDM0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNFLENBQUM7aUJBQU0sSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2hELE1BQU0saUJBQWlCLEdBQUcsSUFBSSw2QkFBNkIsRUFBRSxDQUFBO2dCQUM3RCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO1lBQzlGLENBQUM7WUFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDakIsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDckMsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUM3RCxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7UUFDNUMsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNFLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E0RUc7SUFDSCxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQThDOztRQUNoRSxJQUFJLENBQUM7WUFDSCxJQUFJLE9BQU8sSUFBSSxXQUFXLEVBQUUsQ0FBQztnQkFDM0IsTUFBTSxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsR0FBRyxXQUFXLENBQUE7Z0JBQ3RDLElBQUksYUFBYSxHQUFrQixJQUFJLENBQUE7Z0JBQ3ZDLElBQUksbUJBQW1CLEdBQWtCLElBQUksQ0FBQTtnQkFDN0MsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDO29CQUM3QixDQUFDO29CQUFBLENBQUMsYUFBYSxFQUFFLG1CQUFtQixDQUFDLEdBQUcsTUFBTSx5QkFBeUIsQ0FDckUsSUFBSSxDQUFDLE9BQU8sRUFDWixJQUFJLENBQUMsVUFBVSxDQUNoQixDQUFBO2dCQUNILENBQUM7Z0JBQ0QsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsTUFBTSxFQUFFO29CQUN0RSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLElBQUksRUFBRTt3QkFDSixLQUFLO3dCQUNMLElBQUksRUFBRSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxJQUFJLG1DQUFJLEVBQUU7d0JBQ3pCLFdBQVcsRUFBRSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxnQkFBZ0IsbUNBQUksSUFBSTt3QkFDOUMsb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFlBQVksRUFBRTt3QkFDOUQsY0FBYyxFQUFFLGFBQWE7d0JBQzdCLHFCQUFxQixFQUFFLG1CQUFtQjtxQkFDM0M7b0JBQ0QsVUFBVSxFQUFFLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxlQUFlO2lCQUNyQyxDQUFDLENBQUE7Z0JBQ0YsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUMzRSxDQUFDO1lBQ0QsSUFBSSxPQUFPLElBQUksV0FBVyxFQUFFLENBQUM7Z0JBQzNCLE1BQU0sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEdBQUcsV0FBVyxDQUFBO2dCQUN0QyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsTUFBTSxFQUFFO29CQUM1RSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLElBQUksRUFBRTt3QkFDSixLQUFLO3dCQUNMLElBQUksRUFBRSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxJQUFJLG1DQUFJLEVBQUU7d0JBQ3pCLFdBQVcsRUFBRSxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxnQkFBZ0IsbUNBQUksSUFBSTt3QkFDOUMsb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFlBQVksRUFBRTt3QkFDOUQsT0FBTyxFQUFFLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLE9BQU8sbUNBQUksS0FBSztxQkFDbkM7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztvQkFDeEIsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsVUFBVSxFQUFFO29CQUNoRSxLQUFLO2lCQUNOLENBQUMsQ0FBQTtZQUNKLENBQUM7WUFDRCxNQUFNLElBQUksMkJBQTJCLENBQUMsbURBQW1ELENBQUMsQ0FBQTtRQUM1RixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxnQkFBZ0IsQ0FBQyxDQUFBO1lBQ3ZFLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDM0UsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXdJRztJQUNILEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBdUI7O1FBQ3JDLElBQUksQ0FBQztZQUNILElBQUksVUFBVSxHQUF1QixTQUFTLENBQUE7WUFDOUMsSUFBSSxZQUFZLEdBQXVCLFNBQVMsQ0FBQTtZQUNoRCxJQUFJLFNBQVMsSUFBSSxNQUFNLEVBQUUsQ0FBQztnQkFDeEIsVUFBVSxHQUFHLE1BQUEsTUFBTSxDQUFDLE9BQU8sMENBQUUsVUFBVSxDQUFBO2dCQUN2QyxZQUFZLEdBQUcsTUFBQSxNQUFNLENBQUMsT0FBTywwQ0FBRSxZQUFZLENBQUE7WUFDN0MsQ0FBQztZQUNELE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxTQUFTLEVBQUU7Z0JBQy9FLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsSUFBSSxrQ0FDQyxNQUFNLEtBQ1Qsb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFLEdBQ3REO2dCQUNELFVBQVU7Z0JBQ1YsS0FBSyxFQUFFLGdCQUFnQjthQUN4QixDQUFDLENBQUE7WUFFRixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUNWLE1BQU0sS0FBSyxDQUFBO1lBQ2IsQ0FBQztZQUNELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDVixNQUFNLHNCQUFzQixHQUFHLElBQUksS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7Z0JBQ3BGLE1BQU0sc0JBQXNCLENBQUE7WUFDOUIsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFtQixJQUFJLENBQUMsT0FBTyxDQUFBO1lBQzVDLE1BQU0sSUFBSSxHQUFnQixJQUFJLENBQUMsSUFBSSxDQUFBO1lBRW5DLElBQUksT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFlBQVksRUFBRSxDQUFDO2dCQUMxQixNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBa0IsQ0FBQyxDQUFBO2dCQUMzQyxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FDOUIsTUFBTSxDQUFDLElBQUksSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQzdELE9BQU8sQ0FDUixDQUFBO1lBQ0gsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtRQUNyRSxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDM0UsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9ERztJQUNILEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBcUI7O1FBQ3ZDLElBQUksQ0FBQztZQUNILElBQUksYUFBYSxHQUFrQixJQUFJLENBQUE7WUFDdkMsSUFBSSxtQkFBbUIsR0FBa0IsSUFBSSxDQUFBO1lBQzdDLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxNQUFNLEVBQUUsQ0FBQztnQkFDN0IsQ0FBQztnQkFBQSxDQUFDLGFBQWEsRUFBRSxtQkFBbUIsQ0FBQyxHQUFHLE1BQU0seUJBQXlCLENBQ3JFLElBQUksQ0FBQyxPQUFPLEVBQ1osSUFBSSxDQUFDLFVBQVUsQ0FDaEIsQ0FBQTtZQUNILENBQUM7WUFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLE1BQU0sRUFBRTtnQkFDbkUsSUFBSSw0RUFDQyxDQUFDLFlBQVksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQ3BFLENBQUMsUUFBUSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FDMUQsV0FBVyxFQUFFLE1BQUEsTUFBQSxNQUFNLENBQUMsT0FBTywwQ0FBRSxVQUFVLG1DQUFJLFNBQVMsS0FDakQsQ0FBQyxDQUFBLE1BQUEsTUFBTSxhQUFOLE1BQU0sdUJBQU4sTUFBTSxDQUFFLE9BQU8sMENBQUUsWUFBWTtvQkFDL0IsQ0FBQyxDQUFDLEVBQUUsb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsRUFBRTtvQkFDMUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUNULGtCQUFrQixFQUFFLElBQUksRUFDeEIsY0FBYyxFQUFFLGFBQWEsRUFDN0IscUJBQXFCLEVBQUUsbUJBQW1CLEdBQzNDO2dCQUNELE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsS0FBSyxFQUFFLFlBQVk7YUFDcEIsQ0FBQyxDQUFBO1lBRUYsdUVBQXVFO1lBQ3ZFLElBQUksQ0FBQSxNQUFBLE1BQU0sQ0FBQyxJQUFJLDBDQUFFLEdBQUcsS0FBSSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUEsTUFBQSxNQUFNLENBQUMsT0FBTywwQ0FBRSxtQkFBbUIsQ0FBQSxFQUFFLENBQUM7Z0JBQzVFLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7WUFDekMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUNuQyxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxnQkFBZ0IsQ0FBQyxDQUFBO1lBQ3ZFLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9CRztJQUNILEtBQUssQ0FBQyxjQUFjO1FBQ2xCLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFBO1FBRTVCLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUN0QixvQ0FBb0M7WUFDcEMsT0FBTyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNqRSxPQUFPLE1BQU0sSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFBO1lBQ3JDLENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE9BQU8sTUFBTSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7SUFDckMsQ0FBQztJQUVPLEtBQUssQ0FBQyxlQUFlO1FBQzNCLElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDN0MsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUNqQixLQUFLLEVBQUUsWUFBWSxHQUNwQixHQUFHLE1BQU0sQ0FBQTtnQkFDVixJQUFJLFlBQVk7b0JBQUUsTUFBTSxZQUFZLENBQUE7Z0JBQ3BDLElBQUksQ0FBQyxPQUFPO29CQUFFLE1BQU0sSUFBSSx1QkFBdUIsRUFBRSxDQUFBO2dCQUVqRCxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxpQkFBaUIsRUFBRTtvQkFDaEYsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsT0FBTyxDQUFDLFlBQVk7aUJBQzFCLENBQUMsQ0FBQTtnQkFDRixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNFLENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNFLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0EwREc7SUFDSCxLQUFLLENBQUMsTUFBTSxDQUFDLFdBQXlCO1FBQ3BDLElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsU0FBUyxDQUFBO1lBQ3JDLElBQUksT0FBTyxJQUFJLFdBQVcsRUFBRSxDQUFDO2dCQUMzQixNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsR0FBRyxXQUFXLENBQUE7Z0JBQzVDLElBQUksYUFBYSxHQUFrQixJQUFJLENBQUE7Z0JBQ3ZDLElBQUksbUJBQW1CLEdBQWtCLElBQUksQ0FBQTtnQkFDN0MsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDO29CQUM3QixDQUFDO29CQUFBLENBQUMsYUFBYSxFQUFFLG1CQUFtQixDQUFDLEdBQUcsTUFBTSx5QkFBeUIsQ0FDckUsSUFBSSxDQUFDLE9BQU8sRUFDWixJQUFJLENBQUMsVUFBVSxDQUNoQixDQUFBO2dCQUNILENBQUM7Z0JBQ0QsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRTtvQkFDN0QsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixJQUFJLEVBQUU7d0JBQ0osS0FBSzt3QkFDTCxJQUFJO3dCQUNKLG9CQUFvQixFQUFFLEVBQUUsYUFBYSxFQUFFLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxZQUFZLEVBQUU7d0JBQzlELGNBQWMsRUFBRSxhQUFhO3dCQUM3QixxQkFBcUIsRUFBRSxtQkFBbUI7cUJBQzNDO29CQUNELFVBQVUsRUFBRSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsZUFBZTtpQkFDckMsQ0FBQyxDQUFBO2dCQUNGLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ1YsTUFBTSxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLGdCQUFnQixDQUFDLENBQUE7Z0JBQ3pFLENBQUM7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUMzRSxDQUFDO2lCQUFNLElBQUksT0FBTyxJQUFJLFdBQVcsRUFBRSxDQUFDO2dCQUNsQyxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsR0FBRyxXQUFXLENBQUE7Z0JBQzVDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFO29CQUNuRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLElBQUksRUFBRTt3QkFDSixLQUFLO3dCQUNMLElBQUk7d0JBQ0osb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFlBQVksRUFBRTtxQkFDL0Q7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztvQkFDeEIsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsVUFBVSxFQUFFO29CQUNoRSxLQUFLO2lCQUNOLENBQUMsQ0FBQTtZQUNKLENBQUM7WUFDRCxNQUFNLElBQUksMkJBQTJCLENBQ25DLDZEQUE2RCxDQUM5RCxDQUFBO1FBQ0gsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtZQUN2RSxJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNFLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9GRztJQUNILEtBQUssQ0FBQyxVQUFVO1FBQ2QsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUE7UUFFNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3RCLG9DQUFvQztZQUNwQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ2pFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7b0JBQ3ZDLE9BQU8sTUFBTSxDQUFBO2dCQUNmLENBQUMsQ0FBQyxDQUFBO1lBQ0osQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQzdDLE9BQU8sTUFBTSxDQUFBO1FBQ2YsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssS0FBSyxDQUFDLFlBQVksQ0FBSSxjQUFzQixFQUFFLEVBQW9CO1FBQ3hFLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQTtRQUVyRCxJQUFJLENBQUM7WUFDSCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdEIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNO29CQUNwQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ25ELENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUE7Z0JBRXJCLE1BQU0sTUFBTSxHQUFHLENBQUMsS0FBSyxJQUFJLEVBQUU7b0JBQ3pCLE1BQU0sSUFBSSxDQUFBO29CQUNWLE9BQU8sTUFBTSxFQUFFLEVBQUUsQ0FBQTtnQkFDbkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtnQkFFSixJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FDckIsQ0FBQyxLQUFLLElBQUksRUFBRTtvQkFDVixJQUFJLENBQUM7d0JBQ0gsTUFBTSxNQUFNLENBQUE7b0JBQ2QsQ0FBQztvQkFBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO3dCQUNaLDhCQUE4QjtvQkFDaEMsQ0FBQztnQkFDSCxDQUFDLENBQUMsRUFBRSxDQUNMLENBQUE7Z0JBRUQsT0FBTyxNQUFNLENBQUE7WUFDZixDQUFDO1lBRUQsT0FBTyxNQUFNLElBQUksQ0FBQyxJQUFLLENBQUMsUUFBUSxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsY0FBYyxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUM1RSxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSwrQkFBK0IsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7Z0JBRTlFLElBQUksQ0FBQztvQkFDSCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQTtvQkFFeEIsTUFBTSxNQUFNLEdBQUcsRUFBRSxFQUFFLENBQUE7b0JBRW5CLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUNyQixDQUFDLEtBQUssSUFBSSxFQUFFO3dCQUNWLElBQUksQ0FBQzs0QkFDSCxNQUFNLE1BQU0sQ0FBQTt3QkFDZCxDQUFDO3dCQUFDLE9BQU8sQ0FBTSxFQUFFLENBQUM7NEJBQ2hCLDhCQUE4Qjt3QkFDaEMsQ0FBQztvQkFDSCxDQUFDLENBQUMsRUFBRSxDQUNMLENBQUE7b0JBRUQsTUFBTSxNQUFNLENBQUE7b0JBRVosMkRBQTJEO29CQUMzRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUM7d0JBQ2pDLE1BQU0sTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7d0JBRXRDLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQTt3QkFFekIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQTtvQkFDN0MsQ0FBQztvQkFFRCxPQUFPLE1BQU0sTUFBTSxDQUFBO2dCQUNyQixDQUFDO3dCQUFTLENBQUM7b0JBQ1QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsK0JBQStCLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO29CQUU5RSxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQTtnQkFDM0IsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztnQkFBUyxDQUFDO1lBQ1QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDckMsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssS0FBSyxDQUFDLFdBQVcsQ0FDdkIsRUFvQmU7UUFFZixJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQTtRQUVwQyxJQUFJLENBQUM7WUFDSCxxRUFBcUU7WUFDckUsNkRBQTZEO1lBQzdELHdEQUF3RDtZQUN4RCxpRUFBaUU7WUFDakUsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUE7WUFFekMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUN6QixDQUFDO2dCQUFTLENBQUM7WUFDVCxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUNwQyxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxLQUFLLENBQUMsYUFBYTtRQW9CekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQTtRQUV4QyxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQzVDLDZEQUE2RDtZQUM3RCxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFFLG1DQUFtQyxFQUFFLElBQUksS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDekYsQ0FBQztRQUVELElBQUksQ0FBQztZQUNILElBQUksY0FBYyxHQUFtQixJQUFJLENBQUE7WUFFekMsTUFBTSxZQUFZLEdBQUcsTUFBTSxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7WUFFdEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsc0JBQXNCLEVBQUUsWUFBWSxDQUFDLENBQUE7WUFFbEUsSUFBSSxZQUFZLEtBQUssSUFBSSxFQUFFLENBQUM7Z0JBQzFCLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO29CQUN2QyxjQUFjLEdBQUcsWUFBWSxDQUFBO2dCQUMvQixDQUFDO3FCQUFNLENBQUM7b0JBQ04sSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsbUNBQW1DLENBQUMsQ0FBQTtvQkFDakUsTUFBTSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUE7Z0JBQzdCLENBQUM7WUFDSCxDQUFDO1lBRUQsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUNwQixPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtZQUNqRCxDQUFDO1lBRUQscUVBQXFFO1lBQ3JFLHVFQUF1RTtZQUN2RSwrREFBK0Q7WUFDL0QseUVBQXlFO1lBQ3pFLHNCQUFzQjtZQUN0QixNQUFNLFVBQVUsR0FBRyxjQUFjLENBQUMsVUFBVTtnQkFDMUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxnQkFBZ0I7Z0JBQ2xFLENBQUMsQ0FBQyxLQUFLLENBQUE7WUFFVCxJQUFJLENBQUMsTUFBTSxDQUNULGtCQUFrQixFQUNsQixjQUFjLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLFVBQVUsRUFDaEQsWUFBWSxFQUNaLGNBQWMsQ0FBQyxVQUFVLENBQzFCLENBQUE7WUFFRCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2hCLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUNyQixNQUFNLFNBQVMsR0FBa0MsQ0FBQyxNQUFNLFlBQVksQ0FDbEUsSUFBSSxDQUFDLFdBQVcsRUFDaEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQzFCLENBQVEsQ0FBQTtvQkFFVCxJQUFJLFNBQVMsYUFBVCxTQUFTLHVCQUFULFNBQVMsQ0FBRSxJQUFJLEVBQUUsQ0FBQzt3QkFDcEIsY0FBYyxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFBO29CQUN0QyxDQUFDO3lCQUFNLENBQUM7d0JBQ04sY0FBYyxDQUFDLElBQUksR0FBRyxxQkFBcUIsRUFBRSxDQUFBO29CQUMvQyxDQUFDO2dCQUNILENBQUM7Z0JBRUQsMERBQTBEO2dCQUMxRCxnR0FBZ0c7Z0JBQ2hHLElBQ0UsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRO29CQUNyQixjQUFjLENBQUMsSUFBSTtvQkFDbkIsQ0FBRSxjQUFjLENBQUMsSUFBWSxDQUFDLHlCQUF5QixFQUN2RCxDQUFDO29CQUNELE1BQU0sa0JBQWtCLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUE7b0JBQ3BFLGNBQWMsQ0FBQyxJQUFJLEdBQUcsd0JBQXdCLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxDQUFBO29CQUV2RixpRkFBaUY7b0JBQ2pGLElBQUksa0JBQWtCLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQzdCLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLENBQUE7b0JBQ3ZDLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtZQUMzRCxDQUFDO1lBRUQsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFBO1lBQzNGLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ1YsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDL0QsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQy9ELENBQUM7Z0JBQVMsQ0FBQztZQUNULElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDeEMsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BMkVHO0lBQ0gsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFZO1FBQ3hCLElBQUksR0FBRyxFQUFFLENBQUM7WUFDUixPQUFPLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUNqQyxDQUFDO1FBRUQsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUE7UUFFNUIsSUFBSSxNQUFvQixDQUFBO1FBQ3hCLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUN0QixvQ0FBb0M7WUFDcEMsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ25FLE9BQU8sTUFBTSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUE7WUFDOUIsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQTtRQUNoQyxDQUFDO1FBRUQsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLENBQUE7UUFDdkMsQ0FBQztRQUVELE9BQU8sTUFBTSxDQUFBO0lBQ2YsQ0FBQztJQUVPLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBWTtRQUNqQyxJQUFJLENBQUM7WUFDSCxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUNSLE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxPQUFPLEVBQUU7b0JBQzNELE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsR0FBRyxFQUFFLEdBQUc7b0JBQ1IsS0FBSyxFQUFFLGFBQWE7aUJBQ3JCLENBQUMsQ0FBQTtZQUNKLENBQUM7WUFFRCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7O2dCQUM3QyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sQ0FBQTtnQkFDOUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixNQUFNLEtBQUssQ0FBQTtnQkFDYixDQUFDO2dCQUVELDhFQUE4RTtnQkFDOUUsSUFBSSxDQUFDLENBQUEsTUFBQSxJQUFJLENBQUMsT0FBTywwQ0FBRSxZQUFZLENBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyw0QkFBNEIsRUFBRSxDQUFDO29CQUN0RSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLHVCQUF1QixFQUFFLEVBQUUsQ0FBQTtnQkFDdkUsQ0FBQztnQkFFRCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsT0FBTyxFQUFFO29CQUMzRCxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLEdBQUcsRUFBRSxNQUFBLE1BQUEsSUFBSSxDQUFDLE9BQU8sMENBQUUsWUFBWSxtQ0FBSSxTQUFTO29CQUM1QyxLQUFLLEVBQUUsYUFBYTtpQkFDckIsQ0FBQyxDQUFBO1lBQ0osQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLElBQUkseUJBQXlCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFDckMscUVBQXFFO29CQUNyRSw4REFBOEQ7b0JBRTlELE1BQU0sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFBO29CQUMzQixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtnQkFDekUsQ0FBQztnQkFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUM1RCxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWlIRztJQUNILEtBQUssQ0FBQyxVQUFVLENBQ2QsVUFBMEIsRUFDMUIsVUFFSSxFQUFFO1FBRU4sTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUE7UUFFNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3RCLG9DQUFvQztZQUNwQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ2pFLE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQTtZQUNwRCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUE7SUFDcEQsQ0FBQztJQUVTLEtBQUssQ0FBQyxXQUFXLENBQ3pCLFVBQTBCLEVBQzFCLFVBRUksRUFBRTtRQUVOLElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDN0MsTUFBTSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxHQUFHLE1BQU0sQ0FBQTtnQkFDekQsSUFBSSxZQUFZLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxZQUFZLENBQUE7Z0JBQ3BCLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDekIsTUFBTSxJQUFJLHVCQUF1QixFQUFFLENBQUE7Z0JBQ3JDLENBQUM7Z0JBQ0QsTUFBTSxPQUFPLEdBQVksV0FBVyxDQUFDLE9BQU8sQ0FBQTtnQkFDNUMsSUFBSSxhQUFhLEdBQWtCLElBQUksQ0FBQTtnQkFDdkMsSUFBSSxtQkFBbUIsR0FBa0IsSUFBSSxDQUFBO2dCQUM3QyxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssTUFBTSxJQUFJLFVBQVUsQ0FBQyxLQUFLLElBQUksSUFBSSxFQUFFLENBQUM7b0JBQ3pELENBQUM7b0JBQUEsQ0FBQyxhQUFhLEVBQUUsbUJBQW1CLENBQUMsR0FBRyxNQUFNLHlCQUF5QixDQUNyRSxJQUFJLENBQUMsT0FBTyxFQUNaLElBQUksQ0FBQyxVQUFVLENBQ2hCLENBQUE7Z0JBQ0gsQ0FBQztnQkFFRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLE9BQU8sRUFBRTtvQkFDdkYsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixVQUFVLEVBQUUsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLGVBQWU7b0JBQ3BDLElBQUksa0NBQ0MsVUFBVSxLQUNiLGNBQWMsRUFBRSxhQUFhLEVBQzdCLHFCQUFxQixFQUFFLG1CQUFtQixHQUMzQztvQkFDRCxHQUFHLEVBQUUsT0FBTyxDQUFDLFlBQVk7b0JBQ3pCLEtBQUssRUFBRSxhQUFhO2lCQUNyQixDQUFDLENBQUE7Z0JBQ0YsSUFBSSxTQUFTLEVBQUUsQ0FBQztvQkFDZCxNQUFNLFNBQVMsQ0FBQTtnQkFDakIsQ0FBQztnQkFDRCxPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFZLENBQUE7Z0JBQ2hDLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDaEMsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFBO2dCQUN6RCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1lBQzFFLENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtZQUN2RSxJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUM1RCxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0EySEc7SUFDSCxLQUFLLENBQUMsVUFBVSxDQUFDLGNBR2hCO1FBQ0MsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUE7UUFFNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3RCLG9DQUFvQztZQUNwQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ2pFLE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxDQUFBO1lBQy9DLENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxDQUFBO0lBQy9DLENBQUM7SUFFUyxLQUFLLENBQUMsV0FBVyxDQUFDLGNBRzNCO1FBQ0MsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ2xFLE1BQU0sSUFBSSx1QkFBdUIsRUFBRSxDQUFBO1lBQ3JDLENBQUM7WUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFBO1lBQ2pDLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQTtZQUN2QixJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUE7WUFDckIsSUFBSSxPQUFPLEdBQW1CLElBQUksQ0FBQTtZQUNsQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsU0FBUyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQTtZQUMxRCxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDaEIsU0FBUyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUE7Z0JBQ3ZCLFVBQVUsR0FBRyxTQUFTLElBQUksT0FBTyxDQUFBO1lBQ25DLENBQUM7WUFFRCxJQUFJLFVBQVUsRUFBRSxDQUFDO2dCQUNmLE1BQU0sRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQ3BFLGNBQWMsQ0FBQyxhQUFhLENBQzdCLENBQUE7Z0JBQ0QsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtnQkFDbEYsQ0FBQztnQkFFRCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztvQkFDdEIsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtnQkFDN0QsQ0FBQztnQkFDRCxPQUFPLEdBQUcsZ0JBQWdCLENBQUE7WUFDNUIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQTtnQkFDeEUsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO2dCQUMzRSxDQUFDO2dCQUNELE9BQU8sR0FBRztvQkFDUixZQUFZLEVBQUUsY0FBYyxDQUFDLFlBQVk7b0JBQ3pDLGFBQWEsRUFBRSxjQUFjLENBQUMsYUFBYTtvQkFDM0MsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO29CQUNmLFVBQVUsRUFBRSxRQUFRO29CQUNwQixVQUFVLEVBQUUsU0FBUyxHQUFHLE9BQU87b0JBQy9CLFVBQVUsRUFBRSxTQUFTO2lCQUN0QixDQUFBO2dCQUNELE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDaEMsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFBO1lBQ3hELENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtRQUNuRixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDM0UsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTRIRztJQUNILEtBQUssQ0FBQyxjQUFjLENBQUMsY0FBMEM7UUFDN0QsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUE7UUFFNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3RCLG9DQUFvQztZQUNwQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ2pFLE9BQU8sTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxDQUFBO1lBQ25ELENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE9BQU8sTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxDQUFBO0lBQ25ELENBQUM7SUFFUyxLQUFLLENBQUMsZUFBZSxDQUFDLGNBRS9CO1FBQ0MsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFOztnQkFDN0MsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUNwQixNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sQ0FBQTtvQkFDOUIsSUFBSSxLQUFLLEVBQUUsQ0FBQzt3QkFDVixNQUFNLEtBQUssQ0FBQTtvQkFDYixDQUFDO29CQUVELGNBQWMsR0FBRyxNQUFBLElBQUksQ0FBQyxPQUFPLG1DQUFJLFNBQVMsQ0FBQTtnQkFDNUMsQ0FBQztnQkFFRCxJQUFJLENBQUMsQ0FBQSxjQUFjLGFBQWQsY0FBYyx1QkFBZCxjQUFjLENBQUUsYUFBYSxDQUFBLEVBQUUsQ0FBQztvQkFDbkMsTUFBTSxJQUFJLHVCQUF1QixFQUFFLENBQUE7Z0JBQ3JDLENBQUM7Z0JBRUQsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFBO2dCQUMzRixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUNWLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO2dCQUNsRixDQUFDO2dCQUVELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDYixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtnQkFDakYsQ0FBQztnQkFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtZQUNuRixDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUMzRSxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLGtCQUFrQixDQUM5QixNQUF1QyxFQUN2QyxlQUF1Qjs7UUFRdkIsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFBRSxNQUFNLElBQUksOEJBQThCLENBQUMsc0JBQXNCLENBQUMsQ0FBQTtZQUVsRiwrRkFBK0Y7WUFDL0YsSUFBSSxNQUFNLENBQUMsS0FBSyxJQUFJLE1BQU0sQ0FBQyxpQkFBaUIsSUFBSSxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2xFLG9GQUFvRjtnQkFDcEYsK0RBQStEO2dCQUMvRCxNQUFNLElBQUksOEJBQThCLENBQ3RDLE1BQU0sQ0FBQyxpQkFBaUIsSUFBSSxpREFBaUQsRUFDN0U7b0JBQ0UsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLElBQUksbUJBQW1CO29CQUMxQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFVBQVUsSUFBSSxrQkFBa0I7aUJBQzlDLENBQ0YsQ0FBQTtZQUNILENBQUM7WUFFRCw4RkFBOEY7WUFDOUYsUUFBUSxlQUFlLEVBQUUsQ0FBQztnQkFDeEIsS0FBSyxVQUFVO29CQUNiLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxNQUFNLEVBQUUsQ0FBQzt3QkFDN0IsTUFBTSxJQUFJLDhCQUE4QixDQUFDLDRCQUE0QixDQUFDLENBQUE7b0JBQ3hFLENBQUM7b0JBQ0QsTUFBSztnQkFDUCxLQUFLLE1BQU07b0JBQ1QsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRSxDQUFDO3dCQUNqQyxNQUFNLElBQUksOEJBQThCLENBQUMsc0NBQXNDLENBQUMsQ0FBQTtvQkFDbEYsQ0FBQztvQkFDRCxNQUFLO2dCQUNQLFFBQVE7Z0JBQ1IscUNBQXFDO1lBQ3ZDLENBQUM7WUFFRCx3R0FBd0c7WUFDeEcsSUFBSSxlQUFlLEtBQUssTUFBTSxFQUFFLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQTtnQkFDNUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO29CQUFFLE1BQU0sSUFBSSw4QkFBOEIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO2dCQUMvRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sSUFBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQTtnQkFDdkUsSUFBSSxLQUFLO29CQUFFLE1BQU0sS0FBSyxDQUFBO2dCQUV0QixNQUFNLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFBO2dCQUN6QyxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQTtnQkFFL0IsTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFBO2dCQUVyRSxPQUFPO29CQUNMLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFBLElBQUksQ0FBQyxZQUFZLG1DQUFJLElBQUksRUFBRTtvQkFDeEUsS0FBSyxFQUFFLElBQUk7aUJBQ1osQ0FBQTtZQUNILENBQUM7WUFFRCxNQUFNLEVBQ0osY0FBYyxFQUNkLHNCQUFzQixFQUN0QixZQUFZLEVBQ1osYUFBYSxFQUNiLFVBQVUsRUFDVixVQUFVLEVBQ1YsVUFBVSxHQUNYLEdBQUcsTUFBTSxDQUFBO1lBRVYsSUFBSSxDQUFDLFlBQVksSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLGFBQWEsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNsRSxNQUFNLElBQUksOEJBQThCLENBQUMsMkJBQTJCLENBQUMsQ0FBQTtZQUN2RSxDQUFDO1lBRUQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUE7WUFDN0MsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQ3RDLElBQUksU0FBUyxHQUFHLE9BQU8sR0FBRyxTQUFTLENBQUE7WUFFbkMsSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDZixTQUFTLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQ2xDLENBQUM7WUFFRCxNQUFNLGlCQUFpQixHQUFHLFNBQVMsR0FBRyxPQUFPLENBQUE7WUFDN0MsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLElBQUksNkJBQTZCLEVBQUUsQ0FBQztnQkFDOUQsT0FBTyxDQUFDLElBQUksQ0FDVixpRUFBaUUsaUJBQWlCLGlDQUFpQyxTQUFTLEdBQUcsQ0FDaEksQ0FBQTtZQUNILENBQUM7WUFFRCxNQUFNLFFBQVEsR0FBRyxTQUFTLEdBQUcsU0FBUyxDQUFBO1lBQ3RDLElBQUksT0FBTyxHQUFHLFFBQVEsSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDOUIsT0FBTyxDQUFDLElBQUksQ0FDVixpR0FBaUcsRUFDakcsUUFBUSxFQUNSLFNBQVMsRUFDVCxPQUFPLENBQ1IsQ0FBQTtZQUNILENBQUM7aUJBQU0sSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUNsQyxPQUFPLENBQUMsSUFBSSxDQUNWLDhHQUE4RyxFQUM5RyxRQUFRLEVBQ1IsU0FBUyxFQUNULE9BQU8sQ0FDUixDQUFBO1lBQ0gsQ0FBQztZQUVELE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFBO1lBQ3pELElBQUksS0FBSztnQkFBRSxNQUFNLEtBQUssQ0FBQTtZQUV0QixNQUFNLE9BQU8sR0FBWTtnQkFDdkIsY0FBYztnQkFDZCxzQkFBc0I7Z0JBQ3RCLFlBQVk7Z0JBQ1osVUFBVSxFQUFFLFNBQVM7Z0JBQ3JCLFVBQVUsRUFBRSxTQUFTO2dCQUNyQixhQUFhO2dCQUNiLFVBQVUsRUFBRSxVQUFzQjtnQkFDbEMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2FBQ2hCLENBQUE7WUFFRCx5QkFBeUI7WUFDekIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFBO1lBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsdUJBQXVCLEVBQUUsK0JBQStCLENBQUMsQ0FBQTtZQUVyRSxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtRQUMxRixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbkYsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyx3QkFBd0IsQ0FBQyxNQUF1QztRQUN0RSxJQUFJLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQ2xELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUE7UUFDdkUsQ0FBQztRQUNELE9BQU8sT0FBTyxDQUNaLE1BQU0sQ0FBQyxZQUFZLElBQUksTUFBTSxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUMsaUJBQWlCLElBQUksTUFBTSxDQUFDLFVBQVUsQ0FDckYsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxlQUFlLENBQUMsTUFBdUM7UUFDbkUsTUFBTSxxQkFBcUIsR0FBRyxNQUFNLFlBQVksQ0FDOUMsSUFBSSxDQUFDLE9BQU8sRUFDWixHQUFHLElBQUksQ0FBQyxVQUFVLGdCQUFnQixDQUNuQyxDQUFBO1FBRUQsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLHFCQUFxQixDQUFDLENBQUE7SUFDakQsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bd0NHO0lBQ0gsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFtQixFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUU7UUFDbEQsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUE7UUFFNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3RCLG9DQUFvQztZQUNwQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ2pFLE9BQU8sTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQ3JDLENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE9BQU8sTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQ3JDLENBQUM7SUFFUyxLQUFLLENBQUMsUUFBUSxDQUN0QixFQUFFLEtBQUssS0FBYyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUU7UUFFeEMsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFOztZQUM3QyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsR0FBRyxNQUFNLENBQUE7WUFDNUMsSUFBSSxZQUFZLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO2dCQUM3RCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQTtZQUNwRCxDQUFDO1lBQ0QsTUFBTSxXQUFXLEdBQUcsTUFBQSxJQUFJLENBQUMsT0FBTywwQ0FBRSxZQUFZLENBQUE7WUFDOUMsSUFBSSxXQUFXLEVBQUUsQ0FBQztnQkFDaEIsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFBO2dCQUM5RCxJQUFJLEtBQUssRUFBRSxDQUFDO29CQUNWLGlEQUFpRDtvQkFDakQsa0ZBQWtGO29CQUNsRixJQUNFLENBQUMsQ0FDQyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7d0JBQ3BCLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQzt3QkFDekUseUJBQXlCLENBQUMsS0FBSyxDQUFDLENBQ2pDLEVBQ0QsQ0FBQzt3QkFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO29CQUN0QyxDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1lBQ0QsSUFBSSxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7Z0JBQ3ZCLE1BQU0sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFBO2dCQUMzQixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtZQUN6RSxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7UUFDNUMsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBK0JEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWdMRztJQUNILGlCQUFpQixDQUNmLFFBQW1GO1FBSW5GLE1BQU0sRUFBRSxHQUFvQixrQkFBa0IsRUFBRSxDQUFBO1FBQ2hELE1BQU0sWUFBWSxHQUFpQjtZQUNqQyxFQUFFO1lBQ0YsUUFBUTtZQUNSLFdBQVcsRUFBRSxHQUFHLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsdUNBQXVDLEVBQUUsRUFBRSxDQUFDLENBQUE7Z0JBRTFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUE7WUFDckMsQ0FBQztTQUNGLENBQUE7UUFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixFQUFFLDZCQUE2QixFQUFFLEVBQUUsQ0FBQyxDQUFBO1FBRXRFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUM3QztRQUFBLENBQUMsS0FBSyxJQUFJLEVBQUU7WUFDWCxNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FBQTtZQUU1QixJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQ3RCLG9DQUFvQztnQkFDcEMsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLElBQUksRUFBRTtvQkFDMUQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFBO2dCQUM5QixDQUFDLENBQUMsQ0FBQTtZQUNKLENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUNwQyxDQUFDO1FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtRQUVKLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxZQUFZLEVBQUUsRUFBRSxDQUFBO0lBQ25DLENBQUM7SUFFTyxLQUFLLENBQUMsbUJBQW1CLENBQUMsRUFBbUI7UUFDbkQsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFOztZQUM3QyxJQUFJLENBQUM7Z0JBQ0gsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUNqQixLQUFLLEdBQ04sR0FBRyxNQUFNLENBQUE7Z0JBQ1YsSUFBSSxLQUFLO29CQUFFLE1BQU0sS0FBSyxDQUFBO2dCQUV0QixNQUFNLENBQUEsTUFBQSxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQywwQ0FBRSxRQUFRLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUEsQ0FBQTtnQkFDNUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxhQUFhLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQTtZQUN2RSxDQUFDO1lBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztnQkFDYixNQUFNLENBQUEsTUFBQSxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQywwQ0FBRSxRQUFRLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLENBQUEsQ0FBQTtnQkFDekUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxhQUFhLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQTtnQkFDL0QsSUFBSSx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUNuQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2dCQUNuQixDQUFDO3FCQUFNLENBQUM7b0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFDcEIsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Ba0VHO0lBQ0gsS0FBSyxDQUFDLHFCQUFxQixDQUN6QixLQUFhLEVBQ2IsVUFHSSxFQUFFO1FBUU4sSUFBSSxhQUFhLEdBQWtCLElBQUksQ0FBQTtRQUN2QyxJQUFJLG1CQUFtQixHQUFrQixJQUFJLENBQUE7UUFFN0MsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQzdCLENBQUM7WUFBQSxDQUFDLGFBQWEsRUFBRSxtQkFBbUIsQ0FBQyxHQUFHLE1BQU0seUJBQXlCLENBQ3JFLElBQUksQ0FBQyxPQUFPLEVBQ1osSUFBSSxDQUFDLFVBQVUsRUFDZixJQUFJLENBQUMscUJBQXFCO2FBQzNCLENBQUE7UUFDSCxDQUFDO1FBQ0QsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLFVBQVUsRUFBRTtnQkFDL0QsSUFBSSxFQUFFO29CQUNKLEtBQUs7b0JBQ0wsY0FBYyxFQUFFLGFBQWE7b0JBQzdCLHFCQUFxQixFQUFFLG1CQUFtQjtvQkFDMUMsb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRTtpQkFDOUQ7Z0JBQ0QsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7YUFDL0IsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtZQUN2RSxJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbEQsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BdUNHO0lBQ0gsS0FBSyxDQUFDLGlCQUFpQjs7UUFTckIsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtZQUM1QyxJQUFJLEtBQUs7Z0JBQUUsTUFBTSxLQUFLLENBQUE7WUFDdEIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsVUFBVSxFQUFFLE1BQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLG1DQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQzlGLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBYUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BMEJHO0lBQ0gsS0FBSyxDQUFDLFlBQVksQ0FBQyxXQUFnQjtRQUNqQyxJQUFJLE9BQU8sSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUMzQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLENBQUMsQ0FBQTtRQUM5QyxDQUFDO1FBRUQsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUE7SUFDNUMsQ0FBQztJQUVPLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxXQUF1Qzs7UUFDckUsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFOztnQkFDOUQsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLENBQUE7Z0JBQzlCLElBQUksS0FBSztvQkFBRSxNQUFNLEtBQUssQ0FBQTtnQkFDdEIsTUFBTSxHQUFHLEdBQVcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQy9DLEdBQUcsSUFBSSxDQUFDLEdBQUcsNEJBQTRCLEVBQ3ZDLFdBQVcsQ0FBQyxRQUFRLEVBQ3BCO29CQUNFLFVBQVUsRUFBRSxNQUFBLFdBQVcsQ0FBQyxPQUFPLDBDQUFFLFVBQVU7b0JBQzNDLE1BQU0sRUFBRSxNQUFBLFdBQVcsQ0FBQyxPQUFPLDBDQUFFLE1BQU07b0JBQ25DLFdBQVcsRUFBRSxNQUFBLFdBQVcsQ0FBQyxPQUFPLDBDQUFFLFdBQVc7b0JBQzdDLG1CQUFtQixFQUFFLElBQUk7aUJBQzFCLENBQ0YsQ0FBQTtnQkFDRCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRTtvQkFDNUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsTUFBQSxNQUFBLElBQUksQ0FBQyxPQUFPLDBDQUFFLFlBQVksbUNBQUksU0FBUztpQkFDN0MsQ0FBQyxDQUFBO1lBQ0osQ0FBQyxDQUFDLENBQUE7WUFDRixJQUFJLEtBQUs7Z0JBQUUsTUFBTSxLQUFLLENBQUE7WUFDdEIsSUFBSSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUEsTUFBQSxXQUFXLENBQUMsT0FBTywwQ0FBRSxtQkFBbUIsQ0FBQSxFQUFFLENBQUM7Z0JBQzdELE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksYUFBSixJQUFJLHVCQUFKLElBQUksQ0FBRSxHQUFHLENBQUMsQ0FBQTtZQUNuQyxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUN4QixJQUFJLEVBQUUsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsSUFBSSxhQUFKLElBQUksdUJBQUosSUFBSSxDQUFFLEdBQUcsRUFBRTtnQkFDeEQsS0FBSyxFQUFFLElBQUk7YUFDWixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNGLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRU8sS0FBSyxDQUFDLG1CQUFtQixDQUMvQixXQUF5QztRQUV6QyxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7O1lBQzdDLElBQUksQ0FBQztnQkFDSCxNQUFNLEVBQ0osS0FBSyxFQUFFLFlBQVksRUFDbkIsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQ2xCLEdBQUcsTUFBTSxDQUFBO2dCQUNWLElBQUksWUFBWTtvQkFBRSxNQUFNLFlBQVksQ0FBQTtnQkFFcEMsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUE7Z0JBRXJFLE1BQU0sR0FBRyxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsNEJBQTRCLEVBQUU7b0JBQ3RGLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsR0FBRyxFQUFFLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFlBQVksbUNBQUksU0FBUztvQkFDdkMsSUFBSSxFQUFFO3dCQUNKLFFBQVE7d0JBQ1IsUUFBUSxFQUFFLEtBQUs7d0JBQ2YsWUFBWTt3QkFDWixLQUFLO3dCQUNMLGFBQWEsRUFBRSxJQUFJO3dCQUNuQixvQkFBb0IsRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsWUFBWSxFQUFFO3FCQUMvRDtvQkFDRCxLQUFLLEVBQUUsZ0JBQWdCO2lCQUN4QixDQUFDLENBQUE7Z0JBRUYsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxHQUFHLENBQUE7Z0JBQzNCLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ1YsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtnQkFDM0UsQ0FBQztxQkFBTSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDaEQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO3dCQUN4QixJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUU7d0JBQ25DLEtBQUssRUFBRSxJQUFJLDZCQUE2QixFQUFFO3FCQUMzQyxDQUFDLENBQUE7Z0JBQ0osQ0FBQztnQkFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtvQkFDckMsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDaEUsQ0FBQztnQkFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUM1QyxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtnQkFDdkUsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtnQkFDM0UsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQTtZQUNiLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bd0JHO0lBQ0gsS0FBSyxDQUFDLGNBQWMsQ0FBQyxRQUFzQjtRQU96QyxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7O2dCQUM3QyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sQ0FBQTtnQkFDOUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixNQUFNLEtBQUssQ0FBQTtnQkFDYixDQUFDO2dCQUNELE9BQU8sTUFBTSxRQUFRLENBQ25CLElBQUksQ0FBQyxLQUFLLEVBQ1YsUUFBUSxFQUNSLEdBQUcsSUFBSSxDQUFDLEdBQUcsb0JBQW9CLFFBQVEsQ0FBQyxXQUFXLEVBQUUsRUFDckQ7b0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsTUFBQSxNQUFBLElBQUksQ0FBQyxPQUFPLDBDQUFFLFlBQVksbUNBQUksU0FBUztpQkFDN0MsQ0FDRixDQUFBO1lBQ0gsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNLLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxZQUFvQjtRQUNwRCx1RUFBdUU7UUFDdkUscUVBQXFFO1FBQ3JFLDJEQUEyRDtRQUMzRCxNQUFNLFNBQVMsR0FBRyx3QkFBd0IsQ0FBQTtRQUMxQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQTtRQUUvQixJQUFJLENBQUM7WUFDSCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUE7WUFFNUIsNkRBQTZEO1lBQzdELE9BQU8sTUFBTSxTQUFTLENBQ3BCLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRTtnQkFDaEIsSUFBSSxPQUFPLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ2hCLE1BQU0sS0FBSyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQSxDQUFDLHFCQUFxQjtnQkFDbkUsQ0FBQztnQkFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxvQkFBb0IsRUFBRSxPQUFPLENBQUMsQ0FBQTtnQkFFckQsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLGlDQUFpQyxFQUFFO29CQUN0RixJQUFJLEVBQUUsRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFO29CQUNyQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLEtBQUssRUFBRSxnQkFBZ0I7aUJBQ3hCLENBQUMsQ0FBQTtZQUNKLENBQUMsRUFDRCxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDakIsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUE7Z0JBQ3RELE9BQU8sQ0FDTCxLQUFLO29CQUNMLHlCQUF5QixDQUFDLEtBQUssQ0FBQztvQkFDaEMsMkZBQTJGO29CQUMzRixJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsbUJBQW1CLEdBQUcsU0FBUyxHQUFHLDZCQUE2QixDQUM3RSxDQUFBO1lBQ0gsQ0FBQyxDQUNGLENBQUE7UUFDSCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQTtZQUV0QyxJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQzNFLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7Z0JBQVMsQ0FBQztZQUNULElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRU8sZUFBZSxDQUFDLFlBQXFCO1FBQzNDLE1BQU0sY0FBYyxHQUNsQixPQUFPLFlBQVksS0FBSyxRQUFRO1lBQ2hDLFlBQVksS0FBSyxJQUFJO1lBQ3JCLGNBQWMsSUFBSSxZQUFZO1lBQzlCLGVBQWUsSUFBSSxZQUFZO1lBQy9CLFlBQVksSUFBSSxZQUFZLENBQUE7UUFFOUIsT0FBTyxjQUFjLENBQUE7SUFDdkIsQ0FBQztJQUVPLEtBQUssQ0FBQyxxQkFBcUIsQ0FDakMsUUFBa0IsRUFDbEIsT0FLQztRQUVELE1BQU0sR0FBRyxHQUFXLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsWUFBWSxFQUFFLFFBQVEsRUFBRTtZQUNuRixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7WUFDOUIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO1lBQ3RCLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVztTQUNqQyxDQUFDLENBQUE7UUFFRixJQUFJLENBQUMsTUFBTSxDQUFDLDBCQUEwQixFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUE7UUFFN0YsNkJBQTZCO1FBQzdCLElBQUksU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUNoRCxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUM3QixDQUFDO1FBRUQsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7SUFDakQsQ0FBQztJQUVEOzs7T0FHRztJQUNLLEtBQUssQ0FBQyxrQkFBa0I7O1FBQzlCLE1BQU0sU0FBUyxHQUFHLHVCQUF1QixDQUFBO1FBQ3pDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFBO1FBRS9CLElBQUksQ0FBQztZQUNILE1BQU0sY0FBYyxHQUFHLENBQUMsTUFBTSxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQW1CLENBQUE7WUFFNUYsSUFBSSxjQUFjLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN2QyxJQUFJLFNBQVMsR0FBaUMsQ0FBQyxNQUFNLFlBQVksQ0FDL0QsSUFBSSxDQUFDLFdBQVcsRUFDaEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQzFCLENBQVEsQ0FBQTtnQkFFVCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLElBQUksTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUN0RixtRUFBbUU7b0JBQ25FLGlFQUFpRTtvQkFDakUsbUVBQW1FO29CQUNuRSw4QkFBOEI7b0JBRTlCLFNBQVMsR0FBRyxFQUFFLElBQUksRUFBRSxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUE7b0JBQ3pDLE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUE7Z0JBQzVFLENBQUM7Z0JBRUQsY0FBYyxDQUFDLElBQUksR0FBRyxNQUFBLFNBQVMsYUFBVCxTQUFTLHVCQUFULFNBQVMsQ0FBRSxJQUFJLG1DQUFJLHFCQUFxQixFQUFFLENBQUE7WUFDbEUsQ0FBQztpQkFBTSxJQUFJLGNBQWMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDbEQsdUVBQXVFO2dCQUN2RSw0Q0FBNEM7Z0JBRTVDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3pCLDJIQUEySDtvQkFDM0gsTUFBTSxZQUFZLEdBQWlDLENBQUMsTUFBTSxZQUFZLENBQ3BFLElBQUksQ0FBQyxPQUFPLEVBQ1osSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQzFCLENBQVEsQ0FBQTtvQkFFVCxJQUFJLFlBQVksS0FBSSxZQUFZLGFBQVosWUFBWSx1QkFBWixZQUFZLENBQUUsSUFBSSxDQUFBLEVBQUUsQ0FBQzt3QkFDdkMsY0FBYyxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFBO3dCQUV2QyxNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLENBQUE7d0JBQzlELE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQTtvQkFDbkUsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLGNBQWMsQ0FBQyxJQUFJLEdBQUcscUJBQXFCLEVBQUUsQ0FBQTtvQkFDL0MsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztZQUVELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLHNCQUFzQixFQUFFLGNBQWMsQ0FBQyxDQUFBO1lBRTlELElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLHNCQUFzQixDQUFDLENBQUE7Z0JBQzlDLElBQUksY0FBYyxLQUFLLElBQUksRUFBRSxDQUFDO29CQUM1QixNQUFNLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQTtnQkFDN0IsQ0FBQztnQkFFRCxPQUFNO1lBQ1IsQ0FBQztZQUVELE1BQU0saUJBQWlCLEdBQ3JCLENBQUMsTUFBQSxjQUFjLENBQUMsVUFBVSxtQ0FBSSxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLGdCQUFnQixDQUFBO1lBRWhGLElBQUksQ0FBQyxNQUFNLENBQ1QsU0FBUyxFQUNULGNBQWMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSwyQkFBMkIsZ0JBQWdCLEdBQUcsQ0FDNUYsQ0FBQTtZQUVELElBQUksaUJBQWlCLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLElBQUksY0FBYyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUMxRCxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFBO29CQUU1RSxJQUFJLEtBQUssRUFBRSxDQUFDO3dCQUNWLCtEQUErRDt3QkFDL0QsaUVBQWlFO3dCQUNqRSxvREFBb0Q7d0JBQ3BELElBQUksMkJBQTJCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQzs0QkFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUE7d0JBQ3BFLENBQUM7NkJBQU0sQ0FBQzs0QkFDTixJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQTs0QkFFL0MsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0NBQ3RDLElBQUksQ0FBQyxNQUFNLENBQ1QsU0FBUyxFQUNULGlFQUFpRSxFQUNqRSxLQUFLLENBQ04sQ0FBQTtnQ0FDRCxNQUFNLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQTs0QkFDN0IsQ0FBQzt3QkFDSCxDQUFDO29CQUNILENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7aUJBQU0sSUFDTCxjQUFjLENBQUMsSUFBSTtnQkFDbEIsY0FBYyxDQUFDLElBQVksQ0FBQyx5QkFBeUIsS0FBSyxJQUFJLEVBQy9ELENBQUM7Z0JBQ0QseURBQXlEO2dCQUN6RCxJQUFJLENBQUM7b0JBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQTtvQkFFbkYsSUFBSSxDQUFDLFNBQVMsS0FBSSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsSUFBSSxDQUFBLEVBQUUsQ0FBQzt3QkFDN0IsY0FBYyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFBO3dCQUMvQixNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUE7d0JBQ3ZDLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxjQUFjLENBQUMsQ0FBQTtvQkFDL0QsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLDBEQUEwRCxDQUFDLENBQUE7b0JBQ3BGLENBQUM7Z0JBQ0gsQ0FBQztnQkFBQyxPQUFPLFlBQVksRUFBRSxDQUFDO29CQUN0QixPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLFlBQVksQ0FBQyxDQUFBO29CQUN2RCxJQUFJLENBQUMsTUFBTSxDQUNULFNBQVMsRUFDVCwwREFBMEQsRUFDMUQsWUFBWSxDQUNiLENBQUE7Z0JBQ0gsQ0FBQztZQUNILENBQUM7aUJBQU0sQ0FBQztnQkFDTixxRUFBcUU7Z0JBQ3JFLG9FQUFvRTtnQkFDcEUsdURBQXVEO2dCQUN2RCxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDLENBQUE7WUFDL0QsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFBO1lBRXBDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7WUFDbEIsT0FBTTtRQUNSLENBQUM7Z0JBQVMsQ0FBQztZQUNULElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRU8sS0FBSyxDQUFDLGlCQUFpQixDQUFDLFlBQW9COztRQUNsRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDbEIsTUFBTSxJQUFJLHVCQUF1QixFQUFFLENBQUE7UUFDckMsQ0FBQztRQUVELG9DQUFvQztRQUNwQyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzVCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQTtRQUN4QyxDQUFDO1FBRUQsdUVBQXVFO1FBQ3ZFLHFFQUFxRTtRQUNyRSwyREFBMkQ7UUFDM0QsTUFBTSxTQUFTLEdBQUcsc0JBQXNCLENBQUE7UUFFeEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFFL0IsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksUUFBUSxFQUEwQixDQUFBO1lBRWhFLG1FQUFtRTtZQUNuRSx1RUFBdUU7WUFDdkUscUVBQXFFO1lBQ3JFLDBEQUEwRDtZQUMxRCwrREFBK0Q7WUFDL0QsbUVBQW1FO1lBQ25FLCtEQUErRDtZQUMvRCxnRUFBZ0U7WUFDaEUsZ0VBQWdFO1lBQ2hFLHFFQUFxRTtZQUNyRSxNQUFNLGFBQWEsR0FBRyxDQUFDLE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFtQixDQUFBO1lBRTNGLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxDQUFDLENBQUE7WUFDcEUsSUFBSSxLQUFLO2dCQUFFLE1BQU0sS0FBSyxDQUFBO1lBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTztnQkFBRSxNQUFNLElBQUksdUJBQXVCLEVBQUUsQ0FBQTtZQUV0RCxNQUFNLFdBQVcsR0FBRyxDQUFDLE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFtQixDQUFBO1lBQ3pGLE1BQU0scUJBQXFCLEdBQ3pCLGFBQWEsS0FBSyxJQUFJO2dCQUN0QixDQUFDLFdBQVcsS0FBSyxJQUFJLElBQUksV0FBVyxDQUFDLGFBQWEsS0FBSyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUE7WUFFckYsSUFBSSxxQkFBcUIsRUFBRSxDQUFDO2dCQUMxQixJQUFJLENBQUMsTUFBTSxDQUNULFNBQVMsRUFDVCxnRkFBZ0YsRUFDaEY7b0JBQ0UsZ0VBQWdFO29CQUNoRSwrREFBK0Q7b0JBQy9ELFdBQVcsRUFBRSxTQUFTO29CQUN0QixRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVM7aUJBQy9DLENBQ0YsQ0FBQTtnQkFDRCxNQUFNLFNBQVMsR0FBMkI7b0JBQ3hDLElBQUksRUFBRSxJQUFJO29CQUNWLEtBQUssRUFBRSxJQUFJLHlCQUF5QixFQUFFO2lCQUN2QyxDQUFBO2dCQUNELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUE7Z0JBQzFDLE9BQU8sU0FBUyxDQUFBO1lBQ2xCLENBQUM7WUFFRCxzRUFBc0U7WUFDdEUsbUVBQW1FO1lBQ25FLHdFQUF3RTtZQUN4RSx3RUFBd0U7WUFDeEUsc0VBQXNFO1lBQ3RFLHVFQUF1RTtZQUN2RSw4REFBOEQ7WUFDOUQsaUVBQWlFO1lBQ2pFLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQTtZQUVqRCxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBRXJDLElBQUksSUFBSSxDQUFDLG9CQUFvQixLQUFLLGVBQWUsRUFBRSxDQUFDO2dCQUNsRCxJQUFJLENBQUMsTUFBTSxDQUNULFNBQVMsRUFDVCxpRkFBaUYsQ0FDbEYsQ0FBQTtnQkFDRCxNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtnQkFDcEQsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQ3JCLE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsQ0FBQTtnQkFDcEUsQ0FBQztnQkFDRCxNQUFNLFNBQVMsR0FBMkI7b0JBQ3hDLElBQUksRUFBRSxJQUFJO29CQUNWLEtBQUssRUFBRSxJQUFJLHlCQUF5QixFQUFFO2lCQUN2QyxDQUFBO2dCQUNELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUE7Z0JBQzFDLE9BQU8sU0FBUyxDQUFBO1lBQ2xCLENBQUM7WUFFRCxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7WUFFakUsTUFBTSxNQUFNLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7WUFFbEQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQTtZQUV2QyxPQUFPLE1BQU0sQ0FBQTtRQUNmLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFBO1lBRXRDLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE1BQU0sTUFBTSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQTtnQkFFcEMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7b0JBQ3RDLE1BQU0sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFBO2dCQUM3QixDQUFDO2dCQUVELE1BQUEsSUFBSSxDQUFDLGtCQUFrQiwwQ0FBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7Z0JBRXhDLE9BQU8sTUFBTSxDQUFBO1lBQ2YsQ0FBQztZQUVELE1BQUEsSUFBSSxDQUFDLGtCQUFrQiwwQ0FBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUE7WUFDdEMsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO2dCQUFTLENBQUM7WUFDVCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFBO1lBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRU8sS0FBSyxDQUFDLHFCQUFxQixDQUNqQyxLQUFzQixFQUN0QixPQUF1QixFQUN2QixTQUFTLEdBQUcsSUFBSTtRQUVoQixNQUFNLFNBQVMsR0FBRywwQkFBMEIsS0FBSyxHQUFHLENBQUE7UUFDcEQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxlQUFlLFNBQVMsRUFBRSxDQUFDLENBQUE7UUFFcEUsSUFBSSxDQUFDO1lBQ0gsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQTtZQUN2RCxDQUFDO1lBRUQsTUFBTSxNQUFNLEdBQWMsRUFBRSxDQUFBO1lBQzVCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDN0UsSUFBSSxDQUFDO29CQUNILE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUE7Z0JBQ2xDLENBQUM7Z0JBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztvQkFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO2dCQUNoQixDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUE7WUFFRixNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7WUFFM0IsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUN0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7b0JBQzFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQzFCLENBQUM7Z0JBRUQsTUFBTSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDakIsQ0FBQztRQUNILENBQUM7Z0JBQVMsQ0FBQztZQUNULElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFnQjtRQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxDQUFBO1FBQ3ZDLHlFQUF5RTtRQUN6RSw0RUFBNEU7UUFDNUUsSUFBSSxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQTtRQUNyQyxNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQTtRQUN2RSwyR0FBMkc7UUFDM0csTUFBTSxnQkFBZ0IscUJBQVEsT0FBTyxDQUFFLENBQUE7UUFFdkMsTUFBTSxXQUFXLEdBQ2YsZ0JBQWdCLENBQUMsSUFBSSxJQUFLLGdCQUFnQixDQUFDLElBQVksQ0FBQyx5QkFBeUIsS0FBSyxJQUFJLENBQUE7UUFDNUYsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLFdBQVcsSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDMUMsc0RBQXNEO2dCQUN0RCxNQUFNLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxFQUFFO29CQUM5RCxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtpQkFDNUIsQ0FBQyxDQUFBO1lBQ0osQ0FBQztpQkFBTSxJQUFJLFdBQVcsRUFBRSxDQUFDO2dCQUN2QixpRUFBaUU7Z0JBQ2pFLGtHQUFrRztnQkFDbEcsdUVBQXVFO2dCQUN2RSwwRkFBMEY7WUFDNUYsQ0FBQztZQUVELDZGQUE2RjtZQUM3Rix5RUFBeUU7WUFDekUsTUFBTSxlQUFlLHFCQUFpRCxnQkFBZ0IsQ0FBRSxDQUFBO1lBQ3hGLE9BQU8sZUFBZSxDQUFDLElBQUksQ0FBQSxDQUFDLDhEQUE4RDtZQUUxRixNQUFNLHFCQUFxQixHQUFHLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQTtZQUN4RCxNQUFNLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUscUJBQXFCLENBQUMsQ0FBQTtRQUMxRSxDQUFDO2FBQU0sQ0FBQztZQUNOLGdDQUFnQztZQUNoQyw0REFBNEQ7WUFDNUQsa0dBQWtHO1lBQ2xHLE1BQU0sYUFBYSxHQUFHLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBLENBQUMsd0RBQXdEO1lBQzFHLE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQTtRQUNsRSxDQUFDO0lBQ0gsQ0FBQztJQUVPLEtBQUssQ0FBQyxjQUFjO1FBQzFCLHdFQUF3RTtRQUN4RSx3RUFBd0U7UUFDeEUsNERBQTREO1FBQzVELDZEQUE2RDtRQUM3RCxJQUFJLENBQUMsb0JBQW9CLElBQUksQ0FBQyxDQUFBO1FBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQTtRQUVoQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFBO1FBRXRDLE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1FBQ3BELE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFBO1FBQ3ZFLE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsQ0FBQTtRQUU5RCxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQixNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLENBQUE7UUFDcEUsQ0FBQztRQUVELE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQTtJQUN0RCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxnQ0FBZ0M7UUFDdEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFBO1FBRWxELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQTtRQUMvQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFBO1FBRXJDLElBQUksQ0FBQztZQUNILElBQUksUUFBUSxJQUFJLFNBQVMsRUFBRSxLQUFJLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxtQkFBbUIsQ0FBQSxFQUFFLENBQUM7Z0JBQzNELE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUMsQ0FBQTtZQUMxRCxDQUFDO1FBQ0gsQ0FBQztRQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDWCxPQUFPLENBQUMsS0FBSyxDQUFDLDJDQUEyQyxFQUFFLENBQUMsQ0FBQyxDQUFBO1FBQy9ELENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssS0FBSyxDQUFDLGlCQUFpQjtRQUM3QixNQUFNLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFBO1FBRTdCLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsQ0FBQTtRQUVuQyxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLEVBQUUsNkJBQTZCLENBQUMsQ0FBQTtRQUM3RixJQUFJLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFBO1FBRS9CLElBQUksTUFBTSxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsSUFBSSxPQUFPLE1BQU0sQ0FBQyxLQUFLLEtBQUssVUFBVSxFQUFFLENBQUM7WUFDL0UsK0RBQStEO1lBQy9ELGtEQUFrRDtZQUNsRCw2REFBNkQ7WUFDN0QsK0RBQStEO1lBQy9ELHFFQUFxRTtZQUNyRSxvQ0FBb0M7WUFDcEMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFBO1lBQ2QsNkNBQTZDO1FBQy9DLENBQUM7YUFBTSxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssVUFBVSxFQUFFLENBQUM7WUFDaEYsaURBQWlEO1lBQ2pELDBEQUEwRDtZQUMxRCw2Q0FBNkM7WUFDN0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUN6QixDQUFDO1FBRUQsMkVBQTJFO1FBQzNFLHlFQUF5RTtRQUN6RSxTQUFTO1FBQ1QsTUFBTSxPQUFPLEdBQUcsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ3BDLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFBO1lBQzVCLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUE7UUFDcEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO1FBQ0wsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE9BQU8sQ0FBQTtRQUVyQyxJQUFJLE9BQU8sSUFBSSxPQUFPLE9BQU8sS0FBSyxRQUFRLElBQUksT0FBTyxPQUFPLENBQUMsS0FBSyxLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQ2xGLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQTtZQUNmLDZDQUE2QztRQUMvQyxDQUFDO2FBQU0sSUFBSSxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQ2hGLDZDQUE2QztZQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBQzFCLENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssS0FBSyxDQUFDLGdCQUFnQjtRQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLENBQUE7UUFFbEMsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFBO1FBQ3JDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUE7UUFFN0IsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNYLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUN2QixDQUFDO1FBRUQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFBO1FBQzNDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUE7UUFFbEMsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNaLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUN2QixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BMkNHO0lBQ0gsS0FBSyxDQUFDLGdCQUFnQjtRQUNwQixJQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQTtRQUN2QyxNQUFNLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0lBQ2hDLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E2Qkc7SUFDSCxLQUFLLENBQUMsZUFBZTtRQUNuQixJQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQTtRQUN2QyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFBO0lBQy9CLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E2Qkc7SUFDSCxLQUFLLENBQUMsT0FBTzs7UUFDWCxJQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQTtRQUN2QyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFBO1FBQzdCLE1BQUEsSUFBSSxDQUFDLGdCQUFnQiwwQ0FBRSxLQUFLLEVBQUUsQ0FBQTtRQUM5QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFBO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtJQUNsQyxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMscUJBQXFCO1FBQ2pDLElBQUksQ0FBQyxNQUFNLENBQUMsMEJBQTBCLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFFaEQsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3RCLHVFQUF1RTtZQUN2RSxxRUFBcUU7WUFDckUscUVBQXFFO1lBQ3JFLDhDQUE4QztZQUM5QyxJQUFJLENBQUM7Z0JBQ0gsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBRSxLQUFLLElBQUksRUFBRTtvQkFDcEMsSUFBSSxDQUFDO3dCQUNILE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTt3QkFDdEIsSUFBSSxDQUFDOzRCQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTtnQ0FDN0MsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxHQUNsQixHQUFHLE1BQU0sQ0FBQTtnQ0FFVixJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQ0FDOUQsSUFBSSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxZQUFZLENBQUMsQ0FBQTtvQ0FDckQsT0FBTTtnQ0FDUixDQUFDO2dDQUVELE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQy9CLENBQUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLEdBQUcsNkJBQTZCLENBQ2xFLENBQUE7Z0NBRUQsSUFBSSxDQUFDLE1BQU0sQ0FDVCwwQkFBMEIsRUFDMUIsMkJBQTJCLGNBQWMsd0JBQXdCLDZCQUE2Qiw0QkFBNEIsMkJBQTJCLFFBQVEsQ0FDOUosQ0FBQTtnQ0FFRCxJQUFJLGNBQWMsSUFBSSwyQkFBMkIsRUFBRSxDQUFDO29DQUNsRCxNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUE7Z0NBQ3JELENBQUM7NEJBQ0gsQ0FBQyxDQUFDLENBQUE7d0JBQ0osQ0FBQzt3QkFBQyxPQUFPLENBQUMsRUFBRSxDQUFDOzRCQUNYLE9BQU8sQ0FBQyxLQUFLLENBQ1gsd0VBQXdFLEVBQ3hFLENBQUMsQ0FDRixDQUFBO3dCQUNILENBQUM7b0JBQ0gsQ0FBQzs0QkFBUyxDQUFDO3dCQUNULElBQUksQ0FBQyxNQUFNLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLENBQUE7b0JBQ2hELENBQUM7Z0JBQ0gsQ0FBQyxDQUFDLENBQUE7WUFDSixDQUFDO1lBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztnQkFDWCxJQUFJLENBQUMsWUFBWSx1QkFBdUIsRUFBRSxDQUFDO29CQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLDRDQUE0QyxDQUFDLENBQUE7Z0JBQzNELENBQUM7cUJBQU0sQ0FBQztvQkFDTixNQUFNLENBQUMsQ0FBQTtnQkFDVCxDQUFDO1lBQ0gsQ0FBQztZQUNELE9BQU07UUFDUixDQUFDO1FBRUQsNERBQTREO1FBQzVELHNFQUFzRTtRQUN0RSx1REFBdUQ7UUFDdkQsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEtBQUssSUFBSSxFQUFFLENBQUM7WUFDckMsSUFBSSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxxQ0FBcUMsQ0FBQyxDQUFBO1lBQzlFLE9BQU07UUFDUixDQUFDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFBO1lBRXRCLElBQUksQ0FBQztnQkFDSCxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO29CQUN0QyxNQUFNLEVBQ0osSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQ2xCLEdBQUcsTUFBTSxDQUFBO29CQUVWLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDO3dCQUM5RCxJQUFJLENBQUMsTUFBTSxDQUFDLDBCQUEwQixFQUFFLFlBQVksQ0FBQyxDQUFBO3dCQUNyRCxPQUFNO29CQUNSLENBQUM7b0JBRUQsMEVBQTBFO29CQUMxRSxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUMvQixDQUFDLE9BQU8sQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQyxHQUFHLDZCQUE2QixDQUNsRSxDQUFBO29CQUVELElBQUksQ0FBQyxNQUFNLENBQ1QsMEJBQTBCLEVBQzFCLDJCQUEyQixjQUFjLHdCQUF3Qiw2QkFBNkIsNEJBQTRCLDJCQUEyQixRQUFRLENBQzlKLENBQUE7b0JBRUQsSUFBSSxjQUFjLElBQUksMkJBQTJCLEVBQUUsQ0FBQzt3QkFDbEQsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFBO29CQUNyRCxDQUFDO2dCQUNILENBQUMsQ0FBQyxDQUFBO1lBQ0osQ0FBQztZQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ1gsT0FBTyxDQUFDLEtBQUssQ0FBQyx3RUFBd0UsRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUM1RixDQUFDO1FBQ0gsQ0FBQztnQkFBUyxDQUFDO1lBQ1QsSUFBSSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUNoRCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxLQUFLLENBQUMsdUJBQXVCO1FBQ25DLElBQUksQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQTtRQUV6QyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFBLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxnQkFBZ0IsQ0FBQSxFQUFFLENBQUM7WUFDOUMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDMUIsbUVBQW1FO2dCQUNuRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQTtZQUN6QixDQUFDO1lBRUQsT0FBTyxLQUFLLENBQUE7UUFDZCxDQUFDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssSUFBSSxFQUFFO2dCQUMxQyxJQUFJLENBQUM7b0JBQ0gsTUFBTSxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUE7Z0JBQ3hDLENBQUM7Z0JBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztvQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDLDRCQUE0QixFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQTtnQkFDM0QsQ0FBQztZQUNILENBQUMsQ0FBQTtZQUVELE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxnQkFBZ0IsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQTtZQUU1RSx3RUFBd0U7WUFDeEUsMEJBQTBCO1lBQzFCLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFBLENBQUMsZUFBZTtRQUN2RCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDakQsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxvQkFBNkI7UUFDOUQsTUFBTSxVQUFVLEdBQUcseUJBQXlCLG9CQUFvQixHQUFHLENBQUE7UUFDbkUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFBO1FBRXBFLElBQUksUUFBUSxDQUFDLGVBQWUsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUMzQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUMxQiw2RUFBNkU7Z0JBQzdFLGlDQUFpQztnQkFDakMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUE7WUFDMUIsQ0FBQztZQUVELElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2dCQUMxQiwyREFBMkQ7Z0JBQzNELHVFQUF1RTtnQkFDdkUsc0JBQXNCO2dCQUN0QixNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FBQTtnQkFFNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO29CQUN0QixvQ0FBb0M7b0JBQ3BDLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxJQUFJLEVBQUU7d0JBQzFELElBQUksUUFBUSxDQUFDLGVBQWUsS0FBSyxTQUFTLEVBQUUsQ0FBQzs0QkFDM0MsSUFBSSxDQUFDLE1BQU0sQ0FDVCxVQUFVLEVBQ1YsMEdBQTBHLENBQzNHLENBQUE7NEJBQ0QsT0FBTTt3QkFDUixDQUFDO3dCQUNELE1BQU0sSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUE7b0JBQ2pDLENBQUMsQ0FBQyxDQUFBO2dCQUNKLENBQUM7cUJBQU0sQ0FBQztvQkFDTixJQUFJLFFBQVEsQ0FBQyxlQUFlLEtBQUssU0FBUyxFQUFFLENBQUM7d0JBQzNDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLHlEQUF5RCxDQUFDLENBQUE7d0JBQ2xGLE9BQU07b0JBQ1IsQ0FBQztvQkFDRCxzQkFBc0I7b0JBQ3RCLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUE7Z0JBQ2pDLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQzthQUFNLElBQUksUUFBUSxDQUFDLGVBQWUsS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUNqRCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUMxQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQTtZQUN6QixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLEtBQUssQ0FBQyxrQkFBa0IsQ0FDOUIsR0FBVyxFQUNYLFFBQWtCLEVBQ2xCLE9BS0M7UUFFRCxNQUFNLFNBQVMsR0FBYSxDQUFDLFlBQVksa0JBQWtCLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ3hFLElBQUksT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFVBQVUsRUFBRSxDQUFDO1lBQ3hCLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ3pFLENBQUM7UUFDRCxJQUFJLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxNQUFNLEVBQUUsQ0FBQztZQUNwQixTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsa0JBQWtCLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUNoRSxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQzdCLE1BQU0sQ0FBQyxhQUFhLEVBQUUsbUJBQW1CLENBQUMsR0FBRyxNQUFNLHlCQUF5QixDQUMxRSxJQUFJLENBQUMsT0FBTyxFQUNaLElBQUksQ0FBQyxVQUFVLENBQ2hCLENBQUE7WUFFRCxNQUFNLFVBQVUsR0FBRyxJQUFJLGVBQWUsQ0FBQztnQkFDckMsY0FBYyxFQUFFLEdBQUcsa0JBQWtCLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3RELHFCQUFxQixFQUFFLEdBQUcsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsRUFBRTthQUNwRSxDQUFDLENBQUE7WUFDRixTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFBO1FBQ3ZDLENBQUM7UUFDRCxJQUFJLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxXQUFXLEVBQUUsQ0FBQztZQUN6QixNQUFNLEtBQUssR0FBRyxJQUFJLGVBQWUsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUE7WUFDdEQsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQTtRQUNsQyxDQUFDO1FBQ0QsSUFBSSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsbUJBQW1CLEVBQUUsQ0FBQztZQUNqQyxTQUFTLENBQUMsSUFBSSxDQUFDLHNCQUFzQixPQUFPLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFBO1FBQ3JFLENBQUM7UUFFRCxPQUFPLEdBQUcsR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQTtJQUN4QyxDQUFDO0lBRU8sS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUF5QjtRQUMvQyxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7O2dCQUM3QyxNQUFNLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLEdBQUcsTUFBTSxDQUFBO2dCQUN6RCxJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO2dCQUNoRSxDQUFDO2dCQUVELE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxZQUFZLE1BQU0sQ0FBQyxRQUFRLEVBQUUsRUFBRTtvQkFDcEYsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsTUFBQSxXQUFXLGFBQVgsV0FBVyx1QkFBWCxXQUFXLENBQUUsT0FBTywwQ0FBRSxZQUFZO2lCQUN4QyxDQUFDLENBQUE7WUFDSixDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBUU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUF1QjtRQUMzQyxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7O2dCQUM3QyxNQUFNLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLEdBQUcsTUFBTSxDQUFBO2dCQUN6RCxJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO2dCQUNoRSxDQUFDO2dCQUVELE1BQU0sSUFBSSxtQkFDUixhQUFhLEVBQUUsTUFBTSxDQUFDLFlBQVksRUFDbEMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxVQUFVLElBQzNCLENBQUMsTUFBTSxDQUFDLFVBQVUsS0FBSyxPQUFPO29CQUMvQixDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRTtvQkFDekIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEtBQUssTUFBTTt3QkFDNUIsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLEVBQUU7d0JBQzNCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FDVixDQUFBO2dCQUVELE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLFVBQVUsRUFBRTtvQkFDakYsSUFBSTtvQkFDSixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLEdBQUcsRUFBRSxNQUFBLFdBQVcsYUFBWCxXQUFXLHVCQUFYLFdBQVcsQ0FBRSxPQUFPLDBDQUFFLFlBQVk7aUJBQ3hDLENBQUMsQ0FBMEIsQ0FBQTtnQkFDNUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQ2xELENBQUM7Z0JBRUQsSUFBSSxNQUFNLENBQUMsVUFBVSxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLE1BQU0sS0FBSSxNQUFBLElBQUksYUFBSixJQUFJLHVCQUFKLElBQUksQ0FBRSxJQUFJLDBDQUFFLE9BQU8sQ0FBQSxFQUFFLENBQUM7b0JBQ2hGLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLDRCQUE0QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFBO2dCQUNyRSxDQUFDO2dCQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBVU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUF1QjtRQUMzQyxNQUFNLEdBQUcsR0FBRyxLQUFLLElBQW9DLEVBQUU7WUFDckQsSUFBSSxDQUFDO2dCQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTs7b0JBQzdDLE1BQU0sRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsR0FBRyxNQUFNLENBQUE7b0JBQ3pELElBQUksWUFBWSxFQUFFLENBQUM7d0JBQ2pCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUE7b0JBQ2hFLENBQUM7b0JBRUQsTUFBTSxJQUFJLG1CQWlCUixZQUFZLEVBQUUsTUFBTSxDQUFDLFdBQVcsSUFDN0IsQ0FBQyxVQUFVLElBQUksTUFBTTt3QkFDdEIsQ0FBQyxDQUFDOzRCQUNFLFFBQVEsa0NBQ0gsTUFBTSxDQUFDLFFBQVEsS0FDbEIsbUJBQW1CLEVBQ2pCLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLFFBQVE7b0NBQy9CLENBQUMsQ0FBQyxtQ0FBbUMsQ0FDakMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBNkMsQ0FDOUQ7b0NBQ0gsQ0FBQyxDQUFDLGtDQUFrQyxDQUNoQyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUErQyxDQUNoRSxHQUNSO3lCQUNGO3dCQUNILENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FDM0IsQ0FBQTtvQkFFRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sUUFBUSxDQUNwQyxJQUFJLENBQUMsS0FBSyxFQUNWLE1BQU0sRUFDTixHQUFHLElBQUksQ0FBQyxHQUFHLFlBQVksTUFBTSxDQUFDLFFBQVEsU0FBUyxFQUMvQzt3QkFDRSxJQUFJO3dCQUNKLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTzt3QkFDckIsR0FBRyxFQUFFLE1BQUEsV0FBVyxhQUFYLFdBQVcsdUJBQVgsV0FBVyxDQUFFLE9BQU8sMENBQUUsWUFBWTtxQkFDeEMsQ0FDRixDQUFBO29CQUNELElBQUksS0FBSyxFQUFFLENBQUM7d0JBQ1YsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO29CQUNsRCxDQUFDO29CQUVELE1BQU0sSUFBSSxDQUFDLFlBQVksaUJBQ3JCLFVBQVUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxJQUN4RCxJQUFJLEVBQ1AsQ0FBQTtvQkFDRixNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsQ0FBQTtvQkFFaEUsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQzVDLENBQUMsQ0FBQyxDQUFBO1lBQ0osQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO2dCQUNsRCxDQUFDO2dCQUNELE1BQU0sS0FBSyxDQUFBO1lBQ2IsQ0FBQztRQUNILENBQUMsQ0FBQTtRQUVELElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUN0QixvQ0FBb0M7WUFDcEMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsQ0FBQTtRQUN4RCxDQUFDO1FBQ0QsT0FBTyxHQUFHLEVBQUUsQ0FBQTtJQUNkLENBQUM7SUFjTyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQTBCO1FBQ2pELE1BQU0sR0FBRyxHQUFHLEtBQUssSUFBdUMsRUFBRTtZQUN4RCxJQUFJLENBQUM7Z0JBQ0gsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFOztvQkFDN0MsTUFBTSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxHQUFHLE1BQU0sQ0FBQTtvQkFDekQsSUFBSSxZQUFZLEVBQUUsQ0FBQzt3QkFDakIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQTtvQkFDaEUsQ0FBQztvQkFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUM5QixJQUFJLENBQUMsS0FBSyxFQUNWLE1BQU0sRUFDTixHQUFHLElBQUksQ0FBQyxHQUFHLFlBQVksTUFBTSxDQUFDLFFBQVEsWUFBWSxFQUNsRDt3QkFDRSxJQUFJLEVBQUUsTUFBTTt3QkFDWixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87d0JBQ3JCLEdBQUcsRUFBRSxNQUFBLFdBQVcsYUFBWCxXQUFXLHVCQUFYLFdBQVcsQ0FBRSxPQUFPLDBDQUFFLFlBQVk7cUJBQ3hDLENBQ0YsQ0FHeUMsQ0FBQTtvQkFFMUMsSUFBSSxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQ25CLE9BQU8sUUFBUSxDQUFBO29CQUNqQixDQUFDO29CQUVELE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxRQUFRLENBQUE7b0JBRXpCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxVQUFVLEVBQUUsQ0FBQzt3QkFDN0IsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7b0JBQzlCLENBQUM7b0JBRUQsUUFBUSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUMzQixLQUFLLFFBQVE7NEJBQ1gsT0FBTztnQ0FDTCxJQUFJLGtDQUNDLElBQUksS0FDUCxRQUFRLGtDQUNILElBQUksQ0FBQyxRQUFRLEtBQ2hCLGtCQUFrQixrQ0FDYixJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixLQUNuQyxTQUFTLEVBQUUsb0NBQW9DLENBQzdDLElBQUksQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUMzQyxTQUdOO2dDQUNELEtBQUssRUFBRSxJQUFJOzZCQUNaLENBQUE7d0JBQ0gsS0FBSyxTQUFTOzRCQUNaLE9BQU87Z0NBQ0wsSUFBSSxrQ0FDQyxJQUFJLEtBQ1AsUUFBUSxrQ0FDSCxJQUFJLENBQUMsUUFBUSxLQUNoQixrQkFBa0Isa0NBQ2IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsS0FDbkMsU0FBUyxFQUFFLG1DQUFtQyxDQUM1QyxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FDM0MsU0FHTjtnQ0FDRCxLQUFLLEVBQUUsSUFBSTs2QkFDWixDQUFBO29CQUNMLENBQUM7Z0JBQ0gsQ0FBQyxDQUFDLENBQUE7WUFDSixDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO29CQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQ2xELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUE7WUFDYixDQUFDO1FBQ0gsQ0FBQyxDQUFBO1FBRUQsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3RCLG9DQUFvQztZQUNwQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxDQUFBO1FBQ3hELENBQUM7UUFDRCxPQUFPLEdBQUcsRUFBRSxDQUFBO0lBQ2QsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLG1CQUFtQixDQUMvQixNQUFtQztRQUVuQyxNQUFNLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQzNFLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtTQUMxQixDQUFDLENBQUE7UUFDRixJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQUE7UUFDbEUsQ0FBQztRQUVELE9BQU8sTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDO1lBQ3hCLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixXQUFXLEVBQUUsYUFBYSxDQUFDLEVBQUU7WUFDN0IsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO1NBQ2xCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxZQUFZOztRQUN4QixNQUFNLEVBQ0osSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQ2QsS0FBSyxFQUFFLFNBQVMsR0FDakIsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtRQUN4QixJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2QsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFBO1FBQ3pDLENBQUM7UUFFRCxNQUFNLElBQUksR0FBdUM7WUFDL0MsR0FBRyxFQUFFLEVBQUU7WUFDUCxLQUFLLEVBQUUsRUFBRTtZQUNULElBQUksRUFBRSxFQUFFO1lBQ1IsUUFBUSxFQUFFLEVBQUU7U0FDYixDQUFBO1FBRUQsNkJBQTZCO1FBQzdCLEtBQUssTUFBTSxNQUFNLElBQUksTUFBQSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsT0FBTyxtQ0FBSSxFQUFFLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtZQUNyQixJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUFFLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQXVCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1lBQy9ELENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTztZQUNMLElBQUk7WUFDSixLQUFLLEVBQUUsSUFBSTtTQUNaLENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsK0JBQStCLENBQzNDLEdBQVk7O1FBRVosSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNSLElBQUksQ0FBQztnQkFDSCxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFBO2dCQUVsQyxJQUFJLFlBQVksR0FBd0MsSUFBSSxDQUFBO2dCQUM1RCxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsWUFBWSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUE7Z0JBQzVCLENBQUM7Z0JBRUQsSUFBSSxTQUFTLEdBQXdDLFlBQVksQ0FBQTtnQkFFakUsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxFQUNkLEtBQUssRUFBRSxTQUFTLEdBQ2pCLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFBO2dCQUUzQixJQUFJLFNBQVMsRUFBRSxDQUFDO29CQUNkLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUE7Z0JBQzdELENBQUM7Z0JBRUQsTUFBTSxlQUFlLEdBQ25CLE1BQUEsTUFBQSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsT0FBTywwQ0FBRSxNQUFNLENBQUMsQ0FBQyxNQUFjLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssVUFBVSxDQUFDLG1DQUFJLEVBQUUsQ0FBQTtnQkFFL0UsSUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUMvQixTQUFTLEdBQUcsTUFBTSxDQUFBO2dCQUNwQixDQUFDO2dCQUVELE1BQU0sNEJBQTRCLEdBQUcsT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUE7Z0JBRXRELE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLDRCQUE0QixFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO1lBQ3pGLENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7b0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtnQkFDbEQsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQTtZQUNiLENBQUM7UUFDSCxDQUFDO1FBRUQsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUNqQixLQUFLLEVBQUUsWUFBWSxHQUNwQixHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO1FBRTNCLElBQUksWUFBWSxFQUFFLENBQUM7WUFDakIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQTtRQUNoRSxDQUFDO1FBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsT0FBTztnQkFDTCxJQUFJLEVBQUUsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsNEJBQTRCLEVBQUUsRUFBRSxFQUFFO2dCQUMvRSxLQUFLLEVBQUUsSUFBSTthQUNaLENBQUE7UUFDSCxDQUFDO1FBRUQsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUE7UUFFbkQsSUFBSSxZQUFZLEdBQXdDLElBQUksQ0FBQTtRQUU1RCxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNoQixZQUFZLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQTtRQUM1QixDQUFDO1FBRUQsSUFBSSxTQUFTLEdBQXdDLFlBQVksQ0FBQTtRQUVqRSxNQUFNLGVBQWUsR0FDbkIsTUFBQSxNQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTywwQ0FBRSxNQUFNLENBQUMsQ0FBQyxNQUFjLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssVUFBVSxDQUFDLG1DQUFJLEVBQUUsQ0FBQTtRQUV0RixJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDL0IsU0FBUyxHQUFHLE1BQU0sQ0FBQTtRQUNwQixDQUFDO1FBRUQsTUFBTSw0QkFBNEIsR0FBRyxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQTtRQUV0RCxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSw0QkFBNEIsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtJQUN6RixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNLLEtBQUssQ0FBQyx3QkFBd0IsQ0FDcEMsZUFBdUI7UUFFdkIsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUM3QyxNQUFNLEVBQ0osSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQ2pCLEtBQUssRUFBRSxZQUFZLEdBQ3BCLEdBQUcsTUFBTSxDQUFBO2dCQUVWLElBQUksWUFBWSxFQUFFLENBQUM7b0JBQ2pCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUE7Z0JBQ2hFLENBQUM7Z0JBRUQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNiLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksdUJBQXVCLEVBQUUsRUFBRSxDQUFDLENBQUE7Z0JBQ2pGLENBQUM7Z0JBRUQsT0FBTyxNQUFNLFFBQVEsQ0FDbkIsSUFBSSxDQUFDLEtBQUssRUFDVixLQUFLLEVBQ0wsR0FBRyxJQUFJLENBQUMsR0FBRyx5QkFBeUIsZUFBZSxFQUFFLEVBQ3JEO29CQUNFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsR0FBRyxFQUFFLE9BQU8sQ0FBQyxZQUFZO29CQUN6QixLQUFLLEVBQUUsQ0FBQyxJQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDO2lCQUM5QyxDQUNGLENBQUE7WUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFFRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssS0FBSyxDQUFDLHFCQUFxQixDQUNqQyxlQUF1QixFQUN2QixPQUEyQztRQUUzQyxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQzdDLE1BQU0sRUFDSixJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFDakIsS0FBSyxFQUFFLFlBQVksR0FDcEIsR0FBRyxNQUFNLENBQUE7Z0JBRVYsSUFBSSxZQUFZLEVBQUUsQ0FBQztvQkFDakIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQTtnQkFDaEUsQ0FBQztnQkFFRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ2IsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSx1QkFBdUIsRUFBRSxFQUFFLENBQUMsQ0FBQTtnQkFDakYsQ0FBQztnQkFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLFFBQVEsQ0FDN0IsSUFBSSxDQUFDLEtBQUssRUFDVixNQUFNLEVBQ04sR0FBRyxJQUFJLENBQUMsR0FBRyx5QkFBeUIsZUFBZSxVQUFVLEVBQzdEO29CQUNFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsR0FBRyxFQUFFLE9BQU8sQ0FBQyxZQUFZO29CQUN6QixJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFO29CQUMzQixLQUFLLEVBQUUsQ0FBQyxJQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDO2lCQUM5QyxDQUNGLENBQUE7Z0JBRUQsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7b0JBQ2hELHVFQUF1RTtvQkFDdkUsSUFBSSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLG1CQUFtQixDQUFBLEVBQUUsQ0FBQzt3QkFDakQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQTtvQkFDcEQsQ0FBQztnQkFDSCxDQUFDO2dCQUVELE9BQU8sUUFBUSxDQUFBO1lBQ2pCLENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbEQsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSyxLQUFLLENBQUMsa0JBQWtCLENBQzlCLGVBQXVCLEVBQ3ZCLE9BQTJDO1FBRTNDLElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDN0MsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUNqQixLQUFLLEVBQUUsWUFBWSxHQUNwQixHQUFHLE1BQU0sQ0FBQTtnQkFFVixJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO2dCQUNoRSxDQUFDO2dCQUVELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDYixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFBO2dCQUNqRixDQUFDO2dCQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sUUFBUSxDQUM3QixJQUFJLENBQUMsS0FBSyxFQUNWLE1BQU0sRUFDTixHQUFHLElBQUksQ0FBQyxHQUFHLHlCQUF5QixlQUFlLFVBQVUsRUFDN0Q7b0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsT0FBTyxDQUFDLFlBQVk7b0JBQ3pCLElBQUksRUFBRSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7b0JBQ3hCLEtBQUssRUFBRSxDQUFDLElBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUM7aUJBQzlDLENBQ0YsQ0FBQTtnQkFFRCxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztvQkFDaEQsdUVBQXVFO29CQUN2RSxJQUFJLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsbUJBQW1CLENBQUEsRUFBRSxDQUFDO3dCQUNqRCxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO29CQUNwRCxDQUFDO2dCQUNILENBQUM7Z0JBRUQsT0FBTyxRQUFRLENBQUE7WUFDakIsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNLLEtBQUssQ0FBQyxnQkFBZ0I7UUFDNUIsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUM3QyxNQUFNLEVBQ0osSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQ2pCLEtBQUssRUFBRSxZQUFZLEdBQ3BCLEdBQUcsTUFBTSxDQUFBO2dCQUVWLElBQUksWUFBWSxFQUFFLENBQUM7b0JBQ2pCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUE7Z0JBQ2hFLENBQUM7Z0JBRUQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNiLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksdUJBQXVCLEVBQUUsRUFBRSxDQUFDLENBQUE7Z0JBQ2pGLENBQUM7Z0JBRUQsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLG9CQUFvQixFQUFFO29CQUN4RSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLEdBQUcsRUFBRSxPQUFPLENBQUMsWUFBWTtvQkFDekIsS0FBSyxFQUFFLENBQUMsSUFBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQztpQkFDOUMsQ0FBQyxDQUFBO1lBQ0osQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNLLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxPQUUvQjtRQUNDLElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDN0MsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUNqQixLQUFLLEVBQUUsWUFBWSxHQUNwQixHQUFHLE1BQU0sQ0FBQTtnQkFFVixJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO2dCQUNoRSxDQUFDO2dCQUVELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDYixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFBO2dCQUNqRixDQUFDO2dCQUVELE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsb0JBQW9CLEVBQUU7b0JBQ3BFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsR0FBRyxFQUFFLE9BQU8sQ0FBQyxZQUFZO29CQUN6QixLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLFFBQVEsRUFBRTtvQkFDdEMsYUFBYSxFQUFFLElBQUk7aUJBQ3BCLENBQUMsQ0FBQTtnQkFDRixPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7WUFDbEMsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVPLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBVyxFQUFFLE9BQXdCLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRTtRQUN0RSxzQ0FBc0M7UUFDdEMsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUE7UUFDbEQsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNSLE9BQU8sR0FBRyxDQUFBO1FBQ1osQ0FBQztRQUVELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUV0QiwwQkFBMEI7UUFDMUIsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQTtRQUVuRCxrQ0FBa0M7UUFDbEMsSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFDaEQsT0FBTyxHQUFHLENBQUE7UUFDWixDQUFDO1FBQ0QsaUZBQWlGO1FBQ2pGLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyx3QkFBd0IsRUFBRTtZQUM3RixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87U0FDdEIsQ0FBQyxDQUFBO1FBQ0YsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNWLE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3pDLE9BQU8sSUFBSSxDQUFBO1FBQ2IsQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO1FBQ2hCLElBQUksQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFBO1FBRXpCLHVCQUF1QjtRQUN2QixHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFRLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUE7UUFDbkQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ1QsT0FBTyxJQUFJLENBQUE7UUFDYixDQUFDO1FBQ0QsT0FBTyxHQUFHLENBQUE7SUFDWixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FnRUc7SUFDSCxLQUFLLENBQUMsU0FBUyxDQUNiLEdBQVksRUFDWixVQVdJLEVBQUU7UUFTTixJQUFJLENBQUM7WUFDSCxJQUFJLEtBQUssR0FBRyxHQUFHLENBQUE7WUFDZixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ1gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQTtnQkFDL0MsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQzNCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtnQkFDbEQsQ0FBQztnQkFDRCxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUE7WUFDbkMsQ0FBQztZQUVELE1BQU0sRUFDSixNQUFNLEVBQ04sT0FBTyxFQUNQLFNBQVMsRUFDVCxHQUFHLEVBQUUsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsR0FDaEQsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUE7WUFFcEIsSUFBSSxDQUFDLENBQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFlBQVksQ0FBQSxFQUFFLENBQUM7Z0JBQzNCLHFFQUFxRTtnQkFDckUsb0ZBQW9GO2dCQUNwRixJQUFJLENBQUM7b0JBQ0gsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFDMUIsQ0FBQztnQkFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO29CQUNYLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyxDQUFDLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO2dCQUN6RixDQUFDO1lBQ0gsQ0FBQztZQUVELE1BQU0sVUFBVSxHQUNkLENBQUMsTUFBTSxDQUFDLEdBQUc7Z0JBQ1gsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO2dCQUMzQixDQUFDLE1BQU0sQ0FBQyxHQUFHO2dCQUNYLENBQUMsQ0FBQyxRQUFRLElBQUksVUFBVSxJQUFJLFFBQVEsSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDO2dCQUN4RCxDQUFDLENBQUMsSUFBSTtnQkFDTixDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxJQUFJLENBQUMsQ0FBQTtZQUU3RixnRkFBZ0Y7WUFDaEYsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNoQixNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO2dCQUMzQyxJQUFJLEtBQUssRUFBRSxDQUFDO29CQUNWLE1BQU0sS0FBSyxDQUFBO2dCQUNiLENBQUM7Z0JBQ0QsMkRBQTJEO2dCQUMzRCxPQUFPO29CQUNMLElBQUksRUFBRTt3QkFDSixNQUFNLEVBQUUsT0FBTzt3QkFDZixNQUFNO3dCQUNOLFNBQVM7cUJBQ1Y7b0JBQ0QsS0FBSyxFQUFFLElBQUk7aUJBQ1osQ0FBQTtZQUNILENBQUM7WUFFRCxNQUFNLFNBQVMsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBRTFDLDJCQUEyQjtZQUMzQixNQUFNLFNBQVMsR0FBRyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRTtnQkFDbEYsUUFBUTthQUNULENBQUMsQ0FBQTtZQUVGLHVCQUF1QjtZQUN2QixNQUFNLE9BQU8sR0FBRyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUN4QyxTQUFTLEVBQ1QsU0FBUyxFQUNULFNBQVMsRUFDVCxrQkFBa0IsQ0FBQyxHQUFHLFNBQVMsSUFBSSxVQUFVLEVBQUUsQ0FBQyxDQUNqRCxDQUFBO1lBRUQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNiLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO1lBQ3hELENBQUM7WUFFRCxxREFBcUQ7WUFDckQsT0FBTztnQkFDTCxJQUFJLEVBQUU7b0JBQ0osTUFBTSxFQUFFLE9BQU87b0JBQ2YsTUFBTTtvQkFDTixTQUFTO2lCQUNWO2dCQUNELEtBQUssRUFBRSxJQUFJO2FBQ1osQ0FBQTtRQUNILENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQsMEJBQTBCO0lBRTFCOzs7Ozs7Ozs7T0FTRztJQUNILEtBQUssQ0FBQyxpQkFBaUIsQ0FDckIsV0FBMEM7O1FBRTFDLGdDQUFnQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQTtRQUNuRCxJQUFJLENBQUM7WUFDSCxJQUFJLENBQUMsdUJBQXVCLEVBQUUsRUFBRSxDQUFDO2dCQUMvQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQ3hCLElBQUksRUFBRSxJQUFJO29CQUNWLEtBQUssRUFBRSxJQUFJLGdCQUFnQixDQUFDLG1DQUFtQyxFQUFFLElBQUksQ0FBQztpQkFDdkUsQ0FBQyxDQUFBO1lBQ0osQ0FBQztZQUVELHVDQUF1QztZQUN2QyxNQUFNLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsMkJBQTJCLENBQUM7Z0JBQ3BGLE9BQU8sRUFBRSxFQUFFLFlBQVksRUFBRSxNQUFBLFdBQVcsYUFBWCxXQUFXLHVCQUFYLFdBQVcsQ0FBRSxPQUFPLDBDQUFFLFlBQVksRUFBRTthQUM5RCxDQUFDLENBQUE7WUFDRixJQUFJLFlBQVksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUM3QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO1lBQ2hFLENBQUM7WUFFRCwwREFBMEQ7WUFDMUQsTUFBTSxnQkFBZ0IsR0FBRyxtQ0FBbUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDN0UsTUFBTSxNQUFNLEdBQUcsTUFBQSxNQUFBLFdBQVcsYUFBWCxXQUFXLHVCQUFYLFdBQVcsQ0FBRSxPQUFPLDBDQUFFLE1BQU0sbUNBQUksb0JBQW9CLENBQUMsb0JBQW9CLEVBQUUsQ0FBQTtZQUMxRixNQUFNLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLEdBQUcsTUFBTSxhQUFhLENBQUM7Z0JBQ3ZFLFNBQVMsRUFBRSxnQkFBZ0I7Z0JBQzNCLE1BQU07YUFDUCxDQUFDLENBQUE7WUFDRixJQUFJLGVBQWUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNuQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQ3hCLElBQUksRUFBRSxJQUFJO29CQUNWLEtBQUssRUFBRSxlQUFlLGFBQWYsZUFBZSxjQUFmLGVBQWUsR0FBSSxJQUFJLGdCQUFnQixDQUFDLDBCQUEwQixFQUFFLElBQUksQ0FBQztpQkFDakYsQ0FBQyxDQUFBO1lBQ0osQ0FBQztZQUVELHNDQUFzQztZQUN0QyxNQUFNLFVBQVUsR0FBRyxrQ0FBa0MsQ0FBQyxVQUFVLENBQUMsQ0FBQTtZQUNqRSxPQUFPLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztnQkFDdkMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxZQUFZO2dCQUNqQyxVQUFVLEVBQUUsVUFBVTthQUN2QixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILEtBQUssQ0FBQyxlQUFlLENBQ25CLFdBQXdDOztRQUV4QyxnQ0FBZ0MsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7UUFDbkQsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLHVCQUF1QixFQUFFLEVBQUUsQ0FBQztnQkFDL0IsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUN4QixJQUFJLEVBQUUsSUFBSTtvQkFDVixLQUFLLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxtQ0FBbUMsRUFBRSxJQUFJLENBQUM7aUJBQ3ZFLENBQUMsQ0FBQTtZQUNKLENBQUM7WUFFRCx1Q0FBdUM7WUFDdkMsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxHQUFHLE1BQU0sSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUE7WUFDckYsSUFBSSxZQUFZLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDN0IsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQTtZQUNoRSxDQUFDO1lBRUQsMERBQTBEO1lBQzFELE1BQU0sZ0JBQWdCLEdBQUcsb0NBQW9DLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQzlFLE1BQU0sTUFBTSxHQUFHLE1BQUEsTUFBQSxXQUFXLGFBQVgsV0FBVyx1QkFBWCxXQUFXLENBQUUsT0FBTywwQ0FBRSxNQUFNLG1DQUFJLG9CQUFvQixDQUFDLG9CQUFvQixFQUFFLENBQUE7WUFDMUYsTUFBTSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLGVBQWUsRUFBRSxHQUFHLE1BQU0sZ0JBQWdCLENBQUM7Z0JBQzFFLFNBQVMsRUFBRSxnQkFBZ0I7Z0JBQzNCLE1BQU07YUFDUCxDQUFDLENBQUE7WUFDRixJQUFJLGVBQWUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNuQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQ3hCLElBQUksRUFBRSxJQUFJO29CQUNWLEtBQUssRUFBRSxlQUFlLGFBQWYsZUFBZSxjQUFmLGVBQWUsR0FBSSxJQUFJLGdCQUFnQixDQUFDLDBCQUEwQixFQUFFLElBQUksQ0FBQztpQkFDakYsQ0FBQyxDQUFBO1lBQ0osQ0FBQztZQUVELHNDQUFzQztZQUN0QyxNQUFNLFVBQVUsR0FBRyxtQ0FBbUMsQ0FBQyxVQUFVLENBQUMsQ0FBQTtZQUNsRSxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDckMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxZQUFZO2dCQUNqQyxVQUFVLEVBQUUsVUFBVTthQUN2QixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNLLEtBQUssQ0FBQyx5QkFBeUI7UUFDckMsZ0NBQWdDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBQ25ELElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDN0MsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUNqQixLQUFLLEVBQUUsWUFBWSxHQUNwQixHQUFHLE1BQU0sQ0FBQTtnQkFDVixJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO2dCQUNoRSxDQUFDO2dCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDYixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFBO2dCQUNqRixDQUFDO2dCQUNELE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxRQUFRLENBQ3BDLElBQUksQ0FBQyxLQUFLLEVBQ1YsTUFBTSxFQUNOLEdBQUcsSUFBSSxDQUFDLEdBQUcsZ0NBQWdDLEVBQzNDO29CQUNFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsR0FBRyxFQUFFLE9BQU8sQ0FBQyxZQUFZO29CQUN6QixJQUFJLEVBQUUsRUFBRTtpQkFDVCxDQUNGLENBQUE7Z0JBQ0QsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQ2xELENBQUM7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbEQsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSyxLQUFLLENBQUMsMEJBQTBCLENBQ3RDLE1BQXVDO1FBRXZDLGdDQUFnQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQTtRQUNuRCxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQzdDLE1BQU0sRUFDSixJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFDakIsS0FBSyxFQUFFLFlBQVksR0FDcEIsR0FBRyxNQUFNLENBQUE7Z0JBQ1YsSUFBSSxZQUFZLEVBQUUsQ0FBQztvQkFDakIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQTtnQkFDaEUsQ0FBQztnQkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ2IsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSx1QkFBdUIsRUFBRSxFQUFFLENBQUMsQ0FBQTtnQkFDakYsQ0FBQztnQkFDRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sUUFBUSxDQUNwQyxJQUFJLENBQUMsS0FBSyxFQUNWLE1BQU0sRUFDTixHQUFHLElBQUksQ0FBQyxHQUFHLCtCQUErQixFQUMxQztvQkFDRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLEdBQUcsRUFBRSxPQUFPLENBQUMsWUFBWTtvQkFDekIsSUFBSSxFQUFFO3dCQUNKLFlBQVksRUFBRSxNQUFNLENBQUMsV0FBVzt3QkFDaEMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO3FCQUM5QjtpQkFDRixDQUNGLENBQUE7Z0JBQ0QsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQ2xELENBQUM7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbEQsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSyxLQUFLLENBQUMsMkJBQTJCLENBQ3ZDLE1BQXlDOztRQUV6QyxnQ0FBZ0MsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7UUFDbkQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FDcEMsSUFBSSxDQUFDLEtBQUssRUFDVixNQUFNLEVBQ04sR0FBRyxJQUFJLENBQUMsR0FBRyxrQ0FBa0MsRUFDN0M7Z0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixJQUFJLEVBQUU7b0JBQ0osb0JBQW9CLEVBQUUsRUFBRSxhQUFhLEVBQUUsTUFBQSxNQUFNLGFBQU4sTUFBTSx1QkFBTixNQUFNLENBQUUsT0FBTywwQ0FBRSxZQUFZLEVBQUU7aUJBQ3ZFO2FBQ0YsQ0FDRixDQUFBO1lBQ0QsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbEQsQ0FBQztZQUNELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtRQUNsRCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNLLEtBQUssQ0FBQyw0QkFBNEIsQ0FDeEMsTUFBeUM7UUFFekMsZ0NBQWdDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBQ25ELElBQUksQ0FBQztZQUNILE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxRQUFRLENBQ3BDLElBQUksQ0FBQyxLQUFLLEVBQ1YsTUFBTSxFQUNOLEdBQUcsSUFBSSxDQUFDLEdBQUcsaUNBQWlDLEVBQzVDO2dCQUNFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsSUFBSSxFQUFFO29CQUNKLFlBQVksRUFBRSxNQUFNLENBQUMsV0FBVztvQkFDaEMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO2lCQUM5QjtnQkFDRCxLQUFLLEVBQUUsZ0JBQWdCO2FBQ3hCLENBQ0YsQ0FBQTtZQUNELElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ1YsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDakIsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDckMsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUM3RCxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ2xELENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsYUFBYTtRQUN6QixnQ0FBZ0MsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7UUFDbkQsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUM3QyxNQUFNLEVBQ0osSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQ2pCLEtBQUssRUFBRSxZQUFZLEdBQ3BCLEdBQUcsTUFBTSxDQUFBO2dCQUNWLElBQUksWUFBWSxFQUFFLENBQUM7b0JBQ2pCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUE7Z0JBQ2hFLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNiLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksdUJBQXVCLEVBQUUsRUFBRSxDQUFDLENBQUE7Z0JBQ2pGLENBQUM7Z0JBQ0QsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLFdBQVcsRUFBRTtvQkFDaEYsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsT0FBTyxDQUFDLFlBQVk7b0JBQ3pCLEtBQUssRUFBRSxDQUFDLElBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUM7aUJBQzlDLENBQUMsQ0FBQTtnQkFDRixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUNWLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtnQkFDbEQsQ0FBQztnQkFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7WUFDbEQsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUEyQjtRQUN0RCxnQ0FBZ0MsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7UUFDbkQsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUM3QyxNQUFNLEVBQ0osSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQ2pCLEtBQUssRUFBRSxZQUFZLEdBQ3BCLEdBQUcsTUFBTSxDQUFBO2dCQUNWLElBQUksWUFBWSxFQUFFLENBQUM7b0JBQ2pCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUE7Z0JBQ2hFLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNiLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksdUJBQXVCLEVBQUUsRUFBRSxDQUFDLENBQUE7Z0JBQ2pGLENBQUM7Z0JBQ0QsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FDcEMsSUFBSSxDQUFDLEtBQUssRUFDVixPQUFPLEVBQ1AsR0FBRyxJQUFJLENBQUMsR0FBRyxhQUFhLE1BQU0sQ0FBQyxTQUFTLEVBQUUsRUFDMUM7b0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsT0FBTyxDQUFDLFlBQVk7b0JBQ3pCLElBQUksRUFBRSxFQUFFLGFBQWEsRUFBRSxNQUFNLENBQUMsWUFBWSxFQUFFO2lCQUM3QyxDQUNGLENBQUE7Z0JBQ0QsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQ2xELENBQUM7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDbEQsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBMkI7UUFDdEQsZ0NBQWdDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBQ25ELElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDN0MsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUNqQixLQUFLLEVBQUUsWUFBWSxHQUNwQixHQUFHLE1BQU0sQ0FBQTtnQkFDVixJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO2dCQUNoRSxDQUFDO2dCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDYixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFBO2dCQUNqRixDQUFDO2dCQUNELE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FDOUIsSUFBSSxDQUFDLEtBQUssRUFDVixRQUFRLEVBQ1IsR0FBRyxJQUFJLENBQUMsR0FBRyxhQUFhLE1BQU0sQ0FBQyxTQUFTLEVBQUUsRUFDMUM7b0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixHQUFHLEVBQUUsT0FBTyxDQUFDLFlBQVk7b0JBQ3pCLGFBQWEsRUFBRSxJQUFJO2lCQUNwQixDQUNGLENBQUE7Z0JBQ0QsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDVixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQ2xELENBQUM7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtZQUN4RCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDOztBQXh5TWMsMkJBQWMsR0FBMkIsRUFBRSxBQUE3QixDQUE2QjtlQUR2QyxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEdvVHJ1ZUFkbWluQXBpIGZyb20gJy4vR29UcnVlQWRtaW5BcGknXG5pbXBvcnQge1xuICBBVVRPX1JFRlJFU0hfVElDS19EVVJBVElPTl9NUyxcbiAgQVVUT19SRUZSRVNIX1RJQ0tfVEhSRVNIT0xELFxuICBERUZBVUxUX0hFQURFUlMsXG4gIEVYUElSWV9NQVJHSU5fTVMsXG4gIEdPVFJVRV9VUkwsXG4gIEpXS1NfVFRMLFxuICBTVE9SQUdFX0tFWSxcbn0gZnJvbSAnLi9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHtcbiAgQXV0aEVycm9yLFxuICBBdXRoSW1wbGljaXRHcmFudFJlZGlyZWN0RXJyb3IsXG4gIEF1dGhJbnZhbGlkQ3JlZGVudGlhbHNFcnJvcixcbiAgQXV0aEludmFsaWRKd3RFcnJvcixcbiAgQXV0aEludmFsaWRUb2tlblJlc3BvbnNlRXJyb3IsXG4gIEF1dGhQS0NFQ29kZVZlcmlmaWVyTWlzc2luZ0Vycm9yLFxuICBBdXRoUEtDRUdyYW50Q29kZUV4Y2hhbmdlRXJyb3IsXG4gIEF1dGhSZWZyZXNoRGlzY2FyZGVkRXJyb3IsXG4gIEF1dGhTZXNzaW9uTWlzc2luZ0Vycm9yLFxuICBBdXRoVW5rbm93bkVycm9yLFxuICBpc0F1dGhBcGlFcnJvcixcbiAgaXNBdXRoRXJyb3IsXG4gIGlzQXV0aEltcGxpY2l0R3JhbnRSZWRpcmVjdEVycm9yLFxuICBpc0F1dGhSZWZyZXNoRGlzY2FyZGVkRXJyb3IsXG4gIGlzQXV0aFJldHJ5YWJsZUZldGNoRXJyb3IsXG4gIGlzQXV0aFNlc3Npb25NaXNzaW5nRXJyb3IsXG59IGZyb20gJy4vbGliL2Vycm9ycydcbmltcG9ydCB7XG4gIEZldGNoLFxuICBfcmVxdWVzdCxcbiAgX3Nlc3Npb25SZXNwb25zZSxcbiAgX3Nlc3Npb25SZXNwb25zZVBhc3N3b3JkLFxuICBfc3NvUmVzcG9uc2UsXG4gIF91c2VyUmVzcG9uc2UsXG59IGZyb20gJy4vbGliL2ZldGNoJ1xuaW1wb3J0IHtcbiAgYXNzZXJ0UGFzc2tleUV4cGVyaW1lbnRhbEVuYWJsZWQsXG4gIGRlY29kZUpXVCxcbiAgZGVlcENsb25lLFxuICBEZWZlcnJlZCxcbiAgZ2VuZXJhdGVDYWxsYmFja0lkLFxuICBnZXRBbGdvcml0aG0sXG4gIGdldENvZGVDaGFsbGVuZ2VBbmRNZXRob2QsXG4gIGdldEl0ZW1Bc3luYyxcbiAgaW5zZWN1cmVVc2VyV2FybmluZ1Byb3h5LFxuICBpc0Jyb3dzZXIsXG4gIHBhcnNlUGFyYW1ldGVyc0Zyb21VUkwsXG4gIHJlbW92ZUl0ZW1Bc3luYyxcbiAgcmVzb2x2ZUZldGNoLFxuICByZXRyeWFibGUsXG4gIHNldEl0ZW1Bc3luYyxcbiAgc2xlZXAsXG4gIHN1cHBvcnRzTG9jYWxTdG9yYWdlLFxuICB1c2VyTm90QXZhaWxhYmxlUHJveHksXG4gIHZhbGlkYXRlRXhwLFxufSBmcm9tICcuL2xpYi9oZWxwZXJzJ1xuaW1wb3J0IHsgbWVtb3J5TG9jYWxTdG9yYWdlQWRhcHRlciB9IGZyb20gJy4vbGliL2xvY2FsLXN0b3JhZ2UnXG5pbXBvcnQgeyBMb2NrQWNxdWlyZVRpbWVvdXRFcnJvciwgbmF2aWdhdG9yTG9jayB9IGZyb20gJy4vbGliL2xvY2tzJ1xuaW1wb3J0IHsgcG9seWZpbGxHbG9iYWxUaGlzIH0gZnJvbSAnLi9saWIvcG9seWZpbGxzJ1xuaW1wb3J0IHsgdmVyc2lvbiB9IGZyb20gJy4vbGliL3ZlcnNpb24nXG5cbmltcG9ydCB7IGJ5dGVzVG9CYXNlNjRVUkwsIHN0cmluZ1RvVWludDhBcnJheSB9IGZyb20gJy4vbGliL2Jhc2U2NHVybCdcbmltcG9ydCB0eXBlIHtcbiAgQXV0aENoYW5nZUV2ZW50LFxuICBBdXRoZW50aWNhdG9yQXNzdXJhbmNlTGV2ZWxzLFxuICBBdXRoRmxvd1R5cGUsXG4gIEF1dGhNRkFDaGFsbGVuZ2VQaG9uZVJlc3BvbnNlLFxuICBBdXRoTUZBQ2hhbGxlbmdlUmVzcG9uc2UsXG4gIEF1dGhNRkFDaGFsbGVuZ2VUT1RQUmVzcG9uc2UsXG4gIEF1dGhNRkFDaGFsbGVuZ2VXZWJhdXRoblJlc3BvbnNlLFxuICBBdXRoTUZBQ2hhbGxlbmdlV2ViYXV0aG5TZXJ2ZXJSZXNwb25zZSxcbiAgQXV0aE1GQUVucm9sbFBob25lUmVzcG9uc2UsXG4gIEF1dGhNRkFFbnJvbGxSZXNwb25zZSxcbiAgQXV0aE1GQUVucm9sbFRPVFBSZXNwb25zZSxcbiAgQXV0aE1GQUVucm9sbFdlYmF1dGhuUmVzcG9uc2UsXG4gIEF1dGhNRkFHZXRBdXRoZW50aWNhdG9yQXNzdXJhbmNlTGV2ZWxSZXNwb25zZSxcbiAgQXV0aE1GQUxpc3RGYWN0b3JzUmVzcG9uc2UsXG4gIEF1dGhNRkFVbmVucm9sbFJlc3BvbnNlLFxuICBBdXRoTUZBVmVyaWZ5UmVzcG9uc2UsXG4gIEF1dGhPdHBSZXNwb25zZSxcbiAgQXV0aFJlc3BvbnNlLFxuICBBdXRoUmVzcG9uc2VQYXNzd29yZCxcbiAgQXV0aFRva2VuUmVzcG9uc2UsXG4gIEF1dGhUb2tlblJlc3BvbnNlUGFzc3dvcmQsXG4gIENhbGxSZWZyZXNoVG9rZW5SZXN1bHQsXG4gIEV0aGVyZXVtV2FsbGV0LFxuICBFdGhlcmV1bVdlYjNDcmVkZW50aWFscyxcbiAgRmFjdG9yLFxuICBHb1RydWVDbGllbnRPcHRpb25zLFxuICBHb1RydWVNRkFBcGksXG4gIEluaXRpYWxpemVSZXN1bHQsXG4gIEpXSyxcbiAgSnd0SGVhZGVyLFxuICBKd3RQYXlsb2FkLFxuICBMb2NrRnVuYyxcbiAgTUZBQ2hhbGxlbmdlQW5kVmVyaWZ5UGFyYW1zLFxuICBNRkFDaGFsbGVuZ2VQYXJhbXMsXG4gIE1GQUNoYWxsZW5nZVBob25lUGFyYW1zLFxuICBNRkFDaGFsbGVuZ2VUT1RQUGFyYW1zLFxuICBNRkFDaGFsbGVuZ2VXZWJhdXRoblBhcmFtcyxcbiAgTUZBRW5yb2xsUGFyYW1zLFxuICBNRkFFbnJvbGxQaG9uZVBhcmFtcyxcbiAgTUZBRW5yb2xsVE9UUFBhcmFtcyxcbiAgTUZBRW5yb2xsV2ViYXV0aG5QYXJhbXMsXG4gIE1GQVVuZW5yb2xsUGFyYW1zLFxuICBNRkFWZXJpZnlQYXJhbXMsXG4gIE1GQVZlcmlmeVBob25lUGFyYW1zLFxuICBNRkFWZXJpZnlUT1RQUGFyYW1zLFxuICBNRkFWZXJpZnlXZWJhdXRoblBhcmFtRmllbGRzLFxuICBNRkFWZXJpZnlXZWJhdXRoblBhcmFtcyxcbiAgT0F1dGhSZXNwb25zZSxcbiAgQXV0aE9BdXRoU2VydmVyQXBpLFxuICBBdXRoT0F1dGhBdXRob3JpemF0aW9uRGV0YWlsc1Jlc3BvbnNlLFxuICBBdXRoT0F1dGhDb25zZW50UmVzcG9uc2UsXG4gIEF1dGhPQXV0aEdyYW50c1Jlc3BvbnNlLFxuICBBdXRoT0F1dGhSZXZva2VHcmFudFJlc3BvbnNlLFxuICBQcmV0dGlmeSxcbiAgUHJvdmlkZXIsXG4gIFJlc2VuZFBhcmFtcyxcbiAgU2Vzc2lvbixcbiAgU2lnbkluQW5vbnltb3VzbHlDcmVkZW50aWFscyxcbiAgU2lnbkluV2l0aElkVG9rZW5DcmVkZW50aWFscyxcbiAgU2lnbkluV2l0aE9BdXRoQ3JlZGVudGlhbHMsXG4gIFNpZ25JbldpdGhQYXNzd29yZENyZWRlbnRpYWxzLFxuICBTaWduSW5XaXRoUGFzc3dvcmRsZXNzQ3JlZGVudGlhbHMsXG4gIFNpZ25JbldpdGhTU08sXG4gIFNpZ25PdXQsXG4gIFNpZ25VcFdpdGhQYXNzd29yZENyZWRlbnRpYWxzLFxuICBTb2xhbmFXYWxsZXQsXG4gIFNvbGFuYVdlYjNDcmVkZW50aWFscyxcbiAgU1NPUmVzcG9uc2UsXG4gIFN0cmljdE9taXQsXG4gIFN1YnNjcmlwdGlvbixcbiAgU3VwcG9ydGVkU3RvcmFnZSxcbiAgVXNlcixcbiAgVXNlckF0dHJpYnV0ZXMsXG4gIFVzZXJJZGVudGl0eSxcbiAgVXNlclJlc3BvbnNlLFxuICBWZXJpZnlPdHBQYXJhbXMsXG4gIFdlYjNDcmVkZW50aWFscyxcbiAgQXV0aFBhc3NrZXlBcGksXG4gIEV4cGVyaW1lbnRhbEZlYXR1cmVGbGFncyxcbiAgU2lnbkluV2l0aFBhc3NrZXlDcmVkZW50aWFscyxcbiAgUmVnaXN0ZXJQYXNza2V5Q3JlZGVudGlhbHMsXG4gIFZlcmlmeVBhc3NrZXlSZWdpc3RyYXRpb25QYXJhbXMsXG4gIFN0YXJ0UGFzc2tleUF1dGhlbnRpY2F0aW9uUGFyYW1zLFxuICBWZXJpZnlQYXNza2V5QXV0aGVudGljYXRpb25QYXJhbXMsXG4gIFBhc3NrZXlVcGRhdGVQYXJhbXMsXG4gIFBhc3NrZXlEZWxldGVQYXJhbXMsXG4gIEF1dGhQYXNza2V5UmVnaXN0cmF0aW9uT3B0aW9uc1Jlc3BvbnNlLFxuICBBdXRoUGFzc2tleVJlZ2lzdHJhdGlvblZlcmlmeVJlc3BvbnNlLFxuICBBdXRoUGFzc2tleUF1dGhlbnRpY2F0aW9uT3B0aW9uc1Jlc3BvbnNlLFxuICBBdXRoUGFzc2tleUF1dGhlbnRpY2F0aW9uVmVyaWZ5UmVzcG9uc2UsXG4gIEF1dGhQYXNza2V5TGlzdFJlc3BvbnNlLFxuICBBdXRoUGFzc2tleVVwZGF0ZVJlc3BvbnNlLFxuICBBdXRoUGFzc2tleURlbGV0ZVJlc3BvbnNlLFxufSBmcm9tICcuL2xpYi90eXBlcydcbmltcG9ydCB7XG4gIGNyZWF0ZVNpd2VNZXNzYWdlLFxuICBmcm9tSGV4LFxuICBnZXRBZGRyZXNzLFxuICBIZXgsXG4gIFNpd2VNZXNzYWdlLFxuICB0b0hleCxcbn0gZnJvbSAnLi9saWIvd2ViMy9ldGhlcmV1bSdcbmltcG9ydCB7XG4gIGNyZWF0ZUNyZWRlbnRpYWwsXG4gIGRlc2VyaWFsaXplQ3JlZGVudGlhbENyZWF0aW9uT3B0aW9ucyxcbiAgZGVzZXJpYWxpemVDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnMsXG4gIGdldENyZWRlbnRpYWwsXG4gIHNlcmlhbGl6ZUNyZWRlbnRpYWxDcmVhdGlvblJlc3BvbnNlLFxuICBzZXJpYWxpemVDcmVkZW50aWFsUmVxdWVzdFJlc3BvbnNlLFxuICBicm93c2VyU3VwcG9ydHNXZWJBdXRobixcbiAgd2ViQXV0aG5BYm9ydFNlcnZpY2UsXG4gIFdlYkF1dGhuQXBpLFxufSBmcm9tICcuL2xpYi93ZWJhdXRobidcbmltcG9ydCB7XG4gIEF1dGhlbnRpY2F0aW9uQ3JlZGVudGlhbCxcbiAgUHVibGljS2V5Q3JlZGVudGlhbEpTT04sXG4gIFJlZ2lzdHJhdGlvbkNyZWRlbnRpYWwsXG59IGZyb20gJy4vbGliL3dlYmF1dGhuLmRvbSdcblxucG9seWZpbGxHbG9iYWxUaGlzKCkgLy8gTWFrZSBcImdsb2JhbFRoaXNcIiBhdmFpbGFibGVcblxuY29uc3QgREVGQVVMVF9PUFRJT05TOiBPbWl0PFxuICBSZXF1aXJlZDxHb1RydWVDbGllbnRPcHRpb25zPixcbiAgJ2ZldGNoJyB8ICdzdG9yYWdlJyB8ICd1c2VyU3RvcmFnZScgfCAnbG9jaydcbj4gPSB7XG4gIHVybDogR09UUlVFX1VSTCxcbiAgc3RvcmFnZUtleTogU1RPUkFHRV9LRVksXG4gIGF1dG9SZWZyZXNoVG9rZW46IHRydWUsXG4gIHBlcnNpc3RTZXNzaW9uOiB0cnVlLFxuICBkZXRlY3RTZXNzaW9uSW5Vcmw6IHRydWUsXG4gIGhlYWRlcnM6IERFRkFVTFRfSEVBREVSUyxcbiAgZmxvd1R5cGU6ICdpbXBsaWNpdCcsXG4gIGRlYnVnOiBmYWxzZSxcbiAgaGFzQ3VzdG9tQXV0aG9yaXphdGlvbkhlYWRlcjogZmFsc2UsXG4gIHRocm93T25FcnJvcjogZmFsc2UsXG4gIGxvY2tBY3F1aXJlVGltZW91dDogNTAwMCwgLy8gNSBzZWNvbmRzLiBPbmx5IHVzZWQgd2hlbiBhIGN1c3RvbSBgbG9ja2AgaXMgc3VwcGxpZWQuIFRPRE8odjMpOiByZW1vdmUuXG4gIHNraXBBdXRvSW5pdGlhbGl6ZTogZmFsc2UsXG4gIGV4cGVyaW1lbnRhbDoge30sXG59XG5cbi8qKlxuICogTm8tb3AgbG9jayB1c2VkIGludGVybmFsbHkgYXMgYSBwbGFjZWhvbGRlci4gS2VwdCBzbyBvbGRlciB0ZXN0IHNldHVwcyB0aGF0XG4gKiBpbmplY3QgdGhpcyBleGFjdCByZWZlcmVuY2UgZG8gbm90IGJyZWFrOyBuZXcgY29kZSBuZXZlciBzZWVzIGl0IGJlY2F1c2VcbiAqIGB0aGlzLmxvY2tgIHN0YXlzIGBudWxsYCB3aGVuIG5vIGN1c3RvbSBsb2NrIGlzIHN1cHBsaWVkIChsb2NrbGVzcyBwYXRoKS5cbiAqIFRPRE8odjMpOiByZW1vdmUgd2l0aCB0aGUgbGVnYWN5IGxvY2sgcGF0aC5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gbG9ja05vT3A8Uj4obmFtZTogc3RyaW5nLCBhY3F1aXJlVGltZW91dDogbnVtYmVyLCBmbjogKCkgPT4gUHJvbWlzZTxSPik6IFByb21pc2U8Uj4ge1xuICByZXR1cm4gYXdhaXQgZm4oKVxufVxuXG4vKipcbiAqIENhY2hlcyBKV0tTIHZhbHVlcyBmb3IgYWxsIGNsaWVudHMgY3JlYXRlZCBpbiB0aGUgc2FtZSBlbnZpcm9ubWVudC4gVGhpcyBpc1xuICogZXNwZWNpYWxseSB1c2VmdWwgZm9yIHNoYXJlZC1tZW1vcnkgZXhlY3V0aW9uIGVudmlyb25tZW50cyBzdWNoIGFzIFZlcmNlbCdzXG4gKiBGbHVpZCBDb21wdXRlLCBBV1MgTGFtYmRhIG9yIFN1cGFiYXNlJ3MgRWRnZSBGdW5jdGlvbnMuIFJlZ2FyZGxlc3Mgb2YgaG93XG4gKiBtYW55IGNsaWVudHMgYXJlIGNyZWF0ZWQsIGlmIHRoZXkgc2hhcmUgdGhlIHNhbWUgc3RvcmFnZSBrZXkgdGhleSB3aWxsIHVzZVxuICogdGhlIHNhbWUgSldLUyBjYWNoZSwgc2lnbmlmaWNhbnRseSBzcGVlZGluZyB1cCBnZXRDbGFpbXMoKSB3aXRoIGFzeW1tZXRyaWNcbiAqIEpXVHMuXG4gKi9cbmNvbnN0IEdMT0JBTF9KV0tTOiB7IFtzdG9yYWdlS2V5OiBzdHJpbmddOiB7IGNhY2hlZEF0OiBudW1iZXI7IGp3a3M6IHsga2V5czogSldLW10gfSB9IH0gPSB7fVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHb1RydWVDbGllbnQge1xuICBwcml2YXRlIHN0YXRpYyBuZXh0SW5zdGFuY2VJRDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9XG5cbiAgcHJpdmF0ZSBpbnN0YW5jZUlEOiBudW1iZXJcblxuICAvKipcbiAgICogTmFtZXNwYWNlIGZvciB0aGUgR29UcnVlIGFkbWluIG1ldGhvZHMuXG4gICAqIFRoZXNlIG1ldGhvZHMgc2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBhIHRydXN0ZWQgc2VydmVyLXNpZGUgZW52aXJvbm1lbnQuXG4gICAqL1xuICBhZG1pbjogR29UcnVlQWRtaW5BcGlcbiAgLyoqXG4gICAqIE5hbWVzcGFjZSBmb3IgdGhlIE1GQSBtZXRob2RzLlxuICAgKi9cbiAgbWZhOiBHb1RydWVNRkFBcGlcbiAgLyoqXG4gICAqIE5hbWVzcGFjZSBmb3IgdGhlIE9BdXRoIDIuMSBhdXRob3JpemF0aW9uIHNlcnZlciBtZXRob2RzLlxuICAgKiBPbmx5IHJlbGV2YW50IHdoZW4gdGhlIE9BdXRoIDIuMSBzZXJ2ZXIgaXMgZW5hYmxlZCBpbiBTdXBhYmFzZSBBdXRoLlxuICAgKiBVc2VkIHRvIGltcGxlbWVudCB0aGUgYXV0aG9yaXphdGlvbiBjb2RlIGZsb3cgb24gdGhlIGNvbnNlbnQgcGFnZS5cbiAgICovXG4gIG9hdXRoOiBBdXRoT0F1dGhTZXJ2ZXJBcGlcbiAgLyoqXG4gICAqIE5hbWVzcGFjZSBmb3IgcGFzc2tleSBtZXRob2RzLlxuICAgKiBJbmNsdWRlcyBsb3dlci1sZXZlbCB0d28tc3RlcCByZWdpc3RyYXRpb24vYXV0aGVudGljYXRpb24gYW5kIHBhc3NrZXkgbWFuYWdlbWVudC5cbiAgICpcbiAgICogUmVxdWlyZXMgYGF1dGguZXhwZXJpbWVudGFsLnBhc3NrZXk6IHRydWVgOyBvdGhlcndpc2UgYWxsIG1ldGhvZHMgdGhyb3cuXG4gICAqL1xuICBwYXNza2V5OiBBdXRoUGFzc2tleUFwaVxuICAvKipcbiAgICogVGhlIHN0b3JhZ2Uga2V5IHVzZWQgdG8gaWRlbnRpZnkgdGhlIHZhbHVlcyBzYXZlZCBpbiBsb2NhbFN0b3JhZ2VcbiAgICovXG4gIHByb3RlY3RlZCBzdG9yYWdlS2V5OiBzdHJpbmdcblxuICBwcm90ZWN0ZWQgZmxvd1R5cGU6IEF1dGhGbG93VHlwZVxuXG4gIC8qKlxuICAgKiBUaGUgSldLUyB1c2VkIGZvciB2ZXJpZnlpbmcgYXN5bW1ldHJpYyBKV1RzXG4gICAqL1xuICBwcm90ZWN0ZWQgZ2V0IGp3a3MoKSB7XG4gICAgcmV0dXJuIEdMT0JBTF9KV0tTW3RoaXMuc3RvcmFnZUtleV0/Lmp3a3MgPz8geyBrZXlzOiBbXSB9XG4gIH1cblxuICBwcm90ZWN0ZWQgc2V0IGp3a3ModmFsdWU6IHsga2V5czogSldLW10gfSkge1xuICAgIEdMT0JBTF9KV0tTW3RoaXMuc3RvcmFnZUtleV0gPSB7IC4uLkdMT0JBTF9KV0tTW3RoaXMuc3RvcmFnZUtleV0sIGp3a3M6IHZhbHVlIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBnZXQgandrc19jYWNoZWRfYXQoKSB7XG4gICAgcmV0dXJuIEdMT0JBTF9KV0tTW3RoaXMuc3RvcmFnZUtleV0/LmNhY2hlZEF0ID8/IE51bWJlci5NSU5fU0FGRV9JTlRFR0VSXG4gIH1cblxuICBwcm90ZWN0ZWQgc2V0IGp3a3NfY2FjaGVkX2F0KHZhbHVlOiBudW1iZXIpIHtcbiAgICBHTE9CQUxfSldLU1t0aGlzLnN0b3JhZ2VLZXldID0geyAuLi5HTE9CQUxfSldLU1t0aGlzLnN0b3JhZ2VLZXldLCBjYWNoZWRBdDogdmFsdWUgfVxuICB9XG5cbiAgcHJvdGVjdGVkIGF1dG9SZWZyZXNoVG9rZW46IGJvb2xlYW5cbiAgcHJvdGVjdGVkIHBlcnNpc3RTZXNzaW9uOiBib29sZWFuXG4gIHByb3RlY3RlZCBzdG9yYWdlOiBTdXBwb3J0ZWRTdG9yYWdlXG4gIC8qKlxuICAgKiBAZXhwZXJpbWVudGFsXG4gICAqL1xuICBwcm90ZWN0ZWQgdXNlclN0b3JhZ2U6IFN1cHBvcnRlZFN0b3JhZ2UgfCBudWxsID0gbnVsbFxuICBwcm90ZWN0ZWQgbWVtb3J5U3RvcmFnZTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSB8IG51bGwgPSBudWxsXG4gIHByb3RlY3RlZCBzdGF0ZUNoYW5nZUVtaXR0ZXJzOiBNYXA8c3RyaW5nIHwgc3ltYm9sLCBTdWJzY3JpcHRpb24+ID0gbmV3IE1hcCgpXG4gIHByb3RlY3RlZCBhdXRvUmVmcmVzaFRpY2tlcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGxcbiAgcHJvdGVjdGVkIGF1dG9SZWZyZXNoVGlja1RpbWVvdXQ6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGxcbiAgcHJvdGVjdGVkIHZpc2liaWxpdHlDaGFuZ2VkQ2FsbGJhY2s6ICgoKSA9PiBQcm9taXNlPGFueT4pIHwgbnVsbCA9IG51bGxcbiAgcHJvdGVjdGVkIHJlZnJlc2hpbmdEZWZlcnJlZDogRGVmZXJyZWQ8Q2FsbFJlZnJlc2hUb2tlblJlc3VsdD4gfCBudWxsID0gbnVsbFxuICAvKipcbiAgICogTW9ub3RvbmljIGNvdW50ZXIgaW5jcmVtZW50ZWQgYXQgdGhlIHRvcCBvZiBgX3JlbW92ZVNlc3Npb25gLCBiZWZvcmUgYW55XG4gICAqIGBhd2FpdGAuIFRoZSBjb21taXQgZ3VhcmQgaW5zaWRlIGBfY2FsbFJlZnJlc2hUb2tlbmAgY2FwdHVyZXMgdGhpcyB2YWx1ZVxuICAgKiBiZWZvcmUgYF9zYXZlU2Vzc2lvbmAgYW5kIHJlLWNoZWNrcyBpdCBhZnRlciwgc28gYSBgc2lnbk91dGAgdGhhdFxuICAgKiBpbnRlcmxlYXZlcyBpbnNpZGUgYF9zYXZlU2Vzc2lvbmAncyBzdG9yYWdlLXdyaXRlIGF3YWl0cyBpcyBzdGlsbCBjYXVnaHRcbiAgICogKHRoZSBwb3N0LWZldGNoIHN0b3JhZ2Ugc25hcHNob3QgYWxvbmUgbWlzc2VzIHRoYXQgd2luZG93KS5cbiAgICovXG4gIHByb3RlY3RlZCBfc2Vzc2lvblJlbW92YWxFcG9jaCA9IDBcbiAgLyoqXG4gICAqIEtlZXBzIHRyYWNrIG9mIHRoZSBhc3luYyBjbGllbnQgaW5pdGlhbGl6YXRpb24uXG4gICAqIFdoZW4gbnVsbCBvciBub3QgeWV0IHJlc29sdmVkIHRoZSBhdXRoIHN0YXRlIGlzIGB1bmtub3duYFxuICAgKiBPbmNlIHJlc29sdmVkIHRoZSBhdXRoIHN0YXRlIGlzIGtub3duIGFuZCBpdCdzIHNhZmUgdG8gY2FsbCBhbnkgZnVydGhlciBjbGllbnQgbWV0aG9kcy5cbiAgICogS2VlcCBleHRyYSBjYXJlIHRvIG5ldmVyIHJlamVjdCBvciB0aHJvdyB1bmNhdWdodCBlcnJvcnNcbiAgICovXG4gIHByb3RlY3RlZCBpbml0aWFsaXplUHJvbWlzZTogUHJvbWlzZTxJbml0aWFsaXplUmVzdWx0PiB8IG51bGwgPSBudWxsXG4gIHByb3RlY3RlZCBkZXRlY3RTZXNzaW9uSW5Vcmw6XG4gICAgfCBib29sZWFuXG4gICAgfCAoKHVybDogVVJMLCBwYXJhbXM6IHsgW3BhcmFtZXRlcjogc3RyaW5nXTogc3RyaW5nIH0pID0+IGJvb2xlYW4pID0gdHJ1ZVxuICBwcm90ZWN0ZWQgdXJsOiBzdHJpbmdcbiAgcHJvdGVjdGVkIGhlYWRlcnM6IHtcbiAgICBba2V5OiBzdHJpbmddOiBzdHJpbmdcbiAgfVxuICBwcm90ZWN0ZWQgaGFzQ3VzdG9tQXV0aG9yaXphdGlvbkhlYWRlciA9IGZhbHNlXG4gIHByb3RlY3RlZCBzdXBwcmVzc0dldFNlc3Npb25XYXJuaW5nID0gZmFsc2VcbiAgcHJvdGVjdGVkIGZldGNoOiBGZXRjaFxuICAvKipcbiAgICogQ3VzdG9tIGxvY2sgZnVuY3Rpb24gcGFzc2VkIHZpYSBgc2V0dGluZ3MubG9ja2AuIFdoZW4gbm9uLW51bGwsIGV2ZXJ5IGF1dGhcbiAgICogb3BlcmF0aW9uIHJ1bnMgaW5zaWRlIGBfYWNxdWlyZUxvY2tgLiBXaGVuIG51bGwgKHRoZSBkZWZhdWx0KSwgdGhlIGNsaWVudFxuICAgKiB1c2VzIGl0cyBsb2NrbGVzcyBjb29yZGluYXRpb24gKHJlZnJlc2ggc2luZ2xlLWZsaWdodCArIGNvbW1pdCBndWFyZCkuXG4gICAqIFRPRE8odjMpOiByZW1vdmUgYWxvbmcgd2l0aCB0aGUgbGVnYWN5IGxvY2sgcGF0aC5cbiAgICovXG4gIHByb3RlY3RlZCBsb2NrOiBMb2NrRnVuYyB8IG51bGwgPSBudWxsXG4gIHByb3RlY3RlZCBsb2NrQWNxdWlyZWQgPSBmYWxzZVxuICBwcm90ZWN0ZWQgcGVuZGluZ0luTG9jazogUHJvbWlzZTxhbnk+W10gPSBbXVxuICBwcm90ZWN0ZWQgdGhyb3dPbkVycm9yOiBib29sZWFuXG4gIC8qKlxuICAgKiBPbmx5IGNvbnN1bHRlZCB3aGVuIGEgY3VzdG9tIGBsb2NrYCBpcyBzdXBwbGllZC4gVE9ETyh2Myk6IHJlbW92ZS5cbiAgICovXG4gIHByb3RlY3RlZCBsb2NrQWNxdWlyZVRpbWVvdXQ6IG51bWJlclxuICAvKipcbiAgICogT3B0LWluIGZsYWdzIGZvciBleHBlcmltZW50YWwgZmVhdHVyZXMuIERlZmF1bHRzIHRvIGFuIGVtcHR5IG9iamVjdC5cbiAgICogU2VlIGBHb1RydWVDbGllbnRPcHRpb25zLmV4cGVyaW1lbnRhbGAuXG4gICAqL1xuICBwcm90ZWN0ZWQgZXhwZXJpbWVudGFsOiBFeHBlcmltZW50YWxGZWF0dXJlRmxhZ3NcblxuICAvKipcbiAgICogVXNlZCB0byBicm9hZGNhc3Qgc3RhdGUgY2hhbmdlIGV2ZW50cyB0byBvdGhlciB0YWJzIGxpc3RlbmluZy5cbiAgICovXG4gIHByb3RlY3RlZCBicm9hZGNhc3RDaGFubmVsOiBCcm9hZGNhc3RDaGFubmVsIHwgbnVsbCA9IG51bGxcblxuICBwcm90ZWN0ZWQgbG9nRGVidWdNZXNzYWdlczogYm9vbGVhblxuICBwcm90ZWN0ZWQgbG9nZ2VyOiAobWVzc2FnZTogc3RyaW5nLCAuLi5hcmdzOiBhbnlbXSkgPT4gdm9pZCA9IGNvbnNvbGUubG9nXG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBjbGllbnQgZm9yIHVzZSBpbiB0aGUgYnJvd3Nlci5cbiAgICpcbiAgICogQGV4YW1wbGUgVXNpbmcgc3VwYWJhc2UtanMgKHJlY29tbWVuZGVkKVxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqXG4gICAqIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28nLCAneW91ci1wdWJsaXNoYWJsZS1rZXknKVxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU3RhbmRhbG9uZSBpbXBvcnQgZm9yIGJ1bmRsZS1zZW5zaXRpdmUgZW52aXJvbm1lbnRzXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IEdvVHJ1ZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9hdXRoLWpzJ1xuICAgKlxuICAgKiBjb25zdCBhdXRoID0gbmV3IEdvVHJ1ZUNsaWVudCh7XG4gICAqICAgdXJsOiAnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvL2F1dGgvdjEnLFxuICAgKiAgIGhlYWRlcnM6IHsgYXBpa2V5OiAneW91ci1wdWJsaXNoYWJsZS1rZXknIH0sXG4gICAqICAgc3RvcmFnZUtleTogJ3N1cGFiYXNlLWF1dGgnLFxuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIGNvbnN0cnVjdG9yKG9wdGlvbnM6IEdvVHJ1ZUNsaWVudE9wdGlvbnMpIHtcbiAgICBjb25zdCBzZXR0aW5ncyA9IHsgLi4uREVGQVVMVF9PUFRJT05TLCAuLi5vcHRpb25zIH1cbiAgICB0aGlzLnN0b3JhZ2VLZXkgPSBzZXR0aW5ncy5zdG9yYWdlS2V5XG5cbiAgICB0aGlzLmluc3RhbmNlSUQgPSBHb1RydWVDbGllbnQubmV4dEluc3RhbmNlSURbdGhpcy5zdG9yYWdlS2V5XSA/PyAwXG4gICAgR29UcnVlQ2xpZW50Lm5leHRJbnN0YW5jZUlEW3RoaXMuc3RvcmFnZUtleV0gPSB0aGlzLmluc3RhbmNlSUQgKyAxXG5cbiAgICB0aGlzLmxvZ0RlYnVnTWVzc2FnZXMgPSAhIXNldHRpbmdzLmRlYnVnXG4gICAgaWYgKHR5cGVvZiBzZXR0aW5ncy5kZWJ1ZyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgdGhpcy5sb2dnZXIgPSBzZXR0aW5ncy5kZWJ1Z1xuICAgIH1cblxuICAgIGlmICh0aGlzLmluc3RhbmNlSUQgPiAwICYmIGlzQnJvd3NlcigpKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID0gYCR7dGhpcy5fbG9nUHJlZml4KCl9IE11bHRpcGxlIEdvVHJ1ZUNsaWVudCBpbnN0YW5jZXMgZGV0ZWN0ZWQgaW4gdGhlIHNhbWUgYnJvd3NlciBjb250ZXh0LiBJdCBpcyBub3QgYW4gZXJyb3IsIGJ1dCB0aGlzIHNob3VsZCBiZSBhdm9pZGVkIGFzIGl0IG1heSBwcm9kdWNlIHVuZGVmaW5lZCBiZWhhdmlvciB3aGVuIHVzZWQgY29uY3VycmVudGx5IHVuZGVyIHRoZSBzYW1lIHN0b3JhZ2Uga2V5LmBcbiAgICAgIGNvbnNvbGUud2FybihtZXNzYWdlKVxuICAgICAgaWYgKHRoaXMubG9nRGVidWdNZXNzYWdlcykge1xuICAgICAgICBjb25zb2xlLnRyYWNlKG1lc3NhZ2UpXG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy5wZXJzaXN0U2Vzc2lvbiA9IHNldHRpbmdzLnBlcnNpc3RTZXNzaW9uXG4gICAgdGhpcy5hdXRvUmVmcmVzaFRva2VuID0gc2V0dGluZ3MuYXV0b1JlZnJlc2hUb2tlblxuICAgIHRoaXMuZXhwZXJpbWVudGFsID0gc2V0dGluZ3MuZXhwZXJpbWVudGFsID8/IHt9XG4gICAgdGhpcy5hZG1pbiA9IG5ldyBHb1RydWVBZG1pbkFwaSh7XG4gICAgICB1cmw6IHNldHRpbmdzLnVybCxcbiAgICAgIGhlYWRlcnM6IHNldHRpbmdzLmhlYWRlcnMsXG4gICAgICBmZXRjaDogc2V0dGluZ3MuZmV0Y2gsXG4gICAgICBleHBlcmltZW50YWw6IHRoaXMuZXhwZXJpbWVudGFsLFxuICAgIH0pXG5cbiAgICB0aGlzLnVybCA9IHNldHRpbmdzLnVybFxuICAgIHRoaXMuaGVhZGVycyA9IHNldHRpbmdzLmhlYWRlcnNcbiAgICB0aGlzLmZldGNoID0gcmVzb2x2ZUZldGNoKHNldHRpbmdzLmZldGNoKVxuICAgIHRoaXMuZGV0ZWN0U2Vzc2lvbkluVXJsID0gc2V0dGluZ3MuZGV0ZWN0U2Vzc2lvbkluVXJsXG4gICAgdGhpcy5mbG93VHlwZSA9IHNldHRpbmdzLmZsb3dUeXBlXG4gICAgdGhpcy5oYXNDdXN0b21BdXRob3JpemF0aW9uSGVhZGVyID0gc2V0dGluZ3MuaGFzQ3VzdG9tQXV0aG9yaXphdGlvbkhlYWRlclxuICAgIHRoaXMudGhyb3dPbkVycm9yID0gc2V0dGluZ3MudGhyb3dPbkVycm9yXG5cbiAgICAvLyBBbHdheXMgd2lyZSBgbG9ja0FjcXVpcmVUaW1lb3V0YCBldmVuIG9uIHRoZSBsb2NrbGVzcyBwYXRoOiBjb25zdW1lcnNcbiAgICAvLyAoaW5jbHVkaW5nIHN1cGFiYXNlLWpzIHRlc3RzKSByZWFkIGl0IG9mZiB0aGUgY2xpZW50IHRvIHZlcmlmeSBvcHRpb25cbiAgICAvLyBmbG93LXRocm91Z2guXG4gICAgdGhpcy5sb2NrQWNxdWlyZVRpbWVvdXQgPSBzZXR0aW5ncy5sb2NrQWNxdWlyZVRpbWVvdXRcblxuICAgIC8vIFRPRE8odjMpOiByZW1vdmUuIExlZ2FjeSBvcHQtaW4gcGF0aCBwcmVzZXJ2ZWQgZm9yIGJhY2t3YXJkc1xuICAgIC8vIGNvbXBhdGliaWxpdHkgd2l0aCBjYWxsZXJzIHBhc3NpbmcgYSBjdXN0b20gYGxvY2tgICh0eXBpY2FsbHkgUmVhY3RcbiAgICAvLyBOYXRpdmUgYHByb2Nlc3NMb2NrYCBvciBOb2RlIG11bHRpLXByb2Nlc3Mgc2V0dXBzKS4gV2hlbiBgc2V0dGluZ3MubG9ja2BcbiAgICAvLyBpcyBudWxsIHRoZSBjbGllbnQgdXNlcyBpdHMgbG9ja2xlc3MgY29vcmRpbmF0aW9uIOKAlCBubyBgbmF2aWdhdG9yLmxvY2tzYFxuICAgIC8vIGJ5IGRlZmF1bHQsIG5vIGltcGxpY2l0IGBwcm9jZXNzTG9ja2AuXG4gICAgaWYgKHNldHRpbmdzLmxvY2sgIT0gbnVsbCkge1xuICAgICAgdGhpcy5sb2NrID0gc2V0dGluZ3MubG9ja1xuICAgIH1cblxuICAgIGlmICghdGhpcy5qd2tzKSB7XG4gICAgICB0aGlzLmp3a3MgPSB7IGtleXM6IFtdIH1cbiAgICAgIHRoaXMuandrc19jYWNoZWRfYXQgPSBOdW1iZXIuTUlOX1NBRkVfSU5URUdFUlxuICAgIH1cblxuICAgIHRoaXMubWZhID0ge1xuICAgICAgdmVyaWZ5OiB0aGlzLl92ZXJpZnkuYmluZCh0aGlzKSxcbiAgICAgIGVucm9sbDogdGhpcy5fZW5yb2xsLmJpbmQodGhpcyksXG4gICAgICB1bmVucm9sbDogdGhpcy5fdW5lbnJvbGwuYmluZCh0aGlzKSxcbiAgICAgIGNoYWxsZW5nZTogdGhpcy5fY2hhbGxlbmdlLmJpbmQodGhpcyksXG4gICAgICBsaXN0RmFjdG9yczogdGhpcy5fbGlzdEZhY3RvcnMuYmluZCh0aGlzKSxcbiAgICAgIGNoYWxsZW5nZUFuZFZlcmlmeTogdGhpcy5fY2hhbGxlbmdlQW5kVmVyaWZ5LmJpbmQodGhpcyksXG4gICAgICBnZXRBdXRoZW50aWNhdG9yQXNzdXJhbmNlTGV2ZWw6IHRoaXMuX2dldEF1dGhlbnRpY2F0b3JBc3N1cmFuY2VMZXZlbC5iaW5kKHRoaXMpLFxuICAgICAgd2ViYXV0aG46IG5ldyBXZWJBdXRobkFwaSh0aGlzKSxcbiAgICB9XG5cbiAgICB0aGlzLm9hdXRoID0ge1xuICAgICAgZ2V0QXV0aG9yaXphdGlvbkRldGFpbHM6IHRoaXMuX2dldEF1dGhvcml6YXRpb25EZXRhaWxzLmJpbmQodGhpcyksXG4gICAgICBhcHByb3ZlQXV0aG9yaXphdGlvbjogdGhpcy5fYXBwcm92ZUF1dGhvcml6YXRpb24uYmluZCh0aGlzKSxcbiAgICAgIGRlbnlBdXRob3JpemF0aW9uOiB0aGlzLl9kZW55QXV0aG9yaXphdGlvbi5iaW5kKHRoaXMpLFxuICAgICAgbGlzdEdyYW50czogdGhpcy5fbGlzdE9BdXRoR3JhbnRzLmJpbmQodGhpcyksXG4gICAgICByZXZva2VHcmFudDogdGhpcy5fcmV2b2tlT0F1dGhHcmFudC5iaW5kKHRoaXMpLFxuICAgIH1cblxuICAgIHRoaXMucGFzc2tleSA9IHtcbiAgICAgIHN0YXJ0UmVnaXN0cmF0aW9uOiB0aGlzLl9zdGFydFBhc3NrZXlSZWdpc3RyYXRpb24uYmluZCh0aGlzKSxcbiAgICAgIHZlcmlmeVJlZ2lzdHJhdGlvbjogdGhpcy5fdmVyaWZ5UGFzc2tleVJlZ2lzdHJhdGlvbi5iaW5kKHRoaXMpLFxuICAgICAgc3RhcnRBdXRoZW50aWNhdGlvbjogdGhpcy5fc3RhcnRQYXNza2V5QXV0aGVudGljYXRpb24uYmluZCh0aGlzKSxcbiAgICAgIHZlcmlmeUF1dGhlbnRpY2F0aW9uOiB0aGlzLl92ZXJpZnlQYXNza2V5QXV0aGVudGljYXRpb24uYmluZCh0aGlzKSxcbiAgICAgIGxpc3Q6IHRoaXMuX2xpc3RQYXNza2V5cy5iaW5kKHRoaXMpLFxuICAgICAgdXBkYXRlOiB0aGlzLl91cGRhdGVQYXNza2V5LmJpbmQodGhpcyksXG4gICAgICBkZWxldGU6IHRoaXMuX2RlbGV0ZVBhc3NrZXkuYmluZCh0aGlzKSxcbiAgICB9XG5cbiAgICBpZiAodGhpcy5wZXJzaXN0U2Vzc2lvbikge1xuICAgICAgaWYgKHNldHRpbmdzLnN0b3JhZ2UpIHtcbiAgICAgICAgdGhpcy5zdG9yYWdlID0gc2V0dGluZ3Muc3RvcmFnZVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHN1cHBvcnRzTG9jYWxTdG9yYWdlKCkpIHtcbiAgICAgICAgICB0aGlzLnN0b3JhZ2UgPSBnbG9iYWxUaGlzLmxvY2FsU3RvcmFnZVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMubWVtb3J5U3RvcmFnZSA9IHt9XG4gICAgICAgICAgdGhpcy5zdG9yYWdlID0gbWVtb3J5TG9jYWxTdG9yYWdlQWRhcHRlcih0aGlzLm1lbW9yeVN0b3JhZ2UpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHNldHRpbmdzLnVzZXJTdG9yYWdlKSB7XG4gICAgICAgIHRoaXMudXNlclN0b3JhZ2UgPSBzZXR0aW5ncy51c2VyU3RvcmFnZVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm1lbW9yeVN0b3JhZ2UgPSB7fVxuICAgICAgdGhpcy5zdG9yYWdlID0gbWVtb3J5TG9jYWxTdG9yYWdlQWRhcHRlcih0aGlzLm1lbW9yeVN0b3JhZ2UpXG4gICAgfVxuXG4gICAgaWYgKGlzQnJvd3NlcigpICYmIGdsb2JhbFRoaXMuQnJvYWRjYXN0Q2hhbm5lbCAmJiB0aGlzLnBlcnNpc3RTZXNzaW9uICYmIHRoaXMuc3RvcmFnZUtleSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5icm9hZGNhc3RDaGFubmVsID0gbmV3IGdsb2JhbFRoaXMuQnJvYWRjYXN0Q2hhbm5lbCh0aGlzLnN0b3JhZ2VLZXkpXG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgJ0ZhaWxlZCB0byBjcmVhdGUgYSBuZXcgQnJvYWRjYXN0Q2hhbm5lbCwgbXVsdGktdGFiIHN0YXRlIGNoYW5nZXMgd2lsbCBub3QgYmUgYXZhaWxhYmxlJyxcbiAgICAgICAgICBlXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgdGhpcy5icm9hZGNhc3RDaGFubmVsPy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgICAgIHRoaXMuX2RlYnVnKCdyZWNlaXZlZCBicm9hZGNhc3Qgbm90aWZpY2F0aW9uIGZyb20gb3RoZXIgdGFiIG9yIGNsaWVudCcsIGV2ZW50KVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoZXZlbnQuZGF0YS5ldmVudCwgZXZlbnQuZGF0YS5zZXNzaW9uLCBmYWxzZSkgLy8gYnJvYWRjYXN0ID0gZmFsc2Ugc28gd2UgZG9uJ3QgZ2V0IGFuIGVuZGxlc3MgbG9vcCBvZiBtZXNzYWdlc1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIHRoaXMuX2RlYnVnKCcjYnJvYWRjYXN0Q2hhbm5lbCcsICdlcnJvcicsIGVycm9yKVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH1cblxuICAgIC8vIE9ubHkgYXV0by1pbml0aWFsaXplIGlmIG5vdCBleHBsaWNpdGx5IGRpc2FibGVkLiBTa2lwcGVkIGluIFNTUiBjb250ZXh0c1xuICAgIC8vIHdoZXJlIGluaXRpYWxpemF0aW9uIHRpbWluZyBtdXN0IGJlIGNvbnRyb2xsZWQuIEFsbCBwdWJsaWMgbWV0aG9kcyBoYXZlXG4gICAgLy8gbGF6eSBpbml0aWFsaXphdGlvbiwgc28gdGhlIGNsaWVudCByZW1haW5zIGZ1bGx5IGZ1bmN0aW9uYWwuXG4gICAgaWYgKCFzZXR0aW5ncy5za2lwQXV0b0luaXRpYWxpemUpIHtcbiAgICAgIHRoaXMuaW5pdGlhbGl6ZSgpLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICB0aGlzLl9kZWJ1ZygnI2luaXRpYWxpemUoKScsICdlcnJvcicsIGVycm9yKVxuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB3aGV0aGVyIGVycm9yIHRocm93aW5nIG1vZGUgaXMgZW5hYmxlZCBmb3IgdGhpcyBjbGllbnQuXG4gICAqL1xuICBwdWJsaWMgaXNUaHJvd09uRXJyb3JFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnRocm93T25FcnJvclxuICB9XG5cbiAgLyoqXG4gICAqIENlbnRyYWxpemVzIHJldHVybiBoYW5kbGluZyB3aXRoIG9wdGlvbmFsIGVycm9yIHRocm93aW5nLiBXaGVuIGB0aHJvd09uRXJyb3JgIGlzIGVuYWJsZWRcbiAgICogYW5kIHRoZSBwcm92aWRlZCByZXN1bHQgY29udGFpbnMgYSBub24tbnVsbGlzaCBlcnJvciwgdGhlIGVycm9yIGlzIHRocm93biBpbnN0ZWFkIG9mXG4gICAqIGJlaW5nIHJldHVybmVkLiBUaGlzIGVuc3VyZXMgY29uc2lzdGVudCBiZWhhdmlvciBhY3Jvc3MgYWxsIHB1YmxpYyBBUEkgbWV0aG9kcy5cbiAgICovXG4gIHByaXZhdGUgX3JldHVyblJlc3VsdDxUIGV4dGVuZHMgeyBlcnJvcjogYW55IH0+KHJlc3VsdDogVCk6IFQge1xuICAgIGlmICh0aGlzLnRocm93T25FcnJvciAmJiByZXN1bHQgJiYgcmVzdWx0LmVycm9yKSB7XG4gICAgICB0aHJvdyByZXN1bHQuZXJyb3JcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG5cbiAgcHJpdmF0ZSBfbG9nUHJlZml4KCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIChcbiAgICAgICdHb1RydWVDbGllbnRAJyArXG4gICAgICBgJHt0aGlzLnN0b3JhZ2VLZXl9OiR7dGhpcy5pbnN0YW5jZUlEfSAoJHt2ZXJzaW9ufSkgJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCl9YFxuICAgIClcbiAgfVxuXG4gIHByaXZhdGUgX2RlYnVnKC4uLmFyZ3M6IGFueVtdKTogR29UcnVlQ2xpZW50IHtcbiAgICBpZiAodGhpcy5sb2dEZWJ1Z01lc3NhZ2VzKSB7XG4gICAgICB0aGlzLmxvZ2dlcih0aGlzLl9sb2dQcmVmaXgoKSwgLi4uYXJncylcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemUgdGhlIGF1dGggY2xpZW50IGJ5IGxvYWRpbmcgdGhlIHNlc3Npb24gZnJvbSBzdG9yYWdlIG9yXG4gICAqIGRldGVjdGluZyBpdCBmcm9tIHRoZSBVUkwgYWZ0ZXIgYW4gT0F1dGgsIG1hZ2ljLWxpbmssIG9yIHBhc3N3b3JkLXJlY292ZXJ5XG4gICAqIHJlZGlyZWN0LlxuICAgKlxuICAgKiAqKk1vc3QgY2FsbGVycyBkbyBub3QgbmVlZCB0byBpbnZva2UgdGhpcyBkaXJlY3RseS4qKiBUaGUgY2xpZW50IGNhbGxzIGl0XG4gICAqIGF1dG9tYXRpY2FsbHkgZHVyaW5nIGNvbnN0cnVjdGlvbiwgYW5kIHRvIHJlYWN0IHRvIHNpZ24taW4gZXZlbnRzIChpbmNsdWRpbmdcbiAgICogcG9zdC1yZWRpcmVjdCBldmVudHMpIHlvdSBzaG91bGQgc3Vic2NyaWJlIHRvIGBvbkF1dGhTdGF0ZUNoYW5nZWAgcmF0aGVyXG4gICAqIHRoYW4gYXdhaXRpbmcgYGluaXRpYWxpemUoKWAuXG4gICAqXG4gICAqIFlvdSBvbmx5IG5lZWQgdG8gY2FsbCBpdCBtYW51YWxseSB3aGVuIHlvdSBoYXZlIG9wdGVkIG91dCBvZiB0aGUgYXV0b21hdGljXG4gICAqIGNhbGwgYnkgcGFzc2luZyBgc2tpcEF1dG9Jbml0aWFsaXplOiB0cnVlYCDigJQgZm9yIGV4YW1wbGUsIGluIGFuIFNTUiBjb250ZXh0XG4gICAqIHdoZXJlIHlvdSBuZWVkIHRvIGNvbnRyb2wgaW5pdGlhbGl6YXRpb24gdGltaW5nLiBJbiB0aGF0IGNhc2UsIGF3YWl0aW5nXG4gICAqIGBpbml0aWFsaXplKClgIHJldHVybnMgdGhlIHJlc29sdmVkIHNlc3Npb24gcmVzdWx0IChvciBhbnkgZXJyb3IgZW5jb3VudGVyZWRcbiAgICogd2hpbGUgZGV0ZWN0aW5nIGl0IGZyb20gdGhlIFVSTCkuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqL1xuICBhc3luYyBpbml0aWFsaXplKCk6IFByb21pc2U8SW5pdGlhbGl6ZVJlc3VsdD4ge1xuICAgIGlmICh0aGlzLmluaXRpYWxpemVQcm9taXNlKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5pbml0aWFsaXplUHJvbWlzZVxuICAgIH1cblxuICAgIHRoaXMuaW5pdGlhbGl6ZVByb21pc2UgPSAoYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKHRoaXMubG9jayAhPSBudWxsKSB7XG4gICAgICAgIC8vIFRPRE8odjMpOiByZW1vdmUgbGVnYWN5IGxvY2sgcGF0aFxuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fYWNxdWlyZUxvY2sodGhpcy5sb2NrQWNxdWlyZVRpbWVvdXQsIGFzeW5jICgpID0+IHtcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5faW5pdGlhbGl6ZSgpXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5faW5pdGlhbGl6ZSgpXG4gICAgfSkoKVxuXG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuaW5pdGlhbGl6ZVByb21pc2VcbiAgfVxuXG4gIC8qKlxuICAgKiBJTVBPUlRBTlQ6XG4gICAqIDEuIE5ldmVyIHRocm93IGluIHRoaXMgbWV0aG9kLCBhcyBpdCBpcyBjYWxsZWQgZnJvbSB0aGUgY29uc3RydWN0b3JcbiAgICogMi4gTmV2ZXIgcmV0dXJuIGEgc2Vzc2lvbiBmcm9tIHRoaXMgbWV0aG9kIGFzIGl0IHdvdWxkIGJlIGNhY2hlZCBvdmVyXG4gICAqICAgIHRoZSB3aG9sZSBsaWZldGltZSBvZiB0aGUgY2xpZW50XG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9pbml0aWFsaXplKCk6IFByb21pc2U8SW5pdGlhbGl6ZVJlc3VsdD4ge1xuICAgIHRyeSB7XG4gICAgICBsZXQgcGFyYW1zOiB7IFtwYXJhbWV0ZXI6IHN0cmluZ106IHN0cmluZyB9ID0ge31cbiAgICAgIGxldCBjYWxsYmFja1VybFR5cGUgPSAnbm9uZSdcblxuICAgICAgaWYgKGlzQnJvd3NlcigpKSB7XG4gICAgICAgIHBhcmFtcyA9IHBhcnNlUGFyYW1ldGVyc0Zyb21VUkwod2luZG93LmxvY2F0aW9uLmhyZWYpXG4gICAgICAgIGlmICh0aGlzLl9pc0ltcGxpY2l0R3JhbnRDYWxsYmFjayhwYXJhbXMpKSB7XG4gICAgICAgICAgY2FsbGJhY2tVcmxUeXBlID0gJ2ltcGxpY2l0J1xuICAgICAgICB9IGVsc2UgaWYgKGF3YWl0IHRoaXMuX2lzUEtDRUNhbGxiYWNrKHBhcmFtcykpIHtcbiAgICAgICAgICBjYWxsYmFja1VybFR5cGUgPSAncGtjZSdcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvKipcbiAgICAgICAqIEF0dGVtcHQgdG8gZ2V0IHRoZSBzZXNzaW9uIGZyb20gdGhlIFVSTCBvbmx5IGlmIHRoZXNlIGNvbmRpdGlvbnMgYXJlIGZ1bGZpbGxlZFxuICAgICAgICpcbiAgICAgICAqIE5vdGU6IElmIHRoZSBVUkwgaXNuJ3Qgb25lIG9mIHRoZSBjYWxsYmFjayB1cmwgdHlwZXMgKGltcGxpY2l0IG9yIHBrY2UpLFxuICAgICAgICogdGhlbiB0aGVyZSBjb3VsZCBiZSBhbiBleGlzdGluZyBzZXNzaW9uIHNvIHdlIGRvbid0IHdhbnQgdG8gcHJlbWF0dXJlbHkgcmVtb3ZlIGl0XG4gICAgICAgKi9cbiAgICAgIGlmIChpc0Jyb3dzZXIoKSAmJiB0aGlzLmRldGVjdFNlc3Npb25JblVybCAmJiBjYWxsYmFja1VybFR5cGUgIT09ICdub25lJykge1xuICAgICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCB0aGlzLl9nZXRTZXNzaW9uRnJvbVVSTChwYXJhbXMsIGNhbGxiYWNrVXJsVHlwZSlcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgdGhpcy5fZGVidWcoJyNfaW5pdGlhbGl6ZSgpJywgJ2Vycm9yIGRldGVjdGluZyBzZXNzaW9uIGZyb20gVVJMJywgZXJyb3IpXG5cbiAgICAgICAgICBpZiAoaXNBdXRoSW1wbGljaXRHcmFudFJlZGlyZWN0RXJyb3IoZXJyb3IpKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJvckNvZGUgPSBlcnJvci5kZXRhaWxzPy5jb2RlXG4gICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgIGVycm9yQ29kZSA9PT0gJ2lkZW50aXR5X2FscmVhZHlfZXhpc3RzJyB8fFxuICAgICAgICAgICAgICBlcnJvckNvZGUgPT09ICdpZGVudGl0eV9ub3RfZm91bmQnIHx8XG4gICAgICAgICAgICAgIGVycm9yQ29kZSA9PT0gJ3NpbmdsZV9pZGVudGl0eV9ub3RfZGVsZXRhYmxlJ1xuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIHJldHVybiB7IGVycm9yIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBEb24ndCByZW1vdmUgZXhpc3Rpbmcgc2Vzc2lvbiBvbiBVUkwgbG9naW4gZmFpbHVyZS5cbiAgICAgICAgICAvLyBBIGZhaWxlZCBhdHRlbXB0IChlLmcuIHJldXNlZCBtYWdpYyBsaW5rKSBzaG91bGRuJ3QgaW52YWxpZGF0ZSBhIHZhbGlkIHNlc3Npb24uXG5cbiAgICAgICAgICByZXR1cm4geyBlcnJvciB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IHNlc3Npb24sIHJlZGlyZWN0VHlwZSB9ID0gZGF0YVxuXG4gICAgICAgIHRoaXMuX2RlYnVnKFxuICAgICAgICAgICcjX2luaXRpYWxpemUoKScsXG4gICAgICAgICAgJ2RldGVjdGVkIHNlc3Npb24gaW4gVVJMJyxcbiAgICAgICAgICBzZXNzaW9uLFxuICAgICAgICAgICdyZWRpcmVjdCB0eXBlJyxcbiAgICAgICAgICByZWRpcmVjdFR5cGVcbiAgICAgICAgKVxuXG4gICAgICAgIGF3YWl0IHRoaXMuX3NhdmVTZXNzaW9uKHNlc3Npb24pXG5cbiAgICAgICAgc2V0VGltZW91dChhc3luYyAoKSA9PiB7XG4gICAgICAgICAgaWYgKHJlZGlyZWN0VHlwZSA9PT0gJ3JlY292ZXJ5Jykge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoJ1BBU1NXT1JEX1JFQ09WRVJZJywgc2Vzc2lvbilcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoJ1NJR05FRF9JTicsIHNlc3Npb24pXG4gICAgICAgICAgfVxuICAgICAgICB9LCAwKVxuXG4gICAgICAgIHJldHVybiB7IGVycm9yOiBudWxsIH1cbiAgICAgIH1cbiAgICAgIC8vIG5vIGxvZ2luIGF0dGVtcHQgdmlhIGNhbGxiYWNrIHVybCB0cnkgdG8gcmVjb3ZlciBzZXNzaW9uIGZyb20gc3RvcmFnZVxuICAgICAgYXdhaXQgdGhpcy5fcmVjb3ZlckFuZFJlZnJlc2goKVxuICAgICAgcmV0dXJuIHsgZXJyb3I6IG51bGwgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHtcbiAgICAgICAgZXJyb3I6IG5ldyBBdXRoVW5rbm93bkVycm9yKCdVbmV4cGVjdGVkIGVycm9yIGR1cmluZyBpbml0aWFsaXphdGlvbicsIGVycm9yKSxcbiAgICAgIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGF3YWl0IHRoaXMuX2hhbmRsZVZpc2liaWxpdHlDaGFuZ2UoKVxuICAgICAgdGhpcy5fZGVidWcoJyNfaW5pdGlhbGl6ZSgpJywgJ2VuZCcpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgYW5vbnltb3VzIHVzZXIuXG4gICAqXG4gICAqIEByZXR1cm5zIEEgc2Vzc2lvbiB3aGVyZSB0aGUgaXNfYW5vbnltb3VzIGNsYWltIGluIHRoZSBhY2Nlc3MgdG9rZW4gSldUIHNldCB0byB0cnVlXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUmV0dXJucyBhbiBhbm9ueW1vdXMgdXNlclxuICAgKiAtIEl0IGlzIHJlY29tbWVuZGVkIHRvIHNldCB1cCBjYXB0Y2hhIGZvciBhbm9ueW1vdXMgc2lnbi1pbnMgdG8gcHJldmVudCBhYnVzZS4gWW91IGNhbiBwYXNzIGluIHRoZSBjYXB0Y2hhIHRva2VuIGluIHRoZSBgb3B0aW9uc2AgcGFyYW0uXG4gICAqXG4gICAqIEBleGFtcGxlIENyZWF0ZSBhbiBhbm9ueW1vdXMgdXNlclxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbkFub255bW91c2x5KHtcbiAgICogICBvcHRpb25zOiB7XG4gICAqICAgICBjYXB0Y2hhVG9rZW5cbiAgICogICB9XG4gICAqIH0pO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBDcmVhdGUgYW4gYW5vbnltb3VzIHVzZXJcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcIlwiLFxuICAgKiAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge30sXG4gICAqICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7fSxcbiAgICogICAgICAgXCJpZGVudGl0aWVzXCI6IFtdLFxuICAgKiAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcImlzX2Fub255bW91c1wiOiB0cnVlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzZXNzaW9uXCI6IHtcbiAgICogICAgICAgXCJhY2Nlc3NfdG9rZW5cIjogXCI8QUNDRVNTX1RPS0VOPlwiLFxuICAgKiAgICAgICBcInRva2VuX3R5cGVcIjogXCJiZWFyZXJcIixcbiAgICogICAgICAgXCJleHBpcmVzX2luXCI6IDM2MDAsXG4gICAqICAgICAgIFwiZXhwaXJlc19hdFwiOiAxNzAwMDAwMDAwLFxuICAgKiAgICAgICBcInJlZnJlc2hfdG9rZW5cIjogXCI8UkVGUkVTSF9UT0tFTj5cIixcbiAgICogICAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICAgIFwiZW1haWxcIjogXCJcIixcbiAgICogICAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHt9LFxuICAgKiAgICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7fSxcbiAgICogICAgICAgICBcImlkZW50aXRpZXNcIjogW10sXG4gICAqICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwiaXNfYW5vbnltb3VzXCI6IHRydWVcbiAgICogICAgICAgfVxuICAgKiAgICAgfVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIENyZWF0ZSBhbiBhbm9ueW1vdXMgdXNlciB3aXRoIGN1c3RvbSB1c2VyIG1ldGFkYXRhXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluQW5vbnltb3VzbHkoe1xuICAgKiAgIG9wdGlvbnM6IHtcbiAgICogICAgIGRhdGFcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgc2lnbkluQW5vbnltb3VzbHkoY3JlZGVudGlhbHM/OiBTaWduSW5Bbm9ueW1vdXNseUNyZWRlbnRpYWxzKTogUHJvbWlzZTxBdXRoUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vc2lnbnVwYCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBkYXRhOiBjcmVkZW50aWFscz8ub3B0aW9ucz8uZGF0YSA/PyB7fSxcbiAgICAgICAgICBnb3RydWVfbWV0YV9zZWN1cml0eTogeyBjYXB0Y2hhX3Rva2VuOiBjcmVkZW50aWFscz8ub3B0aW9ucz8uY2FwdGNoYVRva2VuIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHhmb3JtOiBfc2Vzc2lvblJlc3BvbnNlLFxuICAgICAgfSlcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IHJlc1xuXG4gICAgICBpZiAoZXJyb3IgfHwgIWRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvcjogZXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNlc3Npb246IFNlc3Npb24gfCBudWxsID0gZGF0YS5zZXNzaW9uXG4gICAgICBjb25zdCB1c2VyOiBVc2VyIHwgbnVsbCA9IGRhdGEudXNlclxuXG4gICAgICBpZiAoZGF0YS5zZXNzaW9uKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuX3NhdmVTZXNzaW9uKGRhdGEuc2Vzc2lvbilcbiAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoJ1NJR05FRF9JTicsIHNlc3Npb24pXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXIsIHNlc3Npb24gfSwgZXJyb3I6IG51bGwgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgdXNlci5cbiAgICpcbiAgICogQmUgYXdhcmUgdGhhdCBpZiBhIHVzZXIgYWNjb3VudCBleGlzdHMgaW4gdGhlIHN5c3RlbSB5b3UgbWF5IGdldCBiYWNrIGFuXG4gICAqIGVycm9yIG1lc3NhZ2UgdGhhdCBhdHRlbXB0cyB0byBoaWRlIHRoaXMgaW5mb3JtYXRpb24gZnJvbSB0aGUgdXNlci5cbiAgICogVGhpcyBtZXRob2QgaGFzIHN1cHBvcnQgZm9yIFBLQ0UgdmlhIGVtYWlsIHNpZ251cHMuIFRoZSBQS0NFIGZsb3cgY2Fubm90IGJlIHVzZWQgd2hlbiBhdXRvY29uZmlybSBpcyBlbmFibGVkLlxuICAgKlxuICAgKiBAcmV0dXJucyBBIGxvZ2dlZC1pbiBzZXNzaW9uIGlmIHRoZSBzZXJ2ZXIgaGFzIFwiYXV0b2NvbmZpcm1cIiBPTlxuICAgKiBAcmV0dXJucyBBIHVzZXIgaWYgdGhlIHNlcnZlciBoYXMgXCJhdXRvY29uZmlybVwiIE9GRlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEJ5IGRlZmF1bHQsIHRoZSB1c2VyIG5lZWRzIHRvIHZlcmlmeSB0aGVpciBlbWFpbCBhZGRyZXNzIGJlZm9yZSBsb2dnaW5nIGluLiBUbyB0dXJuIHRoaXMgb2ZmLCBkaXNhYmxlICoqQ29uZmlybSBlbWFpbCoqIGluIFt5b3VyIHByb2plY3RdKC9kYXNoYm9hcmQvcHJvamVjdC9fL2F1dGgvcHJvdmlkZXJzKS5cbiAgICogLSAqKkNvbmZpcm0gZW1haWwqKiBkZXRlcm1pbmVzIGlmIHVzZXJzIG5lZWQgdG8gY29uZmlybSB0aGVpciBlbWFpbCBhZGRyZXNzIGFmdGVyIHNpZ25pbmcgdXAuXG4gICAqICAgLSBJZiAqKkNvbmZpcm0gZW1haWwqKiBpcyBlbmFibGVkLCBhIGB1c2VyYCBpcyByZXR1cm5lZCBidXQgYHNlc3Npb25gIGlzIG51bGwuXG4gICAqICAgLSBJZiAqKkNvbmZpcm0gZW1haWwqKiBpcyBkaXNhYmxlZCwgYm90aCBhIGB1c2VyYCBhbmQgYSBgc2Vzc2lvbmAgYXJlIHJldHVybmVkLlxuICAgKiAtIFdoZW4gdGhlIHVzZXIgY29uZmlybXMgdGhlaXIgZW1haWwgYWRkcmVzcywgdGhleSBhcmUgcmVkaXJlY3RlZCB0byB0aGUgW2BTSVRFX1VSTGBdKC9kb2NzL2d1aWRlcy9hdXRoL3JlZGlyZWN0LXVybHMjdXNlLXdpbGRjYXJkcy1pbi1yZWRpcmVjdC11cmxzKSBieSBkZWZhdWx0LiBZb3UgY2FuIG1vZGlmeSB5b3VyIGBTSVRFX1VSTGAgb3IgYWRkIGFkZGl0aW9uYWwgcmVkaXJlY3QgVVJMcyBpbiBbeW91ciBwcm9qZWN0XSgvZGFzaGJvYXJkL3Byb2plY3QvXy9hdXRoL3VybC1jb25maWd1cmF0aW9uKS5cbiAgICogLSBJZiBzaWduVXAoKSBpcyBjYWxsZWQgZm9yIGFuIGV4aXN0aW5nIGNvbmZpcm1lZCB1c2VyOlxuICAgKiAgIC0gV2hlbiBib3RoICoqQ29uZmlybSBlbWFpbCoqIGFuZCAqKkNvbmZpcm0gcGhvbmUqKiAoZXZlbiB3aGVuIHBob25lIHByb3ZpZGVyIGlzIGRpc2FibGVkKSBhcmUgZW5hYmxlZCBpbiBbeW91ciBwcm9qZWN0XSgvZGFzaGJvYXJkL3Byb2plY3QvXy9hdXRoL3Byb3ZpZGVycyksIGFuIG9iZnVzY2F0ZWQvZmFrZSB1c2VyIG9iamVjdCBpcyByZXR1cm5lZC5cbiAgICogICAtIFdoZW4gZWl0aGVyICoqQ29uZmlybSBlbWFpbCoqIG9yICoqQ29uZmlybSBwaG9uZSoqIChldmVuIHdoZW4gcGhvbmUgcHJvdmlkZXIgaXMgZGlzYWJsZWQpIGlzIGRpc2FibGVkLCB0aGUgZXJyb3IgbWVzc2FnZSwgYFVzZXIgYWxyZWFkeSByZWdpc3RlcmVkYCBpcyByZXR1cm5lZC5cbiAgICogLSBUbyBmZXRjaCB0aGUgY3VycmVudGx5IGxvZ2dlZC1pbiB1c2VyLCByZWZlciB0byBbYGdldFVzZXIoKWBdKC9kb2NzL3JlZmVyZW5jZS9qYXZhc2NyaXB0L2F1dGgtZ2V0dXNlcikuXG4gICAqXG4gICAqIEBleGFtcGxlIFNpZ24gdXAgd2l0aCBhbiBlbWFpbCBhbmQgcGFzc3dvcmRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduVXAoe1xuICAgKiAgIGVtYWlsOiAnZXhhbXBsZUBlbWFpbC5jb20nLFxuICAgKiAgIHBhc3N3b3JkOiAnZXhhbXBsZS1wYXNzd29yZCcsXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFNpZ24gdXAgd2l0aCBhbiBlbWFpbCBhbmQgcGFzc3dvcmRcbiAgICogYGBganNvblxuICAgKiAvLyBTb21lIGZpZWxkcyBtYXkgYmUgbnVsbCBpZiBcImNvbmZpcm0gZW1haWxcIiBpcyBlbmFibGVkLlxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJwaG9uZVwiOiBcIlwiLFxuICAgKiAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICBcInByb3ZpZGVyc1wiOiBbXG4gICAqICAgICAgICAgICBcImVtYWlsXCJcbiAgICogICAgICAgICBdXG4gICAqICAgICAgIH0sXG4gICAqICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7fSxcbiAgICogICAgICAgXCJpZGVudGl0aWVzXCI6IFtcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjIyMjIyMjItMjIyMi0yMjIyLTIyMjItMjIyMjIyMjIyMjIyXCIsXG4gICAqICAgICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICBcInVzZXJfaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfZGF0YVwiOiB7XG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiXG4gICAqICAgICAgICAgfVxuICAgKiAgICAgICBdLFxuICAgKiAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzZXNzaW9uXCI6IHtcbiAgICogICAgICAgXCJhY2Nlc3NfdG9rZW5cIjogXCI8QUNDRVNTX1RPS0VOPlwiLFxuICAgKiAgICAgICBcInRva2VuX3R5cGVcIjogXCJiZWFyZXJcIixcbiAgICogICAgICAgXCJleHBpcmVzX2luXCI6IDM2MDAsXG4gICAqICAgICAgIFwiZXhwaXJlc19hdFwiOiAxNzAwMDAwMDAwLFxuICAgKiAgICAgICBcInJlZnJlc2hfdG9rZW5cIjogXCI8UkVGUkVTSF9UT0tFTj5cIixcbiAgICogICAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlcnNcIjogW1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCJcbiAgICogICAgICAgICAgIF1cbiAgICogICAgICAgICB9LFxuICAgKiAgICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7fSxcbiAgICogICAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgICAge1xuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjIyMjIyMjItMjIyMi0yMjIyLTIyMjItMjIyMjIyMjIyMjIyXCIsXG4gICAqICAgICAgICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgICAgXCJ1c2VyX2lkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICAgIFwiaWRlbnRpdHlfZGF0YVwiOiB7XG4gICAqICAgICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICAgICAgXCJlbWFpbF92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICAgICAgfSxcbiAgICogICAgICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICAgIH1cbiAgICogICAgICAgICBdLFxuICAgKiAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIlxuICAgKiAgICAgICB9XG4gICAqICAgICB9XG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU2lnbiB1cCB3aXRoIGEgcGhvbmUgbnVtYmVyIGFuZCBwYXNzd29yZCAoU01TKVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25VcCh7XG4gICAqICAgcGhvbmU6ICcxMjM0NTY3ODknLFxuICAgKiAgIHBhc3N3b3JkOiAnZXhhbXBsZS1wYXNzd29yZCcsXG4gICAqICAgb3B0aW9uczoge1xuICAgKiAgICAgY2hhbm5lbDogJ3NtcydcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFNpZ24gdXAgd2l0aCBhIHBob25lIG51bWJlciBhbmQgcGFzc3dvcmQgKHdoYXRzYXBwKVxuICAgKiBUaGUgdXNlciB3aWxsIGJlIHNlbnQgYSBXaGF0c0FwcCBtZXNzYWdlIHdoaWNoIGNvbnRhaW5zIGEgT1RQLiBCeSBkZWZhdWx0LCBhIGdpdmVuIHVzZXIgY2FuIG9ubHkgcmVxdWVzdCBhIE9UUCBvbmNlIGV2ZXJ5IDYwIHNlY29uZHMuIE5vdGUgdGhhdCBhIHVzZXIgd2lsbCBuZWVkIHRvIGhhdmUgYSB2YWxpZCBXaGF0c0FwcCBhY2NvdW50IHRoYXQgaXMgbGlua2VkIHRvIFR3aWxpbyBpbiBvcmRlciB0byB1c2UgdGhpcyBmZWF0dXJlLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIHVwIHdpdGggYSBwaG9uZSBudW1iZXIgYW5kIHBhc3N3b3JkICh3aGF0c2FwcClcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduVXAoe1xuICAgKiAgIHBob25lOiAnMTIzNDU2Nzg5JyxcbiAgICogICBwYXNzd29yZDogJ2V4YW1wbGUtcGFzc3dvcmQnLFxuICAgKiAgIG9wdGlvbnM6IHtcbiAgICogICAgIGNoYW5uZWw6ICd3aGF0c2FwcCdcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIHVwIHdpdGggYWRkaXRpb25hbCB1c2VyIG1ldGFkYXRhXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnblVwKFxuICAgKiAgIHtcbiAgICogICAgIGVtYWlsOiAnZXhhbXBsZUBlbWFpbC5jb20nLFxuICAgKiAgICAgcGFzc3dvcmQ6ICdleGFtcGxlLXBhc3N3b3JkJyxcbiAgICogICAgIG9wdGlvbnM6IHtcbiAgICogICAgICAgZGF0YToge1xuICAgKiAgICAgICAgIGZpcnN0X25hbWU6ICdKb2huJyxcbiAgICogICAgICAgICBhZ2U6IDI3LFxuICAgKiAgICAgICB9XG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiApXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFNpZ24gdXAgd2l0aCBhIHJlZGlyZWN0IFVSTFxuICAgKiAtIFNlZSBbcmVkaXJlY3QgVVJMcyBhbmQgd2lsZGNhcmRzXSgvZG9jcy9ndWlkZXMvYXV0aC9yZWRpcmVjdC11cmxzI3VzZS13aWxkY2FyZHMtaW4tcmVkaXJlY3QtdXJscykgdG8gYWRkIGFkZGl0aW9uYWwgcmVkaXJlY3QgVVJMcyB0byB5b3VyIHByb2plY3QuXG4gICAqXG4gICAqIEBleGFtcGxlIFNpZ24gdXAgd2l0aCBhIHJlZGlyZWN0IFVSTFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25VcChcbiAgICogICB7XG4gICAqICAgICBlbWFpbDogJ2V4YW1wbGVAZW1haWwuY29tJyxcbiAgICogICAgIHBhc3N3b3JkOiAnZXhhbXBsZS1wYXNzd29yZCcsXG4gICAqICAgICBvcHRpb25zOiB7XG4gICAqICAgICAgIGVtYWlsUmVkaXJlY3RUbzogJ2h0dHBzOi8vZXhhbXBsZS5jb20vd2VsY29tZSdcbiAgICogICAgIH1cbiAgICogICB9XG4gICAqIClcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBzaWduVXAoY3JlZGVudGlhbHM6IFNpZ25VcFdpdGhQYXNzd29yZENyZWRlbnRpYWxzKTogUHJvbWlzZTxBdXRoUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgbGV0IHJlczogQXV0aFJlc3BvbnNlXG4gICAgICBpZiAoJ2VtYWlsJyBpbiBjcmVkZW50aWFscykge1xuICAgICAgICBjb25zdCB7IGVtYWlsLCBwYXNzd29yZCwgb3B0aW9ucyB9ID0gY3JlZGVudGlhbHNcbiAgICAgICAgbGV0IGNvZGVDaGFsbGVuZ2U6IHN0cmluZyB8IG51bGwgPSBudWxsXG4gICAgICAgIGxldCBjb2RlQ2hhbGxlbmdlTWV0aG9kOiBzdHJpbmcgfCBudWxsID0gbnVsbFxuICAgICAgICBpZiAodGhpcy5mbG93VHlwZSA9PT0gJ3BrY2UnKSB7XG4gICAgICAgICAgO1tjb2RlQ2hhbGxlbmdlLCBjb2RlQ2hhbGxlbmdlTWV0aG9kXSA9IGF3YWl0IGdldENvZGVDaGFsbGVuZ2VBbmRNZXRob2QoXG4gICAgICAgICAgICB0aGlzLnN0b3JhZ2UsXG4gICAgICAgICAgICB0aGlzLnN0b3JhZ2VLZXlcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgICAgcmVzID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vc2lnbnVwYCwge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICByZWRpcmVjdFRvOiBvcHRpb25zPy5lbWFpbFJlZGlyZWN0VG8sXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgZW1haWwsXG4gICAgICAgICAgICBwYXNzd29yZCxcbiAgICAgICAgICAgIGRhdGE6IG9wdGlvbnM/LmRhdGEgPz8ge30sXG4gICAgICAgICAgICBnb3RydWVfbWV0YV9zZWN1cml0eTogeyBjYXB0Y2hhX3Rva2VuOiBvcHRpb25zPy5jYXB0Y2hhVG9rZW4gfSxcbiAgICAgICAgICAgIGNvZGVfY2hhbGxlbmdlOiBjb2RlQ2hhbGxlbmdlLFxuICAgICAgICAgICAgY29kZV9jaGFsbGVuZ2VfbWV0aG9kOiBjb2RlQ2hhbGxlbmdlTWV0aG9kLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgeGZvcm06IF9zZXNzaW9uUmVzcG9uc2UsXG4gICAgICAgIH0pXG4gICAgICB9IGVsc2UgaWYgKCdwaG9uZScgaW4gY3JlZGVudGlhbHMpIHtcbiAgICAgICAgY29uc3QgeyBwaG9uZSwgcGFzc3dvcmQsIG9wdGlvbnMgfSA9IGNyZWRlbnRpYWxzXG4gICAgICAgIHJlcyA9IGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdQT1NUJywgYCR7dGhpcy51cmx9L3NpZ251cGAsIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcGhvbmUsXG4gICAgICAgICAgICBwYXNzd29yZCxcbiAgICAgICAgICAgIGRhdGE6IG9wdGlvbnM/LmRhdGEgPz8ge30sXG4gICAgICAgICAgICBjaGFubmVsOiBvcHRpb25zPy5jaGFubmVsID8/ICdzbXMnLFxuICAgICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogb3B0aW9ucz8uY2FwdGNoYVRva2VuIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB4Zm9ybTogX3Nlc3Npb25SZXNwb25zZSxcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBBdXRoSW52YWxpZENyZWRlbnRpYWxzRXJyb3IoXG4gICAgICAgICAgJ1lvdSBtdXN0IHByb3ZpZGUgZWl0aGVyIGFuIGVtYWlsIG9yIHBob25lIG51bWJlciBhbmQgYSBwYXNzd29yZCdcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSByZXNcblxuICAgICAgaWYgKGVycm9yIHx8ICFkYXRhKSB7XG4gICAgICAgIGF3YWl0IHJlbW92ZUl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIGAke3RoaXMuc3RvcmFnZUtleX0tY29kZS12ZXJpZmllcmApXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IG51bGwsIHNlc3Npb246IG51bGwgfSwgZXJyb3I6IGVycm9yIH0pXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHNlc3Npb246IFNlc3Npb24gfCBudWxsID0gZGF0YS5zZXNzaW9uXG4gICAgICBjb25zdCB1c2VyOiBVc2VyIHwgbnVsbCA9IGRhdGEudXNlclxuXG4gICAgICBpZiAoZGF0YS5zZXNzaW9uKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuX3NhdmVTZXNzaW9uKGRhdGEuc2Vzc2lvbilcbiAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoJ1NJR05FRF9JTicsIHNlc3Npb24pXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXIsIHNlc3Npb24gfSwgZXJyb3I6IG51bGwgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBMb2cgaW4gYW4gZXhpc3RpbmcgdXNlciB3aXRoIGFuIGVtYWlsIGFuZCBwYXNzd29yZCBvciBwaG9uZSBhbmQgcGFzc3dvcmQuXG4gICAqXG4gICAqIEJlIGF3YXJlIHRoYXQgeW91IG1heSBnZXQgYmFjayBhbiBlcnJvciBtZXNzYWdlIHRoYXQgd2lsbCBub3QgZGlzdGluZ3Vpc2hcbiAgICogYmV0d2VlbiB0aGUgY2FzZXMgd2hlcmUgdGhlIGFjY291bnQgZG9lcyBub3QgZXhpc3Qgb3IgdGhhdCB0aGVcbiAgICogZW1haWwvcGhvbmUgYW5kIHBhc3N3b3JkIGNvbWJpbmF0aW9uIGlzIHdyb25nIG9yIHRoYXQgdGhlIGFjY291bnQgY2FuIG9ubHlcbiAgICogYmUgYWNjZXNzZWQgdmlhIHNvY2lhbCBsb2dpbi5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSZXF1aXJlcyBlaXRoZXIgYW4gZW1haWwgYW5kIHBhc3N3b3JkIG9yIGEgcGhvbmUgbnVtYmVyIGFuZCBwYXNzd29yZC5cbiAgICpcbiAgICogQGV4YW1wbGUgU2lnbiBpbiB3aXRoIGVtYWlsIGFuZCBwYXNzd29yZFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhQYXNzd29yZCh7XG4gICAqICAgZW1haWw6ICdleGFtcGxlQGVtYWlsLmNvbScsXG4gICAqICAgcGFzc3dvcmQ6ICdleGFtcGxlLXBhc3N3b3JkJyxcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgU2lnbiBpbiB3aXRoIGVtYWlsIGFuZCBwYXNzd29yZFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICBcImF1ZFwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgXCJlbWFpbF9jb25maXJtZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgIFwicHJvdmlkZXJzXCI6IFtcbiAgICogICAgICAgICAgIFwiZW1haWxcIlxuICAgKiAgICAgICAgIF1cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHt9LFxuICAgKiAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIF0sXG4gICAqICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCJcbiAgICogICAgIH0sXG4gICAqICAgICBcInNlc3Npb25cIjoge1xuICAgKiAgICAgICBcImFjY2Vzc190b2tlblwiOiBcIjxBQ0NFU1NfVE9LRU4+XCIsXG4gICAqICAgICAgIFwidG9rZW5fdHlwZVwiOiBcImJlYXJlclwiLFxuICAgKiAgICAgICBcImV4cGlyZXNfaW5cIjogMzYwMCxcbiAgICogICAgICAgXCJleHBpcmVzX2F0XCI6IDE3MDAwMDAwMDAsXG4gICAqICAgICAgIFwicmVmcmVzaF90b2tlblwiOiBcIjxSRUZSRVNIX1RPS0VOPlwiLFxuICAgKiAgICAgICBcInVzZXJcIjoge1xuICAgKiAgICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICBcImF1ZFwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgICBcInJvbGVcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgXCJlbWFpbF9jb25maXJtZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwicGhvbmVcIjogXCJcIixcbiAgICogICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyc1wiOiBbXG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIlxuICAgKiAgICAgICAgICAgXVxuICAgKiAgICAgICAgIH0sXG4gICAqICAgICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHt9LFxuICAgKiAgICAgICAgIFwiaWRlbnRpdGllc1wiOiBbXG4gICAqICAgICAgICAgICB7XG4gICAqICAgICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgICBcInVzZXJfaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIlxuICAgKiAgICAgICAgICAgfVxuICAgKiAgICAgICAgIF0sXG4gICAqICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiXG4gICAqICAgICAgIH1cbiAgICogICAgIH1cbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIGluIHdpdGggcGhvbmUgYW5kIHBhc3N3b3JkXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aFBhc3N3b3JkKHtcbiAgICogICBwaG9uZTogJysxMzMzNDQ0NTU1NScsXG4gICAqICAgcGFzc3dvcmQ6ICdzb21lLXBhc3N3b3JkJyxcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gSGFuZGxpbmcgZXJyb3JzXG4gICAqIExvZyB0aGUgZnVsbCBgZXJyb3JgIG9iamVjdCBzbyBmaWVsZHMgbGlrZSBgY29kZWAsIGBzdGF0dXNgLCBhbmQgYG5hbWVgIGFyZW4ndCBoaWRkZW4uIFRoZSBgZXJyb3IuY29kZWAgKGUuZy4gYCdpbnZhbGlkX2NyZWRlbnRpYWxzJ2AsIGAnZW1haWxfbm90X2NvbmZpcm1lZCdgKSBpcyBvZnRlbiBtb3JlIHVzZWZ1bCBmb3IgYnJhbmNoaW5nIHRoYW4gYGVycm9yLm1lc3NhZ2VgLCBhbmQgdGhlIGZ1bGwgb2JqZWN0IHN1cmZhY2VzIGJvdGguXG4gICAqXG4gICAqIEBleGFtcGxlIEhhbmRsaW5nIGVycm9yc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhQYXNzd29yZCh7XG4gICAqICAgZW1haWw6ICdleGFtcGxlQGVtYWlsLmNvbScsXG4gICAqICAgcGFzc3dvcmQ6ICdleGFtcGxlLXBhc3N3b3JkJyxcbiAgICogfSlcbiAgICogaWYgKGVycm9yKSB7XG4gICAqICAgY29uc29sZS5lcnJvcihlcnJvcilcbiAgICogICByZXR1cm5cbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIHNpZ25JbldpdGhQYXNzd29yZChcbiAgICBjcmVkZW50aWFsczogU2lnbkluV2l0aFBhc3N3b3JkQ3JlZGVudGlhbHNcbiAgKTogUHJvbWlzZTxBdXRoVG9rZW5SZXNwb25zZVBhc3N3b3JkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGxldCByZXM6IEF1dGhSZXNwb25zZVBhc3N3b3JkXG4gICAgICBpZiAoJ2VtYWlsJyBpbiBjcmVkZW50aWFscykge1xuICAgICAgICBjb25zdCB7IGVtYWlsLCBwYXNzd29yZCwgb3B0aW9ucyB9ID0gY3JlZGVudGlhbHNcbiAgICAgICAgcmVzID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vdG9rZW4/Z3JhbnRfdHlwZT1wYXNzd29yZGAsIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgZW1haWwsXG4gICAgICAgICAgICBwYXNzd29yZCxcbiAgICAgICAgICAgIGdvdHJ1ZV9tZXRhX3NlY3VyaXR5OiB7IGNhcHRjaGFfdG9rZW46IG9wdGlvbnM/LmNhcHRjaGFUb2tlbiB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgeGZvcm06IF9zZXNzaW9uUmVzcG9uc2VQYXNzd29yZCxcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSBpZiAoJ3Bob25lJyBpbiBjcmVkZW50aWFscykge1xuICAgICAgICBjb25zdCB7IHBob25lLCBwYXNzd29yZCwgb3B0aW9ucyB9ID0gY3JlZGVudGlhbHNcbiAgICAgICAgcmVzID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vdG9rZW4/Z3JhbnRfdHlwZT1wYXNzd29yZGAsIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcGhvbmUsXG4gICAgICAgICAgICBwYXNzd29yZCxcbiAgICAgICAgICAgIGdvdHJ1ZV9tZXRhX3NlY3VyaXR5OiB7IGNhcHRjaGFfdG9rZW46IG9wdGlvbnM/LmNhcHRjaGFUb2tlbiB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgeGZvcm06IF9zZXNzaW9uUmVzcG9uc2VQYXNzd29yZCxcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBBdXRoSW52YWxpZENyZWRlbnRpYWxzRXJyb3IoXG4gICAgICAgICAgJ1lvdSBtdXN0IHByb3ZpZGUgZWl0aGVyIGFuIGVtYWlsIG9yIHBob25lIG51bWJlciBhbmQgYSBwYXNzd29yZCdcbiAgICAgICAgKVxuICAgICAgfVxuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gcmVzXG5cbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9IGVsc2UgaWYgKCFkYXRhIHx8ICFkYXRhLnNlc3Npb24gfHwgIWRhdGEudXNlcikge1xuICAgICAgICBjb25zdCBpbnZhbGlkVG9rZW5FcnJvciA9IG5ldyBBdXRoSW52YWxpZFRva2VuUmVzcG9uc2VFcnJvcigpXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IG51bGwsIHNlc3Npb246IG51bGwgfSwgZXJyb3I6IGludmFsaWRUb2tlbkVycm9yIH0pXG4gICAgICB9XG4gICAgICBpZiAoZGF0YS5zZXNzaW9uKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuX3NhdmVTZXNzaW9uKGRhdGEuc2Vzc2lvbilcbiAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoJ1NJR05FRF9JTicsIGRhdGEuc2Vzc2lvbilcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoe1xuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgdXNlcjogZGF0YS51c2VyLFxuICAgICAgICAgIHNlc3Npb246IGRhdGEuc2Vzc2lvbixcbiAgICAgICAgICAuLi4oZGF0YS53ZWFrX3Bhc3N3b3JkID8geyB3ZWFrUGFzc3dvcmQ6IGRhdGEud2Vha19wYXNzd29yZCB9IDogbnVsbCksXG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBMb2cgaW4gYW4gZXhpc3RpbmcgdXNlciB2aWEgYSB0aGlyZC1wYXJ0eSBwcm92aWRlci5cbiAgICogVGhpcyBtZXRob2Qgc3VwcG9ydHMgdGhlIFBLQ0UgZmxvdy5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBUaGlzIG1ldGhvZCBpcyB1c2VkIGZvciBzaWduaW5nIGluIHVzaW5nIFtTb2NpYWwgTG9naW4gKE9BdXRoKSBwcm92aWRlcnNdKC9kb2NzL2d1aWRlcy9hdXRoI2NvbmZpZ3VyZS10aGlyZC1wYXJ0eS1wcm92aWRlcnMpLlxuICAgKiAtIEl0IHdvcmtzIGJ5IHJlZGlyZWN0aW5nIHlvdXIgYXBwbGljYXRpb24gdG8gdGhlIHByb3ZpZGVyJ3MgYXV0aG9yaXphdGlvbiBzY3JlZW4sIGJlZm9yZSBicmluZ2luZyBiYWNrIHRoZSB1c2VyIHRvIHlvdXIgYXBwLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIGluIHVzaW5nIGEgdGhpcmQtcGFydHkgcHJvdmlkZXJcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduSW5XaXRoT0F1dGgoe1xuICAgKiAgIHByb3ZpZGVyOiAnZ2l0aHViJ1xuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBTaWduIGluIHVzaW5nIGEgdGhpcmQtcGFydHkgcHJvdmlkZXJcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgZGF0YToge1xuICAgKiAgICAgcHJvdmlkZXI6ICdnaXRodWInLFxuICAgKiAgICAgdXJsOiA8UFJPVklERVJfVVJMX1RPX1JFRElSRUNUX1RPPlxuICAgKiAgIH0sXG4gICAqICAgZXJyb3I6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBTaWduIGluIHVzaW5nIGEgdGhpcmQtcGFydHkgcHJvdmlkZXIgd2l0aCByZWRpcmVjdFxuICAgKiAtIFdoZW4gdGhlIE9BdXRoIHByb3ZpZGVyIHN1Y2Nlc3NmdWxseSBhdXRoZW50aWNhdGVzIHRoZSB1c2VyLCB0aGV5IGFyZSByZWRpcmVjdGVkIHRvIHRoZSBVUkwgc3BlY2lmaWVkIGluIHRoZSBgcmVkaXJlY3RUb2AgcGFyYW1ldGVyLiBUaGlzIHBhcmFtZXRlciBkZWZhdWx0cyB0byB0aGUgW2BTSVRFX1VSTGBdKC9kb2NzL2d1aWRlcy9hdXRoL3JlZGlyZWN0LXVybHMjdXNlLXdpbGRjYXJkcy1pbi1yZWRpcmVjdC11cmxzKS4gSXQgZG9lcyBub3QgcmVkaXJlY3QgdGhlIHVzZXIgaW1tZWRpYXRlbHkgYWZ0ZXIgaW52b2tpbmcgdGhpcyBtZXRob2QuXG4gICAqIC0gU2VlIFtyZWRpcmVjdCBVUkxzIGFuZCB3aWxkY2FyZHNdKC9kb2NzL2d1aWRlcy9hdXRoL3JlZGlyZWN0LXVybHMjdXNlLXdpbGRjYXJkcy1pbi1yZWRpcmVjdC11cmxzKSB0byBhZGQgYWRkaXRpb25hbCByZWRpcmVjdCBVUkxzIHRvIHlvdXIgcHJvamVjdC5cbiAgICpcbiAgICogQGV4YW1wbGUgU2lnbiBpbiB1c2luZyBhIHRoaXJkLXBhcnR5IHByb3ZpZGVyIHdpdGggcmVkaXJlY3RcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduSW5XaXRoT0F1dGgoe1xuICAgKiAgIHByb3ZpZGVyOiAnZ2l0aHViJyxcbiAgICogICBvcHRpb25zOiB7XG4gICAqICAgICByZWRpcmVjdFRvOiAnaHR0cHM6Ly9leGFtcGxlLmNvbS93ZWxjb21lJ1xuICAgKiAgIH1cbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gU2lnbiBpbiB3aXRoIHNjb3BlcyBhbmQgYWNjZXNzIHByb3ZpZGVyIHRva2Vuc1xuICAgKiBJZiB5b3UgbmVlZCBhZGRpdGlvbmFsIGFjY2VzcyBmcm9tIGFuIE9BdXRoIHByb3ZpZGVyLCBpbiBvcmRlciB0byBhY2Nlc3MgcHJvdmlkZXIgc3BlY2lmaWMgQVBJcyBpbiB0aGUgbmFtZSBvZiB0aGUgdXNlciwgeW91IGNhbiBkbyB0aGlzIGJ5IHBhc3NpbmcgaW4gdGhlIHNjb3BlcyB0aGUgdXNlciBzaG91bGQgYXV0aG9yaXplIGZvciB5b3VyIGFwcGxpY2F0aW9uLiBOb3RlIHRoYXQgdGhlIGBzY29wZXNgIG9wdGlvbiB0YWtlcyBpbiAqKmEgc3BhY2Utc2VwYXJhdGVkIGxpc3QqKiBvZiBzY29wZXMuXG4gICAqXG4gICAqIEJlY2F1c2UgT0F1dGggc2lnbi1pbiBvZnRlbiBpbmNsdWRlcyByZWRpcmVjdHMsIHlvdSBzaG91bGQgcmVnaXN0ZXIgYW4gYG9uQXV0aFN0YXRlQ2hhbmdlYCBjYWxsYmFjayBpbW1lZGlhdGVseSBhZnRlciB5b3UgY3JlYXRlIHRoZSBTdXBhYmFzZSBjbGllbnQuIFRoaXMgY2FsbGJhY2sgd2lsbCBsaXN0ZW4gZm9yIHRoZSBwcmVzZW5jZSBvZiBgcHJvdmlkZXJfdG9rZW5gIGFuZCBgcHJvdmlkZXJfcmVmcmVzaF90b2tlbmAgcHJvcGVydGllcyBvbiB0aGUgYHNlc3Npb25gIG9iamVjdCBhbmQgc3RvcmUgdGhlbSBpbiBsb2NhbCBzdG9yYWdlLiBUaGUgY2xpZW50IGxpYnJhcnkgd2lsbCBlbWl0IHRoZXNlIHZhbHVlcyAqKm9ubHkgb25jZSoqIGltbWVkaWF0ZWx5IGFmdGVyIHRoZSB1c2VyIHNpZ25zIGluLiBZb3UgY2FuIHRoZW4gYWNjZXNzIHRoZW0gYnkgbG9va2luZyB0aGVtIHVwIGluIGxvY2FsIHN0b3JhZ2UsIG9yIHNlbmQgdGhlbSB0byB5b3VyIGJhY2tlbmQgc2VydmVycyBmb3IgZnVydGhlciBwcm9jZXNzaW5nLlxuICAgKlxuICAgKiBGaW5hbGx5LCBtYWtlIHN1cmUgeW91IHJlbW92ZSB0aGVtIGZyb20gbG9jYWwgc3RvcmFnZSBvbiB0aGUgYFNJR05FRF9PVVRgIGV2ZW50LiBJZiB0aGUgT0F1dGggcHJvdmlkZXIgc3VwcG9ydHMgdG9rZW4gcmV2b2NhdGlvbiwgbWFrZSBzdXJlIHlvdSBjYWxsIHRob3NlIEFQSXMgZWl0aGVyIGZyb20gdGhlIGZyb250ZW5kIG9yIHNjaGVkdWxlIHRoZW0gdG8gYmUgY2FsbGVkIG9uIHRoZSBiYWNrZW5kLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIGluIHdpdGggc2NvcGVzIGFuZCBhY2Nlc3MgcHJvdmlkZXIgdG9rZW5zXG4gICAqIGBgYGpzXG4gICAqIC8vIFJlZ2lzdGVyIHRoaXMgaW1tZWRpYXRlbHkgYWZ0ZXIgY2FsbGluZyBjcmVhdGVDbGllbnQhXG4gICAqIC8vIEJlY2F1c2Ugc2lnbkluV2l0aE9BdXRoIGNhdXNlcyBhIHJlZGlyZWN0LCB5b3UgbmVlZCB0byBmZXRjaCB0aGVcbiAgICogLy8gcHJvdmlkZXIgdG9rZW5zIGZyb20gdGhlIGNhbGxiYWNrLlxuICAgKiBzdXBhYmFzZS5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKChldmVudCwgc2Vzc2lvbikgPT4ge1xuICAgKiAgIGlmIChzZXNzaW9uICYmIHNlc3Npb24ucHJvdmlkZXJfdG9rZW4pIHtcbiAgICogICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnb2F1dGhfcHJvdmlkZXJfdG9rZW4nLCBzZXNzaW9uLnByb3ZpZGVyX3Rva2VuKVxuICAgKiAgIH1cbiAgICpcbiAgICogICBpZiAoc2Vzc2lvbiAmJiBzZXNzaW9uLnByb3ZpZGVyX3JlZnJlc2hfdG9rZW4pIHtcbiAgICogICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnb2F1dGhfcHJvdmlkZXJfcmVmcmVzaF90b2tlbicsIHNlc3Npb24ucHJvdmlkZXJfcmVmcmVzaF90b2tlbilcbiAgICogICB9XG4gICAqXG4gICAqICAgaWYgKGV2ZW50ID09PSAnU0lHTkVEX09VVCcpIHtcbiAgICogICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnb2F1dGhfcHJvdmlkZXJfdG9rZW4nKVxuICAgKiAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdvYXV0aF9wcm92aWRlcl9yZWZyZXNoX3Rva2VuJylcbiAgICogICB9XG4gICAqIH0pXG4gICAqXG4gICAqIC8vIENhbGwgdGhpcyBvbiB5b3VyIFNpZ24gaW4gd2l0aCBHaXRIdWIgYnV0dG9uIHRvIGluaXRpYXRlIE9BdXRoXG4gICAqIC8vIHdpdGggR2l0SHViIHdpdGggdGhlIHJlcXVlc3RlZCBlbGV2YXRlZCBzY29wZXMuXG4gICAqIGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aE9BdXRoKHtcbiAgICogICBwcm92aWRlcjogJ2dpdGh1YicsXG4gICAqICAgb3B0aW9uczoge1xuICAgKiAgICAgc2NvcGVzOiAncmVwbyBnaXN0IG5vdGlmaWNhdGlvbnMnXG4gICAqICAgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIHNpZ25JbldpdGhPQXV0aChjcmVkZW50aWFsczogU2lnbkluV2l0aE9BdXRoQ3JlZGVudGlhbHMpOiBQcm9taXNlPE9BdXRoUmVzcG9uc2U+IHtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5faGFuZGxlUHJvdmlkZXJTaWduSW4oY3JlZGVudGlhbHMucHJvdmlkZXIsIHtcbiAgICAgIHJlZGlyZWN0VG86IGNyZWRlbnRpYWxzLm9wdGlvbnM/LnJlZGlyZWN0VG8sXG4gICAgICBzY29wZXM6IGNyZWRlbnRpYWxzLm9wdGlvbnM/LnNjb3BlcyxcbiAgICAgIHF1ZXJ5UGFyYW1zOiBjcmVkZW50aWFscy5vcHRpb25zPy5xdWVyeVBhcmFtcyxcbiAgICAgIHNraXBCcm93c2VyUmVkaXJlY3Q6IGNyZWRlbnRpYWxzLm9wdGlvbnM/LnNraXBCcm93c2VyUmVkaXJlY3QsXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2cgaW4gYW4gZXhpc3RpbmcgdXNlciBieSBleGNoYW5naW5nIGFuIEF1dGggQ29kZSBpc3N1ZWQgZHVyaW5nIHRoZSBQS0NFIGZsb3cuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVXNlZCB3aGVuIGBmbG93VHlwZWAgaXMgc2V0IHRvIGBwa2NlYCBpbiBjbGllbnQgb3B0aW9ucy5cbiAgICpcbiAgICogQGV4YW1wbGUgRXhjaGFuZ2UgQXV0aCBDb2RlXG4gICAqIGBgYGpzXG4gICAqIHN1cGFiYXNlLmF1dGguZXhjaGFuZ2VDb2RlRm9yU2Vzc2lvbignMzRlNzcwZGQtOWZmOS00MTZjLTg3ZmEtNDNiMzFkN2VmMjI1JylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgRXhjaGFuZ2UgQXV0aCBDb2RlXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBzZXNzaW9uOiB7XG4gICAqICAgICAgIGFjY2Vzc190b2tlbjogJzxBQ0NFU1NfVE9LRU4+JyxcbiAgICogICAgICAgdG9rZW5fdHlwZTogJ2JlYXJlcicsXG4gICAqICAgICAgIGV4cGlyZXNfaW46IDM2MDAsXG4gICAqICAgICAgIGV4cGlyZXNfYXQ6IDE3MDAwMDAwMDAsXG4gICAqICAgICAgIHJlZnJlc2hfdG9rZW46ICc8UkVGUkVTSF9UT0tFTj4nLFxuICAgKiAgICAgICB1c2VyOiB7XG4gICAqICAgICAgICAgaWQ6ICcxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTEnLFxuICAgKiAgICAgICAgIGF1ZDogJ2F1dGhlbnRpY2F0ZWQnLFxuICAgKiAgICAgICAgIHJvbGU6ICdhdXRoZW50aWNhdGVkJyxcbiAgICogICAgICAgICBlbWFpbDogJ2V4YW1wbGVAZW1haWwuY29tJ1xuICAgKiAgICAgICAgIGVtYWlsX2NvbmZpcm1lZF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgICBwaG9uZTogJycsXG4gICAqICAgICAgICAgY29uZmlybWF0aW9uX3NlbnRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgICAgY29uZmlybWVkX2F0OiAnMjAyNC0wMS0wMVQwMDowMDowMFonLFxuICAgKiAgICAgICAgIGxhc3Rfc2lnbl9pbl9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgICBhcHBfbWV0YWRhdGE6IHtcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlcnNcIjogW1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICAgIFwiPE9USEVSX1BST1ZJREVSPlwiXG4gICAqICAgICAgICAgICBdXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgICB1c2VyX21ldGFkYXRhOiB7XG4gICAqICAgICAgICAgICBlbWFpbDogJ2VtYWlsQGVtYWlsLmNvbScsXG4gICAqICAgICAgICAgICBlbWFpbF92ZXJpZmllZDogdHJ1ZSxcbiAgICogICAgICAgICAgIGZ1bGxfbmFtZTogJ1VzZXIgTmFtZScsXG4gICAqICAgICAgICAgICBpc3M6ICc8SVNTPicsXG4gICAqICAgICAgICAgICBuYW1lOiAnVXNlciBOYW1lJyxcbiAgICogICAgICAgICAgIHBob25lX3ZlcmlmaWVkOiBmYWxzZSxcbiAgICogICAgICAgICAgIHByb3ZpZGVyX2lkOiAnPFBST1ZJREVSX0lEPicsXG4gICAqICAgICAgICAgICBzdWI6ICc8U1VCPidcbiAgICogICAgICAgICB9LFxuICAgKiAgICAgICAgIGlkZW50aXRpZXM6IFtcbiAgICogICAgICAgICAgIHtcbiAgICogICAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjIyMjIyMjIyLTIyMjItMjIyMi0yMjIyLTIyMjIyMjIyMjIyMlwiLFxuICAgKiAgICAgICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIjogXCJlbWFpbEBleGFtcGxlLmNvbVwiXG4gICAqICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAge1xuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMzMzMzMzMzMtMzMzMy0zMzMzLTMzMzMtMzMzMzMzMzMzMzMzXCIsXG4gICAqICAgICAgICAgICAgIFwiaWRcIjogXCI8SUQ+XCIsXG4gICAqICAgICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjxVU0VSX0lEPlwiLFxuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogdHJ1ZSxcbiAgICogICAgICAgICAgICAgICBcImZ1bGxfbmFtZVwiOiBcIlVzZXIgTmFtZVwiLFxuICAgKiAgICAgICAgICAgICAgIFwiaXNzXCI6IFwiPElTUz5cIixcbiAgICogICAgICAgICAgICAgICBcIm5hbWVcIjogXCJVc2VyIE5hbWVcIixcbiAgICogICAgICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICAgIFwicHJvdmlkZXJfaWRcIjogXCI8UFJPVklERVJfSUQ+XCIsXG4gICAqICAgICAgICAgICAgICAgXCJzdWJcIjogXCI8U1VCPlwiXG4gICAqICAgICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICAgIFwicHJvdmlkZXJcIjogXCI8UFJPVklERVI+XCIsXG4gICAqICAgICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICAgIH1cbiAgICogICAgICAgICBdLFxuICAgKiAgICAgICAgIGNyZWF0ZWRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgICAgdXBkYXRlZF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgICBpc19hbm9ueW1vdXM6IGZhbHNlXG4gICAqICAgICAgIH0sXG4gICAqICAgICAgIHByb3ZpZGVyX3Rva2VuOiAnPFBST1ZJREVSX1RPS0VOPicsXG4gICAqICAgICAgIHByb3ZpZGVyX3JlZnJlc2hfdG9rZW46ICc8UFJPVklERVJfUkVGUkVTSF9UT0tFTj4nXG4gICAqICAgICB9LFxuICAgKiAgICAgdXNlcjoge1xuICAgKiAgICAgICBpZDogJzExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMScsXG4gICAqICAgICAgIGF1ZDogJ2F1dGhlbnRpY2F0ZWQnLFxuICAgKiAgICAgICByb2xlOiAnYXV0aGVudGljYXRlZCcsXG4gICAqICAgICAgIGVtYWlsOiAnZXhhbXBsZUBlbWFpbC5jb20nLFxuICAgKiAgICAgICBlbWFpbF9jb25maXJtZWRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIHBob25lOiAnJyxcbiAgICogICAgICAgY29uZmlybWF0aW9uX3NlbnRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIGNvbmZpcm1lZF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgbGFzdF9zaWduX2luX2F0OiAnMjAyNC0wMS0wMVQwMDowMDowMFonLFxuICAgKiAgICAgICBhcHBfbWV0YWRhdGE6IHtcbiAgICogICAgICAgICBwcm92aWRlcjogJ2VtYWlsJyxcbiAgICogICAgICAgICBwcm92aWRlcnM6IFtcbiAgICogICAgICAgICAgIFwiZW1haWxcIixcbiAgICogICAgICAgICAgIFwiPE9USEVSX1BST1ZJREVSPlwiXG4gICAqICAgICAgICAgXVxuICAgKiAgICAgICB9LFxuICAgKiAgICAgICB1c2VyX21ldGFkYXRhOiB7XG4gICAqICAgICAgICAgZW1haWw6ICdlbWFpbEBlbWFpbC5jb20nLFxuICAgKiAgICAgICAgIGVtYWlsX3ZlcmlmaWVkOiB0cnVlLFxuICAgKiAgICAgICAgIGZ1bGxfbmFtZTogJ1VzZXIgTmFtZScsXG4gICAqICAgICAgICAgaXNzOiAnPElTUz4nLFxuICAgKiAgICAgICAgIG5hbWU6ICdVc2VyIE5hbWUnLFxuICAgKiAgICAgICAgIHBob25lX3ZlcmlmaWVkOiBmYWxzZSxcbiAgICogICAgICAgICBwcm92aWRlcl9pZDogJzxQUk9WSURFUl9JRD4nLFxuICAgKiAgICAgICAgIHN1YjogJzxTVUI+J1xuICAgKiAgICAgICB9LFxuICAgKiAgICAgICBpZGVudGl0aWVzOiBbXG4gICAqICAgICAgICAge1xuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjIyMjIyMjIyLTIyMjItMjIyMi0yMjIyLTIyMjIyMjIyMjIyMlwiLFxuICAgKiAgICAgICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJ1c2VyX2lkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgICAgXCJlbWFpbF92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgICAgfSxcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImVtYWlsXCI6IFwiZW1haWxAZXhhbXBsZS5jb21cIlxuICAgKiAgICAgICAgIH0sXG4gICAqICAgICAgICAge1xuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjMzMzMzMzMzLTMzMzMtMzMzMy0zMzMzLTMzMzMzMzMzMzMzM1wiLFxuICAgKiAgICAgICAgICAgXCJpZFwiOiBcIjxJRD5cIixcbiAgICogICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjxVU0VSX0lEPlwiLFxuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogdHJ1ZSxcbiAgICogICAgICAgICAgICAgXCJmdWxsX25hbWVcIjogXCJVc2VyIE5hbWVcIixcbiAgICogICAgICAgICAgICAgXCJpc3NcIjogXCI8SVNTPlwiLFxuICAgKiAgICAgICAgICAgICBcIm5hbWVcIjogXCJVc2VyIE5hbWVcIixcbiAgICogICAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgXCJwcm92aWRlcl9pZFwiOiBcIjxQUk9WSURFUl9JRD5cIixcbiAgICogICAgICAgICAgICAgXCJzdWJcIjogXCI8U1VCPlwiXG4gICAqICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlclwiOiBcIjxQUk9WSURFUj5cIixcbiAgICogICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIF0sXG4gICAqICAgICAgIGNyZWF0ZWRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIHVwZGF0ZWRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIGlzX2Fub255bW91czogZmFsc2VcbiAgICogICAgIH0sXG4gICAqICAgICByZWRpcmVjdFR5cGU6IG51bGxcbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgZXhjaGFuZ2VDb2RlRm9yU2Vzc2lvbihhdXRoQ29kZTogc3RyaW5nKTogUHJvbWlzZTxBdXRoVG9rZW5SZXNwb25zZT4ge1xuICAgIGF3YWl0IHRoaXMuaW5pdGlhbGl6ZVByb21pc2VcblxuICAgIGlmICh0aGlzLmxvY2sgIT0gbnVsbCkge1xuICAgICAgLy8gVE9ETyh2Myk6IHJlbW92ZSBsZWdhY3kgbG9jayBwYXRoXG4gICAgICByZXR1cm4gdGhpcy5fYWNxdWlyZUxvY2sodGhpcy5sb2NrQWNxdWlyZVRpbWVvdXQsIGFzeW5jICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2V4Y2hhbmdlQ29kZUZvclNlc3Npb24oYXV0aENvZGUpXG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl9leGNoYW5nZUNvZGVGb3JTZXNzaW9uKGF1dGhDb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIFNpZ25zIGluIGEgdXNlciBieSB2ZXJpZnlpbmcgYSBtZXNzYWdlIHNpZ25lZCBieSB0aGUgdXNlcidzIHByaXZhdGUga2V5LlxuICAgKiBTdXBwb3J0cyBFdGhlcmV1bSAodmlhIFNpZ24tSW4tV2l0aC1FdGhlcmV1bSkgJiBTb2xhbmEgKFNpZ24tSW4tV2l0aC1Tb2xhbmEpIHN0YW5kYXJkcyxcbiAgICogYm90aCBvZiB3aGljaCBkZXJpdmUgZnJvbSB0aGUgRUlQLTQzNjEgc3RhbmRhcmRcbiAgICogV2l0aCBzbGlnaHQgdmFyaWF0aW9uIG9uIFNvbGFuYSdzIHNpZGUuXG4gICAqIEByZWZlcmVuY2UgaHR0cHM6Ly9laXBzLmV0aGVyZXVtLm9yZy9FSVBTL2VpcC00MzYxXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVXNlcyBhIFdlYjMgKEV0aGVyZXVtLCBTb2xhbmEpIHdhbGxldCB0byBzaWduIGEgdXNlciBpbi5cbiAgICogLSBSZWFkIHVwIG9uIHRoZSBbcG90ZW50aWFsIGZvciBhYnVzZV0oL2RvY3MvZ3VpZGVzL2F1dGgvYXV0aC13ZWIzI3BvdGVudGlhbC1mb3ItYWJ1c2UpIGJlZm9yZSB1c2luZyBpdC5cbiAgICpcbiAgICogQGV4YW1wbGUgU2lnbiBpbiB3aXRoIFNvbGFuYSBvciBFdGhlcmV1bSAoV2luZG93IEFQSSlcbiAgICogYGBganNcbiAgICogICAvLyB1c2VzIHdpbmRvdy5ldGhlcmV1bSBmb3IgdGhlIHdhbGxldFxuICAgKiAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aFdlYjMoe1xuICAgKiAgICAgY2hhaW46ICdldGhlcmV1bScsXG4gICAqICAgICBzdGF0ZW1lbnQ6ICdJIGFjY2VwdCB0aGUgVGVybXMgb2YgU2VydmljZSBhdCBodHRwczovL2V4YW1wbGUuY29tL3RvcydcbiAgICogICB9KVxuICAgKlxuICAgKiAgIC8vIHVzZXMgd2luZG93LnNvbGFuYSBmb3IgdGhlIHdhbGxldFxuICAgKiAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aFdlYjMoe1xuICAgKiAgICAgY2hhaW46ICdzb2xhbmEnLFxuICAgKiAgICAgc3RhdGVtZW50OiAnSSBhY2NlcHQgdGhlIFRlcm1zIG9mIFNlcnZpY2UgYXQgaHR0cHM6Ly9leGFtcGxlLmNvbS90b3MnXG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFNpZ24gaW4gd2l0aCBFdGhlcmV1bSAoTWVzc2FnZSBhbmQgU2lnbmF0dXJlKVxuICAgKiBgYGBqc1xuICAgKiAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aFdlYjMoe1xuICAgKiAgICAgY2hhaW46ICdldGhlcmV1bScsXG4gICAqICAgICBtZXNzYWdlOiAnPHNpZ24gaW4gd2l0aCBldGhlcmV1bSBtZXNzYWdlPicsXG4gICAqICAgICBzaWduYXR1cmU6ICc8aGV4IG9mIHRoZSBldGhlcmV1bSBzaWduYXR1cmUgb3ZlciB0aGUgbWVzc2FnZT4nLFxuICAgKiAgIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIGluIHdpdGggU29sYW5hIChCcmF2ZSlcbiAgICogYGBganNcbiAgICogICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhXZWIzKHtcbiAgICogICAgIGNoYWluOiAnc29sYW5hJyxcbiAgICogICAgIHN0YXRlbWVudDogJ0kgYWNjZXB0IHRoZSBUZXJtcyBvZiBTZXJ2aWNlIGF0IGh0dHBzOi8vZXhhbXBsZS5jb20vdG9zJyxcbiAgICogICAgIHdhbGxldDogd2luZG93LmJyYXZlU29sYW5hXG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFNpZ24gaW4gd2l0aCBTb2xhbmEgKFdhbGxldCBBZGFwdGVyKVxuICAgKiBgYGBqc3hcbiAgICogICBmdW5jdGlvbiBTaWduSW5CdXR0b24oKSB7XG4gICAqICAgY29uc3Qgd2FsbGV0ID0gdXNlV2FsbGV0KClcbiAgICpcbiAgICogICByZXR1cm4gKFxuICAgKiAgICAgPD5cbiAgICogICAgICAge3dhbGxldC5jb25uZWN0ZWQgPyAoXG4gICAqICAgICAgICAgPGJ1dHRvblxuICAgKiAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgKiAgICAgICAgICAgICBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhXZWIzKHtcbiAgICogICAgICAgICAgICAgICBjaGFpbjogJ3NvbGFuYScsXG4gICAqICAgICAgICAgICAgICAgc3RhdGVtZW50OiAnSSBhY2NlcHQgdGhlIFRlcm1zIG9mIFNlcnZpY2UgYXQgaHR0cHM6Ly9leGFtcGxlLmNvbS90b3MnLFxuICAgKiAgICAgICAgICAgICAgIHdhbGxldCxcbiAgICogICAgICAgICAgICAgfSlcbiAgICogICAgICAgICAgIH19XG4gICAqICAgICAgICAgPlxuICAgKiAgICAgICAgICAgU2lnbiBpbiB3aXRoIFNvbGFuYVxuICAgKiAgICAgICAgIDwvYnV0dG9uPlxuICAgKiAgICAgICApIDogKFxuICAgKiAgICAgICAgIDxXYWxsZXRNdWx0aUJ1dHRvbiAvPlxuICAgKiAgICAgICApfVxuICAgKiAgICAgPC8+XG4gICAqICAgKVxuICAgKiB9XG4gICAqXG4gICAqIGZ1bmN0aW9uIEFwcCgpIHtcbiAgICogICBjb25zdCBlbmRwb2ludCA9IGNsdXN0ZXJBcGlVcmwoJ2Rldm5ldCcpXG4gICAqICAgY29uc3Qgd2FsbGV0cyA9IHVzZU1lbW8oKCkgPT4gW10sIFtdKVxuICAgKlxuICAgKiAgIHJldHVybiAoXG4gICAqICAgICA8Q29ubmVjdGlvblByb3ZpZGVyIGVuZHBvaW50PXtlbmRwb2ludH0+XG4gICAqICAgICAgIDxXYWxsZXRQcm92aWRlciB3YWxsZXRzPXt3YWxsZXRzfT5cbiAgICogICAgICAgICA8V2FsbGV0TW9kYWxQcm92aWRlcj5cbiAgICogICAgICAgICAgIDxTaWduSW5CdXR0b24gLz5cbiAgICogICAgICAgICA8L1dhbGxldE1vZGFsUHJvdmlkZXI+XG4gICAqICAgICAgIDwvV2FsbGV0UHJvdmlkZXI+XG4gICAqICAgICA8L0Nvbm5lY3Rpb25Qcm92aWRlcj5cbiAgICogICApXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBzaWduSW5XaXRoV2ViMyhjcmVkZW50aWFsczogV2ViM0NyZWRlbnRpYWxzKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogeyBzZXNzaW9uOiBTZXNzaW9uOyB1c2VyOiBVc2VyIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHsgZGF0YTogeyBzZXNzaW9uOiBudWxsOyB1c2VyOiBudWxsIH07IGVycm9yOiBBdXRoRXJyb3IgfVxuICA+IHtcbiAgICBjb25zdCB7IGNoYWluIH0gPSBjcmVkZW50aWFsc1xuXG4gICAgc3dpdGNoIChjaGFpbikge1xuICAgICAgY2FzZSAnZXRoZXJldW0nOlxuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5zaWduSW5XaXRoRXRoZXJldW0oY3JlZGVudGlhbHMpXG4gICAgICBjYXNlICdzb2xhbmEnOlxuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5zaWduSW5XaXRoU29sYW5hKGNyZWRlbnRpYWxzKVxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBAc3VwYWJhc2UvYXV0aC1qczogVW5zdXBwb3J0ZWQgY2hhaW4gXCIke2NoYWlufVwiYClcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHNpZ25JbldpdGhFdGhlcmV1bShcbiAgICBjcmVkZW50aWFsczogRXRoZXJldW1XZWIzQ3JlZGVudGlhbHNcbiAgKTogUHJvbWlzZTxcbiAgICB8IHsgZGF0YTogeyBzZXNzaW9uOiBTZXNzaW9uOyB1c2VyOiBVc2VyIH07IGVycm9yOiBudWxsIH1cbiAgICB8IHsgZGF0YTogeyBzZXNzaW9uOiBudWxsOyB1c2VyOiBudWxsIH07IGVycm9yOiBBdXRoRXJyb3IgfVxuICA+IHtcbiAgICAvLyBUT0RPOiBmbGF0dGVuIHR5cGVcbiAgICBsZXQgbWVzc2FnZTogc3RyaW5nXG4gICAgbGV0IHNpZ25hdHVyZTogSGV4XG5cbiAgICBpZiAoJ21lc3NhZ2UnIGluIGNyZWRlbnRpYWxzKSB7XG4gICAgICBtZXNzYWdlID0gY3JlZGVudGlhbHMubWVzc2FnZVxuICAgICAgc2lnbmF0dXJlID0gY3JlZGVudGlhbHMuc2lnbmF0dXJlXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHsgY2hhaW4sIHdhbGxldCwgc3RhdGVtZW50LCBvcHRpb25zIH0gPSBjcmVkZW50aWFsc1xuXG4gICAgICBsZXQgcmVzb2x2ZWRXYWxsZXQ6IEV0aGVyZXVtV2FsbGV0XG5cbiAgICAgIGlmICghaXNCcm93c2VyKCkpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB3YWxsZXQgIT09ICdvYmplY3QnIHx8ICFvcHRpb25zPy51cmwpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICAnQHN1cGFiYXNlL2F1dGgtanM6IEJvdGggd2FsbGV0IGFuZCB1cmwgbXVzdCBiZSBzcGVjaWZpZWQgaW4gbm9uLWJyb3dzZXIgZW52aXJvbm1lbnRzLidcbiAgICAgICAgICApXG4gICAgICAgIH1cblxuICAgICAgICByZXNvbHZlZFdhbGxldCA9IHdhbGxldFxuICAgICAgfSBlbHNlIGlmICh0eXBlb2Ygd2FsbGV0ID09PSAnb2JqZWN0Jykge1xuICAgICAgICByZXNvbHZlZFdhbGxldCA9IHdhbGxldFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3Qgd2luZG93QW55ID0gd2luZG93IGFzIGFueVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICAnZXRoZXJldW0nIGluIHdpbmRvd0FueSAmJlxuICAgICAgICAgIHR5cGVvZiB3aW5kb3dBbnkuZXRoZXJldW0gPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgJ3JlcXVlc3QnIGluIHdpbmRvd0FueS5ldGhlcmV1bSAmJlxuICAgICAgICAgIHR5cGVvZiB3aW5kb3dBbnkuZXRoZXJldW0ucmVxdWVzdCA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICApIHtcbiAgICAgICAgICByZXNvbHZlZFdhbGxldCA9IHdpbmRvd0FueS5ldGhlcmV1bVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBAc3VwYWJhc2UvYXV0aC1qczogTm8gY29tcGF0aWJsZSBFdGhlcmV1bSB3YWxsZXQgaW50ZXJmYWNlIG9uIHRoZSB3aW5kb3cgb2JqZWN0ICh3aW5kb3cuZXRoZXJldW0pIGRldGVjdGVkLiBNYWtlIHN1cmUgdGhlIHVzZXIgYWxyZWFkeSBoYXMgYSB3YWxsZXQgaW5zdGFsbGVkIGFuZCBjb25uZWN0ZWQgZm9yIHRoaXMgYXBwLiBQcmVmZXIgcGFzc2luZyB0aGUgd2FsbGV0IGludGVyZmFjZSBvYmplY3QgZGlyZWN0bHkgdG8gc2lnbkluV2l0aFdlYjMoeyBjaGFpbjogJ2V0aGVyZXVtJywgd2FsbGV0OiByZXNvbHZlZFVzZXJXYWxsZXQgfSkgaW5zdGVhZC5gXG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwob3B0aW9ucz8udXJsID8/IHdpbmRvdy5sb2NhdGlvbi5ocmVmKVxuXG4gICAgICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IHJlc29sdmVkV2FsbGV0XG4gICAgICAgIC5yZXF1ZXN0KHtcbiAgICAgICAgICBtZXRob2Q6ICdldGhfcmVxdWVzdEFjY291bnRzJyxcbiAgICAgICAgfSlcbiAgICAgICAgLnRoZW4oKGFjY3MpID0+IGFjY3MgYXMgc3RyaW5nW10pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgYEBzdXBhYmFzZS9hdXRoLWpzOiBXYWxsZXQgbWV0aG9kIGV0aF9yZXF1ZXN0QWNjb3VudHMgaXMgbWlzc2luZyBvciBpbnZhbGlkYFxuICAgICAgICAgIClcbiAgICAgICAgfSlcblxuICAgICAgaWYgKCFhY2NvdW50cyB8fCBhY2NvdW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBAc3VwYWJhc2UvYXV0aC1qczogTm8gYWNjb3VudHMgYXZhaWxhYmxlLiBQbGVhc2UgZW5zdXJlIHRoZSB3YWxsZXQgaXMgY29ubmVjdGVkLmBcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBjb25zdCBhZGRyZXNzID0gZ2V0QWRkcmVzcyhhY2NvdW50c1swXSlcblxuICAgICAgbGV0IGNoYWluSWQgPSBvcHRpb25zPy5zaWduSW5XaXRoRXRoZXJldW0/LmNoYWluSWRcbiAgICAgIGlmICghY2hhaW5JZCkge1xuICAgICAgICBjb25zdCBjaGFpbklkSGV4ID0gYXdhaXQgcmVzb2x2ZWRXYWxsZXQucmVxdWVzdCh7XG4gICAgICAgICAgbWV0aG9kOiAnZXRoX2NoYWluSWQnLFxuICAgICAgICB9KVxuICAgICAgICBjaGFpbklkID0gZnJvbUhleChjaGFpbklkSGV4IGFzIEhleClcbiAgICAgIH1cblxuICAgICAgY29uc3Qgc2l3ZU1lc3NhZ2U6IFNpd2VNZXNzYWdlID0ge1xuICAgICAgICBkb21haW46IHVybC5ob3N0LFxuICAgICAgICBhZGRyZXNzOiBhZGRyZXNzLFxuICAgICAgICBzdGF0ZW1lbnQ6IHN0YXRlbWVudCxcbiAgICAgICAgdXJpOiB1cmwuaHJlZixcbiAgICAgICAgdmVyc2lvbjogJzEnLFxuICAgICAgICBjaGFpbklkOiBjaGFpbklkLFxuICAgICAgICBub25jZTogb3B0aW9ucz8uc2lnbkluV2l0aEV0aGVyZXVtPy5ub25jZSxcbiAgICAgICAgaXNzdWVkQXQ6IG9wdGlvbnM/LnNpZ25JbldpdGhFdGhlcmV1bT8uaXNzdWVkQXQgPz8gbmV3IERhdGUoKSxcbiAgICAgICAgZXhwaXJhdGlvblRpbWU6IG9wdGlvbnM/LnNpZ25JbldpdGhFdGhlcmV1bT8uZXhwaXJhdGlvblRpbWUsXG4gICAgICAgIG5vdEJlZm9yZTogb3B0aW9ucz8uc2lnbkluV2l0aEV0aGVyZXVtPy5ub3RCZWZvcmUsXG4gICAgICAgIHJlcXVlc3RJZDogb3B0aW9ucz8uc2lnbkluV2l0aEV0aGVyZXVtPy5yZXF1ZXN0SWQsXG4gICAgICAgIHJlc291cmNlczogb3B0aW9ucz8uc2lnbkluV2l0aEV0aGVyZXVtPy5yZXNvdXJjZXMsXG4gICAgICB9XG5cbiAgICAgIG1lc3NhZ2UgPSBjcmVhdGVTaXdlTWVzc2FnZShzaXdlTWVzc2FnZSlcblxuICAgICAgLy8gU2lnbiBtZXNzYWdlXG4gICAgICBzaWduYXR1cmUgPSAoYXdhaXQgcmVzb2x2ZWRXYWxsZXQucmVxdWVzdCh7XG4gICAgICAgIG1ldGhvZDogJ3BlcnNvbmFsX3NpZ24nLFxuICAgICAgICBwYXJhbXM6IFt0b0hleChtZXNzYWdlKSwgYWRkcmVzc10sXG4gICAgICB9KSkgYXMgSGV4XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IF9yZXF1ZXN0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAnUE9TVCcsXG4gICAgICAgIGAke3RoaXMudXJsfS90b2tlbj9ncmFudF90eXBlPXdlYjNgLFxuICAgICAgICB7XG4gICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIGNoYWluOiAnZXRoZXJldW0nLFxuICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIHNpZ25hdHVyZSxcbiAgICAgICAgICAgIC4uLihjcmVkZW50aWFscy5vcHRpb25zPy5jYXB0Y2hhVG9rZW5cbiAgICAgICAgICAgICAgPyB7IGdvdHJ1ZV9tZXRhX3NlY3VyaXR5OiB7IGNhcHRjaGFfdG9rZW46IGNyZWRlbnRpYWxzLm9wdGlvbnM/LmNhcHRjaGFUb2tlbiB9IH1cbiAgICAgICAgICAgICAgOiBudWxsKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHhmb3JtOiBfc2Vzc2lvblJlc3BvbnNlLFxuICAgICAgICB9XG4gICAgICApXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgIH1cbiAgICAgIGlmICghZGF0YSB8fCAhZGF0YS5zZXNzaW9uIHx8ICFkYXRhLnVzZXIpIHtcbiAgICAgICAgY29uc3QgaW52YWxpZFRva2VuRXJyb3IgPSBuZXcgQXV0aEludmFsaWRUb2tlblJlc3BvbnNlRXJyb3IoKVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yOiBpbnZhbGlkVG9rZW5FcnJvciB9KVxuICAgICAgfVxuICAgICAgaWYgKGRhdGEuc2Vzc2lvbikge1xuICAgICAgICBhd2FpdCB0aGlzLl9zYXZlU2Vzc2lvbihkYXRhLnNlc3Npb24pXG4gICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdTSUdORURfSU4nLCBkYXRhLnNlc3Npb24pXG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyAuLi5kYXRhIH0sIGVycm9yIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgc2lnbkluV2l0aFNvbGFuYShjcmVkZW50aWFsczogU29sYW5hV2ViM0NyZWRlbnRpYWxzKSB7XG4gICAgbGV0IG1lc3NhZ2U6IHN0cmluZ1xuICAgIGxldCBzaWduYXR1cmU6IFVpbnQ4QXJyYXlcblxuICAgIGlmICgnbWVzc2FnZScgaW4gY3JlZGVudGlhbHMpIHtcbiAgICAgIG1lc3NhZ2UgPSBjcmVkZW50aWFscy5tZXNzYWdlXG4gICAgICBzaWduYXR1cmUgPSBjcmVkZW50aWFscy5zaWduYXR1cmVcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgeyBjaGFpbiwgd2FsbGV0LCBzdGF0ZW1lbnQsIG9wdGlvbnMgfSA9IGNyZWRlbnRpYWxzXG5cbiAgICAgIGxldCByZXNvbHZlZFdhbGxldDogU29sYW5hV2FsbGV0XG5cbiAgICAgIGlmICghaXNCcm93c2VyKCkpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB3YWxsZXQgIT09ICdvYmplY3QnIHx8ICFvcHRpb25zPy51cmwpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICAnQHN1cGFiYXNlL2F1dGgtanM6IEJvdGggd2FsbGV0IGFuZCB1cmwgbXVzdCBiZSBzcGVjaWZpZWQgaW4gbm9uLWJyb3dzZXIgZW52aXJvbm1lbnRzLidcbiAgICAgICAgICApXG4gICAgICAgIH1cblxuICAgICAgICByZXNvbHZlZFdhbGxldCA9IHdhbGxldFxuICAgICAgfSBlbHNlIGlmICh0eXBlb2Ygd2FsbGV0ID09PSAnb2JqZWN0Jykge1xuICAgICAgICByZXNvbHZlZFdhbGxldCA9IHdhbGxldFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3Qgd2luZG93QW55ID0gd2luZG93IGFzIGFueVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICAnc29sYW5hJyBpbiB3aW5kb3dBbnkgJiZcbiAgICAgICAgICB0eXBlb2Ygd2luZG93QW55LnNvbGFuYSA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgICAoKCdzaWduSW4nIGluIHdpbmRvd0FueS5zb2xhbmEgJiYgdHlwZW9mIHdpbmRvd0FueS5zb2xhbmEuc2lnbkluID09PSAnZnVuY3Rpb24nKSB8fFxuICAgICAgICAgICAgKCdzaWduTWVzc2FnZScgaW4gd2luZG93QW55LnNvbGFuYSAmJlxuICAgICAgICAgICAgICB0eXBlb2Ygd2luZG93QW55LnNvbGFuYS5zaWduTWVzc2FnZSA9PT0gJ2Z1bmN0aW9uJykpXG4gICAgICAgICkge1xuICAgICAgICAgIHJlc29sdmVkV2FsbGV0ID0gd2luZG93QW55LnNvbGFuYVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBAc3VwYWJhc2UvYXV0aC1qczogTm8gY29tcGF0aWJsZSBTb2xhbmEgd2FsbGV0IGludGVyZmFjZSBvbiB0aGUgd2luZG93IG9iamVjdCAod2luZG93LnNvbGFuYSkgZGV0ZWN0ZWQuIE1ha2Ugc3VyZSB0aGUgdXNlciBhbHJlYWR5IGhhcyBhIHdhbGxldCBpbnN0YWxsZWQgYW5kIGNvbm5lY3RlZCBmb3IgdGhpcyBhcHAuIFByZWZlciBwYXNzaW5nIHRoZSB3YWxsZXQgaW50ZXJmYWNlIG9iamVjdCBkaXJlY3RseSB0byBzaWduSW5XaXRoV2ViMyh7IGNoYWluOiAnc29sYW5hJywgd2FsbGV0OiByZXNvbHZlZFVzZXJXYWxsZXQgfSkgaW5zdGVhZC5gXG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwob3B0aW9ucz8udXJsID8/IHdpbmRvdy5sb2NhdGlvbi5ocmVmKVxuXG4gICAgICBpZiAoJ3NpZ25JbicgaW4gcmVzb2x2ZWRXYWxsZXQgJiYgcmVzb2x2ZWRXYWxsZXQuc2lnbkluKSB7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IGF3YWl0IHJlc29sdmVkV2FsbGV0LnNpZ25Jbih7XG4gICAgICAgICAgaXNzdWVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcblxuICAgICAgICAgIC4uLm9wdGlvbnM/LnNpZ25JbldpdGhTb2xhbmEsXG5cbiAgICAgICAgICAvLyBub24tb3ZlcnJpZGFibGUgcHJvcGVydGllc1xuICAgICAgICAgIHZlcnNpb246ICcxJyxcbiAgICAgICAgICBkb21haW46IHVybC5ob3N0LFxuICAgICAgICAgIHVyaTogdXJsLmhyZWYsXG5cbiAgICAgICAgICAuLi4oc3RhdGVtZW50ID8geyBzdGF0ZW1lbnQgfSA6IG51bGwpLFxuICAgICAgICB9KVxuXG4gICAgICAgIGxldCBvdXRwdXRUb1Byb2Nlc3M6IGFueVxuXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KG91dHB1dCkgJiYgb3V0cHV0WzBdICYmIHR5cGVvZiBvdXRwdXRbMF0gPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgb3V0cHV0VG9Qcm9jZXNzID0gb3V0cHV0WzBdXG4gICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgb3V0cHV0ICYmXG4gICAgICAgICAgdHlwZW9mIG91dHB1dCA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgICAnc2lnbmVkTWVzc2FnZScgaW4gb3V0cHV0ICYmXG4gICAgICAgICAgJ3NpZ25hdHVyZScgaW4gb3V0cHV0XG4gICAgICAgICkge1xuICAgICAgICAgIG91dHB1dFRvUHJvY2VzcyA9IG91dHB1dFxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQHN1cGFiYXNlL2F1dGgtanM6IFdhbGxldCBtZXRob2Qgc2lnbkluKCkgcmV0dXJuZWQgdW5yZWNvZ25pemVkIHZhbHVlJylcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICAnc2lnbmVkTWVzc2FnZScgaW4gb3V0cHV0VG9Qcm9jZXNzICYmXG4gICAgICAgICAgJ3NpZ25hdHVyZScgaW4gb3V0cHV0VG9Qcm9jZXNzICYmXG4gICAgICAgICAgKHR5cGVvZiBvdXRwdXRUb1Byb2Nlc3Muc2lnbmVkTWVzc2FnZSA9PT0gJ3N0cmluZycgfHxcbiAgICAgICAgICAgIG91dHB1dFRvUHJvY2Vzcy5zaWduZWRNZXNzYWdlIGluc3RhbmNlb2YgVWludDhBcnJheSkgJiZcbiAgICAgICAgICBvdXRwdXRUb1Byb2Nlc3Muc2lnbmF0dXJlIGluc3RhbmNlb2YgVWludDhBcnJheVxuICAgICAgICApIHtcbiAgICAgICAgICBtZXNzYWdlID1cbiAgICAgICAgICAgIHR5cGVvZiBvdXRwdXRUb1Byb2Nlc3Muc2lnbmVkTWVzc2FnZSA9PT0gJ3N0cmluZydcbiAgICAgICAgICAgICAgPyBvdXRwdXRUb1Byb2Nlc3Muc2lnbmVkTWVzc2FnZVxuICAgICAgICAgICAgICA6IG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShvdXRwdXRUb1Byb2Nlc3Muc2lnbmVkTWVzc2FnZSlcbiAgICAgICAgICBzaWduYXR1cmUgPSBvdXRwdXRUb1Byb2Nlc3Muc2lnbmF0dXJlXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgJ0BzdXBhYmFzZS9hdXRoLWpzOiBXYWxsZXQgbWV0aG9kIHNpZ25JbigpIEFQSSByZXR1cm5lZCBvYmplY3Qgd2l0aG91dCBzaWduZWRNZXNzYWdlIGFuZCBzaWduYXR1cmUgZmllbGRzJ1xuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICEoJ3NpZ25NZXNzYWdlJyBpbiByZXNvbHZlZFdhbGxldCkgfHxcbiAgICAgICAgICB0eXBlb2YgcmVzb2x2ZWRXYWxsZXQuc2lnbk1lc3NhZ2UgIT09ICdmdW5jdGlvbicgfHxcbiAgICAgICAgICAhKCdwdWJsaWNLZXknIGluIHJlc29sdmVkV2FsbGV0KSB8fFxuICAgICAgICAgIHR5cGVvZiByZXNvbHZlZFdhbGxldCAhPT0gJ29iamVjdCcgfHxcbiAgICAgICAgICAhcmVzb2x2ZWRXYWxsZXQucHVibGljS2V5IHx8XG4gICAgICAgICAgISgndG9CYXNlNTgnIGluIHJlc29sdmVkV2FsbGV0LnB1YmxpY0tleSkgfHxcbiAgICAgICAgICB0eXBlb2YgcmVzb2x2ZWRXYWxsZXQucHVibGljS2V5LnRvQmFzZTU4ICE9PSAnZnVuY3Rpb24nXG4gICAgICAgICkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgICdAc3VwYWJhc2UvYXV0aC1qczogV2FsbGV0IGRvZXMgbm90IGhhdmUgYSBjb21wYXRpYmxlIHNpZ25NZXNzYWdlKCkgYW5kIHB1YmxpY0tleS50b0Jhc2U1OCgpIEFQSSdcbiAgICAgICAgICApXG4gICAgICAgIH1cblxuICAgICAgICBtZXNzYWdlID0gW1xuICAgICAgICAgIGAke3VybC5ob3N0fSB3YW50cyB5b3UgdG8gc2lnbiBpbiB3aXRoIHlvdXIgU29sYW5hIGFjY291bnQ6YCxcbiAgICAgICAgICByZXNvbHZlZFdhbGxldC5wdWJsaWNLZXkudG9CYXNlNTgoKSxcbiAgICAgICAgICAuLi4oc3RhdGVtZW50ID8gWycnLCBzdGF0ZW1lbnQsICcnXSA6IFsnJ10pLFxuICAgICAgICAgICdWZXJzaW9uOiAxJyxcbiAgICAgICAgICBgVVJJOiAke3VybC5ocmVmfWAsXG4gICAgICAgICAgYElzc3VlZCBBdDogJHtvcHRpb25zPy5zaWduSW5XaXRoU29sYW5hPy5pc3N1ZWRBdCA/PyBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCl9YCxcbiAgICAgICAgICAuLi4ob3B0aW9ucz8uc2lnbkluV2l0aFNvbGFuYT8ubm90QmVmb3JlXG4gICAgICAgICAgICA/IFtgTm90IEJlZm9yZTogJHtvcHRpb25zLnNpZ25JbldpdGhTb2xhbmEubm90QmVmb3JlfWBdXG4gICAgICAgICAgICA6IFtdKSxcbiAgICAgICAgICAuLi4ob3B0aW9ucz8uc2lnbkluV2l0aFNvbGFuYT8uZXhwaXJhdGlvblRpbWVcbiAgICAgICAgICAgID8gW2BFeHBpcmF0aW9uIFRpbWU6ICR7b3B0aW9ucy5zaWduSW5XaXRoU29sYW5hLmV4cGlyYXRpb25UaW1lfWBdXG4gICAgICAgICAgICA6IFtdKSxcbiAgICAgICAgICAuLi4ob3B0aW9ucz8uc2lnbkluV2l0aFNvbGFuYT8uY2hhaW5JZFxuICAgICAgICAgICAgPyBbYENoYWluIElEOiAke29wdGlvbnMuc2lnbkluV2l0aFNvbGFuYS5jaGFpbklkfWBdXG4gICAgICAgICAgICA6IFtdKSxcbiAgICAgICAgICAuLi4ob3B0aW9ucz8uc2lnbkluV2l0aFNvbGFuYT8ubm9uY2UgPyBbYE5vbmNlOiAke29wdGlvbnMuc2lnbkluV2l0aFNvbGFuYS5ub25jZX1gXSA6IFtdKSxcbiAgICAgICAgICAuLi4ob3B0aW9ucz8uc2lnbkluV2l0aFNvbGFuYT8ucmVxdWVzdElkXG4gICAgICAgICAgICA/IFtgUmVxdWVzdCBJRDogJHtvcHRpb25zLnNpZ25JbldpdGhTb2xhbmEucmVxdWVzdElkfWBdXG4gICAgICAgICAgICA6IFtdKSxcbiAgICAgICAgICAuLi4ob3B0aW9ucz8uc2lnbkluV2l0aFNvbGFuYT8ucmVzb3VyY2VzPy5sZW5ndGhcbiAgICAgICAgICAgID8gW1xuICAgICAgICAgICAgICAgICdSZXNvdXJjZXMnLFxuICAgICAgICAgICAgICAgIC4uLm9wdGlvbnMuc2lnbkluV2l0aFNvbGFuYS5yZXNvdXJjZXMubWFwKChyZXNvdXJjZSkgPT4gYC0gJHtyZXNvdXJjZX1gKSxcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgOiBbXSksXG4gICAgICAgIF0uam9pbignXFxuJylcblxuICAgICAgICBjb25zdCBtYXliZVNpZ25hdHVyZSA9IGF3YWl0IHJlc29sdmVkV2FsbGV0LnNpZ25NZXNzYWdlKFxuICAgICAgICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShtZXNzYWdlKSxcbiAgICAgICAgICAndXRmOCdcbiAgICAgICAgKVxuXG4gICAgICAgIGlmICghbWF5YmVTaWduYXR1cmUgfHwgIShtYXliZVNpZ25hdHVyZSBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgJ0BzdXBhYmFzZS9hdXRoLWpzOiBXYWxsZXQgc2lnbk1lc3NhZ2UoKSBBUEkgcmV0dXJuZWQgYW4gcmVjb2duaXplZCB2YWx1ZSdcbiAgICAgICAgICApXG4gICAgICAgIH1cblxuICAgICAgICBzaWduYXR1cmUgPSBtYXliZVNpZ25hdHVyZVxuICAgICAgfVxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgJ1BPU1QnLFxuICAgICAgICBgJHt0aGlzLnVybH0vdG9rZW4/Z3JhbnRfdHlwZT13ZWIzYCxcbiAgICAgICAge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBjaGFpbjogJ3NvbGFuYScsXG4gICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgc2lnbmF0dXJlOiBieXRlc1RvQmFzZTY0VVJMKHNpZ25hdHVyZSksXG5cbiAgICAgICAgICAgIC4uLihjcmVkZW50aWFscy5vcHRpb25zPy5jYXB0Y2hhVG9rZW5cbiAgICAgICAgICAgICAgPyB7IGdvdHJ1ZV9tZXRhX3NlY3VyaXR5OiB7IGNhcHRjaGFfdG9rZW46IGNyZWRlbnRpYWxzLm9wdGlvbnM/LmNhcHRjaGFUb2tlbiB9IH1cbiAgICAgICAgICAgICAgOiBudWxsKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHhmb3JtOiBfc2Vzc2lvblJlc3BvbnNlLFxuICAgICAgICB9XG4gICAgICApXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgIH1cbiAgICAgIGlmICghZGF0YSB8fCAhZGF0YS5zZXNzaW9uIHx8ICFkYXRhLnVzZXIpIHtcbiAgICAgICAgY29uc3QgaW52YWxpZFRva2VuRXJyb3IgPSBuZXcgQXV0aEludmFsaWRUb2tlblJlc3BvbnNlRXJyb3IoKVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yOiBpbnZhbGlkVG9rZW5FcnJvciB9KVxuICAgICAgfVxuICAgICAgaWYgKGRhdGEuc2Vzc2lvbikge1xuICAgICAgICBhd2FpdCB0aGlzLl9zYXZlU2Vzc2lvbihkYXRhLnNlc3Npb24pXG4gICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdTSUdORURfSU4nLCBkYXRhLnNlc3Npb24pXG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyAuLi5kYXRhIH0sIGVycm9yIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2V4Y2hhbmdlQ29kZUZvclNlc3Npb24oYXV0aENvZGU6IHN0cmluZyk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHsgc2Vzc2lvbjogU2Vzc2lvbjsgdXNlcjogVXNlcjsgcmVkaXJlY3RUeXBlOiBzdHJpbmcgfCBudWxsIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHsgZGF0YTogeyBzZXNzaW9uOiBudWxsOyB1c2VyOiBudWxsOyByZWRpcmVjdFR5cGU6IG51bGwgfTsgZXJyb3I6IEF1dGhFcnJvciB9XG4gID4ge1xuICAgIGNvbnN0IHN0b3JhZ2VJdGVtID0gYXdhaXQgZ2V0SXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICBjb25zdCBbY29kZVZlcmlmaWVyLCByZWRpcmVjdFR5cGVdID0gKChzdG9yYWdlSXRlbSA/PyAnJykgYXMgc3RyaW5nKS5zcGxpdCgnLycpXG5cbiAgICB0cnkge1xuICAgICAgaWYgKCFjb2RlVmVyaWZpZXIgJiYgdGhpcy5mbG93VHlwZSA9PT0gJ3BrY2UnKSB7XG4gICAgICAgIHRocm93IG5ldyBBdXRoUEtDRUNvZGVWZXJpZmllck1pc3NpbmdFcnJvcigpXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IF9yZXF1ZXN0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAnUE9TVCcsXG4gICAgICAgIGAke3RoaXMudXJsfS90b2tlbj9ncmFudF90eXBlPXBrY2VgLFxuICAgICAgICB7XG4gICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIGF1dGhfY29kZTogYXV0aENvZGUsXG4gICAgICAgICAgICBjb2RlX3ZlcmlmaWVyOiBjb2RlVmVyaWZpZXIsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB4Zm9ybTogX3Nlc3Npb25SZXNwb25zZSxcbiAgICAgICAgfVxuICAgICAgKVxuICAgICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICB0aHJvdyBlcnJvclxuICAgICAgfVxuICAgICAgaWYgKCFkYXRhIHx8ICFkYXRhLnNlc3Npb24gfHwgIWRhdGEudXNlcikge1xuICAgICAgICBjb25zdCBpbnZhbGlkVG9rZW5FcnJvciA9IG5ldyBBdXRoSW52YWxpZFRva2VuUmVzcG9uc2VFcnJvcigpXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoe1xuICAgICAgICAgIGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCwgcmVkaXJlY3RUeXBlOiBudWxsIH0sXG4gICAgICAgICAgZXJyb3I6IGludmFsaWRUb2tlbkVycm9yLFxuICAgICAgICB9KVxuICAgICAgfVxuICAgICAgaWYgKGRhdGEuc2Vzc2lvbikge1xuICAgICAgICBhd2FpdCB0aGlzLl9zYXZlU2Vzc2lvbihkYXRhLnNlc3Npb24pXG4gICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKFxuICAgICAgICAgIHJlZGlyZWN0VHlwZSA9PT0gJ3JlY292ZXJ5JyA/ICdQQVNTV09SRF9SRUNPVkVSWScgOiAnU0lHTkVEX0lOJyxcbiAgICAgICAgICBkYXRhLnNlc3Npb25cbiAgICAgICAgKVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgLi4uZGF0YSwgcmVkaXJlY3RUeXBlOiByZWRpcmVjdFR5cGUgPz8gbnVsbCB9LCBlcnJvciB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBhd2FpdCByZW1vdmVJdGVtQXN5bmModGhpcy5zdG9yYWdlLCBgJHt0aGlzLnN0b3JhZ2VLZXl9LWNvZGUtdmVyaWZpZXJgKVxuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHtcbiAgICAgICAgICBkYXRhOiB7IHVzZXI6IG51bGwsIHNlc3Npb246IG51bGwsIHJlZGlyZWN0VHlwZTogbnVsbCB9LFxuICAgICAgICAgIGVycm9yLFxuICAgICAgICB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQWxsb3dzIHNpZ25pbmcgaW4gd2l0aCBhbiBPSURDIElEIHRva2VuLiBUaGUgYXV0aGVudGljYXRpb24gcHJvdmlkZXIgdXNlZFxuICAgKiBzaG91bGQgYmUgZW5hYmxlZCBhbmQgY29uZmlndXJlZC5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBVc2UgYW4gSUQgdG9rZW4gdG8gc2lnbiBpbi5cbiAgICogLSBFc3BlY2lhbGx5IHVzZWZ1bCB3aGVuIGltcGxlbWVudGluZyBzaWduIGluIHVzaW5nIG5hdGl2ZSBwbGF0Zm9ybSBkaWFsb2dzIGluIG1vYmlsZSBvciBkZXNrdG9wIGFwcHMgdXNpbmcgU2lnbiBpbiB3aXRoIEFwcGxlIG9yIFNpZ24gaW4gd2l0aCBHb29nbGUgb24gaU9TIGFuZCBBbmRyb2lkLlxuICAgKiAtIFlvdSBjYW4gYWxzbyB1c2UgR29vZ2xlJ3MgW09uZSBUYXBdKGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL2lkZW50aXR5L2dzaS93ZWIvZ3VpZGVzL2Rpc3BsYXktZ29vZ2xlLW9uZS10YXApIGFuZCBbQXV0b21hdGljIHNpZ24taW5dKGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL2lkZW50aXR5L2dzaS93ZWIvZ3VpZGVzL2F1dG9tYXRpYy1zaWduLWluLXNpZ24tb3V0KSB2aWEgdGhpcyBBUEkuXG4gICAqXG4gICAqIEBleGFtcGxlIFNpZ24gSW4gdXNpbmcgSUQgVG9rZW5cbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduSW5XaXRoSWRUb2tlbih7XG4gICAqICAgcHJvdmlkZXI6ICdnb29nbGUnLFxuICAgKiAgIHRva2VuOiAneW91ci1pZC10b2tlbidcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgU2lnbiBJbiB1c2luZyBJRCBUb2tlblxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICBcImF1ZFwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICAuLi5cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICAuLi5cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJpZGVudGl0aWVzXCI6IFtcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjIyMjIyMjItMjIyMi0yMjIyLTIyMjItMjIyMjIyMjIyMjIyXCIsXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZ29vZ2xlXCIsXG4gICAqICAgICAgICAgfVxuICAgKiAgICAgICBdLFxuICAgKiAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgfSxcbiAgICogICAgIFwic2Vzc2lvblwiOiB7XG4gICAqICAgICAgIFwiYWNjZXNzX3Rva2VuXCI6IFwiPEFDQ0VTU19UT0tFTj5cIixcbiAgICogICAgICAgXCJ0b2tlbl90eXBlXCI6IFwiYmVhcmVyXCIsXG4gICAqICAgICAgIFwiZXhwaXJlc19pblwiOiAzNjAwLFxuICAgKiAgICAgICBcImV4cGlyZXNfYXRcIjogMTcwMDAwMDAwMCxcbiAgICogICAgICAgXCJyZWZyZXNoX3Rva2VuXCI6IFwiPFJFRlJFU0hfVE9LRU4+XCIsXG4gICAqICAgICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgIFwiYXVkXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgICAgLi4uXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgICBcInVzZXJfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgICAgLi4uXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgICAge1xuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjIyMjIyMjItMjIyMi0yMjIyLTIyMjItMjIyMjIyMjIyMjIyXCIsXG4gICAqICAgICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJnb29nbGVcIixcbiAgICogICAgICAgICAgIH1cbiAgICogICAgICAgICBdLFxuICAgKiAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgfVxuICAgKiAgICAgfVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBzaWduSW5XaXRoSWRUb2tlbihjcmVkZW50aWFsczogU2lnbkluV2l0aElkVG9rZW5DcmVkZW50aWFscyk6IFByb21pc2U8QXV0aFRva2VuUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBvcHRpb25zLCBwcm92aWRlciwgdG9rZW4sIGFjY2Vzc190b2tlbiwgbm9uY2UgfSA9IGNyZWRlbnRpYWxzXG5cbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdQT1NUJywgYCR7dGhpcy51cmx9L3Rva2VuP2dyYW50X3R5cGU9aWRfdG9rZW5gLCB7XG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHByb3ZpZGVyLFxuICAgICAgICAgIGlkX3Rva2VuOiB0b2tlbixcbiAgICAgICAgICBhY2Nlc3NfdG9rZW4sXG4gICAgICAgICAgbm9uY2UsXG4gICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogb3B0aW9ucz8uY2FwdGNoYVRva2VuIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHhmb3JtOiBfc2Vzc2lvblJlc3BvbnNlLFxuICAgICAgfSlcblxuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gcmVzXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfSBlbHNlIGlmICghZGF0YSB8fCAhZGF0YS5zZXNzaW9uIHx8ICFkYXRhLnVzZXIpIHtcbiAgICAgICAgY29uc3QgaW52YWxpZFRva2VuRXJyb3IgPSBuZXcgQXV0aEludmFsaWRUb2tlblJlc3BvbnNlRXJyb3IoKVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yOiBpbnZhbGlkVG9rZW5FcnJvciB9KVxuICAgICAgfVxuICAgICAgaWYgKGRhdGEuc2Vzc2lvbikge1xuICAgICAgICBhd2FpdCB0aGlzLl9zYXZlU2Vzc2lvbihkYXRhLnNlc3Npb24pXG4gICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdTSUdORURfSU4nLCBkYXRhLnNlc3Npb24pXG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YSwgZXJyb3IgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBMb2cgaW4gYSB1c2VyIHVzaW5nIG1hZ2ljbGluayBvciBhIG9uZS10aW1lIHBhc3N3b3JkIChPVFApLlxuICAgKlxuICAgKiBJZiB0aGUgYHt7IC5Db25maXJtYXRpb25VUkwgfX1gIHZhcmlhYmxlIGlzIHNwZWNpZmllZCBpbiB0aGUgZW1haWwgdGVtcGxhdGUsIGEgbWFnaWNsaW5rIHdpbGwgYmUgc2VudC5cbiAgICogSWYgdGhlIGB7eyAuVG9rZW4gfX1gIHZhcmlhYmxlIGlzIHNwZWNpZmllZCBpbiB0aGUgZW1haWwgdGVtcGxhdGUsIGFuIE9UUCB3aWxsIGJlIHNlbnQuXG4gICAqIElmIHlvdSdyZSB1c2luZyBwaG9uZSBzaWduLWlucywgb25seSBhbiBPVFAgd2lsbCBiZSBzZW50LiBZb3Ugd29uJ3QgYmUgYWJsZSB0byBzZW5kIGEgbWFnaWNsaW5rIGZvciBwaG9uZSBzaWduLWlucy5cbiAgICpcbiAgICogQmUgYXdhcmUgdGhhdCB5b3UgbWF5IGdldCBiYWNrIGFuIGVycm9yIG1lc3NhZ2UgdGhhdCB3aWxsIG5vdCBkaXN0aW5ndWlzaFxuICAgKiBiZXR3ZWVuIHRoZSBjYXNlcyB3aGVyZSB0aGUgYWNjb3VudCBkb2VzIG5vdCBleGlzdCBvciwgdGhhdCB0aGUgYWNjb3VudFxuICAgKiBjYW4gb25seSBiZSBhY2Nlc3NlZCB2aWEgc29jaWFsIGxvZ2luLlxuICAgKlxuICAgKiBEbyBub3RlIHRoYXQgeW91IHdpbGwgbmVlZCB0byBjb25maWd1cmUgYSBXaGF0c2FwcCBzZW5kZXIgb24gVHdpbGlvXG4gICAqIGlmIHlvdSBhcmUgdXNpbmcgcGhvbmUgc2lnbiBpbiB3aXRoIHRoZSAnd2hhdHNhcHAnIGNoYW5uZWwuIFRoZSB3aGF0c2FwcFxuICAgKiBjaGFubmVsIGlzIG5vdCBzdXBwb3J0ZWQgb24gb3RoZXIgcHJvdmlkZXJzXG4gICAqIGF0IHRoaXMgdGltZS5cbiAgICogVGhpcyBtZXRob2Qgc3VwcG9ydHMgUEtDRSB3aGVuIGFuIGVtYWlsIGlzIHBhc3NlZC5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSZXF1aXJlcyBlaXRoZXIgYW4gZW1haWwgb3IgcGhvbmUgbnVtYmVyLlxuICAgKiAtIFRoaXMgbWV0aG9kIGlzIHVzZWQgZm9yIHBhc3N3b3JkbGVzcyBzaWduLWlucyB3aGVyZSBhIE9UUCBpcyBzZW50IHRvIHRoZSB1c2VyJ3MgZW1haWwgb3IgcGhvbmUgbnVtYmVyLlxuICAgKiAtIElmIHRoZSB1c2VyIGRvZXNuJ3QgZXhpc3QsIGBzaWduSW5XaXRoT3RwKClgIHdpbGwgc2lnbnVwIHRoZSB1c2VyIGluc3RlYWQuIFRvIHJlc3RyaWN0IHRoaXMgYmVoYXZpb3IsIHlvdSBjYW4gc2V0IGBzaG91bGRDcmVhdGVVc2VyYCBpbiBgU2lnbkluV2l0aFBhc3N3b3JkbGVzc0NyZWRlbnRpYWxzLm9wdGlvbnNgIHRvIGBmYWxzZWAuXG4gICAqIC0gSWYgeW91J3JlIHVzaW5nIGFuIGVtYWlsLCB5b3UgY2FuIGNvbmZpZ3VyZSB3aGV0aGVyIHlvdSB3YW50IHRoZSB1c2VyIHRvIHJlY2VpdmUgYSBtYWdpY2xpbmsgb3IgYSBPVFAuXG4gICAqIC0gSWYgeW91J3JlIHVzaW5nIHBob25lLCB5b3UgY2FuIGNvbmZpZ3VyZSB3aGV0aGVyIHlvdSB3YW50IHRoZSB1c2VyIHRvIHJlY2VpdmUgYSBPVFAuXG4gICAqIC0gVGhlIG1hZ2ljIGxpbmsncyBkZXN0aW5hdGlvbiBVUkwgaXMgZGV0ZXJtaW5lZCBieSB0aGUgW2BTSVRFX1VSTGBdKC9kb2NzL2d1aWRlcy9hdXRoL3JlZGlyZWN0LXVybHMjdXNlLXdpbGRjYXJkcy1pbi1yZWRpcmVjdC11cmxzKS5cbiAgICogLSBTZWUgW3JlZGlyZWN0IFVSTHMgYW5kIHdpbGRjYXJkc10oL2RvY3MvZ3VpZGVzL2F1dGgvcmVkaXJlY3QtdXJscyN1c2Utd2lsZGNhcmRzLWluLXJlZGlyZWN0LXVybHMpIHRvIGFkZCBhZGRpdGlvbmFsIHJlZGlyZWN0IFVSTHMgdG8geW91ciBwcm9qZWN0LlxuICAgKiAtIE1hZ2ljIGxpbmtzIGFuZCBPVFBzIHNoYXJlIHRoZSBzYW1lIGltcGxlbWVudGF0aW9uLiBUbyBzZW5kIHVzZXJzIGEgb25lLXRpbWUgY29kZSBpbnN0ZWFkIG9mIGEgbWFnaWMgbGluaywgW21vZGlmeSB0aGUgbWFnaWMgbGluayBlbWFpbCB0ZW1wbGF0ZV0oL2Rhc2hib2FyZC9wcm9qZWN0L18vYXV0aC90ZW1wbGF0ZXMpIHRvIGluY2x1ZGUgYHt7IC5Ub2tlbiB9fWAgaW5zdGVhZCBvZiBge3sgLkNvbmZpcm1hdGlvblVSTCB9fWAuXG4gICAqIC0gU2VlIG91ciBbVHdpbGlvIFBob25lIEF1dGggR3VpZGVdKC9kb2NzL2d1aWRlcy9hdXRoL3Bob25lLWxvZ2luP3Nob3dTTVNQcm92aWRlcj1Ud2lsaW8pIGZvciBkZXRhaWxzIGFib3V0IGNvbmZpZ3VyaW5nIFdoYXRzQXBwIHNpZ24gaW4uXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gU2lnbiBpbiB3aXRoIGVtYWlsXG4gICAqIFRoZSB1c2VyIHdpbGwgYmUgc2VudCBhbiBlbWFpbCB3aGljaCBjb250YWlucyBlaXRoZXIgYSBtYWdpY2xpbmsgb3IgYSBPVFAgb3IgYm90aC4gQnkgZGVmYXVsdCwgYSBnaXZlbiB1c2VyIGNhbiBvbmx5IHJlcXVlc3QgYSBPVFAgb25jZSBldmVyeSA2MCBzZWNvbmRzLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIGluIHdpdGggZW1haWxcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduSW5XaXRoT3RwKHtcbiAgICogICBlbWFpbDogJ2V4YW1wbGVAZW1haWwuY29tJyxcbiAgICogICBvcHRpb25zOiB7XG4gICAqICAgICBlbWFpbFJlZGlyZWN0VG86ICdodHRwczovL2V4YW1wbGUuY29tL3dlbGNvbWUnXG4gICAqICAgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBTaWduIGluIHdpdGggZW1haWxcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiBudWxsLFxuICAgKiAgICAgXCJzZXNzaW9uXCI6IG51bGxcbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFNpZ24gaW4gd2l0aCBTTVMgT1RQXG4gICAqIFRoZSB1c2VyIHdpbGwgYmUgc2VudCBhIFNNUyB3aGljaCBjb250YWlucyBhIE9UUC4gQnkgZGVmYXVsdCwgYSBnaXZlbiB1c2VyIGNhbiBvbmx5IHJlcXVlc3QgYSBPVFAgb25jZSBldmVyeSA2MCBzZWNvbmRzLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIGluIHdpdGggU01TIE9UUFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhPdHAoe1xuICAgKiAgIHBob25lOiAnKzEzMzM0NDQ1NTU1JyxcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gU2lnbiBpbiB3aXRoIFdoYXRzQXBwIE9UUFxuICAgKiBUaGUgdXNlciB3aWxsIGJlIHNlbnQgYSBXaGF0c0FwcCBtZXNzYWdlIHdoaWNoIGNvbnRhaW5zIGEgT1RQLiBCeSBkZWZhdWx0LCBhIGdpdmVuIHVzZXIgY2FuIG9ubHkgcmVxdWVzdCBhIE9UUCBvbmNlIGV2ZXJ5IDYwIHNlY29uZHMuIE5vdGUgdGhhdCBhIHVzZXIgd2lsbCBuZWVkIHRvIGhhdmUgYSB2YWxpZCBXaGF0c0FwcCBhY2NvdW50IHRoYXQgaXMgbGlua2VkIHRvIFR3aWxpbyBpbiBvcmRlciB0byB1c2UgdGhpcyBmZWF0dXJlLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTaWduIGluIHdpdGggV2hhdHNBcHAgT1RQXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aE90cCh7XG4gICAqICAgcGhvbmU6ICcrMTMzMzQ0NDU1NTUnLFxuICAgKiAgIG9wdGlvbnM6IHtcbiAgICogICAgIGNoYW5uZWw6J3doYXRzYXBwJyxcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgc2lnbkluV2l0aE90cChjcmVkZW50aWFsczogU2lnbkluV2l0aFBhc3N3b3JkbGVzc0NyZWRlbnRpYWxzKTogUHJvbWlzZTxBdXRoT3RwUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKCdlbWFpbCcgaW4gY3JlZGVudGlhbHMpIHtcbiAgICAgICAgY29uc3QgeyBlbWFpbCwgb3B0aW9ucyB9ID0gY3JlZGVudGlhbHNcbiAgICAgICAgbGV0IGNvZGVDaGFsbGVuZ2U6IHN0cmluZyB8IG51bGwgPSBudWxsXG4gICAgICAgIGxldCBjb2RlQ2hhbGxlbmdlTWV0aG9kOiBzdHJpbmcgfCBudWxsID0gbnVsbFxuICAgICAgICBpZiAodGhpcy5mbG93VHlwZSA9PT0gJ3BrY2UnKSB7XG4gICAgICAgICAgO1tjb2RlQ2hhbGxlbmdlLCBjb2RlQ2hhbGxlbmdlTWV0aG9kXSA9IGF3YWl0IGdldENvZGVDaGFsbGVuZ2VBbmRNZXRob2QoXG4gICAgICAgICAgICB0aGlzLnN0b3JhZ2UsXG4gICAgICAgICAgICB0aGlzLnN0b3JhZ2VLZXlcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vb3RwYCwge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBlbWFpbCxcbiAgICAgICAgICAgIGRhdGE6IG9wdGlvbnM/LmRhdGEgPz8ge30sXG4gICAgICAgICAgICBjcmVhdGVfdXNlcjogb3B0aW9ucz8uc2hvdWxkQ3JlYXRlVXNlciA/PyB0cnVlLFxuICAgICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogb3B0aW9ucz8uY2FwdGNoYVRva2VuIH0sXG4gICAgICAgICAgICBjb2RlX2NoYWxsZW5nZTogY29kZUNoYWxsZW5nZSxcbiAgICAgICAgICAgIGNvZGVfY2hhbGxlbmdlX21ldGhvZDogY29kZUNoYWxsZW5nZU1ldGhvZCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHJlZGlyZWN0VG86IG9wdGlvbnM/LmVtYWlsUmVkaXJlY3RUbyxcbiAgICAgICAgfSlcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuICAgICAgaWYgKCdwaG9uZScgaW4gY3JlZGVudGlhbHMpIHtcbiAgICAgICAgY29uc3QgeyBwaG9uZSwgb3B0aW9ucyB9ID0gY3JlZGVudGlhbHNcbiAgICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vb3RwYCwge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBwaG9uZSxcbiAgICAgICAgICAgIGRhdGE6IG9wdGlvbnM/LmRhdGEgPz8ge30sXG4gICAgICAgICAgICBjcmVhdGVfdXNlcjogb3B0aW9ucz8uc2hvdWxkQ3JlYXRlVXNlciA/PyB0cnVlLFxuICAgICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogb3B0aW9ucz8uY2FwdGNoYVRva2VuIH0sXG4gICAgICAgICAgICBjaGFubmVsOiBvcHRpb25zPy5jaGFubmVsID8/ICdzbXMnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoe1xuICAgICAgICAgIGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCwgbWVzc2FnZUlkOiBkYXRhPy5tZXNzYWdlX2lkIH0sXG4gICAgICAgICAgZXJyb3IsXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgQXV0aEludmFsaWRDcmVkZW50aWFsc0Vycm9yKCdZb3UgbXVzdCBwcm92aWRlIGVpdGhlciBhbiBlbWFpbCBvciBwaG9uZSBudW1iZXIuJylcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBMb2cgaW4gYSB1c2VyIGdpdmVuIGEgVXNlciBzdXBwbGllZCBPVFAgb3IgVG9rZW5IYXNoIHJlY2VpdmVkIHRocm91Z2ggbW9iaWxlIG9yIGVtYWlsLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFRoZSBgdmVyaWZ5T3RwYCBtZXRob2QgdGFrZXMgaW4gZGlmZmVyZW50IHZlcmlmaWNhdGlvbiB0eXBlcy5cbiAgICogLSBJZiBhIHBob25lIG51bWJlciBpcyB1c2VkLCB0aGUgdHlwZSBjYW4gZWl0aGVyIGJlOlxuICAgKiAgIDEuIGBzbXNgIOKAkyBVc2VkIHdoZW4gdmVyaWZ5aW5nIGEgb25lLXRpbWUgcGFzc3dvcmQgKE9UUCkgc2VudCB2aWEgU01TIGR1cmluZyBzaWduLXVwIG9yIHNpZ24taW4uXG4gICAqICAgMi4gYHBob25lX2NoYW5nZWAg4oCTIFVzZWQgd2hlbiB2ZXJpZnlpbmcgYW4gT1RQIHNlbnQgdG8gYSBuZXcgcGhvbmUgbnVtYmVyIGR1cmluZyBhIHBob25lIG51bWJlciB1cGRhdGUgcHJvY2Vzcy5cbiAgICogLSBJZiBhbiBlbWFpbCBhZGRyZXNzIGlzIHVzZWQsIHRoZSB0eXBlIGNhbiBiZSBvbmUgb2YgdGhlIGZvbGxvd2luZyAobm90ZTogYHNpZ251cGAgYW5kIGBtYWdpY2xpbmtgIHR5cGVzIGFyZSBkZXByZWNhdGVkKTpcbiAgICogICAxLiBgZW1haWxgIOKAkyBVc2VkIHdoZW4gdmVyaWZ5aW5nIGFuIE9UUCBzZW50IHRvIHRoZSB1c2VyJ3MgZW1haWwgZHVyaW5nIHNpZ24tdXAgb3Igc2lnbi1pbi5cbiAgICogICAyLiBgcmVjb3ZlcnlgIOKAkyBVc2VkIHdoZW4gdmVyaWZ5aW5nIGFuIE9UUCBzZW50IGZvciBhY2NvdW50IHJlY292ZXJ5LCB0eXBpY2FsbHkgYWZ0ZXIgYSBwYXNzd29yZCByZXNldCByZXF1ZXN0LlxuICAgKiAgIDMuIGBpbnZpdGVgIOKAkyBVc2VkIHdoZW4gdmVyaWZ5aW5nIGFuIE9UUCBzZW50IGFzIHBhcnQgb2YgYW4gaW52aXRhdGlvbiB0byBqb2luIGEgcHJvamVjdCBvciBvcmdhbml6YXRpb24uXG4gICAqICAgNC4gYGVtYWlsX2NoYW5nZWAg4oCTIFVzZWQgd2hlbiB2ZXJpZnlpbmcgYW4gT1RQIHNlbnQgdG8gYSBuZXcgZW1haWwgYWRkcmVzcyBkdXJpbmcgYW4gZW1haWwgdXBkYXRlIHByb2Nlc3MuXG4gICAqIC0gVGhlIHZlcmlmaWNhdGlvbiB0eXBlIHVzZWQgc2hvdWxkIGJlIGRldGVybWluZWQgYmFzZWQgb24gdGhlIGNvcnJlc3BvbmRpbmcgYXV0aCBtZXRob2QgY2FsbGVkIGJlZm9yZSBgdmVyaWZ5T3RwYCB0byBzaWduIHVwIC8gc2lnbi1pbiBhIHVzZXIuXG4gICAqIC0gVGhlIGBUb2tlbkhhc2hgIGlzIGNvbnRhaW5lZCBpbiB0aGUgW2VtYWlsIHRlbXBsYXRlc10oL2RvY3MvZ3VpZGVzL2F1dGgvYXV0aC1lbWFpbC10ZW1wbGF0ZXMpIGFuZCBjYW4gYmUgdXNlZCB0byBzaWduIGluLiAgWW91IG1heSB3aXNoIHRvIHVzZSB0aGUgaGFzaCBmb3IgdGhlIFBLQ0UgZmxvdyBmb3IgU2VydmVyIFNpZGUgQXV0aC4gUmVhZCBbdGhlIFBhc3N3b3JkLWJhc2VkIEF1dGggZ3VpZGVdKC9kb2NzL2d1aWRlcy9hdXRoL3Bhc3N3b3JkcykgZm9yIG1vcmUgZGV0YWlscy5cbiAgICpcbiAgICogQGV4YW1wbGUgVmVyaWZ5IFNpZ251cCBPbmUtVGltZSBQYXNzd29yZCAoT1RQKVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnZlcmlmeU90cCh7IGVtYWlsLCB0b2tlbiwgdHlwZTogJ2VtYWlsJ30pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFZlcmlmeSBTaWdudXAgT25lLVRpbWUgUGFzc3dvcmQgKE9UUClcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJwaG9uZVwiOiBcIlwiLFxuICAgKiAgICAgICBcImNvbmZpcm1lZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwicmVjb3Zlcnlfc2VudF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgIFwicHJvdmlkZXJzXCI6IFtcbiAgICogICAgICAgICAgIFwiZW1haWxcIlxuICAgKiAgICAgICAgIF1cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICB9LFxuICAgKiAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIF0sXG4gICAqICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiaXNfYW5vbnltb3VzXCI6IGZhbHNlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzZXNzaW9uXCI6IHtcbiAgICogICAgICAgXCJhY2Nlc3NfdG9rZW5cIjogXCI8QUNDRVNTX1RPS0VOPlwiLFxuICAgKiAgICAgICBcInRva2VuX3R5cGVcIjogXCJiZWFyZXJcIixcbiAgICogICAgICAgXCJleHBpcmVzX2luXCI6IDM2MDAsXG4gICAqICAgICAgIFwiZXhwaXJlc19hdFwiOiAxNzAwMDAwMDAwLFxuICAgKiAgICAgICBcInJlZnJlc2hfdG9rZW5cIjogXCI8UkVGUkVTSF9UT0tFTj5cIixcbiAgICogICAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgICAgXCJjb25maXJtZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwicmVjb3Zlcnlfc2VudF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlcnNcIjogW1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCJcbiAgICogICAgICAgICAgIF1cbiAgICogICAgICAgICB9LFxuICAgKiAgICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7XG4gICAqICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgIH0sXG4gICAqICAgICAgICAgXCJpZGVudGl0aWVzXCI6IFtcbiAgICogICAgICAgICAgIHtcbiAgICogICAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjIyMjIyMjIyLTIyMjItMjIyMi0yMjIyLTIyMjIyMjIyMjIyMlwiLFxuICAgKiAgICAgICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiXG4gICAqICAgICAgICAgICB9XG4gICAqICAgICAgICAgXSxcbiAgICogICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJpc19hbm9ueW1vdXNcIjogZmFsc2VcbiAgICogICAgICAgfVxuICAgKiAgICAgfVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFZlcmlmeSBTTVMgT25lLVRpbWUgUGFzc3dvcmQgKE9UUClcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC52ZXJpZnlPdHAoeyBwaG9uZSwgdG9rZW4sIHR5cGU6ICdzbXMnfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFZlcmlmeSBFbWFpbCBBdXRoIChUb2tlbiBIYXNoKVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnZlcmlmeU90cCh7IHRva2VuX2hhc2g6IHRva2VuSGFzaCwgdHlwZTogJ2VtYWlsJ30pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgdmVyaWZ5T3RwKHBhcmFtczogVmVyaWZ5T3RwUGFyYW1zKTogUHJvbWlzZTxBdXRoUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgbGV0IHJlZGlyZWN0VG86IHN0cmluZyB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZFxuICAgICAgbGV0IGNhcHRjaGFUb2tlbjogc3RyaW5nIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkXG4gICAgICBpZiAoJ29wdGlvbnMnIGluIHBhcmFtcykge1xuICAgICAgICByZWRpcmVjdFRvID0gcGFyYW1zLm9wdGlvbnM/LnJlZGlyZWN0VG9cbiAgICAgICAgY2FwdGNoYVRva2VuID0gcGFyYW1zLm9wdGlvbnM/LmNhcHRjaGFUb2tlblxuICAgICAgfVxuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vdmVyaWZ5YCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAuLi5wYXJhbXMsXG4gICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogY2FwdGNoYVRva2VuIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHJlZGlyZWN0VG8sXG4gICAgICAgIHhmb3JtOiBfc2Vzc2lvblJlc3BvbnNlLFxuICAgICAgfSlcblxuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIHRocm93IGVycm9yXG4gICAgICB9XG4gICAgICBpZiAoIWRhdGEpIHtcbiAgICAgICAgY29uc3QgdG9rZW5WZXJpZmljYXRpb25FcnJvciA9IG5ldyBFcnJvcignQW4gZXJyb3Igb2NjdXJyZWQgb24gdG9rZW4gdmVyaWZpY2F0aW9uLicpXG4gICAgICAgIHRocm93IHRva2VuVmVyaWZpY2F0aW9uRXJyb3JcbiAgICAgIH1cblxuICAgICAgY29uc3Qgc2Vzc2lvbjogU2Vzc2lvbiB8IG51bGwgPSBkYXRhLnNlc3Npb25cbiAgICAgIGNvbnN0IHVzZXI6IFVzZXIgfCBudWxsID0gZGF0YS51c2VyXG5cbiAgICAgIGlmIChzZXNzaW9uPy5hY2Nlc3NfdG9rZW4pIHtcbiAgICAgICAgYXdhaXQgdGhpcy5fc2F2ZVNlc3Npb24oc2Vzc2lvbiBhcyBTZXNzaW9uKVxuICAgICAgICBhd2FpdCB0aGlzLl9ub3RpZnlBbGxTdWJzY3JpYmVycyhcbiAgICAgICAgICBwYXJhbXMudHlwZSA9PSAncmVjb3ZlcnknID8gJ1BBU1NXT1JEX1JFQ09WRVJZJyA6ICdTSUdORURfSU4nLFxuICAgICAgICAgIHNlc3Npb25cbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyLCBzZXNzaW9uIH0sIGVycm9yOiBudWxsIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBdHRlbXB0cyBhIHNpbmdsZS1zaWduIG9uIHVzaW5nIGFuIGVudGVycHJpc2UgSWRlbnRpdHkgUHJvdmlkZXIuIEFcbiAgICogc3VjY2Vzc2Z1bCBTU08gYXR0ZW1wdCB3aWxsIHJlZGlyZWN0IHRoZSBjdXJyZW50IHBhZ2UgdG8gdGhlIGlkZW50aXR5XG4gICAqIHByb3ZpZGVyIGF1dGhvcml6YXRpb24gcGFnZS4gVGhlIHJlZGlyZWN0IFVSTCBpcyBpbXBsZW1lbnRhdGlvbiBhbmQgU1NPXG4gICAqIHByb3RvY29sIHNwZWNpZmljLlxuICAgKlxuICAgKiBZb3UgY2FuIHVzZSBpdCBieSBwcm92aWRpbmcgYSBTU08gZG9tYWluLiBUeXBpY2FsbHkgeW91IGNhbiBleHRyYWN0IHRoaXNcbiAgICogZG9tYWluIGJ5IGFza2luZyB1c2VycyBmb3IgdGhlaXIgZW1haWwgYWRkcmVzcy4gSWYgdGhpcyBkb21haW4gaXNcbiAgICogcmVnaXN0ZXJlZCBvbiB0aGUgQXV0aCBpbnN0YW5jZSB0aGUgcmVkaXJlY3Qgd2lsbCB1c2UgdGhhdCBvcmdhbml6YXRpb24nc1xuICAgKiBjdXJyZW50bHkgYWN0aXZlIFNTTyBJZGVudGl0eSBQcm92aWRlciBmb3IgdGhlIGxvZ2luLlxuICAgKlxuICAgKiBJZiB5b3UgaGF2ZSBidWlsdCBhbiBvcmdhbml6YXRpb24tc3BlY2lmaWMgbG9naW4gcGFnZSwgeW91IGNhbiB1c2UgdGhlXG4gICAqIG9yZ2FuaXphdGlvbidzIFNTTyBJZGVudGl0eSBQcm92aWRlciBVVUlEIGRpcmVjdGx5IGluc3RlYWQuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gQmVmb3JlIHlvdSBjYW4gY2FsbCB0aGlzIG1ldGhvZCB5b3UgbmVlZCB0byBbZXN0YWJsaXNoIGEgY29ubmVjdGlvbl0oL2RvY3MvZ3VpZGVzL2F1dGgvc3NvL2F1dGgtc3NvLXNhbWwjbWFuYWdpbmctc2FtbC0yMC1jb25uZWN0aW9ucykgdG8gYW4gaWRlbnRpdHkgcHJvdmlkZXIuIFVzZSB0aGUgW0NMSSBjb21tYW5kc10oL2RvY3MvcmVmZXJlbmNlL2NsaS9zdXBhYmFzZS1zc28pIHRvIGRvIHRoaXMuXG4gICAqIC0gSWYgeW91J3ZlIGFzc29jaWF0ZWQgYW4gZW1haWwgZG9tYWluIHRvIHRoZSBpZGVudGl0eSBwcm92aWRlciwgeW91IGNhbiB1c2UgdGhlIGBkb21haW5gIHByb3BlcnR5IHRvIHN0YXJ0IGEgc2lnbi1pbiBmbG93LlxuICAgKiAtIEluIGNhc2UgeW91IG5lZWQgdG8gdXNlIGEgZGlmZmVyZW50IHdheSB0byBzdGFydCB0aGUgYXV0aGVudGljYXRpb24gZmxvdyB3aXRoIGFuIGlkZW50aXR5IHByb3ZpZGVyLCB5b3UgY2FuIHVzZSB0aGUgYHByb3ZpZGVySWRgIHByb3BlcnR5LiBGb3IgZXhhbXBsZTpcbiAgICogICAgIC0gTWFwcGluZyBzcGVjaWZpYyB1c2VyIGVtYWlsIGFkZHJlc3NlcyB3aXRoIGFuIGlkZW50aXR5IHByb3ZpZGVyLlxuICAgKiAgICAgLSBVc2luZyBkaWZmZXJlbnQgaGludHMgdG8gaWRlbnRpdHkgdGhlIGlkZW50aXR5IHByb3ZpZGVyIHRvIGJlIHVzZWQgYnkgdGhlIHVzZXIsIGxpa2UgYSBjb21wYW55LXNwZWNpZmljIHBhZ2UsIElQIGFkZHJlc3Mgb3Igb3RoZXIgdHJhY2tpbmcgaW5mb3JtYXRpb24uXG4gICAqXG4gICAqIEBleGFtcGxlIFNpZ24gaW4gd2l0aCBlbWFpbCBkb21haW5cbiAgICogYGBganNcbiAgICogICAvLyBZb3UgY2FuIGV4dHJhY3QgdGhlIHVzZXIncyBlbWFpbCBkb21haW4gYW5kIHVzZSBpdCB0byB0cmlnZ2VyIHRoZVxuICAgKiAgIC8vIGF1dGhlbnRpY2F0aW9uIGZsb3cgd2l0aCB0aGUgY29ycmVjdCBpZGVudGl0eSBwcm92aWRlci5cbiAgICpcbiAgICogICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhTU08oe1xuICAgKiAgICAgZG9tYWluOiAnY29tcGFueS5jb20nXG4gICAqICAgfSlcbiAgICpcbiAgICogICBpZiAoZGF0YT8udXJsKSB7XG4gICAqICAgICAvLyByZWRpcmVjdCB0aGUgdXNlciB0byB0aGUgaWRlbnRpdHkgcHJvdmlkZXIncyBhdXRoZW50aWNhdGlvbiBmbG93XG4gICAqICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGRhdGEudXJsXG4gICAqICAgfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU2lnbiBpbiB3aXRoIHByb3ZpZGVyIFVVSURcbiAgICogYGBganNcbiAgICogICAvLyBVc2VmdWwgd2hlbiB5b3UgbmVlZCB0byBtYXAgYSB1c2VyJ3Mgc2lnbiBpbiByZXF1ZXN0IGFjY29yZGluZ1xuICAgKiAgIC8vIHRvIGRpZmZlcmVudCBydWxlcyB0aGF0IGNhbid0IHVzZSBlbWFpbCBkb21haW5zLlxuICAgKlxuICAgKiAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aFNTTyh7XG4gICAqICAgICBwcm92aWRlcklkOiAnMjE2NDhhOWQtOGQ1YS00NTU1LWE5ZDEtZDYzNzVkYzE0ZTkyJ1xuICAgKiAgIH0pXG4gICAqXG4gICAqICAgaWYgKGRhdGE/LnVybCkge1xuICAgKiAgICAgLy8gcmVkaXJlY3QgdGhlIHVzZXIgdG8gdGhlIGlkZW50aXR5IHByb3ZpZGVyJ3MgYXV0aGVudGljYXRpb24gZmxvd1xuICAgKiAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBkYXRhLnVybFxuICAgKiAgIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBzaWduSW5XaXRoU1NPKHBhcmFtczogU2lnbkluV2l0aFNTTyk6IFByb21pc2U8U1NPUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgbGV0IGNvZGVDaGFsbGVuZ2U6IHN0cmluZyB8IG51bGwgPSBudWxsXG4gICAgICBsZXQgY29kZUNoYWxsZW5nZU1ldGhvZDogc3RyaW5nIHwgbnVsbCA9IG51bGxcbiAgICAgIGlmICh0aGlzLmZsb3dUeXBlID09PSAncGtjZScpIHtcbiAgICAgICAgO1tjb2RlQ2hhbGxlbmdlLCBjb2RlQ2hhbGxlbmdlTWV0aG9kXSA9IGF3YWl0IGdldENvZGVDaGFsbGVuZ2VBbmRNZXRob2QoXG4gICAgICAgICAgdGhpcy5zdG9yYWdlLFxuICAgICAgICAgIHRoaXMuc3RvcmFnZUtleVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdQT1NUJywgYCR7dGhpcy51cmx9L3Nzb2AsIHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIC4uLigncHJvdmlkZXJJZCcgaW4gcGFyYW1zID8geyBwcm92aWRlcl9pZDogcGFyYW1zLnByb3ZpZGVySWQgfSA6IG51bGwpLFxuICAgICAgICAgIC4uLignZG9tYWluJyBpbiBwYXJhbXMgPyB7IGRvbWFpbjogcGFyYW1zLmRvbWFpbiB9IDogbnVsbCksXG4gICAgICAgICAgcmVkaXJlY3RfdG86IHBhcmFtcy5vcHRpb25zPy5yZWRpcmVjdFRvID8/IHVuZGVmaW5lZCxcbiAgICAgICAgICAuLi4ocGFyYW1zPy5vcHRpb25zPy5jYXB0Y2hhVG9rZW5cbiAgICAgICAgICAgID8geyBnb3RydWVfbWV0YV9zZWN1cml0eTogeyBjYXB0Y2hhX3Rva2VuOiBwYXJhbXMub3B0aW9ucy5jYXB0Y2hhVG9rZW4gfSB9XG4gICAgICAgICAgICA6IG51bGwpLFxuICAgICAgICAgIHNraXBfaHR0cF9yZWRpcmVjdDogdHJ1ZSwgLy8gZmV0Y2ggZG9lcyBub3QgaGFuZGxlIHJlZGlyZWN0c1xuICAgICAgICAgIGNvZGVfY2hhbGxlbmdlOiBjb2RlQ2hhbGxlbmdlLFxuICAgICAgICAgIGNvZGVfY2hhbGxlbmdlX21ldGhvZDogY29kZUNoYWxsZW5nZU1ldGhvZCxcbiAgICAgICAgfSxcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICB4Zm9ybTogX3Nzb1Jlc3BvbnNlLFxuICAgICAgfSlcblxuICAgICAgLy8gQXV0b21hdGljYWxseSByZWRpcmVjdCBpbiBicm93c2VyIHVubGVzcyBza2lwQnJvd3NlclJlZGlyZWN0IGlzIHRydWVcbiAgICAgIGlmIChyZXN1bHQuZGF0YT8udXJsICYmIGlzQnJvd3NlcigpICYmICFwYXJhbXMub3B0aW9ucz8uc2tpcEJyb3dzZXJSZWRpcmVjdCkge1xuICAgICAgICB3aW5kb3cubG9jYXRpb24uYXNzaWduKHJlc3VsdC5kYXRhLnVybClcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdChyZXN1bHQpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGF3YWl0IHJlbW92ZUl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIGAke3RoaXMuc3RvcmFnZUtleX0tY29kZS12ZXJpZmllcmApXG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU2VuZHMgYSByZWF1dGhlbnRpY2F0aW9uIE9UUCB0byB0aGUgdXNlcidzIGVtYWlsIG9yIHBob25lIG51bWJlci5cbiAgICogUmVxdWlyZXMgdGhlIHVzZXIgdG8gYmUgc2lnbmVkLWluLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFRoaXMgbWV0aG9kIGlzIHVzZWQgdG9nZXRoZXIgd2l0aCBgdXBkYXRlVXNlcigpYCB3aGVuIGEgdXNlcidzIHBhc3N3b3JkIG5lZWRzIHRvIGJlIHVwZGF0ZWQuXG4gICAqIC0gSWYgeW91IHJlcXVpcmUgeW91ciB1c2VyIHRvIHJlYXV0aGVudGljYXRlIGJlZm9yZSB1cGRhdGluZyB0aGVpciBwYXNzd29yZCwgeW91IG5lZWQgdG8gZW5hYmxlIHRoZSAqKlNlY3VyZSBwYXNzd29yZCBjaGFuZ2UqKiBvcHRpb24gaW4geW91ciBbcHJvamVjdCdzIGVtYWlsIHByb3ZpZGVyIHNldHRpbmdzXSgvZGFzaGJvYXJkL3Byb2plY3QvXy9hdXRoL3Byb3ZpZGVycykuXG4gICAqIC0gQSB1c2VyIGlzIG9ubHkgcmVxdWlyZSB0byByZWF1dGhlbnRpY2F0ZSBiZWZvcmUgdXBkYXRpbmcgdGhlaXIgcGFzc3dvcmQgaWYgKipTZWN1cmUgcGFzc3dvcmQgY2hhbmdlKiogaXMgZW5hYmxlZCBhbmQgdGhlIHVzZXIgKipoYXNuJ3QgcmVjZW50bHkgc2lnbmVkIGluKiouIEEgdXNlciBpcyBkZWVtZWQgcmVjZW50bHkgc2lnbmVkIGluIGlmIHRoZSBzZXNzaW9uIHdhcyBjcmVhdGVkIGluIHRoZSBsYXN0IDI0IGhvdXJzLlxuICAgKiAtIFRoaXMgbWV0aG9kIHdpbGwgc2VuZCBhIG5vbmNlIHRvIHRoZSB1c2VyJ3MgZW1haWwuIElmIHRoZSB1c2VyIGRvZXNuJ3QgaGF2ZSBhIGNvbmZpcm1lZCBlbWFpbCBhZGRyZXNzLCB0aGUgbWV0aG9kIHdpbGwgc2VuZCB0aGUgbm9uY2UgdG8gdGhlIHVzZXIncyBjb25maXJtZWQgcGhvbmUgbnVtYmVyIGluc3RlYWQuXG4gICAqIC0gQWZ0ZXIgcmVjZWl2aW5nIHRoZSBPVFAsIGluY2x1ZGUgaXQgYXMgdGhlIGBub25jZWAgaW4geW91ciBgdXBkYXRlVXNlcigpYCBjYWxsIHRvIGZpbmFsaXplIHRoZSBwYXNzd29yZCBjaGFuZ2UuXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gU2VuZCByZWF1dGhlbnRpY2F0aW9uIG5vbmNlXG4gICAqIFNlbmRzIGEgcmVhdXRoZW50aWNhdGlvbiBub25jZSB0byB0aGUgdXNlcidzIGVtYWlsIG9yIHBob25lIG51bWJlci5cbiAgICpcbiAgICogQGV4YW1wbGUgU2VuZCByZWF1dGhlbnRpY2F0aW9uIG5vbmNlXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgucmVhdXRoZW50aWNhdGUoKVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIHJlYXV0aGVudGljYXRlKCk6IFByb21pc2U8QXV0aFJlc3BvbnNlPiB7XG4gICAgYXdhaXQgdGhpcy5pbml0aWFsaXplUHJvbWlzZVxuXG4gICAgaWYgKHRoaXMubG9jayAhPSBudWxsKSB7XG4gICAgICAvLyBUT0RPKHYzKTogcmVtb3ZlIGxlZ2FjeSBsb2NrIHBhdGhcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9hY3F1aXJlTG9jayh0aGlzLmxvY2tBY3F1aXJlVGltZW91dCwgYXN5bmMgKCkgPT4ge1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fcmVhdXRoZW50aWNhdGUoKVxuICAgICAgfSlcbiAgICB9XG5cbiAgICByZXR1cm4gYXdhaXQgdGhpcy5fcmVhdXRoZW50aWNhdGUoKVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBfcmVhdXRoZW50aWNhdGUoKTogUHJvbWlzZTxBdXRoUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX3VzZVNlc3Npb24oYXN5bmMgKHJlc3VsdCkgPT4ge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgZGF0YTogeyBzZXNzaW9uIH0sXG4gICAgICAgICAgZXJyb3I6IHNlc3Npb25FcnJvcixcbiAgICAgICAgfSA9IHJlc3VsdFxuICAgICAgICBpZiAoc2Vzc2lvbkVycm9yKSB0aHJvdyBzZXNzaW9uRXJyb3JcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB0aHJvdyBuZXcgQXV0aFNlc3Npb25NaXNzaW5nRXJyb3IoKVxuXG4gICAgICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdHRVQnLCBgJHt0aGlzLnVybH0vcmVhdXRoZW50aWNhdGVgLCB7XG4gICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgIGp3dDogc2Vzc2lvbi5hY2Nlc3NfdG9rZW4sXG4gICAgICAgIH0pXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IG51bGwsIHNlc3Npb246IG51bGwgfSwgZXJyb3IgfSlcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmVzZW5kcyBhbiBleGlzdGluZyBzaWdudXAgY29uZmlybWF0aW9uIGVtYWlsLCBlbWFpbCBjaGFuZ2UgZW1haWwsIFNNUyBPVFAgb3IgcGhvbmUgY2hhbmdlIE9UUC5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSZXNlbmRzIGEgc2lnbnVwIGNvbmZpcm1hdGlvbiwgZW1haWwgY2hhbmdlIG9yIHBob25lIGNoYW5nZSBlbWFpbCB0byB0aGUgdXNlci5cbiAgICogLSBQYXNzd29yZGxlc3Mgc2lnbi1pbnMgY2FuIGJlIHJlc2VudCBieSBjYWxsaW5nIHRoZSBgc2lnbkluV2l0aE90cCgpYCBtZXRob2QgYWdhaW4uXG4gICAqIC0gUGFzc3dvcmQgcmVjb3ZlcnkgZW1haWxzIGNhbiBiZSByZXNlbnQgYnkgY2FsbGluZyB0aGUgYHJlc2V0UGFzc3dvcmRGb3JFbWFpbCgpYCBtZXRob2QgYWdhaW4uXG4gICAqIC0gVGhpcyBtZXRob2Qgd2lsbCBvbmx5IHJlc2VuZCBhbiBlbWFpbCBvciBwaG9uZSBPVFAgdG8gdGhlIHVzZXIgaWYgdGhlcmUgd2FzIGFuIGluaXRpYWwgc2lnbnVwLCBlbWFpbCBjaGFuZ2Ugb3IgcGhvbmUgY2hhbmdlIHJlcXVlc3QgYmVpbmcgbWFkZShub3RlOiBGb3IgZXhpc3RpbmcgdXNlcnMgc2lnbmluZyBpbiB3aXRoIE9UUCwgeW91IHNob3VsZCB1c2UgYHNpZ25JbldpdGhPdHAoKWAgYWdhaW4gdG8gcmVzZW5kIHRoZSBPVFApLlxuICAgKiAtIFlvdSBjYW4gc3BlY2lmeSBhIHJlZGlyZWN0IHVybCB3aGVuIHlvdSByZXNlbmQgYW4gZW1haWwgbGluayB1c2luZyB0aGUgYGVtYWlsUmVkaXJlY3RUb2Agb3B0aW9uLlxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFJlc2VuZCBhbiBlbWFpbCBzaWdudXAgY29uZmlybWF0aW9uXG4gICAqIFJlc2VuZHMgdGhlIGVtYWlsIHNpZ251cCBjb25maXJtYXRpb24gdG8gdGhlIHVzZXJcbiAgICpcbiAgICogQGV4YW1wbGUgUmVzZW5kIGFuIGVtYWlsIHNpZ251cCBjb25maXJtYXRpb25cbiAgICogYGBganNcbiAgICogY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5yZXNlbmQoe1xuICAgKiAgIHR5cGU6ICdzaWdudXAnLFxuICAgKiAgIGVtYWlsOiAnZW1haWxAZXhhbXBsZS5jb20nLFxuICAgKiAgIG9wdGlvbnM6IHtcbiAgICogICAgIGVtYWlsUmVkaXJlY3RUbzogJ2h0dHBzOi8vZXhhbXBsZS5jb20vd2VsY29tZSdcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFJlc2VuZCBhIHBob25lIHNpZ251cCBjb25maXJtYXRpb25cbiAgICogUmVzZW5kcyB0aGUgcGhvbmUgc2lnbnVwIGNvbmZpcm1hdGlvbiBlbWFpbCB0byB0aGUgdXNlclxuICAgKlxuICAgKiBAZXhhbXBsZSBSZXNlbmQgYSBwaG9uZSBzaWdudXAgY29uZmlybWF0aW9uXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgucmVzZW5kKHtcbiAgICogICB0eXBlOiAnc21zJyxcbiAgICogICBwaG9uZTogJzEyMzQ1Njc4OTAnXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFJlc2VuZCBlbWFpbCBjaGFuZ2UgZW1haWxcbiAgICogUmVzZW5kcyB0aGUgZW1haWwgY2hhbmdlIGVtYWlsIHRvIHRoZSB1c2VyXG4gICAqXG4gICAqIEBleGFtcGxlIFJlc2VuZCBlbWFpbCBjaGFuZ2UgZW1haWxcbiAgICogYGBganNcbiAgICogY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5yZXNlbmQoe1xuICAgKiAgIHR5cGU6ICdlbWFpbF9jaGFuZ2UnLFxuICAgKiAgIGVtYWlsOiAnZW1haWxAZXhhbXBsZS5jb20nXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFJlc2VuZCBwaG9uZSBjaGFuZ2UgT1RQXG4gICAqIFJlc2VuZHMgdGhlIHBob25lIGNoYW5nZSBPVFAgdG8gdGhlIHVzZXJcbiAgICpcbiAgICogQGV4YW1wbGUgUmVzZW5kIHBob25lIGNoYW5nZSBPVFBcbiAgICogYGBganNcbiAgICogY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5yZXNlbmQoe1xuICAgKiAgIHR5cGU6ICdwaG9uZV9jaGFuZ2UnLFxuICAgKiAgIHBob25lOiAnMTIzNDU2Nzg5MCdcbiAgICogfSlcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyByZXNlbmQoY3JlZGVudGlhbHM6IFJlc2VuZFBhcmFtcyk6IFByb21pc2U8QXV0aE90cFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGVuZHBvaW50ID0gYCR7dGhpcy51cmx9L3Jlc2VuZGBcbiAgICAgIGlmICgnZW1haWwnIGluIGNyZWRlbnRpYWxzKSB7XG4gICAgICAgIGNvbnN0IHsgZW1haWwsIHR5cGUsIG9wdGlvbnMgfSA9IGNyZWRlbnRpYWxzXG4gICAgICAgIGxldCBjb2RlQ2hhbGxlbmdlOiBzdHJpbmcgfCBudWxsID0gbnVsbFxuICAgICAgICBsZXQgY29kZUNoYWxsZW5nZU1ldGhvZDogc3RyaW5nIHwgbnVsbCA9IG51bGxcbiAgICAgICAgaWYgKHRoaXMuZmxvd1R5cGUgPT09ICdwa2NlJykge1xuICAgICAgICAgIDtbY29kZUNoYWxsZW5nZSwgY29kZUNoYWxsZW5nZU1ldGhvZF0gPSBhd2FpdCBnZXRDb2RlQ2hhbGxlbmdlQW5kTWV0aG9kKFxuICAgICAgICAgICAgdGhpcy5zdG9yYWdlLFxuICAgICAgICAgICAgdGhpcy5zdG9yYWdlS2V5XG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdQT1NUJywgZW5kcG9pbnQsIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgZW1haWwsXG4gICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogb3B0aW9ucz8uY2FwdGNoYVRva2VuIH0sXG4gICAgICAgICAgICBjb2RlX2NoYWxsZW5nZTogY29kZUNoYWxsZW5nZSxcbiAgICAgICAgICAgIGNvZGVfY2hhbGxlbmdlX21ldGhvZDogY29kZUNoYWxsZW5nZU1ldGhvZCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHJlZGlyZWN0VG86IG9wdGlvbnM/LmVtYWlsUmVkaXJlY3RUbyxcbiAgICAgICAgfSlcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9IGVsc2UgaWYgKCdwaG9uZScgaW4gY3JlZGVudGlhbHMpIHtcbiAgICAgICAgY29uc3QgeyBwaG9uZSwgdHlwZSwgb3B0aW9ucyB9ID0gY3JlZGVudGlhbHNcbiAgICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBlbmRwb2ludCwge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBwaG9uZSxcbiAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICBnb3RydWVfbWV0YV9zZWN1cml0eTogeyBjYXB0Y2hhX3Rva2VuOiBvcHRpb25zPy5jYXB0Y2hhVG9rZW4gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHtcbiAgICAgICAgICBkYXRhOiB7IHVzZXI6IG51bGwsIHNlc3Npb246IG51bGwsIG1lc3NhZ2VJZDogZGF0YT8ubWVzc2FnZV9pZCB9LFxuICAgICAgICAgIGVycm9yLFxuICAgICAgICB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEF1dGhJbnZhbGlkQ3JlZGVudGlhbHNFcnJvcihcbiAgICAgICAgJ1lvdSBtdXN0IHByb3ZpZGUgZWl0aGVyIGFuIGVtYWlsIG9yIHBob25lIG51bWJlciBhbmQgYSB0eXBlJ1xuICAgICAgKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBhd2FpdCByZW1vdmVJdGVtQXN5bmModGhpcy5zdG9yYWdlLCBgJHt0aGlzLnN0b3JhZ2VLZXl9LWNvZGUtdmVyaWZpZXJgKVxuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBzZXNzaW9uLCByZWZyZXNoaW5nIGl0IGlmIG5lY2Vzc2FyeS5cbiAgICpcbiAgICogVGhlIHNlc3Npb24gcmV0dXJuZWQgY2FuIGJlIG51bGwgaWYgdGhlIHNlc3Npb24gaXMgbm90IGRldGVjdGVkIHdoaWNoIGNhbiBoYXBwZW4gaW4gdGhlIGV2ZW50IGEgdXNlciBpcyBub3Qgc2lnbmVkLWluIG9yIGhhcyBsb2dnZWQgb3V0LlxuICAgKlxuICAgKiAqKklNUE9SVEFOVDoqKiBUaGlzIG1ldGhvZCBsb2FkcyB2YWx1ZXMgZGlyZWN0bHkgZnJvbSB0aGUgc3RvcmFnZSBhdHRhY2hlZFxuICAgKiB0byB0aGUgY2xpZW50LiBJZiB0aGF0IHN0b3JhZ2UgaXMgYmFzZWQgb24gcmVxdWVzdCBjb29raWVzIGZvciBleGFtcGxlLFxuICAgKiB0aGUgdmFsdWVzIGluIGl0IG1heSBub3QgYmUgYXV0aGVudGljIGFuZCB0aGVyZWZvcmUgaXQncyBzdHJvbmdseSBhZHZpc2VkXG4gICAqIGFnYWluc3QgdXNpbmcgdGhpcyBtZXRob2QgYW5kIGl0cyByZXN1bHRzIGluIHN1Y2ggY2lyY3Vtc3RhbmNlcy4gQSB3YXJuaW5nXG4gICAqIHdpbGwgYmUgZW1pdHRlZCBpZiB0aGlzIGlzIGRldGVjdGVkLiBVc2Uge0BsaW5rICNnZXRVc2VyKCl9IGluc3RlYWQuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gU2luY2UgdGhlIGludHJvZHVjdGlvbiBvZiBbYXN5bW1ldHJpYyBKV1Qgc2lnbmluZyBrZXlzXSgvZG9jcy9ndWlkZXMvYXV0aC9zaWduaW5nLWtleXMpLCB0aGlzIG1ldGhvZCBpcyBjb25zaWRlcmVkIGxvdy1sZXZlbCBhbmQgd2UgZW5jb3VyYWdlIHlvdSB0byB1c2UgYGdldENsYWltcygpYCBvciBgZ2V0VXNlcigpYCBpbnN0ZWFkLlxuICAgKiAtIFJldHJpZXZlcyB0aGUgY3VycmVudCBbdXNlciBzZXNzaW9uXSgvZG9jcy9ndWlkZXMvYXV0aC9zZXNzaW9ucykgZnJvbSB0aGUgc3RvcmFnZSBtZWRpdW0gKGxvY2FsIHN0b3JhZ2UsIGNvb2tpZXMpLlxuICAgKiAtIFRoZSBzZXNzaW9uIGNvbnRhaW5zIGFuIGFjY2VzcyB0b2tlbiAoc2lnbmVkIEpXVCksIGEgcmVmcmVzaCB0b2tlbiBhbmQgdGhlIHVzZXIgb2JqZWN0LlxuICAgKiAtIElmIHRoZSBzZXNzaW9uJ3MgYWNjZXNzIHRva2VuIGlzIGV4cGlyZWQgb3IgaXMgYWJvdXQgdG8gZXhwaXJlLCB0aGlzIG1ldGhvZCB3aWxsIHVzZSB0aGUgcmVmcmVzaCB0b2tlbiB0byByZWZyZXNoIHRoZSBzZXNzaW9uLlxuICAgKiAtIFdoZW4gdXNpbmcgaW4gYSBicm93c2VyLCBvciB5b3UndmUgY2FsbGVkIGBzdGFydEF1dG9SZWZyZXNoKClgIGluIHlvdXIgZW52aXJvbm1lbnQgKFJlYWN0IE5hdGl2ZSwgZXRjLikgdGhpcyBmdW5jdGlvbiBhbHdheXMgcmV0dXJucyBhIHZhbGlkIGFjY2VzcyB0b2tlbiB3aXRob3V0IHJlZnJlc2hpbmcgdGhlIHNlc3Npb24gaXRzZWxmLCBhcyB0aGlzIGlzIGRvbmUgaW4gdGhlIGJhY2tncm91bmQuIFRoaXMgZnVuY3Rpb24gcmV0dXJucyB2ZXJ5IGZhc3QuXG4gICAqIC0gKipJTVBPUlRBTlQgU0VDVVJJVFkgTk9USUNFOioqIElmIHVzaW5nIGFuIGluc2VjdXJlIHN0b3JhZ2UgbWVkaXVtLCBzdWNoIGFzIGNvb2tpZXMgb3IgcmVxdWVzdCBoZWFkZXJzLCB0aGUgdXNlciBvYmplY3QgcmV0dXJuZWQgYnkgdGhpcyBmdW5jdGlvbiAqKm11c3Qgbm90IGJlIHRydXN0ZWQqKi4gQWx3YXlzIHZlcmlmeSB0aGUgSldUIHVzaW5nIGBnZXRDbGFpbXMoKWAgb3IgeW91ciBvd24gSldUIHZlcmlmaWNhdGlvbiBsaWJyYXJ5IHRvIHNlY3VyZWx5IGVzdGFibGlzaCB0aGUgdXNlcidzIGlkZW50aXR5IGFuZCBhY2Nlc3MuIFlvdSBjYW4gYWxzbyB1c2UgYGdldFVzZXIoKWAgdG8gZmV0Y2ggdGhlIHVzZXIgb2JqZWN0IGRpcmVjdGx5IGZyb20gdGhlIEF1dGggc2VydmVyIGZvciB0aGlzIHB1cnBvc2UuXG4gICAqIC0gQ3Jvc3MtdGFiIHJlZnJlc2ggcmFjZXMgYXJlIGhhbmRsZWQgYnkgdGhlIEdvVHJ1ZSBzZXJ2ZXIgKHRoZSByb3RhdGVkIHRva2VuIGZyb20gdGhlIGZpcnN0IHRhYiBpcyByZXR1cm5lZCB0byBzdWJzZXF1ZW50IHRhYnMgdmlhIHRoZSBwYXJlbnQtb2YtYWN0aXZlIG1lY2hhbmlzbSksIHNvIG5vIGNsaWVudC1zaWRlIHNlcmlhbGl6YXRpb24gaXMgbmVlZGVkLlxuICAgKlxuICAgKiBAZXhhbXBsZSBHZXQgdGhlIHNlc3Npb24gZGF0YVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFNlc3Npb24oKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBHZXQgdGhlIHNlc3Npb24gZGF0YVxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJzZXNzaW9uXCI6IHtcbiAgICogICAgICAgXCJhY2Nlc3NfdG9rZW5cIjogXCI8QUNDRVNTX1RPS0VOPlwiLFxuICAgKiAgICAgICBcInRva2VuX3R5cGVcIjogXCJiZWFyZXJcIixcbiAgICogICAgICAgXCJleHBpcmVzX2luXCI6IDM2MDAsXG4gICAqICAgICAgIFwiZXhwaXJlc19hdFwiOiAxNzAwMDAwMDAwLFxuICAgKiAgICAgICBcInJlZnJlc2hfdG9rZW5cIjogXCI8UkVGUkVTSF9UT0tFTj5cIixcbiAgICogICAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlcnNcIjogW1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCJcbiAgICogICAgICAgICAgIF1cbiAgICogICAgICAgICB9LFxuICAgKiAgICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7XG4gICAqICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgIH0sXG4gICAqICAgICAgICAgXCJpZGVudGl0aWVzXCI6IFtcbiAgICogICAgICAgICAgIHtcbiAgICogICAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjIyMjIyMjIyLTIyMjItMjIyMi0yMjIyLTIyMjIyMjIyMjIyMlwiLFxuICAgKiAgICAgICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiXG4gICAqICAgICAgICAgICB9XG4gICAqICAgICAgICAgXSxcbiAgICogICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJpc19hbm9ueW1vdXNcIjogZmFsc2VcbiAgICogICAgICAgfVxuICAgKiAgICAgfVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBnZXRTZXNzaW9uKCkge1xuICAgIGF3YWl0IHRoaXMuaW5pdGlhbGl6ZVByb21pc2VcblxuICAgIGlmICh0aGlzLmxvY2sgIT0gbnVsbCkge1xuICAgICAgLy8gVE9ETyh2Myk6IHJlbW92ZSBsZWdhY3kgbG9jayBwYXRoXG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fYWNxdWlyZUxvY2sodGhpcy5sb2NrQWNxdWlyZVRpbWVvdXQsIGFzeW5jICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3VzZVNlc3Npb24oYXN5bmMgKHJlc3VsdCkgPT4ge1xuICAgICAgICAgIHJldHVybiByZXN1bHRcbiAgICAgICAgfSlcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuX3VzZVNlc3Npb24oYXN5bmMgKHJlc3VsdCkgPT4ge1xuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQWNxdWlyZXMgYSBnbG9iYWwgbG9jayBiYXNlZCBvbiB0aGUgc3RvcmFnZSBrZXkuXG4gICAqXG4gICAqIFRPRE8odjMpOiByZW1vdmUgYWxvbmcgd2l0aCB0aGUgbGVnYWN5IGxvY2sgcGF0aC4gT25seSBjYWxsZWQgd2hlblxuICAgKiBgdGhpcy5sb2NrYCBpcyBub24tbnVsbCAoY3VzdG9tIGxvY2sgc3VwcGxpZWQgdmlhIGNvbnN0cnVjdG9yKS4gVGhlXG4gICAqIGRlZmF1bHQgbG9ja2xlc3MgcGF0aCBieXBhc3NlcyB0aGlzIGVudGlyZWx5LlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfYWNxdWlyZUxvY2s8Uj4oYWNxdWlyZVRpbWVvdXQ6IG51bWJlciwgZm46ICgpID0+IFByb21pc2U8Uj4pOiBQcm9taXNlPFI+IHtcbiAgICB0aGlzLl9kZWJ1ZygnI19hY3F1aXJlTG9jaycsICdiZWdpbicsIGFjcXVpcmVUaW1lb3V0KVxuXG4gICAgdHJ5IHtcbiAgICAgIGlmICh0aGlzLmxvY2tBY3F1aXJlZCkge1xuICAgICAgICBjb25zdCBsYXN0ID0gdGhpcy5wZW5kaW5nSW5Mb2NrLmxlbmd0aFxuICAgICAgICAgID8gdGhpcy5wZW5kaW5nSW5Mb2NrW3RoaXMucGVuZGluZ0luTG9jay5sZW5ndGggLSAxXVxuICAgICAgICAgIDogUHJvbWlzZS5yZXNvbHZlKClcblxuICAgICAgICBjb25zdCByZXN1bHQgPSAoYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGF3YWl0IGxhc3RcbiAgICAgICAgICByZXR1cm4gYXdhaXQgZm4oKVxuICAgICAgICB9KSgpXG5cbiAgICAgICAgdGhpcy5wZW5kaW5nSW5Mb2NrLnB1c2goXG4gICAgICAgICAgKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGF3YWl0IHJlc3VsdFxuICAgICAgICAgICAgfSBjYXRjaCAoX2UpIHtcbiAgICAgICAgICAgICAgLy8gd2UganVzdCBjYXJlIGlmIGl0IGZpbmlzaGVkXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSkoKVxuICAgICAgICApXG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgfVxuXG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5sb2NrIShgbG9jazoke3RoaXMuc3RvcmFnZUtleX1gLCBhY3F1aXJlVGltZW91dCwgYXN5bmMgKCkgPT4ge1xuICAgICAgICB0aGlzLl9kZWJ1ZygnI19hY3F1aXJlTG9jaycsICdsb2NrIGFjcXVpcmVkIGZvciBzdG9yYWdlIGtleScsIHRoaXMuc3RvcmFnZUtleSlcblxuICAgICAgICB0cnkge1xuICAgICAgICAgIHRoaXMubG9ja0FjcXVpcmVkID0gdHJ1ZVxuXG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gZm4oKVxuXG4gICAgICAgICAgdGhpcy5wZW5kaW5nSW5Mb2NrLnB1c2goXG4gICAgICAgICAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGF3YWl0IHJlc3VsdFxuICAgICAgICAgICAgICB9IGNhdGNoIChlOiBhbnkpIHtcbiAgICAgICAgICAgICAgICAvLyB3ZSBqdXN0IGNhcmUgaWYgaXQgZmluaXNoZWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSkoKVxuICAgICAgICAgIClcblxuICAgICAgICAgIGF3YWl0IHJlc3VsdFxuXG4gICAgICAgICAgLy8ga2VlcCBkcmFpbmluZyB0aGUgcXVldWUgdW50aWwgdGhlcmUncyBub3RoaW5nIHRvIHdhaXQgb25cbiAgICAgICAgICB3aGlsZSAodGhpcy5wZW5kaW5nSW5Mb2NrLmxlbmd0aCkge1xuICAgICAgICAgICAgY29uc3Qgd2FpdE9uID0gWy4uLnRoaXMucGVuZGluZ0luTG9ja11cblxuICAgICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwod2FpdE9uKVxuXG4gICAgICAgICAgICB0aGlzLnBlbmRpbmdJbkxvY2suc3BsaWNlKDAsIHdhaXRPbi5sZW5ndGgpXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHJlc3VsdFxuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIHRoaXMuX2RlYnVnKCcjX2FjcXVpcmVMb2NrJywgJ2xvY2sgcmVsZWFzZWQgZm9yIHN0b3JhZ2Uga2V5JywgdGhpcy5zdG9yYWdlS2V5KVxuXG4gICAgICAgICAgdGhpcy5sb2NrQWNxdWlyZWQgPSBmYWxzZVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0gZmluYWxseSB7XG4gICAgICB0aGlzLl9kZWJ1ZygnI19hY3F1aXJlTG9jaycsICdlbmQnKVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBVc2UgaW5zdGVhZCBvZiB7QGxpbmsgI2dldFNlc3Npb259IGluc2lkZSB0aGUgbGlicmFyeS4gTG9hZHMgdGhlIHNlc3Npb25cbiAgICogdmlhIGBfX2xvYWRTZXNzaW9uYCAod2hpY2ggbWF5IHRyaWdnZXIgYSByZWZyZXNoIGlmIHRoZSBhY2Nlc3MgdG9rZW4gaXNcbiAgICogd2l0aGluIHRoZSBleHBpcnkgbWFyZ2luKSBhbmQgcnVucyBgZm5gIHdpdGggdGhlIHJlc3VsdC5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3VzZVNlc3Npb248Uj4oXG4gICAgZm46IChcbiAgICAgIHJlc3VsdDpcbiAgICAgICAgfCB7XG4gICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgIHNlc3Npb246IFNlc3Npb25cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVycm9yOiBudWxsXG4gICAgICAgICAgfVxuICAgICAgICB8IHtcbiAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgc2Vzc2lvbjogbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZXJyb3I6IEF1dGhFcnJvclxuICAgICAgICAgIH1cbiAgICAgICAgfCB7XG4gICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgIHNlc3Npb246IG51bGxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVycm9yOiBudWxsXG4gICAgICAgICAgfVxuICAgICkgPT4gUHJvbWlzZTxSPlxuICApOiBQcm9taXNlPFI+IHtcbiAgICB0aGlzLl9kZWJ1ZygnI191c2VTZXNzaW9uJywgJ2JlZ2luJylcblxuICAgIHRyeSB7XG4gICAgICAvLyBDb25jdXJyZW50IGNhbGxlcnMgbWF5IGJvdGggcmVhY2ggX19sb2FkU2Vzc2lvbjsgc3RvcmFnZSByZWFkcyBhcmVcbiAgICAgIC8vIGlkZW1wb3RlbnQsIGFuZCB0aGUgb25seSB3cml0ZSBwYXRoIGluc2lkZSBpdCAocmVmcmVzaCkgaXNcbiAgICAgIC8vIHNpbmdsZS1mbGlnaHRlZCBkb3duc3RyZWFtIGJ5IGByZWZyZXNoaW5nRGVmZXJyZWRgIGluXG4gICAgICAvLyBgX2NhbGxSZWZyZXNoVG9rZW5gLiBObyBzZXJpYWxpemF0aW9uIGlzIG5lZWRlZCBhdCB0aGlzIGxheWVyLlxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5fX2xvYWRTZXNzaW9uKClcblxuICAgICAgcmV0dXJuIGF3YWl0IGZuKHJlc3VsdClcbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5fZGVidWcoJyNfdXNlU2Vzc2lvbicsICdlbmQnKVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBORVZFUiBVU0UgRElSRUNUTFkhXG4gICAqXG4gICAqIEFsd2F5cyB1c2Uge0BsaW5rICNfdXNlU2Vzc2lvbn0uXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9fbG9hZFNlc3Npb24oKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgIHNlc3Npb246IFNlc3Npb25cbiAgICAgICAgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgc2Vzc2lvbjogbnVsbFxuICAgICAgICB9XG4gICAgICAgIGVycm9yOiBBdXRoRXJyb3JcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgIHNlc3Npb246IG51bGxcbiAgICAgICAgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICA+IHtcbiAgICB0aGlzLl9kZWJ1ZygnI19fbG9hZFNlc3Npb24oKScsICdiZWdpbicpXG5cbiAgICBpZiAodGhpcy5sb2NrICE9IG51bGwgJiYgIXRoaXMubG9ja0FjcXVpcmVkKSB7XG4gICAgICAvLyBUT0RPKHYzKTogcmVtb3ZlLiBPbmx5IG1lYW5pbmdmdWwgb24gdGhlIGxlZ2FjeSBsb2NrIHBhdGguXG4gICAgICB0aGlzLl9kZWJ1ZygnI19fbG9hZFNlc3Npb24oKScsICd1c2VkIG91dHNpZGUgb2YgYW4gYWNxdWlyZWQgbG9jayEnLCBuZXcgRXJyb3IoKS5zdGFjaylcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgbGV0IGN1cnJlbnRTZXNzaW9uOiBTZXNzaW9uIHwgbnVsbCA9IG51bGxcblxuICAgICAgY29uc3QgbWF5YmVTZXNzaW9uID0gYXdhaXQgZ2V0SXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgdGhpcy5zdG9yYWdlS2V5KVxuXG4gICAgICB0aGlzLl9kZWJ1ZygnI2dldFNlc3Npb24oKScsICdzZXNzaW9uIGZyb20gc3RvcmFnZScsIG1heWJlU2Vzc2lvbilcblxuICAgICAgaWYgKG1heWJlU2Vzc2lvbiAhPT0gbnVsbCkge1xuICAgICAgICBpZiAodGhpcy5faXNWYWxpZFNlc3Npb24obWF5YmVTZXNzaW9uKSkge1xuICAgICAgICAgIGN1cnJlbnRTZXNzaW9uID0gbWF5YmVTZXNzaW9uXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5fZGVidWcoJyNnZXRTZXNzaW9uKCknLCAnc2Vzc2lvbiBmcm9tIHN0b3JhZ2UgaXMgbm90IHZhbGlkJylcbiAgICAgICAgICBhd2FpdCB0aGlzLl9yZW1vdmVTZXNzaW9uKClcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIWN1cnJlbnRTZXNzaW9uKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IHsgc2Vzc2lvbjogbnVsbCB9LCBlcnJvcjogbnVsbCB9XG4gICAgICB9XG5cbiAgICAgIC8vIEEgc2Vzc2lvbiBpcyBjb25zaWRlcmVkIGV4cGlyZWQgYmVmb3JlIHRoZSBhY2Nlc3MgdG9rZW4gX2FjdHVhbGx5X1xuICAgICAgLy8gZXhwaXJlcy4gV2hlbiB0aGUgYXV0b1JlZnJlc2hUb2tlbiBvcHRpb24gaXMgb2ZmIChvciB3aGVuIHRoZSB0YWIgaXNcbiAgICAgIC8vIGluIHRoZSBiYWNrZ3JvdW5kKSwgdmVyeSBlYWdlciB1c2VycyBvZiBnZXRTZXNzaW9uKCkgLS0gbGlrZVxuICAgICAgLy8gcmVhbHRpbWUtanMgLS0gbWlnaHQgc2VuZCBhIHZhbGlkIEpXVCB3aGljaCB3aWxsIGV4cGlyZSBieSB0aGUgdGltZSBpdFxuICAgICAgLy8gcmVhY2hlcyB0aGUgc2VydmVyLlxuICAgICAgY29uc3QgaGFzRXhwaXJlZCA9IGN1cnJlbnRTZXNzaW9uLmV4cGlyZXNfYXRcbiAgICAgICAgPyBjdXJyZW50U2Vzc2lvbi5leHBpcmVzX2F0ICogMTAwMCAtIERhdGUubm93KCkgPCBFWFBJUllfTUFSR0lOX01TXG4gICAgICAgIDogZmFsc2VcblxuICAgICAgdGhpcy5fZGVidWcoXG4gICAgICAgICcjX19sb2FkU2Vzc2lvbigpJyxcbiAgICAgICAgYHNlc3Npb24gaGFzJHtoYXNFeHBpcmVkID8gJycgOiAnIG5vdCd9IGV4cGlyZWRgLFxuICAgICAgICAnZXhwaXJlc19hdCcsXG4gICAgICAgIGN1cnJlbnRTZXNzaW9uLmV4cGlyZXNfYXRcbiAgICAgIClcblxuICAgICAgaWYgKCFoYXNFeHBpcmVkKSB7XG4gICAgICAgIGlmICh0aGlzLnVzZXJTdG9yYWdlKSB7XG4gICAgICAgICAgY29uc3QgbWF5YmVVc2VyOiB7IHVzZXI/OiBVc2VyIHwgbnVsbCB9IHwgbnVsbCA9IChhd2FpdCBnZXRJdGVtQXN5bmMoXG4gICAgICAgICAgICB0aGlzLnVzZXJTdG9yYWdlLFxuICAgICAgICAgICAgdGhpcy5zdG9yYWdlS2V5ICsgJy11c2VyJ1xuICAgICAgICAgICkpIGFzIGFueVxuXG4gICAgICAgICAgaWYgKG1heWJlVXNlcj8udXNlcikge1xuICAgICAgICAgICAgY3VycmVudFNlc3Npb24udXNlciA9IG1heWJlVXNlci51c2VyXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGN1cnJlbnRTZXNzaW9uLnVzZXIgPSB1c2VyTm90QXZhaWxhYmxlUHJveHkoKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFdyYXAgdGhlIHVzZXIgb2JqZWN0IHdpdGggYSB3YXJuaW5nIHByb3h5IG9uIHRoZSBzZXJ2ZXJcbiAgICAgICAgLy8gVGhpcyB3YXJucyB3aGVuIHByb3BlcnRpZXMgb2YgdGhlIHVzZXIgYXJlIGFjY2Vzc2VkLCBub3Qgd2hlbiBzZXNzaW9uLnVzZXIgaXRzZWxmIGlzIGFjY2Vzc2VkXG4gICAgICAgIGlmIChcbiAgICAgICAgICB0aGlzLnN0b3JhZ2UuaXNTZXJ2ZXIgJiZcbiAgICAgICAgICBjdXJyZW50U2Vzc2lvbi51c2VyICYmXG4gICAgICAgICAgIShjdXJyZW50U2Vzc2lvbi51c2VyIGFzIGFueSkuX19pc1VzZXJOb3RBdmFpbGFibGVQcm94eVxuICAgICAgICApIHtcbiAgICAgICAgICBjb25zdCBzdXBwcmVzc1dhcm5pbmdSZWYgPSB7IHZhbHVlOiB0aGlzLnN1cHByZXNzR2V0U2Vzc2lvbldhcm5pbmcgfVxuICAgICAgICAgIGN1cnJlbnRTZXNzaW9uLnVzZXIgPSBpbnNlY3VyZVVzZXJXYXJuaW5nUHJveHkoY3VycmVudFNlc3Npb24udXNlciwgc3VwcHJlc3NXYXJuaW5nUmVmKVxuXG4gICAgICAgICAgLy8gVXBkYXRlIHRoZSBjbGllbnQtbGV2ZWwgc3VwcHJlc3Npb24gZmxhZyB3aGVuIHRoZSBwcm94eSBzdXBwcmVzc2VzIHRoZSB3YXJuaW5nXG4gICAgICAgICAgaWYgKHN1cHByZXNzV2FybmluZ1JlZi52YWx1ZSkge1xuICAgICAgICAgICAgdGhpcy5zdXBwcmVzc0dldFNlc3Npb25XYXJuaW5nID0gdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB7IGRhdGE6IHsgc2Vzc2lvbjogY3VycmVudFNlc3Npb24gfSwgZXJyb3I6IG51bGwgfVxuICAgICAgfVxuXG4gICAgICBjb25zdCB7IGRhdGE6IHNlc3Npb24sIGVycm9yIH0gPSBhd2FpdCB0aGlzLl9jYWxsUmVmcmVzaFRva2VuKGN1cnJlbnRTZXNzaW9uLnJlZnJlc2hfdG9rZW4pXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyBzZXNzaW9uIH0sIGVycm9yOiBudWxsIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuX2RlYnVnKCcjX19sb2FkU2Vzc2lvbigpJywgJ2VuZCcpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgdGhlIGN1cnJlbnQgdXNlciBkZXRhaWxzIGlmIHRoZXJlIGlzIGFuIGV4aXN0aW5nIHNlc3Npb24uIFRoaXMgbWV0aG9kXG4gICAqIHBlcmZvcm1zIGEgbmV0d29yayByZXF1ZXN0IHRvIHRoZSBTdXBhYmFzZSBBdXRoIHNlcnZlciwgc28gdGhlIHJldHVybmVkXG4gICAqIHZhbHVlIGlzIGF1dGhlbnRpYyBhbmQgY2FuIGJlIHVzZWQgdG8gYmFzZSBhdXRob3JpemF0aW9uIHJ1bGVzIG9uLlxuICAgKlxuICAgKiBAcGFyYW0gand0IFRha2VzIGluIGFuIG9wdGlvbmFsIGFjY2VzcyB0b2tlbiBKV1QuIElmIG5vIEpXVCBpcyBwcm92aWRlZCwgdGhlIEpXVCBmcm9tIHRoZSBjdXJyZW50IHNlc3Npb24gaXMgdXNlZC5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBUaGlzIG1ldGhvZCBmZXRjaGVzIHRoZSB1c2VyIG9iamVjdCBmcm9tIHRoZSBkYXRhYmFzZSBpbnN0ZWFkIG9mIGxvY2FsIHNlc3Npb24uXG4gICAqIC0gVGhpcyBtZXRob2QgaXMgdXNlZnVsIGZvciBjaGVja2luZyBpZiB0aGUgdXNlciBpcyBhdXRob3JpemVkIGJlY2F1c2UgaXQgdmFsaWRhdGVzIHRoZSB1c2VyJ3MgYWNjZXNzIHRva2VuIEpXVCBvbiB0aGUgc2VydmVyLlxuICAgKiAtIFNob3VsZCBhbHdheXMgYmUgdXNlZCB3aGVuIGNoZWNraW5nIGZvciB1c2VyIGF1dGhvcml6YXRpb24gb24gdGhlIHNlcnZlci4gT24gdGhlIGNsaWVudCwgeW91IGNhbiBpbnN0ZWFkIHVzZSBgZ2V0U2Vzc2lvbigpLnNlc3Npb24udXNlcmAgZm9yIGZhc3RlciByZXN1bHRzLiBgZ2V0U2Vzc2lvbmAgaXMgaW5zZWN1cmUgb24gdGhlIHNlcnZlci5cbiAgICpcbiAgICogQGV4YW1wbGUgR2V0IHRoZSBsb2dnZWQgaW4gdXNlciB3aXRoIHRoZSBjdXJyZW50IGV4aXN0aW5nIHNlc3Npb25cbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgR2V0IHRoZSBsb2dnZWQgaW4gdXNlciB3aXRoIHRoZSBjdXJyZW50IGV4aXN0aW5nIHNlc3Npb25cbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJwaG9uZVwiOiBcIlwiLFxuICAgKiAgICAgICBcImNvbmZpcm1lZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgIFwicHJvdmlkZXJzXCI6IFtcbiAgICogICAgICAgICAgIFwiZW1haWxcIlxuICAgKiAgICAgICAgIF1cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICB9LFxuICAgKiAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIF0sXG4gICAqICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiaXNfYW5vbnltb3VzXCI6IGZhbHNlXG4gICAqICAgICB9XG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgR2V0IHRoZSBsb2dnZWQgaW4gdXNlciB3aXRoIGEgY3VzdG9tIGFjY2VzcyB0b2tlbiBqd3RcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKGp3dClcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBnZXRVc2VyKGp3dD86IHN0cmluZyk6IFByb21pc2U8VXNlclJlc3BvbnNlPiB7XG4gICAgaWYgKGp3dCkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX2dldFVzZXIoand0KVxuICAgIH1cblxuICAgIGF3YWl0IHRoaXMuaW5pdGlhbGl6ZVByb21pc2VcblxuICAgIGxldCByZXN1bHQ6IFVzZXJSZXNwb25zZVxuICAgIGlmICh0aGlzLmxvY2sgIT0gbnVsbCkge1xuICAgICAgLy8gVE9ETyh2Myk6IHJlbW92ZSBsZWdhY3kgbG9jayBwYXRoXG4gICAgICByZXN1bHQgPSBhd2FpdCB0aGlzLl9hY3F1aXJlTG9jayh0aGlzLmxvY2tBY3F1aXJlVGltZW91dCwgYXN5bmMgKCkgPT4ge1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fZ2V0VXNlcigpXG4gICAgICB9KVxuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHQgPSBhd2FpdCB0aGlzLl9nZXRVc2VyKClcbiAgICB9XG5cbiAgICBpZiAocmVzdWx0LmRhdGEudXNlcikge1xuICAgICAgdGhpcy5zdXBwcmVzc0dldFNlc3Npb25XYXJuaW5nID0gdHJ1ZVxuICAgIH1cblxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2dldFVzZXIoand0Pzogc3RyaW5nKTogUHJvbWlzZTxVc2VyUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKGp3dCkge1xuICAgICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ0dFVCcsIGAke3RoaXMudXJsfS91c2VyYCwge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBqd3Q6IGp3dCxcbiAgICAgICAgICB4Zm9ybTogX3VzZXJSZXNwb25zZSxcbiAgICAgICAgfSlcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX3VzZVNlc3Npb24oYXN5bmMgKHJlc3VsdCkgPT4ge1xuICAgICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSByZXN1bHRcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHJldHVybnMgYW4gZXJyb3IgaWYgdGhlcmUgaXMgbm8gYWNjZXNzX3Rva2VuIG9yIGN1c3RvbSBhdXRob3JpemF0aW9uIGhlYWRlclxuICAgICAgICBpZiAoIWRhdGEuc2Vzc2lvbj8uYWNjZXNzX3Rva2VuICYmICF0aGlzLmhhc0N1c3RvbUF1dGhvcml6YXRpb25IZWFkZXIpIHtcbiAgICAgICAgICByZXR1cm4geyBkYXRhOiB7IHVzZXI6IG51bGwgfSwgZXJyb3I6IG5ldyBBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcigpIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnR0VUJywgYCR7dGhpcy51cmx9L3VzZXJgLCB7XG4gICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgIGp3dDogZGF0YS5zZXNzaW9uPy5hY2Nlc3NfdG9rZW4gPz8gdW5kZWZpbmVkLFxuICAgICAgICAgIHhmb3JtOiBfdXNlclJlc3BvbnNlLFxuICAgICAgICB9KVxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICBpZiAoaXNBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcihlcnJvcikpIHtcbiAgICAgICAgICAvLyBKV1QgY29udGFpbnMgYSBgc2Vzc2lvbl9pZGAgd2hpY2ggZG9lcyBub3QgY29ycmVzcG9uZCB0byBhbiBhY3RpdmVcbiAgICAgICAgICAvLyBzZXNzaW9uIGluIHRoZSBkYXRhYmFzZSwgaW5kaWNhdGluZyB0aGUgdXNlciBpcyBzaWduZWQgb3V0LlxuXG4gICAgICAgICAgYXdhaXQgdGhpcy5fcmVtb3ZlU2Vzc2lvbigpXG4gICAgICAgICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IG51bGwgfSwgZXJyb3IgfSlcbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlcyB1c2VyIGRhdGEgZm9yIGEgbG9nZ2VkIGluIHVzZXIuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gSW4gb3JkZXIgdG8gdXNlIHRoZSBgdXBkYXRlVXNlcigpYCBtZXRob2QsIHRoZSB1c2VyIG5lZWRzIHRvIGJlIHNpZ25lZCBpbiBmaXJzdC5cbiAgICogLSBCeSBkZWZhdWx0LCBlbWFpbCB1cGRhdGVzIHNlbmRzIGEgY29uZmlybWF0aW9uIGxpbmsgdG8gYm90aCB0aGUgdXNlcidzIGN1cnJlbnQgYW5kIG5ldyBlbWFpbC5cbiAgICogVG8gb25seSBzZW5kIGEgY29uZmlybWF0aW9uIGxpbmsgdG8gdGhlIHVzZXIncyBuZXcgZW1haWwsIGRpc2FibGUgKipTZWN1cmUgZW1haWwgY2hhbmdlKiogaW4geW91ciBwcm9qZWN0J3MgW2VtYWlsIGF1dGggcHJvdmlkZXIgc2V0dGluZ3NdKC9kYXNoYm9hcmQvcHJvamVjdC9fL2F1dGgvcHJvdmlkZXJzKS5cbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBVcGRhdGUgdGhlIGVtYWlsIGZvciBhbiBhdXRoZW50aWNhdGVkIHVzZXJcbiAgICogU2VuZHMgYSBcIkNvbmZpcm0gRW1haWwgQ2hhbmdlXCIgZW1haWwgdG8gdGhlIG5ldyBhZGRyZXNzLiBJZiAqKlNlY3VyZSBFbWFpbCBDaGFuZ2UqKiBpcyBlbmFibGVkIChkZWZhdWx0KSwgY29uZmlybWF0aW9uIGlzIGFsc28gcmVxdWlyZWQgZnJvbSB0aGUgKipvbGQgZW1haWwqKiBiZWZvcmUgdGhlIGNoYW5nZSBpcyBhcHBsaWVkLiBUbyBza2lwIGR1YWwgY29uZmlybWF0aW9uIGFuZCBhcHBseSB0aGUgY2hhbmdlIGFmdGVyIG9ubHkgdGhlIG5ldyBlbWFpbCBpcyB2ZXJpZmllZCwgZGlzYWJsZSAqKlNlY3VyZSBFbWFpbCBDaGFuZ2UqKiBpbiB0aGUgW0VtYWlsIEF1dGggUHJvdmlkZXIgc2V0dGluZ3NdKC9kYXNoYm9hcmQvcHJvamVjdC9fL2F1dGgvcHJvdmlkZXJzP3Byb3ZpZGVyPUVtYWlsKS5cbiAgICpcbiAgICogQGV4YW1wbGUgVXBkYXRlIHRoZSBlbWFpbCBmb3IgYW4gYXV0aGVudGljYXRlZCB1c2VyXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgudXBkYXRlVXNlcih7XG4gICAqICAgZW1haWw6ICduZXdAZW1haWwuY29tJ1xuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBVcGRhdGUgdGhlIGVtYWlsIGZvciBhbiBhdXRoZW50aWNhdGVkIHVzZXJcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJwaG9uZVwiOiBcIlwiLFxuICAgKiAgICAgICBcImNvbmZpcm1lZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwibmV3X2VtYWlsXCI6IFwibmV3QGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICBcImVtYWlsX2NoYW5nZV9zZW50X2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcImFwcF9tZXRhZGF0YVwiOiB7XG4gICAqICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgXCJwcm92aWRlcnNcIjogW1xuICAgKiAgICAgICAgICAgXCJlbWFpbFwiXG4gICAqICAgICAgICAgXVxuICAgKiAgICAgICB9LFxuICAgKiAgICAgICBcInVzZXJfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgIH0sXG4gICAqICAgICAgIFwiaWRlbnRpdGllc1wiOiBbXG4gICAqICAgICAgICAge1xuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjIyMjIyMjIyLTIyMjItMjIyMi0yMjIyLTIyMjIyMjIyMjIyMlwiLFxuICAgKiAgICAgICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJ1c2VyX2lkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgICAgXCJlbWFpbF92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgICAgfSxcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIlxuICAgKiAgICAgICAgIH1cbiAgICogICAgICAgXSxcbiAgICogICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJpc19hbm9ueW1vdXNcIjogZmFsc2VcbiAgICogICAgIH1cbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFVwZGF0ZSB0aGUgcGhvbmUgbnVtYmVyIGZvciBhbiBhdXRoZW50aWNhdGVkIHVzZXJcbiAgICogU2VuZHMgYSBvbmUtdGltZSBwYXNzd29yZCAoT1RQKSB0byB0aGUgbmV3IHBob25lIG51bWJlci5cbiAgICpcbiAgICogQGV4YW1wbGUgVXBkYXRlIHRoZSBwaG9uZSBudW1iZXIgZm9yIGFuIGF1dGhlbnRpY2F0ZWQgdXNlclxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnVwZGF0ZVVzZXIoe1xuICAgKiAgIHBob25lOiAnMTIzNDU2Nzg5J1xuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgVXBkYXRlIHRoZSBwYXNzd29yZCBmb3IgYW4gYXV0aGVudGljYXRlZCB1c2VyXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgudXBkYXRlVXNlcih7XG4gICAqICAgcGFzc3dvcmQ6ICduZXcgcGFzc3dvcmQnXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFVwZGF0ZSB0aGUgdXNlcidzIG1ldGFkYXRhXG4gICAqIFVwZGF0ZXMgdGhlIHVzZXIncyBjdXN0b20gbWV0YWRhdGEuXG4gICAqXG4gICAqICoqTm90ZSoqOiBUaGUgYGRhdGFgIGZpZWxkIG1hcHMgdG8gdGhlIGBhdXRoLnVzZXJzLnJhd191c2VyX21ldGFfZGF0YWAgY29sdW1uIGluIHlvdXIgU3VwYWJhc2UgZGF0YWJhc2UuIFdoZW4gY2FsbGluZyBgZ2V0VXNlcigpYCwgdGhlIGRhdGEgd2lsbCBiZSBhdmFpbGFibGUgYXMgYHVzZXIudXNlcl9tZXRhZGF0YWAuXG4gICAqXG4gICAqIEBleGFtcGxlIFVwZGF0ZSB0aGUgdXNlcidzIG1ldGFkYXRhXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgudXBkYXRlVXNlcih7XG4gICAqICAgZGF0YTogeyBoZWxsbzogJ3dvcmxkJyB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFVwZGF0ZSB0aGUgdXNlcidzIHBhc3N3b3JkIHdpdGggYSBub25jZVxuICAgKiBJZiAqKlNlY3VyZSBwYXNzd29yZCBjaGFuZ2UqKiBpcyBlbmFibGVkIGluIHlvdXIgW3Byb2plY3QncyBlbWFpbCBwcm92aWRlciBzZXR0aW5nc10oL2Rhc2hib2FyZC9wcm9qZWN0L18vYXV0aC9wcm92aWRlcnMpLCB1cGRhdGluZyB0aGUgdXNlcidzIHBhc3N3b3JkIHdvdWxkIHJlcXVpcmUgYSBub25jZSBpZiB0aGUgdXNlciAqKmhhc24ndCByZWNlbnRseSBzaWduZWQgaW4qKi4gVGhlIG5vbmNlIGlzIHNlbnQgdG8gdGhlIHVzZXIncyBlbWFpbCBvciBwaG9uZSBudW1iZXIuIEEgdXNlciBpcyBkZWVtZWQgcmVjZW50bHkgc2lnbmVkIGluIGlmIHRoZSBzZXNzaW9uIHdhcyBjcmVhdGVkIGluIHRoZSBsYXN0IDI0IGhvdXJzLlxuICAgKlxuICAgKiBAZXhhbXBsZSBVcGRhdGUgdGhlIHVzZXIncyBwYXNzd29yZCB3aXRoIGEgbm9uY2VcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC51cGRhdGVVc2VyKHtcbiAgICogICBwYXNzd29yZDogJ25ldyBwYXNzd29yZCcsXG4gICAqICAgbm9uY2U6ICcxMjM0NTYnXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgdXBkYXRlVXNlcihcbiAgICBhdHRyaWJ1dGVzOiBVc2VyQXR0cmlidXRlcyxcbiAgICBvcHRpb25zOiB7XG4gICAgICBlbWFpbFJlZGlyZWN0VG8/OiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgICB9ID0ge31cbiAgKTogUHJvbWlzZTxVc2VyUmVzcG9uc2U+IHtcbiAgICBhd2FpdCB0aGlzLmluaXRpYWxpemVQcm9taXNlXG5cbiAgICBpZiAodGhpcy5sb2NrICE9IG51bGwpIHtcbiAgICAgIC8vIFRPRE8odjMpOiByZW1vdmUgbGVnYWN5IGxvY2sgcGF0aFxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX2FjcXVpcmVMb2NrKHRoaXMubG9ja0FjcXVpcmVUaW1lb3V0LCBhc3luYyAoKSA9PiB7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91cGRhdGVVc2VyKGF0dHJpYnV0ZXMsIG9wdGlvbnMpXG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCB0aGlzLl91cGRhdGVVc2VyKGF0dHJpYnV0ZXMsIG9wdGlvbnMpXG4gIH1cblxuICBwcm90ZWN0ZWQgYXN5bmMgX3VwZGF0ZVVzZXIoXG4gICAgYXR0cmlidXRlczogVXNlckF0dHJpYnV0ZXMsXG4gICAgb3B0aW9uczoge1xuICAgICAgZW1haWxSZWRpcmVjdFRvPzogc3RyaW5nIHwgdW5kZWZpbmVkXG4gICAgfSA9IHt9XG4gICk6IFByb21pc2U8VXNlclJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBzZXNzaW9uRGF0YSwgZXJyb3I6IHNlc3Npb25FcnJvciB9ID0gcmVzdWx0XG4gICAgICAgIGlmIChzZXNzaW9uRXJyb3IpIHtcbiAgICAgICAgICB0aHJvdyBzZXNzaW9uRXJyb3JcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXNlc3Npb25EYXRhLnNlc3Npb24pIHtcbiAgICAgICAgICB0aHJvdyBuZXcgQXV0aFNlc3Npb25NaXNzaW5nRXJyb3IoKVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNlc3Npb246IFNlc3Npb24gPSBzZXNzaW9uRGF0YS5zZXNzaW9uXG4gICAgICAgIGxldCBjb2RlQ2hhbGxlbmdlOiBzdHJpbmcgfCBudWxsID0gbnVsbFxuICAgICAgICBsZXQgY29kZUNoYWxsZW5nZU1ldGhvZDogc3RyaW5nIHwgbnVsbCA9IG51bGxcbiAgICAgICAgaWYgKHRoaXMuZmxvd1R5cGUgPT09ICdwa2NlJyAmJiBhdHRyaWJ1dGVzLmVtYWlsICE9IG51bGwpIHtcbiAgICAgICAgICA7W2NvZGVDaGFsbGVuZ2UsIGNvZGVDaGFsbGVuZ2VNZXRob2RdID0gYXdhaXQgZ2V0Q29kZUNoYWxsZW5nZUFuZE1ldGhvZChcbiAgICAgICAgICAgIHRoaXMuc3RvcmFnZSxcbiAgICAgICAgICAgIHRoaXMuc3RvcmFnZUtleVxuICAgICAgICAgIClcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BVVCcsIGAke3RoaXMudXJsfS91c2VyYCwge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICByZWRpcmVjdFRvOiBvcHRpb25zPy5lbWFpbFJlZGlyZWN0VG8sXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgLi4uYXR0cmlidXRlcyxcbiAgICAgICAgICAgIGNvZGVfY2hhbGxlbmdlOiBjb2RlQ2hhbGxlbmdlLFxuICAgICAgICAgICAgY29kZV9jaGFsbGVuZ2VfbWV0aG9kOiBjb2RlQ2hhbGxlbmdlTWV0aG9kLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgand0OiBzZXNzaW9uLmFjY2Vzc190b2tlbixcbiAgICAgICAgICB4Zm9ybTogX3VzZXJSZXNwb25zZSxcbiAgICAgICAgfSlcbiAgICAgICAgaWYgKHVzZXJFcnJvcikge1xuICAgICAgICAgIHRocm93IHVzZXJFcnJvclxuICAgICAgICB9XG4gICAgICAgIHNlc3Npb24udXNlciA9IGRhdGEudXNlciBhcyBVc2VyXG4gICAgICAgIGF3YWl0IHRoaXMuX3NhdmVTZXNzaW9uKHNlc3Npb24pXG4gICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdVU0VSX1VQREFURUQnLCBzZXNzaW9uKVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBzZXNzaW9uLnVzZXIgfSwgZXJyb3I6IG51bGwgfSlcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGF3YWl0IHJlbW92ZUl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIGAke3RoaXMuc3RvcmFnZUtleX0tY29kZS12ZXJpZmllcmApXG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IG51bGwgfSwgZXJyb3IgfSlcbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU2V0cyB0aGUgc2Vzc2lvbiBkYXRhIGZyb20gdGhlIGN1cnJlbnQgc2Vzc2lvbi4gSWYgdGhlIGN1cnJlbnQgc2Vzc2lvbiBpcyBleHBpcmVkLCBzZXRTZXNzaW9uIHdpbGwgdGFrZSBjYXJlIG9mIHJlZnJlc2hpbmcgaXQgdG8gb2J0YWluIGEgbmV3IHNlc3Npb24uXG4gICAqIElmIHRoZSByZWZyZXNoIHRva2VuIG9yIGFjY2VzcyB0b2tlbiBpbiB0aGUgY3VycmVudCBzZXNzaW9uIGlzIGludmFsaWQsIGFuIGVycm9yIHdpbGwgYmUgdGhyb3duLlxuICAgKiBAcGFyYW0gY3VycmVudFNlc3Npb24gVGhlIGN1cnJlbnQgc2Vzc2lvbiB0aGF0IG1pbmltYWxseSBjb250YWlucyBhbiBhY2Nlc3MgdG9rZW4gYW5kIHJlZnJlc2ggdG9rZW4uXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVGhpcyBtZXRob2Qgc2V0cyB0aGUgc2Vzc2lvbiB1c2luZyBhbiBgYWNjZXNzX3Rva2VuYCBhbmQgYHJlZnJlc2hfdG9rZW5gLlxuICAgKiAtIElmIHN1Y2Nlc3NmdWwsIGEgYFNJR05FRF9JTmAgZXZlbnQgaXMgZW1pdHRlZC5cbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBTZXQgdGhlIHNlc3Npb25cbiAgICogU2V0cyB0aGUgc2Vzc2lvbiBkYXRhIGZyb20gYW4gYWNjZXNzX3Rva2VuIGFuZCByZWZyZXNoX3Rva2VuLCB0aGVuIHJldHVybnMgYW4gYXV0aCByZXNwb25zZSBvciBlcnJvci5cbiAgICpcbiAgICogQGV4YW1wbGUgU2V0IHRoZSBzZXNzaW9uXG4gICAqIGBgYGpzXG4gICAqICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zZXRTZXNzaW9uKHtcbiAgICogICAgIGFjY2Vzc190b2tlbixcbiAgICogICAgIHJlZnJlc2hfdG9rZW5cbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBTZXQgdGhlIHNlc3Npb25cbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJwaG9uZVwiOiBcIlwiLFxuICAgKiAgICAgICBcImNvbmZpcm1lZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgIFwicHJvdmlkZXJzXCI6IFtcbiAgICogICAgICAgICAgIFwiZW1haWxcIlxuICAgKiAgICAgICAgIF1cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICB9LFxuICAgKiAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIF0sXG4gICAqICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiaXNfYW5vbnltb3VzXCI6IGZhbHNlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzZXNzaW9uXCI6IHtcbiAgICogICAgICAgXCJhY2Nlc3NfdG9rZW5cIjogXCI8QUNDRVNTX1RPS0VOPlwiLFxuICAgKiAgICAgICBcInJlZnJlc2hfdG9rZW5cIjogXCI8UkVGUkVTSF9UT0tFTj5cIixcbiAgICogICAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgICAgXCJjb25maXJtZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyc1wiOiBbXG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIlxuICAgKiAgICAgICAgICAgXVxuICAgKiAgICAgICAgIH0sXG4gICAqICAgICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgXCJlbWFpbF92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgICAge1xuICAgKiAgICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgICBcInVzZXJfaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIlxuICAgKiAgICAgICAgICAgfVxuICAgKiAgICAgICAgIF0sXG4gICAqICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwiaXNfYW5vbnltb3VzXCI6IGZhbHNlXG4gICAqICAgICAgIH0sXG4gICAqICAgICAgIFwidG9rZW5fdHlwZVwiOiBcImJlYXJlclwiLFxuICAgKiAgICAgICBcImV4cGlyZXNfaW5cIjogMzUwMCxcbiAgICogICAgICAgXCJleHBpcmVzX2F0XCI6IDE3MDAwMDAwMDBcbiAgICogICAgIH1cbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgc2V0U2Vzc2lvbihjdXJyZW50U2Vzc2lvbjoge1xuICAgIGFjY2Vzc190b2tlbjogc3RyaW5nXG4gICAgcmVmcmVzaF90b2tlbjogc3RyaW5nXG4gIH0pOiBQcm9taXNlPEF1dGhSZXNwb25zZT4ge1xuICAgIGF3YWl0IHRoaXMuaW5pdGlhbGl6ZVByb21pc2VcblxuICAgIGlmICh0aGlzLmxvY2sgIT0gbnVsbCkge1xuICAgICAgLy8gVE9ETyh2Myk6IHJlbW92ZSBsZWdhY3kgbG9jayBwYXRoXG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fYWNxdWlyZUxvY2sodGhpcy5sb2NrQWNxdWlyZVRpbWVvdXQsIGFzeW5jICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX3NldFNlc3Npb24oY3VycmVudFNlc3Npb24pXG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCB0aGlzLl9zZXRTZXNzaW9uKGN1cnJlbnRTZXNzaW9uKVxuICB9XG5cbiAgcHJvdGVjdGVkIGFzeW5jIF9zZXRTZXNzaW9uKGN1cnJlbnRTZXNzaW9uOiB7XG4gICAgYWNjZXNzX3Rva2VuOiBzdHJpbmdcbiAgICByZWZyZXNoX3Rva2VuOiBzdHJpbmdcbiAgfSk6IFByb21pc2U8QXV0aFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIGlmICghY3VycmVudFNlc3Npb24uYWNjZXNzX3Rva2VuIHx8ICFjdXJyZW50U2Vzc2lvbi5yZWZyZXNoX3Rva2VuKSB7XG4gICAgICAgIHRocm93IG5ldyBBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcigpXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRpbWVOb3cgPSBEYXRlLm5vdygpIC8gMTAwMFxuICAgICAgbGV0IGV4cGlyZXNBdCA9IHRpbWVOb3dcbiAgICAgIGxldCBoYXNFeHBpcmVkID0gdHJ1ZVxuICAgICAgbGV0IHNlc3Npb246IFNlc3Npb24gfCBudWxsID0gbnVsbFxuICAgICAgY29uc3QgeyBwYXlsb2FkIH0gPSBkZWNvZGVKV1QoY3VycmVudFNlc3Npb24uYWNjZXNzX3Rva2VuKVxuICAgICAgaWYgKHBheWxvYWQuZXhwKSB7XG4gICAgICAgIGV4cGlyZXNBdCA9IHBheWxvYWQuZXhwXG4gICAgICAgIGhhc0V4cGlyZWQgPSBleHBpcmVzQXQgPD0gdGltZU5vd1xuICAgICAgfVxuXG4gICAgICBpZiAoaGFzRXhwaXJlZCkge1xuICAgICAgICBjb25zdCB7IGRhdGE6IHJlZnJlc2hlZFNlc3Npb24sIGVycm9yIH0gPSBhd2FpdCB0aGlzLl9jYWxsUmVmcmVzaFRva2VuKFxuICAgICAgICAgIGN1cnJlbnRTZXNzaW9uLnJlZnJlc2hfdG9rZW5cbiAgICAgICAgKVxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yOiBlcnJvciB9KVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFyZWZyZXNoZWRTZXNzaW9uKSB7XG4gICAgICAgICAgcmV0dXJuIHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yOiBudWxsIH1cbiAgICAgICAgfVxuICAgICAgICBzZXNzaW9uID0gcmVmcmVzaGVkU2Vzc2lvblxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgdGhpcy5fZ2V0VXNlcihjdXJyZW50U2Vzc2lvbi5hY2Nlc3NfdG9rZW4pXG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IG51bGwsIHNlc3Npb246IG51bGwgfSwgZXJyb3IgfSlcbiAgICAgICAgfVxuICAgICAgICBzZXNzaW9uID0ge1xuICAgICAgICAgIGFjY2Vzc190b2tlbjogY3VycmVudFNlc3Npb24uYWNjZXNzX3Rva2VuLFxuICAgICAgICAgIHJlZnJlc2hfdG9rZW46IGN1cnJlbnRTZXNzaW9uLnJlZnJlc2hfdG9rZW4sXG4gICAgICAgICAgdXNlcjogZGF0YS51c2VyLFxuICAgICAgICAgIHRva2VuX3R5cGU6ICdiZWFyZXInLFxuICAgICAgICAgIGV4cGlyZXNfaW46IGV4cGlyZXNBdCAtIHRpbWVOb3csXG4gICAgICAgICAgZXhwaXJlc19hdDogZXhwaXJlc0F0LFxuICAgICAgICB9XG4gICAgICAgIGF3YWl0IHRoaXMuX3NhdmVTZXNzaW9uKHNlc3Npb24pXG4gICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdTSUdORURfSU4nLCBzZXNzaW9uKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBzZXNzaW9uLnVzZXIsIHNlc3Npb24gfSwgZXJyb3I6IG51bGwgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyBzZXNzaW9uOiBudWxsLCB1c2VyOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBuZXcgc2Vzc2lvbiwgcmVnYXJkbGVzcyBvZiBleHBpcnkgc3RhdHVzLlxuICAgKiBUYWtlcyBpbiBhbiBvcHRpb25hbCBjdXJyZW50IHNlc3Npb24uIElmIG5vdCBwYXNzZWQgaW4sIHRoZW4gcmVmcmVzaFNlc3Npb24oKSB3aWxsIGF0dGVtcHQgdG8gcmV0cmlldmUgaXQgZnJvbSBnZXRTZXNzaW9uKCkuXG4gICAqIElmIHRoZSBjdXJyZW50IHNlc3Npb24ncyByZWZyZXNoIHRva2VuIGlzIGludmFsaWQsIGFuIGVycm9yIHdpbGwgYmUgdGhyb3duLlxuICAgKiBAcGFyYW0gY3VycmVudFNlc3Npb24gVGhlIGN1cnJlbnQgc2Vzc2lvbi4gSWYgcGFzc2VkIGluLCBpdCBtdXN0IGNvbnRhaW4gYSByZWZyZXNoIHRva2VuLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFRoaXMgbWV0aG9kIHdpbGwgcmVmcmVzaCBhbmQgcmV0dXJuIGEgbmV3IHNlc3Npb24gd2hldGhlciB0aGUgY3VycmVudCBvbmUgaXMgZXhwaXJlZCBvciBub3QuXG4gICAqXG4gICAqIEBleGFtcGxlIFJlZnJlc2ggc2Vzc2lvbiB1c2luZyB0aGUgY3VycmVudCBzZXNzaW9uXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgucmVmcmVzaFNlc3Npb24oKVxuICAgKiBjb25zdCB7IHNlc3Npb24sIHVzZXIgfSA9IGRhdGFcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgUmVmcmVzaCBzZXNzaW9uIHVzaW5nIHRoZSBjdXJyZW50IHNlc3Npb25cbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJwaG9uZVwiOiBcIlwiLFxuICAgKiAgICAgICBcImNvbmZpcm1lZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJhcHBfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgIFwicHJvdmlkZXJzXCI6IFtcbiAgICogICAgICAgICAgIFwiZW1haWxcIlxuICAgKiAgICAgICAgIF1cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJ1c2VyX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICB9LFxuICAgKiAgICAgICBcImlkZW50aXRpZXNcIjogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICAgIFwiZW1haWxfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIF0sXG4gICAqICAgICAgIFwiY3JlYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiaXNfYW5vbnltb3VzXCI6IGZhbHNlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzZXNzaW9uXCI6IHtcbiAgICogICAgICAgXCJhY2Nlc3NfdG9rZW5cIjogXCI8QUNDRVNTX1RPS0VOPlwiLFxuICAgKiAgICAgICBcInRva2VuX3R5cGVcIjogXCJiZWFyZXJcIixcbiAgICogICAgICAgXCJleHBpcmVzX2luXCI6IDM2MDAsXG4gICAqICAgICAgIFwiZXhwaXJlc19hdFwiOiAxNzAwMDAwMDAwLFxuICAgKiAgICAgICBcInJlZnJlc2hfdG9rZW5cIjogXCI8UkVGUkVTSF9UT0tFTj5cIixcbiAgICogICAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgIFwiZW1haWxfY29uZmlybWVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgICAgXCJjb25maXJtZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcImFwcF9tZXRhZGF0YVwiOiB7XG4gICAqICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJzXCI6IFtcbiAgICogICAgICAgICAgICAgXCJlbWFpbFwiXG4gICAqICAgICAgICAgICBdXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgICBcInVzZXJfbWV0YWRhdGFcIjoge1xuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICB9LFxuICAgKiAgICAgICAgIFwiaWRlbnRpdGllc1wiOiBbXG4gICAqICAgICAgICAgICB7XG4gICAqICAgICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgICBcInVzZXJfaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgICAgXCJpZGVudGl0eV9kYXRhXCI6IHtcbiAgICogICAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIlxuICAgKiAgICAgICAgICAgfVxuICAgKiAgICAgICAgIF0sXG4gICAqICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwiaXNfYW5vbnltb3VzXCI6IGZhbHNlXG4gICAqICAgICAgIH1cbiAgICogICAgIH1cbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBSZWZyZXNoIHNlc3Npb24gdXNpbmcgYSByZWZyZXNoIHRva2VuXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgucmVmcmVzaFNlc3Npb24oeyByZWZyZXNoX3Rva2VuIH0pXG4gICAqIGNvbnN0IHsgc2Vzc2lvbiwgdXNlciB9ID0gZGF0YVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIHJlZnJlc2hTZXNzaW9uKGN1cnJlbnRTZXNzaW9uPzogeyByZWZyZXNoX3Rva2VuOiBzdHJpbmcgfSk6IFByb21pc2U8QXV0aFJlc3BvbnNlPiB7XG4gICAgYXdhaXQgdGhpcy5pbml0aWFsaXplUHJvbWlzZVxuXG4gICAgaWYgKHRoaXMubG9jayAhPSBudWxsKSB7XG4gICAgICAvLyBUT0RPKHYzKTogcmVtb3ZlIGxlZ2FjeSBsb2NrIHBhdGhcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9hY3F1aXJlTG9jayh0aGlzLmxvY2tBY3F1aXJlVGltZW91dCwgYXN5bmMgKCkgPT4ge1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fcmVmcmVzaFNlc3Npb24oY3VycmVudFNlc3Npb24pXG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCB0aGlzLl9yZWZyZXNoU2Vzc2lvbihjdXJyZW50U2Vzc2lvbilcbiAgfVxuXG4gIHByb3RlY3RlZCBhc3luYyBfcmVmcmVzaFNlc3Npb24oY3VycmVudFNlc3Npb24/OiB7XG4gICAgcmVmcmVzaF90b2tlbjogc3RyaW5nXG4gIH0pOiBQcm9taXNlPEF1dGhSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmICghY3VycmVudFNlc3Npb24pIHtcbiAgICAgICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSByZXN1bHRcbiAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IGVycm9yXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY3VycmVudFNlc3Npb24gPSBkYXRhLnNlc3Npb24gPz8gdW5kZWZpbmVkXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIWN1cnJlbnRTZXNzaW9uPy5yZWZyZXNoX3Rva2VuKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEF1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKClcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHsgZGF0YTogc2Vzc2lvbiwgZXJyb3IgfSA9IGF3YWl0IHRoaXMuX2NhbGxSZWZyZXNoVG9rZW4oY3VycmVudFNlc3Npb24ucmVmcmVzaF90b2tlbilcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvcjogZXJyb3IgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IG51bGwsIHNlc3Npb246IG51bGwgfSwgZXJyb3I6IG51bGwgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHVzZXI6IHNlc3Npb24udXNlciwgc2Vzc2lvbiB9LCBlcnJvcjogbnVsbCB9KVxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgdGhlIHNlc3Npb24gZGF0YSBmcm9tIGEgVVJMIHN0cmluZ1xuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZ2V0U2Vzc2lvbkZyb21VUkwoXG4gICAgcGFyYW1zOiB7IFtwYXJhbWV0ZXI6IHN0cmluZ106IHN0cmluZyB9LFxuICAgIGNhbGxiYWNrVXJsVHlwZTogc3RyaW5nXG4gICk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHsgc2Vzc2lvbjogU2Vzc2lvbjsgcmVkaXJlY3RUeXBlOiBzdHJpbmcgfCBudWxsIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHsgZGF0YTogeyBzZXNzaW9uOiBudWxsOyByZWRpcmVjdFR5cGU6IG51bGwgfTsgZXJyb3I6IEF1dGhFcnJvciB9XG4gID4ge1xuICAgIHRyeSB7XG4gICAgICBpZiAoIWlzQnJvd3NlcigpKSB0aHJvdyBuZXcgQXV0aEltcGxpY2l0R3JhbnRSZWRpcmVjdEVycm9yKCdObyBicm93c2VyIGRldGVjdGVkLicpXG5cbiAgICAgIC8vIElmIHRoZXJlJ3MgYW4gZXJyb3IgaW4gdGhlIFVSTCwgaXQgZG9lc24ndCBtYXR0ZXIgd2hhdCBmbG93IGl0IGlzLCB3ZSBqdXN0IHJldHVybiB0aGUgZXJyb3IuXG4gICAgICBpZiAocGFyYW1zLmVycm9yIHx8IHBhcmFtcy5lcnJvcl9kZXNjcmlwdGlvbiB8fCBwYXJhbXMuZXJyb3JfY29kZSkge1xuICAgICAgICAvLyBUaGUgZXJyb3IgY2xhc3MgcmV0dXJuZWQgaW1wbGllcyB0aGF0IHRoZSByZWRpcmVjdCBpcyBmcm9tIGFuIGltcGxpY2l0IGdyYW50IGZsb3dcbiAgICAgICAgLy8gYnV0IGl0IGNvdWxkIGFsc28gYmUgZnJvbSBhIHJlZGlyZWN0IGVycm9yIGZyb20gYSBQS0NFIGZsb3cuXG4gICAgICAgIHRocm93IG5ldyBBdXRoSW1wbGljaXRHcmFudFJlZGlyZWN0RXJyb3IoXG4gICAgICAgICAgcGFyYW1zLmVycm9yX2Rlc2NyaXB0aW9uIHx8ICdFcnJvciBpbiBVUkwgd2l0aCB1bnNwZWNpZmllZCBlcnJvcl9kZXNjcmlwdGlvbicsXG4gICAgICAgICAge1xuICAgICAgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvciB8fCAndW5zcGVjaWZpZWRfZXJyb3InLFxuICAgICAgICAgICAgY29kZTogcGFyYW1zLmVycm9yX2NvZGUgfHwgJ3Vuc3BlY2lmaWVkX2NvZGUnLFxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICAvLyBDaGVja3MgZm9yIG1pc21hdGNoZXMgYmV0d2VlbiB0aGUgZmxvd1R5cGUgaW5pdGlhbGlzZWQgaW4gdGhlIGNsaWVudCBhbmQgdGhlIFVSTCBwYXJhbWV0ZXJzXG4gICAgICBzd2l0Y2ggKGNhbGxiYWNrVXJsVHlwZSkge1xuICAgICAgICBjYXNlICdpbXBsaWNpdCc6XG4gICAgICAgICAgaWYgKHRoaXMuZmxvd1R5cGUgPT09ICdwa2NlJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEF1dGhQS0NFR3JhbnRDb2RlRXhjaGFuZ2VFcnJvcignTm90IGEgdmFsaWQgUEtDRSBmbG93IHVybC4nKVxuICAgICAgICAgIH1cbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlICdwa2NlJzpcbiAgICAgICAgICBpZiAodGhpcy5mbG93VHlwZSA9PT0gJ2ltcGxpY2l0Jykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEF1dGhJbXBsaWNpdEdyYW50UmVkaXJlY3RFcnJvcignTm90IGEgdmFsaWQgaW1wbGljaXQgZ3JhbnQgZmxvdyB1cmwuJylcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgLy8gdGhlcmUncyBubyBtaXNtYXRjaCBzbyB3ZSBjb250aW51ZVxuICAgICAgfVxuXG4gICAgICAvLyBTaW5jZSB0aGlzIGlzIGEgcmVkaXJlY3QgZm9yIFBLQ0UsIHdlIGF0dGVtcHQgdG8gcmV0cmlldmUgdGhlIGNvZGUgZnJvbSB0aGUgVVJMIGZvciB0aGUgY29kZSBleGNoYW5nZVxuICAgICAgaWYgKGNhbGxiYWNrVXJsVHlwZSA9PT0gJ3BrY2UnKSB7XG4gICAgICAgIHRoaXMuX2RlYnVnKCcjX2luaXRpYWxpemUoKScsICdiZWdpbicsICdpcyBQS0NFIGZsb3cnLCB0cnVlKVxuICAgICAgICBpZiAoIXBhcmFtcy5jb2RlKSB0aHJvdyBuZXcgQXV0aFBLQ0VHcmFudENvZGVFeGNoYW5nZUVycm9yKCdObyBjb2RlIGRldGVjdGVkLicpXG4gICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHRoaXMuX2V4Y2hhbmdlQ29kZUZvclNlc3Npb24ocGFyYW1zLmNvZGUpXG4gICAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3JcblxuICAgICAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHdpbmRvdy5sb2NhdGlvbi5ocmVmKVxuICAgICAgICB1cmwuc2VhcmNoUGFyYW1zLmRlbGV0ZSgnY29kZScpXG5cbiAgICAgICAgd2luZG93Lmhpc3RvcnkucmVwbGFjZVN0YXRlKHdpbmRvdy5oaXN0b3J5LnN0YXRlLCAnJywgdXJsLnRvU3RyaW5nKCkpXG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBkYXRhOiB7IHNlc3Npb246IGRhdGEuc2Vzc2lvbiwgcmVkaXJlY3RUeXBlOiBkYXRhLnJlZGlyZWN0VHlwZSA/PyBudWxsIH0sXG4gICAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3Qge1xuICAgICAgICBwcm92aWRlcl90b2tlbixcbiAgICAgICAgcHJvdmlkZXJfcmVmcmVzaF90b2tlbixcbiAgICAgICAgYWNjZXNzX3Rva2VuLFxuICAgICAgICByZWZyZXNoX3Rva2VuLFxuICAgICAgICBleHBpcmVzX2luLFxuICAgICAgICBleHBpcmVzX2F0LFxuICAgICAgICB0b2tlbl90eXBlLFxuICAgICAgfSA9IHBhcmFtc1xuXG4gICAgICBpZiAoIWFjY2Vzc190b2tlbiB8fCAhZXhwaXJlc19pbiB8fCAhcmVmcmVzaF90b2tlbiB8fCAhdG9rZW5fdHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgQXV0aEltcGxpY2l0R3JhbnRSZWRpcmVjdEVycm9yKCdObyBzZXNzaW9uIGRlZmluZWQgaW4gVVJMJylcbiAgICAgIH1cblxuICAgICAgY29uc3QgdGltZU5vdyA9IE1hdGgucm91bmQoRGF0ZS5ub3coKSAvIDEwMDApXG4gICAgICBjb25zdCBleHBpcmVzSW4gPSBwYXJzZUludChleHBpcmVzX2luKVxuICAgICAgbGV0IGV4cGlyZXNBdCA9IHRpbWVOb3cgKyBleHBpcmVzSW5cblxuICAgICAgaWYgKGV4cGlyZXNfYXQpIHtcbiAgICAgICAgZXhwaXJlc0F0ID0gcGFyc2VJbnQoZXhwaXJlc19hdClcbiAgICAgIH1cblxuICAgICAgY29uc3QgYWN0dWFsbHlFeHBpcmVzSW4gPSBleHBpcmVzQXQgLSB0aW1lTm93XG4gICAgICBpZiAoYWN0dWFsbHlFeHBpcmVzSW4gKiAxMDAwIDw9IEFVVE9fUkVGUkVTSF9USUNLX0RVUkFUSU9OX01TKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBgQHN1cGFiYXNlL2dvdHJ1ZS1qczogU2Vzc2lvbiBhcyByZXRyaWV2ZWQgZnJvbSBVUkwgZXhwaXJlcyBpbiAke2FjdHVhbGx5RXhwaXJlc0lufXMsIHNob3VsZCBoYXZlIGJlZW4gY2xvc2VyIHRvICR7ZXhwaXJlc0lufXNgXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgY29uc3QgaXNzdWVkQXQgPSBleHBpcmVzQXQgLSBleHBpcmVzSW5cbiAgICAgIGlmICh0aW1lTm93IC0gaXNzdWVkQXQgPj0gMTIwKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAnQHN1cGFiYXNlL2dvdHJ1ZS1qczogU2Vzc2lvbiBhcyByZXRyaWV2ZWQgZnJvbSBVUkwgd2FzIGlzc3VlZCBvdmVyIDEyMHMgYWdvLCBVUkwgY291bGQgYmUgc3RhbGUnLFxuICAgICAgICAgIGlzc3VlZEF0LFxuICAgICAgICAgIGV4cGlyZXNBdCxcbiAgICAgICAgICB0aW1lTm93XG4gICAgICAgIClcbiAgICAgIH0gZWxzZSBpZiAodGltZU5vdyAtIGlzc3VlZEF0IDwgMCkge1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgJ0BzdXBhYmFzZS9nb3RydWUtanM6IFNlc3Npb24gYXMgcmV0cmlldmVkIGZyb20gVVJMIHdhcyBpc3N1ZWQgaW4gdGhlIGZ1dHVyZT8gQ2hlY2sgdGhlIGRldmljZSBjbG9jayBmb3Igc2tldycsXG4gICAgICAgICAgaXNzdWVkQXQsXG4gICAgICAgICAgZXhwaXJlc0F0LFxuICAgICAgICAgIHRpbWVOb3dcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCB0aGlzLl9nZXRVc2VyKGFjY2Vzc190b2tlbilcbiAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3JcblxuICAgICAgY29uc3Qgc2Vzc2lvbjogU2Vzc2lvbiA9IHtcbiAgICAgICAgcHJvdmlkZXJfdG9rZW4sXG4gICAgICAgIHByb3ZpZGVyX3JlZnJlc2hfdG9rZW4sXG4gICAgICAgIGFjY2Vzc190b2tlbixcbiAgICAgICAgZXhwaXJlc19pbjogZXhwaXJlc0luLFxuICAgICAgICBleHBpcmVzX2F0OiBleHBpcmVzQXQsXG4gICAgICAgIHJlZnJlc2hfdG9rZW4sXG4gICAgICAgIHRva2VuX3R5cGU6IHRva2VuX3R5cGUgYXMgJ2JlYXJlcicsXG4gICAgICAgIHVzZXI6IGRhdGEudXNlcixcbiAgICAgIH1cblxuICAgICAgLy8gUmVtb3ZlIHRva2VucyBmcm9tIFVSTFxuICAgICAgd2luZG93LmxvY2F0aW9uLmhhc2ggPSAnJ1xuICAgICAgdGhpcy5fZGVidWcoJyNfZ2V0U2Vzc2lvbkZyb21VUkwoKScsICdjbGVhcmluZyB3aW5kb3cubG9jYXRpb24uaGFzaCcpXG5cbiAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHNlc3Npb24sIHJlZGlyZWN0VHlwZTogcGFyYW1zLnR5cGUgfSwgZXJyb3I6IG51bGwgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyBzZXNzaW9uOiBudWxsLCByZWRpcmVjdFR5cGU6IG51bGwgfSwgZXJyb3IgfSlcbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIGlmIHRoZSBjdXJyZW50IFVSTCBjb250YWlucyBwYXJhbWV0ZXJzIGdpdmVuIGJ5IGFuIGltcGxpY2l0IG9hdXRoIGdyYW50IGZsb3cgKGh0dHBzOi8vd3d3LnJmYy1lZGl0b3Iub3JnL3JmYy9yZmM2NzQ5Lmh0bWwjc2VjdGlvbi00LjIpXG4gICAqXG4gICAqIElmIGBkZXRlY3RTZXNzaW9uSW5VcmxgIGlzIGEgZnVuY3Rpb24sIGl0IHdpbGwgYmUgY2FsbGVkIHdpdGggdGhlIFVSTCBhbmQgcGFyYW1zIHRvIGRldGVybWluZVxuICAgKiBpZiB0aGUgVVJMIHNob3VsZCBiZSBwcm9jZXNzZWQgYXMgYSBTdXBhYmFzZSBhdXRoIGNhbGxiYWNrLiBUaGlzIGFsbG93cyB1c2VycyB0byBleGNsdWRlXG4gICAqIFVSTHMgZnJvbSBvdGhlciBPQXV0aCBwcm92aWRlcnMgKGUuZy4sIEZhY2Vib29rIExvZ2luKSB0aGF0IGFsc28gcmV0dXJuIGFjY2Vzc190b2tlbiBpbiB0aGUgZnJhZ21lbnQuXG4gICAqL1xuICBwcml2YXRlIF9pc0ltcGxpY2l0R3JhbnRDYWxsYmFjayhwYXJhbXM6IHsgW3BhcmFtZXRlcjogc3RyaW5nXTogc3RyaW5nIH0pOiBib29sZWFuIHtcbiAgICBpZiAodHlwZW9mIHRoaXMuZGV0ZWN0U2Vzc2lvbkluVXJsID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICByZXR1cm4gdGhpcy5kZXRlY3RTZXNzaW9uSW5VcmwobmV3IFVSTCh3aW5kb3cubG9jYXRpb24uaHJlZiksIHBhcmFtcylcbiAgICB9XG4gICAgcmV0dXJuIEJvb2xlYW4oXG4gICAgICBwYXJhbXMuYWNjZXNzX3Rva2VuIHx8IHBhcmFtcy5lcnJvciB8fCBwYXJhbXMuZXJyb3JfZGVzY3JpcHRpb24gfHwgcGFyYW1zLmVycm9yX2NvZGVcbiAgICApXG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIGlmIHRoZSBjdXJyZW50IFVSTCBhbmQgYmFja2luZyBzdG9yYWdlIGNvbnRhaW4gcGFyYW1ldGVycyBnaXZlbiBieSBhIFBLQ0UgZmxvd1xuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfaXNQS0NFQ2FsbGJhY2socGFyYW1zOiB7IFtwYXJhbWV0ZXI6IHN0cmluZ106IHN0cmluZyB9KTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgY29uc3QgY3VycmVudFN0b3JhZ2VDb250ZW50ID0gYXdhaXQgZ2V0SXRlbUFzeW5jKFxuICAgICAgdGhpcy5zdG9yYWdlLFxuICAgICAgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYFxuICAgIClcblxuICAgIHJldHVybiAhIShwYXJhbXMuY29kZSAmJiBjdXJyZW50U3RvcmFnZUNvbnRlbnQpXG4gIH1cblxuICAvKipcbiAgICogSW5zaWRlIGEgYnJvd3NlciBjb250ZXh0LCBgc2lnbk91dCgpYCB3aWxsIHJlbW92ZSB0aGUgbG9nZ2VkIGluIHVzZXIgZnJvbSB0aGUgYnJvd3NlciBzZXNzaW9uIGFuZCBsb2cgdGhlbSBvdXQgLSByZW1vdmluZyBhbGwgaXRlbXMgZnJvbSBsb2NhbHN0b3JhZ2UgYW5kIHRoZW4gdHJpZ2dlciBhIGBcIlNJR05FRF9PVVRcImAgZXZlbnQuXG4gICAqXG4gICAqIEZvciBzZXJ2ZXItc2lkZSBtYW5hZ2VtZW50LCB5b3UgY2FuIHJldm9rZSBhbGwgcmVmcmVzaCB0b2tlbnMgZm9yIGEgdXNlciBieSBwYXNzaW5nIGEgdXNlcidzIEpXVCB0aHJvdWdoIHRvIGBhdXRoLmFwaS5zaWduT3V0KEpXVDogc3RyaW5nKWAuXG4gICAqIFRoZXJlIGlzIG5vIHdheSB0byByZXZva2UgYSB1c2VyJ3MgYWNjZXNzIHRva2VuIGp3dCB1bnRpbCBpdCBleHBpcmVzLiBJdCBpcyByZWNvbW1lbmRlZCB0byBzZXQgYSBzaG9ydGVyIGV4cGlyeSBvbiB0aGUgand0IGZvciB0aGlzIHJlYXNvbi5cbiAgICpcbiAgICogSWYgdXNpbmcgYG90aGVyc2Agc2NvcGUsIG5vIGBTSUdORURfT1VUYCBldmVudCBpcyBmaXJlZCFcbiAgICpcbiAgICogKipXYXJuaW5nOioqIHRoZSBkZWZhdWx0IGBzY29wZWAgaXMgYCdnbG9iYWwnYC4gVGhpcyBzaWducyB0aGUgdXNlciBvdXQgb2ZcbiAgICogKipldmVyeSBkZXZpY2UgdGhleSBhcmUgY3VycmVudGx5IHNpZ25lZCBpbiBvbioqLCBub3QganVzdCB0aGUgY3VycmVudFxuICAgKiB0YWIvc2Vzc2lvbi4gSWYgeW91IG9ubHkgd2FudCB0byBzaWduIHRoZSB1c2VyIG91dCBvZiB0aGUgY3VycmVudCBzZXNzaW9uXG4gICAqICh0aGUgYmVoYXZpb3IgbW9zdCBvdGhlciBhdXRoIGxpYnJhcmllcyBkZWZhdWx0IHRvKSwgcGFzc1xuICAgKiBgeyBzY29wZTogJ2xvY2FsJyB9YCBleHBsaWNpdGx5LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEluIG9yZGVyIHRvIHVzZSB0aGUgYHNpZ25PdXQoKWAgbWV0aG9kLCB0aGUgdXNlciBuZWVkcyB0byBiZSBzaWduZWQgaW4gZmlyc3QuXG4gICAqIC0gQnkgZGVmYXVsdCwgYHNpZ25PdXQoKWAgdXNlcyB0aGUgKipnbG9iYWwqKiBzY29wZSwgd2hpY2ggc2lnbnMgb3V0IHRoZSB1c2VyXG4gICAqICAgb24gZXZlcnkgZGV2aWNlIHRoZXkgYXJlIHNpZ25lZCBpbiBvbiAobm90IGp1c3QgdGhlIGN1cnJlbnQgb25lKS4gUGFzc1xuICAgKiAgIGB7IHNjb3BlOiAnbG9jYWwnIH1gIHRvIG9ubHkgc2lnbiBvdXQgdGhlIGN1cnJlbnQgc2Vzc2lvbi4gVGhpcyBpc1xuICAgKiAgIHVzdWFsbHkgd2hhdCBhcHBzIHdhbnQgb24gYSBcIlNpZ24gb3V0XCIgYnV0dG9uLCBlc3BlY2lhbGx5IHdoZW4gdXNlcnNcbiAgICogICBzaWduIGluIGZyb20gbXVsdGlwbGUgZGV2aWNlcyBhbmQgZG8gbm90IGV4cGVjdCBzaWduaW5nIG91dCBvZiBvbmUgdG9cbiAgICogICB0ZXJtaW5hdGUgdGhlIG90aGVycy5cbiAgICogLSBTaW5jZSBTdXBhYmFzZSBBdXRoIHVzZXMgSldUcyBmb3IgYXV0aGVudGljYXRpb24sIHRoZSBhY2Nlc3MgdG9rZW4gSldUIHdpbGwgYmUgdmFsaWQgdW50aWwgaXQncyBleHBpcmVkLiBXaGVuIHRoZSB1c2VyIHNpZ25zIG91dCwgU3VwYWJhc2UgcmV2b2tlcyB0aGUgcmVmcmVzaCB0b2tlbiBhbmQgZGVsZXRlcyB0aGUgSldUIGZyb20gdGhlIGNsaWVudC1zaWRlLiBUaGlzIGRvZXMgbm90IHJldm9rZSB0aGUgSldUIGFuZCBpdCB3aWxsIHN0aWxsIGJlIHZhbGlkIHVudGlsIGl0IGV4cGlyZXMuXG4gICAqXG4gICAqIEBleGFtcGxlIFNpZ24gb3V0IG9mIGV2ZXJ5IGRldmljZSAoZ2xvYmFsIOKAkyBkZWZhdWx0KVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU2lnbiBvdXQgb25seSB0aGUgY3VycmVudCBzZXNzaW9uIChyZWNvbW1lbmRlZCBmb3IgbW9zdCBhcHBzKVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoeyBzY29wZTogJ2xvY2FsJyB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU2lnbiBvdXQgb2YgYWxsIG90aGVyIHNlc3Npb25zLCBrZWVwIHRoZSBjdXJyZW50IG9uZVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoeyBzY29wZTogJ290aGVycycgfSlcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBzaWduT3V0KG9wdGlvbnM6IFNpZ25PdXQgPSB7IHNjb3BlOiAnZ2xvYmFsJyB9KTogUHJvbWlzZTx7IGVycm9yOiBBdXRoRXJyb3IgfCBudWxsIH0+IHtcbiAgICBhd2FpdCB0aGlzLmluaXRpYWxpemVQcm9taXNlXG5cbiAgICBpZiAodGhpcy5sb2NrICE9IG51bGwpIHtcbiAgICAgIC8vIFRPRE8odjMpOiByZW1vdmUgbGVnYWN5IGxvY2sgcGF0aFxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX2FjcXVpcmVMb2NrKHRoaXMubG9ja0FjcXVpcmVUaW1lb3V0LCBhc3luYyAoKSA9PiB7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9zaWduT3V0KG9wdGlvbnMpXG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCB0aGlzLl9zaWduT3V0KG9wdGlvbnMpXG4gIH1cblxuICBwcm90ZWN0ZWQgYXN5bmMgX3NpZ25PdXQoXG4gICAgeyBzY29wZSB9OiBTaWduT3V0ID0geyBzY29wZTogJ2dsb2JhbCcgfVxuICApOiBQcm9taXNlPHsgZXJyb3I6IEF1dGhFcnJvciB8IG51bGwgfT4ge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3I6IHNlc3Npb25FcnJvciB9ID0gcmVzdWx0XG4gICAgICBpZiAoc2Vzc2lvbkVycm9yICYmICFpc0F1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKHNlc3Npb25FcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGVycm9yOiBzZXNzaW9uRXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gZGF0YS5zZXNzaW9uPy5hY2Nlc3NfdG9rZW5cbiAgICAgIGlmIChhY2Nlc3NUb2tlbikge1xuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCB0aGlzLmFkbWluLnNpZ25PdXQoYWNjZXNzVG9rZW4sIHNjb3BlKVxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAvLyBpZ25vcmUgNDA0cyBzaW5jZSB1c2VyIG1pZ2h0IG5vdCBleGlzdCBhbnltb3JlXG4gICAgICAgICAgLy8gaWdub3JlIDQwMXMgc2luY2UgYW4gaW52YWxpZCBvciBleHBpcmVkIEpXVCBzaG91bGQgc2lnbiBvdXQgdGhlIGN1cnJlbnQgc2Vzc2lvblxuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICEoXG4gICAgICAgICAgICAgIChpc0F1dGhBcGlFcnJvcihlcnJvcikgJiZcbiAgICAgICAgICAgICAgICAoZXJyb3Iuc3RhdHVzID09PSA0MDQgfHwgZXJyb3Iuc3RhdHVzID09PSA0MDEgfHwgZXJyb3Iuc3RhdHVzID09PSA0MDMpKSB8fFxuICAgICAgICAgICAgICBpc0F1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKGVycm9yKVxuICAgICAgICAgICAgKVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGVycm9yIH0pXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoc2NvcGUgIT09ICdvdGhlcnMnKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuX3JlbW92ZVNlc3Npb24oKVxuICAgICAgICBhd2FpdCByZW1vdmVJdGVtQXN5bmModGhpcy5zdG9yYWdlLCBgJHt0aGlzLnN0b3JhZ2VLZXl9LWNvZGUtdmVyaWZpZXJgKVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGVycm9yOiBudWxsIH0pXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWNlaXZlIGEgbm90aWZpY2F0aW9uIGV2ZXJ5IHRpbWUgYW4gYXV0aCBldmVudCBoYXBwZW5zLlxuICAgKiBTYWZlIHRvIHVzZSB3aXRob3V0IGFuIGFzeW5jIGZ1bmN0aW9uIGFzIGNhbGxiYWNrLlxuICAgKlxuICAgKiBAcGFyYW0gY2FsbGJhY2sgQSBjYWxsYmFjayBmdW5jdGlvbiB0byBiZSBpbnZva2VkIHdoZW4gYW4gYXV0aCBldmVudCBoYXBwZW5zLlxuICAgKi9cbiAgb25BdXRoU3RhdGVDaGFuZ2UoY2FsbGJhY2s6IChldmVudDogQXV0aENoYW5nZUV2ZW50LCBzZXNzaW9uOiBTZXNzaW9uIHwgbnVsbCkgPT4gdm9pZCk6IHtcbiAgICBkYXRhOiB7IHN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZWNlaXZlIGEgbm90aWZpY2F0aW9uIGV2ZXJ5IHRpbWUgYW4gYXV0aCBldmVudCBoYXBwZW5zLiBDb21tb24gcmVlbnRyeVxuICAgKiBwYXR0ZXJucyAoYGdldFVzZXJgLCBgc2V0U2Vzc2lvbmAsIHJlYWRpbmcgdGhlIHNlc3Npb24gZnJvbSBpbnNpZGUgYVxuICAgKiBoYW5kbGVyKSBjb21wbGV0ZSBub3JtYWxseS4gT25lIGhhemFyZCByZW1haW5zOiBjYWxsaW5nIGByZWZyZXNoU2Vzc2lvbmBcbiAgICogKG9yIGFueXRoaW5nIHRoYXQgcm91dGVzIHRocm91Z2ggYF9jYWxsUmVmcmVzaFRva2VuYCkgZnJvbSBpbnNpZGUgYVxuICAgKiBgVE9LRU5fUkVGUkVTSEVEYCBoYW5kbGVyLiBgcmVmcmVzaGluZ0RlZmVycmVkYCByZXNvbHZlcyBvbmx5IGFmdGVyXG4gICAqIGBfbm90aWZ5QWxsU3Vic2NyaWJlcnNgIHJldHVybnMsIHNvIHRoZSBpbm5lciByZWZyZXNoIGRlZHVwZXMgb250byB0aGVcbiAgICogb3V0ZXIncyB1bnJlc29sdmVkIHByb21pc2UgYW5kIHRoZSB0d28gd2FpdCBvbiBlYWNoIG90aGVyLlxuICAgKlxuICAgKiBAcGFyYW0gY2FsbGJhY2sgQSBjYWxsYmFjayBmdW5jdGlvbiB0byBiZSBpbnZva2VkIHdoZW4gYW4gYXV0aCBldmVudCBoYXBwZW5zLlxuICAgKlxuICAgKiBAZGVwcmVjYXRlZCBBc3luYyBjYWxsYmFja3MgY2FuIGRlYWRsb2NrIHdoZW4gdGhleSB0cmlnZ2VyIGEgbmVzdGVkXG4gICAqIHJlZnJlc2ggZnJvbSBhIGBUT0tFTl9SRUZSRVNIRURgIGV2ZW50LiBQcmVmZXIgdGhlIHN5bmMgb3ZlcmxvYWQsIG9yIG1vdmVcbiAgICogcmVmcmVzaC10cmlnZ2VyaW5nIHdvcmsgb3V0c2lkZSB0aGUgY2FsbGJhY2suXG4gICAqL1xuICBvbkF1dGhTdGF0ZUNoYW5nZShjYWxsYmFjazogKGV2ZW50OiBBdXRoQ2hhbmdlRXZlbnQsIHNlc3Npb246IFNlc3Npb24gfCBudWxsKSA9PiBQcm9taXNlPHZvaWQ+KToge1xuICAgIGRhdGE6IHsgc3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb24gfVxuICB9XG5cbiAgLyoqICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gU3Vic2NyaWJlcyB0byBpbXBvcnRhbnQgZXZlbnRzIG9jY3VycmluZyBvbiB0aGUgdXNlcidzIHNlc3Npb24uXG4gICAqIC0gVXNlIG9uIHRoZSBmcm9udGVuZC9jbGllbnQuIEl0IGlzIGxlc3MgdXNlZnVsIG9uIHRoZSBzZXJ2ZXIuXG4gICAqIC0gRXZlbnRzIGFyZSBlbWl0dGVkIGFjcm9zcyB0YWJzIHRvIGtlZXAgeW91ciBhcHBsaWNhdGlvbidzIFVJIHVwLXRvLWRhdGUuIFNvbWUgZXZlbnRzIGNhbiBmaXJlIHZlcnkgZnJlcXVlbnRseSwgYmFzZWQgb24gdGhlIG51bWJlciBvZiB0YWJzIG9wZW4uIFVzZSBhIHF1aWNrIGFuZCBlZmZpY2llbnQgY2FsbGJhY2sgZnVuY3Rpb24sIGFuZCBkZWZlciBvciBkZWJvdW5jZSBhcyBtYW55IG9wZXJhdGlvbnMgYXMgeW91IGNhbiB0byBiZSBwZXJmb3JtZWQgb3V0c2lkZSBvZiB0aGUgY2FsbGJhY2suXG4gICAqIC0gQ2FsbGJhY2tzIGNhbiBiZSBgYXN5bmNgIGFuZCBjYW4gc2FmZWx5IGNhbGwgb3RoZXIgU3VwYWJhc2UgYXV0aCBtZXRob2RzIChgZ2V0VXNlcmAsIGBzZXRTZXNzaW9uYCwgZXRjLikgZnJvbSBpbnNpZGUgdGhlIGNhbGxiYWNrLlxuICAgKiAtIEtlZXAgY2FsbGJhY2tzIHF1aWNrLiBFdmVudHMgYXJlIGF3YWl0ZWQgaW4gb3JkZXIsIHNvIGEgc2xvdyBjYWxsYmFjayBkZWxheXMgc3Vic2VxdWVudCBldmVudHMgdG8gc3Vic2NyaWJlcnMgaW4gdGhpcyB0YWIuXG4gICAqIC0gRW1pdHRlZCBldmVudHM6XG4gICAqICAgLSBgSU5JVElBTF9TRVNTSU9OYFxuICAgKiAgICAgLSBFbWl0dGVkIHJpZ2h0IGFmdGVyIHRoZSBTdXBhYmFzZSBjbGllbnQgaXMgY29uc3RydWN0ZWQgYW5kIHRoZSBpbml0aWFsIHNlc3Npb24gZnJvbSBzdG9yYWdlIGlzIGxvYWRlZC5cbiAgICogICAtIGBTSUdORURfSU5gXG4gICAqICAgICAtIEVtaXR0ZWQgZWFjaCB0aW1lIGEgdXNlciBzZXNzaW9uIGlzIGNvbmZpcm1lZCBvciByZS1lc3RhYmxpc2hlZCwgaW5jbHVkaW5nIG9uIHVzZXIgc2lnbiBpbiBhbmQgd2hlbiByZWZvY3VzaW5nIGEgdGFiLlxuICAgKiAgICAgLSBBdm9pZCBtYWtpbmcgYXNzdW1wdGlvbnMgYXMgdG8gd2hlbiB0aGlzIGV2ZW50IGlzIGZpcmVkLCB0aGlzIG1heSBvY2N1ciBldmVuIHdoZW4gdGhlIHVzZXIgaXMgYWxyZWFkeSBzaWduZWQgaW4uIEluc3RlYWQsIGNoZWNrIHRoZSB1c2VyIG9iamVjdCBhdHRhY2hlZCB0byB0aGUgZXZlbnQgdG8gc2VlIGlmIGEgbmV3IHVzZXIgaGFzIHNpZ25lZCBpbiBhbmQgdXBkYXRlIHlvdXIgYXBwbGljYXRpb24ncyBVSS5cbiAgICogICAgIC0gVGhpcyBldmVudCBjYW4gZmlyZSB2ZXJ5IGZyZXF1ZW50bHkgZGVwZW5kaW5nIG9uIHRoZSBudW1iZXIgb2YgdGFicyBvcGVuIGluIHlvdXIgYXBwbGljYXRpb24uXG4gICAqICAgLSBgU0lHTkVEX09VVGBcbiAgICogICAgIC0gRW1pdHRlZCB3aGVuIHRoZSB1c2VyIHNpZ25zIG91dC4gVGhpcyBjYW4gYmUgYWZ0ZXI6XG4gICAqICAgICAgIC0gQSBjYWxsIHRvIGBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoKWAuXG4gICAqICAgICAgIC0gQWZ0ZXIgdGhlIHVzZXIncyBzZXNzaW9uIGhhcyBleHBpcmVkIGZvciBhbnkgcmVhc29uOlxuICAgKiAgICAgICAgIC0gVXNlciBoYXMgc2lnbmVkIG91dCBvbiBhbm90aGVyIGRldmljZS5cbiAgICogICAgICAgICAtIFRoZSBzZXNzaW9uIGhhcyByZWFjaGVkIGl0cyB0aW1lYm94IGxpbWl0IG9yIGluYWN0aXZpdHkgdGltZW91dC5cbiAgICogICAgICAgICAtIFVzZXIgaGFzIHNpZ25lZCBpbiBvbiBhbm90aGVyIGRldmljZSB3aXRoIHNpbmdsZSBzZXNzaW9uIHBlciB1c2VyIGVuYWJsZWQuXG4gICAqICAgICAgICAgLSBDaGVjayB0aGUgW1VzZXIgU2Vzc2lvbnNdKC9kb2NzL2d1aWRlcy9hdXRoL3Nlc3Npb25zKSBkb2NzIGZvciBtb3JlIGluZm9ybWF0aW9uLlxuICAgKiAgICAgLSBVc2UgdGhpcyB0byBjbGVhbiB1cCBhbnkgbG9jYWwgc3RvcmFnZSB5b3VyIGFwcGxpY2F0aW9uIGhhcyBhc3NvY2lhdGVkIHdpdGggdGhlIHVzZXIuXG4gICAqICAgLSBgVE9LRU5fUkVGUkVTSEVEYFxuICAgKiAgICAgLSBFbWl0dGVkIGVhY2ggdGltZSBhIG5ldyBhY2Nlc3MgYW5kIHJlZnJlc2ggdG9rZW4gYXJlIGZldGNoZWQgZm9yIHRoZSBzaWduZWQgaW4gdXNlci5cbiAgICogICAgIC0gSXQncyBiZXN0IHByYWN0aWNlIGFuZCBoaWdobHkgcmVjb21tZW5kZWQgdG8gZXh0cmFjdCB0aGUgYWNjZXNzIHRva2VuIChKV1QpIGFuZCBzdG9yZSBpdCBpbiBtZW1vcnkgZm9yIGZ1cnRoZXIgdXNlIGluIHlvdXIgYXBwbGljYXRpb24uXG4gICAqICAgICAgIC0gQXZvaWQgZnJlcXVlbnQgY2FsbHMgdG8gYHN1cGFiYXNlLmF1dGguZ2V0U2Vzc2lvbigpYCBmb3IgdGhlIHNhbWUgcHVycG9zZS5cbiAgICogICAgIC0gVGhlcmUgaXMgYSBiYWNrZ3JvdW5kIHByb2Nlc3MgdGhhdCBrZWVwcyB0cmFjayBvZiB3aGVuIHRoZSBzZXNzaW9uIHNob3VsZCBiZSByZWZyZXNoZWQgc28geW91IHdpbGwgYWx3YXlzIHJlY2VpdmUgdmFsaWQgdG9rZW5zIGJ5IGxpc3RlbmluZyB0byB0aGlzIGV2ZW50LlxuICAgKiAgICAgLSBUaGUgZnJlcXVlbmN5IG9mIHRoaXMgZXZlbnQgaXMgcmVsYXRlZCB0byB0aGUgSldUIGV4cGlyeSBsaW1pdCBjb25maWd1cmVkIG9uIHlvdXIgcHJvamVjdC5cbiAgICogICAtIGBVU0VSX1VQREFURURgXG4gICAqICAgICAtIEVtaXR0ZWQgZWFjaCB0aW1lIHRoZSBgc3VwYWJhc2UuYXV0aC51cGRhdGVVc2VyKClgIG1ldGhvZCBmaW5pc2hlcyBzdWNjZXNzZnVsbHkuIExpc3RlbiB0byBpdCB0byB1cGRhdGUgeW91ciBhcHBsaWNhdGlvbidzIFVJIGJhc2VkIG9uIG5ldyBwcm9maWxlIGluZm9ybWF0aW9uLlxuICAgKiAgIC0gYFBBU1NXT1JEX1JFQ09WRVJZYFxuICAgKiAgICAgLSBFbWl0dGVkIGluc3RlYWQgb2YgdGhlIGBTSUdORURfSU5gIGV2ZW50IHdoZW4gdGhlIHVzZXIgbGFuZHMgb24gYSBwYWdlIHRoYXQgaW5jbHVkZXMgYSBwYXNzd29yZCByZWNvdmVyeSBsaW5rIGluIHRoZSBVUkwuXG4gICAqICAgICAtIFVzZSBpdCB0byBzaG93IGEgVUkgdG8gdGhlIHVzZXIgd2hlcmUgdGhleSBjYW4gW3Jlc2V0IHRoZWlyIHBhc3N3b3JkXSgvZG9jcy9ndWlkZXMvYXV0aC9wYXNzd29yZHMjcmVzZXR0aW5nLWEtdXNlcnMtcGFzc3dvcmQtZm9yZ290LXBhc3N3b3JkKS5cbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdGVuIHRvIGF1dGggY2hhbmdlc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEgfSA9IHN1cGFiYXNlLmF1dGgub25BdXRoU3RhdGVDaGFuZ2UoKGV2ZW50LCBzZXNzaW9uKSA9PiB7XG4gICAqICAgY29uc29sZS5sb2coZXZlbnQsIHNlc3Npb24pXG4gICAqXG4gICAqICAgaWYgKGV2ZW50ID09PSAnSU5JVElBTF9TRVNTSU9OJykge1xuICAgKiAgICAgLy8gaGFuZGxlIGluaXRpYWwgc2Vzc2lvblxuICAgKiAgIH0gZWxzZSBpZiAoZXZlbnQgPT09ICdTSUdORURfSU4nKSB7XG4gICAqICAgICAvLyBoYW5kbGUgc2lnbiBpbiBldmVudFxuICAgKiAgIH0gZWxzZSBpZiAoZXZlbnQgPT09ICdTSUdORURfT1VUJykge1xuICAgKiAgICAgLy8gaGFuZGxlIHNpZ24gb3V0IGV2ZW50XG4gICAqICAgfSBlbHNlIGlmIChldmVudCA9PT0gJ1BBU1NXT1JEX1JFQ09WRVJZJykge1xuICAgKiAgICAgLy8gaGFuZGxlIHBhc3N3b3JkIHJlY292ZXJ5IGV2ZW50XG4gICAqICAgfSBlbHNlIGlmIChldmVudCA9PT0gJ1RPS0VOX1JFRlJFU0hFRCcpIHtcbiAgICogICAgIC8vIGhhbmRsZSB0b2tlbiByZWZyZXNoZWQgZXZlbnRcbiAgICogICB9IGVsc2UgaWYgKGV2ZW50ID09PSAnVVNFUl9VUERBVEVEJykge1xuICAgKiAgICAgLy8gaGFuZGxlIHVzZXIgdXBkYXRlZCBldmVudFxuICAgKiAgIH1cbiAgICogfSlcbiAgICpcbiAgICogLy8gY2FsbCB1bnN1YnNjcmliZSB0byByZW1vdmUgdGhlIGNhbGxiYWNrXG4gICAqIGRhdGEuc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gTGlzdGVuIHRvIHNpZ24gb3V0XG4gICAqIE1ha2Ugc3VyZSB5b3UgY2xlYXIgb3V0IGFueSBsb2NhbCBkYXRhLCBzdWNoIGFzIGxvY2FsIGFuZCBzZXNzaW9uIHN0b3JhZ2UsIGFmdGVyIHRoZSBjbGllbnQgbGlicmFyeSBoYXMgZGV0ZWN0ZWQgdGhlIHVzZXIncyBzaWduIG91dC5cbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdGVuIHRvIHNpZ24gb3V0XG4gICAqIGBgYGpzXG4gICAqIHN1cGFiYXNlLmF1dGgub25BdXRoU3RhdGVDaGFuZ2UoKGV2ZW50LCBzZXNzaW9uKSA9PiB7XG4gICAqICAgaWYgKGV2ZW50ID09PSAnU0lHTkVEX09VVCcpIHtcbiAgICogICAgIGNvbnNvbGUubG9nKCdTSUdORURfT1VUJywgc2Vzc2lvbilcbiAgICpcbiAgICogICAgIC8vIGNsZWFyIGxvY2FsIGFuZCBzZXNzaW9uIHN0b3JhZ2VcbiAgICogICAgIFtcbiAgICogICAgICAgd2luZG93LmxvY2FsU3RvcmFnZSxcbiAgICogICAgICAgd2luZG93LnNlc3Npb25TdG9yYWdlLFxuICAgKiAgICAgXS5mb3JFYWNoKChzdG9yYWdlKSA9PiB7XG4gICAqICAgICAgIE9iamVjdC5lbnRyaWVzKHN0b3JhZ2UpXG4gICAqICAgICAgICAgLmZvckVhY2goKFtrZXldKSA9PiB7XG4gICAqICAgICAgICAgICBzdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KVxuICAgKiAgICAgICAgIH0pXG4gICAqICAgICB9KVxuICAgKiAgIH1cbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gU3RvcmUgT0F1dGggcHJvdmlkZXIgdG9rZW5zIG9uIHNpZ24gaW5cbiAgICogV2hlbiB1c2luZyBbT0F1dGggKFNvY2lhbCBMb2dpbildKC9kb2NzL2d1aWRlcy9hdXRoL3NvY2lhbC1sb2dpbikgeW91IHNvbWV0aW1lcyB3aXNoIHRvIGdldCBhY2Nlc3MgdG8gdGhlIHByb3ZpZGVyJ3MgYWNjZXNzIHRva2VuIGFuZCByZWZyZXNoIHRva2VuLCBpbiBvcmRlciB0byBjYWxsIHByb3ZpZGVyIEFQSXMgaW4gdGhlIG5hbWUgb2YgdGhlIHVzZXIuXG4gICAqXG4gICAqIEZvciBleGFtcGxlLCBpZiB5b3UgYXJlIHVzaW5nIFtTaWduIGluIHdpdGggR29vZ2xlXSgvZG9jcy9ndWlkZXMvYXV0aC9zb2NpYWwtbG9naW4vYXV0aC1nb29nbGUpIHlvdSBtYXkgd2FudCB0byB1c2UgdGhlIHByb3ZpZGVyIHRva2VuIHRvIGNhbGwgR29vZ2xlIEFQSXMgb24gYmVoYWxmIG9mIHRoZSB1c2VyLiBTdXBhYmFzZSBBdXRoIGRvZXMgbm90IGtlZXAgdHJhY2sgb2YgdGhlIHByb3ZpZGVyIGFjY2VzcyBhbmQgcmVmcmVzaCB0b2tlbiwgYnV0IGRvZXMgcmV0dXJuIHRoZW0gZm9yIHlvdSBvbmNlLCBpbW1lZGlhdGVseSBhZnRlciBzaWduIGluLiBZb3UgY2FuIHVzZSB0aGUgYG9uQXV0aFN0YXRlQ2hhbmdlYCBtZXRob2QgdG8gbGlzdGVuIGZvciB0aGUgcHJlc2VuY2Ugb2YgdGhlIHByb3ZpZGVyIHRva2VucyBhbmQgc3RvcmUgdGhlbSBpbiBsb2NhbCBzdG9yYWdlLiBZb3UgY2FuIGZ1cnRoZXIgc2VuZCB0aGVtIHRvIHlvdXIgc2VydmVyJ3MgQVBJcyBmb3IgdXNlIG9uIHRoZSBiYWNrZW5kLlxuICAgKlxuICAgKiBGaW5hbGx5LCBtYWtlIHN1cmUgeW91IHJlbW92ZSB0aGVtIGZyb20gbG9jYWwgc3RvcmFnZSBvbiB0aGUgYFNJR05FRF9PVVRgIGV2ZW50LiBJZiB0aGUgT0F1dGggcHJvdmlkZXIgc3VwcG9ydHMgdG9rZW4gcmV2b2NhdGlvbiwgbWFrZSBzdXJlIHlvdSBjYWxsIHRob3NlIEFQSXMgZWl0aGVyIGZyb20gdGhlIGZyb250ZW5kIG9yIHNjaGVkdWxlIHRoZW0gdG8gYmUgY2FsbGVkIG9uIHRoZSBiYWNrZW5kLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTdG9yZSBPQXV0aCBwcm92aWRlciB0b2tlbnMgb24gc2lnbiBpblxuICAgKiBgYGBqc1xuICAgKiAvLyBSZWdpc3RlciB0aGlzIGltbWVkaWF0ZWx5IGFmdGVyIGNhbGxpbmcgY3JlYXRlQ2xpZW50IVxuICAgKiAvLyBCZWNhdXNlIHNpZ25JbldpdGhPQXV0aCBjYXVzZXMgYSByZWRpcmVjdCwgeW91IG5lZWQgdG8gZmV0Y2ggdGhlXG4gICAqIC8vIHByb3ZpZGVyIHRva2VucyBmcm9tIHRoZSBjYWxsYmFjay5cbiAgICogc3VwYWJhc2UuYXV0aC5vbkF1dGhTdGF0ZUNoYW5nZSgoZXZlbnQsIHNlc3Npb24pID0+IHtcbiAgICogICBpZiAoc2Vzc2lvbiAmJiBzZXNzaW9uLnByb3ZpZGVyX3Rva2VuKSB7XG4gICAqICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ29hdXRoX3Byb3ZpZGVyX3Rva2VuJywgc2Vzc2lvbi5wcm92aWRlcl90b2tlbilcbiAgICogICB9XG4gICAqXG4gICAqICAgaWYgKHNlc3Npb24gJiYgc2Vzc2lvbi5wcm92aWRlcl9yZWZyZXNoX3Rva2VuKSB7XG4gICAqICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ29hdXRoX3Byb3ZpZGVyX3JlZnJlc2hfdG9rZW4nLCBzZXNzaW9uLnByb3ZpZGVyX3JlZnJlc2hfdG9rZW4pXG4gICAqICAgfVxuICAgKlxuICAgKiAgIGlmIChldmVudCA9PT0gJ1NJR05FRF9PVVQnKSB7XG4gICAqICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ29hdXRoX3Byb3ZpZGVyX3Rva2VuJylcbiAgICogICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnb2F1dGhfcHJvdmlkZXJfcmVmcmVzaF90b2tlbicpXG4gICAqICAgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBVc2UgUmVhY3QgQ29udGV4dCBmb3IgdGhlIFVzZXIncyBzZXNzaW9uXG4gICAqIEluc3RlYWQgb2YgcmVseWluZyBvbiBgc3VwYWJhc2UuYXV0aC5nZXRTZXNzaW9uKClgIHdpdGhpbiB5b3VyIFJlYWN0IGNvbXBvbmVudHMsIHlvdSBjYW4gdXNlIGEgW1JlYWN0IENvbnRleHRdKGh0dHBzOi8vcmVhY3QuZGV2L3JlZmVyZW5jZS9yZWFjdC9jcmVhdGVDb250ZXh0KSB0byBzdG9yZSB0aGUgbGF0ZXN0IHNlc3Npb24gaW5mb3JtYXRpb24gZnJvbSB0aGUgYG9uQXV0aFN0YXRlQ2hhbmdlYCBjYWxsYmFjayBhbmQgYWNjZXNzIGl0IHRoYXQgd2F5LlxuICAgKlxuICAgKiBAZXhhbXBsZSBVc2UgUmVhY3QgQ29udGV4dCBmb3IgdGhlIFVzZXIncyBzZXNzaW9uXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IFNlc3Npb25Db250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKVxuICAgKlxuICAgKiBmdW5jdGlvbiBtYWluKCkge1xuICAgKiAgIGNvbnN0IFtzZXNzaW9uLCBzZXRTZXNzaW9uXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpXG4gICAqXG4gICAqICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICogICAgIGNvbnN0IHtkYXRhOiB7IHN1YnNjcmlwdGlvbiB9fSA9IHN1cGFiYXNlLmF1dGgub25BdXRoU3RhdGVDaGFuZ2UoXG4gICAqICAgICAgIChldmVudCwgc2Vzc2lvbikgPT4ge1xuICAgKiAgICAgICAgIGlmIChldmVudCA9PT0gJ1NJR05FRF9PVVQnKSB7XG4gICAqICAgICAgICAgICBzZXRTZXNzaW9uKG51bGwpXG4gICAqICAgICAgICAgfSBlbHNlIGlmIChzZXNzaW9uKSB7XG4gICAqICAgICAgICAgICBzZXRTZXNzaW9uKHNlc3Npb24pXG4gICAqICAgICAgICAgfVxuICAgKiAgICAgICB9KVxuICAgKlxuICAgKiAgICAgcmV0dXJuICgpID0+IHtcbiAgICogICAgICAgc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKClcbiAgICogICAgIH1cbiAgICogICB9LCBbXSlcbiAgICpcbiAgICogICByZXR1cm4gKFxuICAgKiAgICAgPFNlc3Npb25Db250ZXh0LlByb3ZpZGVyIHZhbHVlPXtzZXNzaW9ufT5cbiAgICogICAgICAgPEFwcCAvPlxuICAgKiAgICAgPC9TZXNzaW9uQ29udGV4dC5Qcm92aWRlcj5cbiAgICogICApXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBwYXNzd29yZCByZWNvdmVyeSBldmVudHNcbiAgICogYGBganNcbiAgICogc3VwYWJhc2UuYXV0aC5vbkF1dGhTdGF0ZUNoYW5nZSgoZXZlbnQsIHNlc3Npb24pID0+IHtcbiAgICogICBpZiAoZXZlbnQgPT09ICdQQVNTV09SRF9SRUNPVkVSWScpIHtcbiAgICogICAgIGNvbnNvbGUubG9nKCdQQVNTV09SRF9SRUNPVkVSWScsIHNlc3Npb24pXG4gICAqICAgICAvLyBzaG93IHNjcmVlbiB0byB1cGRhdGUgdXNlcidzIHBhc3N3b3JkXG4gICAqICAgICBzaG93UGFzc3dvcmRSZXNldFNjcmVlbih0cnVlKVxuICAgKiAgIH1cbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBzaWduIGluXG4gICAqIGBgYGpzXG4gICAqIHN1cGFiYXNlLmF1dGgub25BdXRoU3RhdGVDaGFuZ2UoKGV2ZW50LCBzZXNzaW9uKSA9PiB7XG4gICAqICAgaWYgKGV2ZW50ID09PSAnU0lHTkVEX0lOJykgY29uc29sZS5sb2coJ1NJR05FRF9JTicsIHNlc3Npb24pXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBMaXN0ZW4gdG8gdG9rZW4gcmVmcmVzaFxuICAgKiBgYGBqc1xuICAgKiBzdXBhYmFzZS5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKChldmVudCwgc2Vzc2lvbikgPT4ge1xuICAgKiAgIGlmIChldmVudCA9PT0gJ1RPS0VOX1JFRlJFU0hFRCcpIGNvbnNvbGUubG9nKCdUT0tFTl9SRUZSRVNIRUQnLCBzZXNzaW9uKVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdGVuIHRvIHVzZXIgdXBkYXRlc1xuICAgKiBgYGBqc1xuICAgKiBzdXBhYmFzZS5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKChldmVudCwgc2Vzc2lvbikgPT4ge1xuICAgKiAgIGlmIChldmVudCA9PT0gJ1VTRVJfVVBEQVRFRCcpIGNvbnNvbGUubG9nKCdVU0VSX1VQREFURUQnLCBzZXNzaW9uKVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIG9uQXV0aFN0YXRlQ2hhbmdlKFxuICAgIGNhbGxiYWNrOiAoZXZlbnQ6IEF1dGhDaGFuZ2VFdmVudCwgc2Vzc2lvbjogU2Vzc2lvbiB8IG51bGwpID0+IHZvaWQgfCBQcm9taXNlPHZvaWQ+XG4gICk6IHtcbiAgICBkYXRhOiB7IHN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uIH1cbiAgfSB7XG4gICAgY29uc3QgaWQ6IHN0cmluZyB8IHN5bWJvbCA9IGdlbmVyYXRlQ2FsbGJhY2tJZCgpXG4gICAgY29uc3Qgc3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb24gPSB7XG4gICAgICBpZCxcbiAgICAgIGNhbGxiYWNrLFxuICAgICAgdW5zdWJzY3JpYmU6ICgpID0+IHtcbiAgICAgICAgdGhpcy5fZGVidWcoJyN1bnN1YnNjcmliZSgpJywgJ3N0YXRlIGNoYW5nZSBjYWxsYmFjayB3aXRoIGlkIHJlbW92ZWQnLCBpZClcblxuICAgICAgICB0aGlzLnN0YXRlQ2hhbmdlRW1pdHRlcnMuZGVsZXRlKGlkKVxuICAgICAgfSxcbiAgICB9XG5cbiAgICB0aGlzLl9kZWJ1ZygnI29uQXV0aFN0YXRlQ2hhbmdlKCknLCAncmVnaXN0ZXJlZCBjYWxsYmFjayB3aXRoIGlkJywgaWQpXG5cbiAgICB0aGlzLnN0YXRlQ2hhbmdlRW1pdHRlcnMuc2V0KGlkLCBzdWJzY3JpcHRpb24pXG4gICAgOyhhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCB0aGlzLmluaXRpYWxpemVQcm9taXNlXG5cbiAgICAgIGlmICh0aGlzLmxvY2sgIT0gbnVsbCkge1xuICAgICAgICAvLyBUT0RPKHYzKTogcmVtb3ZlIGxlZ2FjeSBsb2NrIHBhdGhcbiAgICAgICAgYXdhaXQgdGhpcy5fYWNxdWlyZUxvY2sodGhpcy5sb2NrQWNxdWlyZVRpbWVvdXQsIGFzeW5jICgpID0+IHtcbiAgICAgICAgICB0aGlzLl9lbWl0SW5pdGlhbFNlc3Npb24oaWQpXG4gICAgICAgIH0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCB0aGlzLl9lbWl0SW5pdGlhbFNlc3Npb24oaWQpXG4gICAgICB9XG4gICAgfSkoKVxuXG4gICAgcmV0dXJuIHsgZGF0YTogeyBzdWJzY3JpcHRpb24gfSB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9lbWl0SW5pdGlhbFNlc3Npb24oaWQ6IHN0cmluZyB8IHN5bWJvbCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBkYXRhOiB7IHNlc3Npb24gfSxcbiAgICAgICAgICBlcnJvcixcbiAgICAgICAgfSA9IHJlc3VsdFxuICAgICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yXG5cbiAgICAgICAgYXdhaXQgdGhpcy5zdGF0ZUNoYW5nZUVtaXR0ZXJzLmdldChpZCk/LmNhbGxiYWNrKCdJTklUSUFMX1NFU1NJT04nLCBzZXNzaW9uKVxuICAgICAgICB0aGlzLl9kZWJ1ZygnSU5JVElBTF9TRVNTSU9OJywgJ2NhbGxiYWNrIGlkJywgaWQsICdzZXNzaW9uJywgc2Vzc2lvbilcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBhd2FpdCB0aGlzLnN0YXRlQ2hhbmdlRW1pdHRlcnMuZ2V0KGlkKT8uY2FsbGJhY2soJ0lOSVRJQUxfU0VTU0lPTicsIG51bGwpXG4gICAgICAgIHRoaXMuX2RlYnVnKCdJTklUSUFMX1NFU1NJT04nLCAnY2FsbGJhY2sgaWQnLCBpZCwgJ2Vycm9yJywgZXJyKVxuICAgICAgICBpZiAoaXNBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcihlcnIpKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKGVycilcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGVycilcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogU2VuZHMgYSBwYXNzd29yZCByZXNldCByZXF1ZXN0IHRvIGFuIGVtYWlsIGFkZHJlc3MuIFRoaXMgbWV0aG9kIHN1cHBvcnRzIHRoZSBQS0NFIGZsb3cuXG4gICAqXG4gICAqIEBwYXJhbSBlbWFpbCBUaGUgZW1haWwgYWRkcmVzcyBvZiB0aGUgdXNlci5cbiAgICogQHBhcmFtIG9wdGlvbnMucmVkaXJlY3RUbyBUaGUgVVJMIHRvIHNlbmQgdGhlIHVzZXIgdG8gYWZ0ZXIgdGhleSBjbGljayB0aGUgcGFzc3dvcmQgcmVzZXQgbGluay5cbiAgICogQHBhcmFtIG9wdGlvbnMuY2FwdGNoYVRva2VuIFZlcmlmaWNhdGlvbiB0b2tlbiByZWNlaXZlZCB3aGVuIHRoZSB1c2VyIGNvbXBsZXRlcyB0aGUgY2FwdGNoYSBvbiB0aGUgc2l0ZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBUaGUgcGFzc3dvcmQgcmVzZXQgZmxvdyBjb25zaXN0IG9mIDIgYnJvYWQgc3RlcHM6IChpKSBBbGxvdyB0aGUgdXNlciB0byBsb2dpbiB2aWEgdGhlIHBhc3N3b3JkIHJlc2V0IGxpbms7IChpaSkgVXBkYXRlIHRoZSB1c2VyJ3MgcGFzc3dvcmQuXG4gICAqIC0gVGhlIGByZXNldFBhc3N3b3JkRm9yRW1haWwoKWAgb25seSBzZW5kcyBhIHBhc3N3b3JkIHJlc2V0IGxpbmsgdG8gdGhlIHVzZXIncyBlbWFpbC5cbiAgICogVG8gdXBkYXRlIHRoZSB1c2VyJ3MgcGFzc3dvcmQsIHNlZSBbYHVwZGF0ZVVzZXIoKWBdKC9kb2NzL3JlZmVyZW5jZS9qYXZhc2NyaXB0L2F1dGgtdXBkYXRldXNlcikuXG4gICAqIC0gQSBgUEFTU1dPUkRfUkVDT1ZFUllgIGV2ZW50IHdpbGwgYmUgZW1pdHRlZCB3aGVuIHRoZSBwYXNzd29yZCByZWNvdmVyeSBsaW5rIGlzIGNsaWNrZWQuXG4gICAqIFlvdSBjYW4gdXNlIFtgb25BdXRoU3RhdGVDaGFuZ2UoKWBdKC9kb2NzL3JlZmVyZW5jZS9qYXZhc2NyaXB0L2F1dGgtb25hdXRoc3RhdGVjaGFuZ2UpIHRvIGxpc3RlbiBhbmQgaW52b2tlIGEgY2FsbGJhY2sgZnVuY3Rpb24gb24gdGhlc2UgZXZlbnRzLlxuICAgKiAtIFdoZW4gdGhlIHVzZXIgY2xpY2tzIHRoZSByZXNldCBsaW5rIGluIHRoZSBlbWFpbCB0aGV5IGFyZSByZWRpcmVjdGVkIGJhY2sgdG8geW91ciBhcHBsaWNhdGlvbi5cbiAgICogWW91IGNhbiBjb25maWd1cmUgdGhlIFVSTCB0aGF0IHRoZSB1c2VyIGlzIHJlZGlyZWN0ZWQgdG8gd2l0aCB0aGUgYHJlZGlyZWN0VG9gIHBhcmFtZXRlci5cbiAgICogU2VlIFtyZWRpcmVjdCBVUkxzIGFuZCB3aWxkY2FyZHNdKC9kb2NzL2d1aWRlcy9hdXRoL3JlZGlyZWN0LXVybHMjdXNlLXdpbGRjYXJkcy1pbi1yZWRpcmVjdC11cmxzKSB0byBhZGQgYWRkaXRpb25hbCByZWRpcmVjdCBVUkxzIHRvIHlvdXIgcHJvamVjdC5cbiAgICogLSBBZnRlciB0aGUgdXNlciBoYXMgYmVlbiByZWRpcmVjdGVkIHN1Y2Nlc3NmdWxseSwgcHJvbXB0IHRoZW0gZm9yIGEgbmV3IHBhc3N3b3JkIGFuZCBjYWxsIGB1cGRhdGVVc2VyKClgOlxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnVwZGF0ZVVzZXIoe1xuICAgKiAgIHBhc3N3b3JkOiBuZXdfcGFzc3dvcmRcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFJlc2V0IHBhc3N3b3JkXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgucmVzZXRQYXNzd29yZEZvckVtYWlsKGVtYWlsLCB7XG4gICAqICAgcmVkaXJlY3RUbzogJ2h0dHBzOi8vZXhhbXBsZS5jb20vdXBkYXRlLXBhc3N3b3JkJyxcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgUmVzZXQgcGFzc3dvcmRcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgZGF0YToge31cbiAgICogICBlcnJvcjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBSZXNldCBwYXNzd29yZCAoUmVhY3QpXG4gICAqIGBgYGpzXG4gICAqIC8qKlxuICAgKiAgKiBTdGVwIDE6IFNlbmQgdGhlIHVzZXIgYW4gZW1haWwgdG8gZ2V0IGEgcGFzc3dvcmQgcmVzZXQgdG9rZW4uXG4gICAqICAqIFRoaXMgZW1haWwgY29udGFpbnMgYSBsaW5rIHdoaWNoIHNlbmRzIHRoZSB1c2VyIGJhY2sgdG8geW91ciBhcHBsaWNhdGlvbi5cbiAgICogICpcXC9cbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aFxuICAgKiAgIC5yZXNldFBhc3N3b3JkRm9yRW1haWwoJ3VzZXJAZW1haWwuY29tJylcbiAgICpcbiAgICogLyoqXG4gICAqICAqIFN0ZXAgMjogT25jZSB0aGUgdXNlciBpcyByZWRpcmVjdGVkIGJhY2sgdG8geW91ciBhcHBsaWNhdGlvbixcbiAgICogICogYXNrIHRoZSB1c2VyIHRvIHJlc2V0IHRoZWlyIHBhc3N3b3JkLlxuICAgKiAgKlxcL1xuICAgKiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICogICAgc3VwYWJhc2UuYXV0aC5vbkF1dGhTdGF0ZUNoYW5nZShhc3luYyAoZXZlbnQsIHNlc3Npb24pID0+IHtcbiAgICogICAgICBpZiAoZXZlbnQgPT0gXCJQQVNTV09SRF9SRUNPVkVSWVwiKSB7XG4gICAqICAgICAgICBjb25zdCBuZXdQYXNzd29yZCA9IHByb21wdChcIldoYXQgd291bGQgeW91IGxpa2UgeW91ciBuZXcgcGFzc3dvcmQgdG8gYmU/XCIpO1xuICAgKiAgICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aFxuICAgKiAgICAgICAgICAudXBkYXRlVXNlcih7IHBhc3N3b3JkOiBuZXdQYXNzd29yZCB9KVxuICAgKlxuICAgKiAgICAgICAgaWYgKGRhdGEpIGFsZXJ0KFwiUGFzc3dvcmQgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIpXG4gICAqICAgICAgICBpZiAoZXJyb3IpIGFsZXJ0KFwiVGhlcmUgd2FzIGFuIGVycm9yIHVwZGF0aW5nIHlvdXIgcGFzc3dvcmQuXCIpXG4gICAqICAgICAgfVxuICAgKiAgICB9KVxuICAgKiAgfSwgW10pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgcmVzZXRQYXNzd29yZEZvckVtYWlsKFxuICAgIGVtYWlsOiBzdHJpbmcsXG4gICAgb3B0aW9uczoge1xuICAgICAgcmVkaXJlY3RUbz86IHN0cmluZ1xuICAgICAgY2FwdGNoYVRva2VuPzogc3RyaW5nXG4gICAgfSA9IHt9XG4gICk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHt9XG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgICB9XG4gICAgfCB7IGRhdGE6IG51bGw7IGVycm9yOiBBdXRoRXJyb3IgfVxuICA+IHtcbiAgICBsZXQgY29kZUNoYWxsZW5nZTogc3RyaW5nIHwgbnVsbCA9IG51bGxcbiAgICBsZXQgY29kZUNoYWxsZW5nZU1ldGhvZDogc3RyaW5nIHwgbnVsbCA9IG51bGxcblxuICAgIGlmICh0aGlzLmZsb3dUeXBlID09PSAncGtjZScpIHtcbiAgICAgIDtbY29kZUNoYWxsZW5nZSwgY29kZUNoYWxsZW5nZU1ldGhvZF0gPSBhd2FpdCBnZXRDb2RlQ2hhbGxlbmdlQW5kTWV0aG9kKFxuICAgICAgICB0aGlzLnN0b3JhZ2UsXG4gICAgICAgIHRoaXMuc3RvcmFnZUtleSxcbiAgICAgICAgdHJ1ZSAvLyBpc1Bhc3N3b3JkUmVjb3ZlcnlcbiAgICAgIClcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnUE9TVCcsIGAke3RoaXMudXJsfS9yZWNvdmVyYCwge1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgZW1haWwsXG4gICAgICAgICAgY29kZV9jaGFsbGVuZ2U6IGNvZGVDaGFsbGVuZ2UsXG4gICAgICAgICAgY29kZV9jaGFsbGVuZ2VfbWV0aG9kOiBjb2RlQ2hhbGxlbmdlTWV0aG9kLFxuICAgICAgICAgIGdvdHJ1ZV9tZXRhX3NlY3VyaXR5OiB7IGNhcHRjaGFfdG9rZW46IG9wdGlvbnMuY2FwdGNoYVRva2VuIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgcmVkaXJlY3RUbzogb3B0aW9ucy5yZWRpcmVjdFRvLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgYWxsIHRoZSBpZGVudGl0aWVzIGxpbmtlZCB0byBhIHVzZXIuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVGhlIHVzZXIgbmVlZHMgdG8gYmUgc2lnbmVkIGluIHRvIGNhbGwgYGdldFVzZXJJZGVudGl0aWVzKClgLlxuICAgKlxuICAgKiBAZXhhbXBsZSBSZXR1cm5zIGEgbGlzdCBvZiBpZGVudGl0aWVzIGxpbmtlZCB0byB0aGUgdXNlclxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXJJZGVudGl0aWVzKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgUmV0dXJucyBhIGxpc3Qgb2YgaWRlbnRpdGllcyBsaW5rZWQgdG8gdGhlIHVzZXJcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwiaWRlbnRpdGllc1wiOiBbXG4gICAqICAgICAgIHtcbiAgICogICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjIyMjIyMjItMjIyMi0yMjIyLTIyMjItMjIyMjIyMjIyMjIyXCIsXG4gICAqICAgICAgICAgXCJpZFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJ1c2VyX2lkXCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgICB9LFxuICAgKiAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgIFwibGFzdF9zaWduX2luX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCJcbiAgICogICAgICAgfVxuICAgKiAgICAgXVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBnZXRVc2VySWRlbnRpdGllcygpOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgaWRlbnRpdGllczogVXNlcklkZW50aXR5W11cbiAgICAgICAgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwgeyBkYXRhOiBudWxsOyBlcnJvcjogQXV0aEVycm9yIH1cbiAgPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHRoaXMuZ2V0VXNlcigpXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yXG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogeyBpZGVudGl0aWVzOiBkYXRhLnVzZXIuaWRlbnRpdGllcyA/PyBbXSB9LCBlcnJvcjogbnVsbCB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogTGlua3MgYW4gb2F1dGggaWRlbnRpdHkgdG8gYW4gZXhpc3RpbmcgdXNlci5cbiAgICogVGhpcyBtZXRob2Qgc3VwcG9ydHMgdGhlIFBLQ0UgZmxvdy5cbiAgICovXG4gIGFzeW5jIGxpbmtJZGVudGl0eShjcmVkZW50aWFsczogU2lnbkluV2l0aE9BdXRoQ3JlZGVudGlhbHMpOiBQcm9taXNlPE9BdXRoUmVzcG9uc2U+XG5cbiAgLyoqXG4gICAqIExpbmtzIGFuIE9JREMgaWRlbnRpdHkgdG8gYW4gZXhpc3RpbmcgdXNlci5cbiAgICovXG4gIGFzeW5jIGxpbmtJZGVudGl0eShjcmVkZW50aWFsczogU2lnbkluV2l0aElkVG9rZW5DcmVkZW50aWFscyk6IFByb21pc2U8QXV0aFRva2VuUmVzcG9uc2U+XG5cbiAgLyoqICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVGhlICoqRW5hYmxlIE1hbnVhbCBMaW5raW5nKiogb3B0aW9uIG11c3QgYmUgZW5hYmxlZCBmcm9tIHlvdXIgW3Byb2plY3QncyBhdXRoZW50aWNhdGlvbiBzZXR0aW5nc10oL2Rhc2hib2FyZC9wcm9qZWN0L18vYXV0aC9wcm92aWRlcnMpLlxuICAgKiAtIFRoZSB1c2VyIG5lZWRzIHRvIGJlIHNpZ25lZCBpbiB0byBjYWxsIGBsaW5rSWRlbnRpdHkoKWAuXG4gICAqIC0gSWYgdGhlIGNhbmRpZGF0ZSBpZGVudGl0eSBpcyBhbHJlYWR5IGxpbmtlZCB0byB0aGUgZXhpc3RpbmcgdXNlciBvciBhbm90aGVyIHVzZXIsIGBsaW5rSWRlbnRpdHkoKWAgd2lsbCBmYWlsLlxuICAgKiAtIElmIGBsaW5rSWRlbnRpdHlgIGlzIHJ1biBpbiB0aGUgYnJvd3NlciwgdGhlIHVzZXIgaXMgYXV0b21hdGljYWxseSByZWRpcmVjdGVkIHRvIHRoZSByZXR1cm5lZCBVUkwuIE9uIHRoZSBzZXJ2ZXIsIHlvdSBzaG91bGQgaGFuZGxlIHRoZSByZWRpcmVjdC5cbiAgICpcbiAgICogQGV4YW1wbGUgTGluayBhbiBpZGVudGl0eSB0byBhIHVzZXJcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5saW5rSWRlbnRpdHkoe1xuICAgKiAgIHByb3ZpZGVyOiAnZ2l0aHViJ1xuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBMaW5rIGFuIGlkZW50aXR5IHRvIGEgdXNlclxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBkYXRhOiB7XG4gICAqICAgICBwcm92aWRlcjogJ2dpdGh1YicsXG4gICAqICAgICB1cmw6IDxQUk9WSURFUl9VUkxfVE9fUkVESVJFQ1RfVE8+XG4gICAqICAgfSxcbiAgICogICBlcnJvcjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgbGlua0lkZW50aXR5KGNyZWRlbnRpYWxzOiBhbnkpOiBQcm9taXNlPGFueT4ge1xuICAgIGlmICgndG9rZW4nIGluIGNyZWRlbnRpYWxzKSB7XG4gICAgICByZXR1cm4gdGhpcy5saW5rSWRlbnRpdHlJZFRva2VuKGNyZWRlbnRpYWxzKVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzLmxpbmtJZGVudGl0eU9BdXRoKGNyZWRlbnRpYWxzKVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBsaW5rSWRlbnRpdHlPQXV0aChjcmVkZW50aWFsczogU2lnbkluV2l0aE9BdXRoQ3JlZGVudGlhbHMpOiBQcm9taXNlPE9BdXRoUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IHJlc3VsdFxuICAgICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yXG4gICAgICAgIGNvbnN0IHVybDogc3RyaW5nID0gYXdhaXQgdGhpcy5fZ2V0VXJsRm9yUHJvdmlkZXIoXG4gICAgICAgICAgYCR7dGhpcy51cmx9L3VzZXIvaWRlbnRpdGllcy9hdXRob3JpemVgLFxuICAgICAgICAgIGNyZWRlbnRpYWxzLnByb3ZpZGVyLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHJlZGlyZWN0VG86IGNyZWRlbnRpYWxzLm9wdGlvbnM/LnJlZGlyZWN0VG8sXG4gICAgICAgICAgICBzY29wZXM6IGNyZWRlbnRpYWxzLm9wdGlvbnM/LnNjb3BlcyxcbiAgICAgICAgICAgIHF1ZXJ5UGFyYW1zOiBjcmVkZW50aWFscy5vcHRpb25zPy5xdWVyeVBhcmFtcyxcbiAgICAgICAgICAgIHNraXBCcm93c2VyUmVkaXJlY3Q6IHRydWUsXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnR0VUJywgdXJsLCB7XG4gICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgIGp3dDogZGF0YS5zZXNzaW9uPy5hY2Nlc3NfdG9rZW4gPz8gdW5kZWZpbmVkLFxuICAgICAgICB9KVxuICAgICAgfSlcbiAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3JcbiAgICAgIGlmIChpc0Jyb3dzZXIoKSAmJiAhY3JlZGVudGlhbHMub3B0aW9ucz8uc2tpcEJyb3dzZXJSZWRpcmVjdCkge1xuICAgICAgICB3aW5kb3cubG9jYXRpb24uYXNzaWduKGRhdGE/LnVybClcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoe1xuICAgICAgICBkYXRhOiB7IHByb3ZpZGVyOiBjcmVkZW50aWFscy5wcm92aWRlciwgdXJsOiBkYXRhPy51cmwgfSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHByb3ZpZGVyOiBjcmVkZW50aWFscy5wcm92aWRlciwgdXJsOiBudWxsIH0sIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbGlua0lkZW50aXR5SWRUb2tlbihcbiAgICBjcmVkZW50aWFsczogU2lnbkluV2l0aElkVG9rZW5DcmVkZW50aWFsc1xuICApOiBQcm9taXNlPEF1dGhUb2tlblJlc3BvbnNlPiB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuX3VzZVNlc3Npb24oYXN5bmMgKHJlc3VsdCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGVycm9yOiBzZXNzaW9uRXJyb3IsXG4gICAgICAgICAgZGF0YTogeyBzZXNzaW9uIH0sXG4gICAgICAgIH0gPSByZXN1bHRcbiAgICAgICAgaWYgKHNlc3Npb25FcnJvcikgdGhyb3cgc2Vzc2lvbkVycm9yXG5cbiAgICAgICAgY29uc3QgeyBvcHRpb25zLCBwcm92aWRlciwgdG9rZW4sIGFjY2Vzc190b2tlbiwgbm9uY2UgfSA9IGNyZWRlbnRpYWxzXG5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vdG9rZW4/Z3JhbnRfdHlwZT1pZF90b2tlbmAsIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgand0OiBzZXNzaW9uPy5hY2Nlc3NfdG9rZW4gPz8gdW5kZWZpbmVkLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHByb3ZpZGVyLFxuICAgICAgICAgICAgaWRfdG9rZW46IHRva2VuLFxuICAgICAgICAgICAgYWNjZXNzX3Rva2VuLFxuICAgICAgICAgICAgbm9uY2UsXG4gICAgICAgICAgICBsaW5rX2lkZW50aXR5OiB0cnVlLFxuICAgICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogb3B0aW9ucz8uY2FwdGNoYVRva2VuIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB4Zm9ybTogX3Nlc3Npb25SZXNwb25zZSxcbiAgICAgICAgfSlcblxuICAgICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSByZXNcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgICB9IGVsc2UgaWYgKCFkYXRhIHx8ICFkYXRhLnNlc3Npb24gfHwgIWRhdGEudXNlcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoe1xuICAgICAgICAgICAgZGF0YTogeyB1c2VyOiBudWxsLCBzZXNzaW9uOiBudWxsIH0sXG4gICAgICAgICAgICBlcnJvcjogbmV3IEF1dGhJbnZhbGlkVG9rZW5SZXNwb25zZUVycm9yKCksXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgICBpZiAoZGF0YS5zZXNzaW9uKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5fc2F2ZVNlc3Npb24oZGF0YS5zZXNzaW9uKVxuICAgICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdVU0VSX1VQREFURUQnLCBkYXRhLnNlc3Npb24pXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGEsIGVycm9yIH0pXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBhd2FpdCByZW1vdmVJdGVtQXN5bmModGhpcy5zdG9yYWdlLCBgJHt0aGlzLnN0b3JhZ2VLZXl9LWNvZGUtdmVyaWZpZXJgKVxuICAgICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IHsgdXNlcjogbnVsbCwgc2Vzc2lvbjogbnVsbCB9LCBlcnJvciB9KVxuICAgICAgICB9XG4gICAgICAgIHRocm93IGVycm9yXG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBVbmxpbmtzIGFuIGlkZW50aXR5IGZyb20gYSB1c2VyIGJ5IGRlbGV0aW5nIGl0LiBUaGUgdXNlciB3aWxsIG5vIGxvbmdlciBiZSBhYmxlIHRvIHNpZ24gaW4gd2l0aCB0aGF0IGlkZW50aXR5IG9uY2UgaXQncyB1bmxpbmtlZC5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBUaGUgKipFbmFibGUgTWFudWFsIExpbmtpbmcqKiBvcHRpb24gbXVzdCBiZSBlbmFibGVkIGZyb20geW91ciBbcHJvamVjdCdzIGF1dGhlbnRpY2F0aW9uIHNldHRpbmdzXSgvZGFzaGJvYXJkL3Byb2plY3QvXy9hdXRoL3Byb3ZpZGVycykuXG4gICAqIC0gVGhlIHVzZXIgbmVlZHMgdG8gYmUgc2lnbmVkIGluIHRvIGNhbGwgYHVubGlua0lkZW50aXR5KClgLlxuICAgKiAtIFRoZSB1c2VyIG11c3QgaGF2ZSBhdCBsZWFzdCAyIGlkZW50aXRpZXMgaW4gb3JkZXIgdG8gdW5saW5rIGFuIGlkZW50aXR5LlxuICAgKiAtIFRoZSBpZGVudGl0eSB0byBiZSB1bmxpbmtlZCBtdXN0IGJlbG9uZyB0byB0aGUgdXNlci5cbiAgICpcbiAgICogQGV4YW1wbGUgVW5saW5rIGFuIGlkZW50aXR5XG4gICAqIGBgYGpzXG4gICAqIC8vIHJldHJpZXZlIGFsbCBpZGVudGl0aWVzIGxpbmtlZCB0byBhIHVzZXJcbiAgICogY29uc3QgaWRlbnRpdGllcyA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcklkZW50aXRpZXMoKVxuICAgKlxuICAgKiAvLyBmaW5kIHRoZSBnb29nbGUgaWRlbnRpdHlcbiAgICogY29uc3QgZ29vZ2xlSWRlbnRpdHkgPSBpZGVudGl0aWVzLmZpbmQoXG4gICAqICAgaWRlbnRpdHkgPT4gaWRlbnRpdHkucHJvdmlkZXIgPT09ICdnb29nbGUnXG4gICAqIClcbiAgICpcbiAgICogLy8gdW5saW5rIHRoZSBnb29nbGUgaWRlbnRpdHlcbiAgICogY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC51bmxpbmtJZGVudGl0eShnb29nbGVJZGVudGl0eSlcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyB1bmxpbmtJZGVudGl0eShpZGVudGl0eTogVXNlcklkZW50aXR5KTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YToge31cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHsgZGF0YTogbnVsbDsgZXJyb3I6IEF1dGhFcnJvciB9XG4gID4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IHJlc3VsdFxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICB0aHJvdyBlcnJvclxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAgICdERUxFVEUnLFxuICAgICAgICAgIGAke3RoaXMudXJsfS91c2VyL2lkZW50aXRpZXMvJHtpZGVudGl0eS5pZGVudGl0eV9pZH1gLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICAgIGp3dDogZGF0YS5zZXNzaW9uPy5hY2Nlc3NfdG9rZW4gPz8gdW5kZWZpbmVkLFxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyBhIG5ldyBKV1QuXG4gICAqIEBwYXJhbSByZWZyZXNoVG9rZW4gQSB2YWxpZCByZWZyZXNoIHRva2VuIHRoYXQgd2FzIHJldHVybmVkIG9uIGxvZ2luLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfcmVmcmVzaEFjY2Vzc1Rva2VuKHJlZnJlc2hUb2tlbjogc3RyaW5nKTogUHJvbWlzZTxBdXRoUmVzcG9uc2U+IHtcbiAgICAvLyBSZWZyZXNoIHRva2VucyBhcmUgbG9uZy1saXZlZCBiZWFyZXIgY3JlZGVudGlhbHM7IGRvIE5PVCBpbmNsdWRlIGFueVxuICAgIC8vIGZyYWdtZW50IG9mIHRoZSB0b2tlbiBpbiB0aGUgZGVidWcgdGFnLCBldmVuIHdoZW4gYGRlYnVnOiB0cnVlYCBpc1xuICAgIC8vIGVuYWJsZWQgKGxvZ3MgbWF5IGJlIGZvcndhcmRlZCB0byB0aGlyZC1wYXJ0eSBzZXJ2aWNlcykuXG4gICAgY29uc3QgZGVidWdOYW1lID0gYCNfcmVmcmVzaEFjY2Vzc1Rva2VuKClgXG4gICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnYmVnaW4nKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IERhdGUubm93KClcblxuICAgICAgLy8gd2lsbCBhdHRlbXB0IHRvIHJlZnJlc2ggdGhlIHRva2VuIHdpdGggZXhwb25lbnRpYWwgYmFja29mZlxuICAgICAgcmV0dXJuIGF3YWl0IHJldHJ5YWJsZShcbiAgICAgICAgYXN5bmMgKGF0dGVtcHQpID0+IHtcbiAgICAgICAgICBpZiAoYXR0ZW1wdCA+IDApIHtcbiAgICAgICAgICAgIGF3YWl0IHNsZWVwKDIwMCAqIE1hdGgucG93KDIsIGF0dGVtcHQgLSAxKSkgLy8gMjAwLCA0MDAsIDgwMCwgLi4uXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAncmVmcmVzaGluZyBhdHRlbXB0JywgYXR0ZW1wdClcblxuICAgICAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnUE9TVCcsIGAke3RoaXMudXJsfS90b2tlbj9ncmFudF90eXBlPXJlZnJlc2hfdG9rZW5gLCB7XG4gICAgICAgICAgICBib2R5OiB7IHJlZnJlc2hfdG9rZW46IHJlZnJlc2hUb2tlbiB9LFxuICAgICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgICAgeGZvcm06IF9zZXNzaW9uUmVzcG9uc2UsXG4gICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgKGF0dGVtcHQsIGVycm9yKSA9PiB7XG4gICAgICAgICAgY29uc3QgbmV4dEJhY2tPZmZJbnRlcnZhbCA9IDIwMCAqIE1hdGgucG93KDIsIGF0dGVtcHQpXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIGVycm9yICYmXG4gICAgICAgICAgICBpc0F1dGhSZXRyeWFibGVGZXRjaEVycm9yKGVycm9yKSAmJlxuICAgICAgICAgICAgLy8gcmV0cnlhYmxlIG9ubHkgaWYgdGhlIHJlcXVlc3QgY2FuIGJlIHNlbnQgYmVmb3JlIHRoZSBiYWNrb2ZmIG92ZXJmbG93cyB0aGUgdGljayBkdXJhdGlvblxuICAgICAgICAgICAgRGF0ZS5ub3coKSArIG5leHRCYWNrT2ZmSW50ZXJ2YWwgLSBzdGFydGVkQXQgPCBBVVRPX1JFRlJFU0hfVElDS19EVVJBVElPTl9NU1xuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aGlzLl9kZWJ1ZyhkZWJ1Z05hbWUsICdlcnJvcicsIGVycm9yKVxuXG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiB7IHNlc3Npb246IG51bGwsIHVzZXI6IG51bGwgfSwgZXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuX2RlYnVnKGRlYnVnTmFtZSwgJ2VuZCcpXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBfaXNWYWxpZFNlc3Npb24obWF5YmVTZXNzaW9uOiB1bmtub3duKTogbWF5YmVTZXNzaW9uIGlzIFNlc3Npb24ge1xuICAgIGNvbnN0IGlzVmFsaWRTZXNzaW9uID1cbiAgICAgIHR5cGVvZiBtYXliZVNlc3Npb24gPT09ICdvYmplY3QnICYmXG4gICAgICBtYXliZVNlc3Npb24gIT09IG51bGwgJiZcbiAgICAgICdhY2Nlc3NfdG9rZW4nIGluIG1heWJlU2Vzc2lvbiAmJlxuICAgICAgJ3JlZnJlc2hfdG9rZW4nIGluIG1heWJlU2Vzc2lvbiAmJlxuICAgICAgJ2V4cGlyZXNfYXQnIGluIG1heWJlU2Vzc2lvblxuXG4gICAgcmV0dXJuIGlzVmFsaWRTZXNzaW9uXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9oYW5kbGVQcm92aWRlclNpZ25JbihcbiAgICBwcm92aWRlcjogUHJvdmlkZXIsXG4gICAgb3B0aW9uczoge1xuICAgICAgcmVkaXJlY3RUbz86IHN0cmluZ1xuICAgICAgc2NvcGVzPzogc3RyaW5nXG4gICAgICBxdWVyeVBhcmFtcz86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH1cbiAgICAgIHNraXBCcm93c2VyUmVkaXJlY3Q/OiBib29sZWFuXG4gICAgfVxuICApIHtcbiAgICBjb25zdCB1cmw6IHN0cmluZyA9IGF3YWl0IHRoaXMuX2dldFVybEZvclByb3ZpZGVyKGAke3RoaXMudXJsfS9hdXRob3JpemVgLCBwcm92aWRlciwge1xuICAgICAgcmVkaXJlY3RUbzogb3B0aW9ucy5yZWRpcmVjdFRvLFxuICAgICAgc2NvcGVzOiBvcHRpb25zLnNjb3BlcyxcbiAgICAgIHF1ZXJ5UGFyYW1zOiBvcHRpb25zLnF1ZXJ5UGFyYW1zLFxuICAgIH0pXG5cbiAgICB0aGlzLl9kZWJ1ZygnI19oYW5kbGVQcm92aWRlclNpZ25JbigpJywgJ3Byb3ZpZGVyJywgcHJvdmlkZXIsICdvcHRpb25zJywgb3B0aW9ucywgJ3VybCcsIHVybClcblxuICAgIC8vIHRyeSB0byBvcGVuIG9uIHRoZSBicm93c2VyXG4gICAgaWYgKGlzQnJvd3NlcigpICYmICFvcHRpb25zLnNraXBCcm93c2VyUmVkaXJlY3QpIHtcbiAgICAgIHdpbmRvdy5sb2NhdGlvbi5hc3NpZ24odXJsKVxuICAgIH1cblxuICAgIHJldHVybiB7IGRhdGE6IHsgcHJvdmlkZXIsIHVybCB9LCBlcnJvcjogbnVsbCB9XG4gIH1cblxuICAvKipcbiAgICogUmVjb3ZlcnMgdGhlIHNlc3Npb24gZnJvbSBMb2NhbFN0b3JhZ2UgYW5kIHJlZnJlc2hlcyB0aGUgdG9rZW5cbiAgICogTm90ZTogdGhpcyBtZXRob2QgaXMgYXN5bmMgdG8gYWNjb21tb2RhdGUgZm9yIEFzeW5jU3RvcmFnZSBlLmcuIGluIFJlYWN0IG5hdGl2ZS5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3JlY292ZXJBbmRSZWZyZXNoKCkge1xuICAgIGNvbnN0IGRlYnVnTmFtZSA9ICcjX3JlY292ZXJBbmRSZWZyZXNoKCknXG4gICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnYmVnaW4nKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGN1cnJlbnRTZXNzaW9uID0gKGF3YWl0IGdldEl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIHRoaXMuc3RvcmFnZUtleSkpIGFzIFNlc3Npb24gfCBudWxsXG5cbiAgICAgIGlmIChjdXJyZW50U2Vzc2lvbiAmJiB0aGlzLnVzZXJTdG9yYWdlKSB7XG4gICAgICAgIGxldCBtYXliZVVzZXI6IHsgdXNlcjogVXNlciB8IG51bGwgfSB8IG51bGwgPSAoYXdhaXQgZ2V0SXRlbUFzeW5jKFxuICAgICAgICAgIHRoaXMudXNlclN0b3JhZ2UsXG4gICAgICAgICAgdGhpcy5zdG9yYWdlS2V5ICsgJy11c2VyJ1xuICAgICAgICApKSBhcyBhbnlcblxuICAgICAgICBpZiAoIXRoaXMuc3RvcmFnZS5pc1NlcnZlciAmJiBPYmplY3QuaXModGhpcy5zdG9yYWdlLCB0aGlzLnVzZXJTdG9yYWdlKSAmJiAhbWF5YmVVc2VyKSB7XG4gICAgICAgICAgLy8gc3RvcmFnZSBhbmQgdXNlclN0b3JhZ2UgYXJlIHRoZSBzYW1lIHN0b3JhZ2UgbWVkaXVtLCBmb3IgZXhhbXBsZVxuICAgICAgICAgIC8vIHdpbmRvdy5sb2NhbFN0b3JhZ2UgaWYgdXNlclN0b3JhZ2UgZG9lcyBub3QgaGF2ZSB0aGUgdXNlciBmcm9tXG4gICAgICAgICAgLy8gc3RvcmFnZSBzdG9yZWQsIHN0b3JlIGl0IGZpcnN0IHRoZXJlYnkgbWlncmF0aW5nIHRoZSB1c2VyIG9iamVjdFxuICAgICAgICAgIC8vIGZyb20gc3RvcmFnZSAtPiB1c2VyU3RvcmFnZVxuXG4gICAgICAgICAgbWF5YmVVc2VyID0geyB1c2VyOiBjdXJyZW50U2Vzc2lvbi51c2VyIH1cbiAgICAgICAgICBhd2FpdCBzZXRJdGVtQXN5bmModGhpcy51c2VyU3RvcmFnZSwgdGhpcy5zdG9yYWdlS2V5ICsgJy11c2VyJywgbWF5YmVVc2VyKVxuICAgICAgICB9XG5cbiAgICAgICAgY3VycmVudFNlc3Npb24udXNlciA9IG1heWJlVXNlcj8udXNlciA/PyB1c2VyTm90QXZhaWxhYmxlUHJveHkoKVxuICAgICAgfSBlbHNlIGlmIChjdXJyZW50U2Vzc2lvbiAmJiAhY3VycmVudFNlc3Npb24udXNlcikge1xuICAgICAgICAvLyB1c2VyIHN0b3JhZ2UgaXMgbm90IHNldCwgbGV0J3MgY2hlY2sgaWYgaXQgd2FzIHByZXZpb3VzbHkgZW5hYmxlZCBzb1xuICAgICAgICAvLyB3ZSBicmluZyBiYWNrIHRoZSBzdG9yYWdlIGFzIGl0IHNob3VsZCBiZVxuXG4gICAgICAgIGlmICghY3VycmVudFNlc3Npb24udXNlcikge1xuICAgICAgICAgIC8vIHRlc3QgaWYgdXNlclN0b3JhZ2Ugd2FzIHByZXZpb3VzbHkgZW5hYmxlZCBhbmQgdGhlIHN0b3JhZ2UgbWVkaXVtIHdhcyB0aGUgc2FtZSwgdG8gbW92ZSB0aGUgdXNlciBiYWNrIHVuZGVyIHRoZSBzYW1lIGtleVxuICAgICAgICAgIGNvbnN0IHNlcGFyYXRlVXNlcjogeyB1c2VyOiBVc2VyIHwgbnVsbCB9IHwgbnVsbCA9IChhd2FpdCBnZXRJdGVtQXN5bmMoXG4gICAgICAgICAgICB0aGlzLnN0b3JhZ2UsXG4gICAgICAgICAgICB0aGlzLnN0b3JhZ2VLZXkgKyAnLXVzZXInXG4gICAgICAgICAgKSkgYXMgYW55XG5cbiAgICAgICAgICBpZiAoc2VwYXJhdGVVc2VyICYmIHNlcGFyYXRlVXNlcj8udXNlcikge1xuICAgICAgICAgICAgY3VycmVudFNlc3Npb24udXNlciA9IHNlcGFyYXRlVXNlci51c2VyXG5cbiAgICAgICAgICAgIGF3YWl0IHJlbW92ZUl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIHRoaXMuc3RvcmFnZUtleSArICctdXNlcicpXG4gICAgICAgICAgICBhd2FpdCBzZXRJdGVtQXN5bmModGhpcy5zdG9yYWdlLCB0aGlzLnN0b3JhZ2VLZXksIGN1cnJlbnRTZXNzaW9uKVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjdXJyZW50U2Vzc2lvbi51c2VyID0gdXNlck5vdEF2YWlsYWJsZVByb3h5KClcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnc2Vzc2lvbiBmcm9tIHN0b3JhZ2UnLCBjdXJyZW50U2Vzc2lvbilcblxuICAgICAgaWYgKCF0aGlzLl9pc1ZhbGlkU2Vzc2lvbihjdXJyZW50U2Vzc2lvbikpIHtcbiAgICAgICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnc2Vzc2lvbiBpcyBub3QgdmFsaWQnKVxuICAgICAgICBpZiAoY3VycmVudFNlc3Npb24gIT09IG51bGwpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLl9yZW1vdmVTZXNzaW9uKClcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBleHBpcmVzV2l0aE1hcmdpbiA9XG4gICAgICAgIChjdXJyZW50U2Vzc2lvbi5leHBpcmVzX2F0ID8/IEluZmluaXR5KSAqIDEwMDAgLSBEYXRlLm5vdygpIDwgRVhQSVJZX01BUkdJTl9NU1xuXG4gICAgICB0aGlzLl9kZWJ1ZyhcbiAgICAgICAgZGVidWdOYW1lLFxuICAgICAgICBgc2Vzc2lvbiBoYXMke2V4cGlyZXNXaXRoTWFyZ2luID8gJycgOiAnIG5vdCd9IGV4cGlyZWQgd2l0aCBtYXJnaW4gb2YgJHtFWFBJUllfTUFSR0lOX01TfXNgXG4gICAgICApXG5cbiAgICAgIGlmIChleHBpcmVzV2l0aE1hcmdpbikge1xuICAgICAgICBpZiAodGhpcy5hdXRvUmVmcmVzaFRva2VuICYmIGN1cnJlbnRTZXNzaW9uLnJlZnJlc2hfdG9rZW4pIHtcbiAgICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCB0aGlzLl9jYWxsUmVmcmVzaFRva2VuKGN1cnJlbnRTZXNzaW9uLnJlZnJlc2hfdG9rZW4pXG5cbiAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIC8vIEF1dGhSZWZyZXNoRGlzY2FyZGVkRXJyb3IgbWVhbnMgYSBjb25jdXJyZW50IHNpZ25PdXQgYWxyZWFkeVxuICAgICAgICAgICAgLy8gY2xlYXJlZCBzdG9yYWdlIGFuZCBmaXJlZCBTSUdORURfT1VULiBEb24ndCBydW4gX3JlbW92ZVNlc3Npb25cbiAgICAgICAgICAgIC8vIGFnYWluIGhlcmUsIG9yIHdlJ2xsIGVtaXQgYSBkdXBsaWNhdGUgU0lHTkVEX09VVC5cbiAgICAgICAgICAgIGlmIChpc0F1dGhSZWZyZXNoRGlzY2FyZGVkRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgICAgICAgIHRoaXMuX2RlYnVnKGRlYnVnTmFtZSwgJ3JlZnJlc2ggZGlzY2FyZGVkIGJ5IGNvbW1pdCBndWFyZCcsIGVycm9yKVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAncmVmcmVzaCBmYWlsZWQnLCBlcnJvcilcblxuICAgICAgICAgICAgICBpZiAoIWlzQXV0aFJldHJ5YWJsZUZldGNoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZGVidWcoXG4gICAgICAgICAgICAgICAgICBkZWJ1Z05hbWUsXG4gICAgICAgICAgICAgICAgICAncmVmcmVzaCBmYWlsZWQgd2l0aCBhIG5vbi1yZXRyeWFibGUgZXJyb3IsIHJlbW92aW5nIHRoZSBzZXNzaW9uJyxcbiAgICAgICAgICAgICAgICAgIGVycm9yXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuX3JlbW92ZVNlc3Npb24oKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKFxuICAgICAgICBjdXJyZW50U2Vzc2lvbi51c2VyICYmXG4gICAgICAgIChjdXJyZW50U2Vzc2lvbi51c2VyIGFzIGFueSkuX19pc1VzZXJOb3RBdmFpbGFibGVQcm94eSA9PT0gdHJ1ZVxuICAgICAgKSB7XG4gICAgICAgIC8vIElmIHdlIGhhdmUgYSBwcm94eSB1c2VyLCB0cnkgdG8gZ2V0IHRoZSByZWFsIHVzZXIgZGF0YVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgdGhpcy5fZ2V0VXNlcihjdXJyZW50U2Vzc2lvbi5hY2Nlc3NfdG9rZW4pXG5cbiAgICAgICAgICBpZiAoIXVzZXJFcnJvciAmJiBkYXRhPy51c2VyKSB7XG4gICAgICAgICAgICBjdXJyZW50U2Vzc2lvbi51c2VyID0gZGF0YS51c2VyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLl9zYXZlU2Vzc2lvbihjdXJyZW50U2Vzc2lvbilcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdTSUdORURfSU4nLCBjdXJyZW50U2Vzc2lvbilcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnY291bGQgbm90IGdldCB1c2VyIGRhdGEsIHNraXBwaW5nIFNJR05FRF9JTiBub3RpZmljYXRpb24nKVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZ2V0VXNlckVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZ2V0dGluZyB1c2VyIGRhdGE6JywgZ2V0VXNlckVycm9yKVxuICAgICAgICAgIHRoaXMuX2RlYnVnKFxuICAgICAgICAgICAgZGVidWdOYW1lLFxuICAgICAgICAgICAgJ2Vycm9yIGdldHRpbmcgdXNlciBkYXRhLCBza2lwcGluZyBTSUdORURfSU4gbm90aWZpY2F0aW9uJyxcbiAgICAgICAgICAgIGdldFVzZXJFcnJvclxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gbm8gbmVlZCB0byBwZXJzaXN0IGN1cnJlbnRTZXNzaW9uIGFnYWluLCBhcyB3ZSBqdXN0IGxvYWRlZCBpdCBmcm9tXG4gICAgICAgIC8vIGxvY2FsIHN0b3JhZ2U7IHBlcnNpc3RpbmcgaXQgYWdhaW4gbWF5IG92ZXJ3cml0ZSBhIHZhbHVlIHNhdmVkIGJ5XG4gICAgICAgIC8vIGFub3RoZXIgY2xpZW50IHdpdGggYWNjZXNzIHRvIHRoZSBzYW1lIGxvY2FsIHN0b3JhZ2VcbiAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoJ1NJR05FRF9JTicsIGN1cnJlbnRTZXNzaW9uKVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnZXJyb3InLCBlcnIpXG5cbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgICAgcmV0dXJuXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuX2RlYnVnKGRlYnVnTmFtZSwgJ2VuZCcpXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBfY2FsbFJlZnJlc2hUb2tlbihyZWZyZXNoVG9rZW46IHN0cmluZyk6IFByb21pc2U8Q2FsbFJlZnJlc2hUb2tlblJlc3VsdD4ge1xuICAgIGlmICghcmVmcmVzaFRva2VuKSB7XG4gICAgICB0aHJvdyBuZXcgQXV0aFNlc3Npb25NaXNzaW5nRXJyb3IoKVxuICAgIH1cblxuICAgIC8vIHJlZnJlc2hpbmcgaXMgYWxyZWFkeSBpbiBwcm9ncmVzc1xuICAgIGlmICh0aGlzLnJlZnJlc2hpbmdEZWZlcnJlZCkge1xuICAgICAgcmV0dXJuIHRoaXMucmVmcmVzaGluZ0RlZmVycmVkLnByb21pc2VcbiAgICB9XG5cbiAgICAvLyBSZWZyZXNoIHRva2VucyBhcmUgbG9uZy1saXZlZCBiZWFyZXIgY3JlZGVudGlhbHM7IGRvIE5PVCBpbmNsdWRlIGFueVxuICAgIC8vIGZyYWdtZW50IG9mIHRoZSB0b2tlbiBpbiB0aGUgZGVidWcgdGFnLCBldmVuIHdoZW4gYGRlYnVnOiB0cnVlYCBpc1xuICAgIC8vIGVuYWJsZWQgKGxvZ3MgbWF5IGJlIGZvcndhcmRlZCB0byB0aGlyZC1wYXJ0eSBzZXJ2aWNlcykuXG4gICAgY29uc3QgZGVidWdOYW1lID0gYCNfY2FsbFJlZnJlc2hUb2tlbigpYFxuXG4gICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnYmVnaW4nKVxuXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMucmVmcmVzaGluZ0RlZmVycmVkID0gbmV3IERlZmVycmVkPENhbGxSZWZyZXNoVG9rZW5SZXN1bHQ+KClcblxuICAgICAgLy8gU25hcHNob3Qgc3RvcmFnZSBiZWZvcmUgdGhlIGZldGNoLiBUaGUgY29tbWl0IGd1YXJkIGRpc2NhcmRzIHRoZVxuICAgICAgLy8gcm90YXRlZCB0b2tlbnMgb25seSB3aGVuIGEgbm9uLW51bGwgcHJlLWZldGNoIHNuYXBzaG90IGNoYW5nZWQgdW5kZXJcbiAgICAgIC8vIHVzIOKAlCB0eXBpY2FsIGNhc2U6IGEgY29uY3VycmVudCBgc2lnbk91dGAgcmFuIGBfcmVtb3ZlU2Vzc2lvbmAsIG9yXG4gICAgICAvLyBhbm90aGVyIHRhYidzIHJlZnJlc2ggcmV3cm90ZSB0aGUgc2xvdC4gQ2FsbGVycyBwYXNzaW5nXG4gICAgICAvLyBleHRlcm5hbGx5LXNvdXJjZWQgdG9rZW5zIChTU1IgY29va2llIGhhbmRvZmYsIG11bHRpLWFjY291bnRcbiAgICAgIC8vIHN3aXRjaGluZywgYHNldFNlc3Npb25gL2ByZWZyZXNoU2Vzc2lvbih7IHJlZnJlc2hfdG9rZW4gfSlgKSBtYXlcbiAgICAgIC8vIHN0YXJ0IGZyb20gYSBudWxsIHNuYXBzaG90IE9SIGZyb20gYSBub24tbnVsbCBzbmFwc2hvdCB3aG9zZVxuICAgICAgLy8gcmVmcmVzaF90b2tlbiBkaWZmZXJzIGZyb20gdGhlIG9uZSB0aGV5J3JlIGh5ZHJhdGluZzsgaW4gYm90aFxuICAgICAgLy8gY2FzZXMgdGhlIGd1YXJkIGZpcmVzIG9ubHkgd2hlbiBzdG9yYWdlIHdhcyAqbW9kaWZpZWQgYmV0d2VlblxuICAgICAgLy8gc25hcHNob3RzKiwgbm90IHdoZW4gdGhlIGlucHV0IHRva2VuIGRpc2FncmVlcyB3aXRoIHdoYXQncyBzdG9yZWQuXG4gICAgICBjb25zdCBzdG9yZWRBdFN0YXJ0ID0gKGF3YWl0IGdldEl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIHRoaXMuc3RvcmFnZUtleSkpIGFzIFNlc3Npb24gfCBudWxsXG5cbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHRoaXMuX3JlZnJlc2hBY2Nlc3NUb2tlbihyZWZyZXNoVG9rZW4pXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yXG4gICAgICBpZiAoIWRhdGEuc2Vzc2lvbikgdGhyb3cgbmV3IEF1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKClcblxuICAgICAgY29uc3Qgc3RvcmVkQWZ0ZXIgPSAoYXdhaXQgZ2V0SXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgdGhpcy5zdG9yYWdlS2V5KSkgYXMgU2Vzc2lvbiB8IG51bGxcbiAgICAgIGNvbnN0IHN0b3JhZ2VDaGFuZ2VkVW5kZXJVcyA9XG4gICAgICAgIHN0b3JlZEF0U3RhcnQgIT09IG51bGwgJiZcbiAgICAgICAgKHN0b3JlZEFmdGVyID09PSBudWxsIHx8IHN0b3JlZEFmdGVyLnJlZnJlc2hfdG9rZW4gIT09IHN0b3JlZEF0U3RhcnQucmVmcmVzaF90b2tlbilcblxuICAgICAgaWYgKHN0b3JhZ2VDaGFuZ2VkVW5kZXJVcykge1xuICAgICAgICB0aGlzLl9kZWJ1ZyhcbiAgICAgICAgICBkZWJ1Z05hbWUsXG4gICAgICAgICAgJ2NvbW1pdCBndWFyZDogc3RvcmFnZSBjaGFuZ2VkIHNpbmNlIHJlZnJlc2ggc3RhcnRlZCwgZGlzY2FyZGluZyByb3RhdGVkIHRva2VucycsXG4gICAgICAgICAge1xuICAgICAgICAgICAgLy8gUHJlc2VuY2UgaW5kaWNhdG9ycyBvbmx5IOKAlCBuZXZlciBsb2cgcmVmcmVzaCB0b2tlbiBmcmFnbWVudHMsXG4gICAgICAgICAgICAvLyBldmVuIHBhcnRpYWwuIExvZ3MgbWF5IGJlIGZvcndhcmRlZCB0byB0aGlyZC1wYXJ0eSBzZXJ2aWNlcy5cbiAgICAgICAgICAgIHN0YXJ0ZWRXaXRoOiAncHJlc2VudCcsXG4gICAgICAgICAgICBub3dIb2xkczogc3RvcmVkQWZ0ZXIgPyAncmVwbGFjZWQnIDogJ2NsZWFyZWQnLFxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgICBjb25zdCBkaXNjYXJkZWQ6IENhbGxSZWZyZXNoVG9rZW5SZXN1bHQgPSB7XG4gICAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgICBlcnJvcjogbmV3IEF1dGhSZWZyZXNoRGlzY2FyZGVkRXJyb3IoKSxcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnJlZnJlc2hpbmdEZWZlcnJlZC5yZXNvbHZlKGRpc2NhcmRlZClcbiAgICAgICAgcmV0dXJuIGRpc2NhcmRlZFxuICAgICAgfVxuXG4gICAgICAvLyBTZWNvbmQgbGVnIG9mIHRoZSBjb21taXQgZ3VhcmQ6IGNsb3NlIHRoZSBUT0NUT1Ugd2luZG93IGJldHdlZW4gdGhlXG4gICAgICAvLyBzeW5jaHJvbm91cyBgc3RvcmFnZUNoYW5nZWRVbmRlclVzYCBjaGVjayBhbmQgdGhlIGFjdHVhbCBzdG9yYWdlXG4gICAgICAvLyB3cml0ZXMgaW5zaWRlIGBfc2F2ZVNlc3Npb25gLiBBIGNvbmN1cnJlbnQgYHNpZ25PdXQg4oaSIF9yZW1vdmVTZXNzaW9uYFxuICAgICAgLy8gY2FuIGxhbmQgaW5zaWRlIGBfc2F2ZVNlc3Npb25gJ3MgYGF3YWl0IHNldEl0ZW1Bc3luYyguLi4pYCB5aWVsZHMgYW5kXG4gICAgICAvLyBjbGVhciBzdG9yYWdlIGp1c3QgYmVmb3JlIHdlIG92ZXJ3cml0ZSBpdC4gQ2FwdHVyZSB0aGUgZXBvY2ggQkVGT1JFXG4gICAgICAvLyB0aGUgc2F2ZSBhbmQgcmUtY2hlY2sgYWZ0ZXI7IGlmIGl0IGFkdmFuY2VkLCB1bmRvIHRoZSB3cml0ZSBkaXJlY3RseVxuICAgICAgLy8gKGRvIE5PVCBjYWxsIGBfcmVtb3ZlU2Vzc2lvbmAg4oCUIHRoYXQgd291bGQgZW1pdCBhIGR1cGxpY2F0ZVxuICAgICAgLy8gU0lHTkVEX09VVCBmb3IgdGhlIGNvbmN1cnJlbnQgc2lnbk91dCB0aGF0IGFscmVhZHkgZmlyZWQgb25lKS5cbiAgICAgIGNvbnN0IGVwb2NoQmVmb3JlU2F2ZSA9IHRoaXMuX3Nlc3Npb25SZW1vdmFsRXBvY2hcblxuICAgICAgYXdhaXQgdGhpcy5fc2F2ZVNlc3Npb24oZGF0YS5zZXNzaW9uKVxuXG4gICAgICBpZiAodGhpcy5fc2Vzc2lvblJlbW92YWxFcG9jaCAhPT0gZXBvY2hCZWZvcmVTYXZlKSB7XG4gICAgICAgIHRoaXMuX2RlYnVnKFxuICAgICAgICAgIGRlYnVnTmFtZSxcbiAgICAgICAgICAnY29tbWl0IGd1YXJkIChwb3N0LXNhdmUpOiBfcmVtb3ZlU2Vzc2lvbiByYW4gZHVyaW5nIF9zYXZlU2Vzc2lvbiwgdW5kb2luZyB3cml0ZSdcbiAgICAgICAgKVxuICAgICAgICBhd2FpdCByZW1vdmVJdGVtQXN5bmModGhpcy5zdG9yYWdlLCB0aGlzLnN0b3JhZ2VLZXkpXG4gICAgICAgIGlmICh0aGlzLnVzZXJTdG9yYWdlKSB7XG4gICAgICAgICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMudXNlclN0b3JhZ2UsIHRoaXMuc3RvcmFnZUtleSArICctdXNlcicpXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZGlzY2FyZGVkOiBDYWxsUmVmcmVzaFRva2VuUmVzdWx0ID0ge1xuICAgICAgICAgIGRhdGE6IG51bGwsXG4gICAgICAgICAgZXJyb3I6IG5ldyBBdXRoUmVmcmVzaERpc2NhcmRlZEVycm9yKCksXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5yZWZyZXNoaW5nRGVmZXJyZWQucmVzb2x2ZShkaXNjYXJkZWQpXG4gICAgICAgIHJldHVybiBkaXNjYXJkZWRcbiAgICAgIH1cblxuICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5QWxsU3Vic2NyaWJlcnMoJ1RPS0VOX1JFRlJFU0hFRCcsIGRhdGEuc2Vzc2lvbilcblxuICAgICAgY29uc3QgcmVzdWx0ID0geyBkYXRhOiBkYXRhLnNlc3Npb24sIGVycm9yOiBudWxsIH1cblxuICAgICAgdGhpcy5yZWZyZXNoaW5nRGVmZXJyZWQucmVzb2x2ZShyZXN1bHQpXG5cbiAgICAgIHJldHVybiByZXN1bHRcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnZXJyb3InLCBlcnJvcilcblxuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB7IGRhdGE6IG51bGwsIGVycm9yIH1cblxuICAgICAgICBpZiAoIWlzQXV0aFJldHJ5YWJsZUZldGNoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5fcmVtb3ZlU2Vzc2lvbigpXG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnJlZnJlc2hpbmdEZWZlcnJlZD8ucmVzb2x2ZShyZXN1bHQpXG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgfVxuXG4gICAgICB0aGlzLnJlZnJlc2hpbmdEZWZlcnJlZD8ucmVqZWN0KGVycm9yKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5yZWZyZXNoaW5nRGVmZXJyZWQgPSBudWxsXG4gICAgICB0aGlzLl9kZWJ1ZyhkZWJ1Z05hbWUsICdlbmQnKVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX25vdGlmeUFsbFN1YnNjcmliZXJzKFxuICAgIGV2ZW50OiBBdXRoQ2hhbmdlRXZlbnQsXG4gICAgc2Vzc2lvbjogU2Vzc2lvbiB8IG51bGwsXG4gICAgYnJvYWRjYXN0ID0gdHJ1ZVxuICApIHtcbiAgICBjb25zdCBkZWJ1Z05hbWUgPSBgI19ub3RpZnlBbGxTdWJzY3JpYmVycygke2V2ZW50fSlgXG4gICAgdGhpcy5fZGVidWcoZGVidWdOYW1lLCAnYmVnaW4nLCBzZXNzaW9uLCBgYnJvYWRjYXN0ID0gJHticm9hZGNhc3R9YClcblxuICAgIHRyeSB7XG4gICAgICBpZiAodGhpcy5icm9hZGNhc3RDaGFubmVsICYmIGJyb2FkY2FzdCkge1xuICAgICAgICB0aGlzLmJyb2FkY2FzdENoYW5uZWwucG9zdE1lc3NhZ2UoeyBldmVudCwgc2Vzc2lvbiB9KVxuICAgICAgfVxuXG4gICAgICBjb25zdCBlcnJvcnM6IHVua25vd25bXSA9IFtdXG4gICAgICBjb25zdCBwcm9taXNlcyA9IEFycmF5LmZyb20odGhpcy5zdGF0ZUNoYW5nZUVtaXR0ZXJzLnZhbHVlcygpKS5tYXAoYXN5bmMgKHgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCB4LmNhbGxiYWNrKGV2ZW50LCBzZXNzaW9uKVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgZXJyb3JzLnB1c2goZSlcbiAgICAgICAgfVxuICAgICAgfSlcblxuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwocHJvbWlzZXMpXG5cbiAgICAgIGlmIChlcnJvcnMubGVuZ3RoID4gMCkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGVycm9ycy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3JzW2ldKVxuICAgICAgICB9XG5cbiAgICAgICAgdGhyb3cgZXJyb3JzWzBdXG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuX2RlYnVnKGRlYnVnTmFtZSwgJ2VuZCcpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIHNldCBjdXJyZW50U2Vzc2lvbiBhbmQgY3VycmVudFVzZXJcbiAgICogcHJvY2VzcyB0byBfc3RhcnRBdXRvUmVmcmVzaFRva2VuIGlmIHBvc3NpYmxlXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9zYXZlU2Vzc2lvbihzZXNzaW9uOiBTZXNzaW9uKSB7XG4gICAgdGhpcy5fZGVidWcoJyNfc2F2ZVNlc3Npb24oKScsIHNlc3Npb24pXG4gICAgLy8gX3NhdmVTZXNzaW9uIGlzIGFsd2F5cyBjYWxsZWQgd2hlbmV2ZXIgYSBuZXcgc2Vzc2lvbiBoYXMgYmVlbiBhY3F1aXJlZFxuICAgIC8vIHNvIHdlIGNhbiBzYWZlbHkgc3VwcHJlc3MgdGhlIHdhcm5pbmcgcmV0dXJuZWQgYnkgZnV0dXJlIGdldFNlc3Npb24gY2FsbHNcbiAgICB0aGlzLnN1cHByZXNzR2V0U2Vzc2lvbldhcm5pbmcgPSB0cnVlXG4gICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgYCR7dGhpcy5zdG9yYWdlS2V5fS1jb2RlLXZlcmlmaWVyYClcbiAgICAvLyBDcmVhdGUgYSBzaGFsbG93IGNvcHkgdG8gd29yayB3aXRoLCB0byBhdm9pZCBtdXRhdGluZyB0aGUgb3JpZ2luYWwgc2Vzc2lvbiBvYmplY3QgaWYgaXQncyB1c2VkIGVsc2V3aGVyZVxuICAgIGNvbnN0IHNlc3Npb25Ub1Byb2Nlc3MgPSB7IC4uLnNlc3Npb24gfVxuXG4gICAgY29uc3QgdXNlcklzUHJveHkgPVxuICAgICAgc2Vzc2lvblRvUHJvY2Vzcy51c2VyICYmIChzZXNzaW9uVG9Qcm9jZXNzLnVzZXIgYXMgYW55KS5fX2lzVXNlck5vdEF2YWlsYWJsZVByb3h5ID09PSB0cnVlXG4gICAgaWYgKHRoaXMudXNlclN0b3JhZ2UpIHtcbiAgICAgIGlmICghdXNlcklzUHJveHkgJiYgc2Vzc2lvblRvUHJvY2Vzcy51c2VyKSB7XG4gICAgICAgIC8vIElmIGl0J3MgYSByZWFsIHVzZXIgb2JqZWN0LCBzYXZlIGl0IHRvIHVzZXJTdG9yYWdlLlxuICAgICAgICBhd2FpdCBzZXRJdGVtQXN5bmModGhpcy51c2VyU3RvcmFnZSwgdGhpcy5zdG9yYWdlS2V5ICsgJy11c2VyJywge1xuICAgICAgICAgIHVzZXI6IHNlc3Npb25Ub1Byb2Nlc3MudXNlcixcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSBpZiAodXNlcklzUHJveHkpIHtcbiAgICAgICAgLy8gSWYgaXQncyB0aGUgcHJveHksIGl0IG1lYW5zIHVzZXIgd2FzIG5vdCBmb3VuZCBpbiB1c2VyU3RvcmFnZS5cbiAgICAgICAgLy8gV2Ugc2hvdWxkIGVuc3VyZSBubyBzdGFsZSB1c2VyIGRhdGEgZm9yIHRoaXMga2V5IGV4aXN0cyBpbiB1c2VyU3RvcmFnZSBpZiB3ZSB3ZXJlIHRvIHNhdmUgbnVsbCxcbiAgICAgICAgLy8gb3Igc2ltcGx5IG5vdCBzYXZlIHRoZSBwcm94eS4gRm9yIG5vdywgd2UgZG9uJ3Qgc2F2ZSB0aGUgcHJveHkgaGVyZS5cbiAgICAgICAgLy8gSWYgdGhlcmUncyBhIG5lZWQgdG8gY2xlYXIgdXNlclN0b3JhZ2UgaWYgdXNlciBiZWNvbWVzIHByb3h5LCB0aGF0IGxvZ2ljIHdvdWxkIGdvIGhlcmUuXG4gICAgICB9XG5cbiAgICAgIC8vIFByZXBhcmUgdGhlIG1haW4gc2Vzc2lvbiBkYXRhIGZvciBwcmltYXJ5IHN0b3JhZ2U6IHJlbW92ZSB0aGUgdXNlciBwcm9wZXJ0eSBiZWZvcmUgY2xvbmluZ1xuICAgICAgLy8gVGhpcyBpcyBpbXBvcnRhbnQgYmVjYXVzZSB0aGUgb3JpZ2luYWwgc2Vzc2lvbi51c2VyIG1pZ2h0IGJlIHRoZSBwcm94eVxuICAgICAgY29uc3QgbWFpblNlc3Npb25EYXRhOiBPbWl0PFNlc3Npb24sICd1c2VyJz4gJiB7IHVzZXI/OiBVc2VyIH0gPSB7IC4uLnNlc3Npb25Ub1Byb2Nlc3MgfVxuICAgICAgZGVsZXRlIG1haW5TZXNzaW9uRGF0YS51c2VyIC8vIFJlbW92ZSB1c2VyIChyZWFsIG9yIHByb3h5KSBiZWZvcmUgY2xvbmluZyBmb3IgbWFpbiBzdG9yYWdlXG5cbiAgICAgIGNvbnN0IGNsb25lZE1haW5TZXNzaW9uRGF0YSA9IGRlZXBDbG9uZShtYWluU2Vzc2lvbkRhdGEpXG4gICAgICBhd2FpdCBzZXRJdGVtQXN5bmModGhpcy5zdG9yYWdlLCB0aGlzLnN0b3JhZ2VLZXksIGNsb25lZE1haW5TZXNzaW9uRGF0YSlcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gTm8gdXNlclN0b3JhZ2UgaXMgY29uZmlndXJlZC5cbiAgICAgIC8vIEluIHRoaXMgY2FzZSwgc2Vzc2lvbi51c2VyIHNob3VsZCBpZGVhbGx5IG5vdCBiZSBhIHByb3h5LlxuICAgICAgLy8gSWYgaXQgd2VyZSwgc3RydWN0dXJlZENsb25lIHdvdWxkIGZhaWwuIFRoaXMgaW1wbGllcyBhbiBpc3N1ZSBlbHNld2hlcmUgaWYgdXNlciBpcyBhIHByb3h5IGhlcmVcbiAgICAgIGNvbnN0IGNsb25lZFNlc3Npb24gPSBkZWVwQ2xvbmUoc2Vzc2lvblRvUHJvY2VzcykgLy8gc2Vzc2lvblRvUHJvY2VzcyBzdGlsbCBoYXMgaXRzIG9yaWdpbmFsIHVzZXIgcHJvcGVydHlcbiAgICAgIGF3YWl0IHNldEl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIHRoaXMuc3RvcmFnZUtleSwgY2xvbmVkU2Vzc2lvbilcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9yZW1vdmVTZXNzaW9uKCkge1xuICAgIC8vIEJ1bXAgc3luY2hyb25vdXNseSwgQkVGT1JFIGFueSBgYXdhaXRgLCBzbyB0aGF0IGBfY2FsbFJlZnJlc2hUb2tlbmAnc1xuICAgIC8vIHBvc3Qtc2F2ZSBjaGVjayBzZWVzIHRoZSBpbmNyZW1lbnQgd2hlbmV2ZXIgdGhpcyBtZXRob2QgaGFzIHN0YXJ0ZWQg4oCUXG4gICAgLy8gZXZlbiBpZiBpdCBoYXNuJ3QgZmluaXNoZWQuIFBhaXJzIHdpdGggdGhlIGVwb2NoIGNoZWNrIGluXG4gICAgLy8gYF9jYWxsUmVmcmVzaFRva2VuYC4gU2VlIGBfc2Vzc2lvblJlbW92YWxFcG9jaGAgZmllbGQgZG9jLlxuICAgIHRoaXMuX3Nlc3Npb25SZW1vdmFsRXBvY2ggKz0gMVxuICAgIHRoaXMuX2RlYnVnKCcjX3JlbW92ZVNlc3Npb24oKScpXG5cbiAgICB0aGlzLnN1cHByZXNzR2V0U2Vzc2lvbldhcm5pbmcgPSBmYWxzZVxuXG4gICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgdGhpcy5zdG9yYWdlS2V5KVxuICAgIGF3YWl0IHJlbW92ZUl0ZW1Bc3luYyh0aGlzLnN0b3JhZ2UsIHRoaXMuc3RvcmFnZUtleSArICctY29kZS12ZXJpZmllcicpXG4gICAgYXdhaXQgcmVtb3ZlSXRlbUFzeW5jKHRoaXMuc3RvcmFnZSwgdGhpcy5zdG9yYWdlS2V5ICsgJy11c2VyJylcblxuICAgIGlmICh0aGlzLnVzZXJTdG9yYWdlKSB7XG4gICAgICBhd2FpdCByZW1vdmVJdGVtQXN5bmModGhpcy51c2VyU3RvcmFnZSwgdGhpcy5zdG9yYWdlS2V5ICsgJy11c2VyJylcbiAgICB9XG5cbiAgICBhd2FpdCB0aGlzLl9ub3RpZnlBbGxTdWJzY3JpYmVycygnU0lHTkVEX09VVCcsIG51bGwpXG4gIH1cblxuICAvKipcbiAgICogUmVtb3ZlcyBhbnkgcmVnaXN0ZXJlZCB2aXNpYmlsaXR5Y2hhbmdlIGNhbGxiYWNrLlxuICAgKlxuICAgKiB7QHNlZSAjc3RhcnRBdXRvUmVmcmVzaH1cbiAgICoge0BzZWUgI3N0b3BBdXRvUmVmcmVzaH1cbiAgICovXG4gIHByaXZhdGUgX3JlbW92ZVZpc2liaWxpdHlDaGFuZ2VkQ2FsbGJhY2soKSB7XG4gICAgdGhpcy5fZGVidWcoJyNfcmVtb3ZlVmlzaWJpbGl0eUNoYW5nZWRDYWxsYmFjaygpJylcblxuICAgIGNvbnN0IGNhbGxiYWNrID0gdGhpcy52aXNpYmlsaXR5Q2hhbmdlZENhbGxiYWNrXG4gICAgdGhpcy52aXNpYmlsaXR5Q2hhbmdlZENhbGxiYWNrID0gbnVsbFxuXG4gICAgdHJ5IHtcbiAgICAgIGlmIChjYWxsYmFjayAmJiBpc0Jyb3dzZXIoKSAmJiB3aW5kb3c/LnJlbW92ZUV2ZW50TGlzdGVuZXIpIHtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBjYWxsYmFjaylcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdyZW1vdmluZyB2aXNpYmlsaXR5Y2hhbmdlIGNhbGxiYWNrIGZhaWxlZCcsIGUpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgdGhlIHByaXZhdGUgaW1wbGVtZW50YXRpb24gb2Yge0BsaW5rICNzdGFydEF1dG9SZWZyZXNofS4gVXNlIHRoaXNcbiAgICogd2l0aGluIHRoZSBsaWJyYXJ5LlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfc3RhcnRBdXRvUmVmcmVzaCgpIHtcbiAgICBhd2FpdCB0aGlzLl9zdG9wQXV0b1JlZnJlc2goKVxuXG4gICAgdGhpcy5fZGVidWcoJyNfc3RhcnRBdXRvUmVmcmVzaCgpJylcblxuICAgIGNvbnN0IHRpY2tlciA9IHNldEludGVydmFsKCgpID0+IHRoaXMuX2F1dG9SZWZyZXNoVG9rZW5UaWNrKCksIEFVVE9fUkVGUkVTSF9USUNLX0RVUkFUSU9OX01TKVxuICAgIHRoaXMuYXV0b1JlZnJlc2hUaWNrZXIgPSB0aWNrZXJcblxuICAgIGlmICh0aWNrZXIgJiYgdHlwZW9mIHRpY2tlciA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIHRpY2tlci51bnJlZiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgLy8gdGlja2VyIGlzIGEgTm9kZUpTIFRpbWVvdXQgb2JqZWN0IHRoYXQgaGFzIGFuIGB1bnJlZmAgbWV0aG9kXG4gICAgICAvLyBodHRwczovL25vZGVqcy5vcmcvYXBpL3RpbWVycy5odG1sI3RpbWVvdXR1bnJlZlxuICAgICAgLy8gV2hlbiBhdXRvIHJlZnJlc2ggaXMgdXNlZCBpbiBOb2RlSlMgKGxpa2UgZm9yIHRlc3RpbmcpIHRoZVxuICAgICAgLy8gYHNldEludGVydmFsYCBpcyBwcmV2ZW50aW5nIHRoZSBwcm9jZXNzIGZyb20gYmVpbmcgbWFya2VkIGFzXG4gICAgICAvLyBmaW5pc2hlZCBhbmQgdGVzdHMgcnVuIGVuZGxlc3NseS4gVGhpcyBjYW4gYmUgcHJldmVudGVkIGJ5IGNhbGxpbmdcbiAgICAgIC8vIGB1bnJlZigpYCBvbiB0aGUgcmV0dXJuZWQgb2JqZWN0LlxuICAgICAgdGlja2VyLnVucmVmKClcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgVFMgaGFzIG5vIGNvbnRleHQgb2YgRGVub1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIERlbm8gIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBEZW5vLnVucmVmVGltZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIC8vIHNpbWlsYXIgbGlrZSBmb3IgTm9kZUpTLCBidXQgd2l0aCB0aGUgRGVubyBBUElcbiAgICAgIC8vIGh0dHBzOi8vZGVuby5sYW5kL2FwaUBsYXRlc3Q/dW5zdGFibGUmcz1EZW5vLnVucmVmVGltZXJcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgVFMgaGFzIG5vIGNvbnRleHQgb2YgRGVub1xuICAgICAgRGVuby51bnJlZlRpbWVyKHRpY2tlcilcbiAgICB9XG5cbiAgICAvLyBydW4gdGhlIHRpY2sgaW1tZWRpYXRlbHksIGJ1dCBpbiB0aGUgbmV4dCBwYXNzIG9mIHRoZSBldmVudCBsb29wIHNvIHRoYXRcbiAgICAvLyAjX2luaXRpYWxpemUgY2FuIGJlIGFsbG93ZWQgdG8gY29tcGxldGUgd2l0aG91dCByZWN1cnNpdmVseSB3YWl0aW5nIG9uXG4gICAgLy8gaXRzZWxmXG4gICAgY29uc3QgdGltZW91dCA9IHNldFRpbWVvdXQoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgdGhpcy5pbml0aWFsaXplUHJvbWlzZVxuICAgICAgYXdhaXQgdGhpcy5fYXV0b1JlZnJlc2hUb2tlblRpY2soKVxuICAgIH0sIDApXG4gICAgdGhpcy5hdXRvUmVmcmVzaFRpY2tUaW1lb3V0ID0gdGltZW91dFxuXG4gICAgaWYgKHRpbWVvdXQgJiYgdHlwZW9mIHRpbWVvdXQgPT09ICdvYmplY3QnICYmIHR5cGVvZiB0aW1lb3V0LnVucmVmID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aW1lb3V0LnVucmVmKClcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgVFMgaGFzIG5vIGNvbnRleHQgb2YgRGVub1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIERlbm8gIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBEZW5vLnVucmVmVGltZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgVFMgaGFzIG5vIGNvbnRleHQgb2YgRGVub1xuICAgICAgRGVuby51bnJlZlRpbWVyKHRpbWVvdXQpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgdGhlIHByaXZhdGUgaW1wbGVtZW50YXRpb24gb2Yge0BsaW5rICNzdG9wQXV0b1JlZnJlc2h9LiBVc2UgdGhpc1xuICAgKiB3aXRoaW4gdGhlIGxpYnJhcnkuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9zdG9wQXV0b1JlZnJlc2goKSB7XG4gICAgdGhpcy5fZGVidWcoJyNfc3RvcEF1dG9SZWZyZXNoKCknKVxuXG4gICAgY29uc3QgdGlja2VyID0gdGhpcy5hdXRvUmVmcmVzaFRpY2tlclxuICAgIHRoaXMuYXV0b1JlZnJlc2hUaWNrZXIgPSBudWxsXG5cbiAgICBpZiAodGlja2VyKSB7XG4gICAgICBjbGVhckludGVydmFsKHRpY2tlcilcbiAgICB9XG5cbiAgICBjb25zdCB0aW1lb3V0ID0gdGhpcy5hdXRvUmVmcmVzaFRpY2tUaW1lb3V0XG4gICAgdGhpcy5hdXRvUmVmcmVzaFRpY2tUaW1lb3V0ID0gbnVsbFxuXG4gICAgaWYgKHRpbWVvdXQpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTdGFydHMgYW4gYXV0by1yZWZyZXNoIHByb2Nlc3MgaW4gdGhlIGJhY2tncm91bmQuIFRoZSBzZXNzaW9uIGlzIGNoZWNrZWRcbiAgICogZXZlcnkgZmV3IHNlY29uZHMuIENsb3NlIHRvIHRoZSB0aW1lIG9mIGV4cGlyYXRpb24gYSBwcm9jZXNzIGlzIHN0YXJ0ZWQgdG9cbiAgICogcmVmcmVzaCB0aGUgc2Vzc2lvbi4gSWYgcmVmcmVzaGluZyBmYWlscyBpdCB3aWxsIGJlIHJldHJpZWQgZm9yIGFzIGxvbmcgYXNcbiAgICogbmVjZXNzYXJ5LlxuICAgKlxuICAgKiBJZiB5b3Ugc2V0IHRoZSB7QGxpbmsgR29UcnVlQ2xpZW50T3B0aW9ucyNhdXRvUmVmcmVzaFRva2VufSB5b3UgZG9uJ3QgbmVlZFxuICAgKiB0byBjYWxsIHRoaXMgZnVuY3Rpb24sIGl0IHdpbGwgYmUgY2FsbGVkIGZvciB5b3UuXG4gICAqXG4gICAqIE9uIGJyb3dzZXJzIHRoZSByZWZyZXNoIHByb2Nlc3Mgd29ya3Mgb25seSB3aGVuIHRoZSB0YWIvd2luZG93IGlzIGluIHRoZVxuICAgKiBmb3JlZ3JvdW5kIHRvIGNvbnNlcnZlIHJlc291cmNlcyBhcyB3ZWxsIGFzIHByZXZlbnQgcmFjZSBjb25kaXRpb25zIGFuZFxuICAgKiBmbG9vZGluZyBhdXRoIHdpdGggcmVxdWVzdHMuIElmIHlvdSBjYWxsIHRoaXMgbWV0aG9kIGFueSBtYW5hZ2VkXG4gICAqIHZpc2liaWxpdHkgY2hhbmdlIGNhbGxiYWNrIHdpbGwgYmUgcmVtb3ZlZCBhbmQgeW91IG11c3QgbWFuYWdlIHZpc2liaWxpdHlcbiAgICogY2hhbmdlcyBvbiB5b3VyIG93bi5cbiAgICpcbiAgICogT24gbm9uLWJyb3dzZXIgcGxhdGZvcm1zIHRoZSByZWZyZXNoIHByb2Nlc3Mgd29ya3MgKmNvbnRpbnVvdXNseSogaW4gdGhlXG4gICAqIGJhY2tncm91bmQsIHdoaWNoIG1heSBub3QgYmUgZGVzaXJhYmxlLiBZb3Ugc2hvdWxkIGhvb2sgaW50byB5b3VyXG4gICAqIHBsYXRmb3JtJ3MgZm9yZWdyb3VuZCBpbmRpY2F0aW9uIG1lY2hhbmlzbSBhbmQgY2FsbCB0aGVzZSBtZXRob2RzXG4gICAqIGFwcHJvcHJpYXRlbHkgdG8gY29uc2VydmUgcmVzb3VyY2VzLlxuICAgKlxuICAgKiB7QHNlZSAjc3RvcEF1dG9SZWZyZXNofVxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIE9ubHkgdXNlZnVsIGluIG5vbi1icm93c2VyIGVudmlyb25tZW50cyBzdWNoIGFzIFJlYWN0IE5hdGl2ZSBvciBFbGVjdHJvbi5cbiAgICogLSBUaGUgU3VwYWJhc2UgQXV0aCBsaWJyYXJ5IGF1dG9tYXRpY2FsbHkgc3RhcnRzIGFuZCBzdG9wcyBwcm9hY3RpdmVseSByZWZyZXNoaW5nIHRoZSBzZXNzaW9uIHdoZW4gYSB0YWIgaXMgZm9jdXNlZCBvciBub3QuXG4gICAqIC0gT24gbm9uLWJyb3dzZXIgcGxhdGZvcm1zLCBzdWNoIGFzIG1vYmlsZSBvciBkZXNrdG9wIGFwcHMgYnVpbHQgd2l0aCB3ZWIgdGVjaG5vbG9naWVzLCB0aGUgbGlicmFyeSBpcyBub3QgYWJsZSB0byBlZmZlY3RpdmVseSBkZXRlcm1pbmUgd2hldGhlciB0aGUgYXBwbGljYXRpb24gaXMgX2ZvY3VzZWRfIG9yIG5vdC5cbiAgICogLSBUbyBnaXZlIHRoaXMgaGludCB0byB0aGUgYXBwbGljYXRpb24sIHlvdSBzaG91bGQgYmUgY2FsbGluZyB0aGlzIG1ldGhvZCB3aGVuIHRoZSBhcHAgaXMgaW4gZm9jdXMgYW5kIGNhbGxpbmcgYHN1cGFiYXNlLmF1dGguc3RvcEF1dG9SZWZyZXNoKClgIHdoZW4gaXQncyBvdXQgb2YgZm9jdXMuXG4gICAqXG4gICAqIEBleGFtcGxlIFN0YXJ0IGFuZCBzdG9wIGF1dG8gcmVmcmVzaCBpbiBSZWFjdCBOYXRpdmVcbiAgICogYGBganNcbiAgICogaW1wb3J0IHsgQXBwU3RhdGUgfSBmcm9tICdyZWFjdC1uYXRpdmUnXG4gICAqXG4gICAqIC8vIG1ha2Ugc3VyZSB5b3UgcmVnaXN0ZXIgdGhpcyBvbmx5IG9uY2UhXG4gICAqIEFwcFN0YXRlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIChzdGF0ZSkgPT4ge1xuICAgKiAgIGlmIChzdGF0ZSA9PT0gJ2FjdGl2ZScpIHtcbiAgICogICAgIHN1cGFiYXNlLmF1dGguc3RhcnRBdXRvUmVmcmVzaCgpXG4gICAqICAgfSBlbHNlIHtcbiAgICogICAgIHN1cGFiYXNlLmF1dGguc3RvcEF1dG9SZWZyZXNoKClcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgc3RhcnRBdXRvUmVmcmVzaCgpIHtcbiAgICB0aGlzLl9yZW1vdmVWaXNpYmlsaXR5Q2hhbmdlZENhbGxiYWNrKClcbiAgICBhd2FpdCB0aGlzLl9zdGFydEF1dG9SZWZyZXNoKClcbiAgfVxuXG4gIC8qKlxuICAgKiBTdG9wcyBhbiBhY3RpdmUgYXV0byByZWZyZXNoIHByb2Nlc3MgcnVubmluZyBpbiB0aGUgYmFja2dyb3VuZCAoaWYgYW55KS5cbiAgICpcbiAgICogSWYgeW91IGNhbGwgdGhpcyBtZXRob2QgYW55IG1hbmFnZWQgdmlzaWJpbGl0eSBjaGFuZ2UgY2FsbGJhY2sgd2lsbCBiZVxuICAgKiByZW1vdmVkIGFuZCB5b3UgbXVzdCBtYW5hZ2UgdmlzaWJpbGl0eSBjaGFuZ2VzIG9uIHlvdXIgb3duLlxuICAgKlxuICAgKiBTZWUge0BsaW5rICNzdGFydEF1dG9SZWZyZXNofSBmb3IgbW9yZSBkZXRhaWxzLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIE9ubHkgdXNlZnVsIGluIG5vbi1icm93c2VyIGVudmlyb25tZW50cyBzdWNoIGFzIFJlYWN0IE5hdGl2ZSBvciBFbGVjdHJvbi5cbiAgICogLSBUaGUgU3VwYWJhc2UgQXV0aCBsaWJyYXJ5IGF1dG9tYXRpY2FsbHkgc3RhcnRzIGFuZCBzdG9wcyBwcm9hY3RpdmVseSByZWZyZXNoaW5nIHRoZSBzZXNzaW9uIHdoZW4gYSB0YWIgaXMgZm9jdXNlZCBvciBub3QuXG4gICAqIC0gT24gbm9uLWJyb3dzZXIgcGxhdGZvcm1zLCBzdWNoIGFzIG1vYmlsZSBvciBkZXNrdG9wIGFwcHMgYnVpbHQgd2l0aCB3ZWIgdGVjaG5vbG9naWVzLCB0aGUgbGlicmFyeSBpcyBub3QgYWJsZSB0byBlZmZlY3RpdmVseSBkZXRlcm1pbmUgd2hldGhlciB0aGUgYXBwbGljYXRpb24gaXMgX2ZvY3VzZWRfIG9yIG5vdC5cbiAgICogLSBXaGVuIHlvdXIgYXBwbGljYXRpb24gZ29lcyBpbiB0aGUgYmFja2dyb3VuZCBvciBvdXQgb2YgZm9jdXMsIGNhbGwgdGhpcyBtZXRob2QgdG8gc3RvcCB0aGUgcHJvYWN0aXZlIHJlZnJlc2hpbmcgb2YgdGhlIHNlc3Npb24uXG4gICAqXG4gICAqIEBleGFtcGxlIFN0YXJ0IGFuZCBzdG9wIGF1dG8gcmVmcmVzaCBpbiBSZWFjdCBOYXRpdmVcbiAgICogYGBganNcbiAgICogaW1wb3J0IHsgQXBwU3RhdGUgfSBmcm9tICdyZWFjdC1uYXRpdmUnXG4gICAqXG4gICAqIC8vIG1ha2Ugc3VyZSB5b3UgcmVnaXN0ZXIgdGhpcyBvbmx5IG9uY2UhXG4gICAqIEFwcFN0YXRlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIChzdGF0ZSkgPT4ge1xuICAgKiAgIGlmIChzdGF0ZSA9PT0gJ2FjdGl2ZScpIHtcbiAgICogICAgIHN1cGFiYXNlLmF1dGguc3RhcnRBdXRvUmVmcmVzaCgpXG4gICAqICAgfSBlbHNlIHtcbiAgICogICAgIHN1cGFiYXNlLmF1dGguc3RvcEF1dG9SZWZyZXNoKClcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgc3RvcEF1dG9SZWZyZXNoKCkge1xuICAgIHRoaXMuX3JlbW92ZVZpc2liaWxpdHlDaGFuZ2VkQ2FsbGJhY2soKVxuICAgIGF3YWl0IHRoaXMuX3N0b3BBdXRvUmVmcmVzaCgpXG4gIH1cblxuICAvKipcbiAgICogVGVhcnMgZG93biB0aGUgY2xpZW50J3MgYmFja2dyb3VuZCB3b3JrOiBzdG9wcyB0aGUgYXV0by1yZWZyZXNoIGludGVydmFsLFxuICAgKiByZW1vdmVzIHRoZSBgdmlzaWJpbGl0eWNoYW5nZWAgbGlzdGVuZXIsIGNsb3NlcyB0aGUgY3Jvc3MtdGFiXG4gICAqIGBCcm9hZGNhc3RDaGFubmVsYCwgYW5kIGNsZWFycyByZWdpc3RlcmVkIGBvbkF1dGhTdGF0ZUNoYW5nZWAgc3Vic2NyaWJlcnMuXG4gICAqXG4gICAqIENhbGwgdGhpcyBmcm9tIGNsZWFudXAgaG9va3Mgd2hlbiB0aGUgY2xpZW50IGlzIGJlaW5nIHJlcGxhY2VkIGJlZm9yZVxuICAgKiBpdHMgSlMgcmVhbG0gaXMgZGVzdHJveWVkLiBSZWFjdCBTdHJpY3QgTW9kZSBhbmQgSE1SIGFyZSB0aGUgY29tbW9uXG4gICAqIGNhc2VzLiBBbnkgaW4tZmxpZ2h0IGBmZXRjaGAgY2FsbHMgY29udGludWUgdG8gY29tcGxldGlvbiBhbmQgbWF5IHN0aWxsXG4gICAqIHdyaXRlIHRvIHN0b3JhZ2U7IGRpc3Bvc2UgZG9lc24ndCBhYm9ydCB0aGVtIG9yIGVyYXNlIHN0b3JhZ2UuXG4gICAqXG4gICAqIExpZmVjeWNsZSBjYXZlYXQ6IGJlY2F1c2UgaW4tZmxpZ2h0IHJlZnJlc2hlcyBhcmUgbm90IGFib3J0ZWQsIGFcbiAgICogZGlzcG9zZWQgaW5zdGFuY2UgY2FuIHN0aWxsIHBlcnNpc3QgYSByb3RhdGVkIHNlc3Npb24gdG8gc3RvcmFnZSBhZnRlclxuICAgKiBgZGlzcG9zZSgpYCByZXR1cm5zLiBBIHN1YnNlcXVlbnQgYGNyZWF0ZUNsaWVudGAgYWdhaW5zdCB0aGUgc2FtZVxuICAgKiBgc3RvcmFnZUtleWAgd2lsbCBwaWNrIHVwIHRoYXQgc2Vzc2lvbiBvbiBpdHMgbmV4dCByZWFkLiBJZiB5b3UgbmVlZFxuICAgKiBzdHJpY3QgaXNvbGF0aW9uIGJldHdlZW4gY2xpZW50IGxpZmVjeWNsZXMsIGF3YWl0IGFueSBwZW5kaW5nIGF1dGhcbiAgICogb3BlcmF0aW9uIGJlZm9yZSBjYWxsaW5nIGBkaXNwb3NlKClgIChvciBjaGFuZ2UgdGhlIGBzdG9yYWdlS2V5YCBmb3JcbiAgICogdGhlIHJlcGxhY2VtZW50IGNsaWVudCkuXG4gICAqXG4gICAqIFNhZmUgdG8gY2FsbCByZXBlYXRlZGx5LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKlxuICAgKiBAZXhhbXBsZSBDbGVhbnVwIG9uIFJlYWN0IHVubW91bnRcbiAgICogYGBgdHNcbiAgICogdXNlRWZmZWN0KCgpID0+IHtcbiAgICogICBjb25zdCBjbGllbnQgPSBjcmVhdGVDbGllbnQoLi4uKVxuICAgKiAgIHJldHVybiAoKSA9PiB7IGNsaWVudC5hdXRoLmRpc3Bvc2UoKSB9XG4gICAqIH0sIFtdKVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGRpc3Bvc2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5fcmVtb3ZlVmlzaWJpbGl0eUNoYW5nZWRDYWxsYmFjaygpXG4gICAgYXdhaXQgdGhpcy5fc3RvcEF1dG9SZWZyZXNoKClcbiAgICB0aGlzLmJyb2FkY2FzdENoYW5uZWw/LmNsb3NlKClcbiAgICB0aGlzLmJyb2FkY2FzdENoYW5uZWwgPSBudWxsXG4gICAgdGhpcy5zdGF0ZUNoYW5nZUVtaXR0ZXJzLmNsZWFyKClcbiAgfVxuXG4gIC8qKlxuICAgKiBSdW5zIHRoZSBhdXRvIHJlZnJlc2ggdG9rZW4gdGljay5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX2F1dG9SZWZyZXNoVG9rZW5UaWNrKCkge1xuICAgIHRoaXMuX2RlYnVnKCcjX2F1dG9SZWZyZXNoVG9rZW5UaWNrKCknLCAnYmVnaW4nKVxuXG4gICAgaWYgKHRoaXMubG9jayAhPSBudWxsKSB7XG4gICAgICAvLyBUT0RPKHYzKTogcmVtb3ZlIGxlZ2FjeSBsb2NrIHBhdGguIFVzZXMgYF9hY3F1aXJlTG9jaygwLCAuLi4pYCB3aGljaFxuICAgICAgLy8gdGhyb3dzIGBMb2NrQWNxdWlyZVRpbWVvdXRFcnJvcmAgaW1tZWRpYXRlbHkgaWYgdGhlIGxvY2sgaXMgaGVsZCDigJRcbiAgICAgIC8vIHRoYXQncyB0aGUgZmFpbC1mYXN0IHNraXAgcGF0aCB0aGF0IGxldHMgdGhlIHRpY2sgYmFpbCBvdXQgaW5zdGVhZFxuICAgICAgLy8gb2YgcXVldWluZyBiZWhpbmQgYSBsb25nLXJ1bm5pbmcgb3BlcmF0aW9uLlxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5fYWNxdWlyZUxvY2soMCwgYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgICAgICAgZGF0YTogeyBzZXNzaW9uIH0sXG4gICAgICAgICAgICAgICAgfSA9IHJlc3VsdFxuXG4gICAgICAgICAgICAgICAgaWYgKCFzZXNzaW9uIHx8ICFzZXNzaW9uLnJlZnJlc2hfdG9rZW4gfHwgIXNlc3Npb24uZXhwaXJlc19hdCkge1xuICAgICAgICAgICAgICAgICAgdGhpcy5fZGVidWcoJyNfYXV0b1JlZnJlc2hUb2tlblRpY2soKScsICdubyBzZXNzaW9uJylcbiAgICAgICAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IGV4cGlyZXNJblRpY2tzID0gTWF0aC5mbG9vcihcbiAgICAgICAgICAgICAgICAgIChzZXNzaW9uLmV4cGlyZXNfYXQgKiAxMDAwIC0gbm93KSAvIEFVVE9fUkVGUkVTSF9USUNLX0RVUkFUSU9OX01TXG4gICAgICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVidWcoXG4gICAgICAgICAgICAgICAgICAnI19hdXRvUmVmcmVzaFRva2VuVGljaygpJyxcbiAgICAgICAgICAgICAgICAgIGBhY2Nlc3MgdG9rZW4gZXhwaXJlcyBpbiAke2V4cGlyZXNJblRpY2tzfSB0aWNrcywgYSB0aWNrIGxhc3RzICR7QVVUT19SRUZSRVNIX1RJQ0tfRFVSQVRJT05fTVN9bXMsIHJlZnJlc2ggdGhyZXNob2xkIGlzICR7QVVUT19SRUZSRVNIX1RJQ0tfVEhSRVNIT0xEfSB0aWNrc2BcbiAgICAgICAgICAgICAgICApXG5cbiAgICAgICAgICAgICAgICBpZiAoZXhwaXJlc0luVGlja3MgPD0gQVVUT19SRUZSRVNIX1RJQ0tfVEhSRVNIT0xEKSB7XG4gICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLl9jYWxsUmVmcmVzaFRva2VuKHNlc3Npb24ucmVmcmVzaF90b2tlbilcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgICAgICAgJ0F1dG8gcmVmcmVzaCB0aWNrIGZhaWxlZCB3aXRoIGVycm9yLiBUaGlzIGlzIGxpa2VseSBhIHRyYW5zaWVudCBlcnJvci4nLFxuICAgICAgICAgICAgICAgIGVcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICB0aGlzLl9kZWJ1ZygnI19hdXRvUmVmcmVzaFRva2VuVGljaygpJywgJ2VuZCcpXG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBpZiAoZSBpbnN0YW5jZW9mIExvY2tBY3F1aXJlVGltZW91dEVycm9yKSB7XG4gICAgICAgICAgdGhpcy5fZGVidWcoJ2F1dG8gcmVmcmVzaCB0b2tlbiB0aWNrIGxvY2sgbm90IGF2YWlsYWJsZScpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhyb3cgZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICAvLyBMb2NrbGVzcyBkZWZhdWx0OiBza2lwIGlmIGEgcmVmcmVzaCBpcyBhbHJlYWR5IGluIGZsaWdodC5cbiAgICAvLyBgX2NhbGxSZWZyZXNoVG9rZW5gIGFsc28gZGVkdXBlcyB2aWEgdGhlIHNhbWUgZmllbGQ7IHRoaXMgaXMganVzdCBhXG4gICAgLy8gZmFzdC1wYXRoIHNraXAgdG8gYXZvaWQgYW4gdW5uZWNlc3Nhcnkgc3RvcmFnZSByZWFkLlxuICAgIGlmICh0aGlzLnJlZnJlc2hpbmdEZWZlcnJlZCAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5fZGVidWcoJyNfYXV0b1JlZnJlc2hUb2tlblRpY2soKScsICdyZWZyZXNoIGFscmVhZHkgaW4gZmxpZ2h0LCBza2lwcGluZycpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKVxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICBkYXRhOiB7IHNlc3Npb24gfSxcbiAgICAgICAgICB9ID0gcmVzdWx0XG5cbiAgICAgICAgICBpZiAoIXNlc3Npb24gfHwgIXNlc3Npb24ucmVmcmVzaF90b2tlbiB8fCAhc2Vzc2lvbi5leHBpcmVzX2F0KSB7XG4gICAgICAgICAgICB0aGlzLl9kZWJ1ZygnI19hdXRvUmVmcmVzaFRva2VuVGljaygpJywgJ25vIHNlc3Npb24nKVxuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gc2Vzc2lvbiB3aWxsIGV4cGlyZSBpbiB0aGlzIG1hbnkgdGlja3MgKG9yIGhhcyBhbHJlYWR5IGV4cGlyZWQgaWYgPD0gMClcbiAgICAgICAgICBjb25zdCBleHBpcmVzSW5UaWNrcyA9IE1hdGguZmxvb3IoXG4gICAgICAgICAgICAoc2Vzc2lvbi5leHBpcmVzX2F0ICogMTAwMCAtIG5vdykgLyBBVVRPX1JFRlJFU0hfVElDS19EVVJBVElPTl9NU1xuICAgICAgICAgIClcblxuICAgICAgICAgIHRoaXMuX2RlYnVnKFxuICAgICAgICAgICAgJyNfYXV0b1JlZnJlc2hUb2tlblRpY2soKScsXG4gICAgICAgICAgICBgYWNjZXNzIHRva2VuIGV4cGlyZXMgaW4gJHtleHBpcmVzSW5UaWNrc30gdGlja3MsIGEgdGljayBsYXN0cyAke0FVVE9fUkVGUkVTSF9USUNLX0RVUkFUSU9OX01TfW1zLCByZWZyZXNoIHRocmVzaG9sZCBpcyAke0FVVE9fUkVGUkVTSF9USUNLX1RIUkVTSE9MRH0gdGlja3NgXG4gICAgICAgICAgKVxuXG4gICAgICAgICAgaWYgKGV4cGlyZXNJblRpY2tzIDw9IEFVVE9fUkVGUkVTSF9USUNLX1RIUkVTSE9MRCkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5fY2FsbFJlZnJlc2hUb2tlbihzZXNzaW9uLnJlZnJlc2hfdG9rZW4pXG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdBdXRvIHJlZnJlc2ggdGljayBmYWlsZWQgd2l0aCBlcnJvci4gVGhpcyBpcyBsaWtlbHkgYSB0cmFuc2llbnQgZXJyb3IuJywgZSlcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5fZGVidWcoJyNfYXV0b1JlZnJlc2hUb2tlblRpY2soKScsICdlbmQnKVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgY2FsbGJhY2tzIG9uIHRoZSBicm93c2VyIC8gcGxhdGZvcm0sIHdoaWNoIGluLXR1cm4gcnVuXG4gICAqIGFsZ29yaXRobXMgd2hlbiB0aGUgYnJvd3NlciB3aW5kb3cvdGFiIGFyZSBpbiBmb3JlZ3JvdW5kLiBPbiBub24tYnJvd3NlclxuICAgKiBwbGF0Zm9ybXMgaXQgYXNzdW1lcyBhbHdheXMgZm9yZWdyb3VuZC5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX2hhbmRsZVZpc2liaWxpdHlDaGFuZ2UoKSB7XG4gICAgdGhpcy5fZGVidWcoJyNfaGFuZGxlVmlzaWJpbGl0eUNoYW5nZSgpJylcblxuICAgIGlmICghaXNCcm93c2VyKCkgfHwgIXdpbmRvdz8uYWRkRXZlbnRMaXN0ZW5lcikge1xuICAgICAgaWYgKHRoaXMuYXV0b1JlZnJlc2hUb2tlbikge1xuICAgICAgICAvLyBpbiBub24tYnJvd3NlciBlbnZpcm9ubWVudHMgdGhlIHJlZnJlc2ggdG9rZW4gdGlja2VyIHJ1bnMgYWx3YXlzXG4gICAgICAgIHRoaXMuc3RhcnRBdXRvUmVmcmVzaCgpXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZpc2liaWxpdHlDaGFuZ2VkQ2FsbGJhY2sgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5fb25WaXNpYmlsaXR5Q2hhbmdlZChmYWxzZSlcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICB0aGlzLl9kZWJ1ZygnI3Zpc2liaWxpdHlDaGFuZ2VkQ2FsbGJhY2snLCAnZXJyb3InLCBlcnJvcilcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB3aW5kb3c/LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCB0aGlzLnZpc2liaWxpdHlDaGFuZ2VkQ2FsbGJhY2spXG5cbiAgICAgIC8vIG5vdyBpbW1lZGlhdGVseSBjYWxsIHRoZSB2aXNiaWxpdHkgY2hhbmdlZCBjYWxsYmFjayB0byBzZXR1cCB3aXRoIHRoZVxuICAgICAgLy8gY3VycmVudCB2aXNiaWxpdHkgc3RhdGVcbiAgICAgIGF3YWl0IHRoaXMuX29uVmlzaWJpbGl0eUNoYW5nZWQodHJ1ZSkgLy8gaW5pdGlhbCBjYWxsXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ19oYW5kbGVWaXNpYmlsaXR5Q2hhbmdlJywgZXJyb3IpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENhbGxiYWNrIHJlZ2lzdGVyZWQgd2l0aCBgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnKWAuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9vblZpc2liaWxpdHlDaGFuZ2VkKGNhbGxlZEZyb21Jbml0aWFsaXplOiBib29sZWFuKSB7XG4gICAgY29uc3QgbWV0aG9kTmFtZSA9IGAjX29uVmlzaWJpbGl0eUNoYW5nZWQoJHtjYWxsZWRGcm9tSW5pdGlhbGl6ZX0pYFxuICAgIHRoaXMuX2RlYnVnKG1ldGhvZE5hbWUsICd2aXNpYmlsaXR5U3RhdGUnLCBkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUpXG5cbiAgICBpZiAoZG9jdW1lbnQudmlzaWJpbGl0eVN0YXRlID09PSAndmlzaWJsZScpIHtcbiAgICAgIGlmICh0aGlzLmF1dG9SZWZyZXNoVG9rZW4pIHtcbiAgICAgICAgLy8gaW4gYnJvd3NlciBlbnZpcm9ubWVudHMgdGhlIHJlZnJlc2ggdG9rZW4gdGlja2VyIHJ1bnMgb25seSBvbiBmb2N1c2VkIHRhYnNcbiAgICAgICAgLy8gd2hpY2ggcHJldmVudHMgcmFjZSBjb25kaXRpb25zXG4gICAgICAgIHRoaXMuX3N0YXJ0QXV0b1JlZnJlc2goKVxuICAgICAgfVxuXG4gICAgICBpZiAoIWNhbGxlZEZyb21Jbml0aWFsaXplKSB7XG4gICAgICAgIC8vIGNhbGxlZCB3aGVuIHRoZSB2aXNpYmlsaXR5IGhhcyBjaGFuZ2VkLCBpLmUuIHRoZSBicm93c2VyXG4gICAgICAgIC8vIHRyYW5zaXRpb25lZCBmcm9tIGhpZGRlbiAtPiB2aXNpYmxlIHNvIHdlIG5lZWQgdG8gc2VlIGlmIHRoZSBzZXNzaW9uXG4gICAgICAgIC8vIHNob3VsZCBiZSByZWNvdmVyZWRcbiAgICAgICAgYXdhaXQgdGhpcy5pbml0aWFsaXplUHJvbWlzZVxuXG4gICAgICAgIGlmICh0aGlzLmxvY2sgIT0gbnVsbCkge1xuICAgICAgICAgIC8vIFRPRE8odjMpOiByZW1vdmUgbGVnYWN5IGxvY2sgcGF0aFxuICAgICAgICAgIGF3YWl0IHRoaXMuX2FjcXVpcmVMb2NrKHRoaXMubG9ja0FjcXVpcmVUaW1lb3V0LCBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQudmlzaWJpbGl0eVN0YXRlICE9PSAndmlzaWJsZScpIHtcbiAgICAgICAgICAgICAgdGhpcy5fZGVidWcoXG4gICAgICAgICAgICAgICAgbWV0aG9kTmFtZSxcbiAgICAgICAgICAgICAgICAnYWNxdWlyZWQgdGhlIGxvY2sgdG8gcmVjb3ZlciB0aGUgc2Vzc2lvbiwgYnV0IHRoZSBicm93c2VyIHZpc2liaWxpdHlTdGF0ZSBpcyBubyBsb25nZXIgdmlzaWJsZSwgYWJvcnRpbmcnXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhd2FpdCB0aGlzLl9yZWNvdmVyQW5kUmVmcmVzaCgpXG4gICAgICAgICAgfSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoZG9jdW1lbnQudmlzaWJpbGl0eVN0YXRlICE9PSAndmlzaWJsZScpIHtcbiAgICAgICAgICAgIHRoaXMuX2RlYnVnKG1ldGhvZE5hbWUsICd2aXNpYmlsaXR5U3RhdGUgaXMgbm8gbG9uZ2VyIHZpc2libGUsIHNraXBwaW5nIHJlY292ZXJ5JylcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgIH1cbiAgICAgICAgICAvLyByZWNvdmVyIHRoZSBzZXNzaW9uXG4gICAgICAgICAgYXdhaXQgdGhpcy5fcmVjb3ZlckFuZFJlZnJlc2goKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09ICdoaWRkZW4nKSB7XG4gICAgICBpZiAodGhpcy5hdXRvUmVmcmVzaFRva2VuKSB7XG4gICAgICAgIHRoaXMuX3N0b3BBdXRvUmVmcmVzaCgpXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyB0aGUgcmVsZXZhbnQgbG9naW4gVVJMIGZvciBhIHRoaXJkLXBhcnR5IHByb3ZpZGVyLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5yZWRpcmVjdFRvIEEgVVJMIG9yIG1vYmlsZSBhZGRyZXNzIHRvIHNlbmQgdGhlIHVzZXIgdG8gYWZ0ZXIgdGhleSBhcmUgY29uZmlybWVkLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5zY29wZXMgQSBzcGFjZS1zZXBhcmF0ZWQgbGlzdCBvZiBzY29wZXMgZ3JhbnRlZCB0byB0aGUgT0F1dGggYXBwbGljYXRpb24uXG4gICAqIEBwYXJhbSBvcHRpb25zLnF1ZXJ5UGFyYW1zIEFuIG9iamVjdCBvZiBrZXktdmFsdWUgcGFpcnMgY29udGFpbmluZyBxdWVyeSBwYXJhbWV0ZXJzIGdyYW50ZWQgdG8gdGhlIE9BdXRoIGFwcGxpY2F0aW9uLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZ2V0VXJsRm9yUHJvdmlkZXIoXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgcHJvdmlkZXI6IFByb3ZpZGVyLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHJlZGlyZWN0VG8/OiBzdHJpbmdcbiAgICAgIHNjb3Blcz86IHN0cmluZ1xuICAgICAgcXVlcnlQYXJhbXM/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9XG4gICAgICBza2lwQnJvd3NlclJlZGlyZWN0PzogYm9vbGVhblxuICAgIH1cbiAgKSB7XG4gICAgY29uc3QgdXJsUGFyYW1zOiBzdHJpbmdbXSA9IFtgcHJvdmlkZXI9JHtlbmNvZGVVUklDb21wb25lbnQocHJvdmlkZXIpfWBdXG4gICAgaWYgKG9wdGlvbnM/LnJlZGlyZWN0VG8pIHtcbiAgICAgIHVybFBhcmFtcy5wdXNoKGByZWRpcmVjdF90bz0ke2VuY29kZVVSSUNvbXBvbmVudChvcHRpb25zLnJlZGlyZWN0VG8pfWApXG4gICAgfVxuICAgIGlmIChvcHRpb25zPy5zY29wZXMpIHtcbiAgICAgIHVybFBhcmFtcy5wdXNoKGBzY29wZXM9JHtlbmNvZGVVUklDb21wb25lbnQob3B0aW9ucy5zY29wZXMpfWApXG4gICAgfVxuICAgIGlmICh0aGlzLmZsb3dUeXBlID09PSAncGtjZScpIHtcbiAgICAgIGNvbnN0IFtjb2RlQ2hhbGxlbmdlLCBjb2RlQ2hhbGxlbmdlTWV0aG9kXSA9IGF3YWl0IGdldENvZGVDaGFsbGVuZ2VBbmRNZXRob2QoXG4gICAgICAgIHRoaXMuc3RvcmFnZSxcbiAgICAgICAgdGhpcy5zdG9yYWdlS2V5XG4gICAgICApXG5cbiAgICAgIGNvbnN0IGZsb3dQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHtcbiAgICAgICAgY29kZV9jaGFsbGVuZ2U6IGAke2VuY29kZVVSSUNvbXBvbmVudChjb2RlQ2hhbGxlbmdlKX1gLFxuICAgICAgICBjb2RlX2NoYWxsZW5nZV9tZXRob2Q6IGAke2VuY29kZVVSSUNvbXBvbmVudChjb2RlQ2hhbGxlbmdlTWV0aG9kKX1gLFxuICAgICAgfSlcbiAgICAgIHVybFBhcmFtcy5wdXNoKGZsb3dQYXJhbXMudG9TdHJpbmcoKSlcbiAgICB9XG4gICAgaWYgKG9wdGlvbnM/LnF1ZXJ5UGFyYW1zKSB7XG4gICAgICBjb25zdCBxdWVyeSA9IG5ldyBVUkxTZWFyY2hQYXJhbXMob3B0aW9ucy5xdWVyeVBhcmFtcylcbiAgICAgIHVybFBhcmFtcy5wdXNoKHF1ZXJ5LnRvU3RyaW5nKCkpXG4gICAgfVxuICAgIGlmIChvcHRpb25zPy5za2lwQnJvd3NlclJlZGlyZWN0KSB7XG4gICAgICB1cmxQYXJhbXMucHVzaChgc2tpcF9odHRwX3JlZGlyZWN0PSR7b3B0aW9ucy5za2lwQnJvd3NlclJlZGlyZWN0fWApXG4gICAgfVxuXG4gICAgcmV0dXJuIGAke3VybH0/JHt1cmxQYXJhbXMuam9pbignJicpfWBcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX3VuZW5yb2xsKHBhcmFtczogTUZBVW5lbnJvbGxQYXJhbXMpOiBQcm9taXNlPEF1dGhNRkFVbmVucm9sbFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBzZXNzaW9uRGF0YSwgZXJyb3I6IHNlc3Npb25FcnJvciB9ID0gcmVzdWx0XG4gICAgICAgIGlmIChzZXNzaW9uRXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IHNlc3Npb25FcnJvciB9KVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdERUxFVEUnLCBgJHt0aGlzLnVybH0vZmFjdG9ycy8ke3BhcmFtcy5mYWN0b3JJZH1gLCB7XG4gICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgIGp3dDogc2Vzc2lvbkRhdGE/LnNlc3Npb24/LmFjY2Vzc190b2tlbixcbiAgICAgICAgfSlcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiB7QHNlZSBHb1RydWVNRkFBcGkjZW5yb2xsfVxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZW5yb2xsKHBhcmFtczogTUZBRW5yb2xsVE9UUFBhcmFtcyk6IFByb21pc2U8QXV0aE1GQUVucm9sbFRPVFBSZXNwb25zZT5cbiAgcHJpdmF0ZSBhc3luYyBfZW5yb2xsKHBhcmFtczogTUZBRW5yb2xsUGhvbmVQYXJhbXMpOiBQcm9taXNlPEF1dGhNRkFFbnJvbGxQaG9uZVJlc3BvbnNlPlxuICBwcml2YXRlIGFzeW5jIF9lbnJvbGwocGFyYW1zOiBNRkFFbnJvbGxXZWJhdXRoblBhcmFtcyk6IFByb21pc2U8QXV0aE1GQUVucm9sbFdlYmF1dGhuUmVzcG9uc2U+XG4gIHByaXZhdGUgYXN5bmMgX2Vucm9sbChwYXJhbXM6IE1GQUVucm9sbFBhcmFtcyk6IFByb21pc2U8QXV0aE1GQUVucm9sbFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBzZXNzaW9uRGF0YSwgZXJyb3I6IHNlc3Npb25FcnJvciB9ID0gcmVzdWx0XG4gICAgICAgIGlmIChzZXNzaW9uRXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IHNlc3Npb25FcnJvciB9KVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYm9keSA9IHtcbiAgICAgICAgICBmcmllbmRseV9uYW1lOiBwYXJhbXMuZnJpZW5kbHlOYW1lLFxuICAgICAgICAgIGZhY3Rvcl90eXBlOiBwYXJhbXMuZmFjdG9yVHlwZSxcbiAgICAgICAgICAuLi4ocGFyYW1zLmZhY3RvclR5cGUgPT09ICdwaG9uZSdcbiAgICAgICAgICAgID8geyBwaG9uZTogcGFyYW1zLnBob25lIH1cbiAgICAgICAgICAgIDogcGFyYW1zLmZhY3RvclR5cGUgPT09ICd0b3RwJ1xuICAgICAgICAgICAgICA/IHsgaXNzdWVyOiBwYXJhbXMuaXNzdWVyIH1cbiAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSAoYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vZmFjdG9yc2AsIHtcbiAgICAgICAgICBib2R5LFxuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBqd3Q6IHNlc3Npb25EYXRhPy5zZXNzaW9uPy5hY2Nlc3NfdG9rZW4sXG4gICAgICAgIH0pKSBhcyBBdXRoTUZBRW5yb2xsUmVzcG9uc2VcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICAgIH1cblxuICAgICAgICBpZiAocGFyYW1zLmZhY3RvclR5cGUgPT09ICd0b3RwJyAmJiBkYXRhLnR5cGUgPT09ICd0b3RwJyAmJiBkYXRhPy50b3RwPy5xcl9jb2RlKSB7XG4gICAgICAgICAgZGF0YS50b3RwLnFyX2NvZGUgPSBgZGF0YTppbWFnZS9zdmcreG1sO3V0Zi04LCR7ZGF0YS50b3RwLnFyX2NvZGV9YFxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGEsIGVycm9yOiBudWxsIH0pXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICoge0BzZWUgR29UcnVlTUZBQXBpI3ZlcmlmeX1cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3ZlcmlmeShwYXJhbXM6IE1GQVZlcmlmeVRPVFBQYXJhbXMpOiBQcm9taXNlPEF1dGhNRkFWZXJpZnlSZXNwb25zZT5cbiAgcHJpdmF0ZSBhc3luYyBfdmVyaWZ5KHBhcmFtczogTUZBVmVyaWZ5UGhvbmVQYXJhbXMpOiBQcm9taXNlPEF1dGhNRkFWZXJpZnlSZXNwb25zZT5cbiAgcHJpdmF0ZSBhc3luYyBfdmVyaWZ5PFQgZXh0ZW5kcyAnY3JlYXRlJyB8ICdyZXF1ZXN0Jz4oXG4gICAgcGFyYW1zOiBNRkFWZXJpZnlXZWJhdXRoblBhcmFtczxUPlxuICApOiBQcm9taXNlPEF1dGhNRkFWZXJpZnlSZXNwb25zZT5cbiAgcHJpdmF0ZSBhc3luYyBfdmVyaWZ5KHBhcmFtczogTUZBVmVyaWZ5UGFyYW1zKTogUHJvbWlzZTxBdXRoTUZBVmVyaWZ5UmVzcG9uc2U+IHtcbiAgICBjb25zdCBydW4gPSBhc3luYyAoKTogUHJvbWlzZTxBdXRoTUZBVmVyaWZ5UmVzcG9uc2U+ID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgICBjb25zdCB7IGRhdGE6IHNlc3Npb25EYXRhLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0gPSByZXN1bHRcbiAgICAgICAgICBpZiAoc2Vzc2lvbkVycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IHNlc3Npb25FcnJvciB9KVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IGJvZHk6IFN0cmljdE9taXQ8XG4gICAgICAgICAgICB8IEV4Y2x1ZGU8TUZBVmVyaWZ5UGFyYW1zLCBNRkFWZXJpZnlXZWJhdXRoblBhcmFtcz5cbiAgICAgICAgICAgIC8qKiBFeGNsdWRlIG91dCB0aGUgd2ViYXV0aG4gcGFyYW1zIGZyb20gaGVyZSBiZWNhdXNlIHdlJ3JlIGdvaW5nIHRvIG5lZWQgdG8gc2VyaWFsaXplIHRoZW0gaW4gdGhlIHJlc3BvbnNlICovXG4gICAgICAgICAgICB8IFByZXR0aWZ5PFxuICAgICAgICAgICAgICAgIFN0cmljdE9taXQ8TUZBVmVyaWZ5V2ViYXV0aG5QYXJhbXMsICd3ZWJhdXRobic+ICYge1xuICAgICAgICAgICAgICAgICAgd2ViYXV0aG46IFByZXR0aWZ5PFxuICAgICAgICAgICAgICAgICAgICBTdHJpY3RPbWl0PE1GQVZlcmlmeVdlYmF1dGhuUGFyYW1GaWVsZHNbJ3dlYmF1dGhuJ10sICdjcmVkZW50aWFsX3Jlc3BvbnNlJz4gJiB7XG4gICAgICAgICAgICAgICAgICAgICAgY3JlZGVudGlhbF9yZXNwb25zZTogUHVibGljS2V5Q3JlZGVudGlhbEpTT05cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgPixcbiAgICAgICAgICAgIC8qICBFeGNsdWRlIGNoYWxsZW5nZUlkIGJlY2F1c2UgdGhlIGJhY2tlbmQgZXhwZWN0cyBzbmFrZV9jYXNlLCBhbmQgZXhjbHVkZSBmYWN0b3JJZCBzaW5jZSBpdCdzIHBhc3NlZCBpbiB0aGUgcGF0aCBwYXJhbXMgKi9cbiAgICAgICAgICAgICdjaGFsbGVuZ2VJZCcgfCAnZmFjdG9ySWQnXG4gICAgICAgICAgPiAmIHtcbiAgICAgICAgICAgIGNoYWxsZW5nZV9pZDogc3RyaW5nXG4gICAgICAgICAgfSA9IHtcbiAgICAgICAgICAgIGNoYWxsZW5nZV9pZDogcGFyYW1zLmNoYWxsZW5nZUlkLFxuICAgICAgICAgICAgLi4uKCd3ZWJhdXRobicgaW4gcGFyYW1zXG4gICAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgICAgd2ViYXV0aG46IHtcbiAgICAgICAgICAgICAgICAgICAgLi4ucGFyYW1zLndlYmF1dGhuLFxuICAgICAgICAgICAgICAgICAgICBjcmVkZW50aWFsX3Jlc3BvbnNlOlxuICAgICAgICAgICAgICAgICAgICAgIHBhcmFtcy53ZWJhdXRobi50eXBlID09PSAnY3JlYXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBzZXJpYWxpemVDcmVkZW50aWFsQ3JlYXRpb25SZXNwb25zZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXMud2ViYXV0aG4uY3JlZGVudGlhbF9yZXNwb25zZSBhcyBSZWdpc3RyYXRpb25DcmVkZW50aWFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgIDogc2VyaWFsaXplQ3JlZGVudGlhbFJlcXVlc3RSZXNwb25zZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXMud2ViYXV0aG4uY3JlZGVudGlhbF9yZXNwb25zZSBhcyBBdXRoZW50aWNhdGlvbkNyZWRlbnRpYWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA6IHsgY29kZTogcGFyYW1zLmNvZGUgfSksXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QoXG4gICAgICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgICAgYCR7dGhpcy51cmx9L2ZhY3RvcnMvJHtwYXJhbXMuZmFjdG9ySWR9L3ZlcmlmeWAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICAgICAgand0OiBzZXNzaW9uRGF0YT8uc2Vzc2lvbj8uYWNjZXNzX3Rva2VuLFxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGF3YWl0IHRoaXMuX3NhdmVTZXNzaW9uKHtcbiAgICAgICAgICAgIGV4cGlyZXNfYXQ6IE1hdGgucm91bmQoRGF0ZS5ub3coKSAvIDEwMDApICsgZGF0YS5leHBpcmVzX2luLFxuICAgICAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgICB9KVxuICAgICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeUFsbFN1YnNjcmliZXJzKCdNRkFfQ0hBTExFTkdFX1ZFUklGSUVEJywgZGF0YSlcblxuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhLCBlcnJvciB9KVxuICAgICAgICB9KVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgICB9XG4gICAgICAgIHRocm93IGVycm9yXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMubG9jayAhPSBudWxsKSB7XG4gICAgICAvLyBUT0RPKHYzKTogcmVtb3ZlIGxlZ2FjeSBsb2NrIHBhdGhcbiAgICAgIHJldHVybiB0aGlzLl9hY3F1aXJlTG9jayh0aGlzLmxvY2tBY3F1aXJlVGltZW91dCwgcnVuKVxuICAgIH1cbiAgICByZXR1cm4gcnVuKClcbiAgfVxuXG4gIC8qKlxuICAgKiB7QHNlZSBHb1RydWVNRkFBcGkjY2hhbGxlbmdlfVxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfY2hhbGxlbmdlKFxuICAgIHBhcmFtczogTUZBQ2hhbGxlbmdlVE9UUFBhcmFtc1xuICApOiBQcm9taXNlPFByZXR0aWZ5PEF1dGhNRkFDaGFsbGVuZ2VUT1RQUmVzcG9uc2U+PlxuICBwcml2YXRlIGFzeW5jIF9jaGFsbGVuZ2UoXG4gICAgcGFyYW1zOiBNRkFDaGFsbGVuZ2VQaG9uZVBhcmFtc1xuICApOiBQcm9taXNlPFByZXR0aWZ5PEF1dGhNRkFDaGFsbGVuZ2VQaG9uZVJlc3BvbnNlPj5cbiAgcHJpdmF0ZSBhc3luYyBfY2hhbGxlbmdlKFxuICAgIHBhcmFtczogTUZBQ2hhbGxlbmdlV2ViYXV0aG5QYXJhbXNcbiAgKTogUHJvbWlzZTxQcmV0dGlmeTxBdXRoTUZBQ2hhbGxlbmdlV2ViYXV0aG5SZXNwb25zZT4+XG4gIHByaXZhdGUgYXN5bmMgX2NoYWxsZW5nZShwYXJhbXM6IE1GQUNoYWxsZW5nZVBhcmFtcyk6IFByb21pc2U8QXV0aE1GQUNoYWxsZW5nZVJlc3BvbnNlPiB7XG4gICAgY29uc3QgcnVuID0gYXN5bmMgKCk6IFByb21pc2U8QXV0aE1GQUNoYWxsZW5nZVJlc3BvbnNlPiA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBzZXNzaW9uRGF0YSwgZXJyb3I6IHNlc3Npb25FcnJvciB9ID0gcmVzdWx0XG4gICAgICAgICAgaWYgKHNlc3Npb25FcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yOiBzZXNzaW9uRXJyb3IgfSlcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCByZXNwb25zZSA9IChhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgICBgJHt0aGlzLnVybH0vZmFjdG9ycy8ke3BhcmFtcy5mYWN0b3JJZH0vY2hhbGxlbmdlYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgYm9keTogcGFyYW1zLFxuICAgICAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgICAgIGp3dDogc2Vzc2lvbkRhdGE/LnNlc3Npb24/LmFjY2Vzc190b2tlbixcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApKSBhc1xuICAgICAgICAgICAgfCBFeGNsdWRlPEF1dGhNRkFDaGFsbGVuZ2VSZXNwb25zZSwgQXV0aE1GQUNoYWxsZW5nZVdlYmF1dGhuUmVzcG9uc2U+XG4gICAgICAgICAgICAvKiogVGhlIHNlcnZlciB3aWxsIHNlbmQgYHNlcmlhbGl6ZWRgIGRhdGEsIHNvIHdlIGFzc2VydCB0aGUgc2VyaWFsaXplZCByZXNwb25zZSAqL1xuICAgICAgICAgICAgfCBBdXRoTUZBQ2hhbGxlbmdlV2ViYXV0aG5TZXJ2ZXJSZXNwb25zZVxuXG4gICAgICAgICAgaWYgKHJlc3BvbnNlLmVycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCB7IGRhdGEgfSA9IHJlc3BvbnNlXG5cbiAgICAgICAgICBpZiAoZGF0YS50eXBlICE9PSAnd2ViYXV0aG4nKSB7XG4gICAgICAgICAgICByZXR1cm4geyBkYXRhLCBlcnJvcjogbnVsbCB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgc3dpdGNoIChkYXRhLndlYmF1dGhuLnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ2NyZWF0ZSc6XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgICAgICAgICAgIHdlYmF1dGhuOiB7XG4gICAgICAgICAgICAgICAgICAgIC4uLmRhdGEud2ViYXV0aG4sXG4gICAgICAgICAgICAgICAgICAgIGNyZWRlbnRpYWxfb3B0aW9uczoge1xuICAgICAgICAgICAgICAgICAgICAgIC4uLmRhdGEud2ViYXV0aG4uY3JlZGVudGlhbF9vcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgIHB1YmxpY0tleTogZGVzZXJpYWxpemVDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zKFxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS53ZWJhdXRobi5jcmVkZW50aWFsX29wdGlvbnMucHVibGljS2V5XG4gICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAncmVxdWVzdCc6XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgICAgICAgICAgIHdlYmF1dGhuOiB7XG4gICAgICAgICAgICAgICAgICAgIC4uLmRhdGEud2ViYXV0aG4sXG4gICAgICAgICAgICAgICAgICAgIGNyZWRlbnRpYWxfb3B0aW9uczoge1xuICAgICAgICAgICAgICAgICAgICAgIC4uLmRhdGEud2ViYXV0aG4uY3JlZGVudGlhbF9vcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgIHB1YmxpY0tleTogZGVzZXJpYWxpemVDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnMoXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhLndlYmF1dGhuLmNyZWRlbnRpYWxfb3B0aW9ucy5wdWJsaWNLZXlcbiAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgICB9XG4gICAgICAgIHRocm93IGVycm9yXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMubG9jayAhPSBudWxsKSB7XG4gICAgICAvLyBUT0RPKHYzKTogcmVtb3ZlIGxlZ2FjeSBsb2NrIHBhdGhcbiAgICAgIHJldHVybiB0aGlzLl9hY3F1aXJlTG9jayh0aGlzLmxvY2tBY3F1aXJlVGltZW91dCwgcnVuKVxuICAgIH1cbiAgICByZXR1cm4gcnVuKClcbiAgfVxuXG4gIC8qKlxuICAgKiB7QHNlZSBHb1RydWVNRkFBcGkjY2hhbGxlbmdlQW5kVmVyaWZ5fVxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfY2hhbGxlbmdlQW5kVmVyaWZ5KFxuICAgIHBhcmFtczogTUZBQ2hhbGxlbmdlQW5kVmVyaWZ5UGFyYW1zXG4gICk6IFByb21pc2U8QXV0aE1GQVZlcmlmeVJlc3BvbnNlPiB7XG4gICAgY29uc3QgeyBkYXRhOiBjaGFsbGVuZ2VEYXRhLCBlcnJvcjogY2hhbGxlbmdlRXJyb3IgfSA9IGF3YWl0IHRoaXMuX2NoYWxsZW5nZSh7XG4gICAgICBmYWN0b3JJZDogcGFyYW1zLmZhY3RvcklkLFxuICAgIH0pXG4gICAgaWYgKGNoYWxsZW5nZUVycm9yKSB7XG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IGNoYWxsZW5nZUVycm9yIH0pXG4gICAgfVxuXG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuX3ZlcmlmeSh7XG4gICAgICBmYWN0b3JJZDogcGFyYW1zLmZhY3RvcklkLFxuICAgICAgY2hhbGxlbmdlSWQ6IGNoYWxsZW5nZURhdGEuaWQsXG4gICAgICBjb2RlOiBwYXJhbXMuY29kZSxcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIHtAc2VlIEdvVHJ1ZU1GQUFwaSNsaXN0RmFjdG9yc31cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX2xpc3RGYWN0b3JzKCk6IFByb21pc2U8QXV0aE1GQUxpc3RGYWN0b3JzUmVzcG9uc2U+IHtcbiAgICBjb25zdCB7XG4gICAgICBkYXRhOiB7IHVzZXIgfSxcbiAgICAgIGVycm9yOiB1c2VyRXJyb3IsXG4gICAgfSA9IGF3YWl0IHRoaXMuZ2V0VXNlcigpXG4gICAgaWYgKHVzZXJFcnJvcikge1xuICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3I6IHVzZXJFcnJvciB9XG4gICAgfVxuXG4gICAgY29uc3QgZGF0YTogQXV0aE1GQUxpc3RGYWN0b3JzUmVzcG9uc2VbJ2RhdGEnXSA9IHtcbiAgICAgIGFsbDogW10sXG4gICAgICBwaG9uZTogW10sXG4gICAgICB0b3RwOiBbXSxcbiAgICAgIHdlYmF1dGhuOiBbXSxcbiAgICB9XG5cbiAgICAvLyBsb29wIG92ZXIgdGhlIGZhY3RvcnMgT05DRVxuICAgIGZvciAoY29uc3QgZmFjdG9yIG9mIHVzZXI/LmZhY3RvcnMgPz8gW10pIHtcbiAgICAgIGRhdGEuYWxsLnB1c2goZmFjdG9yKVxuICAgICAgaWYgKGZhY3Rvci5zdGF0dXMgPT09ICd2ZXJpZmllZCcpIHtcbiAgICAgICAgOyhkYXRhW2ZhY3Rvci5mYWN0b3JfdHlwZV0gYXMgKHR5cGVvZiBmYWN0b3IpW10pLnB1c2goZmFjdG9yKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBkYXRhLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIHtAc2VlIEdvVHJ1ZU1GQUFwaSNnZXRBdXRoZW50aWNhdG9yQXNzdXJhbmNlTGV2ZWx9XG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9nZXRBdXRoZW50aWNhdG9yQXNzdXJhbmNlTGV2ZWwoXG4gICAgand0Pzogc3RyaW5nXG4gICk6IFByb21pc2U8QXV0aE1GQUdldEF1dGhlbnRpY2F0b3JBc3N1cmFuY2VMZXZlbFJlc3BvbnNlPiB7XG4gICAgaWYgKGp3dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyBwYXlsb2FkIH0gPSBkZWNvZGVKV1Qoand0KVxuXG4gICAgICAgIGxldCBjdXJyZW50TGV2ZWw6IEF1dGhlbnRpY2F0b3JBc3N1cmFuY2VMZXZlbHMgfCBudWxsID0gbnVsbFxuICAgICAgICBpZiAocGF5bG9hZC5hYWwpIHtcbiAgICAgICAgICBjdXJyZW50TGV2ZWwgPSBwYXlsb2FkLmFhbFxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IG5leHRMZXZlbDogQXV0aGVudGljYXRvckFzc3VyYW5jZUxldmVscyB8IG51bGwgPSBjdXJyZW50TGV2ZWxcblxuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgZGF0YTogeyB1c2VyIH0sXG4gICAgICAgICAgZXJyb3I6IHVzZXJFcnJvcixcbiAgICAgICAgfSA9IGF3YWl0IHRoaXMuZ2V0VXNlcihqd3QpXG5cbiAgICAgICAgaWYgKHVzZXJFcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogdXNlckVycm9yIH0pXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB2ZXJpZmllZEZhY3RvcnMgPVxuICAgICAgICAgIHVzZXI/LmZhY3RvcnM/LmZpbHRlcigoZmFjdG9yOiBGYWN0b3IpID0+IGZhY3Rvci5zdGF0dXMgPT09ICd2ZXJpZmllZCcpID8/IFtdXG5cbiAgICAgICAgaWYgKHZlcmlmaWVkRmFjdG9ycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgbmV4dExldmVsID0gJ2FhbDInXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBjdXJyZW50QXV0aGVudGljYXRpb25NZXRob2RzID0gcGF5bG9hZC5hbXIgfHwgW11cblxuICAgICAgICByZXR1cm4geyBkYXRhOiB7IGN1cnJlbnRMZXZlbCwgbmV4dExldmVsLCBjdXJyZW50QXV0aGVudGljYXRpb25NZXRob2RzIH0sIGVycm9yOiBudWxsIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBlcnJvclxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHtcbiAgICAgIGRhdGE6IHsgc2Vzc2lvbiB9LFxuICAgICAgZXJyb3I6IHNlc3Npb25FcnJvcixcbiAgICB9ID0gYXdhaXQgdGhpcy5nZXRTZXNzaW9uKClcblxuICAgIGlmIChzZXNzaW9uRXJyb3IpIHtcbiAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0pXG4gICAgfVxuICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZGF0YTogeyBjdXJyZW50TGV2ZWw6IG51bGwsIG5leHRMZXZlbDogbnVsbCwgY3VycmVudEF1dGhlbnRpY2F0aW9uTWV0aG9kczogW10gfSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgeyBwYXlsb2FkIH0gPSBkZWNvZGVKV1Qoc2Vzc2lvbi5hY2Nlc3NfdG9rZW4pXG5cbiAgICBsZXQgY3VycmVudExldmVsOiBBdXRoZW50aWNhdG9yQXNzdXJhbmNlTGV2ZWxzIHwgbnVsbCA9IG51bGxcblxuICAgIGlmIChwYXlsb2FkLmFhbCkge1xuICAgICAgY3VycmVudExldmVsID0gcGF5bG9hZC5hYWxcbiAgICB9XG5cbiAgICBsZXQgbmV4dExldmVsOiBBdXRoZW50aWNhdG9yQXNzdXJhbmNlTGV2ZWxzIHwgbnVsbCA9IGN1cnJlbnRMZXZlbFxuXG4gICAgY29uc3QgdmVyaWZpZWRGYWN0b3JzID1cbiAgICAgIHNlc3Npb24udXNlci5mYWN0b3JzPy5maWx0ZXIoKGZhY3RvcjogRmFjdG9yKSA9PiBmYWN0b3Iuc3RhdHVzID09PSAndmVyaWZpZWQnKSA/PyBbXVxuXG4gICAgaWYgKHZlcmlmaWVkRmFjdG9ycy5sZW5ndGggPiAwKSB7XG4gICAgICBuZXh0TGV2ZWwgPSAnYWFsMidcbiAgICB9XG5cbiAgICBjb25zdCBjdXJyZW50QXV0aGVudGljYXRpb25NZXRob2RzID0gcGF5bG9hZC5hbXIgfHwgW11cblxuICAgIHJldHVybiB7IGRhdGE6IHsgY3VycmVudExldmVsLCBuZXh0TGV2ZWwsIGN1cnJlbnRBdXRoZW50aWNhdGlvbk1ldGhvZHMgfSwgZXJyb3I6IG51bGwgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyBkZXRhaWxzIGFib3V0IGFuIE9BdXRoIGF1dGhvcml6YXRpb24gcmVxdWVzdC5cbiAgICogT25seSByZWxldmFudCB3aGVuIHRoZSBPQXV0aCAyLjEgc2VydmVyIGlzIGVuYWJsZWQgaW4gU3VwYWJhc2UgQXV0aC5cbiAgICpcbiAgICogUmV0dXJucyBhdXRob3JpemF0aW9uIGRldGFpbHMgaW5jbHVkaW5nIGNsaWVudCBpbmZvLCBzY29wZXMsIGFuZCB1c2VyIGluZm9ybWF0aW9uLlxuICAgKiBJZiB0aGUgcmVzcG9uc2UgaW5jbHVkZXMgb25seSBhIHJlZGlyZWN0X3VybCBmaWVsZCwgaXQgbWVhbnMgY29uc2VudCB3YXMgYWxyZWFkeSBnaXZlbiAtIHRoZSBjYWxsZXJcbiAgICogc2hvdWxkIGhhbmRsZSB0aGUgcmVkaXJlY3QgbWFudWFsbHkgaWYgbmVlZGVkLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZ2V0QXV0aG9yaXphdGlvbkRldGFpbHMoXG4gICAgYXV0aG9yaXphdGlvbklkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxBdXRoT0F1dGhBdXRob3JpemF0aW9uRGV0YWlsc1Jlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGRhdGE6IHsgc2Vzc2lvbiB9LFxuICAgICAgICAgIGVycm9yOiBzZXNzaW9uRXJyb3IsXG4gICAgICAgIH0gPSByZXN1bHRcblxuICAgICAgICBpZiAoc2Vzc2lvbkVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yOiBzZXNzaW9uRXJyb3IgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogbmV3IEF1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKCkgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAgICdHRVQnLFxuICAgICAgICAgIGAke3RoaXMudXJsfS9vYXV0aC9hdXRob3JpemF0aW9ucy8ke2F1dGhvcml6YXRpb25JZH1gLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICAgIGp3dDogc2Vzc2lvbi5hY2Nlc3NfdG9rZW4sXG4gICAgICAgICAgICB4Zm9ybTogKGRhdGE6IGFueSkgPT4gKHsgZGF0YSwgZXJyb3I6IG51bGwgfSksXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBcHByb3ZlcyBhbiBPQXV0aCBhdXRob3JpemF0aW9uIHJlcXVlc3QuXG4gICAqIE9ubHkgcmVsZXZhbnQgd2hlbiB0aGUgT0F1dGggMi4xIHNlcnZlciBpcyBlbmFibGVkIGluIFN1cGFiYXNlIEF1dGguXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9hcHByb3ZlQXV0aG9yaXphdGlvbihcbiAgICBhdXRob3JpemF0aW9uSWQ6IHN0cmluZyxcbiAgICBvcHRpb25zPzogeyBza2lwQnJvd3NlclJlZGlyZWN0PzogYm9vbGVhbiB9XG4gICk6IFByb21pc2U8QXV0aE9BdXRoQ29uc2VudFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGRhdGE6IHsgc2Vzc2lvbiB9LFxuICAgICAgICAgIGVycm9yOiBzZXNzaW9uRXJyb3IsXG4gICAgICAgIH0gPSByZXN1bHRcblxuICAgICAgICBpZiAoc2Vzc2lvbkVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yOiBzZXNzaW9uRXJyb3IgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogbmV3IEF1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKCkgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgX3JlcXVlc3QoXG4gICAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYCR7dGhpcy51cmx9L29hdXRoL2F1dGhvcml6YXRpb25zLyR7YXV0aG9yaXphdGlvbklkfS9jb25zZW50YCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgICBqd3Q6IHNlc3Npb24uYWNjZXNzX3Rva2VuLFxuICAgICAgICAgICAgYm9keTogeyBhY3Rpb246ICdhcHByb3ZlJyB9LFxuICAgICAgICAgICAgeGZvcm06IChkYXRhOiBhbnkpID0+ICh7IGRhdGEsIGVycm9yOiBudWxsIH0pLFxuICAgICAgICAgIH1cbiAgICAgICAgKVxuXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEucmVkaXJlY3RfdXJsKSB7XG4gICAgICAgICAgLy8gQXV0b21hdGljYWxseSByZWRpcmVjdCBpbiBicm93c2VyIHVubGVzcyBza2lwQnJvd3NlclJlZGlyZWN0IGlzIHRydWVcbiAgICAgICAgICBpZiAoaXNCcm93c2VyKCkgJiYgIW9wdGlvbnM/LnNraXBCcm93c2VyUmVkaXJlY3QpIHtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5hc3NpZ24ocmVzcG9uc2UuZGF0YS5yZWRpcmVjdF91cmwpXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBEZW5pZXMgYW4gT0F1dGggYXV0aG9yaXphdGlvbiByZXF1ZXN0LlxuICAgKiBPbmx5IHJlbGV2YW50IHdoZW4gdGhlIE9BdXRoIDIuMSBzZXJ2ZXIgaXMgZW5hYmxlZCBpbiBTdXBhYmFzZSBBdXRoLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZGVueUF1dGhvcml6YXRpb24oXG4gICAgYXV0aG9yaXphdGlvbklkOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHsgc2tpcEJyb3dzZXJSZWRpcmVjdD86IGJvb2xlYW4gfVxuICApOiBQcm9taXNlPEF1dGhPQXV0aENvbnNlbnRSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBkYXRhOiB7IHNlc3Npb24gfSxcbiAgICAgICAgICBlcnJvcjogc2Vzc2lvbkVycm9yLFxuICAgICAgICB9ID0gcmVzdWx0XG5cbiAgICAgICAgaWYgKHNlc3Npb25FcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0pXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IG5ldyBBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcigpIH0pXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IF9yZXF1ZXN0KFxuICAgICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgIGAke3RoaXMudXJsfS9vYXV0aC9hdXRob3JpemF0aW9ucy8ke2F1dGhvcml6YXRpb25JZH0vY29uc2VudGAsXG4gICAgICAgICAge1xuICAgICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgICAgand0OiBzZXNzaW9uLmFjY2Vzc190b2tlbixcbiAgICAgICAgICAgIGJvZHk6IHsgYWN0aW9uOiAnZGVueScgfSxcbiAgICAgICAgICAgIHhmb3JtOiAoZGF0YTogYW55KSA9PiAoeyBkYXRhLCBlcnJvcjogbnVsbCB9KSxcbiAgICAgICAgICB9XG4gICAgICAgIClcblxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLnJlZGlyZWN0X3VybCkge1xuICAgICAgICAgIC8vIEF1dG9tYXRpY2FsbHkgcmVkaXJlY3QgaW4gYnJvd3NlciB1bmxlc3Mgc2tpcEJyb3dzZXJSZWRpcmVjdCBpcyB0cnVlXG4gICAgICAgICAgaWYgKGlzQnJvd3NlcigpICYmICFvcHRpb25zPy5za2lwQnJvd3NlclJlZGlyZWN0KSB7XG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uYXNzaWduKHJlc3BvbnNlLmRhdGEucmVkaXJlY3RfdXJsKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXNwb25zZVxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogTGlzdHMgYWxsIE9BdXRoIGdyYW50cyB0aGF0IHRoZSBhdXRoZW50aWNhdGVkIHVzZXIgaGFzIGF1dGhvcml6ZWQuXG4gICAqIE9ubHkgcmVsZXZhbnQgd2hlbiB0aGUgT0F1dGggMi4xIHNlcnZlciBpcyBlbmFibGVkIGluIFN1cGFiYXNlIEF1dGguXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9saXN0T0F1dGhHcmFudHMoKTogUHJvbWlzZTxBdXRoT0F1dGhHcmFudHNSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBkYXRhOiB7IHNlc3Npb24gfSxcbiAgICAgICAgICBlcnJvcjogc2Vzc2lvbkVycm9yLFxuICAgICAgICB9ID0gcmVzdWx0XG5cbiAgICAgICAgaWYgKHNlc3Npb25FcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0pXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IG5ldyBBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcigpIH0pXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ0dFVCcsIGAke3RoaXMudXJsfS91c2VyL29hdXRoL2dyYW50c2AsIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgand0OiBzZXNzaW9uLmFjY2Vzc190b2tlbixcbiAgICAgICAgICB4Zm9ybTogKGRhdGE6IGFueSkgPT4gKHsgZGF0YSwgZXJyb3I6IG51bGwgfSksXG4gICAgICAgIH0pXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXZva2VzIGEgdXNlcidzIE9BdXRoIGdyYW50IGZvciBhIHNwZWNpZmljIGNsaWVudC5cbiAgICogT25seSByZWxldmFudCB3aGVuIHRoZSBPQXV0aCAyLjEgc2VydmVyIGlzIGVuYWJsZWQgaW4gU3VwYWJhc2UgQXV0aC5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3Jldm9rZU9BdXRoR3JhbnQob3B0aW9uczoge1xuICAgIGNsaWVudElkOiBzdHJpbmdcbiAgfSk6IFByb21pc2U8QXV0aE9BdXRoUmV2b2tlR3JhbnRSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBkYXRhOiB7IHNlc3Npb24gfSxcbiAgICAgICAgICBlcnJvcjogc2Vzc2lvbkVycm9yLFxuICAgICAgICB9ID0gcmVzdWx0XG5cbiAgICAgICAgaWYgKHNlc3Npb25FcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0pXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IG5ldyBBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcigpIH0pXG4gICAgICAgIH1cblxuICAgICAgICBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnREVMRVRFJywgYCR7dGhpcy51cmx9L3VzZXIvb2F1dGgvZ3JhbnRzYCwge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBqd3Q6IHNlc3Npb24uYWNjZXNzX3Rva2VuLFxuICAgICAgICAgIHF1ZXJ5OiB7IGNsaWVudF9pZDogb3B0aW9ucy5jbGllbnRJZCB9LFxuICAgICAgICAgIG5vUmVzb2x2ZUpzb246IHRydWUsXG4gICAgICAgIH0pXG4gICAgICAgIHJldHVybiB7IGRhdGE6IHt9LCBlcnJvcjogbnVsbCB9XG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmV0Y2hKd2soa2lkOiBzdHJpbmcsIGp3a3M6IHsga2V5czogSldLW10gfSA9IHsga2V5czogW10gfSk6IFByb21pc2U8SldLIHwgbnVsbD4ge1xuICAgIC8vIHRyeSBmZXRjaGluZyBmcm9tIHRoZSBzdXBwbGllZCBqd2tzXG4gICAgbGV0IGp3ayA9IGp3a3Mua2V5cy5maW5kKChrZXkpID0+IGtleS5raWQgPT09IGtpZClcbiAgICBpZiAoandrKSB7XG4gICAgICByZXR1cm4gandrXG4gICAgfVxuXG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKVxuXG4gICAgLy8gdHJ5IGZldGNoaW5nIGZyb20gY2FjaGVcbiAgICBqd2sgPSB0aGlzLmp3a3Mua2V5cy5maW5kKChrZXkpID0+IGtleS5raWQgPT09IGtpZClcblxuICAgIC8vIGp3ayBleGlzdHMgYW5kIGp3a3MgaXNuJ3Qgc3RhbGVcbiAgICBpZiAoandrICYmIHRoaXMuandrc19jYWNoZWRfYXQgKyBKV0tTX1RUTCA+IG5vdykge1xuICAgICAgcmV0dXJuIGp3a1xuICAgIH1cbiAgICAvLyBqd2sgaXNuJ3QgY2FjaGVkIGluIG1lbW9yeSBzbyB3ZSBuZWVkIHRvIGZldGNoIGl0IGZyb20gdGhlIHdlbGwta25vd24gZW5kcG9pbnRcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnR0VUJywgYCR7dGhpcy51cmx9Ly53ZWxsLWtub3duL2p3a3MuanNvbmAsIHtcbiAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICB9KVxuICAgIGlmIChlcnJvcikge1xuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gICAgaWYgKCFkYXRhLmtleXMgfHwgZGF0YS5rZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICB0aGlzLmp3a3MgPSBkYXRhXG4gICAgdGhpcy5qd2tzX2NhY2hlZF9hdCA9IG5vd1xuXG4gICAgLy8gRmluZCB0aGUgc2lnbmluZyBrZXlcbiAgICBqd2sgPSBkYXRhLmtleXMuZmluZCgoa2V5OiBhbnkpID0+IGtleS5raWQgPT09IGtpZClcbiAgICBpZiAoIWp3aykge1xuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gICAgcmV0dXJuIGp3a1xuICB9XG5cbiAgLyoqXG4gICAqIEV4dHJhY3RzIHRoZSBKV1QgY2xhaW1zIHByZXNlbnQgaW4gdGhlIGFjY2VzcyB0b2tlbiBieSBmaXJzdCB2ZXJpZnlpbmcgdGhlXG4gICAqIEpXVCBhZ2FpbnN0IHRoZSBzZXJ2ZXIncyBKU09OIFdlYiBLZXkgU2V0IGVuZHBvaW50XG4gICAqIGAvLndlbGwta25vd24vandrcy5qc29uYCB3aGljaCBpcyBvZnRlbiBjYWNoZWQsIHJlc3VsdGluZyBpbiBzaWduaWZpY2FudGx5XG4gICAqIGZhc3RlciByZXNwb25zZXMuIFByZWZlciB0aGlzIG1ldGhvZCBvdmVyIHtAbGluayAjZ2V0VXNlcn0gd2hpY2ggYWx3YXlzXG4gICAqIHNlbmRzIGEgcmVxdWVzdCB0byB0aGUgQXV0aCBzZXJ2ZXIgZm9yIGVhY2ggSldULlxuICAgKlxuICAgKiBJZiB0aGUgcHJvamVjdCBpcyBub3QgdXNpbmcgYW4gYXN5bW1ldHJpYyBKV1Qgc2lnbmluZyBrZXkgKGxpa2UgRUNDIG9yXG4gICAqIFJTQSkgaXQgYWx3YXlzIHNlbmRzIGEgcmVxdWVzdCB0byB0aGUgQXV0aCBzZXJ2ZXIgKHNpbWlsYXIgdG8ge0BsaW5rXG4gICAqICNnZXRVc2VyfSkgdG8gdmVyaWZ5IHRoZSBKV1QuXG4gICAqXG4gICAqIEBwYXJhbSBqd3QgQW4gb3B0aW9uYWwgc3BlY2lmaWMgSldUIHlvdSB3aXNoIHRvIHZlcmlmeSwgbm90IHRoZSBvbmUgeW91XG4gICAqICAgICAgICAgICAgY2FuIG9idGFpbiBmcm9tIHtAbGluayAjZ2V0U2Vzc2lvbn0uXG4gICAqIEBwYXJhbSBvcHRpb25zIFZhcmlvdXMgYWRkaXRpb25hbCBvcHRpb25zIHRoYXQgYWxsb3cgeW91IHRvIGN1c3RvbWl6ZSB0aGVcbiAgICogICAgICAgICAgICAgICAgYmVoYXZpb3Igb2YgdGhpcyBtZXRob2QuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUGFyc2VzIHRoZSB1c2VyJ3MgW2FjY2VzcyB0b2tlbl0oL2RvY3MvZ3VpZGVzL2F1dGgvc2Vzc2lvbnMjYWNjZXNzLXRva2VuLWp3dC1jbGFpbXMpIGFzIGEgW0pTT04gV2ViIFRva2VuIChKV1QpXSgvZG9jcy9ndWlkZXMvYXV0aC9qd3RzKSBhbmQgcmV0dXJucyBpdHMgY29tcG9uZW50cyBpZiB2YWxpZCBhbmQgbm90IGV4cGlyZWQuXG4gICAqIC0gSWYgeW91ciBwcm9qZWN0IGlzIHVzaW5nIGFzeW1tZXRyaWMgSldUIHNpZ25pbmcga2V5cywgdGhlbiB0aGUgdmVyaWZpY2F0aW9uIGlzIGRvbmUgbG9jYWxseSB1c3VhbGx5IHdpdGhvdXQgYSBuZXR3b3JrIHJlcXVlc3QgdXNpbmcgdGhlIFtXZWJDcnlwdG8gQVBJXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvV2ViX0NyeXB0b19BUEkpLlxuICAgKiAtIEEgbmV0d29yayByZXF1ZXN0IGlzIHNlbnQgdG8geW91ciBwcm9qZWN0J3MgSldUIHNpZ25pbmcga2V5IGRpc2NvdmVyeSBlbmRwb2ludCBgaHR0cHM6Ly9wcm9qZWN0LWlkLnN1cGFiYXNlLmNvL2F1dGgvdjEvLndlbGwta25vd24vandrcy5qc29uYCwgd2hpY2ggaXMgY2FjaGVkIGxvY2FsbHkuIElmIHlvdXIgZW52aXJvbm1lbnQgaXMgZXBoZW1lcmFsLCBzdWNoIGFzIGEgTGFtYmRhIGZ1bmN0aW9uIHRoYXQgaXMgZGVzdHJveWVkIGFmdGVyIGV2ZXJ5IHJlcXVlc3QsIGEgbmV0d29yayByZXF1ZXN0IHdpbGwgYmUgc2VudCBmb3IgZWFjaCBuZXcgaW52b2NhdGlvbi4gU3VwYWJhc2UgcHJvdmlkZXMgYSBuZXR3b3JrLWVkZ2UgY2FjaGUgcHJvdmlkaW5nIGZhc3QgcmVzcG9uc2VzIGZvciB0aGVzZSBzaXR1YXRpb25zLlxuICAgKiAtIElmIHRoZSB1c2VyJ3MgYWNjZXNzIHRva2VuIGlzIGFib3V0IHRvIGV4cGlyZSB3aGVuIGNhbGxpbmcgdGhpcyBmdW5jdGlvbiwgdGhlIHVzZXIncyBzZXNzaW9uIHdpbGwgZmlyc3QgYmUgcmVmcmVzaGVkIGJlZm9yZSB2YWxpZGF0aW5nIHRoZSBKV1QuXG4gICAqIC0gSWYgeW91ciBwcm9qZWN0IGlzIHVzaW5nIGEgc3ltbWV0cmljIHNlY3JldCB0byBzaWduIHRoZSBKV1QsIGl0IGFsd2F5cyBzZW5kcyBhIHJlcXVlc3Qgc2ltaWxhciB0byBgZ2V0VXNlcigpYCB0byB2YWxpZGF0ZSB0aGUgSldUIGF0IHRoZSBzZXJ2ZXIgYmVmb3JlIHJldHVybmluZyB0aGUgZGVjb2RlZCB0b2tlbi4gVGhpcyBpcyBhbHNvIHVzZWQgaWYgdGhlIFdlYkNyeXB0byBBUEkgaXMgbm90IGF2YWlsYWJsZSBpbiB0aGUgZW52aXJvbm1lbnQuIE1ha2Ugc3VyZSB5b3UgcG9seWZpbGwgaXQgaW4gc3VjaCBzaXR1YXRpb25zLlxuICAgKiAtIFRoZSByZXR1cm5lZCBjbGFpbXMgY2FuIGJlIGN1c3RvbWl6ZWQgcGVyIHByb2plY3QgdXNpbmcgdGhlIFtDdXN0b20gQWNjZXNzIFRva2VuIEhvb2tdKC9kb2NzL2d1aWRlcy9hdXRoL2F1dGgtaG9va3MvY3VzdG9tLWFjY2Vzcy10b2tlbi1ob29rKS5cbiAgICpcbiAgICogQGV4YW1wbGUgR2V0IEpXVCBjbGFpbXMsIGhlYWRlciBhbmQgc2lnbmF0dXJlXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0Q2xhaW1zKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgR2V0IEpXVCBjbGFpbXMsIGhlYWRlciBhbmQgc2lnbmF0dXJlXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcImNsYWltc1wiOiB7XG4gICAqICAgICAgIFwiYWFsXCI6IFwiYWFsMVwiLFxuICAgKiAgICAgICBcImFtclwiOiBbe1xuICAgKiAgICAgICAgIFwibWV0aG9kXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICBcInRpbWVzdGFtcFwiOiAxNzE1NzY2MDAwXG4gICAqICAgICAgIH1dLFxuICAgKiAgICAgICBcImFwcF9tZXRhZGF0YVwiOiB7fSxcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICBcImV4cFwiOiAxNzE1NzY5NjAwLFxuICAgKiAgICAgICBcImlhdFwiOiAxNzE1NzY2MDAwLFxuICAgKiAgICAgICBcImlzX2Fub255bW91c1wiOiBmYWxzZSxcbiAgICogICAgICAgXCJpc3NcIjogXCJodHRwczovL3Byb2plY3QtaWQuc3VwYWJhc2UuY28vYXV0aC92MVwiLFxuICAgKiAgICAgICBcInBob25lXCI6IFwiKzEzMzM0NDQ1NTU1XCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJzZXNzaW9uX2lkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7fVxuICAgKiAgICAgfSxcbiAgICogICAgIFwiaGVhZGVyXCI6IHtcbiAgICogICAgICAgXCJhbGdcIjogXCJSUzI1NlwiLFxuICAgKiAgICAgICBcInR5cFwiOiBcIkpXVFwiLFxuICAgKiAgICAgICBcImtpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzaWduYXR1cmVcIjogWy8qKiBVaW50OEFycmF5ICpcXC9dLFxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBnZXRDbGFpbXMoXG4gICAgand0Pzogc3RyaW5nLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIC8qKlxuICAgICAgICogQGRlcHJlY2F0ZWQgUGxlYXNlIHVzZSBvcHRpb25zLmp3a3MgaW5zdGVhZC5cbiAgICAgICAqL1xuICAgICAga2V5cz86IEpXS1tdXG5cbiAgICAgIC8qKiBJZiBzZXQgdG8gYHRydWVgIHRoZSBgZXhwYCBjbGFpbSB3aWxsIG5vdCBiZSB2YWxpZGF0ZWQgYWdhaW5zdCB0aGUgY3VycmVudCB0aW1lLiAqL1xuICAgICAgYWxsb3dFeHBpcmVkPzogYm9vbGVhblxuXG4gICAgICAvKiogSWYgc2V0LCB0aGlzIEpTT04gV2ViIEtleSBTZXQgaXMgZ29pbmcgdG8gaGF2ZSBwcmVjZWRlbmNlIG92ZXIgdGhlIGNhY2hlZCB2YWx1ZSBhdmFpbGFibGUgb24gdGhlIHNlcnZlci4gKi9cbiAgICAgIGp3a3M/OiB7IGtleXM6IEpXS1tdIH1cbiAgICB9ID0ge31cbiAgKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogeyBjbGFpbXM6IEp3dFBheWxvYWQ7IGhlYWRlcjogSnd0SGVhZGVyOyBzaWduYXR1cmU6IFVpbnQ4QXJyYXkgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwgeyBkYXRhOiBudWxsOyBlcnJvcjogQXV0aEVycm9yIH1cbiAgICB8IHsgZGF0YTogbnVsbDsgZXJyb3I6IG51bGwgfVxuICA+IHtcbiAgICB0cnkge1xuICAgICAgbGV0IHRva2VuID0gand0XG4gICAgICBpZiAoIXRva2VuKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHRoaXMuZ2V0U2Vzc2lvbigpXG4gICAgICAgIGlmIChlcnJvciB8fCAhZGF0YS5zZXNzaW9uKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICAgIH1cbiAgICAgICAgdG9rZW4gPSBkYXRhLnNlc3Npb24uYWNjZXNzX3Rva2VuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHtcbiAgICAgICAgaGVhZGVyLFxuICAgICAgICBwYXlsb2FkLFxuICAgICAgICBzaWduYXR1cmUsXG4gICAgICAgIHJhdzogeyBoZWFkZXI6IHJhd0hlYWRlciwgcGF5bG9hZDogcmF3UGF5bG9hZCB9LFxuICAgICAgfSA9IGRlY29kZUpXVCh0b2tlbilcblxuICAgICAgaWYgKCFvcHRpb25zPy5hbGxvd0V4cGlyZWQpIHtcbiAgICAgICAgLy8gUmVqZWN0IGV4cGlyZWQgSldUcyBzaG91bGQgb25seSBoYXBwZW4gaWYgand0IGFyZ3VtZW50IHdhcyBwYXNzZWQuXG4gICAgICAgIC8vIFJldGhyb3cgYXMgQXV0aEludmFsaWRKd3RFcnJvciBzbyB0aGUgb3V0ZXIgY2F0Y2ggY29udmVydHMgaXQgdG8geyBkYXRhLCBlcnJvciB9LlxuICAgICAgICB0cnkge1xuICAgICAgICAgIHZhbGlkYXRlRXhwKHBheWxvYWQuZXhwKVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEF1dGhJbnZhbGlkSnd0RXJyb3IoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogJ0pXVCB2YWxpZGF0aW9uIGZhaWxlZCcpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3Qgc2lnbmluZ0tleSA9XG4gICAgICAgICFoZWFkZXIuYWxnIHx8XG4gICAgICAgIGhlYWRlci5hbGcuc3RhcnRzV2l0aCgnSFMnKSB8fFxuICAgICAgICAhaGVhZGVyLmtpZCB8fFxuICAgICAgICAhKCdjcnlwdG8nIGluIGdsb2JhbFRoaXMgJiYgJ3N1YnRsZScgaW4gZ2xvYmFsVGhpcy5jcnlwdG8pXG4gICAgICAgICAgPyBudWxsXG4gICAgICAgICAgOiBhd2FpdCB0aGlzLmZldGNoSndrKGhlYWRlci5raWQsIG9wdGlvbnM/LmtleXMgPyB7IGtleXM6IG9wdGlvbnMua2V5cyB9IDogb3B0aW9ucz8uandrcylcblxuICAgICAgLy8gSWYgc3ltbWV0cmljIGFsZ29yaXRobSBvciBXZWJDcnlwdG8gQVBJIGlzIHVuYXZhaWxhYmxlLCBmYWxsYmFjayB0byBnZXRVc2VyKClcbiAgICAgIGlmICghc2lnbmluZ0tleSkge1xuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCB0aGlzLmdldFVzZXIodG9rZW4pXG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIHRocm93IGVycm9yXG4gICAgICAgIH1cbiAgICAgICAgLy8gZ2V0VXNlciBzdWNjZWVkcyBzbyB0aGUgY2xhaW1zIGluIHRoZSBKV1QgY2FuIGJlIHRydXN0ZWRcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICBjbGFpbXM6IHBheWxvYWQsXG4gICAgICAgICAgICBoZWFkZXIsXG4gICAgICAgICAgICBzaWduYXR1cmUsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zdCBhbGdvcml0aG0gPSBnZXRBbGdvcml0aG0oaGVhZGVyLmFsZylcblxuICAgICAgLy8gQ29udmVydCBKV0sgdG8gQ3J5cHRvS2V5XG4gICAgICBjb25zdCBwdWJsaWNLZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgnandrJywgc2lnbmluZ0tleSwgYWxnb3JpdGhtLCB0cnVlLCBbXG4gICAgICAgICd2ZXJpZnknLFxuICAgICAgXSlcblxuICAgICAgLy8gVmVyaWZ5IHRoZSBzaWduYXR1cmVcbiAgICAgIGNvbnN0IGlzVmFsaWQgPSBhd2FpdCBjcnlwdG8uc3VidGxlLnZlcmlmeShcbiAgICAgICAgYWxnb3JpdGhtLFxuICAgICAgICBwdWJsaWNLZXksXG4gICAgICAgIHNpZ25hdHVyZSxcbiAgICAgICAgc3RyaW5nVG9VaW50OEFycmF5KGAke3Jhd0hlYWRlcn0uJHtyYXdQYXlsb2FkfWApXG4gICAgICApXG5cbiAgICAgIGlmICghaXNWYWxpZCkge1xuICAgICAgICB0aHJvdyBuZXcgQXV0aEludmFsaWRKd3RFcnJvcignSW52YWxpZCBKV1Qgc2lnbmF0dXJlJylcbiAgICAgIH1cblxuICAgICAgLy8gSWYgdmVyaWZpY2F0aW9uIHN1Y2NlZWRzLCBkZWNvZGUgYW5kIHJldHVybiBjbGFpbXNcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICBjbGFpbXM6IHBheWxvYWQsXG4gICAgICAgICAgaGVhZGVyLFxuICAgICAgICAgIHNpZ25hdHVyZSxcbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8vIC0tLSBQYXNza2V5IE1ldGhvZHMgLS0tXG5cbiAgLyoqXG4gICAqIFNpZ24gaW4gd2l0aCBhIHBhc3NrZXkuIEhhbmRsZXMgdGhlIGZ1bGwgV2ViQXV0aG4gY2VyZW1vbnk6XG4gICAqIDEuIEZldGNoZXMgYXV0aGVudGljYXRpb24gY2hhbGxlbmdlIGZyb20gc2VydmVyXG4gICAqIDIuIFByb21wdHMgdXNlciB2aWEgbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmdldCgpXG4gICAqIDMuIFZlcmlmaWVzIGNyZWRlbnRpYWwgd2l0aCBzZXJ2ZXIgYW5kIGNyZWF0ZXMgc2Vzc2lvblxuICAgKlxuICAgKiBSZXF1aXJlcyBgYXV0aC5leHBlcmltZW50YWwucGFzc2tleTogdHJ1ZWAuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqL1xuICBhc3luYyBzaWduSW5XaXRoUGFzc2tleShcbiAgICBjcmVkZW50aWFscz86IFNpZ25JbldpdGhQYXNza2V5Q3JlZGVudGlhbHNcbiAgKTogUHJvbWlzZTxBdXRoUGFzc2tleUF1dGhlbnRpY2F0aW9uVmVyaWZ5UmVzcG9uc2U+IHtcbiAgICBhc3NlcnRQYXNza2V5RXhwZXJpbWVudGFsRW5hYmxlZCh0aGlzLmV4cGVyaW1lbnRhbClcbiAgICB0cnkge1xuICAgICAgaWYgKCFicm93c2VyU3VwcG9ydHNXZWJBdXRobigpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoe1xuICAgICAgICAgIGRhdGE6IG51bGwsXG4gICAgICAgICAgZXJyb3I6IG5ldyBBdXRoVW5rbm93bkVycm9yKCdCcm93c2VyIGRvZXMgbm90IHN1cHBvcnQgV2ViQXV0aG4nLCBudWxsKSxcbiAgICAgICAgfSlcbiAgICAgIH1cblxuICAgICAgLy8gMS4gR2V0IGNoYWxsZW5nZSBvcHRpb25zIGZyb20gc2VydmVyXG4gICAgICBjb25zdCB7IGRhdGE6IG9wdGlvbnMsIGVycm9yOiBvcHRpb25zRXJyb3IgfSA9IGF3YWl0IHRoaXMuX3N0YXJ0UGFzc2tleUF1dGhlbnRpY2F0aW9uKHtcbiAgICAgICAgb3B0aW9uczogeyBjYXB0Y2hhVG9rZW46IGNyZWRlbnRpYWxzPy5vcHRpb25zPy5jYXB0Y2hhVG9rZW4gfSxcbiAgICAgIH0pXG4gICAgICBpZiAob3B0aW9uc0Vycm9yIHx8ICFvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogb3B0aW9uc0Vycm9yIH0pXG4gICAgICB9XG5cbiAgICAgIC8vIDIuIERlc2VyaWFsaXplIGFuZCBwcm9tcHQgdXNlciB2aWEgYnJvd3NlciBXZWJBdXRobiBBUElcbiAgICAgIGNvbnN0IHB1YmxpY0tleU9wdGlvbnMgPSBkZXNlcmlhbGl6ZUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9ucyhvcHRpb25zLm9wdGlvbnMpXG4gICAgICBjb25zdCBzaWduYWwgPSBjcmVkZW50aWFscz8ub3B0aW9ucz8uc2lnbmFsID8/IHdlYkF1dGhuQWJvcnRTZXJ2aWNlLmNyZWF0ZU5ld0Fib3J0U2lnbmFsKClcbiAgICAgIGNvbnN0IHsgZGF0YTogY3JlZGVudGlhbCwgZXJyb3I6IGNyZWRlbnRpYWxFcnJvciB9ID0gYXdhaXQgZ2V0Q3JlZGVudGlhbCh7XG4gICAgICAgIHB1YmxpY0tleTogcHVibGljS2V5T3B0aW9ucyxcbiAgICAgICAgc2lnbmFsLFxuICAgICAgfSlcbiAgICAgIGlmIChjcmVkZW50aWFsRXJyb3IgfHwgIWNyZWRlbnRpYWwpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7XG4gICAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgICBlcnJvcjogY3JlZGVudGlhbEVycm9yID8/IG5ldyBBdXRoVW5rbm93bkVycm9yKCdXZWJBdXRobiBjZXJlbW9ueSBmYWlsZWQnLCBudWxsKSxcbiAgICAgICAgfSlcbiAgICAgIH1cblxuICAgICAgLy8gMy4gU2VyaWFsaXplIGFuZCB2ZXJpZnkgd2l0aCBzZXJ2ZXJcbiAgICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBzZXJpYWxpemVDcmVkZW50aWFsUmVxdWVzdFJlc3BvbnNlKGNyZWRlbnRpYWwpXG4gICAgICByZXR1cm4gdGhpcy5fdmVyaWZ5UGFzc2tleUF1dGhlbnRpY2F0aW9uKHtcbiAgICAgICAgY2hhbGxlbmdlSWQ6IG9wdGlvbnMuY2hhbGxlbmdlX2lkLFxuICAgICAgICBjcmVkZW50aWFsOiBzZXJpYWxpemVkLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJlZ2lzdGVyIGEgcGFzc2tleSBmb3IgdGhlIGN1cnJlbnQgYXV0aGVudGljYXRlZCB1c2VyLiBIYW5kbGVzIHRoZSBmdWxsIFdlYkF1dGhuIGNlcmVtb255OlxuICAgKiAxLiBGZXRjaGVzIHJlZ2lzdHJhdGlvbiBjaGFsbGVuZ2UgZnJvbSBzZXJ2ZXJcbiAgICogMi4gUHJvbXB0cyB1c2VyIHZpYSBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuY3JlYXRlKClcbiAgICogMy4gVmVyaWZpZXMgY3JlZGVudGlhbCB3aXRoIHNlcnZlclxuICAgKlxuICAgKiBSZXF1aXJlcyBhbiBhY3RpdmUgc2Vzc2lvbi4gUmVxdWlyZXMgYGF1dGguZXhwZXJpbWVudGFsLnBhc3NrZXk6IHRydWVgLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKi9cbiAgYXN5bmMgcmVnaXN0ZXJQYXNza2V5KFxuICAgIGNyZWRlbnRpYWxzPzogUmVnaXN0ZXJQYXNza2V5Q3JlZGVudGlhbHNcbiAgKTogUHJvbWlzZTxBdXRoUGFzc2tleVJlZ2lzdHJhdGlvblZlcmlmeVJlc3BvbnNlPiB7XG4gICAgYXNzZXJ0UGFzc2tleUV4cGVyaW1lbnRhbEVuYWJsZWQodGhpcy5leHBlcmltZW50YWwpXG4gICAgdHJ5IHtcbiAgICAgIGlmICghYnJvd3NlclN1cHBvcnRzV2ViQXV0aG4oKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHtcbiAgICAgICAgICBkYXRhOiBudWxsLFxuICAgICAgICAgIGVycm9yOiBuZXcgQXV0aFVua25vd25FcnJvcignQnJvd3NlciBkb2VzIG5vdCBzdXBwb3J0IFdlYkF1dGhuJywgbnVsbCksXG4gICAgICAgIH0pXG4gICAgICB9XG5cbiAgICAgIC8vIDEuIEdldCBjaGFsbGVuZ2Ugb3B0aW9ucyBmcm9tIHNlcnZlclxuICAgICAgY29uc3QgeyBkYXRhOiBvcHRpb25zLCBlcnJvcjogb3B0aW9uc0Vycm9yIH0gPSBhd2FpdCB0aGlzLl9zdGFydFBhc3NrZXlSZWdpc3RyYXRpb24oKVxuICAgICAgaWYgKG9wdGlvbnNFcnJvciB8fCAhb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IG9wdGlvbnNFcnJvciB9KVxuICAgICAgfVxuXG4gICAgICAvLyAyLiBEZXNlcmlhbGl6ZSBhbmQgcHJvbXB0IHVzZXIgdmlhIGJyb3dzZXIgV2ViQXV0aG4gQVBJXG4gICAgICBjb25zdCBwdWJsaWNLZXlPcHRpb25zID0gZGVzZXJpYWxpemVDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zKG9wdGlvbnMub3B0aW9ucylcbiAgICAgIGNvbnN0IHNpZ25hbCA9IGNyZWRlbnRpYWxzPy5vcHRpb25zPy5zaWduYWwgPz8gd2ViQXV0aG5BYm9ydFNlcnZpY2UuY3JlYXRlTmV3QWJvcnRTaWduYWwoKVxuICAgICAgY29uc3QgeyBkYXRhOiBjcmVkZW50aWFsLCBlcnJvcjogY3JlZGVudGlhbEVycm9yIH0gPSBhd2FpdCBjcmVhdGVDcmVkZW50aWFsKHtcbiAgICAgICAgcHVibGljS2V5OiBwdWJsaWNLZXlPcHRpb25zLFxuICAgICAgICBzaWduYWwsXG4gICAgICB9KVxuICAgICAgaWYgKGNyZWRlbnRpYWxFcnJvciB8fCAhY3JlZGVudGlhbCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHtcbiAgICAgICAgICBkYXRhOiBudWxsLFxuICAgICAgICAgIGVycm9yOiBjcmVkZW50aWFsRXJyb3IgPz8gbmV3IEF1dGhVbmtub3duRXJyb3IoJ1dlYkF1dGhuIGNlcmVtb255IGZhaWxlZCcsIG51bGwpLFxuICAgICAgICB9KVxuICAgICAgfVxuXG4gICAgICAvLyAzLiBTZXJpYWxpemUgYW5kIHZlcmlmeSB3aXRoIHNlcnZlclxuICAgICAgY29uc3Qgc2VyaWFsaXplZCA9IHNlcmlhbGl6ZUNyZWRlbnRpYWxDcmVhdGlvblJlc3BvbnNlKGNyZWRlbnRpYWwpXG4gICAgICByZXR1cm4gdGhpcy5fdmVyaWZ5UGFzc2tleVJlZ2lzdHJhdGlvbih7XG4gICAgICAgIGNoYWxsZW5nZUlkOiBvcHRpb25zLmNoYWxsZW5nZV9pZCxcbiAgICAgICAgY3JlZGVudGlhbDogc2VyaWFsaXplZCxcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTdGFydCBwYXNza2V5IHJlZ2lzdHJhdGlvbiBmb3IgdGhlIGN1cnJlbnQgYXV0aGVudGljYXRlZCB1c2VyLlxuICAgKiBSZXR1cm5zIFdlYkF1dGhuIGNyZWRlbnRpYWwgY3JlYXRpb24gb3B0aW9ucyB0byBwYXNzIHRvIG5hdmlnYXRvci5jcmVkZW50aWFscy5jcmVhdGUoKS5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3N0YXJ0UGFzc2tleVJlZ2lzdHJhdGlvbigpOiBQcm9taXNlPEF1dGhQYXNza2V5UmVnaXN0cmF0aW9uT3B0aW9uc1Jlc3BvbnNlPiB7XG4gICAgYXNzZXJ0UGFzc2tleUV4cGVyaW1lbnRhbEVuYWJsZWQodGhpcy5leHBlcmltZW50YWwpXG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGRhdGE6IHsgc2Vzc2lvbiB9LFxuICAgICAgICAgIGVycm9yOiBzZXNzaW9uRXJyb3IsXG4gICAgICAgIH0gPSByZXN1bHRcbiAgICAgICAgaWYgKHNlc3Npb25FcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0pXG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yOiBuZXcgQXV0aFNlc3Npb25NaXNzaW5nRXJyb3IoKSB9KVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IF9yZXF1ZXN0KFxuICAgICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgIGAke3RoaXMudXJsfS9wYXNza2V5cy9yZWdpc3RyYXRpb24vb3B0aW9uc2AsXG4gICAgICAgICAge1xuICAgICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgICAgand0OiBzZXNzaW9uLmFjY2Vzc190b2tlbixcbiAgICAgICAgICAgIGJvZHk6IHt9LFxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YSwgZXJyb3I6IG51bGwgfSlcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWZXJpZnkgcGFzc2tleSByZWdpc3RyYXRpb24gd2l0aCB0aGUgY3JlZGVudGlhbCByZXNwb25zZS5cbiAgICogVGhlIGNyZWRlbnRpYWxSZXNwb25zZSBzaG91bGQgYmUgdGhlIHNlcmlhbGl6ZWQgb3V0cHV0IG9mIG5hdmlnYXRvci5jcmVkZW50aWFscy5jcmVhdGUoKS5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3ZlcmlmeVBhc3NrZXlSZWdpc3RyYXRpb24oXG4gICAgcGFyYW1zOiBWZXJpZnlQYXNza2V5UmVnaXN0cmF0aW9uUGFyYW1zXG4gICk6IFByb21pc2U8QXV0aFBhc3NrZXlSZWdpc3RyYXRpb25WZXJpZnlSZXNwb25zZT4ge1xuICAgIGFzc2VydFBhc3NrZXlFeHBlcmltZW50YWxFbmFibGVkKHRoaXMuZXhwZXJpbWVudGFsKVxuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBkYXRhOiB7IHNlc3Npb24gfSxcbiAgICAgICAgICBlcnJvcjogc2Vzc2lvbkVycm9yLFxuICAgICAgICB9ID0gcmVzdWx0XG4gICAgICAgIGlmIChzZXNzaW9uRXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IHNlc3Npb25FcnJvciB9KVxuICAgICAgICB9XG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogbmV3IEF1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKCkgfSlcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAgICdQT1NUJyxcbiAgICAgICAgICBgJHt0aGlzLnVybH0vcGFzc2tleXMvcmVnaXN0cmF0aW9uL3ZlcmlmeWAsXG4gICAgICAgICAge1xuICAgICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgICAgand0OiBzZXNzaW9uLmFjY2Vzc190b2tlbixcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgY2hhbGxlbmdlX2lkOiBwYXJhbXMuY2hhbGxlbmdlSWQsXG4gICAgICAgICAgICAgIGNyZWRlbnRpYWw6IHBhcmFtcy5jcmVkZW50aWFsLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGEsIGVycm9yOiBudWxsIH0pXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU3RhcnQgcGFzc2tleSBhdXRoZW50aWNhdGlvbi5cbiAgICogUmV0dXJucyBXZWJBdXRobiBjcmVkZW50aWFsIHJlcXVlc3Qgb3B0aW9ucyB0byBwYXNzIHRvIG5hdmlnYXRvci5jcmVkZW50aWFscy5nZXQoKS5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3N0YXJ0UGFzc2tleUF1dGhlbnRpY2F0aW9uKFxuICAgIHBhcmFtcz86IFN0YXJ0UGFzc2tleUF1dGhlbnRpY2F0aW9uUGFyYW1zXG4gICk6IFByb21pc2U8QXV0aFBhc3NrZXlBdXRoZW50aWNhdGlvbk9wdGlvbnNSZXNwb25zZT4ge1xuICAgIGFzc2VydFBhc3NrZXlFeHBlcmltZW50YWxFbmFibGVkKHRoaXMuZXhwZXJpbWVudGFsKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgJ1BPU1QnLFxuICAgICAgICBgJHt0aGlzLnVybH0vcGFzc2tleXMvYXV0aGVudGljYXRpb24vb3B0aW9uc2AsXG4gICAgICAgIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgZ290cnVlX21ldGFfc2VjdXJpdHk6IHsgY2FwdGNoYV90b2tlbjogcGFyYW1zPy5vcHRpb25zPy5jYXB0Y2hhVG9rZW4gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9XG4gICAgICApXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YSwgZXJyb3I6IG51bGwgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZlcmlmeSBwYXNza2V5IGF1dGhlbnRpY2F0aW9uIGFuZCBjcmVhdGUgYSBzZXNzaW9uLlxuICAgKiBUaGUgY3JlZGVudGlhbCBzaG91bGQgYmUgdGhlIHNlcmlhbGl6ZWQgb3V0cHV0IG9mIG5hdmlnYXRvci5jcmVkZW50aWFscy5nZXQoKS5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3ZlcmlmeVBhc3NrZXlBdXRoZW50aWNhdGlvbihcbiAgICBwYXJhbXM6IFZlcmlmeVBhc3NrZXlBdXRoZW50aWNhdGlvblBhcmFtc1xuICApOiBQcm9taXNlPEF1dGhQYXNza2V5QXV0aGVudGljYXRpb25WZXJpZnlSZXNwb25zZT4ge1xuICAgIGFzc2VydFBhc3NrZXlFeHBlcmltZW50YWxFbmFibGVkKHRoaXMuZXhwZXJpbWVudGFsKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgJ1BPU1QnLFxuICAgICAgICBgJHt0aGlzLnVybH0vcGFzc2tleXMvYXV0aGVudGljYXRpb24vdmVyaWZ5YCxcbiAgICAgICAge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBjaGFsbGVuZ2VfaWQ6IHBhcmFtcy5jaGFsbGVuZ2VJZCxcbiAgICAgICAgICAgIGNyZWRlbnRpYWw6IHBhcmFtcy5jcmVkZW50aWFsLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgeGZvcm06IF9zZXNzaW9uUmVzcG9uc2UsXG4gICAgICAgIH1cbiAgICAgIClcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIGlmIChkYXRhLnNlc3Npb24pIHtcbiAgICAgICAgYXdhaXQgdGhpcy5fc2F2ZVNlc3Npb24oZGF0YS5zZXNzaW9uKVxuICAgICAgICBhd2FpdCB0aGlzLl9ub3RpZnlBbGxTdWJzY3JpYmVycygnU0lHTkVEX0lOJywgZGF0YS5zZXNzaW9uKVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGEsIGVycm9yOiBudWxsIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBMaXN0IGFsbCBwYXNza2V5cyBmb3IgdGhlIGN1cnJlbnQgdXNlci5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX2xpc3RQYXNza2V5cygpOiBQcm9taXNlPEF1dGhQYXNza2V5TGlzdFJlc3BvbnNlPiB7XG4gICAgYXNzZXJ0UGFzc2tleUV4cGVyaW1lbnRhbEVuYWJsZWQodGhpcy5leHBlcmltZW50YWwpXG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl91c2VTZXNzaW9uKGFzeW5jIChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGRhdGE6IHsgc2Vzc2lvbiB9LFxuICAgICAgICAgIGVycm9yOiBzZXNzaW9uRXJyb3IsXG4gICAgICAgIH0gPSByZXN1bHRcbiAgICAgICAgaWYgKHNlc3Npb25FcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0pXG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yOiBuZXcgQXV0aFNlc3Npb25NaXNzaW5nRXJyb3IoKSB9KVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdHRVQnLCBgJHt0aGlzLnVybH0vcGFzc2tleXNgLCB7XG4gICAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICAgIGp3dDogc2Vzc2lvbi5hY2Nlc3NfdG9rZW4sXG4gICAgICAgICAgeGZvcm06IChkYXRhOiBhbnkpID0+ICh7IGRhdGEsIGVycm9yOiBudWxsIH0pLFxuICAgICAgICB9KVxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YSwgZXJyb3I6IG51bGwgfSlcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGUgYSBwYXNza2V5LlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfdXBkYXRlUGFzc2tleShwYXJhbXM6IFBhc3NrZXlVcGRhdGVQYXJhbXMpOiBQcm9taXNlPEF1dGhQYXNza2V5VXBkYXRlUmVzcG9uc2U+IHtcbiAgICBhc3NlcnRQYXNza2V5RXhwZXJpbWVudGFsRW5hYmxlZCh0aGlzLmV4cGVyaW1lbnRhbClcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX3VzZVNlc3Npb24oYXN5bmMgKHJlc3VsdCkgPT4ge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgZGF0YTogeyBzZXNzaW9uIH0sXG4gICAgICAgICAgZXJyb3I6IHNlc3Npb25FcnJvcixcbiAgICAgICAgfSA9IHJlc3VsdFxuICAgICAgICBpZiAoc2Vzc2lvbkVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yOiBzZXNzaW9uRXJyb3IgfSlcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IG5ldyBBdXRoU2Vzc2lvbk1pc3NpbmdFcnJvcigpIH0pXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QoXG4gICAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgICAnUEFUQ0gnLFxuICAgICAgICAgIGAke3RoaXMudXJsfS9wYXNza2V5cy8ke3BhcmFtcy5wYXNza2V5SWR9YCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgICBqd3Q6IHNlc3Npb24uYWNjZXNzX3Rva2VuLFxuICAgICAgICAgICAgYm9keTogeyBmcmllbmRseV9uYW1lOiBwYXJhbXMuZnJpZW5kbHlOYW1lIH0sXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhLCBlcnJvcjogbnVsbCB9KVxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3IgfSlcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSBhIHBhc3NrZXkuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9kZWxldGVQYXNza2V5KHBhcmFtczogUGFzc2tleURlbGV0ZVBhcmFtcyk6IFByb21pc2U8QXV0aFBhc3NrZXlEZWxldGVSZXNwb25zZT4ge1xuICAgIGFzc2VydFBhc3NrZXlFeHBlcmltZW50YWxFbmFibGVkKHRoaXMuZXhwZXJpbWVudGFsKVxuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fdXNlU2Vzc2lvbihhc3luYyAocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBkYXRhOiB7IHNlc3Npb24gfSxcbiAgICAgICAgICBlcnJvcjogc2Vzc2lvbkVycm9yLFxuICAgICAgICB9ID0gcmVzdWx0XG4gICAgICAgIGlmIChzZXNzaW9uRXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmV0dXJuUmVzdWx0KHsgZGF0YTogbnVsbCwgZXJyb3I6IHNlc3Npb25FcnJvciB9KVxuICAgICAgICB9XG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvcjogbmV3IEF1dGhTZXNzaW9uTWlzc2luZ0Vycm9yKCkgfSlcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAgICdERUxFVEUnLFxuICAgICAgICAgIGAke3RoaXMudXJsfS9wYXNza2V5cy8ke3BhcmFtcy5wYXNza2V5SWR9YCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgICBqd3Q6IHNlc3Npb24uYWNjZXNzX3Rva2VuLFxuICAgICAgICAgICAgbm9SZXNvbHZlSnNvbjogdHJ1ZSxcbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yIH0pXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX3JldHVyblJlc3VsdCh7IGRhdGE6IG51bGwsIGVycm9yOiBudWxsIH0pXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yZXR1cm5SZXN1bHQoeyBkYXRhOiBudWxsLCBlcnJvciB9KVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19