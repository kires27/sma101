import { CHANNEL_EVENTS, CHANNEL_STATES } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/constants.js?v=583078ff";
import RealtimePresence from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/RealtimePresence.js?v=583078ff";
import * as Transformers from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/transformers.js?v=583078ff";
import { httpEndpointURL } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/transformers.js?v=583078ff";
import { normalizeChannelError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/normalizeChannelError.js?v=583078ff";
import ChannelAdapter from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/phoenix/channelAdapter.js?v=583078ff";
export var REALTIME_POSTGRES_CHANGES_LISTEN_EVENT;
(function (REALTIME_POSTGRES_CHANGES_LISTEN_EVENT) {
    REALTIME_POSTGRES_CHANGES_LISTEN_EVENT["ALL"] = "*";
    REALTIME_POSTGRES_CHANGES_LISTEN_EVENT["INSERT"] = "INSERT";
    REALTIME_POSTGRES_CHANGES_LISTEN_EVENT["UPDATE"] = "UPDATE";
    REALTIME_POSTGRES_CHANGES_LISTEN_EVENT["DELETE"] = "DELETE";
})(REALTIME_POSTGRES_CHANGES_LISTEN_EVENT || (REALTIME_POSTGRES_CHANGES_LISTEN_EVENT = {}));
export var REALTIME_LISTEN_TYPES;
(function (REALTIME_LISTEN_TYPES) {
    REALTIME_LISTEN_TYPES["BROADCAST"] = "broadcast";
    REALTIME_LISTEN_TYPES["PRESENCE"] = "presence";
    REALTIME_LISTEN_TYPES["POSTGRES_CHANGES"] = "postgres_changes";
    REALTIME_LISTEN_TYPES["SYSTEM"] = "system";
})(REALTIME_LISTEN_TYPES || (REALTIME_LISTEN_TYPES = {}));
export var REALTIME_SUBSCRIBE_STATES;
(function (REALTIME_SUBSCRIBE_STATES) {
    REALTIME_SUBSCRIBE_STATES["SUBSCRIBED"] = "SUBSCRIBED";
    REALTIME_SUBSCRIBE_STATES["TIMED_OUT"] = "TIMED_OUT";
    REALTIME_SUBSCRIBE_STATES["CLOSED"] = "CLOSED";
    REALTIME_SUBSCRIBE_STATES["CHANNEL_ERROR"] = "CHANNEL_ERROR";
})(REALTIME_SUBSCRIBE_STATES || (REALTIME_SUBSCRIBE_STATES = {}));
export const REALTIME_CHANNEL_STATES = CHANNEL_STATES;
/** A channel is the basic building block of Realtime
 * and narrows the scope of data flow to subscribed clients.
 * You can think of a channel as a chatroom where participants are able to see who's online
 * and send and receive messages.
 */
export default class RealtimeChannel {
    get state() {
        return this.channelAdapter.state;
    }
    set state(state) {
        this.channelAdapter.state = state;
    }
    get joinedOnce() {
        return this.channelAdapter.joinedOnce;
    }
    get timeout() {
        return this.socket.timeout;
    }
    get joinPush() {
        return this.channelAdapter.joinPush;
    }
    get rejoinTimer() {
        return this.channelAdapter.rejoinTimer;
    }
    /**
     * Creates a channel that can broadcast messages, sync presence, and listen to Postgres changes.
     *
     * The topic determines which realtime stream you are subscribing to. Config options let you
     * enable acknowledgement for broadcasts, presence tracking, or private channels.
     *
     * @category Realtime
     *
     * @example Using supabase-js (recommended)
     * ```ts
     * import { createClient } from '@supabase/supabase-js'
     *
     * const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
     * const channel = supabase.channel('room1')
     * channel
     *   .on('broadcast', { event: 'cursor-pos' }, (payload) => console.log(payload))
     *   .subscribe()
     * ```
     *
     * @example Standalone import for bundle-sensitive environments
     * ```ts
     * import RealtimeClient from '@supabase/realtime-js'
     *
     * const client = new RealtimeClient('https://xyzcompany.supabase.co/realtime/v1', {
     *   params: { apikey: 'your-publishable-key' },
     * })
     * const channel = new RealtimeChannel('realtime:public:messages', { config: {} }, client)
     * ```
     */
    constructor(
    /** Topic name can be any string. */
    topic, params = { config: {} }, socket) {
        var _a, _b;
        this.topic = topic;
        this.params = params;
        this.socket = socket;
        this.bindings = {};
        this.subTopic = topic.replace(/^realtime:/i, '');
        this.params.config = Object.assign({
            broadcast: { ack: false, self: false },
            presence: { key: '', enabled: false },
            private: false,
        }, params.config);
        this.channelAdapter = new ChannelAdapter(this.socket.socketAdapter, topic, this.params);
        this.presence = new RealtimePresence(this);
        this._onClose(() => {
            this.socket._remove(this);
        });
        this._updateFilterTransform();
        this.broadcastEndpointURL = httpEndpointURL(this.socket.socketAdapter.endPointURL());
        this.private = this.params.config.private || false;
        if (!this.private && ((_b = (_a = this.params.config) === null || _a === void 0 ? void 0 : _a.broadcast) === null || _b === void 0 ? void 0 : _b.replay)) {
            throw new Error(`tried to use replay on public channel '${this.topic}'. It must be a private channel.`);
        }
    }
    /**
     * Subscribe registers your client with the server.
     *
     * The optional `callback` receives a `status` and, on failure, an `err` argument.
     * Log the full `err` so its `cause`, `name`, and any structured fields aren't hidden
     * behind `err.message`.
     *
     * @category Realtime
     *
     * @example Handling errors
     * ```js
     * supabase.channel('room1').subscribe((status, err) => {
     *   if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
     *     // Log the full error: its `cause` often holds the underlying reason.
     *     console.error(status, err)
     *   }
     * })
     * ```
     */
    subscribe(callback, timeout = this.timeout) {
        var _a, _b, _c;
        if (!this.socket.isConnected()) {
            this.socket.connect();
        }
        if (this.channelAdapter.isClosed()) {
            const { config: { broadcast, presence, private: isPrivate }, } = this.params;
            const postgres_changes = (_b = (_a = this.bindings.postgres_changes) === null || _a === void 0 ? void 0 : _a.map((r) => r.filter)) !== null && _b !== void 0 ? _b : [];
            const presence_enabled = (!!this.bindings[REALTIME_LISTEN_TYPES.PRESENCE] &&
                this.bindings[REALTIME_LISTEN_TYPES.PRESENCE].length > 0) ||
                ((_c = this.params.config.presence) === null || _c === void 0 ? void 0 : _c.enabled) === true;
            const accessTokenPayload = {};
            const config = {
                broadcast,
                presence: Object.assign(Object.assign({}, presence), { enabled: presence_enabled }),
                postgres_changes,
                private: isPrivate,
            };
            if (this.socket.accessTokenValue) {
                accessTokenPayload.access_token = this.socket.accessTokenValue;
            }
            this._onError((reason) => {
                callback === null || callback === void 0 ? void 0 : callback(REALTIME_SUBSCRIBE_STATES.CHANNEL_ERROR, normalizeChannelError(reason));
            });
            this._onClose(() => callback === null || callback === void 0 ? void 0 : callback(REALTIME_SUBSCRIBE_STATES.CLOSED));
            this.updateJoinPayload(Object.assign({ config }, accessTokenPayload));
            this._updateFilterMessage();
            this.channelAdapter
                .subscribe(timeout)
                .receive('ok', async ({ postgres_changes }) => {
                // Only refresh auth if using callback-based tokens
                if (!this.socket._isManualToken()) {
                    this.socket.setAuth();
                }
                if (postgres_changes === undefined) {
                    callback === null || callback === void 0 ? void 0 : callback(REALTIME_SUBSCRIBE_STATES.SUBSCRIBED);
                    return;
                }
                this._updatePostgresBindings(postgres_changes, callback);
            })
                .receive('error', (error) => {
                this.state = CHANNEL_STATES.errored;
                const message = Object.values(error).join(', ') || 'error';
                callback === null || callback === void 0 ? void 0 : callback(REALTIME_SUBSCRIBE_STATES.CHANNEL_ERROR, new Error(message, { cause: error }));
            })
                .receive('timeout', () => {
                callback === null || callback === void 0 ? void 0 : callback(REALTIME_SUBSCRIBE_STATES.TIMED_OUT);
            });
        }
        return this;
    }
    _updatePostgresBindings(postgres_changes, callback) {
        var _a;
        const clientPostgresBindings = this.bindings.postgres_changes;
        const bindingsLen = (_a = clientPostgresBindings === null || clientPostgresBindings === void 0 ? void 0 : clientPostgresBindings.length) !== null && _a !== void 0 ? _a : 0;
        const newPostgresBindings = [];
        for (let i = 0; i < bindingsLen; i++) {
            const clientPostgresBinding = clientPostgresBindings[i];
            const { filter: { event, schema, table, filter }, } = clientPostgresBinding;
            const serverPostgresFilter = postgres_changes && postgres_changes[i];
            if (serverPostgresFilter &&
                serverPostgresFilter.event === event &&
                RealtimeChannel.isFilterValueEqual(serverPostgresFilter.schema, schema) &&
                RealtimeChannel.isFilterValueEqual(serverPostgresFilter.table, table) &&
                RealtimeChannel.isFilterValueEqual(serverPostgresFilter.filter, filter)) {
                newPostgresBindings.push(Object.assign(Object.assign({}, clientPostgresBinding), { id: serverPostgresFilter.id }));
            }
            else {
                this.unsubscribe();
                this.state = CHANNEL_STATES.errored;
                callback === null || callback === void 0 ? void 0 : callback(REALTIME_SUBSCRIBE_STATES.CHANNEL_ERROR, new Error('mismatch between server and client bindings for postgres changes'));
                return;
            }
        }
        this.bindings.postgres_changes = newPostgresBindings;
        if (this.state != CHANNEL_STATES.errored && callback) {
            callback(REALTIME_SUBSCRIBE_STATES.SUBSCRIBED);
        }
    }
    /**
     * Returns the current presence state for this channel.
     *
     * The shape is a map keyed by presence key (for example a user id) where each entry contains the
     * tracked metadata for that user.
     *
     * @category Realtime
     */
    presenceState() {
        return this.presence.state;
    }
    /**
     * Sends the supplied payload to the presence tracker so other subscribers can see that this
     * client is online. Use `untrack` to stop broadcasting presence for the same key.
     *
     * @category Realtime
     */
    async track(payload, opts = {}) {
        return await this.send({
            type: 'presence',
            event: 'track',
            payload,
        }, opts.timeout || this.timeout);
    }
    /**
     * Removes the current presence state for this client.
     *
     * @category Realtime
     */
    async untrack(opts = {}) {
        return await this.send({
            type: 'presence',
            event: 'untrack',
        }, opts);
    }
    /**
     * Listen to realtime events on this channel.
     * @category Realtime
     *
     * @remarks
     * - By default, Broadcast and Presence are enabled for all projects.
     * - By default, listening to database changes is disabled for new projects due to database performance and security concerns. You can turn it on by managing Realtime's [replication](/docs/guides/api#realtime-api-overview).
     * - You can receive the "previous" data for updates and deletes by setting the table's `REPLICA IDENTITY` to `FULL` (e.g., `ALTER TABLE your_table REPLICA IDENTITY FULL;`).
     * - Row level security is not applied to delete statements. When RLS is enabled and replica identity is set to full, only the primary key is sent to clients.
     *
     * @example Listen to broadcast messages
     * ```js
     * const channel = supabase.channel("room1")
     *
     * channel.on("broadcast", { event: "cursor-pos" }, (payload) => {
     *   console.log("Cursor position received!", payload);
     * }).subscribe((status) => {
     *   if (status === "SUBSCRIBED") {
     *     channel.send({
     *       type: "broadcast",
     *       event: "cursor-pos",
     *       payload: { x: Math.random(), y: Math.random() },
     *     });
     *   }
     * });
     * ```
     *
     * @example Listen to presence sync
     * ```js
     * const channel = supabase.channel('room1')
     * channel
     *   .on('presence', { event: 'sync' }, () => {
     *     console.log('Synced presence state: ', channel.presenceState())
     *   })
     *   .subscribe(async (status) => {
     *     if (status === 'SUBSCRIBED') {
     *       await channel.track({ online_at: new Date().toISOString() })
     *     }
     *   })
     * ```
     *
     * @example Listen to presence join
     * ```js
     * const channel = supabase.channel('room1')
     * channel
     *   .on('presence', { event: 'join' }, ({ newPresences }) => {
     *     console.log('Newly joined presences: ', newPresences)
     *   })
     *   .subscribe(async (status) => {
     *     if (status === 'SUBSCRIBED') {
     *       await channel.track({ online_at: new Date().toISOString() })
     *     }
     *   })
     * ```
     *
     * @example Listen to presence leave
     * ```js
     * const channel = supabase.channel('room1')
     * channel
     *   .on('presence', { event: 'leave' }, ({ leftPresences }) => {
     *     console.log('Newly left presences: ', leftPresences)
     *   })
     *   .subscribe(async (status) => {
     *     if (status === 'SUBSCRIBED') {
     *       await channel.track({ online_at: new Date().toISOString() })
     *       await channel.untrack()
     *     }
     *   })
     * ```
     *
     * @example Listen to all database changes
     * ```js
     * supabase
     *   .channel('room1')
     *   .on('postgres_changes', { event: '*', schema: '*' }, payload => {
     *     console.log('Change received!', payload)
     *   })
     *   .subscribe()
     * ```
     *
     * @example Listen to a specific table
     * ```js
     * supabase
     *   .channel('room1')
     *   .on('postgres_changes', { event: '*', schema: 'public', table: 'countries' }, payload => {
     *     console.log('Change received!', payload)
     *   })
     *   .subscribe()
     * ```
     *
     * @example Listen to inserts
     * ```js
     * supabase
     *   .channel('room1')
     *   .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'countries' }, payload => {
     *     console.log('Change received!', payload)
     *   })
     *   .subscribe()
     * ```
     *
     * @exampleDescription Listen to updates
     * By default, Supabase will send only the updated record. If you want to receive the previous values as well you can
     * enable full replication for the table you are listening to:
     *
     * ```sql
     * alter table "your_table" replica identity full;
     * ```
     *
     * @example Listen to updates
     * ```js
     * supabase
     *   .channel('room1')
     *   .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'countries' }, payload => {
     *     console.log('Change received!', payload)
     *   })
     *   .subscribe()
     * ```
     *
     * @exampleDescription Listen to deletes
     * By default, Supabase does not send deleted records. If you want to receive the deleted record you can
     * enable full replication for the table you are listening to:
     *
     * ```sql
     * alter table "your_table" replica identity full;
     * ```
     *
     * @example Listen to deletes
     * ```js
     * supabase
     *   .channel('room1')
     *   .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'countries' }, payload => {
     *     console.log('Change received!', payload)
     *   })
     *   .subscribe()
     * ```
     *
     * @exampleDescription Listen to multiple events
     * You can chain listeners if you want to listen to multiple events for each table.
     *
     * @example Listen to multiple events
     * ```js
     * supabase
     *   .channel('room1')
     *   .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'countries' }, handleRecordInserted)
     *   .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'countries' }, handleRecordDeleted)
     *   .subscribe()
     * ```
     *
     * @exampleDescription Listen to row level changes
     * You can listen to individual rows using the format `{table}:{col}=eq.{val}` - where `{col}` is the column name, and `{val}` is the value which you want to match.
     *
     * @example Listen to row level changes
     * ```js
     * supabase
     *   .channel('room1')
     *   .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'countries', filter: 'id=eq.200' }, handleRecordUpdated)
     *   .subscribe()
     * ```
     */
    on(type, filter, callback) {
        const stateCheck = this.channelAdapter.isJoined() || this.channelAdapter.isJoining();
        const typeCheck = type === REALTIME_LISTEN_TYPES.PRESENCE || type === REALTIME_LISTEN_TYPES.POSTGRES_CHANGES;
        if (stateCheck && typeCheck) {
            this.socket.log('channel', `cannot add \`${type}\` callbacks for ${this.topic} after \`subscribe()\`.`);
            throw new Error(`cannot add \`${type}\` callbacks for ${this.topic} after \`subscribe()\`.`);
        }
        return this._on(type, filter, callback);
    }
    /**
     * Sends a broadcast message explicitly via REST API.
     *
     * This method always uses the REST API endpoint regardless of WebSocket connection state.
     * Useful when you want to guarantee REST delivery or when gradually migrating from implicit REST fallback.
     *
     * Payloads that are `ArrayBuffer` or `ArrayBufferView` (e.g. `Uint8Array`) are sent as
     * `application/octet-stream`; all other payloads are JSON-encoded.
     *
     * @param event The name of the broadcast event
     * @param payload Payload to be sent (required)
     * @param opts Options including timeout
     * @returns Promise resolving to object with success status, and error details if failed
     *
     * @category Realtime
     */
    async httpSend(event, payload, opts = {}) {
        var _a;
        if (payload === undefined || payload === null) {
            return Promise.reject(new Error('Payload is required for httpSend()'));
        }
        const isBinary = payload instanceof ArrayBuffer || ArrayBuffer.isView(payload);
        const headers = {
            apikey: this.socket.apiKey ? this.socket.apiKey : '',
            'Content-Type': isBinary ? 'application/octet-stream' : 'application/json',
        };
        if (this.socket.accessTokenValue) {
            headers['Authorization'] = `Bearer ${this.socket.accessTokenValue}`;
        }
        const url = new URL(this.broadcastEndpointURL);
        url.pathname += `/${encodeURIComponent(this.subTopic)}/events/${encodeURIComponent(event)}`;
        if (this.private) {
            url.searchParams.set('private', 'true');
        }
        const options = {
            method: 'POST',
            headers,
            body: isBinary ? payload : JSON.stringify(payload),
        };
        const response = await this._fetchWithTimeout(url.toString(), options, (_a = opts.timeout) !== null && _a !== void 0 ? _a : this.timeout);
        if (response.status === 202) {
            return { success: true };
        }
        let errorMessage = response.statusText;
        try {
            const errorBody = await response.json();
            errorMessage = errorBody.error || errorBody.message || errorMessage;
        }
        catch (_b) { }
        return Promise.reject(new Error(errorMessage));
    }
    /**
     * Sends a message into the channel.
     *
     * @param args Arguments to send to channel
     * @param args.type The type of event to send
     * @param args.event The name of the event being sent
     * @param args.payload Payload to be sent
     * @param opts Options to be used during the send process
     *
     * @category Realtime
     *
     * @remarks
     * - When using REST you don't need to subscribe to the channel
     * - REST calls are only available from 2.37.0 onwards
     * - If you create a channel only to send a REST broadcast, remove it from
     *   the client when the send completes
     *
     * @example Send a message via websocket
     * ```js
     * const channel = supabase.channel('room1')
     *
     * channel.subscribe((status) => {
     *   if (status === 'SUBSCRIBED') {
     *     channel.send({
     *       type: 'broadcast',
     *       event: 'cursor-pos',
     *       payload: { x: Math.random(), y: Math.random() },
     *     })
     *   }
     * })
     * ```
     *
     * @exampleResponse Send a message via websocket
     * ```js
     * ok | timed out | error
     * ```
     *
     * @example Send a message via REST
     * ```js
     * const channel = supabase.channel('room1')
     *
     * try {
     *   await channel.httpSend('cursor-pos', { x: Math.random(), y: Math.random() })
     * } finally {
     *   await supabase.removeChannel(channel)
     * }
     * ```
     */
    async send(args, opts = {}) {
        var _a, _b;
        if (!this.channelAdapter.canPush() && args.type === 'broadcast') {
            console.warn('Realtime send() is automatically falling back to REST API. ' +
                'This behavior will be deprecated in the future. ' +
                'Please use httpSend() explicitly for REST delivery.');
            const { event, payload: endpoint_payload } = args;
            const headers = {
                apikey: this.socket.apiKey ? this.socket.apiKey : '',
                'Content-Type': 'application/json',
            };
            if (this.socket.accessTokenValue) {
                headers['Authorization'] = `Bearer ${this.socket.accessTokenValue}`;
            }
            const options = {
                method: 'POST',
                headers,
                body: JSON.stringify({
                    messages: [
                        {
                            topic: this.subTopic,
                            event,
                            payload: endpoint_payload,
                            private: this.private,
                        },
                    ],
                }),
            };
            try {
                const response = await this._fetchWithTimeout(this.broadcastEndpointURL, options, (_a = opts.timeout) !== null && _a !== void 0 ? _a : this.timeout);
                await ((_b = response.body) === null || _b === void 0 ? void 0 : _b.cancel());
                return response.ok ? 'ok' : 'error';
            }
            catch (error) {
                if (error instanceof Error && error.name === 'AbortError') {
                    return 'timed out';
                }
                else {
                    return 'error';
                }
            }
        }
        else {
            return new Promise((resolve) => {
                var _a, _b, _c;
                const push = this.channelAdapter.push(args.type, args, opts.timeout || this.timeout);
                if (args.type === 'broadcast' && !((_c = (_b = (_a = this.params) === null || _a === void 0 ? void 0 : _a.config) === null || _b === void 0 ? void 0 : _b.broadcast) === null || _c === void 0 ? void 0 : _c.ack)) {
                    resolve('ok');
                }
                push.receive('ok', () => resolve('ok'));
                push.receive('error', () => resolve('error'));
                push.receive('timeout', () => resolve('timed out'));
            });
        }
    }
    /**
     * Updates the payload that will be sent the next time the channel joins (reconnects).
     * Useful for rotating access tokens or updating config without re-creating the channel.
     *
     * @category Realtime
     */
    updateJoinPayload(payload) {
        this.channelAdapter.updateJoinPayload(payload);
    }
    /**
     * Leaves the channel.
     *
     * Unsubscribes from server events, and instructs channel to terminate on server.
     * Triggers onClose() hooks.
     *
     * To receive leave acknowledgements, use the a `receive` hook to bind to the server ack, ie:
     * channel.unsubscribe().receive("ok", () => alert("left!") )
     *
     * @category Realtime
     */
    async unsubscribe(timeout = this.timeout) {
        return new Promise((resolve) => {
            this.channelAdapter
                .unsubscribe(timeout)
                .receive('ok', () => resolve('ok'))
                .receive('timeout', () => resolve('timed out'))
                .receive('error', () => resolve('error'));
        });
    }
    /**
     * Destroys and stops related timers.
     *
     * @category Realtime
     */
    teardown() {
        this.channelAdapter.teardown();
    }
    /** @internal */
    async _fetchWithTimeout(url, options, timeout) {
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), timeout);
        const response = await this.socket.fetch(url, Object.assign(Object.assign({}, options), { signal: controller.signal }));
        clearTimeout(id);
        return response;
    }
    /** @internal */
    _on(type, filter, callback) {
        const typeLower = type.toLocaleLowerCase();
        const ref = this.channelAdapter.on(type, callback);
        const binding = {
            type: typeLower,
            filter: filter,
            callback: callback,
            ref: ref,
        };
        if (this.bindings[typeLower]) {
            this.bindings[typeLower].push(binding);
        }
        else {
            this.bindings[typeLower] = [binding];
        }
        this._updateFilterMessage();
        return this;
    }
    /**
     * Registers a callback that will be executed when the channel closes.
     *
     * @internal
     */
    _onClose(callback) {
        this.channelAdapter.onClose(callback);
    }
    /**
     * Registers a callback that will be executed when the channel encounteres an error.
     *
     * @internal
     */
    _onError(callback) {
        this.channelAdapter.onError(callback);
    }
    /** @internal */
    _updateFilterMessage() {
        this.channelAdapter.updateFilterBindings((binding, payload, ref) => {
            var _a, _b, _c, _d, _e, _f, _g;
            const typeLower = binding.event.toLocaleLowerCase();
            if (this._notThisChannelEvent(typeLower, ref)) {
                return false;
            }
            const bind = (_a = this.bindings[typeLower]) === null || _a === void 0 ? void 0 : _a.find((bind) => bind.ref === binding.ref);
            if (!bind) {
                return true;
            }
            if (['broadcast', 'presence', 'postgres_changes'].includes(typeLower)) {
                if ('id' in bind) {
                    const bindId = bind.id;
                    const bindEvent = (_b = bind.filter) === null || _b === void 0 ? void 0 : _b.event;
                    return (bindId &&
                        ((_c = payload.ids) === null || _c === void 0 ? void 0 : _c.includes(bindId)) &&
                        (bindEvent === '*' ||
                            (bindEvent === null || bindEvent === void 0 ? void 0 : bindEvent.toLocaleLowerCase()) === ((_d = payload.data) === null || _d === void 0 ? void 0 : _d.type.toLocaleLowerCase())));
                }
                else {
                    const bindEvent = (_f = (_e = bind === null || bind === void 0 ? void 0 : bind.filter) === null || _e === void 0 ? void 0 : _e.event) === null || _f === void 0 ? void 0 : _f.toLocaleLowerCase();
                    return bindEvent === '*' || bindEvent === ((_g = payload === null || payload === void 0 ? void 0 : payload.event) === null || _g === void 0 ? void 0 : _g.toLocaleLowerCase());
                }
            }
            else {
                return bind.type.toLocaleLowerCase() === typeLower;
            }
        });
    }
    /** @internal */
    _notThisChannelEvent(event, ref) {
        const { close, error, leave, join } = CHANNEL_EVENTS;
        const events = [close, error, leave, join];
        return ref && events.includes(event) && ref !== this.joinPush.ref;
    }
    /** @internal */
    _updateFilterTransform() {
        this.channelAdapter.updatePayloadTransform((event, payload, ref) => {
            if (typeof payload === 'object' && 'ids' in payload) {
                const postgresChanges = payload.data;
                const { schema, table, commit_timestamp, type, errors } = postgresChanges;
                const enrichedPayload = {
                    schema: schema,
                    table: table,
                    commit_timestamp: commit_timestamp,
                    eventType: type,
                    new: {},
                    old: {},
                    errors: errors,
                };
                return Object.assign(Object.assign({}, enrichedPayload), this._getPayloadRecords(postgresChanges));
            }
            return payload;
        });
    }
    copyBindings(other) {
        if (this.joinedOnce) {
            throw new Error('cannot copy bindings into joined channel');
        }
        for (const kind in other.bindings) {
            for (const binding of other.bindings[kind]) {
                this._on(binding.type, binding.filter, binding.callback);
            }
        }
    }
    /**
     * Compares two optional filter values for equality.
     * Treats undefined, null, and empty string as equivalent empty values.
     * @internal
     */
    static isFilterValueEqual(serverValue, clientValue) {
        const normalizedServer = serverValue !== null && serverValue !== void 0 ? serverValue : undefined;
        const normalizedClient = clientValue !== null && clientValue !== void 0 ? clientValue : undefined;
        return normalizedServer === normalizedClient;
    }
    /** @internal */
    _getPayloadRecords(payload) {
        const records = {
            new: {},
            old: {},
        };
        if (payload.type === 'INSERT' || payload.type === 'UPDATE') {
            records.new = Transformers.convertChangeData(payload.columns, payload.record);
        }
        if (payload.type === 'UPDATE' || payload.type === 'DELETE') {
            records.old = Transformers.convertChangeData(payload.columns, payload.old_record);
        }
        return records;
    }
}
                                           
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVhbHRpbWVDaGFubmVsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL1JlYWx0aW1lQ2hhbm5lbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRSxNQUFNLGlCQUFpQixDQUFBO0FBR2hFLE9BQU8sZ0JBQXFELE1BQU0sb0JBQW9CLENBQUE7QUFNdEYsT0FBTyxLQUFLLFlBQVksTUFBTSxvQkFBb0IsQ0FBQTtBQUNsRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sb0JBQW9CLENBQUE7QUFDcEQsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sNkJBQTZCLENBQUE7QUFDbkUsT0FBTyxjQUFjLE1BQU0sMEJBQTBCLENBQUE7QUFxSHJELE1BQU0sQ0FBTixJQUFZLHNDQUtYO0FBTEQsV0FBWSxzQ0FBc0M7SUFDaEQsbURBQVMsQ0FBQTtJQUNULDJEQUFpQixDQUFBO0lBQ2pCLDJEQUFpQixDQUFBO0lBQ2pCLDJEQUFpQixDQUFBO0FBQ25CLENBQUMsRUFMVyxzQ0FBc0MsS0FBdEMsc0NBQXNDLFFBS2pEO0FBRUQsTUFBTSxDQUFOLElBQVkscUJBS1g7QUFMRCxXQUFZLHFCQUFxQjtJQUMvQixnREFBdUIsQ0FBQTtJQUN2Qiw4Q0FBcUIsQ0FBQTtJQUNyQiw4REFBcUMsQ0FBQTtJQUNyQywwQ0FBaUIsQ0FBQTtBQUNuQixDQUFDLEVBTFcscUJBQXFCLEtBQXJCLHFCQUFxQixRQUtoQztBQUVELE1BQU0sQ0FBTixJQUFZLHlCQUtYO0FBTEQsV0FBWSx5QkFBeUI7SUFDbkMsc0RBQXlCLENBQUE7SUFDekIsb0RBQXVCLENBQUE7SUFDdkIsOENBQWlCLENBQUE7SUFDakIsNERBQStCLENBQUE7QUFDakMsQ0FBQyxFQUxXLHlCQUF5QixLQUF6Qix5QkFBeUIsUUFLcEM7QUFFRCxNQUFNLENBQUMsTUFBTSx1QkFBdUIsR0FBRyxjQUFjLENBQUE7QUFvQnJEOzs7O0dBSUc7QUFDSCxNQUFNLENBQUMsT0FBTyxPQUFPLGVBQWU7SUFTbEMsSUFBSSxLQUFLO1FBQ1AsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQTtJQUNsQyxDQUFDO0lBRUQsSUFBSSxLQUFLLENBQUMsS0FBbUI7UUFDM0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFBO0lBQ25DLENBQUM7SUFFRCxJQUFJLFVBQVU7UUFDWixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFBO0lBQ3ZDLENBQUM7SUFFRCxJQUFJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFBO0lBQzVCLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDVixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFBO0lBQ3JDLENBQUM7SUFFRCxJQUFJLFdBQVc7UUFDYixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFBO0lBQ3hDLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTRCRztJQUNIO0lBQ0Usb0NBQW9DO0lBQzdCLEtBQWEsRUFDYixTQUFpQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFDL0MsTUFBc0I7O1FBRnRCLFVBQUssR0FBTCxLQUFLLENBQVE7UUFDYixXQUFNLEdBQU4sTUFBTSxDQUF5QztRQUMvQyxXQUFNLEdBQU4sTUFBTSxDQUFnQjtRQWpFL0IsYUFBUSxHQUE4QixFQUFFLENBQUE7UUFtRXRDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUE7UUFDaEQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLGlCQUNiO1lBQ0QsU0FBUyxFQUFFLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFO1lBQ3RDLFFBQVEsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRTtZQUNyQyxPQUFPLEVBQUUsS0FBSztTQUNmLEVBQ0UsTUFBTSxDQUFDLE1BQU0sQ0FDakIsQ0FBQTtRQUVELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUN2RixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUE7UUFFMUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUU7WUFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDM0IsQ0FBQyxDQUFDLENBQUE7UUFFRixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQTtRQUU3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUE7UUFDcEYsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFBO1FBRWxELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxLQUFJLE1BQUEsTUFBQSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sMENBQUUsU0FBUywwQ0FBRSxNQUFNLENBQUEsRUFBRSxDQUFDO1lBQzNELE1BQU0sSUFBSSxLQUFLLENBQ2IsMENBQTBDLElBQUksQ0FBQyxLQUFLLGtDQUFrQyxDQUN2RixDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Ba0JHO0lBQ0gsU0FBUyxDQUNQLFFBQW1FLEVBQ25FLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTzs7UUFFdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFBO1FBQ3ZCLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQztZQUNuQyxNQUFNLEVBQ0osTUFBTSxFQUFFLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLEdBQ3BELEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQTtZQUVmLE1BQU0sZ0JBQWdCLEdBQUcsTUFBQSxNQUFBLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLDBDQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQ0FBSSxFQUFFLENBQUE7WUFFbkYsTUFBTSxnQkFBZ0IsR0FDcEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUM7Z0JBQzlDLElBQUksQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQkFDM0QsQ0FBQSxNQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsMENBQUUsT0FBTyxNQUFLLElBQUksQ0FBQTtZQUMvQyxNQUFNLGtCQUFrQixHQUE4QixFQUFFLENBQUE7WUFDeEQsTUFBTSxNQUFNLEdBQUc7Z0JBQ2IsU0FBUztnQkFDVCxRQUFRLGtDQUFPLFFBQVEsS0FBRSxPQUFPLEVBQUUsZ0JBQWdCLEdBQUU7Z0JBQ3BELGdCQUFnQjtnQkFDaEIsT0FBTyxFQUFFLFNBQVM7YUFDbkIsQ0FBQTtZQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUNqQyxrQkFBa0IsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQTtZQUNoRSxDQUFDO1lBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQWUsRUFBRSxFQUFFO2dCQUNoQyxRQUFRLGFBQVIsUUFBUSx1QkFBUixRQUFRLENBQUcseUJBQXlCLENBQUMsYUFBYSxFQUFFLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUE7WUFDcEYsQ0FBQyxDQUFDLENBQUE7WUFFRixJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsYUFBUixRQUFRLHVCQUFSLFFBQVEsQ0FBRyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFBO1lBRWpFLElBQUksQ0FBQyxpQkFBaUIsZUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFLLGtCQUFrQixFQUFHLENBQUE7WUFFaEUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUE7WUFFM0IsSUFBSSxDQUFDLGNBQWM7aUJBQ2hCLFNBQVMsQ0FBQyxPQUFPLENBQUM7aUJBQ2xCLE9BQU8sQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsZ0JBQWdCLEVBQTBCLEVBQUUsRUFBRTtnQkFDcEUsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDO29CQUNsQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFBO2dCQUN2QixDQUFDO2dCQUNELElBQUksZ0JBQWdCLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ25DLFFBQVEsYUFBUixRQUFRLHVCQUFSLFFBQVEsQ0FBRyx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsQ0FBQTtvQkFDaEQsT0FBTTtnQkFDUixDQUFDO2dCQUVELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUMsQ0FBQTtZQUMxRCxDQUFDLENBQUM7aUJBQ0QsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQTZCLEVBQUUsRUFBRTtnQkFDbEQsSUFBSSxDQUFDLEtBQUssR0FBRyxjQUFjLENBQUMsT0FBTyxDQUFBO2dCQUNuQyxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQUE7Z0JBQzFELFFBQVEsYUFBUixRQUFRLHVCQUFSLFFBQVEsQ0FBRyx5QkFBeUIsQ0FBQyxhQUFhLEVBQUUsSUFBSSxLQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUMzRixDQUFDLENBQUM7aUJBQ0QsT0FBTyxDQUFDLFNBQVMsRUFBRSxHQUFHLEVBQUU7Z0JBQ3ZCLFFBQVEsYUFBUixRQUFRLHVCQUFSLFFBQVEsQ0FBRyx5QkFBeUIsQ0FBQyxTQUFTLENBQUMsQ0FBQTtZQUNqRCxDQUFDLENBQUMsQ0FBQTtRQUNOLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQTtJQUNiLENBQUM7SUFFTyx1QkFBdUIsQ0FDN0IsZ0JBQTRELEVBQzVELFFBQW1FOztRQUVuRSxNQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUE7UUFDN0QsTUFBTSxXQUFXLEdBQUcsTUFBQSxzQkFBc0IsYUFBdEIsc0JBQXNCLHVCQUF0QixzQkFBc0IsQ0FBRSxNQUFNLG1DQUFJLENBQUMsQ0FBQTtRQUN2RCxNQUFNLG1CQUFtQixHQUFHLEVBQUUsQ0FBQTtRQUU5QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDckMsTUFBTSxxQkFBcUIsR0FBRyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUN2RCxNQUFNLEVBQ0osTUFBTSxFQUFFLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQ3pDLEdBQUcscUJBQXFCLENBQUE7WUFDekIsTUFBTSxvQkFBb0IsR0FBRyxnQkFBZ0IsSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUVwRSxJQUNFLG9CQUFvQjtnQkFDcEIsb0JBQW9CLENBQUMsS0FBSyxLQUFLLEtBQUs7Z0JBQ3BDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDO2dCQUN2RSxlQUFlLENBQUMsa0JBQWtCLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQztnQkFDckUsZUFBZSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsRUFDdkUsQ0FBQztnQkFDRCxtQkFBbUIsQ0FBQyxJQUFJLGlDQUNuQixxQkFBcUIsS0FDeEIsRUFBRSxFQUFFLG9CQUFvQixDQUFDLEVBQUUsSUFDM0IsQ0FBQTtZQUNKLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUE7Z0JBQ2xCLElBQUksQ0FBQyxLQUFLLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQTtnQkFFbkMsUUFBUSxhQUFSLFFBQVEsdUJBQVIsUUFBUSxDQUNOLHlCQUF5QixDQUFDLGFBQWEsRUFDdkMsSUFBSSxLQUFLLENBQUMsa0VBQWtFLENBQUMsQ0FDOUUsQ0FBQTtnQkFDRCxPQUFNO1lBQ1IsQ0FBQztRQUNILENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixHQUFHLG1CQUFtQixDQUFBO1FBRXBELElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxjQUFjLENBQUMsT0FBTyxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQ3JELFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUNoRCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxhQUFhO1FBQ1gsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQWlDLENBQUE7SUFDeEQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsS0FBSyxDQUFDLEtBQUssQ0FDVCxPQUErQixFQUMvQixPQUErQixFQUFFO1FBRWpDLE9BQU8sTUFBTSxJQUFJLENBQUMsSUFBSSxDQUNwQjtZQUNFLElBQUksRUFBRSxVQUFVO1lBQ2hCLEtBQUssRUFBRSxPQUFPO1lBQ2QsT0FBTztTQUNSLEVBQ0QsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUM3QixDQUFBO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQStCLEVBQUU7UUFDN0MsT0FBTyxNQUFNLElBQUksQ0FBQyxJQUFJLENBQ3BCO1lBQ0UsSUFBSSxFQUFFLFVBQVU7WUFDaEIsS0FBSyxFQUFFLFNBQVM7U0FDakIsRUFDRCxJQUFJLENBQ0wsQ0FBQTtJQUNILENBQUM7SUEySEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BOEpHO0lBQ0gsRUFBRSxDQUNBLElBQWdDLEVBQ2hDLE1BQWdELEVBQ2hELFFBQWdDO1FBRWhDLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQTtRQUNwRixNQUFNLFNBQVMsR0FDYixJQUFJLEtBQUsscUJBQXFCLENBQUMsUUFBUSxJQUFJLElBQUksS0FBSyxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQTtRQUU1RixJQUFJLFVBQVUsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FDYixTQUFTLEVBQ1QsZ0JBQWdCLElBQUksb0JBQW9CLElBQUksQ0FBQyxLQUFLLHlCQUF5QixDQUM1RSxDQUFBO1lBQ0QsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsSUFBSSxvQkFBb0IsSUFBSSxDQUFDLEtBQUsseUJBQXlCLENBQUMsQ0FBQTtRQUM5RixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUE7SUFDekMsQ0FBQztJQUNEOzs7Ozs7Ozs7Ozs7Ozs7T0FlRztJQUNILEtBQUssQ0FBQyxRQUFRLENBQ1osS0FBYSxFQUNiLE9BQVksRUFDWixPQUE2QixFQUFFOztRQUUvQixJQUFJLE9BQU8sS0FBSyxTQUFTLElBQUksT0FBTyxLQUFLLElBQUksRUFBRSxDQUFDO1lBQzlDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUE7UUFDeEUsQ0FBQztRQUVELE1BQU0sUUFBUSxHQUFHLE9BQU8sWUFBWSxXQUFXLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUU5RSxNQUFNLE9BQU8sR0FBMkI7WUFDdEMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNwRCxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsa0JBQWtCO1NBQzNFLENBQUE7UUFFRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUNqQyxPQUFPLENBQUMsZUFBZSxDQUFDLEdBQUcsVUFBVSxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUE7UUFDckUsQ0FBQztRQUVELE1BQU0sR0FBRyxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFBO1FBQzlDLEdBQUcsQ0FBQyxRQUFRLElBQUksSUFBSSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsa0JBQWtCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQTtRQUMzRixJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNqQixHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUE7UUFDekMsQ0FBQztRQUVELE1BQU0sT0FBTyxHQUFHO1lBQ2QsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPO1lBQ1AsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUUsT0FBeUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7U0FDdEYsQ0FBQTtRQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUMzQyxHQUFHLENBQUMsUUFBUSxFQUFFLEVBQ2QsT0FBTyxFQUNQLE1BQUEsSUFBSSxDQUFDLE9BQU8sbUNBQUksSUFBSSxDQUFDLE9BQU8sQ0FDN0IsQ0FBQTtRQUVELElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUM1QixPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFBO1FBQzFCLENBQUM7UUFFRCxJQUFJLFlBQVksR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFBO1FBQ3RDLElBQUksQ0FBQztZQUNILE1BQU0sU0FBUyxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFBO1lBQ3ZDLFlBQVksR0FBRyxTQUFTLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxPQUFPLElBQUksWUFBWSxDQUFBO1FBQ3JFLENBQUM7UUFBQyxXQUFNLENBQUMsQ0FBQSxDQUFDO1FBRVYsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUE7SUFDaEQsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQStDRztJQUNILEtBQUssQ0FBQyxJQUFJLENBQ1IsSUFLQyxFQUNELE9BQStCLEVBQUU7O1FBRWpDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFLENBQUM7WUFDaEUsT0FBTyxDQUFDLElBQUksQ0FDViw2REFBNkQ7Z0JBQzNELGtEQUFrRDtnQkFDbEQscURBQXFELENBQ3hELENBQUE7WUFFRCxNQUFNLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLElBQUksQ0FBQTtZQUNqRCxNQUFNLE9BQU8sR0FBMkI7Z0JBQ3RDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BELGNBQWMsRUFBRSxrQkFBa0I7YUFDbkMsQ0FBQTtZQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUNqQyxPQUFPLENBQUMsZUFBZSxDQUFDLEdBQUcsVUFBVSxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUE7WUFDckUsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFHO2dCQUNkLE1BQU0sRUFBRSxNQUFNO2dCQUNkLE9BQU87Z0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7b0JBQ25CLFFBQVEsRUFBRTt3QkFDUjs0QkFDRSxLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVE7NEJBQ3BCLEtBQUs7NEJBQ0wsT0FBTyxFQUFFLGdCQUFnQjs0QkFDekIsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO3lCQUN0QjtxQkFDRjtpQkFDRixDQUFDO2FBQ0gsQ0FBQTtZQUVELElBQUksQ0FBQztnQkFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FDM0MsSUFBSSxDQUFDLG9CQUFvQixFQUN6QixPQUFPLEVBQ1AsTUFBQSxJQUFJLENBQUMsT0FBTyxtQ0FBSSxJQUFJLENBQUMsT0FBTyxDQUM3QixDQUFBO2dCQUVELE1BQU0sQ0FBQSxNQUFBLFFBQVEsQ0FBQyxJQUFJLDBDQUFFLE1BQU0sRUFBRSxDQUFBLENBQUE7Z0JBQzdCLE9BQU8sUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUE7WUFDckMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssWUFBWSxFQUFFLENBQUM7b0JBQzFELE9BQU8sV0FBVyxDQUFBO2dCQUNwQixDQUFDO3FCQUFNLENBQUM7b0JBQ04sT0FBTyxPQUFPLENBQUE7Z0JBQ2hCLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUU7O2dCQUM3QixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFFcEYsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDLENBQUEsTUFBQSxNQUFBLE1BQUEsSUFBSSxDQUFDLE1BQU0sMENBQUUsTUFBTSwwQ0FBRSxTQUFTLDBDQUFFLEdBQUcsQ0FBQSxFQUFFLENBQUM7b0JBQ3RFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtnQkFDZixDQUFDO2dCQUVELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO2dCQUN2QyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtnQkFDN0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUE7WUFDckQsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsaUJBQWlCLENBQUMsT0FBNEI7UUFDNUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQTtJQUNoRCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILEtBQUssQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPO1FBQ3RDLE9BQU8sSUFBSSxPQUFPLENBQThCLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDMUQsSUFBSSxDQUFDLGNBQWM7aUJBQ2hCLFdBQVcsQ0FBQyxPQUFPLENBQUM7aUJBQ3BCLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNsQyxPQUFPLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDOUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtRQUM3QyxDQUFDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLENBQUE7SUFDaEMsQ0FBQztJQUVELGdCQUFnQjtJQUNoQixLQUFLLENBQUMsaUJBQWlCLENBQUMsR0FBVyxFQUFFLE9BQStCLEVBQUUsT0FBZTtRQUNuRixNQUFNLFVBQVUsR0FBRyxJQUFJLGVBQWUsRUFBRSxDQUFBO1FBQ3hDLE1BQU0sRUFBRSxHQUFHLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFFeEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLGtDQUN2QyxPQUFPLEtBQ1YsTUFBTSxFQUFFLFVBQVUsQ0FBQyxNQUFNLElBQ3pCLENBQUE7UUFFRixZQUFZLENBQUMsRUFBRSxDQUFDLENBQUE7UUFFaEIsT0FBTyxRQUFRLENBQUE7SUFDakIsQ0FBQztJQUVELGdCQUFnQjtJQUNoQixHQUFHLENBQUMsSUFBWSxFQUFFLE1BQThCLEVBQUUsUUFBZ0M7UUFDaEYsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUE7UUFFMUMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFBO1FBRWxELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLElBQUksRUFBRSxTQUFTO1lBQ2YsTUFBTSxFQUFFLE1BQU07WUFDZCxRQUFRLEVBQUUsUUFBUTtZQUNsQixHQUFHLEVBQUUsR0FBRztTQUNULENBQUE7UUFFRCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUN4QyxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUN0QyxDQUFDO1FBRUQsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUE7UUFFM0IsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLFFBQVEsQ0FBQyxRQUFnQztRQUMvQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN2QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLFFBQVEsQ0FBQyxRQUFnQztRQUMvQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN2QyxDQUFDO0lBRUQsZ0JBQWdCO0lBQ1Isb0JBQW9CO1FBQzFCLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLEVBQUUsT0FBWSxFQUFFLEdBQUcsRUFBRSxFQUFFOztZQUN0RSxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLENBQUE7WUFFbkQsSUFBSSxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzlDLE9BQU8sS0FBSyxDQUFBO1lBQ2QsQ0FBQztZQUVELE1BQU0sSUFBSSxHQUFHLE1BQUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsMENBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQTtZQUUvRSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ1YsT0FBTyxJQUFJLENBQUE7WUFDYixDQUFDO1lBRUQsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFVLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztnQkFDdEUsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUE7b0JBQ3RCLE1BQU0sU0FBUyxHQUFHLE1BQUEsSUFBSSxDQUFDLE1BQU0sMENBQUUsS0FBSyxDQUFBO29CQUNwQyxPQUFPLENBQ0wsTUFBTTt5QkFDTixNQUFBLE9BQU8sQ0FBQyxHQUFHLDBDQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQTt3QkFDN0IsQ0FBQyxTQUFTLEtBQUssR0FBRzs0QkFDaEIsQ0FBQSxTQUFTLGFBQVQsU0FBUyx1QkFBVCxTQUFTLENBQUUsaUJBQWlCLEVBQUUsT0FBSyxNQUFBLE9BQU8sQ0FBQyxJQUFJLDBDQUFFLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFBLENBQUMsQ0FDN0UsQ0FBQTtnQkFDSCxDQUFDO3FCQUFNLENBQUM7b0JBQ04sTUFBTSxTQUFTLEdBQUcsTUFBQSxNQUFBLElBQUksYUFBSixJQUFJLHVCQUFKLElBQUksQ0FBRSxNQUFNLDBDQUFFLEtBQUssMENBQUUsaUJBQWlCLEVBQUUsQ0FBQTtvQkFDMUQsT0FBTyxTQUFTLEtBQUssR0FBRyxJQUFJLFNBQVMsTUFBSyxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxLQUFLLDBDQUFFLGlCQUFpQixFQUFFLENBQUEsQ0FBQTtnQkFDL0UsQ0FBQztZQUNILENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxTQUFTLENBQUE7WUFDcEQsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELGdCQUFnQjtJQUNSLG9CQUFvQixDQUFDLEtBQWEsRUFBRSxHQUFtQjtRQUM3RCxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsY0FBYyxDQUFBO1FBQ3BELE1BQU0sTUFBTSxHQUFhLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUE7UUFDcEQsT0FBTyxHQUFHLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUE7SUFDbkUsQ0FBQztJQUVELGdCQUFnQjtJQUNSLHNCQUFzQjtRQUM1QixJQUFJLENBQUMsY0FBYyxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBSyxFQUFFLE9BQVksRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUN0RSxJQUFJLE9BQU8sT0FBTyxLQUFLLFFBQVEsSUFBSSxLQUFLLElBQUksT0FBTyxFQUFFLENBQUM7Z0JBQ3BELE1BQU0sZUFBZSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUE7Z0JBQ3BDLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLGdCQUFnQixFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxlQUFlLENBQUE7Z0JBQ3pFLE1BQU0sZUFBZSxHQUFHO29CQUN0QixNQUFNLEVBQUUsTUFBTTtvQkFDZCxLQUFLLEVBQUUsS0FBSztvQkFDWixnQkFBZ0IsRUFBRSxnQkFBZ0I7b0JBQ2xDLFNBQVMsRUFBRSxJQUFJO29CQUNmLEdBQUcsRUFBRSxFQUFFO29CQUNQLEdBQUcsRUFBRSxFQUFFO29CQUNQLE1BQU0sRUFBRSxNQUFNO2lCQUNmLENBQUE7Z0JBQ0QsdUNBQ0ssZUFBZSxHQUNmLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsRUFDNUM7WUFDSCxDQUFDO1lBRUQsT0FBTyxPQUFPLENBQUE7UUFDaEIsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQXNCO1FBQ2pDLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLE1BQU0sSUFBSSxLQUFLLENBQUMsMENBQTBDLENBQUMsQ0FBQTtRQUM3RCxDQUFDO1FBQ0QsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbEMsS0FBSyxNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtZQUMxRCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssTUFBTSxDQUFDLGtCQUFrQixDQUMvQixXQUFzQyxFQUN0QyxXQUErQjtRQUUvQixNQUFNLGdCQUFnQixHQUFHLFdBQVcsYUFBWCxXQUFXLGNBQVgsV0FBVyxHQUFJLFNBQVMsQ0FBQTtRQUNqRCxNQUFNLGdCQUFnQixHQUFHLFdBQVcsYUFBWCxXQUFXLGNBQVgsV0FBVyxHQUFJLFNBQVMsQ0FBQTtRQUNqRCxPQUFPLGdCQUFnQixLQUFLLGdCQUFnQixDQUFBO0lBQzlDLENBQUM7SUFFRCxnQkFBZ0I7SUFDUixrQkFBa0IsQ0FBQyxPQUFZO1FBQ3JDLE1BQU0sT0FBTyxHQUFHO1lBQ2QsR0FBRyxFQUFFLEVBQUU7WUFDUCxHQUFHLEVBQUUsRUFBRTtTQUNSLENBQUE7UUFFRCxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssUUFBUSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDM0QsT0FBTyxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDL0UsQ0FBQztRQUVELElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUMzRCxPQUFPLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUNuRixDQUFDO1FBRUQsT0FBTyxPQUFPLENBQUE7SUFDaEIsQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ0hBTk5FTF9FVkVOVFMsIENIQU5ORUxfU1RBVEVTIH0gZnJvbSAnLi9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHR5cGUgeyBDaGFubmVsU3RhdGUgfSBmcm9tICcuL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgdHlwZSBSZWFsdGltZUNsaWVudCBmcm9tICcuL1JlYWx0aW1lQ2xpZW50J1xuaW1wb3J0IFJlYWx0aW1lUHJlc2VuY2UsIHsgUkVBTFRJTUVfUFJFU0VOQ0VfTElTVEVOX0VWRU5UUyB9IGZyb20gJy4vUmVhbHRpbWVQcmVzZW5jZSdcbmltcG9ydCB0eXBlIHtcbiAgUmVhbHRpbWVQcmVzZW5jZUpvaW5QYXlsb2FkLFxuICBSZWFsdGltZVByZXNlbmNlTGVhdmVQYXlsb2FkLFxuICBSZWFsdGltZVByZXNlbmNlU3RhdGUsXG59IGZyb20gJy4vUmVhbHRpbWVQcmVzZW5jZSdcbmltcG9ydCAqIGFzIFRyYW5zZm9ybWVycyBmcm9tICcuL2xpYi90cmFuc2Zvcm1lcnMnXG5pbXBvcnQgeyBodHRwRW5kcG9pbnRVUkwgfSBmcm9tICcuL2xpYi90cmFuc2Zvcm1lcnMnXG5pbXBvcnQgeyBub3JtYWxpemVDaGFubmVsRXJyb3IgfSBmcm9tICcuL2xpYi9ub3JtYWxpemVDaGFubmVsRXJyb3InXG5pbXBvcnQgQ2hhbm5lbEFkYXB0ZXIgZnJvbSAnLi9waG9lbml4L2NoYW5uZWxBZGFwdGVyJ1xuaW1wb3J0IHsgQ2hhbm5lbEJpbmRpbmdDYWxsYmFjaywgQ2hhbm5lbE9uRXJyb3JDYWxsYmFjayB9IGZyb20gJy4vcGhvZW5peC90eXBlcydcbmltcG9ydCB0eXBlIHsgVGltZXIgfSBmcm9tICcuL3Bob2VuaXgvdHlwZXMnXG5cbnR5cGUgUmVwbGF5T3B0aW9uID0ge1xuICBzaW5jZTogbnVtYmVyXG4gIGxpbWl0PzogbnVtYmVyXG59XG5cbmV4cG9ydCB0eXBlIFJlYWx0aW1lQ2hhbm5lbE9wdGlvbnMgPSB7XG4gIGNvbmZpZzoge1xuICAgIC8qKlxuICAgICAqIHNlbGYgb3B0aW9uIGVuYWJsZXMgY2xpZW50IHRvIHJlY2VpdmUgbWVzc2FnZSBpdCBicm9hZGNhc3RcbiAgICAgKiBhY2sgb3B0aW9uIGluc3RydWN0cyBzZXJ2ZXIgdG8gYWNrbm93bGVkZ2UgdGhhdCBicm9hZGNhc3QgbWVzc2FnZSB3YXMgcmVjZWl2ZWRcbiAgICAgKiByZXBsYXkgb3B0aW9uIGluc3RydWN0cyBzZXJ2ZXIgdG8gcmVwbGF5IGJyb2FkY2FzdCBtZXNzYWdlc1xuICAgICAqL1xuICAgIGJyb2FkY2FzdD86IHsgc2VsZj86IGJvb2xlYW47IGFjaz86IGJvb2xlYW47IHJlcGxheT86IFJlcGxheU9wdGlvbiB9XG4gICAgLyoqXG4gICAgICoga2V5IG9wdGlvbiBpcyB1c2VkIHRvIHRyYWNrIHByZXNlbmNlIHBheWxvYWQgYWNyb3NzIGNsaWVudHNcbiAgICAgKi9cbiAgICBwcmVzZW5jZT86IHsga2V5Pzogc3RyaW5nOyBlbmFibGVkPzogYm9vbGVhbiB9XG4gICAgLyoqXG4gICAgICogZGVmaW5lcyBpZiB0aGUgY2hhbm5lbCBpcyBwcml2YXRlIG9yIG5vdCBhbmQgaWYgUkxTIHBvbGljaWVzIHdpbGwgYmUgdXNlZCB0byBjaGVjayBkYXRhXG4gICAgICovXG4gICAgcHJpdmF0ZT86IGJvb2xlYW5cbiAgfVxufVxuXG50eXBlIFJlYWx0aW1lQ2hhbmdlc1BheWxvYWRCYXNlID0ge1xuICBzY2hlbWE6IHN0cmluZ1xuICB0YWJsZTogc3RyaW5nXG59XG5cbnR5cGUgUmVhbHRpbWVCcm9hZGNhc3RDaGFuZ2VzUGF5bG9hZEJhc2UgPSBSZWFsdGltZUNoYW5nZXNQYXlsb2FkQmFzZSAmIHtcbiAgaWQ6IHN0cmluZ1xufVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZUJyb2FkY2FzdEluc2VydFBheWxvYWQ8VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+ID1cbiAgUmVhbHRpbWVCcm9hZGNhc3RDaGFuZ2VzUGF5bG9hZEJhc2UgJiB7XG4gICAgb3BlcmF0aW9uOiBgJHtSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5JTlNFUlR9YFxuICAgIHJlY29yZDogVFxuICAgIG9sZF9yZWNvcmQ6IG51bGxcbiAgfVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZUJyb2FkY2FzdFVwZGF0ZVBheWxvYWQ8VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+ID1cbiAgUmVhbHRpbWVCcm9hZGNhc3RDaGFuZ2VzUGF5bG9hZEJhc2UgJiB7XG4gICAgb3BlcmF0aW9uOiBgJHtSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5VUERBVEV9YFxuICAgIHJlY29yZDogVFxuICAgIG9sZF9yZWNvcmQ6IFRcbiAgfVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZUJyb2FkY2FzdERlbGV0ZVBheWxvYWQ8VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+ID1cbiAgUmVhbHRpbWVCcm9hZGNhc3RDaGFuZ2VzUGF5bG9hZEJhc2UgJiB7XG4gICAgb3BlcmF0aW9uOiBgJHtSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5ERUxFVEV9YFxuICAgIHJlY29yZDogbnVsbFxuICAgIG9sZF9yZWNvcmQ6IFRcbiAgfVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZUJyb2FkY2FzdFBheWxvYWQ8VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+ID1cbiAgfCBSZWFsdGltZUJyb2FkY2FzdEluc2VydFBheWxvYWQ8VD5cbiAgfCBSZWFsdGltZUJyb2FkY2FzdFVwZGF0ZVBheWxvYWQ8VD5cbiAgfCBSZWFsdGltZUJyb2FkY2FzdERlbGV0ZVBheWxvYWQ8VD5cblxudHlwZSBSZWFsdGltZVBvc3RncmVzQ2hhbmdlc1BheWxvYWRCYXNlID0ge1xuICBzY2hlbWE6IHN0cmluZ1xuICB0YWJsZTogc3RyaW5nXG4gIGNvbW1pdF90aW1lc3RhbXA6IHN0cmluZ1xuICBlcnJvcnM6IHN0cmluZ1tdXG59XG5cbmV4cG9ydCB0eXBlIFJlYWx0aW1lUG9zdGdyZXNJbnNlcnRQYXlsb2FkPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PiA9XG4gIFJlYWx0aW1lUG9zdGdyZXNDaGFuZ2VzUGF5bG9hZEJhc2UgJiB7XG4gICAgZXZlbnRUeXBlOiBgJHtSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5JTlNFUlR9YFxuICAgIG5ldzogVFxuICAgIG9sZDoge31cbiAgfVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZVBvc3RncmVzVXBkYXRlUGF5bG9hZDxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfT4gPVxuICBSZWFsdGltZVBvc3RncmVzQ2hhbmdlc1BheWxvYWRCYXNlICYge1xuICAgIGV2ZW50VHlwZTogYCR7UkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlQuVVBEQVRFfWBcbiAgICBuZXc6IFRcbiAgICBvbGQ6IFBhcnRpYWw8VD5cbiAgfVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZVBvc3RncmVzRGVsZXRlUGF5bG9hZDxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfT4gPVxuICBSZWFsdGltZVBvc3RncmVzQ2hhbmdlc1BheWxvYWRCYXNlICYge1xuICAgIGV2ZW50VHlwZTogYCR7UkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlQuREVMRVRFfWBcbiAgICBuZXc6IHt9XG4gICAgb2xkOiBQYXJ0aWFsPFQ+XG4gIH1cblxuZXhwb3J0IHR5cGUgUmVhbHRpbWVQb3N0Z3Jlc0NoYW5nZXNQYXlsb2FkPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PiA9XG4gIHwgUmVhbHRpbWVQb3N0Z3Jlc0luc2VydFBheWxvYWQ8VD5cbiAgfCBSZWFsdGltZVBvc3RncmVzVXBkYXRlUGF5bG9hZDxUPlxuICB8IFJlYWx0aW1lUG9zdGdyZXNEZWxldGVQYXlsb2FkPFQ+XG5cbmV4cG9ydCB0eXBlIFJlYWx0aW1lUG9zdGdyZXNDaGFuZ2VzRmlsdGVyPFQgZXh0ZW5kcyBgJHtSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVH1gPiA9IHtcbiAgLyoqXG4gICAqIFRoZSB0eXBlIG9mIGRhdGFiYXNlIGNoYW5nZSB0byBsaXN0ZW4gdG8uXG4gICAqL1xuICBldmVudDogVFxuICAvKipcbiAgICogVGhlIGRhdGFiYXNlIHNjaGVtYSB0byBsaXN0ZW4gdG8uXG4gICAqL1xuICBzY2hlbWE6IHN0cmluZ1xuICAvKipcbiAgICogVGhlIGRhdGFiYXNlIHRhYmxlIHRvIGxpc3RlbiB0by5cbiAgICovXG4gIHRhYmxlPzogc3RyaW5nXG4gIC8qKlxuICAgKiBSZWNlaXZlIGRhdGFiYXNlIGNoYW5nZXMgd2hlbiBmaWx0ZXIgaXMgbWF0Y2hlZC5cbiAgICovXG4gIGZpbHRlcj86IHN0cmluZ1xufVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZUNoYW5uZWxTZW5kUmVzcG9uc2UgPSAnb2snIHwgJ3RpbWVkIG91dCcgfCAnZXJyb3InIHwgKHN0cmluZyAmIHt9KVxuXG5leHBvcnQgZW51bSBSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVCB7XG4gIEFMTCA9ICcqJyxcbiAgSU5TRVJUID0gJ0lOU0VSVCcsXG4gIFVQREFURSA9ICdVUERBVEUnLFxuICBERUxFVEUgPSAnREVMRVRFJyxcbn1cblxuZXhwb3J0IGVudW0gUkVBTFRJTUVfTElTVEVOX1RZUEVTIHtcbiAgQlJPQURDQVNUID0gJ2Jyb2FkY2FzdCcsXG4gIFBSRVNFTkNFID0gJ3ByZXNlbmNlJyxcbiAgUE9TVEdSRVNfQ0hBTkdFUyA9ICdwb3N0Z3Jlc19jaGFuZ2VzJyxcbiAgU1lTVEVNID0gJ3N5c3RlbScsXG59XG5cbmV4cG9ydCBlbnVtIFJFQUxUSU1FX1NVQlNDUklCRV9TVEFURVMge1xuICBTVUJTQ1JJQkVEID0gJ1NVQlNDUklCRUQnLFxuICBUSU1FRF9PVVQgPSAnVElNRURfT1VUJyxcbiAgQ0xPU0VEID0gJ0NMT1NFRCcsXG4gIENIQU5ORUxfRVJST1IgPSAnQ0hBTk5FTF9FUlJPUicsXG59XG5cbmV4cG9ydCBjb25zdCBSRUFMVElNRV9DSEFOTkVMX1NUQVRFUyA9IENIQU5ORUxfU1RBVEVTXG5cbnR5cGUgUG9zdGdyZXNDaGFuZ2VzRmlsdGVycyA9IHtcbiAgcG9zdGdyZXNfY2hhbmdlczoge1xuICAgIGlkOiBzdHJpbmdcbiAgICBldmVudDogc3RyaW5nXG4gICAgc2NoZW1hPzogc3RyaW5nXG4gICAgdGFibGU/OiBzdHJpbmdcbiAgICBmaWx0ZXI/OiBzdHJpbmdcbiAgfVtdXG59XG5cbnR5cGUgQmluZGluZyA9IHtcbiAgdHlwZTogc3RyaW5nXG4gIGZpbHRlcjogeyBba2V5OiBzdHJpbmddOiBhbnkgfVxuICBjYWxsYmFjazogQ2hhbm5lbEJpbmRpbmdDYWxsYmFja1xuICByZWY6IG51bWJlclxuICBpZD86IHN0cmluZ1xufVxuXG4vKiogQSBjaGFubmVsIGlzIHRoZSBiYXNpYyBidWlsZGluZyBibG9jayBvZiBSZWFsdGltZVxuICogYW5kIG5hcnJvd3MgdGhlIHNjb3BlIG9mIGRhdGEgZmxvdyB0byBzdWJzY3JpYmVkIGNsaWVudHMuXG4gKiBZb3UgY2FuIHRoaW5rIG9mIGEgY2hhbm5lbCBhcyBhIGNoYXRyb29tIHdoZXJlIHBhcnRpY2lwYW50cyBhcmUgYWJsZSB0byBzZWUgd2hvJ3Mgb25saW5lXG4gKiBhbmQgc2VuZCBhbmQgcmVjZWl2ZSBtZXNzYWdlcy5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVhbHRpbWVDaGFubmVsIHtcbiAgYmluZGluZ3M6IFJlY29yZDxzdHJpbmcsIEJpbmRpbmdbXT4gPSB7fVxuICBzdWJUb3BpYzogc3RyaW5nXG4gIGJyb2FkY2FzdEVuZHBvaW50VVJMOiBzdHJpbmdcbiAgcHJpdmF0ZTogYm9vbGVhblxuICBwcmVzZW5jZTogUmVhbHRpbWVQcmVzZW5jZVxuICAvKiogQGludGVybmFsICovXG4gIGNoYW5uZWxBZGFwdGVyOiBDaGFubmVsQWRhcHRlclxuXG4gIGdldCBzdGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5jaGFubmVsQWRhcHRlci5zdGF0ZVxuICB9XG5cbiAgc2V0IHN0YXRlKHN0YXRlOiBDaGFubmVsU3RhdGUpIHtcbiAgICB0aGlzLmNoYW5uZWxBZGFwdGVyLnN0YXRlID0gc3RhdGVcbiAgfVxuXG4gIGdldCBqb2luZWRPbmNlKCkge1xuICAgIHJldHVybiB0aGlzLmNoYW5uZWxBZGFwdGVyLmpvaW5lZE9uY2VcbiAgfVxuXG4gIGdldCB0aW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLnNvY2tldC50aW1lb3V0XG4gIH1cblxuICBnZXQgam9pblB1c2goKSB7XG4gICAgcmV0dXJuIHRoaXMuY2hhbm5lbEFkYXB0ZXIuam9pblB1c2hcbiAgfVxuXG4gIGdldCByZWpvaW5UaW1lcigpOiBUaW1lciB7XG4gICAgcmV0dXJuIHRoaXMuY2hhbm5lbEFkYXB0ZXIucmVqb2luVGltZXJcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgY2hhbm5lbCB0aGF0IGNhbiBicm9hZGNhc3QgbWVzc2FnZXMsIHN5bmMgcHJlc2VuY2UsIGFuZCBsaXN0ZW4gdG8gUG9zdGdyZXMgY2hhbmdlcy5cbiAgICpcbiAgICogVGhlIHRvcGljIGRldGVybWluZXMgd2hpY2ggcmVhbHRpbWUgc3RyZWFtIHlvdSBhcmUgc3Vic2NyaWJpbmcgdG8uIENvbmZpZyBvcHRpb25zIGxldCB5b3VcbiAgICogZW5hYmxlIGFja25vd2xlZGdlbWVudCBmb3IgYnJvYWRjYXN0cywgcHJlc2VuY2UgdHJhY2tpbmcsIG9yIHByaXZhdGUgY2hhbm5lbHMuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKlxuICAgKiBAZXhhbXBsZSBVc2luZyBzdXBhYmFzZS1qcyAocmVjb21tZW5kZWQpXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcydcbiAgICpcbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jbycsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScpXG4gICAqIGNvbnN0IGNoYW5uZWwgPSBzdXBhYmFzZS5jaGFubmVsKCdyb29tMScpXG4gICAqIGNoYW5uZWxcbiAgICogICAub24oJ2Jyb2FkY2FzdCcsIHsgZXZlbnQ6ICdjdXJzb3ItcG9zJyB9LCAocGF5bG9hZCkgPT4gY29uc29sZS5sb2cocGF5bG9hZCkpXG4gICAqICAgLnN1YnNjcmliZSgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTdGFuZGFsb25lIGltcG9ydCBmb3IgYnVuZGxlLXNlbnNpdGl2ZSBlbnZpcm9ubWVudHNcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IFJlYWx0aW1lQ2xpZW50IGZyb20gJ0BzdXBhYmFzZS9yZWFsdGltZS1qcydcbiAgICpcbiAgICogY29uc3QgY2xpZW50ID0gbmV3IFJlYWx0aW1lQ2xpZW50KCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28vcmVhbHRpbWUvdjEnLCB7XG4gICAqICAgcGFyYW1zOiB7IGFwaWtleTogJ3lvdXItcHVibGlzaGFibGUta2V5JyB9LFxuICAgKiB9KVxuICAgKiBjb25zdCBjaGFubmVsID0gbmV3IFJlYWx0aW1lQ2hhbm5lbCgncmVhbHRpbWU6cHVibGljOm1lc3NhZ2VzJywgeyBjb25maWc6IHt9IH0sIGNsaWVudClcbiAgICogYGBgXG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICAvKiogVG9waWMgbmFtZSBjYW4gYmUgYW55IHN0cmluZy4gKi9cbiAgICBwdWJsaWMgdG9waWM6IHN0cmluZyxcbiAgICBwdWJsaWMgcGFyYW1zOiBSZWFsdGltZUNoYW5uZWxPcHRpb25zID0geyBjb25maWc6IHt9IH0sXG4gICAgcHVibGljIHNvY2tldDogUmVhbHRpbWVDbGllbnRcbiAgKSB7XG4gICAgdGhpcy5zdWJUb3BpYyA9IHRvcGljLnJlcGxhY2UoL15yZWFsdGltZTovaSwgJycpXG4gICAgdGhpcy5wYXJhbXMuY29uZmlnID0ge1xuICAgICAgLi4ue1xuICAgICAgICBicm9hZGNhc3Q6IHsgYWNrOiBmYWxzZSwgc2VsZjogZmFsc2UgfSxcbiAgICAgICAgcHJlc2VuY2U6IHsga2V5OiAnJywgZW5hYmxlZDogZmFsc2UgfSxcbiAgICAgICAgcHJpdmF0ZTogZmFsc2UsXG4gICAgICB9LFxuICAgICAgLi4ucGFyYW1zLmNvbmZpZyxcbiAgICB9XG5cbiAgICB0aGlzLmNoYW5uZWxBZGFwdGVyID0gbmV3IENoYW5uZWxBZGFwdGVyKHRoaXMuc29ja2V0LnNvY2tldEFkYXB0ZXIsIHRvcGljLCB0aGlzLnBhcmFtcylcbiAgICB0aGlzLnByZXNlbmNlID0gbmV3IFJlYWx0aW1lUHJlc2VuY2UodGhpcylcblxuICAgIHRoaXMuX29uQ2xvc2UoKCkgPT4ge1xuICAgICAgdGhpcy5zb2NrZXQuX3JlbW92ZSh0aGlzKVxuICAgIH0pXG5cbiAgICB0aGlzLl91cGRhdGVGaWx0ZXJUcmFuc2Zvcm0oKVxuXG4gICAgdGhpcy5icm9hZGNhc3RFbmRwb2ludFVSTCA9IGh0dHBFbmRwb2ludFVSTCh0aGlzLnNvY2tldC5zb2NrZXRBZGFwdGVyLmVuZFBvaW50VVJMKCkpXG4gICAgdGhpcy5wcml2YXRlID0gdGhpcy5wYXJhbXMuY29uZmlnLnByaXZhdGUgfHwgZmFsc2VcblxuICAgIGlmICghdGhpcy5wcml2YXRlICYmIHRoaXMucGFyYW1zLmNvbmZpZz8uYnJvYWRjYXN0Py5yZXBsYXkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYHRyaWVkIHRvIHVzZSByZXBsYXkgb24gcHVibGljIGNoYW5uZWwgJyR7dGhpcy50b3BpY30nLiBJdCBtdXN0IGJlIGEgcHJpdmF0ZSBjaGFubmVsLmBcbiAgICAgIClcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU3Vic2NyaWJlIHJlZ2lzdGVycyB5b3VyIGNsaWVudCB3aXRoIHRoZSBzZXJ2ZXIuXG4gICAqXG4gICAqIFRoZSBvcHRpb25hbCBgY2FsbGJhY2tgIHJlY2VpdmVzIGEgYHN0YXR1c2AgYW5kLCBvbiBmYWlsdXJlLCBhbiBgZXJyYCBhcmd1bWVudC5cbiAgICogTG9nIHRoZSBmdWxsIGBlcnJgIHNvIGl0cyBgY2F1c2VgLCBgbmFtZWAsIGFuZCBhbnkgc3RydWN0dXJlZCBmaWVsZHMgYXJlbid0IGhpZGRlblxuICAgKiBiZWhpbmQgYGVyci5tZXNzYWdlYC5cbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqXG4gICAqIEBleGFtcGxlIEhhbmRsaW5nIGVycm9yc1xuICAgKiBgYGBqc1xuICAgKiBzdXBhYmFzZS5jaGFubmVsKCdyb29tMScpLnN1YnNjcmliZSgoc3RhdHVzLCBlcnIpID0+IHtcbiAgICogICBpZiAoc3RhdHVzID09PSAnQ0hBTk5FTF9FUlJPUicgfHwgc3RhdHVzID09PSAnVElNRURfT1VUJykge1xuICAgKiAgICAgLy8gTG9nIHRoZSBmdWxsIGVycm9yOiBpdHMgYGNhdXNlYCBvZnRlbiBob2xkcyB0aGUgdW5kZXJseWluZyByZWFzb24uXG4gICAqICAgICBjb25zb2xlLmVycm9yKHN0YXR1cywgZXJyKVxuICAgKiAgIH1cbiAgICogfSlcbiAgICogYGBgXG4gICAqL1xuICBzdWJzY3JpYmUoXG4gICAgY2FsbGJhY2s/OiAoc3RhdHVzOiBSRUFMVElNRV9TVUJTQ1JJQkVfU1RBVEVTLCBlcnI/OiBFcnJvcikgPT4gdm9pZCxcbiAgICB0aW1lb3V0ID0gdGhpcy50aW1lb3V0XG4gICk6IFJlYWx0aW1lQ2hhbm5lbCB7XG4gICAgaWYgKCF0aGlzLnNvY2tldC5pc0Nvbm5lY3RlZCgpKSB7XG4gICAgICB0aGlzLnNvY2tldC5jb25uZWN0KClcbiAgICB9XG4gICAgaWYgKHRoaXMuY2hhbm5lbEFkYXB0ZXIuaXNDbG9zZWQoKSkge1xuICAgICAgY29uc3Qge1xuICAgICAgICBjb25maWc6IHsgYnJvYWRjYXN0LCBwcmVzZW5jZSwgcHJpdmF0ZTogaXNQcml2YXRlIH0sXG4gICAgICB9ID0gdGhpcy5wYXJhbXNcblxuICAgICAgY29uc3QgcG9zdGdyZXNfY2hhbmdlcyA9IHRoaXMuYmluZGluZ3MucG9zdGdyZXNfY2hhbmdlcz8ubWFwKChyKSA9PiByLmZpbHRlcikgPz8gW11cblxuICAgICAgY29uc3QgcHJlc2VuY2VfZW5hYmxlZCA9XG4gICAgICAgICghIXRoaXMuYmluZGluZ3NbUkVBTFRJTUVfTElTVEVOX1RZUEVTLlBSRVNFTkNFXSAmJlxuICAgICAgICAgIHRoaXMuYmluZGluZ3NbUkVBTFRJTUVfTElTVEVOX1RZUEVTLlBSRVNFTkNFXS5sZW5ndGggPiAwKSB8fFxuICAgICAgICB0aGlzLnBhcmFtcy5jb25maWcucHJlc2VuY2U/LmVuYWJsZWQgPT09IHRydWVcbiAgICAgIGNvbnN0IGFjY2Vzc1Rva2VuUGF5bG9hZDogeyBhY2Nlc3NfdG9rZW4/OiBzdHJpbmcgfSA9IHt9XG4gICAgICBjb25zdCBjb25maWcgPSB7XG4gICAgICAgIGJyb2FkY2FzdCxcbiAgICAgICAgcHJlc2VuY2U6IHsgLi4ucHJlc2VuY2UsIGVuYWJsZWQ6IHByZXNlbmNlX2VuYWJsZWQgfSxcbiAgICAgICAgcG9zdGdyZXNfY2hhbmdlcyxcbiAgICAgICAgcHJpdmF0ZTogaXNQcml2YXRlLFxuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5zb2NrZXQuYWNjZXNzVG9rZW5WYWx1ZSkge1xuICAgICAgICBhY2Nlc3NUb2tlblBheWxvYWQuYWNjZXNzX3Rva2VuID0gdGhpcy5zb2NrZXQuYWNjZXNzVG9rZW5WYWx1ZVxuICAgICAgfVxuXG4gICAgICB0aGlzLl9vbkVycm9yKChyZWFzb246IHVua25vd24pID0+IHtcbiAgICAgICAgY2FsbGJhY2s/LihSRUFMVElNRV9TVUJTQ1JJQkVfU1RBVEVTLkNIQU5ORUxfRVJST1IsIG5vcm1hbGl6ZUNoYW5uZWxFcnJvcihyZWFzb24pKVxuICAgICAgfSlcblxuICAgICAgdGhpcy5fb25DbG9zZSgoKSA9PiBjYWxsYmFjaz8uKFJFQUxUSU1FX1NVQlNDUklCRV9TVEFURVMuQ0xPU0VEKSlcblxuICAgICAgdGhpcy51cGRhdGVKb2luUGF5bG9hZCh7IC4uLnsgY29uZmlnIH0sIC4uLmFjY2Vzc1Rva2VuUGF5bG9hZCB9KVxuXG4gICAgICB0aGlzLl91cGRhdGVGaWx0ZXJNZXNzYWdlKClcblxuICAgICAgdGhpcy5jaGFubmVsQWRhcHRlclxuICAgICAgICAuc3Vic2NyaWJlKHRpbWVvdXQpXG4gICAgICAgIC5yZWNlaXZlKCdvaycsIGFzeW5jICh7IHBvc3RncmVzX2NoYW5nZXMgfTogUG9zdGdyZXNDaGFuZ2VzRmlsdGVycykgPT4ge1xuICAgICAgICAgIC8vIE9ubHkgcmVmcmVzaCBhdXRoIGlmIHVzaW5nIGNhbGxiYWNrLWJhc2VkIHRva2Vuc1xuICAgICAgICAgIGlmICghdGhpcy5zb2NrZXQuX2lzTWFudWFsVG9rZW4oKSkge1xuICAgICAgICAgICAgdGhpcy5zb2NrZXQuc2V0QXV0aCgpXG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChwb3N0Z3Jlc19jaGFuZ2VzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrPy4oUkVBTFRJTUVfU1VCU0NSSUJFX1NUQVRFUy5TVUJTQ1JJQkVEKVxuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdGhpcy5fdXBkYXRlUG9zdGdyZXNCaW5kaW5ncyhwb3N0Z3Jlc19jaGFuZ2VzLCBjYWxsYmFjaylcbiAgICAgICAgfSlcbiAgICAgICAgLnJlY2VpdmUoJ2Vycm9yJywgKGVycm9yOiB7IFtrZXk6IHN0cmluZ106IGFueSB9KSA9PiB7XG4gICAgICAgICAgdGhpcy5zdGF0ZSA9IENIQU5ORUxfU1RBVEVTLmVycm9yZWRcbiAgICAgICAgICBjb25zdCBtZXNzYWdlID0gT2JqZWN0LnZhbHVlcyhlcnJvcikuam9pbignLCAnKSB8fCAnZXJyb3InXG4gICAgICAgICAgY2FsbGJhY2s/LihSRUFMVElNRV9TVUJTQ1JJQkVfU1RBVEVTLkNIQU5ORUxfRVJST1IsIG5ldyBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiBlcnJvciB9KSlcbiAgICAgICAgfSlcbiAgICAgICAgLnJlY2VpdmUoJ3RpbWVvdXQnLCAoKSA9PiB7XG4gICAgICAgICAgY2FsbGJhY2s/LihSRUFMVElNRV9TVUJTQ1JJQkVfU1RBVEVTLlRJTUVEX09VVClcbiAgICAgICAgfSlcbiAgICB9XG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHByaXZhdGUgX3VwZGF0ZVBvc3RncmVzQmluZGluZ3MoXG4gICAgcG9zdGdyZXNfY2hhbmdlczogUG9zdGdyZXNDaGFuZ2VzRmlsdGVyc1sncG9zdGdyZXNfY2hhbmdlcyddLFxuICAgIGNhbGxiYWNrPzogKHN0YXR1czogUkVBTFRJTUVfU1VCU0NSSUJFX1NUQVRFUywgZXJyPzogRXJyb3IpID0+IHZvaWRcbiAgKSB7XG4gICAgY29uc3QgY2xpZW50UG9zdGdyZXNCaW5kaW5ncyA9IHRoaXMuYmluZGluZ3MucG9zdGdyZXNfY2hhbmdlc1xuICAgIGNvbnN0IGJpbmRpbmdzTGVuID0gY2xpZW50UG9zdGdyZXNCaW5kaW5ncz8ubGVuZ3RoID8/IDBcbiAgICBjb25zdCBuZXdQb3N0Z3Jlc0JpbmRpbmdzID0gW11cblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYmluZGluZ3NMZW47IGkrKykge1xuICAgICAgY29uc3QgY2xpZW50UG9zdGdyZXNCaW5kaW5nID0gY2xpZW50UG9zdGdyZXNCaW5kaW5nc1tpXVxuICAgICAgY29uc3Qge1xuICAgICAgICBmaWx0ZXI6IHsgZXZlbnQsIHNjaGVtYSwgdGFibGUsIGZpbHRlciB9LFxuICAgICAgfSA9IGNsaWVudFBvc3RncmVzQmluZGluZ1xuICAgICAgY29uc3Qgc2VydmVyUG9zdGdyZXNGaWx0ZXIgPSBwb3N0Z3Jlc19jaGFuZ2VzICYmIHBvc3RncmVzX2NoYW5nZXNbaV1cblxuICAgICAgaWYgKFxuICAgICAgICBzZXJ2ZXJQb3N0Z3Jlc0ZpbHRlciAmJlxuICAgICAgICBzZXJ2ZXJQb3N0Z3Jlc0ZpbHRlci5ldmVudCA9PT0gZXZlbnQgJiZcbiAgICAgICAgUmVhbHRpbWVDaGFubmVsLmlzRmlsdGVyVmFsdWVFcXVhbChzZXJ2ZXJQb3N0Z3Jlc0ZpbHRlci5zY2hlbWEsIHNjaGVtYSkgJiZcbiAgICAgICAgUmVhbHRpbWVDaGFubmVsLmlzRmlsdGVyVmFsdWVFcXVhbChzZXJ2ZXJQb3N0Z3Jlc0ZpbHRlci50YWJsZSwgdGFibGUpICYmXG4gICAgICAgIFJlYWx0aW1lQ2hhbm5lbC5pc0ZpbHRlclZhbHVlRXF1YWwoc2VydmVyUG9zdGdyZXNGaWx0ZXIuZmlsdGVyLCBmaWx0ZXIpXG4gICAgICApIHtcbiAgICAgICAgbmV3UG9zdGdyZXNCaW5kaW5ncy5wdXNoKHtcbiAgICAgICAgICAuLi5jbGllbnRQb3N0Z3Jlc0JpbmRpbmcsXG4gICAgICAgICAgaWQ6IHNlcnZlclBvc3RncmVzRmlsdGVyLmlkLFxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy51bnN1YnNjcmliZSgpXG4gICAgICAgIHRoaXMuc3RhdGUgPSBDSEFOTkVMX1NUQVRFUy5lcnJvcmVkXG5cbiAgICAgICAgY2FsbGJhY2s/LihcbiAgICAgICAgICBSRUFMVElNRV9TVUJTQ1JJQkVfU1RBVEVTLkNIQU5ORUxfRVJST1IsXG4gICAgICAgICAgbmV3IEVycm9yKCdtaXNtYXRjaCBiZXR3ZWVuIHNlcnZlciBhbmQgY2xpZW50IGJpbmRpbmdzIGZvciBwb3N0Z3JlcyBjaGFuZ2VzJylcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLmJpbmRpbmdzLnBvc3RncmVzX2NoYW5nZXMgPSBuZXdQb3N0Z3Jlc0JpbmRpbmdzXG5cbiAgICBpZiAodGhpcy5zdGF0ZSAhPSBDSEFOTkVMX1NUQVRFUy5lcnJvcmVkICYmIGNhbGxiYWNrKSB7XG4gICAgICBjYWxsYmFjayhSRUFMVElNRV9TVUJTQ1JJQkVfU1RBVEVTLlNVQlNDUklCRUQpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGN1cnJlbnQgcHJlc2VuY2Ugc3RhdGUgZm9yIHRoaXMgY2hhbm5lbC5cbiAgICpcbiAgICogVGhlIHNoYXBlIGlzIGEgbWFwIGtleWVkIGJ5IHByZXNlbmNlIGtleSAoZm9yIGV4YW1wbGUgYSB1c2VyIGlkKSB3aGVyZSBlYWNoIGVudHJ5IGNvbnRhaW5zIHRoZVxuICAgKiB0cmFja2VkIG1ldGFkYXRhIGZvciB0aGF0IHVzZXIuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgcHJlc2VuY2VTdGF0ZTxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9PigpOiBSZWFsdGltZVByZXNlbmNlU3RhdGU8VD4ge1xuICAgIHJldHVybiB0aGlzLnByZXNlbmNlLnN0YXRlIGFzIFJlYWx0aW1lUHJlc2VuY2VTdGF0ZTxUPlxuICB9XG5cbiAgLyoqXG4gICAqIFNlbmRzIHRoZSBzdXBwbGllZCBwYXlsb2FkIHRvIHRoZSBwcmVzZW5jZSB0cmFja2VyIHNvIG90aGVyIHN1YnNjcmliZXJzIGNhbiBzZWUgdGhhdCB0aGlzXG4gICAqIGNsaWVudCBpcyBvbmxpbmUuIFVzZSBgdW50cmFja2AgdG8gc3RvcCBicm9hZGNhc3RpbmcgcHJlc2VuY2UgZm9yIHRoZSBzYW1lIGtleS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqL1xuICBhc3luYyB0cmFjayhcbiAgICBwYXlsb2FkOiB7IFtrZXk6IHN0cmluZ106IGFueSB9LFxuICAgIG9wdHM6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSB7fVxuICApOiBQcm9taXNlPFJlYWx0aW1lQ2hhbm5lbFNlbmRSZXNwb25zZT4ge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLnNlbmQoXG4gICAgICB7XG4gICAgICAgIHR5cGU6ICdwcmVzZW5jZScsXG4gICAgICAgIGV2ZW50OiAndHJhY2snLFxuICAgICAgICBwYXlsb2FkLFxuICAgICAgfSxcbiAgICAgIG9wdHMudGltZW91dCB8fCB0aGlzLnRpbWVvdXRcbiAgICApXG4gIH1cblxuICAvKipcbiAgICogUmVtb3ZlcyB0aGUgY3VycmVudCBwcmVzZW5jZSBzdGF0ZSBmb3IgdGhpcyBjbGllbnQuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgYXN5bmMgdW50cmFjayhvcHRzOiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0ge30pOiBQcm9taXNlPFJlYWx0aW1lQ2hhbm5lbFNlbmRSZXNwb25zZT4ge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLnNlbmQoXG4gICAgICB7XG4gICAgICAgIHR5cGU6ICdwcmVzZW5jZScsXG4gICAgICAgIGV2ZW50OiAndW50cmFjaycsXG4gICAgICB9LFxuICAgICAgb3B0c1xuICAgIClcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIGV2ZW50IGhhbmRsZXIgdGhhdCBsaXN0ZW5zIHRvIGNoYW5nZXMuXG4gICAqL1xuICBvbihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuUFJFU0VOQ0V9YCxcbiAgICBmaWx0ZXI6IHsgZXZlbnQ6IGAke1JFQUxUSU1FX1BSRVNFTkNFX0xJU1RFTl9FVkVOVFMuU1lOQ31gIH0sXG4gICAgY2FsbGJhY2s6ICgpID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIG9uPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuUFJFU0VOQ0V9YCxcbiAgICBmaWx0ZXI6IHsgZXZlbnQ6IGAke1JFQUxUSU1FX1BSRVNFTkNFX0xJU1RFTl9FVkVOVFMuSk9JTn1gIH0sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkOiBSZWFsdGltZVByZXNlbmNlSm9pblBheWxvYWQ8VD4pID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIG9uPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuUFJFU0VOQ0V9YCxcbiAgICBmaWx0ZXI6IHsgZXZlbnQ6IGAke1JFQUxUSU1FX1BSRVNFTkNFX0xJU1RFTl9FVkVOVFMuTEVBVkV9YCB9LFxuICAgIGNhbGxiYWNrOiAocGF5bG9hZDogUmVhbHRpbWVQcmVzZW5jZUxlYXZlUGF5bG9hZDxUPikgPT4gdm9pZFxuICApOiBSZWFsdGltZUNoYW5uZWxcbiAgb248VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+KFxuICAgIHR5cGU6IGAke1JFQUxUSU1FX0xJU1RFTl9UWVBFUy5QUkVTRU5DRX1gLFxuICAgIGZpbHRlcjogeyBldmVudDogJyonIH0sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkPzogUmVhbHRpbWVQcmVzZW5jZUpvaW5QYXlsb2FkPFQ+IHwgUmVhbHRpbWVQcmVzZW5jZUxlYXZlUGF5bG9hZDxUPikgPT4gdm9pZFxuICApOiBSZWFsdGltZUNoYW5uZWxcbiAgb248VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+KFxuICAgIHR5cGU6IGAke1JFQUxUSU1FX0xJU1RFTl9UWVBFUy5QT1NUR1JFU19DSEFOR0VTfWAsXG4gICAgZmlsdGVyOiBSZWFsdGltZVBvc3RncmVzQ2hhbmdlc0ZpbHRlcjxgJHtSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5BTEx9YD4sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkOiBSZWFsdGltZVBvc3RncmVzQ2hhbmdlc1BheWxvYWQ8VD4pID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIG9uPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuUE9TVEdSRVNfQ0hBTkdFU31gLFxuICAgIGZpbHRlcjogUmVhbHRpbWVQb3N0Z3Jlc0NoYW5nZXNGaWx0ZXI8YCR7UkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlQuSU5TRVJUfWA+LFxuICAgIGNhbGxiYWNrOiAocGF5bG9hZDogUmVhbHRpbWVQb3N0Z3Jlc0luc2VydFBheWxvYWQ8VD4pID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIG9uPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuUE9TVEdSRVNfQ0hBTkdFU31gLFxuICAgIGZpbHRlcjogUmVhbHRpbWVQb3N0Z3Jlc0NoYW5nZXNGaWx0ZXI8YCR7UkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlQuVVBEQVRFfWA+LFxuICAgIGNhbGxiYWNrOiAocGF5bG9hZDogUmVhbHRpbWVQb3N0Z3Jlc1VwZGF0ZVBheWxvYWQ8VD4pID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIG9uPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuUE9TVEdSRVNfQ0hBTkdFU31gLFxuICAgIGZpbHRlcjogUmVhbHRpbWVQb3N0Z3Jlc0NoYW5nZXNGaWx0ZXI8YCR7UkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlQuREVMRVRFfWA+LFxuICAgIGNhbGxiYWNrOiAocGF5bG9hZDogUmVhbHRpbWVQb3N0Z3Jlc0RlbGV0ZVBheWxvYWQ8VD4pID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIG9uPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuUE9TVEdSRVNfQ0hBTkdFU31gLFxuICAgIGZpbHRlcjogUmVhbHRpbWVQb3N0Z3Jlc0NoYW5nZXNGaWx0ZXI8YCR7UkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlR9YD4sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkOiBSZWFsdGltZVBvc3RncmVzQ2hhbmdlc1BheWxvYWQ8VD4pID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIC8qKlxuICAgKiBUaGUgZm9sbG93aW5nIGlzIHBsYWNlZCBoZXJlIHRvIGRpc3BsYXkgb24gc3VwYWJhc2UuY29tL2RvY3MvcmVmZXJlbmNlL2phdmFzY3JpcHQvc3Vic2NyaWJlLlxuICAgKiBAcGFyYW0gdHlwZSBPbmUgb2YgXCJicm9hZGNhc3RcIiwgXCJwcmVzZW5jZVwiLCBvciBcInBvc3RncmVzX2NoYW5nZXNcIi5cbiAgICogQHBhcmFtIGZpbHRlciBDdXN0b20gb2JqZWN0IHNwZWNpZmljIHRvIHRoZSBSZWFsdGltZSBmZWF0dXJlIGRldGFpbGluZyB3aGljaCBwYXlsb2FkcyB0byByZWNlaXZlLlxuICAgKiBAcGFyYW0gY2FsbGJhY2sgRnVuY3Rpb24gdG8gYmUgaW52b2tlZCB3aGVuIGV2ZW50IGhhbmRsZXIgaXMgdHJpZ2dlcmVkLlxuICAgKi9cbiAgb24oXG4gICAgdHlwZTogYCR7UkVBTFRJTUVfTElTVEVOX1RZUEVTLkJST0FEQ0FTVH1gLFxuICAgIGZpbHRlcjogeyBldmVudDogc3RyaW5nIH0sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkOiB7XG4gICAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuQlJPQURDQVNUfWBcbiAgICAgIGV2ZW50OiBzdHJpbmdcbiAgICAgIG1ldGE/OiB7XG4gICAgICAgIHJlcGxheWVkPzogYm9vbGVhblxuICAgICAgICBpZDogc3RyaW5nXG4gICAgICB9XG4gICAgICBba2V5OiBzdHJpbmddOiBhbnlcbiAgICB9KSA9PiB2b2lkXG4gICk6IFJlYWx0aW1lQ2hhbm5lbFxuICBvbjxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfT4oXG4gICAgdHlwZTogYCR7UkVBTFRJTUVfTElTVEVOX1RZUEVTLkJST0FEQ0FTVH1gLFxuICAgIGZpbHRlcjogeyBldmVudDogc3RyaW5nIH0sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkOiB7XG4gICAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuQlJPQURDQVNUfWBcbiAgICAgIGV2ZW50OiBzdHJpbmdcbiAgICAgIG1ldGE/OiB7XG4gICAgICAgIHJlcGxheWVkPzogYm9vbGVhblxuICAgICAgICBpZDogc3RyaW5nXG4gICAgICB9XG4gICAgICBwYXlsb2FkOiBUXG4gICAgfSkgPT4gdm9pZFxuICApOiBSZWFsdGltZUNoYW5uZWxcbiAgb248VCBleHRlbmRzIFJlY29yZDxzdHJpbmcsIHVua25vd24+PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuQlJPQURDQVNUfWAsXG4gICAgZmlsdGVyOiB7IGV2ZW50OiBSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5BTEwgfSxcbiAgICBjYWxsYmFjazogKHBheWxvYWQ6IHtcbiAgICAgIHR5cGU6IGAke1JFQUxUSU1FX0xJU1RFTl9UWVBFUy5CUk9BRENBU1R9YFxuICAgICAgZXZlbnQ6IFJFQUxUSU1FX1BPU1RHUkVTX0NIQU5HRVNfTElTVEVOX0VWRU5ULkFMTFxuICAgICAgcGF5bG9hZDogUmVhbHRpbWVCcm9hZGNhc3RQYXlsb2FkPFQ+XG4gICAgfSkgPT4gdm9pZFxuICApOiBSZWFsdGltZUNoYW5uZWxcbiAgb248VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+KFxuICAgIHR5cGU6IGAke1JFQUxUSU1FX0xJU1RFTl9UWVBFUy5CUk9BRENBU1R9YCxcbiAgICBmaWx0ZXI6IHsgZXZlbnQ6IFJFQUxUSU1FX1BPU1RHUkVTX0NIQU5HRVNfTElTVEVOX0VWRU5ULklOU0VSVCB9LFxuICAgIGNhbGxiYWNrOiAocGF5bG9hZDoge1xuICAgICAgdHlwZTogYCR7UkVBTFRJTUVfTElTVEVOX1RZUEVTLkJST0FEQ0FTVH1gXG4gICAgICBldmVudDogUkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlQuSU5TRVJUXG4gICAgICBwYXlsb2FkOiBSZWFsdGltZUJyb2FkY2FzdEluc2VydFBheWxvYWQ8VD5cbiAgICB9KSA9PiB2b2lkXG4gICk6IFJlYWx0aW1lQ2hhbm5lbFxuICBvbjxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfT4oXG4gICAgdHlwZTogYCR7UkVBTFRJTUVfTElTVEVOX1RZUEVTLkJST0FEQ0FTVH1gLFxuICAgIGZpbHRlcjogeyBldmVudDogUkVBTFRJTUVfUE9TVEdSRVNfQ0hBTkdFU19MSVNURU5fRVZFTlQuVVBEQVRFIH0sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkOiB7XG4gICAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuQlJPQURDQVNUfWBcbiAgICAgIGV2ZW50OiBSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5VUERBVEVcbiAgICAgIHBheWxvYWQ6IFJlYWx0aW1lQnJvYWRjYXN0VXBkYXRlUGF5bG9hZDxUPlxuICAgIH0pID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsXG4gIG9uPFQgZXh0ZW5kcyB7IFtrZXk6IHN0cmluZ106IGFueSB9PihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVMuQlJPQURDQVNUfWAsXG4gICAgZmlsdGVyOiB7IGV2ZW50OiBSRUFMVElNRV9QT1NUR1JFU19DSEFOR0VTX0xJU1RFTl9FVkVOVC5ERUxFVEUgfSxcbiAgICBjYWxsYmFjazogKHBheWxvYWQ6IHtcbiAgICAgIHR5cGU6IGAke1JFQUxUSU1FX0xJU1RFTl9UWVBFUy5CUk9BRENBU1R9YFxuICAgICAgZXZlbnQ6IFJFQUxUSU1FX1BPU1RHUkVTX0NIQU5HRVNfTElTVEVOX0VWRU5ULkRFTEVURVxuICAgICAgcGF5bG9hZDogUmVhbHRpbWVCcm9hZGNhc3REZWxldGVQYXlsb2FkPFQ+XG4gICAgfSkgPT4gdm9pZFxuICApOiBSZWFsdGltZUNoYW5uZWxcbiAgb248VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+KFxuICAgIHR5cGU6IGAke1JFQUxUSU1FX0xJU1RFTl9UWVBFUy5TWVNURU19YCxcbiAgICBmaWx0ZXI6IHt9LFxuICAgIGNhbGxiYWNrOiAocGF5bG9hZDogYW55KSA9PiB2b2lkXG4gICk6IFJlYWx0aW1lQ2hhbm5lbFxuICAvKipcbiAgICogTGlzdGVuIHRvIHJlYWx0aW1lIGV2ZW50cyBvbiB0aGlzIGNoYW5uZWwuXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEJ5IGRlZmF1bHQsIEJyb2FkY2FzdCBhbmQgUHJlc2VuY2UgYXJlIGVuYWJsZWQgZm9yIGFsbCBwcm9qZWN0cy5cbiAgICogLSBCeSBkZWZhdWx0LCBsaXN0ZW5pbmcgdG8gZGF0YWJhc2UgY2hhbmdlcyBpcyBkaXNhYmxlZCBmb3IgbmV3IHByb2plY3RzIGR1ZSB0byBkYXRhYmFzZSBwZXJmb3JtYW5jZSBhbmQgc2VjdXJpdHkgY29uY2VybnMuIFlvdSBjYW4gdHVybiBpdCBvbiBieSBtYW5hZ2luZyBSZWFsdGltZSdzIFtyZXBsaWNhdGlvbl0oL2RvY3MvZ3VpZGVzL2FwaSNyZWFsdGltZS1hcGktb3ZlcnZpZXcpLlxuICAgKiAtIFlvdSBjYW4gcmVjZWl2ZSB0aGUgXCJwcmV2aW91c1wiIGRhdGEgZm9yIHVwZGF0ZXMgYW5kIGRlbGV0ZXMgYnkgc2V0dGluZyB0aGUgdGFibGUncyBgUkVQTElDQSBJREVOVElUWWAgdG8gYEZVTExgIChlLmcuLCBgQUxURVIgVEFCTEUgeW91cl90YWJsZSBSRVBMSUNBIElERU5USVRZIEZVTEw7YCkuXG4gICAqIC0gUm93IGxldmVsIHNlY3VyaXR5IGlzIG5vdCBhcHBsaWVkIHRvIGRlbGV0ZSBzdGF0ZW1lbnRzLiBXaGVuIFJMUyBpcyBlbmFibGVkIGFuZCByZXBsaWNhIGlkZW50aXR5IGlzIHNldCB0byBmdWxsLCBvbmx5IHRoZSBwcmltYXJ5IGtleSBpcyBzZW50IHRvIGNsaWVudHMuXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBicm9hZGNhc3QgbWVzc2FnZXNcbiAgICogYGBganNcbiAgICogY29uc3QgY2hhbm5lbCA9IHN1cGFiYXNlLmNoYW5uZWwoXCJyb29tMVwiKVxuICAgKlxuICAgKiBjaGFubmVsLm9uKFwiYnJvYWRjYXN0XCIsIHsgZXZlbnQ6IFwiY3Vyc29yLXBvc1wiIH0sIChwYXlsb2FkKSA9PiB7XG4gICAqICAgY29uc29sZS5sb2coXCJDdXJzb3IgcG9zaXRpb24gcmVjZWl2ZWQhXCIsIHBheWxvYWQpO1xuICAgKiB9KS5zdWJzY3JpYmUoKHN0YXR1cykgPT4ge1xuICAgKiAgIGlmIChzdGF0dXMgPT09IFwiU1VCU0NSSUJFRFwiKSB7XG4gICAqICAgICBjaGFubmVsLnNlbmQoe1xuICAgKiAgICAgICB0eXBlOiBcImJyb2FkY2FzdFwiLFxuICAgKiAgICAgICBldmVudDogXCJjdXJzb3ItcG9zXCIsXG4gICAqICAgICAgIHBheWxvYWQ6IHsgeDogTWF0aC5yYW5kb20oKSwgeTogTWF0aC5yYW5kb20oKSB9LFxuICAgKiAgICAgfSk7XG4gICAqICAgfVxuICAgKiB9KTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBwcmVzZW5jZSBzeW5jXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IGNoYW5uZWwgPSBzdXBhYmFzZS5jaGFubmVsKCdyb29tMScpXG4gICAqIGNoYW5uZWxcbiAgICogICAub24oJ3ByZXNlbmNlJywgeyBldmVudDogJ3N5bmMnIH0sICgpID0+IHtcbiAgICogICAgIGNvbnNvbGUubG9nKCdTeW5jZWQgcHJlc2VuY2Ugc3RhdGU6ICcsIGNoYW5uZWwucHJlc2VuY2VTdGF0ZSgpKVxuICAgKiAgIH0pXG4gICAqICAgLnN1YnNjcmliZShhc3luYyAoc3RhdHVzKSA9PiB7XG4gICAqICAgICBpZiAoc3RhdHVzID09PSAnU1VCU0NSSUJFRCcpIHtcbiAgICogICAgICAgYXdhaXQgY2hhbm5lbC50cmFjayh7IG9ubGluZV9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0pXG4gICAqICAgICB9XG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBwcmVzZW5jZSBqb2luXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IGNoYW5uZWwgPSBzdXBhYmFzZS5jaGFubmVsKCdyb29tMScpXG4gICAqIGNoYW5uZWxcbiAgICogICAub24oJ3ByZXNlbmNlJywgeyBldmVudDogJ2pvaW4nIH0sICh7IG5ld1ByZXNlbmNlcyB9KSA9PiB7XG4gICAqICAgICBjb25zb2xlLmxvZygnTmV3bHkgam9pbmVkIHByZXNlbmNlczogJywgbmV3UHJlc2VuY2VzKVxuICAgKiAgIH0pXG4gICAqICAgLnN1YnNjcmliZShhc3luYyAoc3RhdHVzKSA9PiB7XG4gICAqICAgICBpZiAoc3RhdHVzID09PSAnU1VCU0NSSUJFRCcpIHtcbiAgICogICAgICAgYXdhaXQgY2hhbm5lbC50cmFjayh7IG9ubGluZV9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0pXG4gICAqICAgICB9XG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBwcmVzZW5jZSBsZWF2ZVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCBjaGFubmVsID0gc3VwYWJhc2UuY2hhbm5lbCgncm9vbTEnKVxuICAgKiBjaGFubmVsXG4gICAqICAgLm9uKCdwcmVzZW5jZScsIHsgZXZlbnQ6ICdsZWF2ZScgfSwgKHsgbGVmdFByZXNlbmNlcyB9KSA9PiB7XG4gICAqICAgICBjb25zb2xlLmxvZygnTmV3bHkgbGVmdCBwcmVzZW5jZXM6ICcsIGxlZnRQcmVzZW5jZXMpXG4gICAqICAgfSlcbiAgICogICAuc3Vic2NyaWJlKGFzeW5jIChzdGF0dXMpID0+IHtcbiAgICogICAgIGlmIChzdGF0dXMgPT09ICdTVUJTQ1JJQkVEJykge1xuICAgKiAgICAgICBhd2FpdCBjaGFubmVsLnRyYWNrKHsgb25saW5lX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSlcbiAgICogICAgICAgYXdhaXQgY2hhbm5lbC51bnRyYWNrKClcbiAgICogICAgIH1cbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdGVuIHRvIGFsbCBkYXRhYmFzZSBjaGFuZ2VzXG4gICAqIGBgYGpzXG4gICAqIHN1cGFiYXNlXG4gICAqICAgLmNoYW5uZWwoJ3Jvb20xJylcbiAgICogICAub24oJ3Bvc3RncmVzX2NoYW5nZXMnLCB7IGV2ZW50OiAnKicsIHNjaGVtYTogJyonIH0sIHBheWxvYWQgPT4ge1xuICAgKiAgICAgY29uc29sZS5sb2coJ0NoYW5nZSByZWNlaXZlZCEnLCBwYXlsb2FkKVxuICAgKiAgIH0pXG4gICAqICAgLnN1YnNjcmliZSgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBMaXN0ZW4gdG8gYSBzcGVjaWZpYyB0YWJsZVxuICAgKiBgYGBqc1xuICAgKiBzdXBhYmFzZVxuICAgKiAgIC5jaGFubmVsKCdyb29tMScpXG4gICAqICAgLm9uKCdwb3N0Z3Jlc19jaGFuZ2VzJywgeyBldmVudDogJyonLCBzY2hlbWE6ICdwdWJsaWMnLCB0YWJsZTogJ2NvdW50cmllcycgfSwgcGF5bG9hZCA9PiB7XG4gICAqICAgICBjb25zb2xlLmxvZygnQ2hhbmdlIHJlY2VpdmVkIScsIHBheWxvYWQpXG4gICAqICAgfSlcbiAgICogICAuc3Vic2NyaWJlKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBpbnNlcnRzXG4gICAqIGBgYGpzXG4gICAqIHN1cGFiYXNlXG4gICAqICAgLmNoYW5uZWwoJ3Jvb20xJylcbiAgICogICAub24oJ3Bvc3RncmVzX2NoYW5nZXMnLCB7IGV2ZW50OiAnSU5TRVJUJywgc2NoZW1hOiAncHVibGljJywgdGFibGU6ICdjb3VudHJpZXMnIH0sIHBheWxvYWQgPT4ge1xuICAgKiAgICAgY29uc29sZS5sb2coJ0NoYW5nZSByZWNlaXZlZCEnLCBwYXlsb2FkKVxuICAgKiAgIH0pXG4gICAqICAgLnN1YnNjcmliZSgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIExpc3RlbiB0byB1cGRhdGVzXG4gICAqIEJ5IGRlZmF1bHQsIFN1cGFiYXNlIHdpbGwgc2VuZCBvbmx5IHRoZSB1cGRhdGVkIHJlY29yZC4gSWYgeW91IHdhbnQgdG8gcmVjZWl2ZSB0aGUgcHJldmlvdXMgdmFsdWVzIGFzIHdlbGwgeW91IGNhblxuICAgKiBlbmFibGUgZnVsbCByZXBsaWNhdGlvbiBmb3IgdGhlIHRhYmxlIHlvdSBhcmUgbGlzdGVuaW5nIHRvOlxuICAgKlxuICAgKiBgYGBzcWxcbiAgICogYWx0ZXIgdGFibGUgXCJ5b3VyX3RhYmxlXCIgcmVwbGljYSBpZGVudGl0eSBmdWxsO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdGVuIHRvIHVwZGF0ZXNcbiAgICogYGBganNcbiAgICogc3VwYWJhc2VcbiAgICogICAuY2hhbm5lbCgncm9vbTEnKVxuICAgKiAgIC5vbigncG9zdGdyZXNfY2hhbmdlcycsIHsgZXZlbnQ6ICdVUERBVEUnLCBzY2hlbWE6ICdwdWJsaWMnLCB0YWJsZTogJ2NvdW50cmllcycgfSwgcGF5bG9hZCA9PiB7XG4gICAqICAgICBjb25zb2xlLmxvZygnQ2hhbmdlIHJlY2VpdmVkIScsIHBheWxvYWQpXG4gICAqICAgfSlcbiAgICogICAuc3Vic2NyaWJlKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gTGlzdGVuIHRvIGRlbGV0ZXNcbiAgICogQnkgZGVmYXVsdCwgU3VwYWJhc2UgZG9lcyBub3Qgc2VuZCBkZWxldGVkIHJlY29yZHMuIElmIHlvdSB3YW50IHRvIHJlY2VpdmUgdGhlIGRlbGV0ZWQgcmVjb3JkIHlvdSBjYW5cbiAgICogZW5hYmxlIGZ1bGwgcmVwbGljYXRpb24gZm9yIHRoZSB0YWJsZSB5b3UgYXJlIGxpc3RlbmluZyB0bzpcbiAgICpcbiAgICogYGBgc3FsXG4gICAqIGFsdGVyIHRhYmxlIFwieW91cl90YWJsZVwiIHJlcGxpY2EgaWRlbnRpdHkgZnVsbDtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3RlbiB0byBkZWxldGVzXG4gICAqIGBgYGpzXG4gICAqIHN1cGFiYXNlXG4gICAqICAgLmNoYW5uZWwoJ3Jvb20xJylcbiAgICogICAub24oJ3Bvc3RncmVzX2NoYW5nZXMnLCB7IGV2ZW50OiAnREVMRVRFJywgc2NoZW1hOiAncHVibGljJywgdGFibGU6ICdjb3VudHJpZXMnIH0sIHBheWxvYWQgPT4ge1xuICAgKiAgICAgY29uc29sZS5sb2coJ0NoYW5nZSByZWNlaXZlZCEnLCBwYXlsb2FkKVxuICAgKiAgIH0pXG4gICAqICAgLnN1YnNjcmliZSgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIExpc3RlbiB0byBtdWx0aXBsZSBldmVudHNcbiAgICogWW91IGNhbiBjaGFpbiBsaXN0ZW5lcnMgaWYgeW91IHdhbnQgdG8gbGlzdGVuIHRvIG11bHRpcGxlIGV2ZW50cyBmb3IgZWFjaCB0YWJsZS5cbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdGVuIHRvIG11bHRpcGxlIGV2ZW50c1xuICAgKiBgYGBqc1xuICAgKiBzdXBhYmFzZVxuICAgKiAgIC5jaGFubmVsKCdyb29tMScpXG4gICAqICAgLm9uKCdwb3N0Z3Jlc19jaGFuZ2VzJywgeyBldmVudDogJ0lOU0VSVCcsIHNjaGVtYTogJ3B1YmxpYycsIHRhYmxlOiAnY291bnRyaWVzJyB9LCBoYW5kbGVSZWNvcmRJbnNlcnRlZClcbiAgICogICAub24oJ3Bvc3RncmVzX2NoYW5nZXMnLCB7IGV2ZW50OiAnREVMRVRFJywgc2NoZW1hOiAncHVibGljJywgdGFibGU6ICdjb3VudHJpZXMnIH0sIGhhbmRsZVJlY29yZERlbGV0ZWQpXG4gICAqICAgLnN1YnNjcmliZSgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIExpc3RlbiB0byByb3cgbGV2ZWwgY2hhbmdlc1xuICAgKiBZb3UgY2FuIGxpc3RlbiB0byBpbmRpdmlkdWFsIHJvd3MgdXNpbmcgdGhlIGZvcm1hdCBge3RhYmxlfTp7Y29sfT1lcS57dmFsfWAgLSB3aGVyZSBge2NvbH1gIGlzIHRoZSBjb2x1bW4gbmFtZSwgYW5kIGB7dmFsfWAgaXMgdGhlIHZhbHVlIHdoaWNoIHlvdSB3YW50IHRvIG1hdGNoLlxuICAgKlxuICAgKiBAZXhhbXBsZSBMaXN0ZW4gdG8gcm93IGxldmVsIGNoYW5nZXNcbiAgICogYGBganNcbiAgICogc3VwYWJhc2VcbiAgICogICAuY2hhbm5lbCgncm9vbTEnKVxuICAgKiAgIC5vbigncG9zdGdyZXNfY2hhbmdlcycsIHsgZXZlbnQ6ICdVUERBVEUnLCBzY2hlbWE6ICdwdWJsaWMnLCB0YWJsZTogJ2NvdW50cmllcycsIGZpbHRlcjogJ2lkPWVxLjIwMCcgfSwgaGFuZGxlUmVjb3JkVXBkYXRlZClcbiAgICogICAuc3Vic2NyaWJlKClcbiAgICogYGBgXG4gICAqL1xuICBvbihcbiAgICB0eXBlOiBgJHtSRUFMVElNRV9MSVNURU5fVFlQRVN9YCxcbiAgICBmaWx0ZXI6IHsgZXZlbnQ6IHN0cmluZzsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0sXG4gICAgY2FsbGJhY2s6IChwYXlsb2FkOiBhbnkpID0+IHZvaWRcbiAgKTogUmVhbHRpbWVDaGFubmVsIHtcbiAgICBjb25zdCBzdGF0ZUNoZWNrID0gdGhpcy5jaGFubmVsQWRhcHRlci5pc0pvaW5lZCgpIHx8IHRoaXMuY2hhbm5lbEFkYXB0ZXIuaXNKb2luaW5nKClcbiAgICBjb25zdCB0eXBlQ2hlY2sgPVxuICAgICAgdHlwZSA9PT0gUkVBTFRJTUVfTElTVEVOX1RZUEVTLlBSRVNFTkNFIHx8IHR5cGUgPT09IFJFQUxUSU1FX0xJU1RFTl9UWVBFUy5QT1NUR1JFU19DSEFOR0VTXG5cbiAgICBpZiAoc3RhdGVDaGVjayAmJiB0eXBlQ2hlY2spIHtcbiAgICAgIHRoaXMuc29ja2V0LmxvZyhcbiAgICAgICAgJ2NoYW5uZWwnLFxuICAgICAgICBgY2Fubm90IGFkZCBcXGAke3R5cGV9XFxgIGNhbGxiYWNrcyBmb3IgJHt0aGlzLnRvcGljfSBhZnRlciBcXGBzdWJzY3JpYmUoKVxcYC5gXG4gICAgICApXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYGNhbm5vdCBhZGQgXFxgJHt0eXBlfVxcYCBjYWxsYmFja3MgZm9yICR7dGhpcy50b3BpY30gYWZ0ZXIgXFxgc3Vic2NyaWJlKClcXGAuYClcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX29uKHR5cGUsIGZpbHRlciwgY2FsbGJhY2spXG4gIH1cbiAgLyoqXG4gICAqIFNlbmRzIGEgYnJvYWRjYXN0IG1lc3NhZ2UgZXhwbGljaXRseSB2aWEgUkVTVCBBUEkuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIGFsd2F5cyB1c2VzIHRoZSBSRVNUIEFQSSBlbmRwb2ludCByZWdhcmRsZXNzIG9mIFdlYlNvY2tldCBjb25uZWN0aW9uIHN0YXRlLlxuICAgKiBVc2VmdWwgd2hlbiB5b3Ugd2FudCB0byBndWFyYW50ZWUgUkVTVCBkZWxpdmVyeSBvciB3aGVuIGdyYWR1YWxseSBtaWdyYXRpbmcgZnJvbSBpbXBsaWNpdCBSRVNUIGZhbGxiYWNrLlxuICAgKlxuICAgKiBQYXlsb2FkcyB0aGF0IGFyZSBgQXJyYXlCdWZmZXJgIG9yIGBBcnJheUJ1ZmZlclZpZXdgIChlLmcuIGBVaW50OEFycmF5YCkgYXJlIHNlbnQgYXNcbiAgICogYGFwcGxpY2F0aW9uL29jdGV0LXN0cmVhbWA7IGFsbCBvdGhlciBwYXlsb2FkcyBhcmUgSlNPTi1lbmNvZGVkLlxuICAgKlxuICAgKiBAcGFyYW0gZXZlbnQgVGhlIG5hbWUgb2YgdGhlIGJyb2FkY2FzdCBldmVudFxuICAgKiBAcGFyYW0gcGF5bG9hZCBQYXlsb2FkIHRvIGJlIHNlbnQgKHJlcXVpcmVkKVxuICAgKiBAcGFyYW0gb3B0cyBPcHRpb25zIGluY2x1ZGluZyB0aW1lb3V0XG4gICAqIEByZXR1cm5zIFByb21pc2UgcmVzb2x2aW5nIHRvIG9iamVjdCB3aXRoIHN1Y2Nlc3Mgc3RhdHVzLCBhbmQgZXJyb3IgZGV0YWlscyBpZiBmYWlsZWRcbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqL1xuICBhc3luYyBodHRwU2VuZChcbiAgICBldmVudDogc3RyaW5nLFxuICAgIHBheWxvYWQ6IGFueSxcbiAgICBvcHRzOiB7IHRpbWVvdXQ/OiBudW1iZXIgfSA9IHt9XG4gICk6IFByb21pc2U8eyBzdWNjZXNzOiB0cnVlIH0gfCB7IHN1Y2Nlc3M6IGZhbHNlOyBzdGF0dXM6IG51bWJlcjsgZXJyb3I6IHN0cmluZyB9PiB7XG4gICAgaWYgKHBheWxvYWQgPT09IHVuZGVmaW5lZCB8fCBwYXlsb2FkID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKCdQYXlsb2FkIGlzIHJlcXVpcmVkIGZvciBodHRwU2VuZCgpJykpXG4gICAgfVxuXG4gICAgY29uc3QgaXNCaW5hcnkgPSBwYXlsb2FkIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIgfHwgQXJyYXlCdWZmZXIuaXNWaWV3KHBheWxvYWQpXG5cbiAgICBjb25zdCBoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgICAgYXBpa2V5OiB0aGlzLnNvY2tldC5hcGlLZXkgPyB0aGlzLnNvY2tldC5hcGlLZXkgOiAnJyxcbiAgICAgICdDb250ZW50LVR5cGUnOiBpc0JpbmFyeSA/ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nIDogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgIH1cblxuICAgIGlmICh0aGlzLnNvY2tldC5hY2Nlc3NUb2tlblZhbHVlKSB7XG4gICAgICBoZWFkZXJzWydBdXRob3JpemF0aW9uJ10gPSBgQmVhcmVyICR7dGhpcy5zb2NrZXQuYWNjZXNzVG9rZW5WYWx1ZX1gXG4gICAgfVxuXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTCh0aGlzLmJyb2FkY2FzdEVuZHBvaW50VVJMKVxuICAgIHVybC5wYXRobmFtZSArPSBgLyR7ZW5jb2RlVVJJQ29tcG9uZW50KHRoaXMuc3ViVG9waWMpfS9ldmVudHMvJHtlbmNvZGVVUklDb21wb25lbnQoZXZlbnQpfWBcbiAgICBpZiAodGhpcy5wcml2YXRlKSB7XG4gICAgICB1cmwuc2VhcmNoUGFyYW1zLnNldCgncHJpdmF0ZScsICd0cnVlJylcbiAgICB9XG5cbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzLFxuICAgICAgYm9keTogaXNCaW5hcnkgPyAocGF5bG9hZCBhcyBBcnJheUJ1ZmZlciB8IEFycmF5QnVmZmVyVmlldykgOiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKSxcbiAgICB9XG5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuX2ZldGNoV2l0aFRpbWVvdXQoXG4gICAgICB1cmwudG9TdHJpbmcoKSxcbiAgICAgIG9wdGlvbnMsXG4gICAgICBvcHRzLnRpbWVvdXQgPz8gdGhpcy50aW1lb3V0XG4gICAgKVxuXG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAyKSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH1cbiAgICB9XG5cbiAgICBsZXQgZXJyb3JNZXNzYWdlID0gcmVzcG9uc2Uuc3RhdHVzVGV4dFxuICAgIHRyeSB7XG4gICAgICBjb25zdCBlcnJvckJvZHkgPSBhd2FpdCByZXNwb25zZS5qc29uKClcbiAgICAgIGVycm9yTWVzc2FnZSA9IGVycm9yQm9keS5lcnJvciB8fCBlcnJvckJvZHkubWVzc2FnZSB8fCBlcnJvck1lc3NhZ2VcbiAgICB9IGNhdGNoIHt9XG5cbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKGVycm9yTWVzc2FnZSkpXG4gIH1cblxuICAvKipcbiAgICogU2VuZHMgYSBtZXNzYWdlIGludG8gdGhlIGNoYW5uZWwuXG4gICAqXG4gICAqIEBwYXJhbSBhcmdzIEFyZ3VtZW50cyB0byBzZW5kIHRvIGNoYW5uZWxcbiAgICogQHBhcmFtIGFyZ3MudHlwZSBUaGUgdHlwZSBvZiBldmVudCB0byBzZW5kXG4gICAqIEBwYXJhbSBhcmdzLmV2ZW50IFRoZSBuYW1lIG9mIHRoZSBldmVudCBiZWluZyBzZW50XG4gICAqIEBwYXJhbSBhcmdzLnBheWxvYWQgUGF5bG9hZCB0byBiZSBzZW50XG4gICAqIEBwYXJhbSBvcHRzIE9wdGlvbnMgdG8gYmUgdXNlZCBkdXJpbmcgdGhlIHNlbmQgcHJvY2Vzc1xuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBXaGVuIHVzaW5nIFJFU1QgeW91IGRvbid0IG5lZWQgdG8gc3Vic2NyaWJlIHRvIHRoZSBjaGFubmVsXG4gICAqIC0gUkVTVCBjYWxscyBhcmUgb25seSBhdmFpbGFibGUgZnJvbSAyLjM3LjAgb253YXJkc1xuICAgKiAtIElmIHlvdSBjcmVhdGUgYSBjaGFubmVsIG9ubHkgdG8gc2VuZCBhIFJFU1QgYnJvYWRjYXN0LCByZW1vdmUgaXQgZnJvbVxuICAgKiAgIHRoZSBjbGllbnQgd2hlbiB0aGUgc2VuZCBjb21wbGV0ZXNcbiAgICpcbiAgICogQGV4YW1wbGUgU2VuZCBhIG1lc3NhZ2UgdmlhIHdlYnNvY2tldFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCBjaGFubmVsID0gc3VwYWJhc2UuY2hhbm5lbCgncm9vbTEnKVxuICAgKlxuICAgKiBjaGFubmVsLnN1YnNjcmliZSgoc3RhdHVzKSA9PiB7XG4gICAqICAgaWYgKHN0YXR1cyA9PT0gJ1NVQlNDUklCRUQnKSB7XG4gICAqICAgICBjaGFubmVsLnNlbmQoe1xuICAgKiAgICAgICB0eXBlOiAnYnJvYWRjYXN0JyxcbiAgICogICAgICAgZXZlbnQ6ICdjdXJzb3ItcG9zJyxcbiAgICogICAgICAgcGF5bG9hZDogeyB4OiBNYXRoLnJhbmRvbSgpLCB5OiBNYXRoLnJhbmRvbSgpIH0sXG4gICAqICAgICB9KVxuICAgKiAgIH1cbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgU2VuZCBhIG1lc3NhZ2UgdmlhIHdlYnNvY2tldFxuICAgKiBgYGBqc1xuICAgKiBvayB8IHRpbWVkIG91dCB8IGVycm9yXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTZW5kIGEgbWVzc2FnZSB2aWEgUkVTVFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCBjaGFubmVsID0gc3VwYWJhc2UuY2hhbm5lbCgncm9vbTEnKVxuICAgKlxuICAgKiB0cnkge1xuICAgKiAgIGF3YWl0IGNoYW5uZWwuaHR0cFNlbmQoJ2N1cnNvci1wb3MnLCB7IHg6IE1hdGgucmFuZG9tKCksIHk6IE1hdGgucmFuZG9tKCkgfSlcbiAgICogfSBmaW5hbGx5IHtcbiAgICogICBhd2FpdCBzdXBhYmFzZS5yZW1vdmVDaGFubmVsKGNoYW5uZWwpXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBzZW5kKFxuICAgIGFyZ3M6IHtcbiAgICAgIHR5cGU6ICdicm9hZGNhc3QnIHwgJ3ByZXNlbmNlJyB8ICdwb3N0Z3Jlc19jaGFuZ2VzJ1xuICAgICAgZXZlbnQ6IHN0cmluZ1xuICAgICAgcGF5bG9hZD86IGFueVxuICAgICAgW2tleTogc3RyaW5nXTogYW55XG4gICAgfSxcbiAgICBvcHRzOiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0ge31cbiAgKTogUHJvbWlzZTxSZWFsdGltZUNoYW5uZWxTZW5kUmVzcG9uc2U+IHtcbiAgICBpZiAoIXRoaXMuY2hhbm5lbEFkYXB0ZXIuY2FuUHVzaCgpICYmIGFyZ3MudHlwZSA9PT0gJ2Jyb2FkY2FzdCcpIHtcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgJ1JlYWx0aW1lIHNlbmQoKSBpcyBhdXRvbWF0aWNhbGx5IGZhbGxpbmcgYmFjayB0byBSRVNUIEFQSS4gJyArXG4gICAgICAgICAgJ1RoaXMgYmVoYXZpb3Igd2lsbCBiZSBkZXByZWNhdGVkIGluIHRoZSBmdXR1cmUuICcgK1xuICAgICAgICAgICdQbGVhc2UgdXNlIGh0dHBTZW5kKCkgZXhwbGljaXRseSBmb3IgUkVTVCBkZWxpdmVyeS4nXG4gICAgICApXG5cbiAgICAgIGNvbnN0IHsgZXZlbnQsIHBheWxvYWQ6IGVuZHBvaW50X3BheWxvYWQgfSA9IGFyZ3NcbiAgICAgIGNvbnN0IGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgICAgIGFwaWtleTogdGhpcy5zb2NrZXQuYXBpS2V5ID8gdGhpcy5zb2NrZXQuYXBpS2V5IDogJycsXG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLnNvY2tldC5hY2Nlc3NUb2tlblZhbHVlKSB7XG4gICAgICAgIGhlYWRlcnNbJ0F1dGhvcml6YXRpb24nXSA9IGBCZWFyZXIgJHt0aGlzLnNvY2tldC5hY2Nlc3NUb2tlblZhbHVlfWBcbiAgICAgIH1cblxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBtZXNzYWdlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICB0b3BpYzogdGhpcy5zdWJUb3BpYyxcbiAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgIHBheWxvYWQ6IGVuZHBvaW50X3BheWxvYWQsXG4gICAgICAgICAgICAgIHByaXZhdGU6IHRoaXMucHJpdmF0ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgfSksXG4gICAgICB9XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5fZmV0Y2hXaXRoVGltZW91dChcbiAgICAgICAgICB0aGlzLmJyb2FkY2FzdEVuZHBvaW50VVJMLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgb3B0cy50aW1lb3V0ID8/IHRoaXMudGltZW91dFxuICAgICAgICApXG5cbiAgICAgICAgYXdhaXQgcmVzcG9uc2UuYm9keT8uY2FuY2VsKClcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rID8gJ29rJyA6ICdlcnJvcidcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yICYmIGVycm9yLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgICAgIHJldHVybiAndGltZWQgb3V0J1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiAnZXJyb3InXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIGNvbnN0IHB1c2ggPSB0aGlzLmNoYW5uZWxBZGFwdGVyLnB1c2goYXJncy50eXBlLCBhcmdzLCBvcHRzLnRpbWVvdXQgfHwgdGhpcy50aW1lb3V0KVxuXG4gICAgICAgIGlmIChhcmdzLnR5cGUgPT09ICdicm9hZGNhc3QnICYmICF0aGlzLnBhcmFtcz8uY29uZmlnPy5icm9hZGNhc3Q/LmFjaykge1xuICAgICAgICAgIHJlc29sdmUoJ29rJylcbiAgICAgICAgfVxuXG4gICAgICAgIHB1c2gucmVjZWl2ZSgnb2snLCAoKSA9PiByZXNvbHZlKCdvaycpKVxuICAgICAgICBwdXNoLnJlY2VpdmUoJ2Vycm9yJywgKCkgPT4gcmVzb2x2ZSgnZXJyb3InKSlcbiAgICAgICAgcHVzaC5yZWNlaXZlKCd0aW1lb3V0JywgKCkgPT4gcmVzb2x2ZSgndGltZWQgb3V0JykpXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGVzIHRoZSBwYXlsb2FkIHRoYXQgd2lsbCBiZSBzZW50IHRoZSBuZXh0IHRpbWUgdGhlIGNoYW5uZWwgam9pbnMgKHJlY29ubmVjdHMpLlxuICAgKiBVc2VmdWwgZm9yIHJvdGF0aW5nIGFjY2VzcyB0b2tlbnMgb3IgdXBkYXRpbmcgY29uZmlnIHdpdGhvdXQgcmUtY3JlYXRpbmcgdGhlIGNoYW5uZWwuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgdXBkYXRlSm9pblBheWxvYWQocGF5bG9hZDogUmVjb3JkPHN0cmluZywgYW55Pikge1xuICAgIHRoaXMuY2hhbm5lbEFkYXB0ZXIudXBkYXRlSm9pblBheWxvYWQocGF5bG9hZClcbiAgfVxuXG4gIC8qKlxuICAgKiBMZWF2ZXMgdGhlIGNoYW5uZWwuXG4gICAqXG4gICAqIFVuc3Vic2NyaWJlcyBmcm9tIHNlcnZlciBldmVudHMsIGFuZCBpbnN0cnVjdHMgY2hhbm5lbCB0byB0ZXJtaW5hdGUgb24gc2VydmVyLlxuICAgKiBUcmlnZ2VycyBvbkNsb3NlKCkgaG9va3MuXG4gICAqXG4gICAqIFRvIHJlY2VpdmUgbGVhdmUgYWNrbm93bGVkZ2VtZW50cywgdXNlIHRoZSBhIGByZWNlaXZlYCBob29rIHRvIGJpbmQgdG8gdGhlIHNlcnZlciBhY2ssIGllOlxuICAgKiBjaGFubmVsLnVuc3Vic2NyaWJlKCkucmVjZWl2ZShcIm9rXCIsICgpID0+IGFsZXJ0KFwibGVmdCFcIikgKVxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGFzeW5jIHVuc3Vic2NyaWJlKHRpbWVvdXQgPSB0aGlzLnRpbWVvdXQpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2U8UmVhbHRpbWVDaGFubmVsU2VuZFJlc3BvbnNlPigocmVzb2x2ZSkgPT4ge1xuICAgICAgdGhpcy5jaGFubmVsQWRhcHRlclxuICAgICAgICAudW5zdWJzY3JpYmUodGltZW91dClcbiAgICAgICAgLnJlY2VpdmUoJ29rJywgKCkgPT4gcmVzb2x2ZSgnb2snKSlcbiAgICAgICAgLnJlY2VpdmUoJ3RpbWVvdXQnLCAoKSA9PiByZXNvbHZlKCd0aW1lZCBvdXQnKSlcbiAgICAgICAgLnJlY2VpdmUoJ2Vycm9yJywgKCkgPT4gcmVzb2x2ZSgnZXJyb3InKSlcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3lzIGFuZCBzdG9wcyByZWxhdGVkIHRpbWVycy5cbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqL1xuICB0ZWFyZG93bigpIHtcbiAgICB0aGlzLmNoYW5uZWxBZGFwdGVyLnRlYXJkb3duKClcbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgYXN5bmMgX2ZldGNoV2l0aFRpbWVvdXQodXJsOiBzdHJpbmcsIG9wdGlvbnM6IHsgW2tleTogc3RyaW5nXTogYW55IH0sIHRpbWVvdXQ6IG51bWJlcikge1xuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcbiAgICBjb25zdCBpZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCB0aW1lb3V0KVxuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNvY2tldC5mZXRjaCh1cmwsIHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgIH0pXG5cbiAgICBjbGVhclRpbWVvdXQoaWQpXG5cbiAgICByZXR1cm4gcmVzcG9uc2VcbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgX29uKHR5cGU6IHN0cmluZywgZmlsdGVyOiB7IFtrZXk6IHN0cmluZ106IGFueSB9LCBjYWxsYmFjazogQ2hhbm5lbEJpbmRpbmdDYWxsYmFjaykge1xuICAgIGNvbnN0IHR5cGVMb3dlciA9IHR5cGUudG9Mb2NhbGVMb3dlckNhc2UoKVxuXG4gICAgY29uc3QgcmVmID0gdGhpcy5jaGFubmVsQWRhcHRlci5vbih0eXBlLCBjYWxsYmFjaylcblxuICAgIGNvbnN0IGJpbmRpbmc6IEJpbmRpbmcgPSB7XG4gICAgICB0eXBlOiB0eXBlTG93ZXIsXG4gICAgICBmaWx0ZXI6IGZpbHRlcixcbiAgICAgIGNhbGxiYWNrOiBjYWxsYmFjayxcbiAgICAgIHJlZjogcmVmLFxuICAgIH1cblxuICAgIGlmICh0aGlzLmJpbmRpbmdzW3R5cGVMb3dlcl0pIHtcbiAgICAgIHRoaXMuYmluZGluZ3NbdHlwZUxvd2VyXS5wdXNoKGJpbmRpbmcpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuYmluZGluZ3NbdHlwZUxvd2VyXSA9IFtiaW5kaW5nXVxuICAgIH1cblxuICAgIHRoaXMuX3VwZGF0ZUZpbHRlck1lc3NhZ2UoKVxuXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBjYWxsYmFjayB0aGF0IHdpbGwgYmUgZXhlY3V0ZWQgd2hlbiB0aGUgY2hhbm5lbCBjbG9zZXMuXG4gICAqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSBfb25DbG9zZShjYWxsYmFjazogQ2hhbm5lbEJpbmRpbmdDYWxsYmFjaykge1xuICAgIHRoaXMuY2hhbm5lbEFkYXB0ZXIub25DbG9zZShjYWxsYmFjaylcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBjYWxsYmFjayB0aGF0IHdpbGwgYmUgZXhlY3V0ZWQgd2hlbiB0aGUgY2hhbm5lbCBlbmNvdW50ZXJlcyBhbiBlcnJvci5cbiAgICpcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIF9vbkVycm9yKGNhbGxiYWNrOiBDaGFubmVsT25FcnJvckNhbGxiYWNrKSB7XG4gICAgdGhpcy5jaGFubmVsQWRhcHRlci5vbkVycm9yKGNhbGxiYWNrKVxuICB9XG5cbiAgLyoqIEBpbnRlcm5hbCAqL1xuICBwcml2YXRlIF91cGRhdGVGaWx0ZXJNZXNzYWdlKCkge1xuICAgIHRoaXMuY2hhbm5lbEFkYXB0ZXIudXBkYXRlRmlsdGVyQmluZGluZ3MoKGJpbmRpbmcsIHBheWxvYWQ6IGFueSwgcmVmKSA9PiB7XG4gICAgICBjb25zdCB0eXBlTG93ZXIgPSBiaW5kaW5nLmV2ZW50LnRvTG9jYWxlTG93ZXJDYXNlKClcblxuICAgICAgaWYgKHRoaXMuX25vdFRoaXNDaGFubmVsRXZlbnQodHlwZUxvd2VyLCByZWYpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICBjb25zdCBiaW5kID0gdGhpcy5iaW5kaW5nc1t0eXBlTG93ZXJdPy5maW5kKChiaW5kKSA9PiBiaW5kLnJlZiA9PT0gYmluZGluZy5yZWYpXG5cbiAgICAgIGlmICghYmluZCkge1xuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgfVxuXG4gICAgICBpZiAoWydicm9hZGNhc3QnLCAncHJlc2VuY2UnLCAncG9zdGdyZXNfY2hhbmdlcyddLmluY2x1ZGVzKHR5cGVMb3dlcikpIHtcbiAgICAgICAgaWYgKCdpZCcgaW4gYmluZCkge1xuICAgICAgICAgIGNvbnN0IGJpbmRJZCA9IGJpbmQuaWRcbiAgICAgICAgICBjb25zdCBiaW5kRXZlbnQgPSBiaW5kLmZpbHRlcj8uZXZlbnRcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgYmluZElkICYmXG4gICAgICAgICAgICBwYXlsb2FkLmlkcz8uaW5jbHVkZXMoYmluZElkKSAmJlxuICAgICAgICAgICAgKGJpbmRFdmVudCA9PT0gJyonIHx8XG4gICAgICAgICAgICAgIGJpbmRFdmVudD8udG9Mb2NhbGVMb3dlckNhc2UoKSA9PT0gcGF5bG9hZC5kYXRhPy50eXBlLnRvTG9jYWxlTG93ZXJDYXNlKCkpXG4gICAgICAgICAgKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGJpbmRFdmVudCA9IGJpbmQ/LmZpbHRlcj8uZXZlbnQ/LnRvTG9jYWxlTG93ZXJDYXNlKClcbiAgICAgICAgICByZXR1cm4gYmluZEV2ZW50ID09PSAnKicgfHwgYmluZEV2ZW50ID09PSBwYXlsb2FkPy5ldmVudD8udG9Mb2NhbGVMb3dlckNhc2UoKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gYmluZC50eXBlLnRvTG9jYWxlTG93ZXJDYXNlKCkgPT09IHR5cGVMb3dlclxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICAvKiogQGludGVybmFsICovXG4gIHByaXZhdGUgX25vdFRoaXNDaGFubmVsRXZlbnQoZXZlbnQ6IHN0cmluZywgcmVmPzogc3RyaW5nIHwgbnVsbCkge1xuICAgIGNvbnN0IHsgY2xvc2UsIGVycm9yLCBsZWF2ZSwgam9pbiB9ID0gQ0hBTk5FTF9FVkVOVFNcbiAgICBjb25zdCBldmVudHM6IHN0cmluZ1tdID0gW2Nsb3NlLCBlcnJvciwgbGVhdmUsIGpvaW5dXG4gICAgcmV0dXJuIHJlZiAmJiBldmVudHMuaW5jbHVkZXMoZXZlbnQpICYmIHJlZiAhPT0gdGhpcy5qb2luUHVzaC5yZWZcbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgcHJpdmF0ZSBfdXBkYXRlRmlsdGVyVHJhbnNmb3JtKCkge1xuICAgIHRoaXMuY2hhbm5lbEFkYXB0ZXIudXBkYXRlUGF5bG9hZFRyYW5zZm9ybSgoZXZlbnQsIHBheWxvYWQ6IGFueSwgcmVmKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIHBheWxvYWQgPT09ICdvYmplY3QnICYmICdpZHMnIGluIHBheWxvYWQpIHtcbiAgICAgICAgY29uc3QgcG9zdGdyZXNDaGFuZ2VzID0gcGF5bG9hZC5kYXRhXG4gICAgICAgIGNvbnN0IHsgc2NoZW1hLCB0YWJsZSwgY29tbWl0X3RpbWVzdGFtcCwgdHlwZSwgZXJyb3JzIH0gPSBwb3N0Z3Jlc0NoYW5nZXNcbiAgICAgICAgY29uc3QgZW5yaWNoZWRQYXlsb2FkID0ge1xuICAgICAgICAgIHNjaGVtYTogc2NoZW1hLFxuICAgICAgICAgIHRhYmxlOiB0YWJsZSxcbiAgICAgICAgICBjb21taXRfdGltZXN0YW1wOiBjb21taXRfdGltZXN0YW1wLFxuICAgICAgICAgIGV2ZW50VHlwZTogdHlwZSxcbiAgICAgICAgICBuZXc6IHt9LFxuICAgICAgICAgIG9sZDoge30sXG4gICAgICAgICAgZXJyb3JzOiBlcnJvcnMsXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi5lbnJpY2hlZFBheWxvYWQsXG4gICAgICAgICAgLi4udGhpcy5fZ2V0UGF5bG9hZFJlY29yZHMocG9zdGdyZXNDaGFuZ2VzKSxcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gcGF5bG9hZFxuICAgIH0pXG4gIH1cblxuICBjb3B5QmluZGluZ3Mob3RoZXI6IFJlYWx0aW1lQ2hhbm5lbCkge1xuICAgIGlmICh0aGlzLmpvaW5lZE9uY2UpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignY2Fubm90IGNvcHkgYmluZGluZ3MgaW50byBqb2luZWQgY2hhbm5lbCcpXG4gICAgfVxuICAgIGZvciAoY29uc3Qga2luZCBpbiBvdGhlci5iaW5kaW5ncykge1xuICAgICAgZm9yIChjb25zdCBiaW5kaW5nIG9mIG90aGVyLmJpbmRpbmdzW2tpbmRdKSB7XG4gICAgICAgIHRoaXMuX29uKGJpbmRpbmcudHlwZSwgYmluZGluZy5maWx0ZXIsIGJpbmRpbmcuY2FsbGJhY2spXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENvbXBhcmVzIHR3byBvcHRpb25hbCBmaWx0ZXIgdmFsdWVzIGZvciBlcXVhbGl0eS5cbiAgICogVHJlYXRzIHVuZGVmaW5lZCwgbnVsbCwgYW5kIGVtcHR5IHN0cmluZyBhcyBlcXVpdmFsZW50IGVtcHR5IHZhbHVlcy5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIHN0YXRpYyBpc0ZpbHRlclZhbHVlRXF1YWwoXG4gICAgc2VydmVyVmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCB8IG51bGwsXG4gICAgY2xpZW50VmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZFxuICApOiBib29sZWFuIHtcbiAgICBjb25zdCBub3JtYWxpemVkU2VydmVyID0gc2VydmVyVmFsdWUgPz8gdW5kZWZpbmVkXG4gICAgY29uc3Qgbm9ybWFsaXplZENsaWVudCA9IGNsaWVudFZhbHVlID8/IHVuZGVmaW5lZFxuICAgIHJldHVybiBub3JtYWxpemVkU2VydmVyID09PSBub3JtYWxpemVkQ2xpZW50XG4gIH1cblxuICAvKiogQGludGVybmFsICovXG4gIHByaXZhdGUgX2dldFBheWxvYWRSZWNvcmRzKHBheWxvYWQ6IGFueSkge1xuICAgIGNvbnN0IHJlY29yZHMgPSB7XG4gICAgICBuZXc6IHt9LFxuICAgICAgb2xkOiB7fSxcbiAgICB9XG5cbiAgICBpZiAocGF5bG9hZC50eXBlID09PSAnSU5TRVJUJyB8fCBwYXlsb2FkLnR5cGUgPT09ICdVUERBVEUnKSB7XG4gICAgICByZWNvcmRzLm5ldyA9IFRyYW5zZm9ybWVycy5jb252ZXJ0Q2hhbmdlRGF0YShwYXlsb2FkLmNvbHVtbnMsIHBheWxvYWQucmVjb3JkKVxuICAgIH1cblxuICAgIGlmIChwYXlsb2FkLnR5cGUgPT09ICdVUERBVEUnIHx8IHBheWxvYWQudHlwZSA9PT0gJ0RFTEVURScpIHtcbiAgICAgIHJlY29yZHMub2xkID0gVHJhbnNmb3JtZXJzLmNvbnZlcnRDaGFuZ2VEYXRhKHBheWxvYWQuY29sdW1ucywgcGF5bG9hZC5vbGRfcmVjb3JkKVxuICAgIH1cblxuICAgIHJldHVybiByZWNvcmRzXG4gIH1cbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19