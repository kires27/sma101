import { Presence } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+phoenix@0.4.2/node_modules/@supabase/phoenix/priv/static/phoenix.mjs?v=583078ff";
export default class PresenceAdapter {
    constructor(channel, opts) {
        const phoenixOptions = phoenixPresenceOptions(opts);
        this.presence = new Presence(channel.getChannel(), phoenixOptions);
        this.presence.onJoin((key, currentPresence, newPresence) => {
            const onJoinPayload = PresenceAdapter.onJoinPayload(key, currentPresence, newPresence);
            channel.getChannel().trigger('presence', onJoinPayload);
        });
        this.presence.onLeave((key, currentPresence, leftPresence) => {
            const onLeavePayload = PresenceAdapter.onLeavePayload(key, currentPresence, leftPresence);
            channel.getChannel().trigger('presence', onLeavePayload);
        });
        this.presence.onSync(() => {
            channel.getChannel().trigger('presence', { event: 'sync' });
        });
    }
    get state() {
        return PresenceAdapter.transformState(this.presence.state);
    }
    /**
     * @private
     * Remove 'metas' key
     * Change 'phx_ref' to 'presence_ref'
     * Remove 'phx_ref' and 'phx_ref_prev'
     *
     * @example Transform state
     * // returns {
     *  abc123: [
     *    { presence_ref: '2', user_id: 1 },
     *    { presence_ref: '3', user_id: 2 }
     *  ]
     * }
     * RealtimePresence.transformState({
     *  abc123: {
     *    metas: [
     *      { phx_ref: '2', phx_ref_prev: '1' user_id: 1 },
     *      { phx_ref: '3', user_id: 2 }
     *    ]
     *  }
     * })
     *
     */
    static transformState(state) {
        state = cloneState(state);
        return Object.getOwnPropertyNames(state).reduce((newState, key) => {
            const presences = state[key];
            newState[key] = transformState(presences);
            return newState;
        }, {});
    }
    static onJoinPayload(key, currentPresence, newPresence) {
        const currentPresences = parseCurrentPresences(currentPresence);
        const newPresences = transformState(newPresence);
        return {
            event: 'join',
            key,
            currentPresences,
            newPresences,
        };
    }
    static onLeavePayload(key, currentPresence, leftPresence) {
        const currentPresences = parseCurrentPresences(currentPresence);
        const leftPresences = transformState(leftPresence);
        return {
            event: 'leave',
            key,
            currentPresences,
            leftPresences,
        };
    }
}
function transformState(presences) {
    return presences.metas.map((presence) => {
        presence['presence_ref'] = presence['phx_ref'];
        delete presence['phx_ref'];
        delete presence['phx_ref_prev'];
        return presence;
    });
}
function cloneState(state) {
    return JSON.parse(JSON.stringify(state));
}
function phoenixPresenceOptions(opts) {
    return (opts === null || opts === void 0 ? void 0 : opts.events) && { events: opts.events };
}
function parseCurrentPresences(currentPresences) {
    return (currentPresences === null || currentPresences === void 0 ? void 0 : currentPresences.metas) ? transformState(currentPresences) : [];
}
                                           
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJlc2VuY2VBZGFwdGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3Bob2VuaXgvcHJlc2VuY2VBZGFwdGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQTtBQVM1QyxNQUFNLENBQUMsT0FBTyxPQUFPLGVBQWU7SUFHbEMsWUFBWSxPQUF1QixFQUFFLElBQThCO1FBQ2pFLE1BQU0sY0FBYyxHQUFHLHNCQUFzQixDQUFDLElBQUksQ0FBQyxDQUFBO1FBQ25ELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFLGNBQWMsQ0FBQyxDQUFBO1FBRWxFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLGVBQWUsRUFBRSxXQUFXLEVBQUUsRUFBRTtZQUN6RCxNQUFNLGFBQWEsR0FBRyxlQUFlLENBQUMsYUFBYSxDQUFDLEdBQUcsRUFBRSxlQUFlLEVBQUUsV0FBVyxDQUFDLENBQUE7WUFDdEYsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsYUFBYSxDQUFDLENBQUE7UUFDekQsQ0FBQyxDQUFDLENBQUE7UUFFRixJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxlQUFlLEVBQUUsWUFBWSxFQUFFLEVBQUU7WUFDM0QsTUFBTSxjQUFjLEdBQUcsZUFBZSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsZUFBZSxFQUFFLFlBQVksQ0FBQyxDQUFBO1lBQ3pGLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLGNBQWMsQ0FBQyxDQUFBO1FBQzFELENBQUMsQ0FBQyxDQUFBO1FBRUYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO1lBQ3hCLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUE7UUFDN0QsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ1AsT0FBTyxlQUFlLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDNUQsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bc0JHO0lBQ0gsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFxQjtRQUN6QyxLQUFLLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBRXpCLE9BQU8sTUFBTSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUNoRSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7WUFDNUIsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtZQUV6QyxPQUFPLFFBQVEsQ0FBQTtRQUNqQixDQUFDLEVBQUUsRUFBMkIsQ0FBQyxDQUFBO0lBQ2pDLENBQUM7SUFFRCxNQUFNLENBQUMsYUFBYSxDQUFDLEdBQVcsRUFBRSxlQUE4QixFQUFFLFdBQTBCO1FBQzFGLE1BQU0sZ0JBQWdCLEdBQUcscUJBQXFCLENBQUMsZUFBZSxDQUFDLENBQUE7UUFDL0QsTUFBTSxZQUFZLEdBQUcsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFBO1FBRWhELE9BQU87WUFDTCxLQUFLLEVBQUUsTUFBTTtZQUNiLEdBQUc7WUFDSCxnQkFBZ0I7WUFDaEIsWUFBWTtTQUNiLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFXLEVBQUUsZUFBOEIsRUFBRSxZQUEyQjtRQUM1RixNQUFNLGdCQUFnQixHQUFHLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxDQUFBO1FBQy9ELE1BQU0sYUFBYSxHQUFHLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQTtRQUVsRCxPQUFPO1lBQ0wsS0FBSyxFQUFFLE9BQU87WUFDZCxHQUFHO1lBQ0gsZ0JBQWdCO1lBQ2hCLGFBQWE7U0FDZCxDQUFBO0lBQ0gsQ0FBQztDQUNGO0FBRUQsU0FBUyxjQUFjLENBQUMsU0FBd0I7SUFDOUMsT0FBTyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1FBQ3RDLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFOUMsT0FBTyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUE7UUFDMUIsT0FBTyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUE7UUFFL0IsT0FBTyxRQUFRLENBQUE7SUFDakIsQ0FBQyxDQUEyQixDQUFBO0FBQzlCLENBQUM7QUFFRCxTQUFTLFVBQVUsQ0FBQyxLQUFxQjtJQUN2QyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFBO0FBQzFDLENBQUM7QUFFRCxTQUFTLHNCQUFzQixDQUFDLElBQThCO0lBQzVELE9BQU8sQ0FBQSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsTUFBTSxLQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQTtBQUNoRCxDQUFDO0FBRUQsU0FBUyxxQkFBcUIsQ0FBQyxnQkFBZ0M7SUFDN0QsT0FBTyxDQUFBLGdCQUFnQixhQUFoQixnQkFBZ0IsdUJBQWhCLGdCQUFnQixDQUFFLEtBQUssRUFBQyxDQUFDLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtBQUN4RSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUHJlc2VuY2UgfSBmcm9tICdAc3VwYWJhc2UvcGhvZW5peCdcbmltcG9ydCB0eXBlIHsgUHJlc2VuY2VTdGF0ZSwgUHJlc2VuY2VTdGF0ZXMgfSBmcm9tICcuL3R5cGVzJ1xuaW1wb3J0IHR5cGUge1xuICBSZWFsdGltZVByZXNlbmNlT3B0aW9ucyxcbiAgUmVhbHRpbWVQcmVzZW5jZVN0YXRlLFxuICBQcmVzZW5jZSBhcyBSZWFsdGltZVByZXNlbmNlVHlwZSxcbn0gZnJvbSAnLi4vUmVhbHRpbWVQcmVzZW5jZSdcbmltcG9ydCBDaGFubmVsQWRhcHRlciBmcm9tICcuL2NoYW5uZWxBZGFwdGVyJ1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQcmVzZW5jZUFkYXB0ZXIge1xuICBwcml2YXRlIHByZXNlbmNlOiBQcmVzZW5jZVxuXG4gIGNvbnN0cnVjdG9yKGNoYW5uZWw6IENoYW5uZWxBZGFwdGVyLCBvcHRzPzogUmVhbHRpbWVQcmVzZW5jZU9wdGlvbnMpIHtcbiAgICBjb25zdCBwaG9lbml4T3B0aW9ucyA9IHBob2VuaXhQcmVzZW5jZU9wdGlvbnMob3B0cylcbiAgICB0aGlzLnByZXNlbmNlID0gbmV3IFByZXNlbmNlKGNoYW5uZWwuZ2V0Q2hhbm5lbCgpLCBwaG9lbml4T3B0aW9ucylcblxuICAgIHRoaXMucHJlc2VuY2Uub25Kb2luKChrZXksIGN1cnJlbnRQcmVzZW5jZSwgbmV3UHJlc2VuY2UpID0+IHtcbiAgICAgIGNvbnN0IG9uSm9pblBheWxvYWQgPSBQcmVzZW5jZUFkYXB0ZXIub25Kb2luUGF5bG9hZChrZXksIGN1cnJlbnRQcmVzZW5jZSwgbmV3UHJlc2VuY2UpXG4gICAgICBjaGFubmVsLmdldENoYW5uZWwoKS50cmlnZ2VyKCdwcmVzZW5jZScsIG9uSm9pblBheWxvYWQpXG4gICAgfSlcblxuICAgIHRoaXMucHJlc2VuY2Uub25MZWF2ZSgoa2V5LCBjdXJyZW50UHJlc2VuY2UsIGxlZnRQcmVzZW5jZSkgPT4ge1xuICAgICAgY29uc3Qgb25MZWF2ZVBheWxvYWQgPSBQcmVzZW5jZUFkYXB0ZXIub25MZWF2ZVBheWxvYWQoa2V5LCBjdXJyZW50UHJlc2VuY2UsIGxlZnRQcmVzZW5jZSlcbiAgICAgIGNoYW5uZWwuZ2V0Q2hhbm5lbCgpLnRyaWdnZXIoJ3ByZXNlbmNlJywgb25MZWF2ZVBheWxvYWQpXG4gICAgfSlcblxuICAgIHRoaXMucHJlc2VuY2Uub25TeW5jKCgpID0+IHtcbiAgICAgIGNoYW5uZWwuZ2V0Q2hhbm5lbCgpLnRyaWdnZXIoJ3ByZXNlbmNlJywgeyBldmVudDogJ3N5bmMnIH0pXG4gICAgfSlcbiAgfVxuXG4gIGdldCBzdGF0ZSgpIHtcbiAgICByZXR1cm4gUHJlc2VuY2VBZGFwdGVyLnRyYW5zZm9ybVN0YXRlKHRoaXMucHJlc2VuY2Uuc3RhdGUpXG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICogUmVtb3ZlICdtZXRhcycga2V5XG4gICAqIENoYW5nZSAncGh4X3JlZicgdG8gJ3ByZXNlbmNlX3JlZidcbiAgICogUmVtb3ZlICdwaHhfcmVmJyBhbmQgJ3BoeF9yZWZfcHJldidcbiAgICpcbiAgICogQGV4YW1wbGUgVHJhbnNmb3JtIHN0YXRlXG4gICAqIC8vIHJldHVybnMge1xuICAgKiAgYWJjMTIzOiBbXG4gICAqICAgIHsgcHJlc2VuY2VfcmVmOiAnMicsIHVzZXJfaWQ6IDEgfSxcbiAgICogICAgeyBwcmVzZW5jZV9yZWY6ICczJywgdXNlcl9pZDogMiB9XG4gICAqICBdXG4gICAqIH1cbiAgICogUmVhbHRpbWVQcmVzZW5jZS50cmFuc2Zvcm1TdGF0ZSh7XG4gICAqICBhYmMxMjM6IHtcbiAgICogICAgbWV0YXM6IFtcbiAgICogICAgICB7IHBoeF9yZWY6ICcyJywgcGh4X3JlZl9wcmV2OiAnMScgdXNlcl9pZDogMSB9LFxuICAgKiAgICAgIHsgcGh4X3JlZjogJzMnLCB1c2VyX2lkOiAyIH1cbiAgICogICAgXVxuICAgKiAgfVxuICAgKiB9KVxuICAgKlxuICAgKi9cbiAgc3RhdGljIHRyYW5zZm9ybVN0YXRlKHN0YXRlOiBQcmVzZW5jZVN0YXRlcyk6IFJlYWx0aW1lUHJlc2VuY2VTdGF0ZSB7XG4gICAgc3RhdGUgPSBjbG9uZVN0YXRlKHN0YXRlKVxuXG4gICAgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHN0YXRlKS5yZWR1Y2UoKG5ld1N0YXRlLCBrZXkpID0+IHtcbiAgICAgIGNvbnN0IHByZXNlbmNlcyA9IHN0YXRlW2tleV1cbiAgICAgIG5ld1N0YXRlW2tleV0gPSB0cmFuc2Zvcm1TdGF0ZShwcmVzZW5jZXMpXG5cbiAgICAgIHJldHVybiBuZXdTdGF0ZVxuICAgIH0sIHt9IGFzIFJlYWx0aW1lUHJlc2VuY2VTdGF0ZSlcbiAgfVxuXG4gIHN0YXRpYyBvbkpvaW5QYXlsb2FkKGtleTogc3RyaW5nLCBjdXJyZW50UHJlc2VuY2U6IFByZXNlbmNlU3RhdGUsIG5ld1ByZXNlbmNlOiBQcmVzZW5jZVN0YXRlKSB7XG4gICAgY29uc3QgY3VycmVudFByZXNlbmNlcyA9IHBhcnNlQ3VycmVudFByZXNlbmNlcyhjdXJyZW50UHJlc2VuY2UpXG4gICAgY29uc3QgbmV3UHJlc2VuY2VzID0gdHJhbnNmb3JtU3RhdGUobmV3UHJlc2VuY2UpXG5cbiAgICByZXR1cm4ge1xuICAgICAgZXZlbnQ6ICdqb2luJyxcbiAgICAgIGtleSxcbiAgICAgIGN1cnJlbnRQcmVzZW5jZXMsXG4gICAgICBuZXdQcmVzZW5jZXMsXG4gICAgfVxuICB9XG5cbiAgc3RhdGljIG9uTGVhdmVQYXlsb2FkKGtleTogc3RyaW5nLCBjdXJyZW50UHJlc2VuY2U6IFByZXNlbmNlU3RhdGUsIGxlZnRQcmVzZW5jZTogUHJlc2VuY2VTdGF0ZSkge1xuICAgIGNvbnN0IGN1cnJlbnRQcmVzZW5jZXMgPSBwYXJzZUN1cnJlbnRQcmVzZW5jZXMoY3VycmVudFByZXNlbmNlKVxuICAgIGNvbnN0IGxlZnRQcmVzZW5jZXMgPSB0cmFuc2Zvcm1TdGF0ZShsZWZ0UHJlc2VuY2UpXG5cbiAgICByZXR1cm4ge1xuICAgICAgZXZlbnQ6ICdsZWF2ZScsXG4gICAgICBrZXksXG4gICAgICBjdXJyZW50UHJlc2VuY2VzLFxuICAgICAgbGVmdFByZXNlbmNlcyxcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gdHJhbnNmb3JtU3RhdGUocHJlc2VuY2VzOiBQcmVzZW5jZVN0YXRlKSB7XG4gIHJldHVybiBwcmVzZW5jZXMubWV0YXMubWFwKChwcmVzZW5jZSkgPT4ge1xuICAgIHByZXNlbmNlWydwcmVzZW5jZV9yZWYnXSA9IHByZXNlbmNlWydwaHhfcmVmJ11cblxuICAgIGRlbGV0ZSBwcmVzZW5jZVsncGh4X3JlZiddXG4gICAgZGVsZXRlIHByZXNlbmNlWydwaHhfcmVmX3ByZXYnXVxuXG4gICAgcmV0dXJuIHByZXNlbmNlXG4gIH0pIGFzIFJlYWx0aW1lUHJlc2VuY2VUeXBlW11cbn1cblxuZnVuY3Rpb24gY2xvbmVTdGF0ZShzdGF0ZTogUHJlc2VuY2VTdGF0ZXMpOiBQcmVzZW5jZVN0YXRlcyB7XG4gIHJldHVybiBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHN0YXRlKSlcbn1cblxuZnVuY3Rpb24gcGhvZW5peFByZXNlbmNlT3B0aW9ucyhvcHRzPzogUmVhbHRpbWVQcmVzZW5jZU9wdGlvbnMpIHtcbiAgcmV0dXJuIG9wdHM/LmV2ZW50cyAmJiB7IGV2ZW50czogb3B0cy5ldmVudHMgfVxufVxuXG5mdW5jdGlvbiBwYXJzZUN1cnJlbnRQcmVzZW5jZXMoY3VycmVudFByZXNlbmNlcz86IFByZXNlbmNlU3RhdGUpIHtcbiAgcmV0dXJuIGN1cnJlbnRQcmVzZW5jZXM/Lm1ldGFzID8gdHJhbnNmb3JtU3RhdGUoY3VycmVudFByZXNlbmNlcykgOiBbXVxufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=