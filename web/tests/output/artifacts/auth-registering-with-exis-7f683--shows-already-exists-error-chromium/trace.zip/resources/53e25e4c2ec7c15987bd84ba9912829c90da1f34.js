import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/pages/auth/[action].vue");import { default as __nuxt_component_0 } from "/_nuxt/ui/Text.vue";
import { default as __nuxt_component_1 } from "/_nuxt/ui/Input.vue";
import { default as __nuxt_component_2 } from "/_nuxt/ui/Checkbox.vue";
import { default as __nuxt_component_3 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/components/nuxt-link.js?v=583078ff";
import { default as __nuxt_component_4 } from "/_nuxt/ui/Button.vue";
import { default as __nuxt_component_5 } from "/_nuxt/ui/Section.vue";
import { default as __nuxt_component_6 } from "/_nuxt/ui/Container.vue";
import { default as __nuxt_component_7 } from "/_nuxt/ui/Footer.vue";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"
import { URI } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/shared/constants/routes.js"
import { Icon } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@iconify+vue@5.0.1_vue@3.5.38_typescript@5.9.3_/node_modules/@iconify/vue/dist/iconify.mjs"
import { validateRegistrationInput } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/shared/validators/user-registration.js"



import { useRoute, navigateTo } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/composables/router.js?v=583078ff";
import { computed, ref } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
import { createError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/composables/error.js?v=583078ff";
import { useSupabaseClient } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@nuxtjs+supabase@2.0.9/node_modules/@nuxtjs/supabase/dist/runtime/composables/useSupabaseClient.js?v=583078ff";
const _sfc_main = {
  __name: '[action]',
  setup(__props, { expose: __expose }) {
  __expose();

const route = useRoute()

const action = computed(() => route.params.action)

const isLogin = computed(() => action.value === 'login')

if (!['login', 'register'].includes(action.value)) {
	throw createError({
		statusCode: 404
	})
}

const supabase = useSupabaseClient();

const email = ref('');
const password = ref('');
const confirmPassword = ref('');
const rememberMe = ref(false);
const loading = ref(false);
const error = ref('');
const info = ref('');
const showPasswordChecks = ref(false)

const handlePasswordFocus = () => {
	showPasswordChecks.value = true
}

const passwordChecks = computed(() => {
	return validateRegistrationInput('', password.value).checks
})

// Centralized error message extraction — handles the fact that
// statusMessage can be sanitized in production, so we prefer
// data.message (set explicitly on the server) as the source of truth.
const extractErrorMessage = (err, fallback) => {
	return (
		err?.data?.data?.message ||
		err?.data?.statusMessage ||
		err?.message ||
		fallback
	)
}

const handleSubmit = async () => {
	if (isLogin.value) {
		if (!email.value || !password.value) {
			error.value = 'Please fill in all fields'
			return
		}

		loading.value = true
		error.value = ''
		info.value = ''

		try {
			const { data, error: authError } = await supabase.auth.signInWithPassword({
				email: email.value,
				password: password.value
			})

			if (authError) {
				error.value = authError.message
			} else {
				info.value = 'Login successful!'
				navigateTo(URI.home)
			}
		} catch (err) {
			error.value = err instanceof Error ? err.message : 'Unknown error'
		} finally {
			loading.value = false
		}
	} else {
		const validation = validateRegistrationInput(email.value, password.value)

		if (!validation.isValid) {
			error.value = Object.values(validation.errors).join(', ')
			return
		}

		if (password.value !== confirmPassword.value) {
			error.value = 'Passwords do not match'
			return
		}

		loading.value = true
		error.value = ''
		info.value = ''

		try {
			await $fetch('/api/user/create', {
				method: 'POST',
				body: { email: email.value, password: password.value },
			})

			info.value = 'Account created! Please check your email to confirm.'
		} catch (err) {
			error.value = extractErrorMessage(err, 'Registration failed')
		} finally {
			loading.value = false
		}
	}
}

const handleGoogleLogin = async () => {
	const { error: googleError } = await supabase.auth.signInWithOAuth({
		provider: 'google'
	})
	if (googleError) error.value = googleError.message
}

const handleForgotPassword = async () => {
	if (!email.value) {
		error.value = 'Please enter your email address'
		return
	}

	loading.value = true
	error.value = ''
	info.value = ''

	try {
		const { error: resetError } = await supabase.auth.resetPasswordForEmail(email.value, {
			redirectTo: `${window.location.origin}/reset-password`
		})

		if (resetError) {
			error.value = resetError.message
		} else {
			info.value = 'Password reset email sent!'
		}
	} catch (err) {
		error.value = err instanceof Error ? err.message : 'Unknown error'
	} finally {
		loading.value = false
	}
}

const __returned__ = { route, action, isLogin, supabase, email, password, confirmPassword, rememberMe, loading, error, info, showPasswordChecks, handlePasswordFocus, passwordChecks, extractErrorMessage, handleSubmit, handleGoogleLogin, handleForgotPassword, get URI() { return URI }, get Icon() { return Icon }, get validateRegistrationInput() { return validateRegistrationInput } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, createElementVNode as _createElementVNode, normalizeClass as _normalizeClass, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, Transition as _Transition, withModifiers as _withModifiers, Fragment as _Fragment } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

const _hoisted_1 = { class: "card" }
const _hoisted_2 = { class: "form-group" }
const _hoisted_3 = { class: "form-group" }
const _hoisted_4 = {
  key: 0,
  class: "password-checks"
}
const _hoisted_5 = {
  key: 0,
  class: "form-group"
}
const _hoisted_6 = {
  key: 1,
  class: "row"
}
const _hoisted_7 = {
  key: 2,
  class: "error-text"
}
const _hoisted_8 = {
  key: 3,
  class: "info-text"
}
const _hoisted_9 = { class: "or-text" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Text = __nuxt_component_0
  const _component_Input = __nuxt_component_1
  const _component_Checkbox = __nuxt_component_2
  const _component_NuxtLink = __nuxt_component_3
  const _component_Button = __nuxt_component_4
  const _component_Section = __nuxt_component_5
  const _component_Container = __nuxt_component_6
  const _component_Footer = __nuxt_component_7

  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _tracer(145,1,_createVNode(_component_Container, { hAlign: "center" }, {
      default: _withCtx(() => [
        _tracer(146,2,_createVNode(_component_Section, { class: "auth-section" }, {
          default: _withCtx(() => [
            _tracer(147,3,_createElementVNode("div", _hoisted_1, [
              _tracer(148,4,_createVNode(_component_Text, { variant: "h3" }, {
                default: _withCtx(() => [
                  _createTextVNode(_toDisplayString($setup.isLogin ? 'Sign in' : 'Sign up'), 1 /* TEXT */)
                ]),
                _: 1 /* STABLE */
              })),
              _tracer(150,4,_createElementVNode("form", {
                class: "form",
                onSubmit: _withModifiers($setup.handleSubmit, ["prevent"])
              }, [
                _tracer(151,5,_createElementVNode("div", _hoisted_2, [
                  _tracer(152,6,_createVNode(_component_Text, { variant: "label" }, {
                    default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
                      _createTextVNode("Email or mobile", -1 /* CACHED */)
                    ]))]),
                    _: 1 /* STABLE */
                  })),
                  _tracer(153,6,_createVNode(_component_Input, {
                    modelValue: $setup.email,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.email) = $event)),
                    type: "text",
                    placeholder: "Email or mobile phone number"
                  }, null, 8 /* PROPS */, ["modelValue"]))
                ])),
                _tracer(156,5,_createElementVNode("div", _hoisted_3, [
                  _tracer(157,6,_createVNode(_component_Text, { variant: "label" }, {
                    default: _withCtx(() => [...(_cache[5] || (_cache[5] = [
                      _createTextVNode("Password", -1 /* CACHED */)
                    ]))]),
                    _: 1 /* STABLE */
                  })),
                  _tracer(158,6,_createVNode(_component_Input, {
                    modelValue: $setup.password,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.password) = $event)),
                    type: "password",
                    placeholder: "Password",
                    onFocus: $setup.handlePasswordFocus
                  }, null, 8 /* PROPS */, ["modelValue"])),
                  _tracer(159,6,_createVNode(_Transition, { name: "fade-slide" }, {
                    default: _withCtx(() => [
                      (!$setup.isLogin && $setup.showPasswordChecks)
                        ? (_openBlock(), _tracer(160,7,_createElementBlock("div", _hoisted_4, [
                            _tracer(161,8,_createElementVNode("div", {
                              class: _normalizeClass(["check-row", { met: $setup.passwordChecks.case }])
                            }, [
                              _tracer(162,9,_createVNode($setup["Icon"], {
                                icon: $setup.passwordChecks.case
										? 'material-symbols:check-circle'
										: 'material-symbols:check-circle-outline',
                                width: "16",
                                height: "16"
                              }, null, 8 /* PROPS */, ["icon"])),
                              _tracer(165,9,_createVNode(_component_Text, {
                                variant: "body-sm",
                                tone: "muted"
                              }, {
                                default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
                                  _createTextVNode("Lowercase & uppercase letters", -1 /* CACHED */)
                                ]))]),
                                _: 1 /* STABLE */
                              }))
                            ], 2 /* CLASS */)),
                            _tracer(167,8,_createElementVNode("div", {
                              class: _normalizeClass(["check-row", { met: $setup.passwordChecks.length }])
                            }, [
                              _tracer(168,9,_createVNode($setup["Icon"], {
                                icon: $setup.passwordChecks.length
										? 'material-symbols:check-circle'
										: 'material-symbols:check-circle-outline',
                                width: "16",
                                height: "16"
                              }, null, 8 /* PROPS */, ["icon"])),
                              _tracer(171,9,_createVNode(_component_Text, {
                                variant: "body-sm",
                                tone: "muted"
                              }, {
                                default: _withCtx(() => [...(_cache[7] || (_cache[7] = [
                                  _createTextVNode("At least 8 characters", -1 /* CACHED */)
                                ]))]),
                                _: 1 /* STABLE */
                              }))
                            ], 2 /* CLASS */)),
                            _tracer(173,8,_createElementVNode("div", {
                              class: _normalizeClass(["check-row", { met: $setup.passwordChecks.number }])
                            }, [
                              _tracer(174,9,_createVNode($setup["Icon"], {
                                icon: $setup.passwordChecks.number
										? 'material-symbols:check-circle'
										: 'material-symbols:check-circle-outline',
                                width: "16",
                                height: "16"
                              }, null, 8 /* PROPS */, ["icon"])),
                              _tracer(177,9,_createVNode(_component_Text, {
                                variant: "body-sm",
                                tone: "muted"
                              }, {
                                default: _withCtx(() => [...(_cache[8] || (_cache[8] = [
                                  _createTextVNode("Contains a number", -1 /* CACHED */)
                                ]))]),
                                _: 1 /* STABLE */
                              }))
                            ], 2 /* CLASS */))
                          ])))
                        : _createCommentVNode("v-if", true)
                    ]),
                    _: 1 /* STABLE */
                  }))
                ])),
                (!$setup.isLogin)
                  ? (_openBlock(), _tracer(183,5,_createElementBlock("div", _hoisted_5, [
                      _tracer(184,6,_createVNode(_component_Text, { variant: "label" }, {
                        default: _withCtx(() => [...(_cache[9] || (_cache[9] = [
                          _createTextVNode("Confirm password", -1 /* CACHED */)
                        ]))]),
                        _: 1 /* STABLE */
                      })),
                      _tracer(185,6,_createVNode(_component_Input, {
                        modelValue: $setup.confirmPassword,
                        "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.confirmPassword) = $event)),
                        type: "password",
                        placeholder: "Confirm password"
                      }, null, 8 /* PROPS */, ["modelValue"]))
                    ])))
                  : _createCommentVNode("v-if", true),
                ($setup.isLogin)
                  ? (_openBlock(), _tracer(188,5,_createElementBlock("div", _hoisted_6, [
                      _tracer(189,6,_createVNode(_component_Checkbox, {
                        modelValue: $setup.rememberMe,
                        "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.rememberMe) = $event)),
                        label: "Remember me"
                      }, null, 8 /* PROPS */, ["modelValue"])),
                      _tracer(190,6,_createVNode(_component_NuxtLink, null, {
                        default: _withCtx(() => [
                          _tracer(191,7,_createVNode(_component_Text, {
                            variant: "label",
                            tone: "muted",
                            link: "",
                            onClick: _withModifiers($setup.handleForgotPassword, ["prevent"])
                          }, {
                            default: _withCtx(() => [...(_cache[10] || (_cache[10] = [
                              _createTextVNode("Forgot password", -1 /* CACHED */)
                            ]))]),
                            _: 1 /* STABLE */
                          }))
                        ]),
                        _: 1 /* STABLE */
                      }))
                    ])))
                  : _createCommentVNode("v-if", true),
                ($setup.error)
                  ? (_openBlock(), _tracer(196,5,_createElementBlock("p", _hoisted_7, _toDisplayString($setup.error), 1 /* TEXT */)))
                  : _createCommentVNode("v-if", true),
                ($setup.info)
                  ? (_openBlock(), _tracer(197,5,_createElementBlock("p", _hoisted_8, _toDisplayString($setup.info), 1 /* TEXT */)))
                  : _createCommentVNode("v-if", true),
                _tracer(199,5,_createVNode(_component_Button, {
                  variant: "primary",
                  wide: "",
                  type: "submit",
                  disabled: $setup.loading
                }, {
                  default: _withCtx(() => [
                    _createTextVNode(_toDisplayString($setup.loading ? 'Please wait...' : ($setup.isLogin ? 'SIGN IN' : 'SIGN UP')), 1 /* TEXT */)
                  ]),
                  _: 1 /* STABLE */
                }, 8 /* PROPS */, ["disabled"])),
                _tracer(203,5,_createElementVNode("div", _hoisted_9, [
                  _tracer(204,6,_createVNode(_component_Text, {
                    variant: "label",
                    tone: "muted"
                  }, {
                    default: _withCtx(() => [...(_cache[11] || (_cache[11] = [
                      _createTextVNode("or", -1 /* CACHED */)
                    ]))]),
                    _: 1 /* STABLE */
                  }))
                ])),
                _tracer(208,5,_createVNode(_component_Button, {
                  type: "button",
                  wide: "",
                  onClick: $setup.handleGoogleLogin
                }, {
                  default: _withCtx(() => [
                    _tracer(209,6,_createVNode($setup["Icon"], {
                      icon: "material-icon-theme:google",
                      width: "20",
                      height: "20"
                    })),
                    _tracer(210,6,_createVNode(_component_Text, { variant: "body-sm" }, {
                      default: _withCtx(() => [...(_cache[12] || (_cache[12] = [
                        _createTextVNode(" Continue with Google ", -1 /* CACHED */)
                      ]))]),
                      _: 1 /* STABLE */
                    }))
                  ]),
                  _: 1 /* STABLE */
                })),
                _tracer(215,5,_createVNode(_component_NuxtLink, {
                  to: $setup.isLogin ? $setup.URI.user.register : $setup.URI.user.login
                }, {
                  default: _withCtx(() => [
                    _tracer(216,6,_createVNode(_component_Button, { wide: "" }, {
                      default: _withCtx(() => [
                        _tracer(217,7,_createVNode(_component_Text, { variant: "body-sm" }, {
                          default: _withCtx(() => [
                            _createTextVNode(_toDisplayString($setup.isLogin ? 'Create account' : 'Already have an account?'), 1 /* TEXT */)
                          ]),
                          _: 1 /* STABLE */
                        }))
                      ]),
                      _: 1 /* STABLE */
                    }))
                  ]),
                  _: 1 /* STABLE */
                }, 8 /* PROPS */, ["to"]))
              ], 32 /* NEED_HYDRATION */))
            ]))
          ]),
          _: 1 /* STABLE */
        }))
      ]),
      _: 1 /* STABLE */
    })),
    _tracer(227,1,_createVNode(_component_Footer, { fullMode: false }))
  ], 64 /* STABLE_FRAGMENT */))
}


import "/_nuxt/pages/auth/[action].vue?vue&type=style&index=0&scoped=88251e54&lang.css"

_sfc_main.__hmrId = "88251e54"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-88251e54"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/pages/auth/[action].vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/pages/auth/[action].vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FBRS9FLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0I7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDOztBQUVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDO0FBQ0Q7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDOztBQUVGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRUosQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFMUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQzs7QUFFRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQzs7QUFFRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRUosQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0Q7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRDs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUM7O0FBRUgsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQztBQUNEOzs7Ozs7Ozs7O3FCQU1RLEtBQUssRUFBQyxNQUFNO3FCQUlWLEtBQUssRUFBQyxZQUFZO3FCQUtsQixLQUFLLEVBQUMsWUFBWTs7O0VBSXNCLEtBQUssRUFBQzs7OztFQXVCOUMsS0FBSyxFQUFDOzs7O0VBS04sS0FBSyxFQUFDOzs7O0VBUUssS0FBSyxFQUFDOzs7O0VBQ1AsS0FBSyxFQUFDOztxQkFNaEIsS0FBSyxFQUFDLFNBQVM7Ozs7Ozs7Ozs7Ozs7a0JBMUR4QixhQWdGWSx3QkFoRkQsTUFBTSxFQUFDLFFBQVE7d0JBQ3pCLENBOEVVO3NCQTlFVixhQThFVSxzQkE5RUQsS0FBSyxFQUFDLGNBQWM7NEJBQzVCLENBNEVNOzBCQTVFTixvQkE0RU0sT0E1RU4sVUE0RU07NEJBM0VMLGFBQStELG1CQUF6RCxPQUFPLEVBQUMsSUFBSTtrQ0FBQyxDQUFxQztvREFBbEMsY0FBTzs7Ozs0QkFFN0Isb0JBd0VPO2dCQXhFRCxLQUFLLEVBQUMsTUFBTTtnQkFBRSxRQUFNLGlCQUFVLG1CQUFZOzs4QkFDL0Msb0JBR00sT0FITixVQUdNO2dDQUZMLGFBQTRDLG1CQUF0QyxPQUFPLEVBQUMsT0FBTztzQ0FBQyxDQUFlO3VDQUFmLGlCQUFlOzs7O2dDQUNyQyxhQUFnRjtnQ0FBaEUsWUFBSztpRkFBTCxZQUFLO29CQUFFLElBQUksRUFBQyxNQUFNO29CQUFDLFdBQVcsRUFBQzs7OzhCQUdoRCxvQkF5Qk0sT0F6Qk4sVUF5Qk07Z0NBeEJMLGFBQXFDLG1CQUEvQixPQUFPLEVBQUMsT0FBTztzQ0FBQyxDQUFRO3VDQUFSLFVBQVE7Ozs7Z0NBQzlCLGFBQWdHO2dDQUFoRixlQUFRO2lGQUFSLGVBQVE7b0JBQUUsSUFBSSxFQUFDLFVBQVU7b0JBQUMsV0FBVyxFQUFDLFVBQVU7b0JBQUUsT0FBSyxFQUFFOztnQ0FDekUsYUFxQmEsZUFyQkQsSUFBSSxFQUFDLFlBQVk7c0NBQzVCLENBbUJNO3dCQW5CTSxjQUFPLElBQUkseUJBQWtCO3VEQUF6QyxvQkFtQk0sT0FuQk4sVUFtQk07MENBbEJMLG9CQUtNOzhCQUxELEtBQUssbUJBQUMsV0FBVyxTQUFnQixxQkFBYyxDQUFDLElBQUk7OzRDQUN4RCxhQUVxRTtnQ0FGOUQsSUFBSSxFQUFFLHFCQUFjLENBQUM7OztnQ0FFZ0IsS0FBSyxFQUFDLElBQUk7Z0NBQUMsTUFBTSxFQUFDOzs0Q0FDOUQsYUFBeUU7Z0NBQW5FLE9BQU8sRUFBQyxTQUFTO2dDQUFDLElBQUksRUFBQzs7a0RBQVEsQ0FBNkI7bURBQTdCLCtCQUE2Qjs7Ozs7MENBRW5FLG9CQUtNOzhCQUxELEtBQUssbUJBQUMsV0FBVyxTQUFnQixxQkFBYyxDQUFDLE1BQU07OzRDQUMxRCxhQUVxRTtnQ0FGOUQsSUFBSSxFQUFFLHFCQUFjLENBQUM7OztnQ0FFZ0IsS0FBSyxFQUFDLElBQUk7Z0NBQUMsTUFBTSxFQUFDOzs0Q0FDOUQsYUFBaUU7Z0NBQTNELE9BQU8sRUFBQyxTQUFTO2dDQUFDLElBQUksRUFBQzs7a0RBQVEsQ0FBcUI7bURBQXJCLHVCQUFxQjs7Ozs7MENBRTNELG9CQUtNOzhCQUxELEtBQUssbUJBQUMsV0FBVyxTQUFnQixxQkFBYyxDQUFDLE1BQU07OzRDQUMxRCxhQUVxRTtnQ0FGOUQsSUFBSSxFQUFFLHFCQUFjLENBQUM7OztnQ0FFZ0IsS0FBSyxFQUFDLElBQUk7Z0NBQUMsTUFBTSxFQUFDOzs0Q0FDOUQsYUFBNkQ7Z0NBQXZELE9BQU8sRUFBQyxTQUFTO2dDQUFDLElBQUksRUFBQzs7a0RBQVEsQ0FBaUI7bURBQWpCLG1CQUFpQjs7Ozs7Ozs7Ozs7a0JBTTNCLGNBQU87aURBQXRDLG9CQUdNLE9BSE4sVUFHTTtvQ0FGTCxhQUE2QyxtQkFBdkMsT0FBTyxFQUFDLE9BQU87MENBQUMsQ0FBZ0I7MkNBQWhCLGtCQUFnQjs7OztvQ0FDdEMsYUFBa0Y7b0NBQWxFLHNCQUFlO3FGQUFmLHNCQUFlO3dCQUFFLElBQUksRUFBQyxVQUFVO3dCQUFDLFdBQVcsRUFBQzs7OztpQkFHdkMsY0FBTztpREFBOUIsb0JBTU0sT0FOTixVQU1NO29DQUxMLGFBQXFEO29DQUFsQyxpQkFBVTtxRkFBVixpQkFBVTt3QkFBRSxLQUFLLEVBQUM7O29DQUNyQyxhQUdXOzBDQUZWLENBQ2dCO3dDQURoQixhQUNnQjs0QkFEVixPQUFPLEVBQUMsT0FBTzs0QkFBQyxJQUFJLEVBQUMsT0FBTzs0QkFBQyxJQUFJLEVBQUosRUFBSTs0QkFBRSxPQUFLLGlCQUFVLDJCQUFvQjs7OENBQUUsQ0FDckU7K0NBRHFFLGlCQUNyRTs7Ozs7Ozs7O2lCQUlGLFlBQUs7aURBQWQsb0JBQWtELEtBQWxELFVBQWtELG1CQUFaLFlBQUs7O2lCQUNsQyxXQUFJO2lEQUFiLG9CQUErQyxLQUEvQyxVQUErQyxtQkFBWCxXQUFJOzs4QkFFeEMsYUFFUztrQkFGRCxPQUFPLEVBQUMsU0FBUztrQkFBQyxJQUFJLEVBQUosRUFBSTtrQkFBQyxJQUFJLEVBQUMsUUFBUTtrQkFBRSxRQUFRLEVBQUU7O29DQUN2RCxDQUFvRTtzREFBakUsY0FBTyx1QkFBdUIsY0FBTzs7Ozs4QkFHekMsb0JBRU0sT0FGTixVQUVNO2dDQURMLGFBQTRDO29CQUF0QyxPQUFPLEVBQUMsT0FBTztvQkFBQyxJQUFJLEVBQUM7O3NDQUFRLENBQUU7dUNBQUYsSUFBRTs7Ozs7OEJBSXRDLGFBS1M7a0JBTEQsSUFBSSxFQUFDLFFBQVE7a0JBQUMsSUFBSSxFQUFKLEVBQUk7a0JBQUUsT0FBSyxFQUFFOztvQ0FDbEMsQ0FBaUU7a0NBQWpFLGFBQWlFO3NCQUEzRCxJQUFJLEVBQUMsNEJBQTRCO3NCQUFDLEtBQUssRUFBQyxJQUFJO3NCQUFDLE1BQU0sRUFBQzs7a0NBQzFELGFBRU8sbUJBRkQsT0FBTyxFQUFDLFNBQVM7d0NBQUMsQ0FFeEI7eUNBRndCLHdCQUV4Qjs7Ozs7Ozs4QkFHRCxhQU1XO2tCQU5BLEVBQUUsRUFBRSxjQUFPLEdBQUcsVUFBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBRyxDQUFDLElBQUksQ0FBQzs7b0NBQ3JELENBSVM7a0NBSlQsYUFJUyxxQkFKRCxJQUFJLEVBQUosRUFBSTt3Q0FDWCxDQUVPO3NDQUZQLGFBRU8sbUJBRkQsT0FBTyxFQUFDLFNBQVM7NENBQ3RCLENBQTZEOzhEQUExRCxjQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7a0JBU2pCLGFBQW1DLHFCQUExQixRQUFRLEVBQUUsS0FBSyIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiW2FjdGlvbl0udnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyBVUkkgfSBmcm9tICcjc2hhcmVkL2NvbnN0YW50cy9yb3V0ZXMnXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnQGljb25pZnkvdnVlJ1xuaW1wb3J0IHsgdmFsaWRhdGVSZWdpc3RyYXRpb25JbnB1dCB9IGZyb20gJyNzaGFyZWQvdmFsaWRhdG9ycy91c2VyLXJlZ2lzdHJhdGlvbidcblxuY29uc3Qgcm91dGUgPSB1c2VSb3V0ZSgpXG5cbmNvbnN0IGFjdGlvbiA9IGNvbXB1dGVkKCgpID0+IHJvdXRlLnBhcmFtcy5hY3Rpb24pXG5cbmNvbnN0IGlzTG9naW4gPSBjb21wdXRlZCgoKSA9PiBhY3Rpb24udmFsdWUgPT09ICdsb2dpbicpXG5cbmlmICghWydsb2dpbicsICdyZWdpc3RlciddLmluY2x1ZGVzKGFjdGlvbi52YWx1ZSkpIHtcblx0dGhyb3cgY3JlYXRlRXJyb3Ioe1xuXHRcdHN0YXR1c0NvZGU6IDQwNFxuXHR9KVxufVxuXG5jb25zdCBzdXBhYmFzZSA9IHVzZVN1cGFiYXNlQ2xpZW50KCk7XG5cbmNvbnN0IGVtYWlsID0gcmVmKCcnKTtcbmNvbnN0IHBhc3N3b3JkID0gcmVmKCcnKTtcbmNvbnN0IGNvbmZpcm1QYXNzd29yZCA9IHJlZignJyk7XG5jb25zdCByZW1lbWJlck1lID0gcmVmKGZhbHNlKTtcbmNvbnN0IGxvYWRpbmcgPSByZWYoZmFsc2UpO1xuY29uc3QgZXJyb3IgPSByZWYoJycpO1xuY29uc3QgaW5mbyA9IHJlZignJyk7XG5jb25zdCBzaG93UGFzc3dvcmRDaGVja3MgPSByZWYoZmFsc2UpXG5cbmNvbnN0IGhhbmRsZVBhc3N3b3JkRm9jdXMgPSAoKSA9PiB7XG5cdHNob3dQYXNzd29yZENoZWNrcy52YWx1ZSA9IHRydWVcbn1cblxuY29uc3QgcGFzc3dvcmRDaGVja3MgPSBjb21wdXRlZCgoKSA9PiB7XG5cdHJldHVybiB2YWxpZGF0ZVJlZ2lzdHJhdGlvbklucHV0KCcnLCBwYXNzd29yZC52YWx1ZSkuY2hlY2tzXG59KVxuXG4vLyBDZW50cmFsaXplZCBlcnJvciBtZXNzYWdlIGV4dHJhY3Rpb24g4oCUIGhhbmRsZXMgdGhlIGZhY3QgdGhhdFxuLy8gc3RhdHVzTWVzc2FnZSBjYW4gYmUgc2FuaXRpemVkIGluIHByb2R1Y3Rpb24sIHNvIHdlIHByZWZlclxuLy8gZGF0YS5tZXNzYWdlIChzZXQgZXhwbGljaXRseSBvbiB0aGUgc2VydmVyKSBhcyB0aGUgc291cmNlIG9mIHRydXRoLlxuY29uc3QgZXh0cmFjdEVycm9yTWVzc2FnZSA9IChlcnIsIGZhbGxiYWNrKSA9PiB7XG5cdHJldHVybiAoXG5cdFx0ZXJyPy5kYXRhPy5kYXRhPy5tZXNzYWdlIHx8XG5cdFx0ZXJyPy5kYXRhPy5zdGF0dXNNZXNzYWdlIHx8XG5cdFx0ZXJyPy5tZXNzYWdlIHx8XG5cdFx0ZmFsbGJhY2tcblx0KVxufVxuXG5jb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoKSA9PiB7XG5cdGlmIChpc0xvZ2luLnZhbHVlKSB7XG5cdFx0aWYgKCFlbWFpbC52YWx1ZSB8fCAhcGFzc3dvcmQudmFsdWUpIHtcblx0XHRcdGVycm9yLnZhbHVlID0gJ1BsZWFzZSBmaWxsIGluIGFsbCBmaWVsZHMnXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRsb2FkaW5nLnZhbHVlID0gdHJ1ZVxuXHRcdGVycm9yLnZhbHVlID0gJydcblx0XHRpbmZvLnZhbHVlID0gJydcblxuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCB7IGRhdGEsIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aFBhc3N3b3JkKHtcblx0XHRcdFx0ZW1haWw6IGVtYWlsLnZhbHVlLFxuXHRcdFx0XHRwYXNzd29yZDogcGFzc3dvcmQudmFsdWVcblx0XHRcdH0pXG5cblx0XHRcdGlmIChhdXRoRXJyb3IpIHtcblx0XHRcdFx0ZXJyb3IudmFsdWUgPSBhdXRoRXJyb3IubWVzc2FnZVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0aW5mby52YWx1ZSA9ICdMb2dpbiBzdWNjZXNzZnVsISdcblx0XHRcdFx0bmF2aWdhdGVUbyhVUkkuaG9tZSlcblx0XHRcdH1cblx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdGVycm9yLnZhbHVlID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJ1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRsb2FkaW5nLnZhbHVlID0gZmFsc2Vcblx0XHR9XG5cdH0gZWxzZSB7XG5cdFx0Y29uc3QgdmFsaWRhdGlvbiA9IHZhbGlkYXRlUmVnaXN0cmF0aW9uSW5wdXQoZW1haWwudmFsdWUsIHBhc3N3b3JkLnZhbHVlKVxuXG5cdFx0aWYgKCF2YWxpZGF0aW9uLmlzVmFsaWQpIHtcblx0XHRcdGVycm9yLnZhbHVlID0gT2JqZWN0LnZhbHVlcyh2YWxpZGF0aW9uLmVycm9ycykuam9pbignLCAnKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKHBhc3N3b3JkLnZhbHVlICE9PSBjb25maXJtUGFzc3dvcmQudmFsdWUpIHtcblx0XHRcdGVycm9yLnZhbHVlID0gJ1Bhc3N3b3JkcyBkbyBub3QgbWF0Y2gnXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRsb2FkaW5nLnZhbHVlID0gdHJ1ZVxuXHRcdGVycm9yLnZhbHVlID0gJydcblx0XHRpbmZvLnZhbHVlID0gJydcblxuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCAkZmV0Y2goJy9hcGkvdXNlci9jcmVhdGUnLCB7XG5cdFx0XHRcdG1ldGhvZDogJ1BPU1QnLFxuXHRcdFx0XHRib2R5OiB7IGVtYWlsOiBlbWFpbC52YWx1ZSwgcGFzc3dvcmQ6IHBhc3N3b3JkLnZhbHVlIH0sXG5cdFx0XHR9KVxuXG5cdFx0XHRpbmZvLnZhbHVlID0gJ0FjY291bnQgY3JlYXRlZCEgUGxlYXNlIGNoZWNrIHlvdXIgZW1haWwgdG8gY29uZmlybS4nXG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRlcnJvci52YWx1ZSA9IGV4dHJhY3RFcnJvck1lc3NhZ2UoZXJyLCAnUmVnaXN0cmF0aW9uIGZhaWxlZCcpXG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGxvYWRpbmcudmFsdWUgPSBmYWxzZVxuXHRcdH1cblx0fVxufVxuXG5jb25zdCBoYW5kbGVHb29nbGVMb2dpbiA9IGFzeW5jICgpID0+IHtcblx0Y29uc3QgeyBlcnJvcjogZ29vZ2xlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aE9BdXRoKHtcblx0XHRwcm92aWRlcjogJ2dvb2dsZSdcblx0fSlcblx0aWYgKGdvb2dsZUVycm9yKSBlcnJvci52YWx1ZSA9IGdvb2dsZUVycm9yLm1lc3NhZ2Vcbn1cblxuY29uc3QgaGFuZGxlRm9yZ290UGFzc3dvcmQgPSBhc3luYyAoKSA9PiB7XG5cdGlmICghZW1haWwudmFsdWUpIHtcblx0XHRlcnJvci52YWx1ZSA9ICdQbGVhc2UgZW50ZXIgeW91ciBlbWFpbCBhZGRyZXNzJ1xuXHRcdHJldHVyblxuXHR9XG5cblx0bG9hZGluZy52YWx1ZSA9IHRydWVcblx0ZXJyb3IudmFsdWUgPSAnJ1xuXHRpbmZvLnZhbHVlID0gJydcblxuXHR0cnkge1xuXHRcdGNvbnN0IHsgZXJyb3I6IHJlc2V0RXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgucmVzZXRQYXNzd29yZEZvckVtYWlsKGVtYWlsLnZhbHVlLCB7XG5cdFx0XHRyZWRpcmVjdFRvOiBgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufS9yZXNldC1wYXNzd29yZGBcblx0XHR9KVxuXG5cdFx0aWYgKHJlc2V0RXJyb3IpIHtcblx0XHRcdGVycm9yLnZhbHVlID0gcmVzZXRFcnJvci5tZXNzYWdlXG5cdFx0fSBlbHNlIHtcblx0XHRcdGluZm8udmFsdWUgPSAnUGFzc3dvcmQgcmVzZXQgZW1haWwgc2VudCEnXG5cdFx0fVxuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRlcnJvci52YWx1ZSA9IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcidcblx0fSBmaW5hbGx5IHtcblx0XHRsb2FkaW5nLnZhbHVlID0gZmFsc2Vcblx0fVxufVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cblx0PENvbnRhaW5lciBoQWxpZ249XCJjZW50ZXJcIj5cblx0XHQ8U2VjdGlvbiBjbGFzcz1cImF1dGgtc2VjdGlvblwiPlxuXHRcdFx0PGRpdiBjbGFzcz1cImNhcmRcIj5cblx0XHRcdFx0PFRleHQgdmFyaWFudD1cImgzXCI+e3sgaXNMb2dpbiA/ICdTaWduIGluJyA6ICdTaWduIHVwJyB9fTwvVGV4dD5cblxuXHRcdFx0XHQ8Zm9ybSBjbGFzcz1cImZvcm1cIiBAc3VibWl0LnByZXZlbnQ9XCJoYW5kbGVTdWJtaXRcIj5cblx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuXHRcdFx0XHRcdFx0PFRleHQgdmFyaWFudD1cImxhYmVsXCI+RW1haWwgb3IgbW9iaWxlPC9UZXh0PlxuXHRcdFx0XHRcdFx0PElucHV0IHYtbW9kZWw9XCJlbWFpbFwiIHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJFbWFpbCBvciBtb2JpbGUgcGhvbmUgbnVtYmVyXCIgLz5cblx0XHRcdFx0XHQ8L2Rpdj5cblxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG5cdFx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwibGFiZWxcIj5QYXNzd29yZDwvVGV4dD5cblx0XHRcdFx0XHRcdDxJbnB1dCB2LW1vZGVsPVwicGFzc3dvcmRcIiB0eXBlPVwicGFzc3dvcmRcIiBwbGFjZWhvbGRlcj1cIlBhc3N3b3JkXCIgQGZvY3VzPVwiaGFuZGxlUGFzc3dvcmRGb2N1c1wiIC8+XG5cdFx0XHRcdFx0XHQ8VHJhbnNpdGlvbiBuYW1lPVwiZmFkZS1zbGlkZVwiPlxuXHRcdFx0XHRcdFx0XHQ8ZGl2IHYtaWY9XCIhaXNMb2dpbiAmJiBzaG93UGFzc3dvcmRDaGVja3NcIiBjbGFzcz1cInBhc3N3b3JkLWNoZWNrc1wiPlxuXHRcdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJjaGVjay1yb3dcIiA6Y2xhc3M9XCJ7IG1ldDogcGFzc3dvcmRDaGVja3MuY2FzZSB9XCI+XG5cdFx0XHRcdFx0XHRcdFx0XHQ8SWNvbiA6aWNvbj1cInBhc3N3b3JkQ2hlY2tzLmNhc2Vcblx0XHRcdFx0XHRcdFx0XHRcdFx0PyAnbWF0ZXJpYWwtc3ltYm9sczpjaGVjay1jaXJjbGUnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdDogJ21hdGVyaWFsLXN5bWJvbHM6Y2hlY2stY2lyY2xlLW91dGxpbmUnXCIgd2lkdGg9XCIxNlwiIGhlaWdodD1cIjE2XCIgLz5cblx0XHRcdFx0XHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5LXNtXCIgdG9uZT1cIm11dGVkXCI+TG93ZXJjYXNlICYgdXBwZXJjYXNlIGxldHRlcnM8L1RleHQ+XG5cdFx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cImNoZWNrLXJvd1wiIDpjbGFzcz1cInsgbWV0OiBwYXNzd29yZENoZWNrcy5sZW5ndGggfVwiPlxuXHRcdFx0XHRcdFx0XHRcdFx0PEljb24gOmljb249XCJwYXNzd29yZENoZWNrcy5sZW5ndGhcblx0XHRcdFx0XHRcdFx0XHRcdFx0PyAnbWF0ZXJpYWwtc3ltYm9sczpjaGVjay1jaXJjbGUnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdDogJ21hdGVyaWFsLXN5bWJvbHM6Y2hlY2stY2lyY2xlLW91dGxpbmUnXCIgd2lkdGg9XCIxNlwiIGhlaWdodD1cIjE2XCIgLz5cblx0XHRcdFx0XHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5LXNtXCIgdG9uZT1cIm11dGVkXCI+QXQgbGVhc3QgOCBjaGFyYWN0ZXJzPC9UZXh0PlxuXHRcdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJjaGVjay1yb3dcIiA6Y2xhc3M9XCJ7IG1ldDogcGFzc3dvcmRDaGVja3MubnVtYmVyIH1cIj5cblx0XHRcdFx0XHRcdFx0XHRcdDxJY29uIDppY29uPVwicGFzc3dvcmRDaGVja3MubnVtYmVyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdD8gJ21hdGVyaWFsLXN5bWJvbHM6Y2hlY2stY2lyY2xlJ1xuXHRcdFx0XHRcdFx0XHRcdFx0XHQ6ICdtYXRlcmlhbC1zeW1ib2xzOmNoZWNrLWNpcmNsZS1vdXRsaW5lJ1wiIHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxNlwiIC8+XG5cdFx0XHRcdFx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwiYm9keS1zbVwiIHRvbmU9XCJtdXRlZFwiPkNvbnRhaW5zIGEgbnVtYmVyPC9UZXh0PlxuXHRcdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHRcdDwvVHJhbnNpdGlvbj5cblx0XHRcdFx0XHQ8L2Rpdj5cblxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCIgdi1pZj1cIiFpc0xvZ2luXCI+XG5cdFx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwibGFiZWxcIj5Db25maXJtIHBhc3N3b3JkPC9UZXh0PlxuXHRcdFx0XHRcdFx0PElucHV0IHYtbW9kZWw9XCJjb25maXJtUGFzc3dvcmRcIiB0eXBlPVwicGFzc3dvcmRcIiBwbGFjZWhvbGRlcj1cIkNvbmZpcm0gcGFzc3dvcmRcIiAvPlxuXHRcdFx0XHRcdDwvZGl2PlxuXG5cdFx0XHRcdFx0PGRpdiBjbGFzcz1cInJvd1wiIHYtaWY9XCJpc0xvZ2luXCI+XG5cdFx0XHRcdFx0XHQ8Q2hlY2tib3ggdi1tb2RlbD1cInJlbWVtYmVyTWVcIiBsYWJlbD1cIlJlbWVtYmVyIG1lXCIgLz5cblx0XHRcdFx0XHRcdDxOdXh0TGluaz5cblx0XHRcdFx0XHRcdFx0PFRleHQgdmFyaWFudD1cImxhYmVsXCIgdG9uZT1cIm11dGVkXCIgbGluayBAY2xpY2sucHJldmVudD1cImhhbmRsZUZvcmdvdFBhc3N3b3JkXCI+Rm9yZ290XG5cdFx0XHRcdFx0XHRcdFx0cGFzc3dvcmQ8L1RleHQ+XG5cdFx0XHRcdFx0XHQ8L051eHRMaW5rPlxuXHRcdFx0XHRcdDwvZGl2PlxuXG5cdFx0XHRcdFx0PHAgdi1pZj1cImVycm9yXCIgY2xhc3M9XCJlcnJvci10ZXh0XCI+e3sgZXJyb3IgfX08L3A+XG5cdFx0XHRcdFx0PHAgdi1pZj1cImluZm9cIiBjbGFzcz1cImluZm8tdGV4dFwiPnt7IGluZm8gfX08L3A+XG5cblx0XHRcdFx0XHQ8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgd2lkZSB0eXBlPVwic3VibWl0XCIgOmRpc2FibGVkPVwibG9hZGluZ1wiPlxuXHRcdFx0XHRcdFx0e3sgbG9hZGluZyA/ICdQbGVhc2Ugd2FpdC4uLicgOiAoaXNMb2dpbiA/ICdTSUdOIElOJyA6ICdTSUdOIFVQJykgfX1cblx0XHRcdFx0XHQ8L0J1dHRvbj5cblxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJvci10ZXh0XCI+XG5cdFx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwibGFiZWxcIiB0b25lPVwibXV0ZWRcIj5vcjwvVGV4dD5cblx0XHRcdFx0XHQ8L2Rpdj5cblxuXG5cdFx0XHRcdFx0PEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgd2lkZSBAY2xpY2s9XCJoYW5kbGVHb29nbGVMb2dpblwiPlxuXHRcdFx0XHRcdFx0PEljb24gaWNvbj1cIm1hdGVyaWFsLWljb24tdGhlbWU6Z29vZ2xlXCIgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgLz5cblx0XHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5LXNtXCI+XG5cdFx0XHRcdFx0XHRcdENvbnRpbnVlIHdpdGggR29vZ2xlXG5cdFx0XHRcdFx0XHQ8L1RleHQ+XG5cdFx0XHRcdFx0PC9CdXR0b24+XG5cblx0XHRcdFx0XHQ8TnV4dExpbmsgOnRvPVwiaXNMb2dpbiA/IFVSSS51c2VyLnJlZ2lzdGVyIDogVVJJLnVzZXIubG9naW5cIj5cblx0XHRcdFx0XHRcdDxCdXR0b24gd2lkZT5cblx0XHRcdFx0XHRcdFx0PFRleHQgdmFyaWFudD1cImJvZHktc21cIj5cblx0XHRcdFx0XHRcdFx0XHR7eyBpc0xvZ2luID8gJ0NyZWF0ZSBhY2NvdW50JyA6ICdBbHJlYWR5IGhhdmUgYW4gYWNjb3VudD8nIH19XG5cdFx0XHRcdFx0XHRcdDwvVGV4dD5cblx0XHRcdFx0XHRcdDwvQnV0dG9uPlxuXHRcdFx0XHRcdDwvTnV4dExpbms+XG5cdFx0XHRcdDwvZm9ybT5cblx0XHRcdDwvZGl2PlxuXHRcdDwvU2VjdGlvbj5cblx0PC9Db250YWluZXI+XG5cblx0PEZvb3RlciA6ZnVsbE1vZGU9XCJmYWxzZVwiPjwvRm9vdGVyPlxuPC90ZW1wbGF0ZT5cblxuPHN0eWxlIHNjb3BlZD5cblxuLmNhcmQge1xuXHR3aWR0aDogNDIwcHg7XG5cdGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsIHZhcigtLWJnLWNhcmQpLCB2YXIoLS1iZy0yKSk7XG5cdGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWJvcmRlci1oaSk7XG5cdHBhZGRpbmc6IDJyZW07XG5cdG1hcmdpbi10b3A6IDFyZW07XG59XG5cbi5mb3JtIHtcblx0ZGlzcGxheTogZmxleDtcblx0ZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblx0Z2FwOiAxcmVtO1xuXHRwYWRkaW5nLXRvcDogMTVweDtcbn1cblxuLmZvcm0tZ3JvdXAge1xuXHRkaXNwbGF5OiBmbGV4O1xuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuXHRnYXA6IDAuNHJlbTtcbn1cblxuLnJvdyB7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcblx0Zm9udC1zaXplOiAxMXB4O1xuXHRjb2xvcjogdmFyKC0tZmctMyk7XG59XG5cbi5vci10ZXh0IHtcblx0dGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uZXJyb3ItdGV4dCB7XG5cdGZvbnQtc2l6ZTogMTJweDtcblx0Y29sb3I6IHZhcigtLXJvc2UpO1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5pbmZvLXRleHQge1xuXHRmb250LXNpemU6IDEycHg7XG5cdGNvbG9yOiB2YXIoLS10ZWFsKTtcblx0dGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4ucGFzc3dvcmQtY2hlY2tzIHtcblx0ZGlzcGxheTogZmxleDtcblx0ZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblx0Z2FwOiAwLjNyZW07XG5cdHBhZGRpbmctdG9wOiAwLjJyZW07XG59XG5cbi5jaGVjay1yb3cge1xuXHRkaXNwbGF5OiBmbGV4O1xuXHRhbGlnbi1pdGVtczogY2VudGVyO1xuXHRnYXA6IDAuNHJlbTtcblx0Y29sb3I6IHZhcigtLWZnLTMpO1xufVxuXG4uY2hlY2stcm93Lm1ldCB7XG5cdGNvbG9yOiB2YXIoLS10ZWFsKTtcbn1cblxuLmZhZGUtc2xpZGUtZW50ZXItYWN0aXZlIHtcblx0dHJhbnNpdGlvbjogYWxsIDAuMjVzIGVhc2Utb3V0O1xufVxuXG4uZmFkZS1zbGlkZS1sZWF2ZS1hY3RpdmUge1xuXHR0cmFuc2l0aW9uOiBhbGwgMC4xNXMgZWFzZS1pbjtcbn1cblxuLmZhZGUtc2xpZGUtZW50ZXItZnJvbSB7XG5cdG9wYWNpdHk6IDA7XG5cdHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNnB4KTtcbn1cblxuLmZhZGUtc2xpZGUtbGVhdmUtdG8ge1xuXHRvcGFjaXR5OiAwO1xuXHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTZweCk7XG59XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvbW50L2tpcmUvUGVyc29uYWwvUHJvZ3JhbW1pbmcvUHJvamVjdHMvTUVJQy93ZWIvYXBwL3BhZ2VzL2F1dGgvW2FjdGlvbl0udnVlIn0=