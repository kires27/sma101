let warned = false;
const DEPRECATED_PACKAGES = [
    "@supabase/auth-helpers-nextjs",
    "@supabase/auth-helpers-react",
    "@supabase/auth-helpers-remix",
    "@supabase/auth-helpers-sveltekit",
];
export function warnIfUsingDeprecatedAuthHelpersPackage() {
    if (warned) {
        return;
    }
    if (typeof process === "undefined" || !process.env?.npm_package_name) {
        return;
    }
    const packageName = process.env.npm_package_name;
    if (!DEPRECATED_PACKAGES.includes(packageName)) {
        return;
    }
    warned = true;
    console.warn(`
╔════════════════════════════════════════════════════════════════════════════╗
║ ⚠️  IMPORTANT: Package Consolidation Notice                                ║
║                                                                            ║
║ The ${packageName.padEnd(35)} package name is deprecated.  ║
║                                                                            ║
║ You are now using @supabase/ssr - a unified solution for all frameworks.  ║
║                                                                            ║
║ The auth-helpers packages have been consolidated into @supabase/ssr       ║
║ to provide better maintenance and consistent APIs across frameworks.      ║
║                                                                            ║
║ Please update your package.json to use @supabase/ssr directly:            ║
║   npm uninstall ${packageName.padEnd(42)} ║
║   npm install @supabase/ssr                                               ║
║                                                                            ║
║ For more information, visit:                                              ║
║ https://supabase.com/docs/guides/auth/server-side                         ║
╚════════════════════════════════════════════════════════════════════════════╝
    `);
}
                                                 
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2FybkRlcHJlY2F0ZWRQYWNrYWdlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3dhcm5EZXByZWNhdGVkUGFja2FnZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUM7QUFFbkIsTUFBTSxtQkFBbUIsR0FBRztJQUMxQiwrQkFBK0I7SUFDL0IsOEJBQThCO0lBQzlCLDhCQUE4QjtJQUM5QixrQ0FBa0M7Q0FDbkMsQ0FBQztBQUVGLE1BQU0sVUFBVSx1Q0FBdUM7SUFDckQsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUNYLE9BQU87SUFDVCxDQUFDO0lBRUQsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLGdCQUFnQixFQUFFLENBQUM7UUFDckUsT0FBTztJQUNULENBQUM7SUFFRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0lBQ2pELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztRQUMvQyxPQUFPO0lBQ1QsQ0FBQztJQUVELE1BQU0sR0FBRyxJQUFJLENBQUM7SUFDZCxPQUFPLENBQUMsSUFBSSxDQUFDOzs7O1FBSVAsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7Ozs7Ozs7O29CQVFWLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDOzs7Ozs7S0FNckMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImxldCB3YXJuZWQgPSBmYWxzZTtcblxuY29uc3QgREVQUkVDQVRFRF9QQUNLQUdFUyA9IFtcbiAgXCJAc3VwYWJhc2UvYXV0aC1oZWxwZXJzLW5leHRqc1wiLFxuICBcIkBzdXBhYmFzZS9hdXRoLWhlbHBlcnMtcmVhY3RcIixcbiAgXCJAc3VwYWJhc2UvYXV0aC1oZWxwZXJzLXJlbWl4XCIsXG4gIFwiQHN1cGFiYXNlL2F1dGgtaGVscGVycy1zdmVsdGVraXRcIixcbl07XG5cbmV4cG9ydCBmdW5jdGlvbiB3YXJuSWZVc2luZ0RlcHJlY2F0ZWRBdXRoSGVscGVyc1BhY2thZ2UoKTogdm9pZCB7XG4gIGlmICh3YXJuZWQpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAodHlwZW9mIHByb2Nlc3MgPT09IFwidW5kZWZpbmVkXCIgfHwgIXByb2Nlc3MuZW52Py5ucG1fcGFja2FnZV9uYW1lKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgcGFja2FnZU5hbWUgPSBwcm9jZXNzLmVudi5ucG1fcGFja2FnZV9uYW1lO1xuICBpZiAoIURFUFJFQ0FURURfUEFDS0FHRVMuaW5jbHVkZXMocGFja2FnZU5hbWUpKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgd2FybmVkID0gdHJ1ZTtcbiAgY29uc29sZS53YXJuKGBcbuKVlOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVl1xu4pWRIOKaoO+4jyAgSU1QT1JUQU5UOiBQYWNrYWdlIENvbnNvbGlkYXRpb24gTm90aWNlICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDilZFcbuKVkSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDilZFcbuKVkSBUaGUgJHtwYWNrYWdlTmFtZS5wYWRFbmQoMzUpfSBwYWNrYWdlIG5hbWUgaXMgZGVwcmVjYXRlZC4gIOKVkVxu4pWRICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKVkVxu4pWRIFlvdSBhcmUgbm93IHVzaW5nIEBzdXBhYmFzZS9zc3IgLSBhIHVuaWZpZWQgc29sdXRpb24gZm9yIGFsbCBmcmFtZXdvcmtzLiAg4pWRXG7ilZEgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pWRXG7ilZEgVGhlIGF1dGgtaGVscGVycyBwYWNrYWdlcyBoYXZlIGJlZW4gY29uc29saWRhdGVkIGludG8gQHN1cGFiYXNlL3NzciAgICAgICDilZFcbuKVkSB0byBwcm92aWRlIGJldHRlciBtYWludGVuYW5jZSBhbmQgY29uc2lzdGVudCBBUElzIGFjcm9zcyBmcmFtZXdvcmtzLiAgICAgIOKVkVxu4pWRICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKVkVxu4pWRIFBsZWFzZSB1cGRhdGUgeW91ciBwYWNrYWdlLmpzb24gdG8gdXNlIEBzdXBhYmFzZS9zc3IgZGlyZWN0bHk6ICAgICAgICAgICAg4pWRXG7ilZEgICBucG0gdW5pbnN0YWxsICR7cGFja2FnZU5hbWUucGFkRW5kKDQyKX0g4pWRXG7ilZEgICBucG0gaW5zdGFsbCBAc3VwYWJhc2Uvc3NyICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDilZFcbuKVkSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDilZFcbuKVkSBGb3IgbW9yZSBpbmZvcm1hdGlvbiwgdmlzaXQ6ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKVkVxu4pWRIGh0dHBzOi8vc3VwYWJhc2UuY29tL2RvY3MvZ3VpZGVzL2F1dGgvc2VydmVyLXNpZGUgICAgICAgICAgICAgICAgICAgICAgICAg4pWRXG7ilZrilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZ1cbiAgICBgKTtcbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19