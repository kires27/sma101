import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Checkbox.vue");import { default as __nuxt_component_0 } from "/_nuxt/ui/Text.vue";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"

const _sfc_main = {
  __name: "Checkbox",
  props: {
	modelValue: {
		type: Boolean,
		default: false
	},
	label: {
		type: String,
		default: ''
	}
},
  emits: ['update:modelValue'],
  setup(__props, { expose: __expose }) {
  __expose();





const __returned__ = {  }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

const _hoisted_1 = { class: "checkbox-label" }
const _hoisted_2 = ["checked"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Text = __nuxt_component_0

  return (_openBlock(), _tracer(17,1,_createElementBlock("label", _hoisted_1, [
    _tracer(18,2,_createElementVNode("input", {
      type: "checkbox",
      class: "checkbox",
      checked: $props.modelValue,
      onChange: _cache[0] || (_cache[0] = $event => (_ctx.$emit('update:modelValue', $event.target.checked)))
    }, null, 40 /* PROPS, NEED_HYDRATION */, _hoisted_2)),
    _tracer(19,2,_createVNode(_component_Text, {
      variant: "label",
      tone: "muted",
      link: ""
    }, {
      default: _withCtx(() => [
        _createTextVNode(_toDisplayString($props.label), 1 /* TEXT */)
      ]),
      _: 1 /* STABLE */
    }))
  ])))
}


import "/_nuxt/ui/Checkbox.vue?vue&type=style&index=0&scoped=2fa37816&lang.css"

_sfc_main.__hmrId = "2fa37816"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-2fa37816"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Checkbox.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Checkbox.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFnQlEsS0FBSyxFQUFDLGdCQUFnQjs7Ozs7O3FDQUE3QixvQkFHUSxTQUhSLFVBR1E7aUJBRlAsb0JBQTRIO01BQXJILElBQUksRUFBQyxVQUFVO01BQUMsS0FBSyxFQUFDLFVBQVU7TUFBRSxPQUFPLEVBQUUsaUJBQVU7TUFBRyxRQUFNLHVDQUFFLFVBQUssc0JBQXNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTzs7aUJBQ3ZILGFBQTBEO01BQXBELE9BQU8sRUFBQyxPQUFPO01BQUMsSUFBSSxFQUFDLE9BQU87TUFBQyxJQUFJLEVBQUo7O3dCQUFLLENBQVc7MENBQVIsWUFBSyIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2hlY2tib3gudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5kZWZpbmVQcm9wcyh7XG5cdG1vZGVsVmFsdWU6IHtcblx0XHR0eXBlOiBCb29sZWFuLFxuXHRcdGRlZmF1bHQ6IGZhbHNlXG5cdH0sXG5cdGxhYmVsOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGRlZmF1bHQ6ICcnXG5cdH1cbn0pXG5cbmRlZmluZUVtaXRzKFsndXBkYXRlOm1vZGVsVmFsdWUnXSlcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG5cdDxsYWJlbCBjbGFzcz1cImNoZWNrYm94LWxhYmVsXCI+XG5cdFx0PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzPVwiY2hlY2tib3hcIiA6Y2hlY2tlZD1cIm1vZGVsVmFsdWVcIiBAY2hhbmdlPVwiJGVtaXQoJ3VwZGF0ZTptb2RlbFZhbHVlJywgJGV2ZW50LnRhcmdldC5jaGVja2VkKVwiIC8+XG5cdFx0PFRleHQgdmFyaWFudD1cImxhYmVsXCIgdG9uZT1cIm11dGVkXCIgbGluaz57eyBsYWJlbCB9fTwvVGV4dD5cblx0PC9sYWJlbD5cbjwvdGVtcGxhdGU+XG5cbjxzdHlsZSBzY29wZWQ+XG4uY2hlY2tib3gtbGFiZWwge1xuXHRkaXNwbGF5OiBmbGV4O1xuXHRhbGlnbi1pdGVtczogY2VudGVyO1xuXHRnYXA6IDAuNXJlbTtcblx0Y3Vyc29yOiBwb2ludGVyO1xuXHRmb250LXNpemU6IDExcHg7XG5cdGNvbG9yOiB2YXIoLS1mZy0zKTtcbn1cblxuLmNoZWNrYm94IHtcblx0YXBwZWFyYW5jZTogbm9uZTtcblx0d2lkdGg6IDE0cHg7XG5cdGhlaWdodDogMTRweDtcblx0Ym9yZGVyOiAxcHggc29saWQgdmFyKC0tYm9yZGVyLWhpKTtcblx0YmFja2dyb3VuZDogdmFyKC0tYmctMik7XG5cdGN1cnNvcjogcG9pbnRlcjtcblx0ZmxleC1zaHJpbms6IDA7XG59XG5cbi5jaGVja2JveDpjaGVja2VkIHtcblx0YmFja2dyb3VuZDogdmFyKC0tdGVhbCk7XG5cdGJvcmRlci1jb2xvcjogdmFyKC0tdGVhbCk7XG59XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvbW50L2tpcmUvUGVyc29uYWwvUHJvZ3JhbW1pbmcvUHJvamVjdHMvTUVJQy93ZWIvYXBwL3VpL0NoZWNrYm94LnZ1ZSJ9