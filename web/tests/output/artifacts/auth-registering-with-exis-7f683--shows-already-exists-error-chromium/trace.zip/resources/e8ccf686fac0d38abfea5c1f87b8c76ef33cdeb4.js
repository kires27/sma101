/*!
* vue-router v5.1.0
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
import { _ as mergeOptions, a as routerKey, c as NavigationFailureType, d as applyToParams, f as assign, i as routeLocationKey, l as createRouterError, m as isArray, n as useRouter, o as routerViewLocationKey, r as matchedRouteKey, s as viewDepthKey, t as useRoute, u as isNavigationFailure, v as noop, y as isBrowser } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue-router@5.1.0_@vue+compiler-sfc@3.5.38_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_ligh_834d8a9034f0ed0e409191762519b088/node_modules/vue-router/dist/useApi-s_02lHjl.js?v=583078ff";
import { C as isSameRouteLocation, E as parseURL, F as warn$1, M as encodeHash, N as encodeParam, O as stringifyURL, S as START_LOCATION_NORMALIZED, T as isSameRouteRecord, _ as saveScrollPosition, a as loadRouteLocation, b as normalizeBase, c as useCallbacks, d as stringifyQuery, f as isRouteLocation, g as getScrollKey, h as getSavedScrollPosition, i as guardToPromiseFn, j as decode, k as stripBase, l as normalizeQuery, m as computeScrollPosition, n as extractChangingRecords, o as onBeforeRouteLeave, p as isRouteName, r as extractComponentsGuards, s as onBeforeRouteUpdate, t as addDevtools, u as parseQuery, v as scrollToPosition, w as isSameRouteLocationParams, y as createHref } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue-router@5.1.0_@vue+compiler-sfc@3.5.38_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_ligh_834d8a9034f0ed0e409191762519b088/node_modules/vue-router/dist/devtools-DCoWQoU_.js?v=583078ff";
import { computed, defineComponent, getCurrentInstance, h, inject, nextTick, provide, reactive, ref, shallowReactive, shallowRef, unref, watch, watchEffect } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
let createBaseLocation = () => location.protocol + "//" + location.host;
function createCurrentLocation(base, location2) {
  const { pathname, search, hash } = location2;
  const hashPos = base.indexOf("#");
  if (hashPos > -1) {
    let slicePos = hash.includes(base.slice(hashPos)) ? base.slice(hashPos).length : 1;
    let pathFromHash = hash.slice(slicePos);
    if (pathFromHash[0] !== "/") pathFromHash = "/" + pathFromHash;
    return stripBase(pathFromHash, "");
  }
  return stripBase(pathname, base) + search + hash;
}
function useHistoryListeners(base, historyState, currentLocation, replace) {
  let listeners = [];
  let teardowns = [];
  let pauseState = null;
  const popStateHandler = ({ state }) => {
    const to = createCurrentLocation(base, location);
    const from = currentLocation.value;
    const fromState = historyState.value;
    let delta = 0;
    if (state) {
      currentLocation.value = to;
      historyState.value = state;
      if (pauseState && pauseState === from) {
        pauseState = null;
        return;
      }
      delta = fromState ? state.position - fromState.position : 0;
    } else replace(to);
    listeners.forEach((listener) => {
      listener(currentLocation.value, from, {
        delta,
        type: "pop",
        direction: delta ? delta > 0 ? "forward" : "back" : ""
      });
    });
  };
  function pauseListeners() {
    pauseState = currentLocation.value;
  }
  function listen(callback) {
    listeners.push(callback);
    const teardown = () => {
      const index = listeners.indexOf(callback);
      if (index > -1) listeners.splice(index, 1);
    };
    teardowns.push(teardown);
    return teardown;
  }
  function beforeUnloadListener() {
    if (document.visibilityState === "hidden") {
      const { history: history2 } = window;
      if (!history2.state) return;
      history2.replaceState(assign({}, history2.state, { scroll: computeScrollPosition() }), "");
    }
  }
  function destroy() {
    for (const teardown of teardowns) teardown();
    teardowns = [];
    window.removeEventListener("popstate", popStateHandler);
    window.removeEventListener("pagehide", beforeUnloadListener);
    document.removeEventListener("visibilitychange", beforeUnloadListener);
  }
  window.addEventListener("popstate", popStateHandler);
  window.addEventListener("pagehide", beforeUnloadListener);
  document.addEventListener("visibilitychange", beforeUnloadListener);
  return {
    pauseListeners,
    listen,
    destroy
  };
}
function buildState(back, current, forward, replaced = false, computeScroll = false) {
  return {
    back,
    current,
    forward,
    replaced,
    position: window.history.length,
    scroll: computeScroll ? computeScrollPosition() : null
  };
}
function useHistoryStateNavigation(base) {
  const { history: history2, location: location2 } = window;
  const currentLocation = { value: createCurrentLocation(base, location2) };
  const historyState = { value: history2.state };
  if (!historyState.value) changeLocation(currentLocation.value, {
    back: null,
    current: currentLocation.value,
    forward: null,
    position: history2.length - 1,
    replaced: true,
    scroll: null
  }, true);
  function changeLocation(to, state, replace2) {
    const hashIndex = base.indexOf("#");
    const url = hashIndex > -1 ? (location2.host && document.querySelector("base") ? base : base.slice(hashIndex)) + to : createBaseLocation() + base + to;
    try {
      history2[replace2 ? "replaceState" : "pushState"](state, "", url);
      historyState.value = state;
    } catch (err) {
      if (true) warn$1("Error with push/replace State", err);
      else console.error(err);
      location2[replace2 ? "replace" : "assign"](url);
    }
  }
  function replace(to, data) {
    changeLocation(to, assign({}, history2.state, buildState(historyState.value.back, to, historyState.value.forward, true), data, { position: historyState.value.position }), true);
    currentLocation.value = to;
  }
  function push(to, data) {
    const currentState = assign({}, historyState.value, history2.state, {
      forward: to,
      scroll: computeScrollPosition()
    });
    if (!history2.state) warn$1("history.state seems to have been manually replaced without preserving the necessary values. Make sure to preserve existing history state if you are manually calling history.replaceState:\n\nhistory.replaceState(history.state, '', url)\n\nYou can find more information at https://router.vuejs.org/guide/migration/#Usage-of-history-state");
    changeLocation(currentState.current, currentState, true);
    changeLocation(to, assign({}, buildState(currentLocation.value, to, null), { position: currentState.position + 1 }, data), false);
    currentLocation.value = to;
  }
  return {
    location: currentLocation,
    state: historyState,
    push,
    replace
  };
}
function createWebHistory(base) {
  base = normalizeBase(base);
  const historyNavigation = useHistoryStateNavigation(base);
  const historyListeners = useHistoryListeners(base, historyNavigation.state, historyNavigation.location, historyNavigation.replace);
  function go(delta, triggerListeners = true) {
    if (!triggerListeners) historyListeners.pauseListeners();
    history.go(delta);
  }
  const routerHistory = assign({
    location: "",
    base,
    go,
    createHref: createHref.bind(null, base)
  }, historyNavigation, historyListeners);
  Object.defineProperty(routerHistory, "location", {
    enumerable: true,
    get: () => historyNavigation.location.value
  });
  Object.defineProperty(routerHistory, "state", {
    enumerable: true,
    get: () => historyNavigation.state.value
  });
  return routerHistory;
}
function createWebHashHistory(base) {
  base = location.host ? base || location.pathname + location.search : "";
  if (!base.includes("#")) base += "#";
  if (!base.endsWith("#/") && !base.endsWith("#")) warn$1(`A hash base must end with a "#":
"${base}" should be "${base.replace(/#.*$/, "#")}".`);
  return createWebHistory(base);
}
function createMemoryHistory(base = "") {
  let listeners = [];
  let queue = [["", {}]];
  let position = 0;
  base = normalizeBase(base);
  function setLocation(location2, state = {}) {
    position++;
    if (position !== queue.length) queue.splice(position);
    queue.push([location2, state]);
  }
  function triggerListeners(to, from, { direction, delta }) {
    const info = {
      direction,
      delta,
      type: "pop"
    };
    for (const callback of listeners) callback(to, from, info);
  }
  const routerHistory = {
    location: "",
    state: {},
    base,
    createHref: createHref.bind(null, base),
    replace(to, state) {
      queue.splice(position--, 1);
      setLocation(to, state);
    },
    push(to, state) {
      setLocation(to, state);
    },
    listen(callback) {
      listeners.push(callback);
      return () => {
        const index = listeners.indexOf(callback);
        if (index > -1) listeners.splice(index, 1);
      };
    },
    destroy() {
      listeners = [];
      queue = [["", {}]];
      position = 0;
    },
    go(delta, shouldTrigger = true) {
      const from = this.location;
      const direction = delta < 0 ? "back" : "forward";
      position = Math.max(0, Math.min(position + delta, queue.length - 1));
      if (shouldTrigger) triggerListeners(this.location, from, {
        direction,
        delta
      });
    }
  };
  Object.defineProperty(routerHistory, "location", {
    enumerable: true,
    get: () => queue[position][0]
  });
  Object.defineProperty(routerHistory, "state", {
    enumerable: true,
    get: () => queue[position][1]
  });
  return routerHistory;
}
const ROOT_TOKEN = {
  type: 0,
  value: ""
};
const VALID_PARAM_RE = /[a-zA-Z0-9_]/;
function tokenizePath(path) {
  if (!path) return [[]];
  if (path === "/") return [[ROOT_TOKEN]];
  if (!path.startsWith("/")) throw new Error(true ? `Route paths should start with a "/": "${path}" should be "/${path}".` : `Invalid path "${path}"`);
  function crash(message) {
    throw new Error(`ERR (${state})/"${buffer}": ${message}`);
  }
  let state = 0;
  let previousState = state;
  const tokens = [];
  let segment;
  function finalizeSegment() {
    if (segment) tokens.push(segment);
    segment = [];
  }
  let i = 0;
  let char;
  let buffer = "";
  let customRe = "";
  function consumeBuffer() {
    if (!buffer) return;
    if (state === 0) segment.push({
      type: 0,
      value: buffer
    });
    else if (state === 1 || state === 2 || state === 3) {
      if (segment.length > 1 && (char === "*" || char === "+")) crash(`A repeatable param (${buffer}) must be alone in its segment. eg: '/:ids+.`);
      segment.push({
        type: 1,
        value: buffer,
        regexp: customRe,
        repeatable: char === "*" || char === "+",
        optional: char === "*" || char === "?"
      });
    } else crash("Invalid state to consume buffer");
    buffer = "";
  }
  function addCharToBuffer() {
    buffer += char;
  }
  while (i < path.length) {
    char = path[i++];
    switch (state) {
      case 0:
        if (char === "\\") {
          previousState = state;
          state = 4;
        } else if (char === "/") {
          if (buffer) consumeBuffer();
          finalizeSegment();
        } else if (char === ":") {
          consumeBuffer();
          state = 1;
        } else addCharToBuffer();
        break;
      case 4:
        addCharToBuffer();
        state = previousState;
        break;
      case 1:
        if (char === "(") state = 2;
        else if (VALID_PARAM_RE.test(char)) addCharToBuffer();
        else {
          consumeBuffer();
          state = 0;
          if (char !== "*" && char !== "?" && char !== "+") i--;
        }
        break;
      case 2:
        if (char === ")") if (customRe[customRe.length - 1] == "\\") customRe = customRe.slice(0, -1) + char;
        else state = 3;
        else customRe += char;
        break;
      case 3:
        consumeBuffer();
        state = 0;
        if (char !== "*" && char !== "?" && char !== "+") i--;
        customRe = "";
        break;
      default:
        crash("Unknown state");
        break;
    }
  }
  if (state === 2) crash(`Unfinished custom RegExp for param "${buffer}"`);
  consumeBuffer();
  finalizeSegment();
  return tokens;
}
const BASE_PARAM_PATTERN = "[^/]+?";
const BASE_PATH_PARSER_OPTIONS = {
  sensitive: false,
  strict: false,
  start: true,
  end: true
};
const REGEX_CHARS_RE = /[.+*?^${}()[\]/\\]/g;
function tokensToParser(segments, extraOptions) {
  const options = assign({}, BASE_PATH_PARSER_OPTIONS, extraOptions);
  const score = [];
  let pattern = options.start ? "^" : "";
  const keys = [];
  for (const segment of segments) {
    const segmentScores = segment.length ? [] : [90];
    if (options.strict && !segment.length) pattern += "/";
    for (let tokenIndex = 0; tokenIndex < segment.length; tokenIndex++) {
      const token = segment[tokenIndex];
      let subSegmentScore = 40 + (options.sensitive ? 0.25 : 0);
      if (token.type === 0) {
        if (!tokenIndex) pattern += "/";
        pattern += token.value.replace(REGEX_CHARS_RE, "\\$&");
        subSegmentScore += 40;
      } else if (token.type === 1) {
        const { value, repeatable, optional, regexp } = token;
        keys.push({
          name: value,
          repeatable,
          optional
        });
        const re2 = regexp ? regexp : BASE_PARAM_PATTERN;
        if (re2 !== BASE_PARAM_PATTERN) {
          subSegmentScore += 10;
          try {
            new RegExp(`(${re2})`);
          } catch (err) {
            throw new Error(`Invalid custom RegExp for param "${value}" (${re2}): ` + err.message);
          }
        }
        let subPattern = repeatable ? `((?:${re2})(?:/(?:${re2}))*)` : `(${re2})`;
        if (!tokenIndex) subPattern = optional && segment.length < 2 ? `(?:/${subPattern})` : "/" + subPattern;
        if (optional) subPattern += "?";
        pattern += subPattern;
        subSegmentScore += 20;
        if (optional) subSegmentScore += -8;
        if (repeatable) subSegmentScore += -20;
        if (re2 === ".*") subSegmentScore += -50;
      }
      segmentScores.push(subSegmentScore);
    }
    score.push(segmentScores);
  }
  if (options.strict && options.end) {
    const i = score.length - 1;
    score[i][score[i].length - 1] += 0.7000000000000001;
  }
  if (!options.strict) pattern += "/?";
  if (options.end) pattern += "$";
  else if (options.strict && !pattern.endsWith("/")) pattern += "(?:/|$)";
  const re = new RegExp(pattern, options.sensitive ? "" : "i");
  function parse(path) {
    const match = path.match(re);
    const params = {};
    if (!match) return null;
    for (let i = 1; i < match.length; i++) {
      const value = match[i] || "";
      const key = keys[i - 1];
      params[key.name] = value && key.repeatable ? value.split("/") : value;
    }
    return params;
  }
  function stringify(params) {
    let path = "";
    let avoidDuplicatedSlash = false;
    for (const segment of segments) {
      if (!avoidDuplicatedSlash || !path.endsWith("/")) path += "/";
      avoidDuplicatedSlash = false;
      for (const token of segment) if (token.type === 0) path += token.value;
      else if (token.type === 1) {
        const { value, repeatable, optional } = token;
        const param = value in params ? params[value] : "";
        if (isArray(param) && !repeatable) throw new Error(`Provided param "${value}" is an array but it is not repeatable (* or + modifiers)`);
        const text = isArray(param) ? param.join("/") : param;
        if (!text) if (optional) {
          if (segment.length < 2) if (path.endsWith("/")) path = path.slice(0, -1);
          else avoidDuplicatedSlash = true;
        } else throw new Error(`Missing required param "${value}"`);
        path += text;
      }
    }
    return path || "/";
  }
  return {
    re,
    score,
    keys,
    parse,
    stringify
  };
}
function compareScoreArray(a, b) {
  let i = 0;
  while (i < a.length && i < b.length) {
    const diff = b[i] - a[i];
    if (diff) return diff;
    i++;
  }
  if (a.length < b.length) return a.length === 1 && a[0] === 80 ? -1 : 1;
  else if (a.length > b.length) return b.length === 1 && b[0] === 80 ? 1 : -1;
  return 0;
}
function comparePathParserScore(a, b) {
  let i = 0;
  const aScore = a.score;
  const bScore = b.score;
  while (i < aScore.length && i < bScore.length) {
    const comp = compareScoreArray(aScore[i], bScore[i]);
    if (comp) return comp;
    i++;
  }
  if (Math.abs(bScore.length - aScore.length) === 1) {
    if (isLastScoreNegative(aScore)) return 1;
    if (isLastScoreNegative(bScore)) return -1;
  }
  return bScore.length - aScore.length;
}
function isLastScoreNegative(score) {
  const last = score[score.length - 1];
  return score.length > 0 && last[last.length - 1] < 0;
}
const PATH_PARSER_OPTIONS_DEFAULTS = {
  strict: false,
  end: true,
  sensitive: false
};
function createRouteRecordMatcher(record, parent, options) {
  const parser = tokensToParser(tokenizePath(record.path), options);
  if (true) {
    const existingKeys = /* @__PURE__ */ new Set();
    for (const key of parser.keys) {
      if (existingKeys.has(key.name)) warn$1(`Found duplicated params with name "${key.name}" for path "${record.path}". Only the last one will be available on "$route.params".`);
      existingKeys.add(key.name);
    }
  }
  const matcher = assign(parser, {
    record,
    parent,
    children: [],
    alias: []
  });
  if (parent) {
    if (!matcher.record.aliasOf === !parent.record.aliasOf) parent.children.push(matcher);
  }
  return matcher;
}
function createRouterMatcher(routes, globalOptions) {
  const matchers = [];
  const matcherMap = /* @__PURE__ */ new Map();
  globalOptions = mergeOptions(PATH_PARSER_OPTIONS_DEFAULTS, globalOptions);
  function getRecordMatcher(name) {
    return matcherMap.get(name);
  }
  function addRoute(record, parent, originalRecord) {
    const isRootAdd = !originalRecord;
    const mainNormalizedRecord = normalizeRouteRecord(record);
    if (true) checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent);
    mainNormalizedRecord.aliasOf = originalRecord && originalRecord.record;
    const options = mergeOptions(globalOptions, record);
    const normalizedRecords = [mainNormalizedRecord];
    if ("alias" in record) {
      const aliases = typeof record.alias === "string" ? [record.alias] : record.alias;
      for (const alias of aliases) normalizedRecords.push(normalizeRouteRecord(assign({}, mainNormalizedRecord, {
        components: originalRecord ? originalRecord.record.components : mainNormalizedRecord.components,
        path: alias,
        aliasOf: originalRecord ? originalRecord.record : mainNormalizedRecord
      })));
    }
    let matcher;
    let originalMatcher;
    for (const normalizedRecord of normalizedRecords) {
      const { path } = normalizedRecord;
      if (parent && path[0] !== "/") {
        const parentPath = parent.record.path;
        const connectingSlash = parentPath[parentPath.length - 1] === "/" ? "" : "/";
        normalizedRecord.path = parent.record.path + (path && connectingSlash + path);
      }
      if (normalizedRecord.path === "*") throw new Error('Catch all routes ("*") must now be defined using a param with a custom regexp.\nSee more at https://router.vuejs.org/guide/migration/#Removed-star-or-catch-all-routes.');
      matcher = createRouteRecordMatcher(normalizedRecord, parent, options);
      if (parent && path[0] === "/") checkMissingParamsInAbsolutePath(matcher, parent);
      if (originalRecord) {
        originalRecord.alias.push(matcher);
        if (true) checkSameParams(originalRecord, matcher);
      } else {
        originalMatcher = originalMatcher || matcher;
        if (originalMatcher !== matcher) originalMatcher.alias.push(matcher);
        if (isRootAdd && record.name && !isAliasRecord(matcher)) {
          if (true) checkSameNameAsAncestor(record, parent);
          removeRoute(record.name);
        }
      }
      if (isMatchable(matcher)) insertMatcher(matcher);
      if (mainNormalizedRecord.children) {
        const children = mainNormalizedRecord.children;
        for (let i = 0; i < children.length; i++) addRoute(children[i], matcher, originalRecord && originalRecord.children[i]);
      }
      originalRecord = originalRecord || matcher;
    }
    return originalMatcher ? () => {
      removeRoute(originalMatcher);
    } : noop;
  }
  function removeRoute(matcherRef) {
    if (isRouteName(matcherRef)) {
      const matcher = matcherMap.get(matcherRef);
      if (matcher) {
        matcherMap.delete(matcherRef);
        matchers.splice(matchers.indexOf(matcher), 1);
        matcher.children.forEach(removeRoute);
        matcher.alias.forEach(removeRoute);
      }
    } else {
      const index = matchers.indexOf(matcherRef);
      if (index > -1) {
        matchers.splice(index, 1);
        if (matcherRef.record.name) matcherMap.delete(matcherRef.record.name);
        matcherRef.children.forEach(removeRoute);
        matcherRef.alias.forEach(removeRoute);
      }
    }
  }
  function getRoutes() {
    return matchers;
  }
  function insertMatcher(matcher) {
    const index = findInsertionIndex(matcher, matchers);
    matchers.splice(index, 0, matcher);
    if (matcher.record.name && !isAliasRecord(matcher)) matcherMap.set(matcher.record.name, matcher);
  }
  function resolve(location2, currentLocation) {
    let matcher;
    let params = {};
    let path;
    let name;
    if ("name" in location2 && location2.name) {
      matcher = matcherMap.get(location2.name);
      if (!matcher) throw createRouterError(1, { location: location2 });
      if (true) {
        const invalidParams = Object.keys(location2.params || {}).filter((paramName) => !matcher.keys.find((k) => k.name === paramName));
        if (invalidParams.length) {
          const isInherited = !matcher.keys.length && invalidParams.some((name2) => name2 in currentLocation.params);
          warn$1(`Discarded invalid param(s) "${invalidParams.join('", "')}" when navigating.` + (isInherited ? ` If you are using a catch-all route with a named redirect, pass an empty \`params\` object: \`redirect: { name: '...', params: {} }\`.` : "") + ` See https://github.com/vuejs/router/blob/main/packages/router/CHANGELOG.md#414-2022-08-22 for more details.`);
        }
      }
      name = matcher.record.name;
      params = assign(pickParams(currentLocation.params, matcher.keys.filter((k) => !k.optional).concat(matcher.parent ? matcher.parent.keys.filter((k) => k.optional) : []).map((k) => k.name)), location2.params && pickParams(location2.params, matcher.keys.map((k) => k.name)));
      path = matcher.stringify(params);
    } else if (location2.path != null) {
      path = location2.path;
      if (!path.startsWith("/")) warn$1(`The Matcher cannot resolve relative paths but received "${path}". Unless you directly called \`matcher.resolve("${path}")\`, this is probably a bug in vue-router. Please open an issue at https://github.com/vuejs/router/issues/new/choose.`);
      matcher = matchers.find((m) => m.re.test(path));
      if (matcher) {
        params = matcher.parse(path);
        name = matcher.record.name;
        matcher.keys.forEach((key) => {
          if (key.optional && !params[key.name]) delete params[key.name];
        });
      }
    } else {
      matcher = currentLocation.name ? matcherMap.get(currentLocation.name) : matchers.find((m) => m.re.test(currentLocation.path));
      if (!matcher) throw createRouterError(1, {
        location: location2,
        currentLocation
      });
      name = matcher.record.name;
      params = assign({}, currentLocation.params, location2.params);
      path = matcher.stringify(params);
    }
    const matched = [];
    let parentMatcher = matcher;
    while (parentMatcher) {
      matched.unshift(parentMatcher.record);
      parentMatcher = parentMatcher.parent;
    }
    return {
      name,
      path,
      params,
      matched,
      meta: mergeMetaFields(matched)
    };
  }
  routes.forEach((route) => addRoute(route));
  function clearRoutes() {
    matchers.length = 0;
    matcherMap.clear();
  }
  return {
    addRoute,
    resolve,
    removeRoute,
    clearRoutes,
    getRoutes,
    getRecordMatcher
  };
}
function pickParams(params, keys) {
  const newParams = {};
  for (const key of keys) if (key in params) newParams[key] = params[key];
  return newParams;
}
function normalizeRouteRecord(record) {
  const normalized = {
    path: record.path,
    redirect: record.redirect,
    name: record.name,
    meta: record.meta || {},
    aliasOf: record.aliasOf,
    beforeEnter: record.beforeEnter,
    props: normalizeRecordProps(record),
    children: record.children || [],
    instances: {},
    leaveGuards: /* @__PURE__ */ new Set(),
    updateGuards: /* @__PURE__ */ new Set(),
    enterCallbacks: {},
    components: "components" in record ? record.components || null : record.component && { default: record.component }
  };
  Object.defineProperty(normalized, "mods", { value: {} });
  return normalized;
}
function normalizeRecordProps(record) {
  const propsObject = {};
  const props = record.props || false;
  if ("component" in record) propsObject.default = props;
  else for (const name in record.components) propsObject[name] = typeof props === "object" ? props[name] : props;
  return propsObject;
}
function isAliasRecord(record) {
  while (record) {
    if (record.record.aliasOf) return true;
    record = record.parent;
  }
  return false;
}
function mergeMetaFields(matched) {
  return matched.reduce((meta, record) => assign(meta, record.meta), {});
}
function isSameParam(a, b) {
  return a.name === b.name && a.optional === b.optional && a.repeatable === b.repeatable;
}
function checkSameParams(a, b) {
  for (const key of a.keys) if (!key.optional && !b.keys.find(isSameParam.bind(null, key))) return warn$1(`Alias "${b.record.path}" and the original record: "${a.record.path}" must have the exact same param named "${key.name}"`);
  for (const key of b.keys) if (!key.optional && !a.keys.find(isSameParam.bind(null, key))) return warn$1(`Alias "${b.record.path}" and the original record: "${a.record.path}" must have the exact same param named "${key.name}"`);
}
function checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent) {
  if (parent && parent.record.name && !mainNormalizedRecord.name && !mainNormalizedRecord.path && mainNormalizedRecord.children.length === 0) warn$1(`The route named "${String(parent.record.name)}" has a child without a name, an empty path, and no children. This is probably a mistake: using that name won't render the empty path child so you probably want to move the name to the child instead. If this is intentional, add a name to the child route to silence the warning.`);
}
function checkSameNameAsAncestor(record, parent) {
  for (let ancestor = parent; ancestor; ancestor = ancestor.parent) if (ancestor.record.name === record.name) throw new Error(`A route named "${String(record.name)}" has been added as a ${parent === ancestor ? "child" : "descendant"} of a route with the same name. Route names must be unique and a nested route cannot use the same name as an ancestor.`);
}
function checkMissingParamsInAbsolutePath(record, parent) {
  for (const key of parent.keys) if (!record.keys.find(isSameParam.bind(null, key))) return warn$1(`Absolute path "${record.record.path}" must have the exact same param named "${key.name}" as its parent "${parent.record.path}".`);
}
function findInsertionIndex(matcher, matchers) {
  let lower = 0;
  let upper = matchers.length;
  while (lower !== upper) {
    const mid = lower + upper >> 1;
    if (comparePathParserScore(matcher, matchers[mid]) < 0) upper = mid;
    else lower = mid + 1;
  }
  const insertionAncestor = getInsertionAncestor(matcher);
  if (insertionAncestor) {
    upper = matchers.lastIndexOf(insertionAncestor, upper - 1);
    if (upper < 0) warn$1(`Finding ancestor route "${insertionAncestor.record.path}" failed for "${matcher.record.path}"`);
  }
  return upper;
}
function getInsertionAncestor(matcher) {
  let ancestor = matcher;
  while (ancestor = ancestor.parent) if (isMatchable(ancestor) && comparePathParserScore(matcher, ancestor) === 0) return ancestor;
}
function isMatchable({ record }) {
  return !!(record.name || record.components && Object.keys(record.components).length || record.redirect);
}
function useLink(props) {
  const router = inject(routerKey);
  const currentRoute = inject(routeLocationKey);
  let hasPrevious = false;
  let previousTo = null;
  const route = computed(() => {
    const to = unref(props.to);
    if (!hasPrevious || to !== previousTo) {
      if (!isRouteLocation(to)) if (hasPrevious) warn$1(`Invalid value for prop "to" in useLink()
- to:`, to, `
- previous to:`, previousTo, `
- props:`, props);
      else warn$1(`Invalid value for prop "to" in useLink()
- to:`, to, `
- props:`, props);
      previousTo = to;
      hasPrevious = true;
    }
    return router.resolve(to);
  });
  const activeRecordIndex = computed(() => {
    const { matched } = route.value;
    const { length } = matched;
    const routeMatched = matched[length - 1];
    const currentMatched = currentRoute.matched;
    if (!routeMatched || !currentMatched.length) return -1;
    const index = currentMatched.findIndex(isSameRouteRecord.bind(null, routeMatched));
    if (index > -1) return index;
    const parentRecordPath = getOriginalPath(matched[length - 2]);
    return length > 1 && getOriginalPath(routeMatched) === parentRecordPath && currentMatched[currentMatched.length - 1].path !== parentRecordPath ? currentMatched.findIndex(isSameRouteRecord.bind(null, matched[length - 2])) : index;
  });
  const isActive = computed(() => activeRecordIndex.value > -1 && includesParams(currentRoute.params, route.value.params));
  const isExactActive = computed(() => activeRecordIndex.value > -1 && activeRecordIndex.value === currentRoute.matched.length - 1 && isSameRouteLocationParams(currentRoute.params, route.value.params));
  function navigate(e = {}) {
    if (guardEvent(e)) {
      const p = router[unref(props.replace) ? "replace" : "push"](unref(props.to)).catch(noop);
      if (props.viewTransition && typeof document !== "undefined" && "startViewTransition" in document) document.startViewTransition(() => p);
      return p;
    }
    return Promise.resolve();
  }
  if (isBrowser) {
    const instance = getCurrentInstance();
    if (instance) {
      const linkContextDevtools = {
        route: route.value,
        isActive: isActive.value,
        isExactActive: isExactActive.value,
        error: null
      };
      instance.__vrl_devtools = instance.__vrl_devtools || [];
      instance.__vrl_devtools.push(linkContextDevtools);
      watchEffect(() => {
        linkContextDevtools.route = route.value;
        linkContextDevtools.isActive = isActive.value;
        linkContextDevtools.isExactActive = isExactActive.value;
        linkContextDevtools.error = isRouteLocation(unref(props.to)) ? null : 'Invalid "to" value';
      }, { flush: "post" });
    }
  }
  return {
    route,
    href: computed(() => route.value.href),
    isActive,
    isExactActive,
    navigate
  };
}
function preferSingleVNode(vnodes) {
  return vnodes.length === 1 ? vnodes[0] : vnodes;
}
const RouterLink = /* @__PURE__ */ defineComponent({
  name: "RouterLink",
  compatConfig: { MODE: 3 },
  props: {
    to: {
      type: [String, Object],
      required: true
    },
    replace: Boolean,
    activeClass: String,
    exactActiveClass: String,
    custom: Boolean,
    ariaCurrentValue: {
      type: String,
      default: "page"
    },
    viewTransition: Boolean
  },
  useLink,
  setup(props, { slots }) {
    const link = reactive(useLink(props));
    const { options } = inject(routerKey);
    const elClass = computed(() => ({
      [getLinkClass(props.activeClass, options.linkActiveClass, "router-link-active")]: link.isActive,
      [getLinkClass(props.exactActiveClass, options.linkExactActiveClass, "router-link-exact-active")]: link.isExactActive
    }));
    return () => {
      const children = slots.default && preferSingleVNode(slots.default(link));
      return props.custom ? children : h("a", {
        "aria-current": link.isExactActive ? props.ariaCurrentValue : null,
        href: link.href,
        onClick: link.navigate,
        class: elClass.value
      }, children);
    };
  }
});
function guardEvent(e) {
  if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) return;
  if (e.defaultPrevented) return;
  if (e.button !== void 0 && e.button !== 0) return;
  if (e.currentTarget && e.currentTarget.getAttribute) {
    const target = e.currentTarget.getAttribute("target");
    if (/\b_blank\b/i.test(target)) return;
  }
  if (e.preventDefault) e.preventDefault();
  return true;
}
function includesParams(outer, inner) {
  for (const key in inner) {
    const innerValue = inner[key];
    const outerValue = outer[key];
    if (typeof innerValue === "string") {
      if (innerValue !== outerValue) return false;
    } else if (!isArray(outerValue) || outerValue.length !== innerValue.length || innerValue.some((value, i) => value.valueOf() !== outerValue[i].valueOf())) return false;
  }
  return true;
}
function getOriginalPath(record) {
  return record ? record.aliasOf ? record.aliasOf.path : record.path : "";
}
const getLinkClass = (propClass, globalClass, defaultClass) => propClass != null ? propClass : globalClass != null ? globalClass : defaultClass;
const RouterViewImpl = /* @__PURE__ */ defineComponent({
  name: "RouterView",
  inheritAttrs: false,
  props: {
    name: {
      type: String,
      default: "default"
    },
    route: Object
  },
  compatConfig: { MODE: 3 },
  setup(props, { attrs, slots }) {
    warnDeprecatedUsage();
    const injectedRoute = inject(routerViewLocationKey);
    const routeToDisplay = computed(() => props.route || injectedRoute.value);
    const injectedDepth = inject(viewDepthKey, 0);
    const depth = computed(() => {
      let initialDepth = unref(injectedDepth);
      const { matched } = routeToDisplay.value;
      let matchedRoute;
      while ((matchedRoute = matched[initialDepth]) && !matchedRoute.components) initialDepth++;
      return initialDepth;
    });
    const matchedRouteRef = computed(() => routeToDisplay.value.matched[depth.value]);
    provide(viewDepthKey, computed(() => depth.value + 1));
    provide(matchedRouteKey, matchedRouteRef);
    provide(routerViewLocationKey, routeToDisplay);
    const viewRef = ref();
    watch(() => [
      viewRef.value,
      matchedRouteRef.value,
      props.name
    ], ([instance, to, name], [oldInstance, from, _oldName]) => {
      if (to) {
        to.instances[name] = instance;
        if (from && from !== to && instance && instance === oldInstance) {
          if (!to.leaveGuards.size) to.leaveGuards = from.leaveGuards;
          if (!to.updateGuards.size) to.updateGuards = from.updateGuards;
        }
      }
      if (instance && to && (!from || !isSameRouteRecord(to, from) || !oldInstance)) (to.enterCallbacks[name] || []).forEach((callback) => callback(instance));
    }, { flush: "post" });
    return () => {
      const route = routeToDisplay.value;
      const currentName = props.name;
      const matchedRoute = matchedRouteRef.value;
      const ViewComponent = matchedRoute && matchedRoute.components[currentName];
      if (!ViewComponent) return normalizeSlot(slots.default, {
        Component: ViewComponent,
        route
      });
      const routePropsOption = matchedRoute.props[currentName];
      const routeProps = routePropsOption ? routePropsOption === true ? route.params : typeof routePropsOption === "function" ? routePropsOption(route) : routePropsOption : null;
      const onVnodeUnmounted = (vnode) => {
        if (vnode.component.isUnmounted) matchedRoute.instances[currentName] = null;
      };
      const component = h(ViewComponent, assign({}, routeProps, attrs, {
        onVnodeUnmounted,
        ref: viewRef
      }));
      if (isBrowser && component.ref) {
        const info = {
          depth: depth.value,
          name: matchedRoute.name,
          path: matchedRoute.path,
          meta: matchedRoute.meta
        };
        (isArray(component.ref) ? component.ref.map((r) => r.i) : [component.ref.i]).forEach((instance) => {
          instance.__vrv_devtools = info;
        });
      }
      return normalizeSlot(slots.default, {
        Component: component,
        route
      }) || component;
    };
  }
});
function normalizeSlot(slot, data) {
  if (!slot) return null;
  const slotContent = slot(data);
  return slotContent.length === 1 ? slotContent[0] : slotContent;
}
const RouterView = RouterViewImpl;
function warnDeprecatedUsage() {
  const instance = getCurrentInstance();
  const parentName = instance.parent && instance.parent.type.name;
  const parentSubTreeType = instance.parent && instance.parent.subTree && instance.parent.subTree.type;
  if (parentName && (parentName === "KeepAlive" || parentName.includes("Transition")) && typeof parentSubTreeType === "object" && parentSubTreeType.name === "RouterView") {
    const comp = parentName === "KeepAlive" ? "keep-alive" : "transition";
    warn$1(`<router-view> can no longer be used directly inside <${comp}>.
Use slot props instead:

<router-view v-slot="{ Component }">
  <${comp}>
    <component :is="Component" />
  </${comp}>
</router-view>`);
  }
}
function createRouter(options) {
  const matcher = createRouterMatcher(options.routes, options);
  const parseQuery$1 = options.parseQuery || parseQuery;
  const stringifyQuery$1 = options.stringifyQuery || stringifyQuery;
  const routerHistory = options.history;
  if (!routerHistory) throw new Error('Provide the "history" option when calling "createRouter()": https://router.vuejs.org/api/interfaces/RouterOptions.html#history');
  const beforeGuards = useCallbacks();
  const beforeResolveGuards = useCallbacks();
  const afterGuards = useCallbacks();
  const currentRoute = shallowRef(START_LOCATION_NORMALIZED);
  let pendingLocation = START_LOCATION_NORMALIZED;
  if (isBrowser && options.scrollBehavior && "scrollRestoration" in history) history.scrollRestoration = "manual";
  const normalizeParams = applyToParams.bind(null, (paramValue) => "" + paramValue);
  const encodeParams = applyToParams.bind(null, encodeParam);
  const decodeParams = applyToParams.bind(null, decode);
  function addRoute(parentOrRoute, route) {
    let parent;
    let record;
    if (isRouteName(parentOrRoute)) {
      parent = matcher.getRecordMatcher(parentOrRoute);
      if (!parent) warn$1(`Parent route "${String(parentOrRoute)}" not found when adding child route`, route);
      record = route;
    } else record = parentOrRoute;
    return matcher.addRoute(record, parent);
  }
  function removeRoute(name) {
    const recordMatcher = matcher.getRecordMatcher(name);
    if (recordMatcher) matcher.removeRoute(recordMatcher);
    else if (true) warn$1(`Cannot remove non-existent route "${String(name)}"`);
  }
  function getRoutes() {
    return matcher.getRoutes().map((routeMatcher) => routeMatcher.record);
  }
  function hasRoute(name) {
    return !!matcher.getRecordMatcher(name);
  }
  function resolve(rawLocation, currentLocation) {
    currentLocation = assign({}, currentLocation || currentRoute.value);
    if (typeof rawLocation === "string") {
      const locationNormalized = parseURL(parseQuery$1, rawLocation, currentLocation.path);
      const matchedRoute2 = matcher.resolve({ path: locationNormalized.path }, currentLocation);
      const href2 = routerHistory.createHref(locationNormalized.fullPath);
      if (true) {
        if (href2.startsWith("//")) warn$1(`Location "${rawLocation}" resolved to "${href2}". A resolved location cannot start with multiple slashes.`);
        else if (!matchedRoute2.matched.length) warn$1(`No match found for location with path "${rawLocation}"`);
      }
      return assign(locationNormalized, matchedRoute2, {
        params: decodeParams(matchedRoute2.params),
        redirectedFrom: void 0,
        href: href2
      });
    }
    if (!isRouteLocation(rawLocation)) {
      warn$1(`router.resolve() was passed an invalid location. This will fail in production.
- Location:`, rawLocation);
      return resolve({});
    }
    let matcherLocation;
    if (rawLocation.path != null) {
      if ("params" in rawLocation && !("name" in rawLocation) && Object.keys(rawLocation.params).length) warn$1(`Path "${rawLocation.path}" was passed with params but they will be ignored. Use a named route alongside params instead.`);
      matcherLocation = assign({}, rawLocation, { path: parseURL(parseQuery$1, rawLocation.path, currentLocation.path).path });
    } else {
      const targetParams = assign({}, rawLocation.params);
      for (const key in targetParams) if (targetParams[key] == null) delete targetParams[key];
      matcherLocation = assign({}, rawLocation, { params: encodeParams(targetParams) });
      currentLocation.params = encodeParams(currentLocation.params);
    }
    const matchedRoute = matcher.resolve(matcherLocation, currentLocation);
    const hash = rawLocation.hash || "";
    if (hash && !hash.startsWith("#")) warn$1(`A \`hash\` should always start with the character "#". Replace "${hash}" with "#${hash}".`);
    matchedRoute.params = normalizeParams(decodeParams(matchedRoute.params));
    const fullPath = stringifyURL(stringifyQuery$1, assign({}, rawLocation, {
      hash: encodeHash(hash),
      path: matchedRoute.path
    }));
    const href = routerHistory.createHref(fullPath);
    if (true) {
      if (href.startsWith("//")) warn$1(`Location "${rawLocation}" resolved to "${href}". A resolved location cannot start with multiple slashes.`);
      else if (!matchedRoute.matched.length) warn$1(`No match found for location with path "${rawLocation.path != null ? rawLocation.path : rawLocation}"`);
    }
    return assign({
      fullPath,
      hash,
      query: stringifyQuery$1 === stringifyQuery ? normalizeQuery(rawLocation.query) : rawLocation.query || {}
    }, matchedRoute, {
      redirectedFrom: void 0,
      href
    });
  }
  function locationAsObject(to) {
    return typeof to === "string" ? parseURL(parseQuery$1, to, currentRoute.value.path) : assign({}, to);
  }
  function checkCanceledNavigation(to, from) {
    if (pendingLocation !== to) return createRouterError(8, {
      from,
      to
    });
  }
  function push(to) {
    return pushWithRedirect(to);
  }
  function replace(to) {
    return push(assign(locationAsObject(to), { replace: true }));
  }
  function handleRedirectRecord(to, from) {
    const lastMatched = to.matched[to.matched.length - 1];
    if (lastMatched && lastMatched.redirect) {
      const { redirect } = lastMatched;
      let newTargetLocation = typeof redirect === "function" ? redirect(to, from) : redirect;
      if (typeof newTargetLocation === "string") {
        newTargetLocation = newTargetLocation.includes("?") || newTargetLocation.includes("#") ? newTargetLocation = locationAsObject(newTargetLocation) : { path: newTargetLocation };
        newTargetLocation.params = {};
      }
      if (newTargetLocation.path == null && !("name" in newTargetLocation)) {
        warn$1(`Invalid redirect found:
${JSON.stringify(newTargetLocation, null, 2)}
 when navigating to "${to.fullPath}". A redirect must contain a name or path. This will break in production.`);
        throw new Error("Invalid redirect");
      }
      return assign({
        query: to.query,
        hash: to.hash,
        params: newTargetLocation.path != null ? {} : to.params
      }, newTargetLocation);
    }
  }
  function pushWithRedirect(to, redirectedFrom) {
    const targetLocation = pendingLocation = resolve(to);
    const from = currentRoute.value;
    const data = to.state;
    const force = to.force;
    const replace2 = to.replace === true;
    const shouldRedirect = handleRedirectRecord(targetLocation, from);
    if (shouldRedirect) return pushWithRedirect(assign(locationAsObject(shouldRedirect), {
      state: typeof shouldRedirect === "object" ? assign({}, data, shouldRedirect.state) : data,
      force,
      replace: replace2
    }), redirectedFrom || targetLocation);
    const toLocation = targetLocation;
    toLocation.redirectedFrom = redirectedFrom;
    let failure;
    if (!force && isSameRouteLocation(stringifyQuery$1, from, targetLocation)) {
      failure = createRouterError(16, {
        to: toLocation,
        from
      });
      handleScroll(from, from, true, false);
    }
    return (failure ? Promise.resolve(failure) : navigate(toLocation, from)).catch((error) => isNavigationFailure(error) ? isNavigationFailure(error, 2) ? error : markAsReady(error) : triggerError(error, toLocation, from)).then((failure2) => {
      if (failure2) {
        if (isNavigationFailure(failure2, 2)) {
          if (isSameRouteLocation(stringifyQuery$1, resolve(failure2.to), toLocation) && redirectedFrom && (redirectedFrom._count = redirectedFrom._count ? redirectedFrom._count + 1 : 1) > 30) {
            warn$1(`Detected a possibly infinite redirection in a navigation guard when going from "${from.fullPath}" to "${toLocation.fullPath}". Aborting to avoid a Stack Overflow.
 Are you always returning a new location within a navigation guard? That would lead to this error. Only return when redirecting or aborting, that should fix this. This might break in production if not fixed.`);
            return Promise.reject(/* @__PURE__ */ new Error("Infinite redirect in navigation guard"));
          }
          return pushWithRedirect(assign({ replace: replace2 }, locationAsObject(failure2.to), {
            state: typeof failure2.to === "object" ? assign({}, data, failure2.to.state) : data,
            force
          }), redirectedFrom || toLocation);
        }
      } else failure2 = finalizeNavigation(toLocation, from, true, replace2, data);
      triggerAfterEach(toLocation, from, failure2);
      return failure2;
    });
  }
  function checkCanceledNavigationAndReject(to, from) {
    const error = checkCanceledNavigation(to, from);
    return error ? Promise.reject(error) : Promise.resolve();
  }
  function runWithContext(fn) {
    const app = installedApps.values().next().value;
    return app && typeof app.runWithContext === "function" ? app.runWithContext(fn) : fn();
  }
  function navigate(to, from) {
    let guards;
    const [leavingRecords, updatingRecords, enteringRecords] = extractChangingRecords(to, from);
    guards = extractComponentsGuards(leavingRecords.reverse(), "beforeRouteLeave", to, from);
    for (const record of leavingRecords) record.leaveGuards.forEach((guard) => {
      guards.push(guardToPromiseFn(guard, to, from));
    });
    const canceledNavigationCheck = checkCanceledNavigationAndReject.bind(null, to, from);
    guards.push(canceledNavigationCheck);
    return runGuardQueue(guards).then(() => {
      guards = [];
      for (const guard of beforeGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
      guards.push(canceledNavigationCheck);
      return runGuardQueue(guards);
    }).then(() => {
      guards = extractComponentsGuards(updatingRecords, "beforeRouteUpdate", to, from);
      for (const record of updatingRecords) record.updateGuards.forEach((guard) => {
        guards.push(guardToPromiseFn(guard, to, from));
      });
      guards.push(canceledNavigationCheck);
      return runGuardQueue(guards);
    }).then(() => {
      guards = [];
      for (const record of enteringRecords) if (record.beforeEnter) if (isArray(record.beforeEnter)) for (const beforeEnter of record.beforeEnter) guards.push(guardToPromiseFn(beforeEnter, to, from));
      else guards.push(guardToPromiseFn(record.beforeEnter, to, from));
      guards.push(canceledNavigationCheck);
      return runGuardQueue(guards);
    }).then(() => {
      to.matched.forEach((record) => record.enterCallbacks = {});
      guards = extractComponentsGuards(enteringRecords, "beforeRouteEnter", to, from, runWithContext);
      guards.push(canceledNavigationCheck);
      return runGuardQueue(guards);
    }).then(() => {
      guards = [];
      for (const guard of beforeResolveGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
      guards.push(canceledNavigationCheck);
      return runGuardQueue(guards);
    }).catch((err) => isNavigationFailure(err, 8) ? err : Promise.reject(err));
  }
  function triggerAfterEach(to, from, failure) {
    afterGuards.list().forEach((guard) => runWithContext(() => guard(to, from, failure)));
  }
  function finalizeNavigation(toLocation, from, isPush, replace2, data) {
    const error = checkCanceledNavigation(toLocation, from);
    if (error) return error;
    const isFirstNavigation = from === START_LOCATION_NORMALIZED;
    const state = !isBrowser ? {} : history.state;
    if (isPush) if (replace2 || isFirstNavigation) routerHistory.replace(toLocation.fullPath, assign({ scroll: isFirstNavigation && state && state.scroll }, data));
    else routerHistory.push(toLocation.fullPath, data);
    currentRoute.value = toLocation;
    handleScroll(toLocation, from, isPush, isFirstNavigation);
    markAsReady();
  }
  let removeHistoryListener;
  function setupListeners() {
    if (removeHistoryListener) return;
    removeHistoryListener = routerHistory.listen((to, _from, info) => {
      if (!router.listening) return;
      const toLocation = resolve(to);
      const shouldRedirect = handleRedirectRecord(toLocation, router.currentRoute.value);
      if (shouldRedirect) {
        pushWithRedirect(assign(shouldRedirect, {
          replace: true,
          force: true
        }), toLocation).catch(noop);
        return;
      }
      pendingLocation = toLocation;
      const from = currentRoute.value;
      if (isBrowser) saveScrollPosition(getScrollKey(from.fullPath, info.delta), computeScrollPosition());
      navigate(toLocation, from).catch((error) => {
        if (isNavigationFailure(error, 12)) return error;
        if (isNavigationFailure(error, 2)) {
          pushWithRedirect(assign(locationAsObject(error.to), { force: true }), toLocation).then((failure) => {
            if (isNavigationFailure(failure, 20) && !info.delta && info.type === "pop") routerHistory.go(-1, false);
          }).catch(noop);
          return Promise.reject();
        }
        if (info.delta) routerHistory.go(-info.delta, false);
        return triggerError(error, toLocation, from);
      }).then((failure) => {
        failure = failure || finalizeNavigation(toLocation, from, false);
        if (failure) {
          if (info.delta && !isNavigationFailure(failure, 8)) routerHistory.go(-info.delta, false);
          else if (info.type === "pop" && isNavigationFailure(failure, 20)) routerHistory.go(-1, false);
        }
        triggerAfterEach(toLocation, from, failure);
      }).catch(noop);
    });
  }
  let readyHandlers = useCallbacks();
  let errorListeners = useCallbacks();
  let ready;
  function triggerError(error, to, from) {
    markAsReady(error);
    const list = errorListeners.list();
    if (list.length) list.forEach((handler) => handler(error, to, from));
    else {
      if (true) warn$1("uncaught error during route navigation:");
      console.error(error);
    }
    return Promise.reject(error);
  }
  function isReady() {
    if (ready && currentRoute.value !== START_LOCATION_NORMALIZED) return Promise.resolve();
    return new Promise((resolve2, reject) => {
      readyHandlers.add([resolve2, reject]);
    });
  }
  function markAsReady(err) {
    if (!ready) {
      ready = !err;
      setupListeners();
      readyHandlers.list().forEach(([resolve2, reject]) => err ? reject(err) : resolve2());
      readyHandlers.reset();
    }
    return err;
  }
  function handleScroll(to, from, isPush, isFirstNavigation) {
    const { scrollBehavior } = options;
    if (!isBrowser || !scrollBehavior) return Promise.resolve();
    const scrollPosition = !isPush && getSavedScrollPosition(getScrollKey(to.fullPath, 0)) || (isFirstNavigation || !isPush) && history.state && history.state.scroll || null;
    return nextTick().then(() => scrollBehavior(to, from, scrollPosition)).then((position) => position && scrollToPosition(position)).catch((err) => triggerError(err, to, from));
  }
  const go = (delta) => routerHistory.go(delta);
  let started;
  const installedApps = /* @__PURE__ */ new Set();
  const router = {
    currentRoute,
    listening: true,
    addRoute,
    removeRoute,
    clearRoutes: matcher.clearRoutes,
    hasRoute,
    getRoutes,
    resolve,
    options,
    push,
    replace,
    go,
    back: () => go(-1),
    forward: () => go(1),
    beforeEach: beforeGuards.add,
    beforeResolve: beforeResolveGuards.add,
    afterEach: afterGuards.add,
    onError: errorListeners.add,
    isReady,
    install(app) {
      app.component("RouterLink", RouterLink);
      app.component("RouterView", RouterView);
      app.config.globalProperties.$router = router;
      Object.defineProperty(app.config.globalProperties, "$route", {
        enumerable: true,
        get: () => unref(currentRoute)
      });
      if (isBrowser && !started && currentRoute.value === START_LOCATION_NORMALIZED) {
        started = true;
        push(routerHistory.location).catch((err) => {
          if (true) warn$1("Unexpected error when starting the router:", err);
        });
      }
      const reactiveRoute = {};
      for (const key in START_LOCATION_NORMALIZED) Object.defineProperty(reactiveRoute, key, {
        get: () => currentRoute.value[key],
        enumerable: true
      });
      app.provide(routerKey, router);
      app.provide(routeLocationKey, shallowReactive(reactiveRoute));
      app.provide(routerViewLocationKey, currentRoute);
      const unmountApp = app.unmount;
      installedApps.add(app);
      app.unmount = function() {
        installedApps.delete(app);
        if (installedApps.size < 1) {
          pendingLocation = START_LOCATION_NORMALIZED;
          removeHistoryListener && removeHistoryListener();
          removeHistoryListener = null;
          currentRoute.value = START_LOCATION_NORMALIZED;
          started = false;
          ready = false;
        }
        unmountApp();
      };
      if (isBrowser && true) addDevtools(app, router, matcher);
    }
  };
  function runGuardQueue(guards) {
    return guards.reduce((promise, guard) => promise.then(() => runWithContext(guard)), Promise.resolve());
  }
  return router;
}
export { NavigationFailureType, RouterLink, RouterView, START_LOCATION_NORMALIZED as START_LOCATION, createMemoryHistory, createRouter, createRouterMatcher, createWebHashHistory, createWebHistory, isNavigationFailure, loadRouteLocation, matchedRouteKey, onBeforeRouteLeave, onBeforeRouteUpdate, parseQuery, routeLocationKey, routerKey, routerViewLocationKey, stringifyQuery, useLink, useRoute, useRouter, viewDepthKey };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZ1ZS1yb3V0ZXIuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohXG4qIHZ1ZS1yb3V0ZXIgdjUuMS4wXG4qIChjKSAyMDI2IEVkdWFyZG8gU2FuIE1hcnRpbiBNb3JvdGVcbiogQGxpY2Vuc2UgTUlUXG4qL1xuaW1wb3J0IHsgXyBhcyBtZXJnZU9wdGlvbnMsIGEgYXMgcm91dGVyS2V5LCBjIGFzIE5hdmlnYXRpb25GYWlsdXJlVHlwZSwgZCBhcyBhcHBseVRvUGFyYW1zLCBmIGFzIGFzc2lnbiwgaSBhcyByb3V0ZUxvY2F0aW9uS2V5LCBsIGFzIGNyZWF0ZVJvdXRlckVycm9yLCBtIGFzIGlzQXJyYXksIG4gYXMgdXNlUm91dGVyLCBvIGFzIHJvdXRlclZpZXdMb2NhdGlvbktleSwgciBhcyBtYXRjaGVkUm91dGVLZXksIHMgYXMgdmlld0RlcHRoS2V5LCB0IGFzIHVzZVJvdXRlLCB1IGFzIGlzTmF2aWdhdGlvbkZhaWx1cmUsIHYgYXMgbm9vcCwgeSBhcyBpc0Jyb3dzZXIgfSBmcm9tIFwiLi91c2VBcGktc18wMmxIamwuanNcIjtcbmltcG9ydCB7IEMgYXMgaXNTYW1lUm91dGVMb2NhdGlvbiwgRSBhcyBwYXJzZVVSTCwgRiBhcyB3YXJuJDEsIE0gYXMgZW5jb2RlSGFzaCwgTiBhcyBlbmNvZGVQYXJhbSwgTyBhcyBzdHJpbmdpZnlVUkwsIFMgYXMgU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCwgVCBhcyBpc1NhbWVSb3V0ZVJlY29yZCwgXyBhcyBzYXZlU2Nyb2xsUG9zaXRpb24sIGEgYXMgbG9hZFJvdXRlTG9jYXRpb24sIGIgYXMgbm9ybWFsaXplQmFzZSwgYyBhcyB1c2VDYWxsYmFja3MsIGQgYXMgc3RyaW5naWZ5UXVlcnksIGYgYXMgaXNSb3V0ZUxvY2F0aW9uLCBnIGFzIGdldFNjcm9sbEtleSwgaCBhcyBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uLCBpIGFzIGd1YXJkVG9Qcm9taXNlRm4sIGogYXMgZGVjb2RlLCBrIGFzIHN0cmlwQmFzZSwgbCBhcyBub3JtYWxpemVRdWVyeSwgbSBhcyBjb21wdXRlU2Nyb2xsUG9zaXRpb24sIG4gYXMgZXh0cmFjdENoYW5naW5nUmVjb3JkcywgbyBhcyBvbkJlZm9yZVJvdXRlTGVhdmUsIHAgYXMgaXNSb3V0ZU5hbWUsIHIgYXMgZXh0cmFjdENvbXBvbmVudHNHdWFyZHMsIHMgYXMgb25CZWZvcmVSb3V0ZVVwZGF0ZSwgdCBhcyBhZGREZXZ0b29scywgdSBhcyBwYXJzZVF1ZXJ5LCB2IGFzIHNjcm9sbFRvUG9zaXRpb24sIHcgYXMgaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcywgeSBhcyBjcmVhdGVIcmVmIH0gZnJvbSBcIi4vZGV2dG9vbHMtRENvV1FvVV8uanNcIjtcbmltcG9ydCB7IGNvbXB1dGVkLCBkZWZpbmVDb21wb25lbnQsIGdldEN1cnJlbnRJbnN0YW5jZSwgaCwgaW5qZWN0LCBuZXh0VGljaywgcHJvdmlkZSwgcmVhY3RpdmUsIHJlZiwgc2hhbGxvd1JlYWN0aXZlLCBzaGFsbG93UmVmLCB1bnJlZiwgd2F0Y2gsIHdhdGNoRWZmZWN0IH0gZnJvbSBcInZ1ZVwiO1xuLy8jcmVnaW9uIHNyYy9oaXN0b3J5L2h0bWw1LnRzXG5sZXQgY3JlYXRlQmFzZUxvY2F0aW9uID0gKCkgPT4gbG9jYXRpb24ucHJvdG9jb2wgKyBcIi8vXCIgKyBsb2NhdGlvbi5ob3N0O1xuLyoqXG4qIENyZWF0ZXMgYSBub3JtYWxpemVkIGhpc3RvcnkgbG9jYXRpb24gZnJvbSBhIHdpbmRvdy5sb2NhdGlvbiBvYmplY3RcbiogQHBhcmFtIGJhc2UgLSBUaGUgYmFzZSBwYXRoXG4qIEBwYXJhbSBsb2NhdGlvbiAtIFRoZSB3aW5kb3cubG9jYXRpb24gb2JqZWN0XG4qL1xuZnVuY3Rpb24gY3JlYXRlQ3VycmVudExvY2F0aW9uKGJhc2UsIGxvY2F0aW9uKSB7XG5cdGNvbnN0IHsgcGF0aG5hbWUsIHNlYXJjaCwgaGFzaCB9ID0gbG9jYXRpb247XG5cdGNvbnN0IGhhc2hQb3MgPSBiYXNlLmluZGV4T2YoXCIjXCIpO1xuXHRpZiAoaGFzaFBvcyA+IC0xKSB7XG5cdFx0bGV0IHNsaWNlUG9zID0gaGFzaC5pbmNsdWRlcyhiYXNlLnNsaWNlKGhhc2hQb3MpKSA/IGJhc2Uuc2xpY2UoaGFzaFBvcykubGVuZ3RoIDogMTtcblx0XHRsZXQgcGF0aEZyb21IYXNoID0gaGFzaC5zbGljZShzbGljZVBvcyk7XG5cdFx0aWYgKHBhdGhGcm9tSGFzaFswXSAhPT0gXCIvXCIpIHBhdGhGcm9tSGFzaCA9IFwiL1wiICsgcGF0aEZyb21IYXNoO1xuXHRcdHJldHVybiBzdHJpcEJhc2UocGF0aEZyb21IYXNoLCBcIlwiKTtcblx0fVxuXHRyZXR1cm4gc3RyaXBCYXNlKHBhdGhuYW1lLCBiYXNlKSArIHNlYXJjaCArIGhhc2g7XG59XG5mdW5jdGlvbiB1c2VIaXN0b3J5TGlzdGVuZXJzKGJhc2UsIGhpc3RvcnlTdGF0ZSwgY3VycmVudExvY2F0aW9uLCByZXBsYWNlKSB7XG5cdGxldCBsaXN0ZW5lcnMgPSBbXTtcblx0bGV0IHRlYXJkb3ducyA9IFtdO1xuXHRsZXQgcGF1c2VTdGF0ZSA9IG51bGw7XG5cdGNvbnN0IHBvcFN0YXRlSGFuZGxlciA9ICh7IHN0YXRlIH0pID0+IHtcblx0XHRjb25zdCB0byA9IGNyZWF0ZUN1cnJlbnRMb2NhdGlvbihiYXNlLCBsb2NhdGlvbik7XG5cdFx0Y29uc3QgZnJvbSA9IGN1cnJlbnRMb2NhdGlvbi52YWx1ZTtcblx0XHRjb25zdCBmcm9tU3RhdGUgPSBoaXN0b3J5U3RhdGUudmFsdWU7XG5cdFx0bGV0IGRlbHRhID0gMDtcblx0XHRpZiAoc3RhdGUpIHtcblx0XHRcdGN1cnJlbnRMb2NhdGlvbi52YWx1ZSA9IHRvO1xuXHRcdFx0aGlzdG9yeVN0YXRlLnZhbHVlID0gc3RhdGU7XG5cdFx0XHRpZiAocGF1c2VTdGF0ZSAmJiBwYXVzZVN0YXRlID09PSBmcm9tKSB7XG5cdFx0XHRcdHBhdXNlU3RhdGUgPSBudWxsO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRkZWx0YSA9IGZyb21TdGF0ZSA/IHN0YXRlLnBvc2l0aW9uIC0gZnJvbVN0YXRlLnBvc2l0aW9uIDogMDtcblx0XHR9IGVsc2UgcmVwbGFjZSh0byk7XG5cdFx0bGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRsaXN0ZW5lcihjdXJyZW50TG9jYXRpb24udmFsdWUsIGZyb20sIHtcblx0XHRcdFx0ZGVsdGEsXG5cdFx0XHRcdHR5cGU6IFwicG9wXCIsXG5cdFx0XHRcdGRpcmVjdGlvbjogZGVsdGEgPyBkZWx0YSA+IDAgPyBcImZvcndhcmRcIiA6IFwiYmFja1wiIDogXCJcIlxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH07XG5cdGZ1bmN0aW9uIHBhdXNlTGlzdGVuZXJzKCkge1xuXHRcdHBhdXNlU3RhdGUgPSBjdXJyZW50TG9jYXRpb24udmFsdWU7XG5cdH1cblx0ZnVuY3Rpb24gbGlzdGVuKGNhbGxiYWNrKSB7XG5cdFx0bGlzdGVuZXJzLnB1c2goY2FsbGJhY2spO1xuXHRcdGNvbnN0IHRlYXJkb3duID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgaW5kZXggPSBsaXN0ZW5lcnMuaW5kZXhPZihjYWxsYmFjayk7XG5cdFx0XHRpZiAoaW5kZXggPiAtMSkgbGlzdGVuZXJzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0fTtcblx0XHR0ZWFyZG93bnMucHVzaCh0ZWFyZG93bik7XG5cdFx0cmV0dXJuIHRlYXJkb3duO1xuXHR9XG5cdGZ1bmN0aW9uIGJlZm9yZVVubG9hZExpc3RlbmVyKCkge1xuXHRcdGlmIChkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09IFwiaGlkZGVuXCIpIHtcblx0XHRcdGNvbnN0IHsgaGlzdG9yeSB9ID0gd2luZG93O1xuXHRcdFx0aWYgKCFoaXN0b3J5LnN0YXRlKSByZXR1cm47XG5cdFx0XHRoaXN0b3J5LnJlcGxhY2VTdGF0ZShhc3NpZ24oe30sIGhpc3Rvcnkuc3RhdGUsIHsgc2Nyb2xsOiBjb21wdXRlU2Nyb2xsUG9zaXRpb24oKSB9KSwgXCJcIik7XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIGRlc3Ryb3koKSB7XG5cdFx0Zm9yIChjb25zdCB0ZWFyZG93biBvZiB0ZWFyZG93bnMpIHRlYXJkb3duKCk7XG5cdFx0dGVhcmRvd25zID0gW107XG5cdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb3BzdGF0ZVwiLCBwb3BTdGF0ZUhhbmRsZXIpO1xuXHRcdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgYmVmb3JlVW5sb2FkTGlzdGVuZXIpO1xuXHRcdGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGJlZm9yZVVubG9hZExpc3RlbmVyKTtcblx0fVxuXHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIHBvcFN0YXRlSGFuZGxlcik7XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgYmVmb3JlVW5sb2FkTGlzdGVuZXIpO1xuXHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwidmlzaWJpbGl0eWNoYW5nZVwiLCBiZWZvcmVVbmxvYWRMaXN0ZW5lcik7XG5cdHJldHVybiB7XG5cdFx0cGF1c2VMaXN0ZW5lcnMsXG5cdFx0bGlzdGVuLFxuXHRcdGRlc3Ryb3lcblx0fTtcbn1cbi8qKlxuKiBDcmVhdGVzIGEgc3RhdGUgb2JqZWN0XG4qL1xuZnVuY3Rpb24gYnVpbGRTdGF0ZShiYWNrLCBjdXJyZW50LCBmb3J3YXJkLCByZXBsYWNlZCA9IGZhbHNlLCBjb21wdXRlU2Nyb2xsID0gZmFsc2UpIHtcblx0cmV0dXJuIHtcblx0XHRiYWNrLFxuXHRcdGN1cnJlbnQsXG5cdFx0Zm9yd2FyZCxcblx0XHRyZXBsYWNlZCxcblx0XHRwb3NpdGlvbjogd2luZG93Lmhpc3RvcnkubGVuZ3RoLFxuXHRcdHNjcm9sbDogY29tcHV0ZVNjcm9sbCA/IGNvbXB1dGVTY3JvbGxQb3NpdGlvbigpIDogbnVsbFxuXHR9O1xufVxuZnVuY3Rpb24gdXNlSGlzdG9yeVN0YXRlTmF2aWdhdGlvbihiYXNlKSB7XG5cdGNvbnN0IHsgaGlzdG9yeSwgbG9jYXRpb24gfSA9IHdpbmRvdztcblx0Y29uc3QgY3VycmVudExvY2F0aW9uID0geyB2YWx1ZTogY3JlYXRlQ3VycmVudExvY2F0aW9uKGJhc2UsIGxvY2F0aW9uKSB9O1xuXHRjb25zdCBoaXN0b3J5U3RhdGUgPSB7IHZhbHVlOiBoaXN0b3J5LnN0YXRlIH07XG5cdGlmICghaGlzdG9yeVN0YXRlLnZhbHVlKSBjaGFuZ2VMb2NhdGlvbihjdXJyZW50TG9jYXRpb24udmFsdWUsIHtcblx0XHRiYWNrOiBudWxsLFxuXHRcdGN1cnJlbnQ6IGN1cnJlbnRMb2NhdGlvbi52YWx1ZSxcblx0XHRmb3J3YXJkOiBudWxsLFxuXHRcdHBvc2l0aW9uOiBoaXN0b3J5Lmxlbmd0aCAtIDEsXG5cdFx0cmVwbGFjZWQ6IHRydWUsXG5cdFx0c2Nyb2xsOiBudWxsXG5cdH0sIHRydWUpO1xuXHRmdW5jdGlvbiBjaGFuZ2VMb2NhdGlvbih0bywgc3RhdGUsIHJlcGxhY2UpIHtcblx0XHQvKipcblx0XHQqIGlmIGEgYmFzZSB0YWcgaXMgcHJvdmlkZWQsIGFuZCB3ZSBhcmUgb24gYSBub3JtYWwgZG9tYWluLCB3ZSBoYXZlIHRvXG5cdFx0KiByZXNwZWN0IHRoZSBwcm92aWRlZCBgYmFzZWAgYXR0cmlidXRlIGJlY2F1c2UgcHVzaFN0YXRlKCkgd2lsbCB1c2UgaXQgYW5kXG5cdFx0KiBwb3RlbnRpYWxseSBlcmFzZSBhbnl0aGluZyBiZWZvcmUgdGhlIGAjYCBsaWtlIGF0XG5cdFx0KiBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyL2lzc3Vlcy82ODUgd2hlcmUgYSBiYXNlIG9mXG5cdFx0KiBgL2ZvbGRlci8jYCBidXQgYSBiYXNlIG9mIGAvYCB3b3VsZCBlcmFzZSB0aGUgYC9mb2xkZXIvYCBzZWN0aW9uLiBJZlxuXHRcdCogdGhlcmUgaXMgbm8gaG9zdCwgdGhlIGA8YmFzZT5gIHRhZyBtYWtlcyBubyBzZW5zZSBhbmQgaWYgdGhlcmUgaXNuJ3QgYVxuXHRcdCogYmFzZSB0YWcgd2UgY2FuIGp1c3QgdXNlIGV2ZXJ5dGhpbmcgYWZ0ZXIgdGhlIGAjYC5cblx0XHQqL1xuXHRcdGNvbnN0IGhhc2hJbmRleCA9IGJhc2UuaW5kZXhPZihcIiNcIik7XG5cdFx0Y29uc3QgdXJsID0gaGFzaEluZGV4ID4gLTEgPyAobG9jYXRpb24uaG9zdCAmJiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYmFzZVwiKSA/IGJhc2UgOiBiYXNlLnNsaWNlKGhhc2hJbmRleCkpICsgdG8gOiBjcmVhdGVCYXNlTG9jYXRpb24oKSArIGJhc2UgKyB0bztcblx0XHR0cnkge1xuXHRcdFx0aGlzdG9yeVtyZXBsYWNlID8gXCJyZXBsYWNlU3RhdGVcIiA6IFwicHVzaFN0YXRlXCJdKHN0YXRlLCBcIlwiLCB1cmwpO1xuXHRcdFx0aGlzdG9yeVN0YXRlLnZhbHVlID0gc3RhdGU7XG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB3YXJuJDEoXCJFcnJvciB3aXRoIHB1c2gvcmVwbGFjZSBTdGF0ZVwiLCBlcnIpO1xuXHRcdFx0ZWxzZSBjb25zb2xlLmVycm9yKGVycik7XG5cdFx0XHRsb2NhdGlvbltyZXBsYWNlID8gXCJyZXBsYWNlXCIgOiBcImFzc2lnblwiXSh1cmwpO1xuXHRcdH1cblx0fVxuXHRmdW5jdGlvbiByZXBsYWNlKHRvLCBkYXRhKSB7XG5cdFx0Y2hhbmdlTG9jYXRpb24odG8sIGFzc2lnbih7fSwgaGlzdG9yeS5zdGF0ZSwgYnVpbGRTdGF0ZShoaXN0b3J5U3RhdGUudmFsdWUuYmFjaywgdG8sIGhpc3RvcnlTdGF0ZS52YWx1ZS5mb3J3YXJkLCB0cnVlKSwgZGF0YSwgeyBwb3NpdGlvbjogaGlzdG9yeVN0YXRlLnZhbHVlLnBvc2l0aW9uIH0pLCB0cnVlKTtcblx0XHRjdXJyZW50TG9jYXRpb24udmFsdWUgPSB0bztcblx0fVxuXHRmdW5jdGlvbiBwdXNoKHRvLCBkYXRhKSB7XG5cdFx0Y29uc3QgY3VycmVudFN0YXRlID0gYXNzaWduKHt9LCBoaXN0b3J5U3RhdGUudmFsdWUsIGhpc3Rvcnkuc3RhdGUsIHtcblx0XHRcdGZvcndhcmQ6IHRvLFxuXHRcdFx0c2Nyb2xsOiBjb21wdXRlU2Nyb2xsUG9zaXRpb24oKVxuXHRcdH0pO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIWhpc3Rvcnkuc3RhdGUpIHdhcm4kMShcImhpc3Rvcnkuc3RhdGUgc2VlbXMgdG8gaGF2ZSBiZWVuIG1hbnVhbGx5IHJlcGxhY2VkIHdpdGhvdXQgcHJlc2VydmluZyB0aGUgbmVjZXNzYXJ5IHZhbHVlcy4gTWFrZSBzdXJlIHRvIHByZXNlcnZlIGV4aXN0aW5nIGhpc3Rvcnkgc3RhdGUgaWYgeW91IGFyZSBtYW51YWxseSBjYWxsaW5nIGhpc3RvcnkucmVwbGFjZVN0YXRlOlxcblxcbmhpc3RvcnkucmVwbGFjZVN0YXRlKGhpc3Rvcnkuc3RhdGUsICcnLCB1cmwpXFxuXFxuWW91IGNhbiBmaW5kIG1vcmUgaW5mb3JtYXRpb24gYXQgaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL21pZ3JhdGlvbi8jVXNhZ2Utb2YtaGlzdG9yeS1zdGF0ZVwiKTtcblx0XHRjaGFuZ2VMb2NhdGlvbihjdXJyZW50U3RhdGUuY3VycmVudCwgY3VycmVudFN0YXRlLCB0cnVlKTtcblx0XHRjaGFuZ2VMb2NhdGlvbih0bywgYXNzaWduKHt9LCBidWlsZFN0YXRlKGN1cnJlbnRMb2NhdGlvbi52YWx1ZSwgdG8sIG51bGwpLCB7IHBvc2l0aW9uOiBjdXJyZW50U3RhdGUucG9zaXRpb24gKyAxIH0sIGRhdGEpLCBmYWxzZSk7XG5cdFx0Y3VycmVudExvY2F0aW9uLnZhbHVlID0gdG87XG5cdH1cblx0cmV0dXJuIHtcblx0XHRsb2NhdGlvbjogY3VycmVudExvY2F0aW9uLFxuXHRcdHN0YXRlOiBoaXN0b3J5U3RhdGUsXG5cdFx0cHVzaCxcblx0XHRyZXBsYWNlXG5cdH07XG59XG4vKipcbiogQ3JlYXRlcyBhbiBIVE1MNSBoaXN0b3J5LiBNb3N0IGNvbW1vbiBoaXN0b3J5IGZvciBzaW5nbGUgcGFnZSBhcHBsaWNhdGlvbnMuXG4qXG4qIEBwYXJhbSBiYXNlIC1cbiovXG5mdW5jdGlvbiBjcmVhdGVXZWJIaXN0b3J5KGJhc2UpIHtcblx0YmFzZSA9IG5vcm1hbGl6ZUJhc2UoYmFzZSk7XG5cdGNvbnN0IGhpc3RvcnlOYXZpZ2F0aW9uID0gdXNlSGlzdG9yeVN0YXRlTmF2aWdhdGlvbihiYXNlKTtcblx0Y29uc3QgaGlzdG9yeUxpc3RlbmVycyA9IHVzZUhpc3RvcnlMaXN0ZW5lcnMoYmFzZSwgaGlzdG9yeU5hdmlnYXRpb24uc3RhdGUsIGhpc3RvcnlOYXZpZ2F0aW9uLmxvY2F0aW9uLCBoaXN0b3J5TmF2aWdhdGlvbi5yZXBsYWNlKTtcblx0ZnVuY3Rpb24gZ28oZGVsdGEsIHRyaWdnZXJMaXN0ZW5lcnMgPSB0cnVlKSB7XG5cdFx0aWYgKCF0cmlnZ2VyTGlzdGVuZXJzKSBoaXN0b3J5TGlzdGVuZXJzLnBhdXNlTGlzdGVuZXJzKCk7XG5cdFx0aGlzdG9yeS5nbyhkZWx0YSk7XG5cdH1cblx0Y29uc3Qgcm91dGVySGlzdG9yeSA9IGFzc2lnbih7XG5cdFx0bG9jYXRpb246IFwiXCIsXG5cdFx0YmFzZSxcblx0XHRnbyxcblx0XHRjcmVhdGVIcmVmOiBjcmVhdGVIcmVmLmJpbmQobnVsbCwgYmFzZSlcblx0fSwgaGlzdG9yeU5hdmlnYXRpb24sIGhpc3RvcnlMaXN0ZW5lcnMpO1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkocm91dGVySGlzdG9yeSwgXCJsb2NhdGlvblwiLCB7XG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRnZXQ6ICgpID0+IGhpc3RvcnlOYXZpZ2F0aW9uLmxvY2F0aW9uLnZhbHVlXG5cdH0pO1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkocm91dGVySGlzdG9yeSwgXCJzdGF0ZVwiLCB7XG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRnZXQ6ICgpID0+IGhpc3RvcnlOYXZpZ2F0aW9uLnN0YXRlLnZhbHVlXG5cdH0pO1xuXHRyZXR1cm4gcm91dGVySGlzdG9yeTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9oaXN0b3J5L2hhc2gudHNcbi8qKlxuKiBDcmVhdGVzIGEgaGFzaCBoaXN0b3J5LiBVc2VmdWwgZm9yIHdlYiBhcHBsaWNhdGlvbnMgd2l0aCBubyBob3N0IChlLmcuIGBmaWxlOi8vYCkgb3Igd2hlbiBjb25maWd1cmluZyBhIHNlcnZlciB0b1xuKiBoYW5kbGUgYW55IFVSTCBpcyBub3QgcG9zc2libGUuXG4qXG4qIEBwYXJhbSBiYXNlIC0gb3B0aW9uYWwgYmFzZSB0byBwcm92aWRlLiBEZWZhdWx0cyB0byBgbG9jYXRpb24ucGF0aG5hbWUgKyBsb2NhdGlvbi5zZWFyY2hgIElmIHRoZXJlIGlzIGEgYDxiYXNlPmAgdGFnXG4qIGluIHRoZSBgaGVhZGAsIGl0cyB2YWx1ZSB3aWxsIGJlIGlnbm9yZWQgaW4gZmF2b3Igb2YgdGhpcyBwYXJhbWV0ZXIgKipidXQgbm90ZSBpdCBhZmZlY3RzIGFsbCB0aGUgaGlzdG9yeS5wdXNoU3RhdGUoKVxuKiBjYWxscyoqLCBtZWFuaW5nIHRoYXQgaWYgeW91IHVzZSBhIGA8YmFzZT5gIHRhZywgaXQncyBgaHJlZmAgdmFsdWUgKipoYXMgdG8gbWF0Y2ggdGhpcyBwYXJhbWV0ZXIqKiAoaWdub3JpbmcgYW55dGhpbmdcbiogYWZ0ZXIgdGhlIGAjYCkuXG4qXG4qIEBleGFtcGxlXG4qIGBgYGpzXG4qIC8vIGF0IGh0dHBzOi8vZXhhbXBsZS5jb20vZm9sZGVyXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCkgLy8gZ2l2ZXMgYSB1cmwgb2YgYGh0dHBzOi8vZXhhbXBsZS5jb20vZm9sZGVyI2BcbiogY3JlYXRlV2ViSGFzaEhpc3RvcnkoJy9mb2xkZXIvJykgLy8gZ2l2ZXMgYSB1cmwgb2YgYGh0dHBzOi8vZXhhbXBsZS5jb20vZm9sZGVyLyNgXG4qIC8vIGlmIHRoZSBgI2AgaXMgcHJvdmlkZWQgaW4gdGhlIGJhc2UsIGl0IHdvbid0IGJlIGFkZGVkIGJ5IGBjcmVhdGVXZWJIYXNoSGlzdG9yeWBcbiogY3JlYXRlV2ViSGFzaEhpc3RvcnkoJy9mb2xkZXIvIy9hcHAvJykgLy8gZ2l2ZXMgYSB1cmwgb2YgYGh0dHBzOi8vZXhhbXBsZS5jb20vZm9sZGVyLyMvYXBwL2BcbiogLy8geW91IHNob3VsZCBhdm9pZCBkb2luZyB0aGlzIGJlY2F1c2UgaXQgY2hhbmdlcyB0aGUgb3JpZ2luYWwgdXJsIGFuZCBicmVha3MgY29weWluZyB1cmxzXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCcvb3RoZXItZm9sZGVyLycpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL290aGVyLWZvbGRlci8jYFxuKlxuKiAvLyBhdCBmaWxlOi8vL3Vzci9ldGMvZm9sZGVyL2luZGV4Lmh0bWxcbiogLy8gZm9yIGxvY2F0aW9ucyB3aXRoIG5vIGBob3N0YCwgdGhlIGJhc2UgaXMgaWdub3JlZFxuKiBjcmVhdGVXZWJIYXNoSGlzdG9yeSgnL2lBbUlnbm9yZWQnKSAvLyBnaXZlcyBhIHVybCBvZiBgZmlsZTovLy91c3IvZXRjL2ZvbGRlci9pbmRleC5odG1sI2BcbiogYGBgXG4qL1xuZnVuY3Rpb24gY3JlYXRlV2ViSGFzaEhpc3RvcnkoYmFzZSkge1xuXHRiYXNlID0gbG9jYXRpb24uaG9zdCA/IGJhc2UgfHwgbG9jYXRpb24ucGF0aG5hbWUgKyBsb2NhdGlvbi5zZWFyY2ggOiBcIlwiO1xuXHRpZiAoIWJhc2UuaW5jbHVkZXMoXCIjXCIpKSBiYXNlICs9IFwiI1wiO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFiYXNlLmVuZHNXaXRoKFwiIy9cIikgJiYgIWJhc2UuZW5kc1dpdGgoXCIjXCIpKSB3YXJuJDEoYEEgaGFzaCBiYXNlIG11c3QgZW5kIHdpdGggYSBcIiNcIjpcXG5cIiR7YmFzZX1cIiBzaG91bGQgYmUgXCIke2Jhc2UucmVwbGFjZSgvIy4qJC8sIFwiI1wiKX1cIi5gKTtcblx0cmV0dXJuIGNyZWF0ZVdlYkhpc3RvcnkoYmFzZSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaGlzdG9yeS9tZW1vcnkudHNcbi8qKlxuKiBDcmVhdGVzIGFuIGluLW1lbW9yeSBiYXNlZCBoaXN0b3J5LiBUaGUgbWFpbiBwdXJwb3NlIG9mIHRoaXMgaGlzdG9yeSBpcyB0byBoYW5kbGUgU1NSLiBJdCBzdGFydHMgaW4gYSBzcGVjaWFsIGxvY2F0aW9uIHRoYXQgaXMgbm93aGVyZS5cbiogSXQncyB1cCB0byB0aGUgdXNlciB0byByZXBsYWNlIHRoYXQgbG9jYXRpb24gd2l0aCB0aGUgc3RhcnRlciBsb2NhdGlvbiBieSBlaXRoZXIgY2FsbGluZyBgcm91dGVyLnB1c2hgIG9yIGByb3V0ZXIucmVwbGFjZWAuXG4qXG4qIEBwYXJhbSBiYXNlIC0gQmFzZSBhcHBsaWVkIHRvIGFsbCB1cmxzLCBkZWZhdWx0cyB0byAnLydcbiogQHJldHVybnMgYSBoaXN0b3J5IG9iamVjdCB0aGF0IGNhbiBiZSBwYXNzZWQgdG8gdGhlIHJvdXRlciBjb25zdHJ1Y3RvclxuKi9cbmZ1bmN0aW9uIGNyZWF0ZU1lbW9yeUhpc3RvcnkoYmFzZSA9IFwiXCIpIHtcblx0bGV0IGxpc3RlbmVycyA9IFtdO1xuXHRsZXQgcXVldWUgPSBbW1wiXCIsIHt9XV07XG5cdGxldCBwb3NpdGlvbiA9IDA7XG5cdGJhc2UgPSBub3JtYWxpemVCYXNlKGJhc2UpO1xuXHRmdW5jdGlvbiBzZXRMb2NhdGlvbihsb2NhdGlvbiwgc3RhdGUgPSB7fSkge1xuXHRcdHBvc2l0aW9uKys7XG5cdFx0aWYgKHBvc2l0aW9uICE9PSBxdWV1ZS5sZW5ndGgpIHF1ZXVlLnNwbGljZShwb3NpdGlvbik7XG5cdFx0cXVldWUucHVzaChbbG9jYXRpb24sIHN0YXRlXSk7XG5cdH1cblx0ZnVuY3Rpb24gdHJpZ2dlckxpc3RlbmVycyh0bywgZnJvbSwgeyBkaXJlY3Rpb24sIGRlbHRhIH0pIHtcblx0XHRjb25zdCBpbmZvID0ge1xuXHRcdFx0ZGlyZWN0aW9uLFxuXHRcdFx0ZGVsdGEsXG5cdFx0XHR0eXBlOiBcInBvcFwiXG5cdFx0fTtcblx0XHRmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIGxpc3RlbmVycykgY2FsbGJhY2sodG8sIGZyb20sIGluZm8pO1xuXHR9XG5cdGNvbnN0IHJvdXRlckhpc3RvcnkgPSB7XG5cdFx0bG9jYXRpb246IFwiXCIsXG5cdFx0c3RhdGU6IHt9LFxuXHRcdGJhc2UsXG5cdFx0Y3JlYXRlSHJlZjogY3JlYXRlSHJlZi5iaW5kKG51bGwsIGJhc2UpLFxuXHRcdHJlcGxhY2UodG8sIHN0YXRlKSB7XG5cdFx0XHRxdWV1ZS5zcGxpY2UocG9zaXRpb24tLSwgMSk7XG5cdFx0XHRzZXRMb2NhdGlvbih0bywgc3RhdGUpO1xuXHRcdH0sXG5cdFx0cHVzaCh0bywgc3RhdGUpIHtcblx0XHRcdHNldExvY2F0aW9uKHRvLCBzdGF0ZSk7XG5cdFx0fSxcblx0XHRsaXN0ZW4oY2FsbGJhY2spIHtcblx0XHRcdGxpc3RlbmVycy5wdXNoKGNhbGxiYWNrKTtcblx0XHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGluZGV4ID0gbGlzdGVuZXJzLmluZGV4T2YoY2FsbGJhY2spO1xuXHRcdFx0XHRpZiAoaW5kZXggPiAtMSkgbGlzdGVuZXJzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHR9O1xuXHRcdH0sXG5cdFx0ZGVzdHJveSgpIHtcblx0XHRcdGxpc3RlbmVycyA9IFtdO1xuXHRcdFx0cXVldWUgPSBbW1wiXCIsIHt9XV07XG5cdFx0XHRwb3NpdGlvbiA9IDA7XG5cdFx0fSxcblx0XHRnbyhkZWx0YSwgc2hvdWxkVHJpZ2dlciA9IHRydWUpIHtcblx0XHRcdGNvbnN0IGZyb20gPSB0aGlzLmxvY2F0aW9uO1xuXHRcdFx0Y29uc3QgZGlyZWN0aW9uID0gZGVsdGEgPCAwID8gXCJiYWNrXCIgOiBcImZvcndhcmRcIjtcblx0XHRcdHBvc2l0aW9uID0gTWF0aC5tYXgoMCwgTWF0aC5taW4ocG9zaXRpb24gKyBkZWx0YSwgcXVldWUubGVuZ3RoIC0gMSkpO1xuXHRcdFx0aWYgKHNob3VsZFRyaWdnZXIpIHRyaWdnZXJMaXN0ZW5lcnModGhpcy5sb2NhdGlvbiwgZnJvbSwge1xuXHRcdFx0XHRkaXJlY3Rpb24sXG5cdFx0XHRcdGRlbHRhXG5cdFx0XHR9KTtcblx0XHR9XG5cdH07XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyb3V0ZXJIaXN0b3J5LCBcImxvY2F0aW9uXCIsIHtcblx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdGdldDogKCkgPT4gcXVldWVbcG9zaXRpb25dWzBdXG5cdH0pO1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkocm91dGVySGlzdG9yeSwgXCJzdGF0ZVwiLCB7XG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRnZXQ6ICgpID0+IHF1ZXVlW3Bvc2l0aW9uXVsxXVxuXHR9KTtcblx0cmV0dXJuIHJvdXRlckhpc3Rvcnk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWF0Y2hlci9wYXRoVG9rZW5pemVyLnRzXG5jb25zdCBST09UX1RPS0VOID0ge1xuXHR0eXBlOiAwLFxuXHR2YWx1ZTogXCJcIlxufTtcbmNvbnN0IFZBTElEX1BBUkFNX1JFID0gL1thLXpBLVowLTlfXS87XG5mdW5jdGlvbiB0b2tlbml6ZVBhdGgocGF0aCkge1xuXHRpZiAoIXBhdGgpIHJldHVybiBbW11dO1xuXHRpZiAocGF0aCA9PT0gXCIvXCIpIHJldHVybiBbW1JPT1RfVE9LRU5dXTtcblx0aWYgKCFwYXRoLnN0YXJ0c1dpdGgoXCIvXCIpKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gYFJvdXRlIHBhdGhzIHNob3VsZCBzdGFydCB3aXRoIGEgXCIvXCI6IFwiJHtwYXRofVwiIHNob3VsZCBiZSBcIi8ke3BhdGh9XCIuYCA6IGBJbnZhbGlkIHBhdGggXCIke3BhdGh9XCJgKTtcblx0ZnVuY3Rpb24gY3Jhc2gobWVzc2FnZSkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgRVJSICgke3N0YXRlfSkvXCIke2J1ZmZlcn1cIjogJHttZXNzYWdlfWApO1xuXHR9XG5cdGxldCBzdGF0ZSA9IDA7XG5cdGxldCBwcmV2aW91c1N0YXRlID0gc3RhdGU7XG5cdGNvbnN0IHRva2VucyA9IFtdO1xuXHRsZXQgc2VnbWVudDtcblx0ZnVuY3Rpb24gZmluYWxpemVTZWdtZW50KCkge1xuXHRcdGlmIChzZWdtZW50KSB0b2tlbnMucHVzaChzZWdtZW50KTtcblx0XHRzZWdtZW50ID0gW107XG5cdH1cblx0bGV0IGkgPSAwO1xuXHRsZXQgY2hhcjtcblx0bGV0IGJ1ZmZlciA9IFwiXCI7XG5cdGxldCBjdXN0b21SZSA9IFwiXCI7XG5cdGZ1bmN0aW9uIGNvbnN1bWVCdWZmZXIoKSB7XG5cdFx0aWYgKCFidWZmZXIpIHJldHVybjtcblx0XHRpZiAoc3RhdGUgPT09IDApIHNlZ21lbnQucHVzaCh7XG5cdFx0XHR0eXBlOiAwLFxuXHRcdFx0dmFsdWU6IGJ1ZmZlclxuXHRcdH0pO1xuXHRcdGVsc2UgaWYgKHN0YXRlID09PSAxIHx8IHN0YXRlID09PSAyIHx8IHN0YXRlID09PSAzKSB7XG5cdFx0XHRpZiAoc2VnbWVudC5sZW5ndGggPiAxICYmIChjaGFyID09PSBcIipcIiB8fCBjaGFyID09PSBcIitcIikpIGNyYXNoKGBBIHJlcGVhdGFibGUgcGFyYW0gKCR7YnVmZmVyfSkgbXVzdCBiZSBhbG9uZSBpbiBpdHMgc2VnbWVudC4gZWc6ICcvOmlkcysuYCk7XG5cdFx0XHRzZWdtZW50LnB1c2goe1xuXHRcdFx0XHR0eXBlOiAxLFxuXHRcdFx0XHR2YWx1ZTogYnVmZmVyLFxuXHRcdFx0XHRyZWdleHA6IGN1c3RvbVJlLFxuXHRcdFx0XHRyZXBlYXRhYmxlOiBjaGFyID09PSBcIipcIiB8fCBjaGFyID09PSBcIitcIixcblx0XHRcdFx0b3B0aW9uYWw6IGNoYXIgPT09IFwiKlwiIHx8IGNoYXIgPT09IFwiP1wiXG5cdFx0XHR9KTtcblx0XHR9IGVsc2UgY3Jhc2goXCJJbnZhbGlkIHN0YXRlIHRvIGNvbnN1bWUgYnVmZmVyXCIpO1xuXHRcdGJ1ZmZlciA9IFwiXCI7XG5cdH1cblx0ZnVuY3Rpb24gYWRkQ2hhclRvQnVmZmVyKCkge1xuXHRcdGJ1ZmZlciArPSBjaGFyO1xuXHR9XG5cdHdoaWxlIChpIDwgcGF0aC5sZW5ndGgpIHtcblx0XHRjaGFyID0gcGF0aFtpKytdO1xuXHRcdHN3aXRjaCAoc3RhdGUpIHtcblx0XHRcdGNhc2UgMDpcblx0XHRcdFx0aWYgKGNoYXIgPT09IFwiXFxcXFwiKSB7XG5cdFx0XHRcdFx0cHJldmlvdXNTdGF0ZSA9IHN0YXRlO1xuXHRcdFx0XHRcdHN0YXRlID0gNDtcblx0XHRcdFx0fSBlbHNlIGlmIChjaGFyID09PSBcIi9cIikge1xuXHRcdFx0XHRcdGlmIChidWZmZXIpIGNvbnN1bWVCdWZmZXIoKTtcblx0XHRcdFx0XHRmaW5hbGl6ZVNlZ21lbnQoKTtcblx0XHRcdFx0fSBlbHNlIGlmIChjaGFyID09PSBcIjpcIikge1xuXHRcdFx0XHRcdGNvbnN1bWVCdWZmZXIoKTtcblx0XHRcdFx0XHRzdGF0ZSA9IDE7XG5cdFx0XHRcdH0gZWxzZSBhZGRDaGFyVG9CdWZmZXIoKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIDQ6XG5cdFx0XHRcdGFkZENoYXJUb0J1ZmZlcigpO1xuXHRcdFx0XHRzdGF0ZSA9IHByZXZpb3VzU3RhdGU7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSAxOlxuXHRcdFx0XHRpZiAoY2hhciA9PT0gXCIoXCIpIHN0YXRlID0gMjtcblx0XHRcdFx0ZWxzZSBpZiAoVkFMSURfUEFSQU1fUkUudGVzdChjaGFyKSkgYWRkQ2hhclRvQnVmZmVyKCk7XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGNvbnN1bWVCdWZmZXIoKTtcblx0XHRcdFx0XHRzdGF0ZSA9IDA7XG5cdFx0XHRcdFx0aWYgKGNoYXIgIT09IFwiKlwiICYmIGNoYXIgIT09IFwiP1wiICYmIGNoYXIgIT09IFwiK1wiKSBpLS07XG5cdFx0XHRcdH1cblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIDI6XG5cdFx0XHRcdGlmIChjaGFyID09PSBcIilcIikgaWYgKGN1c3RvbVJlW2N1c3RvbVJlLmxlbmd0aCAtIDFdID09IFwiXFxcXFwiKSBjdXN0b21SZSA9IGN1c3RvbVJlLnNsaWNlKDAsIC0xKSArIGNoYXI7XG5cdFx0XHRcdGVsc2Ugc3RhdGUgPSAzO1xuXHRcdFx0XHRlbHNlIGN1c3RvbVJlICs9IGNoYXI7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSAzOlxuXHRcdFx0XHRjb25zdW1lQnVmZmVyKCk7XG5cdFx0XHRcdHN0YXRlID0gMDtcblx0XHRcdFx0aWYgKGNoYXIgIT09IFwiKlwiICYmIGNoYXIgIT09IFwiP1wiICYmIGNoYXIgIT09IFwiK1wiKSBpLS07XG5cdFx0XHRcdGN1c3RvbVJlID0gXCJcIjtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRjcmFzaChcIlVua25vd24gc3RhdGVcIik7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdH1cblx0fVxuXHRpZiAoc3RhdGUgPT09IDIpIGNyYXNoKGBVbmZpbmlzaGVkIGN1c3RvbSBSZWdFeHAgZm9yIHBhcmFtIFwiJHtidWZmZXJ9XCJgKTtcblx0Y29uc3VtZUJ1ZmZlcigpO1xuXHRmaW5hbGl6ZVNlZ21lbnQoKTtcblx0cmV0dXJuIHRva2Vucztcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXRjaGVyL3BhdGhQYXJzZXJSYW5rZXIudHNcbmNvbnN0IEJBU0VfUEFSQU1fUEFUVEVSTiA9IFwiW14vXSs/XCI7XG5jb25zdCBCQVNFX1BBVEhfUEFSU0VSX09QVElPTlMgPSB7XG5cdHNlbnNpdGl2ZTogZmFsc2UsXG5cdHN0cmljdDogZmFsc2UsXG5cdHN0YXJ0OiB0cnVlLFxuXHRlbmQ6IHRydWVcbn07XG5jb25zdCBSRUdFWF9DSEFSU19SRSA9IC9bLisqP14ke30oKVtcXF0vXFxcXF0vZztcbi8qKlxuKiBDcmVhdGVzIGEgcGF0aCBwYXJzZXIgZnJvbSBhbiBhcnJheSBvZiBTZWdtZW50cyAoYSBzZWdtZW50IGlzIGFuIGFycmF5IG9mIFRva2VucylcbipcbiogQHBhcmFtIHNlZ21lbnRzIC0gYXJyYXkgb2Ygc2VnbWVudHMgcmV0dXJuZWQgYnkgdG9rZW5pemVQYXRoXG4qIEBwYXJhbSBleHRyYU9wdGlvbnMgLSBvcHRpb25hbCBvcHRpb25zIGZvciB0aGUgcmVnZXhwXG4qIEByZXR1cm5zIGEgUGF0aFBhcnNlclxuKi9cbmZ1bmN0aW9uIHRva2Vuc1RvUGFyc2VyKHNlZ21lbnRzLCBleHRyYU9wdGlvbnMpIHtcblx0Y29uc3Qgb3B0aW9ucyA9IGFzc2lnbih7fSwgQkFTRV9QQVRIX1BBUlNFUl9PUFRJT05TLCBleHRyYU9wdGlvbnMpO1xuXHRjb25zdCBzY29yZSA9IFtdO1xuXHRsZXQgcGF0dGVybiA9IG9wdGlvbnMuc3RhcnQgPyBcIl5cIiA6IFwiXCI7XG5cdGNvbnN0IGtleXMgPSBbXTtcblx0Zm9yIChjb25zdCBzZWdtZW50IG9mIHNlZ21lbnRzKSB7XG5cdFx0Y29uc3Qgc2VnbWVudFNjb3JlcyA9IHNlZ21lbnQubGVuZ3RoID8gW10gOiBbOTBdO1xuXHRcdGlmIChvcHRpb25zLnN0cmljdCAmJiAhc2VnbWVudC5sZW5ndGgpIHBhdHRlcm4gKz0gXCIvXCI7XG5cdFx0Zm9yIChsZXQgdG9rZW5JbmRleCA9IDA7IHRva2VuSW5kZXggPCBzZWdtZW50Lmxlbmd0aDsgdG9rZW5JbmRleCsrKSB7XG5cdFx0XHRjb25zdCB0b2tlbiA9IHNlZ21lbnRbdG9rZW5JbmRleF07XG5cdFx0XHRsZXQgc3ViU2VnbWVudFNjb3JlID0gNDAgKyAob3B0aW9ucy5zZW5zaXRpdmUgPyAuMjUgOiAwKTtcblx0XHRcdGlmICh0b2tlbi50eXBlID09PSAwKSB7XG5cdFx0XHRcdGlmICghdG9rZW5JbmRleCkgcGF0dGVybiArPSBcIi9cIjtcblx0XHRcdFx0cGF0dGVybiArPSB0b2tlbi52YWx1ZS5yZXBsYWNlKFJFR0VYX0NIQVJTX1JFLCBcIlxcXFwkJlwiKTtcblx0XHRcdFx0c3ViU2VnbWVudFNjb3JlICs9IDQwO1xuXHRcdFx0fSBlbHNlIGlmICh0b2tlbi50eXBlID09PSAxKSB7XG5cdFx0XHRcdGNvbnN0IHsgdmFsdWUsIHJlcGVhdGFibGUsIG9wdGlvbmFsLCByZWdleHAgfSA9IHRva2VuO1xuXHRcdFx0XHRrZXlzLnB1c2goe1xuXHRcdFx0XHRcdG5hbWU6IHZhbHVlLFxuXHRcdFx0XHRcdHJlcGVhdGFibGUsXG5cdFx0XHRcdFx0b3B0aW9uYWxcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGNvbnN0IHJlID0gcmVnZXhwID8gcmVnZXhwIDogQkFTRV9QQVJBTV9QQVRURVJOO1xuXHRcdFx0XHRpZiAocmUgIT09IEJBU0VfUEFSQU1fUEFUVEVSTikge1xuXHRcdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSAxMDtcblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0bmV3IFJlZ0V4cChgKCR7cmV9KWApO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGN1c3RvbSBSZWdFeHAgZm9yIHBhcmFtIFwiJHt2YWx1ZX1cIiAoJHtyZX0pOiBgICsgZXJyLm1lc3NhZ2UpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRsZXQgc3ViUGF0dGVybiA9IHJlcGVhdGFibGUgPyBgKCg/OiR7cmV9KSg/Oi8oPzoke3JlfSkpKilgIDogYCgke3JlfSlgO1xuXHRcdFx0XHRpZiAoIXRva2VuSW5kZXgpIHN1YlBhdHRlcm4gPSBvcHRpb25hbCAmJiBzZWdtZW50Lmxlbmd0aCA8IDIgPyBgKD86LyR7c3ViUGF0dGVybn0pYCA6IFwiL1wiICsgc3ViUGF0dGVybjtcblx0XHRcdFx0aWYgKG9wdGlvbmFsKSBzdWJQYXR0ZXJuICs9IFwiP1wiO1xuXHRcdFx0XHRwYXR0ZXJuICs9IHN1YlBhdHRlcm47XG5cdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSAyMDtcblx0XHRcdFx0aWYgKG9wdGlvbmFsKSBzdWJTZWdtZW50U2NvcmUgKz0gLTg7XG5cdFx0XHRcdGlmIChyZXBlYXRhYmxlKSBzdWJTZWdtZW50U2NvcmUgKz0gLTIwO1xuXHRcdFx0XHRpZiAocmUgPT09IFwiLipcIikgc3ViU2VnbWVudFNjb3JlICs9IC01MDtcblx0XHRcdH1cblx0XHRcdHNlZ21lbnRTY29yZXMucHVzaChzdWJTZWdtZW50U2NvcmUpO1xuXHRcdH1cblx0XHRzY29yZS5wdXNoKHNlZ21lbnRTY29yZXMpO1xuXHR9XG5cdGlmIChvcHRpb25zLnN0cmljdCAmJiBvcHRpb25zLmVuZCkge1xuXHRcdGNvbnN0IGkgPSBzY29yZS5sZW5ndGggLSAxO1xuXHRcdHNjb3JlW2ldW3Njb3JlW2ldLmxlbmd0aCAtIDFdICs9IC43MDAwMDAwMDAwMDAwMDAxO1xuXHR9XG5cdGlmICghb3B0aW9ucy5zdHJpY3QpIHBhdHRlcm4gKz0gXCIvP1wiO1xuXHRpZiAob3B0aW9ucy5lbmQpIHBhdHRlcm4gKz0gXCIkXCI7XG5cdGVsc2UgaWYgKG9wdGlvbnMuc3RyaWN0ICYmICFwYXR0ZXJuLmVuZHNXaXRoKFwiL1wiKSkgcGF0dGVybiArPSBcIig/Oi98JClcIjtcblx0Y29uc3QgcmUgPSBuZXcgUmVnRXhwKHBhdHRlcm4sIG9wdGlvbnMuc2Vuc2l0aXZlID8gXCJcIiA6IFwiaVwiKTtcblx0ZnVuY3Rpb24gcGFyc2UocGF0aCkge1xuXHRcdGNvbnN0IG1hdGNoID0gcGF0aC5tYXRjaChyZSk7XG5cdFx0Y29uc3QgcGFyYW1zID0ge307XG5cdFx0aWYgKCFtYXRjaCkgcmV0dXJuIG51bGw7XG5cdFx0Zm9yIChsZXQgaSA9IDE7IGkgPCBtYXRjaC5sZW5ndGg7IGkrKykge1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBtYXRjaFtpXSB8fCBcIlwiO1xuXHRcdFx0Y29uc3Qga2V5ID0ga2V5c1tpIC0gMV07XG5cdFx0XHRwYXJhbXNba2V5Lm5hbWVdID0gdmFsdWUgJiYga2V5LnJlcGVhdGFibGUgPyB2YWx1ZS5zcGxpdChcIi9cIikgOiB2YWx1ZTtcblx0XHR9XG5cdFx0cmV0dXJuIHBhcmFtcztcblx0fVxuXHRmdW5jdGlvbiBzdHJpbmdpZnkocGFyYW1zKSB7XG5cdFx0bGV0IHBhdGggPSBcIlwiO1xuXHRcdGxldCBhdm9pZER1cGxpY2F0ZWRTbGFzaCA9IGZhbHNlO1xuXHRcdGZvciAoY29uc3Qgc2VnbWVudCBvZiBzZWdtZW50cykge1xuXHRcdFx0aWYgKCFhdm9pZER1cGxpY2F0ZWRTbGFzaCB8fCAhcGF0aC5lbmRzV2l0aChcIi9cIikpIHBhdGggKz0gXCIvXCI7XG5cdFx0XHRhdm9pZER1cGxpY2F0ZWRTbGFzaCA9IGZhbHNlO1xuXHRcdFx0Zm9yIChjb25zdCB0b2tlbiBvZiBzZWdtZW50KSBpZiAodG9rZW4udHlwZSA9PT0gMCkgcGF0aCArPSB0b2tlbi52YWx1ZTtcblx0XHRcdGVsc2UgaWYgKHRva2VuLnR5cGUgPT09IDEpIHtcblx0XHRcdFx0Y29uc3QgeyB2YWx1ZSwgcmVwZWF0YWJsZSwgb3B0aW9uYWwgfSA9IHRva2VuO1xuXHRcdFx0XHRjb25zdCBwYXJhbSA9IHZhbHVlIGluIHBhcmFtcyA/IHBhcmFtc1t2YWx1ZV0gOiBcIlwiO1xuXHRcdFx0XHRpZiAoaXNBcnJheShwYXJhbSkgJiYgIXJlcGVhdGFibGUpIHRocm93IG5ldyBFcnJvcihgUHJvdmlkZWQgcGFyYW0gXCIke3ZhbHVlfVwiIGlzIGFuIGFycmF5IGJ1dCBpdCBpcyBub3QgcmVwZWF0YWJsZSAoKiBvciArIG1vZGlmaWVycylgKTtcblx0XHRcdFx0Y29uc3QgdGV4dCA9IGlzQXJyYXkocGFyYW0pID8gcGFyYW0uam9pbihcIi9cIikgOiBwYXJhbTtcblx0XHRcdFx0aWYgKCF0ZXh0KSBpZiAob3B0aW9uYWwpIHtcblx0XHRcdFx0XHRpZiAoc2VnbWVudC5sZW5ndGggPCAyKSBpZiAocGF0aC5lbmRzV2l0aChcIi9cIikpIHBhdGggPSBwYXRoLnNsaWNlKDAsIC0xKTtcblx0XHRcdFx0XHRlbHNlIGF2b2lkRHVwbGljYXRlZFNsYXNoID0gdHJ1ZTtcblx0XHRcdFx0fSBlbHNlIHRocm93IG5ldyBFcnJvcihgTWlzc2luZyByZXF1aXJlZCBwYXJhbSBcIiR7dmFsdWV9XCJgKTtcblx0XHRcdFx0cGF0aCArPSB0ZXh0O1xuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gcGF0aCB8fCBcIi9cIjtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdHJlLFxuXHRcdHNjb3JlLFxuXHRcdGtleXMsXG5cdFx0cGFyc2UsXG5cdFx0c3RyaW5naWZ5XG5cdH07XG59XG4vKipcbiogQ29tcGFyZXMgYW4gYXJyYXkgb2YgbnVtYmVycyBhcyB1c2VkIGluIFBhdGhQYXJzZXIuc2NvcmUgYW5kIHJldHVybnMgYVxuKiBudW1iZXIuIFRoaXMgZnVuY3Rpb24gY2FuIGJlIHVzZWQgdG8gYHNvcnRgIGFuIGFycmF5XG4qXG4qIEBwYXJhbSBhIC0gZmlyc3QgYXJyYXkgb2YgbnVtYmVyc1xuKiBAcGFyYW0gYiAtIHNlY29uZCBhcnJheSBvZiBudW1iZXJzXG4qIEByZXR1cm5zIDAgaWYgYm90aCBhcmUgZXF1YWwsIDwgMCBpZiBhIHNob3VsZCBiZSBzb3J0ZWQgZmlyc3QsID4gMCBpZiBiXG4qIHNob3VsZCBiZSBzb3J0ZWQgZmlyc3RcbiovXG5mdW5jdGlvbiBjb21wYXJlU2NvcmVBcnJheShhLCBiKSB7XG5cdGxldCBpID0gMDtcblx0d2hpbGUgKGkgPCBhLmxlbmd0aCAmJiBpIDwgYi5sZW5ndGgpIHtcblx0XHRjb25zdCBkaWZmID0gYltpXSAtIGFbaV07XG5cdFx0aWYgKGRpZmYpIHJldHVybiBkaWZmO1xuXHRcdGkrKztcblx0fVxuXHRpZiAoYS5sZW5ndGggPCBiLmxlbmd0aCkgcmV0dXJuIGEubGVuZ3RoID09PSAxICYmIGFbMF0gPT09IDgwID8gLTEgOiAxO1xuXHRlbHNlIGlmIChhLmxlbmd0aCA+IGIubGVuZ3RoKSByZXR1cm4gYi5sZW5ndGggPT09IDEgJiYgYlswXSA9PT0gODAgPyAxIDogLTE7XG5cdHJldHVybiAwO1xufVxuLyoqXG4qIENvbXBhcmUgZnVuY3Rpb24gdGhhdCBjYW4gYmUgdXNlZCB3aXRoIGBzb3J0YCB0byBzb3J0IGFuIGFycmF5IG9mIFBhdGhQYXJzZXJcbipcbiogQHBhcmFtIGEgLSBmaXJzdCBQYXRoUGFyc2VyXG4qIEBwYXJhbSBiIC0gc2Vjb25kIFBhdGhQYXJzZXJcbiogQHJldHVybnMgMCBpZiBib3RoIGFyZSBlcXVhbCwgPCAwIGlmIGEgc2hvdWxkIGJlIHNvcnRlZCBmaXJzdCwgPiAwIGlmIGJcbiovXG5mdW5jdGlvbiBjb21wYXJlUGF0aFBhcnNlclNjb3JlKGEsIGIpIHtcblx0bGV0IGkgPSAwO1xuXHRjb25zdCBhU2NvcmUgPSBhLnNjb3JlO1xuXHRjb25zdCBiU2NvcmUgPSBiLnNjb3JlO1xuXHR3aGlsZSAoaSA8IGFTY29yZS5sZW5ndGggJiYgaSA8IGJTY29yZS5sZW5ndGgpIHtcblx0XHRjb25zdCBjb21wID0gY29tcGFyZVNjb3JlQXJyYXkoYVNjb3JlW2ldLCBiU2NvcmVbaV0pO1xuXHRcdGlmIChjb21wKSByZXR1cm4gY29tcDtcblx0XHRpKys7XG5cdH1cblx0aWYgKE1hdGguYWJzKGJTY29yZS5sZW5ndGggLSBhU2NvcmUubGVuZ3RoKSA9PT0gMSkge1xuXHRcdGlmIChpc0xhc3RTY29yZU5lZ2F0aXZlKGFTY29yZSkpIHJldHVybiAxO1xuXHRcdGlmIChpc0xhc3RTY29yZU5lZ2F0aXZlKGJTY29yZSkpIHJldHVybiAtMTtcblx0fVxuXHRyZXR1cm4gYlNjb3JlLmxlbmd0aCAtIGFTY29yZS5sZW5ndGg7XG59XG4vKipcbiogVGhpcyBhbGxvd3MgZGV0ZWN0aW5nIHNwbGF0cyBhdCB0aGUgZW5kIG9mIGEgcGF0aDogL2hvbWUvOmlkKC4qKSpcbipcbiogQHBhcmFtIHNjb3JlIC0gc2NvcmUgdG8gY2hlY2tcbiogQHJldHVybnMgdHJ1ZSBpZiB0aGUgbGFzdCBlbnRyeSBpcyBuZWdhdGl2ZVxuKi9cbmZ1bmN0aW9uIGlzTGFzdFNjb3JlTmVnYXRpdmUoc2NvcmUpIHtcblx0Y29uc3QgbGFzdCA9IHNjb3JlW3Njb3JlLmxlbmd0aCAtIDFdO1xuXHRyZXR1cm4gc2NvcmUubGVuZ3RoID4gMCAmJiBsYXN0W2xhc3QubGVuZ3RoIC0gMV0gPCAwO1xufVxuY29uc3QgUEFUSF9QQVJTRVJfT1BUSU9OU19ERUZBVUxUUyA9IHtcblx0c3RyaWN0OiBmYWxzZSxcblx0ZW5kOiB0cnVlLFxuXHRzZW5zaXRpdmU6IGZhbHNlXG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21hdGNoZXIvcGF0aE1hdGNoZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlUmVjb3JkTWF0Y2hlcihyZWNvcmQsIHBhcmVudCwgb3B0aW9ucykge1xuXHRjb25zdCBwYXJzZXIgPSB0b2tlbnNUb1BhcnNlcih0b2tlbml6ZVBhdGgocmVjb3JkLnBhdGgpLCBvcHRpb25zKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGNvbnN0IGV4aXN0aW5nS2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0Zm9yIChjb25zdCBrZXkgb2YgcGFyc2VyLmtleXMpIHtcblx0XHRcdGlmIChleGlzdGluZ0tleXMuaGFzKGtleS5uYW1lKSkgd2FybiQxKGBGb3VuZCBkdXBsaWNhdGVkIHBhcmFtcyB3aXRoIG5hbWUgXCIke2tleS5uYW1lfVwiIGZvciBwYXRoIFwiJHtyZWNvcmQucGF0aH1cIi4gT25seSB0aGUgbGFzdCBvbmUgd2lsbCBiZSBhdmFpbGFibGUgb24gXCIkcm91dGUucGFyYW1zXCIuYCk7XG5cdFx0XHRleGlzdGluZ0tleXMuYWRkKGtleS5uYW1lKTtcblx0XHR9XG5cdH1cblx0Y29uc3QgbWF0Y2hlciA9IGFzc2lnbihwYXJzZXIsIHtcblx0XHRyZWNvcmQsXG5cdFx0cGFyZW50LFxuXHRcdGNoaWxkcmVuOiBbXSxcblx0XHRhbGlhczogW11cblx0fSk7XG5cdGlmIChwYXJlbnQpIHtcblx0XHRpZiAoIW1hdGNoZXIucmVjb3JkLmFsaWFzT2YgPT09ICFwYXJlbnQucmVjb3JkLmFsaWFzT2YpIHBhcmVudC5jaGlsZHJlbi5wdXNoKG1hdGNoZXIpO1xuXHR9XG5cdHJldHVybiBtYXRjaGVyO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21hdGNoZXIvaW5kZXgudHNcbi8qKlxuKiBDcmVhdGVzIGEgUm91dGVyIE1hdGNoZXIuXG4qXG4qIEBpbnRlcm5hbFxuKiBAcGFyYW0gcm91dGVzIC0gYXJyYXkgb2YgaW5pdGlhbCByb3V0ZXNcbiogQHBhcmFtIGdsb2JhbE9wdGlvbnMgLSBnbG9iYWwgcm91dGUgb3B0aW9uc1xuKi9cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlck1hdGNoZXIocm91dGVzLCBnbG9iYWxPcHRpb25zKSB7XG5cdGNvbnN0IG1hdGNoZXJzID0gW107XG5cdGNvbnN0IG1hdGNoZXJNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRnbG9iYWxPcHRpb25zID0gbWVyZ2VPcHRpb25zKFBBVEhfUEFSU0VSX09QVElPTlNfREVGQVVMVFMsIGdsb2JhbE9wdGlvbnMpO1xuXHRmdW5jdGlvbiBnZXRSZWNvcmRNYXRjaGVyKG5hbWUpIHtcblx0XHRyZXR1cm4gbWF0Y2hlck1hcC5nZXQobmFtZSk7XG5cdH1cblx0ZnVuY3Rpb24gYWRkUm91dGUocmVjb3JkLCBwYXJlbnQsIG9yaWdpbmFsUmVjb3JkKSB7XG5cdFx0Y29uc3QgaXNSb290QWRkID0gIW9yaWdpbmFsUmVjb3JkO1xuXHRcdGNvbnN0IG1haW5Ob3JtYWxpemVkUmVjb3JkID0gbm9ybWFsaXplUm91dGVSZWNvcmQocmVjb3JkKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjaGVja0NoaWxkTWlzc2luZ05hbWVXaXRoRW1wdHlQYXRoKG1haW5Ob3JtYWxpemVkUmVjb3JkLCBwYXJlbnQpO1xuXHRcdG1haW5Ob3JtYWxpemVkUmVjb3JkLmFsaWFzT2YgPSBvcmlnaW5hbFJlY29yZCAmJiBvcmlnaW5hbFJlY29yZC5yZWNvcmQ7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IG1lcmdlT3B0aW9ucyhnbG9iYWxPcHRpb25zLCByZWNvcmQpO1xuXHRcdGNvbnN0IG5vcm1hbGl6ZWRSZWNvcmRzID0gW21haW5Ob3JtYWxpemVkUmVjb3JkXTtcblx0XHRpZiAoXCJhbGlhc1wiIGluIHJlY29yZCkge1xuXHRcdFx0Y29uc3QgYWxpYXNlcyA9IHR5cGVvZiByZWNvcmQuYWxpYXMgPT09IFwic3RyaW5nXCIgPyBbcmVjb3JkLmFsaWFzXSA6IHJlY29yZC5hbGlhcztcblx0XHRcdGZvciAoY29uc3QgYWxpYXMgb2YgYWxpYXNlcykgbm9ybWFsaXplZFJlY29yZHMucHVzaChub3JtYWxpemVSb3V0ZVJlY29yZChhc3NpZ24oe30sIG1haW5Ob3JtYWxpemVkUmVjb3JkLCB7XG5cdFx0XHRcdGNvbXBvbmVudHM6IG9yaWdpbmFsUmVjb3JkID8gb3JpZ2luYWxSZWNvcmQucmVjb3JkLmNvbXBvbmVudHMgOiBtYWluTm9ybWFsaXplZFJlY29yZC5jb21wb25lbnRzLFxuXHRcdFx0XHRwYXRoOiBhbGlhcyxcblx0XHRcdFx0YWxpYXNPZjogb3JpZ2luYWxSZWNvcmQgPyBvcmlnaW5hbFJlY29yZC5yZWNvcmQgOiBtYWluTm9ybWFsaXplZFJlY29yZFxuXHRcdFx0fSkpKTtcblx0XHR9XG5cdFx0bGV0IG1hdGNoZXI7XG5cdFx0bGV0IG9yaWdpbmFsTWF0Y2hlcjtcblx0XHRmb3IgKGNvbnN0IG5vcm1hbGl6ZWRSZWNvcmQgb2Ygbm9ybWFsaXplZFJlY29yZHMpIHtcblx0XHRcdGNvbnN0IHsgcGF0aCB9ID0gbm9ybWFsaXplZFJlY29yZDtcblx0XHRcdGlmIChwYXJlbnQgJiYgcGF0aFswXSAhPT0gXCIvXCIpIHtcblx0XHRcdFx0Y29uc3QgcGFyZW50UGF0aCA9IHBhcmVudC5yZWNvcmQucGF0aDtcblx0XHRcdFx0Y29uc3QgY29ubmVjdGluZ1NsYXNoID0gcGFyZW50UGF0aFtwYXJlbnRQYXRoLmxlbmd0aCAtIDFdID09PSBcIi9cIiA/IFwiXCIgOiBcIi9cIjtcblx0XHRcdFx0bm9ybWFsaXplZFJlY29yZC5wYXRoID0gcGFyZW50LnJlY29yZC5wYXRoICsgKHBhdGggJiYgY29ubmVjdGluZ1NsYXNoICsgcGF0aCk7XG5cdFx0XHR9XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIG5vcm1hbGl6ZWRSZWNvcmQucGF0aCA9PT0gXCIqXCIpIHRocm93IG5ldyBFcnJvcihcIkNhdGNoIGFsbCByb3V0ZXMgKFxcXCIqXFxcIikgbXVzdCBub3cgYmUgZGVmaW5lZCB1c2luZyBhIHBhcmFtIHdpdGggYSBjdXN0b20gcmVnZXhwLlxcblNlZSBtb3JlIGF0IGh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9taWdyYXRpb24vI1JlbW92ZWQtc3Rhci1vci1jYXRjaC1hbGwtcm91dGVzLlwiKTtcblx0XHRcdG1hdGNoZXIgPSBjcmVhdGVSb3V0ZVJlY29yZE1hdGNoZXIobm9ybWFsaXplZFJlY29yZCwgcGFyZW50LCBvcHRpb25zKTtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgcGFyZW50ICYmIHBhdGhbMF0gPT09IFwiL1wiKSBjaGVja01pc3NpbmdQYXJhbXNJbkFic29sdXRlUGF0aChtYXRjaGVyLCBwYXJlbnQpO1xuXHRcdFx0aWYgKG9yaWdpbmFsUmVjb3JkKSB7XG5cdFx0XHRcdG9yaWdpbmFsUmVjb3JkLmFsaWFzLnB1c2gobWF0Y2hlcik7XG5cdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNoZWNrU2FtZVBhcmFtcyhvcmlnaW5hbFJlY29yZCwgbWF0Y2hlcik7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRvcmlnaW5hbE1hdGNoZXIgPSBvcmlnaW5hbE1hdGNoZXIgfHwgbWF0Y2hlcjtcblx0XHRcdFx0aWYgKG9yaWdpbmFsTWF0Y2hlciAhPT0gbWF0Y2hlcikgb3JpZ2luYWxNYXRjaGVyLmFsaWFzLnB1c2gobWF0Y2hlcik7XG5cdFx0XHRcdGlmIChpc1Jvb3RBZGQgJiYgcmVjb3JkLm5hbWUgJiYgIWlzQWxpYXNSZWNvcmQobWF0Y2hlcikpIHtcblx0XHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjaGVja1NhbWVOYW1lQXNBbmNlc3RvcihyZWNvcmQsIHBhcmVudCk7XG5cdFx0XHRcdFx0cmVtb3ZlUm91dGUocmVjb3JkLm5hbWUpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoaXNNYXRjaGFibGUobWF0Y2hlcikpIGluc2VydE1hdGNoZXIobWF0Y2hlcik7XG5cdFx0XHRpZiAobWFpbk5vcm1hbGl6ZWRSZWNvcmQuY2hpbGRyZW4pIHtcblx0XHRcdFx0Y29uc3QgY2hpbGRyZW4gPSBtYWluTm9ybWFsaXplZFJlY29yZC5jaGlsZHJlbjtcblx0XHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykgYWRkUm91dGUoY2hpbGRyZW5baV0sIG1hdGNoZXIsIG9yaWdpbmFsUmVjb3JkICYmIG9yaWdpbmFsUmVjb3JkLmNoaWxkcmVuW2ldKTtcblx0XHRcdH1cblx0XHRcdG9yaWdpbmFsUmVjb3JkID0gb3JpZ2luYWxSZWNvcmQgfHwgbWF0Y2hlcjtcblx0XHR9XG5cdFx0cmV0dXJuIG9yaWdpbmFsTWF0Y2hlciA/ICgpID0+IHtcblx0XHRcdHJlbW92ZVJvdXRlKG9yaWdpbmFsTWF0Y2hlcik7XG5cdFx0fSA6IG5vb3A7XG5cdH1cblx0ZnVuY3Rpb24gcmVtb3ZlUm91dGUobWF0Y2hlclJlZikge1xuXHRcdGlmIChpc1JvdXRlTmFtZShtYXRjaGVyUmVmKSkge1xuXHRcdFx0Y29uc3QgbWF0Y2hlciA9IG1hdGNoZXJNYXAuZ2V0KG1hdGNoZXJSZWYpO1xuXHRcdFx0aWYgKG1hdGNoZXIpIHtcblx0XHRcdFx0bWF0Y2hlck1hcC5kZWxldGUobWF0Y2hlclJlZik7XG5cdFx0XHRcdG1hdGNoZXJzLnNwbGljZShtYXRjaGVycy5pbmRleE9mKG1hdGNoZXIpLCAxKTtcblx0XHRcdFx0bWF0Y2hlci5jaGlsZHJlbi5mb3JFYWNoKHJlbW92ZVJvdXRlKTtcblx0XHRcdFx0bWF0Y2hlci5hbGlhcy5mb3JFYWNoKHJlbW92ZVJvdXRlKTtcblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgaW5kZXggPSBtYXRjaGVycy5pbmRleE9mKG1hdGNoZXJSZWYpO1xuXHRcdFx0aWYgKGluZGV4ID4gLTEpIHtcblx0XHRcdFx0bWF0Y2hlcnMuc3BsaWNlKGluZGV4LCAxKTtcblx0XHRcdFx0aWYgKG1hdGNoZXJSZWYucmVjb3JkLm5hbWUpIG1hdGNoZXJNYXAuZGVsZXRlKG1hdGNoZXJSZWYucmVjb3JkLm5hbWUpO1xuXHRcdFx0XHRtYXRjaGVyUmVmLmNoaWxkcmVuLmZvckVhY2gocmVtb3ZlUm91dGUpO1xuXHRcdFx0XHRtYXRjaGVyUmVmLmFsaWFzLmZvckVhY2gocmVtb3ZlUm91dGUpO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRmdW5jdGlvbiBnZXRSb3V0ZXMoKSB7XG5cdFx0cmV0dXJuIG1hdGNoZXJzO1xuXHR9XG5cdGZ1bmN0aW9uIGluc2VydE1hdGNoZXIobWF0Y2hlcikge1xuXHRcdGNvbnN0IGluZGV4ID0gZmluZEluc2VydGlvbkluZGV4KG1hdGNoZXIsIG1hdGNoZXJzKTtcblx0XHRtYXRjaGVycy5zcGxpY2UoaW5kZXgsIDAsIG1hdGNoZXIpO1xuXHRcdGlmIChtYXRjaGVyLnJlY29yZC5uYW1lICYmICFpc0FsaWFzUmVjb3JkKG1hdGNoZXIpKSBtYXRjaGVyTWFwLnNldChtYXRjaGVyLnJlY29yZC5uYW1lLCBtYXRjaGVyKTtcblx0fVxuXHRmdW5jdGlvbiByZXNvbHZlKGxvY2F0aW9uLCBjdXJyZW50TG9jYXRpb24pIHtcblx0XHRsZXQgbWF0Y2hlcjtcblx0XHRsZXQgcGFyYW1zID0ge307XG5cdFx0bGV0IHBhdGg7XG5cdFx0bGV0IG5hbWU7XG5cdFx0aWYgKFwibmFtZVwiIGluIGxvY2F0aW9uICYmIGxvY2F0aW9uLm5hbWUpIHtcblx0XHRcdG1hdGNoZXIgPSBtYXRjaGVyTWFwLmdldChsb2NhdGlvbi5uYW1lKTtcblx0XHRcdGlmICghbWF0Y2hlcikgdGhyb3cgY3JlYXRlUm91dGVyRXJyb3IoMSwgeyBsb2NhdGlvbiB9KTtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0Y29uc3QgaW52YWxpZFBhcmFtcyA9IE9iamVjdC5rZXlzKGxvY2F0aW9uLnBhcmFtcyB8fCB7fSkuZmlsdGVyKChwYXJhbU5hbWUpID0+ICFtYXRjaGVyLmtleXMuZmluZCgoaykgPT4gay5uYW1lID09PSBwYXJhbU5hbWUpKTtcblx0XHRcdFx0aWYgKGludmFsaWRQYXJhbXMubGVuZ3RoKSB7XG5cdFx0XHRcdFx0Y29uc3QgaXNJbmhlcml0ZWQgPSAhbWF0Y2hlci5rZXlzLmxlbmd0aCAmJiBpbnZhbGlkUGFyYW1zLnNvbWUoKG5hbWUpID0+IG5hbWUgaW4gY3VycmVudExvY2F0aW9uLnBhcmFtcyk7XG5cdFx0XHRcdFx0d2FybiQxKGBEaXNjYXJkZWQgaW52YWxpZCBwYXJhbShzKSBcIiR7aW52YWxpZFBhcmFtcy5qb2luKFwiXFxcIiwgXFxcIlwiKX1cIiB3aGVuIG5hdmlnYXRpbmcuYCArIChpc0luaGVyaXRlZCA/IGAgSWYgeW91IGFyZSB1c2luZyBhIGNhdGNoLWFsbCByb3V0ZSB3aXRoIGEgbmFtZWQgcmVkaXJlY3QsIHBhc3MgYW4gZW1wdHkgXFxgcGFyYW1zXFxgIG9iamVjdDogXFxgcmVkaXJlY3Q6IHsgbmFtZTogJy4uLicsIHBhcmFtczoge30gfVxcYC5gIDogXCJcIikgKyBgIFNlZSBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyL2Jsb2IvbWFpbi9wYWNrYWdlcy9yb3V0ZXIvQ0hBTkdFTE9HLm1kIzQxNC0yMDIyLTA4LTIyIGZvciBtb3JlIGRldGFpbHMuYCk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdG5hbWUgPSBtYXRjaGVyLnJlY29yZC5uYW1lO1xuXHRcdFx0cGFyYW1zID0gYXNzaWduKHBpY2tQYXJhbXMoY3VycmVudExvY2F0aW9uLnBhcmFtcywgbWF0Y2hlci5rZXlzLmZpbHRlcigoaykgPT4gIWsub3B0aW9uYWwpLmNvbmNhdChtYXRjaGVyLnBhcmVudCA/IG1hdGNoZXIucGFyZW50LmtleXMuZmlsdGVyKChrKSA9PiBrLm9wdGlvbmFsKSA6IFtdKS5tYXAoKGspID0+IGsubmFtZSkpLCBsb2NhdGlvbi5wYXJhbXMgJiYgcGlja1BhcmFtcyhsb2NhdGlvbi5wYXJhbXMsIG1hdGNoZXIua2V5cy5tYXAoKGspID0+IGsubmFtZSkpKTtcblx0XHRcdHBhdGggPSBtYXRjaGVyLnN0cmluZ2lmeShwYXJhbXMpO1xuXHRcdH0gZWxzZSBpZiAobG9jYXRpb24ucGF0aCAhPSBudWxsKSB7XG5cdFx0XHRwYXRoID0gbG9jYXRpb24ucGF0aDtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIXBhdGguc3RhcnRzV2l0aChcIi9cIikpIHdhcm4kMShgVGhlIE1hdGNoZXIgY2Fubm90IHJlc29sdmUgcmVsYXRpdmUgcGF0aHMgYnV0IHJlY2VpdmVkIFwiJHtwYXRofVwiLiBVbmxlc3MgeW91IGRpcmVjdGx5IGNhbGxlZCBcXGBtYXRjaGVyLnJlc29sdmUoXCIke3BhdGh9XCIpXFxgLCB0aGlzIGlzIHByb2JhYmx5IGEgYnVnIGluIHZ1ZS1yb3V0ZXIuIFBsZWFzZSBvcGVuIGFuIGlzc3VlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvaXNzdWVzL25ldy9jaG9vc2UuYCk7XG5cdFx0XHRtYXRjaGVyID0gbWF0Y2hlcnMuZmluZCgobSkgPT4gbS5yZS50ZXN0KHBhdGgpKTtcblx0XHRcdGlmIChtYXRjaGVyKSB7XG5cdFx0XHRcdHBhcmFtcyA9IG1hdGNoZXIucGFyc2UocGF0aCk7XG5cdFx0XHRcdG5hbWUgPSBtYXRjaGVyLnJlY29yZC5uYW1lO1xuXHRcdFx0XHRtYXRjaGVyLmtleXMuZm9yRWFjaCgoa2V5KSA9PiB7XG5cdFx0XHRcdFx0aWYgKGtleS5vcHRpb25hbCAmJiAhcGFyYW1zW2tleS5uYW1lXSkgZGVsZXRlIHBhcmFtc1trZXkubmFtZV07XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRtYXRjaGVyID0gY3VycmVudExvY2F0aW9uLm5hbWUgPyBtYXRjaGVyTWFwLmdldChjdXJyZW50TG9jYXRpb24ubmFtZSkgOiBtYXRjaGVycy5maW5kKChtKSA9PiBtLnJlLnRlc3QoY3VycmVudExvY2F0aW9uLnBhdGgpKTtcblx0XHRcdGlmICghbWF0Y2hlcikgdGhyb3cgY3JlYXRlUm91dGVyRXJyb3IoMSwge1xuXHRcdFx0XHRsb2NhdGlvbixcblx0XHRcdFx0Y3VycmVudExvY2F0aW9uXG5cdFx0XHR9KTtcblx0XHRcdG5hbWUgPSBtYXRjaGVyLnJlY29yZC5uYW1lO1xuXHRcdFx0cGFyYW1zID0gYXNzaWduKHt9LCBjdXJyZW50TG9jYXRpb24ucGFyYW1zLCBsb2NhdGlvbi5wYXJhbXMpO1xuXHRcdFx0cGF0aCA9IG1hdGNoZXIuc3RyaW5naWZ5KHBhcmFtcyk7XG5cdFx0fVxuXHRcdGNvbnN0IG1hdGNoZWQgPSBbXTtcblx0XHRsZXQgcGFyZW50TWF0Y2hlciA9IG1hdGNoZXI7XG5cdFx0d2hpbGUgKHBhcmVudE1hdGNoZXIpIHtcblx0XHRcdG1hdGNoZWQudW5zaGlmdChwYXJlbnRNYXRjaGVyLnJlY29yZCk7XG5cdFx0XHRwYXJlbnRNYXRjaGVyID0gcGFyZW50TWF0Y2hlci5wYXJlbnQ7XG5cdFx0fVxuXHRcdHJldHVybiB7XG5cdFx0XHRuYW1lLFxuXHRcdFx0cGF0aCxcblx0XHRcdHBhcmFtcyxcblx0XHRcdG1hdGNoZWQsXG5cdFx0XHRtZXRhOiBtZXJnZU1ldGFGaWVsZHMobWF0Y2hlZClcblx0XHR9O1xuXHR9XG5cdHJvdXRlcy5mb3JFYWNoKChyb3V0ZSkgPT4gYWRkUm91dGUocm91dGUpKTtcblx0ZnVuY3Rpb24gY2xlYXJSb3V0ZXMoKSB7XG5cdFx0bWF0Y2hlcnMubGVuZ3RoID0gMDtcblx0XHRtYXRjaGVyTWFwLmNsZWFyKCk7XG5cdH1cblx0cmV0dXJuIHtcblx0XHRhZGRSb3V0ZSxcblx0XHRyZXNvbHZlLFxuXHRcdHJlbW92ZVJvdXRlLFxuXHRcdGNsZWFyUm91dGVzLFxuXHRcdGdldFJvdXRlcyxcblx0XHRnZXRSZWNvcmRNYXRjaGVyXG5cdH07XG59XG4vKipcbiogUGlja3MgYW4gb2JqZWN0IHBhcmFtIHRvIGNvbnRhaW4gb25seSBzcGVjaWZpZWQga2V5cy5cbipcbiogQHBhcmFtIHBhcmFtcyAtIHBhcmFtcyBvYmplY3QgdG8gcGljayBmcm9tXG4qIEBwYXJhbSBrZXlzIC0ga2V5cyB0byBwaWNrXG4qL1xuZnVuY3Rpb24gcGlja1BhcmFtcyhwYXJhbXMsIGtleXMpIHtcblx0Y29uc3QgbmV3UGFyYW1zID0ge307XG5cdGZvciAoY29uc3Qga2V5IG9mIGtleXMpIGlmIChrZXkgaW4gcGFyYW1zKSBuZXdQYXJhbXNba2V5XSA9IHBhcmFtc1trZXldO1xuXHRyZXR1cm4gbmV3UGFyYW1zO1xufVxuLyoqXG4qIE5vcm1hbGl6ZXMgYSBSb3V0ZVJlY29yZFJhdy4gQ3JlYXRlcyBhIGNvcHlcbipcbiogQHBhcmFtIHJlY29yZFxuKiBAcmV0dXJucyB0aGUgbm9ybWFsaXplZCB2ZXJzaW9uXG4qL1xuZnVuY3Rpb24gbm9ybWFsaXplUm91dGVSZWNvcmQocmVjb3JkKSB7XG5cdGNvbnN0IG5vcm1hbGl6ZWQgPSB7XG5cdFx0cGF0aDogcmVjb3JkLnBhdGgsXG5cdFx0cmVkaXJlY3Q6IHJlY29yZC5yZWRpcmVjdCxcblx0XHRuYW1lOiByZWNvcmQubmFtZSxcblx0XHRtZXRhOiByZWNvcmQubWV0YSB8fCB7fSxcblx0XHRhbGlhc09mOiByZWNvcmQuYWxpYXNPZixcblx0XHRiZWZvcmVFbnRlcjogcmVjb3JkLmJlZm9yZUVudGVyLFxuXHRcdHByb3BzOiBub3JtYWxpemVSZWNvcmRQcm9wcyhyZWNvcmQpLFxuXHRcdGNoaWxkcmVuOiByZWNvcmQuY2hpbGRyZW4gfHwgW10sXG5cdFx0aW5zdGFuY2VzOiB7fSxcblx0XHRsZWF2ZUd1YXJkczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcblx0XHR1cGRhdGVHdWFyZHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG5cdFx0ZW50ZXJDYWxsYmFja3M6IHt9LFxuXHRcdGNvbXBvbmVudHM6IFwiY29tcG9uZW50c1wiIGluIHJlY29yZCA/IHJlY29yZC5jb21wb25lbnRzIHx8IG51bGwgOiByZWNvcmQuY29tcG9uZW50ICYmIHsgZGVmYXVsdDogcmVjb3JkLmNvbXBvbmVudCB9XG5cdH07XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShub3JtYWxpemVkLCBcIm1vZHNcIiwgeyB2YWx1ZToge30gfSk7XG5cdHJldHVybiBub3JtYWxpemVkO1xufVxuLyoqXG4qIE5vcm1hbGl6ZSB0aGUgb3B0aW9uYWwgYHByb3BzYCBpbiBhIHJlY29yZCB0byBhbHdheXMgYmUgYW4gb2JqZWN0IHNpbWlsYXIgdG9cbiogY29tcG9uZW50cy4gQWxzbyBhY2NlcHQgYSBib29sZWFuIGZvciBjb21wb25lbnRzLlxuKiBAcGFyYW0gcmVjb3JkXG4qL1xuZnVuY3Rpb24gbm9ybWFsaXplUmVjb3JkUHJvcHMocmVjb3JkKSB7XG5cdGNvbnN0IHByb3BzT2JqZWN0ID0ge307XG5cdGNvbnN0IHByb3BzID0gcmVjb3JkLnByb3BzIHx8IGZhbHNlO1xuXHRpZiAoXCJjb21wb25lbnRcIiBpbiByZWNvcmQpIHByb3BzT2JqZWN0LmRlZmF1bHQgPSBwcm9wcztcblx0ZWxzZSBmb3IgKGNvbnN0IG5hbWUgaW4gcmVjb3JkLmNvbXBvbmVudHMpIHByb3BzT2JqZWN0W25hbWVdID0gdHlwZW9mIHByb3BzID09PSBcIm9iamVjdFwiID8gcHJvcHNbbmFtZV0gOiBwcm9wcztcblx0cmV0dXJuIHByb3BzT2JqZWN0O1xufVxuLyoqXG4qIENoZWNrcyBpZiBhIHJlY29yZCBvciBhbnkgb2YgaXRzIHBhcmVudCBpcyBhbiBhbGlhc1xuKiBAcGFyYW0gcmVjb3JkXG4qL1xuZnVuY3Rpb24gaXNBbGlhc1JlY29yZChyZWNvcmQpIHtcblx0d2hpbGUgKHJlY29yZCkge1xuXHRcdGlmIChyZWNvcmQucmVjb3JkLmFsaWFzT2YpIHJldHVybiB0cnVlO1xuXHRcdHJlY29yZCA9IHJlY29yZC5wYXJlbnQ7XG5cdH1cblx0cmV0dXJuIGZhbHNlO1xufVxuLyoqXG4qIE1lcmdlIG1ldGEgZmllbGRzIG9mIGFuIGFycmF5IG9mIHJlY29yZHNcbipcbiogQHBhcmFtIG1hdGNoZWQgLSBhcnJheSBvZiBtYXRjaGVkIHJlY29yZHNcbiovXG5mdW5jdGlvbiBtZXJnZU1ldGFGaWVsZHMobWF0Y2hlZCkge1xuXHRyZXR1cm4gbWF0Y2hlZC5yZWR1Y2UoKG1ldGEsIHJlY29yZCkgPT4gYXNzaWduKG1ldGEsIHJlY29yZC5tZXRhKSwge30pO1xufVxuZnVuY3Rpb24gaXNTYW1lUGFyYW0oYSwgYikge1xuXHRyZXR1cm4gYS5uYW1lID09PSBiLm5hbWUgJiYgYS5vcHRpb25hbCA9PT0gYi5vcHRpb25hbCAmJiBhLnJlcGVhdGFibGUgPT09IGIucmVwZWF0YWJsZTtcbn1cbi8qKlxuKiBDaGVjayBpZiBhIHBhdGggYW5kIGl0cyBhbGlhcyBoYXZlIHRoZSBzYW1lIHJlcXVpcmVkIHBhcmFtc1xuKlxuKiBAcGFyYW0gYSAtIG9yaWdpbmFsIHJlY29yZFxuKiBAcGFyYW0gYiAtIGFsaWFzIHJlY29yZFxuKi9cbmZ1bmN0aW9uIGNoZWNrU2FtZVBhcmFtcyhhLCBiKSB7XG5cdGZvciAoY29uc3Qga2V5IG9mIGEua2V5cykgaWYgKCFrZXkub3B0aW9uYWwgJiYgIWIua2V5cy5maW5kKGlzU2FtZVBhcmFtLmJpbmQobnVsbCwga2V5KSkpIHJldHVybiB3YXJuJDEoYEFsaWFzIFwiJHtiLnJlY29yZC5wYXRofVwiIGFuZCB0aGUgb3JpZ2luYWwgcmVjb3JkOiBcIiR7YS5yZWNvcmQucGF0aH1cIiBtdXN0IGhhdmUgdGhlIGV4YWN0IHNhbWUgcGFyYW0gbmFtZWQgXCIke2tleS5uYW1lfVwiYCk7XG5cdGZvciAoY29uc3Qga2V5IG9mIGIua2V5cykgaWYgKCFrZXkub3B0aW9uYWwgJiYgIWEua2V5cy5maW5kKGlzU2FtZVBhcmFtLmJpbmQobnVsbCwga2V5KSkpIHJldHVybiB3YXJuJDEoYEFsaWFzIFwiJHtiLnJlY29yZC5wYXRofVwiIGFuZCB0aGUgb3JpZ2luYWwgcmVjb3JkOiBcIiR7YS5yZWNvcmQucGF0aH1cIiBtdXN0IGhhdmUgdGhlIGV4YWN0IHNhbWUgcGFyYW0gbmFtZWQgXCIke2tleS5uYW1lfVwiYCk7XG59XG4vKipcbiogQSByb3V0ZSB3aXRoIGEgbmFtZSBhbmQgYSBjaGlsZCB3aXRoIGFuIGVtcHR5IHBhdGggd2l0aG91dCBhIG5hbWUgc2hvdWxkIHdhcm4gd2hlbiBhZGRpbmcgdGhlIHJvdXRlXG4qXG4qIEBwYXJhbSBtYWluTm9ybWFsaXplZFJlY29yZCAtIFJvdXRlUmVjb3JkTm9ybWFsaXplZFxuKiBAcGFyYW0gcGFyZW50IC0gUm91dGVSZWNvcmRNYXRjaGVyXG4qL1xuZnVuY3Rpb24gY2hlY2tDaGlsZE1pc3NpbmdOYW1lV2l0aEVtcHR5UGF0aChtYWluTm9ybWFsaXplZFJlY29yZCwgcGFyZW50KSB7XG5cdGlmIChwYXJlbnQgJiYgcGFyZW50LnJlY29yZC5uYW1lICYmICFtYWluTm9ybWFsaXplZFJlY29yZC5uYW1lICYmICFtYWluTm9ybWFsaXplZFJlY29yZC5wYXRoICYmIG1haW5Ob3JtYWxpemVkUmVjb3JkLmNoaWxkcmVuLmxlbmd0aCA9PT0gMCkgd2FybiQxKGBUaGUgcm91dGUgbmFtZWQgXCIke1N0cmluZyhwYXJlbnQucmVjb3JkLm5hbWUpfVwiIGhhcyBhIGNoaWxkIHdpdGhvdXQgYSBuYW1lLCBhbiBlbXB0eSBwYXRoLCBhbmQgbm8gY2hpbGRyZW4uIFRoaXMgaXMgcHJvYmFibHkgYSBtaXN0YWtlOiB1c2luZyB0aGF0IG5hbWUgd29uJ3QgcmVuZGVyIHRoZSBlbXB0eSBwYXRoIGNoaWxkIHNvIHlvdSBwcm9iYWJseSB3YW50IHRvIG1vdmUgdGhlIG5hbWUgdG8gdGhlIGNoaWxkIGluc3RlYWQuIElmIHRoaXMgaXMgaW50ZW50aW9uYWwsIGFkZCBhIG5hbWUgdG8gdGhlIGNoaWxkIHJvdXRlIHRvIHNpbGVuY2UgdGhlIHdhcm5pbmcuYCk7XG59XG5mdW5jdGlvbiBjaGVja1NhbWVOYW1lQXNBbmNlc3RvcihyZWNvcmQsIHBhcmVudCkge1xuXHRmb3IgKGxldCBhbmNlc3RvciA9IHBhcmVudDsgYW5jZXN0b3I7IGFuY2VzdG9yID0gYW5jZXN0b3IucGFyZW50KSBpZiAoYW5jZXN0b3IucmVjb3JkLm5hbWUgPT09IHJlY29yZC5uYW1lKSB0aHJvdyBuZXcgRXJyb3IoYEEgcm91dGUgbmFtZWQgXCIke1N0cmluZyhyZWNvcmQubmFtZSl9XCIgaGFzIGJlZW4gYWRkZWQgYXMgYSAke3BhcmVudCA9PT0gYW5jZXN0b3IgPyBcImNoaWxkXCIgOiBcImRlc2NlbmRhbnRcIn0gb2YgYSByb3V0ZSB3aXRoIHRoZSBzYW1lIG5hbWUuIFJvdXRlIG5hbWVzIG11c3QgYmUgdW5pcXVlIGFuZCBhIG5lc3RlZCByb3V0ZSBjYW5ub3QgdXNlIHRoZSBzYW1lIG5hbWUgYXMgYW4gYW5jZXN0b3IuYCk7XG59XG5mdW5jdGlvbiBjaGVja01pc3NpbmdQYXJhbXNJbkFic29sdXRlUGF0aChyZWNvcmQsIHBhcmVudCkge1xuXHRmb3IgKGNvbnN0IGtleSBvZiBwYXJlbnQua2V5cykgaWYgKCFyZWNvcmQua2V5cy5maW5kKGlzU2FtZVBhcmFtLmJpbmQobnVsbCwga2V5KSkpIHJldHVybiB3YXJuJDEoYEFic29sdXRlIHBhdGggXCIke3JlY29yZC5yZWNvcmQucGF0aH1cIiBtdXN0IGhhdmUgdGhlIGV4YWN0IHNhbWUgcGFyYW0gbmFtZWQgXCIke2tleS5uYW1lfVwiIGFzIGl0cyBwYXJlbnQgXCIke3BhcmVudC5yZWNvcmQucGF0aH1cIi5gKTtcbn1cbi8qKlxuKiBQZXJmb3JtcyBhIGJpbmFyeSBzZWFyY2ggdG8gZmluZCB0aGUgY29ycmVjdCBpbnNlcnRpb24gaW5kZXggZm9yIGEgbmV3IG1hdGNoZXIuXG4qXG4qIE1hdGNoZXJzIGFyZSBwcmltYXJpbHkgc29ydGVkIGJ5IHRoZWlyIHNjb3JlLiBJZiBzY29yZXMgYXJlIHRpZWQgdGhlbiB3ZSBhbHNvIGNvbnNpZGVyIHBhcmVudC9jaGlsZCByZWxhdGlvbnNoaXBzLFxuKiB3aXRoIGRlc2NlbmRhbnRzIGNvbWluZyBiZWZvcmUgYW5jZXN0b3JzLiBJZiB0aGVyZSdzIHN0aWxsIGEgdGllLCBuZXcgcm91dGVzIGFyZSBpbnNlcnRlZCBhZnRlciBleGlzdGluZyByb3V0ZXMuXG4qXG4qIEBwYXJhbSBtYXRjaGVyIC0gbmV3IG1hdGNoZXIgdG8gYmUgaW5zZXJ0ZWRcbiogQHBhcmFtIG1hdGNoZXJzIC0gZXhpc3RpbmcgbWF0Y2hlcnNcbiovXG5mdW5jdGlvbiBmaW5kSW5zZXJ0aW9uSW5kZXgobWF0Y2hlciwgbWF0Y2hlcnMpIHtcblx0bGV0IGxvd2VyID0gMDtcblx0bGV0IHVwcGVyID0gbWF0Y2hlcnMubGVuZ3RoO1xuXHR3aGlsZSAobG93ZXIgIT09IHVwcGVyKSB7XG5cdFx0Y29uc3QgbWlkID0gbG93ZXIgKyB1cHBlciA+PiAxO1xuXHRcdGlmIChjb21wYXJlUGF0aFBhcnNlclNjb3JlKG1hdGNoZXIsIG1hdGNoZXJzW21pZF0pIDwgMCkgdXBwZXIgPSBtaWQ7XG5cdFx0ZWxzZSBsb3dlciA9IG1pZCArIDE7XG5cdH1cblx0Y29uc3QgaW5zZXJ0aW9uQW5jZXN0b3IgPSBnZXRJbnNlcnRpb25BbmNlc3RvcihtYXRjaGVyKTtcblx0aWYgKGluc2VydGlvbkFuY2VzdG9yKSB7XG5cdFx0dXBwZXIgPSBtYXRjaGVycy5sYXN0SW5kZXhPZihpbnNlcnRpb25BbmNlc3RvciwgdXBwZXIgLSAxKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHVwcGVyIDwgMCkgd2FybiQxKGBGaW5kaW5nIGFuY2VzdG9yIHJvdXRlIFwiJHtpbnNlcnRpb25BbmNlc3Rvci5yZWNvcmQucGF0aH1cIiBmYWlsZWQgZm9yIFwiJHttYXRjaGVyLnJlY29yZC5wYXRofVwiYCk7XG5cdH1cblx0cmV0dXJuIHVwcGVyO1xufVxuZnVuY3Rpb24gZ2V0SW5zZXJ0aW9uQW5jZXN0b3IobWF0Y2hlcikge1xuXHRsZXQgYW5jZXN0b3IgPSBtYXRjaGVyO1xuXHR3aGlsZSAoYW5jZXN0b3IgPSBhbmNlc3Rvci5wYXJlbnQpIGlmIChpc01hdGNoYWJsZShhbmNlc3RvcikgJiYgY29tcGFyZVBhdGhQYXJzZXJTY29yZShtYXRjaGVyLCBhbmNlc3RvcikgPT09IDApIHJldHVybiBhbmNlc3Rvcjtcbn1cbi8qKlxuKiBDaGVja3MgaWYgYSBtYXRjaGVyIGNhbiBiZSByZWFjaGFibGUuIFRoaXMgbWVhbnMgaWYgaXQncyBwb3NzaWJsZSB0byByZWFjaCBpdCBhcyBhIHJvdXRlLiBGb3IgZXhhbXBsZSwgcm91dGVzIHdpdGhvdXRcbiogYSBjb21wb25lbnQsIG9yIG5hbWUsIG9yIHJlZGlyZWN0LCBhcmUganVzdCB1c2VkIHRvIGdyb3VwIG90aGVyIHJvdXRlcy5cbiogQHBhcmFtIG1hdGNoZXJcbiogQHBhcmFtIG1hdGNoZXIucmVjb3JkIHJlY29yZCBvZiB0aGUgbWF0Y2hlclxuKiBAcmV0dXJuc1xuKi9cbmZ1bmN0aW9uIGlzTWF0Y2hhYmxlKHsgcmVjb3JkIH0pIHtcblx0cmV0dXJuICEhKHJlY29yZC5uYW1lIHx8IHJlY29yZC5jb21wb25lbnRzICYmIE9iamVjdC5rZXlzKHJlY29yZC5jb21wb25lbnRzKS5sZW5ndGggfHwgcmVjb3JkLnJlZGlyZWN0KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9Sb3V0ZXJMaW5rLnRzXG4vKipcbiogUmV0dXJucyB0aGUgaW50ZXJuYWwgYmVoYXZpb3Igb2YgYSB7QGxpbmsgUm91dGVyTGlua30gd2l0aG91dCB0aGUgcmVuZGVyaW5nIHBhcnQuXG4qXG4qIEBwYXJhbSBwcm9wcyAtIGEgYHRvYCBsb2NhdGlvbiBhbmQgYW4gb3B0aW9uYWwgYHJlcGxhY2VgIGZsYWdcbiovXG5mdW5jdGlvbiB1c2VMaW5rKHByb3BzKSB7XG5cdGNvbnN0IHJvdXRlciA9IGluamVjdChyb3V0ZXJLZXkpO1xuXHRjb25zdCBjdXJyZW50Um91dGUgPSBpbmplY3Qocm91dGVMb2NhdGlvbktleSk7XG5cdGxldCBoYXNQcmV2aW91cyA9IGZhbHNlO1xuXHRsZXQgcHJldmlvdXNUbyA9IG51bGw7XG5cdGNvbnN0IHJvdXRlID0gY29tcHV0ZWQoKCkgPT4ge1xuXHRcdGNvbnN0IHRvID0gdW5yZWYocHJvcHMudG8pO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgKCFoYXNQcmV2aW91cyB8fCB0byAhPT0gcHJldmlvdXNUbykpIHtcblx0XHRcdGlmICghaXNSb3V0ZUxvY2F0aW9uKHRvKSkgaWYgKGhhc1ByZXZpb3VzKSB3YXJuJDEoYEludmFsaWQgdmFsdWUgZm9yIHByb3AgXCJ0b1wiIGluIHVzZUxpbmsoKVxcbi0gdG86YCwgdG8sIGBcXG4tIHByZXZpb3VzIHRvOmAsIHByZXZpb3VzVG8sIGBcXG4tIHByb3BzOmAsIHByb3BzKTtcblx0XHRcdGVsc2Ugd2FybiQxKGBJbnZhbGlkIHZhbHVlIGZvciBwcm9wIFwidG9cIiBpbiB1c2VMaW5rKClcXG4tIHRvOmAsIHRvLCBgXFxuLSBwcm9wczpgLCBwcm9wcyk7XG5cdFx0XHRwcmV2aW91c1RvID0gdG87XG5cdFx0XHRoYXNQcmV2aW91cyA9IHRydWU7XG5cdFx0fVxuXHRcdHJldHVybiByb3V0ZXIucmVzb2x2ZSh0byk7XG5cdH0pO1xuXHRjb25zdCBhY3RpdmVSZWNvcmRJbmRleCA9IGNvbXB1dGVkKCgpID0+IHtcblx0XHRjb25zdCB7IG1hdGNoZWQgfSA9IHJvdXRlLnZhbHVlO1xuXHRcdGNvbnN0IHsgbGVuZ3RoIH0gPSBtYXRjaGVkO1xuXHRcdGNvbnN0IHJvdXRlTWF0Y2hlZCA9IG1hdGNoZWRbbGVuZ3RoIC0gMV07XG5cdFx0Y29uc3QgY3VycmVudE1hdGNoZWQgPSBjdXJyZW50Um91dGUubWF0Y2hlZDtcblx0XHRpZiAoIXJvdXRlTWF0Y2hlZCB8fCAhY3VycmVudE1hdGNoZWQubGVuZ3RoKSByZXR1cm4gLTE7XG5cdFx0Y29uc3QgaW5kZXggPSBjdXJyZW50TWF0Y2hlZC5maW5kSW5kZXgoaXNTYW1lUm91dGVSZWNvcmQuYmluZChudWxsLCByb3V0ZU1hdGNoZWQpKTtcblx0XHRpZiAoaW5kZXggPiAtMSkgcmV0dXJuIGluZGV4O1xuXHRcdGNvbnN0IHBhcmVudFJlY29yZFBhdGggPSBnZXRPcmlnaW5hbFBhdGgobWF0Y2hlZFtsZW5ndGggLSAyXSk7XG5cdFx0cmV0dXJuIGxlbmd0aCA+IDEgJiYgZ2V0T3JpZ2luYWxQYXRoKHJvdXRlTWF0Y2hlZCkgPT09IHBhcmVudFJlY29yZFBhdGggJiYgY3VycmVudE1hdGNoZWRbY3VycmVudE1hdGNoZWQubGVuZ3RoIC0gMV0ucGF0aCAhPT0gcGFyZW50UmVjb3JkUGF0aCA/IGN1cnJlbnRNYXRjaGVkLmZpbmRJbmRleChpc1NhbWVSb3V0ZVJlY29yZC5iaW5kKG51bGwsIG1hdGNoZWRbbGVuZ3RoIC0gMl0pKSA6IGluZGV4O1xuXHR9KTtcblx0Y29uc3QgaXNBY3RpdmUgPSBjb21wdXRlZCgoKSA9PiBhY3RpdmVSZWNvcmRJbmRleC52YWx1ZSA+IC0xICYmIGluY2x1ZGVzUGFyYW1zKGN1cnJlbnRSb3V0ZS5wYXJhbXMsIHJvdXRlLnZhbHVlLnBhcmFtcykpO1xuXHRjb25zdCBpc0V4YWN0QWN0aXZlID0gY29tcHV0ZWQoKCkgPT4gYWN0aXZlUmVjb3JkSW5kZXgudmFsdWUgPiAtMSAmJiBhY3RpdmVSZWNvcmRJbmRleC52YWx1ZSA9PT0gY3VycmVudFJvdXRlLm1hdGNoZWQubGVuZ3RoIC0gMSAmJiBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zKGN1cnJlbnRSb3V0ZS5wYXJhbXMsIHJvdXRlLnZhbHVlLnBhcmFtcykpO1xuXHRmdW5jdGlvbiBuYXZpZ2F0ZShlID0ge30pIHtcblx0XHRpZiAoZ3VhcmRFdmVudChlKSkge1xuXHRcdFx0Y29uc3QgcCA9IHJvdXRlclt1bnJlZihwcm9wcy5yZXBsYWNlKSA/IFwicmVwbGFjZVwiIDogXCJwdXNoXCJdKHVucmVmKHByb3BzLnRvKSkuY2F0Y2gobm9vcCk7XG5cdFx0XHRpZiAocHJvcHMudmlld1RyYW5zaXRpb24gJiYgdHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIFwic3RhcnRWaWV3VHJhbnNpdGlvblwiIGluIGRvY3VtZW50KSBkb2N1bWVudC5zdGFydFZpZXdUcmFuc2l0aW9uKCgpID0+IHApO1xuXHRcdFx0cmV0dXJuIHA7XG5cdFx0fVxuXHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0fVxuXHRpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIGlzQnJvd3Nlcikge1xuXHRcdGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG5cdFx0aWYgKGluc3RhbmNlKSB7XG5cdFx0XHRjb25zdCBsaW5rQ29udGV4dERldnRvb2xzID0ge1xuXHRcdFx0XHRyb3V0ZTogcm91dGUudmFsdWUsXG5cdFx0XHRcdGlzQWN0aXZlOiBpc0FjdGl2ZS52YWx1ZSxcblx0XHRcdFx0aXNFeGFjdEFjdGl2ZTogaXNFeGFjdEFjdGl2ZS52YWx1ZSxcblx0XHRcdFx0ZXJyb3I6IG51bGxcblx0XHRcdH07XG5cdFx0XHRpbnN0YW5jZS5fX3ZybF9kZXZ0b29scyA9IGluc3RhbmNlLl9fdnJsX2RldnRvb2xzIHx8IFtdO1xuXHRcdFx0aW5zdGFuY2UuX192cmxfZGV2dG9vbHMucHVzaChsaW5rQ29udGV4dERldnRvb2xzKTtcblx0XHRcdHdhdGNoRWZmZWN0KCgpID0+IHtcblx0XHRcdFx0bGlua0NvbnRleHREZXZ0b29scy5yb3V0ZSA9IHJvdXRlLnZhbHVlO1xuXHRcdFx0XHRsaW5rQ29udGV4dERldnRvb2xzLmlzQWN0aXZlID0gaXNBY3RpdmUudmFsdWU7XG5cdFx0XHRcdGxpbmtDb250ZXh0RGV2dG9vbHMuaXNFeGFjdEFjdGl2ZSA9IGlzRXhhY3RBY3RpdmUudmFsdWU7XG5cdFx0XHRcdGxpbmtDb250ZXh0RGV2dG9vbHMuZXJyb3IgPSBpc1JvdXRlTG9jYXRpb24odW5yZWYocHJvcHMudG8pKSA/IG51bGwgOiBcIkludmFsaWQgXFxcInRvXFxcIiB2YWx1ZVwiO1xuXHRcdFx0fSwgeyBmbHVzaDogXCJwb3N0XCIgfSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIE5PVEU6IHVwZGF0ZSB7QGxpbmsgX1JvdXRlckxpbmtJfSdzIGAkc2xvdHNgIHR5cGUgd2hlbiB1cGRhdGluZyB0aGlzXG5cdCovXG5cdHJldHVybiB7XG5cdFx0cm91dGUsXG5cdFx0aHJlZjogY29tcHV0ZWQoKCkgPT4gcm91dGUudmFsdWUuaHJlZiksXG5cdFx0aXNBY3RpdmUsXG5cdFx0aXNFeGFjdEFjdGl2ZSxcblx0XHRuYXZpZ2F0ZVxuXHR9O1xufVxuZnVuY3Rpb24gcHJlZmVyU2luZ2xlVk5vZGUodm5vZGVzKSB7XG5cdHJldHVybiB2bm9kZXMubGVuZ3RoID09PSAxID8gdm5vZGVzWzBdIDogdm5vZGVzO1xufVxuLyoqXG4qIENvbXBvbmVudCB0byByZW5kZXIgYSBsaW5rIHRoYXQgdHJpZ2dlcnMgYSBuYXZpZ2F0aW9uIG9uIGNsaWNrLlxuKi9cbmNvbnN0IFJvdXRlckxpbmsgPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lQ29tcG9uZW50KHtcblx0bmFtZTogXCJSb3V0ZXJMaW5rXCIsXG5cdGNvbXBhdENvbmZpZzogeyBNT0RFOiAzIH0sXG5cdHByb3BzOiB7XG5cdFx0dG86IHtcblx0XHRcdHR5cGU6IFtTdHJpbmcsIE9iamVjdF0sXG5cdFx0XHRyZXF1aXJlZDogdHJ1ZVxuXHRcdH0sXG5cdFx0cmVwbGFjZTogQm9vbGVhbixcblx0XHRhY3RpdmVDbGFzczogU3RyaW5nLFxuXHRcdGV4YWN0QWN0aXZlQ2xhc3M6IFN0cmluZyxcblx0XHRjdXN0b206IEJvb2xlYW4sXG5cdFx0YXJpYUN1cnJlbnRWYWx1ZToge1xuXHRcdFx0dHlwZTogU3RyaW5nLFxuXHRcdFx0ZGVmYXVsdDogXCJwYWdlXCJcblx0XHR9LFxuXHRcdHZpZXdUcmFuc2l0aW9uOiBCb29sZWFuXG5cdH0sXG5cdHVzZUxpbmssXG5cdHNldHVwKHByb3BzLCB7IHNsb3RzIH0pIHtcblx0XHRjb25zdCBsaW5rID0gcmVhY3RpdmUodXNlTGluayhwcm9wcykpO1xuXHRcdGNvbnN0IHsgb3B0aW9ucyB9ID0gaW5qZWN0KHJvdXRlcktleSk7XG5cdFx0Y29uc3QgZWxDbGFzcyA9IGNvbXB1dGVkKCgpID0+ICh7XG5cdFx0XHRbZ2V0TGlua0NsYXNzKHByb3BzLmFjdGl2ZUNsYXNzLCBvcHRpb25zLmxpbmtBY3RpdmVDbGFzcywgXCJyb3V0ZXItbGluay1hY3RpdmVcIildOiBsaW5rLmlzQWN0aXZlLFxuXHRcdFx0W2dldExpbmtDbGFzcyhwcm9wcy5leGFjdEFjdGl2ZUNsYXNzLCBvcHRpb25zLmxpbmtFeGFjdEFjdGl2ZUNsYXNzLCBcInJvdXRlci1saW5rLWV4YWN0LWFjdGl2ZVwiKV06IGxpbmsuaXNFeGFjdEFjdGl2ZVxuXHRcdH0pKTtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0Y29uc3QgY2hpbGRyZW4gPSBzbG90cy5kZWZhdWx0ICYmIHByZWZlclNpbmdsZVZOb2RlKHNsb3RzLmRlZmF1bHQobGluaykpO1xuXHRcdFx0cmV0dXJuIHByb3BzLmN1c3RvbSA/IGNoaWxkcmVuIDogaChcImFcIiwge1xuXHRcdFx0XHRcImFyaWEtY3VycmVudFwiOiBsaW5rLmlzRXhhY3RBY3RpdmUgPyBwcm9wcy5hcmlhQ3VycmVudFZhbHVlIDogbnVsbCxcblx0XHRcdFx0aHJlZjogbGluay5ocmVmLFxuXHRcdFx0XHRvbkNsaWNrOiBsaW5rLm5hdmlnYXRlLFxuXHRcdFx0XHRjbGFzczogZWxDbGFzcy52YWx1ZVxuXHRcdFx0fSwgY2hpbGRyZW4pO1xuXHRcdH07XG5cdH1cbn0pO1xuZnVuY3Rpb24gZ3VhcmRFdmVudChlKSB7XG5cdGlmIChlLm1ldGFLZXkgfHwgZS5hbHRLZXkgfHwgZS5jdHJsS2V5IHx8IGUuc2hpZnRLZXkpIHJldHVybjtcblx0aWYgKGUuZGVmYXVsdFByZXZlbnRlZCkgcmV0dXJuO1xuXHRpZiAoZS5idXR0b24gIT09IHZvaWQgMCAmJiBlLmJ1dHRvbiAhPT0gMCkgcmV0dXJuO1xuXHRpZiAoZS5jdXJyZW50VGFyZ2V0ICYmIGUuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUpIHtcblx0XHRjb25zdCB0YXJnZXQgPSBlLmN1cnJlbnRUYXJnZXQuZ2V0QXR0cmlidXRlKFwidGFyZ2V0XCIpO1xuXHRcdGlmICgvXFxiX2JsYW5rXFxiL2kudGVzdCh0YXJnZXQpKSByZXR1cm47XG5cdH1cblx0aWYgKGUucHJldmVudERlZmF1bHQpIGUucHJldmVudERlZmF1bHQoKTtcblx0cmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpbmNsdWRlc1BhcmFtcyhvdXRlciwgaW5uZXIpIHtcblx0Zm9yIChjb25zdCBrZXkgaW4gaW5uZXIpIHtcblx0XHRjb25zdCBpbm5lclZhbHVlID0gaW5uZXJba2V5XTtcblx0XHRjb25zdCBvdXRlclZhbHVlID0gb3V0ZXJba2V5XTtcblx0XHRpZiAodHlwZW9mIGlubmVyVmFsdWUgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGlmIChpbm5lclZhbHVlICE9PSBvdXRlclZhbHVlKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghaXNBcnJheShvdXRlclZhbHVlKSB8fCBvdXRlclZhbHVlLmxlbmd0aCAhPT0gaW5uZXJWYWx1ZS5sZW5ndGggfHwgaW5uZXJWYWx1ZS5zb21lKCh2YWx1ZSwgaSkgPT4gdmFsdWUudmFsdWVPZigpICE9PSBvdXRlclZhbHVlW2ldLnZhbHVlT2YoKSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gdHJ1ZTtcbn1cbi8qKlxuKiBHZXQgdGhlIG9yaWdpbmFsIHBhdGggdmFsdWUgb2YgYSByZWNvcmQgYnkgZm9sbG93aW5nIGl0cyBhbGlhc09mXG4qIEBwYXJhbSByZWNvcmRcbiovXG5mdW5jdGlvbiBnZXRPcmlnaW5hbFBhdGgocmVjb3JkKSB7XG5cdHJldHVybiByZWNvcmQgPyByZWNvcmQuYWxpYXNPZiA/IHJlY29yZC5hbGlhc09mLnBhdGggOiByZWNvcmQucGF0aCA6IFwiXCI7XG59XG4vKipcbiogVXRpbGl0eSBjbGFzcyB0byBnZXQgdGhlIGFjdGl2ZSBjbGFzcyBiYXNlZCBvbiBkZWZhdWx0cy5cbiogQHBhcmFtIHByb3BDbGFzc1xuKiBAcGFyYW0gZ2xvYmFsQ2xhc3NcbiogQHBhcmFtIGRlZmF1bHRDbGFzc1xuKi9cbmNvbnN0IGdldExpbmtDbGFzcyA9IChwcm9wQ2xhc3MsIGdsb2JhbENsYXNzLCBkZWZhdWx0Q2xhc3MpID0+IHByb3BDbGFzcyAhPSBudWxsID8gcHJvcENsYXNzIDogZ2xvYmFsQ2xhc3MgIT0gbnVsbCA/IGdsb2JhbENsYXNzIDogZGVmYXVsdENsYXNzO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL1JvdXRlclZpZXcudHNcbmNvbnN0IFJvdXRlclZpZXdJbXBsID0gLyogQF9fUFVSRV9fICovIGRlZmluZUNvbXBvbmVudCh7XG5cdG5hbWU6IFwiUm91dGVyVmlld1wiLFxuXHRpbmhlcml0QXR0cnM6IGZhbHNlLFxuXHRwcm9wczoge1xuXHRcdG5hbWU6IHtcblx0XHRcdHR5cGU6IFN0cmluZyxcblx0XHRcdGRlZmF1bHQ6IFwiZGVmYXVsdFwiXG5cdFx0fSxcblx0XHRyb3V0ZTogT2JqZWN0XG5cdH0sXG5cdGNvbXBhdENvbmZpZzogeyBNT0RFOiAzIH0sXG5cdHNldHVwKHByb3BzLCB7IGF0dHJzLCBzbG90cyB9KSB7XG5cdFx0cHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHdhcm5EZXByZWNhdGVkVXNhZ2UoKTtcblx0XHRjb25zdCBpbmplY3RlZFJvdXRlID0gaW5qZWN0KHJvdXRlclZpZXdMb2NhdGlvbktleSk7XG5cdFx0Y29uc3Qgcm91dGVUb0Rpc3BsYXkgPSBjb21wdXRlZCgoKSA9PiBwcm9wcy5yb3V0ZSB8fCBpbmplY3RlZFJvdXRlLnZhbHVlKTtcblx0XHRjb25zdCBpbmplY3RlZERlcHRoID0gaW5qZWN0KHZpZXdEZXB0aEtleSwgMCk7XG5cdFx0Y29uc3QgZGVwdGggPSBjb21wdXRlZCgoKSA9PiB7XG5cdFx0XHRsZXQgaW5pdGlhbERlcHRoID0gdW5yZWYoaW5qZWN0ZWREZXB0aCk7XG5cdFx0XHRjb25zdCB7IG1hdGNoZWQgfSA9IHJvdXRlVG9EaXNwbGF5LnZhbHVlO1xuXHRcdFx0bGV0IG1hdGNoZWRSb3V0ZTtcblx0XHRcdHdoaWxlICgobWF0Y2hlZFJvdXRlID0gbWF0Y2hlZFtpbml0aWFsRGVwdGhdKSAmJiAhbWF0Y2hlZFJvdXRlLmNvbXBvbmVudHMpIGluaXRpYWxEZXB0aCsrO1xuXHRcdFx0cmV0dXJuIGluaXRpYWxEZXB0aDtcblx0XHR9KTtcblx0XHRjb25zdCBtYXRjaGVkUm91dGVSZWYgPSBjb21wdXRlZCgoKSA9PiByb3V0ZVRvRGlzcGxheS52YWx1ZS5tYXRjaGVkW2RlcHRoLnZhbHVlXSk7XG5cdFx0cHJvdmlkZSh2aWV3RGVwdGhLZXksIGNvbXB1dGVkKCgpID0+IGRlcHRoLnZhbHVlICsgMSkpO1xuXHRcdHByb3ZpZGUobWF0Y2hlZFJvdXRlS2V5LCBtYXRjaGVkUm91dGVSZWYpO1xuXHRcdHByb3ZpZGUocm91dGVyVmlld0xvY2F0aW9uS2V5LCByb3V0ZVRvRGlzcGxheSk7XG5cdFx0Y29uc3Qgdmlld1JlZiA9IHJlZigpO1xuXHRcdHdhdGNoKCgpID0+IFtcblx0XHRcdHZpZXdSZWYudmFsdWUsXG5cdFx0XHRtYXRjaGVkUm91dGVSZWYudmFsdWUsXG5cdFx0XHRwcm9wcy5uYW1lXG5cdFx0XSwgKFtpbnN0YW5jZSwgdG8sIG5hbWVdLCBbb2xkSW5zdGFuY2UsIGZyb20sIF9vbGROYW1lXSkgPT4ge1xuXHRcdFx0aWYgKHRvKSB7XG5cdFx0XHRcdHRvLmluc3RhbmNlc1tuYW1lXSA9IGluc3RhbmNlO1xuXHRcdFx0XHRpZiAoZnJvbSAmJiBmcm9tICE9PSB0byAmJiBpbnN0YW5jZSAmJiBpbnN0YW5jZSA9PT0gb2xkSW5zdGFuY2UpIHtcblx0XHRcdFx0XHRpZiAoIXRvLmxlYXZlR3VhcmRzLnNpemUpIHRvLmxlYXZlR3VhcmRzID0gZnJvbS5sZWF2ZUd1YXJkcztcblx0XHRcdFx0XHRpZiAoIXRvLnVwZGF0ZUd1YXJkcy5zaXplKSB0by51cGRhdGVHdWFyZHMgPSBmcm9tLnVwZGF0ZUd1YXJkcztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGluc3RhbmNlICYmIHRvICYmICghZnJvbSB8fCAhaXNTYW1lUm91dGVSZWNvcmQodG8sIGZyb20pIHx8ICFvbGRJbnN0YW5jZSkpICh0by5lbnRlckNhbGxiYWNrc1tuYW1lXSB8fCBbXSkuZm9yRWFjaCgoY2FsbGJhY2spID0+IGNhbGxiYWNrKGluc3RhbmNlKSk7XG5cdFx0fSwgeyBmbHVzaDogXCJwb3N0XCIgfSk7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IHJvdXRlID0gcm91dGVUb0Rpc3BsYXkudmFsdWU7XG5cdFx0XHRjb25zdCBjdXJyZW50TmFtZSA9IHByb3BzLm5hbWU7XG5cdFx0XHRjb25zdCBtYXRjaGVkUm91dGUgPSBtYXRjaGVkUm91dGVSZWYudmFsdWU7XG5cdFx0XHRjb25zdCBWaWV3Q29tcG9uZW50ID0gbWF0Y2hlZFJvdXRlICYmIG1hdGNoZWRSb3V0ZS5jb21wb25lbnRzW2N1cnJlbnROYW1lXTtcblx0XHRcdGlmICghVmlld0NvbXBvbmVudCkgcmV0dXJuIG5vcm1hbGl6ZVNsb3Qoc2xvdHMuZGVmYXVsdCwge1xuXHRcdFx0XHRDb21wb25lbnQ6IFZpZXdDb21wb25lbnQsXG5cdFx0XHRcdHJvdXRlXG5cdFx0XHR9KTtcblx0XHRcdGNvbnN0IHJvdXRlUHJvcHNPcHRpb24gPSBtYXRjaGVkUm91dGUucHJvcHNbY3VycmVudE5hbWVdO1xuXHRcdFx0Y29uc3Qgcm91dGVQcm9wcyA9IHJvdXRlUHJvcHNPcHRpb24gPyByb3V0ZVByb3BzT3B0aW9uID09PSB0cnVlID8gcm91dGUucGFyYW1zIDogdHlwZW9mIHJvdXRlUHJvcHNPcHRpb24gPT09IFwiZnVuY3Rpb25cIiA/IHJvdXRlUHJvcHNPcHRpb24ocm91dGUpIDogcm91dGVQcm9wc09wdGlvbiA6IG51bGw7XG5cdFx0XHRjb25zdCBvblZub2RlVW5tb3VudGVkID0gKHZub2RlKSA9PiB7XG5cdFx0XHRcdGlmICh2bm9kZS5jb21wb25lbnQuaXNVbm1vdW50ZWQpIG1hdGNoZWRSb3V0ZS5pbnN0YW5jZXNbY3VycmVudE5hbWVdID0gbnVsbDtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBjb21wb25lbnQgPSBoKFZpZXdDb21wb25lbnQsIGFzc2lnbih7fSwgcm91dGVQcm9wcywgYXR0cnMsIHtcblx0XHRcdFx0b25Wbm9kZVVubW91bnRlZCxcblx0XHRcdFx0cmVmOiB2aWV3UmVmXG5cdFx0XHR9KSk7XG5cdFx0XHRpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIGlzQnJvd3NlciAmJiBjb21wb25lbnQucmVmKSB7XG5cdFx0XHRcdGNvbnN0IGluZm8gPSB7XG5cdFx0XHRcdFx0ZGVwdGg6IGRlcHRoLnZhbHVlLFxuXHRcdFx0XHRcdG5hbWU6IG1hdGNoZWRSb3V0ZS5uYW1lLFxuXHRcdFx0XHRcdHBhdGg6IG1hdGNoZWRSb3V0ZS5wYXRoLFxuXHRcdFx0XHRcdG1ldGE6IG1hdGNoZWRSb3V0ZS5tZXRhXG5cdFx0XHRcdH07XG5cdFx0XHRcdChpc0FycmF5KGNvbXBvbmVudC5yZWYpID8gY29tcG9uZW50LnJlZi5tYXAoKHIpID0+IHIuaSkgOiBbY29tcG9uZW50LnJlZi5pXSkuZm9yRWFjaCgoaW5zdGFuY2UpID0+IHtcblx0XHRcdFx0XHRpbnN0YW5jZS5fX3Zydl9kZXZ0b29scyA9IGluZm87XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIG5vcm1hbGl6ZVNsb3Qoc2xvdHMuZGVmYXVsdCwge1xuXHRcdFx0XHRDb21wb25lbnQ6IGNvbXBvbmVudCxcblx0XHRcdFx0cm91dGVcblx0XHRcdH0pIHx8IGNvbXBvbmVudDtcblx0XHR9O1xuXHR9XG59KTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZVNsb3Qoc2xvdCwgZGF0YSkge1xuXHRpZiAoIXNsb3QpIHJldHVybiBudWxsO1xuXHRjb25zdCBzbG90Q29udGVudCA9IHNsb3QoZGF0YSk7XG5cdHJldHVybiBzbG90Q29udGVudC5sZW5ndGggPT09IDEgPyBzbG90Q29udGVudFswXSA6IHNsb3RDb250ZW50O1xufVxuLyoqXG4qIENvbXBvbmVudCB0byBkaXNwbGF5IHRoZSBjdXJyZW50IHJvdXRlIHRoZSB1c2VyIGlzIGF0LlxuKi9cbmNvbnN0IFJvdXRlclZpZXcgPSBSb3V0ZXJWaWV3SW1wbDtcbmZ1bmN0aW9uIHdhcm5EZXByZWNhdGVkVXNhZ2UoKSB7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG5cdGNvbnN0IHBhcmVudE5hbWUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnR5cGUubmFtZTtcblx0Y29uc3QgcGFyZW50U3ViVHJlZVR5cGUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUudHlwZTtcblx0aWYgKHBhcmVudE5hbWUgJiYgKHBhcmVudE5hbWUgPT09IFwiS2VlcEFsaXZlXCIgfHwgcGFyZW50TmFtZS5pbmNsdWRlcyhcIlRyYW5zaXRpb25cIikpICYmIHR5cGVvZiBwYXJlbnRTdWJUcmVlVHlwZSA9PT0gXCJvYmplY3RcIiAmJiBwYXJlbnRTdWJUcmVlVHlwZS5uYW1lID09PSBcIlJvdXRlclZpZXdcIikge1xuXHRcdGNvbnN0IGNvbXAgPSBwYXJlbnROYW1lID09PSBcIktlZXBBbGl2ZVwiID8gXCJrZWVwLWFsaXZlXCIgOiBcInRyYW5zaXRpb25cIjtcblx0XHR3YXJuJDEoYDxyb3V0ZXItdmlldz4gY2FuIG5vIGxvbmdlciBiZSB1c2VkIGRpcmVjdGx5IGluc2lkZSA8JHtjb21wfT4uXFxuVXNlIHNsb3QgcHJvcHMgaW5zdGVhZDpcXG5cXG48cm91dGVyLXZpZXcgdi1zbG90PVwieyBDb21wb25lbnQgfVwiPlxcbiAgPCR7Y29tcH0+XFxuICAgIDxjb21wb25lbnQgOmlzPVwiQ29tcG9uZW50XCIgLz5cXG4gIDwvJHtjb21wfT5cXG48L3JvdXRlci12aWV3PmApO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvcm91dGVyLnRzXG4vKipcbiogQ3JlYXRlcyBhIFJvdXRlciBpbnN0YW5jZSB0aGF0IGNhbiBiZSB1c2VkIGJ5IGEgVnVlIGFwcC5cbipcbiogQHBhcmFtIG9wdGlvbnMgLSB7QGxpbmsgUm91dGVyT3B0aW9uc31cbiovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXIob3B0aW9ucykge1xuXHRjb25zdCBtYXRjaGVyID0gY3JlYXRlUm91dGVyTWF0Y2hlcihvcHRpb25zLnJvdXRlcywgb3B0aW9ucyk7XG5cdGNvbnN0IHBhcnNlUXVlcnkkMSA9IG9wdGlvbnMucGFyc2VRdWVyeSB8fCBwYXJzZVF1ZXJ5O1xuXHRjb25zdCBzdHJpbmdpZnlRdWVyeSQxID0gb3B0aW9ucy5zdHJpbmdpZnlRdWVyeSB8fCBzdHJpbmdpZnlRdWVyeTtcblx0Y29uc3Qgcm91dGVySGlzdG9yeSA9IG9wdGlvbnMuaGlzdG9yeTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhcm91dGVySGlzdG9yeSkgdGhyb3cgbmV3IEVycm9yKFwiUHJvdmlkZSB0aGUgXFxcImhpc3RvcnlcXFwiIG9wdGlvbiB3aGVuIGNhbGxpbmcgXFxcImNyZWF0ZVJvdXRlcigpXFxcIjogaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2FwaS9pbnRlcmZhY2VzL1JvdXRlck9wdGlvbnMuaHRtbCNoaXN0b3J5XCIpO1xuXHRjb25zdCBiZWZvcmVHdWFyZHMgPSB1c2VDYWxsYmFja3MoKTtcblx0Y29uc3QgYmVmb3JlUmVzb2x2ZUd1YXJkcyA9IHVzZUNhbGxiYWNrcygpO1xuXHRjb25zdCBhZnRlckd1YXJkcyA9IHVzZUNhbGxiYWNrcygpO1xuXHRjb25zdCBjdXJyZW50Um91dGUgPSBzaGFsbG93UmVmKFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQpO1xuXHRsZXQgcGVuZGluZ0xvY2F0aW9uID0gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRDtcblx0aWYgKGlzQnJvd3NlciAmJiBvcHRpb25zLnNjcm9sbEJlaGF2aW9yICYmIFwic2Nyb2xsUmVzdG9yYXRpb25cIiBpbiBoaXN0b3J5KSBoaXN0b3J5LnNjcm9sbFJlc3RvcmF0aW9uID0gXCJtYW51YWxcIjtcblx0Y29uc3Qgbm9ybWFsaXplUGFyYW1zID0gYXBwbHlUb1BhcmFtcy5iaW5kKG51bGwsIChwYXJhbVZhbHVlKSA9PiBcIlwiICsgcGFyYW1WYWx1ZSk7XG5cdGNvbnN0IGVuY29kZVBhcmFtcyA9IGFwcGx5VG9QYXJhbXMuYmluZChudWxsLCBlbmNvZGVQYXJhbSk7XG5cdGNvbnN0IGRlY29kZVBhcmFtcyA9IGFwcGx5VG9QYXJhbXMuYmluZChudWxsLCBkZWNvZGUpO1xuXHRmdW5jdGlvbiBhZGRSb3V0ZShwYXJlbnRPclJvdXRlLCByb3V0ZSkge1xuXHRcdGxldCBwYXJlbnQ7XG5cdFx0bGV0IHJlY29yZDtcblx0XHRpZiAoaXNSb3V0ZU5hbWUocGFyZW50T3JSb3V0ZSkpIHtcblx0XHRcdHBhcmVudCA9IG1hdGNoZXIuZ2V0UmVjb3JkTWF0Y2hlcihwYXJlbnRPclJvdXRlKTtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIXBhcmVudCkgd2FybiQxKGBQYXJlbnQgcm91dGUgXCIke1N0cmluZyhwYXJlbnRPclJvdXRlKX1cIiBub3QgZm91bmQgd2hlbiBhZGRpbmcgY2hpbGQgcm91dGVgLCByb3V0ZSk7XG5cdFx0XHRyZWNvcmQgPSByb3V0ZTtcblx0XHR9IGVsc2UgcmVjb3JkID0gcGFyZW50T3JSb3V0ZTtcblx0XHRyZXR1cm4gbWF0Y2hlci5hZGRSb3V0ZShyZWNvcmQsIHBhcmVudCk7XG5cdH1cblx0ZnVuY3Rpb24gcmVtb3ZlUm91dGUobmFtZSkge1xuXHRcdGNvbnN0IHJlY29yZE1hdGNoZXIgPSBtYXRjaGVyLmdldFJlY29yZE1hdGNoZXIobmFtZSk7XG5cdFx0aWYgKHJlY29yZE1hdGNoZXIpIG1hdGNoZXIucmVtb3ZlUm91dGUocmVjb3JkTWF0Y2hlcik7XG5cdFx0ZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB3YXJuJDEoYENhbm5vdCByZW1vdmUgbm9uLWV4aXN0ZW50IHJvdXRlIFwiJHtTdHJpbmcobmFtZSl9XCJgKTtcblx0fVxuXHRmdW5jdGlvbiBnZXRSb3V0ZXMoKSB7XG5cdFx0cmV0dXJuIG1hdGNoZXIuZ2V0Um91dGVzKCkubWFwKChyb3V0ZU1hdGNoZXIpID0+IHJvdXRlTWF0Y2hlci5yZWNvcmQpO1xuXHR9XG5cdGZ1bmN0aW9uIGhhc1JvdXRlKG5hbWUpIHtcblx0XHRyZXR1cm4gISFtYXRjaGVyLmdldFJlY29yZE1hdGNoZXIobmFtZSk7XG5cdH1cblx0ZnVuY3Rpb24gcmVzb2x2ZShyYXdMb2NhdGlvbiwgY3VycmVudExvY2F0aW9uKSB7XG5cdFx0Y3VycmVudExvY2F0aW9uID0gYXNzaWduKHt9LCBjdXJyZW50TG9jYXRpb24gfHwgY3VycmVudFJvdXRlLnZhbHVlKTtcblx0XHRpZiAodHlwZW9mIHJhd0xvY2F0aW9uID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRjb25zdCBsb2NhdGlvbk5vcm1hbGl6ZWQgPSBwYXJzZVVSTChwYXJzZVF1ZXJ5JDEsIHJhd0xvY2F0aW9uLCBjdXJyZW50TG9jYXRpb24ucGF0aCk7XG5cdFx0XHRjb25zdCBtYXRjaGVkUm91dGUgPSBtYXRjaGVyLnJlc29sdmUoeyBwYXRoOiBsb2NhdGlvbk5vcm1hbGl6ZWQucGF0aCB9LCBjdXJyZW50TG9jYXRpb24pO1xuXHRcdFx0Y29uc3QgaHJlZiA9IHJvdXRlckhpc3RvcnkuY3JlYXRlSHJlZihsb2NhdGlvbk5vcm1hbGl6ZWQuZnVsbFBhdGgpO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAoaHJlZi5zdGFydHNXaXRoKFwiLy9cIikpIHdhcm4kMShgTG9jYXRpb24gXCIke3Jhd0xvY2F0aW9ufVwiIHJlc29sdmVkIHRvIFwiJHtocmVmfVwiLiBBIHJlc29sdmVkIGxvY2F0aW9uIGNhbm5vdCBzdGFydCB3aXRoIG11bHRpcGxlIHNsYXNoZXMuYCk7XG5cdFx0XHRcdGVsc2UgaWYgKCFtYXRjaGVkUm91dGUubWF0Y2hlZC5sZW5ndGgpIHdhcm4kMShgTm8gbWF0Y2ggZm91bmQgZm9yIGxvY2F0aW9uIHdpdGggcGF0aCBcIiR7cmF3TG9jYXRpb259XCJgKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBhc3NpZ24obG9jYXRpb25Ob3JtYWxpemVkLCBtYXRjaGVkUm91dGUsIHtcblx0XHRcdFx0cGFyYW1zOiBkZWNvZGVQYXJhbXMobWF0Y2hlZFJvdXRlLnBhcmFtcyksXG5cdFx0XHRcdHJlZGlyZWN0ZWRGcm9tOiB2b2lkIDAsXG5cdFx0XHRcdGhyZWZcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFpc1JvdXRlTG9jYXRpb24ocmF3TG9jYXRpb24pKSB7XG5cdFx0XHR3YXJuJDEoYHJvdXRlci5yZXNvbHZlKCkgd2FzIHBhc3NlZCBhbiBpbnZhbGlkIGxvY2F0aW9uLiBUaGlzIHdpbGwgZmFpbCBpbiBwcm9kdWN0aW9uLlxcbi0gTG9jYXRpb246YCwgcmF3TG9jYXRpb24pO1xuXHRcdFx0cmV0dXJuIHJlc29sdmUoe30pO1xuXHRcdH1cblx0XHRsZXQgbWF0Y2hlckxvY2F0aW9uO1xuXHRcdGlmIChyYXdMb2NhdGlvbi5wYXRoICE9IG51bGwpIHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgXCJwYXJhbXNcIiBpbiByYXdMb2NhdGlvbiAmJiAhKFwibmFtZVwiIGluIHJhd0xvY2F0aW9uKSAmJiBPYmplY3Qua2V5cyhyYXdMb2NhdGlvbi5wYXJhbXMpLmxlbmd0aCkgd2FybiQxKGBQYXRoIFwiJHtyYXdMb2NhdGlvbi5wYXRofVwiIHdhcyBwYXNzZWQgd2l0aCBwYXJhbXMgYnV0IHRoZXkgd2lsbCBiZSBpZ25vcmVkLiBVc2UgYSBuYW1lZCByb3V0ZSBhbG9uZ3NpZGUgcGFyYW1zIGluc3RlYWQuYCk7XG5cdFx0XHRtYXRjaGVyTG9jYXRpb24gPSBhc3NpZ24oe30sIHJhd0xvY2F0aW9uLCB7IHBhdGg6IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgcmF3TG9jYXRpb24ucGF0aCwgY3VycmVudExvY2F0aW9uLnBhdGgpLnBhdGggfSk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IHRhcmdldFBhcmFtcyA9IGFzc2lnbih7fSwgcmF3TG9jYXRpb24ucGFyYW1zKTtcblx0XHRcdGZvciAoY29uc3Qga2V5IGluIHRhcmdldFBhcmFtcykgaWYgKHRhcmdldFBhcmFtc1trZXldID09IG51bGwpIGRlbGV0ZSB0YXJnZXRQYXJhbXNba2V5XTtcblx0XHRcdG1hdGNoZXJMb2NhdGlvbiA9IGFzc2lnbih7fSwgcmF3TG9jYXRpb24sIHsgcGFyYW1zOiBlbmNvZGVQYXJhbXModGFyZ2V0UGFyYW1zKSB9KTtcblx0XHRcdGN1cnJlbnRMb2NhdGlvbi5wYXJhbXMgPSBlbmNvZGVQYXJhbXMoY3VycmVudExvY2F0aW9uLnBhcmFtcyk7XG5cdFx0fVxuXHRcdGNvbnN0IG1hdGNoZWRSb3V0ZSA9IG1hdGNoZXIucmVzb2x2ZShtYXRjaGVyTG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbik7XG5cdFx0Y29uc3QgaGFzaCA9IHJhd0xvY2F0aW9uLmhhc2ggfHwgXCJcIjtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGhhc2ggJiYgIWhhc2guc3RhcnRzV2l0aChcIiNcIikpIHdhcm4kMShgQSBcXGBoYXNoXFxgIHNob3VsZCBhbHdheXMgc3RhcnQgd2l0aCB0aGUgY2hhcmFjdGVyIFwiI1wiLiBSZXBsYWNlIFwiJHtoYXNofVwiIHdpdGggXCIjJHtoYXNofVwiLmApO1xuXHRcdG1hdGNoZWRSb3V0ZS5wYXJhbXMgPSBub3JtYWxpemVQYXJhbXMoZGVjb2RlUGFyYW1zKG1hdGNoZWRSb3V0ZS5wYXJhbXMpKTtcblx0XHRjb25zdCBmdWxsUGF0aCA9IHN0cmluZ2lmeVVSTChzdHJpbmdpZnlRdWVyeSQxLCBhc3NpZ24oe30sIHJhd0xvY2F0aW9uLCB7XG5cdFx0XHRoYXNoOiBlbmNvZGVIYXNoKGhhc2gpLFxuXHRcdFx0cGF0aDogbWF0Y2hlZFJvdXRlLnBhdGhcblx0XHR9KSk7XG5cdFx0Y29uc3QgaHJlZiA9IHJvdXRlckhpc3RvcnkuY3JlYXRlSHJlZihmdWxsUGF0aCk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0aWYgKGhyZWYuc3RhcnRzV2l0aChcIi8vXCIpKSB3YXJuJDEoYExvY2F0aW9uIFwiJHtyYXdMb2NhdGlvbn1cIiByZXNvbHZlZCB0byBcIiR7aHJlZn1cIi4gQSByZXNvbHZlZCBsb2NhdGlvbiBjYW5ub3Qgc3RhcnQgd2l0aCBtdWx0aXBsZSBzbGFzaGVzLmApO1xuXHRcdFx0ZWxzZSBpZiAoIW1hdGNoZWRSb3V0ZS5tYXRjaGVkLmxlbmd0aCkgd2FybiQxKGBObyBtYXRjaCBmb3VuZCBmb3IgbG9jYXRpb24gd2l0aCBwYXRoIFwiJHtyYXdMb2NhdGlvbi5wYXRoICE9IG51bGwgPyByYXdMb2NhdGlvbi5wYXRoIDogcmF3TG9jYXRpb259XCJgKTtcblx0XHR9XG5cdFx0cmV0dXJuIGFzc2lnbih7XG5cdFx0XHRmdWxsUGF0aCxcblx0XHRcdGhhc2gsXG5cdFx0XHRxdWVyeTogc3RyaW5naWZ5UXVlcnkkMSA9PT0gc3RyaW5naWZ5UXVlcnkgPyBub3JtYWxpemVRdWVyeShyYXdMb2NhdGlvbi5xdWVyeSkgOiByYXdMb2NhdGlvbi5xdWVyeSB8fCB7fVxuXHRcdH0sIG1hdGNoZWRSb3V0ZSwge1xuXHRcdFx0cmVkaXJlY3RlZEZyb206IHZvaWQgMCxcblx0XHRcdGhyZWZcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBsb2NhdGlvbkFzT2JqZWN0KHRvKSB7XG5cdFx0cmV0dXJuIHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIiA/IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgdG8sIGN1cnJlbnRSb3V0ZS52YWx1ZS5wYXRoKSA6IGFzc2lnbih7fSwgdG8pO1xuXHR9XG5cdGZ1bmN0aW9uIGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uKHRvLCBmcm9tKSB7XG5cdFx0aWYgKHBlbmRpbmdMb2NhdGlvbiAhPT0gdG8pIHJldHVybiBjcmVhdGVSb3V0ZXJFcnJvcig4LCB7XG5cdFx0XHRmcm9tLFxuXHRcdFx0dG9cblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBwdXNoKHRvKSB7XG5cdFx0cmV0dXJuIHB1c2hXaXRoUmVkaXJlY3QodG8pO1xuXHR9XG5cdGZ1bmN0aW9uIHJlcGxhY2UodG8pIHtcblx0XHRyZXR1cm4gcHVzaChhc3NpZ24obG9jYXRpb25Bc09iamVjdCh0byksIHsgcmVwbGFjZTogdHJ1ZSB9KSk7XG5cdH1cblx0ZnVuY3Rpb24gaGFuZGxlUmVkaXJlY3RSZWNvcmQodG8sIGZyb20pIHtcblx0XHRjb25zdCBsYXN0TWF0Y2hlZCA9IHRvLm1hdGNoZWRbdG8ubWF0Y2hlZC5sZW5ndGggLSAxXTtcblx0XHRpZiAobGFzdE1hdGNoZWQgJiYgbGFzdE1hdGNoZWQucmVkaXJlY3QpIHtcblx0XHRcdGNvbnN0IHsgcmVkaXJlY3QgfSA9IGxhc3RNYXRjaGVkO1xuXHRcdFx0bGV0IG5ld1RhcmdldExvY2F0aW9uID0gdHlwZW9mIHJlZGlyZWN0ID09PSBcImZ1bmN0aW9uXCIgPyByZWRpcmVjdCh0bywgZnJvbSkgOiByZWRpcmVjdDtcblx0XHRcdGlmICh0eXBlb2YgbmV3VGFyZ2V0TG9jYXRpb24gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24gPSBuZXdUYXJnZXRMb2NhdGlvbi5pbmNsdWRlcyhcIj9cIikgfHwgbmV3VGFyZ2V0TG9jYXRpb24uaW5jbHVkZXMoXCIjXCIpID8gbmV3VGFyZ2V0TG9jYXRpb24gPSBsb2NhdGlvbkFzT2JqZWN0KG5ld1RhcmdldExvY2F0aW9uKSA6IHsgcGF0aDogbmV3VGFyZ2V0TG9jYXRpb24gfTtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24ucGFyYW1zID0ge307XG5cdFx0XHR9XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIG5ld1RhcmdldExvY2F0aW9uLnBhdGggPT0gbnVsbCAmJiAhKFwibmFtZVwiIGluIG5ld1RhcmdldExvY2F0aW9uKSkge1xuXHRcdFx0XHR3YXJuJDEoYEludmFsaWQgcmVkaXJlY3QgZm91bmQ6XFxuJHtKU09OLnN0cmluZ2lmeShuZXdUYXJnZXRMb2NhdGlvbiwgbnVsbCwgMil9XFxuIHdoZW4gbmF2aWdhdGluZyB0byBcIiR7dG8uZnVsbFBhdGh9XCIuIEEgcmVkaXJlY3QgbXVzdCBjb250YWluIGEgbmFtZSBvciBwYXRoLiBUaGlzIHdpbGwgYnJlYWsgaW4gcHJvZHVjdGlvbi5gKTtcblx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCByZWRpcmVjdFwiKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBhc3NpZ24oe1xuXHRcdFx0XHRxdWVyeTogdG8ucXVlcnksXG5cdFx0XHRcdGhhc2g6IHRvLmhhc2gsXG5cdFx0XHRcdHBhcmFtczogbmV3VGFyZ2V0TG9jYXRpb24ucGF0aCAhPSBudWxsID8ge30gOiB0by5wYXJhbXNcblx0XHRcdH0sIG5ld1RhcmdldExvY2F0aW9uKTtcblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gcHVzaFdpdGhSZWRpcmVjdCh0bywgcmVkaXJlY3RlZEZyb20pIHtcblx0XHRjb25zdCB0YXJnZXRMb2NhdGlvbiA9IHBlbmRpbmdMb2NhdGlvbiA9IHJlc29sdmUodG8pO1xuXHRcdGNvbnN0IGZyb20gPSBjdXJyZW50Um91dGUudmFsdWU7XG5cdFx0Y29uc3QgZGF0YSA9IHRvLnN0YXRlO1xuXHRcdGNvbnN0IGZvcmNlID0gdG8uZm9yY2U7XG5cdFx0Y29uc3QgcmVwbGFjZSA9IHRvLnJlcGxhY2UgPT09IHRydWU7XG5cdFx0Y29uc3Qgc2hvdWxkUmVkaXJlY3QgPSBoYW5kbGVSZWRpcmVjdFJlY29yZCh0YXJnZXRMb2NhdGlvbiwgZnJvbSk7XG5cdFx0aWYgKHNob3VsZFJlZGlyZWN0KSByZXR1cm4gcHVzaFdpdGhSZWRpcmVjdChhc3NpZ24obG9jYXRpb25Bc09iamVjdChzaG91bGRSZWRpcmVjdCksIHtcblx0XHRcdHN0YXRlOiB0eXBlb2Ygc2hvdWxkUmVkaXJlY3QgPT09IFwib2JqZWN0XCIgPyBhc3NpZ24oe30sIGRhdGEsIHNob3VsZFJlZGlyZWN0LnN0YXRlKSA6IGRhdGEsXG5cdFx0XHRmb3JjZSxcblx0XHRcdHJlcGxhY2Vcblx0XHR9KSwgcmVkaXJlY3RlZEZyb20gfHwgdGFyZ2V0TG9jYXRpb24pO1xuXHRcdGNvbnN0IHRvTG9jYXRpb24gPSB0YXJnZXRMb2NhdGlvbjtcblx0XHR0b0xvY2F0aW9uLnJlZGlyZWN0ZWRGcm9tID0gcmVkaXJlY3RlZEZyb207XG5cdFx0bGV0IGZhaWx1cmU7XG5cdFx0aWYgKCFmb3JjZSAmJiBpc1NhbWVSb3V0ZUxvY2F0aW9uKHN0cmluZ2lmeVF1ZXJ5JDEsIGZyb20sIHRhcmdldExvY2F0aW9uKSkge1xuXHRcdFx0ZmFpbHVyZSA9IGNyZWF0ZVJvdXRlckVycm9yKDE2LCB7XG5cdFx0XHRcdHRvOiB0b0xvY2F0aW9uLFxuXHRcdFx0XHRmcm9tXG5cdFx0XHR9KTtcblx0XHRcdGhhbmRsZVNjcm9sbChmcm9tLCBmcm9tLCB0cnVlLCBmYWxzZSk7XG5cdFx0fVxuXHRcdHJldHVybiAoZmFpbHVyZSA/IFByb21pc2UucmVzb2x2ZShmYWlsdXJlKSA6IG5hdmlnYXRlKHRvTG9jYXRpb24sIGZyb20pKS5jYXRjaCgoZXJyb3IpID0+IGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyb3IpID8gaXNOYXZpZ2F0aW9uRmFpbHVyZShlcnJvciwgMikgPyBlcnJvciA6IG1hcmtBc1JlYWR5KGVycm9yKSA6IHRyaWdnZXJFcnJvcihlcnJvciwgdG9Mb2NhdGlvbiwgZnJvbSkpLnRoZW4oKGZhaWx1cmUpID0+IHtcblx0XHRcdGlmIChmYWlsdXJlKSB7XG5cdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIDIpKSB7XG5cdFx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBpc1NhbWVSb3V0ZUxvY2F0aW9uKHN0cmluZ2lmeVF1ZXJ5JDEsIHJlc29sdmUoZmFpbHVyZS50byksIHRvTG9jYXRpb24pICYmIHJlZGlyZWN0ZWRGcm9tICYmIChyZWRpcmVjdGVkRnJvbS5fY291bnQgPSByZWRpcmVjdGVkRnJvbS5fY291bnQgPyByZWRpcmVjdGVkRnJvbS5fY291bnQgKyAxIDogMSkgPiAzMCkge1xuXHRcdFx0XHRcdFx0d2FybiQxKGBEZXRlY3RlZCBhIHBvc3NpYmx5IGluZmluaXRlIHJlZGlyZWN0aW9uIGluIGEgbmF2aWdhdGlvbiBndWFyZCB3aGVuIGdvaW5nIGZyb20gXCIke2Zyb20uZnVsbFBhdGh9XCIgdG8gXCIke3RvTG9jYXRpb24uZnVsbFBhdGh9XCIuIEFib3J0aW5nIHRvIGF2b2lkIGEgU3RhY2sgT3ZlcmZsb3cuXFxuIEFyZSB5b3UgYWx3YXlzIHJldHVybmluZyBhIG5ldyBsb2NhdGlvbiB3aXRoaW4gYSBuYXZpZ2F0aW9uIGd1YXJkPyBUaGF0IHdvdWxkIGxlYWQgdG8gdGhpcyBlcnJvci4gT25seSByZXR1cm4gd2hlbiByZWRpcmVjdGluZyBvciBhYm9ydGluZywgdGhhdCBzaG91bGQgZml4IHRoaXMuIFRoaXMgbWlnaHQgYnJlYWsgaW4gcHJvZHVjdGlvbiBpZiBub3QgZml4ZWQuYCk7XG5cdFx0XHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkluZmluaXRlIHJlZGlyZWN0IGluIG5hdmlnYXRpb24gZ3VhcmRcIikpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gcHVzaFdpdGhSZWRpcmVjdChhc3NpZ24oeyByZXBsYWNlIH0sIGxvY2F0aW9uQXNPYmplY3QoZmFpbHVyZS50byksIHtcblx0XHRcdFx0XHRcdHN0YXRlOiB0eXBlb2YgZmFpbHVyZS50byA9PT0gXCJvYmplY3RcIiA/IGFzc2lnbih7fSwgZGF0YSwgZmFpbHVyZS50by5zdGF0ZSkgOiBkYXRhLFxuXHRcdFx0XHRcdFx0Zm9yY2Vcblx0XHRcdFx0XHR9KSwgcmVkaXJlY3RlZEZyb20gfHwgdG9Mb2NhdGlvbik7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBmYWlsdXJlID0gZmluYWxpemVOYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20sIHRydWUsIHJlcGxhY2UsIGRhdGEpO1xuXHRcdFx0dHJpZ2dlckFmdGVyRWFjaCh0b0xvY2F0aW9uLCBmcm9tLCBmYWlsdXJlKTtcblx0XHRcdHJldHVybiBmYWlsdXJlO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIEhlbHBlciB0byByZWplY3QgYW5kIHNraXAgYWxsIG5hdmlnYXRpb24gZ3VhcmRzIGlmIGEgbmV3IG5hdmlnYXRpb24gaGFwcGVuZWRcblx0KiBAcGFyYW0gdG9cblx0KiBAcGFyYW0gZnJvbVxuXHQqL1xuXHRmdW5jdGlvbiBjaGVja0NhbmNlbGVkTmF2aWdhdGlvbkFuZFJlamVjdCh0bywgZnJvbSkge1xuXHRcdGNvbnN0IGVycm9yID0gY2hlY2tDYW5jZWxlZE5hdmlnYXRpb24odG8sIGZyb20pO1xuXHRcdHJldHVybiBlcnJvciA/IFByb21pc2UucmVqZWN0KGVycm9yKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdGZ1bmN0aW9uIHJ1bldpdGhDb250ZXh0KGZuKSB7XG5cdFx0Y29uc3QgYXBwID0gaW5zdGFsbGVkQXBwcy52YWx1ZXMoKS5uZXh0KCkudmFsdWU7XG5cdFx0cmV0dXJuIGFwcCAmJiB0eXBlb2YgYXBwLnJ1bldpdGhDb250ZXh0ID09PSBcImZ1bmN0aW9uXCIgPyBhcHAucnVuV2l0aENvbnRleHQoZm4pIDogZm4oKTtcblx0fVxuXHRmdW5jdGlvbiBuYXZpZ2F0ZSh0bywgZnJvbSkge1xuXHRcdGxldCBndWFyZHM7XG5cdFx0Y29uc3QgW2xlYXZpbmdSZWNvcmRzLCB1cGRhdGluZ1JlY29yZHMsIGVudGVyaW5nUmVjb3Jkc10gPSBleHRyYWN0Q2hhbmdpbmdSZWNvcmRzKHRvLCBmcm9tKTtcblx0XHRndWFyZHMgPSBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyhsZWF2aW5nUmVjb3Jkcy5yZXZlcnNlKCksIFwiYmVmb3JlUm91dGVMZWF2ZVwiLCB0bywgZnJvbSk7XG5cdFx0Zm9yIChjb25zdCByZWNvcmQgb2YgbGVhdmluZ1JlY29yZHMpIHJlY29yZC5sZWF2ZUd1YXJkcy5mb3JFYWNoKChndWFyZCkgPT4ge1xuXHRcdFx0Z3VhcmRzLnB1c2goZ3VhcmRUb1Byb21pc2VGbihndWFyZCwgdG8sIGZyb20pKTtcblx0XHR9KTtcblx0XHRjb25zdCBjYW5jZWxlZE5hdmlnYXRpb25DaGVjayA9IGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uQW5kUmVqZWN0LmJpbmQobnVsbCwgdG8sIGZyb20pO1xuXHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IGd1YXJkIG9mIGJlZm9yZUd1YXJkcy5saXN0KCkpIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tKSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gZXh0cmFjdENvbXBvbmVudHNHdWFyZHModXBkYXRpbmdSZWNvcmRzLCBcImJlZm9yZVJvdXRlVXBkYXRlXCIsIHRvLCBmcm9tKTtcblx0XHRcdGZvciAoY29uc3QgcmVjb3JkIG9mIHVwZGF0aW5nUmVjb3JkcykgcmVjb3JkLnVwZGF0ZUd1YXJkcy5mb3JFYWNoKChndWFyZCkgPT4ge1xuXHRcdFx0XHRndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSkpO1xuXHRcdFx0fSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IHJlY29yZCBvZiBlbnRlcmluZ1JlY29yZHMpIGlmIChyZWNvcmQuYmVmb3JlRW50ZXIpIGlmIChpc0FycmF5KHJlY29yZC5iZWZvcmVFbnRlcikpIGZvciAoY29uc3QgYmVmb3JlRW50ZXIgb2YgcmVjb3JkLmJlZm9yZUVudGVyKSBndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGJlZm9yZUVudGVyLCB0bywgZnJvbSkpO1xuXHRcdFx0ZWxzZSBndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKHJlY29yZC5iZWZvcmVFbnRlciwgdG8sIGZyb20pKTtcblx0XHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcyk7XG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHR0by5tYXRjaGVkLmZvckVhY2goKHJlY29yZCkgPT4gcmVjb3JkLmVudGVyQ2FsbGJhY2tzID0ge30pO1xuXHRcdFx0Z3VhcmRzID0gZXh0cmFjdENvbXBvbmVudHNHdWFyZHMoZW50ZXJpbmdSZWNvcmRzLCBcImJlZm9yZVJvdXRlRW50ZXJcIiwgdG8sIGZyb20sIHJ1bldpdGhDb250ZXh0KTtcblx0XHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcyk7XG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHRndWFyZHMgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgZ3VhcmQgb2YgYmVmb3JlUmVzb2x2ZUd1YXJkcy5saXN0KCkpIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tKSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLmNhdGNoKChlcnIpID0+IGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyLCA4KSA/IGVyciA6IFByb21pc2UucmVqZWN0KGVycikpO1xuXHR9XG5cdGZ1bmN0aW9uIHRyaWdnZXJBZnRlckVhY2godG8sIGZyb20sIGZhaWx1cmUpIHtcblx0XHRhZnRlckd1YXJkcy5saXN0KCkuZm9yRWFjaCgoZ3VhcmQpID0+IHJ1bldpdGhDb250ZXh0KCgpID0+IGd1YXJkKHRvLCBmcm9tLCBmYWlsdXJlKSkpO1xuXHR9XG5cdC8qKlxuXHQqIC0gQ2xlYW5zIHVwIGFueSBuYXZpZ2F0aW9uIGd1YXJkc1xuXHQqIC0gQ2hhbmdlcyB0aGUgdXJsIGlmIG5lY2Vzc2FyeVxuXHQqIC0gQ2FsbHMgdGhlIHNjcm9sbEJlaGF2aW9yXG5cdCovXG5cdGZ1bmN0aW9uIGZpbmFsaXplTmF2aWdhdGlvbih0b0xvY2F0aW9uLCBmcm9tLCBpc1B1c2gsIHJlcGxhY2UsIGRhdGEpIHtcblx0XHRjb25zdCBlcnJvciA9IGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20pO1xuXHRcdGlmIChlcnJvcikgcmV0dXJuIGVycm9yO1xuXHRcdGNvbnN0IGlzRmlyc3ROYXZpZ2F0aW9uID0gZnJvbSA9PT0gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRDtcblx0XHRjb25zdCBzdGF0ZSA9ICFpc0Jyb3dzZXIgPyB7fSA6IGhpc3Rvcnkuc3RhdGU7XG5cdFx0aWYgKGlzUHVzaCkgaWYgKHJlcGxhY2UgfHwgaXNGaXJzdE5hdmlnYXRpb24pIHJvdXRlckhpc3RvcnkucmVwbGFjZSh0b0xvY2F0aW9uLmZ1bGxQYXRoLCBhc3NpZ24oeyBzY3JvbGw6IGlzRmlyc3ROYXZpZ2F0aW9uICYmIHN0YXRlICYmIHN0YXRlLnNjcm9sbCB9LCBkYXRhKSk7XG5cdFx0ZWxzZSByb3V0ZXJIaXN0b3J5LnB1c2godG9Mb2NhdGlvbi5mdWxsUGF0aCwgZGF0YSk7XG5cdFx0Y3VycmVudFJvdXRlLnZhbHVlID0gdG9Mb2NhdGlvbjtcblx0XHRoYW5kbGVTY3JvbGwodG9Mb2NhdGlvbiwgZnJvbSwgaXNQdXNoLCBpc0ZpcnN0TmF2aWdhdGlvbik7XG5cdFx0bWFya0FzUmVhZHkoKTtcblx0fVxuXHRsZXQgcmVtb3ZlSGlzdG9yeUxpc3RlbmVyO1xuXHRmdW5jdGlvbiBzZXR1cExpc3RlbmVycygpIHtcblx0XHRpZiAocmVtb3ZlSGlzdG9yeUxpc3RlbmVyKSByZXR1cm47XG5cdFx0cmVtb3ZlSGlzdG9yeUxpc3RlbmVyID0gcm91dGVySGlzdG9yeS5saXN0ZW4oKHRvLCBfZnJvbSwgaW5mbykgPT4ge1xuXHRcdFx0aWYgKCFyb3V0ZXIubGlzdGVuaW5nKSByZXR1cm47XG5cdFx0XHRjb25zdCB0b0xvY2F0aW9uID0gcmVzb2x2ZSh0byk7XG5cdFx0XHRjb25zdCBzaG91bGRSZWRpcmVjdCA9IGhhbmRsZVJlZGlyZWN0UmVjb3JkKHRvTG9jYXRpb24sIHJvdXRlci5jdXJyZW50Um91dGUudmFsdWUpO1xuXHRcdFx0aWYgKHNob3VsZFJlZGlyZWN0KSB7XG5cdFx0XHRcdHB1c2hXaXRoUmVkaXJlY3QoYXNzaWduKHNob3VsZFJlZGlyZWN0LCB7XG5cdFx0XHRcdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRcdFx0XHRmb3JjZTogdHJ1ZVxuXHRcdFx0XHR9KSwgdG9Mb2NhdGlvbikuY2F0Y2gobm9vcCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdHBlbmRpbmdMb2NhdGlvbiA9IHRvTG9jYXRpb247XG5cdFx0XHRjb25zdCBmcm9tID0gY3VycmVudFJvdXRlLnZhbHVlO1xuXHRcdFx0aWYgKGlzQnJvd3Nlcikgc2F2ZVNjcm9sbFBvc2l0aW9uKGdldFNjcm9sbEtleShmcm9tLmZ1bGxQYXRoLCBpbmZvLmRlbHRhKSwgY29tcHV0ZVNjcm9sbFBvc2l0aW9uKCkpO1xuXHRcdFx0bmF2aWdhdGUodG9Mb2NhdGlvbiwgZnJvbSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGVycm9yLCAxMikpIHJldHVybiBlcnJvcjtcblx0XHRcdFx0aWYgKGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyb3IsIDIpKSB7XG5cdFx0XHRcdFx0cHVzaFdpdGhSZWRpcmVjdChhc3NpZ24obG9jYXRpb25Bc09iamVjdChlcnJvci50byksIHsgZm9yY2U6IHRydWUgfSksIHRvTG9jYXRpb24pLnRoZW4oKGZhaWx1cmUpID0+IHtcblx0XHRcdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIDIwKSAmJiAhaW5mby5kZWx0YSAmJiBpbmZvLnR5cGUgPT09IFwicG9wXCIpIHJvdXRlckhpc3RvcnkuZ28oLTEsIGZhbHNlKTtcblx0XHRcdFx0XHR9KS5jYXRjaChub29wKTtcblx0XHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoaW5mby5kZWx0YSkgcm91dGVySGlzdG9yeS5nbygtaW5mby5kZWx0YSwgZmFsc2UpO1xuXHRcdFx0XHRyZXR1cm4gdHJpZ2dlckVycm9yKGVycm9yLCB0b0xvY2F0aW9uLCBmcm9tKTtcblx0XHRcdH0pLnRoZW4oKGZhaWx1cmUpID0+IHtcblx0XHRcdFx0ZmFpbHVyZSA9IGZhaWx1cmUgfHwgZmluYWxpemVOYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20sIGZhbHNlKTtcblx0XHRcdFx0aWYgKGZhaWx1cmUpIHtcblx0XHRcdFx0XHRpZiAoaW5mby5kZWx0YSAmJiAhaXNOYXZpZ2F0aW9uRmFpbHVyZShmYWlsdXJlLCA4KSkgcm91dGVySGlzdG9yeS5nbygtaW5mby5kZWx0YSwgZmFsc2UpO1xuXHRcdFx0XHRcdGVsc2UgaWYgKGluZm8udHlwZSA9PT0gXCJwb3BcIiAmJiBpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIDIwKSkgcm91dGVySGlzdG9yeS5nbygtMSwgZmFsc2UpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRyaWdnZXJBZnRlckVhY2godG9Mb2NhdGlvbiwgZnJvbSwgZmFpbHVyZSk7XG5cdFx0XHR9KS5jYXRjaChub29wKTtcblx0XHR9KTtcblx0fVxuXHRsZXQgcmVhZHlIYW5kbGVycyA9IHVzZUNhbGxiYWNrcygpO1xuXHRsZXQgZXJyb3JMaXN0ZW5lcnMgPSB1c2VDYWxsYmFja3MoKTtcblx0bGV0IHJlYWR5O1xuXHQvKipcblx0KiBUcmlnZ2VyIGVycm9yTGlzdGVuZXJzIGFkZGVkIHZpYSBvbkVycm9yIGFuZCB0aHJvd3MgdGhlIGVycm9yIGFzIHdlbGxcblx0KlxuXHQqIEBwYXJhbSBlcnJvciAtIGVycm9yIHRvIHRocm93XG5cdCogQHBhcmFtIHRvIC0gbG9jYXRpb24gd2Ugd2VyZSBuYXZpZ2F0aW5nIHRvIHdoZW4gdGhlIGVycm9yIGhhcHBlbmVkXG5cdCogQHBhcmFtIGZyb20gLSBsb2NhdGlvbiB3ZSB3ZXJlIG5hdmlnYXRpbmcgZnJvbSB3aGVuIHRoZSBlcnJvciBoYXBwZW5lZFxuXHQqIEByZXR1cm5zIHRoZSBlcnJvciBhcyBhIHJlamVjdGVkIHByb21pc2Vcblx0Ki9cblx0ZnVuY3Rpb24gdHJpZ2dlckVycm9yKGVycm9yLCB0bywgZnJvbSkge1xuXHRcdG1hcmtBc1JlYWR5KGVycm9yKTtcblx0XHRjb25zdCBsaXN0ID0gZXJyb3JMaXN0ZW5lcnMubGlzdCgpO1xuXHRcdGlmIChsaXN0Lmxlbmd0aCkgbGlzdC5mb3JFYWNoKChoYW5kbGVyKSA9PiBoYW5kbGVyKGVycm9yLCB0bywgZnJvbSkpO1xuXHRcdGVsc2Uge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgd2FybiQxKFwidW5jYXVnaHQgZXJyb3IgZHVyaW5nIHJvdXRlIG5hdmlnYXRpb246XCIpO1xuXHRcdFx0Y29uc29sZS5lcnJvcihlcnJvcik7XG5cdFx0fVxuXHRcdHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG5cdH1cblx0ZnVuY3Rpb24gaXNSZWFkeSgpIHtcblx0XHRpZiAocmVhZHkgJiYgY3VycmVudFJvdXRlLnZhbHVlICE9PSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHJlYWR5SGFuZGxlcnMuYWRkKFtyZXNvbHZlLCByZWplY3RdKTtcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBtYXJrQXNSZWFkeShlcnIpIHtcblx0XHRpZiAoIXJlYWR5KSB7XG5cdFx0XHRyZWFkeSA9ICFlcnI7XG5cdFx0XHRzZXR1cExpc3RlbmVycygpO1xuXHRcdFx0cmVhZHlIYW5kbGVycy5saXN0KCkuZm9yRWFjaCgoW3Jlc29sdmUsIHJlamVjdF0pID0+IGVyciA/IHJlamVjdChlcnIpIDogcmVzb2x2ZSgpKTtcblx0XHRcdHJlYWR5SGFuZGxlcnMucmVzZXQoKTtcblx0XHR9XG5cdFx0cmV0dXJuIGVycjtcblx0fVxuXHRmdW5jdGlvbiBoYW5kbGVTY3JvbGwodG8sIGZyb20sIGlzUHVzaCwgaXNGaXJzdE5hdmlnYXRpb24pIHtcblx0XHRjb25zdCB7IHNjcm9sbEJlaGF2aW9yIH0gPSBvcHRpb25zO1xuXHRcdGlmICghaXNCcm93c2VyIHx8ICFzY3JvbGxCZWhhdmlvcikgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdGNvbnN0IHNjcm9sbFBvc2l0aW9uID0gIWlzUHVzaCAmJiBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uKGdldFNjcm9sbEtleSh0by5mdWxsUGF0aCwgMCkpIHx8IChpc0ZpcnN0TmF2aWdhdGlvbiB8fCAhaXNQdXNoKSAmJiBoaXN0b3J5LnN0YXRlICYmIGhpc3Rvcnkuc3RhdGUuc2Nyb2xsIHx8IG51bGw7XG5cdFx0cmV0dXJuIG5leHRUaWNrKCkudGhlbigoKSA9PiBzY3JvbGxCZWhhdmlvcih0bywgZnJvbSwgc2Nyb2xsUG9zaXRpb24pKS50aGVuKChwb3NpdGlvbikgPT4gcG9zaXRpb24gJiYgc2Nyb2xsVG9Qb3NpdGlvbihwb3NpdGlvbikpLmNhdGNoKChlcnIpID0+IHRyaWdnZXJFcnJvcihlcnIsIHRvLCBmcm9tKSk7XG5cdH1cblx0Y29uc3QgZ28gPSAoZGVsdGEpID0+IHJvdXRlckhpc3RvcnkuZ28oZGVsdGEpO1xuXHRsZXQgc3RhcnRlZDtcblx0Y29uc3QgaW5zdGFsbGVkQXBwcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0IHJvdXRlciA9IHtcblx0XHRjdXJyZW50Um91dGUsXG5cdFx0bGlzdGVuaW5nOiB0cnVlLFxuXHRcdGFkZFJvdXRlLFxuXHRcdHJlbW92ZVJvdXRlLFxuXHRcdGNsZWFyUm91dGVzOiBtYXRjaGVyLmNsZWFyUm91dGVzLFxuXHRcdGhhc1JvdXRlLFxuXHRcdGdldFJvdXRlcyxcblx0XHRyZXNvbHZlLFxuXHRcdG9wdGlvbnMsXG5cdFx0cHVzaCxcblx0XHRyZXBsYWNlLFxuXHRcdGdvLFxuXHRcdGJhY2s6ICgpID0+IGdvKC0xKSxcblx0XHRmb3J3YXJkOiAoKSA9PiBnbygxKSxcblx0XHRiZWZvcmVFYWNoOiBiZWZvcmVHdWFyZHMuYWRkLFxuXHRcdGJlZm9yZVJlc29sdmU6IGJlZm9yZVJlc29sdmVHdWFyZHMuYWRkLFxuXHRcdGFmdGVyRWFjaDogYWZ0ZXJHdWFyZHMuYWRkLFxuXHRcdG9uRXJyb3I6IGVycm9yTGlzdGVuZXJzLmFkZCxcblx0XHRpc1JlYWR5LFxuXHRcdGluc3RhbGwoYXBwKSB7XG5cdFx0XHRhcHAuY29tcG9uZW50KFwiUm91dGVyTGlua1wiLCBSb3V0ZXJMaW5rKTtcblx0XHRcdGFwcC5jb21wb25lbnQoXCJSb3V0ZXJWaWV3XCIsIFJvdXRlclZpZXcpO1xuXHRcdFx0YXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLiRyb3V0ZXIgPSByb3V0ZXI7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoYXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLCBcIiRyb3V0ZVwiLCB7XG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdGdldDogKCkgPT4gdW5yZWYoY3VycmVudFJvdXRlKVxuXHRcdFx0fSk7XG5cdFx0XHRpZiAoaXNCcm93c2VyICYmICFzdGFydGVkICYmIGN1cnJlbnRSb3V0ZS52YWx1ZSA9PT0gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCkge1xuXHRcdFx0XHRzdGFydGVkID0gdHJ1ZTtcblx0XHRcdFx0cHVzaChyb3V0ZXJIaXN0b3J5LmxvY2F0aW9uKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgd2FybiQxKFwiVW5leHBlY3RlZCBlcnJvciB3aGVuIHN0YXJ0aW5nIHRoZSByb3V0ZXI6XCIsIGVycik7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcmVhY3RpdmVSb3V0ZSA9IHt9O1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCkgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlYWN0aXZlUm91dGUsIGtleSwge1xuXHRcdFx0XHRnZXQ6ICgpID0+IGN1cnJlbnRSb3V0ZS52YWx1ZVtrZXldLFxuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlXG5cdFx0XHR9KTtcblx0XHRcdGFwcC5wcm92aWRlKHJvdXRlcktleSwgcm91dGVyKTtcblx0XHRcdGFwcC5wcm92aWRlKHJvdXRlTG9jYXRpb25LZXksIHNoYWxsb3dSZWFjdGl2ZShyZWFjdGl2ZVJvdXRlKSk7XG5cdFx0XHRhcHAucHJvdmlkZShyb3V0ZXJWaWV3TG9jYXRpb25LZXksIGN1cnJlbnRSb3V0ZSk7XG5cdFx0XHRjb25zdCB1bm1vdW50QXBwID0gYXBwLnVubW91bnQ7XG5cdFx0XHRpbnN0YWxsZWRBcHBzLmFkZChhcHApO1xuXHRcdFx0YXBwLnVubW91bnQgPSBmdW5jdGlvbigpIHtcblx0XHRcdFx0aW5zdGFsbGVkQXBwcy5kZWxldGUoYXBwKTtcblx0XHRcdFx0aWYgKGluc3RhbGxlZEFwcHMuc2l6ZSA8IDEpIHtcblx0XHRcdFx0XHRwZW5kaW5nTG9jYXRpb24gPSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEO1xuXHRcdFx0XHRcdHJlbW92ZUhpc3RvcnlMaXN0ZW5lciAmJiByZW1vdmVIaXN0b3J5TGlzdGVuZXIoKTtcblx0XHRcdFx0XHRyZW1vdmVIaXN0b3J5TGlzdGVuZXIgPSBudWxsO1xuXHRcdFx0XHRcdGN1cnJlbnRSb3V0ZS52YWx1ZSA9IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQ7XG5cdFx0XHRcdFx0c3RhcnRlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdHJlYWR5ID0gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdFx0dW5tb3VudEFwcCgpO1xuXHRcdFx0fTtcblx0XHRcdGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykgJiYgaXNCcm93c2VyICYmIHRydWUpIGFkZERldnRvb2xzKGFwcCwgcm91dGVyLCBtYXRjaGVyKTtcblx0XHR9XG5cdH07XG5cdGZ1bmN0aW9uIHJ1bkd1YXJkUXVldWUoZ3VhcmRzKSB7XG5cdFx0cmV0dXJuIGd1YXJkcy5yZWR1Y2UoKHByb21pc2UsIGd1YXJkKSA9PiBwcm9taXNlLnRoZW4oKCkgPT4gcnVuV2l0aENvbnRleHQoZ3VhcmQpKSwgUHJvbWlzZS5yZXNvbHZlKCkpO1xuXHR9XG5cdHJldHVybiByb3V0ZXI7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE5hdmlnYXRpb25GYWlsdXJlVHlwZSwgUm91dGVyTGluaywgUm91dGVyVmlldywgU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCBhcyBTVEFSVF9MT0NBVElPTiwgY3JlYXRlTWVtb3J5SGlzdG9yeSwgY3JlYXRlUm91dGVyLCBjcmVhdGVSb3V0ZXJNYXRjaGVyLCBjcmVhdGVXZWJIYXNoSGlzdG9yeSwgY3JlYXRlV2ViSGlzdG9yeSwgaXNOYXZpZ2F0aW9uRmFpbHVyZSwgbG9hZFJvdXRlTG9jYXRpb24sIG1hdGNoZWRSb3V0ZUtleSwgb25CZWZvcmVSb3V0ZUxlYXZlLCBvbkJlZm9yZVJvdXRlVXBkYXRlLCBwYXJzZVF1ZXJ5LCByb3V0ZUxvY2F0aW9uS2V5LCByb3V0ZXJLZXksIHJvdXRlclZpZXdMb2NhdGlvbktleSwgc3RyaW5naWZ5UXVlcnksIHVzZUxpbmssIHVzZVJvdXRlLCB1c2VSb3V0ZXIsIHZpZXdEZXB0aEtleSB9O1xuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS0EsU0FBUyxLQUFLLGNBQWMsS0FBSyxXQUFXLEtBQUssdUJBQXVCLEtBQUssZUFBZSxLQUFLLFFBQVEsS0FBSyxrQkFBa0IsS0FBSyxtQkFBbUIsS0FBSyxTQUFTLEtBQUssV0FBVyxLQUFLLHVCQUF1QixLQUFLLGlCQUFpQixLQUFLLGNBQWMsS0FBSyxVQUFVLEtBQUsscUJBQXFCLEtBQUssTUFBTSxLQUFLLGlCQUFpQjtBQUNyVSxTQUFTLEtBQUsscUJBQXFCLEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxZQUFZLEtBQUssYUFBYSxLQUFLLGNBQWMsS0FBSywyQkFBMkIsS0FBSyxtQkFBbUIsS0FBSyxvQkFBb0IsS0FBSyxtQkFBbUIsS0FBSyxlQUFlLEtBQUssY0FBYyxLQUFLLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLGNBQWMsS0FBSyx3QkFBd0IsS0FBSyxrQkFBa0IsS0FBSyxRQUFRLEtBQUssV0FBVyxLQUFLLGdCQUFnQixLQUFLLHVCQUF1QixLQUFLLHdCQUF3QixLQUFLLG9CQUFvQixLQUFLLGFBQWEsS0FBSyx5QkFBeUIsS0FBSyxxQkFBcUIsS0FBSyxhQUFhLEtBQUssWUFBWSxLQUFLLGtCQUFrQixLQUFLLDJCQUEyQixLQUFLLGtCQUFrQjtBQUN0ckIsU0FBUyxVQUFVLGlCQUFpQixvQkFBb0IsR0FBRyxRQUFRLFVBQVUsU0FBUyxVQUFVLEtBQUssaUJBQWlCLFlBQVksT0FBTyxPQUFPLG1CQUFtQjtBQUVuSyxJQUFJLHFCQUFxQixNQUFNLFNBQVMsV0FBVyxPQUFPLFNBQVM7QUFNbkUsU0FBUyxzQkFBc0IsTUFBTUEsV0FBVTtBQUM5QyxRQUFNLEVBQUUsVUFBVSxRQUFRLEtBQUssSUFBSUE7QUFDbkMsUUFBTSxVQUFVLEtBQUssUUFBUSxHQUFHO0FBQ2hDLE1BQUksVUFBVSxJQUFJO0FBQ2pCLFFBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxPQUFPLEVBQUUsU0FBUztBQUNqRixRQUFJLGVBQWUsS0FBSyxNQUFNLFFBQVE7QUFDdEMsUUFBSSxhQUFhLENBQUMsTUFBTSxJQUFLLGdCQUFlLE1BQU07QUFDbEQsV0FBTyxVQUFVLGNBQWMsRUFBRTtBQUFBLEVBQ2xDO0FBQ0EsU0FBTyxVQUFVLFVBQVUsSUFBSSxJQUFJLFNBQVM7QUFDN0M7QUFDQSxTQUFTLG9CQUFvQixNQUFNLGNBQWMsaUJBQWlCLFNBQVM7QUFDMUUsTUFBSSxZQUFZLENBQUM7QUFDakIsTUFBSSxZQUFZLENBQUM7QUFDakIsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sa0JBQWtCLENBQUMsRUFBRSxNQUFNLE1BQU07QUFDdEMsVUFBTSxLQUFLLHNCQUFzQixNQUFNLFFBQVE7QUFDL0MsVUFBTSxPQUFPLGdCQUFnQjtBQUM3QixVQUFNLFlBQVksYUFBYTtBQUMvQixRQUFJLFFBQVE7QUFDWixRQUFJLE9BQU87QUFDVixzQkFBZ0IsUUFBUTtBQUN4QixtQkFBYSxRQUFRO0FBQ3JCLFVBQUksY0FBYyxlQUFlLE1BQU07QUFDdEMscUJBQWE7QUFDYjtBQUFBLE1BQ0Q7QUFDQSxjQUFRLFlBQVksTUFBTSxXQUFXLFVBQVUsV0FBVztBQUFBLElBQzNELE1BQU8sU0FBUSxFQUFFO0FBQ2pCLGNBQVUsUUFBUSxDQUFDLGFBQWE7QUFDL0IsZUFBUyxnQkFBZ0IsT0FBTyxNQUFNO0FBQUEsUUFDckM7QUFBQSxRQUNBLE1BQU07QUFBQSxRQUNOLFdBQVcsUUFBUSxRQUFRLElBQUksWUFBWSxTQUFTO0FBQUEsTUFDckQsQ0FBQztBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0Y7QUFDQSxXQUFTLGlCQUFpQjtBQUN6QixpQkFBYSxnQkFBZ0I7QUFBQSxFQUM5QjtBQUNBLFdBQVMsT0FBTyxVQUFVO0FBQ3pCLGNBQVUsS0FBSyxRQUFRO0FBQ3ZCLFVBQU0sV0FBVyxNQUFNO0FBQ3RCLFlBQU0sUUFBUSxVQUFVLFFBQVEsUUFBUTtBQUN4QyxVQUFJLFFBQVEsR0FBSSxXQUFVLE9BQU8sT0FBTyxDQUFDO0FBQUEsSUFDMUM7QUFDQSxjQUFVLEtBQUssUUFBUTtBQUN2QixXQUFPO0FBQUEsRUFDUjtBQUNBLFdBQVMsdUJBQXVCO0FBQy9CLFFBQUksU0FBUyxvQkFBb0IsVUFBVTtBQUMxQyxZQUFNLEVBQUUsU0FBQUMsU0FBUSxJQUFJO0FBQ3BCLFVBQUksQ0FBQ0EsU0FBUSxNQUFPO0FBQ3BCLE1BQUFBLFNBQVEsYUFBYSxPQUFPLENBQUMsR0FBR0EsU0FBUSxPQUFPLEVBQUUsUUFBUSxzQkFBc0IsRUFBRSxDQUFDLEdBQUcsRUFBRTtBQUFBLElBQ3hGO0FBQUEsRUFDRDtBQUNBLFdBQVMsVUFBVTtBQUNsQixlQUFXLFlBQVksVUFBVyxVQUFTO0FBQzNDLGdCQUFZLENBQUM7QUFDYixXQUFPLG9CQUFvQixZQUFZLGVBQWU7QUFDdEQsV0FBTyxvQkFBb0IsWUFBWSxvQkFBb0I7QUFDM0QsYUFBUyxvQkFBb0Isb0JBQW9CLG9CQUFvQjtBQUFBLEVBQ3RFO0FBQ0EsU0FBTyxpQkFBaUIsWUFBWSxlQUFlO0FBQ25ELFNBQU8saUJBQWlCLFlBQVksb0JBQW9CO0FBQ3hELFdBQVMsaUJBQWlCLG9CQUFvQixvQkFBb0I7QUFDbEUsU0FBTztBQUFBLElBQ047QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Q7QUFDRDtBQUlBLFNBQVMsV0FBVyxNQUFNLFNBQVMsU0FBUyxXQUFXLE9BQU8sZ0JBQWdCLE9BQU87QUFDcEYsU0FBTztBQUFBLElBQ047QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFVBQVUsT0FBTyxRQUFRO0FBQUEsSUFDekIsUUFBUSxnQkFBZ0Isc0JBQXNCLElBQUk7QUFBQSxFQUNuRDtBQUNEO0FBQ0EsU0FBUywwQkFBMEIsTUFBTTtBQUN4QyxRQUFNLEVBQUUsU0FBQUEsVUFBUyxVQUFBRCxVQUFTLElBQUk7QUFDOUIsUUFBTSxrQkFBa0IsRUFBRSxPQUFPLHNCQUFzQixNQUFNQSxTQUFRLEVBQUU7QUFDdkUsUUFBTSxlQUFlLEVBQUUsT0FBT0MsU0FBUSxNQUFNO0FBQzVDLE1BQUksQ0FBQyxhQUFhLE1BQU8sZ0JBQWUsZ0JBQWdCLE9BQU87QUFBQSxJQUM5RCxNQUFNO0FBQUEsSUFDTixTQUFTLGdCQUFnQjtBQUFBLElBQ3pCLFNBQVM7QUFBQSxJQUNULFVBQVVBLFNBQVEsU0FBUztBQUFBLElBQzNCLFVBQVU7QUFBQSxJQUNWLFFBQVE7QUFBQSxFQUNULEdBQUcsSUFBSTtBQUNQLFdBQVMsZUFBZSxJQUFJLE9BQU9DLFVBQVM7QUFVM0MsVUFBTSxZQUFZLEtBQUssUUFBUSxHQUFHO0FBQ2xDLFVBQU0sTUFBTSxZQUFZLE1BQU1GLFVBQVMsUUFBUSxTQUFTLGNBQWMsTUFBTSxJQUFJLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLG1CQUFtQixJQUFJLE9BQU87QUFDbkosUUFBSTtBQUNILE1BQUFDLFNBQVFDLFdBQVUsaUJBQWlCLFdBQVcsRUFBRSxPQUFPLElBQUksR0FBRztBQUM5RCxtQkFBYSxRQUFRO0FBQUEsSUFDdEIsU0FBUyxLQUFLO0FBQ2IsVUFBSSxLQUF1QyxRQUFPLGlDQUFpQyxHQUFHO0FBQUEsVUFDakYsU0FBUSxNQUFNLEdBQUc7QUFDdEIsTUFBQUYsVUFBU0UsV0FBVSxZQUFZLFFBQVEsRUFBRSxHQUFHO0FBQUEsSUFDN0M7QUFBQSxFQUNEO0FBQ0EsV0FBUyxRQUFRLElBQUksTUFBTTtBQUMxQixtQkFBZSxJQUFJLE9BQU8sQ0FBQyxHQUFHRCxTQUFRLE9BQU8sV0FBVyxhQUFhLE1BQU0sTUFBTSxJQUFJLGFBQWEsTUFBTSxTQUFTLElBQUksR0FBRyxNQUFNLEVBQUUsVUFBVSxhQUFhLE1BQU0sU0FBUyxDQUFDLEdBQUcsSUFBSTtBQUM5SyxvQkFBZ0IsUUFBUTtBQUFBLEVBQ3pCO0FBQ0EsV0FBUyxLQUFLLElBQUksTUFBTTtBQUN2QixVQUFNLGVBQWUsT0FBTyxDQUFDLEdBQUcsYUFBYSxPQUFPQSxTQUFRLE9BQU87QUFBQSxNQUNsRSxTQUFTO0FBQUEsTUFDVCxRQUFRLHNCQUFzQjtBQUFBLElBQy9CLENBQUM7QUFDRCxRQUE2QyxDQUFDQSxTQUFRLE1BQU8sUUFBTyxpVkFBaVY7QUFDclosbUJBQWUsYUFBYSxTQUFTLGNBQWMsSUFBSTtBQUN2RCxtQkFBZSxJQUFJLE9BQU8sQ0FBQyxHQUFHLFdBQVcsZ0JBQWdCLE9BQU8sSUFBSSxJQUFJLEdBQUcsRUFBRSxVQUFVLGFBQWEsV0FBVyxFQUFFLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDaEksb0JBQWdCLFFBQVE7QUFBQSxFQUN6QjtBQUNBLFNBQU87QUFBQSxJQUNOLFVBQVU7QUFBQSxJQUNWLE9BQU87QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLEVBQ0Q7QUFDRDtBQU1BLFNBQVMsaUJBQWlCLE1BQU07QUFDL0IsU0FBTyxjQUFjLElBQUk7QUFDekIsUUFBTSxvQkFBb0IsMEJBQTBCLElBQUk7QUFDeEQsUUFBTSxtQkFBbUIsb0JBQW9CLE1BQU0sa0JBQWtCLE9BQU8sa0JBQWtCLFVBQVUsa0JBQWtCLE9BQU87QUFDakksV0FBUyxHQUFHLE9BQU8sbUJBQW1CLE1BQU07QUFDM0MsUUFBSSxDQUFDLGlCQUFrQixrQkFBaUIsZUFBZTtBQUN2RCxZQUFRLEdBQUcsS0FBSztBQUFBLEVBQ2pCO0FBQ0EsUUFBTSxnQkFBZ0IsT0FBTztBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWSxXQUFXLEtBQUssTUFBTSxJQUFJO0FBQUEsRUFDdkMsR0FBRyxtQkFBbUIsZ0JBQWdCO0FBQ3RDLFNBQU8sZUFBZSxlQUFlLFlBQVk7QUFBQSxJQUNoRCxZQUFZO0FBQUEsSUFDWixLQUFLLE1BQU0sa0JBQWtCLFNBQVM7QUFBQSxFQUN2QyxDQUFDO0FBQ0QsU0FBTyxlQUFlLGVBQWUsU0FBUztBQUFBLElBQzdDLFlBQVk7QUFBQSxJQUNaLEtBQUssTUFBTSxrQkFBa0IsTUFBTTtBQUFBLEVBQ3BDLENBQUM7QUFDRCxTQUFPO0FBQ1I7QUEyQkEsU0FBUyxxQkFBcUIsTUFBTTtBQUNuQyxTQUFPLFNBQVMsT0FBTyxRQUFRLFNBQVMsV0FBVyxTQUFTLFNBQVM7QUFDckUsTUFBSSxDQUFDLEtBQUssU0FBUyxHQUFHLEVBQUcsU0FBUTtBQUNqQyxNQUE2QyxDQUFDLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxLQUFLLFNBQVMsR0FBRyxFQUFHLFFBQU87QUFBQSxHQUFzQyxJQUFJLGdCQUFnQixLQUFLLFFBQVEsUUFBUSxHQUFHLENBQUMsSUFBSTtBQUN4TCxTQUFPLGlCQUFpQixJQUFJO0FBQzdCO0FBVUEsU0FBUyxvQkFBb0IsT0FBTyxJQUFJO0FBQ3ZDLE1BQUksWUFBWSxDQUFDO0FBQ2pCLE1BQUksUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNyQixNQUFJLFdBQVc7QUFDZixTQUFPLGNBQWMsSUFBSTtBQUN6QixXQUFTLFlBQVlELFdBQVUsUUFBUSxDQUFDLEdBQUc7QUFDMUM7QUFDQSxRQUFJLGFBQWEsTUFBTSxPQUFRLE9BQU0sT0FBTyxRQUFRO0FBQ3BELFVBQU0sS0FBSyxDQUFDQSxXQUFVLEtBQUssQ0FBQztBQUFBLEVBQzdCO0FBQ0EsV0FBUyxpQkFBaUIsSUFBSSxNQUFNLEVBQUUsV0FBVyxNQUFNLEdBQUc7QUFDekQsVUFBTSxPQUFPO0FBQUEsTUFDWjtBQUFBLE1BQ0E7QUFBQSxNQUNBLE1BQU07QUFBQSxJQUNQO0FBQ0EsZUFBVyxZQUFZLFVBQVcsVUFBUyxJQUFJLE1BQU0sSUFBSTtBQUFBLEVBQzFEO0FBQ0EsUUFBTSxnQkFBZ0I7QUFBQSxJQUNyQixVQUFVO0FBQUEsSUFDVixPQUFPLENBQUM7QUFBQSxJQUNSO0FBQUEsSUFDQSxZQUFZLFdBQVcsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUN0QyxRQUFRLElBQUksT0FBTztBQUNsQixZQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzFCLGtCQUFZLElBQUksS0FBSztBQUFBLElBQ3RCO0FBQUEsSUFDQSxLQUFLLElBQUksT0FBTztBQUNmLGtCQUFZLElBQUksS0FBSztBQUFBLElBQ3RCO0FBQUEsSUFDQSxPQUFPLFVBQVU7QUFDaEIsZ0JBQVUsS0FBSyxRQUFRO0FBQ3ZCLGFBQU8sTUFBTTtBQUNaLGNBQU0sUUFBUSxVQUFVLFFBQVEsUUFBUTtBQUN4QyxZQUFJLFFBQVEsR0FBSSxXQUFVLE9BQU8sT0FBTyxDQUFDO0FBQUEsTUFDMUM7QUFBQSxJQUNEO0FBQUEsSUFDQSxVQUFVO0FBQ1Qsa0JBQVksQ0FBQztBQUNiLGNBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakIsaUJBQVc7QUFBQSxJQUNaO0FBQUEsSUFDQSxHQUFHLE9BQU8sZ0JBQWdCLE1BQU07QUFDL0IsWUFBTSxPQUFPLEtBQUs7QUFDbEIsWUFBTSxZQUFZLFFBQVEsSUFBSSxTQUFTO0FBQ3ZDLGlCQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxXQUFXLE9BQU8sTUFBTSxTQUFTLENBQUMsQ0FBQztBQUNuRSxVQUFJLGNBQWUsa0JBQWlCLEtBQUssVUFBVSxNQUFNO0FBQUEsUUFDeEQ7QUFBQSxRQUNBO0FBQUEsTUFDRCxDQUFDO0FBQUEsSUFDRjtBQUFBLEVBQ0Q7QUFDQSxTQUFPLGVBQWUsZUFBZSxZQUFZO0FBQUEsSUFDaEQsWUFBWTtBQUFBLElBQ1osS0FBSyxNQUFNLE1BQU0sUUFBUSxFQUFFLENBQUM7QUFBQSxFQUM3QixDQUFDO0FBQ0QsU0FBTyxlQUFlLGVBQWUsU0FBUztBQUFBLElBQzdDLFlBQVk7QUFBQSxJQUNaLEtBQUssTUFBTSxNQUFNLFFBQVEsRUFBRSxDQUFDO0FBQUEsRUFDN0IsQ0FBQztBQUNELFNBQU87QUFDUjtBQUdBLE1BQU0sYUFBYTtBQUFBLEVBQ2xCLE1BQU07QUFBQSxFQUNOLE9BQU87QUFDUjtBQUNBLE1BQU0saUJBQWlCO0FBQ3ZCLFNBQVMsYUFBYSxNQUFNO0FBQzNCLE1BQUksQ0FBQyxLQUFNLFFBQU8sQ0FBQyxDQUFDLENBQUM7QUFDckIsTUFBSSxTQUFTLElBQUssUUFBTyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3RDLE1BQUksQ0FBQyxLQUFLLFdBQVcsR0FBRyxFQUFHLE9BQU0sSUFBSSxNQUFNLE9BQXdDLHlDQUF5QyxJQUFJLGlCQUFpQixJQUFJLE9BQU8saUJBQWlCLElBQUksR0FBRztBQUNwTCxXQUFTLE1BQU0sU0FBUztBQUN2QixVQUFNLElBQUksTUFBTSxRQUFRLEtBQUssTUFBTSxNQUFNLE1BQU0sT0FBTyxFQUFFO0FBQUEsRUFDekQ7QUFDQSxNQUFJLFFBQVE7QUFDWixNQUFJLGdCQUFnQjtBQUNwQixRQUFNLFNBQVMsQ0FBQztBQUNoQixNQUFJO0FBQ0osV0FBUyxrQkFBa0I7QUFDMUIsUUFBSSxRQUFTLFFBQU8sS0FBSyxPQUFPO0FBQ2hDLGNBQVUsQ0FBQztBQUFBLEVBQ1o7QUFDQSxNQUFJLElBQUk7QUFDUixNQUFJO0FBQ0osTUFBSSxTQUFTO0FBQ2IsTUFBSSxXQUFXO0FBQ2YsV0FBUyxnQkFBZ0I7QUFDeEIsUUFBSSxDQUFDLE9BQVE7QUFDYixRQUFJLFVBQVUsRUFBRyxTQUFRLEtBQUs7QUFBQSxNQUM3QixNQUFNO0FBQUEsTUFDTixPQUFPO0FBQUEsSUFDUixDQUFDO0FBQUEsYUFDUSxVQUFVLEtBQUssVUFBVSxLQUFLLFVBQVUsR0FBRztBQUNuRCxVQUFJLFFBQVEsU0FBUyxNQUFNLFNBQVMsT0FBTyxTQUFTLEtBQU0sT0FBTSx1QkFBdUIsTUFBTSw4Q0FBOEM7QUFDM0ksY0FBUSxLQUFLO0FBQUEsUUFDWixNQUFNO0FBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsUUFDUixZQUFZLFNBQVMsT0FBTyxTQUFTO0FBQUEsUUFDckMsVUFBVSxTQUFTLE9BQU8sU0FBUztBQUFBLE1BQ3BDLENBQUM7QUFBQSxJQUNGLE1BQU8sT0FBTSxpQ0FBaUM7QUFDOUMsYUFBUztBQUFBLEVBQ1Y7QUFDQSxXQUFTLGtCQUFrQjtBQUMxQixjQUFVO0FBQUEsRUFDWDtBQUNBLFNBQU8sSUFBSSxLQUFLLFFBQVE7QUFDdkIsV0FBTyxLQUFLLEdBQUc7QUFDZixZQUFRLE9BQU87QUFBQSxNQUNkLEtBQUs7QUFDSixZQUFJLFNBQVMsTUFBTTtBQUNsQiwwQkFBZ0I7QUFDaEIsa0JBQVE7QUFBQSxRQUNULFdBQVcsU0FBUyxLQUFLO0FBQ3hCLGNBQUksT0FBUSxlQUFjO0FBQzFCLDBCQUFnQjtBQUFBLFFBQ2pCLFdBQVcsU0FBUyxLQUFLO0FBQ3hCLHdCQUFjO0FBQ2Qsa0JBQVE7QUFBQSxRQUNULE1BQU8saUJBQWdCO0FBQ3ZCO0FBQUEsTUFDRCxLQUFLO0FBQ0osd0JBQWdCO0FBQ2hCLGdCQUFRO0FBQ1I7QUFBQSxNQUNELEtBQUs7QUFDSixZQUFJLFNBQVMsSUFBSyxTQUFRO0FBQUEsaUJBQ2pCLGVBQWUsS0FBSyxJQUFJLEVBQUcsaUJBQWdCO0FBQUEsYUFDL0M7QUFDSix3QkFBYztBQUNkLGtCQUFRO0FBQ1IsY0FBSSxTQUFTLE9BQU8sU0FBUyxPQUFPLFNBQVMsSUFBSztBQUFBLFFBQ25EO0FBQ0E7QUFBQSxNQUNELEtBQUs7QUFDSixZQUFJLFNBQVMsSUFBSyxLQUFJLFNBQVMsU0FBUyxTQUFTLENBQUMsS0FBSyxLQUFNLFlBQVcsU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQUEsWUFDM0YsU0FBUTtBQUFBLFlBQ1IsYUFBWTtBQUNqQjtBQUFBLE1BQ0QsS0FBSztBQUNKLHNCQUFjO0FBQ2QsZ0JBQVE7QUFDUixZQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUyxJQUFLO0FBQ2xELG1CQUFXO0FBQ1g7QUFBQSxNQUNEO0FBQ0MsY0FBTSxlQUFlO0FBQ3JCO0FBQUEsSUFDRjtBQUFBLEVBQ0Q7QUFDQSxNQUFJLFVBQVUsRUFBRyxPQUFNLHVDQUF1QyxNQUFNLEdBQUc7QUFDdkUsZ0JBQWM7QUFDZCxrQkFBZ0I7QUFDaEIsU0FBTztBQUNSO0FBR0EsTUFBTSxxQkFBcUI7QUFDM0IsTUFBTSwyQkFBMkI7QUFBQSxFQUNoQyxXQUFXO0FBQUEsRUFDWCxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxLQUFLO0FBQ047QUFDQSxNQUFNLGlCQUFpQjtBQVF2QixTQUFTLGVBQWUsVUFBVSxjQUFjO0FBQy9DLFFBQU0sVUFBVSxPQUFPLENBQUMsR0FBRywwQkFBMEIsWUFBWTtBQUNqRSxRQUFNLFFBQVEsQ0FBQztBQUNmLE1BQUksVUFBVSxRQUFRLFFBQVEsTUFBTTtBQUNwQyxRQUFNLE9BQU8sQ0FBQztBQUNkLGFBQVcsV0FBVyxVQUFVO0FBQy9CLFVBQU0sZ0JBQWdCLFFBQVEsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQy9DLFFBQUksUUFBUSxVQUFVLENBQUMsUUFBUSxPQUFRLFlBQVc7QUFDbEQsYUFBUyxhQUFhLEdBQUcsYUFBYSxRQUFRLFFBQVEsY0FBYztBQUNuRSxZQUFNLFFBQVEsUUFBUSxVQUFVO0FBQ2hDLFVBQUksa0JBQWtCLE1BQU0sUUFBUSxZQUFZLE9BQU07QUFDdEQsVUFBSSxNQUFNLFNBQVMsR0FBRztBQUNyQixZQUFJLENBQUMsV0FBWSxZQUFXO0FBQzVCLG1CQUFXLE1BQU0sTUFBTSxRQUFRLGdCQUFnQixNQUFNO0FBQ3JELDJCQUFtQjtBQUFBLE1BQ3BCLFdBQVcsTUFBTSxTQUFTLEdBQUc7QUFDNUIsY0FBTSxFQUFFLE9BQU8sWUFBWSxVQUFVLE9BQU8sSUFBSTtBQUNoRCxhQUFLLEtBQUs7QUFBQSxVQUNULE1BQU07QUFBQSxVQUNOO0FBQUEsVUFDQTtBQUFBLFFBQ0QsQ0FBQztBQUNELGNBQU1HLE1BQUssU0FBUyxTQUFTO0FBQzdCLFlBQUlBLFFBQU8sb0JBQW9CO0FBQzlCLDZCQUFtQjtBQUNuQixjQUFJO0FBQ0gsZ0JBQUksT0FBTyxJQUFJQSxHQUFFLEdBQUc7QUFBQSxVQUNyQixTQUFTLEtBQUs7QUFDYixrQkFBTSxJQUFJLE1BQU0sb0NBQW9DLEtBQUssTUFBTUEsR0FBRSxRQUFRLElBQUksT0FBTztBQUFBLFVBQ3JGO0FBQUEsUUFDRDtBQUNBLFlBQUksYUFBYSxhQUFhLE9BQU9BLEdBQUUsV0FBV0EsR0FBRSxTQUFTLElBQUlBLEdBQUU7QUFDbkUsWUFBSSxDQUFDLFdBQVksY0FBYSxZQUFZLFFBQVEsU0FBUyxJQUFJLE9BQU8sVUFBVSxNQUFNLE1BQU07QUFDNUYsWUFBSSxTQUFVLGVBQWM7QUFDNUIsbUJBQVc7QUFDWCwyQkFBbUI7QUFDbkIsWUFBSSxTQUFVLG9CQUFtQjtBQUNqQyxZQUFJLFdBQVksb0JBQW1CO0FBQ25DLFlBQUlBLFFBQU8sS0FBTSxvQkFBbUI7QUFBQSxNQUNyQztBQUNBLG9CQUFjLEtBQUssZUFBZTtBQUFBLElBQ25DO0FBQ0EsVUFBTSxLQUFLLGFBQWE7QUFBQSxFQUN6QjtBQUNBLE1BQUksUUFBUSxVQUFVLFFBQVEsS0FBSztBQUNsQyxVQUFNLElBQUksTUFBTSxTQUFTO0FBQ3pCLFVBQU0sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLO0FBQUEsRUFDbEM7QUFDQSxNQUFJLENBQUMsUUFBUSxPQUFRLFlBQVc7QUFDaEMsTUFBSSxRQUFRLElBQUssWUFBVztBQUFBLFdBQ25CLFFBQVEsVUFBVSxDQUFDLFFBQVEsU0FBUyxHQUFHLEVBQUcsWUFBVztBQUM5RCxRQUFNLEtBQUssSUFBSSxPQUFPLFNBQVMsUUFBUSxZQUFZLEtBQUssR0FBRztBQUMzRCxXQUFTLE1BQU0sTUFBTTtBQUNwQixVQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUU7QUFDM0IsVUFBTSxTQUFTLENBQUM7QUFDaEIsUUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixhQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3RDLFlBQU0sUUFBUSxNQUFNLENBQUMsS0FBSztBQUMxQixZQUFNLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDdEIsYUFBTyxJQUFJLElBQUksSUFBSSxTQUFTLElBQUksYUFBYSxNQUFNLE1BQU0sR0FBRyxJQUFJO0FBQUEsSUFDakU7QUFDQSxXQUFPO0FBQUEsRUFDUjtBQUNBLFdBQVMsVUFBVSxRQUFRO0FBQzFCLFFBQUksT0FBTztBQUNYLFFBQUksdUJBQXVCO0FBQzNCLGVBQVcsV0FBVyxVQUFVO0FBQy9CLFVBQUksQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLFNBQVMsR0FBRyxFQUFHLFNBQVE7QUFDMUQsNkJBQXVCO0FBQ3ZCLGlCQUFXLFNBQVMsUUFBUyxLQUFJLE1BQU0sU0FBUyxFQUFHLFNBQVEsTUFBTTtBQUFBLGVBQ3hELE1BQU0sU0FBUyxHQUFHO0FBQzFCLGNBQU0sRUFBRSxPQUFPLFlBQVksU0FBUyxJQUFJO0FBQ3hDLGNBQU0sUUFBUSxTQUFTLFNBQVMsT0FBTyxLQUFLLElBQUk7QUFDaEQsWUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLFdBQVksT0FBTSxJQUFJLE1BQU0sbUJBQW1CLEtBQUssMkRBQTJEO0FBQ3RJLGNBQU0sT0FBTyxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJO0FBQ2hELFlBQUksQ0FBQyxLQUFNLEtBQUksVUFBVTtBQUN4QixjQUFJLFFBQVEsU0FBUyxFQUFHLEtBQUksS0FBSyxTQUFTLEdBQUcsRUFBRyxRQUFPLEtBQUssTUFBTSxHQUFHLEVBQUU7QUFBQSxjQUNsRSx3QkFBdUI7QUFBQSxRQUM3QixNQUFPLE9BQU0sSUFBSSxNQUFNLDJCQUEyQixLQUFLLEdBQUc7QUFDMUQsZ0JBQVE7QUFBQSxNQUNUO0FBQUEsSUFDRDtBQUNBLFdBQU8sUUFBUTtBQUFBLEVBQ2hCO0FBQ0EsU0FBTztBQUFBLElBQ047QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRDtBQUNEO0FBVUEsU0FBUyxrQkFBa0IsR0FBRyxHQUFHO0FBQ2hDLE1BQUksSUFBSTtBQUNSLFNBQU8sSUFBSSxFQUFFLFVBQVUsSUFBSSxFQUFFLFFBQVE7QUFDcEMsVUFBTSxPQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUN2QixRQUFJLEtBQU0sUUFBTztBQUNqQjtBQUFBLEVBQ0Q7QUFDQSxNQUFJLEVBQUUsU0FBUyxFQUFFLE9BQVEsUUFBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLENBQUMsTUFBTSxLQUFLLEtBQUs7QUFBQSxXQUM1RCxFQUFFLFNBQVMsRUFBRSxPQUFRLFFBQU8sRUFBRSxXQUFXLEtBQUssRUFBRSxDQUFDLE1BQU0sS0FBSyxJQUFJO0FBQ3pFLFNBQU87QUFDUjtBQVFBLFNBQVMsdUJBQXVCLEdBQUcsR0FBRztBQUNyQyxNQUFJLElBQUk7QUFDUixRQUFNLFNBQVMsRUFBRTtBQUNqQixRQUFNLFNBQVMsRUFBRTtBQUNqQixTQUFPLElBQUksT0FBTyxVQUFVLElBQUksT0FBTyxRQUFRO0FBQzlDLFVBQU0sT0FBTyxrQkFBa0IsT0FBTyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUM7QUFDbkQsUUFBSSxLQUFNLFFBQU87QUFDakI7QUFBQSxFQUNEO0FBQ0EsTUFBSSxLQUFLLElBQUksT0FBTyxTQUFTLE9BQU8sTUFBTSxNQUFNLEdBQUc7QUFDbEQsUUFBSSxvQkFBb0IsTUFBTSxFQUFHLFFBQU87QUFDeEMsUUFBSSxvQkFBb0IsTUFBTSxFQUFHLFFBQU87QUFBQSxFQUN6QztBQUNBLFNBQU8sT0FBTyxTQUFTLE9BQU87QUFDL0I7QUFPQSxTQUFTLG9CQUFvQixPQUFPO0FBQ25DLFFBQU0sT0FBTyxNQUFNLE1BQU0sU0FBUyxDQUFDO0FBQ25DLFNBQU8sTUFBTSxTQUFTLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQyxJQUFJO0FBQ3BEO0FBQ0EsTUFBTSwrQkFBK0I7QUFBQSxFQUNwQyxRQUFRO0FBQUEsRUFDUixLQUFLO0FBQUEsRUFDTCxXQUFXO0FBQ1o7QUFHQSxTQUFTLHlCQUF5QixRQUFRLFFBQVEsU0FBUztBQUMxRCxRQUFNLFNBQVMsZUFBZSxhQUFhLE9BQU8sSUFBSSxHQUFHLE9BQU87QUFDaEUsTUFBSSxNQUF1QztBQUMxQyxVQUFNLGVBQStCLG9CQUFJLElBQUk7QUFDN0MsZUFBVyxPQUFPLE9BQU8sTUFBTTtBQUM5QixVQUFJLGFBQWEsSUFBSSxJQUFJLElBQUksRUFBRyxRQUFPLHNDQUFzQyxJQUFJLElBQUksZUFBZSxPQUFPLElBQUksNERBQTREO0FBQzNLLG1CQUFhLElBQUksSUFBSSxJQUFJO0FBQUEsSUFDMUI7QUFBQSxFQUNEO0FBQ0EsUUFBTSxVQUFVLE9BQU8sUUFBUTtBQUFBLElBQzlCO0FBQUEsSUFDQTtBQUFBLElBQ0EsVUFBVSxDQUFDO0FBQUEsSUFDWCxPQUFPLENBQUM7QUFBQSxFQUNULENBQUM7QUFDRCxNQUFJLFFBQVE7QUFDWCxRQUFJLENBQUMsUUFBUSxPQUFPLFlBQVksQ0FBQyxPQUFPLE9BQU8sUUFBUyxRQUFPLFNBQVMsS0FBSyxPQUFPO0FBQUEsRUFDckY7QUFDQSxTQUFPO0FBQ1I7QUFVQSxTQUFTLG9CQUFvQixRQUFRLGVBQWU7QUFDbkQsUUFBTSxXQUFXLENBQUM7QUFDbEIsUUFBTSxhQUE2QixvQkFBSSxJQUFJO0FBQzNDLGtCQUFnQixhQUFhLDhCQUE4QixhQUFhO0FBQ3hFLFdBQVMsaUJBQWlCLE1BQU07QUFDL0IsV0FBTyxXQUFXLElBQUksSUFBSTtBQUFBLEVBQzNCO0FBQ0EsV0FBUyxTQUFTLFFBQVEsUUFBUSxnQkFBZ0I7QUFDakQsVUFBTSxZQUFZLENBQUM7QUFDbkIsVUFBTSx1QkFBdUIscUJBQXFCLE1BQU07QUFDeEQsUUFBSSxLQUF1QyxvQ0FBbUMsc0JBQXNCLE1BQU07QUFDMUcseUJBQXFCLFVBQVUsa0JBQWtCLGVBQWU7QUFDaEUsVUFBTSxVQUFVLGFBQWEsZUFBZSxNQUFNO0FBQ2xELFVBQU0sb0JBQW9CLENBQUMsb0JBQW9CO0FBQy9DLFFBQUksV0FBVyxRQUFRO0FBQ3RCLFlBQU0sVUFBVSxPQUFPLE9BQU8sVUFBVSxXQUFXLENBQUMsT0FBTyxLQUFLLElBQUksT0FBTztBQUMzRSxpQkFBVyxTQUFTLFFBQVMsbUJBQWtCLEtBQUsscUJBQXFCLE9BQU8sQ0FBQyxHQUFHLHNCQUFzQjtBQUFBLFFBQ3pHLFlBQVksaUJBQWlCLGVBQWUsT0FBTyxhQUFhLHFCQUFxQjtBQUFBLFFBQ3JGLE1BQU07QUFBQSxRQUNOLFNBQVMsaUJBQWlCLGVBQWUsU0FBUztBQUFBLE1BQ25ELENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDSjtBQUNBLFFBQUk7QUFDSixRQUFJO0FBQ0osZUFBVyxvQkFBb0IsbUJBQW1CO0FBQ2pELFlBQU0sRUFBRSxLQUFLLElBQUk7QUFDakIsVUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEtBQUs7QUFDOUIsY0FBTSxhQUFhLE9BQU8sT0FBTztBQUNqQyxjQUFNLGtCQUFrQixXQUFXLFdBQVcsU0FBUyxDQUFDLE1BQU0sTUFBTSxLQUFLO0FBQ3pFLHlCQUFpQixPQUFPLE9BQU8sT0FBTyxRQUFRLFFBQVEsa0JBQWtCO0FBQUEsTUFDekU7QUFDQSxVQUE2QyxpQkFBaUIsU0FBUyxJQUFLLE9BQU0sSUFBSSxNQUFNLHlLQUEySztBQUN2USxnQkFBVSx5QkFBeUIsa0JBQWtCLFFBQVEsT0FBTztBQUNwRSxVQUE2QyxVQUFVLEtBQUssQ0FBQyxNQUFNLElBQUssa0NBQWlDLFNBQVMsTUFBTTtBQUN4SCxVQUFJLGdCQUFnQjtBQUNuQix1QkFBZSxNQUFNLEtBQUssT0FBTztBQUNqQyxZQUFJLEtBQXVDLGlCQUFnQixnQkFBZ0IsT0FBTztBQUFBLE1BQ25GLE9BQU87QUFDTiwwQkFBa0IsbUJBQW1CO0FBQ3JDLFlBQUksb0JBQW9CLFFBQVMsaUJBQWdCLE1BQU0sS0FBSyxPQUFPO0FBQ25FLFlBQUksYUFBYSxPQUFPLFFBQVEsQ0FBQyxjQUFjLE9BQU8sR0FBRztBQUN4RCxjQUFJLEtBQXVDLHlCQUF3QixRQUFRLE1BQU07QUFDakYsc0JBQVksT0FBTyxJQUFJO0FBQUEsUUFDeEI7QUFBQSxNQUNEO0FBQ0EsVUFBSSxZQUFZLE9BQU8sRUFBRyxlQUFjLE9BQU87QUFDL0MsVUFBSSxxQkFBcUIsVUFBVTtBQUNsQyxjQUFNLFdBQVcscUJBQXFCO0FBQ3RDLGlCQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxJQUFLLFVBQVMsU0FBUyxDQUFDLEdBQUcsU0FBUyxrQkFBa0IsZUFBZSxTQUFTLENBQUMsQ0FBQztBQUFBLE1BQ3RIO0FBQ0EsdUJBQWlCLGtCQUFrQjtBQUFBLElBQ3BDO0FBQ0EsV0FBTyxrQkFBa0IsTUFBTTtBQUM5QixrQkFBWSxlQUFlO0FBQUEsSUFDNUIsSUFBSTtBQUFBLEVBQ0w7QUFDQSxXQUFTLFlBQVksWUFBWTtBQUNoQyxRQUFJLFlBQVksVUFBVSxHQUFHO0FBQzVCLFlBQU0sVUFBVSxXQUFXLElBQUksVUFBVTtBQUN6QyxVQUFJLFNBQVM7QUFDWixtQkFBVyxPQUFPLFVBQVU7QUFDNUIsaUJBQVMsT0FBTyxTQUFTLFFBQVEsT0FBTyxHQUFHLENBQUM7QUFDNUMsZ0JBQVEsU0FBUyxRQUFRLFdBQVc7QUFDcEMsZ0JBQVEsTUFBTSxRQUFRLFdBQVc7QUFBQSxNQUNsQztBQUFBLElBQ0QsT0FBTztBQUNOLFlBQU0sUUFBUSxTQUFTLFFBQVEsVUFBVTtBQUN6QyxVQUFJLFFBQVEsSUFBSTtBQUNmLGlCQUFTLE9BQU8sT0FBTyxDQUFDO0FBQ3hCLFlBQUksV0FBVyxPQUFPLEtBQU0sWUFBVyxPQUFPLFdBQVcsT0FBTyxJQUFJO0FBQ3BFLG1CQUFXLFNBQVMsUUFBUSxXQUFXO0FBQ3ZDLG1CQUFXLE1BQU0sUUFBUSxXQUFXO0FBQUEsTUFDckM7QUFBQSxJQUNEO0FBQUEsRUFDRDtBQUNBLFdBQVMsWUFBWTtBQUNwQixXQUFPO0FBQUEsRUFDUjtBQUNBLFdBQVMsY0FBYyxTQUFTO0FBQy9CLFVBQU0sUUFBUSxtQkFBbUIsU0FBUyxRQUFRO0FBQ2xELGFBQVMsT0FBTyxPQUFPLEdBQUcsT0FBTztBQUNqQyxRQUFJLFFBQVEsT0FBTyxRQUFRLENBQUMsY0FBYyxPQUFPLEVBQUcsWUFBVyxJQUFJLFFBQVEsT0FBTyxNQUFNLE9BQU87QUFBQSxFQUNoRztBQUNBLFdBQVMsUUFBUUgsV0FBVSxpQkFBaUI7QUFDM0MsUUFBSTtBQUNKLFFBQUksU0FBUyxDQUFDO0FBQ2QsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJLFVBQVVBLGFBQVlBLFVBQVMsTUFBTTtBQUN4QyxnQkFBVSxXQUFXLElBQUlBLFVBQVMsSUFBSTtBQUN0QyxVQUFJLENBQUMsUUFBUyxPQUFNLGtCQUFrQixHQUFHLEVBQUUsVUFBQUEsVUFBUyxDQUFDO0FBQ3JELFVBQUksTUFBdUM7QUFDMUMsY0FBTSxnQkFBZ0IsT0FBTyxLQUFLQSxVQUFTLFVBQVUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEtBQUssS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUM5SCxZQUFJLGNBQWMsUUFBUTtBQUN6QixnQkFBTSxjQUFjLENBQUMsUUFBUSxLQUFLLFVBQVUsY0FBYyxLQUFLLENBQUNJLFVBQVNBLFNBQVEsZ0JBQWdCLE1BQU07QUFDdkcsaUJBQU8sK0JBQStCLGNBQWMsS0FBSyxNQUFRLENBQUMsd0JBQXdCLGNBQWMsMklBQTJJLE1BQU0sOEdBQThHO0FBQUEsUUFDeFc7QUFBQSxNQUNEO0FBQ0EsYUFBTyxRQUFRLE9BQU87QUFDdEIsZUFBUyxPQUFPLFdBQVcsZ0JBQWdCLFFBQVEsUUFBUSxLQUFLLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxRQUFRLEVBQUUsT0FBTyxRQUFRLFNBQVMsUUFBUSxPQUFPLEtBQUssT0FBTyxDQUFDLE1BQU0sRUFBRSxRQUFRLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsR0FBR0osVUFBUyxVQUFVLFdBQVdBLFVBQVMsUUFBUSxRQUFRLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztBQUMzUSxhQUFPLFFBQVEsVUFBVSxNQUFNO0FBQUEsSUFDaEMsV0FBV0EsVUFBUyxRQUFRLE1BQU07QUFDakMsYUFBT0EsVUFBUztBQUNoQixVQUE2QyxDQUFDLEtBQUssV0FBVyxHQUFHLEVBQUcsUUFBTywyREFBMkQsSUFBSSxvREFBb0QsSUFBSSx3SEFBd0g7QUFDMVQsZ0JBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLEdBQUcsS0FBSyxJQUFJLENBQUM7QUFDOUMsVUFBSSxTQUFTO0FBQ1osaUJBQVMsUUFBUSxNQUFNLElBQUk7QUFDM0IsZUFBTyxRQUFRLE9BQU87QUFDdEIsZ0JBQVEsS0FBSyxRQUFRLENBQUMsUUFBUTtBQUM3QixjQUFJLElBQUksWUFBWSxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUcsUUFBTyxPQUFPLElBQUksSUFBSTtBQUFBLFFBQzlELENBQUM7QUFBQSxNQUNGO0FBQUEsSUFDRCxPQUFPO0FBQ04sZ0JBQVUsZ0JBQWdCLE9BQU8sV0FBVyxJQUFJLGdCQUFnQixJQUFJLElBQUksU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLEdBQUcsS0FBSyxnQkFBZ0IsSUFBSSxDQUFDO0FBQzVILFVBQUksQ0FBQyxRQUFTLE9BQU0sa0JBQWtCLEdBQUc7QUFBQSxRQUN4QyxVQUFBQTtBQUFBLFFBQ0E7QUFBQSxNQUNELENBQUM7QUFDRCxhQUFPLFFBQVEsT0FBTztBQUN0QixlQUFTLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQixRQUFRQSxVQUFTLE1BQU07QUFDM0QsYUFBTyxRQUFRLFVBQVUsTUFBTTtBQUFBLElBQ2hDO0FBQ0EsVUFBTSxVQUFVLENBQUM7QUFDakIsUUFBSSxnQkFBZ0I7QUFDcEIsV0FBTyxlQUFlO0FBQ3JCLGNBQVEsUUFBUSxjQUFjLE1BQU07QUFDcEMsc0JBQWdCLGNBQWM7QUFBQSxJQUMvQjtBQUNBLFdBQU87QUFBQSxNQUNOO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxNQUFNLGdCQUFnQixPQUFPO0FBQUEsSUFDOUI7QUFBQSxFQUNEO0FBQ0EsU0FBTyxRQUFRLENBQUMsVUFBVSxTQUFTLEtBQUssQ0FBQztBQUN6QyxXQUFTLGNBQWM7QUFDdEIsYUFBUyxTQUFTO0FBQ2xCLGVBQVcsTUFBTTtBQUFBLEVBQ2xCO0FBQ0EsU0FBTztBQUFBLElBQ047QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Q7QUFDRDtBQU9BLFNBQVMsV0FBVyxRQUFRLE1BQU07QUFDakMsUUFBTSxZQUFZLENBQUM7QUFDbkIsYUFBVyxPQUFPLEtBQU0sS0FBSSxPQUFPLE9BQVEsV0FBVSxHQUFHLElBQUksT0FBTyxHQUFHO0FBQ3RFLFNBQU87QUFDUjtBQU9BLFNBQVMscUJBQXFCLFFBQVE7QUFDckMsUUFBTSxhQUFhO0FBQUEsSUFDbEIsTUFBTSxPQUFPO0FBQUEsSUFDYixVQUFVLE9BQU87QUFBQSxJQUNqQixNQUFNLE9BQU87QUFBQSxJQUNiLE1BQU0sT0FBTyxRQUFRLENBQUM7QUFBQSxJQUN0QixTQUFTLE9BQU87QUFBQSxJQUNoQixhQUFhLE9BQU87QUFBQSxJQUNwQixPQUFPLHFCQUFxQixNQUFNO0FBQUEsSUFDbEMsVUFBVSxPQUFPLFlBQVksQ0FBQztBQUFBLElBQzlCLFdBQVcsQ0FBQztBQUFBLElBQ1osYUFBNkIsb0JBQUksSUFBSTtBQUFBLElBQ3JDLGNBQThCLG9CQUFJLElBQUk7QUFBQSxJQUN0QyxnQkFBZ0IsQ0FBQztBQUFBLElBQ2pCLFlBQVksZ0JBQWdCLFNBQVMsT0FBTyxjQUFjLE9BQU8sT0FBTyxhQUFhLEVBQUUsU0FBUyxPQUFPLFVBQVU7QUFBQSxFQUNsSDtBQUNBLFNBQU8sZUFBZSxZQUFZLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ3ZELFNBQU87QUFDUjtBQU1BLFNBQVMscUJBQXFCLFFBQVE7QUFDckMsUUFBTSxjQUFjLENBQUM7QUFDckIsUUFBTSxRQUFRLE9BQU8sU0FBUztBQUM5QixNQUFJLGVBQWUsT0FBUSxhQUFZLFVBQVU7QUFBQSxNQUM1QyxZQUFXLFFBQVEsT0FBTyxXQUFZLGFBQVksSUFBSSxJQUFJLE9BQU8sVUFBVSxXQUFXLE1BQU0sSUFBSSxJQUFJO0FBQ3pHLFNBQU87QUFDUjtBQUtBLFNBQVMsY0FBYyxRQUFRO0FBQzlCLFNBQU8sUUFBUTtBQUNkLFFBQUksT0FBTyxPQUFPLFFBQVMsUUFBTztBQUNsQyxhQUFTLE9BQU87QUFBQSxFQUNqQjtBQUNBLFNBQU87QUFDUjtBQU1BLFNBQVMsZ0JBQWdCLFNBQVM7QUFDakMsU0FBTyxRQUFRLE9BQU8sQ0FBQyxNQUFNLFdBQVcsT0FBTyxNQUFNLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQztBQUN0RTtBQUNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7QUFDMUIsU0FBTyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUU7QUFDN0U7QUFPQSxTQUFTLGdCQUFnQixHQUFHLEdBQUc7QUFDOUIsYUFBVyxPQUFPLEVBQUUsS0FBTSxLQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsRUFBRSxLQUFLLEtBQUssWUFBWSxLQUFLLE1BQU0sR0FBRyxDQUFDLEVBQUcsUUFBTyxPQUFPLFVBQVUsRUFBRSxPQUFPLElBQUksK0JBQStCLEVBQUUsT0FBTyxJQUFJLDJDQUEyQyxJQUFJLElBQUksR0FBRztBQUNqTyxhQUFXLE9BQU8sRUFBRSxLQUFNLEtBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxFQUFFLEtBQUssS0FBSyxZQUFZLEtBQUssTUFBTSxHQUFHLENBQUMsRUFBRyxRQUFPLE9BQU8sVUFBVSxFQUFFLE9BQU8sSUFBSSwrQkFBK0IsRUFBRSxPQUFPLElBQUksMkNBQTJDLElBQUksSUFBSSxHQUFHO0FBQ2xPO0FBT0EsU0FBUyxtQ0FBbUMsc0JBQXNCLFFBQVE7QUFDekUsTUFBSSxVQUFVLE9BQU8sT0FBTyxRQUFRLENBQUMscUJBQXFCLFFBQVEsQ0FBQyxxQkFBcUIsUUFBUSxxQkFBcUIsU0FBUyxXQUFXLEVBQUcsUUFBTyxvQkFBb0IsT0FBTyxPQUFPLE9BQU8sSUFBSSxDQUFDLHVSQUF1UjtBQUN6ZDtBQUNBLFNBQVMsd0JBQXdCLFFBQVEsUUFBUTtBQUNoRCxXQUFTLFdBQVcsUUFBUSxVQUFVLFdBQVcsU0FBUyxPQUFRLEtBQUksU0FBUyxPQUFPLFNBQVMsT0FBTyxLQUFNLE9BQU0sSUFBSSxNQUFNLGtCQUFrQixPQUFPLE9BQU8sSUFBSSxDQUFDLHlCQUF5QixXQUFXLFdBQVcsVUFBVSxZQUFZLHdIQUF3SDtBQUMvVjtBQUNBLFNBQVMsaUNBQWlDLFFBQVEsUUFBUTtBQUN6RCxhQUFXLE9BQU8sT0FBTyxLQUFNLEtBQUksQ0FBQyxPQUFPLEtBQUssS0FBSyxZQUFZLEtBQUssTUFBTSxHQUFHLENBQUMsRUFBRyxRQUFPLE9BQU8sa0JBQWtCLE9BQU8sT0FBTyxJQUFJLDJDQUEyQyxJQUFJLElBQUksb0JBQW9CLE9BQU8sT0FBTyxJQUFJLElBQUk7QUFDbk87QUFVQSxTQUFTLG1CQUFtQixTQUFTLFVBQVU7QUFDOUMsTUFBSSxRQUFRO0FBQ1osTUFBSSxRQUFRLFNBQVM7QUFDckIsU0FBTyxVQUFVLE9BQU87QUFDdkIsVUFBTSxNQUFNLFFBQVEsU0FBUztBQUM3QixRQUFJLHVCQUF1QixTQUFTLFNBQVMsR0FBRyxDQUFDLElBQUksRUFBRyxTQUFRO0FBQUEsUUFDM0QsU0FBUSxNQUFNO0FBQUEsRUFDcEI7QUFDQSxRQUFNLG9CQUFvQixxQkFBcUIsT0FBTztBQUN0RCxNQUFJLG1CQUFtQjtBQUN0QixZQUFRLFNBQVMsWUFBWSxtQkFBbUIsUUFBUSxDQUFDO0FBQ3pELFFBQTZDLFFBQVEsRUFBRyxRQUFPLDJCQUEyQixrQkFBa0IsT0FBTyxJQUFJLGlCQUFpQixRQUFRLE9BQU8sSUFBSSxHQUFHO0FBQUEsRUFDL0o7QUFDQSxTQUFPO0FBQ1I7QUFDQSxTQUFTLHFCQUFxQixTQUFTO0FBQ3RDLE1BQUksV0FBVztBQUNmLFNBQU8sV0FBVyxTQUFTLE9BQVEsS0FBSSxZQUFZLFFBQVEsS0FBSyx1QkFBdUIsU0FBUyxRQUFRLE1BQU0sRUFBRyxRQUFPO0FBQ3pIO0FBUUEsU0FBUyxZQUFZLEVBQUUsT0FBTyxHQUFHO0FBQ2hDLFNBQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxPQUFPLGNBQWMsT0FBTyxLQUFLLE9BQU8sVUFBVSxFQUFFLFVBQVUsT0FBTztBQUMvRjtBQVFBLFNBQVMsUUFBUSxPQUFPO0FBQ3ZCLFFBQU0sU0FBUyxPQUFPLFNBQVM7QUFDL0IsUUFBTSxlQUFlLE9BQU8sZ0JBQWdCO0FBQzVDLE1BQUksY0FBYztBQUNsQixNQUFJLGFBQWE7QUFDakIsUUFBTSxRQUFRLFNBQVMsTUFBTTtBQUM1QixVQUFNLEtBQUssTUFBTSxNQUFNLEVBQUU7QUFDekIsUUFBOEMsQ0FBQyxlQUFlLE9BQU8sWUFBYTtBQUNqRixVQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRyxLQUFJLFlBQWEsUUFBTztBQUFBLFFBQW1ELElBQUk7QUFBQSxpQkFBb0IsWUFBWTtBQUFBLFdBQWMsS0FBSztBQUFBLFVBQ3ZKLFFBQU87QUFBQSxRQUFtRCxJQUFJO0FBQUEsV0FBYyxLQUFLO0FBQ3RGLG1CQUFhO0FBQ2Isb0JBQWM7QUFBQSxJQUNmO0FBQ0EsV0FBTyxPQUFPLFFBQVEsRUFBRTtBQUFBLEVBQ3pCLENBQUM7QUFDRCxRQUFNLG9CQUFvQixTQUFTLE1BQU07QUFDeEMsVUFBTSxFQUFFLFFBQVEsSUFBSSxNQUFNO0FBQzFCLFVBQU0sRUFBRSxPQUFPLElBQUk7QUFDbkIsVUFBTSxlQUFlLFFBQVEsU0FBUyxDQUFDO0FBQ3ZDLFVBQU0saUJBQWlCLGFBQWE7QUFDcEMsUUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsT0FBUSxRQUFPO0FBQ3BELFVBQU0sUUFBUSxlQUFlLFVBQVUsa0JBQWtCLEtBQUssTUFBTSxZQUFZLENBQUM7QUFDakYsUUFBSSxRQUFRLEdBQUksUUFBTztBQUN2QixVQUFNLG1CQUFtQixnQkFBZ0IsUUFBUSxTQUFTLENBQUMsQ0FBQztBQUM1RCxXQUFPLFNBQVMsS0FBSyxnQkFBZ0IsWUFBWSxNQUFNLG9CQUFvQixlQUFlLGVBQWUsU0FBUyxDQUFDLEVBQUUsU0FBUyxtQkFBbUIsZUFBZSxVQUFVLGtCQUFrQixLQUFLLE1BQU0sUUFBUSxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFBQSxFQUNoTyxDQUFDO0FBQ0QsUUFBTSxXQUFXLFNBQVMsTUFBTSxrQkFBa0IsUUFBUSxNQUFNLGVBQWUsYUFBYSxRQUFRLE1BQU0sTUFBTSxNQUFNLENBQUM7QUFDdkgsUUFBTSxnQkFBZ0IsU0FBUyxNQUFNLGtCQUFrQixRQUFRLE1BQU0sa0JBQWtCLFVBQVUsYUFBYSxRQUFRLFNBQVMsS0FBSywwQkFBMEIsYUFBYSxRQUFRLE1BQU0sTUFBTSxNQUFNLENBQUM7QUFDdE0sV0FBUyxTQUFTLElBQUksQ0FBQyxHQUFHO0FBQ3pCLFFBQUksV0FBVyxDQUFDLEdBQUc7QUFDbEIsWUFBTSxJQUFJLE9BQU8sTUFBTSxNQUFNLE9BQU8sSUFBSSxZQUFZLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxDQUFDLEVBQUUsTUFBTSxJQUFJO0FBQ3ZGLFVBQUksTUFBTSxrQkFBa0IsT0FBTyxhQUFhLGVBQWUseUJBQXlCLFNBQVUsVUFBUyxvQkFBb0IsTUFBTSxDQUFDO0FBQ3RJLGFBQU87QUFBQSxJQUNSO0FBQ0EsV0FBTyxRQUFRLFFBQVE7QUFBQSxFQUN4QjtBQUNBLE1BQXdFLFdBQVc7QUFDbEYsVUFBTSxXQUFXLG1CQUFtQjtBQUNwQyxRQUFJLFVBQVU7QUFDYixZQUFNLHNCQUFzQjtBQUFBLFFBQzNCLE9BQU8sTUFBTTtBQUFBLFFBQ2IsVUFBVSxTQUFTO0FBQUEsUUFDbkIsZUFBZSxjQUFjO0FBQUEsUUFDN0IsT0FBTztBQUFBLE1BQ1I7QUFDQSxlQUFTLGlCQUFpQixTQUFTLGtCQUFrQixDQUFDO0FBQ3RELGVBQVMsZUFBZSxLQUFLLG1CQUFtQjtBQUNoRCxrQkFBWSxNQUFNO0FBQ2pCLDRCQUFvQixRQUFRLE1BQU07QUFDbEMsNEJBQW9CLFdBQVcsU0FBUztBQUN4Qyw0QkFBb0IsZ0JBQWdCLGNBQWM7QUFDbEQsNEJBQW9CLFFBQVEsZ0JBQWdCLE1BQU0sTUFBTSxFQUFFLENBQUMsSUFBSSxPQUFPO0FBQUEsTUFDdkUsR0FBRyxFQUFFLE9BQU8sT0FBTyxDQUFDO0FBQUEsSUFDckI7QUFBQSxFQUNEO0FBSUEsU0FBTztBQUFBLElBQ047QUFBQSxJQUNBLE1BQU0sU0FBUyxNQUFNLE1BQU0sTUFBTSxJQUFJO0FBQUEsSUFDckM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Q7QUFDRDtBQUNBLFNBQVMsa0JBQWtCLFFBQVE7QUFDbEMsU0FBTyxPQUFPLFdBQVcsSUFBSSxPQUFPLENBQUMsSUFBSTtBQUMxQztBQUlBLE1BQU0sYUFBNkIsZ0NBQWdCO0FBQUEsRUFDbEQsTUFBTTtBQUFBLEVBQ04sY0FBYyxFQUFFLE1BQU0sRUFBRTtBQUFBLEVBQ3hCLE9BQU87QUFBQSxJQUNOLElBQUk7QUFBQSxNQUNILE1BQU0sQ0FBQyxRQUFRLE1BQU07QUFBQSxNQUNyQixVQUFVO0FBQUEsSUFDWDtBQUFBLElBQ0EsU0FBUztBQUFBLElBQ1QsYUFBYTtBQUFBLElBQ2Isa0JBQWtCO0FBQUEsSUFDbEIsUUFBUTtBQUFBLElBQ1Isa0JBQWtCO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sU0FBUztBQUFBLElBQ1Y7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLEVBQ2pCO0FBQUEsRUFDQTtBQUFBLEVBQ0EsTUFBTSxPQUFPLEVBQUUsTUFBTSxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxTQUFTLFFBQVEsS0FBSyxDQUFDO0FBQ3BDLFVBQU0sRUFBRSxRQUFRLElBQUksT0FBTyxTQUFTO0FBQ3BDLFVBQU0sVUFBVSxTQUFTLE9BQU87QUFBQSxNQUMvQixDQUFDLGFBQWEsTUFBTSxhQUFhLFFBQVEsaUJBQWlCLG9CQUFvQixDQUFDLEdBQUcsS0FBSztBQUFBLE1BQ3ZGLENBQUMsYUFBYSxNQUFNLGtCQUFrQixRQUFRLHNCQUFzQiwwQkFBMEIsQ0FBQyxHQUFHLEtBQUs7QUFBQSxJQUN4RyxFQUFFO0FBQ0YsV0FBTyxNQUFNO0FBQ1osWUFBTSxXQUFXLE1BQU0sV0FBVyxrQkFBa0IsTUFBTSxRQUFRLElBQUksQ0FBQztBQUN2RSxhQUFPLE1BQU0sU0FBUyxXQUFXLEVBQUUsS0FBSztBQUFBLFFBQ3ZDLGdCQUFnQixLQUFLLGdCQUFnQixNQUFNLG1CQUFtQjtBQUFBLFFBQzlELE1BQU0sS0FBSztBQUFBLFFBQ1gsU0FBUyxLQUFLO0FBQUEsUUFDZCxPQUFPLFFBQVE7QUFBQSxNQUNoQixHQUFHLFFBQVE7QUFBQSxJQUNaO0FBQUEsRUFDRDtBQUNELENBQUM7QUFDRCxTQUFTLFdBQVcsR0FBRztBQUN0QixNQUFJLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsU0FBVTtBQUN0RCxNQUFJLEVBQUUsaUJBQWtCO0FBQ3hCLE1BQUksRUFBRSxXQUFXLFVBQVUsRUFBRSxXQUFXLEVBQUc7QUFDM0MsTUFBSSxFQUFFLGlCQUFpQixFQUFFLGNBQWMsY0FBYztBQUNwRCxVQUFNLFNBQVMsRUFBRSxjQUFjLGFBQWEsUUFBUTtBQUNwRCxRQUFJLGNBQWMsS0FBSyxNQUFNLEVBQUc7QUFBQSxFQUNqQztBQUNBLE1BQUksRUFBRSxlQUFnQixHQUFFLGVBQWU7QUFDdkMsU0FBTztBQUNSO0FBQ0EsU0FBUyxlQUFlLE9BQU8sT0FBTztBQUNyQyxhQUFXLE9BQU8sT0FBTztBQUN4QixVQUFNLGFBQWEsTUFBTSxHQUFHO0FBQzVCLFVBQU0sYUFBYSxNQUFNLEdBQUc7QUFDNUIsUUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNuQyxVQUFJLGVBQWUsV0FBWSxRQUFPO0FBQUEsSUFDdkMsV0FBVyxDQUFDLFFBQVEsVUFBVSxLQUFLLFdBQVcsV0FBVyxXQUFXLFVBQVUsV0FBVyxLQUFLLENBQUMsT0FBTyxNQUFNLE1BQU0sUUFBUSxNQUFNLFdBQVcsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU87QUFBQSxFQUNsSztBQUNBLFNBQU87QUFDUjtBQUtBLFNBQVMsZ0JBQWdCLFFBQVE7QUFDaEMsU0FBTyxTQUFTLE9BQU8sVUFBVSxPQUFPLFFBQVEsT0FBTyxPQUFPLE9BQU87QUFDdEU7QUFPQSxNQUFNLGVBQWUsQ0FBQyxXQUFXLGFBQWEsaUJBQWlCLGFBQWEsT0FBTyxZQUFZLGVBQWUsT0FBTyxjQUFjO0FBR25JLE1BQU0saUJBQWlDLGdDQUFnQjtBQUFBLEVBQ3RELE1BQU07QUFBQSxFQUNOLGNBQWM7QUFBQSxFQUNkLE9BQU87QUFBQSxJQUNOLE1BQU07QUFBQSxNQUNMLE1BQU07QUFBQSxNQUNOLFNBQVM7QUFBQSxJQUNWO0FBQUEsSUFDQSxPQUFPO0FBQUEsRUFDUjtBQUFBLEVBQ0EsY0FBYyxFQUFFLE1BQU0sRUFBRTtBQUFBLEVBQ3hCLE1BQU0sT0FBTyxFQUFFLE9BQU8sTUFBTSxHQUFHO0FBQzlCLElBQXlDLG9CQUFvQjtBQUM3RCxVQUFNLGdCQUFnQixPQUFPLHFCQUFxQjtBQUNsRCxVQUFNLGlCQUFpQixTQUFTLE1BQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4RSxVQUFNLGdCQUFnQixPQUFPLGNBQWMsQ0FBQztBQUM1QyxVQUFNLFFBQVEsU0FBUyxNQUFNO0FBQzVCLFVBQUksZUFBZSxNQUFNLGFBQWE7QUFDdEMsWUFBTSxFQUFFLFFBQVEsSUFBSSxlQUFlO0FBQ25DLFVBQUk7QUFDSixjQUFRLGVBQWUsUUFBUSxZQUFZLE1BQU0sQ0FBQyxhQUFhLFdBQVk7QUFDM0UsYUFBTztBQUFBLElBQ1IsQ0FBQztBQUNELFVBQU0sa0JBQWtCLFNBQVMsTUFBTSxlQUFlLE1BQU0sUUFBUSxNQUFNLEtBQUssQ0FBQztBQUNoRixZQUFRLGNBQWMsU0FBUyxNQUFNLE1BQU0sUUFBUSxDQUFDLENBQUM7QUFDckQsWUFBUSxpQkFBaUIsZUFBZTtBQUN4QyxZQUFRLHVCQUF1QixjQUFjO0FBQzdDLFVBQU0sVUFBVSxJQUFJO0FBQ3BCLFVBQU0sTUFBTTtBQUFBLE1BQ1gsUUFBUTtBQUFBLE1BQ1IsZ0JBQWdCO0FBQUEsTUFDaEIsTUFBTTtBQUFBLElBQ1AsR0FBRyxDQUFDLENBQUMsVUFBVSxJQUFJLElBQUksR0FBRyxDQUFDLGFBQWEsTUFBTSxRQUFRLE1BQU07QUFDM0QsVUFBSSxJQUFJO0FBQ1AsV0FBRyxVQUFVLElBQUksSUFBSTtBQUNyQixZQUFJLFFBQVEsU0FBUyxNQUFNLFlBQVksYUFBYSxhQUFhO0FBQ2hFLGNBQUksQ0FBQyxHQUFHLFlBQVksS0FBTSxJQUFHLGNBQWMsS0FBSztBQUNoRCxjQUFJLENBQUMsR0FBRyxhQUFhLEtBQU0sSUFBRyxlQUFlLEtBQUs7QUFBQSxRQUNuRDtBQUFBLE1BQ0Q7QUFDQSxVQUFJLFlBQVksT0FBTyxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsSUFBSSxJQUFJLEtBQUssQ0FBQyxhQUFjLEVBQUMsR0FBRyxlQUFlLElBQUksS0FBSyxDQUFDLEdBQUcsUUFBUSxDQUFDLGFBQWEsU0FBUyxRQUFRLENBQUM7QUFBQSxJQUN4SixHQUFHLEVBQUUsT0FBTyxPQUFPLENBQUM7QUFDcEIsV0FBTyxNQUFNO0FBQ1osWUFBTSxRQUFRLGVBQWU7QUFDN0IsWUFBTSxjQUFjLE1BQU07QUFDMUIsWUFBTSxlQUFlLGdCQUFnQjtBQUNyQyxZQUFNLGdCQUFnQixnQkFBZ0IsYUFBYSxXQUFXLFdBQVc7QUFDekUsVUFBSSxDQUFDLGNBQWUsUUFBTyxjQUFjLE1BQU0sU0FBUztBQUFBLFFBQ3ZELFdBQVc7QUFBQSxRQUNYO0FBQUEsTUFDRCxDQUFDO0FBQ0QsWUFBTSxtQkFBbUIsYUFBYSxNQUFNLFdBQVc7QUFDdkQsWUFBTSxhQUFhLG1CQUFtQixxQkFBcUIsT0FBTyxNQUFNLFNBQVMsT0FBTyxxQkFBcUIsYUFBYSxpQkFBaUIsS0FBSyxJQUFJLG1CQUFtQjtBQUN2SyxZQUFNLG1CQUFtQixDQUFDLFVBQVU7QUFDbkMsWUFBSSxNQUFNLFVBQVUsWUFBYSxjQUFhLFVBQVUsV0FBVyxJQUFJO0FBQUEsTUFDeEU7QUFDQSxZQUFNLFlBQVksRUFBRSxlQUFlLE9BQU8sQ0FBQyxHQUFHLFlBQVksT0FBTztBQUFBLFFBQ2hFO0FBQUEsUUFDQSxLQUFLO0FBQUEsTUFDTixDQUFDLENBQUM7QUFDRixVQUF3RSxhQUFhLFVBQVUsS0FBSztBQUNuRyxjQUFNLE9BQU87QUFBQSxVQUNaLE9BQU8sTUFBTTtBQUFBLFVBQ2IsTUFBTSxhQUFhO0FBQUEsVUFDbkIsTUFBTSxhQUFhO0FBQUEsVUFDbkIsTUFBTSxhQUFhO0FBQUEsUUFDcEI7QUFDQSxTQUFDLFFBQVEsVUFBVSxHQUFHLElBQUksVUFBVSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsYUFBYTtBQUNsRyxtQkFBUyxpQkFBaUI7QUFBQSxRQUMzQixDQUFDO0FBQUEsTUFDRjtBQUNBLGFBQU8sY0FBYyxNQUFNLFNBQVM7QUFBQSxRQUNuQyxXQUFXO0FBQUEsUUFDWDtBQUFBLE1BQ0QsQ0FBQyxLQUFLO0FBQUEsSUFDUDtBQUFBLEVBQ0Q7QUFDRCxDQUFDO0FBQ0QsU0FBUyxjQUFjLE1BQU0sTUFBTTtBQUNsQyxNQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLFFBQU0sY0FBYyxLQUFLLElBQUk7QUFDN0IsU0FBTyxZQUFZLFdBQVcsSUFBSSxZQUFZLENBQUMsSUFBSTtBQUNwRDtBQUlBLE1BQU0sYUFBYTtBQUNuQixTQUFTLHNCQUFzQjtBQUM5QixRQUFNLFdBQVcsbUJBQW1CO0FBQ3BDLFFBQU0sYUFBYSxTQUFTLFVBQVUsU0FBUyxPQUFPLEtBQUs7QUFDM0QsUUFBTSxvQkFBb0IsU0FBUyxVQUFVLFNBQVMsT0FBTyxXQUFXLFNBQVMsT0FBTyxRQUFRO0FBQ2hHLE1BQUksZUFBZSxlQUFlLGVBQWUsV0FBVyxTQUFTLFlBQVksTUFBTSxPQUFPLHNCQUFzQixZQUFZLGtCQUFrQixTQUFTLGNBQWM7QUFDeEssVUFBTSxPQUFPLGVBQWUsY0FBYyxlQUFlO0FBQ3pELFdBQU8sd0RBQXdELElBQUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUEyRSxJQUFJO0FBQUE7QUFBQSxNQUE2QyxJQUFJO0FBQUEsZUFBbUI7QUFBQSxFQUN2TjtBQUNEO0FBUUEsU0FBUyxhQUFhLFNBQVM7QUFDOUIsUUFBTSxVQUFVLG9CQUFvQixRQUFRLFFBQVEsT0FBTztBQUMzRCxRQUFNLGVBQWUsUUFBUSxjQUFjO0FBQzNDLFFBQU0sbUJBQW1CLFFBQVEsa0JBQWtCO0FBQ25ELFFBQU0sZ0JBQWdCLFFBQVE7QUFDOUIsTUFBNkMsQ0FBQyxjQUFlLE9BQU0sSUFBSSxNQUFNLGdJQUFvSTtBQUNqTixRQUFNLGVBQWUsYUFBYTtBQUNsQyxRQUFNLHNCQUFzQixhQUFhO0FBQ3pDLFFBQU0sY0FBYyxhQUFhO0FBQ2pDLFFBQU0sZUFBZSxXQUFXLHlCQUF5QjtBQUN6RCxNQUFJLGtCQUFrQjtBQUN0QixNQUFJLGFBQWEsUUFBUSxrQkFBa0IsdUJBQXVCLFFBQVMsU0FBUSxvQkFBb0I7QUFDdkcsUUFBTSxrQkFBa0IsY0FBYyxLQUFLLE1BQU0sQ0FBQyxlQUFlLEtBQUssVUFBVTtBQUNoRixRQUFNLGVBQWUsY0FBYyxLQUFLLE1BQU0sV0FBVztBQUN6RCxRQUFNLGVBQWUsY0FBYyxLQUFLLE1BQU0sTUFBTTtBQUNwRCxXQUFTLFNBQVMsZUFBZSxPQUFPO0FBQ3ZDLFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSSxZQUFZLGFBQWEsR0FBRztBQUMvQixlQUFTLFFBQVEsaUJBQWlCLGFBQWE7QUFDL0MsVUFBNkMsQ0FBQyxPQUFRLFFBQU8saUJBQWlCLE9BQU8sYUFBYSxDQUFDLHVDQUF1QyxLQUFLO0FBQy9JLGVBQVM7QUFBQSxJQUNWLE1BQU8sVUFBUztBQUNoQixXQUFPLFFBQVEsU0FBUyxRQUFRLE1BQU07QUFBQSxFQUN2QztBQUNBLFdBQVMsWUFBWSxNQUFNO0FBQzFCLFVBQU0sZ0JBQWdCLFFBQVEsaUJBQWlCLElBQUk7QUFDbkQsUUFBSSxjQUFlLFNBQVEsWUFBWSxhQUFhO0FBQUEsYUFDM0MsS0FBdUMsUUFBTyxxQ0FBcUMsT0FBTyxJQUFJLENBQUMsR0FBRztBQUFBLEVBQzVHO0FBQ0EsV0FBUyxZQUFZO0FBQ3BCLFdBQU8sUUFBUSxVQUFVLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixhQUFhLE1BQU07QUFBQSxFQUNyRTtBQUNBLFdBQVMsU0FBUyxNQUFNO0FBQ3ZCLFdBQU8sQ0FBQyxDQUFDLFFBQVEsaUJBQWlCLElBQUk7QUFBQSxFQUN2QztBQUNBLFdBQVMsUUFBUSxhQUFhLGlCQUFpQjtBQUM5QyxzQkFBa0IsT0FBTyxDQUFDLEdBQUcsbUJBQW1CLGFBQWEsS0FBSztBQUNsRSxRQUFJLE9BQU8sZ0JBQWdCLFVBQVU7QUFDcEMsWUFBTSxxQkFBcUIsU0FBUyxjQUFjLGFBQWEsZ0JBQWdCLElBQUk7QUFDbkYsWUFBTUssZ0JBQWUsUUFBUSxRQUFRLEVBQUUsTUFBTSxtQkFBbUIsS0FBSyxHQUFHLGVBQWU7QUFDdkYsWUFBTUMsUUFBTyxjQUFjLFdBQVcsbUJBQW1CLFFBQVE7QUFDakUsVUFBSSxNQUF1QztBQUMxQyxZQUFJQSxNQUFLLFdBQVcsSUFBSSxFQUFHLFFBQU8sYUFBYSxXQUFXLGtCQUFrQkEsS0FBSSw0REFBNEQ7QUFBQSxpQkFDbkksQ0FBQ0QsY0FBYSxRQUFRLE9BQVEsUUFBTywwQ0FBMEMsV0FBVyxHQUFHO0FBQUEsTUFDdkc7QUFDQSxhQUFPLE9BQU8sb0JBQW9CQSxlQUFjO0FBQUEsUUFDL0MsUUFBUSxhQUFhQSxjQUFhLE1BQU07QUFBQSxRQUN4QyxnQkFBZ0I7QUFBQSxRQUNoQixNQUFBQztBQUFBLE1BQ0QsQ0FBQztBQUFBLElBQ0Y7QUFDQSxRQUE2QyxDQUFDLGdCQUFnQixXQUFXLEdBQUc7QUFDM0UsYUFBTztBQUFBLGNBQStGLFdBQVc7QUFDakgsYUFBTyxRQUFRLENBQUMsQ0FBQztBQUFBLElBQ2xCO0FBQ0EsUUFBSTtBQUNKLFFBQUksWUFBWSxRQUFRLE1BQU07QUFDN0IsVUFBNkMsWUFBWSxlQUFlLEVBQUUsVUFBVSxnQkFBZ0IsT0FBTyxLQUFLLFlBQVksTUFBTSxFQUFFLE9BQVEsUUFBTyxTQUFTLFlBQVksSUFBSSxnR0FBZ0c7QUFDNVEsd0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGFBQWEsRUFBRSxNQUFNLFNBQVMsY0FBYyxZQUFZLE1BQU0sZ0JBQWdCLElBQUksRUFBRSxLQUFLLENBQUM7QUFBQSxJQUN4SCxPQUFPO0FBQ04sWUFBTSxlQUFlLE9BQU8sQ0FBQyxHQUFHLFlBQVksTUFBTTtBQUNsRCxpQkFBVyxPQUFPLGFBQWMsS0FBSSxhQUFhLEdBQUcsS0FBSyxLQUFNLFFBQU8sYUFBYSxHQUFHO0FBQ3RGLHdCQUFrQixPQUFPLENBQUMsR0FBRyxhQUFhLEVBQUUsUUFBUSxhQUFhLFlBQVksRUFBRSxDQUFDO0FBQ2hGLHNCQUFnQixTQUFTLGFBQWEsZ0JBQWdCLE1BQU07QUFBQSxJQUM3RDtBQUNBLFVBQU0sZUFBZSxRQUFRLFFBQVEsaUJBQWlCLGVBQWU7QUFDckUsVUFBTSxPQUFPLFlBQVksUUFBUTtBQUNqQyxRQUE2QyxRQUFRLENBQUMsS0FBSyxXQUFXLEdBQUcsRUFBRyxRQUFPLG1FQUFtRSxJQUFJLFlBQVksSUFBSSxJQUFJO0FBQzlLLGlCQUFhLFNBQVMsZ0JBQWdCLGFBQWEsYUFBYSxNQUFNLENBQUM7QUFDdkUsVUFBTSxXQUFXLGFBQWEsa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGFBQWE7QUFBQSxNQUN2RSxNQUFNLFdBQVcsSUFBSTtBQUFBLE1BQ3JCLE1BQU0sYUFBYTtBQUFBLElBQ3BCLENBQUMsQ0FBQztBQUNGLFVBQU0sT0FBTyxjQUFjLFdBQVcsUUFBUTtBQUM5QyxRQUFJLE1BQXVDO0FBQzFDLFVBQUksS0FBSyxXQUFXLElBQUksRUFBRyxRQUFPLGFBQWEsV0FBVyxrQkFBa0IsSUFBSSw0REFBNEQ7QUFBQSxlQUNuSSxDQUFDLGFBQWEsUUFBUSxPQUFRLFFBQU8sMENBQTBDLFlBQVksUUFBUSxPQUFPLFlBQVksT0FBTyxXQUFXLEdBQUc7QUFBQSxJQUNySjtBQUNBLFdBQU8sT0FBTztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsTUFDQSxPQUFPLHFCQUFxQixpQkFBaUIsZUFBZSxZQUFZLEtBQUssSUFBSSxZQUFZLFNBQVMsQ0FBQztBQUFBLElBQ3hHLEdBQUcsY0FBYztBQUFBLE1BQ2hCLGdCQUFnQjtBQUFBLE1BQ2hCO0FBQUEsSUFDRCxDQUFDO0FBQUEsRUFDRjtBQUNBLFdBQVMsaUJBQWlCLElBQUk7QUFDN0IsV0FBTyxPQUFPLE9BQU8sV0FBVyxTQUFTLGNBQWMsSUFBSSxhQUFhLE1BQU0sSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUU7QUFBQSxFQUNwRztBQUNBLFdBQVMsd0JBQXdCLElBQUksTUFBTTtBQUMxQyxRQUFJLG9CQUFvQixHQUFJLFFBQU8sa0JBQWtCLEdBQUc7QUFBQSxNQUN2RDtBQUFBLE1BQ0E7QUFBQSxJQUNELENBQUM7QUFBQSxFQUNGO0FBQ0EsV0FBUyxLQUFLLElBQUk7QUFDakIsV0FBTyxpQkFBaUIsRUFBRTtBQUFBLEVBQzNCO0FBQ0EsV0FBUyxRQUFRLElBQUk7QUFDcEIsV0FBTyxLQUFLLE9BQU8saUJBQWlCLEVBQUUsR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQSxFQUM1RDtBQUNBLFdBQVMscUJBQXFCLElBQUksTUFBTTtBQUN2QyxVQUFNLGNBQWMsR0FBRyxRQUFRLEdBQUcsUUFBUSxTQUFTLENBQUM7QUFDcEQsUUFBSSxlQUFlLFlBQVksVUFBVTtBQUN4QyxZQUFNLEVBQUUsU0FBUyxJQUFJO0FBQ3JCLFVBQUksb0JBQW9CLE9BQU8sYUFBYSxhQUFhLFNBQVMsSUFBSSxJQUFJLElBQUk7QUFDOUUsVUFBSSxPQUFPLHNCQUFzQixVQUFVO0FBQzFDLDRCQUFvQixrQkFBa0IsU0FBUyxHQUFHLEtBQUssa0JBQWtCLFNBQVMsR0FBRyxJQUFJLG9CQUFvQixpQkFBaUIsaUJBQWlCLElBQUksRUFBRSxNQUFNLGtCQUFrQjtBQUM3SywwQkFBa0IsU0FBUyxDQUFDO0FBQUEsTUFDN0I7QUFDQSxVQUE2QyxrQkFBa0IsUUFBUSxRQUFRLEVBQUUsVUFBVSxvQkFBb0I7QUFDOUcsZUFBTztBQUFBLEVBQTRCLEtBQUssVUFBVSxtQkFBbUIsTUFBTSxDQUFDLENBQUM7QUFBQSx1QkFBMEIsR0FBRyxRQUFRLDJFQUEyRTtBQUM3TCxjQUFNLElBQUksTUFBTSxrQkFBa0I7QUFBQSxNQUNuQztBQUNBLGFBQU8sT0FBTztBQUFBLFFBQ2IsT0FBTyxHQUFHO0FBQUEsUUFDVixNQUFNLEdBQUc7QUFBQSxRQUNULFFBQVEsa0JBQWtCLFFBQVEsT0FBTyxDQUFDLElBQUksR0FBRztBQUFBLE1BQ2xELEdBQUcsaUJBQWlCO0FBQUEsSUFDckI7QUFBQSxFQUNEO0FBQ0EsV0FBUyxpQkFBaUIsSUFBSSxnQkFBZ0I7QUFDN0MsVUFBTSxpQkFBaUIsa0JBQWtCLFFBQVEsRUFBRTtBQUNuRCxVQUFNLE9BQU8sYUFBYTtBQUMxQixVQUFNLE9BQU8sR0FBRztBQUNoQixVQUFNLFFBQVEsR0FBRztBQUNqQixVQUFNSixXQUFVLEdBQUcsWUFBWTtBQUMvQixVQUFNLGlCQUFpQixxQkFBcUIsZ0JBQWdCLElBQUk7QUFDaEUsUUFBSSxlQUFnQixRQUFPLGlCQUFpQixPQUFPLGlCQUFpQixjQUFjLEdBQUc7QUFBQSxNQUNwRixPQUFPLE9BQU8sbUJBQW1CLFdBQVcsT0FBTyxDQUFDLEdBQUcsTUFBTSxlQUFlLEtBQUssSUFBSTtBQUFBLE1BQ3JGO0FBQUEsTUFDQSxTQUFBQTtBQUFBLElBQ0QsQ0FBQyxHQUFHLGtCQUFrQixjQUFjO0FBQ3BDLFVBQU0sYUFBYTtBQUNuQixlQUFXLGlCQUFpQjtBQUM1QixRQUFJO0FBQ0osUUFBSSxDQUFDLFNBQVMsb0JBQW9CLGtCQUFrQixNQUFNLGNBQWMsR0FBRztBQUMxRSxnQkFBVSxrQkFBa0IsSUFBSTtBQUFBLFFBQy9CLElBQUk7QUFBQSxRQUNKO0FBQUEsTUFDRCxDQUFDO0FBQ0QsbUJBQWEsTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLElBQ3JDO0FBQ0EsWUFBUSxVQUFVLFFBQVEsUUFBUSxPQUFPLElBQUksU0FBUyxZQUFZLElBQUksR0FBRyxNQUFNLENBQUMsVUFBVSxvQkFBb0IsS0FBSyxJQUFJLG9CQUFvQixPQUFPLENBQUMsSUFBSSxRQUFRLFlBQVksS0FBSyxJQUFJLGFBQWEsT0FBTyxZQUFZLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQ0ssYUFBWTtBQUM1TyxVQUFJQSxVQUFTO0FBQ1osWUFBSSxvQkFBb0JBLFVBQVMsQ0FBQyxHQUFHO0FBQ3BDLGNBQTZDLG9CQUFvQixrQkFBa0IsUUFBUUEsU0FBUSxFQUFFLEdBQUcsVUFBVSxLQUFLLG1CQUFtQixlQUFlLFNBQVMsZUFBZSxTQUFTLGVBQWUsU0FBUyxJQUFJLEtBQUssSUFBSTtBQUM5TixtQkFBTyxtRkFBbUYsS0FBSyxRQUFRLFNBQVMsV0FBVyxRQUFRO0FBQUEsZ05BQXlQO0FBQzVYLG1CQUFPLFFBQVEsT0FBdUIsb0JBQUksTUFBTSx1Q0FBdUMsQ0FBQztBQUFBLFVBQ3pGO0FBQ0EsaUJBQU8saUJBQWlCLE9BQU8sRUFBRSxTQUFBTCxTQUFRLEdBQUcsaUJBQWlCSyxTQUFRLEVBQUUsR0FBRztBQUFBLFlBQ3pFLE9BQU8sT0FBT0EsU0FBUSxPQUFPLFdBQVcsT0FBTyxDQUFDLEdBQUcsTUFBTUEsU0FBUSxHQUFHLEtBQUssSUFBSTtBQUFBLFlBQzdFO0FBQUEsVUFDRCxDQUFDLEdBQUcsa0JBQWtCLFVBQVU7QUFBQSxRQUNqQztBQUFBLE1BQ0QsTUFBTyxDQUFBQSxXQUFVLG1CQUFtQixZQUFZLE1BQU0sTUFBTUwsVUFBUyxJQUFJO0FBQ3pFLHVCQUFpQixZQUFZLE1BQU1LLFFBQU87QUFDMUMsYUFBT0E7QUFBQSxJQUNSLENBQUM7QUFBQSxFQUNGO0FBTUEsV0FBUyxpQ0FBaUMsSUFBSSxNQUFNO0FBQ25ELFVBQU0sUUFBUSx3QkFBd0IsSUFBSSxJQUFJO0FBQzlDLFdBQU8sUUFBUSxRQUFRLE9BQU8sS0FBSyxJQUFJLFFBQVEsUUFBUTtBQUFBLEVBQ3hEO0FBQ0EsV0FBUyxlQUFlLElBQUk7QUFDM0IsVUFBTSxNQUFNLGNBQWMsT0FBTyxFQUFFLEtBQUssRUFBRTtBQUMxQyxXQUFPLE9BQU8sT0FBTyxJQUFJLG1CQUFtQixhQUFhLElBQUksZUFBZSxFQUFFLElBQUksR0FBRztBQUFBLEVBQ3RGO0FBQ0EsV0FBUyxTQUFTLElBQUksTUFBTTtBQUMzQixRQUFJO0FBQ0osVUFBTSxDQUFDLGdCQUFnQixpQkFBaUIsZUFBZSxJQUFJLHVCQUF1QixJQUFJLElBQUk7QUFDMUYsYUFBUyx3QkFBd0IsZUFBZSxRQUFRLEdBQUcsb0JBQW9CLElBQUksSUFBSTtBQUN2RixlQUFXLFVBQVUsZUFBZ0IsUUFBTyxZQUFZLFFBQVEsQ0FBQyxVQUFVO0FBQzFFLGFBQU8sS0FBSyxpQkFBaUIsT0FBTyxJQUFJLElBQUksQ0FBQztBQUFBLElBQzlDLENBQUM7QUFDRCxVQUFNLDBCQUEwQixpQ0FBaUMsS0FBSyxNQUFNLElBQUksSUFBSTtBQUNwRixXQUFPLEtBQUssdUJBQXVCO0FBQ25DLFdBQU8sY0FBYyxNQUFNLEVBQUUsS0FBSyxNQUFNO0FBQ3ZDLGVBQVMsQ0FBQztBQUNWLGlCQUFXLFNBQVMsYUFBYSxLQUFLLEVBQUcsUUFBTyxLQUFLLGlCQUFpQixPQUFPLElBQUksSUFBSSxDQUFDO0FBQ3RGLGFBQU8sS0FBSyx1QkFBdUI7QUFDbkMsYUFBTyxjQUFjLE1BQU07QUFBQSxJQUM1QixDQUFDLEVBQUUsS0FBSyxNQUFNO0FBQ2IsZUFBUyx3QkFBd0IsaUJBQWlCLHFCQUFxQixJQUFJLElBQUk7QUFDL0UsaUJBQVcsVUFBVSxnQkFBaUIsUUFBTyxhQUFhLFFBQVEsQ0FBQyxVQUFVO0FBQzVFLGVBQU8sS0FBSyxpQkFBaUIsT0FBTyxJQUFJLElBQUksQ0FBQztBQUFBLE1BQzlDLENBQUM7QUFDRCxhQUFPLEtBQUssdUJBQXVCO0FBQ25DLGFBQU8sY0FBYyxNQUFNO0FBQUEsSUFDNUIsQ0FBQyxFQUFFLEtBQUssTUFBTTtBQUNiLGVBQVMsQ0FBQztBQUNWLGlCQUFXLFVBQVUsZ0JBQWlCLEtBQUksT0FBTyxZQUFhLEtBQUksUUFBUSxPQUFPLFdBQVcsRUFBRyxZQUFXLGVBQWUsT0FBTyxZQUFhLFFBQU8sS0FBSyxpQkFBaUIsYUFBYSxJQUFJLElBQUksQ0FBQztBQUFBLFVBQzNMLFFBQU8sS0FBSyxpQkFBaUIsT0FBTyxhQUFhLElBQUksSUFBSSxDQUFDO0FBQy9ELGFBQU8sS0FBSyx1QkFBdUI7QUFDbkMsYUFBTyxjQUFjLE1BQU07QUFBQSxJQUM1QixDQUFDLEVBQUUsS0FBSyxNQUFNO0FBQ2IsU0FBRyxRQUFRLFFBQVEsQ0FBQyxXQUFXLE9BQU8saUJBQWlCLENBQUMsQ0FBQztBQUN6RCxlQUFTLHdCQUF3QixpQkFBaUIsb0JBQW9CLElBQUksTUFBTSxjQUFjO0FBQzlGLGFBQU8sS0FBSyx1QkFBdUI7QUFDbkMsYUFBTyxjQUFjLE1BQU07QUFBQSxJQUM1QixDQUFDLEVBQUUsS0FBSyxNQUFNO0FBQ2IsZUFBUyxDQUFDO0FBQ1YsaUJBQVcsU0FBUyxvQkFBb0IsS0FBSyxFQUFHLFFBQU8sS0FBSyxpQkFBaUIsT0FBTyxJQUFJLElBQUksQ0FBQztBQUM3RixhQUFPLEtBQUssdUJBQXVCO0FBQ25DLGFBQU8sY0FBYyxNQUFNO0FBQUEsSUFDNUIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRLG9CQUFvQixLQUFLLENBQUMsSUFBSSxNQUFNLFFBQVEsT0FBTyxHQUFHLENBQUM7QUFBQSxFQUMxRTtBQUNBLFdBQVMsaUJBQWlCLElBQUksTUFBTSxTQUFTO0FBQzVDLGdCQUFZLEtBQUssRUFBRSxRQUFRLENBQUMsVUFBVSxlQUFlLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxDQUFDLENBQUM7QUFBQSxFQUNyRjtBQU1BLFdBQVMsbUJBQW1CLFlBQVksTUFBTSxRQUFRTCxVQUFTLE1BQU07QUFDcEUsVUFBTSxRQUFRLHdCQUF3QixZQUFZLElBQUk7QUFDdEQsUUFBSSxNQUFPLFFBQU87QUFDbEIsVUFBTSxvQkFBb0IsU0FBUztBQUNuQyxVQUFNLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxRQUFRO0FBQ3hDLFFBQUksT0FBUSxLQUFJQSxZQUFXLGtCQUFtQixlQUFjLFFBQVEsV0FBVyxVQUFVLE9BQU8sRUFBRSxRQUFRLHFCQUFxQixTQUFTLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQztBQUFBLFFBQ3hKLGVBQWMsS0FBSyxXQUFXLFVBQVUsSUFBSTtBQUNqRCxpQkFBYSxRQUFRO0FBQ3JCLGlCQUFhLFlBQVksTUFBTSxRQUFRLGlCQUFpQjtBQUN4RCxnQkFBWTtBQUFBLEVBQ2I7QUFDQSxNQUFJO0FBQ0osV0FBUyxpQkFBaUI7QUFDekIsUUFBSSxzQkFBdUI7QUFDM0IsNEJBQXdCLGNBQWMsT0FBTyxDQUFDLElBQUksT0FBTyxTQUFTO0FBQ2pFLFVBQUksQ0FBQyxPQUFPLFVBQVc7QUFDdkIsWUFBTSxhQUFhLFFBQVEsRUFBRTtBQUM3QixZQUFNLGlCQUFpQixxQkFBcUIsWUFBWSxPQUFPLGFBQWEsS0FBSztBQUNqRixVQUFJLGdCQUFnQjtBQUNuQix5QkFBaUIsT0FBTyxnQkFBZ0I7QUFBQSxVQUN2QyxTQUFTO0FBQUEsVUFDVCxPQUFPO0FBQUEsUUFDUixDQUFDLEdBQUcsVUFBVSxFQUFFLE1BQU0sSUFBSTtBQUMxQjtBQUFBLE1BQ0Q7QUFDQSx3QkFBa0I7QUFDbEIsWUFBTSxPQUFPLGFBQWE7QUFDMUIsVUFBSSxVQUFXLG9CQUFtQixhQUFhLEtBQUssVUFBVSxLQUFLLEtBQUssR0FBRyxzQkFBc0IsQ0FBQztBQUNsRyxlQUFTLFlBQVksSUFBSSxFQUFFLE1BQU0sQ0FBQyxVQUFVO0FBQzNDLFlBQUksb0JBQW9CLE9BQU8sRUFBRSxFQUFHLFFBQU87QUFDM0MsWUFBSSxvQkFBb0IsT0FBTyxDQUFDLEdBQUc7QUFDbEMsMkJBQWlCLE9BQU8saUJBQWlCLE1BQU0sRUFBRSxHQUFHLEVBQUUsT0FBTyxLQUFLLENBQUMsR0FBRyxVQUFVLEVBQUUsS0FBSyxDQUFDLFlBQVk7QUFDbkcsZ0JBQUksb0JBQW9CLFNBQVMsRUFBRSxLQUFLLENBQUMsS0FBSyxTQUFTLEtBQUssU0FBUyxNQUFPLGVBQWMsR0FBRyxJQUFJLEtBQUs7QUFBQSxVQUN2RyxDQUFDLEVBQUUsTUFBTSxJQUFJO0FBQ2IsaUJBQU8sUUFBUSxPQUFPO0FBQUEsUUFDdkI7QUFDQSxZQUFJLEtBQUssTUFBTyxlQUFjLEdBQUcsQ0FBQyxLQUFLLE9BQU8sS0FBSztBQUNuRCxlQUFPLGFBQWEsT0FBTyxZQUFZLElBQUk7QUFBQSxNQUM1QyxDQUFDLEVBQUUsS0FBSyxDQUFDLFlBQVk7QUFDcEIsa0JBQVUsV0FBVyxtQkFBbUIsWUFBWSxNQUFNLEtBQUs7QUFDL0QsWUFBSSxTQUFTO0FBQ1osY0FBSSxLQUFLLFNBQVMsQ0FBQyxvQkFBb0IsU0FBUyxDQUFDLEVBQUcsZUFBYyxHQUFHLENBQUMsS0FBSyxPQUFPLEtBQUs7QUFBQSxtQkFDOUUsS0FBSyxTQUFTLFNBQVMsb0JBQW9CLFNBQVMsRUFBRSxFQUFHLGVBQWMsR0FBRyxJQUFJLEtBQUs7QUFBQSxRQUM3RjtBQUNBLHlCQUFpQixZQUFZLE1BQU0sT0FBTztBQUFBLE1BQzNDLENBQUMsRUFBRSxNQUFNLElBQUk7QUFBQSxJQUNkLENBQUM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxnQkFBZ0IsYUFBYTtBQUNqQyxNQUFJLGlCQUFpQixhQUFhO0FBQ2xDLE1BQUk7QUFTSixXQUFTLGFBQWEsT0FBTyxJQUFJLE1BQU07QUFDdEMsZ0JBQVksS0FBSztBQUNqQixVQUFNLE9BQU8sZUFBZSxLQUFLO0FBQ2pDLFFBQUksS0FBSyxPQUFRLE1BQUssUUFBUSxDQUFDLFlBQVksUUFBUSxPQUFPLElBQUksSUFBSSxDQUFDO0FBQUEsU0FDOUQ7QUFDSixVQUFJLEtBQXVDLFFBQU8seUNBQXlDO0FBQzNGLGNBQVEsTUFBTSxLQUFLO0FBQUEsSUFDcEI7QUFDQSxXQUFPLFFBQVEsT0FBTyxLQUFLO0FBQUEsRUFDNUI7QUFDQSxXQUFTLFVBQVU7QUFDbEIsUUFBSSxTQUFTLGFBQWEsVUFBVSwwQkFBMkIsUUFBTyxRQUFRLFFBQVE7QUFDdEYsV0FBTyxJQUFJLFFBQVEsQ0FBQ00sVUFBUyxXQUFXO0FBQ3ZDLG9CQUFjLElBQUksQ0FBQ0EsVUFBUyxNQUFNLENBQUM7QUFBQSxJQUNwQyxDQUFDO0FBQUEsRUFDRjtBQUNBLFdBQVMsWUFBWSxLQUFLO0FBQ3pCLFFBQUksQ0FBQyxPQUFPO0FBQ1gsY0FBUSxDQUFDO0FBQ1QscUJBQWU7QUFDZixvQkFBYyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUNBLFVBQVMsTUFBTSxNQUFNLE1BQU0sT0FBTyxHQUFHLElBQUlBLFNBQVEsQ0FBQztBQUNqRixvQkFBYyxNQUFNO0FBQUEsSUFDckI7QUFDQSxXQUFPO0FBQUEsRUFDUjtBQUNBLFdBQVMsYUFBYSxJQUFJLE1BQU0sUUFBUSxtQkFBbUI7QUFDMUQsVUFBTSxFQUFFLGVBQWUsSUFBSTtBQUMzQixRQUFJLENBQUMsYUFBYSxDQUFDLGVBQWdCLFFBQU8sUUFBUSxRQUFRO0FBQzFELFVBQU0saUJBQWlCLENBQUMsVUFBVSx1QkFBdUIsYUFBYSxHQUFHLFVBQVUsQ0FBQyxDQUFDLE1BQU0scUJBQXFCLENBQUMsV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNLFVBQVU7QUFDckssV0FBTyxTQUFTLEVBQUUsS0FBSyxNQUFNLGVBQWUsSUFBSSxNQUFNLGNBQWMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxhQUFhLFlBQVksaUJBQWlCLFFBQVEsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRLGFBQWEsS0FBSyxJQUFJLElBQUksQ0FBQztBQUFBLEVBQzdLO0FBQ0EsUUFBTSxLQUFLLENBQUMsVUFBVSxjQUFjLEdBQUcsS0FBSztBQUM1QyxNQUFJO0FBQ0osUUFBTSxnQkFBZ0Msb0JBQUksSUFBSTtBQUM5QyxRQUFNLFNBQVM7QUFBQSxJQUNkO0FBQUEsSUFDQSxXQUFXO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxJQUNBLGFBQWEsUUFBUTtBQUFBLElBQ3JCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxNQUFNLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDakIsU0FBUyxNQUFNLEdBQUcsQ0FBQztBQUFBLElBQ25CLFlBQVksYUFBYTtBQUFBLElBQ3pCLGVBQWUsb0JBQW9CO0FBQUEsSUFDbkMsV0FBVyxZQUFZO0FBQUEsSUFDdkIsU0FBUyxlQUFlO0FBQUEsSUFDeEI7QUFBQSxJQUNBLFFBQVEsS0FBSztBQUNaLFVBQUksVUFBVSxjQUFjLFVBQVU7QUFDdEMsVUFBSSxVQUFVLGNBQWMsVUFBVTtBQUN0QyxVQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDdEMsYUFBTyxlQUFlLElBQUksT0FBTyxrQkFBa0IsVUFBVTtBQUFBLFFBQzVELFlBQVk7QUFBQSxRQUNaLEtBQUssTUFBTSxNQUFNLFlBQVk7QUFBQSxNQUM5QixDQUFDO0FBQ0QsVUFBSSxhQUFhLENBQUMsV0FBVyxhQUFhLFVBQVUsMkJBQTJCO0FBQzlFLGtCQUFVO0FBQ1YsYUFBSyxjQUFjLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUMzQyxjQUFJLEtBQXVDLFFBQU8sOENBQThDLEdBQUc7QUFBQSxRQUNwRyxDQUFDO0FBQUEsTUFDRjtBQUNBLFlBQU0sZ0JBQWdCLENBQUM7QUFDdkIsaUJBQVcsT0FBTywwQkFBMkIsUUFBTyxlQUFlLGVBQWUsS0FBSztBQUFBLFFBQ3RGLEtBQUssTUFBTSxhQUFhLE1BQU0sR0FBRztBQUFBLFFBQ2pDLFlBQVk7QUFBQSxNQUNiLENBQUM7QUFDRCxVQUFJLFFBQVEsV0FBVyxNQUFNO0FBQzdCLFVBQUksUUFBUSxrQkFBa0IsZ0JBQWdCLGFBQWEsQ0FBQztBQUM1RCxVQUFJLFFBQVEsdUJBQXVCLFlBQVk7QUFDL0MsWUFBTSxhQUFhLElBQUk7QUFDdkIsb0JBQWMsSUFBSSxHQUFHO0FBQ3JCLFVBQUksVUFBVSxXQUFXO0FBQ3hCLHNCQUFjLE9BQU8sR0FBRztBQUN4QixZQUFJLGNBQWMsT0FBTyxHQUFHO0FBQzNCLDRCQUFrQjtBQUNsQixtQ0FBeUIsc0JBQXNCO0FBQy9DLGtDQUF3QjtBQUN4Qix1QkFBYSxRQUFRO0FBQ3JCLG9CQUFVO0FBQ1Ysa0JBQVE7QUFBQSxRQUNUO0FBQ0EsbUJBQVc7QUFBQSxNQUNaO0FBQ0EsVUFBd0UsYUFBYSxLQUFNLGFBQVksS0FBSyxRQUFRLE9BQU87QUFBQSxJQUM1SDtBQUFBLEVBQ0Q7QUFDQSxXQUFTLGNBQWMsUUFBUTtBQUM5QixXQUFPLE9BQU8sT0FBTyxDQUFDLFNBQVMsVUFBVSxRQUFRLEtBQUssTUFBTSxlQUFlLEtBQUssQ0FBQyxHQUFHLFFBQVEsUUFBUSxDQUFDO0FBQUEsRUFDdEc7QUFDQSxTQUFPO0FBQ1I7QUFFQSxTQUFTLHVCQUF1QixZQUFZLFlBQVksNkJBQTZCLGdCQUFnQixxQkFBcUIsY0FBYyxxQkFBcUIsc0JBQXNCLGtCQUFrQixxQkFBcUIsbUJBQW1CLGlCQUFpQixvQkFBb0IscUJBQXFCLFlBQVksa0JBQWtCLFdBQVcsdUJBQXVCLGdCQUFnQixTQUFTLFVBQVUsV0FBVzsiLCJuYW1lcyI6WyJsb2NhdGlvbiIsImhpc3RvcnkiLCJyZXBsYWNlIiwicmUiLCJuYW1lIiwibWF0Y2hlZFJvdXRlIiwiaHJlZiIsImZhaWx1cmUiLCJyZXNvbHZlIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=