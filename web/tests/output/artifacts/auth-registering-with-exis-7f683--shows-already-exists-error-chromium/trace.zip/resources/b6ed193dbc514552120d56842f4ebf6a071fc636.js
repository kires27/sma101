/**
 * Helpers to convert the change Payload into native JS types.
 */
// Adapted from epgsql (src/epgsql_binary.erl), this module licensed under
// 3-clause BSD found here: https://raw.githubusercontent.com/epgsql/epgsql/devel/LICENSE
export var PostgresTypes;
(function (PostgresTypes) {
    PostgresTypes["abstime"] = "abstime";
    PostgresTypes["bool"] = "bool";
    PostgresTypes["date"] = "date";
    PostgresTypes["daterange"] = "daterange";
    PostgresTypes["float4"] = "float4";
    PostgresTypes["float8"] = "float8";
    PostgresTypes["int2"] = "int2";
    PostgresTypes["int4"] = "int4";
    PostgresTypes["int4range"] = "int4range";
    PostgresTypes["int8"] = "int8";
    PostgresTypes["int8range"] = "int8range";
    PostgresTypes["json"] = "json";
    PostgresTypes["jsonb"] = "jsonb";
    PostgresTypes["money"] = "money";
    PostgresTypes["numeric"] = "numeric";
    PostgresTypes["oid"] = "oid";
    PostgresTypes["reltime"] = "reltime";
    PostgresTypes["text"] = "text";
    PostgresTypes["time"] = "time";
    PostgresTypes["timestamp"] = "timestamp";
    PostgresTypes["timestamptz"] = "timestamptz";
    PostgresTypes["timetz"] = "timetz";
    PostgresTypes["tsrange"] = "tsrange";
    PostgresTypes["tstzrange"] = "tstzrange";
})(PostgresTypes || (PostgresTypes = {}));
/**
 * Takes an array of columns and an object of string values then converts each string value
 * to its mapped type.
 *
 * @param {{name: String, type: String}[]} columns
 * @param {Object} record
 * @param {Object} options The map of various options that can be applied to the mapper
 * @param {Array} options.skipTypes The array of types that should not be converted
 *
 * @example convertChangeData([{name: 'first_name', type: 'text'}, {name: 'age', type: 'int4'}], {first_name: 'Paul', age:'33'}, {})
 * //=>{ first_name: 'Paul', age: 33 }
 */
export const convertChangeData = (columns, record, options = {}) => {
    var _a;
    const skipTypes = (_a = options.skipTypes) !== null && _a !== void 0 ? _a : [];
    if (!record) {
        return {};
    }
    return Object.keys(record).reduce((acc, rec_key) => {
        acc[rec_key] = convertColumn(rec_key, columns, record, skipTypes);
        return acc;
    }, {});
};
/**
 * Converts the value of an individual column.
 *
 * @param {String} columnName The column that you want to convert
 * @param {{name: String, type: String}[]} columns All of the columns
 * @param {Object} record The map of string values
 * @param {Array} skipTypes An array of types that should not be converted
 * @return {object} Useless information
 *
 * @example convertColumn('age', [{name: 'first_name', type: 'text'}, {name: 'age', type: 'int4'}], {first_name: 'Paul', age: '33'}, [])
 * //=> 33
 * @example convertColumn('age', [{name: 'first_name', type: 'text'}, {name: 'age', type: 'int4'}], {first_name: 'Paul', age: '33'}, ['int4'])
 * //=> "33"
 */
export const convertColumn = (columnName, columns, record, skipTypes) => {
    const column = columns.find((x) => x.name === columnName);
    const colType = column === null || column === void 0 ? void 0 : column.type;
    const value = record[columnName];
    if (colType && !skipTypes.includes(colType)) {
        return convertCell(colType, value);
    }
    return noop(value);
};
/**
 * If the value of the cell is `null`, returns null.
 * Otherwise converts the string value to the correct type.
 * @param {String} type A postgres column type
 * @param {String} value The cell value
 *
 * @example convertCell('bool', 't')
 * //=> true
 * @example convertCell('int8', '10')
 * //=> 10
 * @example convertCell('_int4', '{1,2,3,4}')
 * //=> [1,2,3,4]
 */
export const convertCell = (type, value) => {
    // if data type is an array
    if (type.charAt(0) === '_') {
        const dataType = type.slice(1, type.length);
        return toArray(value, dataType);
    }
    // If not null, convert to correct type.
    switch (type) {
        case PostgresTypes.bool:
            return toBoolean(value);
        case PostgresTypes.float4:
        case PostgresTypes.float8:
        case PostgresTypes.int2:
        case PostgresTypes.int4:
        case PostgresTypes.int8:
        case PostgresTypes.numeric:
        case PostgresTypes.oid:
            return toNumber(value);
        case PostgresTypes.json:
        case PostgresTypes.jsonb:
            return toJson(value);
        case PostgresTypes.timestamp:
            return toTimestampString(value); // Format to be consistent with PostgREST
        case PostgresTypes.abstime: // To allow users to cast it based on Timezone
        case PostgresTypes.date: // To allow users to cast it based on Timezone
        case PostgresTypes.daterange:
        case PostgresTypes.int4range:
        case PostgresTypes.int8range:
        case PostgresTypes.money:
        case PostgresTypes.reltime: // To allow users to cast it based on Timezone
        case PostgresTypes.text:
        case PostgresTypes.time: // To allow users to cast it based on Timezone
        case PostgresTypes.timestamptz: // To allow users to cast it based on Timezone
        case PostgresTypes.timetz: // To allow users to cast it based on Timezone
        case PostgresTypes.tsrange:
        case PostgresTypes.tstzrange:
            return noop(value);
        default:
            // Return the value for remaining types
            return noop(value);
    }
};
const noop = (value) => {
    return value;
};
export const toBoolean = (value) => {
    switch (value) {
        case 't':
            return true;
        case 'f':
            return false;
        default:
            return value;
    }
};
export const toNumber = (value) => {
    if (typeof value === 'string') {
        const parsedValue = parseFloat(value);
        if (!Number.isNaN(parsedValue)) {
            return parsedValue;
        }
    }
    return value;
};
export const toJson = (value) => {
    if (typeof value === 'string') {
        try {
            return JSON.parse(value);
        }
        catch (_a) {
            return value;
        }
    }
    return value;
};
/**
 * Converts a Postgres Array into a native JS array
 *
 * @example toArray('{}', 'int4')
 * //=> []
 * @example toArray('{"[2021-01-01,2021-12-31)","(2021-01-01,2021-12-32]"}', 'daterange')
 * //=> ['[2021-01-01,2021-12-31)', '(2021-01-01,2021-12-32]']
 * @example toArray([1,2,3,4], 'int4')
 * //=> [1,2,3,4]
 */
export const toArray = (value, type) => {
    if (typeof value !== 'string') {
        return value;
    }
    const lastIdx = value.length - 1;
    const closeBrace = value[lastIdx];
    const openBrace = value[0];
    // Confirm value is a Postgres array by checking curly brackets
    if (openBrace === '{' && closeBrace === '}') {
        let arr;
        const valTrim = value.slice(1, lastIdx);
        // TODO: find a better solution to separate Postgres array data
        try {
            arr = JSON.parse('[' + valTrim + ']');
        }
        catch (_) {
            // WARNING: splitting on comma does not cover all edge cases
            arr = valTrim ? valTrim.split(',') : [];
        }
        return arr.map((val) => convertCell(type, val));
    }
    return value;
};
/**
 * Fixes timestamp to be ISO-8601. Swaps the space between the date and time for a 'T'
 * See https://github.com/supabase/supabase/issues/18
 *
 * @example toTimestampString('2019-09-10 00:00:00')
 * //=> '2019-09-10T00:00:00'
 */
export const toTimestampString = (value) => {
    if (typeof value === 'string') {
        return value.replace(' ', 'T');
    }
    return value;
};
export const httpEndpointURL = (socketUrl) => {
    const wsUrl = new URL(socketUrl);
    wsUrl.protocol = wsUrl.protocol.replace(/^ws/i, 'http');
    wsUrl.pathname = wsUrl.pathname
        .replace(/\/+$/, '') // remove all trailing slashes
        .replace(/\/socket\/websocket$/i, '') // remove the socket/websocket path
        .replace(/\/socket$/i, '') // remove the socket path
        .replace(/\/websocket$/i, ''); // remove the websocket path
    if (wsUrl.pathname === '' || wsUrl.pathname === '/') {
        wsUrl.pathname = '/api/broadcast';
    }
    else {
        wsUrl.pathname = wsUrl.pathname + '/api/broadcast';
    }
    return wsUrl.href;
};
                                        
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJhbnNmb3JtZXJzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2xpYi90cmFuc2Zvcm1lcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0dBRUc7QUFFSCwwRUFBMEU7QUFDMUUseUZBQXlGO0FBRXpGLE1BQU0sQ0FBTixJQUFZLGFBeUJYO0FBekJELFdBQVksYUFBYTtJQUN2QixvQ0FBbUIsQ0FBQTtJQUNuQiw4QkFBYSxDQUFBO0lBQ2IsOEJBQWEsQ0FBQTtJQUNiLHdDQUF1QixDQUFBO0lBQ3ZCLGtDQUFpQixDQUFBO0lBQ2pCLGtDQUFpQixDQUFBO0lBQ2pCLDhCQUFhLENBQUE7SUFDYiw4QkFBYSxDQUFBO0lBQ2Isd0NBQXVCLENBQUE7SUFDdkIsOEJBQWEsQ0FBQTtJQUNiLHdDQUF1QixDQUFBO0lBQ3ZCLDhCQUFhLENBQUE7SUFDYixnQ0FBZSxDQUFBO0lBQ2YsZ0NBQWUsQ0FBQTtJQUNmLG9DQUFtQixDQUFBO0lBQ25CLDRCQUFXLENBQUE7SUFDWCxvQ0FBbUIsQ0FBQTtJQUNuQiw4QkFBYSxDQUFBO0lBQ2IsOEJBQWEsQ0FBQTtJQUNiLHdDQUF1QixDQUFBO0lBQ3ZCLDRDQUEyQixDQUFBO0lBQzNCLGtDQUFpQixDQUFBO0lBQ2pCLG9DQUFtQixDQUFBO0lBQ25CLHdDQUF1QixDQUFBO0FBQ3pCLENBQUMsRUF6QlcsYUFBYSxLQUFiLGFBQWEsUUF5QnhCO0FBZ0JEOzs7Ozs7Ozs7OztHQVdHO0FBQ0gsTUFBTSxDQUFDLE1BQU0saUJBQWlCLEdBQUcsQ0FDL0IsT0FBZ0IsRUFDaEIsTUFBcUIsRUFDckIsVUFBb0MsRUFBRSxFQUM5QixFQUFFOztJQUNWLE1BQU0sU0FBUyxHQUFHLE1BQUEsT0FBTyxDQUFDLFNBQVMsbUNBQUksRUFBRSxDQUFBO0lBRXpDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNaLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVELE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLEVBQUU7UUFDakQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLGFBQWEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQTtRQUNqRSxPQUFPLEdBQUcsQ0FBQTtJQUNaLENBQUMsRUFBRSxFQUFZLENBQUMsQ0FBQTtBQUNsQixDQUFDLENBQUE7QUFFRDs7Ozs7Ozs7Ozs7OztHQWFHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sYUFBYSxHQUFHLENBQzNCLFVBQWtCLEVBQ2xCLE9BQWdCLEVBQ2hCLE1BQWMsRUFDZCxTQUFtQixFQUNOLEVBQUU7SUFDZixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLFVBQVUsQ0FBQyxDQUFBO0lBQ3pELE1BQU0sT0FBTyxHQUFHLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxJQUFJLENBQUE7SUFDNUIsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0lBRWhDLElBQUksT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQzVDLE9BQU8sV0FBVyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQTtJQUNwQyxDQUFDO0lBRUQsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDcEIsQ0FBQyxDQUFBO0FBRUQ7Ozs7Ozs7Ozs7OztHQVlHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sV0FBVyxHQUFHLENBQUMsSUFBWSxFQUFFLEtBQWtCLEVBQWUsRUFBRTtJQUMzRSwyQkFBMkI7SUFDM0IsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQzNCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUMzQyxPQUFPLE9BQU8sQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUE7SUFDakMsQ0FBQztJQUVELHdDQUF3QztJQUN4QyxRQUFRLElBQUksRUFBRSxDQUFDO1FBQ2IsS0FBSyxhQUFhLENBQUMsSUFBSTtZQUNyQixPQUFPLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUN6QixLQUFLLGFBQWEsQ0FBQyxNQUFNLENBQUM7UUFDMUIsS0FBSyxhQUFhLENBQUMsTUFBTSxDQUFDO1FBQzFCLEtBQUssYUFBYSxDQUFDLElBQUksQ0FBQztRQUN4QixLQUFLLGFBQWEsQ0FBQyxJQUFJLENBQUM7UUFDeEIsS0FBSyxhQUFhLENBQUMsSUFBSSxDQUFDO1FBQ3hCLEtBQUssYUFBYSxDQUFDLE9BQU8sQ0FBQztRQUMzQixLQUFLLGFBQWEsQ0FBQyxHQUFHO1lBQ3BCLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQ3hCLEtBQUssYUFBYSxDQUFDLElBQUksQ0FBQztRQUN4QixLQUFLLGFBQWEsQ0FBQyxLQUFLO1lBQ3RCLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQ3RCLEtBQUssYUFBYSxDQUFDLFNBQVM7WUFDMUIsT0FBTyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQSxDQUFDLHlDQUF5QztRQUMzRSxLQUFLLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyw4Q0FBOEM7UUFDMUUsS0FBSyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsOENBQThDO1FBQ3ZFLEtBQUssYUFBYSxDQUFDLFNBQVMsQ0FBQztRQUM3QixLQUFLLGFBQWEsQ0FBQyxTQUFTLENBQUM7UUFDN0IsS0FBSyxhQUFhLENBQUMsU0FBUyxDQUFDO1FBQzdCLEtBQUssYUFBYSxDQUFDLEtBQUssQ0FBQztRQUN6QixLQUFLLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyw4Q0FBOEM7UUFDMUUsS0FBSyxhQUFhLENBQUMsSUFBSSxDQUFDO1FBQ3hCLEtBQUssYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLDhDQUE4QztRQUN2RSxLQUFLLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQyw4Q0FBOEM7UUFDOUUsS0FBSyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsOENBQThDO1FBQ3pFLEtBQUssYUFBYSxDQUFDLE9BQU8sQ0FBQztRQUMzQixLQUFLLGFBQWEsQ0FBQyxTQUFTO1lBQzFCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQ3BCO1lBQ0UsdUNBQXVDO1lBQ3ZDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ3RCLENBQUM7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLElBQUksR0FBRyxDQUFDLEtBQWtCLEVBQWUsRUFBRTtJQUMvQyxPQUFPLEtBQUssQ0FBQTtBQUNkLENBQUMsQ0FBQTtBQUNELE1BQU0sQ0FBQyxNQUFNLFNBQVMsR0FBRyxDQUFDLEtBQWtCLEVBQWUsRUFBRTtJQUMzRCxRQUFRLEtBQUssRUFBRSxDQUFDO1FBQ2QsS0FBSyxHQUFHO1lBQ04sT0FBTyxJQUFJLENBQUE7UUFDYixLQUFLLEdBQUc7WUFDTixPQUFPLEtBQUssQ0FBQTtRQUNkO1lBQ0UsT0FBTyxLQUFLLENBQUE7SUFDaEIsQ0FBQztBQUNILENBQUMsQ0FBQTtBQUNELE1BQU0sQ0FBQyxNQUFNLFFBQVEsR0FBRyxDQUFDLEtBQWtCLEVBQWUsRUFBRTtJQUMxRCxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDO1FBQzlCLE1BQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUNyQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO1lBQy9CLE9BQU8sV0FBVyxDQUFBO1FBQ3BCLENBQUM7SUFDSCxDQUFDO0lBQ0QsT0FBTyxLQUFLLENBQUE7QUFDZCxDQUFDLENBQUE7QUFDRCxNQUFNLENBQUMsTUFBTSxNQUFNLEdBQUcsQ0FBQyxLQUFrQixFQUFlLEVBQUU7SUFDeEQsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUM7WUFDSCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDMUIsQ0FBQztRQUFDLFdBQU0sQ0FBQztZQUNQLE9BQU8sS0FBSyxDQUFBO1FBQ2QsQ0FBQztJQUNILENBQUM7SUFDRCxPQUFPLEtBQUssQ0FBQTtBQUNkLENBQUMsQ0FBQTtBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILE1BQU0sQ0FBQyxNQUFNLE9BQU8sR0FBRyxDQUFDLEtBQWtCLEVBQUUsSUFBWSxFQUFlLEVBQUU7SUFDdkUsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUUsQ0FBQztRQUM5QixPQUFPLEtBQUssQ0FBQTtJQUNkLENBQUM7SUFFRCxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQTtJQUNoQyxNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDakMsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBRTFCLCtEQUErRDtJQUMvRCxJQUFJLFNBQVMsS0FBSyxHQUFHLElBQUksVUFBVSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQzVDLElBQUksR0FBRyxDQUFBO1FBQ1AsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFFdkMsK0RBQStEO1FBQy9ELElBQUksQ0FBQztZQUNILEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUE7UUFDdkMsQ0FBQztRQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDWCw0REFBNEQ7WUFDNUQsR0FBRyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBQ3pDLENBQUM7UUFFRCxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFjLEVBQUUsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQTtJQUM1RCxDQUFDO0lBRUQsT0FBTyxLQUFLLENBQUE7QUFDZCxDQUFDLENBQUE7QUFFRDs7Ozs7O0dBTUc7QUFDSCxNQUFNLENBQUMsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLEtBQWtCLEVBQWUsRUFBRTtJQUNuRSxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDO1FBQzlCLE9BQU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUE7SUFDaEMsQ0FBQztJQUVELE9BQU8sS0FBSyxDQUFBO0FBQ2QsQ0FBQyxDQUFBO0FBRUQsTUFBTSxDQUFDLE1BQU0sZUFBZSxHQUFHLENBQUMsU0FBaUIsRUFBVSxFQUFFO0lBQzNELE1BQU0sS0FBSyxHQUFHLElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFBO0lBRWhDLEtBQUssQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFBO0lBRXZELEtBQUssQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVE7U0FDNUIsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyw4QkFBOEI7U0FDbEQsT0FBTyxDQUFDLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFDLG1DQUFtQztTQUN4RSxPQUFPLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDLHlCQUF5QjtTQUNuRCxPQUFPLENBQUMsZUFBZSxFQUFFLEVBQUUsQ0FBQyxDQUFBLENBQUMsNEJBQTRCO0lBRTVELElBQUksS0FBSyxDQUFDLFFBQVEsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDLFFBQVEsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNwRCxLQUFLLENBQUMsUUFBUSxHQUFHLGdCQUFnQixDQUFBO0lBQ25DLENBQUM7U0FBTSxDQUFDO1FBQ04sS0FBSyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxHQUFHLGdCQUFnQixDQUFBO0lBQ3BELENBQUM7SUFFRCxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUE7QUFDbkIsQ0FBQyxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBIZWxwZXJzIHRvIGNvbnZlcnQgdGhlIGNoYW5nZSBQYXlsb2FkIGludG8gbmF0aXZlIEpTIHR5cGVzLlxuICovXG5cbi8vIEFkYXB0ZWQgZnJvbSBlcGdzcWwgKHNyYy9lcGdzcWxfYmluYXJ5LmVybCksIHRoaXMgbW9kdWxlIGxpY2Vuc2VkIHVuZGVyXG4vLyAzLWNsYXVzZSBCU0QgZm91bmQgaGVyZTogaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2VwZ3NxbC9lcGdzcWwvZGV2ZWwvTElDRU5TRVxuXG5leHBvcnQgZW51bSBQb3N0Z3Jlc1R5cGVzIHtcbiAgYWJzdGltZSA9ICdhYnN0aW1lJyxcbiAgYm9vbCA9ICdib29sJyxcbiAgZGF0ZSA9ICdkYXRlJyxcbiAgZGF0ZXJhbmdlID0gJ2RhdGVyYW5nZScsXG4gIGZsb2F0NCA9ICdmbG9hdDQnLFxuICBmbG9hdDggPSAnZmxvYXQ4JyxcbiAgaW50MiA9ICdpbnQyJyxcbiAgaW50NCA9ICdpbnQ0JyxcbiAgaW50NHJhbmdlID0gJ2ludDRyYW5nZScsXG4gIGludDggPSAnaW50OCcsXG4gIGludDhyYW5nZSA9ICdpbnQ4cmFuZ2UnLFxuICBqc29uID0gJ2pzb24nLFxuICBqc29uYiA9ICdqc29uYicsXG4gIG1vbmV5ID0gJ21vbmV5JyxcbiAgbnVtZXJpYyA9ICdudW1lcmljJyxcbiAgb2lkID0gJ29pZCcsXG4gIHJlbHRpbWUgPSAncmVsdGltZScsXG4gIHRleHQgPSAndGV4dCcsXG4gIHRpbWUgPSAndGltZScsXG4gIHRpbWVzdGFtcCA9ICd0aW1lc3RhbXAnLFxuICB0aW1lc3RhbXB0eiA9ICd0aW1lc3RhbXB0eicsXG4gIHRpbWV0eiA9ICd0aW1ldHonLFxuICB0c3JhbmdlID0gJ3RzcmFuZ2UnLFxuICB0c3R6cmFuZ2UgPSAndHN0enJhbmdlJyxcbn1cblxudHlwZSBDb2x1bW5zID0ge1xuICBuYW1lOiBzdHJpbmcgLy8gdGhlIGNvbHVtbiBuYW1lLiBlZzogXCJ1c2VyX2lkXCJcbiAgdHlwZTogc3RyaW5nIC8vIHRoZSBjb2x1bW4gdHlwZS4gZWc6IFwidXVpZFwiXG4gIGZsYWdzPzogc3RyaW5nW10gLy8gYW55IHNwZWNpYWwgZmxhZ3MgZm9yIHRoZSBjb2x1bW4uIGVnOiBbXCJrZXlcIl1cbiAgdHlwZV9tb2RpZmllcj86IG51bWJlciAvLyB0aGUgdHlwZSBtb2RpZmllci4gZWc6IDQyOTQ5NjcyOTVcbn1bXVxuXG50eXBlIEJhc2VWYWx1ZSA9IG51bGwgfCBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuXG50eXBlIFJlY29yZFZhbHVlID0gQmFzZVZhbHVlIHwgQmFzZVZhbHVlW11cblxudHlwZSBSZWNvcmQgPSB7XG4gIFtrZXk6IHN0cmluZ106IFJlY29yZFZhbHVlXG59XG5cbi8qKlxuICogVGFrZXMgYW4gYXJyYXkgb2YgY29sdW1ucyBhbmQgYW4gb2JqZWN0IG9mIHN0cmluZyB2YWx1ZXMgdGhlbiBjb252ZXJ0cyBlYWNoIHN0cmluZyB2YWx1ZVxuICogdG8gaXRzIG1hcHBlZCB0eXBlLlxuICpcbiAqIEBwYXJhbSB7e25hbWU6IFN0cmluZywgdHlwZTogU3RyaW5nfVtdfSBjb2x1bW5zXG4gKiBAcGFyYW0ge09iamVjdH0gcmVjb3JkXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyBUaGUgbWFwIG9mIHZhcmlvdXMgb3B0aW9ucyB0aGF0IGNhbiBiZSBhcHBsaWVkIHRvIHRoZSBtYXBwZXJcbiAqIEBwYXJhbSB7QXJyYXl9IG9wdGlvbnMuc2tpcFR5cGVzIFRoZSBhcnJheSBvZiB0eXBlcyB0aGF0IHNob3VsZCBub3QgYmUgY29udmVydGVkXG4gKlxuICogQGV4YW1wbGUgY29udmVydENoYW5nZURhdGEoW3tuYW1lOiAnZmlyc3RfbmFtZScsIHR5cGU6ICd0ZXh0J30sIHtuYW1lOiAnYWdlJywgdHlwZTogJ2ludDQnfV0sIHtmaXJzdF9uYW1lOiAnUGF1bCcsIGFnZTonMzMnfSwge30pXG4gKiAvLz0+eyBmaXJzdF9uYW1lOiAnUGF1bCcsIGFnZTogMzMgfVxuICovXG5leHBvcnQgY29uc3QgY29udmVydENoYW5nZURhdGEgPSAoXG4gIGNvbHVtbnM6IENvbHVtbnMsXG4gIHJlY29yZDogUmVjb3JkIHwgbnVsbCxcbiAgb3B0aW9uczogeyBza2lwVHlwZXM/OiBzdHJpbmdbXSB9ID0ge31cbik6IFJlY29yZCA9PiB7XG4gIGNvbnN0IHNraXBUeXBlcyA9IG9wdGlvbnMuc2tpcFR5cGVzID8/IFtdXG5cbiAgaWYgKCFyZWNvcmQpIHtcbiAgICByZXR1cm4ge31cbiAgfVxuXG4gIHJldHVybiBPYmplY3Qua2V5cyhyZWNvcmQpLnJlZHVjZSgoYWNjLCByZWNfa2V5KSA9PiB7XG4gICAgYWNjW3JlY19rZXldID0gY29udmVydENvbHVtbihyZWNfa2V5LCBjb2x1bW5zLCByZWNvcmQsIHNraXBUeXBlcylcbiAgICByZXR1cm4gYWNjXG4gIH0sIHt9IGFzIFJlY29yZClcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyB0aGUgdmFsdWUgb2YgYW4gaW5kaXZpZHVhbCBjb2x1bW4uXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGNvbHVtbk5hbWUgVGhlIGNvbHVtbiB0aGF0IHlvdSB3YW50IHRvIGNvbnZlcnRcbiAqIEBwYXJhbSB7e25hbWU6IFN0cmluZywgdHlwZTogU3RyaW5nfVtdfSBjb2x1bW5zIEFsbCBvZiB0aGUgY29sdW1uc1xuICogQHBhcmFtIHtPYmplY3R9IHJlY29yZCBUaGUgbWFwIG9mIHN0cmluZyB2YWx1ZXNcbiAqIEBwYXJhbSB7QXJyYXl9IHNraXBUeXBlcyBBbiBhcnJheSBvZiB0eXBlcyB0aGF0IHNob3VsZCBub3QgYmUgY29udmVydGVkXG4gKiBAcmV0dXJuIHtvYmplY3R9IFVzZWxlc3MgaW5mb3JtYXRpb25cbiAqXG4gKiBAZXhhbXBsZSBjb252ZXJ0Q29sdW1uKCdhZ2UnLCBbe25hbWU6ICdmaXJzdF9uYW1lJywgdHlwZTogJ3RleHQnfSwge25hbWU6ICdhZ2UnLCB0eXBlOiAnaW50NCd9XSwge2ZpcnN0X25hbWU6ICdQYXVsJywgYWdlOiAnMzMnfSwgW10pXG4gKiAvLz0+IDMzXG4gKiBAZXhhbXBsZSBjb252ZXJ0Q29sdW1uKCdhZ2UnLCBbe25hbWU6ICdmaXJzdF9uYW1lJywgdHlwZTogJ3RleHQnfSwge25hbWU6ICdhZ2UnLCB0eXBlOiAnaW50NCd9XSwge2ZpcnN0X25hbWU6ICdQYXVsJywgYWdlOiAnMzMnfSwgWydpbnQ0J10pXG4gKiAvLz0+IFwiMzNcIlxuICovXG5leHBvcnQgY29uc3QgY29udmVydENvbHVtbiA9IChcbiAgY29sdW1uTmFtZTogc3RyaW5nLFxuICBjb2x1bW5zOiBDb2x1bW5zLFxuICByZWNvcmQ6IFJlY29yZCxcbiAgc2tpcFR5cGVzOiBzdHJpbmdbXVxuKTogUmVjb3JkVmFsdWUgPT4ge1xuICBjb25zdCBjb2x1bW4gPSBjb2x1bW5zLmZpbmQoKHgpID0+IHgubmFtZSA9PT0gY29sdW1uTmFtZSlcbiAgY29uc3QgY29sVHlwZSA9IGNvbHVtbj8udHlwZVxuICBjb25zdCB2YWx1ZSA9IHJlY29yZFtjb2x1bW5OYW1lXVxuXG4gIGlmIChjb2xUeXBlICYmICFza2lwVHlwZXMuaW5jbHVkZXMoY29sVHlwZSkpIHtcbiAgICByZXR1cm4gY29udmVydENlbGwoY29sVHlwZSwgdmFsdWUpXG4gIH1cblxuICByZXR1cm4gbm9vcCh2YWx1ZSlcbn1cblxuLyoqXG4gKiBJZiB0aGUgdmFsdWUgb2YgdGhlIGNlbGwgaXMgYG51bGxgLCByZXR1cm5zIG51bGwuXG4gKiBPdGhlcndpc2UgY29udmVydHMgdGhlIHN0cmluZyB2YWx1ZSB0byB0aGUgY29ycmVjdCB0eXBlLlxuICogQHBhcmFtIHtTdHJpbmd9IHR5cGUgQSBwb3N0Z3JlcyBjb2x1bW4gdHlwZVxuICogQHBhcmFtIHtTdHJpbmd9IHZhbHVlIFRoZSBjZWxsIHZhbHVlXG4gKlxuICogQGV4YW1wbGUgY29udmVydENlbGwoJ2Jvb2wnLCAndCcpXG4gKiAvLz0+IHRydWVcbiAqIEBleGFtcGxlIGNvbnZlcnRDZWxsKCdpbnQ4JywgJzEwJylcbiAqIC8vPT4gMTBcbiAqIEBleGFtcGxlIGNvbnZlcnRDZWxsKCdfaW50NCcsICd7MSwyLDMsNH0nKVxuICogLy89PiBbMSwyLDMsNF1cbiAqL1xuZXhwb3J0IGNvbnN0IGNvbnZlcnRDZWxsID0gKHR5cGU6IHN0cmluZywgdmFsdWU6IFJlY29yZFZhbHVlKTogUmVjb3JkVmFsdWUgPT4ge1xuICAvLyBpZiBkYXRhIHR5cGUgaXMgYW4gYXJyYXlcbiAgaWYgKHR5cGUuY2hhckF0KDApID09PSAnXycpIHtcbiAgICBjb25zdCBkYXRhVHlwZSA9IHR5cGUuc2xpY2UoMSwgdHlwZS5sZW5ndGgpXG4gICAgcmV0dXJuIHRvQXJyYXkodmFsdWUsIGRhdGFUeXBlKVxuICB9XG5cbiAgLy8gSWYgbm90IG51bGwsIGNvbnZlcnQgdG8gY29ycmVjdCB0eXBlLlxuICBzd2l0Y2ggKHR5cGUpIHtcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMuYm9vbDpcbiAgICAgIHJldHVybiB0b0Jvb2xlYW4odmFsdWUpXG4gICAgY2FzZSBQb3N0Z3Jlc1R5cGVzLmZsb2F0NDpcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMuZmxvYXQ4OlxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy5pbnQyOlxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy5pbnQ0OlxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy5pbnQ4OlxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy5udW1lcmljOlxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy5vaWQ6XG4gICAgICByZXR1cm4gdG9OdW1iZXIodmFsdWUpXG4gICAgY2FzZSBQb3N0Z3Jlc1R5cGVzLmpzb246XG4gICAgY2FzZSBQb3N0Z3Jlc1R5cGVzLmpzb25iOlxuICAgICAgcmV0dXJuIHRvSnNvbih2YWx1ZSlcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMudGltZXN0YW1wOlxuICAgICAgcmV0dXJuIHRvVGltZXN0YW1wU3RyaW5nKHZhbHVlKSAvLyBGb3JtYXQgdG8gYmUgY29uc2lzdGVudCB3aXRoIFBvc3RnUkVTVFxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy5hYnN0aW1lOiAvLyBUbyBhbGxvdyB1c2VycyB0byBjYXN0IGl0IGJhc2VkIG9uIFRpbWV6b25lXG4gICAgY2FzZSBQb3N0Z3Jlc1R5cGVzLmRhdGU6IC8vIFRvIGFsbG93IHVzZXJzIHRvIGNhc3QgaXQgYmFzZWQgb24gVGltZXpvbmVcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMuZGF0ZXJhbmdlOlxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy5pbnQ0cmFuZ2U6XG4gICAgY2FzZSBQb3N0Z3Jlc1R5cGVzLmludDhyYW5nZTpcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMubW9uZXk6XG4gICAgY2FzZSBQb3N0Z3Jlc1R5cGVzLnJlbHRpbWU6IC8vIFRvIGFsbG93IHVzZXJzIHRvIGNhc3QgaXQgYmFzZWQgb24gVGltZXpvbmVcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMudGV4dDpcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMudGltZTogLy8gVG8gYWxsb3cgdXNlcnMgdG8gY2FzdCBpdCBiYXNlZCBvbiBUaW1lem9uZVxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy50aW1lc3RhbXB0ejogLy8gVG8gYWxsb3cgdXNlcnMgdG8gY2FzdCBpdCBiYXNlZCBvbiBUaW1lem9uZVxuICAgIGNhc2UgUG9zdGdyZXNUeXBlcy50aW1ldHo6IC8vIFRvIGFsbG93IHVzZXJzIHRvIGNhc3QgaXQgYmFzZWQgb24gVGltZXpvbmVcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMudHNyYW5nZTpcbiAgICBjYXNlIFBvc3RncmVzVHlwZXMudHN0enJhbmdlOlxuICAgICAgcmV0dXJuIG5vb3AodmFsdWUpXG4gICAgZGVmYXVsdDpcbiAgICAgIC8vIFJldHVybiB0aGUgdmFsdWUgZm9yIHJlbWFpbmluZyB0eXBlc1xuICAgICAgcmV0dXJuIG5vb3AodmFsdWUpXG4gIH1cbn1cblxuY29uc3Qgbm9vcCA9ICh2YWx1ZTogUmVjb3JkVmFsdWUpOiBSZWNvcmRWYWx1ZSA9PiB7XG4gIHJldHVybiB2YWx1ZVxufVxuZXhwb3J0IGNvbnN0IHRvQm9vbGVhbiA9ICh2YWx1ZTogUmVjb3JkVmFsdWUpOiBSZWNvcmRWYWx1ZSA9PiB7XG4gIHN3aXRjaCAodmFsdWUpIHtcbiAgICBjYXNlICd0JzpcbiAgICAgIHJldHVybiB0cnVlXG4gICAgY2FzZSAnZic6XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHZhbHVlXG4gIH1cbn1cbmV4cG9ydCBjb25zdCB0b051bWJlciA9ICh2YWx1ZTogUmVjb3JkVmFsdWUpOiBSZWNvcmRWYWx1ZSA9PiB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgY29uc3QgcGFyc2VkVmFsdWUgPSBwYXJzZUZsb2F0KHZhbHVlKVxuICAgIGlmICghTnVtYmVyLmlzTmFOKHBhcnNlZFZhbHVlKSkge1xuICAgICAgcmV0dXJuIHBhcnNlZFZhbHVlXG4gICAgfVxuICB9XG4gIHJldHVybiB2YWx1ZVxufVxuZXhwb3J0IGNvbnN0IHRvSnNvbiA9ICh2YWx1ZTogUmVjb3JkVmFsdWUpOiBSZWNvcmRWYWx1ZSA9PiB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKHZhbHVlKVxuICAgIH0gY2F0Y2gge1xuICAgICAgcmV0dXJuIHZhbHVlXG4gICAgfVxuICB9XG4gIHJldHVybiB2YWx1ZVxufVxuXG4vKipcbiAqIENvbnZlcnRzIGEgUG9zdGdyZXMgQXJyYXkgaW50byBhIG5hdGl2ZSBKUyBhcnJheVxuICpcbiAqIEBleGFtcGxlIHRvQXJyYXkoJ3t9JywgJ2ludDQnKVxuICogLy89PiBbXVxuICogQGV4YW1wbGUgdG9BcnJheSgne1wiWzIwMjEtMDEtMDEsMjAyMS0xMi0zMSlcIixcIigyMDIxLTAxLTAxLDIwMjEtMTItMzJdXCJ9JywgJ2RhdGVyYW5nZScpXG4gKiAvLz0+IFsnWzIwMjEtMDEtMDEsMjAyMS0xMi0zMSknLCAnKDIwMjEtMDEtMDEsMjAyMS0xMi0zMl0nXVxuICogQGV4YW1wbGUgdG9BcnJheShbMSwyLDMsNF0sICdpbnQ0JylcbiAqIC8vPT4gWzEsMiwzLDRdXG4gKi9cbmV4cG9ydCBjb25zdCB0b0FycmF5ID0gKHZhbHVlOiBSZWNvcmRWYWx1ZSwgdHlwZTogc3RyaW5nKTogUmVjb3JkVmFsdWUgPT4ge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiB2YWx1ZVxuICB9XG5cbiAgY29uc3QgbGFzdElkeCA9IHZhbHVlLmxlbmd0aCAtIDFcbiAgY29uc3QgY2xvc2VCcmFjZSA9IHZhbHVlW2xhc3RJZHhdXG4gIGNvbnN0IG9wZW5CcmFjZSA9IHZhbHVlWzBdXG5cbiAgLy8gQ29uZmlybSB2YWx1ZSBpcyBhIFBvc3RncmVzIGFycmF5IGJ5IGNoZWNraW5nIGN1cmx5IGJyYWNrZXRzXG4gIGlmIChvcGVuQnJhY2UgPT09ICd7JyAmJiBjbG9zZUJyYWNlID09PSAnfScpIHtcbiAgICBsZXQgYXJyXG4gICAgY29uc3QgdmFsVHJpbSA9IHZhbHVlLnNsaWNlKDEsIGxhc3RJZHgpXG5cbiAgICAvLyBUT0RPOiBmaW5kIGEgYmV0dGVyIHNvbHV0aW9uIHRvIHNlcGFyYXRlIFBvc3RncmVzIGFycmF5IGRhdGFcbiAgICB0cnkge1xuICAgICAgYXJyID0gSlNPTi5wYXJzZSgnWycgKyB2YWxUcmltICsgJ10nKVxuICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgIC8vIFdBUk5JTkc6IHNwbGl0dGluZyBvbiBjb21tYSBkb2VzIG5vdCBjb3ZlciBhbGwgZWRnZSBjYXNlc1xuICAgICAgYXJyID0gdmFsVHJpbSA/IHZhbFRyaW0uc3BsaXQoJywnKSA6IFtdXG4gICAgfVxuXG4gICAgcmV0dXJuIGFyci5tYXAoKHZhbDogQmFzZVZhbHVlKSA9PiBjb252ZXJ0Q2VsbCh0eXBlLCB2YWwpKVxuICB9XG5cbiAgcmV0dXJuIHZhbHVlXG59XG5cbi8qKlxuICogRml4ZXMgdGltZXN0YW1wIHRvIGJlIElTTy04NjAxLiBTd2FwcyB0aGUgc3BhY2UgYmV0d2VlbiB0aGUgZGF0ZSBhbmQgdGltZSBmb3IgYSAnVCdcbiAqIFNlZSBodHRwczovL2dpdGh1Yi5jb20vc3VwYWJhc2Uvc3VwYWJhc2UvaXNzdWVzLzE4XG4gKlxuICogQGV4YW1wbGUgdG9UaW1lc3RhbXBTdHJpbmcoJzIwMTktMDktMTAgMDA6MDA6MDAnKVxuICogLy89PiAnMjAxOS0wOS0xMFQwMDowMDowMCdcbiAqL1xuZXhwb3J0IGNvbnN0IHRvVGltZXN0YW1wU3RyaW5nID0gKHZhbHVlOiBSZWNvcmRWYWx1ZSk6IFJlY29yZFZhbHVlID0+IHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gdmFsdWUucmVwbGFjZSgnICcsICdUJylcbiAgfVxuXG4gIHJldHVybiB2YWx1ZVxufVxuXG5leHBvcnQgY29uc3QgaHR0cEVuZHBvaW50VVJMID0gKHNvY2tldFVybDogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgY29uc3Qgd3NVcmwgPSBuZXcgVVJMKHNvY2tldFVybClcblxuICB3c1VybC5wcm90b2NvbCA9IHdzVXJsLnByb3RvY29sLnJlcGxhY2UoL153cy9pLCAnaHR0cCcpXG5cbiAgd3NVcmwucGF0aG5hbWUgPSB3c1VybC5wYXRobmFtZVxuICAgIC5yZXBsYWNlKC9cXC8rJC8sICcnKSAvLyByZW1vdmUgYWxsIHRyYWlsaW5nIHNsYXNoZXNcbiAgICAucmVwbGFjZSgvXFwvc29ja2V0XFwvd2Vic29ja2V0JC9pLCAnJykgLy8gcmVtb3ZlIHRoZSBzb2NrZXQvd2Vic29ja2V0IHBhdGhcbiAgICAucmVwbGFjZSgvXFwvc29ja2V0JC9pLCAnJykgLy8gcmVtb3ZlIHRoZSBzb2NrZXQgcGF0aFxuICAgIC5yZXBsYWNlKC9cXC93ZWJzb2NrZXQkL2ksICcnKSAvLyByZW1vdmUgdGhlIHdlYnNvY2tldCBwYXRoXG5cbiAgaWYgKHdzVXJsLnBhdGhuYW1lID09PSAnJyB8fCB3c1VybC5wYXRobmFtZSA9PT0gJy8nKSB7XG4gICAgd3NVcmwucGF0aG5hbWUgPSAnL2FwaS9icm9hZGNhc3QnXG4gIH0gZWxzZSB7XG4gICAgd3NVcmwucGF0aG5hbWUgPSB3c1VybC5wYXRobmFtZSArICcvYXBpL2Jyb2FkY2FzdCdcbiAgfVxuXG4gIHJldHVybiB3c1VybC5ocmVmXG59XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==