// src/errors/IcebergError.ts
var IcebergError = class extends Error {
  constructor(message, opts) {
    super(message);
    this.name = "IcebergError";
    this.status = opts.status;
    this.icebergType = opts.icebergType;
    this.icebergCode = opts.icebergCode;
    this.details = opts.details;
    this.isCommitStateUnknown = opts.icebergType === "CommitStateUnknownException" || [500, 502, 504].includes(opts.status) && opts.icebergType?.includes("CommitState") === true;
  }
  /**
   * Returns true if the error is a 404 Not Found error.
   */
  isNotFound() {
    return this.status === 404;
  }
  /**
   * Returns true if the error is a 409 Conflict error.
   */
  isConflict() {
    return this.status === 409;
  }
  /**
   * Returns true if the error is a 419 Authentication Timeout error.
   */
  isAuthenticationTimeout() {
    return this.status === 419;
  }
};

// src/utils/url.ts
function buildUrl(baseUrl, path, query) {
  const url = new URL(path, baseUrl);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0) {
        url.searchParams.set(key, value);
      }
    }
  }
  return url.toString();
}

// src/http/createFetchClient.ts
async function buildAuthHeaders(auth) {
  if (!auth || auth.type === "none") {
    return {};
  }
  if (auth.type === "bearer") {
    return { Authorization: `Bearer ${auth.token}` };
  }
  if (auth.type === "header") {
    return { [auth.name]: auth.value };
  }
  if (auth.type === "custom") {
    return await auth.getHeaders();
  }
  return {};
}
function createFetchClient(options) {
  const fetchFn = options.fetchImpl ?? globalThis.fetch;
  return {
    async request({
      method,
      path,
      query,
      body,
      headers
    }) {
      const url = buildUrl(options.baseUrl, path, query);
      const authHeaders = await buildAuthHeaders(options.auth);
      const res = await fetchFn(url, {
        method,
        headers: {
          ...body ? { "Content-Type": "application/json" } : {},
          ...authHeaders,
          ...headers
        },
        body: body ? JSON.stringify(body) : void 0
      });
      const text = await res.text();
      const isJson = (res.headers.get("content-type") || "").includes("application/json");
      const data = isJson && text ? JSON.parse(text) : text;
      if (!res.ok) {
        const errBody = isJson ? data : void 0;
        const errorDetail = errBody?.error;
        throw new IcebergError(
          errorDetail?.message ?? `Request failed with status ${res.status}`,
          {
            status: res.status,
            icebergType: errorDetail?.type,
            icebergCode: errorDetail?.code,
            details: errBody
          }
        );
      }
      return { status: res.status, headers: res.headers, data };
    }
  };
}

// src/catalog/namespaces.ts
function namespaceToPath(namespace) {
  return namespace.join("");
}
var NamespaceOperations = class {
  constructor(client, prefix = "") {
    this.client = client;
    this.prefix = prefix;
  }
  async listNamespaces(parent) {
    const query = parent ? { parent: namespaceToPath(parent.namespace) } : void 0;
    const response = await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces`,
      query
    });
    return response.data.namespaces.map((ns) => ({ namespace: ns }));
  }
  async createNamespace(id, metadata) {
    const request = {
      namespace: id.namespace,
      properties: metadata?.properties
    };
    const response = await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces`,
      body: request
    });
    return response.data;
  }
  async dropNamespace(id) {
    await this.client.request({
      method: "DELETE",
      path: `${this.prefix}/namespaces/${namespaceToPath(id.namespace)}`
    });
  }
  async loadNamespaceMetadata(id) {
    const response = await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces/${namespaceToPath(id.namespace)}`
    });
    return {
      properties: response.data.properties
    };
  }
  async namespaceExists(id) {
    try {
      await this.client.request({
        method: "HEAD",
        path: `${this.prefix}/namespaces/${namespaceToPath(id.namespace)}`
      });
      return true;
    } catch (error) {
      if (error instanceof IcebergError && error.status === 404) {
        return false;
      }
      throw error;
    }
  }
  async createNamespaceIfNotExists(id, metadata) {
    try {
      return await this.createNamespace(id, metadata);
    } catch (error) {
      if (error instanceof IcebergError && error.status === 409) {
        return;
      }
      throw error;
    }
  }
};

// src/catalog/tables.ts
function namespaceToPath2(namespace) {
  return namespace.join("");
}
var TableOperations = class {
  constructor(client, prefix = "", accessDelegation) {
    this.client = client;
    this.prefix = prefix;
    this.accessDelegation = accessDelegation;
  }
  async listTables(namespace) {
    const response = await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces/${namespaceToPath2(namespace.namespace)}/tables`
    });
    return response.data.identifiers;
  }
  async createTable(namespace, request) {
    const headers = {};
    if (this.accessDelegation) {
      headers["X-Iceberg-Access-Delegation"] = this.accessDelegation;
    }
    const response = await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces/${namespaceToPath2(namespace.namespace)}/tables`,
      body: request,
      headers
    });
    return response.data.metadata;
  }
  async updateTable(id, request) {
    const response = await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces/${namespaceToPath2(id.namespace)}/tables/${id.name}`,
      body: request
    });
    return {
      "metadata-location": response.data["metadata-location"],
      metadata: response.data.metadata
    };
  }
  async dropTable(id, options) {
    await this.client.request({
      method: "DELETE",
      path: `${this.prefix}/namespaces/${namespaceToPath2(id.namespace)}/tables/${id.name}`,
      query: { purgeRequested: String(options?.purge ?? false) }
    });
  }
  async loadTable(id) {
    const headers = {};
    if (this.accessDelegation) {
      headers["X-Iceberg-Access-Delegation"] = this.accessDelegation;
    }
    const response = await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces/${namespaceToPath2(id.namespace)}/tables/${id.name}`,
      headers
    });
    return response.data.metadata;
  }
  async tableExists(id) {
    const headers = {};
    if (this.accessDelegation) {
      headers["X-Iceberg-Access-Delegation"] = this.accessDelegation;
    }
    try {
      await this.client.request({
        method: "HEAD",
        path: `${this.prefix}/namespaces/${namespaceToPath2(id.namespace)}/tables/${id.name}`,
        headers
      });
      return true;
    } catch (error) {
      if (error instanceof IcebergError && error.status === 404) {
        return false;
      }
      throw error;
    }
  }
  async createTableIfNotExists(namespace, request) {
    try {
      return await this.createTable(namespace, request);
    } catch (error) {
      if (error instanceof IcebergError && error.status === 409) {
        return await this.loadTable({ namespace: namespace.namespace, name: request.name });
      }
      throw error;
    }
  }
};

// src/catalog/IcebergRestCatalog.ts
var IcebergRestCatalog = class {
  /**
   * Creates a new Iceberg REST Catalog client.
   *
   * @param options - Configuration options for the catalog client
   */
  constructor(options) {
    let prefix = "v1";
    if (options.catalogName) {
      prefix += `/${options.catalogName}`;
    }
    const baseUrl = options.baseUrl.endsWith("/") ? options.baseUrl : `${options.baseUrl}/`;
    this.client = createFetchClient({
      baseUrl,
      auth: options.auth,
      fetchImpl: options.fetch
    });
    this.accessDelegation = options.accessDelegation?.join(",");
    this.namespaceOps = new NamespaceOperations(this.client, prefix);
    this.tableOps = new TableOperations(this.client, prefix, this.accessDelegation);
  }
  /**
   * Lists all namespaces in the catalog.
   *
   * @param parent - Optional parent namespace to list children under
   * @returns Array of namespace identifiers
   *
   * @example
   * ```typescript
   * // List all top-level namespaces
   * const namespaces = await catalog.listNamespaces();
   *
   * // List namespaces under a parent
   * const children = await catalog.listNamespaces({ namespace: ['analytics'] });
   * ```
   */
  async listNamespaces(parent) {
    return this.namespaceOps.listNamespaces(parent);
  }
  /**
   * Creates a new namespace in the catalog.
   *
   * @param id - Namespace identifier to create
   * @param metadata - Optional metadata properties for the namespace
   * @returns Response containing the created namespace and its properties
   *
   * @example
   * ```typescript
   * const response = await catalog.createNamespace(
   *   { namespace: ['analytics'] },
   *   { properties: { owner: 'data-team' } }
   * );
   * console.log(response.namespace); // ['analytics']
   * console.log(response.properties); // { owner: 'data-team', ... }
   * ```
   */
  async createNamespace(id, metadata) {
    return this.namespaceOps.createNamespace(id, metadata);
  }
  /**
   * Drops a namespace from the catalog.
   *
   * The namespace must be empty (contain no tables) before it can be dropped.
   *
   * @param id - Namespace identifier to drop
   *
   * @example
   * ```typescript
   * await catalog.dropNamespace({ namespace: ['analytics'] });
   * ```
   */
  async dropNamespace(id) {
    await this.namespaceOps.dropNamespace(id);
  }
  /**
   * Loads metadata for a namespace.
   *
   * @param id - Namespace identifier to load
   * @returns Namespace metadata including properties
   *
   * @example
   * ```typescript
   * const metadata = await catalog.loadNamespaceMetadata({ namespace: ['analytics'] });
   * console.log(metadata.properties);
   * ```
   */
  async loadNamespaceMetadata(id) {
    return this.namespaceOps.loadNamespaceMetadata(id);
  }
  /**
   * Lists all tables in a namespace.
   *
   * @param namespace - Namespace identifier to list tables from
   * @returns Array of table identifiers
   *
   * @example
   * ```typescript
   * const tables = await catalog.listTables({ namespace: ['analytics'] });
   * console.log(tables); // [{ namespace: ['analytics'], name: 'events' }, ...]
   * ```
   */
  async listTables(namespace) {
    return this.tableOps.listTables(namespace);
  }
  /**
   * Creates a new table in the catalog.
   *
   * @param namespace - Namespace to create the table in
   * @param request - Table creation request including name, schema, partition spec, etc.
   * @returns Table metadata for the created table
   *
   * @example
   * ```typescript
   * const metadata = await catalog.createTable(
   *   { namespace: ['analytics'] },
   *   {
   *     name: 'events',
   *     schema: {
   *       type: 'struct',
   *       fields: [
   *         { id: 1, name: 'id', type: 'long', required: true },
   *         { id: 2, name: 'timestamp', type: 'timestamp', required: true }
   *       ],
   *       'schema-id': 0
   *     },
   *     'partition-spec': {
   *       'spec-id': 0,
   *       fields: [
   *         { source_id: 2, field_id: 1000, name: 'ts_day', transform: 'day' }
   *       ]
   *     }
   *   }
   * );
   * ```
   */
  async createTable(namespace, request) {
    return this.tableOps.createTable(namespace, request);
  }
  /**
   * Updates an existing table's metadata.
   *
   * Can update the schema, partition spec, or properties of a table.
   *
   * @param id - Table identifier to update
   * @param request - Update request with fields to modify
   * @returns Response containing the metadata location and updated table metadata
   *
   * @example
   * ```typescript
   * const response = await catalog.updateTable(
   *   { namespace: ['analytics'], name: 'events' },
   *   {
   *     properties: { 'read.split.target-size': '134217728' }
   *   }
   * );
   * console.log(response['metadata-location']); // s3://...
   * console.log(response.metadata); // TableMetadata object
   * ```
   */
  async updateTable(id, request) {
    return this.tableOps.updateTable(id, request);
  }
  /**
   * Drops a table from the catalog.
   *
   * @param id - Table identifier to drop
   *
   * @example
   * ```typescript
   * await catalog.dropTable({ namespace: ['analytics'], name: 'events' });
   * ```
   */
  async dropTable(id, options) {
    await this.tableOps.dropTable(id, options);
  }
  /**
   * Loads metadata for a table.
   *
   * @param id - Table identifier to load
   * @returns Table metadata including schema, partition spec, location, etc.
   *
   * @example
   * ```typescript
   * const metadata = await catalog.loadTable({ namespace: ['analytics'], name: 'events' });
   * console.log(metadata.schema);
   * console.log(metadata.location);
   * ```
   */
  async loadTable(id) {
    return this.tableOps.loadTable(id);
  }
  /**
   * Checks if a namespace exists in the catalog.
   *
   * @param id - Namespace identifier to check
   * @returns True if the namespace exists, false otherwise
   *
   * @example
   * ```typescript
   * const exists = await catalog.namespaceExists({ namespace: ['analytics'] });
   * console.log(exists); // true or false
   * ```
   */
  async namespaceExists(id) {
    return this.namespaceOps.namespaceExists(id);
  }
  /**
   * Checks if a table exists in the catalog.
   *
   * @param id - Table identifier to check
   * @returns True if the table exists, false otherwise
   *
   * @example
   * ```typescript
   * const exists = await catalog.tableExists({ namespace: ['analytics'], name: 'events' });
   * console.log(exists); // true or false
   * ```
   */
  async tableExists(id) {
    return this.tableOps.tableExists(id);
  }
  /**
   * Creates a namespace if it does not exist.
   *
   * If the namespace already exists, returns void. If created, returns the response.
   *
   * @param id - Namespace identifier to create
   * @param metadata - Optional metadata properties for the namespace
   * @returns Response containing the created namespace and its properties, or void if it already exists
   *
   * @example
   * ```typescript
   * const response = await catalog.createNamespaceIfNotExists(
   *   { namespace: ['analytics'] },
   *   { properties: { owner: 'data-team' } }
   * );
   * if (response) {
   *   console.log('Created:', response.namespace);
   * } else {
   *   console.log('Already exists');
   * }
   * ```
   */
  async createNamespaceIfNotExists(id, metadata) {
    return this.namespaceOps.createNamespaceIfNotExists(id, metadata);
  }
  /**
   * Creates a table if it does not exist.
   *
   * If the table already exists, returns its metadata instead.
   *
   * @param namespace - Namespace to create the table in
   * @param request - Table creation request including name, schema, partition spec, etc.
   * @returns Table metadata for the created or existing table
   *
   * @example
   * ```typescript
   * const metadata = await catalog.createTableIfNotExists(
   *   { namespace: ['analytics'] },
   *   {
   *     name: 'events',
   *     schema: {
   *       type: 'struct',
   *       fields: [
   *         { id: 1, name: 'id', type: 'long', required: true },
   *         { id: 2, name: 'timestamp', type: 'timestamp', required: true }
   *       ],
   *       'schema-id': 0
   *     }
   *   }
   * );
   * ```
   */
  async createTableIfNotExists(namespace, request) {
    return this.tableOps.createTableIfNotExists(namespace, request);
  }
};

// src/catalog/types.ts
var DECIMAL_REGEX = /^decimal\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)$/;
var FIXED_REGEX = /^fixed\s*\[\s*(\d+)\s*\]$/;
function parseDecimalType(type) {
  const match = type.match(DECIMAL_REGEX);
  if (!match) return null;
  return {
    precision: parseInt(match[1], 10),
    scale: parseInt(match[2], 10)
  };
}
function parseFixedType(type) {
  const match = type.match(FIXED_REGEX);
  if (!match) return null;
  return {
    length: parseInt(match[1], 10)
  };
}
function isDecimalType(type) {
  return DECIMAL_REGEX.test(type);
}
function isFixedType(type) {
  return FIXED_REGEX.test(type);
}
function typesEqual(a, b) {
  const decimalA = parseDecimalType(a);
  const decimalB = parseDecimalType(b);
  if (decimalA && decimalB) {
    return decimalA.precision === decimalB.precision && decimalA.scale === decimalB.scale;
  }
  const fixedA = parseFixedType(a);
  const fixedB = parseFixedType(b);
  if (fixedA && fixedB) {
    return fixedA.length === fixedB.length;
  }
  return a === b;
}
function getCurrentSchema(metadata) {
  return metadata.schemas.find((s) => s["schema-id"] === metadata["current-schema-id"]);
}

export { IcebergError, IcebergRestCatalog, getCurrentSchema, isDecimalType, isFixedType, parseDecimalType, parseFixedType, typesEqual };
                                  
                                  
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9lcnJvcnMvSWNlYmVyZ0Vycm9yLnRzIiwiLi4vc3JjL3V0aWxzL3VybC50cyIsIi4uL3NyYy9odHRwL2NyZWF0ZUZldGNoQ2xpZW50LnRzIiwiLi4vc3JjL2NhdGFsb2cvbmFtZXNwYWNlcy50cyIsIi4uL3NyYy9jYXRhbG9nL3RhYmxlcy50cyIsIi4uL3NyYy9jYXRhbG9nL0ljZWJlcmdSZXN0Q2F0YWxvZy50cyIsIi4uL3NyYy9jYXRhbG9nL3R5cGVzLnRzIl0sIm5hbWVzIjpbIm5hbWVzcGFjZVRvUGF0aCJdLCJtYXBwaW5ncyI6IjtBQVNPLElBQU0sWUFBQSxHQUFOLGNBQTJCLEtBQUEsQ0FBTTtBQUFBLEVBT3RDLFdBQUEsQ0FDRSxTQUNBLElBQUEsRUFNQTtBQUNBLElBQUEsS0FBQSxDQUFNLE9BQU8sQ0FBQTtBQUNiLElBQUEsSUFBQSxDQUFLLElBQUEsR0FBTyxjQUFBO0FBQ1osSUFBQSxJQUFBLENBQUssU0FBUyxJQUFBLENBQUssTUFBQTtBQUNuQixJQUFBLElBQUEsQ0FBSyxjQUFjLElBQUEsQ0FBSyxXQUFBO0FBQ3hCLElBQUEsSUFBQSxDQUFLLGNBQWMsSUFBQSxDQUFLLFdBQUE7QUFDeEIsSUFBQSxJQUFBLENBQUssVUFBVSxJQUFBLENBQUssT0FBQTtBQUdwQixJQUFBLElBQUEsQ0FBSyx1QkFDSCxJQUFBLENBQUssV0FBQSxLQUFnQiw2QkFBQSxJQUNwQixDQUFDLEtBQUssR0FBQSxFQUFLLEdBQUcsQ0FBQSxDQUFFLFFBQUEsQ0FBUyxLQUFLLE1BQU0sQ0FBQSxJQUFLLEtBQUssV0FBQSxFQUFhLFFBQUEsQ0FBUyxhQUFhLENBQUEsS0FBTSxJQUFBO0FBQUEsRUFDNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLFVBQUEsR0FBc0I7QUFDcEIsSUFBQSxPQUFPLEtBQUssTUFBQSxLQUFXLEdBQUE7QUFBQSxFQUN6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsVUFBQSxHQUFzQjtBQUNwQixJQUFBLE9BQU8sS0FBSyxNQUFBLEtBQVcsR0FBQTtBQUFBLEVBQ3pCO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSx1QkFBQSxHQUFtQztBQUNqQyxJQUFBLE9BQU8sS0FBSyxNQUFBLEtBQVcsR0FBQTtBQUFBLEVBQ3pCO0FBQ0Y7OztBQzFETyxTQUFTLFFBQUEsQ0FDZCxPQUFBLEVBQ0EsSUFBQSxFQUNBLEtBQUEsRUFDUTtBQUNSLEVBQUEsTUFBTSxHQUFBLEdBQU0sSUFBSSxHQUFBLENBQUksSUFBQSxFQUFNLE9BQU8sQ0FBQTtBQUVqQyxFQUFBLElBQUksS0FBQSxFQUFPO0FBQ1QsSUFBQSxLQUFBLE1BQVcsQ0FBQyxHQUFBLEVBQUssS0FBSyxLQUFLLE1BQUEsQ0FBTyxPQUFBLENBQVEsS0FBSyxDQUFBLEVBQUc7QUFDaEQsTUFBQSxJQUFJLFVBQVUsTUFBQSxFQUFXO0FBQ3ZCLFFBQUEsR0FBQSxDQUFJLFlBQUEsQ0FBYSxHQUFBLENBQUksR0FBQSxFQUFLLEtBQUssQ0FBQTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxFQUFBLE9BQU8sSUFBSSxRQUFBLEVBQVM7QUFDdEI7OztBQ1pBLGVBQWUsaUJBQWlCLElBQUEsRUFBb0Q7QUFDbEYsRUFBQSxJQUFJLENBQUMsSUFBQSxJQUFRLElBQUEsQ0FBSyxJQUFBLEtBQVMsTUFBQSxFQUFRO0FBQ2pDLElBQUEsT0FBTyxFQUFDO0FBQUEsRUFDVjtBQUVBLEVBQUEsSUFBSSxJQUFBLENBQUssU0FBUyxRQUFBLEVBQVU7QUFDMUIsSUFBQSxPQUFPLEVBQUUsYUFBQSxFQUFlLENBQUEsT0FBQSxFQUFVLElBQUEsQ0FBSyxLQUFLLENBQUEsQ0FBQSxFQUFHO0FBQUEsRUFDakQ7QUFFQSxFQUFBLElBQUksSUFBQSxDQUFLLFNBQVMsUUFBQSxFQUFVO0FBQzFCLElBQUEsT0FBTyxFQUFFLENBQUMsSUFBQSxDQUFLLElBQUksR0FBRyxLQUFLLEtBQUEsRUFBTTtBQUFBLEVBQ25DO0FBRUEsRUFBQSxJQUFJLElBQUEsQ0FBSyxTQUFTLFFBQUEsRUFBVTtBQUMxQixJQUFBLE9BQU8sTUFBTSxLQUFLLFVBQUEsRUFBVztBQUFBLEVBQy9CO0FBRUEsRUFBQSxPQUFPLEVBQUM7QUFDVjtBQUVPLFNBQVMsa0JBQWtCLE9BQUEsRUFJbkI7QUFDYixFQUFBLE1BQU0sT0FBQSxHQUFVLE9BQUEsQ0FBUSxTQUFBLElBQWEsVUFBQSxDQUFXLEtBQUE7QUFFaEQsRUFBQSxPQUFPO0FBQUEsSUFDTCxNQUFNLE9BQUEsQ0FBVztBQUFBLE1BQ2YsTUFBQTtBQUFBLE1BQ0EsSUFBQTtBQUFBLE1BQ0EsS0FBQTtBQUFBLE1BQ0EsSUFBQTtBQUFBLE1BQ0E7QUFBQSxLQUNGLEVBQTBDO0FBQ3hDLE1BQUEsTUFBTSxHQUFBLEdBQU0sUUFBQSxDQUFTLE9BQUEsQ0FBUSxPQUFBLEVBQVMsTUFBTSxLQUFLLENBQUE7QUFDakQsTUFBQSxNQUFNLFdBQUEsR0FBYyxNQUFNLGdCQUFBLENBQWlCLE9BQUEsQ0FBUSxJQUFJLENBQUE7QUFFdkQsTUFBQSxNQUFNLEdBQUEsR0FBTSxNQUFNLE9BQUEsQ0FBUSxHQUFBLEVBQUs7QUFBQSxRQUM3QixNQUFBO0FBQUEsUUFDQSxPQUFBLEVBQVM7QUFBQSxVQUNQLEdBQUksSUFBQSxHQUFPLEVBQUUsY0FBQSxFQUFnQixrQkFBQSxLQUF1QixFQUFDO0FBQUEsVUFDckQsR0FBRyxXQUFBO0FBQUEsVUFDSCxHQUFHO0FBQUEsU0FDTDtBQUFBLFFBQ0EsSUFBQSxFQUFNLElBQUEsR0FBTyxJQUFBLENBQUssU0FBQSxDQUFVLElBQUksQ0FBQSxHQUFJO0FBQUEsT0FDckMsQ0FBQTtBQUVELE1BQUEsTUFBTSxJQUFBLEdBQU8sTUFBTSxHQUFBLENBQUksSUFBQSxFQUFLO0FBQzVCLE1BQUEsTUFBTSxNQUFBLEdBQUEsQ0FBVSxJQUFJLE9BQUEsQ0FBUSxHQUFBLENBQUksY0FBYyxDQUFBLElBQUssRUFBQSxFQUFJLFNBQVMsa0JBQWtCLENBQUE7QUFDbEYsTUFBQSxNQUFNLE9BQU8sTUFBQSxJQUFVLElBQUEsR0FBUSxJQUFBLENBQUssS0FBQSxDQUFNLElBQUksQ0FBQSxHQUFXLElBQUE7QUFFekQsTUFBQSxJQUFJLENBQUMsSUFBSSxFQUFBLEVBQUk7QUFDWCxRQUFBLE1BQU0sT0FBQSxHQUFVLFNBQVUsSUFBQSxHQUFnQyxNQUFBO0FBQzFELFFBQUEsTUFBTSxjQUFjLE9BQUEsRUFBUyxLQUFBO0FBQzdCLFFBQUEsTUFBTSxJQUFJLFlBQUE7QUFBQSxVQUNSLFdBQUEsRUFBYSxPQUFBLElBQVcsQ0FBQSwyQkFBQSxFQUE4QixHQUFBLENBQUksTUFBTSxDQUFBLENBQUE7QUFBQSxVQUNoRTtBQUFBLFlBQ0UsUUFBUSxHQUFBLENBQUksTUFBQTtBQUFBLFlBQ1osYUFBYSxXQUFBLEVBQWEsSUFBQTtBQUFBLFlBQzFCLGFBQWEsV0FBQSxFQUFhLElBQUE7QUFBQSxZQUMxQixPQUFBLEVBQVM7QUFBQTtBQUNYLFNBQ0Y7QUFBQSxNQUNGO0FBRUEsTUFBQSxPQUFPLEVBQUUsTUFBQSxFQUFRLEdBQUEsQ0FBSSxRQUFRLE9BQUEsRUFBUyxHQUFBLENBQUksU0FBUyxJQUFBLEVBQWdCO0FBQUEsSUFDckU7QUFBQSxHQUNGO0FBQ0Y7OztBQzlEQSxTQUFTLGdCQUFnQixTQUFBLEVBQTZCO0FBQ3BELEVBQUEsT0FBTyxTQUFBLENBQVUsS0FBSyxHQUFNLENBQUE7QUFDOUI7QUFFTyxJQUFNLHNCQUFOLE1BQTBCO0FBQUEsRUFDL0IsV0FBQSxDQUNtQixNQUFBLEVBQ0EsTUFBQSxHQUFpQixFQUFBLEVBQ2xDO0FBRmlCLElBQUEsSUFBQSxDQUFBLE1BQUEsR0FBQSxNQUFBO0FBQ0EsSUFBQSxJQUFBLENBQUEsTUFBQSxHQUFBLE1BQUE7QUFBQSxFQUNoQjtBQUFBLEVBRUgsTUFBTSxlQUFlLE1BQUEsRUFBOEQ7QUFDakYsSUFBQSxNQUFNLEtBQUEsR0FBUSxTQUFTLEVBQUUsTUFBQSxFQUFRLGdCQUFnQixNQUFBLENBQU8sU0FBUyxHQUFFLEdBQUksTUFBQTtBQUV2RSxJQUFBLE1BQU0sUUFBQSxHQUFXLE1BQU0sSUFBQSxDQUFLLE1BQUEsQ0FBTyxPQUFBLENBQWdDO0FBQUEsTUFDakUsTUFBQSxFQUFRLEtBQUE7QUFBQSxNQUNSLElBQUEsRUFBTSxDQUFBLEVBQUcsSUFBQSxDQUFLLE1BQU0sQ0FBQSxXQUFBLENBQUE7QUFBQSxNQUNwQjtBQUFBLEtBQ0QsQ0FBQTtBQUVELElBQUEsT0FBTyxRQUFBLENBQVMsS0FBSyxVQUFBLENBQVcsR0FBQSxDQUFJLENBQUMsRUFBQSxNQUFRLEVBQUUsU0FBQSxFQUFXLEVBQUEsRUFBRyxDQUFFLENBQUE7QUFBQSxFQUNqRTtBQUFBLEVBRUEsTUFBTSxlQUFBLENBQ0osRUFBQSxFQUNBLFFBQUEsRUFDa0M7QUFDbEMsSUFBQSxNQUFNLE9BQUEsR0FBa0M7QUFBQSxNQUN0QyxXQUFXLEVBQUEsQ0FBRyxTQUFBO0FBQUEsTUFDZCxZQUFZLFFBQUEsRUFBVTtBQUFBLEtBQ3hCO0FBRUEsSUFBQSxNQUFNLFFBQUEsR0FBVyxNQUFNLElBQUEsQ0FBSyxNQUFBLENBQU8sT0FBQSxDQUFpQztBQUFBLE1BQ2xFLE1BQUEsRUFBUSxNQUFBO0FBQUEsTUFDUixJQUFBLEVBQU0sQ0FBQSxFQUFHLElBQUEsQ0FBSyxNQUFNLENBQUEsV0FBQSxDQUFBO0FBQUEsTUFDcEIsSUFBQSxFQUFNO0FBQUEsS0FDUCxDQUFBO0FBRUQsSUFBQSxPQUFPLFFBQUEsQ0FBUyxJQUFBO0FBQUEsRUFDbEI7QUFBQSxFQUVBLE1BQU0sY0FBYyxFQUFBLEVBQXdDO0FBQzFELElBQUEsTUFBTSxJQUFBLENBQUssT0FBTyxPQUFBLENBQWM7QUFBQSxNQUM5QixNQUFBLEVBQVEsUUFBQTtBQUFBLE1BQ1IsSUFBQSxFQUFNLEdBQUcsSUFBQSxDQUFLLE1BQU0sZUFBZSxlQUFBLENBQWdCLEVBQUEsQ0FBRyxTQUFTLENBQUMsQ0FBQTtBQUFBLEtBQ2pFLENBQUE7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLHNCQUFzQixFQUFBLEVBQXFEO0FBQy9FLElBQUEsTUFBTSxRQUFBLEdBQVcsTUFBTSxJQUFBLENBQUssTUFBQSxDQUFPLE9BQUEsQ0FBOEI7QUFBQSxNQUMvRCxNQUFBLEVBQVEsS0FBQTtBQUFBLE1BQ1IsSUFBQSxFQUFNLEdBQUcsSUFBQSxDQUFLLE1BQU0sZUFBZSxlQUFBLENBQWdCLEVBQUEsQ0FBRyxTQUFTLENBQUMsQ0FBQTtBQUFBLEtBQ2pFLENBQUE7QUFFRCxJQUFBLE9BQU87QUFBQSxNQUNMLFVBQUEsRUFBWSxTQUFTLElBQUEsQ0FBSztBQUFBLEtBQzVCO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxnQkFBZ0IsRUFBQSxFQUEyQztBQUMvRCxJQUFBLElBQUk7QUFDRixNQUFBLE1BQU0sSUFBQSxDQUFLLE9BQU8sT0FBQSxDQUFjO0FBQUEsUUFDOUIsTUFBQSxFQUFRLE1BQUE7QUFBQSxRQUNSLElBQUEsRUFBTSxHQUFHLElBQUEsQ0FBSyxNQUFNLGVBQWUsZUFBQSxDQUFnQixFQUFBLENBQUcsU0FBUyxDQUFDLENBQUE7QUFBQSxPQUNqRSxDQUFBO0FBQ0QsTUFBQSxPQUFPLElBQUE7QUFBQSxJQUNULFNBQVMsS0FBQSxFQUFPO0FBQ2QsTUFBQSxJQUFJLEtBQUEsWUFBaUIsWUFBQSxJQUFnQixLQUFBLENBQU0sTUFBQSxLQUFXLEdBQUEsRUFBSztBQUN6RCxRQUFBLE9BQU8sS0FBQTtBQUFBLE1BQ1Q7QUFDQSxNQUFBLE1BQU0sS0FBQTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFNLDBCQUFBLENBQ0osRUFBQSxFQUNBLFFBQUEsRUFDeUM7QUFDekMsSUFBQSxJQUFJO0FBQ0YsTUFBQSxPQUFPLE1BQU0sSUFBQSxDQUFLLGVBQUEsQ0FBZ0IsRUFBQSxFQUFJLFFBQVEsQ0FBQTtBQUFBLElBQ2hELFNBQVMsS0FBQSxFQUFPO0FBQ2QsTUFBQSxJQUFJLEtBQUEsWUFBaUIsWUFBQSxJQUFnQixLQUFBLENBQU0sTUFBQSxLQUFXLEdBQUEsRUFBSztBQUN6RCxRQUFBO0FBQUEsTUFDRjtBQUNBLE1BQUEsTUFBTSxLQUFBO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDRixDQUFBOzs7QUNuRkEsU0FBU0EsaUJBQWdCLFNBQUEsRUFBNkI7QUFDcEQsRUFBQSxPQUFPLFNBQUEsQ0FBVSxLQUFLLEdBQU0sQ0FBQTtBQUM5QjtBQUVPLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUMzQixXQUFBLENBQ21CLE1BQUEsRUFDQSxNQUFBLEdBQWlCLEVBQUEsRUFDakIsZ0JBQUEsRUFDakI7QUFIaUIsSUFBQSxJQUFBLENBQUEsTUFBQSxHQUFBLE1BQUE7QUFDQSxJQUFBLElBQUEsQ0FBQSxNQUFBLEdBQUEsTUFBQTtBQUNBLElBQUEsSUFBQSxDQUFBLGdCQUFBLEdBQUEsZ0JBQUE7QUFBQSxFQUNoQjtBQUFBLEVBRUgsTUFBTSxXQUFXLFNBQUEsRUFBNEQ7QUFDM0UsSUFBQSxNQUFNLFFBQUEsR0FBVyxNQUFNLElBQUEsQ0FBSyxNQUFBLENBQU8sT0FBQSxDQUE0QjtBQUFBLE1BQzdELE1BQUEsRUFBUSxLQUFBO0FBQUEsTUFDUixJQUFBLEVBQU0sR0FBRyxJQUFBLENBQUssTUFBTSxlQUFlQSxnQkFBQUEsQ0FBZ0IsU0FBQSxDQUFVLFNBQVMsQ0FBQyxDQUFBLE9BQUE7QUFBQSxLQUN4RSxDQUFBO0FBRUQsSUFBQSxPQUFPLFNBQVMsSUFBQSxDQUFLLFdBQUE7QUFBQSxFQUN2QjtBQUFBLEVBRUEsTUFBTSxXQUFBLENBQ0osU0FBQSxFQUNBLE9BQUEsRUFDd0I7QUFDeEIsSUFBQSxNQUFNLFVBQWtDLEVBQUM7QUFDekMsSUFBQSxJQUFJLEtBQUssZ0JBQUEsRUFBa0I7QUFDekIsTUFBQSxPQUFBLENBQVEsNkJBQTZCLElBQUksSUFBQSxDQUFLLGdCQUFBO0FBQUEsSUFDaEQ7QUFFQSxJQUFBLE1BQU0sUUFBQSxHQUFXLE1BQU0sSUFBQSxDQUFLLE1BQUEsQ0FBTyxPQUFBLENBQTJCO0FBQUEsTUFDNUQsTUFBQSxFQUFRLE1BQUE7QUFBQSxNQUNSLElBQUEsRUFBTSxHQUFHLElBQUEsQ0FBSyxNQUFNLGVBQWVBLGdCQUFBQSxDQUFnQixTQUFBLENBQVUsU0FBUyxDQUFDLENBQUEsT0FBQSxDQUFBO0FBQUEsTUFDdkUsSUFBQSxFQUFNLE9BQUE7QUFBQSxNQUNOO0FBQUEsS0FDRCxDQUFBO0FBRUQsSUFBQSxPQUFPLFNBQVMsSUFBQSxDQUFLLFFBQUE7QUFBQSxFQUN2QjtBQUFBLEVBRUEsTUFBTSxXQUFBLENBQVksRUFBQSxFQUFxQixPQUFBLEVBQTJEO0FBQ2hHLElBQUEsTUFBTSxRQUFBLEdBQVcsTUFBTSxJQUFBLENBQUssTUFBQSxDQUFPLE9BQUEsQ0FBMkI7QUFBQSxNQUM1RCxNQUFBLEVBQVEsTUFBQTtBQUFBLE1BQ1IsSUFBQSxFQUFNLENBQUEsRUFBRyxJQUFBLENBQUssTUFBTSxDQUFBLFlBQUEsRUFBZUEsZ0JBQUFBLENBQWdCLEVBQUEsQ0FBRyxTQUFTLENBQUMsQ0FBQSxRQUFBLEVBQVcsRUFBQSxDQUFHLElBQUksQ0FBQSxDQUFBO0FBQUEsTUFDbEYsSUFBQSxFQUFNO0FBQUEsS0FDUCxDQUFBO0FBRUQsSUFBQSxPQUFPO0FBQUEsTUFDTCxtQkFBQSxFQUFxQixRQUFBLENBQVMsSUFBQSxDQUFLLG1CQUFtQixDQUFBO0FBQUEsTUFDdEQsUUFBQSxFQUFVLFNBQVMsSUFBQSxDQUFLO0FBQUEsS0FDMUI7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFNLFNBQUEsQ0FBVSxFQUFBLEVBQXFCLE9BQUEsRUFBMkM7QUFDOUUsSUFBQSxNQUFNLElBQUEsQ0FBSyxPQUFPLE9BQUEsQ0FBYztBQUFBLE1BQzlCLE1BQUEsRUFBUSxRQUFBO0FBQUEsTUFDUixJQUFBLEVBQU0sQ0FBQSxFQUFHLElBQUEsQ0FBSyxNQUFNLENBQUEsWUFBQSxFQUFlQSxnQkFBQUEsQ0FBZ0IsRUFBQSxDQUFHLFNBQVMsQ0FBQyxDQUFBLFFBQUEsRUFBVyxFQUFBLENBQUcsSUFBSSxDQUFBLENBQUE7QUFBQSxNQUNsRixPQUFPLEVBQUUsY0FBQSxFQUFnQixPQUFPLE9BQUEsRUFBUyxLQUFBLElBQVMsS0FBSyxDQUFBO0FBQUUsS0FDMUQsQ0FBQTtBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQU0sVUFBVSxFQUFBLEVBQTZDO0FBQzNELElBQUEsTUFBTSxVQUFrQyxFQUFDO0FBQ3pDLElBQUEsSUFBSSxLQUFLLGdCQUFBLEVBQWtCO0FBQ3pCLE1BQUEsT0FBQSxDQUFRLDZCQUE2QixJQUFJLElBQUEsQ0FBSyxnQkFBQTtBQUFBLElBQ2hEO0FBRUEsSUFBQSxNQUFNLFFBQUEsR0FBVyxNQUFNLElBQUEsQ0FBSyxNQUFBLENBQU8sT0FBQSxDQUEyQjtBQUFBLE1BQzVELE1BQUEsRUFBUSxLQUFBO0FBQUEsTUFDUixJQUFBLEVBQU0sQ0FBQSxFQUFHLElBQUEsQ0FBSyxNQUFNLENBQUEsWUFBQSxFQUFlQSxnQkFBQUEsQ0FBZ0IsRUFBQSxDQUFHLFNBQVMsQ0FBQyxDQUFBLFFBQUEsRUFBVyxFQUFBLENBQUcsSUFBSSxDQUFBLENBQUE7QUFBQSxNQUNsRjtBQUFBLEtBQ0QsQ0FBQTtBQUVELElBQUEsT0FBTyxTQUFTLElBQUEsQ0FBSyxRQUFBO0FBQUEsRUFDdkI7QUFBQSxFQUVBLE1BQU0sWUFBWSxFQUFBLEVBQXVDO0FBQ3ZELElBQUEsTUFBTSxVQUFrQyxFQUFDO0FBQ3pDLElBQUEsSUFBSSxLQUFLLGdCQUFBLEVBQWtCO0FBQ3pCLE1BQUEsT0FBQSxDQUFRLDZCQUE2QixJQUFJLElBQUEsQ0FBSyxnQkFBQTtBQUFBLElBQ2hEO0FBRUEsSUFBQSxJQUFJO0FBQ0YsTUFBQSxNQUFNLElBQUEsQ0FBSyxPQUFPLE9BQUEsQ0FBYztBQUFBLFFBQzlCLE1BQUEsRUFBUSxNQUFBO0FBQUEsUUFDUixJQUFBLEVBQU0sQ0FBQSxFQUFHLElBQUEsQ0FBSyxNQUFNLENBQUEsWUFBQSxFQUFlQSxnQkFBQUEsQ0FBZ0IsRUFBQSxDQUFHLFNBQVMsQ0FBQyxDQUFBLFFBQUEsRUFBVyxFQUFBLENBQUcsSUFBSSxDQUFBLENBQUE7QUFBQSxRQUNsRjtBQUFBLE9BQ0QsQ0FBQTtBQUNELE1BQUEsT0FBTyxJQUFBO0FBQUEsSUFDVCxTQUFTLEtBQUEsRUFBTztBQUNkLE1BQUEsSUFBSSxLQUFBLFlBQWlCLFlBQUEsSUFBZ0IsS0FBQSxDQUFNLE1BQUEsS0FBVyxHQUFBLEVBQUs7QUFDekQsUUFBQSxPQUFPLEtBQUE7QUFBQSxNQUNUO0FBQ0EsTUFBQSxNQUFNLEtBQUE7QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxzQkFBQSxDQUNKLFNBQUEsRUFDQSxPQUFBLEVBQ3dCO0FBQ3hCLElBQUEsSUFBSTtBQUNGLE1BQUEsT0FBTyxNQUFNLElBQUEsQ0FBSyxXQUFBLENBQVksU0FBQSxFQUFXLE9BQU8sQ0FBQTtBQUFBLElBQ2xELFNBQVMsS0FBQSxFQUFPO0FBQ2QsTUFBQSxJQUFJLEtBQUEsWUFBaUIsWUFBQSxJQUFnQixLQUFBLENBQU0sTUFBQSxLQUFXLEdBQUEsRUFBSztBQUN6RCxRQUFBLE9BQU8sTUFBTSxJQUFBLENBQUssU0FBQSxDQUFVLEVBQUUsU0FBQSxFQUFXLFVBQVUsU0FBQSxFQUFXLElBQUEsRUFBTSxPQUFBLENBQVEsSUFBQSxFQUFNLENBQUE7QUFBQSxNQUNwRjtBQUNBLE1BQUEsTUFBTSxLQUFBO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDRixDQUFBOzs7QUNsRE8sSUFBTSxxQkFBTixNQUF5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVc5QixZQUFZLE9BQUEsRUFBb0M7QUFDOUMsSUFBQSxJQUFJLE1BQUEsR0FBUyxJQUFBO0FBQ2IsSUFBQSxJQUFJLFFBQVEsV0FBQSxFQUFhO0FBQ3ZCLE1BQUEsTUFBQSxJQUFVLENBQUEsQ0FBQSxFQUFJLFFBQVEsV0FBVyxDQUFBLENBQUE7QUFBQSxJQUNuQztBQUVBLElBQUEsTUFBTSxPQUFBLEdBQVUsT0FBQSxDQUFRLE9BQUEsQ0FBUSxRQUFBLENBQVMsR0FBRyxJQUFJLE9BQUEsQ0FBUSxPQUFBLEdBQVUsQ0FBQSxFQUFHLE9BQUEsQ0FBUSxPQUFPLENBQUEsQ0FBQSxDQUFBO0FBRXBGLElBQUEsSUFBQSxDQUFLLFNBQVMsaUJBQUEsQ0FBa0I7QUFBQSxNQUM5QixPQUFBO0FBQUEsTUFDQSxNQUFNLE9BQUEsQ0FBUSxJQUFBO0FBQUEsTUFDZCxXQUFXLE9BQUEsQ0FBUTtBQUFBLEtBQ3BCLENBQUE7QUFHRCxJQUFBLElBQUEsQ0FBSyxnQkFBQSxHQUFtQixPQUFBLENBQVEsZ0JBQUEsRUFBa0IsSUFBQSxDQUFLLEdBQUcsQ0FBQTtBQUUxRCxJQUFBLElBQUEsQ0FBSyxZQUFBLEdBQWUsSUFBSSxtQkFBQSxDQUFvQixJQUFBLENBQUssUUFBUSxNQUFNLENBQUE7QUFDL0QsSUFBQSxJQUFBLENBQUssV0FBVyxJQUFJLGVBQUEsQ0FBZ0IsS0FBSyxNQUFBLEVBQVEsTUFBQSxFQUFRLEtBQUssZ0JBQWdCLENBQUE7QUFBQSxFQUNoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBaUJBLE1BQU0sZUFBZSxNQUFBLEVBQThEO0FBQ2pGLElBQUEsT0FBTyxJQUFBLENBQUssWUFBQSxDQUFhLGNBQUEsQ0FBZSxNQUFNLENBQUE7QUFBQSxFQUNoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1CQSxNQUFNLGVBQUEsQ0FBZ0IsRUFBQSxFQUF5QixRQUFBLEVBQWdFO0FBQzdHLElBQUEsT0FBTyxJQUFBLENBQUssWUFBQSxDQUFhLGVBQUEsQ0FBZ0IsRUFBQSxFQUFJLFFBQVEsQ0FBQTtBQUFBLEVBQ3ZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjQSxNQUFNLGNBQWMsRUFBQSxFQUF3QztBQUMxRCxJQUFBLE1BQU0sSUFBQSxDQUFLLFlBQUEsQ0FBYSxhQUFBLENBQWMsRUFBRSxDQUFBO0FBQUEsRUFDMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWNBLE1BQU0sc0JBQXNCLEVBQUEsRUFBcUQ7QUFDL0UsSUFBQSxPQUFPLElBQUEsQ0FBSyxZQUFBLENBQWEscUJBQUEsQ0FBc0IsRUFBRSxDQUFBO0FBQUEsRUFDbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWNBLE1BQU0sV0FBVyxTQUFBLEVBQTREO0FBQzNFLElBQUEsT0FBTyxJQUFBLENBQUssUUFBQSxDQUFTLFVBQUEsQ0FBVyxTQUFTLENBQUE7QUFBQSxFQUMzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpQ0EsTUFBTSxXQUFBLENBQ0osU0FBQSxFQUNBLE9BQUEsRUFDd0I7QUFDeEIsSUFBQSxPQUFPLElBQUEsQ0FBSyxRQUFBLENBQVMsV0FBQSxDQUFZLFNBQUEsRUFBVyxPQUFPLENBQUE7QUFBQSxFQUNyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBdUJBLE1BQU0sV0FBQSxDQUFZLEVBQUEsRUFBcUIsT0FBQSxFQUEyRDtBQUNoRyxJQUFBLE9BQU8sSUFBQSxDQUFLLFFBQUEsQ0FBUyxXQUFBLENBQVksRUFBQSxFQUFJLE9BQU8sQ0FBQTtBQUFBLEVBQzlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVlBLE1BQU0sU0FBQSxDQUFVLEVBQUEsRUFBcUIsT0FBQSxFQUEyQztBQUM5RSxJQUFBLE1BQU0sSUFBQSxDQUFLLFFBQUEsQ0FBUyxTQUFBLENBQVUsRUFBQSxFQUFJLE9BQU8sQ0FBQTtBQUFBLEVBQzNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWVBLE1BQU0sVUFBVSxFQUFBLEVBQTZDO0FBQzNELElBQUEsT0FBTyxJQUFBLENBQUssUUFBQSxDQUFTLFNBQUEsQ0FBVSxFQUFFLENBQUE7QUFBQSxFQUNuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBY0EsTUFBTSxnQkFBZ0IsRUFBQSxFQUEyQztBQUMvRCxJQUFBLE9BQU8sSUFBQSxDQUFLLFlBQUEsQ0FBYSxlQUFBLENBQWdCLEVBQUUsQ0FBQTtBQUFBLEVBQzdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjQSxNQUFNLFlBQVksRUFBQSxFQUF1QztBQUN2RCxJQUFBLE9BQU8sSUFBQSxDQUFLLFFBQUEsQ0FBUyxXQUFBLENBQVksRUFBRSxDQUFBO0FBQUEsRUFDckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBd0JBLE1BQU0sMEJBQUEsQ0FDSixFQUFBLEVBQ0EsUUFBQSxFQUN5QztBQUN6QyxJQUFBLE9BQU8sSUFBQSxDQUFLLFlBQUEsQ0FBYSwwQkFBQSxDQUEyQixFQUFBLEVBQUksUUFBUSxDQUFBO0FBQUEsRUFDbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTZCQSxNQUFNLHNCQUFBLENBQ0osU0FBQSxFQUNBLE9BQUEsRUFDd0I7QUFDeEIsSUFBQSxPQUFPLElBQUEsQ0FBSyxRQUFBLENBQVMsc0JBQUEsQ0FBdUIsU0FBQSxFQUFXLE9BQU8sQ0FBQTtBQUFBLEVBQ2hFO0FBQ0Y7OztBQ3BWQSxJQUFNLGFBQUEsR0FBZ0IseUNBQUE7QUFDdEIsSUFBTSxXQUFBLEdBQWMsMkJBQUE7QUFTYixTQUFTLGlCQUFpQixJQUFBLEVBQTJEO0FBQzFGLEVBQUEsTUFBTSxLQUFBLEdBQVEsSUFBQSxDQUFLLEtBQUEsQ0FBTSxhQUFhLENBQUE7QUFDdEMsRUFBQSxJQUFJLENBQUMsT0FBTyxPQUFPLElBQUE7QUFDbkIsRUFBQSxPQUFPO0FBQUEsSUFDTCxTQUFBLEVBQVcsUUFBQSxDQUFTLEtBQUEsQ0FBTSxDQUFDLEdBQUcsRUFBRSxDQUFBO0FBQUEsSUFDaEMsS0FBQSxFQUFPLFFBQUEsQ0FBUyxLQUFBLENBQU0sQ0FBQyxHQUFHLEVBQUU7QUFBQSxHQUM5QjtBQUNGO0FBU08sU0FBUyxlQUFlLElBQUEsRUFBeUM7QUFDdEUsRUFBQSxNQUFNLEtBQUEsR0FBUSxJQUFBLENBQUssS0FBQSxDQUFNLFdBQVcsQ0FBQTtBQUNwQyxFQUFBLElBQUksQ0FBQyxPQUFPLE9BQU8sSUFBQTtBQUNuQixFQUFBLE9BQU87QUFBQSxJQUNMLE1BQUEsRUFBUSxRQUFBLENBQVMsS0FBQSxDQUFNLENBQUMsR0FBRyxFQUFFO0FBQUEsR0FDL0I7QUFDRjtBQUtPLFNBQVMsY0FBYyxJQUFBLEVBQXVCO0FBQ25ELEVBQUEsT0FBTyxhQUFBLENBQWMsS0FBSyxJQUFJLENBQUE7QUFDaEM7QUFLTyxTQUFTLFlBQVksSUFBQSxFQUF1QjtBQUNqRCxFQUFBLE9BQU8sV0FBQSxDQUFZLEtBQUssSUFBSSxDQUFBO0FBQzlCO0FBV08sU0FBUyxVQUFBLENBQVcsR0FBVyxDQUFBLEVBQW9CO0FBRXhELEVBQUEsTUFBTSxRQUFBLEdBQVcsaUJBQWlCLENBQUMsQ0FBQTtBQUNuQyxFQUFBLE1BQU0sUUFBQSxHQUFXLGlCQUFpQixDQUFDLENBQUE7QUFDbkMsRUFBQSxJQUFJLFlBQVksUUFBQSxFQUFVO0FBQ3hCLElBQUEsT0FBTyxTQUFTLFNBQUEsS0FBYyxRQUFBLENBQVMsU0FBQSxJQUFhLFFBQUEsQ0FBUyxVQUFVLFFBQUEsQ0FBUyxLQUFBO0FBQUEsRUFDbEY7QUFHQSxFQUFBLE1BQU0sTUFBQSxHQUFTLGVBQWUsQ0FBQyxDQUFBO0FBQy9CLEVBQUEsTUFBTSxNQUFBLEdBQVMsZUFBZSxDQUFDLENBQUE7QUFDL0IsRUFBQSxJQUFJLFVBQVUsTUFBQSxFQUFRO0FBQ3BCLElBQUEsT0FBTyxNQUFBLENBQU8sV0FBVyxNQUFBLENBQU8sTUFBQTtBQUFBLEVBQ2xDO0FBR0EsRUFBQSxPQUFPLENBQUEsS0FBTSxDQUFBO0FBQ2Y7QUE0TE8sU0FBUyxpQkFBaUIsUUFBQSxFQUFrRDtBQUNqRixFQUFBLE9BQU8sUUFBQSxDQUFTLE9BQUEsQ0FBUSxJQUFBLENBQUssQ0FBQyxDQUFBLEtBQU0sRUFBRSxXQUFXLENBQUEsS0FBTSxRQUFBLENBQVMsbUJBQW1CLENBQUMsQ0FBQTtBQUN0RiIsImZpbGUiOiJpbmRleC5tanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIEljZWJlcmdFcnJvclJlc3BvbnNlIHtcbiAgZXJyb3I6IHtcbiAgICBtZXNzYWdlOiBzdHJpbmdcbiAgICB0eXBlOiBzdHJpbmdcbiAgICBjb2RlOiBudW1iZXJcbiAgICBzdGFjaz86IHN0cmluZ1tdXG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEljZWJlcmdFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgcmVhZG9ubHkgc3RhdHVzOiBudW1iZXJcbiAgcmVhZG9ubHkgaWNlYmVyZ1R5cGU/OiBzdHJpbmdcbiAgcmVhZG9ubHkgaWNlYmVyZ0NvZGU/OiBudW1iZXJcbiAgcmVhZG9ubHkgZGV0YWlscz86IHVua25vd25cbiAgcmVhZG9ubHkgaXNDb21taXRTdGF0ZVVua25vd246IGJvb2xlYW5cblxuICBjb25zdHJ1Y3RvcihcbiAgICBtZXNzYWdlOiBzdHJpbmcsXG4gICAgb3B0czoge1xuICAgICAgc3RhdHVzOiBudW1iZXJcbiAgICAgIGljZWJlcmdUeXBlPzogc3RyaW5nXG4gICAgICBpY2ViZXJnQ29kZT86IG51bWJlclxuICAgICAgZGV0YWlscz86IHVua25vd25cbiAgICB9XG4gICkge1xuICAgIHN1cGVyKG1lc3NhZ2UpXG4gICAgdGhpcy5uYW1lID0gJ0ljZWJlcmdFcnJvcidcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzXG4gICAgdGhpcy5pY2ViZXJnVHlwZSA9IG9wdHMuaWNlYmVyZ1R5cGVcbiAgICB0aGlzLmljZWJlcmdDb2RlID0gb3B0cy5pY2ViZXJnQ29kZVxuICAgIHRoaXMuZGV0YWlscyA9IG9wdHMuZGV0YWlsc1xuXG4gICAgLy8gRGV0ZWN0IENvbW1pdFN0YXRlVW5rbm93bkV4Y2VwdGlvbiAoNTAwLCA1MDIsIDUwNCBkdXJpbmcgdGFibGUgY29tbWl0cylcbiAgICB0aGlzLmlzQ29tbWl0U3RhdGVVbmtub3duID1cbiAgICAgIG9wdHMuaWNlYmVyZ1R5cGUgPT09ICdDb21taXRTdGF0ZVVua25vd25FeGNlcHRpb24nIHx8XG4gICAgICAoWzUwMCwgNTAyLCA1MDRdLmluY2x1ZGVzKG9wdHMuc3RhdHVzKSAmJiBvcHRzLmljZWJlcmdUeXBlPy5pbmNsdWRlcygnQ29tbWl0U3RhdGUnKSA9PT0gdHJ1ZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIGVycm9yIGlzIGEgNDA0IE5vdCBGb3VuZCBlcnJvci5cbiAgICovXG4gIGlzTm90Rm91bmQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdHVzID09PSA0MDRcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIGVycm9yIGlzIGEgNDA5IENvbmZsaWN0IGVycm9yLlxuICAgKi9cbiAgaXNDb25mbGljdCgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0dXMgPT09IDQwOVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZXJyb3IgaXMgYSA0MTkgQXV0aGVudGljYXRpb24gVGltZW91dCBlcnJvci5cbiAgICovXG4gIGlzQXV0aGVudGljYXRpb25UaW1lb3V0KCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnN0YXR1cyA9PT0gNDE5XG4gIH1cbn1cbiIsImV4cG9ydCBmdW5jdGlvbiBidWlsZFVybChcbiAgYmFzZVVybDogc3RyaW5nLFxuICBwYXRoOiBzdHJpbmcsXG4gIHF1ZXJ5PzogUmVjb3JkPHN0cmluZywgc3RyaW5nIHwgdW5kZWZpbmVkPlxuKTogc3RyaW5nIHtcbiAgY29uc3QgdXJsID0gbmV3IFVSTChwYXRoLCBiYXNlVXJsKVxuXG4gIGlmIChxdWVyeSkge1xuICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHF1ZXJ5KSkge1xuICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdXJsLnNlYXJjaFBhcmFtcy5zZXQoa2V5LCB2YWx1ZSlcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gdXJsLnRvU3RyaW5nKClcbn1cbiIsImltcG9ydCB7IEljZWJlcmdFcnJvciwgdHlwZSBJY2ViZXJnRXJyb3JSZXNwb25zZSB9IGZyb20gJy4uL2Vycm9ycy9JY2ViZXJnRXJyb3InXG5pbXBvcnQgeyBidWlsZFVybCB9IGZyb20gJy4uL3V0aWxzL3VybCdcbmltcG9ydCB0eXBlIHsgQXV0aENvbmZpZywgSHR0cENsaWVudCwgSHR0cFJlcXVlc3QsIEh0dHBSZXNwb25zZSB9IGZyb20gJy4vdHlwZXMnXG5cbmFzeW5jIGZ1bmN0aW9uIGJ1aWxkQXV0aEhlYWRlcnMoYXV0aD86IEF1dGhDb25maWcpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+IHtcbiAgaWYgKCFhdXRoIHx8IGF1dGgudHlwZSA9PT0gJ25vbmUnKSB7XG4gICAgcmV0dXJuIHt9XG4gIH1cblxuICBpZiAoYXV0aC50eXBlID09PSAnYmVhcmVyJykge1xuICAgIHJldHVybiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHthdXRoLnRva2VufWAgfVxuICB9XG5cbiAgaWYgKGF1dGgudHlwZSA9PT0gJ2hlYWRlcicpIHtcbiAgICByZXR1cm4geyBbYXV0aC5uYW1lXTogYXV0aC52YWx1ZSB9XG4gIH1cblxuICBpZiAoYXV0aC50eXBlID09PSAnY3VzdG9tJykge1xuICAgIHJldHVybiBhd2FpdCBhdXRoLmdldEhlYWRlcnMoKVxuICB9XG5cbiAgcmV0dXJuIHt9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVGZXRjaENsaWVudChvcHRpb25zOiB7XG4gIGJhc2VVcmw6IHN0cmluZ1xuICBhdXRoPzogQXV0aENvbmZpZ1xuICBmZXRjaEltcGw/OiB0eXBlb2YgZmV0Y2hcbn0pOiBIdHRwQ2xpZW50IHtcbiAgY29uc3QgZmV0Y2hGbiA9IG9wdGlvbnMuZmV0Y2hJbXBsID8/IGdsb2JhbFRoaXMuZmV0Y2hcblxuICByZXR1cm4ge1xuICAgIGFzeW5jIHJlcXVlc3Q8VD4oe1xuICAgICAgbWV0aG9kLFxuICAgICAgcGF0aCxcbiAgICAgIHF1ZXJ5LFxuICAgICAgYm9keSxcbiAgICAgIGhlYWRlcnMsXG4gICAgfTogSHR0cFJlcXVlc3QpOiBQcm9taXNlPEh0dHBSZXNwb25zZTxUPj4ge1xuICAgICAgY29uc3QgdXJsID0gYnVpbGRVcmwob3B0aW9ucy5iYXNlVXJsLCBwYXRoLCBxdWVyeSlcbiAgICAgIGNvbnN0IGF1dGhIZWFkZXJzID0gYXdhaXQgYnVpbGRBdXRoSGVhZGVycyhvcHRpb25zLmF1dGgpXG5cbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoRm4odXJsLCB7XG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIC4uLihib2R5ID8geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gOiB7fSksXG4gICAgICAgICAgLi4uYXV0aEhlYWRlcnMsXG4gICAgICAgICAgLi4uaGVhZGVycyxcbiAgICAgICAgfSxcbiAgICAgICAgYm9keTogYm9keSA/IEpTT04uc3RyaW5naWZ5KGJvZHkpIDogdW5kZWZpbmVkLFxuICAgICAgfSlcblxuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KClcbiAgICAgIGNvbnN0IGlzSnNvbiA9IChyZXMuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpIHx8ICcnKS5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpXG4gICAgICBjb25zdCBkYXRhID0gaXNKc29uICYmIHRleHQgPyAoSlNPTi5wYXJzZSh0ZXh0KSBhcyBUKSA6ICh0ZXh0IGFzIFQpXG5cbiAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgIGNvbnN0IGVyckJvZHkgPSBpc0pzb24gPyAoZGF0YSBhcyBJY2ViZXJnRXJyb3JSZXNwb25zZSkgOiB1bmRlZmluZWRcbiAgICAgICAgY29uc3QgZXJyb3JEZXRhaWwgPSBlcnJCb2R5Py5lcnJvclxuICAgICAgICB0aHJvdyBuZXcgSWNlYmVyZ0Vycm9yKFxuICAgICAgICAgIGVycm9yRGV0YWlsPy5tZXNzYWdlID8/IGBSZXF1ZXN0IGZhaWxlZCB3aXRoIHN0YXR1cyAke3Jlcy5zdGF0dXN9YCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBzdGF0dXM6IHJlcy5zdGF0dXMsXG4gICAgICAgICAgICBpY2ViZXJnVHlwZTogZXJyb3JEZXRhaWw/LnR5cGUsXG4gICAgICAgICAgICBpY2ViZXJnQ29kZTogZXJyb3JEZXRhaWw/LmNvZGUsXG4gICAgICAgICAgICBkZXRhaWxzOiBlcnJCb2R5LFxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4geyBzdGF0dXM6IHJlcy5zdGF0dXMsIGhlYWRlcnM6IHJlcy5oZWFkZXJzLCBkYXRhOiBkYXRhIGFzIFQgfVxuICAgIH0sXG4gIH1cbn1cbiIsImltcG9ydCB0eXBlIHsgSHR0cENsaWVudCB9IGZyb20gJy4uL2h0dHAvdHlwZXMnXG5pbXBvcnQgeyBJY2ViZXJnRXJyb3IgfSBmcm9tICcuLi9lcnJvcnMvSWNlYmVyZ0Vycm9yJ1xuaW1wb3J0IHR5cGUge1xuICBDcmVhdGVOYW1lc3BhY2VSZXF1ZXN0LFxuICBDcmVhdGVOYW1lc3BhY2VSZXNwb25zZSxcbiAgR2V0TmFtZXNwYWNlUmVzcG9uc2UsXG4gIExpc3ROYW1lc3BhY2VzUmVzcG9uc2UsXG4gIE5hbWVzcGFjZUlkZW50aWZpZXIsXG4gIE5hbWVzcGFjZU1ldGFkYXRhLFxufSBmcm9tICcuL3R5cGVzJ1xuXG5mdW5jdGlvbiBuYW1lc3BhY2VUb1BhdGgobmFtZXNwYWNlOiBzdHJpbmdbXSk6IHN0cmluZyB7XG4gIHJldHVybiBuYW1lc3BhY2Uuam9pbignXFx4MUYnKVxufVxuXG5leHBvcnQgY2xhc3MgTmFtZXNwYWNlT3BlcmF0aW9ucyB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcmVhZG9ubHkgY2xpZW50OiBIdHRwQ2xpZW50LFxuICAgIHByaXZhdGUgcmVhZG9ubHkgcHJlZml4OiBzdHJpbmcgPSAnJ1xuICApIHt9XG5cbiAgYXN5bmMgbGlzdE5hbWVzcGFjZXMocGFyZW50PzogTmFtZXNwYWNlSWRlbnRpZmllcik6IFByb21pc2U8TmFtZXNwYWNlSWRlbnRpZmllcltdPiB7XG4gICAgY29uc3QgcXVlcnkgPSBwYXJlbnQgPyB7IHBhcmVudDogbmFtZXNwYWNlVG9QYXRoKHBhcmVudC5uYW1lc3BhY2UpIH0gOiB1bmRlZmluZWRcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5jbGllbnQucmVxdWVzdDxMaXN0TmFtZXNwYWNlc1Jlc3BvbnNlPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogYCR7dGhpcy5wcmVmaXh9L25hbWVzcGFjZXNgLFxuICAgICAgcXVlcnksXG4gICAgfSlcblxuICAgIHJldHVybiByZXNwb25zZS5kYXRhLm5hbWVzcGFjZXMubWFwKChucykgPT4gKHsgbmFtZXNwYWNlOiBucyB9KSlcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZU5hbWVzcGFjZShcbiAgICBpZDogTmFtZXNwYWNlSWRlbnRpZmllcixcbiAgICBtZXRhZGF0YT86IE5hbWVzcGFjZU1ldGFkYXRhXG4gICk6IFByb21pc2U8Q3JlYXRlTmFtZXNwYWNlUmVzcG9uc2U+IHtcbiAgICBjb25zdCByZXF1ZXN0OiBDcmVhdGVOYW1lc3BhY2VSZXF1ZXN0ID0ge1xuICAgICAgbmFtZXNwYWNlOiBpZC5uYW1lc3BhY2UsXG4gICAgICBwcm9wZXJ0aWVzOiBtZXRhZGF0YT8ucHJvcGVydGllcyxcbiAgICB9XG5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuY2xpZW50LnJlcXVlc3Q8Q3JlYXRlTmFtZXNwYWNlUmVzcG9uc2U+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgcGF0aDogYCR7dGhpcy5wcmVmaXh9L25hbWVzcGFjZXNgLFxuICAgICAgYm9keTogcmVxdWVzdCxcbiAgICB9KVxuXG4gICAgcmV0dXJuIHJlc3BvbnNlLmRhdGFcbiAgfVxuXG4gIGFzeW5jIGRyb3BOYW1lc3BhY2UoaWQ6IE5hbWVzcGFjZUlkZW50aWZpZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLmNsaWVudC5yZXF1ZXN0PHZvaWQ+KHtcbiAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICBwYXRoOiBgJHt0aGlzLnByZWZpeH0vbmFtZXNwYWNlcy8ke25hbWVzcGFjZVRvUGF0aChpZC5uYW1lc3BhY2UpfWAsXG4gICAgfSlcbiAgfVxuXG4gIGFzeW5jIGxvYWROYW1lc3BhY2VNZXRhZGF0YShpZDogTmFtZXNwYWNlSWRlbnRpZmllcik6IFByb21pc2U8TmFtZXNwYWNlTWV0YWRhdGE+IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuY2xpZW50LnJlcXVlc3Q8R2V0TmFtZXNwYWNlUmVzcG9uc2U+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBwYXRoOiBgJHt0aGlzLnByZWZpeH0vbmFtZXNwYWNlcy8ke25hbWVzcGFjZVRvUGF0aChpZC5uYW1lc3BhY2UpfWAsXG4gICAgfSlcblxuICAgIHJldHVybiB7XG4gICAgICBwcm9wZXJ0aWVzOiByZXNwb25zZS5kYXRhLnByb3BlcnRpZXMsXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgbmFtZXNwYWNlRXhpc3RzKGlkOiBOYW1lc3BhY2VJZGVudGlmaWVyKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuY2xpZW50LnJlcXVlc3Q8dm9pZD4oe1xuICAgICAgICBtZXRob2Q6ICdIRUFEJyxcbiAgICAgICAgcGF0aDogYCR7dGhpcy5wcmVmaXh9L25hbWVzcGFjZXMvJHtuYW1lc3BhY2VUb1BhdGgoaWQubmFtZXNwYWNlKX1gLFxuICAgICAgfSlcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEljZWJlcmdFcnJvciAmJiBlcnJvci5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgY3JlYXRlTmFtZXNwYWNlSWZOb3RFeGlzdHMoXG4gICAgaWQ6IE5hbWVzcGFjZUlkZW50aWZpZXIsXG4gICAgbWV0YWRhdGE/OiBOYW1lc3BhY2VNZXRhZGF0YVxuICApOiBQcm9taXNlPENyZWF0ZU5hbWVzcGFjZVJlc3BvbnNlIHwgdm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5jcmVhdGVOYW1lc3BhY2UoaWQsIG1ldGFkYXRhKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBJY2ViZXJnRXJyb3IgJiYgZXJyb3Iuc3RhdHVzID09PSA0MDkpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwiaW1wb3J0IHR5cGUgeyBIdHRwQ2xpZW50IH0gZnJvbSAnLi4vaHR0cC90eXBlcydcbmltcG9ydCB7IEljZWJlcmdFcnJvciB9IGZyb20gJy4uL2Vycm9ycy9JY2ViZXJnRXJyb3InXG5pbXBvcnQgdHlwZSB7XG4gIENyZWF0ZVRhYmxlUmVxdWVzdCxcbiAgQ29tbWl0VGFibGVSZXNwb25zZSxcbiAgTGlzdFRhYmxlc1Jlc3BvbnNlLFxuICBMb2FkVGFibGVSZXNwb25zZSxcbiAgTmFtZXNwYWNlSWRlbnRpZmllcixcbiAgVGFibGVJZGVudGlmaWVyLFxuICBUYWJsZU1ldGFkYXRhLFxuICBVcGRhdGVUYWJsZVJlcXVlc3QsXG4gIERyb3BUYWJsZVJlcXVlc3QsXG59IGZyb20gJy4vdHlwZXMnXG5cbmZ1bmN0aW9uIG5hbWVzcGFjZVRvUGF0aChuYW1lc3BhY2U6IHN0cmluZ1tdKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5hbWVzcGFjZS5qb2luKCdcXHgxRicpXG59XG5cbmV4cG9ydCBjbGFzcyBUYWJsZU9wZXJhdGlvbnMge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlYWRvbmx5IGNsaWVudDogSHR0cENsaWVudCxcbiAgICBwcml2YXRlIHJlYWRvbmx5IHByZWZpeDogc3RyaW5nID0gJycsXG4gICAgcHJpdmF0ZSByZWFkb25seSBhY2Nlc3NEZWxlZ2F0aW9uPzogc3RyaW5nXG4gICkge31cblxuICBhc3luYyBsaXN0VGFibGVzKG5hbWVzcGFjZTogTmFtZXNwYWNlSWRlbnRpZmllcik6IFByb21pc2U8VGFibGVJZGVudGlmaWVyW10+IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuY2xpZW50LnJlcXVlc3Q8TGlzdFRhYmxlc1Jlc3BvbnNlPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogYCR7dGhpcy5wcmVmaXh9L25hbWVzcGFjZXMvJHtuYW1lc3BhY2VUb1BhdGgobmFtZXNwYWNlLm5hbWVzcGFjZSl9L3RhYmxlc2AsXG4gICAgfSlcblxuICAgIHJldHVybiByZXNwb25zZS5kYXRhLmlkZW50aWZpZXJzXG4gIH1cblxuICBhc3luYyBjcmVhdGVUYWJsZShcbiAgICBuYW1lc3BhY2U6IE5hbWVzcGFjZUlkZW50aWZpZXIsXG4gICAgcmVxdWVzdDogQ3JlYXRlVGFibGVSZXF1ZXN0XG4gICk6IFByb21pc2U8VGFibGVNZXRhZGF0YT4ge1xuICAgIGNvbnN0IGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fVxuICAgIGlmICh0aGlzLmFjY2Vzc0RlbGVnYXRpb24pIHtcbiAgICAgIGhlYWRlcnNbJ1gtSWNlYmVyZy1BY2Nlc3MtRGVsZWdhdGlvbiddID0gdGhpcy5hY2Nlc3NEZWxlZ2F0aW9uXG4gICAgfVxuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmNsaWVudC5yZXF1ZXN0PExvYWRUYWJsZVJlc3BvbnNlPih7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHBhdGg6IGAke3RoaXMucHJlZml4fS9uYW1lc3BhY2VzLyR7bmFtZXNwYWNlVG9QYXRoKG5hbWVzcGFjZS5uYW1lc3BhY2UpfS90YWJsZXNgLFxuICAgICAgYm9keTogcmVxdWVzdCxcbiAgICAgIGhlYWRlcnMsXG4gICAgfSlcblxuICAgIHJldHVybiByZXNwb25zZS5kYXRhLm1ldGFkYXRhXG4gIH1cblxuICBhc3luYyB1cGRhdGVUYWJsZShpZDogVGFibGVJZGVudGlmaWVyLCByZXF1ZXN0OiBVcGRhdGVUYWJsZVJlcXVlc3QpOiBQcm9taXNlPENvbW1pdFRhYmxlUmVzcG9uc2U+IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuY2xpZW50LnJlcXVlc3Q8TG9hZFRhYmxlUmVzcG9uc2U+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgcGF0aDogYCR7dGhpcy5wcmVmaXh9L25hbWVzcGFjZXMvJHtuYW1lc3BhY2VUb1BhdGgoaWQubmFtZXNwYWNlKX0vdGFibGVzLyR7aWQubmFtZX1gLFxuICAgICAgYm9keTogcmVxdWVzdCxcbiAgICB9KVxuXG4gICAgcmV0dXJuIHtcbiAgICAgICdtZXRhZGF0YS1sb2NhdGlvbic6IHJlc3BvbnNlLmRhdGFbJ21ldGFkYXRhLWxvY2F0aW9uJ10sXG4gICAgICBtZXRhZGF0YTogcmVzcG9uc2UuZGF0YS5tZXRhZGF0YSxcbiAgICB9XG4gIH1cblxuICBhc3luYyBkcm9wVGFibGUoaWQ6IFRhYmxlSWRlbnRpZmllciwgb3B0aW9ucz86IERyb3BUYWJsZVJlcXVlc3QpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLmNsaWVudC5yZXF1ZXN0PHZvaWQ+KHtcbiAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICBwYXRoOiBgJHt0aGlzLnByZWZpeH0vbmFtZXNwYWNlcy8ke25hbWVzcGFjZVRvUGF0aChpZC5uYW1lc3BhY2UpfS90YWJsZXMvJHtpZC5uYW1lfWAsXG4gICAgICBxdWVyeTogeyBwdXJnZVJlcXVlc3RlZDogU3RyaW5nKG9wdGlvbnM/LnB1cmdlID8/IGZhbHNlKSB9LFxuICAgIH0pXG4gIH1cblxuICBhc3luYyBsb2FkVGFibGUoaWQ6IFRhYmxlSWRlbnRpZmllcik6IFByb21pc2U8VGFibGVNZXRhZGF0YT4ge1xuICAgIGNvbnN0IGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fVxuICAgIGlmICh0aGlzLmFjY2Vzc0RlbGVnYXRpb24pIHtcbiAgICAgIGhlYWRlcnNbJ1gtSWNlYmVyZy1BY2Nlc3MtRGVsZWdhdGlvbiddID0gdGhpcy5hY2Nlc3NEZWxlZ2F0aW9uXG4gICAgfVxuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmNsaWVudC5yZXF1ZXN0PExvYWRUYWJsZVJlc3BvbnNlPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogYCR7dGhpcy5wcmVmaXh9L25hbWVzcGFjZXMvJHtuYW1lc3BhY2VUb1BhdGgoaWQubmFtZXNwYWNlKX0vdGFibGVzLyR7aWQubmFtZX1gLFxuICAgICAgaGVhZGVycyxcbiAgICB9KVxuXG4gICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEubWV0YWRhdGFcbiAgfVxuXG4gIGFzeW5jIHRhYmxlRXhpc3RzKGlkOiBUYWJsZUlkZW50aWZpZXIpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBjb25zdCBoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge31cbiAgICBpZiAodGhpcy5hY2Nlc3NEZWxlZ2F0aW9uKSB7XG4gICAgICBoZWFkZXJzWydYLUljZWJlcmctQWNjZXNzLURlbGVnYXRpb24nXSA9IHRoaXMuYWNjZXNzRGVsZWdhdGlvblxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWVudC5yZXF1ZXN0PHZvaWQ+KHtcbiAgICAgICAgbWV0aG9kOiAnSEVBRCcsXG4gICAgICAgIHBhdGg6IGAke3RoaXMucHJlZml4fS9uYW1lc3BhY2VzLyR7bmFtZXNwYWNlVG9QYXRoKGlkLm5hbWVzcGFjZSl9L3RhYmxlcy8ke2lkLm5hbWV9YCxcbiAgICAgICAgaGVhZGVycyxcbiAgICAgIH0pXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBJY2ViZXJnRXJyb3IgJiYgZXJyb3Iuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVRhYmxlSWZOb3RFeGlzdHMoXG4gICAgbmFtZXNwYWNlOiBOYW1lc3BhY2VJZGVudGlmaWVyLFxuICAgIHJlcXVlc3Q6IENyZWF0ZVRhYmxlUmVxdWVzdFxuICApOiBQcm9taXNlPFRhYmxlTWV0YWRhdGE+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY3JlYXRlVGFibGUobmFtZXNwYWNlLCByZXF1ZXN0KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBJY2ViZXJnRXJyb3IgJiYgZXJyb3Iuc3RhdHVzID09PSA0MDkpIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubG9hZFRhYmxlKHsgbmFtZXNwYWNlOiBuYW1lc3BhY2UubmFtZXNwYWNlLCBuYW1lOiByZXF1ZXN0Lm5hbWUgfSlcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iLCJpbXBvcnQgeyBjcmVhdGVGZXRjaENsaWVudCB9IGZyb20gJy4uL2h0dHAvY3JlYXRlRmV0Y2hDbGllbnQnXG5pbXBvcnQgdHlwZSB7IEF1dGhDb25maWcsIEh0dHBDbGllbnQgfSBmcm9tICcuLi9odHRwL3R5cGVzJ1xuaW1wb3J0IHsgTmFtZXNwYWNlT3BlcmF0aW9ucyB9IGZyb20gJy4vbmFtZXNwYWNlcydcbmltcG9ydCB7IFRhYmxlT3BlcmF0aW9ucyB9IGZyb20gJy4vdGFibGVzJ1xuaW1wb3J0IHR5cGUge1xuICBDcmVhdGVUYWJsZVJlcXVlc3QsXG4gIENyZWF0ZU5hbWVzcGFjZVJlc3BvbnNlLFxuICBDb21taXRUYWJsZVJlc3BvbnNlLFxuICBOYW1lc3BhY2VJZGVudGlmaWVyLFxuICBOYW1lc3BhY2VNZXRhZGF0YSxcbiAgVGFibGVJZGVudGlmaWVyLFxuICBUYWJsZU1ldGFkYXRhLFxuICBVcGRhdGVUYWJsZVJlcXVlc3QsXG4gIERyb3BUYWJsZVJlcXVlc3QsXG59IGZyb20gJy4vdHlwZXMnXG5cbi8qKlxuICogQWNjZXNzIGRlbGVnYXRpb24gbWVjaGFuaXNtcyBzdXBwb3J0ZWQgYnkgdGhlIEljZWJlcmcgUkVTVCBDYXRhbG9nLlxuICpcbiAqIC0gYHZlbmRlZC1jcmVkZW50aWFsc2A6IFNlcnZlciBwcm92aWRlcyB0ZW1wb3JhcnkgY3JlZGVudGlhbHMgZm9yIGRhdGEgYWNjZXNzXG4gKiAtIGByZW1vdGUtc2lnbmluZ2A6IFNlcnZlciBzaWducyByZXF1ZXN0cyBvbiBiZWhhbGYgb2YgdGhlIGNsaWVudFxuICovXG5leHBvcnQgdHlwZSBBY2Nlc3NEZWxlZ2F0aW9uID0gJ3ZlbmRlZC1jcmVkZW50aWFscycgfCAncmVtb3RlLXNpZ25pbmcnXG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBvcHRpb25zIGZvciB0aGUgSWNlYmVyZyBSRVNUIENhdGFsb2cgY2xpZW50LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEljZWJlcmdSZXN0Q2F0YWxvZ09wdGlvbnMge1xuICAvKiogQmFzZSBVUkwgb2YgdGhlIEljZWJlcmcgUkVTVCBDYXRhbG9nIEFQSSAqL1xuICBiYXNlVXJsOiBzdHJpbmdcbiAgLyoqIE9wdGlvbmFsIGNhdGFsb2cgbmFtZSBwcmVmaXggZm9yIG11bHRpLWNhdGFsb2cgc2VydmVycyAqL1xuICBjYXRhbG9nTmFtZT86IHN0cmluZ1xuICAvKiogQXV0aGVudGljYXRpb24gY29uZmlndXJhdGlvbiAqL1xuICBhdXRoPzogQXV0aENvbmZpZ1xuICAvKiogQ3VzdG9tIGZldGNoIGltcGxlbWVudGF0aW9uIChkZWZhdWx0cyB0byBnbG9iYWxUaGlzLmZldGNoKSAqL1xuICBmZXRjaD86IHR5cGVvZiBmZXRjaFxuICAvKipcbiAgICogQWNjZXNzIGRlbGVnYXRpb24gbWVjaGFuaXNtcyB0byByZXF1ZXN0IGZyb20gdGhlIHNlcnZlci5cbiAgICogV2hlbiBzcGVjaWZpZWQsIHRoZSBYLUljZWJlcmctQWNjZXNzLURlbGVnYXRpb24gaGVhZGVyIHdpbGwgYmUgc2VudFxuICAgKiB3aXRoIHN1cHBvcnRlZCBvcGVyYXRpb25zIChjcmVhdGVUYWJsZSwgbG9hZFRhYmxlKS5cbiAgICpcbiAgICogQGV4YW1wbGUgWyd2ZW5kZWQtY3JlZGVudGlhbHMnXVxuICAgKiBAZXhhbXBsZSBbJ3ZlbmRlZC1jcmVkZW50aWFscycsICdyZW1vdGUtc2lnbmluZyddXG4gICAqL1xuICBhY2Nlc3NEZWxlZ2F0aW9uPzogQWNjZXNzRGVsZWdhdGlvbltdXG59XG5cbi8qKlxuICogQ2xpZW50IGZvciBpbnRlcmFjdGluZyB3aXRoIGFuIEFwYWNoZSBJY2ViZXJnIFJFU1QgQ2F0YWxvZy5cbiAqXG4gKiBUaGlzIGNsYXNzIHByb3ZpZGVzIG1ldGhvZHMgZm9yIG1hbmFnaW5nIG5hbWVzcGFjZXMgYW5kIHRhYmxlcyBpbiBhbiBJY2ViZXJnIGNhdGFsb2cuXG4gKiBJdCBoYW5kbGVzIGF1dGhlbnRpY2F0aW9uLCByZXF1ZXN0IGZvcm1hdHRpbmcsIGFuZCBlcnJvciBoYW5kbGluZyBhdXRvbWF0aWNhbGx5LlxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0eXBlc2NyaXB0XG4gKiBjb25zdCBjYXRhbG9nID0gbmV3IEljZWJlcmdSZXN0Q2F0YWxvZyh7XG4gKiAgIGJhc2VVcmw6ICdodHRwczovL215LWNhdGFsb2cuZXhhbXBsZS5jb20vaWNlYmVyZy92MScsXG4gKiAgIGF1dGg6IHsgdHlwZTogJ2JlYXJlcicsIHRva2VuOiBwcm9jZXNzLmVudi5JQ0VCRVJHX1RPS0VOIH1cbiAqIH0pO1xuICpcbiAqIC8vIENyZWF0ZSBhIG5hbWVzcGFjZVxuICogYXdhaXQgY2F0YWxvZy5jcmVhdGVOYW1lc3BhY2UoeyBuYW1lc3BhY2U6IFsnYW5hbHl0aWNzJ10gfSk7XG4gKlxuICogLy8gQ3JlYXRlIGEgdGFibGVcbiAqIGF3YWl0IGNhdGFsb2cuY3JlYXRlVGFibGUoXG4gKiAgIHsgbmFtZXNwYWNlOiBbJ2FuYWx5dGljcyddIH0sXG4gKiAgIHtcbiAqICAgICBuYW1lOiAnZXZlbnRzJyxcbiAqICAgICBzY2hlbWE6IHsgdHlwZTogJ3N0cnVjdCcsIGZpZWxkczogWy4uLl0gfVxuICogICB9XG4gKiApO1xuICogYGBgXG4gKi9cbmV4cG9ydCBjbGFzcyBJY2ViZXJnUmVzdENhdGFsb2cge1xuICBwcml2YXRlIHJlYWRvbmx5IGNsaWVudDogSHR0cENsaWVudFxuICBwcml2YXRlIHJlYWRvbmx5IG5hbWVzcGFjZU9wczogTmFtZXNwYWNlT3BlcmF0aW9uc1xuICBwcml2YXRlIHJlYWRvbmx5IHRhYmxlT3BzOiBUYWJsZU9wZXJhdGlvbnNcbiAgcHJpdmF0ZSByZWFkb25seSBhY2Nlc3NEZWxlZ2F0aW9uPzogc3RyaW5nXG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgSWNlYmVyZyBSRVNUIENhdGFsb2cgY2xpZW50LlxuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIENvbmZpZ3VyYXRpb24gb3B0aW9ucyBmb3IgdGhlIGNhdGFsb2cgY2xpZW50XG4gICAqL1xuICBjb25zdHJ1Y3RvcihvcHRpb25zOiBJY2ViZXJnUmVzdENhdGFsb2dPcHRpb25zKSB7XG4gICAgbGV0IHByZWZpeCA9ICd2MSdcbiAgICBpZiAob3B0aW9ucy5jYXRhbG9nTmFtZSkge1xuICAgICAgcHJlZml4ICs9IGAvJHtvcHRpb25zLmNhdGFsb2dOYW1lfWBcbiAgICB9XG5cbiAgICBjb25zdCBiYXNlVXJsID0gb3B0aW9ucy5iYXNlVXJsLmVuZHNXaXRoKCcvJykgPyBvcHRpb25zLmJhc2VVcmwgOiBgJHtvcHRpb25zLmJhc2VVcmx9L2BcblxuICAgIHRoaXMuY2xpZW50ID0gY3JlYXRlRmV0Y2hDbGllbnQoe1xuICAgICAgYmFzZVVybCxcbiAgICAgIGF1dGg6IG9wdGlvbnMuYXV0aCxcbiAgICAgIGZldGNoSW1wbDogb3B0aW9ucy5mZXRjaCxcbiAgICB9KVxuXG4gICAgLy8gRm9ybWF0IGFjY2Vzc0RlbGVnYXRpb24gYXMgY29tbWEtc2VwYXJhdGVkIHN0cmluZyBwZXIgc3BlY1xuICAgIHRoaXMuYWNjZXNzRGVsZWdhdGlvbiA9IG9wdGlvbnMuYWNjZXNzRGVsZWdhdGlvbj8uam9pbignLCcpXG5cbiAgICB0aGlzLm5hbWVzcGFjZU9wcyA9IG5ldyBOYW1lc3BhY2VPcGVyYXRpb25zKHRoaXMuY2xpZW50LCBwcmVmaXgpXG4gICAgdGhpcy50YWJsZU9wcyA9IG5ldyBUYWJsZU9wZXJhdGlvbnModGhpcy5jbGllbnQsIHByZWZpeCwgdGhpcy5hY2Nlc3NEZWxlZ2F0aW9uKVxuICB9XG5cbiAgLyoqXG4gICAqIExpc3RzIGFsbCBuYW1lc3BhY2VzIGluIHRoZSBjYXRhbG9nLlxuICAgKlxuICAgKiBAcGFyYW0gcGFyZW50IC0gT3B0aW9uYWwgcGFyZW50IG5hbWVzcGFjZSB0byBsaXN0IGNoaWxkcmVuIHVuZGVyXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIG5hbWVzcGFjZSBpZGVudGlmaWVyc1xuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIC8vIExpc3QgYWxsIHRvcC1sZXZlbCBuYW1lc3BhY2VzXG4gICAqIGNvbnN0IG5hbWVzcGFjZXMgPSBhd2FpdCBjYXRhbG9nLmxpc3ROYW1lc3BhY2VzKCk7XG4gICAqXG4gICAqIC8vIExpc3QgbmFtZXNwYWNlcyB1bmRlciBhIHBhcmVudFxuICAgKiBjb25zdCBjaGlsZHJlbiA9IGF3YWl0IGNhdGFsb2cubGlzdE5hbWVzcGFjZXMoeyBuYW1lc3BhY2U6IFsnYW5hbHl0aWNzJ10gfSk7XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgbGlzdE5hbWVzcGFjZXMocGFyZW50PzogTmFtZXNwYWNlSWRlbnRpZmllcik6IFByb21pc2U8TmFtZXNwYWNlSWRlbnRpZmllcltdPiB7XG4gICAgcmV0dXJuIHRoaXMubmFtZXNwYWNlT3BzLmxpc3ROYW1lc3BhY2VzKHBhcmVudClcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IG5hbWVzcGFjZSBpbiB0aGUgY2F0YWxvZy5cbiAgICpcbiAgICogQHBhcmFtIGlkIC0gTmFtZXNwYWNlIGlkZW50aWZpZXIgdG8gY3JlYXRlXG4gICAqIEBwYXJhbSBtZXRhZGF0YSAtIE9wdGlvbmFsIG1ldGFkYXRhIHByb3BlcnRpZXMgZm9yIHRoZSBuYW1lc3BhY2VcbiAgICogQHJldHVybnMgUmVzcG9uc2UgY29udGFpbmluZyB0aGUgY3JlYXRlZCBuYW1lc3BhY2UgYW5kIGl0cyBwcm9wZXJ0aWVzXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjYXRhbG9nLmNyZWF0ZU5hbWVzcGFjZShcbiAgICogICB7IG5hbWVzcGFjZTogWydhbmFseXRpY3MnXSB9LFxuICAgKiAgIHsgcHJvcGVydGllczogeyBvd25lcjogJ2RhdGEtdGVhbScgfSB9XG4gICAqICk7XG4gICAqIGNvbnNvbGUubG9nKHJlc3BvbnNlLm5hbWVzcGFjZSk7IC8vIFsnYW5hbHl0aWNzJ11cbiAgICogY29uc29sZS5sb2cocmVzcG9uc2UucHJvcGVydGllcyk7IC8vIHsgb3duZXI6ICdkYXRhLXRlYW0nLCAuLi4gfVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGNyZWF0ZU5hbWVzcGFjZShpZDogTmFtZXNwYWNlSWRlbnRpZmllciwgbWV0YWRhdGE/OiBOYW1lc3BhY2VNZXRhZGF0YSk6IFByb21pc2U8Q3JlYXRlTmFtZXNwYWNlUmVzcG9uc2U+IHtcbiAgICByZXR1cm4gdGhpcy5uYW1lc3BhY2VPcHMuY3JlYXRlTmFtZXNwYWNlKGlkLCBtZXRhZGF0YSlcbiAgfVxuXG4gIC8qKlxuICAgKiBEcm9wcyBhIG5hbWVzcGFjZSBmcm9tIHRoZSBjYXRhbG9nLlxuICAgKlxuICAgKiBUaGUgbmFtZXNwYWNlIG11c3QgYmUgZW1wdHkgKGNvbnRhaW4gbm8gdGFibGVzKSBiZWZvcmUgaXQgY2FuIGJlIGRyb3BwZWQuXG4gICAqXG4gICAqIEBwYXJhbSBpZCAtIE5hbWVzcGFjZSBpZGVudGlmaWVyIHRvIGRyb3BcbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBhd2FpdCBjYXRhbG9nLmRyb3BOYW1lc3BhY2UoeyBuYW1lc3BhY2U6IFsnYW5hbHl0aWNzJ10gfSk7XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgZHJvcE5hbWVzcGFjZShpZDogTmFtZXNwYWNlSWRlbnRpZmllcik6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMubmFtZXNwYWNlT3BzLmRyb3BOYW1lc3BhY2UoaWQpXG4gIH1cblxuICAvKipcbiAgICogTG9hZHMgbWV0YWRhdGEgZm9yIGEgbmFtZXNwYWNlLlxuICAgKlxuICAgKiBAcGFyYW0gaWQgLSBOYW1lc3BhY2UgaWRlbnRpZmllciB0byBsb2FkXG4gICAqIEByZXR1cm5zIE5hbWVzcGFjZSBtZXRhZGF0YSBpbmNsdWRpbmcgcHJvcGVydGllc1xuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IG1ldGFkYXRhID0gYXdhaXQgY2F0YWxvZy5sb2FkTmFtZXNwYWNlTWV0YWRhdGEoeyBuYW1lc3BhY2U6IFsnYW5hbHl0aWNzJ10gfSk7XG4gICAqIGNvbnNvbGUubG9nKG1ldGFkYXRhLnByb3BlcnRpZXMpO1xuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGxvYWROYW1lc3BhY2VNZXRhZGF0YShpZDogTmFtZXNwYWNlSWRlbnRpZmllcik6IFByb21pc2U8TmFtZXNwYWNlTWV0YWRhdGE+IHtcbiAgICByZXR1cm4gdGhpcy5uYW1lc3BhY2VPcHMubG9hZE5hbWVzcGFjZU1ldGFkYXRhKGlkKVxuICB9XG5cbiAgLyoqXG4gICAqIExpc3RzIGFsbCB0YWJsZXMgaW4gYSBuYW1lc3BhY2UuXG4gICAqXG4gICAqIEBwYXJhbSBuYW1lc3BhY2UgLSBOYW1lc3BhY2UgaWRlbnRpZmllciB0byBsaXN0IHRhYmxlcyBmcm9tXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIHRhYmxlIGlkZW50aWZpZXJzXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgdGFibGVzID0gYXdhaXQgY2F0YWxvZy5saXN0VGFibGVzKHsgbmFtZXNwYWNlOiBbJ2FuYWx5dGljcyddIH0pO1xuICAgKiBjb25zb2xlLmxvZyh0YWJsZXMpOyAvLyBbeyBuYW1lc3BhY2U6IFsnYW5hbHl0aWNzJ10sIG5hbWU6ICdldmVudHMnIH0sIC4uLl1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBsaXN0VGFibGVzKG5hbWVzcGFjZTogTmFtZXNwYWNlSWRlbnRpZmllcik6IFByb21pc2U8VGFibGVJZGVudGlmaWVyW10+IHtcbiAgICByZXR1cm4gdGhpcy50YWJsZU9wcy5saXN0VGFibGVzKG5hbWVzcGFjZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IHRhYmxlIGluIHRoZSBjYXRhbG9nLlxuICAgKlxuICAgKiBAcGFyYW0gbmFtZXNwYWNlIC0gTmFtZXNwYWNlIHRvIGNyZWF0ZSB0aGUgdGFibGUgaW5cbiAgICogQHBhcmFtIHJlcXVlc3QgLSBUYWJsZSBjcmVhdGlvbiByZXF1ZXN0IGluY2x1ZGluZyBuYW1lLCBzY2hlbWEsIHBhcnRpdGlvbiBzcGVjLCBldGMuXG4gICAqIEByZXR1cm5zIFRhYmxlIG1ldGFkYXRhIGZvciB0aGUgY3JlYXRlZCB0YWJsZVxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IG1ldGFkYXRhID0gYXdhaXQgY2F0YWxvZy5jcmVhdGVUYWJsZShcbiAgICogICB7IG5hbWVzcGFjZTogWydhbmFseXRpY3MnXSB9LFxuICAgKiAgIHtcbiAgICogICAgIG5hbWU6ICdldmVudHMnLFxuICAgKiAgICAgc2NoZW1hOiB7XG4gICAqICAgICAgIHR5cGU6ICdzdHJ1Y3QnLFxuICAgKiAgICAgICBmaWVsZHM6IFtcbiAgICogICAgICAgICB7IGlkOiAxLCBuYW1lOiAnaWQnLCB0eXBlOiAnbG9uZycsIHJlcXVpcmVkOiB0cnVlIH0sXG4gICAqICAgICAgICAgeyBpZDogMiwgbmFtZTogJ3RpbWVzdGFtcCcsIHR5cGU6ICd0aW1lc3RhbXAnLCByZXF1aXJlZDogdHJ1ZSB9XG4gICAqICAgICAgIF0sXG4gICAqICAgICAgICdzY2hlbWEtaWQnOiAwXG4gICAqICAgICB9LFxuICAgKiAgICAgJ3BhcnRpdGlvbi1zcGVjJzoge1xuICAgKiAgICAgICAnc3BlYy1pZCc6IDAsXG4gICAqICAgICAgIGZpZWxkczogW1xuICAgKiAgICAgICAgIHsgc291cmNlX2lkOiAyLCBmaWVsZF9pZDogMTAwMCwgbmFtZTogJ3RzX2RheScsIHRyYW5zZm9ybTogJ2RheScgfVxuICAgKiAgICAgICBdXG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiApO1xuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGNyZWF0ZVRhYmxlKFxuICAgIG5hbWVzcGFjZTogTmFtZXNwYWNlSWRlbnRpZmllcixcbiAgICByZXF1ZXN0OiBDcmVhdGVUYWJsZVJlcXVlc3RcbiAgKTogUHJvbWlzZTxUYWJsZU1ldGFkYXRhPiB7XG4gICAgcmV0dXJuIHRoaXMudGFibGVPcHMuY3JlYXRlVGFibGUobmFtZXNwYWNlLCByZXF1ZXN0KVxuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgYW4gZXhpc3RpbmcgdGFibGUncyBtZXRhZGF0YS5cbiAgICpcbiAgICogQ2FuIHVwZGF0ZSB0aGUgc2NoZW1hLCBwYXJ0aXRpb24gc3BlYywgb3IgcHJvcGVydGllcyBvZiBhIHRhYmxlLlxuICAgKlxuICAgKiBAcGFyYW0gaWQgLSBUYWJsZSBpZGVudGlmaWVyIHRvIHVwZGF0ZVxuICAgKiBAcGFyYW0gcmVxdWVzdCAtIFVwZGF0ZSByZXF1ZXN0IHdpdGggZmllbGRzIHRvIG1vZGlmeVxuICAgKiBAcmV0dXJucyBSZXNwb25zZSBjb250YWluaW5nIHRoZSBtZXRhZGF0YSBsb2NhdGlvbiBhbmQgdXBkYXRlZCB0YWJsZSBtZXRhZGF0YVxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2F0YWxvZy51cGRhdGVUYWJsZShcbiAgICogICB7IG5hbWVzcGFjZTogWydhbmFseXRpY3MnXSwgbmFtZTogJ2V2ZW50cycgfSxcbiAgICogICB7XG4gICAqICAgICBwcm9wZXJ0aWVzOiB7ICdyZWFkLnNwbGl0LnRhcmdldC1zaXplJzogJzEzNDIxNzcyOCcgfVxuICAgKiAgIH1cbiAgICogKTtcbiAgICogY29uc29sZS5sb2cocmVzcG9uc2VbJ21ldGFkYXRhLWxvY2F0aW9uJ10pOyAvLyBzMzovLy4uLlxuICAgKiBjb25zb2xlLmxvZyhyZXNwb25zZS5tZXRhZGF0YSk7IC8vIFRhYmxlTWV0YWRhdGEgb2JqZWN0XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgdXBkYXRlVGFibGUoaWQ6IFRhYmxlSWRlbnRpZmllciwgcmVxdWVzdDogVXBkYXRlVGFibGVSZXF1ZXN0KTogUHJvbWlzZTxDb21taXRUYWJsZVJlc3BvbnNlPiB7XG4gICAgcmV0dXJuIHRoaXMudGFibGVPcHMudXBkYXRlVGFibGUoaWQsIHJlcXVlc3QpXG4gIH1cblxuICAvKipcbiAgICogRHJvcHMgYSB0YWJsZSBmcm9tIHRoZSBjYXRhbG9nLlxuICAgKlxuICAgKiBAcGFyYW0gaWQgLSBUYWJsZSBpZGVudGlmaWVyIHRvIGRyb3BcbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBhd2FpdCBjYXRhbG9nLmRyb3BUYWJsZSh7IG5hbWVzcGFjZTogWydhbmFseXRpY3MnXSwgbmFtZTogJ2V2ZW50cycgfSk7XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgZHJvcFRhYmxlKGlkOiBUYWJsZUlkZW50aWZpZXIsIG9wdGlvbnM/OiBEcm9wVGFibGVSZXF1ZXN0KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgdGhpcy50YWJsZU9wcy5kcm9wVGFibGUoaWQsIG9wdGlvbnMpXG4gIH1cblxuICAvKipcbiAgICogTG9hZHMgbWV0YWRhdGEgZm9yIGEgdGFibGUuXG4gICAqXG4gICAqIEBwYXJhbSBpZCAtIFRhYmxlIGlkZW50aWZpZXIgdG8gbG9hZFxuICAgKiBAcmV0dXJucyBUYWJsZSBtZXRhZGF0YSBpbmNsdWRpbmcgc2NoZW1hLCBwYXJ0aXRpb24gc3BlYywgbG9jYXRpb24sIGV0Yy5cbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBjb25zdCBtZXRhZGF0YSA9IGF3YWl0IGNhdGFsb2cubG9hZFRhYmxlKHsgbmFtZXNwYWNlOiBbJ2FuYWx5dGljcyddLCBuYW1lOiAnZXZlbnRzJyB9KTtcbiAgICogY29uc29sZS5sb2cobWV0YWRhdGEuc2NoZW1hKTtcbiAgICogY29uc29sZS5sb2cobWV0YWRhdGEubG9jYXRpb24pO1xuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGxvYWRUYWJsZShpZDogVGFibGVJZGVudGlmaWVyKTogUHJvbWlzZTxUYWJsZU1ldGFkYXRhPiB7XG4gICAgcmV0dXJuIHRoaXMudGFibGVPcHMubG9hZFRhYmxlKGlkKVxuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyBpZiBhIG5hbWVzcGFjZSBleGlzdHMgaW4gdGhlIGNhdGFsb2cuXG4gICAqXG4gICAqIEBwYXJhbSBpZCAtIE5hbWVzcGFjZSBpZGVudGlmaWVyIHRvIGNoZWNrXG4gICAqIEByZXR1cm5zIFRydWUgaWYgdGhlIG5hbWVzcGFjZSBleGlzdHMsIGZhbHNlIG90aGVyd2lzZVxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IGV4aXN0cyA9IGF3YWl0IGNhdGFsb2cubmFtZXNwYWNlRXhpc3RzKHsgbmFtZXNwYWNlOiBbJ2FuYWx5dGljcyddIH0pO1xuICAgKiBjb25zb2xlLmxvZyhleGlzdHMpOyAvLyB0cnVlIG9yIGZhbHNlXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgbmFtZXNwYWNlRXhpc3RzKGlkOiBOYW1lc3BhY2VJZGVudGlmaWVyKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgcmV0dXJuIHRoaXMubmFtZXNwYWNlT3BzLm5hbWVzcGFjZUV4aXN0cyhpZClcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgYSB0YWJsZSBleGlzdHMgaW4gdGhlIGNhdGFsb2cuXG4gICAqXG4gICAqIEBwYXJhbSBpZCAtIFRhYmxlIGlkZW50aWZpZXIgdG8gY2hlY2tcbiAgICogQHJldHVybnMgVHJ1ZSBpZiB0aGUgdGFibGUgZXhpc3RzLCBmYWxzZSBvdGhlcndpc2VcbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBjb25zdCBleGlzdHMgPSBhd2FpdCBjYXRhbG9nLnRhYmxlRXhpc3RzKHsgbmFtZXNwYWNlOiBbJ2FuYWx5dGljcyddLCBuYW1lOiAnZXZlbnRzJyB9KTtcbiAgICogY29uc29sZS5sb2coZXhpc3RzKTsgLy8gdHJ1ZSBvciBmYWxzZVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIHRhYmxlRXhpc3RzKGlkOiBUYWJsZUlkZW50aWZpZXIpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICByZXR1cm4gdGhpcy50YWJsZU9wcy50YWJsZUV4aXN0cyhpZClcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmFtZXNwYWNlIGlmIGl0IGRvZXMgbm90IGV4aXN0LlxuICAgKlxuICAgKiBJZiB0aGUgbmFtZXNwYWNlIGFscmVhZHkgZXhpc3RzLCByZXR1cm5zIHZvaWQuIElmIGNyZWF0ZWQsIHJldHVybnMgdGhlIHJlc3BvbnNlLlxuICAgKlxuICAgKiBAcGFyYW0gaWQgLSBOYW1lc3BhY2UgaWRlbnRpZmllciB0byBjcmVhdGVcbiAgICogQHBhcmFtIG1ldGFkYXRhIC0gT3B0aW9uYWwgbWV0YWRhdGEgcHJvcGVydGllcyBmb3IgdGhlIG5hbWVzcGFjZVxuICAgKiBAcmV0dXJucyBSZXNwb25zZSBjb250YWluaW5nIHRoZSBjcmVhdGVkIG5hbWVzcGFjZSBhbmQgaXRzIHByb3BlcnRpZXMsIG9yIHZvaWQgaWYgaXQgYWxyZWFkeSBleGlzdHNcbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNhdGFsb2cuY3JlYXRlTmFtZXNwYWNlSWZOb3RFeGlzdHMoXG4gICAqICAgeyBuYW1lc3BhY2U6IFsnYW5hbHl0aWNzJ10gfSxcbiAgICogICB7IHByb3BlcnRpZXM6IHsgb3duZXI6ICdkYXRhLXRlYW0nIH0gfVxuICAgKiApO1xuICAgKiBpZiAocmVzcG9uc2UpIHtcbiAgICogICBjb25zb2xlLmxvZygnQ3JlYXRlZDonLCByZXNwb25zZS5uYW1lc3BhY2UpO1xuICAgKiB9IGVsc2Uge1xuICAgKiAgIGNvbnNvbGUubG9nKCdBbHJlYWR5IGV4aXN0cycpO1xuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgY3JlYXRlTmFtZXNwYWNlSWZOb3RFeGlzdHMoXG4gICAgaWQ6IE5hbWVzcGFjZUlkZW50aWZpZXIsXG4gICAgbWV0YWRhdGE/OiBOYW1lc3BhY2VNZXRhZGF0YVxuICApOiBQcm9taXNlPENyZWF0ZU5hbWVzcGFjZVJlc3BvbnNlIHwgdm9pZD4ge1xuICAgIHJldHVybiB0aGlzLm5hbWVzcGFjZU9wcy5jcmVhdGVOYW1lc3BhY2VJZk5vdEV4aXN0cyhpZCwgbWV0YWRhdGEpXG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIHRhYmxlIGlmIGl0IGRvZXMgbm90IGV4aXN0LlxuICAgKlxuICAgKiBJZiB0aGUgdGFibGUgYWxyZWFkeSBleGlzdHMsIHJldHVybnMgaXRzIG1ldGFkYXRhIGluc3RlYWQuXG4gICAqXG4gICAqIEBwYXJhbSBuYW1lc3BhY2UgLSBOYW1lc3BhY2UgdG8gY3JlYXRlIHRoZSB0YWJsZSBpblxuICAgKiBAcGFyYW0gcmVxdWVzdCAtIFRhYmxlIGNyZWF0aW9uIHJlcXVlc3QgaW5jbHVkaW5nIG5hbWUsIHNjaGVtYSwgcGFydGl0aW9uIHNwZWMsIGV0Yy5cbiAgICogQHJldHVybnMgVGFibGUgbWV0YWRhdGEgZm9yIHRoZSBjcmVhdGVkIG9yIGV4aXN0aW5nIHRhYmxlXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgbWV0YWRhdGEgPSBhd2FpdCBjYXRhbG9nLmNyZWF0ZVRhYmxlSWZOb3RFeGlzdHMoXG4gICAqICAgeyBuYW1lc3BhY2U6IFsnYW5hbHl0aWNzJ10gfSxcbiAgICogICB7XG4gICAqICAgICBuYW1lOiAnZXZlbnRzJyxcbiAgICogICAgIHNjaGVtYToge1xuICAgKiAgICAgICB0eXBlOiAnc3RydWN0JyxcbiAgICogICAgICAgZmllbGRzOiBbXG4gICAqICAgICAgICAgeyBpZDogMSwgbmFtZTogJ2lkJywgdHlwZTogJ2xvbmcnLCByZXF1aXJlZDogdHJ1ZSB9LFxuICAgKiAgICAgICAgIHsgaWQ6IDIsIG5hbWU6ICd0aW1lc3RhbXAnLCB0eXBlOiAndGltZXN0YW1wJywgcmVxdWlyZWQ6IHRydWUgfVxuICAgKiAgICAgICBdLFxuICAgKiAgICAgICAnc2NoZW1hLWlkJzogMFxuICAgKiAgICAgfVxuICAgKiAgIH1cbiAgICogKTtcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBjcmVhdGVUYWJsZUlmTm90RXhpc3RzKFxuICAgIG5hbWVzcGFjZTogTmFtZXNwYWNlSWRlbnRpZmllcixcbiAgICByZXF1ZXN0OiBDcmVhdGVUYWJsZVJlcXVlc3RcbiAgKTogUHJvbWlzZTxUYWJsZU1ldGFkYXRhPiB7XG4gICAgcmV0dXJuIHRoaXMudGFibGVPcHMuY3JlYXRlVGFibGVJZk5vdEV4aXN0cyhuYW1lc3BhY2UsIHJlcXVlc3QpXG4gIH1cbn1cbiIsImV4cG9ydCBpbnRlcmZhY2UgTmFtZXNwYWNlSWRlbnRpZmllciB7XG4gIG5hbWVzcGFjZTogc3RyaW5nW11cbn1cblxuZXhwb3J0IGludGVyZmFjZSBOYW1lc3BhY2VNZXRhZGF0YSB7XG4gIHByb3BlcnRpZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBUYWJsZUlkZW50aWZpZXIge1xuICBuYW1lc3BhY2U6IHN0cmluZ1tdXG4gIG5hbWU6IHN0cmluZ1xufVxuXG4vKipcbiAqIFByaW1pdGl2ZSB0eXBlcyBpbiBJY2ViZXJnIC0gYWxsIHJlcHJlc2VudGVkIGFzIHN0cmluZ3MuXG4gKiBQYXJhbWV0ZXJpemVkIHR5cGVzIHVzZSBzdHJpbmcgZm9ybWF0OiBkZWNpbWFsKHByZWNpc2lvbixzY2FsZSkgYW5kIGZpeGVkW2xlbmd0aF1cbiAqXG4gKiBOb3RlOiBUaGUgT3BlbkFQSSBzcGVjIGRlZmluZXMgUHJpbWl0aXZlVHlwZSBhcyBgdHlwZTogc3RyaW5nYCwgc28gYW55IHN0cmluZyBpcyB2YWxpZC5cbiAqIFdlIGluY2x1ZGUga25vd24gdHlwZXMgZm9yIGF1dG9jb21wbGV0ZSwgcGx1cyBhIGNhdGNoLWFsbCBmb3IgZmxleGliaWxpdHkuXG4gKi9cbmV4cG9ydCB0eXBlIFByaW1pdGl2ZVR5cGUgPVxuICB8ICdib29sZWFuJ1xuICB8ICdpbnQnXG4gIHwgJ2xvbmcnXG4gIHwgJ2Zsb2F0J1xuICB8ICdkb3VibGUnXG4gIHwgJ3N0cmluZydcbiAgfCAndGltZXN0YW1wJ1xuICB8ICdkYXRlJ1xuICB8ICd0aW1lJ1xuICB8ICd0aW1lc3RhbXB0eidcbiAgfCAndXVpZCdcbiAgfCAnYmluYXJ5J1xuICB8IGBkZWNpbWFsKCR7bnVtYmVyfSwke251bWJlcn0pYFxuICB8IGBmaXhlZFske251bWJlcn1dYFxuICB8IChzdHJpbmcgJiB7fSkgLy8gY2F0Y2gtYWxsIGZvciBhbnkgZm9ybWF0IChlLmcuLCBcImRlY2ltYWwoMTAsIDIpXCIgd2l0aCBzcGFjZXMpIGFuZCBmdXR1cmUgdHlwZXNcblxuLyoqXG4gKiBSZWdleCBwYXR0ZXJucyBmb3IgcGFyc2luZyBwYXJhbWV0ZXJpemVkIHR5cGVzLlxuICogVGhlc2UgYWxsb3cgZmxleGlibGUgd2hpdGVzcGFjZSBtYXRjaGluZy5cbiAqL1xuY29uc3QgREVDSU1BTF9SRUdFWCA9IC9eZGVjaW1hbFxccypcXChcXHMqKFxcZCspXFxzKixcXHMqKFxcZCspXFxzKlxcKSQvXG5jb25zdCBGSVhFRF9SRUdFWCA9IC9eZml4ZWRcXHMqXFxbXFxzKihcXGQrKVxccypcXF0kL1xuXG4vKipcbiAqIFBhcnNlIGEgZGVjaW1hbCB0eXBlIHN0cmluZyBpbnRvIGl0cyBjb21wb25lbnRzLlxuICogSGFuZGxlcyBhbnkgd2hpdGVzcGFjZSBmb3JtYXR0aW5nIChlLmcuLCBcImRlY2ltYWwoMTAsMilcIiwgXCJkZWNpbWFsKDEwLCAyKVwiLCBcImRlY2ltYWwoIDEwICwgMiApXCIpLlxuICpcbiAqIEBwYXJhbSB0eXBlIC0gVGhlIHR5cGUgc3RyaW5nIHRvIHBhcnNlXG4gKiBAcmV0dXJucyBPYmplY3Qgd2l0aCBwcmVjaXNpb24gYW5kIHNjYWxlLCBvciBudWxsIGlmIG5vdCBhIHZhbGlkIGRlY2ltYWwgdHlwZVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VEZWNpbWFsVHlwZSh0eXBlOiBzdHJpbmcpOiB7IHByZWNpc2lvbjogbnVtYmVyOyBzY2FsZTogbnVtYmVyIH0gfCBudWxsIHtcbiAgY29uc3QgbWF0Y2ggPSB0eXBlLm1hdGNoKERFQ0lNQUxfUkVHRVgpXG4gIGlmICghbWF0Y2gpIHJldHVybiBudWxsXG4gIHJldHVybiB7XG4gICAgcHJlY2lzaW9uOiBwYXJzZUludChtYXRjaFsxXSwgMTApLFxuICAgIHNjYWxlOiBwYXJzZUludChtYXRjaFsyXSwgMTApLFxuICB9XG59XG5cbi8qKlxuICogUGFyc2UgYSBmaXhlZCB0eXBlIHN0cmluZyBpbnRvIGl0cyBsZW5ndGguXG4gKiBIYW5kbGVzIGFueSB3aGl0ZXNwYWNlIGZvcm1hdHRpbmcgKGUuZy4sIFwiZml4ZWRbMTZdXCIsIFwiZml4ZWRbIDE2IF1cIikuXG4gKlxuICogQHBhcmFtIHR5cGUgLSBUaGUgdHlwZSBzdHJpbmcgdG8gcGFyc2VcbiAqIEByZXR1cm5zIE9iamVjdCB3aXRoIGxlbmd0aCwgb3IgbnVsbCBpZiBub3QgYSB2YWxpZCBmaXhlZCB0eXBlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUZpeGVkVHlwZSh0eXBlOiBzdHJpbmcpOiB7IGxlbmd0aDogbnVtYmVyIH0gfCBudWxsIHtcbiAgY29uc3QgbWF0Y2ggPSB0eXBlLm1hdGNoKEZJWEVEX1JFR0VYKVxuICBpZiAoIW1hdGNoKSByZXR1cm4gbnVsbFxuICByZXR1cm4ge1xuICAgIGxlbmd0aDogcGFyc2VJbnQobWF0Y2hbMV0sIDEwKSxcbiAgfVxufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgdHlwZSBzdHJpbmcgaXMgYSBkZWNpbWFsIHR5cGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0RlY2ltYWxUeXBlKHR5cGU6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gREVDSU1BTF9SRUdFWC50ZXN0KHR5cGUpXG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYSB0eXBlIHN0cmluZyBpcyBhIGZpeGVkIHR5cGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0ZpeGVkVHlwZSh0eXBlOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgcmV0dXJuIEZJWEVEX1JFR0VYLnRlc3QodHlwZSlcbn1cblxuLyoqXG4gKiBDb21wYXJlIHR3byBJY2ViZXJnIHR5cGUgc3RyaW5ncyBmb3IgZXF1YWxpdHksIGlnbm9yaW5nIHdoaXRlc3BhY2UgZGlmZmVyZW5jZXMuXG4gKiBUaGlzIGlzIHVzZWZ1bCB3aGVuIGNvbXBhcmluZyB0eXBlcyBmcm9tIHVzZXIgaW5wdXQgdnMgY2F0YWxvZyByZXNwb25zZXMsXG4gKiBhcyBjYXRhbG9ncyBtYXkgbm9ybWFsaXplIHdoaXRlc3BhY2UgZGlmZmVyZW50bHkuXG4gKlxuICogQHBhcmFtIGEgLSBGaXJzdCB0eXBlIHN0cmluZ1xuICogQHBhcmFtIGIgLSBTZWNvbmQgdHlwZSBzdHJpbmdcbiAqIEByZXR1cm5zIHRydWUgaWYgdGhlIHR5cGVzIGFyZSBlcXVpdmFsZW50XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0eXBlc0VxdWFsKGE6IHN0cmluZywgYjogc3RyaW5nKTogYm9vbGVhbiB7XG4gIC8vIEZvciBkZWNpbWFsIHR5cGVzLCBjb21wYXJlIHBhcnNlZCB2YWx1ZXNcbiAgY29uc3QgZGVjaW1hbEEgPSBwYXJzZURlY2ltYWxUeXBlKGEpXG4gIGNvbnN0IGRlY2ltYWxCID0gcGFyc2VEZWNpbWFsVHlwZShiKVxuICBpZiAoZGVjaW1hbEEgJiYgZGVjaW1hbEIpIHtcbiAgICByZXR1cm4gZGVjaW1hbEEucHJlY2lzaW9uID09PSBkZWNpbWFsQi5wcmVjaXNpb24gJiYgZGVjaW1hbEEuc2NhbGUgPT09IGRlY2ltYWxCLnNjYWxlXG4gIH1cblxuICAvLyBGb3IgZml4ZWQgdHlwZXMsIGNvbXBhcmUgcGFyc2VkIHZhbHVlc1xuICBjb25zdCBmaXhlZEEgPSBwYXJzZUZpeGVkVHlwZShhKVxuICBjb25zdCBmaXhlZEIgPSBwYXJzZUZpeGVkVHlwZShiKVxuICBpZiAoZml4ZWRBICYmIGZpeGVkQikge1xuICAgIHJldHVybiBmaXhlZEEubGVuZ3RoID09PSBmaXhlZEIubGVuZ3RoXG4gIH1cblxuICAvLyBGb3Igb3RoZXIgdHlwZXMsIGRpcmVjdCBzdHJpbmcgY29tcGFyaXNvblxuICByZXR1cm4gYSA9PT0gYlxufVxuXG4vKipcbiAqIFN0cnVjdCB0eXBlIC0gYSBuZXN0ZWQgc3RydWN0dXJlIGNvbnRhaW5pbmcgZmllbGRzLlxuICogVXNlZCBmb3IgbmVzdGVkIHJlY29yZHMgd2l0aGluIGEgZmllbGQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3RydWN0VHlwZSB7XG4gIHR5cGU6ICdzdHJ1Y3QnXG4gIGZpZWxkczogU3RydWN0RmllbGRbXVxufVxuXG4vKipcbiAqIExpc3QgdHlwZSAtIGFuIGFycmF5IG9mIGVsZW1lbnRzLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIExpc3RUeXBlIHtcbiAgdHlwZTogJ2xpc3QnXG4gICdlbGVtZW50LWlkJzogbnVtYmVyXG4gIGVsZW1lbnQ6IEljZWJlcmdUeXBlXG4gICdlbGVtZW50LXJlcXVpcmVkJzogYm9vbGVhblxufVxuXG4vKipcbiAqIE1hcCB0eXBlIC0gYSBrZXktdmFsdWUgbWFwcGluZy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNYXBUeXBlIHtcbiAgdHlwZTogJ21hcCdcbiAgJ2tleS1pZCc6IG51bWJlclxuICBrZXk6IEljZWJlcmdUeXBlXG4gICd2YWx1ZS1pZCc6IG51bWJlclxuICB2YWx1ZTogSWNlYmVyZ1R5cGVcbiAgJ3ZhbHVlLXJlcXVpcmVkJzogYm9vbGVhblxufVxuXG4vKipcbiAqIFVuaW9uIG9mIGFsbCBJY2ViZXJnIHR5cGVzLlxuICogQ2FuIGJlIGEgcHJpbWl0aXZlIHR5cGUgKHN0cmluZykgb3IgYSBjb21wbGV4IHR5cGUgKHN0cnVjdCwgbGlzdCwgbWFwKS5cbiAqL1xuZXhwb3J0IHR5cGUgSWNlYmVyZ1R5cGUgPSBQcmltaXRpdmVUeXBlIHwgU3RydWN0VHlwZSB8IExpc3RUeXBlIHwgTWFwVHlwZVxuXG4vKipcbiAqIFByaW1pdGl2ZSB0eXBlIHZhbHVlcyBmb3IgZGVmYXVsdCB2YWx1ZXMuXG4gKiBSZXByZXNlbnRzIHRoZSBwb3NzaWJsZSB2YWx1ZXMgZm9yIGluaXRpYWwtZGVmYXVsdCBhbmQgd3JpdGUtZGVmYXVsdC5cbiAqL1xuZXhwb3J0IHR5cGUgUHJpbWl0aXZlVHlwZVZhbHVlID0gYm9vbGVhbiB8IG51bWJlciB8IHN0cmluZ1xuXG4vKipcbiAqIEEgZmllbGQgd2l0aGluIGEgc3RydWN0ICh1c2VkIGluIG5lc3RlZCBTdHJ1Y3RUeXBlKS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBTdHJ1Y3RGaWVsZCB7XG4gIGlkOiBudW1iZXJcbiAgbmFtZTogc3RyaW5nXG4gIHR5cGU6IEljZWJlcmdUeXBlXG4gIHJlcXVpcmVkOiBib29sZWFuXG4gIGRvYz86IHN0cmluZ1xuICAnaW5pdGlhbC1kZWZhdWx0Jz86IFByaW1pdGl2ZVR5cGVWYWx1ZVxuICAnd3JpdGUtZGVmYXVsdCc/OiBQcmltaXRpdmVUeXBlVmFsdWVcbn1cblxuLyoqXG4gKiBBIGZpZWxkIHdpdGhpbiBhIHRhYmxlIHNjaGVtYSAodG9wLWxldmVsKS5cbiAqIEVxdWl2YWxlbnQgdG8gU3RydWN0RmllbGQgYnV0IGtlcHQgZm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFRhYmxlRmllbGQge1xuICBpZDogbnVtYmVyXG4gIG5hbWU6IHN0cmluZ1xuICB0eXBlOiBJY2ViZXJnVHlwZVxuICByZXF1aXJlZDogYm9vbGVhblxuICBkb2M/OiBzdHJpbmdcbiAgJ2luaXRpYWwtZGVmYXVsdCc/OiBQcmltaXRpdmVUeXBlVmFsdWVcbiAgJ3dyaXRlLWRlZmF1bHQnPzogUHJpbWl0aXZlVHlwZVZhbHVlXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGFibGVTY2hlbWEge1xuICB0eXBlOiAnc3RydWN0J1xuICBmaWVsZHM6IFRhYmxlRmllbGRbXVxuICAnc2NoZW1hLWlkJz86IG51bWJlclxuICAnaWRlbnRpZmllci1maWVsZC1pZHMnPzogbnVtYmVyW11cbn1cblxuZXhwb3J0IGludGVyZmFjZSBQYXJ0aXRpb25GaWVsZCB7XG4gIHNvdXJjZV9pZDogbnVtYmVyXG4gIGZpZWxkX2lkOiBudW1iZXJcbiAgbmFtZTogc3RyaW5nXG4gIHRyYW5zZm9ybTogc3RyaW5nXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGFydGl0aW9uU3BlYyB7XG4gICdzcGVjLWlkJzogbnVtYmVyXG4gIGZpZWxkczogUGFydGl0aW9uRmllbGRbXVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNvcnRGaWVsZCB7XG4gIHNvdXJjZV9pZDogbnVtYmVyXG4gIHRyYW5zZm9ybTogc3RyaW5nXG4gIGRpcmVjdGlvbjogJ2FzYycgfCAnZGVzYydcbiAgbnVsbF9vcmRlcjogJ251bGxzLWZpcnN0JyB8ICdudWxscy1sYXN0J1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNvcnRPcmRlciB7XG4gICdvcmRlci1pZCc6IG51bWJlclxuICBmaWVsZHM6IFNvcnRGaWVsZFtdXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlVGFibGVSZXF1ZXN0IHtcbiAgbmFtZTogc3RyaW5nXG4gIHNjaGVtYTogVGFibGVTY2hlbWFcbiAgJ3BhcnRpdGlvbi1zcGVjJz86IFBhcnRpdGlvblNwZWNcbiAgJ3dyaXRlLW9yZGVyJz86IFNvcnRPcmRlclxuICBwcm9wZXJ0aWVzPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPlxuICAnc3RhZ2UtY3JlYXRlJz86IGJvb2xlYW5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVUYWJsZVJlcXVlc3Qge1xuICBzY2hlbWE/OiBUYWJsZVNjaGVtYVxuICAncGFydGl0aW9uLXNwZWMnPzogUGFydGl0aW9uU3BlY1xuICBwcm9wZXJ0aWVzPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPlxufVxuXG5leHBvcnQgaW50ZXJmYWNlIERyb3BUYWJsZVJlcXVlc3Qge1xuICBwdXJnZT86IGJvb2xlYW5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBUYWJsZU1ldGFkYXRhIHtcbiAgbmFtZT86IHN0cmluZ1xuICBsb2NhdGlvbjogc3RyaW5nXG4gIHNjaGVtYXM6IFRhYmxlU2NoZW1hW11cbiAgJ2N1cnJlbnQtc2NoZW1hLWlkJzogbnVtYmVyXG4gICdwYXJ0aXRpb24tc3BlY3MnOiBQYXJ0aXRpb25TcGVjW11cbiAgJ2RlZmF1bHQtc3BlYy1pZCc/OiBudW1iZXJcbiAgJ3NvcnQtb3JkZXJzJzogU29ydE9yZGVyW11cbiAgJ2RlZmF1bHQtc29ydC1vcmRlci1pZCc/OiBudW1iZXJcbiAgcHJvcGVydGllczogUmVjb3JkPHN0cmluZywgc3RyaW5nPlxuICAnbWV0YWRhdGEtbG9jYXRpb24nPzogc3RyaW5nXG4gICdjdXJyZW50LXNuYXBzaG90LWlkJz86IG51bWJlclxuICBzbmFwc2hvdHM/OiB1bmtub3duW11cbiAgJ3NuYXBzaG90LWxvZyc/OiB1bmtub3duW11cbiAgJ21ldGFkYXRhLWxvZyc/OiB1bmtub3duW11cbiAgcmVmcz86IFJlY29yZDxzdHJpbmcsIHVua25vd24+XG4gICdsYXN0LXVwZGF0ZWQtbXMnPzogbnVtYmVyXG4gICdsYXN0LWNvbHVtbi1pZCc/OiBudW1iZXJcbiAgJ2xhc3Qtc2VxdWVuY2UtbnVtYmVyJz86IG51bWJlclxuICAndGFibGUtdXVpZCc/OiBzdHJpbmdcbiAgJ2Zvcm1hdC12ZXJzaW9uJz86IG51bWJlclxuICAnbGFzdC1wYXJ0aXRpb24taWQnPzogbnVtYmVyXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlTmFtZXNwYWNlUmVxdWVzdCB7XG4gIG5hbWVzcGFjZTogc3RyaW5nW11cbiAgcHJvcGVydGllcz86IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBDcmVhdGVOYW1lc3BhY2VSZXNwb25zZSB7XG4gIG5hbWVzcGFjZTogc3RyaW5nW11cbiAgcHJvcGVydGllcz86IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBHZXROYW1lc3BhY2VSZXNwb25zZSB7XG4gIG5hbWVzcGFjZTogc3RyaW5nW11cbiAgcHJvcGVydGllczogUmVjb3JkPHN0cmluZywgc3RyaW5nPlxufVxuXG5leHBvcnQgaW50ZXJmYWNlIExpc3ROYW1lc3BhY2VzUmVzcG9uc2Uge1xuICBuYW1lc3BhY2VzOiBzdHJpbmdbXVtdXG4gICduZXh0LXBhZ2UtdG9rZW4nPzogc3RyaW5nXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTGlzdFRhYmxlc1Jlc3BvbnNlIHtcbiAgaWRlbnRpZmllcnM6IFRhYmxlSWRlbnRpZmllcltdXG4gICduZXh0LXBhZ2UtdG9rZW4nPzogc3RyaW5nXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTG9hZFRhYmxlUmVzcG9uc2Uge1xuICAnbWV0YWRhdGEtbG9jYXRpb24nOiBzdHJpbmdcbiAgbWV0YWRhdGE6IFRhYmxlTWV0YWRhdGFcbiAgY29uZmlnPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPlxufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdFRhYmxlUmVzcG9uc2Uge1xuICAnbWV0YWRhdGEtbG9jYXRpb24nOiBzdHJpbmdcbiAgbWV0YWRhdGE6IFRhYmxlTWV0YWRhdGFcbn1cblxuLyoqXG4gKiBHZXRzIHRoZSBjdXJyZW50IChhY3RpdmUpIHNjaGVtYSBmcm9tIHRhYmxlIG1ldGFkYXRhLlxuICpcbiAqIEBwYXJhbSBtZXRhZGF0YSAtIFRhYmxlIG1ldGFkYXRhIGNvbnRhaW5pbmcgc2NoZW1hcyBhcnJheSBhbmQgY3VycmVudC1zY2hlbWEtaWRcbiAqIEByZXR1cm5zIFRoZSBjdXJyZW50IHRhYmxlIHNjaGVtYSwgb3IgdW5kZWZpbmVkIGlmIG5vdCBmb3VuZFxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q3VycmVudFNjaGVtYShtZXRhZGF0YTogVGFibGVNZXRhZGF0YSk6IFRhYmxlU2NoZW1hIHwgdW5kZWZpbmVkIHtcbiAgcmV0dXJuIG1ldGFkYXRhLnNjaGVtYXMuZmluZCgocykgPT4gc1snc2NoZW1hLWlkJ10gPT09IG1ldGFkYXRhWydjdXJyZW50LXNjaGVtYS1pZCddKVxufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2XX0=