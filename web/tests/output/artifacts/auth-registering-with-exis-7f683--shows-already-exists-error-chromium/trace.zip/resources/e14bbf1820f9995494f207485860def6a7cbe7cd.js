import __vite__cjsImport0_cookie from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.cache/vite/client/deps/@nuxtjs_supabase___@supabase_ssr___cookie.js?v=1219a004"; const parse = __vite__cjsImport0_cookie["parse"]; const serialize = __vite__cjsImport0_cookie["serialize"];
import { DEFAULT_COOKIE_OPTIONS, combineChunks, createChunks, isBrowser, isChunkLike, stringFromBase64URL, stringToBase64URL, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+ssr@0.10.3_@supabase+supabase-js@2.108.1/node_modules/@supabase/ssr/dist/module/utils/index.js?v=583078ff";
const BASE64_PREFIX = "base64-";
/**
 * Decodes a chunked cookie value that may carry the `base64-` prefix written
 * by this module. When the prefix is present, the underlying payload is always
 * JSON encoded by auth-js (`setItemAsync` runs `JSON.stringify` on every
 * write). If the decoded value cannot be parsed as JSON, the chunks are
 * mismatched (e.g. a partial cookie write left the browser holding a mix of
 * old and new generations) and we treat the entry as absent so the SDK does
 * not propagate or re-save the corrupted payload.
 */
function decodeChunkedCookieValue(value) {
    if (!value.startsWith(BASE64_PREFIX)) {
        return value;
    }
    let decoded;
    try {
        decoded = stringFromBase64URL(value.substring(BASE64_PREFIX.length));
    }
    catch (error) {
        console.warn("@supabase/ssr: could not base64url-decode chunked cookie value, treating as absent. Cookie chunks may have been written partially across responses.", error);
        return null;
    }
    try {
        JSON.parse(decoded);
    }
    catch {
        console.warn("@supabase/ssr: chunked cookie decoded to invalid JSON, treating as absent. This usually indicates that cookie chunks from different writes were combined (e.g. response committed before all Set-Cookie headers were sent).");
        return null;
    }
    return decoded;
}
/**
 * Creates a storage client that handles cookies correctly for browser and
 * server clients with or without properly provided cookie methods.
 *
 * @param options The options passed to createBrowserClient or createServer client.
 *
 * @param isServerClient Whether it's called from createServerClient.
 */
export function createStorageFromOptions(options, isServerClient) {
    const cookies = options.cookies ?? null;
    const cookieEncoding = options.cookieEncoding;
    const setItems = {};
    const removedItems = {};
    let getAll;
    let setAll;
    const documentCookieGetAll = () => {
        const parsed = parse(document.cookie);
        return Object.keys(parsed).map((name) => ({
            name,
            value: parsed[name] ?? "",
        }));
    };
    const documentCookieSetAll = (setCookies) => {
        setCookies.forEach(({ name, value, options }) => {
            document.cookie = serialize(name, value, options);
        });
    };
    if (cookies) {
        if ("get" in cookies) {
            // Just get is not enough, because the client needs to see what cookies
            // are already set and unset them if necessary. To attempt to fix this
            // behavior for most use cases, we pass "hints" which is the keys of the
            // storage items. They are then converted to their corresponding cookie
            // chunk names and are fetched with get. Only 5 chunks are fetched, which
            // should be enough for the majority of use cases, but does not solve
            // those with very large sessions.
            const getWithHints = async (keyHints) => {
                // optimistically find the first 5 potential chunks for the specified key
                const chunkNames = keyHints.flatMap((keyHint) => [
                    keyHint,
                    ...Array.from({ length: 5 }).map((_, i) => `${keyHint}.${i}`),
                ]);
                const chunks = [];
                for (let i = 0; i < chunkNames.length; i += 1) {
                    const value = await cookies.get(chunkNames[i]);
                    if (!value && typeof value !== "string") {
                        continue;
                    }
                    chunks.push({ name: chunkNames[i], value });
                }
                // TODO: detect and log stale chunks error
                return chunks;
            };
            getAll = async (keyHints) => await getWithHints(keyHints);
            if ("set" in cookies && "remove" in cookies) {
                setAll = async (setCookies) => {
                    for (let i = 0; i < setCookies.length; i += 1) {
                        const { name, value, options } = setCookies[i];
                        if (value) {
                            await cookies.set(name, value, options);
                        }
                        else {
                            await cookies.remove(name, options);
                        }
                    }
                };
            }
            else if (isServerClient) {
                setAll = async () => {
                    console.warn("@supabase/ssr: createServerClient was configured without set and remove cookie methods, but the client needs to set cookies. This can lead to issues such as random logouts, early session termination or increased token refresh requests. If in NextJS, check your middleware.ts file, route handlers and server actions for correctness. Consider switching to the getAll and setAll cookie methods instead of get, set and remove which are deprecated and can be difficult to use correctly.");
                };
            }
            else {
                throw new Error("@supabase/ssr: createBrowserClient requires configuring a getAll and setAll cookie method (deprecated: alternatively both get, set and remove can be used)");
            }
        }
        else if ("getAll" in cookies) {
            getAll = async () => await cookies.getAll();
            if ("setAll" in cookies) {
                setAll = cookies.setAll;
            }
            else if (isServerClient) {
                setAll = async () => {
                    console.warn("@supabase/ssr: createServerClient was configured without the setAll cookie method, but the client needs to set cookies. This can lead to issues such as random logouts, early session termination or increased token refresh requests. If in NextJS, check your middleware.ts file, route handlers and server actions for correctness.");
                };
            }
            else {
                throw new Error("@supabase/ssr: createBrowserClient requires configuring both getAll and setAll cookie methods (deprecated: alternatively both get, set and remove can be used)");
            }
        }
        else if (!isServerClient && isBrowser()) {
            // cookies object provided (e.g. just to set `encode`) but no accessors.
            // Fall through to document.cookie defaults, same as when cookies isn't
            // provided at all.
            getAll = () => documentCookieGetAll();
            setAll = documentCookieSetAll;
        }
        else {
            // neither get nor getAll is present on cookies, only will occur if pure JavaScript is used, but cookies is an object
            throw new Error(`@supabase/ssr: ${isServerClient ? "createServerClient" : "createBrowserClient"} requires configuring getAll and setAll cookie methods (deprecated: alternatively use get, set and remove).${isBrowser() ? " As this is called in a browser runtime, consider removing the cookies option object to use the document.cookie API automatically." : ""}`);
        }
    }
    else if (!isServerClient && isBrowser()) {
        // The environment is browser, so use the document.cookie API to implement getAll and setAll.
        getAll = () => documentCookieGetAll();
        setAll = documentCookieSetAll;
    }
    else if (isServerClient) {
        throw new Error("@supabase/ssr: createServerClient must be initialized with cookie options that specify getAll and setAll functions (deprecated, not recommended: alternatively use get, set and remove)");
    }
    else {
        // getting cookies when there's no window but we're in browser mode can be OK, because the developer probably is not using auth functions
        getAll = () => {
            return [];
        };
        // this is NOT OK because the developer is using auth functions that require setting some state, so that must error out
        setAll = () => {
            throw new Error("@supabase/ssr: createBrowserClient in non-browser runtimes (including Next.js pre-rendering mode) was not initialized cookie options that specify getAll and setAll functions (deprecated: alternatively use get, set and remove), but they were needed");
        };
    }
    if (!isServerClient) {
        // This is the storage client to be used in browsers. It only
        // works on the cookies abstraction, unlike the server client
        // which only uses cookies to read the initial state. When an
        // item is set, cookies are both cleared and set to values so
        // that stale chunks are not left remaining.
        return {
            getAll, // for type consistency
            setAll, // for type consistency
            setItems, // for type consistency
            removedItems, // for type consistency
            storage: {
                isServer: false,
                getItem: async (key) => {
                    const allCookies = await getAll([key]);
                    const chunkedCookie = await combineChunks(key, async (chunkName) => {
                        const cookie = allCookies?.find(({ name }) => name === chunkName) || null;
                        if (!cookie) {
                            return null;
                        }
                        return cookie.value;
                    });
                    if (!chunkedCookie) {
                        return null;
                    }
                    return decodeChunkedCookieValue(chunkedCookie);
                },
                setItem: async (key, value) => {
                    const allCookies = await getAll([key]);
                    const cookieNames = allCookies?.map(({ name }) => name) || [];
                    const removeCookies = new Set(cookieNames.filter((name) => isChunkLike(name, key)));
                    let encoded = value;
                    if (cookieEncoding === "base64url") {
                        encoded = BASE64_PREFIX + stringToBase64URL(value);
                    }
                    const setCookies = createChunks(key, encoded);
                    setCookies.forEach(({ name }) => {
                        removeCookies.delete(name);
                    });
                    const removeCookieOptions = {
                        ...DEFAULT_COOKIE_OPTIONS,
                        ...options?.cookieOptions,
                        maxAge: 0,
                    };
                    const setCookieOptions = {
                        ...DEFAULT_COOKIE_OPTIONS,
                        ...options?.cookieOptions,
                        maxAge: DEFAULT_COOKIE_OPTIONS.maxAge,
                    };
                    // the NextJS cookieStore API can get confused if the `name` from
                    // options.cookieOptions leaks
                    delete removeCookieOptions.name;
                    delete setCookieOptions.name;
                    const allToSet = [
                        ...[...removeCookies].map((name) => ({
                            name,
                            value: "",
                            options: removeCookieOptions,
                        })),
                        ...setCookies.map(({ name, value }) => ({
                            name,
                            value,
                            options: setCookieOptions,
                        })),
                    ];
                    if (allToSet.length > 0) {
                        await setAll(allToSet, {});
                    }
                },
                removeItem: async (key) => {
                    const allCookies = await getAll([key]);
                    const cookieNames = allCookies?.map(({ name }) => name) || [];
                    const removeCookies = cookieNames.filter((name) => isChunkLike(name, key));
                    const removeCookieOptions = {
                        ...DEFAULT_COOKIE_OPTIONS,
                        ...options?.cookieOptions,
                        maxAge: 0,
                    };
                    // the NextJS cookieStore API can get confused if the `name` from
                    // options.cookieOptions leaks
                    delete removeCookieOptions.name;
                    if (removeCookies.length > 0) {
                        await setAll(removeCookies.map((name) => ({
                            name,
                            value: "",
                            options: removeCookieOptions,
                        })), {});
                    }
                },
            },
        };
    }
    // This is the server client. It only uses getAll to read the initial
    // state. Any subsequent changes to the items is persisted in the
    // setItems and removedItems objects. createServerClient *must* use
    // getAll, setAll and the values in setItems and removedItems to
    // persist the changes *at once* when appropriate (usually only when
    // the TOKEN_REFRESHED, USER_UPDATED or SIGNED_OUT events are fired by
    // the Supabase Auth client).
    return {
        getAll,
        setAll,
        setItems,
        removedItems,
        storage: {
            // to signal to the libraries that these cookies are
            // coming from a server environment and their value
            // should not be trusted
            isServer: true,
            getItem: async (key) => {
                if (typeof setItems[key] === "string") {
                    return setItems[key];
                }
                if (removedItems[key]) {
                    return null;
                }
                const allCookies = await getAll([key]);
                const chunkedCookie = await combineChunks(key, async (chunkName) => {
                    const cookie = allCookies?.find(({ name }) => name === chunkName) || null;
                    if (!cookie) {
                        return null;
                    }
                    return cookie.value;
                });
                if (!chunkedCookie) {
                    return null;
                }
                if (typeof chunkedCookie !== "string") {
                    return chunkedCookie;
                }
                return decodeChunkedCookieValue(chunkedCookie);
            },
            setItem: async (key, value) => {
                // We don't have an `onAuthStateChange` event that can let us know that
                // the PKCE code verifier is being set. Therefore, if we see it being
                // set, we need to apply the storage (call `setAll` so the cookie is
                // set properly).
                if (key.endsWith("-code-verifier")) {
                    await applyServerStorage({
                        getAll,
                        setAll,
                        // pretend only that the code verifier was set
                        setItems: { [key]: value },
                        // pretend that nothing was removed
                        removedItems: {},
                    }, {
                        cookieOptions: options?.cookieOptions ?? null,
                        cookieEncoding,
                    });
                }
                setItems[key] = value;
                delete removedItems[key];
            },
            removeItem: async (key) => {
                // Intentionally not applying the storage when the key is the PKCE code
                // verifier, as usually right after it's removed other items are set,
                // so application of the storage will be handled by the
                // `onAuthStateChange` callback that follows removal -- usually as part
                // of the `exchangeCodeForSession` call.
                delete setItems[key];
                removedItems[key] = true;
            },
        },
    };
}
/**
 * When createServerClient needs to apply the created storage to cookies, it
 * should call this function which handles correcly setting cookies for stored
 * and removed items in the storage.
 */
export async function applyServerStorage({ getAll, setAll, setItems, removedItems, }, options) {
    const cookieEncoding = options.cookieEncoding;
    const cookieOptions = options.cookieOptions ?? null;
    const allCookies = await getAll([
        ...(setItems ? Object.keys(setItems) : []),
        ...(removedItems ? Object.keys(removedItems) : []),
    ]);
    const cookieNames = allCookies?.map(({ name }) => name) || [];
    const removeCookies = Object.keys(removedItems).flatMap((itemName) => {
        return cookieNames.filter((name) => isChunkLike(name, itemName));
    });
    const setCookies = Object.keys(setItems).flatMap((itemName) => {
        const removeExistingCookiesForItem = new Set(cookieNames.filter((name) => isChunkLike(name, itemName)));
        let encoded = setItems[itemName];
        if (cookieEncoding === "base64url") {
            encoded = BASE64_PREFIX + stringToBase64URL(encoded);
        }
        const chunks = createChunks(itemName, encoded);
        chunks.forEach((chunk) => {
            removeExistingCookiesForItem.delete(chunk.name);
        });
        removeCookies.push(...removeExistingCookiesForItem);
        return chunks;
    });
    const removeCookieOptions = {
        ...DEFAULT_COOKIE_OPTIONS,
        ...cookieOptions,
        maxAge: 0,
    };
    const setCookieOptions = {
        ...DEFAULT_COOKIE_OPTIONS,
        ...cookieOptions,
        maxAge: DEFAULT_COOKIE_OPTIONS.maxAge,
    };
    // the NextJS cookieStore API can get confused if the `name` from
    // options.cookieOptions leaks
    delete removeCookieOptions.name;
    delete setCookieOptions.name;
    await setAll([
        ...removeCookies.map((name) => ({
            name,
            value: "",
            options: removeCookieOptions,
        })),
        ...setCookies.map(({ name, value }) => ({
            name,
            value,
            options: setCookieOptions,
        })),
    ], {
        "Cache-Control": "private, no-cache, no-store, must-revalidate, max-age=0",
        Expires: "0",
        Pragma: "no-cache",
    });
}
                                   
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29va2llcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb29raWVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU0sUUFBUSxDQUFDO0FBRTFDLE9BQU8sRUFDTCxzQkFBc0IsRUFDdEIsYUFBYSxFQUNiLFlBQVksRUFDWixTQUFTLEVBQ1QsV0FBVyxFQUNYLG1CQUFtQixFQUNuQixpQkFBaUIsR0FDbEIsTUFBTSxTQUFTLENBQUM7QUFhakIsTUFBTSxhQUFhLEdBQUcsU0FBUyxDQUFDO0FBRWhDOzs7Ozs7OztHQVFHO0FBQ0gsU0FBUyx3QkFBd0IsQ0FBQyxLQUFhO0lBQzdDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7UUFDckMsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsSUFBSSxPQUFlLENBQUM7SUFFcEIsSUFBSSxDQUFDO1FBQ0gsT0FBTyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsSUFBSSxDQUNWLHFKQUFxSixFQUNySixLQUFLLENBQ04sQ0FBQztRQUNGLE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVELElBQUksQ0FBQztRQUNILElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdEIsQ0FBQztJQUFDLE1BQU0sQ0FBQztRQUNQLE9BQU8sQ0FBQyxJQUFJLENBQ1YsNk5BQTZOLENBQzlOLENBQUM7UUFDRixPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRCxPQUFPLE9BQU8sQ0FBQztBQUNqQixDQUFDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILE1BQU0sVUFBVSx3QkFBd0IsQ0FDdEMsT0FRQyxFQUNELGNBQXVCO0lBRXZCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDO0lBQ3hDLE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUM7SUFFOUMsTUFBTSxRQUFRLEdBQThCLEVBQUUsQ0FBQztJQUMvQyxNQUFNLFlBQVksR0FBK0IsRUFBRSxDQUFDO0lBRXBELElBQUksTUFBeUQsQ0FBQztJQUM5RCxJQUFJLE1BQXFCLENBQUM7SUFFMUIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLEVBQUU7UUFDaEMsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV0QyxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3hDLElBQUk7WUFDSixLQUFLLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7U0FDMUIsQ0FBQyxDQUFDLENBQUM7SUFDTixDQUFDLENBQUM7SUFFRixNQUFNLG9CQUFvQixHQUFrQixDQUFDLFVBQVUsRUFBRSxFQUFFO1FBQ3pELFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRTtZQUM5QyxRQUFRLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3BELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDO0lBRUYsSUFBSSxPQUFPLEVBQUUsQ0FBQztRQUNaLElBQUksS0FBSyxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ3JCLHVFQUF1RTtZQUN2RSxzRUFBc0U7WUFDdEUsd0VBQXdFO1lBQ3hFLHVFQUF1RTtZQUN2RSx5RUFBeUU7WUFDekUscUVBQXFFO1lBQ3JFLGtDQUFrQztZQUVsQyxNQUFNLFlBQVksR0FBRyxLQUFLLEVBQUUsUUFBa0IsRUFBRSxFQUFFO2dCQUNoRCx5RUFBeUU7Z0JBQ3pFLE1BQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO29CQUMvQyxPQUFPO29CQUNQLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxDQUFDO2lCQUM5RCxDQUFDLENBQUM7Z0JBRUgsTUFBTSxNQUFNLEdBQThCLEVBQUUsQ0FBQztnQkFFN0MsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLEtBQUssR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRS9DLElBQUksQ0FBQyxLQUFLLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7d0JBQ3hDLFNBQVM7b0JBQ1gsQ0FBQztvQkFFRCxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2dCQUM5QyxDQUFDO2dCQUVELDBDQUEwQztnQkFFMUMsT0FBTyxNQUFNLENBQUM7WUFDaEIsQ0FBQyxDQUFDO1lBRUYsTUFBTSxHQUFHLEtBQUssRUFBRSxRQUFrQixFQUFFLEVBQUUsQ0FBQyxNQUFNLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUVwRSxJQUFJLEtBQUssSUFBSSxPQUFPLElBQUksUUFBUSxJQUFJLE9BQU8sRUFBRSxDQUFDO2dCQUM1QyxNQUFNLEdBQUcsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFO29CQUM1QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQzlDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFL0MsSUFBSSxLQUFLLEVBQUUsQ0FBQzs0QkFDVixNQUFNLE9BQU8sQ0FBQyxHQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQzt3QkFDM0MsQ0FBQzs2QkFBTSxDQUFDOzRCQUNOLE1BQU0sT0FBTyxDQUFDLE1BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7d0JBQ3ZDLENBQUM7b0JBQ0gsQ0FBQztnQkFDSCxDQUFDLENBQUM7WUFDSixDQUFDO2lCQUFNLElBQUksY0FBYyxFQUFFLENBQUM7Z0JBQzFCLE1BQU0sR0FBRyxLQUFLLElBQUksRUFBRTtvQkFDbEIsT0FBTyxDQUFDLElBQUksQ0FDVixtZUFBbWUsQ0FDcGUsQ0FBQztnQkFDSixDQUFDLENBQUM7WUFDSixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxJQUFJLEtBQUssQ0FDYiw0SkFBNEosQ0FDN0osQ0FBQztZQUNKLENBQUM7UUFDSCxDQUFDO2FBQU0sSUFBSSxRQUFRLElBQUksT0FBTyxFQUFFLENBQUM7WUFDL0IsTUFBTSxHQUFHLEtBQUssSUFBSSxFQUFFLENBQUMsTUFBTSxPQUFPLENBQUMsTUFBTyxFQUFFLENBQUM7WUFFN0MsSUFBSSxRQUFRLElBQUksT0FBTyxFQUFFLENBQUM7Z0JBQ3hCLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTyxDQUFDO1lBQzNCLENBQUM7aUJBQU0sSUFBSSxjQUFjLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxHQUFHLEtBQUssSUFBSSxFQUFFO29CQUNsQixPQUFPLENBQUMsSUFBSSxDQUNWLHdVQUF3VSxDQUN6VSxDQUFDO2dCQUNKLENBQUMsQ0FBQztZQUNKLENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLElBQUksS0FBSyxDQUNiLGdLQUFnSyxDQUNqSyxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUM7YUFBTSxJQUFJLENBQUMsY0FBYyxJQUFJLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDMUMsd0VBQXdFO1lBQ3hFLHVFQUF1RTtZQUN2RSxtQkFBbUI7WUFDbkIsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDLG9CQUFvQixFQUFFLENBQUM7WUFDdEMsTUFBTSxHQUFHLG9CQUFvQixDQUFDO1FBQ2hDLENBQUM7YUFBTSxDQUFDO1lBQ04scUhBQXFIO1lBQ3JILE1BQU0sSUFBSSxLQUFLLENBQ2Isa0JBQWtCLGNBQWMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLHFCQUFxQiw4R0FBOEcsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLG9JQUFvSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FDdlYsQ0FBQztRQUNKLENBQUM7SUFDSCxDQUFDO1NBQU0sSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLEVBQUUsRUFBRSxDQUFDO1FBQzFDLDZGQUE2RjtRQUM3RixNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUN0QyxNQUFNLEdBQUcsb0JBQW9CLENBQUM7SUFDaEMsQ0FBQztTQUFNLElBQUksY0FBYyxFQUFFLENBQUM7UUFDMUIsTUFBTSxJQUFJLEtBQUssQ0FDYix5TEFBeUwsQ0FDMUwsQ0FBQztJQUNKLENBQUM7U0FBTSxDQUFDO1FBQ04seUlBQXlJO1FBQ3pJLE1BQU0sR0FBRyxHQUFHLEVBQUU7WUFDWixPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUMsQ0FBQztRQUVGLHVIQUF1SDtRQUN2SCxNQUFNLEdBQUcsR0FBRyxFQUFFO1lBQ1osTUFBTSxJQUFJLEtBQUssQ0FDYix5UEFBeVAsQ0FDMVAsQ0FBQztRQUNKLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDcEIsNkRBQTZEO1FBQzdELDZEQUE2RDtRQUM3RCw2REFBNkQ7UUFDN0QsNkRBQTZEO1FBQzdELDRDQUE0QztRQUM1QyxPQUFPO1lBQ0wsTUFBTSxFQUFFLHVCQUF1QjtZQUMvQixNQUFNLEVBQUUsdUJBQXVCO1lBQy9CLFFBQVEsRUFBRSx1QkFBdUI7WUFDakMsWUFBWSxFQUFFLHVCQUF1QjtZQUNyQyxPQUFPLEVBQUU7Z0JBQ1AsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsT0FBTyxFQUFFLEtBQUssRUFBRSxHQUFXLEVBQUUsRUFBRTtvQkFDN0IsTUFBTSxVQUFVLEdBQUcsTUFBTSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN2QyxNQUFNLGFBQWEsR0FBRyxNQUFNLGFBQWEsQ0FDdkMsR0FBRyxFQUNILEtBQUssRUFBRSxTQUFpQixFQUFFLEVBQUU7d0JBQzFCLE1BQU0sTUFBTSxHQUNWLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEtBQUssU0FBUyxDQUFDLElBQUksSUFBSSxDQUFDO3dCQUU3RCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7NEJBQ1osT0FBTyxJQUFJLENBQUM7d0JBQ2QsQ0FBQzt3QkFFRCxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0JBQ3RCLENBQUMsQ0FDRixDQUFDO29CQUVGLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDbkIsT0FBTyxJQUFJLENBQUM7b0JBQ2QsQ0FBQztvQkFFRCxPQUFPLHdCQUF3QixDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUNqRCxDQUFDO2dCQUNELE9BQU8sRUFBRSxLQUFLLEVBQUUsR0FBVyxFQUFFLEtBQWEsRUFBRSxFQUFFO29CQUM1QyxNQUFNLFVBQVUsR0FBRyxNQUFNLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZDLE1BQU0sV0FBVyxHQUFHLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBRTlELE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxDQUMzQixXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQ3JELENBQUM7b0JBRUYsSUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDO29CQUVwQixJQUFJLGNBQWMsS0FBSyxXQUFXLEVBQUUsQ0FBQzt3QkFDbkMsT0FBTyxHQUFHLGFBQWEsR0FBRyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDckQsQ0FBQztvQkFFRCxNQUFNLFVBQVUsR0FBRyxZQUFZLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDO29CQUU5QyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFO3dCQUM5QixhQUFhLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUM3QixDQUFDLENBQUMsQ0FBQztvQkFFSCxNQUFNLG1CQUFtQixHQUFHO3dCQUMxQixHQUFHLHNCQUFzQjt3QkFDekIsR0FBRyxPQUFPLEVBQUUsYUFBYTt3QkFDekIsTUFBTSxFQUFFLENBQUM7cUJBQ1YsQ0FBQztvQkFDRixNQUFNLGdCQUFnQixHQUFHO3dCQUN2QixHQUFHLHNCQUFzQjt3QkFDekIsR0FBRyxPQUFPLEVBQUUsYUFBYTt3QkFDekIsTUFBTSxFQUFFLHNCQUFzQixDQUFDLE1BQU07cUJBQ3RDLENBQUM7b0JBRUYsaUVBQWlFO29CQUNqRSw4QkFBOEI7b0JBQzlCLE9BQU8sbUJBQW1CLENBQUMsSUFBSSxDQUFDO29CQUNoQyxPQUFPLGdCQUFnQixDQUFDLElBQUksQ0FBQztvQkFFN0IsTUFBTSxRQUFRLEdBQUc7d0JBQ2YsR0FBRyxDQUFDLEdBQUcsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDOzRCQUNuQyxJQUFJOzRCQUNKLEtBQUssRUFBRSxFQUFFOzRCQUNULE9BQU8sRUFBRSxtQkFBbUI7eUJBQzdCLENBQUMsQ0FBQzt3QkFDSCxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQzs0QkFDdEMsSUFBSTs0QkFDSixLQUFLOzRCQUNMLE9BQU8sRUFBRSxnQkFBZ0I7eUJBQzFCLENBQUMsQ0FBQztxQkFDSixDQUFDO29CQUVGLElBQUksUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDeEIsTUFBTSxNQUFNLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUM3QixDQUFDO2dCQUNILENBQUM7Z0JBQ0QsVUFBVSxFQUFFLEtBQUssRUFBRSxHQUFXLEVBQUUsRUFBRTtvQkFDaEMsTUFBTSxVQUFVLEdBQUcsTUFBTSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN2QyxNQUFNLFdBQVcsR0FBRyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO29CQUM5RCxNQUFNLGFBQWEsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FDaEQsV0FBVyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FDdkIsQ0FBQztvQkFFRixNQUFNLG1CQUFtQixHQUFHO3dCQUMxQixHQUFHLHNCQUFzQjt3QkFDekIsR0FBRyxPQUFPLEVBQUUsYUFBYTt3QkFDekIsTUFBTSxFQUFFLENBQUM7cUJBQ1YsQ0FBQztvQkFFRixpRUFBaUU7b0JBQ2pFLDhCQUE4QjtvQkFDOUIsT0FBTyxtQkFBbUIsQ0FBQyxJQUFJLENBQUM7b0JBRWhDLElBQUksYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDN0IsTUFBTSxNQUFNLENBQ1YsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQzs0QkFDM0IsSUFBSTs0QkFDSixLQUFLLEVBQUUsRUFBRTs0QkFDVCxPQUFPLEVBQUUsbUJBQW1CO3lCQUM3QixDQUFDLENBQUMsRUFDSCxFQUFFLENBQ0gsQ0FBQztvQkFDSixDQUFDO2dCQUNILENBQUM7YUFDRjtTQUNGLENBQUM7SUFDSixDQUFDO0lBRUQscUVBQXFFO0lBQ3JFLGlFQUFpRTtJQUNqRSxtRUFBbUU7SUFDbkUsZ0VBQWdFO0lBQ2hFLG9FQUFvRTtJQUNwRSxzRUFBc0U7SUFDdEUsNkJBQTZCO0lBQzdCLE9BQU87UUFDTCxNQUFNO1FBQ04sTUFBTTtRQUNOLFFBQVE7UUFDUixZQUFZO1FBQ1osT0FBTyxFQUFFO1lBQ1Asb0RBQW9EO1lBQ3BELG1EQUFtRDtZQUNuRCx3QkFBd0I7WUFDeEIsUUFBUSxFQUFFLElBQUk7WUFDZCxPQUFPLEVBQUUsS0FBSyxFQUFFLEdBQVcsRUFBRSxFQUFFO2dCQUM3QixJQUFJLE9BQU8sUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsRUFBRSxDQUFDO29CQUN0QyxPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDdkIsQ0FBQztnQkFFRCxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUN0QixPQUFPLElBQUksQ0FBQztnQkFDZCxDQUFDO2dCQUVELE1BQU0sVUFBVSxHQUFHLE1BQU0sTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdkMsTUFBTSxhQUFhLEdBQUcsTUFBTSxhQUFhLENBQ3ZDLEdBQUcsRUFDSCxLQUFLLEVBQUUsU0FBaUIsRUFBRSxFQUFFO29CQUMxQixNQUFNLE1BQU0sR0FDVixVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsSUFBSSxLQUFLLFNBQVMsQ0FBQyxJQUFJLElBQUksQ0FBQztvQkFFN0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO3dCQUNaLE9BQU8sSUFBSSxDQUFDO29CQUNkLENBQUM7b0JBRUQsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUN0QixDQUFDLENBQ0YsQ0FBQztnQkFFRixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ25CLE9BQU8sSUFBSSxDQUFDO2dCQUNkLENBQUM7Z0JBRUQsSUFBSSxPQUFPLGFBQWEsS0FBSyxRQUFRLEVBQUUsQ0FBQztvQkFDdEMsT0FBTyxhQUFhLENBQUM7Z0JBQ3ZCLENBQUM7Z0JBRUQsT0FBTyx3QkFBd0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNqRCxDQUFDO1lBQ0QsT0FBTyxFQUFFLEtBQUssRUFBRSxHQUFXLEVBQUUsS0FBYSxFQUFFLEVBQUU7Z0JBQzVDLHVFQUF1RTtnQkFDdkUscUVBQXFFO2dCQUNyRSxvRUFBb0U7Z0JBQ3BFLGlCQUFpQjtnQkFDakIsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQztvQkFDbkMsTUFBTSxrQkFBa0IsQ0FDdEI7d0JBQ0UsTUFBTTt3QkFDTixNQUFNO3dCQUNOLDhDQUE4Qzt3QkFDOUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUU7d0JBQzFCLG1DQUFtQzt3QkFDbkMsWUFBWSxFQUFFLEVBQUU7cUJBQ2pCLEVBQ0Q7d0JBQ0UsYUFBYSxFQUFFLE9BQU8sRUFBRSxhQUFhLElBQUksSUFBSTt3QkFDN0MsY0FBYztxQkFDZixDQUNGLENBQUM7Z0JBQ0osQ0FBQztnQkFFRCxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO2dCQUN0QixPQUFPLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMzQixDQUFDO1lBQ0QsVUFBVSxFQUFFLEtBQUssRUFBRSxHQUFXLEVBQUUsRUFBRTtnQkFDaEMsdUVBQXVFO2dCQUN2RSxxRUFBcUU7Z0JBQ3JFLHVEQUF1RDtnQkFDdkQsdUVBQXVFO2dCQUN2RSx3Q0FBd0M7Z0JBQ3hDLE9BQU8sUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQixZQUFZLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQzNCLENBQUM7U0FDRjtLQUNGLENBQUM7QUFDSixDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQU0sQ0FBQyxLQUFLLFVBQVUsa0JBQWtCLENBQ3RDLEVBQ0UsTUFBTSxFQUNOLE1BQU0sRUFDTixRQUFRLEVBQ1IsWUFBWSxHQU1iLEVBQ0QsT0FHQztJQUVELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUM7SUFDOUMsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUM7SUFFcEQsTUFBTSxVQUFVLEdBQUcsTUFBTSxNQUFNLENBQUM7UUFDOUIsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3hELEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNqRSxDQUFDLENBQUM7SUFDSCxNQUFNLFdBQVcsR0FBRyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0lBRTlELE1BQU0sYUFBYSxHQUFhLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUMvRCxDQUFDLFFBQVEsRUFBRSxFQUFFO1FBQ1gsT0FBTyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDbkUsQ0FBQyxDQUNGLENBQUM7SUFFRixNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1FBQzVELE1BQU0sNEJBQTRCLEdBQUcsSUFBSSxHQUFHLENBQzFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FDMUQsQ0FBQztRQUVGLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVqQyxJQUFJLGNBQWMsS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUNuQyxPQUFPLEdBQUcsYUFBYSxHQUFHLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3ZELENBQUM7UUFFRCxNQUFNLE1BQU0sR0FBRyxZQUFZLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRS9DLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUN2Qiw0QkFBNEIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxDQUFDO1FBRUgsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLDRCQUE0QixDQUFDLENBQUM7UUFFcEQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQyxDQUFDLENBQUM7SUFFSCxNQUFNLG1CQUFtQixHQUFHO1FBQzFCLEdBQUcsc0JBQXNCO1FBQ3pCLEdBQUcsYUFBYTtRQUNoQixNQUFNLEVBQUUsQ0FBQztLQUNWLENBQUM7SUFDRixNQUFNLGdCQUFnQixHQUFHO1FBQ3ZCLEdBQUcsc0JBQXNCO1FBQ3pCLEdBQUcsYUFBYTtRQUNoQixNQUFNLEVBQUUsc0JBQXNCLENBQUMsTUFBTTtLQUN0QyxDQUFDO0lBRUYsaUVBQWlFO0lBQ2pFLDhCQUE4QjtJQUM5QixPQUFRLG1CQUEyQixDQUFDLElBQUksQ0FBQztJQUN6QyxPQUFRLGdCQUF3QixDQUFDLElBQUksQ0FBQztJQUV0QyxNQUFNLE1BQU0sQ0FDVjtRQUNFLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztZQUM5QixJQUFJO1lBQ0osS0FBSyxFQUFFLEVBQUU7WUFDVCxPQUFPLEVBQUUsbUJBQW1CO1NBQzdCLENBQUMsQ0FBQztRQUNILEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3RDLElBQUk7WUFDSixLQUFLO1lBQ0wsT0FBTyxFQUFFLGdCQUFnQjtTQUMxQixDQUFDLENBQUM7S0FDSixFQUNEO1FBQ0UsZUFBZSxFQUNiLHlEQUF5RDtRQUMzRCxPQUFPLEVBQUUsR0FBRztRQUNaLE1BQU0sRUFBRSxVQUFVO0tBQ25CLENBQ0YsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBwYXJzZSwgc2VyaWFsaXplIH0gZnJvbSBcImNvb2tpZVwiO1xuXG5pbXBvcnQge1xuICBERUZBVUxUX0NPT0tJRV9PUFRJT05TLFxuICBjb21iaW5lQ2h1bmtzLFxuICBjcmVhdGVDaHVua3MsXG4gIGlzQnJvd3NlcixcbiAgaXNDaHVua0xpa2UsXG4gIHN0cmluZ0Zyb21CYXNlNjRVUkwsXG4gIHN0cmluZ1RvQmFzZTY0VVJMLFxufSBmcm9tIFwiLi91dGlsc1wiO1xuXG5pbXBvcnQgdHlwZSB7XG4gIENvb2tpZU1ldGhvZHNTZXJ2ZXIsXG4gIENvb2tpZU1ldGhvZHNTZXJ2ZXJEZXByZWNhdGVkLFxuICBDb29raWVNZXRob2RzQnJvd3NlcixcbiAgQ29va2llTWV0aG9kc0Jyb3dzZXJEZXByZWNhdGVkLFxuICBDb29raWVPcHRpb25zLFxuICBDb29raWVPcHRpb25zV2l0aE5hbWUsXG4gIEdldEFsbENvb2tpZXMsXG4gIFNldEFsbENvb2tpZXMsXG59IGZyb20gXCIuL3R5cGVzXCI7XG5cbmNvbnN0IEJBU0U2NF9QUkVGSVggPSBcImJhc2U2NC1cIjtcblxuLyoqXG4gKiBEZWNvZGVzIGEgY2h1bmtlZCBjb29raWUgdmFsdWUgdGhhdCBtYXkgY2FycnkgdGhlIGBiYXNlNjQtYCBwcmVmaXggd3JpdHRlblxuICogYnkgdGhpcyBtb2R1bGUuIFdoZW4gdGhlIHByZWZpeCBpcyBwcmVzZW50LCB0aGUgdW5kZXJseWluZyBwYXlsb2FkIGlzIGFsd2F5c1xuICogSlNPTiBlbmNvZGVkIGJ5IGF1dGgtanMgKGBzZXRJdGVtQXN5bmNgIHJ1bnMgYEpTT04uc3RyaW5naWZ5YCBvbiBldmVyeVxuICogd3JpdGUpLiBJZiB0aGUgZGVjb2RlZCB2YWx1ZSBjYW5ub3QgYmUgcGFyc2VkIGFzIEpTT04sIHRoZSBjaHVua3MgYXJlXG4gKiBtaXNtYXRjaGVkIChlLmcuIGEgcGFydGlhbCBjb29raWUgd3JpdGUgbGVmdCB0aGUgYnJvd3NlciBob2xkaW5nIGEgbWl4IG9mXG4gKiBvbGQgYW5kIG5ldyBnZW5lcmF0aW9ucykgYW5kIHdlIHRyZWF0IHRoZSBlbnRyeSBhcyBhYnNlbnQgc28gdGhlIFNESyBkb2VzXG4gKiBub3QgcHJvcGFnYXRlIG9yIHJlLXNhdmUgdGhlIGNvcnJ1cHRlZCBwYXlsb2FkLlxuICovXG5mdW5jdGlvbiBkZWNvZGVDaHVua2VkQ29va2llVmFsdWUodmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXZhbHVlLnN0YXJ0c1dpdGgoQkFTRTY0X1BSRUZJWCkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cblxuICBsZXQgZGVjb2RlZDogc3RyaW5nO1xuXG4gIHRyeSB7XG4gICAgZGVjb2RlZCA9IHN0cmluZ0Zyb21CYXNlNjRVUkwodmFsdWUuc3Vic3RyaW5nKEJBU0U2NF9QUkVGSVgubGVuZ3RoKSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS53YXJuKFxuICAgICAgXCJAc3VwYWJhc2Uvc3NyOiBjb3VsZCBub3QgYmFzZTY0dXJsLWRlY29kZSBjaHVua2VkIGNvb2tpZSB2YWx1ZSwgdHJlYXRpbmcgYXMgYWJzZW50LiBDb29raWUgY2h1bmtzIG1heSBoYXZlIGJlZW4gd3JpdHRlbiBwYXJ0aWFsbHkgYWNyb3NzIHJlc3BvbnNlcy5cIixcbiAgICAgIGVycm9yLFxuICAgICk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICB0cnkge1xuICAgIEpTT04ucGFyc2UoZGVjb2RlZCk7XG4gIH0gY2F0Y2gge1xuICAgIGNvbnNvbGUud2FybihcbiAgICAgIFwiQHN1cGFiYXNlL3NzcjogY2h1bmtlZCBjb29raWUgZGVjb2RlZCB0byBpbnZhbGlkIEpTT04sIHRyZWF0aW5nIGFzIGFic2VudC4gVGhpcyB1c3VhbGx5IGluZGljYXRlcyB0aGF0IGNvb2tpZSBjaHVua3MgZnJvbSBkaWZmZXJlbnQgd3JpdGVzIHdlcmUgY29tYmluZWQgKGUuZy4gcmVzcG9uc2UgY29tbWl0dGVkIGJlZm9yZSBhbGwgU2V0LUNvb2tpZSBoZWFkZXJzIHdlcmUgc2VudCkuXCIsXG4gICAgKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiBkZWNvZGVkO1xufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBzdG9yYWdlIGNsaWVudCB0aGF0IGhhbmRsZXMgY29va2llcyBjb3JyZWN0bHkgZm9yIGJyb3dzZXIgYW5kXG4gKiBzZXJ2ZXIgY2xpZW50cyB3aXRoIG9yIHdpdGhvdXQgcHJvcGVybHkgcHJvdmlkZWQgY29va2llIG1ldGhvZHMuXG4gKlxuICogQHBhcmFtIG9wdGlvbnMgVGhlIG9wdGlvbnMgcGFzc2VkIHRvIGNyZWF0ZUJyb3dzZXJDbGllbnQgb3IgY3JlYXRlU2VydmVyIGNsaWVudC5cbiAqXG4gKiBAcGFyYW0gaXNTZXJ2ZXJDbGllbnQgV2hldGhlciBpdCdzIGNhbGxlZCBmcm9tIGNyZWF0ZVNlcnZlckNsaWVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVN0b3JhZ2VGcm9tT3B0aW9ucyhcbiAgb3B0aW9uczoge1xuICAgIGNvb2tpZUVuY29kaW5nOiBcInJhd1wiIHwgXCJiYXNlNjR1cmxcIjtcbiAgICBjb29raWVzPzpcbiAgICAgIHwgQ29va2llTWV0aG9kc0Jyb3dzZXJcbiAgICAgIHwgQ29va2llTWV0aG9kc0Jyb3dzZXJEZXByZWNhdGVkXG4gICAgICB8IENvb2tpZU1ldGhvZHNTZXJ2ZXJcbiAgICAgIHwgQ29va2llTWV0aG9kc1NlcnZlckRlcHJlY2F0ZWQ7XG4gICAgY29va2llT3B0aW9ucz86IENvb2tpZU9wdGlvbnNXaXRoTmFtZTtcbiAgfSxcbiAgaXNTZXJ2ZXJDbGllbnQ6IGJvb2xlYW4sXG4pIHtcbiAgY29uc3QgY29va2llcyA9IG9wdGlvbnMuY29va2llcyA/PyBudWxsO1xuICBjb25zdCBjb29raWVFbmNvZGluZyA9IG9wdGlvbnMuY29va2llRW5jb2Rpbmc7XG5cbiAgY29uc3Qgc2V0SXRlbXM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fTtcbiAgY29uc3QgcmVtb3ZlZEl0ZW1zOiB7IFtrZXk6IHN0cmluZ106IGJvb2xlYW4gfSA9IHt9O1xuXG4gIGxldCBnZXRBbGw6IChrZXlIaW50czogc3RyaW5nW10pID0+IFJldHVyblR5cGU8R2V0QWxsQ29va2llcz47XG4gIGxldCBzZXRBbGw6IFNldEFsbENvb2tpZXM7XG5cbiAgY29uc3QgZG9jdW1lbnRDb29raWVHZXRBbGwgPSAoKSA9PiB7XG4gICAgY29uc3QgcGFyc2VkID0gcGFyc2UoZG9jdW1lbnQuY29va2llKTtcblxuICAgIHJldHVybiBPYmplY3Qua2V5cyhwYXJzZWQpLm1hcCgobmFtZSkgPT4gKHtcbiAgICAgIG5hbWUsXG4gICAgICB2YWx1ZTogcGFyc2VkW25hbWVdID8/IFwiXCIsXG4gICAgfSkpO1xuICB9O1xuXG4gIGNvbnN0IGRvY3VtZW50Q29va2llU2V0QWxsOiBTZXRBbGxDb29raWVzID0gKHNldENvb2tpZXMpID0+IHtcbiAgICBzZXRDb29raWVzLmZvckVhY2goKHsgbmFtZSwgdmFsdWUsIG9wdGlvbnMgfSkgPT4ge1xuICAgICAgZG9jdW1lbnQuY29va2llID0gc2VyaWFsaXplKG5hbWUsIHZhbHVlLCBvcHRpb25zKTtcbiAgICB9KTtcbiAgfTtcblxuICBpZiAoY29va2llcykge1xuICAgIGlmIChcImdldFwiIGluIGNvb2tpZXMpIHtcbiAgICAgIC8vIEp1c3QgZ2V0IGlzIG5vdCBlbm91Z2gsIGJlY2F1c2UgdGhlIGNsaWVudCBuZWVkcyB0byBzZWUgd2hhdCBjb29raWVzXG4gICAgICAvLyBhcmUgYWxyZWFkeSBzZXQgYW5kIHVuc2V0IHRoZW0gaWYgbmVjZXNzYXJ5LiBUbyBhdHRlbXB0IHRvIGZpeCB0aGlzXG4gICAgICAvLyBiZWhhdmlvciBmb3IgbW9zdCB1c2UgY2FzZXMsIHdlIHBhc3MgXCJoaW50c1wiIHdoaWNoIGlzIHRoZSBrZXlzIG9mIHRoZVxuICAgICAgLy8gc3RvcmFnZSBpdGVtcy4gVGhleSBhcmUgdGhlbiBjb252ZXJ0ZWQgdG8gdGhlaXIgY29ycmVzcG9uZGluZyBjb29raWVcbiAgICAgIC8vIGNodW5rIG5hbWVzIGFuZCBhcmUgZmV0Y2hlZCB3aXRoIGdldC4gT25seSA1IGNodW5rcyBhcmUgZmV0Y2hlZCwgd2hpY2hcbiAgICAgIC8vIHNob3VsZCBiZSBlbm91Z2ggZm9yIHRoZSBtYWpvcml0eSBvZiB1c2UgY2FzZXMsIGJ1dCBkb2VzIG5vdCBzb2x2ZVxuICAgICAgLy8gdGhvc2Ugd2l0aCB2ZXJ5IGxhcmdlIHNlc3Npb25zLlxuXG4gICAgICBjb25zdCBnZXRXaXRoSGludHMgPSBhc3luYyAoa2V5SGludHM6IHN0cmluZ1tdKSA9PiB7XG4gICAgICAgIC8vIG9wdGltaXN0aWNhbGx5IGZpbmQgdGhlIGZpcnN0IDUgcG90ZW50aWFsIGNodW5rcyBmb3IgdGhlIHNwZWNpZmllZCBrZXlcbiAgICAgICAgY29uc3QgY2h1bmtOYW1lcyA9IGtleUhpbnRzLmZsYXRNYXAoKGtleUhpbnQpID0+IFtcbiAgICAgICAgICBrZXlIaW50LFxuICAgICAgICAgIC4uLkFycmF5LmZyb20oeyBsZW5ndGg6IDUgfSkubWFwKChfLCBpKSA9PiBgJHtrZXlIaW50fS4ke2l9YCksXG4gICAgICAgIF0pO1xuXG4gICAgICAgIGNvbnN0IGNodW5rczogUmV0dXJuVHlwZTxHZXRBbGxDb29raWVzPiA9IFtdO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2h1bmtOYW1lcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXdhaXQgY29va2llcy5nZXQoY2h1bmtOYW1lc1tpXSk7XG5cbiAgICAgICAgICBpZiAoIXZhbHVlICYmIHR5cGVvZiB2YWx1ZSAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY2h1bmtzLnB1c2goeyBuYW1lOiBjaHVua05hbWVzW2ldLCB2YWx1ZSB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRPRE86IGRldGVjdCBhbmQgbG9nIHN0YWxlIGNodW5rcyBlcnJvclxuXG4gICAgICAgIHJldHVybiBjaHVua3M7XG4gICAgICB9O1xuXG4gICAgICBnZXRBbGwgPSBhc3luYyAoa2V5SGludHM6IHN0cmluZ1tdKSA9PiBhd2FpdCBnZXRXaXRoSGludHMoa2V5SGludHMpO1xuXG4gICAgICBpZiAoXCJzZXRcIiBpbiBjb29raWVzICYmIFwicmVtb3ZlXCIgaW4gY29va2llcykge1xuICAgICAgICBzZXRBbGwgPSBhc3luYyAoc2V0Q29va2llcykgPT4ge1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2V0Q29va2llcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgICAgY29uc3QgeyBuYW1lLCB2YWx1ZSwgb3B0aW9ucyB9ID0gc2V0Q29va2llc1tpXTtcblxuICAgICAgICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgICAgIGF3YWl0IGNvb2tpZXMuc2V0IShuYW1lLCB2YWx1ZSwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBhd2FpdCBjb29raWVzLnJlbW92ZSEobmFtZSwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIGlmIChpc1NlcnZlckNsaWVudCkge1xuICAgICAgICBzZXRBbGwgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgXCJAc3VwYWJhc2Uvc3NyOiBjcmVhdGVTZXJ2ZXJDbGllbnQgd2FzIGNvbmZpZ3VyZWQgd2l0aG91dCBzZXQgYW5kIHJlbW92ZSBjb29raWUgbWV0aG9kcywgYnV0IHRoZSBjbGllbnQgbmVlZHMgdG8gc2V0IGNvb2tpZXMuIFRoaXMgY2FuIGxlYWQgdG8gaXNzdWVzIHN1Y2ggYXMgcmFuZG9tIGxvZ291dHMsIGVhcmx5IHNlc3Npb24gdGVybWluYXRpb24gb3IgaW5jcmVhc2VkIHRva2VuIHJlZnJlc2ggcmVxdWVzdHMuIElmIGluIE5leHRKUywgY2hlY2sgeW91ciBtaWRkbGV3YXJlLnRzIGZpbGUsIHJvdXRlIGhhbmRsZXJzIGFuZCBzZXJ2ZXIgYWN0aW9ucyBmb3IgY29ycmVjdG5lc3MuIENvbnNpZGVyIHN3aXRjaGluZyB0byB0aGUgZ2V0QWxsIGFuZCBzZXRBbGwgY29va2llIG1ldGhvZHMgaW5zdGVhZCBvZiBnZXQsIHNldCBhbmQgcmVtb3ZlIHdoaWNoIGFyZSBkZXByZWNhdGVkIGFuZCBjYW4gYmUgZGlmZmljdWx0IHRvIHVzZSBjb3JyZWN0bHkuXCIsXG4gICAgICAgICAgKTtcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICBcIkBzdXBhYmFzZS9zc3I6IGNyZWF0ZUJyb3dzZXJDbGllbnQgcmVxdWlyZXMgY29uZmlndXJpbmcgYSBnZXRBbGwgYW5kIHNldEFsbCBjb29raWUgbWV0aG9kIChkZXByZWNhdGVkOiBhbHRlcm5hdGl2ZWx5IGJvdGggZ2V0LCBzZXQgYW5kIHJlbW92ZSBjYW4gYmUgdXNlZClcIixcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKFwiZ2V0QWxsXCIgaW4gY29va2llcykge1xuICAgICAgZ2V0QWxsID0gYXN5bmMgKCkgPT4gYXdhaXQgY29va2llcy5nZXRBbGwhKCk7XG5cbiAgICAgIGlmIChcInNldEFsbFwiIGluIGNvb2tpZXMpIHtcbiAgICAgICAgc2V0QWxsID0gY29va2llcy5zZXRBbGwhO1xuICAgICAgfSBlbHNlIGlmIChpc1NlcnZlckNsaWVudCkge1xuICAgICAgICBzZXRBbGwgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgXCJAc3VwYWJhc2Uvc3NyOiBjcmVhdGVTZXJ2ZXJDbGllbnQgd2FzIGNvbmZpZ3VyZWQgd2l0aG91dCB0aGUgc2V0QWxsIGNvb2tpZSBtZXRob2QsIGJ1dCB0aGUgY2xpZW50IG5lZWRzIHRvIHNldCBjb29raWVzLiBUaGlzIGNhbiBsZWFkIHRvIGlzc3VlcyBzdWNoIGFzIHJhbmRvbSBsb2dvdXRzLCBlYXJseSBzZXNzaW9uIHRlcm1pbmF0aW9uIG9yIGluY3JlYXNlZCB0b2tlbiByZWZyZXNoIHJlcXVlc3RzLiBJZiBpbiBOZXh0SlMsIGNoZWNrIHlvdXIgbWlkZGxld2FyZS50cyBmaWxlLCByb3V0ZSBoYW5kbGVycyBhbmQgc2VydmVyIGFjdGlvbnMgZm9yIGNvcnJlY3RuZXNzLlwiLFxuICAgICAgICAgICk7XG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgXCJAc3VwYWJhc2Uvc3NyOiBjcmVhdGVCcm93c2VyQ2xpZW50IHJlcXVpcmVzIGNvbmZpZ3VyaW5nIGJvdGggZ2V0QWxsIGFuZCBzZXRBbGwgY29va2llIG1ldGhvZHMgKGRlcHJlY2F0ZWQ6IGFsdGVybmF0aXZlbHkgYm90aCBnZXQsIHNldCBhbmQgcmVtb3ZlIGNhbiBiZSB1c2VkKVwiLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoIWlzU2VydmVyQ2xpZW50ICYmIGlzQnJvd3NlcigpKSB7XG4gICAgICAvLyBjb29raWVzIG9iamVjdCBwcm92aWRlZCAoZS5nLiBqdXN0IHRvIHNldCBgZW5jb2RlYCkgYnV0IG5vIGFjY2Vzc29ycy5cbiAgICAgIC8vIEZhbGwgdGhyb3VnaCB0byBkb2N1bWVudC5jb29raWUgZGVmYXVsdHMsIHNhbWUgYXMgd2hlbiBjb29raWVzIGlzbid0XG4gICAgICAvLyBwcm92aWRlZCBhdCBhbGwuXG4gICAgICBnZXRBbGwgPSAoKSA9PiBkb2N1bWVudENvb2tpZUdldEFsbCgpO1xuICAgICAgc2V0QWxsID0gZG9jdW1lbnRDb29raWVTZXRBbGw7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIG5laXRoZXIgZ2V0IG5vciBnZXRBbGwgaXMgcHJlc2VudCBvbiBjb29raWVzLCBvbmx5IHdpbGwgb2NjdXIgaWYgcHVyZSBKYXZhU2NyaXB0IGlzIHVzZWQsIGJ1dCBjb29raWVzIGlzIGFuIG9iamVjdFxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgQHN1cGFiYXNlL3NzcjogJHtpc1NlcnZlckNsaWVudCA/IFwiY3JlYXRlU2VydmVyQ2xpZW50XCIgOiBcImNyZWF0ZUJyb3dzZXJDbGllbnRcIn0gcmVxdWlyZXMgY29uZmlndXJpbmcgZ2V0QWxsIGFuZCBzZXRBbGwgY29va2llIG1ldGhvZHMgKGRlcHJlY2F0ZWQ6IGFsdGVybmF0aXZlbHkgdXNlIGdldCwgc2V0IGFuZCByZW1vdmUpLiR7aXNCcm93c2VyKCkgPyBcIiBBcyB0aGlzIGlzIGNhbGxlZCBpbiBhIGJyb3dzZXIgcnVudGltZSwgY29uc2lkZXIgcmVtb3ZpbmcgdGhlIGNvb2tpZXMgb3B0aW9uIG9iamVjdCB0byB1c2UgdGhlIGRvY3VtZW50LmNvb2tpZSBBUEkgYXV0b21hdGljYWxseS5cIiA6IFwiXCJ9YCxcbiAgICAgICk7XG4gICAgfVxuICB9IGVsc2UgaWYgKCFpc1NlcnZlckNsaWVudCAmJiBpc0Jyb3dzZXIoKSkge1xuICAgIC8vIFRoZSBlbnZpcm9ubWVudCBpcyBicm93c2VyLCBzbyB1c2UgdGhlIGRvY3VtZW50LmNvb2tpZSBBUEkgdG8gaW1wbGVtZW50IGdldEFsbCBhbmQgc2V0QWxsLlxuICAgIGdldEFsbCA9ICgpID0+IGRvY3VtZW50Q29va2llR2V0QWxsKCk7XG4gICAgc2V0QWxsID0gZG9jdW1lbnRDb29raWVTZXRBbGw7XG4gIH0gZWxzZSBpZiAoaXNTZXJ2ZXJDbGllbnQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBcIkBzdXBhYmFzZS9zc3I6IGNyZWF0ZVNlcnZlckNsaWVudCBtdXN0IGJlIGluaXRpYWxpemVkIHdpdGggY29va2llIG9wdGlvbnMgdGhhdCBzcGVjaWZ5IGdldEFsbCBhbmQgc2V0QWxsIGZ1bmN0aW9ucyAoZGVwcmVjYXRlZCwgbm90IHJlY29tbWVuZGVkOiBhbHRlcm5hdGl2ZWx5IHVzZSBnZXQsIHNldCBhbmQgcmVtb3ZlKVwiLFxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgLy8gZ2V0dGluZyBjb29raWVzIHdoZW4gdGhlcmUncyBubyB3aW5kb3cgYnV0IHdlJ3JlIGluIGJyb3dzZXIgbW9kZSBjYW4gYmUgT0ssIGJlY2F1c2UgdGhlIGRldmVsb3BlciBwcm9iYWJseSBpcyBub3QgdXNpbmcgYXV0aCBmdW5jdGlvbnNcbiAgICBnZXRBbGwgPSAoKSA9PiB7XG4gICAgICByZXR1cm4gW107XG4gICAgfTtcblxuICAgIC8vIHRoaXMgaXMgTk9UIE9LIGJlY2F1c2UgdGhlIGRldmVsb3BlciBpcyB1c2luZyBhdXRoIGZ1bmN0aW9ucyB0aGF0IHJlcXVpcmUgc2V0dGluZyBzb21lIHN0YXRlLCBzbyB0aGF0IG11c3QgZXJyb3Igb3V0XG4gICAgc2V0QWxsID0gKCkgPT4ge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBcIkBzdXBhYmFzZS9zc3I6IGNyZWF0ZUJyb3dzZXJDbGllbnQgaW4gbm9uLWJyb3dzZXIgcnVudGltZXMgKGluY2x1ZGluZyBOZXh0LmpzIHByZS1yZW5kZXJpbmcgbW9kZSkgd2FzIG5vdCBpbml0aWFsaXplZCBjb29raWUgb3B0aW9ucyB0aGF0IHNwZWNpZnkgZ2V0QWxsIGFuZCBzZXRBbGwgZnVuY3Rpb25zIChkZXByZWNhdGVkOiBhbHRlcm5hdGl2ZWx5IHVzZSBnZXQsIHNldCBhbmQgcmVtb3ZlKSwgYnV0IHRoZXkgd2VyZSBuZWVkZWRcIixcbiAgICAgICk7XG4gICAgfTtcbiAgfVxuXG4gIGlmICghaXNTZXJ2ZXJDbGllbnQpIHtcbiAgICAvLyBUaGlzIGlzIHRoZSBzdG9yYWdlIGNsaWVudCB0byBiZSB1c2VkIGluIGJyb3dzZXJzLiBJdCBvbmx5XG4gICAgLy8gd29ya3Mgb24gdGhlIGNvb2tpZXMgYWJzdHJhY3Rpb24sIHVubGlrZSB0aGUgc2VydmVyIGNsaWVudFxuICAgIC8vIHdoaWNoIG9ubHkgdXNlcyBjb29raWVzIHRvIHJlYWQgdGhlIGluaXRpYWwgc3RhdGUuIFdoZW4gYW5cbiAgICAvLyBpdGVtIGlzIHNldCwgY29va2llcyBhcmUgYm90aCBjbGVhcmVkIGFuZCBzZXQgdG8gdmFsdWVzIHNvXG4gICAgLy8gdGhhdCBzdGFsZSBjaHVua3MgYXJlIG5vdCBsZWZ0IHJlbWFpbmluZy5cbiAgICByZXR1cm4ge1xuICAgICAgZ2V0QWxsLCAvLyBmb3IgdHlwZSBjb25zaXN0ZW5jeVxuICAgICAgc2V0QWxsLCAvLyBmb3IgdHlwZSBjb25zaXN0ZW5jeVxuICAgICAgc2V0SXRlbXMsIC8vIGZvciB0eXBlIGNvbnNpc3RlbmN5XG4gICAgICByZW1vdmVkSXRlbXMsIC8vIGZvciB0eXBlIGNvbnNpc3RlbmN5XG4gICAgICBzdG9yYWdlOiB7XG4gICAgICAgIGlzU2VydmVyOiBmYWxzZSxcbiAgICAgICAgZ2V0SXRlbTogYXN5bmMgKGtleTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgY29uc3QgYWxsQ29va2llcyA9IGF3YWl0IGdldEFsbChba2V5XSk7XG4gICAgICAgICAgY29uc3QgY2h1bmtlZENvb2tpZSA9IGF3YWl0IGNvbWJpbmVDaHVua3MoXG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBhc3luYyAoY2h1bmtOYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgY29va2llID1cbiAgICAgICAgICAgICAgICBhbGxDb29raWVzPy5maW5kKCh7IG5hbWUgfSkgPT4gbmFtZSA9PT0gY2h1bmtOYW1lKSB8fCBudWxsO1xuXG4gICAgICAgICAgICAgIGlmICghY29va2llKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICByZXR1cm4gY29va2llLnZhbHVlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICApO1xuXG4gICAgICAgICAgaWYgKCFjaHVua2VkQ29va2llKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gZGVjb2RlQ2h1bmtlZENvb2tpZVZhbHVlKGNodW5rZWRDb29raWUpO1xuICAgICAgICB9LFxuICAgICAgICBzZXRJdGVtOiBhc3luYyAoa2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICBjb25zdCBhbGxDb29raWVzID0gYXdhaXQgZ2V0QWxsKFtrZXldKTtcbiAgICAgICAgICBjb25zdCBjb29raWVOYW1lcyA9IGFsbENvb2tpZXM/Lm1hcCgoeyBuYW1lIH0pID0+IG5hbWUpIHx8IFtdO1xuXG4gICAgICAgICAgY29uc3QgcmVtb3ZlQ29va2llcyA9IG5ldyBTZXQoXG4gICAgICAgICAgICBjb29raWVOYW1lcy5maWx0ZXIoKG5hbWUpID0+IGlzQ2h1bmtMaWtlKG5hbWUsIGtleSkpLFxuICAgICAgICAgICk7XG5cbiAgICAgICAgICBsZXQgZW5jb2RlZCA9IHZhbHVlO1xuXG4gICAgICAgICAgaWYgKGNvb2tpZUVuY29kaW5nID09PSBcImJhc2U2NHVybFwiKSB7XG4gICAgICAgICAgICBlbmNvZGVkID0gQkFTRTY0X1BSRUZJWCArIHN0cmluZ1RvQmFzZTY0VVJMKHZhbHVlKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCBzZXRDb29raWVzID0gY3JlYXRlQ2h1bmtzKGtleSwgZW5jb2RlZCk7XG5cbiAgICAgICAgICBzZXRDb29raWVzLmZvckVhY2goKHsgbmFtZSB9KSA9PiB7XG4gICAgICAgICAgICByZW1vdmVDb29raWVzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGNvbnN0IHJlbW92ZUNvb2tpZU9wdGlvbnMgPSB7XG4gICAgICAgICAgICAuLi5ERUZBVUxUX0NPT0tJRV9PUFRJT05TLFxuICAgICAgICAgICAgLi4ub3B0aW9ucz8uY29va2llT3B0aW9ucyxcbiAgICAgICAgICAgIG1heEFnZTogMCxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHNldENvb2tpZU9wdGlvbnMgPSB7XG4gICAgICAgICAgICAuLi5ERUZBVUxUX0NPT0tJRV9PUFRJT05TLFxuICAgICAgICAgICAgLi4ub3B0aW9ucz8uY29va2llT3B0aW9ucyxcbiAgICAgICAgICAgIG1heEFnZTogREVGQVVMVF9DT09LSUVfT1BUSU9OUy5tYXhBZ2UsXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vIHRoZSBOZXh0SlMgY29va2llU3RvcmUgQVBJIGNhbiBnZXQgY29uZnVzZWQgaWYgdGhlIGBuYW1lYCBmcm9tXG4gICAgICAgICAgLy8gb3B0aW9ucy5jb29raWVPcHRpb25zIGxlYWtzXG4gICAgICAgICAgZGVsZXRlIHJlbW92ZUNvb2tpZU9wdGlvbnMubmFtZTtcbiAgICAgICAgICBkZWxldGUgc2V0Q29va2llT3B0aW9ucy5uYW1lO1xuXG4gICAgICAgICAgY29uc3QgYWxsVG9TZXQgPSBbXG4gICAgICAgICAgICAuLi5bLi4ucmVtb3ZlQ29va2llc10ubWFwKChuYW1lKSA9PiAoe1xuICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICB2YWx1ZTogXCJcIixcbiAgICAgICAgICAgICAgb3B0aW9uczogcmVtb3ZlQ29va2llT3B0aW9ucyxcbiAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIC4uLnNldENvb2tpZXMubWFwKCh7IG5hbWUsIHZhbHVlIH0pID0+ICh7XG4gICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgICBvcHRpb25zOiBzZXRDb29raWVPcHRpb25zLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgIF07XG5cbiAgICAgICAgICBpZiAoYWxsVG9TZXQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgYXdhaXQgc2V0QWxsKGFsbFRvU2V0LCB7fSk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICByZW1vdmVJdGVtOiBhc3luYyAoa2V5OiBzdHJpbmcpID0+IHtcbiAgICAgICAgICBjb25zdCBhbGxDb29raWVzID0gYXdhaXQgZ2V0QWxsKFtrZXldKTtcbiAgICAgICAgICBjb25zdCBjb29raWVOYW1lcyA9IGFsbENvb2tpZXM/Lm1hcCgoeyBuYW1lIH0pID0+IG5hbWUpIHx8IFtdO1xuICAgICAgICAgIGNvbnN0IHJlbW92ZUNvb2tpZXMgPSBjb29raWVOYW1lcy5maWx0ZXIoKG5hbWUpID0+XG4gICAgICAgICAgICBpc0NodW5rTGlrZShuYW1lLCBrZXkpLFxuICAgICAgICAgICk7XG5cbiAgICAgICAgICBjb25zdCByZW1vdmVDb29raWVPcHRpb25zID0ge1xuICAgICAgICAgICAgLi4uREVGQVVMVF9DT09LSUVfT1BUSU9OUyxcbiAgICAgICAgICAgIC4uLm9wdGlvbnM/LmNvb2tpZU9wdGlvbnMsXG4gICAgICAgICAgICBtYXhBZ2U6IDAsXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vIHRoZSBOZXh0SlMgY29va2llU3RvcmUgQVBJIGNhbiBnZXQgY29uZnVzZWQgaWYgdGhlIGBuYW1lYCBmcm9tXG4gICAgICAgICAgLy8gb3B0aW9ucy5jb29raWVPcHRpb25zIGxlYWtzXG4gICAgICAgICAgZGVsZXRlIHJlbW92ZUNvb2tpZU9wdGlvbnMubmFtZTtcblxuICAgICAgICAgIGlmIChyZW1vdmVDb29raWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGF3YWl0IHNldEFsbChcbiAgICAgICAgICAgICAgcmVtb3ZlQ29va2llcy5tYXAoKG5hbWUpID0+ICh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICB2YWx1ZTogXCJcIixcbiAgICAgICAgICAgICAgICBvcHRpb25zOiByZW1vdmVDb29raWVPcHRpb25zLFxuICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH07XG4gIH1cblxuICAvLyBUaGlzIGlzIHRoZSBzZXJ2ZXIgY2xpZW50LiBJdCBvbmx5IHVzZXMgZ2V0QWxsIHRvIHJlYWQgdGhlIGluaXRpYWxcbiAgLy8gc3RhdGUuIEFueSBzdWJzZXF1ZW50IGNoYW5nZXMgdG8gdGhlIGl0ZW1zIGlzIHBlcnNpc3RlZCBpbiB0aGVcbiAgLy8gc2V0SXRlbXMgYW5kIHJlbW92ZWRJdGVtcyBvYmplY3RzLiBjcmVhdGVTZXJ2ZXJDbGllbnQgKm11c3QqIHVzZVxuICAvLyBnZXRBbGwsIHNldEFsbCBhbmQgdGhlIHZhbHVlcyBpbiBzZXRJdGVtcyBhbmQgcmVtb3ZlZEl0ZW1zIHRvXG4gIC8vIHBlcnNpc3QgdGhlIGNoYW5nZXMgKmF0IG9uY2UqIHdoZW4gYXBwcm9wcmlhdGUgKHVzdWFsbHkgb25seSB3aGVuXG4gIC8vIHRoZSBUT0tFTl9SRUZSRVNIRUQsIFVTRVJfVVBEQVRFRCBvciBTSUdORURfT1VUIGV2ZW50cyBhcmUgZmlyZWQgYnlcbiAgLy8gdGhlIFN1cGFiYXNlIEF1dGggY2xpZW50KS5cbiAgcmV0dXJuIHtcbiAgICBnZXRBbGwsXG4gICAgc2V0QWxsLFxuICAgIHNldEl0ZW1zLFxuICAgIHJlbW92ZWRJdGVtcyxcbiAgICBzdG9yYWdlOiB7XG4gICAgICAvLyB0byBzaWduYWwgdG8gdGhlIGxpYnJhcmllcyB0aGF0IHRoZXNlIGNvb2tpZXMgYXJlXG4gICAgICAvLyBjb21pbmcgZnJvbSBhIHNlcnZlciBlbnZpcm9ubWVudCBhbmQgdGhlaXIgdmFsdWVcbiAgICAgIC8vIHNob3VsZCBub3QgYmUgdHJ1c3RlZFxuICAgICAgaXNTZXJ2ZXI6IHRydWUsXG4gICAgICBnZXRJdGVtOiBhc3luYyAoa2V5OiBzdHJpbmcpID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiBzZXRJdGVtc1trZXldID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgcmV0dXJuIHNldEl0ZW1zW2tleV07XG4gICAgICAgIH1cblxuICAgICAgICBpZiAocmVtb3ZlZEl0ZW1zW2tleV0pIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGFsbENvb2tpZXMgPSBhd2FpdCBnZXRBbGwoW2tleV0pO1xuICAgICAgICBjb25zdCBjaHVua2VkQ29va2llID0gYXdhaXQgY29tYmluZUNodW5rcyhcbiAgICAgICAgICBrZXksXG4gICAgICAgICAgYXN5bmMgKGNodW5rTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBjb29raWUgPVxuICAgICAgICAgICAgICBhbGxDb29raWVzPy5maW5kKCh7IG5hbWUgfSkgPT4gbmFtZSA9PT0gY2h1bmtOYW1lKSB8fCBudWxsO1xuXG4gICAgICAgICAgICBpZiAoIWNvb2tpZSkge1xuICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIGNvb2tpZS52YWx1ZTtcbiAgICAgICAgICB9LFxuICAgICAgICApO1xuXG4gICAgICAgIGlmICghY2h1bmtlZENvb2tpZSkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHR5cGVvZiBjaHVua2VkQ29va2llICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgcmV0dXJuIGNodW5rZWRDb29raWU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gZGVjb2RlQ2h1bmtlZENvb2tpZVZhbHVlKGNodW5rZWRDb29raWUpO1xuICAgICAgfSxcbiAgICAgIHNldEl0ZW06IGFzeW5jIChrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZykgPT4ge1xuICAgICAgICAvLyBXZSBkb24ndCBoYXZlIGFuIGBvbkF1dGhTdGF0ZUNoYW5nZWAgZXZlbnQgdGhhdCBjYW4gbGV0IHVzIGtub3cgdGhhdFxuICAgICAgICAvLyB0aGUgUEtDRSBjb2RlIHZlcmlmaWVyIGlzIGJlaW5nIHNldC4gVGhlcmVmb3JlLCBpZiB3ZSBzZWUgaXQgYmVpbmdcbiAgICAgICAgLy8gc2V0LCB3ZSBuZWVkIHRvIGFwcGx5IHRoZSBzdG9yYWdlIChjYWxsIGBzZXRBbGxgIHNvIHRoZSBjb29raWUgaXNcbiAgICAgICAgLy8gc2V0IHByb3Blcmx5KS5cbiAgICAgICAgaWYgKGtleS5lbmRzV2l0aChcIi1jb2RlLXZlcmlmaWVyXCIpKSB7XG4gICAgICAgICAgYXdhaXQgYXBwbHlTZXJ2ZXJTdG9yYWdlKFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBnZXRBbGwsXG4gICAgICAgICAgICAgIHNldEFsbCxcbiAgICAgICAgICAgICAgLy8gcHJldGVuZCBvbmx5IHRoYXQgdGhlIGNvZGUgdmVyaWZpZXIgd2FzIHNldFxuICAgICAgICAgICAgICBzZXRJdGVtczogeyBba2V5XTogdmFsdWUgfSxcbiAgICAgICAgICAgICAgLy8gcHJldGVuZCB0aGF0IG5vdGhpbmcgd2FzIHJlbW92ZWRcbiAgICAgICAgICAgICAgcmVtb3ZlZEl0ZW1zOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGNvb2tpZU9wdGlvbnM6IG9wdGlvbnM/LmNvb2tpZU9wdGlvbnMgPz8gbnVsbCxcbiAgICAgICAgICAgICAgY29va2llRW5jb2RpbmcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJdGVtc1trZXldID0gdmFsdWU7XG4gICAgICAgIGRlbGV0ZSByZW1vdmVkSXRlbXNba2V5XTtcbiAgICAgIH0sXG4gICAgICByZW1vdmVJdGVtOiBhc3luYyAoa2V5OiBzdHJpbmcpID0+IHtcbiAgICAgICAgLy8gSW50ZW50aW9uYWxseSBub3QgYXBwbHlpbmcgdGhlIHN0b3JhZ2Ugd2hlbiB0aGUga2V5IGlzIHRoZSBQS0NFIGNvZGVcbiAgICAgICAgLy8gdmVyaWZpZXIsIGFzIHVzdWFsbHkgcmlnaHQgYWZ0ZXIgaXQncyByZW1vdmVkIG90aGVyIGl0ZW1zIGFyZSBzZXQsXG4gICAgICAgIC8vIHNvIGFwcGxpY2F0aW9uIG9mIHRoZSBzdG9yYWdlIHdpbGwgYmUgaGFuZGxlZCBieSB0aGVcbiAgICAgICAgLy8gYG9uQXV0aFN0YXRlQ2hhbmdlYCBjYWxsYmFjayB0aGF0IGZvbGxvd3MgcmVtb3ZhbCAtLSB1c3VhbGx5IGFzIHBhcnRcbiAgICAgICAgLy8gb2YgdGhlIGBleGNoYW5nZUNvZGVGb3JTZXNzaW9uYCBjYWxsLlxuICAgICAgICBkZWxldGUgc2V0SXRlbXNba2V5XTtcbiAgICAgICAgcmVtb3ZlZEl0ZW1zW2tleV0gPSB0cnVlO1xuICAgICAgfSxcbiAgICB9LFxuICB9O1xufVxuXG4vKipcbiAqIFdoZW4gY3JlYXRlU2VydmVyQ2xpZW50IG5lZWRzIHRvIGFwcGx5IHRoZSBjcmVhdGVkIHN0b3JhZ2UgdG8gY29va2llcywgaXRcbiAqIHNob3VsZCBjYWxsIHRoaXMgZnVuY3Rpb24gd2hpY2ggaGFuZGxlcyBjb3JyZWNseSBzZXR0aW5nIGNvb2tpZXMgZm9yIHN0b3JlZFxuICogYW5kIHJlbW92ZWQgaXRlbXMgaW4gdGhlIHN0b3JhZ2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBseVNlcnZlclN0b3JhZ2UoXG4gIHtcbiAgICBnZXRBbGwsXG4gICAgc2V0QWxsLFxuICAgIHNldEl0ZW1zLFxuICAgIHJlbW92ZWRJdGVtcyxcbiAgfToge1xuICAgIGdldEFsbDogKGtleUhpbnRzOiBzdHJpbmdbXSkgPT4gUmV0dXJuVHlwZTxHZXRBbGxDb29raWVzPjtcbiAgICBzZXRBbGw6IFNldEFsbENvb2tpZXM7XG4gICAgc2V0SXRlbXM6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9O1xuICAgIHJlbW92ZWRJdGVtczogeyBbbmFtZTogc3RyaW5nXTogYm9vbGVhbiB9O1xuICB9LFxuICBvcHRpb25zOiB7XG4gICAgY29va2llRW5jb2Rpbmc6IFwicmF3XCIgfCBcImJhc2U2NHVybFwiO1xuICAgIGNvb2tpZU9wdGlvbnM/OiBDb29raWVPcHRpb25zIHwgbnVsbDtcbiAgfSxcbikge1xuICBjb25zdCBjb29raWVFbmNvZGluZyA9IG9wdGlvbnMuY29va2llRW5jb2Rpbmc7XG4gIGNvbnN0IGNvb2tpZU9wdGlvbnMgPSBvcHRpb25zLmNvb2tpZU9wdGlvbnMgPz8gbnVsbDtcblxuICBjb25zdCBhbGxDb29raWVzID0gYXdhaXQgZ2V0QWxsKFtcbiAgICAuLi4oc2V0SXRlbXMgPyAoT2JqZWN0LmtleXMoc2V0SXRlbXMpIGFzIHN0cmluZ1tdKSA6IFtdKSxcbiAgICAuLi4ocmVtb3ZlZEl0ZW1zID8gKE9iamVjdC5rZXlzKHJlbW92ZWRJdGVtcykgYXMgc3RyaW5nW10pIDogW10pLFxuICBdKTtcbiAgY29uc3QgY29va2llTmFtZXMgPSBhbGxDb29raWVzPy5tYXAoKHsgbmFtZSB9KSA9PiBuYW1lKSB8fCBbXTtcblxuICBjb25zdCByZW1vdmVDb29raWVzOiBzdHJpbmdbXSA9IE9iamVjdC5rZXlzKHJlbW92ZWRJdGVtcykuZmxhdE1hcChcbiAgICAoaXRlbU5hbWUpID0+IHtcbiAgICAgIHJldHVybiBjb29raWVOYW1lcy5maWx0ZXIoKG5hbWUpID0+IGlzQ2h1bmtMaWtlKG5hbWUsIGl0ZW1OYW1lKSk7XG4gICAgfSxcbiAgKTtcblxuICBjb25zdCBzZXRDb29raWVzID0gT2JqZWN0LmtleXMoc2V0SXRlbXMpLmZsYXRNYXAoKGl0ZW1OYW1lKSA9PiB7XG4gICAgY29uc3QgcmVtb3ZlRXhpc3RpbmdDb29raWVzRm9ySXRlbSA9IG5ldyBTZXQoXG4gICAgICBjb29raWVOYW1lcy5maWx0ZXIoKG5hbWUpID0+IGlzQ2h1bmtMaWtlKG5hbWUsIGl0ZW1OYW1lKSksXG4gICAgKTtcblxuICAgIGxldCBlbmNvZGVkID0gc2V0SXRlbXNbaXRlbU5hbWVdO1xuXG4gICAgaWYgKGNvb2tpZUVuY29kaW5nID09PSBcImJhc2U2NHVybFwiKSB7XG4gICAgICBlbmNvZGVkID0gQkFTRTY0X1BSRUZJWCArIHN0cmluZ1RvQmFzZTY0VVJMKGVuY29kZWQpO1xuICAgIH1cblxuICAgIGNvbnN0IGNodW5rcyA9IGNyZWF0ZUNodW5rcyhpdGVtTmFtZSwgZW5jb2RlZCk7XG5cbiAgICBjaHVua3MuZm9yRWFjaCgoY2h1bmspID0+IHtcbiAgICAgIHJlbW92ZUV4aXN0aW5nQ29va2llc0Zvckl0ZW0uZGVsZXRlKGNodW5rLm5hbWUpO1xuICAgIH0pO1xuXG4gICAgcmVtb3ZlQ29va2llcy5wdXNoKC4uLnJlbW92ZUV4aXN0aW5nQ29va2llc0Zvckl0ZW0pO1xuXG4gICAgcmV0dXJuIGNodW5rcztcbiAgfSk7XG5cbiAgY29uc3QgcmVtb3ZlQ29va2llT3B0aW9ucyA9IHtcbiAgICAuLi5ERUZBVUxUX0NPT0tJRV9PUFRJT05TLFxuICAgIC4uLmNvb2tpZU9wdGlvbnMsXG4gICAgbWF4QWdlOiAwLFxuICB9O1xuICBjb25zdCBzZXRDb29raWVPcHRpb25zID0ge1xuICAgIC4uLkRFRkFVTFRfQ09PS0lFX09QVElPTlMsXG4gICAgLi4uY29va2llT3B0aW9ucyxcbiAgICBtYXhBZ2U6IERFRkFVTFRfQ09PS0lFX09QVElPTlMubWF4QWdlLFxuICB9O1xuXG4gIC8vIHRoZSBOZXh0SlMgY29va2llU3RvcmUgQVBJIGNhbiBnZXQgY29uZnVzZWQgaWYgdGhlIGBuYW1lYCBmcm9tXG4gIC8vIG9wdGlvbnMuY29va2llT3B0aW9ucyBsZWFrc1xuICBkZWxldGUgKHJlbW92ZUNvb2tpZU9wdGlvbnMgYXMgYW55KS5uYW1lO1xuICBkZWxldGUgKHNldENvb2tpZU9wdGlvbnMgYXMgYW55KS5uYW1lO1xuXG4gIGF3YWl0IHNldEFsbChcbiAgICBbXG4gICAgICAuLi5yZW1vdmVDb29raWVzLm1hcCgobmFtZSkgPT4gKHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdmFsdWU6IFwiXCIsXG4gICAgICAgIG9wdGlvbnM6IHJlbW92ZUNvb2tpZU9wdGlvbnMsXG4gICAgICB9KSksXG4gICAgICAuLi5zZXRDb29raWVzLm1hcCgoeyBuYW1lLCB2YWx1ZSB9KSA9PiAoe1xuICAgICAgICBuYW1lLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgb3B0aW9uczogc2V0Q29va2llT3B0aW9ucyxcbiAgICAgIH0pKSxcbiAgICBdLFxuICAgIHtcbiAgICAgIFwiQ2FjaGUtQ29udHJvbFwiOlxuICAgICAgICBcInByaXZhdGUsIG5vLWNhY2hlLCBuby1zdG9yZSwgbXVzdC1yZXZhbGlkYXRlLCBtYXgtYWdlPTBcIixcbiAgICAgIEV4cGlyZXM6IFwiMFwiLFxuICAgICAgUHJhZ21hOiBcIm5vLWNhY2hlXCIsXG4gICAgfSxcbiAgKTtcbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19