/* eslint-disable @typescript-eslint/ban-ts-comment */
import { isValidDomain } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/webauthn.js?v=583078ff";
/**
 * A custom Error used to return a more nuanced error detailing _why_ one of the eight documented
 * errors in the spec was raised after calling `navigator.credentials.create()` or
 * `navigator.credentials.get()`:
 *
 * - `AbortError`
 * - `ConstraintError`
 * - `InvalidStateError`
 * - `NotAllowedError`
 * - `NotSupportedError`
 * - `SecurityError`
 * - `TypeError`
 * - `UnknownError`
 *
 * Error messages were determined through investigation of the spec to determine under which
 * scenarios a given error would be raised.
 */
export class WebAuthnError extends Error {
    constructor({ message, code, cause, name, }) {
        var _a;
        // @ts-ignore: help Rollup understand that `cause` is okay to set
        super(message, { cause });
        this.__isWebAuthnError = true;
        this.name = (_a = name !== null && name !== void 0 ? name : (cause instanceof Error ? cause.name : undefined)) !== null && _a !== void 0 ? _a : 'Unknown Error';
        this.code = code;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            code: this.code,
        };
    }
}
/**
 * Error class for unknown WebAuthn errors.
 * Wraps unexpected errors that don't match known WebAuthn error conditions.
 */
export class WebAuthnUnknownError extends WebAuthnError {
    constructor(message, originalError) {
        super({
            code: 'ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY',
            cause: originalError,
            message,
        });
        this.name = 'WebAuthnUnknownError';
        this.originalError = originalError;
    }
}
/**
 * Type guard to check if an error is a WebAuthnError.
 * @param {unknown} error - The error to check
 * @returns {boolean} True if the error is a WebAuthnError
 */
export function isWebAuthnError(error) {
    return typeof error === 'object' && error !== null && '__isWebAuthnError' in error;
}
/**
 * Attempt to intuit _why_ an error was raised after calling `navigator.credentials.create()`.
 * Maps browser errors to specific WebAuthn error codes for better debugging.
 * @param {Object} params - Error identification parameters
 * @param {Error} params.error - The error thrown by the browser
 * @param {CredentialCreationOptions} params.options - The options passed to credentials.create()
 * @returns {WebAuthnError} A WebAuthnError with a specific error code
 * @see {@link https://w3c.github.io/webauthn/#sctn-createCredential W3C WebAuthn Spec - Create Credential}
 */
export function identifyRegistrationError({ error, options, }) {
    var _a, _b, _c;
    const { publicKey } = options;
    if (!publicKey) {
        throw Error('options was missing required publicKey property');
    }
    if (error.name === 'AbortError') {
        if (options.signal instanceof AbortSignal) {
            // https://www.w3.org/TR/webauthn-2/#sctn-createCredential (Step 16)
            return new WebAuthnError({
                message: 'Registration ceremony was sent an abort signal',
                code: 'ERROR_CEREMONY_ABORTED',
                cause: error,
            });
        }
    }
    else if (error.name === 'ConstraintError') {
        if (((_a = publicKey.authenticatorSelection) === null || _a === void 0 ? void 0 : _a.requireResidentKey) === true) {
            // https://www.w3.org/TR/webauthn-2/#sctn-op-make-cred (Step 4)
            return new WebAuthnError({
                message: 'Discoverable credentials were required but no available authenticator supported it',
                code: 'ERROR_AUTHENTICATOR_MISSING_DISCOVERABLE_CREDENTIAL_SUPPORT',
                cause: error,
            });
        }
        else if (
        // @ts-ignore: `mediation` doesn't yet exist on CredentialCreationOptions but it's possible as of Sept 2024
        options.mediation === 'conditional' &&
            ((_b = publicKey.authenticatorSelection) === null || _b === void 0 ? void 0 : _b.userVerification) === 'required') {
            // https://w3c.github.io/webauthn/#sctn-createCredential (Step 22.4)
            return new WebAuthnError({
                message: 'User verification was required during automatic registration but it could not be performed',
                code: 'ERROR_AUTO_REGISTER_USER_VERIFICATION_FAILURE',
                cause: error,
            });
        }
        else if (((_c = publicKey.authenticatorSelection) === null || _c === void 0 ? void 0 : _c.userVerification) === 'required') {
            // https://www.w3.org/TR/webauthn-2/#sctn-op-make-cred (Step 5)
            return new WebAuthnError({
                message: 'User verification was required but no available authenticator supported it',
                code: 'ERROR_AUTHENTICATOR_MISSING_USER_VERIFICATION_SUPPORT',
                cause: error,
            });
        }
    }
    else if (error.name === 'InvalidStateError') {
        // https://www.w3.org/TR/webauthn-2/#sctn-createCredential (Step 20)
        // https://www.w3.org/TR/webauthn-2/#sctn-op-make-cred (Step 3)
        return new WebAuthnError({
            message: 'The authenticator was previously registered',
            code: 'ERROR_AUTHENTICATOR_PREVIOUSLY_REGISTERED',
            cause: error,
        });
    }
    else if (error.name === 'NotAllowedError') {
        /**
         * Pass the error directly through. Platforms are overloading this error beyond what the spec
         * defines and we don't want to overwrite potentially useful error messages.
         */
        return new WebAuthnError({
            message: error.message,
            code: 'ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY',
            cause: error,
        });
    }
    else if (error.name === 'NotSupportedError') {
        const validPubKeyCredParams = publicKey.pubKeyCredParams.filter((param) => param.type === 'public-key');
        if (validPubKeyCredParams.length === 0) {
            // https://www.w3.org/TR/webauthn-2/#sctn-createCredential (Step 10)
            return new WebAuthnError({
                message: 'No entry in pubKeyCredParams was of type "public-key"',
                code: 'ERROR_MALFORMED_PUBKEYCREDPARAMS',
                cause: error,
            });
        }
        // https://www.w3.org/TR/webauthn-2/#sctn-op-make-cred (Step 2)
        return new WebAuthnError({
            message: 'No available authenticator supported any of the specified pubKeyCredParams algorithms',
            code: 'ERROR_AUTHENTICATOR_NO_SUPPORTED_PUBKEYCREDPARAMS_ALG',
            cause: error,
        });
    }
    else if (error.name === 'SecurityError') {
        const effectiveDomain = window.location.hostname;
        if (!isValidDomain(effectiveDomain)) {
            // https://www.w3.org/TR/webauthn-2/#sctn-createCredential (Step 7)
            return new WebAuthnError({
                message: `${window.location.hostname} is an invalid domain`,
                code: 'ERROR_INVALID_DOMAIN',
                cause: error,
            });
        }
        else if (publicKey.rp.id !== effectiveDomain) {
            // https://www.w3.org/TR/webauthn-2/#sctn-createCredential (Step 8)
            return new WebAuthnError({
                message: `The RP ID "${publicKey.rp.id}" is invalid for this domain`,
                code: 'ERROR_INVALID_RP_ID',
                cause: error,
            });
        }
    }
    else if (error.name === 'TypeError') {
        if (publicKey.user.id.byteLength < 1 || publicKey.user.id.byteLength > 64) {
            // https://www.w3.org/TR/webauthn-2/#sctn-createCredential (Step 5)
            return new WebAuthnError({
                message: 'User ID was not between 1 and 64 characters',
                code: 'ERROR_INVALID_USER_ID_LENGTH',
                cause: error,
            });
        }
    }
    else if (error.name === 'UnknownError') {
        // https://www.w3.org/TR/webauthn-2/#sctn-op-make-cred (Step 1)
        // https://www.w3.org/TR/webauthn-2/#sctn-op-make-cred (Step 8)
        return new WebAuthnError({
            message: 'The authenticator was unable to process the specified options, or could not create a new credential',
            code: 'ERROR_AUTHENTICATOR_GENERAL_ERROR',
            cause: error,
        });
    }
    return new WebAuthnError({
        message: 'a Non-Webauthn related error has occurred',
        code: 'ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY',
        cause: error,
    });
}
/**
 * Attempt to intuit _why_ an error was raised after calling `navigator.credentials.get()`.
 * Maps browser errors to specific WebAuthn error codes for better debugging.
 * @param {Object} params - Error identification parameters
 * @param {Error} params.error - The error thrown by the browser
 * @param {CredentialRequestOptions} params.options - The options passed to credentials.get()
 * @returns {WebAuthnError} A WebAuthnError with a specific error code
 * @see {@link https://w3c.github.io/webauthn/#sctn-getAssertion W3C WebAuthn Spec - Get Assertion}
 */
export function identifyAuthenticationError({ error, options, }) {
    const { publicKey } = options;
    if (!publicKey) {
        throw Error('options was missing required publicKey property');
    }
    if (error.name === 'AbortError') {
        if (options.signal instanceof AbortSignal) {
            // https://www.w3.org/TR/webauthn-2/#sctn-createCredential (Step 16)
            return new WebAuthnError({
                message: 'Authentication ceremony was sent an abort signal',
                code: 'ERROR_CEREMONY_ABORTED',
                cause: error,
            });
        }
    }
    else if (error.name === 'NotAllowedError') {
        /**
         * Pass the error directly through. Platforms are overloading this error beyond what the spec
         * defines and we don't want to overwrite potentially useful error messages.
         */
        return new WebAuthnError({
            message: error.message,
            code: 'ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY',
            cause: error,
        });
    }
    else if (error.name === 'SecurityError') {
        const effectiveDomain = window.location.hostname;
        if (!isValidDomain(effectiveDomain)) {
            // https://www.w3.org/TR/webauthn-2/#sctn-discover-from-external-source (Step 5)
            return new WebAuthnError({
                message: `${window.location.hostname} is an invalid domain`,
                code: 'ERROR_INVALID_DOMAIN',
                cause: error,
            });
        }
        else if (publicKey.rpId !== effectiveDomain) {
            // https://www.w3.org/TR/webauthn-2/#sctn-discover-from-external-source (Step 6)
            return new WebAuthnError({
                message: `The RP ID "${publicKey.rpId}" is invalid for this domain`,
                code: 'ERROR_INVALID_RP_ID',
                cause: error,
            });
        }
    }
    else if (error.name === 'UnknownError') {
        // https://www.w3.org/TR/webauthn-2/#sctn-op-get-assertion (Step 1)
        // https://www.w3.org/TR/webauthn-2/#sctn-op-get-assertion (Step 12)
        return new WebAuthnError({
            message: 'The authenticator was unable to process the specified options, or could not create a new assertion signature',
            code: 'ERROR_AUTHENTICATOR_GENERAL_ERROR',
            cause: error,
        });
    }
    return new WebAuthnError({
        message: 'a Non-Webauthn related error has occurred',
        code: 'ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY',
        cause: error,
    });
}
                                           
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2ViYXV0aG4uZXJyb3JzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2xpYi93ZWJhdXRobi5lcnJvcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsc0RBQXNEO0FBR3RELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxZQUFZLENBQUE7QUFNMUM7Ozs7Ozs7Ozs7Ozs7Ozs7R0FnQkc7QUFDSCxNQUFNLE9BQU8sYUFBYyxTQUFRLEtBQUs7SUFLdEMsWUFBWSxFQUNWLE9BQU8sRUFDUCxJQUFJLEVBQ0osS0FBSyxFQUNMLElBQUksR0FNTDs7UUFDQyxpRUFBaUU7UUFDakUsS0FBSyxDQUFDLE9BQU8sRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7UUFkakIsc0JBQWlCLEdBQUcsSUFBSSxDQUFBO1FBZWhDLElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBQSxJQUFJLGFBQUosSUFBSSxjQUFKLElBQUksR0FBSSxDQUFDLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxtQ0FBSSxlQUFlLENBQUE7UUFDeEYsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7SUFDbEIsQ0FBQztJQUVELE1BQU07UUFLSixPQUFPO1lBQ0wsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQ2YsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO1lBQ3JCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtTQUNoQixDQUFBO0lBQ0gsQ0FBQztDQUNGO0FBRUQ7OztHQUdHO0FBQ0gsTUFBTSxPQUFPLG9CQUFxQixTQUFRLGFBQWE7SUFHckQsWUFBWSxPQUFlLEVBQUUsYUFBc0I7UUFDakQsS0FBSyxDQUFDO1lBQ0osSUFBSSxFQUFFLHNDQUFzQztZQUM1QyxLQUFLLEVBQUUsYUFBYTtZQUNwQixPQUFPO1NBQ1IsQ0FBQyxDQUFBO1FBQ0YsSUFBSSxDQUFDLElBQUksR0FBRyxzQkFBc0IsQ0FBQTtRQUNsQyxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQTtJQUNwQyxDQUFDO0NBQ0Y7QUFFRDs7OztHQUlHO0FBQ0gsTUFBTSxVQUFVLGVBQWUsQ0FBQyxLQUFjO0lBQzVDLE9BQU8sT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksbUJBQW1CLElBQUksS0FBSyxDQUFBO0FBQ3BGLENBQUM7QUFxQkQ7Ozs7Ozs7O0dBUUc7QUFDSCxNQUFNLFVBQVUseUJBQXlCLENBQUMsRUFDeEMsS0FBSyxFQUNMLE9BQU8sR0FNUjs7SUFDQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEdBQUcsT0FBTyxDQUFBO0lBRTdCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNmLE1BQU0sS0FBSyxDQUFDLGlEQUFpRCxDQUFDLENBQUE7SUFDaEUsQ0FBQztJQUVELElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxZQUFZLEVBQUUsQ0FBQztRQUNoQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLFlBQVksV0FBVyxFQUFFLENBQUM7WUFDMUMsb0VBQW9FO1lBQ3BFLE9BQU8sSUFBSSxhQUFhLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxnREFBZ0Q7Z0JBQ3pELElBQUksRUFBRSx3QkFBd0I7Z0JBQzlCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFBO1FBQ0osQ0FBQztJQUNILENBQUM7U0FBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssaUJBQWlCLEVBQUUsQ0FBQztRQUM1QyxJQUFJLENBQUEsTUFBQSxTQUFTLENBQUMsc0JBQXNCLDBDQUFFLGtCQUFrQixNQUFLLElBQUksRUFBRSxDQUFDO1lBQ2xFLCtEQUErRDtZQUMvRCxPQUFPLElBQUksYUFBYSxDQUFDO2dCQUN2QixPQUFPLEVBQ0wsb0ZBQW9GO2dCQUN0RixJQUFJLEVBQUUsNkRBQTZEO2dCQUNuRSxLQUFLLEVBQUUsS0FBSzthQUNiLENBQUMsQ0FBQTtRQUNKLENBQUM7YUFBTTtRQUNMLDJHQUEyRztRQUMzRyxPQUFPLENBQUMsU0FBUyxLQUFLLGFBQWE7WUFDbkMsQ0FBQSxNQUFBLFNBQVMsQ0FBQyxzQkFBc0IsMENBQUUsZ0JBQWdCLE1BQUssVUFBVSxFQUNqRSxDQUFDO1lBQ0Qsb0VBQW9FO1lBQ3BFLE9BQU8sSUFBSSxhQUFhLENBQUM7Z0JBQ3ZCLE9BQU8sRUFDTCw0RkFBNEY7Z0JBQzlGLElBQUksRUFBRSwrQ0FBK0M7Z0JBQ3JELEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFBO1FBQ0osQ0FBQzthQUFNLElBQUksQ0FBQSxNQUFBLFNBQVMsQ0FBQyxzQkFBc0IsMENBQUUsZ0JBQWdCLE1BQUssVUFBVSxFQUFFLENBQUM7WUFDN0UsK0RBQStEO1lBQy9ELE9BQU8sSUFBSSxhQUFhLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSw0RUFBNEU7Z0JBQ3JGLElBQUksRUFBRSx1REFBdUQ7Z0JBQzdELEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFBO1FBQ0osQ0FBQztJQUNILENBQUM7U0FBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssbUJBQW1CLEVBQUUsQ0FBQztRQUM5QyxvRUFBb0U7UUFDcEUsK0RBQStEO1FBQy9ELE9BQU8sSUFBSSxhQUFhLENBQUM7WUFDdkIsT0FBTyxFQUFFLDZDQUE2QztZQUN0RCxJQUFJLEVBQUUsMkNBQTJDO1lBQ2pELEtBQUssRUFBRSxLQUFLO1NBQ2IsQ0FBQyxDQUFBO0lBQ0osQ0FBQztTQUFNLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxpQkFBaUIsRUFBRSxDQUFDO1FBQzVDOzs7V0FHRztRQUNILE9BQU8sSUFBSSxhQUFhLENBQUM7WUFDdkIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1lBQ3RCLElBQUksRUFBRSxzQ0FBc0M7WUFDNUMsS0FBSyxFQUFFLEtBQUs7U0FDYixDQUFDLENBQUE7SUFDSixDQUFDO1NBQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLG1CQUFtQixFQUFFLENBQUM7UUFDOUMsTUFBTSxxQkFBcUIsR0FBRyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUM3RCxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxZQUFZLENBQ3ZDLENBQUE7UUFFRCxJQUFJLHFCQUFxQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN2QyxvRUFBb0U7WUFDcEUsT0FBTyxJQUFJLGFBQWEsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLHVEQUF1RDtnQkFDaEUsSUFBSSxFQUFFLGtDQUFrQztnQkFDeEMsS0FBSyxFQUFFLEtBQUs7YUFDYixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsK0RBQStEO1FBQy9ELE9BQU8sSUFBSSxhQUFhLENBQUM7WUFDdkIsT0FBTyxFQUNMLHVGQUF1RjtZQUN6RixJQUFJLEVBQUUsdURBQXVEO1lBQzdELEtBQUssRUFBRSxLQUFLO1NBQ2IsQ0FBQyxDQUFBO0lBQ0osQ0FBQztTQUFNLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxlQUFlLEVBQUUsQ0FBQztRQUMxQyxNQUFNLGVBQWUsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQTtRQUNoRCxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUM7WUFDcEMsbUVBQW1FO1lBQ25FLE9BQU8sSUFBSSxhQUFhLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSx1QkFBdUI7Z0JBQzNELElBQUksRUFBRSxzQkFBc0I7Z0JBQzVCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFBO1FBQ0osQ0FBQzthQUFNLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssZUFBZSxFQUFFLENBQUM7WUFDL0MsbUVBQW1FO1lBQ25FLE9BQU8sSUFBSSxhQUFhLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxjQUFjLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSw4QkFBOEI7Z0JBQ3BFLElBQUksRUFBRSxxQkFBcUI7Z0JBQzNCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFBO1FBQ0osQ0FBQztJQUNILENBQUM7U0FBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFLENBQUM7UUFDdEMsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsR0FBRyxFQUFFLEVBQUUsQ0FBQztZQUMxRSxtRUFBbUU7WUFDbkUsT0FBTyxJQUFJLGFBQWEsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLDZDQUE2QztnQkFDdEQsSUFBSSxFQUFFLDhCQUE4QjtnQkFDcEMsS0FBSyxFQUFFLEtBQUs7YUFDYixDQUFDLENBQUE7UUFDSixDQUFDO0lBQ0gsQ0FBQztTQUFNLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxjQUFjLEVBQUUsQ0FBQztRQUN6QywrREFBK0Q7UUFDL0QsK0RBQStEO1FBQy9ELE9BQU8sSUFBSSxhQUFhLENBQUM7WUFDdkIsT0FBTyxFQUNMLHFHQUFxRztZQUN2RyxJQUFJLEVBQUUsbUNBQW1DO1lBQ3pDLEtBQUssRUFBRSxLQUFLO1NBQ2IsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELE9BQU8sSUFBSSxhQUFhLENBQUM7UUFDdkIsT0FBTyxFQUFFLDJDQUEyQztRQUNwRCxJQUFJLEVBQUUsc0NBQXNDO1FBQzVDLEtBQUssRUFBRSxLQUFLO0tBQ2IsQ0FBQyxDQUFBO0FBQ0osQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxVQUFVLDJCQUEyQixDQUFDLEVBQzFDLEtBQUssRUFDTCxPQUFPLEdBTVI7SUFDQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEdBQUcsT0FBTyxDQUFBO0lBRTdCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNmLE1BQU0sS0FBSyxDQUFDLGlEQUFpRCxDQUFDLENBQUE7SUFDaEUsQ0FBQztJQUVELElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxZQUFZLEVBQUUsQ0FBQztRQUNoQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLFlBQVksV0FBVyxFQUFFLENBQUM7WUFDMUMsb0VBQW9FO1lBQ3BFLE9BQU8sSUFBSSxhQUFhLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxrREFBa0Q7Z0JBQzNELElBQUksRUFBRSx3QkFBd0I7Z0JBQzlCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFBO1FBQ0osQ0FBQztJQUNILENBQUM7U0FBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssaUJBQWlCLEVBQUUsQ0FBQztRQUM1Qzs7O1dBR0c7UUFDSCxPQUFPLElBQUksYUFBYSxDQUFDO1lBQ3ZCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztZQUN0QixJQUFJLEVBQUUsc0NBQXNDO1lBQzVDLEtBQUssRUFBRSxLQUFLO1NBQ2IsQ0FBQyxDQUFBO0lBQ0osQ0FBQztTQUFNLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxlQUFlLEVBQUUsQ0FBQztRQUMxQyxNQUFNLGVBQWUsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQTtRQUNoRCxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUM7WUFDcEMsZ0ZBQWdGO1lBQ2hGLE9BQU8sSUFBSSxhQUFhLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSx1QkFBdUI7Z0JBQzNELElBQUksRUFBRSxzQkFBc0I7Z0JBQzVCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFBO1FBQ0osQ0FBQzthQUFNLElBQUksU0FBUyxDQUFDLElBQUksS0FBSyxlQUFlLEVBQUUsQ0FBQztZQUM5QyxnRkFBZ0Y7WUFDaEYsT0FBTyxJQUFJLGFBQWEsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLGNBQWMsU0FBUyxDQUFDLElBQUksOEJBQThCO2dCQUNuRSxJQUFJLEVBQUUscUJBQXFCO2dCQUMzQixLQUFLLEVBQUUsS0FBSzthQUNiLENBQUMsQ0FBQTtRQUNKLENBQUM7SUFDSCxDQUFDO1NBQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLGNBQWMsRUFBRSxDQUFDO1FBQ3pDLG1FQUFtRTtRQUNuRSxvRUFBb0U7UUFDcEUsT0FBTyxJQUFJLGFBQWEsQ0FBQztZQUN2QixPQUFPLEVBQ0wsOEdBQThHO1lBQ2hILElBQUksRUFBRSxtQ0FBbUM7WUFDekMsS0FBSyxFQUFFLEtBQUs7U0FDYixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsT0FBTyxJQUFJLGFBQWEsQ0FBQztRQUN2QixPQUFPLEVBQUUsMkNBQTJDO1FBQ3BELElBQUksRUFBRSxzQ0FBc0M7UUFDNUMsS0FBSyxFQUFFLEtBQUs7S0FDYixDQUFDLENBQUE7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50ICovXG5cbmltcG9ydCB7IFN0cmljdE9taXQgfSBmcm9tICcuL3R5cGVzJ1xuaW1wb3J0IHsgaXNWYWxpZERvbWFpbiB9IGZyb20gJy4vd2ViYXV0aG4nXG5pbXBvcnQge1xuICBQdWJsaWNLZXlDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zRnV0dXJlLFxuICBQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmUsXG59IGZyb20gJy4vd2ViYXV0aG4uZG9tJ1xuXG4vKipcbiAqIEEgY3VzdG9tIEVycm9yIHVzZWQgdG8gcmV0dXJuIGEgbW9yZSBudWFuY2VkIGVycm9yIGRldGFpbGluZyBfd2h5XyBvbmUgb2YgdGhlIGVpZ2h0IGRvY3VtZW50ZWRcbiAqIGVycm9ycyBpbiB0aGUgc3BlYyB3YXMgcmFpc2VkIGFmdGVyIGNhbGxpbmcgYG5hdmlnYXRvci5jcmVkZW50aWFscy5jcmVhdGUoKWAgb3JcbiAqIGBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuZ2V0KClgOlxuICpcbiAqIC0gYEFib3J0RXJyb3JgXG4gKiAtIGBDb25zdHJhaW50RXJyb3JgXG4gKiAtIGBJbnZhbGlkU3RhdGVFcnJvcmBcbiAqIC0gYE5vdEFsbG93ZWRFcnJvcmBcbiAqIC0gYE5vdFN1cHBvcnRlZEVycm9yYFxuICogLSBgU2VjdXJpdHlFcnJvcmBcbiAqIC0gYFR5cGVFcnJvcmBcbiAqIC0gYFVua25vd25FcnJvcmBcbiAqXG4gKiBFcnJvciBtZXNzYWdlcyB3ZXJlIGRldGVybWluZWQgdGhyb3VnaCBpbnZlc3RpZ2F0aW9uIG9mIHRoZSBzcGVjIHRvIGRldGVybWluZSB1bmRlciB3aGljaFxuICogc2NlbmFyaW9zIGEgZ2l2ZW4gZXJyb3Igd291bGQgYmUgcmFpc2VkLlxuICovXG5leHBvcnQgY2xhc3MgV2ViQXV0aG5FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29kZTogV2ViQXV0aG5FcnJvckNvZGVcblxuICBwcm90ZWN0ZWQgX19pc1dlYkF1dGhuRXJyb3IgPSB0cnVlXG5cbiAgY29uc3RydWN0b3Ioe1xuICAgIG1lc3NhZ2UsXG4gICAgY29kZSxcbiAgICBjYXVzZSxcbiAgICBuYW1lLFxuICB9OiB7XG4gICAgbWVzc2FnZTogc3RyaW5nXG4gICAgY29kZTogV2ViQXV0aG5FcnJvckNvZGVcbiAgICBjYXVzZT86IEVycm9yIHwgdW5rbm93blxuICAgIG5hbWU/OiBzdHJpbmdcbiAgfSkge1xuICAgIC8vIEB0cy1pZ25vcmU6IGhlbHAgUm9sbHVwIHVuZGVyc3RhbmQgdGhhdCBgY2F1c2VgIGlzIG9rYXkgdG8gc2V0XG4gICAgc3VwZXIobWVzc2FnZSwgeyBjYXVzZSB9KVxuICAgIHRoaXMubmFtZSA9IG5hbWUgPz8gKGNhdXNlIGluc3RhbmNlb2YgRXJyb3IgPyBjYXVzZS5uYW1lIDogdW5kZWZpbmVkKSA/PyAnVW5rbm93biBFcnJvcidcbiAgICB0aGlzLmNvZGUgPSBjb2RlXG4gIH1cblxuICB0b0pTT04oKToge1xuICAgIG5hbWU6IHN0cmluZ1xuICAgIG1lc3NhZ2U6IHN0cmluZ1xuICAgIGNvZGU6IFdlYkF1dGhuRXJyb3JDb2RlXG4gIH0ge1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBtZXNzYWdlOiB0aGlzLm1lc3NhZ2UsXG4gICAgICBjb2RlOiB0aGlzLmNvZGUsXG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogRXJyb3IgY2xhc3MgZm9yIHVua25vd24gV2ViQXV0aG4gZXJyb3JzLlxuICogV3JhcHMgdW5leHBlY3RlZCBlcnJvcnMgdGhhdCBkb24ndCBtYXRjaCBrbm93biBXZWJBdXRobiBlcnJvciBjb25kaXRpb25zLlxuICovXG5leHBvcnQgY2xhc3MgV2ViQXV0aG5Vbmtub3duRXJyb3IgZXh0ZW5kcyBXZWJBdXRobkVycm9yIHtcbiAgb3JpZ2luYWxFcnJvcjogdW5rbm93blxuXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZywgb3JpZ2luYWxFcnJvcjogdW5rbm93bikge1xuICAgIHN1cGVyKHtcbiAgICAgIGNvZGU6ICdFUlJPUl9QQVNTVEhST1VHSF9TRUVfQ0FVU0VfUFJPUEVSVFknLFxuICAgICAgY2F1c2U6IG9yaWdpbmFsRXJyb3IsXG4gICAgICBtZXNzYWdlLFxuICAgIH0pXG4gICAgdGhpcy5uYW1lID0gJ1dlYkF1dGhuVW5rbm93bkVycm9yJ1xuICAgIHRoaXMub3JpZ2luYWxFcnJvciA9IG9yaWdpbmFsRXJyb3JcbiAgfVxufVxuXG4vKipcbiAqIFR5cGUgZ3VhcmQgdG8gY2hlY2sgaWYgYW4gZXJyb3IgaXMgYSBXZWJBdXRobkVycm9yLlxuICogQHBhcmFtIHt1bmtub3dufSBlcnJvciAtIFRoZSBlcnJvciB0byBjaGVja1xuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIGVycm9yIGlzIGEgV2ViQXV0aG5FcnJvclxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNXZWJBdXRobkVycm9yKGVycm9yOiB1bmtub3duKTogZXJyb3IgaXMgV2ViQXV0aG5FcnJvciB7XG4gIHJldHVybiB0eXBlb2YgZXJyb3IgPT09ICdvYmplY3QnICYmIGVycm9yICE9PSBudWxsICYmICdfX2lzV2ViQXV0aG5FcnJvcicgaW4gZXJyb3Jcbn1cblxuLyoqXG4gKiBFcnJvciBjb2RlcyBmb3IgV2ViQXV0aG4gb3BlcmF0aW9ucy5cbiAqIFRoZXNlIGNvZGVzIHByb3ZpZGUgc3BlY2lmaWMgaW5mb3JtYXRpb24gYWJvdXQgd2h5IGEgV2ViQXV0aG4gY2VyZW1vbnkgZmFpbGVkLlxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3dlYmF1dGhuLyNzY3RuLWRlZmluZWQtZXJyb3JzIFczQyBXZWJBdXRobiBTcGVjIC0gRGVmaW5lZCBFcnJvcnN9XG4gKi9cbmV4cG9ydCB0eXBlIFdlYkF1dGhuRXJyb3JDb2RlID1cbiAgfCAnRVJST1JfQ0VSRU1PTllfQUJPUlRFRCdcbiAgfCAnRVJST1JfSU5WQUxJRF9ET01BSU4nXG4gIHwgJ0VSUk9SX0lOVkFMSURfUlBfSUQnXG4gIHwgJ0VSUk9SX0lOVkFMSURfVVNFUl9JRF9MRU5HVEgnXG4gIHwgJ0VSUk9SX01BTEZPUk1FRF9QVUJLRVlDUkVEUEFSQU1TJ1xuICB8ICdFUlJPUl9BVVRIRU5USUNBVE9SX0dFTkVSQUxfRVJST1InXG4gIHwgJ0VSUk9SX0FVVEhFTlRJQ0FUT1JfTUlTU0lOR19ESVNDT1ZFUkFCTEVfQ1JFREVOVElBTF9TVVBQT1JUJ1xuICB8ICdFUlJPUl9BVVRIRU5USUNBVE9SX01JU1NJTkdfVVNFUl9WRVJJRklDQVRJT05fU1VQUE9SVCdcbiAgfCAnRVJST1JfQVVUSEVOVElDQVRPUl9QUkVWSU9VU0xZX1JFR0lTVEVSRUQnXG4gIHwgJ0VSUk9SX0FVVEhFTlRJQ0FUT1JfTk9fU1VQUE9SVEVEX1BVQktFWUNSRURQQVJBTVNfQUxHJ1xuICB8ICdFUlJPUl9BVVRPX1JFR0lTVEVSX1VTRVJfVkVSSUZJQ0FUSU9OX0ZBSUxVUkUnXG4gIHwgJ0VSUk9SX1BBU1NUSFJPVUdIX1NFRV9DQVVTRV9QUk9QRVJUWSdcblxuLyoqXG4gKiBBdHRlbXB0IHRvIGludHVpdCBfd2h5XyBhbiBlcnJvciB3YXMgcmFpc2VkIGFmdGVyIGNhbGxpbmcgYG5hdmlnYXRvci5jcmVkZW50aWFscy5jcmVhdGUoKWAuXG4gKiBNYXBzIGJyb3dzZXIgZXJyb3JzIHRvIHNwZWNpZmljIFdlYkF1dGhuIGVycm9yIGNvZGVzIGZvciBiZXR0ZXIgZGVidWdnaW5nLlxuICogQHBhcmFtIHtPYmplY3R9IHBhcmFtcyAtIEVycm9yIGlkZW50aWZpY2F0aW9uIHBhcmFtZXRlcnNcbiAqIEBwYXJhbSB7RXJyb3J9IHBhcmFtcy5lcnJvciAtIFRoZSBlcnJvciB0aHJvd24gYnkgdGhlIGJyb3dzZXJcbiAqIEBwYXJhbSB7Q3JlZGVudGlhbENyZWF0aW9uT3B0aW9uc30gcGFyYW1zLm9wdGlvbnMgLSBUaGUgb3B0aW9ucyBwYXNzZWQgdG8gY3JlZGVudGlhbHMuY3JlYXRlKClcbiAqIEByZXR1cm5zIHtXZWJBdXRobkVycm9yfSBBIFdlYkF1dGhuRXJyb3Igd2l0aCBhIHNwZWNpZmljIGVycm9yIGNvZGVcbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jc2N0bi1jcmVhdGVDcmVkZW50aWFsIFczQyBXZWJBdXRobiBTcGVjIC0gQ3JlYXRlIENyZWRlbnRpYWx9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpZGVudGlmeVJlZ2lzdHJhdGlvbkVycm9yKHtcbiAgZXJyb3IsXG4gIG9wdGlvbnMsXG59OiB7XG4gIGVycm9yOiBFcnJvclxuICBvcHRpb25zOiBTdHJpY3RPbWl0PENyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnMsICdwdWJsaWNLZXknPiAmIHtcbiAgICBwdWJsaWNLZXk6IFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmVcbiAgfVxufSk6IFdlYkF1dGhuRXJyb3Ige1xuICBjb25zdCB7IHB1YmxpY0tleSB9ID0gb3B0aW9uc1xuXG4gIGlmICghcHVibGljS2V5KSB7XG4gICAgdGhyb3cgRXJyb3IoJ29wdGlvbnMgd2FzIG1pc3NpbmcgcmVxdWlyZWQgcHVibGljS2V5IHByb3BlcnR5JylcbiAgfVxuXG4gIGlmIChlcnJvci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICBpZiAob3B0aW9ucy5zaWduYWwgaW5zdGFuY2VvZiBBYm9ydFNpZ25hbCkge1xuICAgICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tY3JlYXRlQ3JlZGVudGlhbCAoU3RlcCAxNilcbiAgICAgIHJldHVybiBuZXcgV2ViQXV0aG5FcnJvcih7XG4gICAgICAgIG1lc3NhZ2U6ICdSZWdpc3RyYXRpb24gY2VyZW1vbnkgd2FzIHNlbnQgYW4gYWJvcnQgc2lnbmFsJyxcbiAgICAgICAgY29kZTogJ0VSUk9SX0NFUkVNT05ZX0FCT1JURUQnLFxuICAgICAgICBjYXVzZTogZXJyb3IsXG4gICAgICB9KVxuICAgIH1cbiAgfSBlbHNlIGlmIChlcnJvci5uYW1lID09PSAnQ29uc3RyYWludEVycm9yJykge1xuICAgIGlmIChwdWJsaWNLZXkuYXV0aGVudGljYXRvclNlbGVjdGlvbj8ucmVxdWlyZVJlc2lkZW50S2V5ID09PSB0cnVlKSB7XG4gICAgICAvLyBodHRwczovL3d3dy53My5vcmcvVFIvd2ViYXV0aG4tMi8jc2N0bi1vcC1tYWtlLWNyZWQgKFN0ZXAgNClcbiAgICAgIHJldHVybiBuZXcgV2ViQXV0aG5FcnJvcih7XG4gICAgICAgIG1lc3NhZ2U6XG4gICAgICAgICAgJ0Rpc2NvdmVyYWJsZSBjcmVkZW50aWFscyB3ZXJlIHJlcXVpcmVkIGJ1dCBubyBhdmFpbGFibGUgYXV0aGVudGljYXRvciBzdXBwb3J0ZWQgaXQnLFxuICAgICAgICBjb2RlOiAnRVJST1JfQVVUSEVOVElDQVRPUl9NSVNTSU5HX0RJU0NPVkVSQUJMRV9DUkVERU5USUFMX1NVUFBPUlQnLFxuICAgICAgICBjYXVzZTogZXJyb3IsXG4gICAgICB9KVxuICAgIH0gZWxzZSBpZiAoXG4gICAgICAvLyBAdHMtaWdub3JlOiBgbWVkaWF0aW9uYCBkb2Vzbid0IHlldCBleGlzdCBvbiBDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zIGJ1dCBpdCdzIHBvc3NpYmxlIGFzIG9mIFNlcHQgMjAyNFxuICAgICAgb3B0aW9ucy5tZWRpYXRpb24gPT09ICdjb25kaXRpb25hbCcgJiZcbiAgICAgIHB1YmxpY0tleS5hdXRoZW50aWNhdG9yU2VsZWN0aW9uPy51c2VyVmVyaWZpY2F0aW9uID09PSAncmVxdWlyZWQnXG4gICAgKSB7XG4gICAgICAvLyBodHRwczovL3czYy5naXRodWIuaW8vd2ViYXV0aG4vI3NjdG4tY3JlYXRlQ3JlZGVudGlhbCAoU3RlcCAyMi40KVxuICAgICAgcmV0dXJuIG5ldyBXZWJBdXRobkVycm9yKHtcbiAgICAgICAgbWVzc2FnZTpcbiAgICAgICAgICAnVXNlciB2ZXJpZmljYXRpb24gd2FzIHJlcXVpcmVkIGR1cmluZyBhdXRvbWF0aWMgcmVnaXN0cmF0aW9uIGJ1dCBpdCBjb3VsZCBub3QgYmUgcGVyZm9ybWVkJyxcbiAgICAgICAgY29kZTogJ0VSUk9SX0FVVE9fUkVHSVNURVJfVVNFUl9WRVJJRklDQVRJT05fRkFJTFVSRScsXG4gICAgICAgIGNhdXNlOiBlcnJvcixcbiAgICAgIH0pXG4gICAgfSBlbHNlIGlmIChwdWJsaWNLZXkuYXV0aGVudGljYXRvclNlbGVjdGlvbj8udXNlclZlcmlmaWNhdGlvbiA9PT0gJ3JlcXVpcmVkJykge1xuICAgICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tb3AtbWFrZS1jcmVkIChTdGVwIDUpXG4gICAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiAnVXNlciB2ZXJpZmljYXRpb24gd2FzIHJlcXVpcmVkIGJ1dCBubyBhdmFpbGFibGUgYXV0aGVudGljYXRvciBzdXBwb3J0ZWQgaXQnLFxuICAgICAgICBjb2RlOiAnRVJST1JfQVVUSEVOVElDQVRPUl9NSVNTSU5HX1VTRVJfVkVSSUZJQ0FUSU9OX1NVUFBPUlQnLFxuICAgICAgICBjYXVzZTogZXJyb3IsXG4gICAgICB9KVxuICAgIH1cbiAgfSBlbHNlIGlmIChlcnJvci5uYW1lID09PSAnSW52YWxpZFN0YXRlRXJyb3InKSB7XG4gICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tY3JlYXRlQ3JlZGVudGlhbCAoU3RlcCAyMClcbiAgICAvLyBodHRwczovL3d3dy53My5vcmcvVFIvd2ViYXV0aG4tMi8jc2N0bi1vcC1tYWtlLWNyZWQgKFN0ZXAgMylcbiAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgbWVzc2FnZTogJ1RoZSBhdXRoZW50aWNhdG9yIHdhcyBwcmV2aW91c2x5IHJlZ2lzdGVyZWQnLFxuICAgICAgY29kZTogJ0VSUk9SX0FVVEhFTlRJQ0FUT1JfUFJFVklPVVNMWV9SRUdJU1RFUkVEJyxcbiAgICAgIGNhdXNlOiBlcnJvcixcbiAgICB9KVxuICB9IGVsc2UgaWYgKGVycm9yLm5hbWUgPT09ICdOb3RBbGxvd2VkRXJyb3InKSB7XG4gICAgLyoqXG4gICAgICogUGFzcyB0aGUgZXJyb3IgZGlyZWN0bHkgdGhyb3VnaC4gUGxhdGZvcm1zIGFyZSBvdmVybG9hZGluZyB0aGlzIGVycm9yIGJleW9uZCB3aGF0IHRoZSBzcGVjXG4gICAgICogZGVmaW5lcyBhbmQgd2UgZG9uJ3Qgd2FudCB0byBvdmVyd3JpdGUgcG90ZW50aWFsbHkgdXNlZnVsIGVycm9yIG1lc3NhZ2VzLlxuICAgICAqL1xuICAgIHJldHVybiBuZXcgV2ViQXV0aG5FcnJvcih7XG4gICAgICBtZXNzYWdlOiBlcnJvci5tZXNzYWdlLFxuICAgICAgY29kZTogJ0VSUk9SX1BBU1NUSFJPVUdIX1NFRV9DQVVTRV9QUk9QRVJUWScsXG4gICAgICBjYXVzZTogZXJyb3IsXG4gICAgfSlcbiAgfSBlbHNlIGlmIChlcnJvci5uYW1lID09PSAnTm90U3VwcG9ydGVkRXJyb3InKSB7XG4gICAgY29uc3QgdmFsaWRQdWJLZXlDcmVkUGFyYW1zID0gcHVibGljS2V5LnB1YktleUNyZWRQYXJhbXMuZmlsdGVyKFxuICAgICAgKHBhcmFtKSA9PiBwYXJhbS50eXBlID09PSAncHVibGljLWtleSdcbiAgICApXG5cbiAgICBpZiAodmFsaWRQdWJLZXlDcmVkUGFyYW1zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tY3JlYXRlQ3JlZGVudGlhbCAoU3RlcCAxMClcbiAgICAgIHJldHVybiBuZXcgV2ViQXV0aG5FcnJvcih7XG4gICAgICAgIG1lc3NhZ2U6ICdObyBlbnRyeSBpbiBwdWJLZXlDcmVkUGFyYW1zIHdhcyBvZiB0eXBlIFwicHVibGljLWtleVwiJyxcbiAgICAgICAgY29kZTogJ0VSUk9SX01BTEZPUk1FRF9QVUJLRVlDUkVEUEFSQU1TJyxcbiAgICAgICAgY2F1c2U6IGVycm9yLFxuICAgICAgfSlcbiAgICB9XG5cbiAgICAvLyBodHRwczovL3d3dy53My5vcmcvVFIvd2ViYXV0aG4tMi8jc2N0bi1vcC1tYWtlLWNyZWQgKFN0ZXAgMilcbiAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgbWVzc2FnZTpcbiAgICAgICAgJ05vIGF2YWlsYWJsZSBhdXRoZW50aWNhdG9yIHN1cHBvcnRlZCBhbnkgb2YgdGhlIHNwZWNpZmllZCBwdWJLZXlDcmVkUGFyYW1zIGFsZ29yaXRobXMnLFxuICAgICAgY29kZTogJ0VSUk9SX0FVVEhFTlRJQ0FUT1JfTk9fU1VQUE9SVEVEX1BVQktFWUNSRURQQVJBTVNfQUxHJyxcbiAgICAgIGNhdXNlOiBlcnJvcixcbiAgICB9KVxuICB9IGVsc2UgaWYgKGVycm9yLm5hbWUgPT09ICdTZWN1cml0eUVycm9yJykge1xuICAgIGNvbnN0IGVmZmVjdGl2ZURvbWFpbiA9IHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZVxuICAgIGlmICghaXNWYWxpZERvbWFpbihlZmZlY3RpdmVEb21haW4pKSB7XG4gICAgICAvLyBodHRwczovL3d3dy53My5vcmcvVFIvd2ViYXV0aG4tMi8jc2N0bi1jcmVhdGVDcmVkZW50aWFsIChTdGVwIDcpXG4gICAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiBgJHt3aW5kb3cubG9jYXRpb24uaG9zdG5hbWV9IGlzIGFuIGludmFsaWQgZG9tYWluYCxcbiAgICAgICAgY29kZTogJ0VSUk9SX0lOVkFMSURfRE9NQUlOJyxcbiAgICAgICAgY2F1c2U6IGVycm9yLFxuICAgICAgfSlcbiAgICB9IGVsc2UgaWYgKHB1YmxpY0tleS5ycC5pZCAhPT0gZWZmZWN0aXZlRG9tYWluKSB7XG4gICAgICAvLyBodHRwczovL3d3dy53My5vcmcvVFIvd2ViYXV0aG4tMi8jc2N0bi1jcmVhdGVDcmVkZW50aWFsIChTdGVwIDgpXG4gICAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiBgVGhlIFJQIElEIFwiJHtwdWJsaWNLZXkucnAuaWR9XCIgaXMgaW52YWxpZCBmb3IgdGhpcyBkb21haW5gLFxuICAgICAgICBjb2RlOiAnRVJST1JfSU5WQUxJRF9SUF9JRCcsXG4gICAgICAgIGNhdXNlOiBlcnJvcixcbiAgICAgIH0pXG4gICAgfVxuICB9IGVsc2UgaWYgKGVycm9yLm5hbWUgPT09ICdUeXBlRXJyb3InKSB7XG4gICAgaWYgKHB1YmxpY0tleS51c2VyLmlkLmJ5dGVMZW5ndGggPCAxIHx8IHB1YmxpY0tleS51c2VyLmlkLmJ5dGVMZW5ndGggPiA2NCkge1xuICAgICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tY3JlYXRlQ3JlZGVudGlhbCAoU3RlcCA1KVxuICAgICAgcmV0dXJuIG5ldyBXZWJBdXRobkVycm9yKHtcbiAgICAgICAgbWVzc2FnZTogJ1VzZXIgSUQgd2FzIG5vdCBiZXR3ZWVuIDEgYW5kIDY0IGNoYXJhY3RlcnMnLFxuICAgICAgICBjb2RlOiAnRVJST1JfSU5WQUxJRF9VU0VSX0lEX0xFTkdUSCcsXG4gICAgICAgIGNhdXNlOiBlcnJvcixcbiAgICAgIH0pXG4gICAgfVxuICB9IGVsc2UgaWYgKGVycm9yLm5hbWUgPT09ICdVbmtub3duRXJyb3InKSB7XG4gICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tb3AtbWFrZS1jcmVkIChTdGVwIDEpXG4gICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tb3AtbWFrZS1jcmVkIChTdGVwIDgpXG4gICAgcmV0dXJuIG5ldyBXZWJBdXRobkVycm9yKHtcbiAgICAgIG1lc3NhZ2U6XG4gICAgICAgICdUaGUgYXV0aGVudGljYXRvciB3YXMgdW5hYmxlIHRvIHByb2Nlc3MgdGhlIHNwZWNpZmllZCBvcHRpb25zLCBvciBjb3VsZCBub3QgY3JlYXRlIGEgbmV3IGNyZWRlbnRpYWwnLFxuICAgICAgY29kZTogJ0VSUk9SX0FVVEhFTlRJQ0FUT1JfR0VORVJBTF9FUlJPUicsXG4gICAgICBjYXVzZTogZXJyb3IsXG4gICAgfSlcbiAgfVxuXG4gIHJldHVybiBuZXcgV2ViQXV0aG5FcnJvcih7XG4gICAgbWVzc2FnZTogJ2EgTm9uLVdlYmF1dGhuIHJlbGF0ZWQgZXJyb3IgaGFzIG9jY3VycmVkJyxcbiAgICBjb2RlOiAnRVJST1JfUEFTU1RIUk9VR0hfU0VFX0NBVVNFX1BST1BFUlRZJyxcbiAgICBjYXVzZTogZXJyb3IsXG4gIH0pXG59XG5cbi8qKlxuICogQXR0ZW1wdCB0byBpbnR1aXQgX3doeV8gYW4gZXJyb3Igd2FzIHJhaXNlZCBhZnRlciBjYWxsaW5nIGBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuZ2V0KClgLlxuICogTWFwcyBicm93c2VyIGVycm9ycyB0byBzcGVjaWZpYyBXZWJBdXRobiBlcnJvciBjb2RlcyBmb3IgYmV0dGVyIGRlYnVnZ2luZy5cbiAqIEBwYXJhbSB7T2JqZWN0fSBwYXJhbXMgLSBFcnJvciBpZGVudGlmaWNhdGlvbiBwYXJhbWV0ZXJzXG4gKiBAcGFyYW0ge0Vycm9yfSBwYXJhbXMuZXJyb3IgLSBUaGUgZXJyb3IgdGhyb3duIGJ5IHRoZSBicm93c2VyXG4gKiBAcGFyYW0ge0NyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc30gcGFyYW1zLm9wdGlvbnMgLSBUaGUgb3B0aW9ucyBwYXNzZWQgdG8gY3JlZGVudGlhbHMuZ2V0KClcbiAqIEByZXR1cm5zIHtXZWJBdXRobkVycm9yfSBBIFdlYkF1dGhuRXJyb3Igd2l0aCBhIHNwZWNpZmljIGVycm9yIGNvZGVcbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jc2N0bi1nZXRBc3NlcnRpb24gVzNDIFdlYkF1dGhuIFNwZWMgLSBHZXQgQXNzZXJ0aW9ufVxuICovXG5leHBvcnQgZnVuY3Rpb24gaWRlbnRpZnlBdXRoZW50aWNhdGlvbkVycm9yKHtcbiAgZXJyb3IsXG4gIG9wdGlvbnMsXG59OiB7XG4gIGVycm9yOiBFcnJvclxuICBvcHRpb25zOiBTdHJpY3RPbWl0PENyZWRlbnRpYWxSZXF1ZXN0T3B0aW9ucywgJ3B1YmxpY0tleSc+ICYge1xuICAgIHB1YmxpY0tleTogUHVibGljS2V5Q3JlZGVudGlhbFJlcXVlc3RPcHRpb25zRnV0dXJlXG4gIH1cbn0pOiBXZWJBdXRobkVycm9yIHtcbiAgY29uc3QgeyBwdWJsaWNLZXkgfSA9IG9wdGlvbnNcblxuICBpZiAoIXB1YmxpY0tleSkge1xuICAgIHRocm93IEVycm9yKCdvcHRpb25zIHdhcyBtaXNzaW5nIHJlcXVpcmVkIHB1YmxpY0tleSBwcm9wZXJ0eScpXG4gIH1cblxuICBpZiAoZXJyb3IubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XG4gICAgaWYgKG9wdGlvbnMuc2lnbmFsIGluc3RhbmNlb2YgQWJvcnRTaWduYWwpIHtcbiAgICAgIC8vIGh0dHBzOi8vd3d3LnczLm9yZy9UUi93ZWJhdXRobi0yLyNzY3RuLWNyZWF0ZUNyZWRlbnRpYWwgKFN0ZXAgMTYpXG4gICAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiAnQXV0aGVudGljYXRpb24gY2VyZW1vbnkgd2FzIHNlbnQgYW4gYWJvcnQgc2lnbmFsJyxcbiAgICAgICAgY29kZTogJ0VSUk9SX0NFUkVNT05ZX0FCT1JURUQnLFxuICAgICAgICBjYXVzZTogZXJyb3IsXG4gICAgICB9KVxuICAgIH1cbiAgfSBlbHNlIGlmIChlcnJvci5uYW1lID09PSAnTm90QWxsb3dlZEVycm9yJykge1xuICAgIC8qKlxuICAgICAqIFBhc3MgdGhlIGVycm9yIGRpcmVjdGx5IHRocm91Z2guIFBsYXRmb3JtcyBhcmUgb3ZlcmxvYWRpbmcgdGhpcyBlcnJvciBiZXlvbmQgd2hhdCB0aGUgc3BlY1xuICAgICAqIGRlZmluZXMgYW5kIHdlIGRvbid0IHdhbnQgdG8gb3ZlcndyaXRlIHBvdGVudGlhbGx5IHVzZWZ1bCBlcnJvciBtZXNzYWdlcy5cbiAgICAgKi9cbiAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgbWVzc2FnZTogZXJyb3IubWVzc2FnZSxcbiAgICAgIGNvZGU6ICdFUlJPUl9QQVNTVEhST1VHSF9TRUVfQ0FVU0VfUFJPUEVSVFknLFxuICAgICAgY2F1c2U6IGVycm9yLFxuICAgIH0pXG4gIH0gZWxzZSBpZiAoZXJyb3IubmFtZSA9PT0gJ1NlY3VyaXR5RXJyb3InKSB7XG4gICAgY29uc3QgZWZmZWN0aXZlRG9tYWluID0gd2luZG93LmxvY2F0aW9uLmhvc3RuYW1lXG4gICAgaWYgKCFpc1ZhbGlkRG9tYWluKGVmZmVjdGl2ZURvbWFpbikpIHtcbiAgICAgIC8vIGh0dHBzOi8vd3d3LnczLm9yZy9UUi93ZWJhdXRobi0yLyNzY3RuLWRpc2NvdmVyLWZyb20tZXh0ZXJuYWwtc291cmNlIChTdGVwIDUpXG4gICAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiBgJHt3aW5kb3cubG9jYXRpb24uaG9zdG5hbWV9IGlzIGFuIGludmFsaWQgZG9tYWluYCxcbiAgICAgICAgY29kZTogJ0VSUk9SX0lOVkFMSURfRE9NQUlOJyxcbiAgICAgICAgY2F1c2U6IGVycm9yLFxuICAgICAgfSlcbiAgICB9IGVsc2UgaWYgKHB1YmxpY0tleS5ycElkICE9PSBlZmZlY3RpdmVEb21haW4pIHtcbiAgICAgIC8vIGh0dHBzOi8vd3d3LnczLm9yZy9UUi93ZWJhdXRobi0yLyNzY3RuLWRpc2NvdmVyLWZyb20tZXh0ZXJuYWwtc291cmNlIChTdGVwIDYpXG4gICAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiBgVGhlIFJQIElEIFwiJHtwdWJsaWNLZXkucnBJZH1cIiBpcyBpbnZhbGlkIGZvciB0aGlzIGRvbWFpbmAsXG4gICAgICAgIGNvZGU6ICdFUlJPUl9JTlZBTElEX1JQX0lEJyxcbiAgICAgICAgY2F1c2U6IGVycm9yLFxuICAgICAgfSlcbiAgICB9XG4gIH0gZWxzZSBpZiAoZXJyb3IubmFtZSA9PT0gJ1Vua25vd25FcnJvcicpIHtcbiAgICAvLyBodHRwczovL3d3dy53My5vcmcvVFIvd2ViYXV0aG4tMi8jc2N0bi1vcC1nZXQtYXNzZXJ0aW9uIChTdGVwIDEpXG4gICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSL3dlYmF1dGhuLTIvI3NjdG4tb3AtZ2V0LWFzc2VydGlvbiAoU3RlcCAxMilcbiAgICByZXR1cm4gbmV3IFdlYkF1dGhuRXJyb3Ioe1xuICAgICAgbWVzc2FnZTpcbiAgICAgICAgJ1RoZSBhdXRoZW50aWNhdG9yIHdhcyB1bmFibGUgdG8gcHJvY2VzcyB0aGUgc3BlY2lmaWVkIG9wdGlvbnMsIG9yIGNvdWxkIG5vdCBjcmVhdGUgYSBuZXcgYXNzZXJ0aW9uIHNpZ25hdHVyZScsXG4gICAgICBjb2RlOiAnRVJST1JfQVVUSEVOVElDQVRPUl9HRU5FUkFMX0VSUk9SJyxcbiAgICAgIGNhdXNlOiBlcnJvcixcbiAgICB9KVxuICB9XG5cbiAgcmV0dXJuIG5ldyBXZWJBdXRobkVycm9yKHtcbiAgICBtZXNzYWdlOiAnYSBOb24tV2ViYXV0aG4gcmVsYXRlZCBlcnJvciBoYXMgb2NjdXJyZWQnLFxuICAgIGNvZGU6ICdFUlJPUl9QQVNTVEhST1VHSF9TRUVfQ0FVU0VfUFJPUEVSVFknLFxuICAgIGNhdXNlOiBlcnJvcixcbiAgfSlcbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19