//#region src/types/common/common.ts
/**
* Default number of retry attempts.
*/
const DEFAULT_MAX_RETRIES = 3;
/**
* Default exponential backoff delay function.
* Delays: 1s, 2s, 4s, 8s, ... (max 30s)
*
* @param attemptIndex - Zero-based index of the retry attempt
* @returns Delay in milliseconds before the next retry
*/
const getRetryDelay = (attemptIndex) => Math.min(1e3 * 2 ** attemptIndex, 3e4);
/**
* Status codes that are safe to retry.
* 520 = Cloudflare timeout/connection errors (transient)
* 503 = PostgREST schema cache not yet loaded (transient, signals retry via Retry-After header)
*/
const RETRYABLE_STATUS_CODES = [520, 503];
/**
* HTTP methods that are safe to retry (idempotent operations).
*/
const RETRYABLE_METHODS = [
	"GET",
	"HEAD",
	"OPTIONS"
];

//#endregion
//#region src/PostgrestError.ts
/**
* Error format
*
* Returned by every PostgREST request that fails. When something fails, the
* single most useful field is usually `hint` — Postgres often returns the
* actionable fix there, not in `message`. Always log the full object (e.g.
* `console.error(error)`); logging only `error.message` hides the hint.
*
* Read the fields in roughly this order of usefulness:
*
* - `hint` — actionable guidance from the database when available. For
*   permission-denied errors (`42501`), this is the literal SQL to fix the
*   problem, e.g.
*   `"Grant the required privileges to the current role with: GRANT SELECT ON public.users TO anon;"`.
*   Missing column? `hint` suggests the column you probably meant. Whenever
*   Postgres knows the fix, it puts it in `hint`.
* - `code` — stable error code from PostgREST (e.g. `PGRST301`) or Postgres
*   (e.g. `42501`). Branch on this rather than on `message` text.
* - `details` — extra context, often the offending value, key, or row.
* - `message` — human-readable summary. Useful in UI strings; less useful
*   for debugging.
*
* {@link https://postgrest.org/en/stable/api.html?highlight=options#errors-and-http-status-codes}
*/
var PostgrestError = class extends Error {
	/**
	* @example
	* ```ts
	* import PostgrestError from '@supabase/postgrest-js'
	*
	* throw new PostgrestError({
	*   message: 'Row level security prevented the request',
	*   details: 'RLS denied the insert',
	*   hint: 'Check your policies',
	*   code: 'PGRST301',
	* })
	* ```
	*/
	constructor(context) {
		super(context.message);
		this.name = "PostgrestError";
		this.details = context.details;
		this.hint = context.hint;
		this.code = context.code;
	}
	toJSON() {
		return {
			name: this.name,
			message: this.message,
			details: this.details,
			hint: this.hint,
			code: this.code
		};
	}
};

//#endregion
//#region src/PostgrestBuilder.ts
/**
* Sleep for a given number of milliseconds.
* If an AbortSignal is provided, the sleep resolves early when the signal is aborted.
*/
function sleep(ms, signal) {
	return new Promise((resolve) => {
		if (signal === null || signal === void 0 ? void 0 : signal.aborted) {
			resolve();
			return;
		}
		const id = setTimeout(() => {
			signal === null || signal === void 0 || signal.removeEventListener("abort", onAbort);
			resolve();
		}, ms);
		function onAbort() {
			clearTimeout(id);
			resolve();
		}
		signal === null || signal === void 0 || signal.addEventListener("abort", onAbort);
	});
}
/**
* Check if a request should be retried based on method and status code.
*/
function shouldRetry(method, status, attemptCount, retryEnabled) {
	if (!retryEnabled || attemptCount >= DEFAULT_MAX_RETRIES) return false;
	if (!RETRYABLE_METHODS.includes(method)) return false;
	if (!RETRYABLE_STATUS_CODES.includes(status)) return false;
	return true;
}
var PostgrestBuilder = class {
	/**
	* Creates a builder configured for a specific PostgREST request.
	*
	* @example Using supabase-js (recommended)
	* ```ts
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	* const { data, error } = await supabase.from('users').select('*')
	* ```
	*
	* @category Database
	*
	* @example Standalone import for bundle-sensitive environments
	* ```ts
	* import { PostgrestQueryBuilder } from '@supabase/postgrest-js'
	*
	* const builder = new PostgrestQueryBuilder(
	*   new URL('https://xyzcompany.supabase.co/rest/v1/users'),
	*   { headers: new Headers({ apikey: 'your-publishable-key' }) }
	* )
	* ```
	*/
	constructor(builder) {
		var _builder$shouldThrowO, _builder$isMaybeSingl, _builder$shouldStripN, _builder$urlLengthLim, _builder$retry;
		this.shouldThrowOnError = false;
		this.retryEnabled = true;
		this.method = builder.method;
		this.url = builder.url;
		this.headers = new Headers(builder.headers);
		this.schema = builder.schema;
		this.body = builder.body;
		this.shouldThrowOnError = (_builder$shouldThrowO = builder.shouldThrowOnError) !== null && _builder$shouldThrowO !== void 0 ? _builder$shouldThrowO : false;
		this.signal = builder.signal;
		this.isMaybeSingle = (_builder$isMaybeSingl = builder.isMaybeSingle) !== null && _builder$isMaybeSingl !== void 0 ? _builder$isMaybeSingl : false;
		this.shouldStripNulls = (_builder$shouldStripN = builder.shouldStripNulls) !== null && _builder$shouldStripN !== void 0 ? _builder$shouldStripN : false;
		this.urlLengthLimit = (_builder$urlLengthLim = builder.urlLengthLimit) !== null && _builder$urlLengthLim !== void 0 ? _builder$urlLengthLim : 8e3;
		this.retryEnabled = (_builder$retry = builder.retry) !== null && _builder$retry !== void 0 ? _builder$retry : true;
		if (builder.fetch) this.fetch = builder.fetch;
		else this.fetch = fetch;
	}
	/**
	* If there's an error with the query, throwOnError will reject the promise by
	* throwing the error instead of returning it as part of a successful response.
	*
	* {@link https://github.com/supabase/supabase-js/issues/92}
	*
	* @category Database
	* @subcategory Using modifiers
	*/
	throwOnError() {
		this.shouldThrowOnError = true;
		return this;
	}
	/**
	* Strip null values from the response data. Properties with `null` values
	* will be omitted from the returned JSON objects.
	*
	* Requires PostgREST 11.2.0+.
	*
	* {@link https://docs.postgrest.org/en/stable/references/api/resource_representation.html#stripped-nulls}
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .stripNulls()
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text, bio text);
	*
	* insert into
	*   characters (id, name, bio)
	* values
	*   (1, 'Luke', null),
	*   (2, 'Leia', 'Princess of Alderaan');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Luke"
	*     },
	*     {
	*       "id": 2,
	*       "name": "Leia",
	*       "bio": "Princess of Alderaan"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	stripNulls() {
		if (this.headers.get("Accept") === "text/csv") throw new Error("stripNulls() cannot be used with csv()");
		this.shouldStripNulls = true;
		return this;
	}
	/**
	* Set an HTTP header on this single PostgREST request, overriding any header
	* with the same name set on the client.
	*
	* This is an advanced escape hatch for one-off needs (passing a custom
	* `Authorization` for a single query, attaching a tracing header, etc.).
	* Most callers do not need it: configure client-wide headers via the
	* `headers` option when constructing the client, and authentication via
	* Supabase Auth.
	*
	* @param name - HTTP header name
	* @param value - HTTP header value
	*
	* @category Database
	* @subcategory Using modifiers
	*/
	setHeader(name, value) {
		this.headers = new Headers(this.headers);
		this.headers.set(name, value);
		return this;
	}
	/**
	* @category Database
	* @subcategory Using modifiers
	*
	* Configure retry behavior for this request.
	*
	* By default, retries are enabled for idempotent requests (GET, HEAD, OPTIONS)
	* that fail with network errors or specific HTTP status codes (503, 520).
	* Retries use exponential backoff (1s, 2s, 4s) with a maximum of 3 attempts.
	*
	* @param enabled - Whether to enable retries for this request
	*
	* @example
	* ```ts
	* // Disable retries for a specific query
	* const { data, error } = await supabase
	*   .from('users')
	*   .select()
	*   .retry(false)
	* ```
	*/
	retry(enabled) {
		this.retryEnabled = enabled;
		return this;
	}
	then(onfulfilled, onrejected) {
		var _this = this;
		if (this.schema === void 0) {} else if (["GET", "HEAD"].includes(this.method)) this.headers.set("Accept-Profile", this.schema);
		else this.headers.set("Content-Profile", this.schema);
		if (this.method !== "GET" && this.method !== "HEAD") this.headers.set("Content-Type", "application/json");
		if (this.shouldStripNulls) {
			const currentAccept = this.headers.get("Accept");
			if (currentAccept === "application/vnd.pgrst.object+json") this.headers.set("Accept", "application/vnd.pgrst.object+json;nulls=stripped");
			else if (!currentAccept || currentAccept === "application/json") this.headers.set("Accept", "application/vnd.pgrst.array+json;nulls=stripped");
		}
		const _fetch = this.fetch;
		const executeWithRetry = async () => {
			let attemptCount = 0;
			while (true) {
				const headers = {};
				_this.headers.forEach((value, key) => {
					headers[key] = value;
				});
				if (attemptCount > 0) headers["X-Retry-Count"] = String(attemptCount);
				let res$1;
				try {
					res$1 = await _fetch(_this.url.toString(), {
						method: _this.method,
						headers,
						body: JSON.stringify(_this.body, (_, value) => typeof value === "bigint" ? value.toString() : value),
						signal: _this.signal
					});
				} catch (fetchError) {
					if ((fetchError === null || fetchError === void 0 ? void 0 : fetchError.name) === "AbortError" || (fetchError === null || fetchError === void 0 ? void 0 : fetchError.code) === "ABORT_ERR") throw fetchError;
					if (!RETRYABLE_METHODS.includes(_this.method)) throw fetchError;
					if (_this.retryEnabled && attemptCount < DEFAULT_MAX_RETRIES) {
						const delay = getRetryDelay(attemptCount);
						attemptCount++;
						await sleep(delay, _this.signal);
						continue;
					}
					throw fetchError;
				}
				if (shouldRetry(_this.method, res$1.status, attemptCount, _this.retryEnabled)) {
					var _res$headers$get, _res$headers;
					const retryAfterHeader = (_res$headers$get = (_res$headers = res$1.headers) === null || _res$headers === void 0 ? void 0 : _res$headers.get("Retry-After")) !== null && _res$headers$get !== void 0 ? _res$headers$get : null;
					const delay = retryAfterHeader !== null ? Math.max(0, parseInt(retryAfterHeader, 10) || 0) * 1e3 : getRetryDelay(attemptCount);
					await res$1.text();
					attemptCount++;
					await sleep(delay, _this.signal);
					continue;
				}
				return await _this.processResponse(res$1);
			}
		};
		let res = executeWithRetry();
		if (!this.shouldThrowOnError) res = res.catch((fetchError) => {
			var _fetchError$name2;
			let errorDetails = "";
			let hint = "";
			let code = "";
			const cause = fetchError === null || fetchError === void 0 ? void 0 : fetchError.cause;
			if (cause) {
				var _cause$message, _cause$code, _fetchError$name, _cause$name;
				const causeMessage = (_cause$message = cause === null || cause === void 0 ? void 0 : cause.message) !== null && _cause$message !== void 0 ? _cause$message : "";
				const causeCode = (_cause$code = cause === null || cause === void 0 ? void 0 : cause.code) !== null && _cause$code !== void 0 ? _cause$code : "";
				errorDetails = `${(_fetchError$name = fetchError === null || fetchError === void 0 ? void 0 : fetchError.name) !== null && _fetchError$name !== void 0 ? _fetchError$name : "FetchError"}: ${fetchError === null || fetchError === void 0 ? void 0 : fetchError.message}`;
				errorDetails += `\n\nCaused by: ${(_cause$name = cause === null || cause === void 0 ? void 0 : cause.name) !== null && _cause$name !== void 0 ? _cause$name : "Error"}: ${causeMessage}`;
				if (causeCode) errorDetails += ` (${causeCode})`;
				if (cause === null || cause === void 0 ? void 0 : cause.stack) errorDetails += `\n${cause.stack}`;
			} else {
				var _fetchError$stack;
				errorDetails = (_fetchError$stack = fetchError === null || fetchError === void 0 ? void 0 : fetchError.stack) !== null && _fetchError$stack !== void 0 ? _fetchError$stack : "";
			}
			const urlLength = this.url.toString().length;
			if ((fetchError === null || fetchError === void 0 ? void 0 : fetchError.name) === "AbortError" || (fetchError === null || fetchError === void 0 ? void 0 : fetchError.code) === "ABORT_ERR") {
				code = "";
				hint = "Request was aborted (timeout or manual cancellation)";
				if (urlLength > this.urlLengthLimit) hint += `. Note: Your request URL is ${urlLength} characters, which may exceed server limits. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [many IDs])), consider using an RPC function to pass values server-side.`;
			} else if ((cause === null || cause === void 0 ? void 0 : cause.name) === "HeadersOverflowError" || (cause === null || cause === void 0 ? void 0 : cause.code) === "UND_ERR_HEADERS_OVERFLOW") {
				code = "";
				hint = "HTTP headers exceeded server limits (typically 16KB)";
				if (urlLength > this.urlLengthLimit) hint += `. Your request URL is ${urlLength} characters. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [200+ IDs])), consider using an RPC function instead.`;
			}
			return {
				success: false,
				error: {
					message: `${(_fetchError$name2 = fetchError === null || fetchError === void 0 ? void 0 : fetchError.name) !== null && _fetchError$name2 !== void 0 ? _fetchError$name2 : "FetchError"}: ${fetchError === null || fetchError === void 0 ? void 0 : fetchError.message}`,
					details: errorDetails,
					hint,
					code
				},
				data: null,
				count: null,
				status: 0,
				statusText: ""
			};
		});
		return res.then(onfulfilled, onrejected);
	}
	/**
	* Process a fetch response and return the standardized postgrest response.
	*/
	async processResponse(res) {
		var _this2 = this;
		let error = null;
		let data = null;
		let count = null;
		let status = res.status;
		let statusText = res.statusText;
		if (res.ok) {
			var _this$headers$get2, _res$headers$get2;
			if (_this2.method !== "HEAD") {
				var _this$headers$get;
				const body = await res.text();
				if (body === "") {} else if (_this2.headers.get("Accept") === "text/csv") data = body;
				else if (_this2.headers.get("Accept") && ((_this$headers$get = _this2.headers.get("Accept")) === null || _this$headers$get === void 0 ? void 0 : _this$headers$get.includes("application/vnd.pgrst.plan+text"))) data = body;
				else try {
					data = JSON.parse(body);
				} catch (_unused) {
					error = { message: body };
					data = null;
					if (_this2.shouldThrowOnError) throw new PostgrestError({
						message: body,
						details: "",
						hint: "",
						code: ""
					});
				}
			}
			const countHeader = (_this$headers$get2 = _this2.headers.get("Prefer")) === null || _this$headers$get2 === void 0 ? void 0 : _this$headers$get2.match(/count=(exact|planned|estimated)/);
			const contentRange = (_res$headers$get2 = res.headers.get("content-range")) === null || _res$headers$get2 === void 0 ? void 0 : _res$headers$get2.split("/");
			if (countHeader && contentRange && contentRange.length > 1) count = parseInt(contentRange[1]);
			if (_this2.isMaybeSingle && Array.isArray(data)) if (data.length > 1) {
				error = {
					code: "PGRST116",
					details: `Results contain ${data.length} rows, application/vnd.pgrst.object+json requires 1 row`,
					hint: null,
					message: "JSON object requested, multiple (or no) rows returned"
				};
				data = null;
				count = null;
				status = 406;
				statusText = "Not Acceptable";
			} else if (data.length === 1) data = data[0];
			else data = null;
		} else {
			const body = await res.text();
			try {
				error = JSON.parse(body);
				if (Array.isArray(error) && res.status === 404) {
					data = [];
					error = null;
					status = 200;
					statusText = "OK";
				}
			} catch (_unused2) {
				if (res.status === 404 && body === "") {
					status = 204;
					statusText = "No Content";
				} else error = { message: body };
			}
			if (error && _this2.shouldThrowOnError) throw new PostgrestError(error);
		}
		return {
			success: error === null,
			error,
			data,
			count,
			status,
			statusText
		};
	}
	/**
	* Override the type of the returned `data`.
	*
	* @typeParam NewResult - The new result type to override with
	* @deprecated Use overrideTypes<yourType, { merge: false }>() method at the end of your call chain instead
	*
	* @category Database
	* @subcategory Using modifiers
	*/
	returns() {
		/* istanbul ignore next */
		return this;
	}
	/**
	* Override the type of the returned `data` field in the response.
	*
	* @typeParam NewResult - The new type to cast the response data to
	* @typeParam Options - Optional type configuration (defaults to { merge: true })
	* @typeParam Options.merge - When true, merges the new type with existing return type. When false, replaces the existing types entirely (defaults to true)
	* @example
	* ```typescript
	* // Merge with existing types (default behavior)
	* const query = supabase
	*   .from('users')
	*   .select()
	*   .overrideTypes<{ custom_field: string }>()
	*
	* // Replace existing types completely
	* const replaceQuery = supabase
	*   .from('users')
	*   .select()
	*   .overrideTypes<{ id: number; name: string }, { merge: false }>()
	* ```
	* @returns A PostgrestBuilder instance with the new type
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example Complete Override type of successful response
	* ```ts
	* const { data } = await supabase
	*   .from('countries')
	*   .select()
	*   .overrideTypes<Array<MyType>, { merge: false }>()
	* ```
	*
	* @exampleResponse Complete Override type of successful response
	* ```ts
	* let x: typeof data // MyType[]
	* ```
	*
	* @example Complete Override type of object response
	* ```ts
	* const { data } = await supabase
	*   .from('countries')
	*   .select()
	*   .maybeSingle()
	*   .overrideTypes<MyType, { merge: false }>()
	* ```
	*
	* @exampleResponse Complete Override type of object response
	* ```ts
	* let x: typeof data // MyType | null
	* ```
	*
	* @example Partial Override type of successful response
	* ```ts
	* const { data } = await supabase
	*   .from('countries')
	*   .select()
	*   .overrideTypes<Array<{ status: "A" | "B" }>>()
	* ```
	*
	* @exampleResponse Partial Override type of successful response
	* ```ts
	* let x: typeof data // Array<CountryRowProperties & { status: "A" | "B" }>
	* ```
	*
	* @example Partial Override type of object response
	* ```ts
	* const { data } = await supabase
	*   .from('countries')
	*   .select()
	*   .maybeSingle()
	*   .overrideTypes<{ status: "A" | "B" }>()
	* ```
	*
	* @exampleResponse Partial Override type of object response
	* ```ts
	* let x: typeof data // CountryRowProperties & { status: "A" | "B" } | null
	* ```
	*
	* @example Merge vs replace existing types
	* ```typescript
	* // Merge with existing types (default behavior)
	* const query = supabase
	*   .from('users')
	*   .select()
	*   .overrideTypes<{ custom_field: string }>()
	*
	* // Replace existing types completely
	* const replaceQuery = supabase
	*   .from('users')
	*   .select()
	*   .overrideTypes<{ id: number; name: string }, { merge: false }>()
	* ```
	*/
	overrideTypes() {
		return this;
	}
};

//#endregion
//#region src/PostgrestTransformBuilder.ts
var PostgrestTransformBuilder = class extends PostgrestBuilder {
	throwOnError() {
		return super.throwOnError();
	}
	/**
	* Perform a SELECT on the query result.
	*
	* By default, `.insert()`, `.update()`, `.upsert()`, and `.delete()` do not
	* return modified rows. By calling this method, modified rows are returned in
	* `data`.
	*
	* @param columns - The columns to retrieve, separated by commas
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example With `upsert()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .upsert({ id: 1, name: 'Han Solo' })
	*   .select()
	* ```
	*
	* @exampleSql With `upsert()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Han');
	* ```
	*
	* @exampleResponse With `upsert()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Han Solo"
	*     }
	*   ],
	*   "status": 201,
	*   "statusText": "Created"
	* }
	* ```
	*/
	select(columns) {
		let quoted = false;
		const cleanedColumns = (columns !== null && columns !== void 0 ? columns : "*").split("").map((c) => {
			if (/\s/.test(c) && !quoted) return "";
			if (c === "\"") quoted = !quoted;
			return c;
		}).join("");
		this.url.searchParams.set("select", cleanedColumns);
		this.headers.append("Prefer", "return=representation");
		return this;
	}
	/**
	* Order the query result by `column`.
	*
	* You can call this method multiple times to order by multiple columns.
	*
	* You can order referenced tables, but it only affects the ordering of the
	* parent table if you use `!inner` in the query.
	*
	* @param column - The column to order by
	* @param options - Named parameters
	* @param options.ascending - If `true`, the result will be in ascending order
	* @param options.nullsFirst - If `true`, `null`s appear first. If `false`,
	* `null`s appear last.
	* @param options.referencedTable - Set this to order a referenced table by
	* its columns
	* @param options.foreignTable - Deprecated, use `options.referencedTable`
	* instead
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('id, name')
	*   .order('id', { ascending: false })
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 3,
	*       "name": "Han"
	*     },
	*     {
	*       "id": 2,
	*       "name": "Leia"
	*     },
	*     {
	*       "id": 1,
	*       "name": "Luke"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription On a referenced table
	* Ordering with `referencedTable` doesn't affect the ordering of the
	* parent table.
	*
	* @example On a referenced table
	* ```ts
	*   const { data, error } = await supabase
	*     .from('orchestral_sections')
	*     .select(`
	*       name,
	*       instruments (
	*         name
	*       )
	*     `)
	*     .order('name', { referencedTable: 'instruments', ascending: false })
	*
	* ```
	*
	* @exampleSql On a referenced table
	* ```sql
	* create table
	*   orchestral_sections (id int8 primary key, name text);
	* create table
	*   instruments (
	*     id int8 primary key,
	*     section_id int8 not null references orchestral_sections,
	*     name text
	*   );
	*
	* insert into
	*   orchestral_sections (id, name)
	* values
	*   (1, 'strings'),
	*   (2, 'woodwinds');
	* insert into
	*   instruments (id, section_id, name)
	* values
	*   (1, 1, 'harp'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse On a referenced table
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "strings",
	*       "instruments": [
	*         {
	*           "name": "violin"
	*         },
	*         {
	*           "name": "harp"
	*         }
	*       ]
	*     },
	*     {
	*       "name": "woodwinds",
	*       "instruments": []
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Order parent table by a referenced table
	* Ordering with `referenced_table(col)` affects the ordering of the
	* parent table.
	*
	* @example Order parent table by a referenced table
	* ```ts
	*   const { data, error } = await supabase
	*     .from('instruments')
	*     .select(`
	*       name,
	*       section:orchestral_sections (
	*         name
	*       )
	*     `)
	*     .order('section(name)', { ascending: true })
	*
	* ```
	*
	* @exampleSql Order parent table by a referenced table
	* ```sql
	* create table
	*   orchestral_sections (id int8 primary key, name text);
	* create table
	*   instruments (
	*     id int8 primary key,
	*     section_id int8 not null references orchestral_sections,
	*     name text
	*   );
	*
	* insert into
	*   orchestral_sections (id, name)
	* values
	*   (1, 'strings'),
	*   (2, 'woodwinds');
	* insert into
	*   instruments (id, section_id, name)
	* values
	*   (1, 2, 'flute'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse Order parent table by a referenced table
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "violin",
	*       "orchestral_sections": {"name": "strings"}
	*     },
	*     {
	*       "name": "flute",
	*       "orchestral_sections": {"name": "woodwinds"}
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	order(column, { ascending = true, nullsFirst, foreignTable, referencedTable = foreignTable } = {}) {
		const key = referencedTable ? `${referencedTable}.order` : "order";
		const existingOrder = this.url.searchParams.get(key);
		this.url.searchParams.set(key, `${existingOrder ? `${existingOrder},` : ""}${column}.${ascending ? "asc" : "desc"}${nullsFirst === void 0 ? "" : nullsFirst ? ".nullsfirst" : ".nullslast"}`);
		return this;
	}
	/**
	* Limit the query result by `rows`.
	*
	* @param rows - The maximum number of rows to return
	* @param options - Named parameters
	* @param options.referencedTable - Set this to limit rows of referenced
	* tables instead of the parent table
	* @param options.foreignTable - Deprecated, use `options.referencedTable`
	* instead
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('name')
	*   .limit(1)
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Luke"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example On a referenced table
	* ```ts
	* const { data, error } = await supabase
	*   .from('orchestral_sections')
	*   .select(`
	*     name,
	*     instruments (
	*       name
	*     )
	*   `)
	*   .limit(1, { referencedTable: 'instruments' })
	* ```
	*
	* @exampleSql On a referenced table
	* ```sql
	* create table
	*   orchestral_sections (id int8 primary key, name text);
	* create table
	*   instruments (
	*     id int8 primary key,
	*     section_id int8 not null references orchestral_sections,
	*     name text
	*   );
	*
	* insert into
	*   orchestral_sections (id, name)
	* values
	*   (1, 'strings');
	* insert into
	*   instruments (id, section_id, name)
	* values
	*   (1, 1, 'harp'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse On a referenced table
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "strings",
	*       "instruments": [
	*         {
	*           "name": "violin"
	*         }
	*       ]
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	limit(rows, { foreignTable, referencedTable = foreignTable } = {}) {
		const key = typeof referencedTable === "undefined" ? "limit" : `${referencedTable}.limit`;
		this.url.searchParams.set(key, `${rows}`);
		return this;
	}
	/**
	* Limit the query result by starting at an offset `from` and ending at the offset `to`.
	* Only records within this range are returned.
	* This respects the query order and if there is no order clause the range could behave unexpectedly.
	* The `from` and `to` values are 0-based and inclusive: `range(1, 3)` will include the second, third
	* and fourth rows of the query.
	*
	* @param from - The starting index from which to limit the result
	* @param to - The last index to which to limit the result
	* @param options - Named parameters
	* @param options.referencedTable - Set this to limit rows of referenced
	* tables instead of the parent table
	* @param options.foreignTable - Deprecated, use `options.referencedTable`
	* instead
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('name')
	*   .range(0, 1)
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Luke"
	*     },
	*     {
	*       "name": "Leia"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	range(from, to, { foreignTable, referencedTable = foreignTable } = {}) {
		const keyOffset = typeof referencedTable === "undefined" ? "offset" : `${referencedTable}.offset`;
		const keyLimit = typeof referencedTable === "undefined" ? "limit" : `${referencedTable}.limit`;
		this.url.searchParams.set(keyOffset, `${from}`);
		this.url.searchParams.set(keyLimit, `${to - from + 1}`);
		return this;
	}
	/**
	* Set the AbortSignal for the fetch request.
	*
	* @param signal - The AbortSignal to use for the fetch request
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @remarks
	* You can use this to set a timeout for the request.
	*
	* @exampleDescription Aborting requests in-flight
	* You can use an [`AbortController`](https://developer.mozilla.org/en-US/docs/Web/API/AbortController) to abort requests.
	* Note that `status` and `statusText` don't mean anything for aborted requests as the request wasn't fulfilled.
	*
	* @example Aborting requests in-flight
	* ```ts
	* const ac = new AbortController()
	*
	* const { data, error } = await supabase
	*   .from('very_big_table')
	*   .select()
	*   .abortSignal(ac.signal)
	*
	* // Abort the request after 100 ms
	* setTimeout(() => ac.abort(), 100)
	* ```
	*
	* @exampleResponse Aborting requests in-flight
	* ```json
	*   {
	*     "error": {
	*       "message": "AbortError: The user aborted a request.",
	*       "details": "",
	*       "hint": "The request was aborted locally via the provided AbortSignal.",
	*       "code": ""
	*     },
	*     "status": 0,
	*     "statusText": ""
	*   }
	*
	* ```
	*
	* @example Set a timeout
	* ```ts
	* const { data, error } = await supabase
	*   .from('very_big_table')
	*   .select()
	*   .abortSignal(AbortSignal.timeout(1000 /* ms *\/))
	* ```
	*
	* @exampleResponse Set a timeout
	* ```json
	*   {
	*     "error": {
	*       "message": "FetchError: The user aborted a request.",
	*       "details": "",
	*       "hint": "",
	*       "code": ""
	*     },
	*     "status": 400,
	*     "statusText": "Bad Request"
	*   }
	*
	* ```
	*/
	abortSignal(signal) {
		this.signal = signal;
		return this;
	}
	/**
	* Return `data` as a single object instead of an array of objects.
	*
	* Query result must be one row (e.g. using `.limit(1)`), otherwise this
	* returns an error.
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('name')
	*   .limit(1)
	*   .single()
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": {
	*     "name": "Luke"
	*   },
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	single() {
		this.headers.set("Accept", "application/vnd.pgrst.object+json");
		return this;
	}
	/**
	* Return `data` as a single object instead of an array of objects.
	*
	* Query result must be zero or one row (e.g. using `.limit(1)`), otherwise
	* this returns an error.
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .eq('name', 'Katniss')
	*   .maybeSingle()
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	maybeSingle() {
		this.isMaybeSingle = true;
		return this;
	}
	/**
	* Return `data` as a string in CSV format.
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @exampleDescription Return data as CSV
	* By default, the data is returned in JSON format, but can also be returned as Comma Separated Values.
	*
	* @example Return data as CSV
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .csv()
	* ```
	*
	* @exampleSql Return data as CSV
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse Return data as CSV
	* ```json
	* {
	*   "data": "id,name\n1,Luke\n2,Leia\n3,Han",
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	csv() {
		this.headers.set("Accept", "text/csv");
		return this;
	}
	/**
	* Return `data` as an object in [GeoJSON](https://geojson.org) format.
	*
	* @category Database
	* @subcategory Using modifiers
	*/
	geojson() {
		this.headers.set("Accept", "application/geo+json");
		return this;
	}
	/**
	* Return `data` as the EXPLAIN plan for the query.
	*
	* You need to enable the
	* [db_plan_enabled](https://supabase.com/docs/guides/database/debugging-performance#enabling-explain)
	* setting before using this method.
	*
	* @param options - Named parameters
	*
	* @param options.analyze - If `true`, the query will be executed and the
	* actual run time will be returned
	*
	* @param options.verbose - If `true`, the query identifier will be returned
	* and `data` will include the output columns of the query
	*
	* @param options.settings - If `true`, include information on configuration
	* parameters that affect query planning
	*
	* @param options.buffers - If `true`, include information on buffer usage
	*
	* @param options.wal - If `true`, include information on WAL record generation
	*
	* @param options.format - The format of the output, can be `"text"` (default)
	* or `"json"`
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @exampleDescription Get the execution plan
	* By default, the data is returned in TEXT format, but can also be returned as JSON by using the `format` parameter.
	*
	* @example Get the execution plan
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .explain()
	* ```
	*
	* @exampleSql Get the execution plan
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse Get the execution plan
	* ```js
	* Aggregate  (cost=33.34..33.36 rows=1 width=112)
	*   ->  Limit  (cost=0.00..18.33 rows=1000 width=40)
	*         ->  Seq Scan on characters  (cost=0.00..22.00 rows=1200 width=40)
	* ```
	*
	* @exampleDescription Get the execution plan with analyze and verbose
	* By default, the data is returned in TEXT format, but can also be returned as JSON by using the `format` parameter.
	*
	* @example Get the execution plan with analyze and verbose
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .explain({analyze:true,verbose:true})
	* ```
	*
	* @exampleSql Get the execution plan with analyze and verbose
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse Get the execution plan with analyze and verbose
	* ```js
	* Aggregate  (cost=33.34..33.36 rows=1 width=112) (actual time=0.041..0.041 rows=1 loops=1)
	*   Output: NULL::bigint, count(ROW(characters.id, characters.name)), COALESCE(json_agg(ROW(characters.id, characters.name)), '[]'::json), NULLIF(current_setting('response.headers'::text, true), ''::text), NULLIF(current_setting('response.status'::text, true), ''::text)
	*   ->  Limit  (cost=0.00..18.33 rows=1000 width=40) (actual time=0.005..0.006 rows=3 loops=1)
	*         Output: characters.id, characters.name
	*         ->  Seq Scan on public.characters  (cost=0.00..22.00 rows=1200 width=40) (actual time=0.004..0.005 rows=3 loops=1)
	*               Output: characters.id, characters.name
	* Query Identifier: -4730654291623321173
	* Planning Time: 0.407 ms
	* Execution Time: 0.119 ms
	* ```
	*/
	explain({ analyze = false, verbose = false, settings = false, buffers = false, wal = false, format = "text" } = {}) {
		var _this$headers$get;
		const options = [
			analyze ? "analyze" : null,
			verbose ? "verbose" : null,
			settings ? "settings" : null,
			buffers ? "buffers" : null,
			wal ? "wal" : null
		].filter(Boolean).join("|");
		const forMediatype = (_this$headers$get = this.headers.get("Accept")) !== null && _this$headers$get !== void 0 ? _this$headers$get : "application/json";
		this.headers.set("Accept", `application/vnd.pgrst.plan+${format}; for="${forMediatype}"; options=${options};`);
		if (format === "json") return this;
		else return this;
	}
	/**
	* Dry-run this request: execute the query but discard the changes.
	*
	* Server-side, PostgREST runs the query inside a transaction and rolls it back
	* instead of committing. The response still contains the data that *would* have
	* been returned — `RETURNING` clauses execute and RLS, triggers, and constraints
	* are all evaluated — but no row is actually inserted, updated, or deleted.
	*
	* This affects only the single request it is chained to. The JS caller has no
	* handle on the transaction: supabase-js does not group multiple queries into
	* one transaction. For multi-statement transactional logic, use a database
	* function (`supabase.rpc(...)`).
	*
	* Sets the `Prefer: tx=rollback` header. See PostgREST's docs on transaction
	* preferences for the underlying mechanism.
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @example Validate an insert without persisting
	* ```ts
	* const { data, error } = await supabase
	*   .from('countries')
	*   .insert({ name: 'France' })
	*   .select()
	*   .rollback()
	* // `data` shows what would have been inserted; nothing is saved.
	* ```
	*/
	rollback() {
		this.headers.append("Prefer", "tx=rollback");
		return this;
	}
	/**
	* Override the type of the returned `data`.
	*
	* @typeParam NewResult - The new result type to override with
	* @deprecated Use overrideTypes<yourType, { merge: false }>() method at the end of your call chain instead
	*
	* @category Database
	* @subcategory Using modifiers
	*
	* @remarks
	* - Deprecated: use overrideTypes method instead
	*
	* @example Override type of successful response
	* ```ts
	* const { data } = await supabase
	*   .from('countries')
	*   .select()
	*   .returns<Array<MyType>>()
	* ```
	*
	* @exampleResponse Override type of successful response
	* ```js
	* let x: typeof data // MyType[]
	* ```
	*
	* @example Override type of object response
	* ```ts
	* const { data } = await supabase
	*   .from('countries')
	*   .select()
	*   .maybeSingle()
	*   .returns<MyType>()
	* ```
	*
	* @exampleResponse Override type of object response
	* ```js
	* let x: typeof data // MyType | null
	* ```
	*/
	returns() {
		return this;
	}
	/**
	* Set the maximum number of rows that can be affected by the query.
	* Only available in PostgREST v13+ and only works with PATCH and DELETE methods.
	*
	* @param rows - The maximum number of rows that can be affected
	*
	* @category Database
	* @subcategory Using modifiers
	*/
	maxAffected(rows) {
		this.headers.append("Prefer", "handling=strict");
		this.headers.append("Prefer", `max-affected=${rows}`);
		return this;
	}
};

//#endregion
//#region src/PostgrestFilterBuilder.ts
const PostgrestReservedCharsRegexp = /* @__PURE__ */ new RegExp("[,()]");
var PostgrestFilterBuilder = class extends PostgrestTransformBuilder {
	throwOnError() {
		return super.throwOnError();
	}
	/**
	* Match only rows where `column` is equal to `value`.
	*
	* To check if the value of `column` is NULL, you should use `.is()` instead.
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .eq('name', 'Leia')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 2,
	*       "name": "Leia"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	eq(column, value) {
		this.url.searchParams.append(column, `eq.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` is not equal to `value`.
	*
	* This filter does not include rows where `column` is `NULL`. To match null
	* values, use `.is(column, null)` instead.
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .neq('name', 'Leia')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Luke"
	*     },
	*     {
	*       "id": 3,
	*       "name": "Han"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	neq(column, value) {
		this.url.searchParams.append(column, `neq.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` is greater than `value`.
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @exampleDescription With `select()`
	* When using [reserved words](https://www.postgresql.org/docs/current/sql-keywords-appendix.html) for column names you need
	* to add double quotes e.g. `.gt('"order"', 2)`
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .gt('id', 2)
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 3,
	*       "name": "Han"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	gt(column, value) {
		this.url.searchParams.append(column, `gt.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` is greater than or equal to `value`.
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .gte('id', 2)
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 2,
	*       "name": "Leia"
	*     },
	*     {
	*       "id": 3,
	*       "name": "Han"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	gte(column, value) {
		this.url.searchParams.append(column, `gte.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` is less than `value`.
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .lt('id', 2)
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Luke"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	lt(column, value) {
		this.url.searchParams.append(column, `lt.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` is less than or equal to `value`.
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .lte('id', 2)
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Luke"
	*     },
	*     {
	*       "id": 2,
	*       "name": "Leia"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	lte(column, value) {
		this.url.searchParams.append(column, `lte.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` matches `pattern` case-sensitively.
	*
	* @param column - The column to filter on
	* @param pattern - The pattern to match with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .like('name', '%Lu%')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Luke"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	like(column, pattern) {
		this.url.searchParams.append(column, `like.${pattern}`);
		return this;
	}
	/**
	* Match only rows where `column` matches all of `patterns` case-sensitively.
	*
	* @param column - The column to filter on
	* @param patterns - The patterns to match with
	*
	* @category Database
	* @subcategory Using filters
	*/
	likeAllOf(column, patterns) {
		this.url.searchParams.append(column, `like(all).{${patterns.join(",")}}`);
		return this;
	}
	/**
	* Match only rows where `column` matches any of `patterns` case-sensitively.
	*
	* @param column - The column to filter on
	* @param patterns - The patterns to match with
	*
	* @category Database
	* @subcategory Using filters
	*/
	likeAnyOf(column, patterns) {
		this.url.searchParams.append(column, `like(any).{${patterns.join(",")}}`);
		return this;
	}
	/**
	* Match only rows where `column` matches `pattern` case-insensitively.
	*
	* @param column - The column to filter on
	* @param pattern - The pattern to match with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .ilike('name', '%lu%')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Luke"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	ilike(column, pattern) {
		this.url.searchParams.append(column, `ilike.${pattern}`);
		return this;
	}
	/**
	* Match only rows where `column` matches all of `patterns` case-insensitively.
	*
	* @param column - The column to filter on
	* @param patterns - The patterns to match with
	*
	* @category Database
	* @subcategory Using filters
	*/
	ilikeAllOf(column, patterns) {
		this.url.searchParams.append(column, `ilike(all).{${patterns.join(",")}}`);
		return this;
	}
	/**
	* Match only rows where `column` matches any of `patterns` case-insensitively.
	*
	* @param column - The column to filter on
	* @param patterns - The patterns to match with
	*
	* @category Database
	* @subcategory Using filters
	*/
	ilikeAnyOf(column, patterns) {
		this.url.searchParams.append(column, `ilike(any).{${patterns.join(",")}}`);
		return this;
	}
	/**
	* Match only rows where `column` matches the PostgreSQL regex `pattern`
	* case-sensitively (using the `~` operator).
	*
	* @param column - The column to filter on
	* @param pattern - The PostgreSQL regular expression pattern to match with
	*/
	regexMatch(column, pattern) {
		this.url.searchParams.append(column, `match.${pattern}`);
		return this;
	}
	/**
	* Match only rows where `column` matches the PostgreSQL regex `pattern`
	* case-insensitively (using the `~*` operator).
	*
	* @param column - The column to filter on
	* @param pattern - The PostgreSQL regular expression pattern to match with
	*/
	regexIMatch(column, pattern) {
		this.url.searchParams.append(column, `imatch.${pattern}`);
		return this;
	}
	/**
	* Match only rows where `column` IS `value`.
	*
	* For non-boolean columns, this is only relevant for checking if the value of
	* `column` is NULL by setting `value` to `null`.
	*
	* For boolean columns, you can also set `value` to `true` or `false` and it
	* will behave the same way as `.eq()`.
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @exampleDescription Checking for nullness, true or false
	* Using the `eq()` filter doesn't work when filtering for `null`.
	*
	* Instead, you need to use `is()`.
	*
	* @example Checking for nullness, true or false
	* ```ts
	* const { data, error } = await supabase
	*   .from('countries')
	*   .select()
	*   .is('name', null)
	* ```
	*
	* @exampleSql Checking for nullness, true or false
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	*
	* insert into
	*   countries (id, name)
	* values
	*   (1, 'null'),
	*   (2, null);
	* ```
	*
	* @exampleResponse Checking for nullness, true or false
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 2,
	*       "name": "null"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	is(column, value) {
		this.url.searchParams.append(column, `is.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` IS DISTINCT FROM `value`.
	*
	* Unlike `.neq()`, this treats `NULL` as a comparable value. Two `NULL` values
	* are considered equal (not distinct), and comparing `NULL` with any non-NULL
	* value returns true (distinct).
	*
	* @param column - The column to filter on
	* @param value - The value to filter with
	*/
	isDistinct(column, value) {
		this.url.searchParams.append(column, `isdistinct.${value}`);
		return this;
	}
	/**
	* Match only rows where `column` is included in the `values` array.
	*
	* @param column - The column to filter on
	* @param values - The values array to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .in('name', ['Leia', 'Han'])
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 2,
	*       "name": "Leia"
	*     },
	*     {
	*       "id": 3,
	*       "name": "Han"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	in(column, values) {
		const cleanedValues = Array.from(new Set(values)).map((s) => {
			if (typeof s === "string" && PostgrestReservedCharsRegexp.test(s)) return `"${s}"`;
			else return `${s}`;
		}).join(",");
		this.url.searchParams.append(column, `in.(${cleanedValues})`);
		return this;
	}
	/**
	* Match only rows where `column` is NOT included in the `values` array.
	*
	* @param column - The column to filter on
	* @param values - The values array to filter with
	*/
	notIn(column, values) {
		const cleanedValues = Array.from(new Set(values)).map((s) => {
			if (typeof s === "string" && PostgrestReservedCharsRegexp.test(s)) return `"${s}"`;
			else return `${s}`;
		}).join(",");
		this.url.searchParams.append(column, `not.in.(${cleanedValues})`);
		return this;
	}
	/**
	* Only relevant for jsonb, array, and range columns. Match only rows where
	* `column` contains every element appearing in `value`.
	*
	* @param column - The jsonb, array, or range column to filter on
	* @param value - The jsonb, array, or range value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example On array columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('issues')
	*   .select()
	*   .contains('tags', ['is:open', 'priority:low'])
	* ```
	*
	* @exampleSql On array columns
	* ```sql
	* create table
	*   issues (
	*     id int8 primary key,
	*     title text,
	*     tags text[]
	*   );
	*
	* insert into
	*   issues (id, title, tags)
	* values
	*   (1, 'Cache invalidation is not working', array['is:open', 'severity:high', 'priority:low']),
	*   (2, 'Use better names', array['is:open', 'severity:low', 'priority:medium']);
	* ```
	*
	* @exampleResponse On array columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "title": "Cache invalidation is not working"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription On range columns
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example On range columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .contains('during', '[2000-01-01 13:00, 2000-01-01 13:30)')
	* ```
	*
	* @exampleSql On range columns
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse On range columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "room_name": "Emerald",
	*       "during": "[\"2000-01-01 13:00:00\",\"2000-01-01 15:00:00\")"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example On `jsonb` columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('users')
	*   .select('name')
	*   .contains('address', { postcode: 90210 })
	* ```
	*
	* @exampleSql On `jsonb` columns
	* ```sql
	* create table
	*   users (
	*     id int8 primary key,
	*     name text,
	*     address jsonb
	*   );
	*
	* insert into
	*   users (id, name, address)
	* values
	*   (1, 'Michael', '{ "postcode": 90210, "street": "Melrose Place" }'),
	*   (2, 'Jane', '{}');
	* ```
	*
	* @exampleResponse On `jsonb` columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Michael"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	contains(column, value) {
		if (typeof value === "string") this.url.searchParams.append(column, `cs.${value}`);
		else if (Array.isArray(value)) this.url.searchParams.append(column, `cs.{${value.join(",")}}`);
		else this.url.searchParams.append(column, `cs.${JSON.stringify(value)}`);
		return this;
	}
	/**
	* Only relevant for jsonb, array, and range columns. Match only rows where
	* every element appearing in `column` is contained by `value`.
	*
	* @param column - The jsonb, array, or range column to filter on
	* @param value - The jsonb, array, or range value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example On array columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('classes')
	*   .select('name')
	*   .containedBy('days', ['monday', 'tuesday', 'wednesday', 'friday'])
	* ```
	*
	* @exampleSql On array columns
	* ```sql
	* create table
	*   classes (
	*     id int8 primary key,
	*     name text,
	*     days text[]
	*   );
	*
	* insert into
	*   classes (id, name, days)
	* values
	*   (1, 'Chemistry', array['monday', 'friday']),
	*   (2, 'History', array['monday', 'wednesday', 'thursday']);
	* ```
	*
	* @exampleResponse On array columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Chemistry"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription On range columns
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example On range columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .containedBy('during', '[2000-01-01 00:00, 2000-01-01 23:59)')
	* ```
	*
	* @exampleSql On range columns
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse On range columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "room_name": "Emerald",
	*       "during": "[\"2000-01-01 13:00:00\",\"2000-01-01 15:00:00\")"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example On `jsonb` columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('users')
	*   .select('name')
	*   .containedBy('address', {})
	* ```
	*
	* @exampleSql On `jsonb` columns
	* ```sql
	* create table
	*   users (
	*     id int8 primary key,
	*     name text,
	*     address jsonb
	*   );
	*
	* insert into
	*   users (id, name, address)
	* values
	*   (1, 'Michael', '{ "postcode": 90210, "street": "Melrose Place" }'),
	*   (2, 'Jane', '{}');
	* ```
	*
	* @exampleResponse On `jsonb` columns
	* ```json
	*   {
	*     "data": [
	*       {
	*         "name": "Jane"
	*       }
	*     ],
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*
	* ```
	*/
	containedBy(column, value) {
		if (typeof value === "string") this.url.searchParams.append(column, `cd.${value}`);
		else if (Array.isArray(value)) this.url.searchParams.append(column, `cd.{${value.join(",")}}`);
		else this.url.searchParams.append(column, `cd.${JSON.stringify(value)}`);
		return this;
	}
	/**
	* Only relevant for range columns. Match only rows where every element in
	* `column` is greater than any element in `range`.
	*
	* @param column - The range column to filter on
	* @param range - The range to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @exampleDescription With `select()`
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .rangeGt('during', '[2000-01-02 08:00, 2000-01-02 09:00)')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	*   {
	*     "data": [
	*       {
	*         "id": 2,
	*         "room_name": "Topaz",
	*         "during": "[\"2000-01-02 09:00:00\",\"2000-01-02 10:00:00\")"
	*       }
	*     ],
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*
	* ```
	*/
	rangeGt(column, range) {
		this.url.searchParams.append(column, `sr.${range}`);
		return this;
	}
	/**
	* Only relevant for range columns. Match only rows where every element in
	* `column` is either contained in `range` or greater than any element in
	* `range`.
	*
	* @param column - The range column to filter on
	* @param range - The range to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @exampleDescription With `select()`
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .rangeGte('during', '[2000-01-02 08:30, 2000-01-02 09:30)')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	*   {
	*     "data": [
	*       {
	*         "id": 2,
	*         "room_name": "Topaz",
	*         "during": "[\"2000-01-02 09:00:00\",\"2000-01-02 10:00:00\")"
	*       }
	*     ],
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*
	* ```
	*/
	rangeGte(column, range) {
		this.url.searchParams.append(column, `nxl.${range}`);
		return this;
	}
	/**
	* Only relevant for range columns. Match only rows where every element in
	* `column` is less than any element in `range`.
	*
	* @param column - The range column to filter on
	* @param range - The range to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @exampleDescription With `select()`
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .rangeLt('during', '[2000-01-01 15:00, 2000-01-01 16:00)')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "room_name": "Emerald",
	*       "during": "[\"2000-01-01 13:00:00\",\"2000-01-01 15:00:00\")"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	rangeLt(column, range) {
		this.url.searchParams.append(column, `sl.${range}`);
		return this;
	}
	/**
	* Only relevant for range columns. Match only rows where every element in
	* `column` is either contained in `range` or less than any element in
	* `range`.
	*
	* @param column - The range column to filter on
	* @param range - The range to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @exampleDescription With `select()`
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .rangeLte('during', '[2000-01-01 14:00, 2000-01-01 16:00)')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	*   {
	*     "data": [
	*       {
	*         "id": 1,
	*         "room_name": "Emerald",
	*         "during": "[\"2000-01-01 13:00:00\",\"2000-01-01 15:00:00\")"
	*       }
	*     ],
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*
	* ```
	*/
	rangeLte(column, range) {
		this.url.searchParams.append(column, `nxr.${range}`);
		return this;
	}
	/**
	* Only relevant for range columns. Match only rows where `column` is
	* mutually exclusive to `range` and there can be no element between the two
	* ranges.
	*
	* @param column - The range column to filter on
	* @param range - The range to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @exampleDescription With `select()`
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .rangeAdjacent('during', '[2000-01-01 12:00, 2000-01-01 13:00)')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "room_name": "Emerald",
	*       "during": "[\"2000-01-01 13:00:00\",\"2000-01-01 15:00:00\")"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	rangeAdjacent(column, range) {
		this.url.searchParams.append(column, `adj.${range}`);
		return this;
	}
	/**
	* Only relevant for array and range columns. Match only rows where
	* `column` and `value` have an element in common.
	*
	* @param column - The array or range column to filter on
	* @param value - The array or range value to filter with
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example On array columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('issues')
	*   .select('title')
	*   .overlaps('tags', ['is:closed', 'severity:high'])
	* ```
	*
	* @exampleSql On array columns
	* ```sql
	* create table
	*   issues (
	*     id int8 primary key,
	*     title text,
	*     tags text[]
	*   );
	*
	* insert into
	*   issues (id, title, tags)
	* values
	*   (1, 'Cache invalidation is not working', array['is:open', 'severity:high', 'priority:low']),
	*   (2, 'Use better names', array['is:open', 'severity:low', 'priority:medium']);
	* ```
	*
	* @exampleResponse On array columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "title": "Cache invalidation is not working"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription On range columns
	* Postgres supports a number of [range
	* types](https://www.postgresql.org/docs/current/rangetypes.html). You
	* can filter on range columns using the string representation of range
	* values.
	*
	* @example On range columns
	* ```ts
	* const { data, error } = await supabase
	*   .from('reservations')
	*   .select()
	*   .overlaps('during', '[2000-01-01 12:45, 2000-01-01 13:15)')
	* ```
	*
	* @exampleSql On range columns
	* ```sql
	* create table
	*   reservations (
	*     id int8 primary key,
	*     room_name text,
	*     during tsrange
	*   );
	*
	* insert into
	*   reservations (id, room_name, during)
	* values
	*   (1, 'Emerald', '[2000-01-01 13:00, 2000-01-01 15:00)'),
	*   (2, 'Topaz', '[2000-01-02 09:00, 2000-01-02 10:00)');
	* ```
	*
	* @exampleResponse On range columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "room_name": "Emerald",
	*       "during": "[\"2000-01-01 13:00:00\",\"2000-01-01 15:00:00\")"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	overlaps(column, value) {
		if (typeof value === "string") this.url.searchParams.append(column, `ov.${value}`);
		else this.url.searchParams.append(column, `ov.{${value.join(",")}}`);
		return this;
	}
	/**
	* Only relevant for text and tsvector columns. Match only rows where
	* `column` matches the query string in `query`.
	*
	* @param column - The text or tsvector column to filter on
	* @param query - The query text to match with
	* @param options - Named parameters
	* @param options.config - The text search configuration to use
	* @param options.type - Change how the `query` text is interpreted
	*
	* @category Database
	* @subcategory Using filters
	*
	* @remarks
	* - For more information, see [Postgres full text search](/docs/guides/database/full-text-search).
	*
	* @example Text search
	* ```ts
	* const result = await supabase
	*   .from("texts")
	*   .select("content")
	*   .textSearch("content", `'eggs' & 'ham'`, {
	*     config: "english",
	*   });
	* ```
	*
	* @exampleSql Text search
	* ```sql
	* create table texts (
	*   id      bigint
	*           primary key
	*           generated always as identity,
	*   content text
	* );
	*
	* insert into texts (content) values
	*     ('Four score and seven years ago'),
	*     ('The road goes ever on and on'),
	*     ('Green eggs and ham')
	* ;
	* ```
	*
	* @exampleResponse Text search
	* ```json
	* {
	*   "data": [
	*     {
	*       "content": "Green eggs and ham"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Basic normalization
	* Uses PostgreSQL's `plainto_tsquery` function.
	*
	* @example Basic normalization
	* ```ts
	* const { data, error } = await supabase
	*   .from('quotes')
	*   .select('catchphrase')
	*   .textSearch('catchphrase', `'fat' & 'cat'`, {
	*     type: 'plain',
	*     config: 'english'
	*   })
	* ```
	*
	* @exampleDescription Full normalization
	* Uses PostgreSQL's `phraseto_tsquery` function.
	*
	* @example Full normalization
	* ```ts
	* const { data, error } = await supabase
	*   .from('quotes')
	*   .select('catchphrase')
	*   .textSearch('catchphrase', `'fat' & 'cat'`, {
	*     type: 'phrase',
	*     config: 'english'
	*   })
	* ```
	*
	* @exampleDescription Websearch
	* Uses PostgreSQL's `websearch_to_tsquery` function.
	* This function will never raise syntax errors, which makes it possible to use raw user-supplied input for search, and can be used
	* with advanced operators.
	*
	* - `unquoted text`: text not inside quote marks will be converted to terms separated by & operators, as if processed by plainto_tsquery.
	* - `"quoted text"`: text inside quote marks will be converted to terms separated by `<->` operators, as if processed by phraseto_tsquery.
	* - `OR`: the word “or” will be converted to the | operator.
	* - `-`: a dash will be converted to the ! operator.
	*
	* @example Websearch
	* ```ts
	* const { data, error } = await supabase
	*   .from('quotes')
	*   .select('catchphrase')
	*   .textSearch('catchphrase', `'fat or cat'`, {
	*     type: 'websearch',
	*     config: 'english'
	*   })
	* ```
	*/
	textSearch(column, query, { config, type } = {}) {
		let typePart = "";
		if (type === "plain") typePart = "pl";
		else if (type === "phrase") typePart = "ph";
		else if (type === "websearch") typePart = "w";
		const configPart = config === void 0 ? "" : `(${config})`;
		this.url.searchParams.append(column, `${typePart}fts${configPart}.${query}`);
		return this;
	}
	/**
	* Match only rows where each column in `query` keys is equal to its
	* associated value. Shorthand for multiple `.eq()`s.
	*
	* @param query - The object to filter with, with column names as keys mapped
	* to their filter values
	*
	* @category Database
	* @subcategory Using filters
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('name')
	*   .match({ id: 2, name: 'Leia' })
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Leia"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	match(query) {
		Object.entries(query).filter(([_, value]) => value !== void 0).forEach(([column, value]) => {
			this.url.searchParams.append(column, `eq.${value}`);
		});
		return this;
	}
	/**
	* Match only rows which doesn't satisfy the filter.
	*
	* Unlike most filters, `opearator` and `value` are used as-is and need to
	* follow [PostgREST
	* syntax](https://postgrest.org/en/stable/api.html#operators). You also need
	* to make sure they are properly sanitized.
	*
	* @param column - The column to filter on
	* @param operator - The operator to be negated to filter with, following
	* PostgREST syntax
	* @param value - The value to filter with, following PostgREST syntax
	*
	* @category Database
	* @subcategory Using filters
	*
	* @remarks
	* not() expects you to use the raw PostgREST syntax for the filter values.
	*
	* ```ts
	* .not('id', 'in', '(5,6,7)')  // Use `()` for `in` filter
	* .not('arraycol', 'cs', '{"a","b"}')  // Use `cs` for `contains()`, `{}` for array values
	* ```
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('countries')
	*   .select()
	*   .not('name', 'is', null)
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	*
	* insert into
	*   countries (id, name)
	* values
	*   (1, 'null'),
	*   (2, null);
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	*   {
	*     "data": [
	*       {
	*         "id": 1,
	*         "name": "null"
	*       }
	*     ],
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*
	* ```
	*/
	not(column, operator, value) {
		this.url.searchParams.append(column, `not.${operator}.${value}`);
		return this;
	}
	/**
	* Match only rows which satisfy at least one of the filters.
	*
	* Unlike most filters, `filters` is used as-is and needs to follow [PostgREST
	* syntax](https://postgrest.org/en/stable/api.html#operators). You also need
	* to make sure it's properly sanitized.
	*
	* It's currently not possible to do an `.or()` filter across multiple tables.
	*
	* @param filters - The filters to use, following PostgREST syntax
	* @param options - Named parameters
	* @param options.referencedTable - Set this to filter on referenced tables
	* instead of the parent table
	* @param options.foreignTable - Deprecated, use `referencedTable` instead
	*
	* @category Database
	* @subcategory Using filters
	*
	* @remarks
	* or() expects you to use the raw PostgREST syntax for the filter names and values.
	*
	* ```ts
	* .or('id.in.(5,6,7), arraycol.cs.{"a","b"}')  // Use `()` for `in` filter, `{}` for array values and `cs` for `contains()`.
	* .or('id.in.(5,6,7), arraycol.cd.{"a","b"}')  // Use `cd` for `containedBy()`
	* ```
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('name')
	*   .or('id.eq.2,name.eq.Han')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Leia"
	*     },
	*     {
	*       "name": "Han"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example Use `or` with `and`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('name')
	*   .or('id.gt.3,and(id.eq.1,name.eq.Luke)')
	* ```
	*
	* @exampleSql Use `or` with `and`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse Use `or` with `and`
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Luke"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example Use `or` on referenced tables
	* ```ts
	* const { data, error } = await supabase
	*   .from('orchestral_sections')
	*   .select(`
	*     name,
	*     instruments!inner (
	*       name
	*     )
	*   `)
	*   .or('section_id.eq.1,name.eq.guzheng', { referencedTable: 'instruments' })
	* ```
	*
	* @exampleSql Use `or` on referenced tables
	* ```sql
	* create table
	*   orchestral_sections (id int8 primary key, name text);
	* create table
	*   instruments (
	*     id int8 primary key,
	*     section_id int8 not null references orchestral_sections,
	*     name text
	*   );
	*
	* insert into
	*   orchestral_sections (id, name)
	* values
	*   (1, 'strings'),
	*   (2, 'woodwinds');
	* insert into
	*   instruments (id, section_id, name)
	* values
	*   (1, 2, 'flute'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse Use `or` on referenced tables
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "strings",
	*       "instruments": [
	*         {
	*           "name": "violin"
	*         }
	*       ]
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	or(filters, { foreignTable, referencedTable = foreignTable } = {}) {
		const key = referencedTable ? `${referencedTable}.or` : "or";
		this.url.searchParams.append(key, `(${filters})`);
		return this;
	}
	/**
	* Match only rows which satisfy the filter. This is an escape hatch - you
	* should use the specific filter methods wherever possible.
	*
	* Unlike most filters, `opearator` and `value` are used as-is and need to
	* follow [PostgREST
	* syntax](https://postgrest.org/en/stable/api.html#operators). You also need
	* to make sure they are properly sanitized.
	*
	* @param column - The column to filter on
	* @param operator - The operator to filter with, following PostgREST syntax
	* @param value - The value to filter with, following PostgREST syntax
	*
	* @category Database
	* @subcategory Using filters
	*
	* @remarks
	* filter() expects you to use the raw PostgREST syntax for the filter values.
	*
	* ```ts
	* .filter('id', 'in', '(5,6,7)')  // Use `()` for `in` filter
	* .filter('arraycol', 'cs', '{"a","b"}')  // Use `cs` for `contains()`, `{}` for array values
	* ```
	*
	* @example With `select()`
	* ```ts
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	*   .filter('name', 'in', '("Han","Yoda")')
	* ```
	*
	* @exampleSql With `select()`
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse With `select()`
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 3,
	*       "name": "Han"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example On a referenced table
	* ```ts
	* const { data, error } = await supabase
	*   .from('orchestral_sections')
	*   .select(`
	*     name,
	*     instruments!inner (
	*       name
	*     )
	*   `)
	*   .filter('instruments.name', 'eq', 'flute')
	* ```
	*
	* @exampleSql On a referenced table
	* ```sql
	* create table
	*   orchestral_sections (id int8 primary key, name text);
	* create table
	*    instruments (
	*     id int8 primary key,
	*     section_id int8 not null references orchestral_sections,
	*     name text
	*   );
	*
	* insert into
	*   orchestral_sections (id, name)
	* values
	*   (1, 'strings'),
	*   (2, 'woodwinds');
	* insert into
	*   instruments (id, section_id, name)
	* values
	*   (1, 2, 'flute'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse On a referenced table
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "woodwinds",
	*       "instruments": [
	*         {
	*           "name": "flute"
	*         }
	*       ]
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	filter(column, operator, value) {
		this.url.searchParams.append(column, `${operator}.${value}`);
		return this;
	}
};

//#endregion
//#region src/PostgrestQueryBuilder.ts
var PostgrestQueryBuilder = class {
	/**
	* Creates a query builder scoped to a Postgres table or view.
	*
	* @category Database
	*
	* @param url - The URL for the query
	* @param options - Named parameters
	* @param options.headers - Custom headers
	* @param options.schema - Postgres schema to use
	* @param options.fetch - Custom fetch implementation
	* @param options.urlLengthLimit - Maximum URL length before warning
	* @param options.retry - Enable automatic retries for transient errors (default: true)
	*
	* @example Using supabase-js (recommended)
	* ```ts
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	* const { data, error } = await supabase.from('users').select('*')
	* ```
	*
	* @example Standalone import for bundle-sensitive environments
	* ```ts
	* import { PostgrestQueryBuilder } from '@supabase/postgrest-js'
	*
	* const query = new PostgrestQueryBuilder(
	*   new URL('https://xyzcompany.supabase.co/rest/v1/users'),
	*   { headers: { apikey: 'your-publishable-key' }, retry: true }
	* )
	* ```
	*/
	constructor(url, { headers = {}, schema, fetch: fetch$1, urlLengthLimit = 8e3, retry }) {
		this.url = url;
		this.headers = new Headers(headers);
		this.schema = schema;
		this.fetch = fetch$1;
		this.urlLengthLimit = urlLengthLimit;
		this.retry = retry;
	}
	/**
	* Clone URL and headers to prevent shared state between operations.
	*/
	cloneRequestState() {
		return {
			url: new URL(this.url.toString()),
			headers: new Headers(this.headers)
		};
	}
	/**
	* Perform a SELECT query on the table or view.
	*
	* @param columns - The columns to retrieve, separated by commas. Columns can be renamed when returned with `customName:columnName`
	*
	* @param options - Named parameters
	*
	* @param options.head - When set to `true`, `data` will not be returned.
	* Useful if you only need the count.
	*
	* @param options.count - Count algorithm to use to count rows in the table or view.
	*
	* `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
	* hood.
	*
	* `"planned"`: Approximated but fast count algorithm. Uses the Postgres
	* statistics under the hood.
	*
	* `"estimated"`: Uses exact count for low numbers and planned count for high
	* numbers.
	*
	* @remarks
	* When using `count` with `.range()` or `.limit()`, the returned `count` is the total number of rows
	* that match your filters, not the number of rows in the current page. Use this to build pagination UI.
	
	* - By default, Supabase projects return a maximum of 1,000 rows. This setting can be changed in your project's [API settings](/dashboard/project/_/settings/api). It's recommended that you keep it low to limit the payload size of accidental or malicious requests. You can use `range()` queries to paginate through your data.
	* - `select()` can be combined with [Filters](/docs/reference/javascript/using-filters)
	* - `select()` can be combined with [Modifiers](/docs/reference/javascript/using-modifiers)
	* - `apikey` is a reserved keyword if you're using the [Supabase Platform](/docs/guides/platform) and [should be avoided as a column name](https://github.com/supabase/supabase/issues/5465). *
	* @category Database
	*
	* @example Getting your data
	* ```js
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select()
	* ```
	*
	* @exampleSql Getting your data
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Harry'),
	*   (2, 'Frodo'),
	*   (3, 'Katniss');
	* ```
	*
	* @exampleResponse Getting your data
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Harry"
	*     },
	*     {
	*       "id": 2,
	*       "name": "Frodo"
	*     },
	*     {
	*       "id": 3,
	*       "name": "Katniss"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Handling errors
	* The most useful field on a Postgres error is usually `hint` — when the database knows the fix, it puts the literal SQL there. For example, a permission-denied error (`code: '42501'`) arrives with a `hint` like `"Grant the required privileges to the current role with: GRANT SELECT ON public.characters TO anon;"`. Log the full `error` object so the hint isn't hidden behind `error.message`.
	*
	* @example Handling errors
	* ```js
	* const { data, error } = await supabase.from('characters').select()
	* if (error) {
	*   // Logs the full error: message, code, details, and hint.
	*   console.error(error)
	*   return
	* }
	* ```
	*
	* @exampleResponse Handling errors
	* ```json
	* {
	*   "error": {
	*     "code": "42501",
	*     "details": null,
	*     "hint": "Grant the required privileges to the current role with: GRANT SELECT ON public.characters TO anon;",
	*     "message": "permission denied for table characters"
	*   },
	*   "status": 401,
	*   "statusText": "Unauthorized"
	* }
	* ```
	*
	* @example Selecting specific columns
	* ```js
	* const { data, error } = await supabase
	*   .from('characters')
	*   .select('name')
	* ```
	*
	* @exampleSql Selecting specific columns
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Frodo'),
	*   (2, 'Harry'),
	*   (3, 'Katniss');
	* ```
	*
	* @exampleResponse Selecting specific columns
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "Frodo"
	*     },
	*     {
	*       "name": "Harry"
	*     },
	*     {
	*       "name": "Katniss"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Query referenced tables
	* If your database has foreign key relationships, you can query related tables too.
	*
	* @example Query referenced tables
	* ```js
	* const { data, error } = await supabase
	*   .from('orchestral_sections')
	*   .select(`
	*     name,
	*     instruments (
	*       name
	*     )
	*   `)
	* ```
	*
	* @exampleSql Query referenced tables
	* ```sql
	* create table
	*   orchestral_sections (id int8 primary key, name text);
	* create table
	*   instruments (
	*     id int8 primary key,
	*     section_id int8 not null references orchestral_sections,
	*     name text
	*   );
	*
	* insert into
	*   orchestral_sections (id, name)
	* values
	*   (1, 'strings'),
	*   (2, 'woodwinds');
	* insert into
	*   instruments (id, section_id, name)
	* values
	*   (1, 2, 'flute'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse Query referenced tables
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "strings",
	*       "instruments": [
	*         {
	*           "name": "violin"
	*         }
	*       ]
	*     },
	*     {
	*       "name": "woodwinds",
	*       "instruments": [
	*         {
	*           "name": "flute"
	*         }
	*       ]
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Query referenced tables with spaces in their names
	* If your table name contains spaces, you must use double quotes in the `select` statement to reference the table.
	*
	* @example Query referenced tables with spaces in their names
	* ```js
	* const { data, error } = await supabase
	*   .from('orchestral sections')
	*   .select(`
	*     name,
	*     "musical instruments" (
	*       name
	*     )
	*   `)
	* ```
	*
	* @exampleSql Query referenced tables with spaces in their names
	* ```sql
	* create table
	*   "orchestral sections" (id int8 primary key, name text);
	* create table
	*   "musical instruments" (
	*     id int8 primary key,
	*     section_id int8 not null references "orchestral sections",
	*     name text
	*   );
	*
	* insert into
	*   "orchestral sections" (id, name)
	* values
	*   (1, 'strings'),
	*   (2, 'woodwinds');
	* insert into
	*   "musical instruments" (id, section_id, name)
	* values
	*   (1, 2, 'flute'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse Query referenced tables with spaces in their names
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "strings",
	*       "musical instruments": [
	*         {
	*           "name": "violin"
	*         }
	*       ]
	*     },
	*     {
	*       "name": "woodwinds",
	*       "musical instruments": [
	*         {
	*           "name": "flute"
	*         }
	*       ]
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Query referenced tables through a join table
	* If you're in a situation where your tables are **NOT** directly
	* related, but instead are joined by a _join table_, you can still use
	* the `select()` method to query the related data. The join table needs
	* to have the foreign keys as part of its composite primary key.
	*
	* @example Query referenced tables through a join table
	* ```ts
	* const { data, error } = await supabase
	*   .from('users')
	*   .select(`
	*     name,
	*     teams (
	*       name
	*     )
	*   `)
	*   
	* ```
	*
	* @exampleSql Query referenced tables through a join table
	* ```sql
	* create table
	*   users (
	*     id int8 primary key,
	*     name text
	*   );
	* create table
	*   teams (
	*     id int8 primary key,
	*     name text
	*   );
	* -- join table
	* create table
	*   users_teams (
	*     user_id int8 not null references users,
	*     team_id int8 not null references teams,
	*     -- both foreign keys must be part of a composite primary key
	*     primary key (user_id, team_id)
	*   );
	*
	* insert into
	*   users (id, name)
	* values
	*   (1, 'Kiran'),
	*   (2, 'Evan');
	* insert into
	*   teams (id, name)
	* values
	*   (1, 'Green'),
	*   (2, 'Blue');
	* insert into
	*   users_teams (user_id, team_id)
	* values
	*   (1, 1),
	*   (1, 2),
	*   (2, 2);
	* ```
	*
	* @exampleResponse Query referenced tables through a join table
	* ```json
	*   {
	*     "data": [
	*       {
	*         "name": "Kiran",
	*         "teams": [
	*           {
	*             "name": "Green"
	*           },
	*           {
	*             "name": "Blue"
	*           }
	*         ]
	*       },
	*       {
	*         "name": "Evan",
	*         "teams": [
	*           {
	*             "name": "Blue"
	*           }
	*         ]
	*       }
	*     ],
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*   
	* ```
	*
	* @exampleDescription Query the same referenced table multiple times
	* If you need to query the same referenced table twice, use the name of the
	* joined column to identify which join to use. You can also give each
	* column an alias.
	*
	* @example Query the same referenced table multiple times
	* ```ts
	* const { data, error } = await supabase
	*   .from('messages')
	*   .select(`
	*     content,
	*     from:sender_id(name),
	*     to:receiver_id(name)
	*   `)
	*
	* // To infer types, use the name of the table (in this case `users`) and
	* // the name of the foreign key constraint.
	* const { data, error } = await supabase
	*   .from('messages')
	*   .select(`
	*     content,
	*     from:users!messages_sender_id_fkey(name),
	*     to:users!messages_receiver_id_fkey(name)
	*   `)
	* ```
	*
	* @exampleSql Query the same referenced table multiple times
	* ```sql
	*  create table
	*  users (id int8 primary key, name text);
	*
	*  create table
	*    messages (
	*      sender_id int8 not null references users,
	*      receiver_id int8 not null references users,
	*      content text
	*    );
	*
	*  insert into
	*    users (id, name)
	*  values
	*    (1, 'Kiran'),
	*    (2, 'Evan');
	*
	*  insert into
	*    messages (sender_id, receiver_id, content)
	*  values
	*    (1, 2, '👋');
	*  ```
	* ```
	*
	* @exampleResponse Query the same referenced table multiple times
	* ```json
	* {
	*   "data": [
	*     {
	*       "content": "👋",
	*       "from": {
	*         "name": "Kiran"
	*       },
	*       "to": {
	*         "name": "Evan"
	*       }
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Query nested foreign tables through a join table
	* You can use the result of a joined table to gather data in
	* another foreign table. With multiple references to the same foreign
	* table you must specify the column on which to conduct the join.
	*
	* @example Query nested foreign tables through a join table
	* ```ts
	*   const { data, error } = await supabase
	*     .from('games')
	*     .select(`
	*       game_id:id,
	*       away_team:teams!games_away_team_fkey (
	*         users (
	*           id,
	*           name
	*         )
	*       )
	*     `)
	*   
	* ```
	*
	* @exampleSql Query nested foreign tables through a join table
	* ```sql
	* ```sql
	* create table
	*   users (
	*     id int8 primary key,
	*     name text
	*   );
	* create table
	*   teams (
	*     id int8 primary key,
	*     name text
	*   );
	* -- join table
	* create table
	*   users_teams (
	*     user_id int8 not null references users,
	*     team_id int8 not null references teams,
	*
	*     primary key (user_id, team_id)
	*   );
	* create table
	*   games (
	*     id int8 primary key,
	*     home_team int8 not null references teams,
	*     away_team int8 not null references teams,
	*     name text
	*   );
	*
	* insert into users (id, name)
	* values
	*   (1, 'Kiran'),
	*   (2, 'Evan');
	* insert into
	*   teams (id, name)
	* values
	*   (1, 'Green'),
	*   (2, 'Blue');
	* insert into
	*   users_teams (user_id, team_id)
	* values
	*   (1, 1),
	*   (1, 2),
	*   (2, 2);
	* insert into
	*   games (id, home_team, away_team, name)
	* values
	*   (1, 1, 2, 'Green vs Blue'),
	*   (2, 2, 1, 'Blue vs Green');
	* ```
	*
	* @exampleResponse Query nested foreign tables through a join table
	* ```json
	*   {
	*     "data": [
	*       {
	*         "game_id": 1,
	*         "away_team": {
	*           "users": [
	*             {
	*               "id": 1,
	*               "name": "Kiran"
	*             },
	*             {
	*               "id": 2,
	*               "name": "Evan"
	*             }
	*           ]
	*         }
	*       },
	*       {
	*         "game_id": 2,
	*         "away_team": {
	*           "users": [
	*             {
	*               "id": 1,
	*               "name": "Kiran"
	*             }
	*           ]
	*         }
	*       }
	*     ],
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*   
	* ```
	*
	* @exampleDescription Filtering through referenced tables
	* If the filter on a referenced table's column is not satisfied, the referenced
	* table returns `[]` or `null` but the parent table is not filtered out.
	* If you want to filter out the parent table rows, use the `!inner` hint
	*
	* @example Filtering through referenced tables
	* ```ts
	* const { data, error } = await supabase
	*   .from('instruments')
	*   .select('name, orchestral_sections(*)')
	*   .eq('orchestral_sections.name', 'percussion')
	* ```
	*
	* @exampleSql Filtering through referenced tables
	* ```sql
	* create table
	*   orchestral_sections (id int8 primary key, name text);
	* create table
	*   instruments (
	*     id int8 primary key,
	*     section_id int8 not null references orchestral_sections,
	*     name text
	*   );
	*
	* insert into
	*   orchestral_sections (id, name)
	* values
	*   (1, 'strings'),
	*   (2, 'woodwinds');
	* insert into
	*   instruments (id, section_id, name)
	* values
	*   (1, 2, 'flute'),
	*   (2, 1, 'violin');
	* ```
	*
	* @exampleResponse Filtering through referenced tables
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "flute",
	*       "orchestral_sections": null
	*     },
	*     {
	*       "name": "violin",
	*       "orchestral_sections": null
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Querying referenced table with count
	* You can get the number of rows in a related table by using the
	* **count** property.
	*
	* @example Querying referenced table with count
	* ```ts
	* const { data, error } = await supabase
	*   .from('orchestral_sections')
	*   .select(`*, instruments(count)`)
	* ```
	*
	* @exampleSql Querying referenced table with count
	* ```sql
	* create table orchestral_sections (
	*   "id" "uuid" primary key default "extensions"."uuid_generate_v4"() not null,
	*   "name" text
	* );
	*
	* create table characters (
	*   "id" "uuid" primary key default "extensions"."uuid_generate_v4"() not null,
	*   "name" text,
	*   "section_id" "uuid" references public.orchestral_sections on delete cascade
	* );
	*
	* with section as (
	*   insert into orchestral_sections (name)
	*   values ('strings') returning id
	* )
	* insert into instruments (name, section_id) values
	* ('violin', (select id from section)),
	* ('viola', (select id from section)),
	* ('cello', (select id from section)),
	* ('double bass', (select id from section));
	* ```
	*
	* @exampleResponse Querying referenced table with count
	* ```json
	* [
	*   {
	*     "id": "693694e7-d993-4360-a6d7-6294e325d9b6",
	*     "name": "strings",
	*     "instruments": [
	*       {
	*         "count": 4
	*       }
	*     ]
	*   }
	* ]
	* ```
	*
	* @exampleDescription Querying with count option
	* You can get the number of rows by using the
	* [count](/docs/reference/javascript/select#parameters) option.
	*
	* @example Querying with count option
	* ```ts
	* const { count, error } = await supabase
	*   .from('characters')
	*   .select('*', { count: 'exact', head: true })
	* ```
	*
	* @exampleSql Querying with count option
	* ```sql
	* create table
	*   characters (id int8 primary key, name text);
	*
	* insert into
	*   characters (id, name)
	* values
	*   (1, 'Luke'),
	*   (2, 'Leia'),
	*   (3, 'Han');
	* ```
	*
	* @exampleResponse Querying with count option
	* ```json
	* {
	*   "count": 3,
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Querying JSON data
	* You can select and filter data inside of
	* [JSON](/docs/guides/database/json) columns. Postgres offers some
	* [operators](/docs/guides/database/json#query-the-jsonb-data) for
	* querying JSON data.
	*
	* @example Querying JSON data
	* ```ts
	* const { data, error } = await supabase
	*   .from('users')
	*   .select(`
	*     id, name,
	*     address->city
	*   `)
	* ```
	*
	* @exampleSql Querying JSON data
	* ```sql
	* create table
	*   users (
	*     id int8 primary key,
	*     name text,
	*     address jsonb
	*   );
	*
	* insert into
	*   users (id, name, address)
	* values
	*   (1, 'Frodo', '{"city":"Hobbiton"}');
	* ```
	*
	* @exampleResponse Querying JSON data
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Frodo",
	*       "city": "Hobbiton"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Querying referenced table with inner join
	* If you don't want to return the referenced table contents, you can leave the parenthesis empty.
	* Like `.select('name, orchestral_sections!inner()')`.
	*
	* @example Querying referenced table with inner join
	* ```ts
	* const { data, error } = await supabase
	*   .from('instruments')
	*   .select('name, orchestral_sections!inner(name)')
	*   .eq('orchestral_sections.name', 'woodwinds')
	*   .limit(1)
	* ```
	*
	* @exampleSql Querying referenced table with inner join
	* ```sql
	* create table orchestral_sections (
	*   "id" "uuid" primary key default "extensions"."uuid_generate_v4"() not null,
	*   "name" text
	* );
	*
	* create table instruments (
	*   "id" "uuid" primary key default "extensions"."uuid_generate_v4"() not null,
	*   "name" text,
	*   "section_id" "uuid" references public.orchestral_sections on delete cascade
	* );
	*
	* with section as (
	*   insert into orchestral_sections (name)
	*   values ('woodwinds') returning id
	* )
	* insert into instruments (name, section_id) values
	* ('flute', (select id from section)),
	* ('clarinet', (select id from section)),
	* ('bassoon', (select id from section)),
	* ('piccolo', (select id from section));
	* ```
	*
	* @exampleResponse Querying referenced table with inner join
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "flute",
	*       "orchestral_sections": {"name": "woodwinds"}
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Switching schemas per query
	* In addition to setting the schema during initialization, you can also switch schemas on a per-query basis.
	* Make sure you've set up your [database privileges and API settings](/docs/guides/api/using-custom-schemas).
	*
	* @example Switching schemas per query
	* ```ts
	* const { data, error } = await supabase
	*   .schema('myschema')
	*   .from('mytable')
	*   .select()
	* ```
	*
	* @exampleSql Switching schemas per query
	* ```sql
	* create schema myschema;
	*
	* create table myschema.mytable (
	*   id uuid primary key default gen_random_uuid(),
	*   data text
	* );
	*
	* insert into myschema.mytable (data) values ('mydata');
	* ```
	*
	* @exampleResponse Switching schemas per query
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": "4162e008-27b0-4c0f-82dc-ccaeee9a624d",
	*       "data": "mydata"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	select(columns, options) {
		const { head = false, count } = options !== null && options !== void 0 ? options : {};
		const method = head ? "HEAD" : "GET";
		let quoted = false;
		const cleanedColumns = (columns !== null && columns !== void 0 ? columns : "*").split("").map((c) => {
			if (/\s/.test(c) && !quoted) return "";
			if (c === "\"") quoted = !quoted;
			return c;
		}).join("");
		const { url, headers } = this.cloneRequestState();
		url.searchParams.set("select", cleanedColumns);
		if (count) headers.append("Prefer", `count=${count}`);
		return new PostgrestFilterBuilder({
			method,
			url,
			headers,
			schema: this.schema,
			fetch: this.fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
	/**
	* Perform an INSERT into the table or view.
	*
	* By default, inserted rows are not returned. To return it, chain the call
	* with `.select()`.
	*
	* @param values - The values to insert. Pass an object to insert a single row
	* or an array to insert multiple rows.
	*
	* @param options - Named parameters
	*
	* @param options.count - Count algorithm to use to count inserted rows.
	*
	* `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
	* hood.
	*
	* `"planned"`: Approximated but fast count algorithm. Uses the Postgres
	* statistics under the hood.
	*
	* `"estimated"`: Uses exact count for low numbers and planned count for high
	* numbers.
	*
	* @param options.defaultToNull - Make missing fields default to `null`.
	* Otherwise, use the default value for the column. Only applies for bulk
	* inserts.
	*
	* @category Database
	*
	* @example Create a record
	* ```ts
	* const { error } = await supabase
	*   .from('countries')
	*   .insert({ id: 1, name: 'Mordor' })
	* ```
	*
	* @exampleSql Create a record
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	* ```
	*
	* @exampleResponse Create a record
	* ```json
	* {
	*   "status": 201,
	*   "statusText": "Created"
	* }
	* ```
	*
	* @exampleDescription Handling errors
	* `error.hint` from Postgres often contains the actionable fix (e.g. `"Grant the required privileges to the current role with: GRANT INSERT ON public.countries TO anon;"` for a `42501` permission-denied error). Log the full `error` object so it isn't hidden behind `error.message`.
	*
	* @example Handling errors
	* ```js
	* const { error } = await supabase.from('countries').insert({ id: 1, name: 'Mordor' })
	* if (error) console.error(error)
	* ```
	*
	* @example Create a record and return it
	* ```ts
	* const { data, error } = await supabase
	*   .from('countries')
	*   .insert({ id: 1, name: 'Mordor' })
	*   .select()
	* ```
	*
	* @exampleSql Create a record and return it
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	* ```
	*
	* @exampleResponse Create a record and return it
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Mordor"
	*     }
	*   ],
	*   "status": 201,
	*   "statusText": "Created"
	* }
	* ```
	*
	* @exampleDescription Bulk create
	* A bulk create operation is handled in a single transaction.
	* If any of the inserts fail, none of the rows are inserted.
	*
	* @example Bulk create
	* ```ts
	* const { error } = await supabase
	*   .from('countries')
	*   .insert([
	*     { id: 1, name: 'Mordor' },
	*     { id: 1, name: 'The Shire' },
	*   ])
	* ```
	*
	* @exampleSql Bulk create
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	* ```
	*
	* @exampleResponse Bulk create
	* ```json
	* {
	*   "error": {
	*     "code": "23505",
	*     "details": "Key (id)=(1) already exists.",
	*     "hint": null,
	*     "message": "duplicate key value violates unique constraint \"countries_pkey\""
	*   },
	*   "status": 409,
	*   "statusText": "Conflict"
	* }
	* ```
	*/
	insert(values, { count, defaultToNull = true } = {}) {
		var _this$fetch;
		const method = "POST";
		const { url, headers } = this.cloneRequestState();
		if (count) headers.append("Prefer", `count=${count}`);
		if (!defaultToNull) headers.append("Prefer", `missing=default`);
		if (Array.isArray(values)) {
			const columns = values.reduce((acc, x) => acc.concat(Object.keys(x)), []);
			if (columns.length > 0) {
				const uniqueColumns = [...new Set(columns)].map((column) => `"${column}"`);
				url.searchParams.set("columns", uniqueColumns.join(","));
			}
		}
		return new PostgrestFilterBuilder({
			method,
			url,
			headers,
			schema: this.schema,
			body: values,
			fetch: (_this$fetch = this.fetch) !== null && _this$fetch !== void 0 ? _this$fetch : fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
	/**
	* Perform an UPSERT on the table or view. Depending on the column(s) passed
	* to `onConflict`, `.upsert()` allows you to perform the equivalent of
	* `.insert()` if a row with the corresponding `onConflict` columns doesn't
	* exist, or if it does exist, perform an alternative action depending on
	* `ignoreDuplicates`.
	*
	* By default, upserted rows are not returned. To return it, chain the call
	* with `.select()`.
	*
	* @param values - The values to upsert with. Pass an object to upsert a
	* single row or an array to upsert multiple rows.
	*
	* @param options - Named parameters
	*
	* @param options.onConflict - Comma-separated UNIQUE column(s) to specify how
	* duplicate rows are determined. Two rows are duplicates if all the
	* `onConflict` columns are equal.
	*
	* @param options.ignoreDuplicates - If `true`, duplicate rows are ignored. If
	* `false`, duplicate rows are merged with existing rows.
	*
	* @param options.count - Count algorithm to use to count upserted rows.
	*
	* `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
	* hood.
	*
	* `"planned"`: Approximated but fast count algorithm. Uses the Postgres
	* statistics under the hood.
	*
	* `"estimated"`: Uses exact count for low numbers and planned count for high
	* numbers.
	*
	* @param options.defaultToNull - Make missing fields default to `null`.
	* Otherwise, use the default value for the column. This only applies when
	* inserting new rows, not when merging with existing rows under
	* `ignoreDuplicates: false`. This also only applies when doing bulk upserts.
	*
	* @example Upsert a single row using a unique key
	* ```ts
	* // Upserting a single row, overwriting based on the 'username' unique column
	* const { data, error } = await supabase
	*   .from('users')
	*   .upsert({ username: 'supabot' }, { onConflict: 'username' })
	*
	* // Example response:
	* // {
	* //   data: [
	* //     { id: 4, message: 'bar', username: 'supabot' }
	* //   ],
	* //   error: null
	* // }
	* ```
	*
	* @example Upsert with conflict resolution and exact row counting
	* ```ts
	* // Upserting and returning exact count
	* const { data, error, count } = await supabase
	*   .from('users')
	*   .upsert(
	*     {
	*       id: 3,
	*       message: 'foo',
	*       username: 'supabot'
	*     },
	*     {
	*       onConflict: 'username',
	*       count: 'exact'
	*     }
	*   )
	*
	* // Example response:
	* // {
	* //   data: [
	* //     {
	* //       id: 42,
	* //       handle: "saoirse",
	* //       display_name: "Saoirse"
	* //     }
	* //   ],
	* //   count: 1,
	* //   error: null
	* // }
	* ```
	*
	* @category Database
	*
	* @remarks
	* - Primary keys must be included in `values` to use upsert.
	*
	* @example Upsert your data
	* ```ts
	* const { data, error } = await supabase
	*   .from('instruments')
	*   .upsert({ id: 1, name: 'piano' })
	*   .select()
	* ```
	*
	* @exampleSql Upsert your data
	* ```sql
	* create table
	*   instruments (id int8 primary key, name text);
	*
	* insert into
	*   instruments (id, name)
	* values
	*   (1, 'harpsichord');
	* ```
	*
	* @exampleResponse Upsert your data
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "piano"
	*     }
	*   ],
	*   "status": 201,
	*   "statusText": "Created"
	* }
	* ```
	*
	* @exampleDescription Handling errors
	* `error.hint` from Postgres often contains the actionable fix (e.g. `"Grant the required privileges to the current role with: GRANT INSERT, UPDATE ON public.instruments TO anon;"` for a `42501` permission-denied error). Log the full `error` object so it isn't hidden behind `error.message`.
	*
	* @example Handling errors
	* ```js
	* const { data, error } = await supabase.from('instruments').upsert({ id: 1, name: 'piano' }).select()
	* if (error) console.error(error)
	* ```
	*
	* @example Bulk Upsert your data
	* ```ts
	* const { data, error } = await supabase
	*   .from('instruments')
	*   .upsert([
	*     { id: 1, name: 'piano' },
	*     { id: 2, name: 'harp' },
	*   ])
	*   .select()
	* ```
	*
	* @exampleSql Bulk Upsert your data
	* ```sql
	* create table
	*   instruments (id int8 primary key, name text);
	*
	* insert into
	*   instruments (id, name)
	* values
	*   (1, 'harpsichord');
	* ```
	*
	* @exampleResponse Bulk Upsert your data
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "piano"
	*     },
	*     {
	*       "id": 2,
	*       "name": "harp"
	*     }
	*   ],
	*   "status": 201,
	*   "statusText": "Created"
	* }
	* ```
	*
	* @exampleDescription Upserting into tables with constraints
	* In the following query, `upsert()` implicitly uses the `id`
	* (primary key) column to determine conflicts. If there is no existing
	* row with the same `id`, `upsert()` inserts a new row, which
	* will fail in this case as there is already a row with `handle` `"saoirse"`.
	* Using the `onConflict` option, you can instruct `upsert()` to use
	* another column with a unique constraint to determine conflicts.
	*
	* @example Upserting into tables with constraints
	* ```ts
	* const { data, error } = await supabase
	*   .from('users')
	*   .upsert({ id: 42, handle: 'saoirse', display_name: 'Saoirse' })
	*   .select()
	* ```
	*
	* @exampleSql Upserting into tables with constraints
	* ```sql
	* create table
	*   users (
	*     id int8 generated by default as identity primary key,
	*     handle text not null unique,
	*     display_name text
	*   );
	*
	* insert into
	*   users (id, handle, display_name)
	* values
	*   (1, 'saoirse', null);
	* ```
	*
	* @exampleResponse Upserting into tables with constraints
	* ```json
	* {
	*   "error": {
	*     "code": "23505",
	*     "details": "Key (handle)=(saoirse) already exists.",
	*     "hint": null,
	*     "message": "duplicate key value violates unique constraint \"users_handle_key\""
	*   },
	*   "status": 409,
	*   "statusText": "Conflict"
	* }
	* ```
	*/
	upsert(values, { onConflict, ignoreDuplicates = false, count, defaultToNull = true } = {}) {
		var _this$fetch2;
		const method = "POST";
		const { url, headers } = this.cloneRequestState();
		headers.append("Prefer", `resolution=${ignoreDuplicates ? "ignore" : "merge"}-duplicates`);
		if (onConflict !== void 0) url.searchParams.set("on_conflict", onConflict);
		if (count) headers.append("Prefer", `count=${count}`);
		if (!defaultToNull) headers.append("Prefer", "missing=default");
		if (Array.isArray(values)) {
			const columns = values.reduce((acc, x) => acc.concat(Object.keys(x)), []);
			if (columns.length > 0) {
				const uniqueColumns = [...new Set(columns)].map((column) => `"${column}"`);
				url.searchParams.set("columns", uniqueColumns.join(","));
			}
		}
		return new PostgrestFilterBuilder({
			method,
			url,
			headers,
			schema: this.schema,
			body: values,
			fetch: (_this$fetch2 = this.fetch) !== null && _this$fetch2 !== void 0 ? _this$fetch2 : fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
	/**
	* Perform an UPDATE on the table or view.
	*
	* By default, updated rows are not returned. To return it, chain the call
	* with `.select()` after filters.
	*
	* @param values - The values to update with
	*
	* @param options - Named parameters
	*
	* @param options.count - Count algorithm to use to count updated rows.
	*
	* `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
	* hood.
	*
	* `"planned"`: Approximated but fast count algorithm. Uses the Postgres
	* statistics under the hood.
	*
	* `"estimated"`: Uses exact count for low numbers and planned count for high
	* numbers.
	*
	* @category Database
	*
	* @remarks
	* - `update()` should always be combined with [Filters](/docs/reference/javascript/using-filters) to target the item(s) you wish to update.
	*
	* @example Updating your data
	* ```ts
	* const { error } = await supabase
	*   .from('instruments')
	*   .update({ name: 'piano' })
	*   .eq('id', 1)
	* ```
	*
	* @exampleSql Updating your data
	* ```sql
	* create table
	*   instruments (id int8 primary key, name text);
	*
	* insert into
	*   instruments (id, name)
	* values
	*   (1, 'harpsichord');
	* ```
	*
	* @exampleResponse Updating your data
	* ```json
	* {
	*   "status": 204,
	*   "statusText": "No Content"
	* }
	* ```
	*
	* @exampleDescription Handling errors
	* `error.hint` from Postgres often contains the actionable fix (e.g. `"Grant the required privileges to the current role with: GRANT UPDATE ON public.instruments TO anon;"` for a `42501` permission-denied error). Log the full `error` object so it isn't hidden behind `error.message`.
	*
	* @example Handling errors
	* ```js
	* const { error } = await supabase.from('instruments').update({ name: 'piano' }).eq('id', 1)
	* if (error) console.error(error)
	* ```
	*
	* @example Update a record and return it
	* ```ts
	* const { data, error } = await supabase
	*   .from('instruments')
	*   .update({ name: 'piano' })
	*   .eq('id', 1)
	*   .select()
	* ```
	*
	* @exampleSql Update a record and return it
	* ```sql
	* create table
	*   instruments (id int8 primary key, name text);
	*
	* insert into
	*   instruments (id, name)
	* values
	*   (1, 'harpsichord');
	* ```
	*
	* @exampleResponse Update a record and return it
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "piano"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Updating JSON data
	* Postgres offers some
	* [operators](/docs/guides/database/json#query-the-jsonb-data) for
	* working with JSON data. Currently, it is only possible to update the entire JSON document.
	*
	* @example Updating JSON data
	* ```ts
	* const { data, error } = await supabase
	*   .from('users')
	*   .update({
	*     address: {
	*       street: 'Melrose Place',
	*       postcode: 90210
	*     }
	*   })
	*   .eq('address->postcode', 90210)
	*   .select()
	* ```
	*
	* @exampleSql Updating JSON data
	* ```sql
	* create table
	*   users (
	*     id int8 primary key,
	*     name text,
	*     address jsonb
	*   );
	*
	* insert into
	*   users (id, name, address)
	* values
	*   (1, 'Michael', '{ "postcode": 90210 }');
	* ```
	*
	* @exampleResponse Updating JSON data
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Michael",
	*       "address": {
	*         "street": "Melrose Place",
	*         "postcode": 90210
	*       }
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	update(values, { count } = {}) {
		var _this$fetch3;
		const method = "PATCH";
		const { url, headers } = this.cloneRequestState();
		if (count) headers.append("Prefer", `count=${count}`);
		return new PostgrestFilterBuilder({
			method,
			url,
			headers,
			schema: this.schema,
			body: values,
			fetch: (_this$fetch3 = this.fetch) !== null && _this$fetch3 !== void 0 ? _this$fetch3 : fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
	/**
	* Perform a DELETE on the table or view.
	*
	* By default, deleted rows are not returned. To return it, chain the call
	* with `.select()` after filters.
	*
	* @param options - Named parameters
	*
	* @param options.count - Count algorithm to use to count deleted rows.
	*
	* `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
	* hood.
	*
	* `"planned"`: Approximated but fast count algorithm. Uses the Postgres
	* statistics under the hood.
	*
	* `"estimated"`: Uses exact count for low numbers and planned count for high
	* numbers.
	*
	* @category Database
	*
	* @remarks
	* - `delete()` should always be combined with [filters](/docs/reference/javascript/using-filters) to target the item(s) you wish to delete.
	* - If you use `delete()` with filters and you have
	*   [RLS](/docs/learn/auth-deep-dive/auth-row-level-security) enabled, only
	*   rows visible through `SELECT` policies are deleted. Note that by default
	*   no rows are visible, so you need at least one `SELECT`/`ALL` policy that
	*   makes the rows visible.
	* - When using `delete().in()`, specify an array of values to target multiple rows with a single query. This is particularly useful for batch deleting entries that share common criteria, such as deleting users by their IDs. Ensure that the array you provide accurately represents all records you intend to delete to avoid unintended data removal.
	*
	* @example Delete a single record
	* ```ts
	* const response = await supabase
	*   .from('countries')
	*   .delete()
	*   .eq('id', 1)
	* ```
	*
	* @exampleSql Delete a single record
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	*
	* insert into
	*   countries (id, name)
	* values
	*   (1, 'Mordor');
	* ```
	*
	* @exampleResponse Delete a single record
	* ```json
	* {
	*   "status": 204,
	*   "statusText": "No Content"
	* }
	* ```
	*
	* @exampleDescription Handling errors
	* `error.hint` from Postgres often contains the actionable fix (e.g. `"Grant the required privileges to the current role with: GRANT DELETE ON public.countries TO anon;"` for a `42501` permission-denied error). Log the full `error` object so it isn't hidden behind `error.message`.
	*
	* @example Handling errors
	* ```js
	* const { error } = await supabase.from('countries').delete().eq('id', 1)
	* if (error) console.error(error)
	* ```
	*
	* @example Delete a record and return it
	* ```ts
	* const { data, error } = await supabase
	*   .from('countries')
	*   .delete()
	*   .eq('id', 1)
	*   .select()
	* ```
	*
	* @exampleSql Delete a record and return it
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	*
	* insert into
	*   countries (id, name)
	* values
	*   (1, 'Mordor');
	* ```
	*
	* @exampleResponse Delete a record and return it
	* ```json
	* {
	*   "data": [
	*     {
	*       "id": 1,
	*       "name": "Mordor"
	*     }
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example Delete multiple records
	* ```ts
	* const response = await supabase
	*   .from('countries')
	*   .delete()
	*   .in('id', [1, 2, 3])
	* ```
	*
	* @exampleSql Delete multiple records
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	*
	* insert into
	*   countries (id, name)
	* values
	*   (1, 'Rohan'), (2, 'The Shire'), (3, 'Mordor');
	* ```
	*
	* @exampleResponse Delete multiple records
	* ```json
	* {
	*   "status": 204,
	*   "statusText": "No Content"
	* }
	* ```
	*/
	delete({ count } = {}) {
		var _this$fetch4;
		const method = "DELETE";
		const { url, headers } = this.cloneRequestState();
		if (count) headers.append("Prefer", `count=${count}`);
		return new PostgrestFilterBuilder({
			method,
			url,
			headers,
			schema: this.schema,
			fetch: (_this$fetch4 = this.fetch) !== null && _this$fetch4 !== void 0 ? _this$fetch4 : fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
};

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/typeof.js
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o$1) {
		return typeof o$1;
	} : function(o$1) {
		return o$1 && "function" == typeof Symbol && o$1.constructor === Symbol && o$1 !== Symbol.prototype ? "symbol" : typeof o$1;
	}, _typeof(o);
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/toPrimitive.js
function toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/toPropertyKey.js
function toPropertyKey(t) {
	var i = toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/defineProperty.js
function _defineProperty(e, r, t) {
	return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/objectSpread2.js
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r$1) {
			return Object.getOwnPropertyDescriptor(e, r$1).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r$1) {
			_defineProperty(e, r$1, t[r$1]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r$1) {
			Object.defineProperty(e, r$1, Object.getOwnPropertyDescriptor(t, r$1));
		});
	}
	return e;
}

//#endregion
//#region src/PostgrestClient.ts
/**
* PostgREST client.
*
* @typeParam Database - Types for the schema from the [type
* generator](https://supabase.com/docs/reference/javascript/next/typescript-support)
*
* @typeParam SchemaName - Postgres schema to switch to. Must be a string
* literal, the same one passed to the constructor. If the schema is not
* `"public"`, this must be supplied manually.
*/
var PostgrestClient = class PostgrestClient {
	/**
	* Creates a PostgREST client.
	*
	* @param url - URL of the PostgREST endpoint
	* @param options - Named parameters
	* @param options.headers - Custom headers
	* @param options.schema - Postgres schema to switch to
	* @param options.fetch - Custom fetch
	* @param options.timeout - Optional timeout in milliseconds for all requests. When set, requests will automatically abort after this duration to prevent indefinite hangs.
	* @param options.urlLengthLimit - Maximum URL length in characters before warnings/errors are triggered. Defaults to 8000.
	* @param options.retry - Enable or disable automatic retries for transient errors.
	*   When enabled, idempotent requests (GET, HEAD, OPTIONS) that fail with network
	*   errors or HTTP 503/520 responses will be automatically retried up to 3 times
	*   with exponential backoff (1s, 2s, 4s). Defaults to `true`.
	* @example Using supabase-js (recommended)
	* ```ts
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	* const { data, error } = await supabase.from('profiles').select('*')
	* ```
	*
	* @category Database
	*
	* @remarks
	* - A `timeout` option (in milliseconds) can be set to automatically abort requests that take too long.
	* - A `urlLengthLimit` option (default: 8000) can be set to control when URL length warnings are included in error messages for aborted requests.
	*
	* @example Standalone import for bundle-sensitive environments
	* ```ts
	* import { PostgrestClient } from '@supabase/postgrest-js'
	*
	* const postgrest = new PostgrestClient('https://xyzcompany.supabase.co/rest/v1', {
	*   headers: { apikey: 'your-publishable-key' },
	*   schema: 'public',
	*   timeout: 30000, // 30 second timeout
	* })
	* ```
	*/
	constructor(url, { headers = {}, schema, fetch: fetch$1, timeout, urlLengthLimit = 8e3, retry } = {}) {
		this.url = url;
		this.headers = new Headers(headers);
		this.schemaName = schema;
		this.urlLengthLimit = urlLengthLimit;
		const originalFetch = fetch$1 !== null && fetch$1 !== void 0 ? fetch$1 : globalThis.fetch;
		if (timeout !== void 0 && timeout > 0) this.fetch = (input, init) => {
			const controller = new AbortController();
			const timeoutId = setTimeout(() => controller.abort(), timeout);
			const existingSignal = init === null || init === void 0 ? void 0 : init.signal;
			if (existingSignal) {
				if (existingSignal.aborted) {
					clearTimeout(timeoutId);
					return originalFetch(input, init);
				}
				const abortHandler = () => {
					clearTimeout(timeoutId);
					controller.abort();
				};
				existingSignal.addEventListener("abort", abortHandler, { once: true });
				return originalFetch(input, _objectSpread2(_objectSpread2({}, init), {}, { signal: controller.signal })).finally(() => {
					clearTimeout(timeoutId);
					existingSignal.removeEventListener("abort", abortHandler);
				});
			}
			return originalFetch(input, _objectSpread2(_objectSpread2({}, init), {}, { signal: controller.signal })).finally(() => clearTimeout(timeoutId));
		};
		else this.fetch = originalFetch;
		this.retry = retry;
	}
	/**
	* Perform a query on a table or a view.
	*
	* @param relation - The table or view name to query
	*
	* @category Database
	*/
	from(relation) {
		if (!relation || typeof relation !== "string" || relation.trim() === "") throw new Error("Invalid relation name: relation must be a non-empty string.");
		return new PostgrestQueryBuilder(new URL(`${this.url}/${relation}`), {
			headers: new Headers(this.headers),
			schema: this.schemaName,
			fetch: this.fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
	/**
	* Select a schema to query or perform an function (rpc) call.
	*
	* The schema needs to be on the list of exposed schemas inside Supabase.
	*
	* @param schema - The schema to query
	*
	* @category Database
	*/
	schema(schema) {
		return new PostgrestClient(this.url, {
			headers: this.headers,
			schema,
			fetch: this.fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
	/**
	* Perform a function call.
	*
	* @param fn - The function name to call
	* @param args - The arguments to pass to the function call
	* @param options - Named parameters
	* @param options.head - When set to `true`, `data` will not be returned.
	* Useful if you only need the count.
	* @param options.get - When set to `true`, the function will be called with
	* read-only access mode.
	* @param options.count - Count algorithm to use to count rows returned by the
	* function. Only applicable for [set-returning
	* functions](https://www.postgresql.org/docs/current/functions-srf.html).
	*
	* `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
	* hood.
	*
	* `"planned"`: Approximated but fast count algorithm. Uses the Postgres
	* statistics under the hood.
	*
	* `"estimated"`: Uses exact count for low numbers and planned count for high
	* numbers.
	*
	* @example
	* ```ts
	* // For cross-schema functions where type inference fails, use overrideTypes:
	* const { data } = await supabase
	*   .schema('schema_b')
	*   .rpc('function_a', {})
	*   .overrideTypes<{ id: string; user_id: string }[]>()
	* ```
	*
	* @category Database
	*
	* @example Call a Postgres function without arguments
	* ```ts
	* const { data, error } = await supabase.rpc('hello_world')
	* ```
	*
	* @exampleSql Call a Postgres function without arguments
	* ```sql
	* create function hello_world() returns text as $$
	*   select 'Hello world';
	* $$ language sql;
	* ```
	*
	* @exampleResponse Call a Postgres function without arguments
	* ```json
	* {
	*   "data": "Hello world",
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example Call a Postgres function with arguments
	* ```ts
	* const { data, error } = await supabase.rpc('echo', { say: '👋' })
	* ```
	*
	* @exampleSql Call a Postgres function with arguments
	* ```sql
	* create function echo(say text) returns text as $$
	*   select say;
	* $$ language sql;
	* ```
	*
	* @exampleResponse Call a Postgres function with arguments
	* ```json
	*   {
	*     "data": "👋",
	*     "status": 200,
	*     "statusText": "OK"
	*   }
	*
	* ```
	*
	* @exampleDescription Bulk processing
	* You can process large payloads by passing in an array as an argument.
	*
	* @example Bulk processing
	* ```ts
	* const { data, error } = await supabase.rpc('add_one_each', { arr: [1, 2, 3] })
	* ```
	*
	* @exampleSql Bulk processing
	* ```sql
	* create function add_one_each(arr int[]) returns int[] as $$
	*   select array_agg(n + 1) from unnest(arr) as n;
	* $$ language sql;
	* ```
	*
	* @exampleResponse Bulk processing
	* ```json
	* {
	*   "data": [
	*     2,
	*     3,
	*     4
	*   ],
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @exampleDescription Call a Postgres function with filters
	* Postgres functions that return tables can also be combined with [Filters](/docs/reference/javascript/using-filters) and [Modifiers](/docs/reference/javascript/using-modifiers).
	*
	* @example Call a Postgres function with filters
	* ```ts
	* const { data, error } = await supabase
	*   .rpc('list_stored_countries')
	*   .eq('id', 1)
	*   .single()
	* ```
	*
	* @exampleSql Call a Postgres function with filters
	* ```sql
	* create table
	*   countries (id int8 primary key, name text);
	*
	* insert into
	*   countries (id, name)
	* values
	*   (1, 'Rohan'),
	*   (2, 'The Shire');
	*
	* create function list_stored_countries() returns setof countries as $$
	*   select * from countries;
	* $$ language sql;
	* ```
	*
	* @exampleResponse Call a Postgres function with filters
	* ```json
	* {
	*   "data": {
	*     "id": 1,
	*     "name": "Rohan"
	*   },
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*
	* @example Call a read-only Postgres function
	* ```ts
	* const { data, error } = await supabase.rpc('hello_world', undefined, { get: true })
	* ```
	*
	* @exampleSql Call a read-only Postgres function
	* ```sql
	* create function hello_world() returns text as $$
	*   select 'Hello world';
	* $$ language sql;
	* ```
	*
	* @exampleResponse Call a read-only Postgres function
	* ```json
	* {
	*   "data": "Hello world",
	*   "status": 200,
	*   "statusText": "OK"
	* }
	* ```
	*/
	rpc(fn, args = {}, { head = false, get = false, count } = {}) {
		var _this$fetch;
		let method;
		const url = new URL(`${this.url}/rpc/${fn}`);
		let body;
		const _isObject = (v) => v !== null && typeof v === "object" && (!Array.isArray(v) || v.some(_isObject));
		const _hasObjectArg = head && Object.values(args).some(_isObject);
		if (_hasObjectArg) {
			method = "POST";
			body = args;
		} else if (head || get) {
			method = head ? "HEAD" : "GET";
			Object.entries(args).filter(([_, value]) => value !== void 0).map(([name, value]) => [name, Array.isArray(value) ? `{${value.join(",")}}` : `${value}`]).forEach(([name, value]) => {
				url.searchParams.append(name, value);
			});
		} else {
			method = "POST";
			body = args;
		}
		const headers = new Headers(this.headers);
		if (_hasObjectArg) headers.set("Prefer", count ? `count=${count},return=minimal` : "return=minimal");
		else if (count) headers.set("Prefer", `count=${count}`);
		return new PostgrestFilterBuilder({
			method,
			url,
			headers,
			schema: this.schemaName,
			body,
			fetch: (_this$fetch = this.fetch) !== null && _this$fetch !== void 0 ? _this$fetch : fetch,
			urlLengthLimit: this.urlLengthLimit,
			retry: this.retry
		});
	}
};

//#endregion
//#region src/index.ts
var src_default = {
	PostgrestClient,
	PostgrestQueryBuilder,
	PostgrestFilterBuilder,
	PostgrestTransformBuilder,
	PostgrestBuilder,
	PostgrestError
};

//#endregion
export { PostgrestBuilder, PostgrestClient, PostgrestError, PostgrestFilterBuilder, PostgrestQueryBuilder, PostgrestTransformBuilder, src_default as default };
                                  
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXgubWpzIiwibmFtZXMiOlsiaGVhZGVyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiIsInJlczogUmVzcG9uc2UiLCJ0aGlzIiwiZmV0Y2hFcnJvcjogYW55IiwicmVzIiwiY291bnQ6IG51bWJlciB8IG51bGwiLCJmZXRjaCIsImZldGNoIiwibWV0aG9kOiAnSEVBRCcgfCAnR0VUJyB8ICdQT1NUJyIsImJvZHk6IHVua25vd24gfCB1bmRlZmluZWQiXSwic291cmNlcyI6WyIuLi9zcmMvdHlwZXMvY29tbW9uL2NvbW1vbi50cyIsIi4uL3NyYy9Qb3N0Z3Jlc3RFcnJvci50cyIsIi4uL3NyYy9Qb3N0Z3Jlc3RCdWlsZGVyLnRzIiwiLi4vc3JjL1Bvc3RncmVzdFRyYW5zZm9ybUJ1aWxkZXIudHMiLCIuLi9zcmMvUG9zdGdyZXN0RmlsdGVyQnVpbGRlci50cyIsIi4uL3NyYy9Qb3N0Z3Jlc3RRdWVyeUJ1aWxkZXIudHMiLCIuLi9zcmMvUG9zdGdyZXN0Q2xpZW50LnRzIiwiLi4vc3JjL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFR5cGVzIHRoYXQgYXJlIHNoYXJlZCBiZXR3ZWVuIHN1cGFiYXNlLWpzIGFuZCBwb3N0Z3Jlc3QtanNcblxuZXhwb3J0IHR5cGUgRmV0Y2ggPSB0eXBlb2YgZmV0Y2hcblxuLyoqXG4gKiBEZWZhdWx0IG51bWJlciBvZiByZXRyeSBhdHRlbXB0cy5cbiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfTUFYX1JFVFJJRVMgPSAzXG5cbi8qKlxuICogRGVmYXVsdCBleHBvbmVudGlhbCBiYWNrb2ZmIGRlbGF5IGZ1bmN0aW9uLlxuICogRGVsYXlzOiAxcywgMnMsIDRzLCA4cywgLi4uIChtYXggMzBzKVxuICpcbiAqIEBwYXJhbSBhdHRlbXB0SW5kZXggLSBaZXJvLWJhc2VkIGluZGV4IG9mIHRoZSByZXRyeSBhdHRlbXB0XG4gKiBAcmV0dXJucyBEZWxheSBpbiBtaWxsaXNlY29uZHMgYmVmb3JlIHRoZSBuZXh0IHJldHJ5XG4gKi9cbmV4cG9ydCBjb25zdCBnZXRSZXRyeURlbGF5ID0gKGF0dGVtcHRJbmRleDogbnVtYmVyKTogbnVtYmVyID0+XG4gIE1hdGgubWluKDEwMDAgKiAyICoqIGF0dGVtcHRJbmRleCwgMzAwMDApXG5cbi8qKlxuICogU3RhdHVzIGNvZGVzIHRoYXQgYXJlIHNhZmUgdG8gcmV0cnkuXG4gKiA1MjAgPSBDbG91ZGZsYXJlIHRpbWVvdXQvY29ubmVjdGlvbiBlcnJvcnMgKHRyYW5zaWVudClcbiAqIDUwMyA9IFBvc3RnUkVTVCBzY2hlbWEgY2FjaGUgbm90IHlldCBsb2FkZWQgKHRyYW5zaWVudCwgc2lnbmFscyByZXRyeSB2aWEgUmV0cnktQWZ0ZXIgaGVhZGVyKVxuICovXG5leHBvcnQgY29uc3QgUkVUUllBQkxFX1NUQVRVU19DT0RFUyA9IFs1MjAsIDUwM10gYXMgY29uc3RcblxuLyoqXG4gKiBIVFRQIG1ldGhvZHMgdGhhdCBhcmUgc2FmZSB0byByZXRyeSAoaWRlbXBvdGVudCBvcGVyYXRpb25zKS5cbiAqL1xuZXhwb3J0IGNvbnN0IFJFVFJZQUJMRV9NRVRIT0RTID0gWydHRVQnLCAnSEVBRCcsICdPUFRJT05TJ10gYXMgY29uc3RcblxuZXhwb3J0IHR5cGUgR2VuZXJpY1JlbGF0aW9uc2hpcCA9IHtcbiAgZm9yZWlnbktleU5hbWU6IHN0cmluZ1xuICBjb2x1bW5zOiBzdHJpbmdbXVxuICBpc09uZVRvT25lPzogYm9vbGVhblxuICByZWZlcmVuY2VkUmVsYXRpb246IHN0cmluZ1xuICByZWZlcmVuY2VkQ29sdW1uczogc3RyaW5nW11cbn1cblxuZXhwb3J0IHR5cGUgR2VuZXJpY1RhYmxlID0ge1xuICBSb3c6IFJlY29yZDxzdHJpbmcsIHVua25vd24+XG4gIEluc2VydDogUmVjb3JkPHN0cmluZywgdW5rbm93bj5cbiAgVXBkYXRlOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuICBSZWxhdGlvbnNoaXBzOiBHZW5lcmljUmVsYXRpb25zaGlwW11cbn1cblxuZXhwb3J0IHR5cGUgR2VuZXJpY1VwZGF0YWJsZVZpZXcgPSB7XG4gIFJvdzogUmVjb3JkPHN0cmluZywgdW5rbm93bj5cbiAgSW5zZXJ0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuICBVcGRhdGU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+XG4gIFJlbGF0aW9uc2hpcHM6IEdlbmVyaWNSZWxhdGlvbnNoaXBbXVxufVxuXG5leHBvcnQgdHlwZSBHZW5lcmljTm9uVXBkYXRhYmxlVmlldyA9IHtcbiAgUm93OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuICBSZWxhdGlvbnNoaXBzOiBHZW5lcmljUmVsYXRpb25zaGlwW11cbn1cblxuZXhwb3J0IHR5cGUgR2VuZXJpY1ZpZXcgPSBHZW5lcmljVXBkYXRhYmxlVmlldyB8IEdlbmVyaWNOb25VcGRhdGFibGVWaWV3XG5cbmV4cG9ydCB0eXBlIEdlbmVyaWNTZXRvZk9wdGlvbiA9IHtcbiAgaXNTZXRvZlJldHVybj86IGJvb2xlYW4gfCB1bmRlZmluZWRcbiAgaXNPbmVUb09uZT86IGJvb2xlYW4gfCB1bmRlZmluZWRcbiAgaXNOb3ROdWxsYWJsZT86IGJvb2xlYW4gfCB1bmRlZmluZWRcbiAgdG86IHN0cmluZ1xuICBmcm9tOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgR2VuZXJpY0Z1bmN0aW9uID0ge1xuICBBcmdzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG5ldmVyXG4gIFJldHVybnM6IHVua25vd25cbiAgU2V0b2ZPcHRpb25zPzogR2VuZXJpY1NldG9mT3B0aW9uXG59XG5cbmV4cG9ydCB0eXBlIEdlbmVyaWNTY2hlbWEgPSB7XG4gIFRhYmxlczogUmVjb3JkPHN0cmluZywgR2VuZXJpY1RhYmxlPlxuICBWaWV3czogUmVjb3JkPHN0cmluZywgR2VuZXJpY1ZpZXc+XG4gIEZ1bmN0aW9uczogUmVjb3JkPHN0cmluZywgR2VuZXJpY0Z1bmN0aW9uPlxufVxuXG5leHBvcnQgdHlwZSBDbGllbnRTZXJ2ZXJPcHRpb25zID0ge1xuICBQb3N0Z3Jlc3RWZXJzaW9uPzogc3RyaW5nXG59XG4iLCIvKipcbiAqIEVycm9yIGZvcm1hdFxuICpcbiAqIFJldHVybmVkIGJ5IGV2ZXJ5IFBvc3RnUkVTVCByZXF1ZXN0IHRoYXQgZmFpbHMuIFdoZW4gc29tZXRoaW5nIGZhaWxzLCB0aGVcbiAqIHNpbmdsZSBtb3N0IHVzZWZ1bCBmaWVsZCBpcyB1c3VhbGx5IGBoaW50YCDigJQgUG9zdGdyZXMgb2Z0ZW4gcmV0dXJucyB0aGVcbiAqIGFjdGlvbmFibGUgZml4IHRoZXJlLCBub3QgaW4gYG1lc3NhZ2VgLiBBbHdheXMgbG9nIHRoZSBmdWxsIG9iamVjdCAoZS5nLlxuICogYGNvbnNvbGUuZXJyb3IoZXJyb3IpYCk7IGxvZ2dpbmcgb25seSBgZXJyb3IubWVzc2FnZWAgaGlkZXMgdGhlIGhpbnQuXG4gKlxuICogUmVhZCB0aGUgZmllbGRzIGluIHJvdWdobHkgdGhpcyBvcmRlciBvZiB1c2VmdWxuZXNzOlxuICpcbiAqIC0gYGhpbnRgIOKAlCBhY3Rpb25hYmxlIGd1aWRhbmNlIGZyb20gdGhlIGRhdGFiYXNlIHdoZW4gYXZhaWxhYmxlLiBGb3JcbiAqICAgcGVybWlzc2lvbi1kZW5pZWQgZXJyb3JzIChgNDI1MDFgKSwgdGhpcyBpcyB0aGUgbGl0ZXJhbCBTUUwgdG8gZml4IHRoZVxuICogICBwcm9ibGVtLCBlLmcuXG4gKiAgIGBcIkdyYW50IHRoZSByZXF1aXJlZCBwcml2aWxlZ2VzIHRvIHRoZSBjdXJyZW50IHJvbGUgd2l0aDogR1JBTlQgU0VMRUNUIE9OIHB1YmxpYy51c2VycyBUTyBhbm9uO1wiYC5cbiAqICAgTWlzc2luZyBjb2x1bW4/IGBoaW50YCBzdWdnZXN0cyB0aGUgY29sdW1uIHlvdSBwcm9iYWJseSBtZWFudC4gV2hlbmV2ZXJcbiAqICAgUG9zdGdyZXMga25vd3MgdGhlIGZpeCwgaXQgcHV0cyBpdCBpbiBgaGludGAuXG4gKiAtIGBjb2RlYCDigJQgc3RhYmxlIGVycm9yIGNvZGUgZnJvbSBQb3N0Z1JFU1QgKGUuZy4gYFBHUlNUMzAxYCkgb3IgUG9zdGdyZXNcbiAqICAgKGUuZy4gYDQyNTAxYCkuIEJyYW5jaCBvbiB0aGlzIHJhdGhlciB0aGFuIG9uIGBtZXNzYWdlYCB0ZXh0LlxuICogLSBgZGV0YWlsc2Ag4oCUIGV4dHJhIGNvbnRleHQsIG9mdGVuIHRoZSBvZmZlbmRpbmcgdmFsdWUsIGtleSwgb3Igcm93LlxuICogLSBgbWVzc2FnZWAg4oCUIGh1bWFuLXJlYWRhYmxlIHN1bW1hcnkuIFVzZWZ1bCBpbiBVSSBzdHJpbmdzOyBsZXNzIHVzZWZ1bFxuICogICBmb3IgZGVidWdnaW5nLlxuICpcbiAqIHtAbGluayBodHRwczovL3Bvc3RncmVzdC5vcmcvZW4vc3RhYmxlL2FwaS5odG1sP2hpZ2hsaWdodD1vcHRpb25zI2Vycm9ycy1hbmQtaHR0cC1zdGF0dXMtY29kZXN9XG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFBvc3RncmVzdEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBkZXRhaWxzOiBzdHJpbmdcbiAgaGludDogc3RyaW5nXG4gIGNvZGU6IHN0cmluZ1xuXG4gIC8qKlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgUG9zdGdyZXN0RXJyb3IgZnJvbSAnQHN1cGFiYXNlL3Bvc3RncmVzdC1qcydcbiAgICpcbiAgICogdGhyb3cgbmV3IFBvc3RncmVzdEVycm9yKHtcbiAgICogICBtZXNzYWdlOiAnUm93IGxldmVsIHNlY3VyaXR5IHByZXZlbnRlZCB0aGUgcmVxdWVzdCcsXG4gICAqICAgZGV0YWlsczogJ1JMUyBkZW5pZWQgdGhlIGluc2VydCcsXG4gICAqICAgaGludDogJ0NoZWNrIHlvdXIgcG9saWNpZXMnLFxuICAgKiAgIGNvZGU6ICdQR1JTVDMwMScsXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgY29uc3RydWN0b3IoY29udGV4dDogeyBtZXNzYWdlOiBzdHJpbmc7IGRldGFpbHM6IHN0cmluZzsgaGludDogc3RyaW5nOyBjb2RlOiBzdHJpbmcgfSkge1xuICAgIHN1cGVyKGNvbnRleHQubWVzc2FnZSlcbiAgICB0aGlzLm5hbWUgPSAnUG9zdGdyZXN0RXJyb3InXG4gICAgdGhpcy5kZXRhaWxzID0gY29udGV4dC5kZXRhaWxzXG4gICAgdGhpcy5oaW50ID0gY29udGV4dC5oaW50XG4gICAgdGhpcy5jb2RlID0gY29udGV4dC5jb2RlXG4gIH1cblxuICB0b0pTT04oKTogeyBuYW1lOiBzdHJpbmc7IG1lc3NhZ2U6IHN0cmluZzsgZGV0YWlsczogc3RyaW5nOyBoaW50OiBzdHJpbmc7IGNvZGU6IHN0cmluZyB9IHtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgbWVzc2FnZTogdGhpcy5tZXNzYWdlLFxuICAgICAgZGV0YWlsczogdGhpcy5kZXRhaWxzLFxuICAgICAgaGludDogdGhpcy5oaW50LFxuICAgICAgY29kZTogdGhpcy5jb2RlLFxuICAgIH1cbiAgfVxufVxuIiwiaW1wb3J0IHR5cGUge1xuICBQb3N0Z3Jlc3RTaW5nbGVSZXNwb25zZSxcbiAgUG9zdGdyZXN0UmVzcG9uc2VTdWNjZXNzLFxuICBDaGVja01hdGNoaW5nQXJyYXlUeXBlcyxcbiAgTWVyZ2VQYXJ0aWFsUmVzdWx0LFxuICBJc1ZhbGlkUmVzdWx0T3ZlcnJpZGUsXG59IGZyb20gJy4vdHlwZXMvdHlwZXMnXG5pbXBvcnQge1xuICBDbGllbnRTZXJ2ZXJPcHRpb25zLFxuICBGZXRjaCxcbiAgREVGQVVMVF9NQVhfUkVUUklFUyxcbiAgZ2V0UmV0cnlEZWxheSxcbiAgUkVUUllBQkxFX1NUQVRVU19DT0RFUyxcbiAgUkVUUllBQkxFX01FVEhPRFMsXG59IGZyb20gJy4vdHlwZXMvY29tbW9uL2NvbW1vbidcbmltcG9ydCBQb3N0Z3Jlc3RFcnJvciBmcm9tICcuL1Bvc3RncmVzdEVycm9yJ1xuaW1wb3J0IHsgQ29udGFpbnNOdWxsIH0gZnJvbSAnLi9zZWxlY3QtcXVlcnktcGFyc2VyL3R5cGVzJ1xuXG4vKipcbiAqIFNsZWVwIGZvciBhIGdpdmVuIG51bWJlciBvZiBtaWxsaXNlY29uZHMuXG4gKiBJZiBhbiBBYm9ydFNpZ25hbCBpcyBwcm92aWRlZCwgdGhlIHNsZWVwIHJlc29sdmVzIGVhcmx5IHdoZW4gdGhlIHNpZ25hbCBpcyBhYm9ydGVkLlxuICovXG5mdW5jdGlvbiBzbGVlcChtczogbnVtYmVyLCBzaWduYWw/OiBBYm9ydFNpZ25hbCk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBpZiAoc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICByZXNvbHZlKClcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBjb25zdCBpZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2lnbmFsPy5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIG9uQWJvcnQpXG4gICAgICByZXNvbHZlKClcbiAgICB9LCBtcylcbiAgICBmdW5jdGlvbiBvbkFib3J0KCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGlkKVxuICAgICAgcmVzb2x2ZSgpXG4gICAgfVxuICAgIHNpZ25hbD8uYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkFib3J0KVxuICB9KVxufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgcmVxdWVzdCBzaG91bGQgYmUgcmV0cmllZCBiYXNlZCBvbiBtZXRob2QgYW5kIHN0YXR1cyBjb2RlLlxuICovXG5mdW5jdGlvbiBzaG91bGRSZXRyeShcbiAgbWV0aG9kOiBzdHJpbmcsXG4gIHN0YXR1czogbnVtYmVyLFxuICBhdHRlbXB0Q291bnQ6IG51bWJlcixcbiAgcmV0cnlFbmFibGVkOiBib29sZWFuXG4pOiBib29sZWFuIHtcbiAgLy8gRG9uJ3QgcmV0cnkgaWYgcmV0cmllcyBhcmUgZGlzYWJsZWQgb3Igd2UndmUgZXhoYXVzdGVkIGF0dGVtcHRzXG4gIGlmICghcmV0cnlFbmFibGVkIHx8IGF0dGVtcHRDb3VudCA+PSBERUZBVUxUX01BWF9SRVRSSUVTKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICAvLyBPbmx5IHJldHJ5IGlkZW1wb3RlbnQgbWV0aG9kcyAoR0VULCBIRUFELCBPUFRJT05TKVxuICBpZiAoIVJFVFJZQUJMRV9NRVRIT0RTLmluY2x1ZGVzKG1ldGhvZCBhcyAodHlwZW9mIFJFVFJZQUJMRV9NRVRIT0RTKVtudW1iZXJdKSkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgLy8gT25seSByZXRyeSBvbiBzcGVjaWZpYyBzdGF0dXMgY29kZXMgKDUyMCAtIENsb3VkZmxhcmUgZXJyb3JzKVxuICBpZiAoIVJFVFJZQUJMRV9TVEFUVVNfQ09ERVMuaW5jbHVkZXMoc3RhdHVzIGFzICh0eXBlb2YgUkVUUllBQkxFX1NUQVRVU19DT0RFUylbbnVtYmVyXSkpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIHJldHVybiB0cnVlXG59XG5cbmV4cG9ydCBkZWZhdWx0IGFic3RyYWN0IGNsYXNzIFBvc3RncmVzdEJ1aWxkZXI8XG4gIENsaWVudE9wdGlvbnMgZXh0ZW5kcyBDbGllbnRTZXJ2ZXJPcHRpb25zLFxuICBSZXN1bHQsXG4gIFRocm93T25FcnJvciBleHRlbmRzIGJvb2xlYW4gPSBmYWxzZSxcbj4gaW1wbGVtZW50cyBQcm9taXNlTGlrZTxcbiAgVGhyb3dPbkVycm9yIGV4dGVuZHMgdHJ1ZSA/IFBvc3RncmVzdFJlc3BvbnNlU3VjY2VzczxSZXN1bHQ+IDogUG9zdGdyZXN0U2luZ2xlUmVzcG9uc2U8UmVzdWx0PlxuPiB7XG4gIHByb3RlY3RlZCBtZXRob2Q6ICdHRVQnIHwgJ0hFQUQnIHwgJ1BPU1QnIHwgJ1BBVENIJyB8ICdERUxFVEUnXG4gIHByb3RlY3RlZCB1cmw6IFVSTFxuICBwcm90ZWN0ZWQgaGVhZGVyczogSGVhZGVyc1xuICBwcm90ZWN0ZWQgc2NoZW1hPzogc3RyaW5nXG4gIHByb3RlY3RlZCBib2R5PzogdW5rbm93blxuICBwcm90ZWN0ZWQgc2hvdWxkVGhyb3dPbkVycm9yID0gZmFsc2VcbiAgcHJvdGVjdGVkIHNpZ25hbD86IEFib3J0U2lnbmFsXG4gIHByb3RlY3RlZCBmZXRjaDogRmV0Y2hcbiAgcHJvdGVjdGVkIGlzTWF5YmVTaW5nbGU6IGJvb2xlYW5cbiAgcHJvdGVjdGVkIHNob3VsZFN0cmlwTnVsbHM6IGJvb2xlYW5cbiAgcHJvdGVjdGVkIHVybExlbmd0aExpbWl0OiBudW1iZXJcblxuICAvLyBSZXRyeSBjb25maWd1cmF0aW9uIC0gZW5hYmxlZCBieSBkZWZhdWx0XG4gIHByb3RlY3RlZCByZXRyeUVuYWJsZWQ6IGJvb2xlYW4gPSB0cnVlXG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBidWlsZGVyIGNvbmZpZ3VyZWQgZm9yIGEgc3BlY2lmaWMgUG9zdGdSRVNUIHJlcXVlc3QuXG4gICAqXG4gICAqIEBleGFtcGxlIFVzaW5nIHN1cGFiYXNlLWpzIChyZWNvbW1lbmRlZClcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3N1cGFiYXNlLWpzJ1xuICAgKlxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudCgnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvJywgJ3lvdXItcHVibGlzaGFibGUta2V5JylcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgndXNlcnMnKS5zZWxlY3QoJyonKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqXG4gICAqIEBleGFtcGxlIFN0YW5kYWxvbmUgaW1wb3J0IGZvciBidW5kbGUtc2Vuc2l0aXZlIGVudmlyb25tZW50c1xuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBQb3N0Z3Jlc3RRdWVyeUJ1aWxkZXIgfSBmcm9tICdAc3VwYWJhc2UvcG9zdGdyZXN0LWpzJ1xuICAgKlxuICAgKiBjb25zdCBidWlsZGVyID0gbmV3IFBvc3RncmVzdFF1ZXJ5QnVpbGRlcihcbiAgICogICBuZXcgVVJMKCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28vcmVzdC92MS91c2VycycpLFxuICAgKiAgIHsgaGVhZGVyczogbmV3IEhlYWRlcnMoeyBhcGlrZXk6ICd5b3VyLXB1Ymxpc2hhYmxlLWtleScgfSkgfVxuICAgKiApXG4gICAqIGBgYFxuICAgKi9cbiAgY29uc3RydWN0b3IoYnVpbGRlcjoge1xuICAgIG1ldGhvZDogJ0dFVCcgfCAnSEVBRCcgfCAnUE9TVCcgfCAnUEFUQ0gnIHwgJ0RFTEVURSdcbiAgICB1cmw6IFVSTFxuICAgIGhlYWRlcnM6IEhlYWRlcnNJbml0XG4gICAgc2NoZW1hPzogc3RyaW5nXG4gICAgYm9keT86IHVua25vd25cbiAgICBzaG91bGRUaHJvd09uRXJyb3I/OiBib29sZWFuXG4gICAgc2lnbmFsPzogQWJvcnRTaWduYWxcbiAgICBmZXRjaD86IEZldGNoXG4gICAgaXNNYXliZVNpbmdsZT86IGJvb2xlYW5cbiAgICBzaG91bGRTdHJpcE51bGxzPzogYm9vbGVhblxuICAgIHVybExlbmd0aExpbWl0PzogbnVtYmVyXG4gICAgLy8gUmV0cnkgb3B0aW9uXG4gICAgcmV0cnk/OiBib29sZWFuXG4gIH0pIHtcbiAgICB0aGlzLm1ldGhvZCA9IGJ1aWxkZXIubWV0aG9kXG4gICAgdGhpcy51cmwgPSBidWlsZGVyLnVybFxuICAgIHRoaXMuaGVhZGVycyA9IG5ldyBIZWFkZXJzKGJ1aWxkZXIuaGVhZGVycylcbiAgICB0aGlzLnNjaGVtYSA9IGJ1aWxkZXIuc2NoZW1hXG4gICAgdGhpcy5ib2R5ID0gYnVpbGRlci5ib2R5XG4gICAgdGhpcy5zaG91bGRUaHJvd09uRXJyb3IgPSBidWlsZGVyLnNob3VsZFRocm93T25FcnJvciA/PyBmYWxzZVxuICAgIHRoaXMuc2lnbmFsID0gYnVpbGRlci5zaWduYWxcbiAgICB0aGlzLmlzTWF5YmVTaW5nbGUgPSBidWlsZGVyLmlzTWF5YmVTaW5nbGUgPz8gZmFsc2VcbiAgICB0aGlzLnNob3VsZFN0cmlwTnVsbHMgPSBidWlsZGVyLnNob3VsZFN0cmlwTnVsbHMgPz8gZmFsc2VcbiAgICB0aGlzLnVybExlbmd0aExpbWl0ID0gYnVpbGRlci51cmxMZW5ndGhMaW1pdCA/PyA4MDAwXG4gICAgdGhpcy5yZXRyeUVuYWJsZWQgPSBidWlsZGVyLnJldHJ5ID8/IHRydWVcblxuICAgIGlmIChidWlsZGVyLmZldGNoKSB7XG4gICAgICB0aGlzLmZldGNoID0gYnVpbGRlci5mZXRjaFxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmZldGNoID0gZmV0Y2hcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogSWYgdGhlcmUncyBhbiBlcnJvciB3aXRoIHRoZSBxdWVyeSwgdGhyb3dPbkVycm9yIHdpbGwgcmVqZWN0IHRoZSBwcm9taXNlIGJ5XG4gICAqIHRocm93aW5nIHRoZSBlcnJvciBpbnN0ZWFkIG9mIHJldHVybmluZyBpdCBhcyBwYXJ0IG9mIGEgc3VjY2Vzc2Z1bCByZXNwb25zZS5cbiAgICpcbiAgICoge0BsaW5rIGh0dHBzOi8vZ2l0aHViLmNvbS9zdXBhYmFzZS9zdXBhYmFzZS1qcy9pc3N1ZXMvOTJ9XG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqL1xuICB0aHJvd09uRXJyb3IoKTogUG9zdGdyZXN0QnVpbGRlcjxDbGllbnRPcHRpb25zLCBSZXN1bHQsIHRydWU+IHtcbiAgICB0aGlzLnNob3VsZFRocm93T25FcnJvciA9IHRydWVcbiAgICByZXR1cm4gdGhpcyBhcyBQb3N0Z3Jlc3RCdWlsZGVyPENsaWVudE9wdGlvbnMsIFJlc3VsdCwgdHJ1ZT5cbiAgfVxuXG4gIC8qKlxuICAgKiBTdHJpcCBudWxsIHZhbHVlcyBmcm9tIHRoZSByZXNwb25zZSBkYXRhLiBQcm9wZXJ0aWVzIHdpdGggYG51bGxgIHZhbHVlc1xuICAgKiB3aWxsIGJlIG9taXR0ZWQgZnJvbSB0aGUgcmV0dXJuZWQgSlNPTiBvYmplY3RzLlxuICAgKlxuICAgKiBSZXF1aXJlcyBQb3N0Z1JFU1QgMTEuMi4wKy5cbiAgICpcbiAgICoge0BsaW5rIGh0dHBzOi8vZG9jcy5wb3N0Z3Jlc3Qub3JnL2VuL3N0YWJsZS9yZWZlcmVuY2VzL2FwaS9yZXNvdXJjZV9yZXByZXNlbnRhdGlvbi5odG1sI3N0cmlwcGVkLW51bGxzfVxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIG1vZGlmaWVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLnN0cmlwTnVsbHMoKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQsIGJpbyB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSwgYmlvKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnLCBudWxsKSxcbiAgICogICAoMiwgJ0xlaWEnLCAnUHJpbmNlc3Mgb2YgQWxkZXJhYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMSxcbiAgICogICAgICAgXCJuYW1lXCI6IFwiTHVrZVwiXG4gICAqICAgICB9LFxuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDIsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIkxlaWFcIixcbiAgICogICAgICAgXCJiaW9cIjogXCJQcmluY2VzcyBvZiBBbGRlcmFhblwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgc3RyaXBOdWxscygpOiB0aGlzIHtcbiAgICBpZiAodGhpcy5oZWFkZXJzLmdldCgnQWNjZXB0JykgPT09ICd0ZXh0L2NzdicpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignc3RyaXBOdWxscygpIGNhbm5vdCBiZSB1c2VkIHdpdGggY3N2KCknKVxuICAgIH1cbiAgICB0aGlzLnNob3VsZFN0cmlwTnVsbHMgPSB0cnVlXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgYW4gSFRUUCBoZWFkZXIgb24gdGhpcyBzaW5nbGUgUG9zdGdSRVNUIHJlcXVlc3QsIG92ZXJyaWRpbmcgYW55IGhlYWRlclxuICAgKiB3aXRoIHRoZSBzYW1lIG5hbWUgc2V0IG9uIHRoZSBjbGllbnQuXG4gICAqXG4gICAqIFRoaXMgaXMgYW4gYWR2YW5jZWQgZXNjYXBlIGhhdGNoIGZvciBvbmUtb2ZmIG5lZWRzIChwYXNzaW5nIGEgY3VzdG9tXG4gICAqIGBBdXRob3JpemF0aW9uYCBmb3IgYSBzaW5nbGUgcXVlcnksIGF0dGFjaGluZyBhIHRyYWNpbmcgaGVhZGVyLCBldGMuKS5cbiAgICogTW9zdCBjYWxsZXJzIGRvIG5vdCBuZWVkIGl0OiBjb25maWd1cmUgY2xpZW50LXdpZGUgaGVhZGVycyB2aWEgdGhlXG4gICAqIGBoZWFkZXJzYCBvcHRpb24gd2hlbiBjb25zdHJ1Y3RpbmcgdGhlIGNsaWVudCwgYW5kIGF1dGhlbnRpY2F0aW9uIHZpYVxuICAgKiBTdXBhYmFzZSBBdXRoLlxuICAgKlxuICAgKiBAcGFyYW0gbmFtZSAtIEhUVFAgaGVhZGVyIG5hbWVcbiAgICogQHBhcmFtIHZhbHVlIC0gSFRUUCBoZWFkZXIgdmFsdWVcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBtb2RpZmllcnNcbiAgICovXG4gIHNldEhlYWRlcihuYW1lOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcpOiB0aGlzIHtcbiAgICB0aGlzLmhlYWRlcnMgPSBuZXcgSGVhZGVycyh0aGlzLmhlYWRlcnMpXG4gICAgdGhpcy5oZWFkZXJzLnNldChuYW1lLCB2YWx1ZSlcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIENvbmZpZ3VyZSByZXRyeSBiZWhhdmlvciBmb3IgdGhpcyByZXF1ZXN0LlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCByZXRyaWVzIGFyZSBlbmFibGVkIGZvciBpZGVtcG90ZW50IHJlcXVlc3RzIChHRVQsIEhFQUQsIE9QVElPTlMpXG4gICAqIHRoYXQgZmFpbCB3aXRoIG5ldHdvcmsgZXJyb3JzIG9yIHNwZWNpZmljIEhUVFAgc3RhdHVzIGNvZGVzICg1MDMsIDUyMCkuXG4gICAqIFJldHJpZXMgdXNlIGV4cG9uZW50aWFsIGJhY2tvZmYgKDFzLCAycywgNHMpIHdpdGggYSBtYXhpbXVtIG9mIDMgYXR0ZW1wdHMuXG4gICAqXG4gICAqIEBwYXJhbSBlbmFibGVkIC0gV2hldGhlciB0byBlbmFibGUgcmV0cmllcyBmb3IgdGhpcyByZXF1ZXN0XG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIERpc2FibGUgcmV0cmllcyBmb3IgYSBzcGVjaWZpYyBxdWVyeVxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCd1c2VycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLnJldHJ5KGZhbHNlKVxuICAgKiBgYGBcbiAgICovXG4gIHJldHJ5KGVuYWJsZWQ6IGJvb2xlYW4pOiB0aGlzIHtcbiAgICB0aGlzLnJldHJ5RW5hYmxlZCA9IGVuYWJsZWRcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgdGhlbjxcbiAgICBUUmVzdWx0MSA9IFRocm93T25FcnJvciBleHRlbmRzIHRydWVcbiAgICAgID8gUG9zdGdyZXN0UmVzcG9uc2VTdWNjZXNzPFJlc3VsdD5cbiAgICAgIDogUG9zdGdyZXN0U2luZ2xlUmVzcG9uc2U8UmVzdWx0PixcbiAgICBUUmVzdWx0MiA9IG5ldmVyLFxuICA+KFxuICAgIG9uZnVsZmlsbGVkPzpcbiAgICAgIHwgKChcbiAgICAgICAgICB2YWx1ZTogVGhyb3dPbkVycm9yIGV4dGVuZHMgdHJ1ZVxuICAgICAgICAgICAgPyBQb3N0Z3Jlc3RSZXNwb25zZVN1Y2Nlc3M8UmVzdWx0PlxuICAgICAgICAgICAgOiBQb3N0Z3Jlc3RTaW5nbGVSZXNwb25zZTxSZXN1bHQ+XG4gICAgICAgICkgPT4gVFJlc3VsdDEgfCBQcm9taXNlTGlrZTxUUmVzdWx0MT4pXG4gICAgICB8IHVuZGVmaW5lZFxuICAgICAgfCBudWxsLFxuICAgIG9ucmVqZWN0ZWQ/OiAoKHJlYXNvbjogYW55KSA9PiBUUmVzdWx0MiB8IFByb21pc2VMaWtlPFRSZXN1bHQyPikgfCB1bmRlZmluZWQgfCBudWxsXG4gICk6IFByb21pc2VMaWtlPFRSZXN1bHQxIHwgVFJlc3VsdDI+IHtcbiAgICAvLyBodHRwczovL3Bvc3RncmVzdC5vcmcvZW4vc3RhYmxlL2FwaS5odG1sI3N3aXRjaGluZy1zY2hlbWFzXG4gICAgaWYgKHRoaXMuc2NoZW1hID09PSB1bmRlZmluZWQpIHtcbiAgICAgIC8vIHNraXBcbiAgICB9IGVsc2UgaWYgKFsnR0VUJywgJ0hFQUQnXS5pbmNsdWRlcyh0aGlzLm1ldGhvZCkpIHtcbiAgICAgIHRoaXMuaGVhZGVycy5zZXQoJ0FjY2VwdC1Qcm9maWxlJywgdGhpcy5zY2hlbWEpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuaGVhZGVycy5zZXQoJ0NvbnRlbnQtUHJvZmlsZScsIHRoaXMuc2NoZW1hKVxuICAgIH1cbiAgICBpZiAodGhpcy5tZXRob2QgIT09ICdHRVQnICYmIHRoaXMubWV0aG9kICE9PSAnSEVBRCcpIHtcbiAgICAgIHRoaXMuaGVhZGVycy5zZXQoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi9qc29uJylcbiAgICB9XG5cbiAgICAvLyBodHRwczovL2RvY3MucG9zdGdyZXN0Lm9yZy9lbi9zdGFibGUvcmVmZXJlbmNlcy9hcGkvcmVzb3VyY2VfcmVwcmVzZW50YXRpb24uaHRtbCNzdHJpcHBlZC1udWxsc1xuICAgIGlmICh0aGlzLnNob3VsZFN0cmlwTnVsbHMpIHtcbiAgICAgIGNvbnN0IGN1cnJlbnRBY2NlcHQgPSB0aGlzLmhlYWRlcnMuZ2V0KCdBY2NlcHQnKVxuICAgICAgaWYgKGN1cnJlbnRBY2NlcHQgPT09ICdhcHBsaWNhdGlvbi92bmQucGdyc3Qub2JqZWN0K2pzb24nKSB7XG4gICAgICAgIHRoaXMuaGVhZGVycy5zZXQoJ0FjY2VwdCcsICdhcHBsaWNhdGlvbi92bmQucGdyc3Qub2JqZWN0K2pzb247bnVsbHM9c3RyaXBwZWQnKVxuICAgICAgfSBlbHNlIGlmICghY3VycmVudEFjY2VwdCB8fCBjdXJyZW50QWNjZXB0ID09PSAnYXBwbGljYXRpb24vanNvbicpIHtcbiAgICAgICAgdGhpcy5oZWFkZXJzLnNldCgnQWNjZXB0JywgJ2FwcGxpY2F0aW9uL3ZuZC5wZ3JzdC5hcnJheStqc29uO251bGxzPXN0cmlwcGVkJylcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFOiBJbnZva2Ugdy9vIGB0aGlzYCB0byBhdm9pZCBpbGxlZ2FsIGludm9jYXRpb24gZXJyb3IuXG4gICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3N1cGFiYXNlL3Bvc3RncmVzdC1qcy9wdWxsLzI0N1xuICAgIGNvbnN0IF9mZXRjaCA9IHRoaXMuZmV0Y2hcblxuICAgIC8vIEV4ZWN1dGUgZmV0Y2ggd2l0aCByZXRyeSBsb2dpY1xuICAgIGNvbnN0IGV4ZWN1dGVXaXRoUmV0cnkgPSBhc3luYyAoKTogUHJvbWlzZTx7XG4gICAgICBlcnJvcjogYW55XG4gICAgICBkYXRhOiBhbnlcbiAgICAgIGNvdW50OiBudW1iZXIgfCBudWxsXG4gICAgICBzdGF0dXM6IG51bWJlclxuICAgICAgc3RhdHVzVGV4dDogc3RyaW5nXG4gICAgfT4gPT4ge1xuICAgICAgbGV0IGF0dGVtcHRDb3VudCA9IDBcblxuICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgLy8gU2VyaWFsaXplIGhlYWRlcnMgYXMgYSBwbGFpbiBvYmplY3QgcmF0aGVyIHRoYW4gYSBIZWFkZXJzIGluc3RhbmNlLlxuICAgICAgICAvLyBSZWFjdCBOYXRpdmUncyBYSFItYmFzZWQgZmV0Y2ggc2lsZW50bHkgZHJvcHMgaGVhZGVycyAobm90YWJseSBDb250ZW50LVR5cGUpXG4gICAgICAgIC8vIHdoZW4gZ2l2ZW4gYSBIZWFkZXJzIGluc3RhbmNlLCBjYXVzaW5nIFBHUlNUMjAyIG9uIHBhcmFtZXRlci1sZXNzIFJQQyBjYWxscy5cbiAgICAgICAgLy8gU2VlIHN1cGFiYXNlL3N1cGFiYXNlLWpzIzE1NjIgYW5kIGZhY2Vib29rL3JlYWN0LW5hdGl2ZSMzMzkzMy5cbiAgICAgICAgLy8gQWxsIHNpYmxpbmcgcGFja2FnZXMgKGF1dGgtanMsIHN0b3JhZ2UtanMsIGZ1bmN0aW9ucy1qcykgYWxyZWFkeSBwYXNzIHBsYWluIG9iamVjdHMuXG4gICAgICAgIGNvbnN0IGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fVxuICAgICAgICB0aGlzLmhlYWRlcnMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xuICAgICAgICAgIGhlYWRlcnNba2V5XSA9IHZhbHVlXG4gICAgICAgIH0pXG4gICAgICAgIGlmIChhdHRlbXB0Q291bnQgPiAwKSB7XG4gICAgICAgICAgaGVhZGVyc1snWC1SZXRyeS1Db3VudCddID0gU3RyaW5nKGF0dGVtcHRDb3VudClcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIE9ubHkgd3JhcCB0aGUgZmV0Y2ggY2FsbCBpdHNlbGYg4oCUIHByb2Nlc3NSZXNwb25zZSBlcnJvcnMgbXVzdCBuZXZlciB0cmlnZ2VyIHJldHJpZXNcbiAgICAgICAgbGV0IHJlczogUmVzcG9uc2VcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXMgPSBhd2FpdCBfZmV0Y2godGhpcy51cmwudG9TdHJpbmcoKSwge1xuICAgICAgICAgICAgbWV0aG9kOiB0aGlzLm1ldGhvZCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh0aGlzLmJvZHksIChfLCB2YWx1ZSkgPT5cbiAgICAgICAgICAgICAgdHlwZW9mIHZhbHVlID09PSAnYmlnaW50JyA/IHZhbHVlLnRvU3RyaW5nKCkgOiB2YWx1ZVxuICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIHNpZ25hbDogdGhpcy5zaWduYWwsXG4gICAgICAgICAgfSlcbiAgICAgICAgICAvLyBKUyBhbGxvd3MgdGhyb3dpbmcgYW55IHZhbHVlLCBhbmQgc2VydmVybGVzcyBvciByZWFsbS1jcm9zc2luZyBmZXRjaFxuICAgICAgICAgIC8vIGltcGxlbWVudGF0aW9ucyBjYW4gcmVqZWN0IHdpdGggbm9uLUVycm9yIG9iamVjdHMuIGBpbnN0YW5jZW9mIEVycm9yYFxuICAgICAgICAgIC8vIGlzIHRvbyBuYXJyb3cgaGVyZTsgbmFycm93IGF0IHRoZSB1c2Ugc2l0ZSB3aXRoIG9wdGlvbmFsIGNoYWluaW5nLlxuICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgIH0gY2F0Y2ggKGZldGNoRXJyb3I6IGFueSkge1xuICAgICAgICAgIC8vIE5ldmVyIHJldHJ5IGFib3J0ZWQgcmVxdWVzdHNcbiAgICAgICAgICBpZiAoZmV0Y2hFcnJvcj8ubmFtZSA9PT0gJ0Fib3J0RXJyb3InIHx8IGZldGNoRXJyb3I/LmNvZGUgPT09ICdBQk9SVF9FUlInKSB7XG4gICAgICAgICAgICB0aHJvdyBmZXRjaEVycm9yXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gRG9uJ3QgcmV0cnkgbmV0d29yayBlcnJvcnMgZm9yIG5vbi1pZGVtcG90ZW50IG1ldGhvZHNcbiAgICAgICAgICBpZiAoIVJFVFJZQUJMRV9NRVRIT0RTLmluY2x1ZGVzKHRoaXMubWV0aG9kIGFzICh0eXBlb2YgUkVUUllBQkxFX01FVEhPRFMpW251bWJlcl0pKSB7XG4gICAgICAgICAgICB0aHJvdyBmZXRjaEVycm9yXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gQ2hlY2sgaWYgd2Ugc2hvdWxkIHJldHJ5IG5ldHdvcmsgZXJyb3JzXG4gICAgICAgICAgaWYgKHRoaXMucmV0cnlFbmFibGVkICYmIGF0dGVtcHRDb3VudCA8IERFRkFVTFRfTUFYX1JFVFJJRVMpIHtcbiAgICAgICAgICAgIGNvbnN0IGRlbGF5ID0gZ2V0UmV0cnlEZWxheShhdHRlbXB0Q291bnQpXG4gICAgICAgICAgICBhdHRlbXB0Q291bnQrK1xuICAgICAgICAgICAgYXdhaXQgc2xlZXAoZGVsYXksIHRoaXMuc2lnbmFsKVxuICAgICAgICAgICAgY29udGludWVcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBFeGhhdXN0ZWQgcmV0cmllcyBvciByZXRyaWVzIGRpc2FibGVkLCB0aHJvdyB0aGUgbGFzdCBlcnJvclxuICAgICAgICAgIHRocm93IGZldGNoRXJyb3JcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIENoZWNrIGlmIHdlIHNob3VsZCByZXRyeSB0aGlzIEhUVFAgcmVzcG9uc2VcbiAgICAgICAgaWYgKHNob3VsZFJldHJ5KHRoaXMubWV0aG9kLCByZXMuc3RhdHVzLCBhdHRlbXB0Q291bnQsIHRoaXMucmV0cnlFbmFibGVkKSkge1xuICAgICAgICAgIGNvbnN0IHJldHJ5QWZ0ZXJIZWFkZXIgPSByZXMuaGVhZGVycz8uZ2V0KCdSZXRyeS1BZnRlcicpID8/IG51bGxcbiAgICAgICAgICBjb25zdCBkZWxheSA9XG4gICAgICAgICAgICByZXRyeUFmdGVySGVhZGVyICE9PSBudWxsXG4gICAgICAgICAgICAgID8gTWF0aC5tYXgoMCwgcGFyc2VJbnQocmV0cnlBZnRlckhlYWRlciwgMTApIHx8IDApICogMTAwMFxuICAgICAgICAgICAgICA6IGdldFJldHJ5RGVsYXkoYXR0ZW1wdENvdW50KVxuICAgICAgICAgIGF3YWl0IHJlcy50ZXh0KClcbiAgICAgICAgICBhdHRlbXB0Q291bnQrK1xuICAgICAgICAgIGF3YWl0IHNsZWVwKGRlbGF5LCB0aGlzLnNpZ25hbClcbiAgICAgICAgICBjb250aW51ZVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMucHJvY2Vzc1Jlc3BvbnNlKHJlcylcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsZXQgcmVzID0gZXhlY3V0ZVdpdGhSZXRyeSgpXG5cbiAgICBpZiAoIXRoaXMuc2hvdWxkVGhyb3dPbkVycm9yKSB7XG4gICAgICByZXMgPSByZXMuY2F0Y2goKGZldGNoRXJyb3IpID0+IHtcbiAgICAgICAgLy8gQnVpbGQgZGV0YWlsZWQgZXJyb3IgaW5mb3JtYXRpb24gaW5jbHVkaW5nIGNhdXNlIGlmIGF2YWlsYWJsZVxuICAgICAgICAvLyBOb3RlOiBXZSBkb24ndCBwb3B1bGF0ZSBjb2RlL2hpbnQgZm9yIGNsaWVudC1zaWRlIG5ldHdvcmsgZXJyb3JzIHNpbmNlIHRob3NlXG4gICAgICAgIC8vIGZpZWxkcyBhcmUgbWVhbnQgZm9yIHVwc3RyZWFtIHNlcnZpY2UgZXJyb3JzIChQb3N0Z1JFU1QvUG9zdGdyZVNRTClcbiAgICAgICAgbGV0IGVycm9yRGV0YWlscyA9ICcnXG4gICAgICAgIGxldCBoaW50ID0gJydcbiAgICAgICAgbGV0IGNvZGUgPSAnJ1xuXG4gICAgICAgIC8vIEFkZCBjYXVzZSBpbmZvcm1hdGlvbiBpZiBhdmFpbGFibGUgKGUuZy4sIEROUyBlcnJvcnMsIG5ldHdvcmsgZmFpbHVyZXMpXG4gICAgICAgIGNvbnN0IGNhdXNlID0gZmV0Y2hFcnJvcj8uY2F1c2VcbiAgICAgICAgaWYgKGNhdXNlKSB7XG4gICAgICAgICAgY29uc3QgY2F1c2VNZXNzYWdlID0gY2F1c2U/Lm1lc3NhZ2UgPz8gJydcbiAgICAgICAgICBjb25zdCBjYXVzZUNvZGUgPSBjYXVzZT8uY29kZSA/PyAnJ1xuXG4gICAgICAgICAgZXJyb3JEZXRhaWxzID0gYCR7ZmV0Y2hFcnJvcj8ubmFtZSA/PyAnRmV0Y2hFcnJvcid9OiAke2ZldGNoRXJyb3I/Lm1lc3NhZ2V9YFxuICAgICAgICAgIGVycm9yRGV0YWlscyArPSBgXFxuXFxuQ2F1c2VkIGJ5OiAke2NhdXNlPy5uYW1lID8/ICdFcnJvcid9OiAke2NhdXNlTWVzc2FnZX1gXG4gICAgICAgICAgaWYgKGNhdXNlQ29kZSkge1xuICAgICAgICAgICAgZXJyb3JEZXRhaWxzICs9IGAgKCR7Y2F1c2VDb2RlfSlgXG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChjYXVzZT8uc3RhY2spIHtcbiAgICAgICAgICAgIGVycm9yRGV0YWlscyArPSBgXFxuJHtjYXVzZS5zdGFja31gXG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIE5vIGNhdXNlIGF2YWlsYWJsZSwganVzdCBpbmNsdWRlIHRoZSBlcnJvciBzdGFja1xuICAgICAgICAgIGVycm9yRGV0YWlscyA9IGZldGNoRXJyb3I/LnN0YWNrID8/ICcnXG4gICAgICAgIH1cblxuICAgICAgICAvLyBHZXQgVVJMIGxlbmd0aCBmb3IgcG90ZW50aWFsIGhpbnRzXG4gICAgICAgIGNvbnN0IHVybExlbmd0aCA9IHRoaXMudXJsLnRvU3RyaW5nKCkubGVuZ3RoXG5cbiAgICAgICAgLy8gSGFuZGxlIEFib3J0RXJyb3Igc3BlY2lhbGx5IHdpdGggaGVscGZ1bCBoaW50c1xuICAgICAgICBpZiAoZmV0Y2hFcnJvcj8ubmFtZSA9PT0gJ0Fib3J0RXJyb3InIHx8IGZldGNoRXJyb3I/LmNvZGUgPT09ICdBQk9SVF9FUlInKSB7XG4gICAgICAgICAgY29kZSA9ICcnXG4gICAgICAgICAgaGludCA9ICdSZXF1ZXN0IHdhcyBhYm9ydGVkICh0aW1lb3V0IG9yIG1hbnVhbCBjYW5jZWxsYXRpb24pJ1xuXG4gICAgICAgICAgaWYgKHVybExlbmd0aCA+IHRoaXMudXJsTGVuZ3RoTGltaXQpIHtcbiAgICAgICAgICAgIGhpbnQgKz0gYC4gTm90ZTogWW91ciByZXF1ZXN0IFVSTCBpcyAke3VybExlbmd0aH0gY2hhcmFjdGVycywgd2hpY2ggbWF5IGV4Y2VlZCBzZXJ2ZXIgbGltaXRzLiBJZiBzZWxlY3RpbmcgbWFueSBmaWVsZHMsIGNvbnNpZGVyIHVzaW5nIHZpZXdzLiBJZiBmaWx0ZXJpbmcgd2l0aCBsYXJnZSBhcnJheXMgKGUuZy4sIC5pbignaWQnLCBbbWFueSBJRHNdKSksIGNvbnNpZGVyIHVzaW5nIGFuIFJQQyBmdW5jdGlvbiB0byBwYXNzIHZhbHVlcyBzZXJ2ZXItc2lkZS5gXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIEhhbmRsZSBIZWFkZXJzT3ZlcmZsb3dFcnJvciBmcm9tIHVuZGljaSAoTm9kZS5qcyBmZXRjaCBpbXBsZW1lbnRhdGlvbilcbiAgICAgICAgZWxzZSBpZiAoXG4gICAgICAgICAgY2F1c2U/Lm5hbWUgPT09ICdIZWFkZXJzT3ZlcmZsb3dFcnJvcicgfHxcbiAgICAgICAgICBjYXVzZT8uY29kZSA9PT0gJ1VORF9FUlJfSEVBREVSU19PVkVSRkxPVydcbiAgICAgICAgKSB7XG4gICAgICAgICAgY29kZSA9ICcnXG4gICAgICAgICAgaGludCA9ICdIVFRQIGhlYWRlcnMgZXhjZWVkZWQgc2VydmVyIGxpbWl0cyAodHlwaWNhbGx5IDE2S0IpJ1xuXG4gICAgICAgICAgaWYgKHVybExlbmd0aCA+IHRoaXMudXJsTGVuZ3RoTGltaXQpIHtcbiAgICAgICAgICAgIGhpbnQgKz0gYC4gWW91ciByZXF1ZXN0IFVSTCBpcyAke3VybExlbmd0aH0gY2hhcmFjdGVycy4gSWYgc2VsZWN0aW5nIG1hbnkgZmllbGRzLCBjb25zaWRlciB1c2luZyB2aWV3cy4gSWYgZmlsdGVyaW5nIHdpdGggbGFyZ2UgYXJyYXlzIChlLmcuLCAuaW4oJ2lkJywgWzIwMCsgSURzXSkpLCBjb25zaWRlciB1c2luZyBhbiBSUEMgZnVuY3Rpb24gaW5zdGVhZC5gXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSBhcyBjb25zdCxcbiAgICAgICAgICBlcnJvcjoge1xuICAgICAgICAgICAgbWVzc2FnZTogYCR7ZmV0Y2hFcnJvcj8ubmFtZSA/PyAnRmV0Y2hFcnJvcid9OiAke2ZldGNoRXJyb3I/Lm1lc3NhZ2V9YCxcbiAgICAgICAgICAgIGRldGFpbHM6IGVycm9yRGV0YWlscyxcbiAgICAgICAgICAgIGhpbnQ6IGhpbnQsXG4gICAgICAgICAgICBjb2RlOiBjb2RlLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgICBjb3VudDogbnVsbCxcbiAgICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgICAgc3RhdHVzVGV4dDogJycsXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgIHJlcyBhcyBQcm9taXNlPFxuICAgICAgICBUaHJvd09uRXJyb3IgZXh0ZW5kcyB0cnVlXG4gICAgICAgICAgPyBQb3N0Z3Jlc3RSZXNwb25zZVN1Y2Nlc3M8UmVzdWx0PlxuICAgICAgICAgIDogUG9zdGdyZXN0U2luZ2xlUmVzcG9uc2U8UmVzdWx0PlxuICAgICAgPlxuICAgICkudGhlbihvbmZ1bGZpbGxlZCwgb25yZWplY3RlZClcbiAgfVxuXG4gIC8qKlxuICAgKiBQcm9jZXNzIGEgZmV0Y2ggcmVzcG9uc2UgYW5kIHJldHVybiB0aGUgc3RhbmRhcmRpemVkIHBvc3RncmVzdCByZXNwb25zZS5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgcHJvY2Vzc1Jlc3BvbnNlKHJlczogUmVzcG9uc2UpOiBQcm9taXNlPHtcbiAgICBzdWNjZXNzOiBib29sZWFuXG4gICAgZXJyb3I6IGFueVxuICAgIGRhdGE6IGFueVxuICAgIGNvdW50OiBudW1iZXIgfCBudWxsXG4gICAgc3RhdHVzOiBudW1iZXJcbiAgICBzdGF0dXNUZXh0OiBzdHJpbmdcbiAgfT4ge1xuICAgIGxldCBlcnJvciA9IG51bGxcbiAgICBsZXQgZGF0YSA9IG51bGxcbiAgICBsZXQgY291bnQ6IG51bWJlciB8IG51bGwgPSBudWxsXG4gICAgbGV0IHN0YXR1cyA9IHJlcy5zdGF0dXNcbiAgICBsZXQgc3RhdHVzVGV4dCA9IHJlcy5zdGF0dXNUZXh0XG5cbiAgICBpZiAocmVzLm9rKSB7XG4gICAgICBpZiAodGhpcy5tZXRob2QgIT09ICdIRUFEJykge1xuICAgICAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVzLnRleHQoKVxuICAgICAgICBpZiAoYm9keSA9PT0gJycpIHtcbiAgICAgICAgICAvLyBQcmVmZXI6IHJldHVybj1taW5pbWFsXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5oZWFkZXJzLmdldCgnQWNjZXB0JykgPT09ICd0ZXh0L2NzdicpIHtcbiAgICAgICAgICBkYXRhID0gYm9keVxuICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgIHRoaXMuaGVhZGVycy5nZXQoJ0FjY2VwdCcpICYmXG4gICAgICAgICAgdGhpcy5oZWFkZXJzLmdldCgnQWNjZXB0Jyk/LmluY2x1ZGVzKCdhcHBsaWNhdGlvbi92bmQucGdyc3QucGxhbit0ZXh0JylcbiAgICAgICAgKSB7XG4gICAgICAgICAgZGF0YSA9IGJvZHlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgZGF0YSA9IEpTT04ucGFyc2UoYm9keSlcbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIC8vIEEgMnh4IHN0YXR1cyBkb2Vzbid0IGd1YXJhbnRlZSBhIEpTT04gYm9keTsgbWlycm9yIHRoZSBub24tMnh4IGZhbGxiYWNrIGJlbG93LlxuICAgICAgICAgICAgZXJyb3IgPSB7IG1lc3NhZ2U6IGJvZHkgfVxuICAgICAgICAgICAgZGF0YSA9IG51bGxcblxuICAgICAgICAgICAgaWYgKHRoaXMuc2hvdWxkVGhyb3dPbkVycm9yKSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBQb3N0Z3Jlc3RFcnJvcih7IG1lc3NhZ2U6IGJvZHksIGRldGFpbHM6ICcnLCBoaW50OiAnJywgY29kZTogJycgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgY291bnRIZWFkZXIgPSB0aGlzLmhlYWRlcnMuZ2V0KCdQcmVmZXInKT8ubWF0Y2goL2NvdW50PShleGFjdHxwbGFubmVkfGVzdGltYXRlZCkvKVxuICAgICAgY29uc3QgY29udGVudFJhbmdlID0gcmVzLmhlYWRlcnMuZ2V0KCdjb250ZW50LXJhbmdlJyk/LnNwbGl0KCcvJylcbiAgICAgIGlmIChjb3VudEhlYWRlciAmJiBjb250ZW50UmFuZ2UgJiYgY29udGVudFJhbmdlLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgY291bnQgPSBwYXJzZUludChjb250ZW50UmFuZ2VbMV0pXG4gICAgICB9XG5cbiAgICAgIC8vIEZpeCBmb3IgaHR0cHM6Ly9naXRodWIuY29tL3N1cGFiYXNlL3Bvc3RncmVzdC1qcy9pc3N1ZXMvMzYxIOKAlCBhcHBsaWVzIHRvIGFsbCBtZXRob2RzLlxuICAgICAgaWYgKHRoaXMuaXNNYXliZVNpbmdsZSAmJiBBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgIGlmIChkYXRhLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICBlcnJvciA9IHtcbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Qb3N0Z1JFU1QvcG9zdGdyZXN0L2Jsb2IvYTg2N2Q3OWM0MjQxOWFmMTZjMThjM2ZiMDE5ZWJhOGRmOTkyNjI2Zi9zcmMvUG9zdGdSRVNUL0Vycm9yLmhzI0w1NTNcbiAgICAgICAgICAgIGNvZGU6ICdQR1JTVDExNicsXG4gICAgICAgICAgICBkZXRhaWxzOiBgUmVzdWx0cyBjb250YWluICR7ZGF0YS5sZW5ndGh9IHJvd3MsIGFwcGxpY2F0aW9uL3ZuZC5wZ3JzdC5vYmplY3QranNvbiByZXF1aXJlcyAxIHJvd2AsXG4gICAgICAgICAgICBoaW50OiBudWxsLFxuICAgICAgICAgICAgbWVzc2FnZTogJ0pTT04gb2JqZWN0IHJlcXVlc3RlZCwgbXVsdGlwbGUgKG9yIG5vKSByb3dzIHJldHVybmVkJyxcbiAgICAgICAgICB9XG4gICAgICAgICAgZGF0YSA9IG51bGxcbiAgICAgICAgICBjb3VudCA9IG51bGxcbiAgICAgICAgICBzdGF0dXMgPSA0MDZcbiAgICAgICAgICBzdGF0dXNUZXh0ID0gJ05vdCBBY2NlcHRhYmxlJ1xuICAgICAgICB9IGVsc2UgaWYgKGRhdGEubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgZGF0YSA9IGRhdGFbMF1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBkYXRhID0gbnVsbFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXMudGV4dCgpXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGVycm9yID0gSlNPTi5wYXJzZShib2R5KVxuXG4gICAgICAgIC8vIFdvcmthcm91bmQgZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9zdXBhYmFzZS9wb3N0Z3Jlc3QtanMvaXNzdWVzLzI5NVxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShlcnJvcikgJiYgcmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICAgICAgZGF0YSA9IFtdXG4gICAgICAgICAgZXJyb3IgPSBudWxsXG4gICAgICAgICAgc3RhdHVzID0gMjAwXG4gICAgICAgICAgc3RhdHVzVGV4dCA9ICdPSydcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIFdvcmthcm91bmQgZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9zdXBhYmFzZS9wb3N0Z3Jlc3QtanMvaXNzdWVzLzI5NVxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0ICYmIGJvZHkgPT09ICcnKSB7XG4gICAgICAgICAgc3RhdHVzID0gMjA0XG4gICAgICAgICAgc3RhdHVzVGV4dCA9ICdObyBDb250ZW50J1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVycm9yID0ge1xuICAgICAgICAgICAgbWVzc2FnZTogYm9keSxcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGVycm9yICYmIHRoaXMuc2hvdWxkVGhyb3dPbkVycm9yKSB7XG4gICAgICAgIHRocm93IG5ldyBQb3N0Z3Jlc3RFcnJvcihlcnJvcilcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogZXJyb3IgPT09IG51bGwsXG4gICAgICBlcnJvcixcbiAgICAgIGRhdGEsXG4gICAgICBjb3VudCxcbiAgICAgIHN0YXR1cyxcbiAgICAgIHN0YXR1c1RleHQsXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIE92ZXJyaWRlIHRoZSB0eXBlIG9mIHRoZSByZXR1cm5lZCBgZGF0YWAuXG4gICAqXG4gICAqIEB0eXBlUGFyYW0gTmV3UmVzdWx0IC0gVGhlIG5ldyByZXN1bHQgdHlwZSB0byBvdmVycmlkZSB3aXRoXG4gICAqIEBkZXByZWNhdGVkIFVzZSBvdmVycmlkZVR5cGVzPHlvdXJUeXBlLCB7IG1lcmdlOiBmYWxzZSB9PigpIG1ldGhvZCBhdCB0aGUgZW5kIG9mIHlvdXIgY2FsbCBjaGFpbiBpbnN0ZWFkXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqL1xuICByZXR1cm5zPE5ld1Jlc3VsdD4oKTogUG9zdGdyZXN0QnVpbGRlcjxcbiAgICBDbGllbnRPcHRpb25zLFxuICAgIENoZWNrTWF0Y2hpbmdBcnJheVR5cGVzPFJlc3VsdCwgTmV3UmVzdWx0PixcbiAgICBUaHJvd09uRXJyb3JcbiAgPiB7XG4gICAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cbiAgICByZXR1cm4gdGhpcyBhcyB1bmtub3duIGFzIFBvc3RncmVzdEJ1aWxkZXI8XG4gICAgICBDbGllbnRPcHRpb25zLFxuICAgICAgQ2hlY2tNYXRjaGluZ0FycmF5VHlwZXM8UmVzdWx0LCBOZXdSZXN1bHQ+LFxuICAgICAgVGhyb3dPbkVycm9yXG4gICAgPlxuICB9XG5cbiAgLyoqXG4gICAqIE92ZXJyaWRlIHRoZSB0eXBlIG9mIHRoZSByZXR1cm5lZCBgZGF0YWAgZmllbGQgaW4gdGhlIHJlc3BvbnNlLlxuICAgKlxuICAgKiBAdHlwZVBhcmFtIE5ld1Jlc3VsdCAtIFRoZSBuZXcgdHlwZSB0byBjYXN0IHRoZSByZXNwb25zZSBkYXRhIHRvXG4gICAqIEB0eXBlUGFyYW0gT3B0aW9ucyAtIE9wdGlvbmFsIHR5cGUgY29uZmlndXJhdGlvbiAoZGVmYXVsdHMgdG8geyBtZXJnZTogdHJ1ZSB9KVxuICAgKiBAdHlwZVBhcmFtIE9wdGlvbnMubWVyZ2UgLSBXaGVuIHRydWUsIG1lcmdlcyB0aGUgbmV3IHR5cGUgd2l0aCBleGlzdGluZyByZXR1cm4gdHlwZS4gV2hlbiBmYWxzZSwgcmVwbGFjZXMgdGhlIGV4aXN0aW5nIHR5cGVzIGVudGlyZWx5IChkZWZhdWx0cyB0byB0cnVlKVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIC8vIE1lcmdlIHdpdGggZXhpc3RpbmcgdHlwZXMgKGRlZmF1bHQgYmVoYXZpb3IpXG4gICAqIGNvbnN0IHF1ZXJ5ID0gc3VwYWJhc2VcbiAgICogICAuZnJvbSgndXNlcnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5vdmVycmlkZVR5cGVzPHsgY3VzdG9tX2ZpZWxkOiBzdHJpbmcgfT4oKVxuICAgKlxuICAgKiAvLyBSZXBsYWNlIGV4aXN0aW5nIHR5cGVzIGNvbXBsZXRlbHlcbiAgICogY29uc3QgcmVwbGFjZVF1ZXJ5ID0gc3VwYWJhc2VcbiAgICogICAuZnJvbSgndXNlcnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5vdmVycmlkZVR5cGVzPHsgaWQ6IG51bWJlcjsgbmFtZTogc3RyaW5nIH0sIHsgbWVyZ2U6IGZhbHNlIH0+KClcbiAgICogYGBgXG4gICAqIEByZXR1cm5zIEEgUG9zdGdyZXN0QnVpbGRlciBpbnN0YW5jZSB3aXRoIHRoZSBuZXcgdHlwZVxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIG1vZGlmaWVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBDb21wbGV0ZSBPdmVycmlkZSB0eXBlIG9mIHN1Y2Nlc3NmdWwgcmVzcG9uc2VcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjb3VudHJpZXMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5vdmVycmlkZVR5cGVzPEFycmF5PE15VHlwZT4sIHsgbWVyZ2U6IGZhbHNlIH0+KClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQ29tcGxldGUgT3ZlcnJpZGUgdHlwZSBvZiBzdWNjZXNzZnVsIHJlc3BvbnNlXG4gICAqIGBgYHRzXG4gICAqIGxldCB4OiB0eXBlb2YgZGF0YSAvLyBNeVR5cGVbXVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgQ29tcGxldGUgT3ZlcnJpZGUgdHlwZSBvZiBvYmplY3QgcmVzcG9uc2VcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjb3VudHJpZXMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5tYXliZVNpbmdsZSgpXG4gICAqICAgLm92ZXJyaWRlVHlwZXM8TXlUeXBlLCB7IG1lcmdlOiBmYWxzZSB9PigpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIENvbXBsZXRlIE92ZXJyaWRlIHR5cGUgb2Ygb2JqZWN0IHJlc3BvbnNlXG4gICAqIGBgYHRzXG4gICAqIGxldCB4OiB0eXBlb2YgZGF0YSAvLyBNeVR5cGUgfCBudWxsXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBQYXJ0aWFsIE92ZXJyaWRlIHR5cGUgb2Ygc3VjY2Vzc2Z1bCByZXNwb25zZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NvdW50cmllcycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLm92ZXJyaWRlVHlwZXM8QXJyYXk8eyBzdGF0dXM6IFwiQVwiIHwgXCJCXCIgfT4+KClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgUGFydGlhbCBPdmVycmlkZSB0eXBlIG9mIHN1Y2Nlc3NmdWwgcmVzcG9uc2VcbiAgICogYGBgdHNcbiAgICogbGV0IHg6IHR5cGVvZiBkYXRhIC8vIEFycmF5PENvdW50cnlSb3dQcm9wZXJ0aWVzICYgeyBzdGF0dXM6IFwiQVwiIHwgXCJCXCIgfT5cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFBhcnRpYWwgT3ZlcnJpZGUgdHlwZSBvZiBvYmplY3QgcmVzcG9uc2VcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjb3VudHJpZXMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5tYXliZVNpbmdsZSgpXG4gICAqICAgLm92ZXJyaWRlVHlwZXM8eyBzdGF0dXM6IFwiQVwiIHwgXCJCXCIgfT4oKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBQYXJ0aWFsIE92ZXJyaWRlIHR5cGUgb2Ygb2JqZWN0IHJlc3BvbnNlXG4gICAqIGBgYHRzXG4gICAqIGxldCB4OiB0eXBlb2YgZGF0YSAvLyBDb3VudHJ5Um93UHJvcGVydGllcyAmIHsgc3RhdHVzOiBcIkFcIiB8IFwiQlwiIH0gfCBudWxsXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBNZXJnZSB2cyByZXBsYWNlIGV4aXN0aW5nIHR5cGVzXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogLy8gTWVyZ2Ugd2l0aCBleGlzdGluZyB0eXBlcyAoZGVmYXVsdCBiZWhhdmlvcilcbiAgICogY29uc3QgcXVlcnkgPSBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCd1c2VycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLm92ZXJyaWRlVHlwZXM8eyBjdXN0b21fZmllbGQ6IHN0cmluZyB9PigpXG4gICAqXG4gICAqIC8vIFJlcGxhY2UgZXhpc3RpbmcgdHlwZXMgY29tcGxldGVseVxuICAgKiBjb25zdCByZXBsYWNlUXVlcnkgPSBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCd1c2VycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLm92ZXJyaWRlVHlwZXM8eyBpZDogbnVtYmVyOyBuYW1lOiBzdHJpbmcgfSwgeyBtZXJnZTogZmFsc2UgfT4oKVxuICAgKiBgYGBcbiAgICovXG4gIG92ZXJyaWRlVHlwZXM8XG4gICAgTmV3UmVzdWx0LFxuICAgIE9wdGlvbnMgZXh0ZW5kcyB7IG1lcmdlPzogYm9vbGVhbiB9ID0geyBtZXJnZTogdHJ1ZSB9LFxuICA+KCk6IFBvc3RncmVzdEJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBJc1ZhbGlkUmVzdWx0T3ZlcnJpZGU8UmVzdWx0LCBOZXdSZXN1bHQsIGZhbHNlLCBmYWxzZT4gZXh0ZW5kcyB0cnVlXG4gICAgICA/IC8vIFByZXNlcnZlIHRoZSBvcHRpb25hbGl0eSBvZiB0aGUgcmVzdWx0IGlmIHRoZSBvdmVycmlkZW4gdHlwZSBpcyBhbiBvYmplY3QgKGNhc2Ugb2YgY2hhaW5pbmcgd2l0aCBgbWF5YmVTaW5nbGVgKVxuICAgICAgICBDb250YWluc051bGw8UmVzdWx0PiBleHRlbmRzIHRydWVcbiAgICAgICAgPyBNZXJnZVBhcnRpYWxSZXN1bHQ8TmV3UmVzdWx0LCBOb25OdWxsYWJsZTxSZXN1bHQ+LCBPcHRpb25zPiB8IG51bGxcbiAgICAgICAgOiBNZXJnZVBhcnRpYWxSZXN1bHQ8TmV3UmVzdWx0LCBSZXN1bHQsIE9wdGlvbnM+XG4gICAgICA6IENoZWNrTWF0Y2hpbmdBcnJheVR5cGVzPFJlc3VsdCwgTmV3UmVzdWx0PixcbiAgICBUaHJvd09uRXJyb3JcbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMgYXMgdW5rbm93biBhcyBQb3N0Z3Jlc3RCdWlsZGVyPFxuICAgICAgQ2xpZW50T3B0aW9ucyxcbiAgICAgIElzVmFsaWRSZXN1bHRPdmVycmlkZTxSZXN1bHQsIE5ld1Jlc3VsdCwgZmFsc2UsIGZhbHNlPiBleHRlbmRzIHRydWVcbiAgICAgICAgPyAvLyBQcmVzZXJ2ZSB0aGUgb3B0aW9uYWxpdHkgb2YgdGhlIHJlc3VsdCBpZiB0aGUgb3ZlcnJpZGVuIHR5cGUgaXMgYW4gb2JqZWN0IChjYXNlIG9mIGNoYWluaW5nIHdpdGggYG1heWJlU2luZ2xlYClcbiAgICAgICAgICBDb250YWluc051bGw8UmVzdWx0PiBleHRlbmRzIHRydWVcbiAgICAgICAgICA/IE1lcmdlUGFydGlhbFJlc3VsdDxOZXdSZXN1bHQsIE5vbk51bGxhYmxlPFJlc3VsdD4sIE9wdGlvbnM+IHwgbnVsbFxuICAgICAgICAgIDogTWVyZ2VQYXJ0aWFsUmVzdWx0PE5ld1Jlc3VsdCwgUmVzdWx0LCBPcHRpb25zPlxuICAgICAgICA6IENoZWNrTWF0Y2hpbmdBcnJheVR5cGVzPFJlc3VsdCwgTmV3UmVzdWx0PixcbiAgICAgIFRocm93T25FcnJvclxuICAgID5cbiAgfVxufVxuIiwiaW1wb3J0IFBvc3RncmVzdEJ1aWxkZXIgZnJvbSAnLi9Qb3N0Z3Jlc3RCdWlsZGVyJ1xuaW1wb3J0IFBvc3RncmVzdEZpbHRlckJ1aWxkZXIsIHsgSW52YWxpZE1ldGhvZEVycm9yIH0gZnJvbSAnLi9Qb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyJ1xuaW1wb3J0IHsgR2V0UmVzdWx0IH0gZnJvbSAnLi9zZWxlY3QtcXVlcnktcGFyc2VyL3Jlc3VsdCdcbmltcG9ydCB7IENoZWNrTWF0Y2hpbmdBcnJheVR5cGVzIH0gZnJvbSAnLi90eXBlcy90eXBlcydcbmltcG9ydCB7IENsaWVudFNlcnZlck9wdGlvbnMsIEdlbmVyaWNTY2hlbWEgfSBmcm9tICcuL3R5cGVzL2NvbW1vbi9jb21tb24nXG5pbXBvcnQgdHlwZSB7IE1heEFmZmVjdGVkRW5hYmxlZCB9IGZyb20gJy4vdHlwZXMvZmVhdHVyZS1mbGFncydcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUG9zdGdyZXN0VHJhbnNmb3JtQnVpbGRlcjxcbiAgQ2xpZW50T3B0aW9ucyBleHRlbmRzIENsaWVudFNlcnZlck9wdGlvbnMsXG4gIFNjaGVtYSBleHRlbmRzIEdlbmVyaWNTY2hlbWEsXG4gIFJvdyBleHRlbmRzIFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBSZXN1bHQsXG4gIFJlbGF0aW9uTmFtZSA9IHVua25vd24sXG4gIFJlbGF0aW9uc2hpcHMgPSB1bmtub3duLFxuICBNZXRob2QgPSB1bmtub3duLFxuICBUaHJvd09uRXJyb3IgZXh0ZW5kcyBib29sZWFuID0gZmFsc2UsXG4+IGV4dGVuZHMgUG9zdGdyZXN0QnVpbGRlcjxDbGllbnRPcHRpb25zLCBSZXN1bHQsIFRocm93T25FcnJvcj4ge1xuICB0aHJvd09uRXJyb3IoKTogUG9zdGdyZXN0VHJhbnNmb3JtQnVpbGRlcjxcbiAgICBDbGllbnRPcHRpb25zLFxuICAgIFNjaGVtYSxcbiAgICBSb3csXG4gICAgUmVzdWx0LFxuICAgIFJlbGF0aW9uTmFtZSxcbiAgICBSZWxhdGlvbnNoaXBzLFxuICAgIE1ldGhvZCxcbiAgICB0cnVlXG4gID4ge1xuICAgIHJldHVybiBzdXBlci50aHJvd09uRXJyb3IoKSBhcyBQb3N0Z3Jlc3RUcmFuc2Zvcm1CdWlsZGVyPFxuICAgICAgQ2xpZW50T3B0aW9ucyxcbiAgICAgIFNjaGVtYSxcbiAgICAgIFJvdyxcbiAgICAgIFJlc3VsdCxcbiAgICAgIFJlbGF0aW9uTmFtZSxcbiAgICAgIFJlbGF0aW9uc2hpcHMsXG4gICAgICBNZXRob2QsXG4gICAgICB0cnVlXG4gICAgPlxuICB9XG5cbiAgLyoqXG4gICAqIFBlcmZvcm0gYSBTRUxFQ1Qgb24gdGhlIHF1ZXJ5IHJlc3VsdC5cbiAgICpcbiAgICogQnkgZGVmYXVsdCwgYC5pbnNlcnQoKWAsIGAudXBkYXRlKClgLCBgLnVwc2VydCgpYCwgYW5kIGAuZGVsZXRlKClgIGRvIG5vdFxuICAgKiByZXR1cm4gbW9kaWZpZWQgcm93cy4gQnkgY2FsbGluZyB0aGlzIG1ldGhvZCwgbW9kaWZpZWQgcm93cyBhcmUgcmV0dXJuZWQgaW5cbiAgICogYGRhdGFgLlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1ucyAtIFRoZSBjb2x1bW5zIHRvIHJldHJpZXZlLCBzZXBhcmF0ZWQgYnkgY29tbWFzXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHVwc2VydCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjaGFyYWN0ZXJzJylcbiAgICogICAudXBzZXJ0KHsgaWQ6IDEsIG5hbWU6ICdIYW4gU29sbycgfSlcbiAgICogICAuc2VsZWN0KClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHVwc2VydCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgdXBzZXJ0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMSxcbiAgICogICAgICAgXCJuYW1lXCI6IFwiSGFuIFNvbG9cIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAxLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIkNyZWF0ZWRcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgc2VsZWN0PFxuICAgIFF1ZXJ5IGV4dGVuZHMgc3RyaW5nID0gJyonLFxuICAgIE5ld1Jlc3VsdE9uZSA9IEdldFJlc3VsdDxTY2hlbWEsIFJvdywgUmVsYXRpb25OYW1lLCBSZWxhdGlvbnNoaXBzLCBRdWVyeSwgQ2xpZW50T3B0aW9ucz4sXG4gID4oXG4gICAgY29sdW1ucz86IFF1ZXJ5XG4gICk6IFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBTY2hlbWEsXG4gICAgUm93LFxuICAgIE1ldGhvZCBleHRlbmRzICdSUEMnXG4gICAgICA/IFJlc3VsdCBleHRlbmRzIHVua25vd25bXVxuICAgICAgICA/IE5ld1Jlc3VsdE9uZVtdXG4gICAgICAgIDogTmV3UmVzdWx0T25lXG4gICAgICA6IE5ld1Jlc3VsdE9uZVtdLFxuICAgIFJlbGF0aW9uTmFtZSxcbiAgICBSZWxhdGlvbnNoaXBzLFxuICAgIE1ldGhvZCxcbiAgICBUaHJvd09uRXJyb3JcbiAgPiB7XG4gICAgLy8gUmVtb3ZlIHdoaXRlc3BhY2VzIGV4Y2VwdCB3aGVuIHF1b3RlZFxuICAgIGxldCBxdW90ZWQgPSBmYWxzZVxuICAgIGNvbnN0IGNsZWFuZWRDb2x1bW5zID0gKGNvbHVtbnMgPz8gJyonKVxuICAgICAgLnNwbGl0KCcnKVxuICAgICAgLm1hcCgoYykgPT4ge1xuICAgICAgICBpZiAoL1xccy8udGVzdChjKSAmJiAhcXVvdGVkKSB7XG4gICAgICAgICAgcmV0dXJuICcnXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGMgPT09ICdcIicpIHtcbiAgICAgICAgICBxdW90ZWQgPSAhcXVvdGVkXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNcbiAgICAgIH0pXG4gICAgICAuam9pbignJylcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuc2V0KCdzZWxlY3QnLCBjbGVhbmVkQ29sdW1ucylcbiAgICB0aGlzLmhlYWRlcnMuYXBwZW5kKCdQcmVmZXInLCAncmV0dXJuPXJlcHJlc2VudGF0aW9uJylcbiAgICByZXR1cm4gdGhpcyBhcyB1bmtub3duIGFzIFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgICBDbGllbnRPcHRpb25zLFxuICAgICAgU2NoZW1hLFxuICAgICAgUm93LFxuICAgICAgTWV0aG9kIGV4dGVuZHMgJ1JQQydcbiAgICAgICAgPyBSZXN1bHQgZXh0ZW5kcyB1bmtub3duW11cbiAgICAgICAgICA/IE5ld1Jlc3VsdE9uZVtdXG4gICAgICAgICAgOiBOZXdSZXN1bHRPbmVcbiAgICAgICAgOiBOZXdSZXN1bHRPbmVbXSxcbiAgICAgIFJlbGF0aW9uTmFtZSxcbiAgICAgIFJlbGF0aW9uc2hpcHMsXG4gICAgICBNZXRob2QsXG4gICAgICBUaHJvd09uRXJyb3JcbiAgICA+XG4gIH1cblxuICBvcmRlcjxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93PihcbiAgICBjb2x1bW46IENvbHVtbk5hbWUsXG4gICAgb3B0aW9ucz86IHsgYXNjZW5kaW5nPzogYm9vbGVhbjsgbnVsbHNGaXJzdD86IGJvb2xlYW47IHJlZmVyZW5jZWRUYWJsZT86IHVuZGVmaW5lZCB9XG4gICk6IHRoaXNcbiAgb3JkZXIoXG4gICAgY29sdW1uOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHsgYXNjZW5kaW5nPzogYm9vbGVhbjsgbnVsbHNGaXJzdD86IGJvb2xlYW47IHJlZmVyZW5jZWRUYWJsZT86IHN0cmluZyB9XG4gICk6IHRoaXNcbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIFVzZSBgb3B0aW9ucy5yZWZlcmVuY2VkVGFibGVgIGluc3RlYWQgb2YgYG9wdGlvbnMuZm9yZWlnblRhYmxlYFxuICAgKi9cbiAgb3JkZXI8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lLFxuICAgIG9wdGlvbnM/OiB7IGFzY2VuZGluZz86IGJvb2xlYW47IG51bGxzRmlyc3Q/OiBib29sZWFuOyBmb3JlaWduVGFibGU/OiB1bmRlZmluZWQgfVxuICApOiB0aGlzXG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBVc2UgYG9wdGlvbnMucmVmZXJlbmNlZFRhYmxlYCBpbnN0ZWFkIG9mIGBvcHRpb25zLmZvcmVpZ25UYWJsZWBcbiAgICovXG4gIG9yZGVyKFxuICAgIGNvbHVtbjogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiB7IGFzY2VuZGluZz86IGJvb2xlYW47IG51bGxzRmlyc3Q/OiBib29sZWFuOyBmb3JlaWduVGFibGU/OiBzdHJpbmcgfVxuICApOiB0aGlzXG4gIC8qKlxuICAgKiBPcmRlciB0aGUgcXVlcnkgcmVzdWx0IGJ5IGBjb2x1bW5gLlxuICAgKlxuICAgKiBZb3UgY2FuIGNhbGwgdGhpcyBtZXRob2QgbXVsdGlwbGUgdGltZXMgdG8gb3JkZXIgYnkgbXVsdGlwbGUgY29sdW1ucy5cbiAgICpcbiAgICogWW91IGNhbiBvcmRlciByZWZlcmVuY2VkIHRhYmxlcywgYnV0IGl0IG9ubHkgYWZmZWN0cyB0aGUgb3JkZXJpbmcgb2YgdGhlXG4gICAqIHBhcmVudCB0YWJsZSBpZiB5b3UgdXNlIGAhaW5uZXJgIGluIHRoZSBxdWVyeS5cbiAgICpcbiAgICogQHBhcmFtIGNvbHVtbiAtIFRoZSBjb2x1bW4gdG8gb3JkZXIgYnlcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBOYW1lZCBwYXJhbWV0ZXJzXG4gICAqIEBwYXJhbSBvcHRpb25zLmFzY2VuZGluZyAtIElmIGB0cnVlYCwgdGhlIHJlc3VsdCB3aWxsIGJlIGluIGFzY2VuZGluZyBvcmRlclxuICAgKiBAcGFyYW0gb3B0aW9ucy5udWxsc0ZpcnN0IC0gSWYgYHRydWVgLCBgbnVsbGBzIGFwcGVhciBmaXJzdC4gSWYgYGZhbHNlYCxcbiAgICogYG51bGxgcyBhcHBlYXIgbGFzdC5cbiAgICogQHBhcmFtIG9wdGlvbnMucmVmZXJlbmNlZFRhYmxlIC0gU2V0IHRoaXMgdG8gb3JkZXIgYSByZWZlcmVuY2VkIHRhYmxlIGJ5XG4gICAqIGl0cyBjb2x1bW5zXG4gICAqIEBwYXJhbSBvcHRpb25zLmZvcmVpZ25UYWJsZSAtIERlcHJlY2F0ZWQsIHVzZSBgb3B0aW9ucy5yZWZlcmVuY2VkVGFibGVgXG4gICAqIGluc3RlYWRcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBtb2RpZmllcnNcbiAgICpcbiAgICogQGV4YW1wbGUgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgKiAgIC5zZWxlY3QoJ2lkLCBuYW1lJylcbiAgICogICAub3JkZXIoJ2lkJywgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGNoYXJhY3RlcnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgY2hhcmFjdGVycyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTHVrZScpLFxuICAgKiAgICgyLCAnTGVpYScpLFxuICAgKiAgICgzLCAnSGFuJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDMsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIkhhblwiXG4gICAqICAgICB9LFxuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDIsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIkxlaWFcIlxuICAgKiAgICAgfSxcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJMdWtlXCJcbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gT24gYSByZWZlcmVuY2VkIHRhYmxlXG4gICAqIE9yZGVyaW5nIHdpdGggYHJlZmVyZW5jZWRUYWJsZWAgZG9lc24ndCBhZmZlY3QgdGhlIG9yZGVyaW5nIG9mIHRoZVxuICAgKiBwYXJlbnQgdGFibGUuXG4gICAqXG4gICAqIEBleGFtcGxlIE9uIGEgcmVmZXJlbmNlZCB0YWJsZVxuICAgKiBgYGB0c1xuICAgKiAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgICAuZnJvbSgnb3JjaGVzdHJhbF9zZWN0aW9ucycpXG4gICAqICAgICAuc2VsZWN0KGBcbiAgICogICAgICAgbmFtZSxcbiAgICogICAgICAgaW5zdHJ1bWVudHMgKFxuICAgKiAgICAgICAgIG5hbWVcbiAgICogICAgICAgKVxuICAgKiAgICAgYClcbiAgICogICAgIC5vcmRlcignbmFtZScsIHsgcmVmZXJlbmNlZFRhYmxlOiAnaW5zdHJ1bWVudHMnLCBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAqXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBPbiBhIHJlZmVyZW5jZWQgdGFibGVcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIG9yY2hlc3RyYWxfc2VjdGlvbnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGluc3RydW1lbnRzIChcbiAgICogICAgIGlkIGludDggcHJpbWFyeSBrZXksXG4gICAqICAgICBzZWN0aW9uX2lkIGludDggbm90IG51bGwgcmVmZXJlbmNlcyBvcmNoZXN0cmFsX3NlY3Rpb25zLFxuICAgKiAgICAgbmFtZSB0ZXh0XG4gICAqICAgKTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBvcmNoZXN0cmFsX3NlY3Rpb25zIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdzdHJpbmdzJyksXG4gICAqICAgKDIsICd3b29kd2luZHMnKTtcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBpbnN0cnVtZW50cyAoaWQsIHNlY3Rpb25faWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAxLCAnaGFycCcpLFxuICAgKiAgICgyLCAxLCAndmlvbGluJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9uIGEgcmVmZXJlbmNlZCB0YWJsZVxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcIm5hbWVcIjogXCJzdHJpbmdzXCIsXG4gICAqICAgICAgIFwiaW5zdHJ1bWVudHNcIjogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwibmFtZVwiOiBcInZpb2xpblwiXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICBcIm5hbWVcIjogXCJoYXJwXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIF1cbiAgICogICAgIH0sXG4gICAqICAgICB7XG4gICAqICAgICAgIFwibmFtZVwiOiBcIndvb2R3aW5kc1wiLFxuICAgKiAgICAgICBcImluc3RydW1lbnRzXCI6IFtdXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIE9yZGVyIHBhcmVudCB0YWJsZSBieSBhIHJlZmVyZW5jZWQgdGFibGVcbiAgICogT3JkZXJpbmcgd2l0aCBgcmVmZXJlbmNlZF90YWJsZShjb2wpYCBhZmZlY3RzIHRoZSBvcmRlcmluZyBvZiB0aGVcbiAgICogcGFyZW50IHRhYmxlLlxuICAgKlxuICAgKiBAZXhhbXBsZSBPcmRlciBwYXJlbnQgdGFibGUgYnkgYSByZWZlcmVuY2VkIHRhYmxlXG4gICAqIGBgYHRzXG4gICAqICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAgIC5mcm9tKCdpbnN0cnVtZW50cycpXG4gICAqICAgICAuc2VsZWN0KGBcbiAgICogICAgICAgbmFtZSxcbiAgICogICAgICAgc2VjdGlvbjpvcmNoZXN0cmFsX3NlY3Rpb25zIChcbiAgICogICAgICAgICBuYW1lXG4gICAqICAgICAgIClcbiAgICogICAgIGApXG4gICAqICAgICAub3JkZXIoJ3NlY3Rpb24obmFtZSknLCB7IGFzY2VuZGluZzogdHJ1ZSB9KVxuICAgKlxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgT3JkZXIgcGFyZW50IHRhYmxlIGJ5IGEgcmVmZXJlbmNlZCB0YWJsZVxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgb3JjaGVzdHJhbF9zZWN0aW9ucyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgaW5zdHJ1bWVudHMgKFxuICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICogICAgIHNlY3Rpb25faWQgaW50OCBub3QgbnVsbCByZWZlcmVuY2VzIG9yY2hlc3RyYWxfc2VjdGlvbnMsXG4gICAqICAgICBuYW1lIHRleHRcbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIG9yY2hlc3RyYWxfc2VjdGlvbnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ3N0cmluZ3MnKSxcbiAgICogICAoMiwgJ3dvb2R3aW5kcycpO1xuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGluc3RydW1lbnRzIChpZCwgc2VjdGlvbl9pZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsIDIsICdmbHV0ZScpLFxuICAgKiAgICgyLCAxLCAndmlvbGluJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9yZGVyIHBhcmVudCB0YWJsZSBieSBhIHJlZmVyZW5jZWQgdGFibGVcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwidmlvbGluXCIsXG4gICAqICAgICAgIFwib3JjaGVzdHJhbF9zZWN0aW9uc1wiOiB7XCJuYW1lXCI6IFwic3RyaW5nc1wifVxuICAgKiAgICAgfSxcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwiZmx1dGVcIixcbiAgICogICAgICAgXCJvcmNoZXN0cmFsX3NlY3Rpb25zXCI6IHtcIm5hbWVcIjogXCJ3b29kd2luZHNcIn1cbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBvcmRlcihcbiAgICBjb2x1bW46IHN0cmluZyxcbiAgICB7XG4gICAgICBhc2NlbmRpbmcgPSB0cnVlLFxuICAgICAgbnVsbHNGaXJzdCxcbiAgICAgIGZvcmVpZ25UYWJsZSxcbiAgICAgIHJlZmVyZW5jZWRUYWJsZSA9IGZvcmVpZ25UYWJsZSxcbiAgICB9OiB7XG4gICAgICBhc2NlbmRpbmc/OiBib29sZWFuXG4gICAgICBudWxsc0ZpcnN0PzogYm9vbGVhblxuICAgICAgZm9yZWlnblRhYmxlPzogc3RyaW5nXG4gICAgICByZWZlcmVuY2VkVGFibGU/OiBzdHJpbmdcbiAgICB9ID0ge31cbiAgKTogdGhpcyB7XG4gICAgY29uc3Qga2V5ID0gcmVmZXJlbmNlZFRhYmxlID8gYCR7cmVmZXJlbmNlZFRhYmxlfS5vcmRlcmAgOiAnb3JkZXInXG4gICAgY29uc3QgZXhpc3RpbmdPcmRlciA9IHRoaXMudXJsLnNlYXJjaFBhcmFtcy5nZXQoa2V5KVxuXG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLnNldChcbiAgICAgIGtleSxcbiAgICAgIGAke2V4aXN0aW5nT3JkZXIgPyBgJHtleGlzdGluZ09yZGVyfSxgIDogJyd9JHtjb2x1bW59LiR7YXNjZW5kaW5nID8gJ2FzYycgOiAnZGVzYyd9JHtcbiAgICAgICAgbnVsbHNGaXJzdCA9PT0gdW5kZWZpbmVkID8gJycgOiBudWxsc0ZpcnN0ID8gJy5udWxsc2ZpcnN0JyA6ICcubnVsbHNsYXN0J1xuICAgICAgfWBcbiAgICApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIC8qKlxuICAgKiBMaW1pdCB0aGUgcXVlcnkgcmVzdWx0IGJ5IGByb3dzYC5cbiAgICpcbiAgICogQHBhcmFtIHJvd3MgLSBUaGUgbWF4aW11bSBudW1iZXIgb2Ygcm93cyB0byByZXR1cm5cbiAgICogQHBhcmFtIG9wdGlvbnMgLSBOYW1lZCBwYXJhbWV0ZXJzXG4gICAqIEBwYXJhbSBvcHRpb25zLnJlZmVyZW5jZWRUYWJsZSAtIFNldCB0aGlzIHRvIGxpbWl0IHJvd3Mgb2YgcmVmZXJlbmNlZFxuICAgKiB0YWJsZXMgaW5zdGVhZCBvZiB0aGUgcGFyZW50IHRhYmxlXG4gICAqIEBwYXJhbSBvcHRpb25zLmZvcmVpZ25UYWJsZSAtIERlcHJlY2F0ZWQsIHVzZSBgb3B0aW9ucy5yZWZlcmVuY2VkVGFibGVgXG4gICAqIGluc3RlYWRcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBtb2RpZmllcnNcbiAgICpcbiAgICogQGV4YW1wbGUgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgKiAgIC5zZWxlY3QoJ25hbWUnKVxuICAgKiAgIC5saW1pdCgxKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwiTHVrZVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBPbiBhIHJlZmVyZW5jZWQgdGFibGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnb3JjaGVzdHJhbF9zZWN0aW9ucycpXG4gICAqICAgLnNlbGVjdChgXG4gICAqICAgICBuYW1lLFxuICAgKiAgICAgaW5zdHJ1bWVudHMgKFxuICAgKiAgICAgICBuYW1lXG4gICAqICAgICApXG4gICAqICAgYClcbiAgICogICAubGltaXQoMSwgeyByZWZlcmVuY2VkVGFibGU6ICdpbnN0cnVtZW50cycgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIE9uIGEgcmVmZXJlbmNlZCB0YWJsZVxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgb3JjaGVzdHJhbF9zZWN0aW9ucyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgaW5zdHJ1bWVudHMgKFxuICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICogICAgIHNlY3Rpb25faWQgaW50OCBub3QgbnVsbCByZWZlcmVuY2VzIG9yY2hlc3RyYWxfc2VjdGlvbnMsXG4gICAqICAgICBuYW1lIHRleHRcbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIG9yY2hlc3RyYWxfc2VjdGlvbnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ3N0cmluZ3MnKTtcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBpbnN0cnVtZW50cyAoaWQsIHNlY3Rpb25faWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAxLCAnaGFycCcpLFxuICAgKiAgICgyLCAxLCAndmlvbGluJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9uIGEgcmVmZXJlbmNlZCB0YWJsZVxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcIm5hbWVcIjogXCJzdHJpbmdzXCIsXG4gICAqICAgICAgIFwiaW5zdHJ1bWVudHNcIjogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwibmFtZVwiOiBcInZpb2xpblwiXG4gICAqICAgICAgICAgfVxuICAgKiAgICAgICBdXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgbGltaXQoXG4gICAgcm93czogbnVtYmVyLFxuICAgIHtcbiAgICAgIGZvcmVpZ25UYWJsZSxcbiAgICAgIHJlZmVyZW5jZWRUYWJsZSA9IGZvcmVpZ25UYWJsZSxcbiAgICB9OiB7IGZvcmVpZ25UYWJsZT86IHN0cmluZzsgcmVmZXJlbmNlZFRhYmxlPzogc3RyaW5nIH0gPSB7fVxuICApOiB0aGlzIHtcbiAgICBjb25zdCBrZXkgPSB0eXBlb2YgcmVmZXJlbmNlZFRhYmxlID09PSAndW5kZWZpbmVkJyA/ICdsaW1pdCcgOiBgJHtyZWZlcmVuY2VkVGFibGV9LmxpbWl0YFxuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5zZXQoa2V5LCBgJHtyb3dzfWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIC8qKlxuICAgKiBMaW1pdCB0aGUgcXVlcnkgcmVzdWx0IGJ5IHN0YXJ0aW5nIGF0IGFuIG9mZnNldCBgZnJvbWAgYW5kIGVuZGluZyBhdCB0aGUgb2Zmc2V0IGB0b2AuXG4gICAqIE9ubHkgcmVjb3JkcyB3aXRoaW4gdGhpcyByYW5nZSBhcmUgcmV0dXJuZWQuXG4gICAqIFRoaXMgcmVzcGVjdHMgdGhlIHF1ZXJ5IG9yZGVyIGFuZCBpZiB0aGVyZSBpcyBubyBvcmRlciBjbGF1c2UgdGhlIHJhbmdlIGNvdWxkIGJlaGF2ZSB1bmV4cGVjdGVkbHkuXG4gICAqIFRoZSBgZnJvbWAgYW5kIGB0b2AgdmFsdWVzIGFyZSAwLWJhc2VkIGFuZCBpbmNsdXNpdmU6IGByYW5nZSgxLCAzKWAgd2lsbCBpbmNsdWRlIHRoZSBzZWNvbmQsIHRoaXJkXG4gICAqIGFuZCBmb3VydGggcm93cyBvZiB0aGUgcXVlcnkuXG4gICAqXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIHN0YXJ0aW5nIGluZGV4IGZyb20gd2hpY2ggdG8gbGltaXQgdGhlIHJlc3VsdFxuICAgKiBAcGFyYW0gdG8gLSBUaGUgbGFzdCBpbmRleCB0byB3aGljaCB0byBsaW1pdCB0aGUgcmVzdWx0XG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKiBAcGFyYW0gb3B0aW9ucy5yZWZlcmVuY2VkVGFibGUgLSBTZXQgdGhpcyB0byBsaW1pdCByb3dzIG9mIHJlZmVyZW5jZWRcbiAgICogdGFibGVzIGluc3RlYWQgb2YgdGhlIHBhcmVudCB0YWJsZVxuICAgKiBAcGFyYW0gb3B0aW9ucy5mb3JlaWduVGFibGUgLSBEZXByZWNhdGVkLCB1c2UgYG9wdGlvbnMucmVmZXJlbmNlZFRhYmxlYFxuICAgKiBpbnN0ZWFkXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjaGFyYWN0ZXJzJylcbiAgICogICAuc2VsZWN0KCduYW1lJylcbiAgICogICAucmFuZ2UoMCwgMSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdMdWtlJyksXG4gICAqICAgKDIsICdMZWlhJyksXG4gICAqICAgKDMsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwibmFtZVwiOiBcIkx1a2VcIlxuICAgKiAgICAgfSxcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwiTGVpYVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgcmFuZ2UoXG4gICAgZnJvbTogbnVtYmVyLFxuICAgIHRvOiBudW1iZXIsXG4gICAge1xuICAgICAgZm9yZWlnblRhYmxlLFxuICAgICAgcmVmZXJlbmNlZFRhYmxlID0gZm9yZWlnblRhYmxlLFxuICAgIH06IHsgZm9yZWlnblRhYmxlPzogc3RyaW5nOyByZWZlcmVuY2VkVGFibGU/OiBzdHJpbmcgfSA9IHt9XG4gICk6IHRoaXMge1xuICAgIGNvbnN0IGtleU9mZnNldCA9XG4gICAgICB0eXBlb2YgcmVmZXJlbmNlZFRhYmxlID09PSAndW5kZWZpbmVkJyA/ICdvZmZzZXQnIDogYCR7cmVmZXJlbmNlZFRhYmxlfS5vZmZzZXRgXG4gICAgY29uc3Qga2V5TGltaXQgPSB0eXBlb2YgcmVmZXJlbmNlZFRhYmxlID09PSAndW5kZWZpbmVkJyA/ICdsaW1pdCcgOiBgJHtyZWZlcmVuY2VkVGFibGV9LmxpbWl0YFxuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5zZXQoa2V5T2Zmc2V0LCBgJHtmcm9tfWApXG4gICAgLy8gUmFuZ2UgaXMgaW5jbHVzaXZlLCBzbyBhZGQgMVxuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5zZXQoa2V5TGltaXQsIGAke3RvIC0gZnJvbSArIDF9YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIFNldCB0aGUgQWJvcnRTaWduYWwgZm9yIHRoZSBmZXRjaCByZXF1ZXN0LlxuICAgKlxuICAgKiBAcGFyYW0gc2lnbmFsIC0gVGhlIEFib3J0U2lnbmFsIHRvIHVzZSBmb3IgdGhlIGZldGNoIHJlcXVlc3RcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBtb2RpZmllcnNcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogWW91IGNhbiB1c2UgdGhpcyB0byBzZXQgYSB0aW1lb3V0IGZvciB0aGUgcmVxdWVzdC5cbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBBYm9ydGluZyByZXF1ZXN0cyBpbi1mbGlnaHRcbiAgICogWW91IGNhbiB1c2UgYW4gW2BBYm9ydENvbnRyb2xsZXJgXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvQWJvcnRDb250cm9sbGVyKSB0byBhYm9ydCByZXF1ZXN0cy5cbiAgICogTm90ZSB0aGF0IGBzdGF0dXNgIGFuZCBgc3RhdHVzVGV4dGAgZG9uJ3QgbWVhbiBhbnl0aGluZyBmb3IgYWJvcnRlZCByZXF1ZXN0cyBhcyB0aGUgcmVxdWVzdCB3YXNuJ3QgZnVsZmlsbGVkLlxuICAgKlxuICAgKiBAZXhhbXBsZSBBYm9ydGluZyByZXF1ZXN0cyBpbi1mbGlnaHRcbiAgICogYGBgdHNcbiAgICogY29uc3QgYWMgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcbiAgICpcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgndmVyeV9iaWdfdGFibGUnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5hYm9ydFNpZ25hbChhYy5zaWduYWwpXG4gICAqXG4gICAqIC8vIEFib3J0IHRoZSByZXF1ZXN0IGFmdGVyIDEwMCBtc1xuICAgKiBzZXRUaW1lb3V0KCgpID0+IGFjLmFib3J0KCksIDEwMClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQWJvcnRpbmcgcmVxdWVzdHMgaW4tZmxpZ2h0XG4gICAqIGBgYGpzb25cbiAgICogICB7XG4gICAqICAgICBcImVycm9yXCI6IHtcbiAgICogICAgICAgXCJtZXNzYWdlXCI6IFwiQWJvcnRFcnJvcjogVGhlIHVzZXIgYWJvcnRlZCBhIHJlcXVlc3QuXCIsXG4gICAqICAgICAgIFwiZGV0YWlsc1wiOiBcIlwiLFxuICAgKiAgICAgICBcImhpbnRcIjogXCJUaGUgcmVxdWVzdCB3YXMgYWJvcnRlZCBsb2NhbGx5IHZpYSB0aGUgcHJvdmlkZWQgQWJvcnRTaWduYWwuXCIsXG4gICAqICAgICAgIFwiY29kZVwiOiBcIlwiXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzdGF0dXNcIjogMCxcbiAgICogICAgIFwic3RhdHVzVGV4dFwiOiBcIlwiXG4gICAqICAgfVxuICAgKlxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU2V0IGEgdGltZW91dFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCd2ZXJ5X2JpZ190YWJsZScpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmFib3J0U2lnbmFsKEFib3J0U2lnbmFsLnRpbWVvdXQoMTAwMCAvKiBtcyAqXFwvKSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgU2V0IGEgdGltZW91dFxuICAgKiBgYGBqc29uXG4gICAqICAge1xuICAgKiAgICAgXCJlcnJvclwiOiB7XG4gICAqICAgICAgIFwibWVzc2FnZVwiOiBcIkZldGNoRXJyb3I6IFRoZSB1c2VyIGFib3J0ZWQgYSByZXF1ZXN0LlwiLFxuICAgKiAgICAgICBcImRldGFpbHNcIjogXCJcIixcbiAgICogICAgICAgXCJoaW50XCI6IFwiXCIsXG4gICAqICAgICAgIFwiY29kZVwiOiBcIlwiXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJzdGF0dXNcIjogNDAwLFxuICAgKiAgICAgXCJzdGF0dXNUZXh0XCI6IFwiQmFkIFJlcXVlc3RcIlxuICAgKiAgIH1cbiAgICpcbiAgICogYGBgXG4gICAqL1xuICBhYm9ydFNpZ25hbChzaWduYWw6IEFib3J0U2lnbmFsKTogdGhpcyB7XG4gICAgdGhpcy5zaWduYWwgPSBzaWduYWxcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiBgZGF0YWAgYXMgYSBzaW5nbGUgb2JqZWN0IGluc3RlYWQgb2YgYW4gYXJyYXkgb2Ygb2JqZWN0cy5cbiAgICpcbiAgICogUXVlcnkgcmVzdWx0IG11c3QgYmUgb25lIHJvdyAoZS5nLiB1c2luZyBgLmxpbWl0KDEpYCksIG90aGVyd2lzZSB0aGlzXG4gICAqIHJldHVybnMgYW4gZXJyb3IuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjaGFyYWN0ZXJzJylcbiAgICogICAuc2VsZWN0KCduYW1lJylcbiAgICogICAubGltaXQoMSlcbiAgICogICAuc2luZ2xlKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdMdWtlJyksXG4gICAqICAgKDIsICdMZWlhJyksXG4gICAqICAgKDMsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcIm5hbWVcIjogXCJMdWtlXCJcbiAgICogICB9LFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBzaW5nbGU8UmVzdWx0T25lID0gUmVzdWx0IGV4dGVuZHMgKGluZmVyIFJlc3VsdE9uZSlbXSA/IFJlc3VsdE9uZSA6IG5ldmVyPigpOiBQb3N0Z3Jlc3RCdWlsZGVyPFxuICAgIENsaWVudE9wdGlvbnMsXG4gICAgUmVzdWx0T25lLFxuICAgIFRocm93T25FcnJvclxuICA+IHtcbiAgICB0aGlzLmhlYWRlcnMuc2V0KCdBY2NlcHQnLCAnYXBwbGljYXRpb24vdm5kLnBncnN0Lm9iamVjdCtqc29uJylcbiAgICByZXR1cm4gdGhpcyBhcyB1bmtub3duIGFzIFBvc3RncmVzdEJ1aWxkZXI8Q2xpZW50T3B0aW9ucywgUmVzdWx0T25lLCBUaHJvd09uRXJyb3I+XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIGBkYXRhYCBhcyBhIHNpbmdsZSBvYmplY3QgaW5zdGVhZCBvZiBhbiBhcnJheSBvZiBvYmplY3RzLlxuICAgKlxuICAgKiBRdWVyeSByZXN1bHQgbXVzdCBiZSB6ZXJvIG9yIG9uZSByb3cgKGUuZy4gdXNpbmcgYC5saW1pdCgxKWApLCBvdGhlcndpc2VcbiAgICogdGhpcyByZXR1cm5zIGFuIGVycm9yLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIG1vZGlmaWVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmVxKCduYW1lJywgJ0thdG5pc3MnKVxuICAgKiAgIC5tYXliZVNpbmdsZSgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGNoYXJhY3RlcnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgY2hhcmFjdGVycyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTHVrZScpLFxuICAgKiAgICgyLCAnTGVpYScpLFxuICAgKiAgICgzLCAnSGFuJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgbWF5YmVTaW5nbGU8XG4gICAgUmVzdWx0T25lID0gUmVzdWx0IGV4dGVuZHMgKGluZmVyIFJlc3VsdE9uZSlbXSA/IFJlc3VsdE9uZSA6IG5ldmVyLFxuICA+KCk6IFBvc3RncmVzdEJ1aWxkZXI8Q2xpZW50T3B0aW9ucywgUmVzdWx0T25lIHwgbnVsbCwgVGhyb3dPbkVycm9yPiB7XG4gICAgLy8gTm8gQWNjZXB0IGhlYWRlciBvdmVycmlkZSDigJQgd2UgZmV0Y2ggYXMgYSBsaXN0IGFuZCBlbmZvcmNlIGNhcmRpbmFsaXR5IGNsaWVudC1zaWRlLlxuICAgIC8vIEZpeGVzIGh0dHBzOi8vZ2l0aHViLmNvbS9zdXBhYmFzZS9wb3N0Z3Jlc3QtanMvaXNzdWVzLzM2MSBmb3IgYWxsIHJlcXVlc3QgbWV0aG9kcy5cbiAgICB0aGlzLmlzTWF5YmVTaW5nbGUgPSB0cnVlXG4gICAgcmV0dXJuIHRoaXMgYXMgdW5rbm93biBhcyBQb3N0Z3Jlc3RCdWlsZGVyPENsaWVudE9wdGlvbnMsIFJlc3VsdE9uZSB8IG51bGwsIFRocm93T25FcnJvcj5cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gYGRhdGFgIGFzIGEgc3RyaW5nIGluIENTViBmb3JtYXQuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gUmV0dXJuIGRhdGEgYXMgQ1NWXG4gICAqIEJ5IGRlZmF1bHQsIHRoZSBkYXRhIGlzIHJldHVybmVkIGluIEpTT04gZm9ybWF0LCBidXQgY2FuIGFsc28gYmUgcmV0dXJuZWQgYXMgQ29tbWEgU2VwYXJhdGVkIFZhbHVlcy5cbiAgICpcbiAgICogQGV4YW1wbGUgUmV0dXJuIGRhdGEgYXMgQ1NWXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5jc3YoKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgUmV0dXJuIGRhdGEgYXMgQ1NWXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBSZXR1cm4gZGF0YSBhcyBDU1ZcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFwiaWQsbmFtZVxcbjEsTHVrZVxcbjIsTGVpYVxcbjMsSGFuXCIsXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIGNzdigpOiBQb3N0Z3Jlc3RCdWlsZGVyPENsaWVudE9wdGlvbnMsIHN0cmluZywgVGhyb3dPbkVycm9yPiB7XG4gICAgdGhpcy5oZWFkZXJzLnNldCgnQWNjZXB0JywgJ3RleHQvY3N2JylcbiAgICByZXR1cm4gdGhpcyBhcyB1bmtub3duIGFzIFBvc3RncmVzdEJ1aWxkZXI8Q2xpZW50T3B0aW9ucywgc3RyaW5nLCBUaHJvd09uRXJyb3I+XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIGBkYXRhYCBhcyBhbiBvYmplY3QgaW4gW0dlb0pTT05dKGh0dHBzOi8vZ2VvanNvbi5vcmcpIGZvcm1hdC5cbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBtb2RpZmllcnNcbiAgICovXG4gIGdlb2pzb24oKTogUG9zdGdyZXN0QnVpbGRlcjxDbGllbnRPcHRpb25zLCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgVGhyb3dPbkVycm9yPiB7XG4gICAgdGhpcy5oZWFkZXJzLnNldCgnQWNjZXB0JywgJ2FwcGxpY2F0aW9uL2dlbytqc29uJylcbiAgICByZXR1cm4gdGhpcyBhcyB1bmtub3duIGFzIFBvc3RncmVzdEJ1aWxkZXI8Q2xpZW50T3B0aW9ucywgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIFRocm93T25FcnJvcj5cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gYGRhdGFgIGFzIHRoZSBFWFBMQUlOIHBsYW4gZm9yIHRoZSBxdWVyeS5cbiAgICpcbiAgICogWW91IG5lZWQgdG8gZW5hYmxlIHRoZVxuICAgKiBbZGJfcGxhbl9lbmFibGVkXShodHRwczovL3N1cGFiYXNlLmNvbS9kb2NzL2d1aWRlcy9kYXRhYmFzZS9kZWJ1Z2dpbmctcGVyZm9ybWFuY2UjZW5hYmxpbmctZXhwbGFpbilcbiAgICogc2V0dGluZyBiZWZvcmUgdXNpbmcgdGhpcyBtZXRob2QuXG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5hbmFseXplIC0gSWYgYHRydWVgLCB0aGUgcXVlcnkgd2lsbCBiZSBleGVjdXRlZCBhbmQgdGhlXG4gICAqIGFjdHVhbCBydW4gdGltZSB3aWxsIGJlIHJldHVybmVkXG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zLnZlcmJvc2UgLSBJZiBgdHJ1ZWAsIHRoZSBxdWVyeSBpZGVudGlmaWVyIHdpbGwgYmUgcmV0dXJuZWRcbiAgICogYW5kIGBkYXRhYCB3aWxsIGluY2x1ZGUgdGhlIG91dHB1dCBjb2x1bW5zIG9mIHRoZSBxdWVyeVxuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5zZXR0aW5ncyAtIElmIGB0cnVlYCwgaW5jbHVkZSBpbmZvcm1hdGlvbiBvbiBjb25maWd1cmF0aW9uXG4gICAqIHBhcmFtZXRlcnMgdGhhdCBhZmZlY3QgcXVlcnkgcGxhbm5pbmdcbiAgICpcbiAgICogQHBhcmFtIG9wdGlvbnMuYnVmZmVycyAtIElmIGB0cnVlYCwgaW5jbHVkZSBpbmZvcm1hdGlvbiBvbiBidWZmZXIgdXNhZ2VcbiAgICpcbiAgICogQHBhcmFtIG9wdGlvbnMud2FsIC0gSWYgYHRydWVgLCBpbmNsdWRlIGluZm9ybWF0aW9uIG9uIFdBTCByZWNvcmQgZ2VuZXJhdGlvblxuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5mb3JtYXQgLSBUaGUgZm9ybWF0IG9mIHRoZSBvdXRwdXQsIGNhbiBiZSBgXCJ0ZXh0XCJgIChkZWZhdWx0KVxuICAgKiBvciBgXCJqc29uXCJgXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gR2V0IHRoZSBleGVjdXRpb24gcGxhblxuICAgKiBCeSBkZWZhdWx0LCB0aGUgZGF0YSBpcyByZXR1cm5lZCBpbiBURVhUIGZvcm1hdCwgYnV0IGNhbiBhbHNvIGJlIHJldHVybmVkIGFzIEpTT04gYnkgdXNpbmcgdGhlIGBmb3JtYXRgIHBhcmFtZXRlci5cbiAgICpcbiAgICogQGV4YW1wbGUgR2V0IHRoZSBleGVjdXRpb24gcGxhblxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjaGFyYWN0ZXJzJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAuZXhwbGFpbigpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBHZXQgdGhlIGV4ZWN1dGlvbiBwbGFuXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBHZXQgdGhlIGV4ZWN1dGlvbiBwbGFuXG4gICAqIGBgYGpzXG4gICAqIEFnZ3JlZ2F0ZSAgKGNvc3Q9MzMuMzQuLjMzLjM2IHJvd3M9MSB3aWR0aD0xMTIpXG4gICAqICAgLT4gIExpbWl0ICAoY29zdD0wLjAwLi4xOC4zMyByb3dzPTEwMDAgd2lkdGg9NDApXG4gICAqICAgICAgICAgLT4gIFNlcSBTY2FuIG9uIGNoYXJhY3RlcnMgIChjb3N0PTAuMDAuLjIyLjAwIHJvd3M9MTIwMCB3aWR0aD00MClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gR2V0IHRoZSBleGVjdXRpb24gcGxhbiB3aXRoIGFuYWx5emUgYW5kIHZlcmJvc2VcbiAgICogQnkgZGVmYXVsdCwgdGhlIGRhdGEgaXMgcmV0dXJuZWQgaW4gVEVYVCBmb3JtYXQsIGJ1dCBjYW4gYWxzbyBiZSByZXR1cm5lZCBhcyBKU09OIGJ5IHVzaW5nIHRoZSBgZm9ybWF0YCBwYXJhbWV0ZXIuXG4gICAqXG4gICAqIEBleGFtcGxlIEdldCB0aGUgZXhlY3V0aW9uIHBsYW4gd2l0aCBhbmFseXplIGFuZCB2ZXJib3NlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5leHBsYWluKHthbmFseXplOnRydWUsdmVyYm9zZTp0cnVlfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIEdldCB0aGUgZXhlY3V0aW9uIHBsYW4gd2l0aCBhbmFseXplIGFuZCB2ZXJib3NlXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBHZXQgdGhlIGV4ZWN1dGlvbiBwbGFuIHdpdGggYW5hbHl6ZSBhbmQgdmVyYm9zZVxuICAgKiBgYGBqc1xuICAgKiBBZ2dyZWdhdGUgIChjb3N0PTMzLjM0Li4zMy4zNiByb3dzPTEgd2lkdGg9MTEyKSAoYWN0dWFsIHRpbWU9MC4wNDEuLjAuMDQxIHJvd3M9MSBsb29wcz0xKVxuICAgKiAgIE91dHB1dDogTlVMTDo6YmlnaW50LCBjb3VudChST1coY2hhcmFjdGVycy5pZCwgY2hhcmFjdGVycy5uYW1lKSksIENPQUxFU0NFKGpzb25fYWdnKFJPVyhjaGFyYWN0ZXJzLmlkLCBjaGFyYWN0ZXJzLm5hbWUpKSwgJ1tdJzo6anNvbiksIE5VTExJRihjdXJyZW50X3NldHRpbmcoJ3Jlc3BvbnNlLmhlYWRlcnMnOjp0ZXh0LCB0cnVlKSwgJyc6OnRleHQpLCBOVUxMSUYoY3VycmVudF9zZXR0aW5nKCdyZXNwb25zZS5zdGF0dXMnOjp0ZXh0LCB0cnVlKSwgJyc6OnRleHQpXG4gICAqICAgLT4gIExpbWl0ICAoY29zdD0wLjAwLi4xOC4zMyByb3dzPTEwMDAgd2lkdGg9NDApIChhY3R1YWwgdGltZT0wLjAwNS4uMC4wMDYgcm93cz0zIGxvb3BzPTEpXG4gICAqICAgICAgICAgT3V0cHV0OiBjaGFyYWN0ZXJzLmlkLCBjaGFyYWN0ZXJzLm5hbWVcbiAgICogICAgICAgICAtPiAgU2VxIFNjYW4gb24gcHVibGljLmNoYXJhY3RlcnMgIChjb3N0PTAuMDAuLjIyLjAwIHJvd3M9MTIwMCB3aWR0aD00MCkgKGFjdHVhbCB0aW1lPTAuMDA0Li4wLjAwNSByb3dzPTMgbG9vcHM9MSlcbiAgICogICAgICAgICAgICAgICBPdXRwdXQ6IGNoYXJhY3RlcnMuaWQsIGNoYXJhY3RlcnMubmFtZVxuICAgKiBRdWVyeSBJZGVudGlmaWVyOiAtNDczMDY1NDI5MTYyMzMyMTE3M1xuICAgKiBQbGFubmluZyBUaW1lOiAwLjQwNyBtc1xuICAgKiBFeGVjdXRpb24gVGltZTogMC4xMTkgbXNcbiAgICogYGBgXG4gICAqL1xuICBleHBsYWluKHtcbiAgICBhbmFseXplID0gZmFsc2UsXG4gICAgdmVyYm9zZSA9IGZhbHNlLFxuICAgIHNldHRpbmdzID0gZmFsc2UsXG4gICAgYnVmZmVycyA9IGZhbHNlLFxuICAgIHdhbCA9IGZhbHNlLFxuICAgIGZvcm1hdCA9ICd0ZXh0JyxcbiAgfToge1xuICAgIGFuYWx5emU/OiBib29sZWFuXG4gICAgdmVyYm9zZT86IGJvb2xlYW5cbiAgICBzZXR0aW5ncz86IGJvb2xlYW5cbiAgICBidWZmZXJzPzogYm9vbGVhblxuICAgIHdhbD86IGJvb2xlYW5cbiAgICBmb3JtYXQ/OiAnanNvbicgfCAndGV4dCdcbiAgfSA9IHt9KSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IFtcbiAgICAgIGFuYWx5emUgPyAnYW5hbHl6ZScgOiBudWxsLFxuICAgICAgdmVyYm9zZSA/ICd2ZXJib3NlJyA6IG51bGwsXG4gICAgICBzZXR0aW5ncyA/ICdzZXR0aW5ncycgOiBudWxsLFxuICAgICAgYnVmZmVycyA/ICdidWZmZXJzJyA6IG51bGwsXG4gICAgICB3YWwgPyAnd2FsJyA6IG51bGwsXG4gICAgXVxuICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgLmpvaW4oJ3wnKVxuICAgIC8vIEFuIEFjY2VwdCBoZWFkZXIgY2FuIGNhcnJ5IG11bHRpcGxlIG1lZGlhIHR5cGVzIGJ1dCBwb3N0Z3Jlc3QtanMgYWx3YXlzIHNlbmRzIG9uZVxuICAgIGNvbnN0IGZvck1lZGlhdHlwZSA9IHRoaXMuaGVhZGVycy5nZXQoJ0FjY2VwdCcpID8/ICdhcHBsaWNhdGlvbi9qc29uJ1xuICAgIHRoaXMuaGVhZGVycy5zZXQoXG4gICAgICAnQWNjZXB0JyxcbiAgICAgIGBhcHBsaWNhdGlvbi92bmQucGdyc3QucGxhbiske2Zvcm1hdH07IGZvcj1cIiR7Zm9yTWVkaWF0eXBlfVwiOyBvcHRpb25zPSR7b3B0aW9uc307YFxuICAgIClcbiAgICBpZiAoZm9ybWF0ID09PSAnanNvbicpIHtcbiAgICAgIHJldHVybiB0aGlzIGFzIHVua25vd24gYXMgUG9zdGdyZXN0QnVpbGRlcjxcbiAgICAgICAgQ2xpZW50T3B0aW9ucyxcbiAgICAgICAgUmVjb3JkPHN0cmluZywgdW5rbm93bj5bXSxcbiAgICAgICAgVGhyb3dPbkVycm9yXG4gICAgICA+XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzIGFzIHVua25vd24gYXMgUG9zdGdyZXN0QnVpbGRlcjxDbGllbnRPcHRpb25zLCBzdHJpbmcsIFRocm93T25FcnJvcj5cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRHJ5LXJ1biB0aGlzIHJlcXVlc3Q6IGV4ZWN1dGUgdGhlIHF1ZXJ5IGJ1dCBkaXNjYXJkIHRoZSBjaGFuZ2VzLlxuICAgKlxuICAgKiBTZXJ2ZXItc2lkZSwgUG9zdGdSRVNUIHJ1bnMgdGhlIHF1ZXJ5IGluc2lkZSBhIHRyYW5zYWN0aW9uIGFuZCByb2xscyBpdCBiYWNrXG4gICAqIGluc3RlYWQgb2YgY29tbWl0dGluZy4gVGhlIHJlc3BvbnNlIHN0aWxsIGNvbnRhaW5zIHRoZSBkYXRhIHRoYXQgKndvdWxkKiBoYXZlXG4gICAqIGJlZW4gcmV0dXJuZWQg4oCUIGBSRVRVUk5JTkdgIGNsYXVzZXMgZXhlY3V0ZSBhbmQgUkxTLCB0cmlnZ2VycywgYW5kIGNvbnN0cmFpbnRzXG4gICAqIGFyZSBhbGwgZXZhbHVhdGVkIOKAlCBidXQgbm8gcm93IGlzIGFjdHVhbGx5IGluc2VydGVkLCB1cGRhdGVkLCBvciBkZWxldGVkLlxuICAgKlxuICAgKiBUaGlzIGFmZmVjdHMgb25seSB0aGUgc2luZ2xlIHJlcXVlc3QgaXQgaXMgY2hhaW5lZCB0by4gVGhlIEpTIGNhbGxlciBoYXMgbm9cbiAgICogaGFuZGxlIG9uIHRoZSB0cmFuc2FjdGlvbjogc3VwYWJhc2UtanMgZG9lcyBub3QgZ3JvdXAgbXVsdGlwbGUgcXVlcmllcyBpbnRvXG4gICAqIG9uZSB0cmFuc2FjdGlvbi4gRm9yIG11bHRpLXN0YXRlbWVudCB0cmFuc2FjdGlvbmFsIGxvZ2ljLCB1c2UgYSBkYXRhYmFzZVxuICAgKiBmdW5jdGlvbiAoYHN1cGFiYXNlLnJwYyguLi4pYCkuXG4gICAqXG4gICAqIFNldHMgdGhlIGBQcmVmZXI6IHR4PXJvbGxiYWNrYCBoZWFkZXIuIFNlZSBQb3N0Z1JFU1QncyBkb2NzIG9uIHRyYW5zYWN0aW9uXG4gICAqIHByZWZlcmVuY2VzIGZvciB0aGUgdW5kZXJseWluZyBtZWNoYW5pc20uXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIEBleGFtcGxlIFZhbGlkYXRlIGFuIGluc2VydCB3aXRob3V0IHBlcnNpc3RpbmdcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY291bnRyaWVzJylcbiAgICogICAuaW5zZXJ0KHsgbmFtZTogJ0ZyYW5jZScgfSlcbiAgICogICAuc2VsZWN0KClcbiAgICogICAucm9sbGJhY2soKVxuICAgKiAvLyBgZGF0YWAgc2hvd3Mgd2hhdCB3b3VsZCBoYXZlIGJlZW4gaW5zZXJ0ZWQ7IG5vdGhpbmcgaXMgc2F2ZWQuXG4gICAqIGBgYFxuICAgKi9cbiAgcm9sbGJhY2soKTogdGhpcyB7XG4gICAgdGhpcy5oZWFkZXJzLmFwcGVuZCgnUHJlZmVyJywgJ3R4PXJvbGxiYWNrJylcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIE92ZXJyaWRlIHRoZSB0eXBlIG9mIHRoZSByZXR1cm5lZCBgZGF0YWAuXG4gICAqXG4gICAqIEB0eXBlUGFyYW0gTmV3UmVzdWx0IC0gVGhlIG5ldyByZXN1bHQgdHlwZSB0byBvdmVycmlkZSB3aXRoXG4gICAqIEBkZXByZWNhdGVkIFVzZSBvdmVycmlkZVR5cGVzPHlvdXJUeXBlLCB7IG1lcmdlOiBmYWxzZSB9PigpIG1ldGhvZCBhdCB0aGUgZW5kIG9mIHlvdXIgY2FsbCBjaGFpbiBpbnN0ZWFkXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgbW9kaWZpZXJzXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gRGVwcmVjYXRlZDogdXNlIG92ZXJyaWRlVHlwZXMgbWV0aG9kIGluc3RlYWRcbiAgICpcbiAgICogQGV4YW1wbGUgT3ZlcnJpZGUgdHlwZSBvZiBzdWNjZXNzZnVsIHJlc3BvbnNlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY291bnRyaWVzJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAucmV0dXJuczxBcnJheTxNeVR5cGU+PigpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE92ZXJyaWRlIHR5cGUgb2Ygc3VjY2Vzc2Z1bCByZXNwb25zZVxuICAgKiBgYGBqc1xuICAgKiBsZXQgeDogdHlwZW9mIGRhdGEgLy8gTXlUeXBlW11cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIE92ZXJyaWRlIHR5cGUgb2Ygb2JqZWN0IHJlc3BvbnNlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY291bnRyaWVzJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAubWF5YmVTaW5nbGUoKVxuICAgKiAgIC5yZXR1cm5zPE15VHlwZT4oKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBPdmVycmlkZSB0eXBlIG9mIG9iamVjdCByZXNwb25zZVxuICAgKiBgYGBqc1xuICAgKiBsZXQgeDogdHlwZW9mIGRhdGEgLy8gTXlUeXBlIHwgbnVsbFxuICAgKiBgYGBcbiAgICovXG4gIHJldHVybnM8TmV3UmVzdWx0PigpOiBQb3N0Z3Jlc3RUcmFuc2Zvcm1CdWlsZGVyPFxuICAgIENsaWVudE9wdGlvbnMsXG4gICAgU2NoZW1hLFxuICAgIFJvdyxcbiAgICBDaGVja01hdGNoaW5nQXJyYXlUeXBlczxSZXN1bHQsIE5ld1Jlc3VsdD4sXG4gICAgUmVsYXRpb25OYW1lLFxuICAgIFJlbGF0aW9uc2hpcHMsXG4gICAgTWV0aG9kLFxuICAgIFRocm93T25FcnJvclxuICA+IHtcbiAgICByZXR1cm4gdGhpcyBhcyB1bmtub3duIGFzIFBvc3RncmVzdFRyYW5zZm9ybUJ1aWxkZXI8XG4gICAgICBDbGllbnRPcHRpb25zLFxuICAgICAgU2NoZW1hLFxuICAgICAgUm93LFxuICAgICAgQ2hlY2tNYXRjaGluZ0FycmF5VHlwZXM8UmVzdWx0LCBOZXdSZXN1bHQ+LFxuICAgICAgUmVsYXRpb25OYW1lLFxuICAgICAgUmVsYXRpb25zaGlwcyxcbiAgICAgIE1ldGhvZCxcbiAgICAgIFRocm93T25FcnJvclxuICAgID5cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIG1heGltdW0gbnVtYmVyIG9mIHJvd3MgdGhhdCBjYW4gYmUgYWZmZWN0ZWQgYnkgdGhlIHF1ZXJ5LlxuICAgKiBPbmx5IGF2YWlsYWJsZSBpbiBQb3N0Z1JFU1QgdjEzKyBhbmQgb25seSB3b3JrcyB3aXRoIFBBVENIIGFuZCBERUxFVEUgbWV0aG9kcy5cbiAgICpcbiAgICogQHBhcmFtIHJvd3MgLSBUaGUgbWF4aW11bSBudW1iZXIgb2Ygcm93cyB0aGF0IGNhbiBiZSBhZmZlY3RlZFxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIG1vZGlmaWVyc1xuICAgKi9cbiAgbWF4QWZmZWN0ZWQocm93czogbnVtYmVyKTogTWF4QWZmZWN0ZWRFbmFibGVkPENsaWVudE9wdGlvbnNbJ1Bvc3RncmVzdFZlcnNpb24nXT4gZXh0ZW5kcyB0cnVlXG4gICAgPyAvLyBUT0RPOiB1cGRhdGUgdGhlIFJQQyBjYXNlIHRvIG9ubHkgd29yayBvbiBSUEMgdGhhdCByZXR1cm5zIFNFVE9GIHJvd3NcbiAgICAgIE1ldGhvZCBleHRlbmRzICdQQVRDSCcgfCAnREVMRVRFJyB8ICdSUEMnXG4gICAgICA/IHRoaXNcbiAgICAgIDogSW52YWxpZE1ldGhvZEVycm9yPCdtYXhBZmZlY3RlZCBtZXRob2Qgb25seSBhdmFpbGFibGUgb24gdXBkYXRlIG9yIGRlbGV0ZSc+XG4gICAgOiBJbnZhbGlkTWV0aG9kRXJyb3I8J21heEFmZmVjdGVkIG1ldGhvZCBvbmx5IGF2YWlsYWJsZSBvbiBwb3N0Z3Jlc3QgMTMrJz4ge1xuICAgIHRoaXMuaGVhZGVycy5hcHBlbmQoJ1ByZWZlcicsICdoYW5kbGluZz1zdHJpY3QnKVxuICAgIHRoaXMuaGVhZGVycy5hcHBlbmQoJ1ByZWZlcicsIGBtYXgtYWZmZWN0ZWQ9JHtyb3dzfWApXG4gICAgcmV0dXJuIHRoaXMgYXMgdW5rbm93biBhcyBNYXhBZmZlY3RlZEVuYWJsZWQ8Q2xpZW50T3B0aW9uc1snUG9zdGdyZXN0VmVyc2lvbiddPiBleHRlbmRzIHRydWVcbiAgICAgID8gTWV0aG9kIGV4dGVuZHMgJ1BBVENIJyB8ICdERUxFVEUnIHwgJ1JQQydcbiAgICAgICAgPyB0aGlzXG4gICAgICAgIDogSW52YWxpZE1ldGhvZEVycm9yPCdtYXhBZmZlY3RlZCBtZXRob2Qgb25seSBhdmFpbGFibGUgb24gdXBkYXRlIG9yIGRlbGV0ZSc+XG4gICAgICA6IEludmFsaWRNZXRob2RFcnJvcjwnbWF4QWZmZWN0ZWQgbWV0aG9kIG9ubHkgYXZhaWxhYmxlIG9uIHBvc3RncmVzdCAxMysnPlxuICB9XG59XG4iLCJpbXBvcnQgUG9zdGdyZXN0VHJhbnNmb3JtQnVpbGRlciBmcm9tICcuL1Bvc3RncmVzdFRyYW5zZm9ybUJ1aWxkZXInXG5pbXBvcnQgeyBKc29uUGF0aFRvQWNjZXNzb3IsIEpzb25QYXRoVG9UeXBlIH0gZnJvbSAnLi9zZWxlY3QtcXVlcnktcGFyc2VyL3V0aWxzJ1xuaW1wb3J0IHsgQ2xpZW50U2VydmVyT3B0aW9ucywgR2VuZXJpY1NjaGVtYSB9IGZyb20gJy4vdHlwZXMvY29tbW9uL2NvbW1vbidcblxudHlwZSBGaWx0ZXJPcGVyYXRvciA9XG4gIHwgJ2VxJ1xuICB8ICduZXEnXG4gIHwgJ2d0J1xuICB8ICdndGUnXG4gIHwgJ2x0J1xuICB8ICdsdGUnXG4gIHwgJ2xpa2UnXG4gIHwgJ2lsaWtlJ1xuICB8ICdpcydcbiAgfCAnaXNkaXN0aW5jdCdcbiAgfCAnaW4nXG4gIHwgJ2NzJ1xuICB8ICdjZCdcbiAgfCAnc2wnXG4gIHwgJ3NyJ1xuICB8ICdueGwnXG4gIHwgJ254cidcbiAgfCAnYWRqJ1xuICB8ICdvdidcbiAgfCAnZnRzJ1xuICB8ICdwbGZ0cydcbiAgfCAncGhmdHMnXG4gIHwgJ3dmdHMnXG4gIHwgJ21hdGNoJ1xuICB8ICdpbWF0Y2gnXG5cbmV4cG9ydCB0eXBlIElzU3RyaW5nT3BlcmF0b3I8UGF0aCBleHRlbmRzIHN0cmluZz4gPSBQYXRoIGV4dGVuZHMgYCR7c3RyaW5nfS0+PiR7c3RyaW5nfWBcbiAgPyB0cnVlXG4gIDogZmFsc2VcblxuY29uc3QgUG9zdGdyZXN0UmVzZXJ2ZWRDaGFyc1JlZ2V4cCA9IG5ldyBSZWdFeHAoJ1ssKCldJylcblxuLy8gTWF0Y2ggcmVsYXRpb25zaGlwIGZpbHRlcnMgd2l0aCBgdGFibGUuY29sdW1uYCBzeW50YXggYW5kIHJlc29sdmUgdW5kZXJseWluZ1xuLy8gY29sdW1uIHZhbHVlLiBJZiBub3QgbWF0Y2hlZCwgZmFsbGJhY2sgdG8gZ2VuZXJpYyB0eXBlLlxuLy8gVE9ETzogVmFsaWRhdGUgdGhlIHJlbGF0aW9uc2hpcCBpdHNlbGYgYWxhIHNlbGVjdC1xdWVyeS1wYXJzZXIuIEN1cnJlbnRseSB3ZVxuLy8gYXNzdW1lIHRoYXQgYWxsIHRhYmxlcyBoYXZlIHZhbGlkIHJlbGF0aW9uc2hpcHMgdG8gZWFjaCBvdGhlciwgZGVzcGl0ZVxuLy8gbm9uZXhpc3RlbnQgZm9yZWlnbiBrZXlzLlxudHlwZSBSZXNvbHZlRmlsdGVyVmFsdWU8XG4gIFNjaGVtYSBleHRlbmRzIEdlbmVyaWNTY2hlbWEsXG4gIFJvdyBleHRlbmRzIFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nLFxuPiA9IENvbHVtbk5hbWUgZXh0ZW5kcyBgJHtpbmZlciBSZWxhdGlvbnNoaXBUYWJsZX0uJHtpbmZlciBSZW1haW5kZXJ9YFxuICA/IFJlbWFpbmRlciBleHRlbmRzIGAke2luZmVyIF99LiR7aW5mZXIgX31gXG4gICAgPyBSZXNvbHZlRmlsdGVyVmFsdWU8U2NoZW1hLCBSb3csIFJlbWFpbmRlcj5cbiAgICA6IFJlc29sdmVGaWx0ZXJSZWxhdGlvbnNoaXBWYWx1ZTxTY2hlbWEsIFJlbGF0aW9uc2hpcFRhYmxlLCBSZW1haW5kZXI+XG4gIDogQ29sdW1uTmFtZSBleHRlbmRzIGtleW9mIFJvd1xuICAgID8gUm93W0NvbHVtbk5hbWVdXG4gICAgOiAvLyBJZiB0aGUgY29sdW1uIHNlbGVjdGlvbiBpcyBhIGpzb25wYXRoIGxpa2UgYGRhdGEtPnZhbHVlYCBvciBgZGF0YS0+PnZhbHVlYCB3ZSBhdHRlbXB0IHRvIG1hdGNoXG4gICAgICAvLyB0aGUgZXhwZWN0ZWQgdHlwZSB3aXRoIHRoZSBwYXJzZWQgY3VzdG9tIGpzb24gdHlwZVxuICAgICAgSXNTdHJpbmdPcGVyYXRvcjxDb2x1bW5OYW1lPiBleHRlbmRzIHRydWVcbiAgICAgID8gc3RyaW5nXG4gICAgICA6IEpzb25QYXRoVG9UeXBlPFJvdywgSnNvblBhdGhUb0FjY2Vzc29yPENvbHVtbk5hbWU+PiBleHRlbmRzIGluZmVyIEpzb25QYXRoVmFsdWVcbiAgICAgICAgPyBKc29uUGF0aFZhbHVlIGV4dGVuZHMgbmV2ZXJcbiAgICAgICAgICA/IG5ldmVyXG4gICAgICAgICAgOiBKc29uUGF0aFZhbHVlXG4gICAgICAgIDogbmV2ZXJcblxudHlwZSBSZXNvbHZlRmlsdGVyUmVsYXRpb25zaGlwVmFsdWU8XG4gIFNjaGVtYSBleHRlbmRzIEdlbmVyaWNTY2hlbWEsXG4gIFJlbGF0aW9uc2hpcFRhYmxlIGV4dGVuZHMgc3RyaW5nLFxuICBSZWxhdGlvbnNoaXBDb2x1bW4gZXh0ZW5kcyBzdHJpbmcsXG4+ID0gU2NoZW1hWydUYWJsZXMnXSAmIFNjaGVtYVsnVmlld3MnXSBleHRlbmRzIGluZmVyIFRhYmxlc0FuZFZpZXdzXG4gID8gUmVsYXRpb25zaGlwVGFibGUgZXh0ZW5kcyBrZXlvZiBUYWJsZXNBbmRWaWV3c1xuICAgID8gJ1JvdycgZXh0ZW5kcyBrZXlvZiBUYWJsZXNBbmRWaWV3c1tSZWxhdGlvbnNoaXBUYWJsZV1cbiAgICAgID8gUmVsYXRpb25zaGlwQ29sdW1uIGV4dGVuZHMga2V5b2YgVGFibGVzQW5kVmlld3NbUmVsYXRpb25zaGlwVGFibGVdWydSb3cnXVxuICAgICAgICA/IFRhYmxlc0FuZFZpZXdzW1JlbGF0aW9uc2hpcFRhYmxlXVsnUm93J11bUmVsYXRpb25zaGlwQ29sdW1uXVxuICAgICAgICA6IHVua25vd25cbiAgICAgIDogdW5rbm93blxuICAgIDogdW5rbm93blxuICA6IG5ldmVyXG5cbmV4cG9ydCB0eXBlIEludmFsaWRNZXRob2RFcnJvcjxTIGV4dGVuZHMgc3RyaW5nPiA9IHsgRXJyb3I6IFMgfVxuXG50eXBlIE5vbk51bGxhYmxlQ29sdW1uPFQgZXh0ZW5kcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgQ29sIGV4dGVuZHMgc3RyaW5nPiA9IENvbCBleHRlbmRzIGtleW9mIFRcbiAgPyB7IFtLIGluIGtleW9mIFRdOiBLIGV4dGVuZHMgQ29sID8gTm9uTnVsbGFibGU8VFtLXT4gOiBUW0tdIH1cbiAgOiBUXG5cbnR5cGUgTmFycm93UmVzdWx0Q29sdW1uPFQsIENvbCBleHRlbmRzIHN0cmluZz4gPSBUIGV4dGVuZHMgKGluZmVyIEl0ZW0pW11cbiAgPyBJdGVtIGV4dGVuZHMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5cbiAgICA/IENvbCBleHRlbmRzIGtleW9mIEl0ZW1cbiAgICAgID8geyBbSyBpbiBrZXlvZiBJdGVtXTogSyBleHRlbmRzIENvbCA/IE5vbk51bGxhYmxlPEl0ZW1bS10+IDogSXRlbVtLXSB9W11cbiAgICAgIDogVFxuICAgIDogVFxuICA6IFQgZXh0ZW5kcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuICAgID8gQ29sIGV4dGVuZHMga2V5b2YgVFxuICAgICAgPyB7IFtLIGluIGtleW9mIFRdOiBLIGV4dGVuZHMgQ29sID8gTm9uTnVsbGFibGU8VFtLXT4gOiBUW0tdIH1cbiAgICAgIDogVFxuICAgIDogVFxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyPFxuICBDbGllbnRPcHRpb25zIGV4dGVuZHMgQ2xpZW50U2VydmVyT3B0aW9ucyxcbiAgU2NoZW1hIGV4dGVuZHMgR2VuZXJpY1NjaGVtYSxcbiAgUm93IGV4dGVuZHMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIFJlc3VsdCxcbiAgUmVsYXRpb25OYW1lID0gdW5rbm93bixcbiAgUmVsYXRpb25zaGlwcyA9IHVua25vd24sXG4gIE1ldGhvZCA9IHVua25vd24sXG4gIFRocm93T25FcnJvciBleHRlbmRzIGJvb2xlYW4gPSBmYWxzZSxcbj4gZXh0ZW5kcyBQb3N0Z3Jlc3RUcmFuc2Zvcm1CdWlsZGVyPFxuICBDbGllbnRPcHRpb25zLFxuICBTY2hlbWEsXG4gIFJvdyxcbiAgUmVzdWx0LFxuICBSZWxhdGlvbk5hbWUsXG4gIFJlbGF0aW9uc2hpcHMsXG4gIE1ldGhvZCxcbiAgVGhyb3dPbkVycm9yXG4+IHtcbiAgdGhyb3dPbkVycm9yKCk6IFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBTY2hlbWEsXG4gICAgUm93LFxuICAgIFJlc3VsdCxcbiAgICBSZWxhdGlvbk5hbWUsXG4gICAgUmVsYXRpb25zaGlwcyxcbiAgICBNZXRob2QsXG4gICAgdHJ1ZVxuICA+IHtcbiAgICByZXR1cm4gc3VwZXIudGhyb3dPbkVycm9yKCkgYXMgUG9zdGdyZXN0RmlsdGVyQnVpbGRlcjxcbiAgICAgIENsaWVudE9wdGlvbnMsXG4gICAgICBTY2hlbWEsXG4gICAgICBSb3csXG4gICAgICBSZXN1bHQsXG4gICAgICBSZWxhdGlvbk5hbWUsXG4gICAgICBSZWxhdGlvbnNoaXBzLFxuICAgICAgTWV0aG9kLFxuICAgICAgdHJ1ZVxuICAgID5cbiAgfVxuXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgYGNvbHVtbmAgaXMgZXF1YWwgdG8gYHZhbHVlYC5cbiAgICpcbiAgICogVG8gY2hlY2sgaWYgdGhlIHZhbHVlIG9mIGBjb2x1bW5gIGlzIE5VTEwsIHlvdSBzaG91bGQgdXNlIGAuaXMoKWAgaW5zdGVhZC5cbiAgICpcbiAgICogQHBhcmFtIGNvbHVtbiAtIFRoZSBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSB2YWx1ZSAtIFRoZSB2YWx1ZSB0byBmaWx0ZXIgd2l0aFxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIGZpbHRlcnNcbiAgICpcbiAgICogQGV4YW1wbGUgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5lcSgnbmFtZScsICdMZWlhJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdMdWtlJyksXG4gICAqICAgKDIsICdMZWlhJyksXG4gICAqICAgKDMsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMixcbiAgICogICAgICAgXCJuYW1lXCI6IFwiTGVpYVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgZXE8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lIGV4dGVuZHMga2V5b2YgUm93XG4gICAgICA/IENvbHVtbk5hbWVcbiAgICAgIDogQ29sdW1uTmFtZSBleHRlbmRzIGAke3N0cmluZ30uJHtzdHJpbmd9YCB8IGAke3N0cmluZ30tPiR7c3RyaW5nfWBcbiAgICAgICAgPyBDb2x1bW5OYW1lXG4gICAgICAgIDogc3RyaW5nIGV4dGVuZHMgQ29sdW1uTmFtZVxuICAgICAgICAgID8gc3RyaW5nXG4gICAgICAgICAgOiBrZXlvZiBSb3csXG4gICAgdmFsdWU6IFJlc29sdmVGaWx0ZXJWYWx1ZTxTY2hlbWEsIFJvdywgQ29sdW1uTmFtZT4gZXh0ZW5kcyBuZXZlclxuICAgICAgPyBOb25OdWxsYWJsZTx1bmtub3duPlxuICAgICAgOiBSZXNvbHZlRmlsdGVyVmFsdWU8U2NoZW1hLCBSb3csIENvbHVtbk5hbWU+IGV4dGVuZHMgaW5mZXIgUmVzb2x2ZWRGaWx0ZXJWYWx1ZVxuICAgICAgICA/IE5vbk51bGxhYmxlPFJlc29sdmVkRmlsdGVyVmFsdWU+XG4gICAgICAgIDogbmV2ZXJcbiAgKTogdGhpcyB7XG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4gYXMgc3RyaW5nLCBgZXEuJHt2YWx1ZX1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIGlzIG5vdCBlcXVhbCB0byBgdmFsdWVgLlxuICAgKlxuICAgKiBUaGlzIGZpbHRlciBkb2VzIG5vdCBpbmNsdWRlIHJvd3Mgd2hlcmUgYGNvbHVtbmAgaXMgYE5VTExgLiBUbyBtYXRjaCBudWxsXG4gICAqIHZhbHVlcywgdXNlIGAuaXMoY29sdW1uLCBudWxsKWAgaW5zdGVhZC5cbiAgICpcbiAgICogQHBhcmFtIGNvbHVtbiAtIFRoZSBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSB2YWx1ZSAtIFRoZSB2YWx1ZSB0byBmaWx0ZXIgd2l0aFxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIGZpbHRlcnNcbiAgICpcbiAgICogQGV4YW1wbGUgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5uZXEoJ25hbWUnLCAnTGVpYScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGNoYXJhY3RlcnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgY2hhcmFjdGVycyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTHVrZScpLFxuICAgKiAgICgyLCAnTGVpYScpLFxuICAgKiAgICgzLCAnSGFuJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIkx1a2VcIlxuICAgKiAgICAgfSxcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAzLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJIYW5cIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIG5lcTxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nPihcbiAgICBjb2x1bW46IENvbHVtbk5hbWUgZXh0ZW5kcyBrZXlvZiBSb3dcbiAgICAgID8gQ29sdW1uTmFtZVxuICAgICAgOiBDb2x1bW5OYW1lIGV4dGVuZHMgYCR7c3RyaW5nfS4ke3N0cmluZ31gIHwgYCR7c3RyaW5nfS0+JHtzdHJpbmd9YFxuICAgICAgICA/IENvbHVtbk5hbWVcbiAgICAgICAgOiBzdHJpbmcgZXh0ZW5kcyBDb2x1bW5OYW1lXG4gICAgICAgICAgPyBzdHJpbmdcbiAgICAgICAgICA6IGtleW9mIFJvdyxcbiAgICB2YWx1ZTogUmVzb2x2ZUZpbHRlclZhbHVlPFNjaGVtYSwgUm93LCBDb2x1bW5OYW1lPiBleHRlbmRzIG5ldmVyXG4gICAgICA/IHVua25vd25cbiAgICAgIDogUmVzb2x2ZUZpbHRlclZhbHVlPFNjaGVtYSwgUm93LCBDb2x1bW5OYW1lPiBleHRlbmRzIGluZmVyIFJlc29sdmVkXG4gICAgICAgID8gUmVzb2x2ZWRcbiAgICAgICAgOiBuZXZlclxuICApOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiBhcyBzdHJpbmcsIGBuZXEuJHt2YWx1ZX1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBndDxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93Pihjb2x1bW46IENvbHVtbk5hbWUsIHZhbHVlOiBSb3dbQ29sdW1uTmFtZV0pOiB0aGlzXG4gIGd0KGNvbHVtbjogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IHRoaXNcbiAgLyoqXG4gICAqIE1hdGNoIG9ubHkgcm93cyB3aGVyZSBgY29sdW1uYCBpcyBncmVhdGVyIHRoYW4gYHZhbHVlYC5cbiAgICpcbiAgICogQHBhcmFtIGNvbHVtbiAtIFRoZSBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSB2YWx1ZSAtIFRoZSB2YWx1ZSB0byBmaWx0ZXIgd2l0aFxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIGZpbHRlcnNcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBXaXRoIGBzZWxlY3QoKWBcbiAgICogV2hlbiB1c2luZyBbcmVzZXJ2ZWQgd29yZHNdKGh0dHBzOi8vd3d3LnBvc3RncmVzcWwub3JnL2RvY3MvY3VycmVudC9zcWwta2V5d29yZHMtYXBwZW5kaXguaHRtbCkgZm9yIGNvbHVtbiBuYW1lcyB5b3UgbmVlZFxuICAgKiB0byBhZGQgZG91YmxlIHF1b3RlcyBlLmcuIGAuZ3QoJ1wib3JkZXJcIicsIDIpYFxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmd0KCdpZCcsIDIpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGNoYXJhY3RlcnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgY2hhcmFjdGVycyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTHVrZScpLFxuICAgKiAgICgyLCAnTGVpYScpLFxuICAgKiAgICgzLCAnSGFuJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDMsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIkhhblwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgZ3QoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogdGhpcyB7XG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBndC4ke3ZhbHVlfWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIGd0ZTxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93Pihjb2x1bW46IENvbHVtbk5hbWUsIHZhbHVlOiBSb3dbQ29sdW1uTmFtZV0pOiB0aGlzXG4gIGd0ZShjb2x1bW46IHN0cmluZywgdmFsdWU6IHVua25vd24pOiB0aGlzXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgYGNvbHVtbmAgaXMgZ3JlYXRlciB0aGFuIG9yIGVxdWFsIHRvIGB2YWx1ZWAuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gZmlsdGVyIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjaGFyYWN0ZXJzJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAuZ3RlKCdpZCcsIDIpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGNoYXJhY3RlcnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgY2hhcmFjdGVycyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTHVrZScpLFxuICAgKiAgICgyLCAnTGVpYScpLFxuICAgKiAgICgzLCAnSGFuJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDIsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIkxlaWFcIlxuICAgKiAgICAgfSxcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAzLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJIYW5cIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIGd0ZShjb2x1bW46IHN0cmluZywgdmFsdWU6IHVua25vd24pOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGd0ZS4ke3ZhbHVlfWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIGx0PENvbHVtbk5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBSb3c+KGNvbHVtbjogQ29sdW1uTmFtZSwgdmFsdWU6IFJvd1tDb2x1bW5OYW1lXSk6IHRoaXNcbiAgbHQoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogdGhpc1xuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIGlzIGxlc3MgdGhhbiBgdmFsdWVgLlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGZpbHRlciB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmx0KCdpZCcsIDIpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGNoYXJhY3RlcnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgY2hhcmFjdGVycyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTHVrZScpLFxuICAgKiAgICgyLCAnTGVpYScpLFxuICAgKiAgICgzLCAnSGFuJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIkx1a2VcIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIGx0KGNvbHVtbjogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IHRoaXMge1xuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgbHQuJHt2YWx1ZX1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBsdGU8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oY29sdW1uOiBDb2x1bW5OYW1lLCB2YWx1ZTogUm93W0NvbHVtbk5hbWVdKTogdGhpc1xuICBsdGUoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogdGhpc1xuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIGlzIGxlc3MgdGhhbiBvciBlcXVhbCB0byBgdmFsdWVgLlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGZpbHRlciB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmx0ZSgnaWQnLCAyKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJMdWtlXCJcbiAgICogICAgIH0sXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMixcbiAgICogICAgICAgXCJuYW1lXCI6IFwiTGVpYVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgbHRlKGNvbHVtbjogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IHRoaXMge1xuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgbHRlLiR7dmFsdWV9YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgbGlrZTxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93Pihjb2x1bW46IENvbHVtbk5hbWUsIHBhdHRlcm46IHN0cmluZyk6IHRoaXNcbiAgbGlrZShjb2x1bW46IHN0cmluZywgcGF0dGVybjogc3RyaW5nKTogdGhpc1xuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIG1hdGNoZXMgYHBhdHRlcm5gIGNhc2Utc2Vuc2l0aXZlbHkuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gcGF0dGVybiAtIFRoZSBwYXR0ZXJuIHRvIG1hdGNoIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjaGFyYWN0ZXJzJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAubGlrZSgnbmFtZScsICclTHUlJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdMdWtlJyksXG4gICAqICAgKDIsICdMZWlhJyksXG4gICAqICAgKDMsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMSxcbiAgICogICAgICAgXCJuYW1lXCI6IFwiTHVrZVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgbGlrZShjb2x1bW46IHN0cmluZywgcGF0dGVybjogc3RyaW5nKTogdGhpcyB7XG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBsaWtlLiR7cGF0dGVybn1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBsaWtlQWxsT2Y8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lLFxuICAgIHBhdHRlcm5zOiByZWFkb25seSBzdHJpbmdbXVxuICApOiB0aGlzXG4gIGxpa2VBbGxPZihjb2x1bW46IHN0cmluZywgcGF0dGVybnM6IHJlYWRvbmx5IHN0cmluZ1tdKTogdGhpc1xuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIG1hdGNoZXMgYWxsIG9mIGBwYXR0ZXJuc2AgY2FzZS1zZW5zaXRpdmVseS5cbiAgICpcbiAgICogQHBhcmFtIGNvbHVtbiAtIFRoZSBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSBwYXR0ZXJucyAtIFRoZSBwYXR0ZXJucyB0byBtYXRjaCB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKi9cbiAgbGlrZUFsbE9mKGNvbHVtbjogc3RyaW5nLCBwYXR0ZXJuczogcmVhZG9ubHkgc3RyaW5nW10pOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGxpa2UoYWxsKS57JHtwYXR0ZXJucy5qb2luKCcsJyl9fWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIGxpa2VBbnlPZjxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93PihcbiAgICBjb2x1bW46IENvbHVtbk5hbWUsXG4gICAgcGF0dGVybnM6IHJlYWRvbmx5IHN0cmluZ1tdXG4gICk6IHRoaXNcbiAgbGlrZUFueU9mKGNvbHVtbjogc3RyaW5nLCBwYXR0ZXJuczogcmVhZG9ubHkgc3RyaW5nW10pOiB0aGlzXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgYGNvbHVtbmAgbWF0Y2hlcyBhbnkgb2YgYHBhdHRlcm5zYCBjYXNlLXNlbnNpdGl2ZWx5LlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHBhdHRlcm5zIC0gVGhlIHBhdHRlcm5zIHRvIG1hdGNoIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqL1xuICBsaWtlQW55T2YoY29sdW1uOiBzdHJpbmcsIHBhdHRlcm5zOiByZWFkb25seSBzdHJpbmdbXSk6IHRoaXMge1xuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgbGlrZShhbnkpLnske3BhdHRlcm5zLmpvaW4oJywnKX19YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgaWxpa2U8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oY29sdW1uOiBDb2x1bW5OYW1lLCBwYXR0ZXJuOiBzdHJpbmcpOiB0aGlzXG4gIGlsaWtlKGNvbHVtbjogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcpOiB0aGlzXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgYGNvbHVtbmAgbWF0Y2hlcyBgcGF0dGVybmAgY2FzZS1pbnNlbnNpdGl2ZWx5LlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHBhdHRlcm4gLSBUaGUgcGF0dGVybiB0byBtYXRjaCB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmlsaWtlKCduYW1lJywgJyVsdSUnKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJMdWtlXCJcbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBpbGlrZShjb2x1bW46IHN0cmluZywgcGF0dGVybjogc3RyaW5nKTogdGhpcyB7XG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBpbGlrZS4ke3BhdHRlcm59YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgaWxpa2VBbGxPZjxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93PihcbiAgICBjb2x1bW46IENvbHVtbk5hbWUsXG4gICAgcGF0dGVybnM6IHJlYWRvbmx5IHN0cmluZ1tdXG4gICk6IHRoaXNcbiAgaWxpa2VBbGxPZihjb2x1bW46IHN0cmluZywgcGF0dGVybnM6IHJlYWRvbmx5IHN0cmluZ1tdKTogdGhpc1xuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIG1hdGNoZXMgYWxsIG9mIGBwYXR0ZXJuc2AgY2FzZS1pbnNlbnNpdGl2ZWx5LlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHBhdHRlcm5zIC0gVGhlIHBhdHRlcm5zIHRvIG1hdGNoIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqL1xuICBpbGlrZUFsbE9mKGNvbHVtbjogc3RyaW5nLCBwYXR0ZXJuczogcmVhZG9ubHkgc3RyaW5nW10pOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGlsaWtlKGFsbCkueyR7cGF0dGVybnMuam9pbignLCcpfX1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBpbGlrZUFueU9mPENvbHVtbk5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBSb3c+KFxuICAgIGNvbHVtbjogQ29sdW1uTmFtZSxcbiAgICBwYXR0ZXJuczogcmVhZG9ubHkgc3RyaW5nW11cbiAgKTogdGhpc1xuICBpbGlrZUFueU9mKGNvbHVtbjogc3RyaW5nLCBwYXR0ZXJuczogcmVhZG9ubHkgc3RyaW5nW10pOiB0aGlzXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgYGNvbHVtbmAgbWF0Y2hlcyBhbnkgb2YgYHBhdHRlcm5zYCBjYXNlLWluc2Vuc2l0aXZlbHkuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gcGF0dGVybnMgLSBUaGUgcGF0dGVybnMgdG8gbWF0Y2ggd2l0aFxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIGZpbHRlcnNcbiAgICovXG4gIGlsaWtlQW55T2YoY29sdW1uOiBzdHJpbmcsIHBhdHRlcm5zOiByZWFkb25seSBzdHJpbmdbXSk6IHRoaXMge1xuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgaWxpa2UoYW55KS57JHtwYXR0ZXJucy5qb2luKCcsJyl9fWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHJlZ2V4TWF0Y2g8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oY29sdW1uOiBDb2x1bW5OYW1lLCBwYXR0ZXJuOiBzdHJpbmcpOiB0aGlzXG4gIHJlZ2V4TWF0Y2goY29sdW1uOiBzdHJpbmcsIHBhdHRlcm46IHN0cmluZyk6IHRoaXNcbiAgLyoqXG4gICAqIE1hdGNoIG9ubHkgcm93cyB3aGVyZSBgY29sdW1uYCBtYXRjaGVzIHRoZSBQb3N0Z3JlU1FMIHJlZ2V4IGBwYXR0ZXJuYFxuICAgKiBjYXNlLXNlbnNpdGl2ZWx5ICh1c2luZyB0aGUgYH5gIG9wZXJhdG9yKS5cbiAgICpcbiAgICogQHBhcmFtIGNvbHVtbiAtIFRoZSBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSBwYXR0ZXJuIC0gVGhlIFBvc3RncmVTUUwgcmVndWxhciBleHByZXNzaW9uIHBhdHRlcm4gdG8gbWF0Y2ggd2l0aFxuICAgKi9cbiAgcmVnZXhNYXRjaChjb2x1bW46IHN0cmluZywgcGF0dGVybjogc3RyaW5nKTogdGhpcyB7XG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBtYXRjaC4ke3BhdHRlcm59YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgcmVnZXhJTWF0Y2g8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oY29sdW1uOiBDb2x1bW5OYW1lLCBwYXR0ZXJuOiBzdHJpbmcpOiB0aGlzXG4gIHJlZ2V4SU1hdGNoKGNvbHVtbjogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcpOiB0aGlzXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgYGNvbHVtbmAgbWF0Y2hlcyB0aGUgUG9zdGdyZVNRTCByZWdleCBgcGF0dGVybmBcbiAgICogY2FzZS1pbnNlbnNpdGl2ZWx5ICh1c2luZyB0aGUgYH4qYCBvcGVyYXRvcikuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gcGF0dGVybiAtIFRoZSBQb3N0Z3JlU1FMIHJlZ3VsYXIgZXhwcmVzc2lvbiBwYXR0ZXJuIHRvIG1hdGNoIHdpdGhcbiAgICovXG4gIHJlZ2V4SU1hdGNoKGNvbHVtbjogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcpOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGltYXRjaC4ke3BhdHRlcm59YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgaXM8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lLFxuICAgIHZhbHVlOiBSb3dbQ29sdW1uTmFtZV0gJiAoYm9vbGVhbiB8IG51bGwpXG4gICk6IHRoaXNcbiAgaXMoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiBib29sZWFuIHwgbnVsbCk6IHRoaXNcbiAgLyoqXG4gICAqIE1hdGNoIG9ubHkgcm93cyB3aGVyZSBgY29sdW1uYCBJUyBgdmFsdWVgLlxuICAgKlxuICAgKiBGb3Igbm9uLWJvb2xlYW4gY29sdW1ucywgdGhpcyBpcyBvbmx5IHJlbGV2YW50IGZvciBjaGVja2luZyBpZiB0aGUgdmFsdWUgb2ZcbiAgICogYGNvbHVtbmAgaXMgTlVMTCBieSBzZXR0aW5nIGB2YWx1ZWAgdG8gYG51bGxgLlxuICAgKlxuICAgKiBGb3IgYm9vbGVhbiBjb2x1bW5zLCB5b3UgY2FuIGFsc28gc2V0IGB2YWx1ZWAgdG8gYHRydWVgIG9yIGBmYWxzZWAgYW5kIGl0XG4gICAqIHdpbGwgYmVoYXZlIHRoZSBzYW1lIHdheSBhcyBgLmVxKClgLlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGZpbHRlciB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIENoZWNraW5nIGZvciBudWxsbmVzcywgdHJ1ZSBvciBmYWxzZVxuICAgKiBVc2luZyB0aGUgYGVxKClgIGZpbHRlciBkb2Vzbid0IHdvcmsgd2hlbiBmaWx0ZXJpbmcgZm9yIGBudWxsYC5cbiAgICpcbiAgICogSW5zdGVhZCwgeW91IG5lZWQgdG8gdXNlIGBpcygpYC5cbiAgICpcbiAgICogQGV4YW1wbGUgQ2hlY2tpbmcgZm9yIG51bGxuZXNzLCB0cnVlIG9yIGZhbHNlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NvdW50cmllcycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmlzKCduYW1lJywgbnVsbClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIENoZWNraW5nIGZvciBudWxsbmVzcywgdHJ1ZSBvciBmYWxzZVxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY291bnRyaWVzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNvdW50cmllcyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnbnVsbCcpLFxuICAgKiAgICgyLCBudWxsKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQ2hlY2tpbmcgZm9yIG51bGxuZXNzLCB0cnVlIG9yIGZhbHNlXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMixcbiAgICogICAgICAgXCJuYW1lXCI6IFwibnVsbFwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgaXMoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiBib29sZWFuIHwgbnVsbCk6IHRoaXMge1xuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgaXMuJHt2YWx1ZX1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIElTIERJU1RJTkNUIEZST00gYHZhbHVlYC5cbiAgICpcbiAgICogVW5saWtlIGAubmVxKClgLCB0aGlzIHRyZWF0cyBgTlVMTGAgYXMgYSBjb21wYXJhYmxlIHZhbHVlLiBUd28gYE5VTExgIHZhbHVlc1xuICAgKiBhcmUgY29uc2lkZXJlZCBlcXVhbCAobm90IGRpc3RpbmN0KSwgYW5kIGNvbXBhcmluZyBgTlVMTGAgd2l0aCBhbnkgbm9uLU5VTExcbiAgICogdmFsdWUgcmV0dXJucyB0cnVlIChkaXN0aW5jdCkuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gZmlsdGVyIHdpdGhcbiAgICovXG4gIGlzRGlzdGluY3Q8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lLFxuICAgIHZhbHVlOiBSZXNvbHZlRmlsdGVyVmFsdWU8U2NoZW1hLCBSb3csIENvbHVtbk5hbWU+IGV4dGVuZHMgbmV2ZXJcbiAgICAgID8gdW5rbm93blxuICAgICAgOiBSZXNvbHZlRmlsdGVyVmFsdWU8U2NoZW1hLCBSb3csIENvbHVtbk5hbWU+IGV4dGVuZHMgaW5mZXIgUmVzb2x2ZWRGaWx0ZXJWYWx1ZVxuICAgICAgICA/IFJlc29sdmVkRmlsdGVyVmFsdWVcbiAgICAgICAgOiBuZXZlclxuICApOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGlzZGlzdGluY3QuJHt2YWx1ZX1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIGlzIGluY2x1ZGVkIGluIHRoZSBgdmFsdWVzYCBhcnJheS5cbiAgICpcbiAgICogQHBhcmFtIGNvbHVtbiAtIFRoZSBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSB2YWx1ZXMgLSBUaGUgdmFsdWVzIGFycmF5IHRvIGZpbHRlciB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgpXG4gICAqICAgLmluKCduYW1lJywgWydMZWlhJywgJ0hhbiddKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAyLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJMZWlhXCJcbiAgICogICAgIH0sXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMyxcbiAgICogICAgICAgXCJuYW1lXCI6IFwiSGFuXCJcbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBpbjxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nPihcbiAgICBjb2x1bW46IENvbHVtbk5hbWUsXG4gICAgdmFsdWVzOiBSZWFkb25seUFycmF5PFxuICAgICAgUmVzb2x2ZUZpbHRlclZhbHVlPFNjaGVtYSwgUm93LCBDb2x1bW5OYW1lPiBleHRlbmRzIG5ldmVyXG4gICAgICAgID8gdW5rbm93blxuICAgICAgICA6IC8vIFdlIHdhbnQgdG8gaW5mZXIgdGhlIHR5cGUgYmVmb3JlIHdyYXBwaW5nIGl0IGludG8gYSBgTm9uTnVsbGFibGVgIHRvIGF2b2lkIHRvbyBkZWVwXG4gICAgICAgICAgLy8gdHlwZSByZXNvbHV0aW9uIGVycm9yXG4gICAgICAgICAgUmVzb2x2ZUZpbHRlclZhbHVlPFNjaGVtYSwgUm93LCBDb2x1bW5OYW1lPiBleHRlbmRzIGluZmVyIFJlc29sdmVkRmlsdGVyVmFsdWVcbiAgICAgICAgICA/IFJlc29sdmVkRmlsdGVyVmFsdWVcbiAgICAgICAgICA6IC8vIFdlIHNob3VsZCBuZXZlciBlbnRlciB0aGlzIGNhc2UgYXMgYWxsIHRoZSBicmFuY2hlcyBhcmUgY292ZXJlZCBhYm92ZVxuICAgICAgICAgICAgbmV2ZXJcbiAgICA+XG4gICk6IHRoaXMge1xuICAgIGNvbnN0IGNsZWFuZWRWYWx1ZXMgPSBBcnJheS5mcm9tKG5ldyBTZXQodmFsdWVzKSlcbiAgICAgIC5tYXAoKHMpID0+IHtcbiAgICAgICAgLy8gaGFuZGxlIHBvc3RncmVzdCByZXNlcnZlZCBjaGFyYWN0ZXJzXG4gICAgICAgIC8vIGh0dHBzOi8vcG9zdGdyZXN0Lm9yZy9lbi92Ny4wLjAvYXBpLmh0bWwjcmVzZXJ2ZWQtY2hhcmFjdGVyc1xuICAgICAgICBpZiAodHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIFBvc3RncmVzdFJlc2VydmVkQ2hhcnNSZWdleHAudGVzdChzKSkgcmV0dXJuIGBcIiR7c31cImBcbiAgICAgICAgZWxzZSByZXR1cm4gYCR7c31gXG4gICAgICB9KVxuICAgICAgLmpvaW4oJywnKVxuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgaW4uKCR7Y2xlYW5lZFZhbHVlc30pYClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIE1hdGNoIG9ubHkgcm93cyB3aGVyZSBgY29sdW1uYCBpcyBOT1QgaW5jbHVkZWQgaW4gdGhlIGB2YWx1ZXNgIGFycmF5LlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHZhbHVlcyAtIFRoZSB2YWx1ZXMgYXJyYXkgdG8gZmlsdGVyIHdpdGhcbiAgICovXG4gIG5vdEluPENvbHVtbk5hbWUgZXh0ZW5kcyBzdHJpbmc+KFxuICAgIGNvbHVtbjogQ29sdW1uTmFtZSxcbiAgICB2YWx1ZXM6IFJlYWRvbmx5QXJyYXk8XG4gICAgICBSZXNvbHZlRmlsdGVyVmFsdWU8U2NoZW1hLCBSb3csIENvbHVtbk5hbWU+IGV4dGVuZHMgbmV2ZXJcbiAgICAgICAgPyB1bmtub3duXG4gICAgICAgIDogUmVzb2x2ZUZpbHRlclZhbHVlPFNjaGVtYSwgUm93LCBDb2x1bW5OYW1lPiBleHRlbmRzIGluZmVyIFJlc29sdmVkRmlsdGVyVmFsdWVcbiAgICAgICAgICA/IFJlc29sdmVkRmlsdGVyVmFsdWVcbiAgICAgICAgICA6IG5ldmVyXG4gICAgPlxuICApOiB0aGlzIHtcbiAgICBjb25zdCBjbGVhbmVkVmFsdWVzID0gQXJyYXkuZnJvbShuZXcgU2V0KHZhbHVlcykpXG4gICAgICAubWFwKChzKSA9PiB7XG4gICAgICAgIC8vIGhhbmRsZSBwb3N0Z3Jlc3QgcmVzZXJ2ZWQgY2hhcmFjdGVyc1xuICAgICAgICAvLyBodHRwczovL3Bvc3RncmVzdC5vcmcvZW4vdjcuMC4wL2FwaS5odG1sI3Jlc2VydmVkLWNoYXJhY3RlcnNcbiAgICAgICAgaWYgKHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBQb3N0Z3Jlc3RSZXNlcnZlZENoYXJzUmVnZXhwLnRlc3QocykpIHJldHVybiBgXCIke3N9XCJgXG4gICAgICAgIGVsc2UgcmV0dXJuIGAke3N9YFxuICAgICAgfSlcbiAgICAgIC5qb2luKCcsJylcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYG5vdC5pbi4oJHtjbGVhbmVkVmFsdWVzfSlgKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBjb250YWluczxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93PihcbiAgICBjb2x1bW46IENvbHVtbk5hbWUsXG4gICAgdmFsdWU6IHN0cmluZyB8IFJlYWRvbmx5QXJyYXk8Um93W0NvbHVtbk5hbWVdPiB8IFJlY29yZDxzdHJpbmcsIHVua25vd24+XG4gICk6IHRoaXNcbiAgY29udGFpbnMoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcgfCByZWFkb25seSB1bmtub3duW10gfCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHRoaXNcbiAgLyoqXG4gICAqIE9ubHkgcmVsZXZhbnQgZm9yIGpzb25iLCBhcnJheSwgYW5kIHJhbmdlIGNvbHVtbnMuIE1hdGNoIG9ubHkgcm93cyB3aGVyZVxuICAgKiBgY29sdW1uYCBjb250YWlucyBldmVyeSBlbGVtZW50IGFwcGVhcmluZyBpbiBgdmFsdWVgLlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIGpzb25iLCBhcnJheSwgb3IgcmFuZ2UgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gdmFsdWUgLSBUaGUganNvbmIsIGFycmF5LCBvciByYW5nZSB2YWx1ZSB0byBmaWx0ZXIgd2l0aFxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIGZpbHRlcnNcbiAgICpcbiAgICogQGV4YW1wbGUgT24gYXJyYXkgY29sdW1uc1xuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdpc3N1ZXMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5jb250YWlucygndGFncycsIFsnaXM6b3BlbicsICdwcmlvcml0eTpsb3cnXSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIE9uIGFycmF5IGNvbHVtbnNcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGlzc3VlcyAoXG4gICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgKiAgICAgdGl0bGUgdGV4dCxcbiAgICogICAgIHRhZ3MgdGV4dFtdXG4gICAqICAgKTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBpc3N1ZXMgKGlkLCB0aXRsZSwgdGFncylcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdDYWNoZSBpbnZhbGlkYXRpb24gaXMgbm90IHdvcmtpbmcnLCBhcnJheVsnaXM6b3BlbicsICdzZXZlcml0eTpoaWdoJywgJ3ByaW9yaXR5OmxvdyddKSxcbiAgICogICAoMiwgJ1VzZSBiZXR0ZXIgbmFtZXMnLCBhcnJheVsnaXM6b3BlbicsICdzZXZlcml0eTpsb3cnLCAncHJpb3JpdHk6bWVkaXVtJ10pO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBPbiBhcnJheSBjb2x1bW5zXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwidGl0bGVcIjogXCJDYWNoZSBpbnZhbGlkYXRpb24gaXMgbm90IHdvcmtpbmdcIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBPbiByYW5nZSBjb2x1bW5zXG4gICAqIFBvc3RncmVzIHN1cHBvcnRzIGEgbnVtYmVyIG9mIFtyYW5nZVxuICAgKiB0eXBlc10oaHR0cHM6Ly93d3cucG9zdGdyZXNxbC5vcmcvZG9jcy9jdXJyZW50L3JhbmdldHlwZXMuaHRtbCkuIFlvdVxuICAgKiBjYW4gZmlsdGVyIG9uIHJhbmdlIGNvbHVtbnMgdXNpbmcgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiByYW5nZVxuICAgKiB2YWx1ZXMuXG4gICAqXG4gICAqIEBleGFtcGxlIE9uIHJhbmdlIGNvbHVtbnNcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgncmVzZXJ2YXRpb25zJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAuY29udGFpbnMoJ2R1cmluZycsICdbMjAwMC0wMS0wMSAxMzowMCwgMjAwMC0wMS0wMSAxMzozMCknKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgT24gcmFuZ2UgY29sdW1uc1xuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgcmVzZXJ2YXRpb25zIChcbiAgICogICAgIGlkIGludDggcHJpbWFyeSBrZXksXG4gICAqICAgICByb29tX25hbWUgdGV4dCxcbiAgICogICAgIGR1cmluZyB0c3JhbmdlXG4gICAqICAgKTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICByZXNlcnZhdGlvbnMgKGlkLCByb29tX25hbWUsIGR1cmluZylcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdFbWVyYWxkJywgJ1syMDAwLTAxLTAxIDEzOjAwLCAyMDAwLTAxLTAxIDE1OjAwKScpLFxuICAgKiAgICgyLCAnVG9wYXonLCAnWzIwMDAtMDEtMDIgMDk6MDAsIDIwMDAtMDEtMDIgMTA6MDApJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9uIHJhbmdlIGNvbHVtbnNcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcInJvb21fbmFtZVwiOiBcIkVtZXJhbGRcIixcbiAgICogICAgICAgXCJkdXJpbmdcIjogXCJbXFxcIjIwMDAtMDEtMDEgMTM6MDA6MDBcXFwiLFxcXCIyMDAwLTAxLTAxIDE1OjAwOjAwXFxcIilcIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgT24gYGpzb25iYCBjb2x1bW5zXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ3VzZXJzJylcbiAgICogICAuc2VsZWN0KCduYW1lJylcbiAgICogICAuY29udGFpbnMoJ2FkZHJlc3MnLCB7IHBvc3Rjb2RlOiA5MDIxMCB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgT24gYGpzb25iYCBjb2x1bW5zXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICB1c2VycyAoXG4gICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgKiAgICAgbmFtZSB0ZXh0LFxuICAgKiAgICAgYWRkcmVzcyBqc29uYlxuICAgKiAgICk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgdXNlcnMgKGlkLCBuYW1lLCBhZGRyZXNzKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ01pY2hhZWwnLCAneyBcInBvc3Rjb2RlXCI6IDkwMjEwLCBcInN0cmVldFwiOiBcIk1lbHJvc2UgUGxhY2VcIiB9JyksXG4gICAqICAgKDIsICdKYW5lJywgJ3t9Jyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9uIGBqc29uYmAgY29sdW1uc1xuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcIm5hbWVcIjogXCJNaWNoYWVsXCJcbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBjb250YWlucyhjb2x1bW46IHN0cmluZywgdmFsdWU6IHN0cmluZyB8IHJlYWRvbmx5IHVua25vd25bXSB8IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogdGhpcyB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgIC8vIHJhbmdlIHR5cGVzIGNhbiBiZSBpbmNsdXNpdmUgJ1snLCAnXScgb3IgZXhjbHVzaXZlICcoJywgJyknIHNvIGp1c3RcbiAgICAgIC8vIGtlZXAgaXQgc2ltcGxlIGFuZCBhY2NlcHQgYSBzdHJpbmdcbiAgICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgY3MuJHt2YWx1ZX1gKVxuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIC8vIGFycmF5XG4gICAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGNzLnske3ZhbHVlLmpvaW4oJywnKX19YClcbiAgICB9IGVsc2Uge1xuICAgICAgLy8ganNvblxuICAgICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBjcy4ke0pTT04uc3RyaW5naWZ5KHZhbHVlKX1gKVxuICAgIH1cbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgY29udGFpbmVkQnk8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lLFxuICAgIHZhbHVlOiBzdHJpbmcgfCBSZWFkb25seUFycmF5PFJvd1tDb2x1bW5OYW1lXT4gfCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuICApOiB0aGlzXG4gIGNvbnRhaW5lZEJ5KGNvbHVtbjogc3RyaW5nLCB2YWx1ZTogc3RyaW5nIHwgcmVhZG9ubHkgdW5rbm93bltdIHwgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiB0aGlzXG4gIC8qKlxuICAgKiBPbmx5IHJlbGV2YW50IGZvciBqc29uYiwgYXJyYXksIGFuZCByYW5nZSBjb2x1bW5zLiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmVcbiAgICogZXZlcnkgZWxlbWVudCBhcHBlYXJpbmcgaW4gYGNvbHVtbmAgaXMgY29udGFpbmVkIGJ5IGB2YWx1ZWAuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUganNvbmIsIGFycmF5LCBvciByYW5nZSBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBqc29uYiwgYXJyYXksIG9yIHJhbmdlIHZhbHVlIHRvIGZpbHRlciB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBPbiBhcnJheSBjb2x1bW5zXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NsYXNzZXMnKVxuICAgKiAgIC5zZWxlY3QoJ25hbWUnKVxuICAgKiAgIC5jb250YWluZWRCeSgnZGF5cycsIFsnbW9uZGF5JywgJ3R1ZXNkYXknLCAnd2VkbmVzZGF5JywgJ2ZyaWRheSddKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgT24gYXJyYXkgY29sdW1uc1xuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2xhc3NlcyAoXG4gICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgKiAgICAgbmFtZSB0ZXh0LFxuICAgKiAgICAgZGF5cyB0ZXh0W11cbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNsYXNzZXMgKGlkLCBuYW1lLCBkYXlzKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0NoZW1pc3RyeScsIGFycmF5Wydtb25kYXknLCAnZnJpZGF5J10pLFxuICAgKiAgICgyLCAnSGlzdG9yeScsIGFycmF5Wydtb25kYXknLCAnd2VkbmVzZGF5JywgJ3RodXJzZGF5J10pO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBPbiBhcnJheSBjb2x1bW5zXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwibmFtZVwiOiBcIkNoZW1pc3RyeVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIE9uIHJhbmdlIGNvbHVtbnNcbiAgICogUG9zdGdyZXMgc3VwcG9ydHMgYSBudW1iZXIgb2YgW3JhbmdlXG4gICAqIHR5cGVzXShodHRwczovL3d3dy5wb3N0Z3Jlc3FsLm9yZy9kb2NzL2N1cnJlbnQvcmFuZ2V0eXBlcy5odG1sKS4gWW91XG4gICAqIGNhbiBmaWx0ZXIgb24gcmFuZ2UgY29sdW1ucyB1c2luZyB0aGUgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHJhbmdlXG4gICAqIHZhbHVlcy5cbiAgICpcbiAgICogQGV4YW1wbGUgT24gcmFuZ2UgY29sdW1uc1xuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdyZXNlcnZhdGlvbnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5jb250YWluZWRCeSgnZHVyaW5nJywgJ1syMDAwLTAxLTAxIDAwOjAwLCAyMDAwLTAxLTAxIDIzOjU5KScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBPbiByYW5nZSBjb2x1bW5zXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICByZXNlcnZhdGlvbnMgKFxuICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICogICAgIHJvb21fbmFtZSB0ZXh0LFxuICAgKiAgICAgZHVyaW5nIHRzcmFuZ2VcbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIHJlc2VydmF0aW9ucyAoaWQsIHJvb21fbmFtZSwgZHVyaW5nKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0VtZXJhbGQnLCAnWzIwMDAtMDEtMDEgMTM6MDAsIDIwMDAtMDEtMDEgMTU6MDApJyksXG4gICAqICAgKDIsICdUb3BheicsICdbMjAwMC0wMS0wMiAwOTowMCwgMjAwMC0wMS0wMiAxMDowMCknKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgT24gcmFuZ2UgY29sdW1uc1xuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAqICAgICAgIFwicm9vbV9uYW1lXCI6IFwiRW1lcmFsZFwiLFxuICAgKiAgICAgICBcImR1cmluZ1wiOiBcIltcXFwiMjAwMC0wMS0wMSAxMzowMDowMFxcXCIsXFxcIjIwMDAtMDEtMDEgMTU6MDA6MDBcXFwiKVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBPbiBganNvbmJgIGNvbHVtbnNcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgndXNlcnMnKVxuICAgKiAgIC5zZWxlY3QoJ25hbWUnKVxuICAgKiAgIC5jb250YWluZWRCeSgnYWRkcmVzcycsIHt9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgT24gYGpzb25iYCBjb2x1bW5zXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICB1c2VycyAoXG4gICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgKiAgICAgbmFtZSB0ZXh0LFxuICAgKiAgICAgYWRkcmVzcyBqc29uYlxuICAgKiAgICk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgdXNlcnMgKGlkLCBuYW1lLCBhZGRyZXNzKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ01pY2hhZWwnLCAneyBcInBvc3Rjb2RlXCI6IDkwMjEwLCBcInN0cmVldFwiOiBcIk1lbHJvc2UgUGxhY2VcIiB9JyksXG4gICAqICAgKDIsICdKYW5lJywgJ3t9Jyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9uIGBqc29uYmAgY29sdW1uc1xuICAgKiBgYGBqc29uXG4gICAqICAge1xuICAgKiAgICAgXCJkYXRhXCI6IFtcbiAgICogICAgICAge1xuICAgKiAgICAgICAgIFwibmFtZVwiOiBcIkphbmVcIlxuICAgKiAgICAgICB9XG4gICAqICAgICBdLFxuICAgKiAgICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiAgIH1cbiAgICpcbiAgICogYGBgXG4gICAqL1xuICBjb250YWluZWRCeShjb2x1bW46IHN0cmluZywgdmFsdWU6IHN0cmluZyB8IHJlYWRvbmx5IHVua25vd25bXSB8IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogdGhpcyB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgIC8vIHJhbmdlXG4gICAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGNkLiR7dmFsdWV9YClcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAvLyBhcnJheVxuICAgICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBjZC57JHt2YWx1ZS5qb2luKCcsJyl9fWApXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIGpzb25cbiAgICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgY2QuJHtKU09OLnN0cmluZ2lmeSh2YWx1ZSl9YClcbiAgICB9XG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHJhbmdlR3Q8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oY29sdW1uOiBDb2x1bW5OYW1lLCByYW5nZTogc3RyaW5nKTogdGhpc1xuICByYW5nZUd0KGNvbHVtbjogc3RyaW5nLCByYW5nZTogc3RyaW5nKTogdGhpc1xuICAvKipcbiAgICogT25seSByZWxldmFudCBmb3IgcmFuZ2UgY29sdW1ucy4gTWF0Y2ggb25seSByb3dzIHdoZXJlIGV2ZXJ5IGVsZW1lbnQgaW5cbiAgICogYGNvbHVtbmAgaXMgZ3JlYXRlciB0aGFuIGFueSBlbGVtZW50IGluIGByYW5nZWAuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgcmFuZ2UgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gcmFuZ2UgLSBUaGUgcmFuZ2UgdG8gZmlsdGVyIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gV2l0aCBgc2VsZWN0KClgXG4gICAqIFBvc3RncmVzIHN1cHBvcnRzIGEgbnVtYmVyIG9mIFtyYW5nZVxuICAgKiB0eXBlc10oaHR0cHM6Ly93d3cucG9zdGdyZXNxbC5vcmcvZG9jcy9jdXJyZW50L3JhbmdldHlwZXMuaHRtbCkuIFlvdVxuICAgKiBjYW4gZmlsdGVyIG9uIHJhbmdlIGNvbHVtbnMgdXNpbmcgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiByYW5nZVxuICAgKiB2YWx1ZXMuXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdyZXNlcnZhdGlvbnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5yYW5nZUd0KCdkdXJpbmcnLCAnWzIwMDAtMDEtMDIgMDg6MDAsIDIwMDAtMDEtMDIgMDk6MDApJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgcmVzZXJ2YXRpb25zIChcbiAgICogICAgIGlkIGludDggcHJpbWFyeSBrZXksXG4gICAqICAgICByb29tX25hbWUgdGV4dCxcbiAgICogICAgIGR1cmluZyB0c3JhbmdlXG4gICAqICAgKTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICByZXNlcnZhdGlvbnMgKGlkLCByb29tX25hbWUsIGR1cmluZylcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdFbWVyYWxkJywgJ1syMDAwLTAxLTAxIDEzOjAwLCAyMDAwLTAxLTAxIDE1OjAwKScpLFxuICAgKiAgICgyLCAnVG9wYXonLCAnWzIwMDAtMDEtMDIgMDk6MDAsIDIwMDAtMDEtMDIgMTA6MDApJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqICAge1xuICAgKiAgICAgXCJkYXRhXCI6IFtcbiAgICogICAgICAge1xuICAgKiAgICAgICAgIFwiaWRcIjogMixcbiAgICogICAgICAgICBcInJvb21fbmFtZVwiOiBcIlRvcGF6XCIsXG4gICAqICAgICAgICAgXCJkdXJpbmdcIjogXCJbXFxcIjIwMDAtMDEtMDIgMDk6MDA6MDBcXFwiLFxcXCIyMDAwLTAxLTAyIDEwOjAwOjAwXFxcIilcIlxuICAgKiAgICAgICB9XG4gICAqICAgICBdLFxuICAgKiAgICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiAgIH1cbiAgICpcbiAgICogYGBgXG4gICAqL1xuICByYW5nZUd0KGNvbHVtbjogc3RyaW5nLCByYW5nZTogc3RyaW5nKTogdGhpcyB7XG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBzci4ke3JhbmdlfWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHJhbmdlR3RlPENvbHVtbk5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBSb3c+KGNvbHVtbjogQ29sdW1uTmFtZSwgcmFuZ2U6IHN0cmluZyk6IHRoaXNcbiAgcmFuZ2VHdGUoY29sdW1uOiBzdHJpbmcsIHJhbmdlOiBzdHJpbmcpOiB0aGlzXG4gIC8qKlxuICAgKiBPbmx5IHJlbGV2YW50IGZvciByYW5nZSBjb2x1bW5zLiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgZXZlcnkgZWxlbWVudCBpblxuICAgKiBgY29sdW1uYCBpcyBlaXRoZXIgY29udGFpbmVkIGluIGByYW5nZWAgb3IgZ3JlYXRlciB0aGFuIGFueSBlbGVtZW50IGluXG4gICAqIGByYW5nZWAuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgcmFuZ2UgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gcmFuZ2UgLSBUaGUgcmFuZ2UgdG8gZmlsdGVyIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gV2l0aCBgc2VsZWN0KClgXG4gICAqIFBvc3RncmVzIHN1cHBvcnRzIGEgbnVtYmVyIG9mIFtyYW5nZVxuICAgKiB0eXBlc10oaHR0cHM6Ly93d3cucG9zdGdyZXNxbC5vcmcvZG9jcy9jdXJyZW50L3JhbmdldHlwZXMuaHRtbCkuIFlvdVxuICAgKiBjYW4gZmlsdGVyIG9uIHJhbmdlIGNvbHVtbnMgdXNpbmcgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiByYW5nZVxuICAgKiB2YWx1ZXMuXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdyZXNlcnZhdGlvbnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5yYW5nZUd0ZSgnZHVyaW5nJywgJ1syMDAwLTAxLTAyIDA4OjMwLCAyMDAwLTAxLTAyIDA5OjMwKScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIHJlc2VydmF0aW9ucyAoXG4gICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgKiAgICAgcm9vbV9uYW1lIHRleHQsXG4gICAqICAgICBkdXJpbmcgdHNyYW5nZVxuICAgKiAgICk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgcmVzZXJ2YXRpb25zIChpZCwgcm9vbV9uYW1lLCBkdXJpbmcpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnRW1lcmFsZCcsICdbMjAwMC0wMS0wMSAxMzowMCwgMjAwMC0wMS0wMSAxNTowMCknKSxcbiAgICogICAoMiwgJ1RvcGF6JywgJ1syMDAwLTAxLTAyIDA5OjAwLCAyMDAwLTAxLTAyIDEwOjAwKScpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBganNvblxuICAgKiAgIHtcbiAgICogICAgIFwiZGF0YVwiOiBbXG4gICAqICAgICAgIHtcbiAgICogICAgICAgICBcImlkXCI6IDIsXG4gICAqICAgICAgICAgXCJyb29tX25hbWVcIjogXCJUb3BhelwiLFxuICAgKiAgICAgICAgIFwiZHVyaW5nXCI6IFwiW1xcXCIyMDAwLTAxLTAyIDA5OjAwOjAwXFxcIixcXFwiMjAwMC0wMS0wMiAxMDowMDowMFxcXCIpXCJcbiAgICogICAgICAgfVxuICAgKiAgICAgXSxcbiAgICogICAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogICB9XG4gICAqXG4gICAqIGBgYFxuICAgKi9cbiAgcmFuZ2VHdGUoY29sdW1uOiBzdHJpbmcsIHJhbmdlOiBzdHJpbmcpOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYG54bC4ke3JhbmdlfWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHJhbmdlTHQ8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oY29sdW1uOiBDb2x1bW5OYW1lLCByYW5nZTogc3RyaW5nKTogdGhpc1xuICByYW5nZUx0KGNvbHVtbjogc3RyaW5nLCByYW5nZTogc3RyaW5nKTogdGhpc1xuICAvKipcbiAgICogT25seSByZWxldmFudCBmb3IgcmFuZ2UgY29sdW1ucy4gTWF0Y2ggb25seSByb3dzIHdoZXJlIGV2ZXJ5IGVsZW1lbnQgaW5cbiAgICogYGNvbHVtbmAgaXMgbGVzcyB0aGFuIGFueSBlbGVtZW50IGluIGByYW5nZWAuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgcmFuZ2UgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gcmFuZ2UgLSBUaGUgcmFuZ2UgdG8gZmlsdGVyIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gV2l0aCBgc2VsZWN0KClgXG4gICAqIFBvc3RncmVzIHN1cHBvcnRzIGEgbnVtYmVyIG9mIFtyYW5nZVxuICAgKiB0eXBlc10oaHR0cHM6Ly93d3cucG9zdGdyZXNxbC5vcmcvZG9jcy9jdXJyZW50L3JhbmdldHlwZXMuaHRtbCkuIFlvdVxuICAgKiBjYW4gZmlsdGVyIG9uIHJhbmdlIGNvbHVtbnMgdXNpbmcgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiByYW5nZVxuICAgKiB2YWx1ZXMuXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdyZXNlcnZhdGlvbnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5yYW5nZUx0KCdkdXJpbmcnLCAnWzIwMDAtMDEtMDEgMTU6MDAsIDIwMDAtMDEtMDEgMTY6MDApJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgcmVzZXJ2YXRpb25zIChcbiAgICogICAgIGlkIGludDggcHJpbWFyeSBrZXksXG4gICAqICAgICByb29tX25hbWUgdGV4dCxcbiAgICogICAgIGR1cmluZyB0c3JhbmdlXG4gICAqICAgKTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICByZXNlcnZhdGlvbnMgKGlkLCByb29tX25hbWUsIGR1cmluZylcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdFbWVyYWxkJywgJ1syMDAwLTAxLTAxIDEzOjAwLCAyMDAwLTAxLTAxIDE1OjAwKScpLFxuICAgKiAgICgyLCAnVG9wYXonLCAnWzIwMDAtMDEtMDIgMDk6MDAsIDIwMDAtMDEtMDIgMTA6MDApJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAqICAgICAgIFwicm9vbV9uYW1lXCI6IFwiRW1lcmFsZFwiLFxuICAgKiAgICAgICBcImR1cmluZ1wiOiBcIltcXFwiMjAwMC0wMS0wMSAxMzowMDowMFxcXCIsXFxcIjIwMDAtMDEtMDEgMTU6MDA6MDBcXFwiKVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgcmFuZ2VMdChjb2x1bW46IHN0cmluZywgcmFuZ2U6IHN0cmluZyk6IHRoaXMge1xuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgc2wuJHtyYW5nZX1gKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICByYW5nZUx0ZTxDb2x1bW5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgUm93Pihjb2x1bW46IENvbHVtbk5hbWUsIHJhbmdlOiBzdHJpbmcpOiB0aGlzXG4gIHJhbmdlTHRlKGNvbHVtbjogc3RyaW5nLCByYW5nZTogc3RyaW5nKTogdGhpc1xuICAvKipcbiAgICogT25seSByZWxldmFudCBmb3IgcmFuZ2UgY29sdW1ucy4gTWF0Y2ggb25seSByb3dzIHdoZXJlIGV2ZXJ5IGVsZW1lbnQgaW5cbiAgICogYGNvbHVtbmAgaXMgZWl0aGVyIGNvbnRhaW5lZCBpbiBgcmFuZ2VgIG9yIGxlc3MgdGhhbiBhbnkgZWxlbWVudCBpblxuICAgKiBgcmFuZ2VgLlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIHJhbmdlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHJhbmdlIC0gVGhlIHJhbmdlIHRvIGZpbHRlciB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFdpdGggYHNlbGVjdCgpYFxuICAgKiBQb3N0Z3JlcyBzdXBwb3J0cyBhIG51bWJlciBvZiBbcmFuZ2VcbiAgICogdHlwZXNdKGh0dHBzOi8vd3d3LnBvc3RncmVzcWwub3JnL2RvY3MvY3VycmVudC9yYW5nZXR5cGVzLmh0bWwpLiBZb3VcbiAgICogY2FuIGZpbHRlciBvbiByYW5nZSBjb2x1bW5zIHVzaW5nIHRoZSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgcmFuZ2VcbiAgICogdmFsdWVzLlxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgncmVzZXJ2YXRpb25zJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAucmFuZ2VMdGUoJ2R1cmluZycsICdbMjAwMC0wMS0wMSAxNDowMCwgMjAwMC0wMS0wMSAxNjowMCknKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICByZXNlcnZhdGlvbnMgKFxuICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICogICAgIHJvb21fbmFtZSB0ZXh0LFxuICAgKiAgICAgZHVyaW5nIHRzcmFuZ2VcbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIHJlc2VydmF0aW9ucyAoaWQsIHJvb21fbmFtZSwgZHVyaW5nKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0VtZXJhbGQnLCAnWzIwMDAtMDEtMDEgMTM6MDAsIDIwMDAtMDEtMDEgMTU6MDApJyksXG4gICAqICAgKDIsICdUb3BheicsICdbMjAwMC0wMS0wMiAwOTowMCwgMjAwMC0wMS0wMiAxMDowMCknKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICogICB7XG4gICAqICAgICBcImRhdGFcIjogW1xuICAgKiAgICAgICB7XG4gICAqICAgICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICAgIFwicm9vbV9uYW1lXCI6IFwiRW1lcmFsZFwiLFxuICAgKiAgICAgICAgIFwiZHVyaW5nXCI6IFwiW1xcXCIyMDAwLTAxLTAxIDEzOjAwOjAwXFxcIixcXFwiMjAwMC0wMS0wMSAxNTowMDowMFxcXCIpXCJcbiAgICogICAgICAgfVxuICAgKiAgICAgXSxcbiAgICogICAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogICB9XG4gICAqXG4gICAqIGBgYFxuICAgKi9cbiAgcmFuZ2VMdGUoY29sdW1uOiBzdHJpbmcsIHJhbmdlOiBzdHJpbmcpOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYG54ci4ke3JhbmdlfWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHJhbmdlQWRqYWNlbnQ8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oY29sdW1uOiBDb2x1bW5OYW1lLCByYW5nZTogc3RyaW5nKTogdGhpc1xuICByYW5nZUFkamFjZW50KGNvbHVtbjogc3RyaW5nLCByYW5nZTogc3RyaW5nKTogdGhpc1xuICAvKipcbiAgICogT25seSByZWxldmFudCBmb3IgcmFuZ2UgY29sdW1ucy4gTWF0Y2ggb25seSByb3dzIHdoZXJlIGBjb2x1bW5gIGlzXG4gICAqIG11dHVhbGx5IGV4Y2x1c2l2ZSB0byBgcmFuZ2VgIGFuZCB0aGVyZSBjYW4gYmUgbm8gZWxlbWVudCBiZXR3ZWVuIHRoZSB0d29cbiAgICogcmFuZ2VzLlxuICAgKlxuICAgKiBAcGFyYW0gY29sdW1uIC0gVGhlIHJhbmdlIGNvbHVtbiB0byBmaWx0ZXIgb25cbiAgICogQHBhcmFtIHJhbmdlIC0gVGhlIHJhbmdlIHRvIGZpbHRlciB3aXRoXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFdpdGggYHNlbGVjdCgpYFxuICAgKiBQb3N0Z3JlcyBzdXBwb3J0cyBhIG51bWJlciBvZiBbcmFuZ2VcbiAgICogdHlwZXNdKGh0dHBzOi8vd3d3LnBvc3RncmVzcWwub3JnL2RvY3MvY3VycmVudC9yYW5nZXR5cGVzLmh0bWwpLiBZb3VcbiAgICogY2FuIGZpbHRlciBvbiByYW5nZSBjb2x1bW5zIHVzaW5nIHRoZSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgcmFuZ2VcbiAgICogdmFsdWVzLlxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgncmVzZXJ2YXRpb25zJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAucmFuZ2VBZGphY2VudCgnZHVyaW5nJywgJ1syMDAwLTAxLTAxIDEyOjAwLCAyMDAwLTAxLTAxIDEzOjAwKScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIHJlc2VydmF0aW9ucyAoXG4gICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgKiAgICAgcm9vbV9uYW1lIHRleHQsXG4gICAqICAgICBkdXJpbmcgdHNyYW5nZVxuICAgKiAgICk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgcmVzZXJ2YXRpb25zIChpZCwgcm9vbV9uYW1lLCBkdXJpbmcpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnRW1lcmFsZCcsICdbMjAwMC0wMS0wMSAxMzowMCwgMjAwMC0wMS0wMSAxNTowMCknKSxcbiAgICogICAoMiwgJ1RvcGF6JywgJ1syMDAwLTAxLTAyIDA5OjAwLCAyMDAwLTAxLTAyIDEwOjAwKScpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcInJvb21fbmFtZVwiOiBcIkVtZXJhbGRcIixcbiAgICogICAgICAgXCJkdXJpbmdcIjogXCJbXFxcIjIwMDAtMDEtMDEgMTM6MDA6MDBcXFwiLFxcXCIyMDAwLTAxLTAxIDE1OjAwOjAwXFxcIilcIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIHJhbmdlQWRqYWNlbnQoY29sdW1uOiBzdHJpbmcsIHJhbmdlOiBzdHJpbmcpOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYGFkai4ke3JhbmdlfWApXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIG92ZXJsYXBzPENvbHVtbk5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBSb3c+KFxuICAgIGNvbHVtbjogQ29sdW1uTmFtZSxcbiAgICB2YWx1ZTogc3RyaW5nIHwgUmVhZG9ubHlBcnJheTxSb3dbQ29sdW1uTmFtZV0+XG4gICk6IHRoaXNcbiAgb3ZlcmxhcHMoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcgfCByZWFkb25seSB1bmtub3duW10pOiB0aGlzXG4gIC8qKlxuICAgKiBPbmx5IHJlbGV2YW50IGZvciBhcnJheSBhbmQgcmFuZ2UgY29sdW1ucy4gTWF0Y2ggb25seSByb3dzIHdoZXJlXG4gICAqIGBjb2x1bW5gIGFuZCBgdmFsdWVgIGhhdmUgYW4gZWxlbWVudCBpbiBjb21tb24uXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgYXJyYXkgb3IgcmFuZ2UgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gdmFsdWUgLSBUaGUgYXJyYXkgb3IgcmFuZ2UgdmFsdWUgdG8gZmlsdGVyIHdpdGhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqXG4gICAqIEBleGFtcGxlIE9uIGFycmF5IGNvbHVtbnNcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnaXNzdWVzJylcbiAgICogICAuc2VsZWN0KCd0aXRsZScpXG4gICAqICAgLm92ZXJsYXBzKCd0YWdzJywgWydpczpjbG9zZWQnLCAnc2V2ZXJpdHk6aGlnaCddKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgT24gYXJyYXkgY29sdW1uc1xuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgaXNzdWVzIChcbiAgICogICAgIGlkIGludDggcHJpbWFyeSBrZXksXG4gICAqICAgICB0aXRsZSB0ZXh0LFxuICAgKiAgICAgdGFncyB0ZXh0W11cbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGlzc3VlcyAoaWQsIHRpdGxlLCB0YWdzKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0NhY2hlIGludmFsaWRhdGlvbiBpcyBub3Qgd29ya2luZycsIGFycmF5WydpczpvcGVuJywgJ3NldmVyaXR5OmhpZ2gnLCAncHJpb3JpdHk6bG93J10pLFxuICAgKiAgICgyLCAnVXNlIGJldHRlciBuYW1lcycsIGFycmF5WydpczpvcGVuJywgJ3NldmVyaXR5OmxvdycsICdwcmlvcml0eTptZWRpdW0nXSk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9uIGFycmF5IGNvbHVtbnNcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJ0aXRsZVwiOiBcIkNhY2hlIGludmFsaWRhdGlvbiBpcyBub3Qgd29ya2luZ1wiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIE9uIHJhbmdlIGNvbHVtbnNcbiAgICogUG9zdGdyZXMgc3VwcG9ydHMgYSBudW1iZXIgb2YgW3JhbmdlXG4gICAqIHR5cGVzXShodHRwczovL3d3dy5wb3N0Z3Jlc3FsLm9yZy9kb2NzL2N1cnJlbnQvcmFuZ2V0eXBlcy5odG1sKS4gWW91XG4gICAqIGNhbiBmaWx0ZXIgb24gcmFuZ2UgY29sdW1ucyB1c2luZyB0aGUgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHJhbmdlXG4gICAqIHZhbHVlcy5cbiAgICpcbiAgICogQGV4YW1wbGUgT24gcmFuZ2UgY29sdW1uc1xuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdyZXNlcnZhdGlvbnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5vdmVybGFwcygnZHVyaW5nJywgJ1syMDAwLTAxLTAxIDEyOjQ1LCAyMDAwLTAxLTAxIDEzOjE1KScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBPbiByYW5nZSBjb2x1bW5zXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICByZXNlcnZhdGlvbnMgKFxuICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICogICAgIHJvb21fbmFtZSB0ZXh0LFxuICAgKiAgICAgZHVyaW5nIHRzcmFuZ2VcbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIHJlc2VydmF0aW9ucyAoaWQsIHJvb21fbmFtZSwgZHVyaW5nKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0VtZXJhbGQnLCAnWzIwMDAtMDEtMDEgMTM6MDAsIDIwMDAtMDEtMDEgMTU6MDApJyksXG4gICAqICAgKDIsICdUb3BheicsICdbMjAwMC0wMS0wMiAwOTowMCwgMjAwMC0wMS0wMiAxMDowMCknKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgT24gcmFuZ2UgY29sdW1uc1xuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAqICAgICAgIFwicm9vbV9uYW1lXCI6IFwiRW1lcmFsZFwiLFxuICAgKiAgICAgICBcImR1cmluZ1wiOiBcIltcXFwiMjAwMC0wMS0wMSAxMzowMDowMFxcXCIsXFxcIjIwMDAtMDEtMDEgMTU6MDA6MDBcXFwiKVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgb3ZlcmxhcHMoY29sdW1uOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcgfCByZWFkb25seSB1bmtub3duW10pOiB0aGlzIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgICAgLy8gcmFuZ2VcbiAgICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgb3YuJHt2YWx1ZX1gKVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBhcnJheVxuICAgICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBvdi57JHt2YWx1ZS5qb2luKCcsJyl9fWApXG4gICAgfVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICB0ZXh0U2VhcmNoPENvbHVtbk5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBSb3c+KFxuICAgIGNvbHVtbjogQ29sdW1uTmFtZSxcbiAgICBxdWVyeTogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiB7IGNvbmZpZz86IHN0cmluZzsgdHlwZT86ICdwbGFpbicgfCAncGhyYXNlJyB8ICd3ZWJzZWFyY2gnIH1cbiAgKTogdGhpc1xuICB0ZXh0U2VhcmNoKFxuICAgIGNvbHVtbjogc3RyaW5nLFxuICAgIHF1ZXJ5OiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHsgY29uZmlnPzogc3RyaW5nOyB0eXBlPzogJ3BsYWluJyB8ICdwaHJhc2UnIHwgJ3dlYnNlYXJjaCcgfVxuICApOiB0aGlzXG4gIC8qKlxuICAgKiBPbmx5IHJlbGV2YW50IGZvciB0ZXh0IGFuZCB0c3ZlY3RvciBjb2x1bW5zLiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmVcbiAgICogYGNvbHVtbmAgbWF0Y2hlcyB0aGUgcXVlcnkgc3RyaW5nIGluIGBxdWVyeWAuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgdGV4dCBvciB0c3ZlY3RvciBjb2x1bW4gdG8gZmlsdGVyIG9uXG4gICAqIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0ZXh0IHRvIG1hdGNoIHdpdGhcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBOYW1lZCBwYXJhbWV0ZXJzXG4gICAqIEBwYXJhbSBvcHRpb25zLmNvbmZpZyAtIFRoZSB0ZXh0IHNlYXJjaCBjb25maWd1cmF0aW9uIHRvIHVzZVxuICAgKiBAcGFyYW0gb3B0aW9ucy50eXBlIC0gQ2hhbmdlIGhvdyB0aGUgYHF1ZXJ5YCB0ZXh0IGlzIGludGVycHJldGVkXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEZvciBtb3JlIGluZm9ybWF0aW9uLCBzZWUgW1Bvc3RncmVzIGZ1bGwgdGV4dCBzZWFyY2hdKC9kb2NzL2d1aWRlcy9kYXRhYmFzZS9mdWxsLXRleHQtc2VhcmNoKS5cbiAgICpcbiAgICogQGV4YW1wbGUgVGV4dCBzZWFyY2hcbiAgICogYGBgdHNcbiAgICogY29uc3QgcmVzdWx0ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbShcInRleHRzXCIpXG4gICAqICAgLnNlbGVjdChcImNvbnRlbnRcIilcbiAgICogICAudGV4dFNlYXJjaChcImNvbnRlbnRcIiwgYCdlZ2dzJyAmICdoYW0nYCwge1xuICAgKiAgICAgY29uZmlnOiBcImVuZ2xpc2hcIixcbiAgICogICB9KTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFRleHQgc2VhcmNoXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGUgdGV4dHMgKFxuICAgKiAgIGlkICAgICAgYmlnaW50XG4gICAqICAgICAgICAgICBwcmltYXJ5IGtleVxuICAgKiAgICAgICAgICAgZ2VuZXJhdGVkIGFsd2F5cyBhcyBpZGVudGl0eSxcbiAgICogICBjb250ZW50IHRleHRcbiAgICogKTtcbiAgICpcbiAgICogaW5zZXJ0IGludG8gdGV4dHMgKGNvbnRlbnQpIHZhbHVlc1xuICAgKiAgICAgKCdGb3VyIHNjb3JlIGFuZCBzZXZlbiB5ZWFycyBhZ28nKSxcbiAgICogICAgICgnVGhlIHJvYWQgZ29lcyBldmVyIG9uIGFuZCBvbicpLFxuICAgKiAgICAgKCdHcmVlbiBlZ2dzIGFuZCBoYW0nKVxuICAgKiA7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFRleHQgc2VhcmNoXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiY29udGVudFwiOiBcIkdyZWVuIGVnZ3MgYW5kIGhhbVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIEJhc2ljIG5vcm1hbGl6YXRpb25cbiAgICogVXNlcyBQb3N0Z3JlU1FMJ3MgYHBsYWludG9fdHNxdWVyeWAgZnVuY3Rpb24uXG4gICAqXG4gICAqIEBleGFtcGxlIEJhc2ljIG5vcm1hbGl6YXRpb25cbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgncXVvdGVzJylcbiAgICogICAuc2VsZWN0KCdjYXRjaHBocmFzZScpXG4gICAqICAgLnRleHRTZWFyY2goJ2NhdGNocGhyYXNlJywgYCdmYXQnICYgJ2NhdCdgLCB7XG4gICAqICAgICB0eXBlOiAncGxhaW4nLFxuICAgKiAgICAgY29uZmlnOiAnZW5nbGlzaCdcbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBGdWxsIG5vcm1hbGl6YXRpb25cbiAgICogVXNlcyBQb3N0Z3JlU1FMJ3MgYHBocmFzZXRvX3RzcXVlcnlgIGZ1bmN0aW9uLlxuICAgKlxuICAgKiBAZXhhbXBsZSBGdWxsIG5vcm1hbGl6YXRpb25cbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgncXVvdGVzJylcbiAgICogICAuc2VsZWN0KCdjYXRjaHBocmFzZScpXG4gICAqICAgLnRleHRTZWFyY2goJ2NhdGNocGhyYXNlJywgYCdmYXQnICYgJ2NhdCdgLCB7XG4gICAqICAgICB0eXBlOiAncGhyYXNlJyxcbiAgICogICAgIGNvbmZpZzogJ2VuZ2xpc2gnXG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gV2Vic2VhcmNoXG4gICAqIFVzZXMgUG9zdGdyZVNRTCdzIGB3ZWJzZWFyY2hfdG9fdHNxdWVyeWAgZnVuY3Rpb24uXG4gICAqIFRoaXMgZnVuY3Rpb24gd2lsbCBuZXZlciByYWlzZSBzeW50YXggZXJyb3JzLCB3aGljaCBtYWtlcyBpdCBwb3NzaWJsZSB0byB1c2UgcmF3IHVzZXItc3VwcGxpZWQgaW5wdXQgZm9yIHNlYXJjaCwgYW5kIGNhbiBiZSB1c2VkXG4gICAqIHdpdGggYWR2YW5jZWQgb3BlcmF0b3JzLlxuICAgKlxuICAgKiAtIGB1bnF1b3RlZCB0ZXh0YDogdGV4dCBub3QgaW5zaWRlIHF1b3RlIG1hcmtzIHdpbGwgYmUgY29udmVydGVkIHRvIHRlcm1zIHNlcGFyYXRlZCBieSAmIG9wZXJhdG9ycywgYXMgaWYgcHJvY2Vzc2VkIGJ5IHBsYWludG9fdHNxdWVyeS5cbiAgICogLSBgXCJxdW90ZWQgdGV4dFwiYDogdGV4dCBpbnNpZGUgcXVvdGUgbWFya3Mgd2lsbCBiZSBjb252ZXJ0ZWQgdG8gdGVybXMgc2VwYXJhdGVkIGJ5IGA8LT5gIG9wZXJhdG9ycywgYXMgaWYgcHJvY2Vzc2VkIGJ5IHBocmFzZXRvX3RzcXVlcnkuXG4gICAqIC0gYE9SYDogdGhlIHdvcmQg4oCcb3LigJ0gd2lsbCBiZSBjb252ZXJ0ZWQgdG8gdGhlIHwgb3BlcmF0b3IuXG4gICAqIC0gYC1gOiBhIGRhc2ggd2lsbCBiZSBjb252ZXJ0ZWQgdG8gdGhlICEgb3BlcmF0b3IuXG4gICAqXG4gICAqIEBleGFtcGxlIFdlYnNlYXJjaFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdxdW90ZXMnKVxuICAgKiAgIC5zZWxlY3QoJ2NhdGNocGhyYXNlJylcbiAgICogICAudGV4dFNlYXJjaCgnY2F0Y2hwaHJhc2UnLCBgJ2ZhdCBvciBjYXQnYCwge1xuICAgKiAgICAgdHlwZTogJ3dlYnNlYXJjaCcsXG4gICAqICAgICBjb25maWc6ICdlbmdsaXNoJ1xuICAgKiAgIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgdGV4dFNlYXJjaChcbiAgICBjb2x1bW46IHN0cmluZyxcbiAgICBxdWVyeTogc3RyaW5nLFxuICAgIHsgY29uZmlnLCB0eXBlIH06IHsgY29uZmlnPzogc3RyaW5nOyB0eXBlPzogJ3BsYWluJyB8ICdwaHJhc2UnIHwgJ3dlYnNlYXJjaCcgfSA9IHt9XG4gICk6IHRoaXMge1xuICAgIGxldCB0eXBlUGFydCA9ICcnXG4gICAgaWYgKHR5cGUgPT09ICdwbGFpbicpIHtcbiAgICAgIHR5cGVQYXJ0ID0gJ3BsJ1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ3BocmFzZScpIHtcbiAgICAgIHR5cGVQYXJ0ID0gJ3BoJ1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ3dlYnNlYXJjaCcpIHtcbiAgICAgIHR5cGVQYXJ0ID0gJ3cnXG4gICAgfVxuICAgIGNvbnN0IGNvbmZpZ1BhcnQgPSBjb25maWcgPT09IHVuZGVmaW5lZCA/ICcnIDogYCgke2NvbmZpZ30pYFxuICAgIHRoaXMudXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoY29sdW1uLCBgJHt0eXBlUGFydH1mdHMke2NvbmZpZ1BhcnR9LiR7cXVlcnl9YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgbWF0Y2g8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4ocXVlcnk6IFJlY29yZDxDb2x1bW5OYW1lLCBSb3dbQ29sdW1uTmFtZV0+KTogdGhpc1xuICBtYXRjaChxdWVyeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiB0aGlzXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hlcmUgZWFjaCBjb2x1bW4gaW4gYHF1ZXJ5YCBrZXlzIGlzIGVxdWFsIHRvIGl0c1xuICAgKiBhc3NvY2lhdGVkIHZhbHVlLiBTaG9ydGhhbmQgZm9yIG11bHRpcGxlIGAuZXEoKWBzLlxuICAgKlxuICAgKiBAcGFyYW0gcXVlcnkgLSBUaGUgb2JqZWN0IHRvIGZpbHRlciB3aXRoLCB3aXRoIGNvbHVtbiBuYW1lcyBhcyBrZXlzIG1hcHBlZFxuICAgKiB0byB0aGVpciBmaWx0ZXIgdmFsdWVzXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgnbmFtZScpXG4gICAqICAgLm1hdGNoKHsgaWQ6IDIsIG5hbWU6ICdMZWlhJyB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ0x1a2UnKSxcbiAgICogICAoMiwgJ0xlaWEnKSxcbiAgICogICAoMywgJ0hhbicpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwiTGVpYVwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgbWF0Y2gocXVlcnk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogdGhpcyB7XG4gICAgT2JqZWN0LmVudHJpZXMocXVlcnkpXG4gICAgICAvLyBjb2x1bW5zIHdpdGggYHVuZGVmaW5lZGAgdmFsdWUgbmVlZHMgdG8gYmUgZmlsdGVyZWQgb3V0LCBvdGhlcndpc2UgaXQnbGxcbiAgICAgIC8vIHNob3cgdXAgYXMgYD9jb2x1bW49ZXEudW5kZWZpbmVkYFxuICAgICAgLmZpbHRlcigoW18sIHZhbHVlXSkgPT4gdmFsdWUgIT09IHVuZGVmaW5lZClcbiAgICAgIC5mb3JFYWNoKChbY29sdW1uLCB2YWx1ZV0pID0+IHtcbiAgICAgICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChjb2x1bW4sIGBlcS4ke3ZhbHVlfWApXG4gICAgICB9KVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBub3Q8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lLFxuICAgIG9wZXJhdG9yOiAnaXMnLFxuICAgIHZhbHVlOiBudWxsXG4gICk6IFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBTY2hlbWEsXG4gICAgTm9uTnVsbGFibGVDb2x1bW48Um93LCBDb2x1bW5OYW1lPixcbiAgICBOYXJyb3dSZXN1bHRDb2x1bW48UmVzdWx0LCBDb2x1bW5OYW1lPixcbiAgICBSZWxhdGlvbk5hbWUsXG4gICAgUmVsYXRpb25zaGlwcyxcbiAgICBNZXRob2QsXG4gICAgVGhyb3dPbkVycm9yXG4gID4gJlxuICAgIHRoaXNcbiAgbm90PENvbHVtbk5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBSb3c+KFxuICAgIGNvbHVtbjogQ29sdW1uTmFtZSxcbiAgICBvcGVyYXRvcjogRmlsdGVyT3BlcmF0b3IsXG4gICAgdmFsdWU6IFJvd1tDb2x1bW5OYW1lXVxuICApOiB0aGlzXG4gIG5vdChjb2x1bW46IHN0cmluZywgb3BlcmF0b3I6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiB0aGlzXG4gIC8qKlxuICAgKiBNYXRjaCBvbmx5IHJvd3Mgd2hpY2ggZG9lc24ndCBzYXRpc2Z5IHRoZSBmaWx0ZXIuXG4gICAqXG4gICAqIFVubGlrZSBtb3N0IGZpbHRlcnMsIGBvcGVhcmF0b3JgIGFuZCBgdmFsdWVgIGFyZSB1c2VkIGFzLWlzIGFuZCBuZWVkIHRvXG4gICAqIGZvbGxvdyBbUG9zdGdSRVNUXG4gICAqIHN5bnRheF0oaHR0cHM6Ly9wb3N0Z3Jlc3Qub3JnL2VuL3N0YWJsZS9hcGkuaHRtbCNvcGVyYXRvcnMpLiBZb3UgYWxzbyBuZWVkXG4gICAqIHRvIG1ha2Ugc3VyZSB0aGV5IGFyZSBwcm9wZXJseSBzYW5pdGl6ZWQuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gb3BlcmF0b3IgLSBUaGUgb3BlcmF0b3IgdG8gYmUgbmVnYXRlZCB0byBmaWx0ZXIgd2l0aCwgZm9sbG93aW5nXG4gICAqIFBvc3RnUkVTVCBzeW50YXhcbiAgICogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGZpbHRlciB3aXRoLCBmb2xsb3dpbmcgUG9zdGdSRVNUIHN5bnRheFxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICogQHN1YmNhdGVnb3J5IFVzaW5nIGZpbHRlcnNcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogbm90KCkgZXhwZWN0cyB5b3UgdG8gdXNlIHRoZSByYXcgUG9zdGdSRVNUIHN5bnRheCBmb3IgdGhlIGZpbHRlciB2YWx1ZXMuXG4gICAqXG4gICAqIGBgYHRzXG4gICAqIC5ub3QoJ2lkJywgJ2luJywgJyg1LDYsNyknKSAgLy8gVXNlIGAoKWAgZm9yIGBpbmAgZmlsdGVyXG4gICAqIC5ub3QoJ2FycmF5Y29sJywgJ2NzJywgJ3tcImFcIixcImJcIn0nKSAgLy8gVXNlIGBjc2AgZm9yIGBjb250YWlucygpYCwgYHt9YCBmb3IgYXJyYXkgdmFsdWVzXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY291bnRyaWVzJylcbiAgICogICAuc2VsZWN0KClcbiAgICogICAubm90KCduYW1lJywgJ2lzJywgbnVsbClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY291bnRyaWVzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNvdW50cmllcyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnbnVsbCcpLFxuICAgKiAgICgyLCBudWxsKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICogICB7XG4gICAqICAgICBcImRhdGFcIjogW1xuICAgKiAgICAgICB7XG4gICAqICAgICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICAgIFwibmFtZVwiOiBcIm51bGxcIlxuICAgKiAgICAgICB9XG4gICAqICAgICBdLFxuICAgKiAgICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiAgIH1cbiAgICpcbiAgICogYGBgXG4gICAqL1xuICBub3QoXG4gICAgY29sdW1uOiBzdHJpbmcsXG4gICAgb3BlcmF0b3I6IHN0cmluZyxcbiAgICB2YWx1ZTogdW5rbm93blxuICApOiBQb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyPFxuICAgIENsaWVudE9wdGlvbnMsXG4gICAgU2NoZW1hLFxuICAgIGFueSxcbiAgICBhbnksXG4gICAgUmVsYXRpb25OYW1lLFxuICAgIFJlbGF0aW9uc2hpcHMsXG4gICAgTWV0aG9kLFxuICAgIFRocm93T25FcnJvclxuICA+ICZcbiAgICB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYG5vdC4ke29wZXJhdG9yfS4ke3ZhbHVlfWApXG4gICAgcmV0dXJuIHRoaXMgYXMgYW55XG4gIH1cblxuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoaWNoIHNhdGlzZnkgYXQgbGVhc3Qgb25lIG9mIHRoZSBmaWx0ZXJzLlxuICAgKlxuICAgKiBVbmxpa2UgbW9zdCBmaWx0ZXJzLCBgZmlsdGVyc2AgaXMgdXNlZCBhcy1pcyBhbmQgbmVlZHMgdG8gZm9sbG93IFtQb3N0Z1JFU1RcbiAgICogc3ludGF4XShodHRwczovL3Bvc3RncmVzdC5vcmcvZW4vc3RhYmxlL2FwaS5odG1sI29wZXJhdG9ycykuIFlvdSBhbHNvIG5lZWRcbiAgICogdG8gbWFrZSBzdXJlIGl0J3MgcHJvcGVybHkgc2FuaXRpemVkLlxuICAgKlxuICAgKiBJdCdzIGN1cnJlbnRseSBub3QgcG9zc2libGUgdG8gZG8gYW4gYC5vcigpYCBmaWx0ZXIgYWNyb3NzIG11bHRpcGxlIHRhYmxlcy5cbiAgICpcbiAgICogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0byB1c2UsIGZvbGxvd2luZyBQb3N0Z1JFU1Qgc3ludGF4XG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKiBAcGFyYW0gb3B0aW9ucy5yZWZlcmVuY2VkVGFibGUgLSBTZXQgdGhpcyB0byBmaWx0ZXIgb24gcmVmZXJlbmNlZCB0YWJsZXNcbiAgICogaW5zdGVhZCBvZiB0aGUgcGFyZW50IHRhYmxlXG4gICAqIEBwYXJhbSBvcHRpb25zLmZvcmVpZ25UYWJsZSAtIERlcHJlY2F0ZWQsIHVzZSBgcmVmZXJlbmNlZFRhYmxlYCBpbnN0ZWFkXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKiBAc3ViY2F0ZWdvcnkgVXNpbmcgZmlsdGVyc1xuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiBvcigpIGV4cGVjdHMgeW91IHRvIHVzZSB0aGUgcmF3IFBvc3RnUkVTVCBzeW50YXggZm9yIHRoZSBmaWx0ZXIgbmFtZXMgYW5kIHZhbHVlcy5cbiAgICpcbiAgICogYGBgdHNcbiAgICogLm9yKCdpZC5pbi4oNSw2LDcpLCBhcnJheWNvbC5jcy57XCJhXCIsXCJiXCJ9JykgIC8vIFVzZSBgKClgIGZvciBgaW5gIGZpbHRlciwgYHt9YCBmb3IgYXJyYXkgdmFsdWVzIGFuZCBgY3NgIGZvciBgY29udGFpbnMoKWAuXG4gICAqIC5vcignaWQuaW4uKDUsNiw3KSwgYXJyYXljb2wuY2Que1wiYVwiLFwiYlwifScpICAvLyBVc2UgYGNkYCBmb3IgYGNvbnRhaW5lZEJ5KClgXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGBzZWxlY3QoKWBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgnbmFtZScpXG4gICAqICAgLm9yKCdpZC5lcS4yLG5hbWUuZXEuSGFuJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdMdWtlJyksXG4gICAqICAgKDIsICdMZWlhJyksXG4gICAqICAgKDMsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwibmFtZVwiOiBcIkxlaWFcIlxuICAgKiAgICAgfSxcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwiSGFuXCJcbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFVzZSBgb3JgIHdpdGggYGFuZGBcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAqICAgLnNlbGVjdCgnbmFtZScpXG4gICAqICAgLm9yKCdpZC5ndC4zLGFuZChpZC5lcS4xLG5hbWUuZXEuTHVrZSknKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgVXNlIGBvcmAgd2l0aCBgYW5kYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdMdWtlJyksXG4gICAqICAgKDIsICdMZWlhJyksXG4gICAqICAgKDMsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgVXNlIGBvcmAgd2l0aCBgYW5kYFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcIm5hbWVcIjogXCJMdWtlXCJcbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFVzZSBgb3JgIG9uIHJlZmVyZW5jZWQgdGFibGVzXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ29yY2hlc3RyYWxfc2VjdGlvbnMnKVxuICAgKiAgIC5zZWxlY3QoYFxuICAgKiAgICAgbmFtZSxcbiAgICogICAgIGluc3RydW1lbnRzIWlubmVyIChcbiAgICogICAgICAgbmFtZVxuICAgKiAgICAgKVxuICAgKiAgIGApXG4gICAqICAgLm9yKCdzZWN0aW9uX2lkLmVxLjEsbmFtZS5lcS5ndXpoZW5nJywgeyByZWZlcmVuY2VkVGFibGU6ICdpbnN0cnVtZW50cycgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFVzZSBgb3JgIG9uIHJlZmVyZW5jZWQgdGFibGVzXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBvcmNoZXN0cmFsX3NlY3Rpb25zIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBpbnN0cnVtZW50cyAoXG4gICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgKiAgICAgc2VjdGlvbl9pZCBpbnQ4IG5vdCBudWxsIHJlZmVyZW5jZXMgb3JjaGVzdHJhbF9zZWN0aW9ucyxcbiAgICogICAgIG5hbWUgdGV4dFxuICAgKiAgICk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgb3JjaGVzdHJhbF9zZWN0aW9ucyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnc3RyaW5ncycpLFxuICAgKiAgICgyLCAnd29vZHdpbmRzJyk7XG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgaW5zdHJ1bWVudHMgKGlkLCBzZWN0aW9uX2lkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgMiwgJ2ZsdXRlJyksXG4gICAqICAgKDIsIDEsICd2aW9saW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgVXNlIGBvcmAgb24gcmVmZXJlbmNlZCB0YWJsZXNcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwic3RyaW5nc1wiLFxuICAgKiAgICAgICBcImluc3RydW1lbnRzXCI6IFtcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICBcIm5hbWVcIjogXCJ2aW9saW5cIlxuICAgKiAgICAgICAgIH1cbiAgICogICAgICAgXVxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIG9yKFxuICAgIGZpbHRlcnM6IHN0cmluZyxcbiAgICB7XG4gICAgICBmb3JlaWduVGFibGUsXG4gICAgICByZWZlcmVuY2VkVGFibGUgPSBmb3JlaWduVGFibGUsXG4gICAgfTogeyBmb3JlaWduVGFibGU/OiBzdHJpbmc7IHJlZmVyZW5jZWRUYWJsZT86IHN0cmluZyB9ID0ge31cbiAgKTogdGhpcyB7XG4gICAgY29uc3Qga2V5ID0gcmVmZXJlbmNlZFRhYmxlID8gYCR7cmVmZXJlbmNlZFRhYmxlfS5vcmAgOiAnb3InXG4gICAgdGhpcy51cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChrZXksIGAoJHtmaWx0ZXJzfSlgKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBmaWx0ZXI8Q29sdW1uTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFJvdz4oXG4gICAgY29sdW1uOiBDb2x1bW5OYW1lLFxuICAgIG9wZXJhdG9yOiBgJHsnJyB8ICdub3QuJ30ke0ZpbHRlck9wZXJhdG9yfWAsXG4gICAgdmFsdWU6IHVua25vd25cbiAgKTogdGhpc1xuICBmaWx0ZXIoY29sdW1uOiBzdHJpbmcsIG9wZXJhdG9yOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogdGhpc1xuICAvKipcbiAgICogTWF0Y2ggb25seSByb3dzIHdoaWNoIHNhdGlzZnkgdGhlIGZpbHRlci4gVGhpcyBpcyBhbiBlc2NhcGUgaGF0Y2ggLSB5b3VcbiAgICogc2hvdWxkIHVzZSB0aGUgc3BlY2lmaWMgZmlsdGVyIG1ldGhvZHMgd2hlcmV2ZXIgcG9zc2libGUuXG4gICAqXG4gICAqIFVubGlrZSBtb3N0IGZpbHRlcnMsIGBvcGVhcmF0b3JgIGFuZCBgdmFsdWVgIGFyZSB1c2VkIGFzLWlzIGFuZCBuZWVkIHRvXG4gICAqIGZvbGxvdyBbUG9zdGdSRVNUXG4gICAqIHN5bnRheF0oaHR0cHM6Ly9wb3N0Z3Jlc3Qub3JnL2VuL3N0YWJsZS9hcGkuaHRtbCNvcGVyYXRvcnMpLiBZb3UgYWxzbyBuZWVkXG4gICAqIHRvIG1ha2Ugc3VyZSB0aGV5IGFyZSBwcm9wZXJseSBzYW5pdGl6ZWQuXG4gICAqXG4gICAqIEBwYXJhbSBjb2x1bW4gLSBUaGUgY29sdW1uIHRvIGZpbHRlciBvblxuICAgKiBAcGFyYW0gb3BlcmF0b3IgLSBUaGUgb3BlcmF0b3IgdG8gZmlsdGVyIHdpdGgsIGZvbGxvd2luZyBQb3N0Z1JFU1Qgc3ludGF4XG4gICAqIEBwYXJhbSB2YWx1ZSAtIFRoZSB2YWx1ZSB0byBmaWx0ZXIgd2l0aCwgZm9sbG93aW5nIFBvc3RnUkVTVCBzeW50YXhcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqIEBzdWJjYXRlZ29yeSBVc2luZyBmaWx0ZXJzXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIGZpbHRlcigpIGV4cGVjdHMgeW91IHRvIHVzZSB0aGUgcmF3IFBvc3RnUkVTVCBzeW50YXggZm9yIHRoZSBmaWx0ZXIgdmFsdWVzLlxuICAgKlxuICAgKiBgYGB0c1xuICAgKiAuZmlsdGVyKCdpZCcsICdpbicsICcoNSw2LDcpJykgIC8vIFVzZSBgKClgIGZvciBgaW5gIGZpbHRlclxuICAgKiAuZmlsdGVyKCdhcnJheWNvbCcsICdjcycsICd7XCJhXCIsXCJiXCJ9JykgIC8vIFVzZSBgY3NgIGZvciBgY29udGFpbnMoKWAsIGB7fWAgZm9yIGFycmF5IHZhbHVlc1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiAgIC5maWx0ZXIoJ25hbWUnLCAnaW4nLCAnKFwiSGFuXCIsXCJZb2RhXCIpJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFdpdGggYHNlbGVjdCgpYFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY2hhcmFjdGVycyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjaGFyYWN0ZXJzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdMdWtlJyksXG4gICAqICAgKDIsICdMZWlhJyksXG4gICAqICAgKDMsICdIYW4nKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgV2l0aCBgc2VsZWN0KClgXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMyxcbiAgICogICAgICAgXCJuYW1lXCI6IFwiSGFuXCJcbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIE9uIGEgcmVmZXJlbmNlZCB0YWJsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdvcmNoZXN0cmFsX3NlY3Rpb25zJylcbiAgICogICAuc2VsZWN0KGBcbiAgICogICAgIG5hbWUsXG4gICAqICAgICBpbnN0cnVtZW50cyFpbm5lciAoXG4gICAqICAgICAgIG5hbWVcbiAgICogICAgIClcbiAgICogICBgKVxuICAgKiAgIC5maWx0ZXIoJ2luc3RydW1lbnRzLm5hbWUnLCAnZXEnLCAnZmx1dGUnKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgT24gYSByZWZlcmVuY2VkIHRhYmxlXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBvcmNoZXN0cmFsX3NlY3Rpb25zIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICAgaW5zdHJ1bWVudHMgKFxuICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICogICAgIHNlY3Rpb25faWQgaW50OCBub3QgbnVsbCByZWZlcmVuY2VzIG9yY2hlc3RyYWxfc2VjdGlvbnMsXG4gICAqICAgICBuYW1lIHRleHRcbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIG9yY2hlc3RyYWxfc2VjdGlvbnMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ3N0cmluZ3MnKSxcbiAgICogICAoMiwgJ3dvb2R3aW5kcycpO1xuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGluc3RydW1lbnRzIChpZCwgc2VjdGlvbl9pZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsIDIsICdmbHV0ZScpLFxuICAgKiAgICgyLCAxLCAndmlvbGluJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIE9uIGEgcmVmZXJlbmNlZCB0YWJsZVxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcIm5hbWVcIjogXCJ3b29kd2luZHNcIixcbiAgICogICAgICAgXCJpbnN0cnVtZW50c1wiOiBbXG4gICAqICAgICAgICAge1xuICAgKiAgICAgICAgICAgXCJuYW1lXCI6IFwiZmx1dGVcIlxuICAgKiAgICAgICAgIH1cbiAgICogICAgICAgXVxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIGZpbHRlcihjb2x1bW46IHN0cmluZywgb3BlcmF0b3I6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiB0aGlzIHtcbiAgICB0aGlzLnVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKGNvbHVtbiwgYCR7b3BlcmF0b3J9LiR7dmFsdWV9YClcbiAgICByZXR1cm4gdGhpc1xuICB9XG59XG4iLCJpbXBvcnQgUG9zdGdyZXN0RmlsdGVyQnVpbGRlciBmcm9tICcuL1Bvc3RncmVzdEZpbHRlckJ1aWxkZXInXG5pbXBvcnQgeyBHZXRSZXN1bHQgfSBmcm9tICcuL3NlbGVjdC1xdWVyeS1wYXJzZXIvcmVzdWx0J1xuaW1wb3J0IHtcbiAgQ2xpZW50U2VydmVyT3B0aW9ucyxcbiAgRmV0Y2gsXG4gIEdlbmVyaWNTY2hlbWEsXG4gIEdlbmVyaWNUYWJsZSxcbiAgR2VuZXJpY1ZpZXcsXG59IGZyb20gJy4vdHlwZXMvY29tbW9uL2NvbW1vbidcbmltcG9ydCB7IFJlamVjdEV4Y2Vzc1Byb3BlcnRpZXMgfSBmcm9tICcuL3R5cGVzL3R5cGVzJ1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQb3N0Z3Jlc3RRdWVyeUJ1aWxkZXI8XG4gIENsaWVudE9wdGlvbnMgZXh0ZW5kcyBDbGllbnRTZXJ2ZXJPcHRpb25zLFxuICBTY2hlbWEgZXh0ZW5kcyBHZW5lcmljU2NoZW1hLFxuICBSZWxhdGlvbiBleHRlbmRzIEdlbmVyaWNUYWJsZSB8IEdlbmVyaWNWaWV3LFxuICBSZWxhdGlvbk5hbWUgPSB1bmtub3duLFxuICBSZWxhdGlvbnNoaXBzID0gUmVsYXRpb24gZXh0ZW5kcyB7IFJlbGF0aW9uc2hpcHM6IGluZmVyIFIgfSA/IFIgOiB1bmtub3duLFxuPiB7XG4gIHVybDogVVJMXG4gIGhlYWRlcnM6IEhlYWRlcnNcbiAgc2NoZW1hPzogc3RyaW5nXG4gIHNpZ25hbD86IEFib3J0U2lnbmFsXG4gIGZldGNoPzogRmV0Y2hcbiAgdXJsTGVuZ3RoTGltaXQ6IG51bWJlclxuXG4gIC8qKlxuICAgKiBFbmFibGUgb3IgZGlzYWJsZSBhdXRvbWF0aWMgcmV0cmllcyBmb3IgdHJhbnNpZW50IGVycm9ycy5cbiAgICogV2hlbiBlbmFibGVkLCBpZGVtcG90ZW50IHJlcXVlc3RzIChHRVQvSEVBRC9PUFRJT05TKSB0aGF0IGZhaWwgd2l0aCBuZXR3b3JrXG4gICAqIGVycm9ycyBvciBIVFRQIDUwMy81MjAgcmVzcG9uc2VzIGFyZSBhdXRvbWF0aWNhbGx5IHJldHJpZWQgd2l0aCBleHBvbmVudGlhbFxuICAgKiBiYWNrb2ZmICgxcywgMnMsIDRzLCB1cCB0byAzIGF0dGVtcHRzKS4gRGVmYXVsdHMgdG8gYHRydWVgIHdoZW4gbm90IHNwZWNpZmllZC5cbiAgICovXG4gIHJldHJ5PzogYm9vbGVhblxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgcXVlcnkgYnVpbGRlciBzY29wZWQgdG8gYSBQb3N0Z3JlcyB0YWJsZSBvciB2aWV3LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICpcbiAgICogQHBhcmFtIHVybCAtIFRoZSBVUkwgZm9yIHRoZSBxdWVyeVxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIE5hbWVkIHBhcmFtZXRlcnNcbiAgICogQHBhcmFtIG9wdGlvbnMuaGVhZGVycyAtIEN1c3RvbSBoZWFkZXJzXG4gICAqIEBwYXJhbSBvcHRpb25zLnNjaGVtYSAtIFBvc3RncmVzIHNjaGVtYSB0byB1c2VcbiAgICogQHBhcmFtIG9wdGlvbnMuZmV0Y2ggLSBDdXN0b20gZmV0Y2ggaW1wbGVtZW50YXRpb25cbiAgICogQHBhcmFtIG9wdGlvbnMudXJsTGVuZ3RoTGltaXQgLSBNYXhpbXVtIFVSTCBsZW5ndGggYmVmb3JlIHdhcm5pbmdcbiAgICogQHBhcmFtIG9wdGlvbnMucmV0cnkgLSBFbmFibGUgYXV0b21hdGljIHJldHJpZXMgZm9yIHRyYW5zaWVudCBlcnJvcnMgKGRlZmF1bHQ6IHRydWUpXG4gICAqXG4gICAqIEBleGFtcGxlIFVzaW5nIHN1cGFiYXNlLWpzIChyZWNvbW1lbmRlZClcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3N1cGFiYXNlLWpzJ1xuICAgKlxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudCgnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvJywgJ3lvdXItcHVibGlzaGFibGUta2V5JylcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgndXNlcnMnKS5zZWxlY3QoJyonKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU3RhbmRhbG9uZSBpbXBvcnQgZm9yIGJ1bmRsZS1zZW5zaXRpdmUgZW52aXJvbm1lbnRzXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IFBvc3RncmVzdFF1ZXJ5QnVpbGRlciB9IGZyb20gJ0BzdXBhYmFzZS9wb3N0Z3Jlc3QtanMnXG4gICAqXG4gICAqIGNvbnN0IHF1ZXJ5ID0gbmV3IFBvc3RncmVzdFF1ZXJ5QnVpbGRlcihcbiAgICogICBuZXcgVVJMKCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28vcmVzdC92MS91c2VycycpLFxuICAgKiAgIHsgaGVhZGVyczogeyBhcGlrZXk6ICd5b3VyLXB1Ymxpc2hhYmxlLWtleScgfSwgcmV0cnk6IHRydWUgfVxuICAgKiApXG4gICAqIGBgYFxuICAgKi9cbiAgY29uc3RydWN0b3IoXG4gICAgdXJsOiBVUkwsXG4gICAge1xuICAgICAgaGVhZGVycyA9IHt9LFxuICAgICAgc2NoZW1hLFxuICAgICAgZmV0Y2gsXG4gICAgICB1cmxMZW5ndGhMaW1pdCA9IDgwMDAsXG4gICAgICByZXRyeSxcbiAgICB9OiB7XG4gICAgICBoZWFkZXJzPzogSGVhZGVyc0luaXRcbiAgICAgIHNjaGVtYT86IHN0cmluZ1xuICAgICAgZmV0Y2g/OiBGZXRjaFxuICAgICAgdXJsTGVuZ3RoTGltaXQ/OiBudW1iZXJcbiAgICAgIHJldHJ5PzogYm9vbGVhblxuICAgIH1cbiAgKSB7XG4gICAgdGhpcy51cmwgPSB1cmxcbiAgICB0aGlzLmhlYWRlcnMgPSBuZXcgSGVhZGVycyhoZWFkZXJzKVxuICAgIHRoaXMuc2NoZW1hID0gc2NoZW1hXG4gICAgdGhpcy5mZXRjaCA9IGZldGNoXG4gICAgdGhpcy51cmxMZW5ndGhMaW1pdCA9IHVybExlbmd0aExpbWl0XG4gICAgdGhpcy5yZXRyeSA9IHJldHJ5XG4gIH1cblxuICAvKipcbiAgICogQ2xvbmUgVVJMIGFuZCBoZWFkZXJzIHRvIHByZXZlbnQgc2hhcmVkIHN0YXRlIGJldHdlZW4gb3BlcmF0aW9ucy5cbiAgICovXG4gIHByaXZhdGUgY2xvbmVSZXF1ZXN0U3RhdGUoKTogeyB1cmw6IFVSTDsgaGVhZGVyczogSGVhZGVycyB9IHtcbiAgICByZXR1cm4ge1xuICAgICAgdXJsOiBuZXcgVVJMKHRoaXMudXJsLnRvU3RyaW5nKCkpLFxuICAgICAgaGVhZGVyczogbmV3IEhlYWRlcnModGhpcy5oZWFkZXJzKSxcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICAgICAqIFBlcmZvcm0gYSBTRUxFQ1QgcXVlcnkgb24gdGhlIHRhYmxlIG9yIHZpZXcuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIGNvbHVtbnMgLSBUaGUgY29sdW1ucyB0byByZXRyaWV2ZSwgc2VwYXJhdGVkIGJ5IGNvbW1hcy4gQ29sdW1ucyBjYW4gYmUgcmVuYW1lZCB3aGVuIHJldHVybmVkIHdpdGggYGN1c3RvbU5hbWU6Y29sdW1uTmFtZWBcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0gb3B0aW9ucyAtIE5hbWVkIHBhcmFtZXRlcnNcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0gb3B0aW9ucy5oZWFkIC0gV2hlbiBzZXQgdG8gYHRydWVgLCBgZGF0YWAgd2lsbCBub3QgYmUgcmV0dXJuZWQuXG4gICAgICAgKiBVc2VmdWwgaWYgeW91IG9ubHkgbmVlZCB0aGUgY291bnQuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIG9wdGlvbnMuY291bnQgLSBDb3VudCBhbGdvcml0aG0gdG8gdXNlIHRvIGNvdW50IHJvd3MgaW4gdGhlIHRhYmxlIG9yIHZpZXcuXG4gICAgICAgKlxuICAgICAgICogYFwiZXhhY3RcImA6IEV4YWN0IGJ1dCBzbG93IGNvdW50IGFsZ29yaXRobS4gUGVyZm9ybXMgYSBgQ09VTlQoKilgIHVuZGVyIHRoZVxuICAgICAgICogaG9vZC5cbiAgICAgICAqXG4gICAgICAgKiBgXCJwbGFubmVkXCJgOiBBcHByb3hpbWF0ZWQgYnV0IGZhc3QgY291bnQgYWxnb3JpdGhtLiBVc2VzIHRoZSBQb3N0Z3Jlc1xuICAgICAgICogc3RhdGlzdGljcyB1bmRlciB0aGUgaG9vZC5cbiAgICAgICAqXG4gICAgICAgKiBgXCJlc3RpbWF0ZWRcImA6IFVzZXMgZXhhY3QgY291bnQgZm9yIGxvdyBudW1iZXJzIGFuZCBwbGFubmVkIGNvdW50IGZvciBoaWdoXG4gICAgICAgKiBudW1iZXJzLlxuICAgICAgICpcbiAgICAgICAqIEByZW1hcmtzXG4gICAgICAgKiBXaGVuIHVzaW5nIGBjb3VudGAgd2l0aCBgLnJhbmdlKClgIG9yIGAubGltaXQoKWAsIHRoZSByZXR1cm5lZCBgY291bnRgIGlzIHRoZSB0b3RhbCBudW1iZXIgb2Ygcm93c1xuICAgICAgICogdGhhdCBtYXRjaCB5b3VyIGZpbHRlcnMsIG5vdCB0aGUgbnVtYmVyIG9mIHJvd3MgaW4gdGhlIGN1cnJlbnQgcGFnZS4gVXNlIHRoaXMgdG8gYnVpbGQgcGFnaW5hdGlvbiBVSS5cbiAgICAgICBcbiAgICAgKiAtIEJ5IGRlZmF1bHQsIFN1cGFiYXNlIHByb2plY3RzIHJldHVybiBhIG1heGltdW0gb2YgMSwwMDAgcm93cy4gVGhpcyBzZXR0aW5nIGNhbiBiZSBjaGFuZ2VkIGluIHlvdXIgcHJvamVjdCdzIFtBUEkgc2V0dGluZ3NdKC9kYXNoYm9hcmQvcHJvamVjdC9fL3NldHRpbmdzL2FwaSkuIEl0J3MgcmVjb21tZW5kZWQgdGhhdCB5b3Uga2VlcCBpdCBsb3cgdG8gbGltaXQgdGhlIHBheWxvYWQgc2l6ZSBvZiBhY2NpZGVudGFsIG9yIG1hbGljaW91cyByZXF1ZXN0cy4gWW91IGNhbiB1c2UgYHJhbmdlKClgIHF1ZXJpZXMgdG8gcGFnaW5hdGUgdGhyb3VnaCB5b3VyIGRhdGEuXG4gICAgICogLSBgc2VsZWN0KClgIGNhbiBiZSBjb21iaW5lZCB3aXRoIFtGaWx0ZXJzXSgvZG9jcy9yZWZlcmVuY2UvamF2YXNjcmlwdC91c2luZy1maWx0ZXJzKVxuICAgICAqIC0gYHNlbGVjdCgpYCBjYW4gYmUgY29tYmluZWQgd2l0aCBbTW9kaWZpZXJzXSgvZG9jcy9yZWZlcmVuY2UvamF2YXNjcmlwdC91c2luZy1tb2RpZmllcnMpXG4gICAgICogLSBgYXBpa2V5YCBpcyBhIHJlc2VydmVkIGtleXdvcmQgaWYgeW91J3JlIHVzaW5nIHRoZSBbU3VwYWJhc2UgUGxhdGZvcm1dKC9kb2NzL2d1aWRlcy9wbGF0Zm9ybSkgYW5kIFtzaG91bGQgYmUgYXZvaWRlZCBhcyBhIGNvbHVtbiBuYW1lXShodHRwczovL2dpdGh1Yi5jb20vc3VwYWJhc2Uvc3VwYWJhc2UvaXNzdWVzLzU0NjUpLiAqXG4gICAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZSBHZXR0aW5nIHlvdXIgZGF0YVxuICAgICAqIGBgYGpzXG4gICAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgKiAgIC5mcm9tKCdjaGFyYWN0ZXJzJylcbiAgICAgKiAgIC5zZWxlY3QoKVxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVTcWwgR2V0dGluZyB5b3VyIGRhdGFcbiAgICAgKiBgYGBzcWxcbiAgICAgKiBjcmVhdGUgdGFibGVcbiAgICAgKiAgIGNoYXJhY3RlcnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAgICpcbiAgICAgKiBpbnNlcnQgaW50b1xuICAgICAqICAgY2hhcmFjdGVycyAoaWQsIG5hbWUpXG4gICAgICogdmFsdWVzXG4gICAgICogICAoMSwgJ0hhcnJ5JyksXG4gICAgICogICAoMiwgJ0Zyb2RvJyksXG4gICAgICogICAoMywgJ0thdG5pc3MnKTtcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgR2V0dGluZyB5b3VyIGRhdGFcbiAgICAgKiBgYGBqc29uXG4gICAgICoge1xuICAgICAqICAgXCJkYXRhXCI6IFtcbiAgICAgKiAgICAge1xuICAgICAqICAgICAgIFwiaWRcIjogMSxcbiAgICAgKiAgICAgICBcIm5hbWVcIjogXCJIYXJyeVwiXG4gICAgICogICAgIH0sXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcImlkXCI6IDIsXG4gICAgICogICAgICAgXCJuYW1lXCI6IFwiRnJvZG9cIlxuICAgICAqICAgICB9LFxuICAgICAqICAgICB7XG4gICAgICogICAgICAgXCJpZFwiOiAzLFxuICAgICAqICAgICAgIFwibmFtZVwiOiBcIkthdG5pc3NcIlxuICAgICAqICAgICB9XG4gICAgICogICBdLFxuICAgICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlRGVzY3JpcHRpb24gSGFuZGxpbmcgZXJyb3JzXG4gICAgICogVGhlIG1vc3QgdXNlZnVsIGZpZWxkIG9uIGEgUG9zdGdyZXMgZXJyb3IgaXMgdXN1YWxseSBgaGludGAg4oCUIHdoZW4gdGhlIGRhdGFiYXNlIGtub3dzIHRoZSBmaXgsIGl0IHB1dHMgdGhlIGxpdGVyYWwgU1FMIHRoZXJlLiBGb3IgZXhhbXBsZSwgYSBwZXJtaXNzaW9uLWRlbmllZCBlcnJvciAoYGNvZGU6ICc0MjUwMSdgKSBhcnJpdmVzIHdpdGggYSBgaGludGAgbGlrZSBgXCJHcmFudCB0aGUgcmVxdWlyZWQgcHJpdmlsZWdlcyB0byB0aGUgY3VycmVudCByb2xlIHdpdGg6IEdSQU5UIFNFTEVDVCBPTiBwdWJsaWMuY2hhcmFjdGVycyBUTyBhbm9uO1wiYC4gTG9nIHRoZSBmdWxsIGBlcnJvcmAgb2JqZWN0IHNvIHRoZSBoaW50IGlzbid0IGhpZGRlbiBiZWhpbmQgYGVycm9yLm1lc3NhZ2VgLlxuICAgICAqXG4gICAgICogQGV4YW1wbGUgSGFuZGxpbmcgZXJyb3JzXG4gICAgICogYGBganNcbiAgICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdjaGFyYWN0ZXJzJykuc2VsZWN0KClcbiAgICAgKiBpZiAoZXJyb3IpIHtcbiAgICAgKiAgIC8vIExvZ3MgdGhlIGZ1bGwgZXJyb3I6IG1lc3NhZ2UsIGNvZGUsIGRldGFpbHMsIGFuZCBoaW50LlxuICAgICAqICAgY29uc29sZS5lcnJvcihlcnJvcilcbiAgICAgKiAgIHJldHVyblxuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgSGFuZGxpbmcgZXJyb3JzXG4gICAgICogYGBganNvblxuICAgICAqIHtcbiAgICAgKiAgIFwiZXJyb3JcIjoge1xuICAgICAqICAgICBcImNvZGVcIjogXCI0MjUwMVwiLFxuICAgICAqICAgICBcImRldGFpbHNcIjogbnVsbCxcbiAgICAgKiAgICAgXCJoaW50XCI6IFwiR3JhbnQgdGhlIHJlcXVpcmVkIHByaXZpbGVnZXMgdG8gdGhlIGN1cnJlbnQgcm9sZSB3aXRoOiBHUkFOVCBTRUxFQ1QgT04gcHVibGljLmNoYXJhY3RlcnMgVE8gYW5vbjtcIixcbiAgICAgKiAgICAgXCJtZXNzYWdlXCI6IFwicGVybWlzc2lvbiBkZW5pZWQgZm9yIHRhYmxlIGNoYXJhY3RlcnNcIlxuICAgICAqICAgfSxcbiAgICAgKiAgIFwic3RhdHVzXCI6IDQwMSxcbiAgICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIlVuYXV0aG9yaXplZFwiXG4gICAgICogfVxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGUgU2VsZWN0aW5nIHNwZWNpZmljIGNvbHVtbnNcbiAgICAgKiBgYGBqc1xuICAgICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICogICAuZnJvbSgnY2hhcmFjdGVycycpXG4gICAgICogICAuc2VsZWN0KCduYW1lJylcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlU3FsIFNlbGVjdGluZyBzcGVjaWZpYyBjb2x1bW5zXG4gICAgICogYGBgc3FsXG4gICAgICogY3JlYXRlIHRhYmxlXG4gICAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgICAqXG4gICAgICogaW5zZXJ0IGludG9cbiAgICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsICdGcm9kbycpLFxuICAgICAqICAgKDIsICdIYXJyeScpLFxuICAgICAqICAgKDMsICdLYXRuaXNzJyk7XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVJlc3BvbnNlIFNlbGVjdGluZyBzcGVjaWZpYyBjb2x1bW5zXG4gICAgICogYGBganNvblxuICAgICAqIHtcbiAgICAgKiAgIFwiZGF0YVwiOiBbXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcIm5hbWVcIjogXCJGcm9kb1wiXG4gICAgICogICAgIH0sXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcIm5hbWVcIjogXCJIYXJyeVwiXG4gICAgICogICAgIH0sXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcIm5hbWVcIjogXCJLYXRuaXNzXCJcbiAgICAgKiAgICAgfVxuICAgICAqICAgXSxcbiAgICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICAgKiB9XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFF1ZXJ5IHJlZmVyZW5jZWQgdGFibGVzXG4gICAgICogSWYgeW91ciBkYXRhYmFzZSBoYXMgZm9yZWlnbiBrZXkgcmVsYXRpb25zaGlwcywgeW91IGNhbiBxdWVyeSByZWxhdGVkIHRhYmxlcyB0b28uXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZSBRdWVyeSByZWZlcmVuY2VkIHRhYmxlc1xuICAgICAqIGBgYGpzXG4gICAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgKiAgIC5mcm9tKCdvcmNoZXN0cmFsX3NlY3Rpb25zJylcbiAgICAgKiAgIC5zZWxlY3QoYFxuICAgICAqICAgICBuYW1lLFxuICAgICAqICAgICBpbnN0cnVtZW50cyAoXG4gICAgICogICAgICAgbmFtZVxuICAgICAqICAgICApXG4gICAgICogICBgKVxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVTcWwgUXVlcnkgcmVmZXJlbmNlZCB0YWJsZXNcbiAgICAgKiBgYGBzcWxcbiAgICAgKiBjcmVhdGUgdGFibGVcbiAgICAgKiAgIG9yY2hlc3RyYWxfc2VjdGlvbnMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAgICogY3JlYXRlIHRhYmxlXG4gICAgICogICBpbnN0cnVtZW50cyAoXG4gICAgICogICAgIGlkIGludDggcHJpbWFyeSBrZXksXG4gICAgICogICAgIHNlY3Rpb25faWQgaW50OCBub3QgbnVsbCByZWZlcmVuY2VzIG9yY2hlc3RyYWxfc2VjdGlvbnMsXG4gICAgICogICAgIG5hbWUgdGV4dFxuICAgICAqICAgKTtcbiAgICAgKlxuICAgICAqIGluc2VydCBpbnRvXG4gICAgICogICBvcmNoZXN0cmFsX3NlY3Rpb25zIChpZCwgbmFtZSlcbiAgICAgKiB2YWx1ZXNcbiAgICAgKiAgICgxLCAnc3RyaW5ncycpLFxuICAgICAqICAgKDIsICd3b29kd2luZHMnKTtcbiAgICAgKiBpbnNlcnQgaW50b1xuICAgICAqICAgaW5zdHJ1bWVudHMgKGlkLCBzZWN0aW9uX2lkLCBuYW1lKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsIDIsICdmbHV0ZScpLFxuICAgICAqICAgKDIsIDEsICd2aW9saW4nKTtcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgUXVlcnkgcmVmZXJlbmNlZCB0YWJsZXNcbiAgICAgKiBgYGBqc29uXG4gICAgICoge1xuICAgICAqICAgXCJkYXRhXCI6IFtcbiAgICAgKiAgICAge1xuICAgICAqICAgICAgIFwibmFtZVwiOiBcInN0cmluZ3NcIixcbiAgICAgKiAgICAgICBcImluc3RydW1lbnRzXCI6IFtcbiAgICAgKiAgICAgICAgIHtcbiAgICAgKiAgICAgICAgICAgXCJuYW1lXCI6IFwidmlvbGluXCJcbiAgICAgKiAgICAgICAgIH1cbiAgICAgKiAgICAgICBdXG4gICAgICogICAgIH0sXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcIm5hbWVcIjogXCJ3b29kd2luZHNcIixcbiAgICAgKiAgICAgICBcImluc3RydW1lbnRzXCI6IFtcbiAgICAgKiAgICAgICAgIHtcbiAgICAgKiAgICAgICAgICAgXCJuYW1lXCI6IFwiZmx1dGVcIlxuICAgICAqICAgICAgICAgfVxuICAgICAqICAgICAgIF1cbiAgICAgKiAgICAgfVxuICAgICAqICAgXSxcbiAgICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICAgKiB9XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFF1ZXJ5IHJlZmVyZW5jZWQgdGFibGVzIHdpdGggc3BhY2VzIGluIHRoZWlyIG5hbWVzXG4gICAgICogSWYgeW91ciB0YWJsZSBuYW1lIGNvbnRhaW5zIHNwYWNlcywgeW91IG11c3QgdXNlIGRvdWJsZSBxdW90ZXMgaW4gdGhlIGBzZWxlY3RgIHN0YXRlbWVudCB0byByZWZlcmVuY2UgdGhlIHRhYmxlLlxuICAgICAqXG4gICAgICogQGV4YW1wbGUgUXVlcnkgcmVmZXJlbmNlZCB0YWJsZXMgd2l0aCBzcGFjZXMgaW4gdGhlaXIgbmFtZXNcbiAgICAgKiBgYGBqc1xuICAgICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICogICAuZnJvbSgnb3JjaGVzdHJhbCBzZWN0aW9ucycpXG4gICAgICogICAuc2VsZWN0KGBcbiAgICAgKiAgICAgbmFtZSxcbiAgICAgKiAgICAgXCJtdXNpY2FsIGluc3RydW1lbnRzXCIgKFxuICAgICAqICAgICAgIG5hbWVcbiAgICAgKiAgICAgKVxuICAgICAqICAgYClcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlU3FsIFF1ZXJ5IHJlZmVyZW5jZWQgdGFibGVzIHdpdGggc3BhY2VzIGluIHRoZWlyIG5hbWVzXG4gICAgICogYGBgc3FsXG4gICAgICogY3JlYXRlIHRhYmxlXG4gICAgICogICBcIm9yY2hlc3RyYWwgc2VjdGlvbnNcIiAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICAgKiBjcmVhdGUgdGFibGVcbiAgICAgKiAgIFwibXVzaWNhbCBpbnN0cnVtZW50c1wiIChcbiAgICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICAgKiAgICAgc2VjdGlvbl9pZCBpbnQ4IG5vdCBudWxsIHJlZmVyZW5jZXMgXCJvcmNoZXN0cmFsIHNlY3Rpb25zXCIsXG4gICAgICogICAgIG5hbWUgdGV4dFxuICAgICAqICAgKTtcbiAgICAgKlxuICAgICAqIGluc2VydCBpbnRvXG4gICAgICogICBcIm9yY2hlc3RyYWwgc2VjdGlvbnNcIiAoaWQsIG5hbWUpXG4gICAgICogdmFsdWVzXG4gICAgICogICAoMSwgJ3N0cmluZ3MnKSxcbiAgICAgKiAgICgyLCAnd29vZHdpbmRzJyk7XG4gICAgICogaW5zZXJ0IGludG9cbiAgICAgKiAgIFwibXVzaWNhbCBpbnN0cnVtZW50c1wiIChpZCwgc2VjdGlvbl9pZCwgbmFtZSlcbiAgICAgKiB2YWx1ZXNcbiAgICAgKiAgICgxLCAyLCAnZmx1dGUnKSxcbiAgICAgKiAgICgyLCAxLCAndmlvbGluJyk7XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVJlc3BvbnNlIFF1ZXJ5IHJlZmVyZW5jZWQgdGFibGVzIHdpdGggc3BhY2VzIGluIHRoZWlyIG5hbWVzXG4gICAgICogYGBganNvblxuICAgICAqIHtcbiAgICAgKiAgIFwiZGF0YVwiOiBbXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcIm5hbWVcIjogXCJzdHJpbmdzXCIsXG4gICAgICogICAgICAgXCJtdXNpY2FsIGluc3RydW1lbnRzXCI6IFtcbiAgICAgKiAgICAgICAgIHtcbiAgICAgKiAgICAgICAgICAgXCJuYW1lXCI6IFwidmlvbGluXCJcbiAgICAgKiAgICAgICAgIH1cbiAgICAgKiAgICAgICBdXG4gICAgICogICAgIH0sXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcIm5hbWVcIjogXCJ3b29kd2luZHNcIixcbiAgICAgKiAgICAgICBcIm11c2ljYWwgaW5zdHJ1bWVudHNcIjogW1xuICAgICAqICAgICAgICAge1xuICAgICAqICAgICAgICAgICBcIm5hbWVcIjogXCJmbHV0ZVwiXG4gICAgICogICAgICAgICB9XG4gICAgICogICAgICAgXVxuICAgICAqICAgICB9XG4gICAgICogICBdLFxuICAgICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlRGVzY3JpcHRpb24gUXVlcnkgcmVmZXJlbmNlZCB0YWJsZXMgdGhyb3VnaCBhIGpvaW4gdGFibGVcbiAgICAgKiBJZiB5b3UncmUgaW4gYSBzaXR1YXRpb24gd2hlcmUgeW91ciB0YWJsZXMgYXJlICoqTk9UKiogZGlyZWN0bHlcbiAgICAgKiByZWxhdGVkLCBidXQgaW5zdGVhZCBhcmUgam9pbmVkIGJ5IGEgX2pvaW4gdGFibGVfLCB5b3UgY2FuIHN0aWxsIHVzZVxuICAgICAqIHRoZSBgc2VsZWN0KClgIG1ldGhvZCB0byBxdWVyeSB0aGUgcmVsYXRlZCBkYXRhLiBUaGUgam9pbiB0YWJsZSBuZWVkc1xuICAgICAqIHRvIGhhdmUgdGhlIGZvcmVpZ24ga2V5cyBhcyBwYXJ0IG9mIGl0cyBjb21wb3NpdGUgcHJpbWFyeSBrZXkuXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZSBRdWVyeSByZWZlcmVuY2VkIHRhYmxlcyB0aHJvdWdoIGEgam9pbiB0YWJsZVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgKiAgIC5mcm9tKCd1c2VycycpXG4gICAgICogICAuc2VsZWN0KGBcbiAgICAgKiAgICAgbmFtZSxcbiAgICAgKiAgICAgdGVhbXMgKFxuICAgICAqICAgICAgIG5hbWVcbiAgICAgKiAgICAgKVxuICAgICAqICAgYClcbiAgICAgKiAgIFxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVTcWwgUXVlcnkgcmVmZXJlbmNlZCB0YWJsZXMgdGhyb3VnaCBhIGpvaW4gdGFibGVcbiAgICAgKiBgYGBzcWxcbiAgICAgKiBjcmVhdGUgdGFibGVcbiAgICAgKiAgIHVzZXJzIChcbiAgICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICAgKiAgICAgbmFtZSB0ZXh0XG4gICAgICogICApO1xuICAgICAqIGNyZWF0ZSB0YWJsZVxuICAgICAqICAgdGVhbXMgKFxuICAgICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgICAqICAgICBuYW1lIHRleHRcbiAgICAgKiAgICk7XG4gICAgICogLS0gam9pbiB0YWJsZVxuICAgICAqIGNyZWF0ZSB0YWJsZVxuICAgICAqICAgdXNlcnNfdGVhbXMgKFxuICAgICAqICAgICB1c2VyX2lkIGludDggbm90IG51bGwgcmVmZXJlbmNlcyB1c2VycyxcbiAgICAgKiAgICAgdGVhbV9pZCBpbnQ4IG5vdCBudWxsIHJlZmVyZW5jZXMgdGVhbXMsXG4gICAgICogICAgIC0tIGJvdGggZm9yZWlnbiBrZXlzIG11c3QgYmUgcGFydCBvZiBhIGNvbXBvc2l0ZSBwcmltYXJ5IGtleVxuICAgICAqICAgICBwcmltYXJ5IGtleSAodXNlcl9pZCwgdGVhbV9pZClcbiAgICAgKiAgICk7XG4gICAgICpcbiAgICAgKiBpbnNlcnQgaW50b1xuICAgICAqICAgdXNlcnMgKGlkLCBuYW1lKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsICdLaXJhbicpLFxuICAgICAqICAgKDIsICdFdmFuJyk7XG4gICAgICogaW5zZXJ0IGludG9cbiAgICAgKiAgIHRlYW1zIChpZCwgbmFtZSlcbiAgICAgKiB2YWx1ZXNcbiAgICAgKiAgICgxLCAnR3JlZW4nKSxcbiAgICAgKiAgICgyLCAnQmx1ZScpO1xuICAgICAqIGluc2VydCBpbnRvXG4gICAgICogICB1c2Vyc190ZWFtcyAodXNlcl9pZCwgdGVhbV9pZClcbiAgICAgKiB2YWx1ZXNcbiAgICAgKiAgICgxLCAxKSxcbiAgICAgKiAgICgxLCAyKSxcbiAgICAgKiAgICgyLCAyKTtcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgUXVlcnkgcmVmZXJlbmNlZCB0YWJsZXMgdGhyb3VnaCBhIGpvaW4gdGFibGVcbiAgICAgKiBgYGBqc29uXG4gICAgICogICB7XG4gICAgICogICAgIFwiZGF0YVwiOiBbXG4gICAgICogICAgICAge1xuICAgICAqICAgICAgICAgXCJuYW1lXCI6IFwiS2lyYW5cIixcbiAgICAgKiAgICAgICAgIFwidGVhbXNcIjogW1xuICAgICAqICAgICAgICAgICB7XG4gICAgICogICAgICAgICAgICAgXCJuYW1lXCI6IFwiR3JlZW5cIlxuICAgICAqICAgICAgICAgICB9LFxuICAgICAqICAgICAgICAgICB7XG4gICAgICogICAgICAgICAgICAgXCJuYW1lXCI6IFwiQmx1ZVwiXG4gICAgICogICAgICAgICAgIH1cbiAgICAgKiAgICAgICAgIF1cbiAgICAgKiAgICAgICB9LFxuICAgICAqICAgICAgIHtcbiAgICAgKiAgICAgICAgIFwibmFtZVwiOiBcIkV2YW5cIixcbiAgICAgKiAgICAgICAgIFwidGVhbXNcIjogW1xuICAgICAqICAgICAgICAgICB7XG4gICAgICogICAgICAgICAgICAgXCJuYW1lXCI6IFwiQmx1ZVwiXG4gICAgICogICAgICAgICAgIH1cbiAgICAgKiAgICAgICAgIF1cbiAgICAgKiAgICAgICB9XG4gICAgICogICAgIF0sXG4gICAgICogICAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICAgKiAgICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgICAqICAgfVxuICAgICAqICAgXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFF1ZXJ5IHRoZSBzYW1lIHJlZmVyZW5jZWQgdGFibGUgbXVsdGlwbGUgdGltZXNcbiAgICAgKiBJZiB5b3UgbmVlZCB0byBxdWVyeSB0aGUgc2FtZSByZWZlcmVuY2VkIHRhYmxlIHR3aWNlLCB1c2UgdGhlIG5hbWUgb2YgdGhlXG4gICAgICogam9pbmVkIGNvbHVtbiB0byBpZGVudGlmeSB3aGljaCBqb2luIHRvIHVzZS4gWW91IGNhbiBhbHNvIGdpdmUgZWFjaFxuICAgICAqIGNvbHVtbiBhbiBhbGlhcy5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlIFF1ZXJ5IHRoZSBzYW1lIHJlZmVyZW5jZWQgdGFibGUgbXVsdGlwbGUgdGltZXNcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICogICAuZnJvbSgnbWVzc2FnZXMnKVxuICAgICAqICAgLnNlbGVjdChgXG4gICAgICogICAgIGNvbnRlbnQsXG4gICAgICogICAgIGZyb206c2VuZGVyX2lkKG5hbWUpLFxuICAgICAqICAgICB0bzpyZWNlaXZlcl9pZChuYW1lKVxuICAgICAqICAgYClcbiAgICAgKlxuICAgICAqIC8vIFRvIGluZmVyIHR5cGVzLCB1c2UgdGhlIG5hbWUgb2YgdGhlIHRhYmxlIChpbiB0aGlzIGNhc2UgYHVzZXJzYCkgYW5kXG4gICAgICogLy8gdGhlIG5hbWUgb2YgdGhlIGZvcmVpZ24ga2V5IGNvbnN0cmFpbnQuXG4gICAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgKiAgIC5mcm9tKCdtZXNzYWdlcycpXG4gICAgICogICAuc2VsZWN0KGBcbiAgICAgKiAgICAgY29udGVudCxcbiAgICAgKiAgICAgZnJvbTp1c2VycyFtZXNzYWdlc19zZW5kZXJfaWRfZmtleShuYW1lKSxcbiAgICAgKiAgICAgdG86dXNlcnMhbWVzc2FnZXNfcmVjZWl2ZXJfaWRfZmtleShuYW1lKVxuICAgICAqICAgYClcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlU3FsIFF1ZXJ5IHRoZSBzYW1lIHJlZmVyZW5jZWQgdGFibGUgbXVsdGlwbGUgdGltZXNcbiAgICAgKiBgYGBzcWxcbiAgICAgKiAgY3JlYXRlIHRhYmxlXG4gICAgICogIHVzZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgICAqXG4gICAgICogIGNyZWF0ZSB0YWJsZVxuICAgICAqICAgIG1lc3NhZ2VzIChcbiAgICAgKiAgICAgIHNlbmRlcl9pZCBpbnQ4IG5vdCBudWxsIHJlZmVyZW5jZXMgdXNlcnMsXG4gICAgICogICAgICByZWNlaXZlcl9pZCBpbnQ4IG5vdCBudWxsIHJlZmVyZW5jZXMgdXNlcnMsXG4gICAgICogICAgICBjb250ZW50IHRleHRcbiAgICAgKiAgICApO1xuICAgICAqXG4gICAgICogIGluc2VydCBpbnRvXG4gICAgICogICAgdXNlcnMgKGlkLCBuYW1lKVxuICAgICAqICB2YWx1ZXNcbiAgICAgKiAgICAoMSwgJ0tpcmFuJyksXG4gICAgICogICAgKDIsICdFdmFuJyk7XG4gICAgICpcbiAgICAgKiAgaW5zZXJ0IGludG9cbiAgICAgKiAgICBtZXNzYWdlcyAoc2VuZGVyX2lkLCByZWNlaXZlcl9pZCwgY29udGVudClcbiAgICAgKiAgdmFsdWVzXG4gICAgICogICAgKDEsIDIsICfwn5GLJyk7XG4gICAgICogIGBgYFxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVSZXNwb25zZSBRdWVyeSB0aGUgc2FtZSByZWZlcmVuY2VkIHRhYmxlIG11bHRpcGxlIHRpbWVzXG4gICAgICogYGBganNvblxuICAgICAqIHtcbiAgICAgKiAgIFwiZGF0YVwiOiBbXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcImNvbnRlbnRcIjogXCLwn5GLXCIsXG4gICAgICogICAgICAgXCJmcm9tXCI6IHtcbiAgICAgKiAgICAgICAgIFwibmFtZVwiOiBcIktpcmFuXCJcbiAgICAgKiAgICAgICB9LFxuICAgICAqICAgICAgIFwidG9cIjoge1xuICAgICAqICAgICAgICAgXCJuYW1lXCI6IFwiRXZhblwiXG4gICAgICogICAgICAgfVxuICAgICAqICAgICB9XG4gICAgICogICBdLFxuICAgICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlRGVzY3JpcHRpb24gUXVlcnkgbmVzdGVkIGZvcmVpZ24gdGFibGVzIHRocm91Z2ggYSBqb2luIHRhYmxlXG4gICAgICogWW91IGNhbiB1c2UgdGhlIHJlc3VsdCBvZiBhIGpvaW5lZCB0YWJsZSB0byBnYXRoZXIgZGF0YSBpblxuICAgICAqIGFub3RoZXIgZm9yZWlnbiB0YWJsZS4gV2l0aCBtdWx0aXBsZSByZWZlcmVuY2VzIHRvIHRoZSBzYW1lIGZvcmVpZ25cbiAgICAgKiB0YWJsZSB5b3UgbXVzdCBzcGVjaWZ5IHRoZSBjb2x1bW4gb24gd2hpY2ggdG8gY29uZHVjdCB0aGUgam9pbi5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlIFF1ZXJ5IG5lc3RlZCBmb3JlaWduIHRhYmxlcyB0aHJvdWdoIGEgam9pbiB0YWJsZVxuICAgICAqIGBgYHRzXG4gICAgICogICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAqICAgICAuZnJvbSgnZ2FtZXMnKVxuICAgICAqICAgICAuc2VsZWN0KGBcbiAgICAgKiAgICAgICBnYW1lX2lkOmlkLFxuICAgICAqICAgICAgIGF3YXlfdGVhbTp0ZWFtcyFnYW1lc19hd2F5X3RlYW1fZmtleSAoXG4gICAgICogICAgICAgICB1c2VycyAoXG4gICAgICogICAgICAgICAgIGlkLFxuICAgICAqICAgICAgICAgICBuYW1lXG4gICAgICogICAgICAgICApXG4gICAgICogICAgICAgKVxuICAgICAqICAgICBgKVxuICAgICAqICAgXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVNxbCBRdWVyeSBuZXN0ZWQgZm9yZWlnbiB0YWJsZXMgdGhyb3VnaCBhIGpvaW4gdGFibGVcbiAgICAgKiBgYGBzcWxcbiAgICAgKiBgYGBzcWxcbiAgICAgKiBjcmVhdGUgdGFibGVcbiAgICAgKiAgIHVzZXJzIChcbiAgICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICAgKiAgICAgbmFtZSB0ZXh0XG4gICAgICogICApO1xuICAgICAqIGNyZWF0ZSB0YWJsZVxuICAgICAqICAgdGVhbXMgKFxuICAgICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgICAqICAgICBuYW1lIHRleHRcbiAgICAgKiAgICk7XG4gICAgICogLS0gam9pbiB0YWJsZVxuICAgICAqIGNyZWF0ZSB0YWJsZVxuICAgICAqICAgdXNlcnNfdGVhbXMgKFxuICAgICAqICAgICB1c2VyX2lkIGludDggbm90IG51bGwgcmVmZXJlbmNlcyB1c2VycyxcbiAgICAgKiAgICAgdGVhbV9pZCBpbnQ4IG5vdCBudWxsIHJlZmVyZW5jZXMgdGVhbXMsXG4gICAgICpcbiAgICAgKiAgICAgcHJpbWFyeSBrZXkgKHVzZXJfaWQsIHRlYW1faWQpXG4gICAgICogICApO1xuICAgICAqIGNyZWF0ZSB0YWJsZVxuICAgICAqICAgZ2FtZXMgKFxuICAgICAqICAgICBpZCBpbnQ4IHByaW1hcnkga2V5LFxuICAgICAqICAgICBob21lX3RlYW0gaW50OCBub3QgbnVsbCByZWZlcmVuY2VzIHRlYW1zLFxuICAgICAqICAgICBhd2F5X3RlYW0gaW50OCBub3QgbnVsbCByZWZlcmVuY2VzIHRlYW1zLFxuICAgICAqICAgICBuYW1lIHRleHRcbiAgICAgKiAgICk7XG4gICAgICpcbiAgICAgKiBpbnNlcnQgaW50byB1c2VycyAoaWQsIG5hbWUpXG4gICAgICogdmFsdWVzXG4gICAgICogICAoMSwgJ0tpcmFuJyksXG4gICAgICogICAoMiwgJ0V2YW4nKTtcbiAgICAgKiBpbnNlcnQgaW50b1xuICAgICAqICAgdGVhbXMgKGlkLCBuYW1lKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsICdHcmVlbicpLFxuICAgICAqICAgKDIsICdCbHVlJyk7XG4gICAgICogaW5zZXJ0IGludG9cbiAgICAgKiAgIHVzZXJzX3RlYW1zICh1c2VyX2lkLCB0ZWFtX2lkKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsIDEpLFxuICAgICAqICAgKDEsIDIpLFxuICAgICAqICAgKDIsIDIpO1xuICAgICAqIGluc2VydCBpbnRvXG4gICAgICogICBnYW1lcyAoaWQsIGhvbWVfdGVhbSwgYXdheV90ZWFtLCBuYW1lKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsIDEsIDIsICdHcmVlbiB2cyBCbHVlJyksXG4gICAgICogICAoMiwgMiwgMSwgJ0JsdWUgdnMgR3JlZW4nKTtcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgUXVlcnkgbmVzdGVkIGZvcmVpZ24gdGFibGVzIHRocm91Z2ggYSBqb2luIHRhYmxlXG4gICAgICogYGBganNvblxuICAgICAqICAge1xuICAgICAqICAgICBcImRhdGFcIjogW1xuICAgICAqICAgICAgIHtcbiAgICAgKiAgICAgICAgIFwiZ2FtZV9pZFwiOiAxLFxuICAgICAqICAgICAgICAgXCJhd2F5X3RlYW1cIjoge1xuICAgICAqICAgICAgICAgICBcInVzZXJzXCI6IFtcbiAgICAgKiAgICAgICAgICAgICB7XG4gICAgICogICAgICAgICAgICAgICBcImlkXCI6IDEsXG4gICAgICogICAgICAgICAgICAgICBcIm5hbWVcIjogXCJLaXJhblwiXG4gICAgICogICAgICAgICAgICAgfSxcbiAgICAgKiAgICAgICAgICAgICB7XG4gICAgICogICAgICAgICAgICAgICBcImlkXCI6IDIsXG4gICAgICogICAgICAgICAgICAgICBcIm5hbWVcIjogXCJFdmFuXCJcbiAgICAgKiAgICAgICAgICAgICB9XG4gICAgICogICAgICAgICAgIF1cbiAgICAgKiAgICAgICAgIH1cbiAgICAgKiAgICAgICB9LFxuICAgICAqICAgICAgIHtcbiAgICAgKiAgICAgICAgIFwiZ2FtZV9pZFwiOiAyLFxuICAgICAqICAgICAgICAgXCJhd2F5X3RlYW1cIjoge1xuICAgICAqICAgICAgICAgICBcInVzZXJzXCI6IFtcbiAgICAgKiAgICAgICAgICAgICB7XG4gICAgICogICAgICAgICAgICAgICBcImlkXCI6IDEsXG4gICAgICogICAgICAgICAgICAgICBcIm5hbWVcIjogXCJLaXJhblwiXG4gICAgICogICAgICAgICAgICAgfVxuICAgICAqICAgICAgICAgICBdXG4gICAgICogICAgICAgICB9XG4gICAgICogICAgICAgfVxuICAgICAqICAgICBdLFxuICAgICAqICAgICBcInN0YXR1c1wiOiAyMDAsXG4gICAgICogICAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICAgKiAgIH1cbiAgICAgKiAgIFxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBGaWx0ZXJpbmcgdGhyb3VnaCByZWZlcmVuY2VkIHRhYmxlc1xuICAgICAqIElmIHRoZSBmaWx0ZXIgb24gYSByZWZlcmVuY2VkIHRhYmxlJ3MgY29sdW1uIGlzIG5vdCBzYXRpc2ZpZWQsIHRoZSByZWZlcmVuY2VkXG4gICAgICogdGFibGUgcmV0dXJucyBgW11gIG9yIGBudWxsYCBidXQgdGhlIHBhcmVudCB0YWJsZSBpcyBub3QgZmlsdGVyZWQgb3V0LlxuICAgICAqIElmIHlvdSB3YW50IHRvIGZpbHRlciBvdXQgdGhlIHBhcmVudCB0YWJsZSByb3dzLCB1c2UgdGhlIGAhaW5uZXJgIGhpbnRcbiAgICAgKlxuICAgICAqIEBleGFtcGxlIEZpbHRlcmluZyB0aHJvdWdoIHJlZmVyZW5jZWQgdGFibGVzXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAqICAgLmZyb20oJ2luc3RydW1lbnRzJylcbiAgICAgKiAgIC5zZWxlY3QoJ25hbWUsIG9yY2hlc3RyYWxfc2VjdGlvbnMoKiknKVxuICAgICAqICAgLmVxKCdvcmNoZXN0cmFsX3NlY3Rpb25zLm5hbWUnLCAncGVyY3Vzc2lvbicpXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVNxbCBGaWx0ZXJpbmcgdGhyb3VnaCByZWZlcmVuY2VkIHRhYmxlc1xuICAgICAqIGBgYHNxbFxuICAgICAqIGNyZWF0ZSB0YWJsZVxuICAgICAqICAgb3JjaGVzdHJhbF9zZWN0aW9ucyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICAgKiBjcmVhdGUgdGFibGVcbiAgICAgKiAgIGluc3RydW1lbnRzIChcbiAgICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICAgKiAgICAgc2VjdGlvbl9pZCBpbnQ4IG5vdCBudWxsIHJlZmVyZW5jZXMgb3JjaGVzdHJhbF9zZWN0aW9ucyxcbiAgICAgKiAgICAgbmFtZSB0ZXh0XG4gICAgICogICApO1xuICAgICAqXG4gICAgICogaW5zZXJ0IGludG9cbiAgICAgKiAgIG9yY2hlc3RyYWxfc2VjdGlvbnMgKGlkLCBuYW1lKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsICdzdHJpbmdzJyksXG4gICAgICogICAoMiwgJ3dvb2R3aW5kcycpO1xuICAgICAqIGluc2VydCBpbnRvXG4gICAgICogICBpbnN0cnVtZW50cyAoaWQsIHNlY3Rpb25faWQsIG5hbWUpXG4gICAgICogdmFsdWVzXG4gICAgICogICAoMSwgMiwgJ2ZsdXRlJyksXG4gICAgICogICAoMiwgMSwgJ3Zpb2xpbicpO1xuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVSZXNwb25zZSBGaWx0ZXJpbmcgdGhyb3VnaCByZWZlcmVuY2VkIHRhYmxlc1xuICAgICAqIGBgYGpzb25cbiAgICAgKiB7XG4gICAgICogICBcImRhdGFcIjogW1xuICAgICAqICAgICB7XG4gICAgICogICAgICAgXCJuYW1lXCI6IFwiZmx1dGVcIixcbiAgICAgKiAgICAgICBcIm9yY2hlc3RyYWxfc2VjdGlvbnNcIjogbnVsbFxuICAgICAqICAgICB9LFxuICAgICAqICAgICB7XG4gICAgICogICAgICAgXCJuYW1lXCI6IFwidmlvbGluXCIsXG4gICAgICogICAgICAgXCJvcmNoZXN0cmFsX3NlY3Rpb25zXCI6IG51bGxcbiAgICAgKiAgICAgfVxuICAgICAqICAgXSxcbiAgICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICAgKiB9XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFF1ZXJ5aW5nIHJlZmVyZW5jZWQgdGFibGUgd2l0aCBjb3VudFxuICAgICAqIFlvdSBjYW4gZ2V0IHRoZSBudW1iZXIgb2Ygcm93cyBpbiBhIHJlbGF0ZWQgdGFibGUgYnkgdXNpbmcgdGhlXG4gICAgICogKipjb3VudCoqIHByb3BlcnR5LlxuICAgICAqXG4gICAgICogQGV4YW1wbGUgUXVlcnlpbmcgcmVmZXJlbmNlZCB0YWJsZSB3aXRoIGNvdW50XG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAqICAgLmZyb20oJ29yY2hlc3RyYWxfc2VjdGlvbnMnKVxuICAgICAqICAgLnNlbGVjdChgKiwgaW5zdHJ1bWVudHMoY291bnQpYClcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlU3FsIFF1ZXJ5aW5nIHJlZmVyZW5jZWQgdGFibGUgd2l0aCBjb3VudFxuICAgICAqIGBgYHNxbFxuICAgICAqIGNyZWF0ZSB0YWJsZSBvcmNoZXN0cmFsX3NlY3Rpb25zIChcbiAgICAgKiAgIFwiaWRcIiBcInV1aWRcIiBwcmltYXJ5IGtleSBkZWZhdWx0IFwiZXh0ZW5zaW9uc1wiLlwidXVpZF9nZW5lcmF0ZV92NFwiKCkgbm90IG51bGwsXG4gICAgICogICBcIm5hbWVcIiB0ZXh0XG4gICAgICogKTtcbiAgICAgKlxuICAgICAqIGNyZWF0ZSB0YWJsZSBjaGFyYWN0ZXJzIChcbiAgICAgKiAgIFwiaWRcIiBcInV1aWRcIiBwcmltYXJ5IGtleSBkZWZhdWx0IFwiZXh0ZW5zaW9uc1wiLlwidXVpZF9nZW5lcmF0ZV92NFwiKCkgbm90IG51bGwsXG4gICAgICogICBcIm5hbWVcIiB0ZXh0LFxuICAgICAqICAgXCJzZWN0aW9uX2lkXCIgXCJ1dWlkXCIgcmVmZXJlbmNlcyBwdWJsaWMub3JjaGVzdHJhbF9zZWN0aW9ucyBvbiBkZWxldGUgY2FzY2FkZVxuICAgICAqICk7XG4gICAgICpcbiAgICAgKiB3aXRoIHNlY3Rpb24gYXMgKFxuICAgICAqICAgaW5zZXJ0IGludG8gb3JjaGVzdHJhbF9zZWN0aW9ucyAobmFtZSlcbiAgICAgKiAgIHZhbHVlcyAoJ3N0cmluZ3MnKSByZXR1cm5pbmcgaWRcbiAgICAgKiApXG4gICAgICogaW5zZXJ0IGludG8gaW5zdHJ1bWVudHMgKG5hbWUsIHNlY3Rpb25faWQpIHZhbHVlc1xuICAgICAqICgndmlvbGluJywgKHNlbGVjdCBpZCBmcm9tIHNlY3Rpb24pKSxcbiAgICAgKiAoJ3Zpb2xhJywgKHNlbGVjdCBpZCBmcm9tIHNlY3Rpb24pKSxcbiAgICAgKiAoJ2NlbGxvJywgKHNlbGVjdCBpZCBmcm9tIHNlY3Rpb24pKSxcbiAgICAgKiAoJ2RvdWJsZSBiYXNzJywgKHNlbGVjdCBpZCBmcm9tIHNlY3Rpb24pKTtcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgUXVlcnlpbmcgcmVmZXJlbmNlZCB0YWJsZSB3aXRoIGNvdW50XG4gICAgICogYGBganNvblxuICAgICAqIFtcbiAgICAgKiAgIHtcbiAgICAgKiAgICAgXCJpZFwiOiBcIjY5MzY5NGU3LWQ5OTMtNDM2MC1hNmQ3LTYyOTRlMzI1ZDliNlwiLFxuICAgICAqICAgICBcIm5hbWVcIjogXCJzdHJpbmdzXCIsXG4gICAgICogICAgIFwiaW5zdHJ1bWVudHNcIjogW1xuICAgICAqICAgICAgIHtcbiAgICAgKiAgICAgICAgIFwiY291bnRcIjogNFxuICAgICAqICAgICAgIH1cbiAgICAgKiAgICAgXVxuICAgICAqICAgfVxuICAgICAqIF1cbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlRGVzY3JpcHRpb24gUXVlcnlpbmcgd2l0aCBjb3VudCBvcHRpb25cbiAgICAgKiBZb3UgY2FuIGdldCB0aGUgbnVtYmVyIG9mIHJvd3MgYnkgdXNpbmcgdGhlXG4gICAgICogW2NvdW50XSgvZG9jcy9yZWZlcmVuY2UvamF2YXNjcmlwdC9zZWxlY3QjcGFyYW1ldGVycykgb3B0aW9uLlxuICAgICAqXG4gICAgICogQGV4YW1wbGUgUXVlcnlpbmcgd2l0aCBjb3VudCBvcHRpb25cbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IHsgY291bnQsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAqICAgLmZyb20oJ2NoYXJhY3RlcnMnKVxuICAgICAqICAgLnNlbGVjdCgnKicsIHsgY291bnQ6ICdleGFjdCcsIGhlYWQ6IHRydWUgfSlcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlU3FsIFF1ZXJ5aW5nIHdpdGggY291bnQgb3B0aW9uXG4gICAgICogYGBgc3FsXG4gICAgICogY3JlYXRlIHRhYmxlXG4gICAgICogICBjaGFyYWN0ZXJzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgICAqXG4gICAgICogaW5zZXJ0IGludG9cbiAgICAgKiAgIGNoYXJhY3RlcnMgKGlkLCBuYW1lKVxuICAgICAqIHZhbHVlc1xuICAgICAqICAgKDEsICdMdWtlJyksXG4gICAgICogICAoMiwgJ0xlaWEnKSxcbiAgICAgKiAgICgzLCAnSGFuJyk7XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVJlc3BvbnNlIFF1ZXJ5aW5nIHdpdGggY291bnQgb3B0aW9uXG4gICAgICogYGBganNvblxuICAgICAqIHtcbiAgICAgKiAgIFwiY291bnRcIjogMyxcbiAgICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICAgKiB9XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFF1ZXJ5aW5nIEpTT04gZGF0YVxuICAgICAqIFlvdSBjYW4gc2VsZWN0IGFuZCBmaWx0ZXIgZGF0YSBpbnNpZGUgb2ZcbiAgICAgKiBbSlNPTl0oL2RvY3MvZ3VpZGVzL2RhdGFiYXNlL2pzb24pIGNvbHVtbnMuIFBvc3RncmVzIG9mZmVycyBzb21lXG4gICAgICogW29wZXJhdG9yc10oL2RvY3MvZ3VpZGVzL2RhdGFiYXNlL2pzb24jcXVlcnktdGhlLWpzb25iLWRhdGEpIGZvclxuICAgICAqIHF1ZXJ5aW5nIEpTT04gZGF0YS5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlIFF1ZXJ5aW5nIEpTT04gZGF0YVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgKiAgIC5mcm9tKCd1c2VycycpXG4gICAgICogICAuc2VsZWN0KGBcbiAgICAgKiAgICAgaWQsIG5hbWUsXG4gICAgICogICAgIGFkZHJlc3MtPmNpdHlcbiAgICAgKiAgIGApXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVNxbCBRdWVyeWluZyBKU09OIGRhdGFcbiAgICAgKiBgYGBzcWxcbiAgICAgKiBjcmVhdGUgdGFibGVcbiAgICAgKiAgIHVzZXJzIChcbiAgICAgKiAgICAgaWQgaW50OCBwcmltYXJ5IGtleSxcbiAgICAgKiAgICAgbmFtZSB0ZXh0LFxuICAgICAqICAgICBhZGRyZXNzIGpzb25iXG4gICAgICogICApO1xuICAgICAqXG4gICAgICogaW5zZXJ0IGludG9cbiAgICAgKiAgIHVzZXJzIChpZCwgbmFtZSwgYWRkcmVzcylcbiAgICAgKiB2YWx1ZXNcbiAgICAgKiAgICgxLCAnRnJvZG8nLCAne1wiY2l0eVwiOlwiSG9iYml0b25cIn0nKTtcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgUXVlcnlpbmcgSlNPTiBkYXRhXG4gICAgICogYGBganNvblxuICAgICAqIHtcbiAgICAgKiAgIFwiZGF0YVwiOiBbXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAgICogICAgICAgXCJuYW1lXCI6IFwiRnJvZG9cIixcbiAgICAgKiAgICAgICBcImNpdHlcIjogXCJIb2JiaXRvblwiXG4gICAgICogICAgIH1cbiAgICAgKiAgIF0sXG4gICAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAgICogfVxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBRdWVyeWluZyByZWZlcmVuY2VkIHRhYmxlIHdpdGggaW5uZXIgam9pblxuICAgICAqIElmIHlvdSBkb24ndCB3YW50IHRvIHJldHVybiB0aGUgcmVmZXJlbmNlZCB0YWJsZSBjb250ZW50cywgeW91IGNhbiBsZWF2ZSB0aGUgcGFyZW50aGVzaXMgZW1wdHkuXG4gICAgICogTGlrZSBgLnNlbGVjdCgnbmFtZSwgb3JjaGVzdHJhbF9zZWN0aW9ucyFpbm5lcigpJylgLlxuICAgICAqXG4gICAgICogQGV4YW1wbGUgUXVlcnlpbmcgcmVmZXJlbmNlZCB0YWJsZSB3aXRoIGlubmVyIGpvaW5cbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICogICAuZnJvbSgnaW5zdHJ1bWVudHMnKVxuICAgICAqICAgLnNlbGVjdCgnbmFtZSwgb3JjaGVzdHJhbF9zZWN0aW9ucyFpbm5lcihuYW1lKScpXG4gICAgICogICAuZXEoJ29yY2hlc3RyYWxfc2VjdGlvbnMubmFtZScsICd3b29kd2luZHMnKVxuICAgICAqICAgLmxpbWl0KDEpXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVNxbCBRdWVyeWluZyByZWZlcmVuY2VkIHRhYmxlIHdpdGggaW5uZXIgam9pblxuICAgICAqIGBgYHNxbFxuICAgICAqIGNyZWF0ZSB0YWJsZSBvcmNoZXN0cmFsX3NlY3Rpb25zIChcbiAgICAgKiAgIFwiaWRcIiBcInV1aWRcIiBwcmltYXJ5IGtleSBkZWZhdWx0IFwiZXh0ZW5zaW9uc1wiLlwidXVpZF9nZW5lcmF0ZV92NFwiKCkgbm90IG51bGwsXG4gICAgICogICBcIm5hbWVcIiB0ZXh0XG4gICAgICogKTtcbiAgICAgKlxuICAgICAqIGNyZWF0ZSB0YWJsZSBpbnN0cnVtZW50cyAoXG4gICAgICogICBcImlkXCIgXCJ1dWlkXCIgcHJpbWFyeSBrZXkgZGVmYXVsdCBcImV4dGVuc2lvbnNcIi5cInV1aWRfZ2VuZXJhdGVfdjRcIigpIG5vdCBudWxsLFxuICAgICAqICAgXCJuYW1lXCIgdGV4dCxcbiAgICAgKiAgIFwic2VjdGlvbl9pZFwiIFwidXVpZFwiIHJlZmVyZW5jZXMgcHVibGljLm9yY2hlc3RyYWxfc2VjdGlvbnMgb24gZGVsZXRlIGNhc2NhZGVcbiAgICAgKiApO1xuICAgICAqXG4gICAgICogd2l0aCBzZWN0aW9uIGFzIChcbiAgICAgKiAgIGluc2VydCBpbnRvIG9yY2hlc3RyYWxfc2VjdGlvbnMgKG5hbWUpXG4gICAgICogICB2YWx1ZXMgKCd3b29kd2luZHMnKSByZXR1cm5pbmcgaWRcbiAgICAgKiApXG4gICAgICogaW5zZXJ0IGludG8gaW5zdHJ1bWVudHMgKG5hbWUsIHNlY3Rpb25faWQpIHZhbHVlc1xuICAgICAqICgnZmx1dGUnLCAoc2VsZWN0IGlkIGZyb20gc2VjdGlvbikpLFxuICAgICAqICgnY2xhcmluZXQnLCAoc2VsZWN0IGlkIGZyb20gc2VjdGlvbikpLFxuICAgICAqICgnYmFzc29vbicsIChzZWxlY3QgaWQgZnJvbSBzZWN0aW9uKSksXG4gICAgICogKCdwaWNjb2xvJywgKHNlbGVjdCBpZCBmcm9tIHNlY3Rpb24pKTtcbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEBleGFtcGxlUmVzcG9uc2UgUXVlcnlpbmcgcmVmZXJlbmNlZCB0YWJsZSB3aXRoIGlubmVyIGpvaW5cbiAgICAgKiBgYGBqc29uXG4gICAgICoge1xuICAgICAqICAgXCJkYXRhXCI6IFtcbiAgICAgKiAgICAge1xuICAgICAqICAgICAgIFwibmFtZVwiOiBcImZsdXRlXCIsXG4gICAgICogICAgICAgXCJvcmNoZXN0cmFsX3NlY3Rpb25zXCI6IHtcIm5hbWVcIjogXCJ3b29kd2luZHNcIn1cbiAgICAgKiAgICAgfVxuICAgICAqICAgXSxcbiAgICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICAgKiB9XG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFN3aXRjaGluZyBzY2hlbWFzIHBlciBxdWVyeVxuICAgICAqIEluIGFkZGl0aW9uIHRvIHNldHRpbmcgdGhlIHNjaGVtYSBkdXJpbmcgaW5pdGlhbGl6YXRpb24sIHlvdSBjYW4gYWxzbyBzd2l0Y2ggc2NoZW1hcyBvbiBhIHBlci1xdWVyeSBiYXNpcy5cbiAgICAgKiBNYWtlIHN1cmUgeW91J3ZlIHNldCB1cCB5b3VyIFtkYXRhYmFzZSBwcml2aWxlZ2VzIGFuZCBBUEkgc2V0dGluZ3NdKC9kb2NzL2d1aWRlcy9hcGkvdXNpbmctY3VzdG9tLXNjaGVtYXMpLlxuICAgICAqXG4gICAgICogQGV4YW1wbGUgU3dpdGNoaW5nIHNjaGVtYXMgcGVyIHF1ZXJ5XG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAqICAgLnNjaGVtYSgnbXlzY2hlbWEnKVxuICAgICAqICAgLmZyb20oJ215dGFibGUnKVxuICAgICAqICAgLnNlbGVjdCgpXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVNxbCBTd2l0Y2hpbmcgc2NoZW1hcyBwZXIgcXVlcnlcbiAgICAgKiBgYGBzcWxcbiAgICAgKiBjcmVhdGUgc2NoZW1hIG15c2NoZW1hO1xuICAgICAqXG4gICAgICogY3JlYXRlIHRhYmxlIG15c2NoZW1hLm15dGFibGUgKFxuICAgICAqICAgaWQgdXVpZCBwcmltYXJ5IGtleSBkZWZhdWx0IGdlbl9yYW5kb21fdXVpZCgpLFxuICAgICAqICAgZGF0YSB0ZXh0XG4gICAgICogKTtcbiAgICAgKlxuICAgICAqIGluc2VydCBpbnRvIG15c2NoZW1hLm15dGFibGUgKGRhdGEpIHZhbHVlcyAoJ215ZGF0YScpO1xuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQGV4YW1wbGVSZXNwb25zZSBTd2l0Y2hpbmcgc2NoZW1hcyBwZXIgcXVlcnlcbiAgICAgKiBgYGBqc29uXG4gICAgICoge1xuICAgICAqICAgXCJkYXRhXCI6IFtcbiAgICAgKiAgICAge1xuICAgICAqICAgICAgIFwiaWRcIjogXCI0MTYyZTAwOC0yN2IwLTRjMGYtODJkYy1jY2FlZWU5YTYyNGRcIixcbiAgICAgKiAgICAgICBcImRhdGFcIjogXCJteWRhdGFcIlxuICAgICAqICAgICB9XG4gICAgICogICBdLFxuICAgICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgICAqL1xuICBzZWxlY3Q8XG4gICAgUXVlcnkgZXh0ZW5kcyBzdHJpbmcgPSAnKicsXG4gICAgUmVzdWx0T25lID0gR2V0UmVzdWx0PFxuICAgICAgU2NoZW1hLFxuICAgICAgUmVsYXRpb25bJ1JvdyddLFxuICAgICAgUmVsYXRpb25OYW1lLFxuICAgICAgUmVsYXRpb25zaGlwcyxcbiAgICAgIFF1ZXJ5LFxuICAgICAgQ2xpZW50T3B0aW9uc1xuICAgID4sXG4gID4oXG4gICAgY29sdW1ucz86IFF1ZXJ5LFxuICAgIG9wdGlvbnM/OiB7XG4gICAgICBoZWFkPzogYm9vbGVhblxuICAgICAgY291bnQ/OiAnZXhhY3QnIHwgJ3BsYW5uZWQnIHwgJ2VzdGltYXRlZCcgfCAoc3RyaW5nICYge30pXG4gICAgfVxuICApOiBQb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyPFxuICAgIENsaWVudE9wdGlvbnMsXG4gICAgU2NoZW1hLFxuICAgIFJlbGF0aW9uWydSb3cnXSxcbiAgICBSZXN1bHRPbmVbXSxcbiAgICBSZWxhdGlvbk5hbWUsXG4gICAgUmVsYXRpb25zaGlwcyxcbiAgICAnR0VUJ1xuICA+IHtcbiAgICBjb25zdCB7IGhlYWQgPSBmYWxzZSwgY291bnQgfSA9IG9wdGlvbnMgPz8ge31cblxuICAgIGNvbnN0IG1ldGhvZCA9IGhlYWQgPyAnSEVBRCcgOiAnR0VUJ1xuICAgIC8vIFJlbW92ZSB3aGl0ZXNwYWNlcyBleGNlcHQgd2hlbiBxdW90ZWRcbiAgICBsZXQgcXVvdGVkID0gZmFsc2VcbiAgICBjb25zdCBjbGVhbmVkQ29sdW1ucyA9IChjb2x1bW5zID8/ICcqJylcbiAgICAgIC5zcGxpdCgnJylcbiAgICAgIC5tYXAoKGMpID0+IHtcbiAgICAgICAgaWYgKC9cXHMvLnRlc3QoYykgJiYgIXF1b3RlZCkge1xuICAgICAgICAgIHJldHVybiAnJ1xuICAgICAgICB9XG4gICAgICAgIGlmIChjID09PSAnXCInKSB7XG4gICAgICAgICAgcXVvdGVkID0gIXF1b3RlZFxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjXG4gICAgICB9KVxuICAgICAgLmpvaW4oJycpXG5cbiAgICBjb25zdCB7IHVybCwgaGVhZGVycyB9ID0gdGhpcy5jbG9uZVJlcXVlc3RTdGF0ZSgpXG4gICAgdXJsLnNlYXJjaFBhcmFtcy5zZXQoJ3NlbGVjdCcsIGNsZWFuZWRDb2x1bW5zKVxuXG4gICAgaWYgKGNvdW50KSB7XG4gICAgICBoZWFkZXJzLmFwcGVuZCgnUHJlZmVyJywgYGNvdW50PSR7Y291bnR9YClcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFBvc3RncmVzdEZpbHRlckJ1aWxkZXIoe1xuICAgICAgbWV0aG9kLFxuICAgICAgdXJsLFxuICAgICAgaGVhZGVycyxcbiAgICAgIHNjaGVtYTogdGhpcy5zY2hlbWEsXG4gICAgICBmZXRjaDogdGhpcy5mZXRjaCxcbiAgICAgIHVybExlbmd0aExpbWl0OiB0aGlzLnVybExlbmd0aExpbWl0LFxuICAgICAgcmV0cnk6IHRoaXMucmV0cnksXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBQZXJmb3JtIGFuIElOU0VSVCBpbnRvIHRoZSB0YWJsZSBvciB2aWV3LlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCBpbnNlcnRlZCByb3dzIGFyZSBub3QgcmV0dXJuZWQuIFRvIHJldHVybiBpdCwgY2hhaW4gdGhlIGNhbGxcbiAgICogd2l0aCBgLnNlbGVjdCgpYC5cbiAgICpcbiAgICogQHBhcmFtIHZhbHVlcyAtIFRoZSB2YWx1ZXMgdG8gaW5zZXJ0LiBQYXNzIGFuIG9iamVjdCB0byBpbnNlcnQgYSBzaW5nbGUgcm93XG4gICAqIG9yIGFuIGFycmF5IHRvIGluc2VydCBtdWx0aXBsZSByb3dzLlxuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIE5hbWVkIHBhcmFtZXRlcnNcbiAgICpcbiAgICogQHBhcmFtIG9wdGlvbnMuY291bnQgLSBDb3VudCBhbGdvcml0aG0gdG8gdXNlIHRvIGNvdW50IGluc2VydGVkIHJvd3MuXG4gICAqXG4gICAqIGBcImV4YWN0XCJgOiBFeGFjdCBidXQgc2xvdyBjb3VudCBhbGdvcml0aG0uIFBlcmZvcm1zIGEgYENPVU5UKCopYCB1bmRlciB0aGVcbiAgICogaG9vZC5cbiAgICpcbiAgICogYFwicGxhbm5lZFwiYDogQXBwcm94aW1hdGVkIGJ1dCBmYXN0IGNvdW50IGFsZ29yaXRobS4gVXNlcyB0aGUgUG9zdGdyZXNcbiAgICogc3RhdGlzdGljcyB1bmRlciB0aGUgaG9vZC5cbiAgICpcbiAgICogYFwiZXN0aW1hdGVkXCJgOiBVc2VzIGV4YWN0IGNvdW50IGZvciBsb3cgbnVtYmVycyBhbmQgcGxhbm5lZCBjb3VudCBmb3IgaGlnaFxuICAgKiBudW1iZXJzLlxuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5kZWZhdWx0VG9OdWxsIC0gTWFrZSBtaXNzaW5nIGZpZWxkcyBkZWZhdWx0IHRvIGBudWxsYC5cbiAgICogT3RoZXJ3aXNlLCB1c2UgdGhlIGRlZmF1bHQgdmFsdWUgZm9yIHRoZSBjb2x1bW4uIE9ubHkgYXBwbGllcyBmb3IgYnVsa1xuICAgKiBpbnNlcnRzLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICpcbiAgICogQGV4YW1wbGUgQ3JlYXRlIGEgcmVjb3JkXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ2NvdW50cmllcycpXG4gICAqICAgLmluc2VydCh7IGlkOiAxLCBuYW1lOiAnTW9yZG9yJyB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgQ3JlYXRlIGEgcmVjb3JkXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjb3VudHJpZXMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIENyZWF0ZSBhIHJlY29yZFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcInN0YXR1c1wiOiAyMDEsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiQ3JlYXRlZFwiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gSGFuZGxpbmcgZXJyb3JzXG4gICAqIGBlcnJvci5oaW50YCBmcm9tIFBvc3RncmVzIG9mdGVuIGNvbnRhaW5zIHRoZSBhY3Rpb25hYmxlIGZpeCAoZS5nLiBgXCJHcmFudCB0aGUgcmVxdWlyZWQgcHJpdmlsZWdlcyB0byB0aGUgY3VycmVudCByb2xlIHdpdGg6IEdSQU5UIElOU0VSVCBPTiBwdWJsaWMuY291bnRyaWVzIFRPIGFub247XCJgIGZvciBhIGA0MjUwMWAgcGVybWlzc2lvbi1kZW5pZWQgZXJyb3IpLiBMb2cgdGhlIGZ1bGwgYGVycm9yYCBvYmplY3Qgc28gaXQgaXNuJ3QgaGlkZGVuIGJlaGluZCBgZXJyb3IubWVzc2FnZWAuXG4gICAqXG4gICAqIEBleGFtcGxlIEhhbmRsaW5nIGVycm9yc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdjb3VudHJpZXMnKS5pbnNlcnQoeyBpZDogMSwgbmFtZTogJ01vcmRvcicgfSlcbiAgICogaWYgKGVycm9yKSBjb25zb2xlLmVycm9yKGVycm9yKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgQ3JlYXRlIGEgcmVjb3JkIGFuZCByZXR1cm4gaXRcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY291bnRyaWVzJylcbiAgICogICAuaW5zZXJ0KHsgaWQ6IDEsIG5hbWU6ICdNb3Jkb3InIH0pXG4gICAqICAgLnNlbGVjdCgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBDcmVhdGUgYSByZWNvcmQgYW5kIHJldHVybiBpdFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY291bnRyaWVzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBDcmVhdGUgYSByZWNvcmQgYW5kIHJldHVybiBpdFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAqICAgICAgIFwibmFtZVwiOiBcIk1vcmRvclwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDEsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiQ3JlYXRlZFwiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gQnVsayBjcmVhdGVcbiAgICogQSBidWxrIGNyZWF0ZSBvcGVyYXRpb24gaXMgaGFuZGxlZCBpbiBhIHNpbmdsZSB0cmFuc2FjdGlvbi5cbiAgICogSWYgYW55IG9mIHRoZSBpbnNlcnRzIGZhaWwsIG5vbmUgb2YgdGhlIHJvd3MgYXJlIGluc2VydGVkLlxuICAgKlxuICAgKiBAZXhhbXBsZSBCdWxrIGNyZWF0ZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjb3VudHJpZXMnKVxuICAgKiAgIC5pbnNlcnQoW1xuICAgKiAgICAgeyBpZDogMSwgbmFtZTogJ01vcmRvcicgfSxcbiAgICogICAgIHsgaWQ6IDEsIG5hbWU6ICdUaGUgU2hpcmUnIH0sXG4gICAqICAgXSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIEJ1bGsgY3JlYXRlXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjb3VudHJpZXMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIEJ1bGsgY3JlYXRlXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZXJyb3JcIjoge1xuICAgKiAgICAgXCJjb2RlXCI6IFwiMjM1MDVcIixcbiAgICogICAgIFwiZGV0YWlsc1wiOiBcIktleSAoaWQpPSgxKSBhbHJlYWR5IGV4aXN0cy5cIixcbiAgICogICAgIFwiaGludFwiOiBudWxsLFxuICAgKiAgICAgXCJtZXNzYWdlXCI6IFwiZHVwbGljYXRlIGtleSB2YWx1ZSB2aW9sYXRlcyB1bmlxdWUgY29uc3RyYWludCBcXFwiY291bnRyaWVzX3BrZXlcXFwiXCJcbiAgICogICB9LFxuICAgKiAgIFwic3RhdHVzXCI6IDQwOSxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJDb25mbGljdFwiXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBpbnNlcnQ8Um93IGV4dGVuZHMgUmVsYXRpb24gZXh0ZW5kcyB7IEluc2VydDogdW5rbm93biB9ID8gUmVsYXRpb25bJ0luc2VydCddIDogbmV2ZXI+KFxuICAgIHZhbHVlczpcbiAgICAgIHwgUmVqZWN0RXhjZXNzUHJvcGVydGllczxcbiAgICAgICAgICBSZWxhdGlvbiBleHRlbmRzIHsgSW5zZXJ0OiB1bmtub3duIH0gPyBSZWxhdGlvblsnSW5zZXJ0J10gOiBuZXZlcixcbiAgICAgICAgICBSb3dcbiAgICAgICAgPlxuICAgICAgfCBSZWplY3RFeGNlc3NQcm9wZXJ0aWVzPFxuICAgICAgICAgIFJlbGF0aW9uIGV4dGVuZHMgeyBJbnNlcnQ6IHVua25vd24gfSA/IFJlbGF0aW9uWydJbnNlcnQnXSA6IG5ldmVyLFxuICAgICAgICAgIFJvd1xuICAgICAgICA+W10sXG4gICAge1xuICAgICAgY291bnQsXG4gICAgICBkZWZhdWx0VG9OdWxsID0gdHJ1ZSxcbiAgICB9OiB7XG4gICAgICBjb3VudD86ICdleGFjdCcgfCAncGxhbm5lZCcgfCAnZXN0aW1hdGVkJyB8IChzdHJpbmcgJiB7fSlcbiAgICAgIGRlZmF1bHRUb051bGw/OiBib29sZWFuXG4gICAgfSA9IHt9XG4gICk6IFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBTY2hlbWEsXG4gICAgUmVsYXRpb25bJ1JvdyddLFxuICAgIG51bGwsXG4gICAgUmVsYXRpb25OYW1lLFxuICAgIFJlbGF0aW9uc2hpcHMsXG4gICAgJ1BPU1QnXG4gID4ge1xuICAgIGNvbnN0IG1ldGhvZCA9ICdQT1NUJ1xuICAgIGNvbnN0IHsgdXJsLCBoZWFkZXJzIH0gPSB0aGlzLmNsb25lUmVxdWVzdFN0YXRlKClcblxuICAgIGlmIChjb3VudCkge1xuICAgICAgaGVhZGVycy5hcHBlbmQoJ1ByZWZlcicsIGBjb3VudD0ke2NvdW50fWApXG4gICAgfVxuICAgIGlmICghZGVmYXVsdFRvTnVsbCkge1xuICAgICAgaGVhZGVycy5hcHBlbmQoJ1ByZWZlcicsIGBtaXNzaW5nPWRlZmF1bHRgKVxuICAgIH1cblxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlcykpIHtcbiAgICAgIGNvbnN0IGNvbHVtbnMgPSB2YWx1ZXMucmVkdWNlKChhY2MsIHgpID0+IGFjYy5jb25jYXQoT2JqZWN0LmtleXMoeCkpLCBbXSBhcyBzdHJpbmdbXSlcbiAgICAgIGlmIChjb2x1bW5zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc3QgdW5pcXVlQ29sdW1ucyA9IFsuLi5uZXcgU2V0KGNvbHVtbnMpXS5tYXAoKGNvbHVtbikgPT4gYFwiJHtjb2x1bW59XCJgKVxuICAgICAgICB1cmwuc2VhcmNoUGFyYW1zLnNldCgnY29sdW1ucycsIHVuaXF1ZUNvbHVtbnMuam9pbignLCcpKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgUG9zdGdyZXN0RmlsdGVyQnVpbGRlcih7XG4gICAgICBtZXRob2QsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzLFxuICAgICAgc2NoZW1hOiB0aGlzLnNjaGVtYSxcbiAgICAgIGJvZHk6IHZhbHVlcyxcbiAgICAgIGZldGNoOiB0aGlzLmZldGNoID8/IGZldGNoLFxuICAgICAgdXJsTGVuZ3RoTGltaXQ6IHRoaXMudXJsTGVuZ3RoTGltaXQsXG4gICAgICByZXRyeTogdGhpcy5yZXRyeSxcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIFBlcmZvcm0gYW4gVVBTRVJUIG9uIHRoZSB0YWJsZSBvciB2aWV3LiBEZXBlbmRpbmcgb24gdGhlIGNvbHVtbihzKSBwYXNzZWRcbiAgICogdG8gYG9uQ29uZmxpY3RgLCBgLnVwc2VydCgpYCBhbGxvd3MgeW91IHRvIHBlcmZvcm0gdGhlIGVxdWl2YWxlbnQgb2ZcbiAgICogYC5pbnNlcnQoKWAgaWYgYSByb3cgd2l0aCB0aGUgY29ycmVzcG9uZGluZyBgb25Db25mbGljdGAgY29sdW1ucyBkb2Vzbid0XG4gICAqIGV4aXN0LCBvciBpZiBpdCBkb2VzIGV4aXN0LCBwZXJmb3JtIGFuIGFsdGVybmF0aXZlIGFjdGlvbiBkZXBlbmRpbmcgb25cbiAgICogYGlnbm9yZUR1cGxpY2F0ZXNgLlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCB1cHNlcnRlZCByb3dzIGFyZSBub3QgcmV0dXJuZWQuIFRvIHJldHVybiBpdCwgY2hhaW4gdGhlIGNhbGxcbiAgICogd2l0aCBgLnNlbGVjdCgpYC5cbiAgICpcbiAgICogQHBhcmFtIHZhbHVlcyAtIFRoZSB2YWx1ZXMgdG8gdXBzZXJ0IHdpdGguIFBhc3MgYW4gb2JqZWN0IHRvIHVwc2VydCBhXG4gICAqIHNpbmdsZSByb3cgb3IgYW4gYXJyYXkgdG8gdXBzZXJ0IG11bHRpcGxlIHJvd3MuXG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5vbkNvbmZsaWN0IC0gQ29tbWEtc2VwYXJhdGVkIFVOSVFVRSBjb2x1bW4ocykgdG8gc3BlY2lmeSBob3dcbiAgICogZHVwbGljYXRlIHJvd3MgYXJlIGRldGVybWluZWQuIFR3byByb3dzIGFyZSBkdXBsaWNhdGVzIGlmIGFsbCB0aGVcbiAgICogYG9uQ29uZmxpY3RgIGNvbHVtbnMgYXJlIGVxdWFsLlxuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5pZ25vcmVEdXBsaWNhdGVzIC0gSWYgYHRydWVgLCBkdXBsaWNhdGUgcm93cyBhcmUgaWdub3JlZC4gSWZcbiAgICogYGZhbHNlYCwgZHVwbGljYXRlIHJvd3MgYXJlIG1lcmdlZCB3aXRoIGV4aXN0aW5nIHJvd3MuXG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zLmNvdW50IC0gQ291bnQgYWxnb3JpdGhtIHRvIHVzZSB0byBjb3VudCB1cHNlcnRlZCByb3dzLlxuICAgKlxuICAgKiBgXCJleGFjdFwiYDogRXhhY3QgYnV0IHNsb3cgY291bnQgYWxnb3JpdGhtLiBQZXJmb3JtcyBhIGBDT1VOVCgqKWAgdW5kZXIgdGhlXG4gICAqIGhvb2QuXG4gICAqXG4gICAqIGBcInBsYW5uZWRcImA6IEFwcHJveGltYXRlZCBidXQgZmFzdCBjb3VudCBhbGdvcml0aG0uIFVzZXMgdGhlIFBvc3RncmVzXG4gICAqIHN0YXRpc3RpY3MgdW5kZXIgdGhlIGhvb2QuXG4gICAqXG4gICAqIGBcImVzdGltYXRlZFwiYDogVXNlcyBleGFjdCBjb3VudCBmb3IgbG93IG51bWJlcnMgYW5kIHBsYW5uZWQgY291bnQgZm9yIGhpZ2hcbiAgICogbnVtYmVycy5cbiAgICpcbiAgICogQHBhcmFtIG9wdGlvbnMuZGVmYXVsdFRvTnVsbCAtIE1ha2UgbWlzc2luZyBmaWVsZHMgZGVmYXVsdCB0byBgbnVsbGAuXG4gICAqIE90aGVyd2lzZSwgdXNlIHRoZSBkZWZhdWx0IHZhbHVlIGZvciB0aGUgY29sdW1uLiBUaGlzIG9ubHkgYXBwbGllcyB3aGVuXG4gICAqIGluc2VydGluZyBuZXcgcm93cywgbm90IHdoZW4gbWVyZ2luZyB3aXRoIGV4aXN0aW5nIHJvd3MgdW5kZXJcbiAgICogYGlnbm9yZUR1cGxpY2F0ZXM6IGZhbHNlYC4gVGhpcyBhbHNvIG9ubHkgYXBwbGllcyB3aGVuIGRvaW5nIGJ1bGsgdXBzZXJ0cy5cbiAgICpcbiAgICogQGV4YW1wbGUgVXBzZXJ0IGEgc2luZ2xlIHJvdyB1c2luZyBhIHVuaXF1ZSBrZXlcbiAgICogYGBgdHNcbiAgICogLy8gVXBzZXJ0aW5nIGEgc2luZ2xlIHJvdywgb3ZlcndyaXRpbmcgYmFzZWQgb24gdGhlICd1c2VybmFtZScgdW5pcXVlIGNvbHVtblxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCd1c2VycycpXG4gICAqICAgLnVwc2VydCh7IHVzZXJuYW1lOiAnc3VwYWJvdCcgfSwgeyBvbkNvbmZsaWN0OiAndXNlcm5hbWUnIH0pXG4gICAqXG4gICAqIC8vIEV4YW1wbGUgcmVzcG9uc2U6XG4gICAqIC8vIHtcbiAgICogLy8gICBkYXRhOiBbXG4gICAqIC8vICAgICB7IGlkOiA0LCBtZXNzYWdlOiAnYmFyJywgdXNlcm5hbWU6ICdzdXBhYm90JyB9XG4gICAqIC8vICAgXSxcbiAgICogLy8gICBlcnJvcjogbnVsbFxuICAgKiAvLyB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBVcHNlcnQgd2l0aCBjb25mbGljdCByZXNvbHV0aW9uIGFuZCBleGFjdCByb3cgY291bnRpbmdcbiAgICogYGBgdHNcbiAgICogLy8gVXBzZXJ0aW5nIGFuZCByZXR1cm5pbmcgZXhhY3QgY291bnRcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciwgY291bnQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ3VzZXJzJylcbiAgICogICAudXBzZXJ0KFxuICAgKiAgICAge1xuICAgKiAgICAgICBpZDogMyxcbiAgICogICAgICAgbWVzc2FnZTogJ2ZvbycsXG4gICAqICAgICAgIHVzZXJuYW1lOiAnc3VwYWJvdCdcbiAgICogICAgIH0sXG4gICAqICAgICB7XG4gICAqICAgICAgIG9uQ29uZmxpY3Q6ICd1c2VybmFtZScsXG4gICAqICAgICAgIGNvdW50OiAnZXhhY3QnXG4gICAqICAgICB9XG4gICAqICAgKVxuICAgKlxuICAgKiAvLyBFeGFtcGxlIHJlc3BvbnNlOlxuICAgKiAvLyB7XG4gICAqIC8vICAgZGF0YTogW1xuICAgKiAvLyAgICAge1xuICAgKiAvLyAgICAgICBpZDogNDIsXG4gICAqIC8vICAgICAgIGhhbmRsZTogXCJzYW9pcnNlXCIsXG4gICAqIC8vICAgICAgIGRpc3BsYXlfbmFtZTogXCJTYW9pcnNlXCJcbiAgICogLy8gICAgIH1cbiAgICogLy8gICBdLFxuICAgKiAvLyAgIGNvdW50OiAxLFxuICAgKiAvLyAgIGVycm9yOiBudWxsXG4gICAqIC8vIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFByaW1hcnkga2V5cyBtdXN0IGJlIGluY2x1ZGVkIGluIGB2YWx1ZXNgIHRvIHVzZSB1cHNlcnQuXG4gICAqXG4gICAqIEBleGFtcGxlIFVwc2VydCB5b3VyIGRhdGFcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnaW5zdHJ1bWVudHMnKVxuICAgKiAgIC51cHNlcnQoeyBpZDogMSwgbmFtZTogJ3BpYW5vJyB9KVxuICAgKiAgIC5zZWxlY3QoKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgVXBzZXJ0IHlvdXIgZGF0YVxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgaW5zdHJ1bWVudHMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgaW5zdHJ1bWVudHMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ2hhcnBzaWNob3JkJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFVwc2VydCB5b3VyIGRhdGFcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJwaWFub1wiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDEsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiQ3JlYXRlZFwiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gSGFuZGxpbmcgZXJyb3JzXG4gICAqIGBlcnJvci5oaW50YCBmcm9tIFBvc3RncmVzIG9mdGVuIGNvbnRhaW5zIHRoZSBhY3Rpb25hYmxlIGZpeCAoZS5nLiBgXCJHcmFudCB0aGUgcmVxdWlyZWQgcHJpdmlsZWdlcyB0byB0aGUgY3VycmVudCByb2xlIHdpdGg6IEdSQU5UIElOU0VSVCwgVVBEQVRFIE9OIHB1YmxpYy5pbnN0cnVtZW50cyBUTyBhbm9uO1wiYCBmb3IgYSBgNDI1MDFgIHBlcm1pc3Npb24tZGVuaWVkIGVycm9yKS4gTG9nIHRoZSBmdWxsIGBlcnJvcmAgb2JqZWN0IHNvIGl0IGlzbid0IGhpZGRlbiBiZWhpbmQgYGVycm9yLm1lc3NhZ2VgLlxuICAgKlxuICAgKiBAZXhhbXBsZSBIYW5kbGluZyBlcnJvcnNcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgnaW5zdHJ1bWVudHMnKS51cHNlcnQoeyBpZDogMSwgbmFtZTogJ3BpYW5vJyB9KS5zZWxlY3QoKVxuICAgKiBpZiAoZXJyb3IpIGNvbnNvbGUuZXJyb3IoZXJyb3IpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBCdWxrIFVwc2VydCB5b3VyIGRhdGFcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnaW5zdHJ1bWVudHMnKVxuICAgKiAgIC51cHNlcnQoW1xuICAgKiAgICAgeyBpZDogMSwgbmFtZTogJ3BpYW5vJyB9LFxuICAgKiAgICAgeyBpZDogMiwgbmFtZTogJ2hhcnAnIH0sXG4gICAqICAgXSlcbiAgICogICAuc2VsZWN0KClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIEJ1bGsgVXBzZXJ0IHlvdXIgZGF0YVxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgaW5zdHJ1bWVudHMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgaW5zdHJ1bWVudHMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ2hhcnBzaWNob3JkJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIEJ1bGsgVXBzZXJ0IHlvdXIgZGF0YVxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImlkXCI6IDEsXG4gICAqICAgICAgIFwibmFtZVwiOiBcInBpYW5vXCJcbiAgICogICAgIH0sXG4gICAqICAgICB7XG4gICAqICAgICAgIFwiaWRcIjogMixcbiAgICogICAgICAgXCJuYW1lXCI6IFwiaGFycFwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDEsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiQ3JlYXRlZFwiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gVXBzZXJ0aW5nIGludG8gdGFibGVzIHdpdGggY29uc3RyYWludHNcbiAgICogSW4gdGhlIGZvbGxvd2luZyBxdWVyeSwgYHVwc2VydCgpYCBpbXBsaWNpdGx5IHVzZXMgdGhlIGBpZGBcbiAgICogKHByaW1hcnkga2V5KSBjb2x1bW4gdG8gZGV0ZXJtaW5lIGNvbmZsaWN0cy4gSWYgdGhlcmUgaXMgbm8gZXhpc3RpbmdcbiAgICogcm93IHdpdGggdGhlIHNhbWUgYGlkYCwgYHVwc2VydCgpYCBpbnNlcnRzIGEgbmV3IHJvdywgd2hpY2hcbiAgICogd2lsbCBmYWlsIGluIHRoaXMgY2FzZSBhcyB0aGVyZSBpcyBhbHJlYWR5IGEgcm93IHdpdGggYGhhbmRsZWAgYFwic2FvaXJzZVwiYC5cbiAgICogVXNpbmcgdGhlIGBvbkNvbmZsaWN0YCBvcHRpb24sIHlvdSBjYW4gaW5zdHJ1Y3QgYHVwc2VydCgpYCB0byB1c2VcbiAgICogYW5vdGhlciBjb2x1bW4gd2l0aCBhIHVuaXF1ZSBjb25zdHJhaW50IHRvIGRldGVybWluZSBjb25mbGljdHMuXG4gICAqXG4gICAqIEBleGFtcGxlIFVwc2VydGluZyBpbnRvIHRhYmxlcyB3aXRoIGNvbnN0cmFpbnRzXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLmZyb20oJ3VzZXJzJylcbiAgICogICAudXBzZXJ0KHsgaWQ6IDQyLCBoYW5kbGU6ICdzYW9pcnNlJywgZGlzcGxheV9uYW1lOiAnU2FvaXJzZScgfSlcbiAgICogICAuc2VsZWN0KClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFVwc2VydGluZyBpbnRvIHRhYmxlcyB3aXRoIGNvbnN0cmFpbnRzXG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICB1c2VycyAoXG4gICAqICAgICBpZCBpbnQ4IGdlbmVyYXRlZCBieSBkZWZhdWx0IGFzIGlkZW50aXR5IHByaW1hcnkga2V5LFxuICAgKiAgICAgaGFuZGxlIHRleHQgbm90IG51bGwgdW5pcXVlLFxuICAgKiAgICAgZGlzcGxheV9uYW1lIHRleHRcbiAgICogICApO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIHVzZXJzIChpZCwgaGFuZGxlLCBkaXNwbGF5X25hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnc2FvaXJzZScsIG51bGwpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBVcHNlcnRpbmcgaW50byB0YWJsZXMgd2l0aCBjb25zdHJhaW50c1xuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImVycm9yXCI6IHtcbiAgICogICAgIFwiY29kZVwiOiBcIjIzNTA1XCIsXG4gICAqICAgICBcImRldGFpbHNcIjogXCJLZXkgKGhhbmRsZSk9KHNhb2lyc2UpIGFscmVhZHkgZXhpc3RzLlwiLFxuICAgKiAgICAgXCJoaW50XCI6IG51bGwsXG4gICAqICAgICBcIm1lc3NhZ2VcIjogXCJkdXBsaWNhdGUga2V5IHZhbHVlIHZpb2xhdGVzIHVuaXF1ZSBjb25zdHJhaW50IFxcXCJ1c2Vyc19oYW5kbGVfa2V5XFxcIlwiXG4gICAqICAgfSxcbiAgICogICBcInN0YXR1c1wiOiA0MDksXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiQ29uZmxpY3RcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cblxuICB1cHNlcnQ8Um93IGV4dGVuZHMgUmVsYXRpb24gZXh0ZW5kcyB7IEluc2VydDogdW5rbm93biB9ID8gUmVsYXRpb25bJ0luc2VydCddIDogbmV2ZXI+KFxuICAgIHZhbHVlczpcbiAgICAgIHwgUmVqZWN0RXhjZXNzUHJvcGVydGllczxcbiAgICAgICAgICBSZWxhdGlvbiBleHRlbmRzIHsgSW5zZXJ0OiB1bmtub3duIH0gPyBSZWxhdGlvblsnSW5zZXJ0J10gOiBuZXZlcixcbiAgICAgICAgICBSb3dcbiAgICAgICAgPlxuICAgICAgfCBSZWplY3RFeGNlc3NQcm9wZXJ0aWVzPFxuICAgICAgICAgIFJlbGF0aW9uIGV4dGVuZHMgeyBJbnNlcnQ6IHVua25vd24gfSA/IFJlbGF0aW9uWydJbnNlcnQnXSA6IG5ldmVyLFxuICAgICAgICAgIFJvd1xuICAgICAgICA+W10sXG4gICAge1xuICAgICAgb25Db25mbGljdCxcbiAgICAgIGlnbm9yZUR1cGxpY2F0ZXMgPSBmYWxzZSxcbiAgICAgIGNvdW50LFxuICAgICAgZGVmYXVsdFRvTnVsbCA9IHRydWUsXG4gICAgfToge1xuICAgICAgb25Db25mbGljdD86IHN0cmluZ1xuICAgICAgaWdub3JlRHVwbGljYXRlcz86IGJvb2xlYW5cbiAgICAgIGNvdW50PzogJ2V4YWN0JyB8ICdwbGFubmVkJyB8ICdlc3RpbWF0ZWQnIHwgKHN0cmluZyAmIHt9KVxuICAgICAgZGVmYXVsdFRvTnVsbD86IGJvb2xlYW5cbiAgICB9ID0ge31cbiAgKTogUG9zdGdyZXN0RmlsdGVyQnVpbGRlcjxcbiAgICBDbGllbnRPcHRpb25zLFxuICAgIFNjaGVtYSxcbiAgICBSZWxhdGlvblsnUm93J10sXG4gICAgbnVsbCxcbiAgICBSZWxhdGlvbk5hbWUsXG4gICAgUmVsYXRpb25zaGlwcyxcbiAgICAnUE9TVCdcbiAgPiB7XG4gICAgY29uc3QgbWV0aG9kID0gJ1BPU1QnXG4gICAgY29uc3QgeyB1cmwsIGhlYWRlcnMgfSA9IHRoaXMuY2xvbmVSZXF1ZXN0U3RhdGUoKVxuXG4gICAgaGVhZGVycy5hcHBlbmQoJ1ByZWZlcicsIGByZXNvbHV0aW9uPSR7aWdub3JlRHVwbGljYXRlcyA/ICdpZ25vcmUnIDogJ21lcmdlJ30tZHVwbGljYXRlc2ApXG5cbiAgICBpZiAob25Db25mbGljdCAhPT0gdW5kZWZpbmVkKSB1cmwuc2VhcmNoUGFyYW1zLnNldCgnb25fY29uZmxpY3QnLCBvbkNvbmZsaWN0KVxuICAgIGlmIChjb3VudCkge1xuICAgICAgaGVhZGVycy5hcHBlbmQoJ1ByZWZlcicsIGBjb3VudD0ke2NvdW50fWApXG4gICAgfVxuICAgIGlmICghZGVmYXVsdFRvTnVsbCkge1xuICAgICAgaGVhZGVycy5hcHBlbmQoJ1ByZWZlcicsICdtaXNzaW5nPWRlZmF1bHQnKVxuICAgIH1cblxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlcykpIHtcbiAgICAgIGNvbnN0IGNvbHVtbnMgPSB2YWx1ZXMucmVkdWNlKChhY2MsIHgpID0+IGFjYy5jb25jYXQoT2JqZWN0LmtleXMoeCkpLCBbXSBhcyBzdHJpbmdbXSlcbiAgICAgIGlmIChjb2x1bW5zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc3QgdW5pcXVlQ29sdW1ucyA9IFsuLi5uZXcgU2V0KGNvbHVtbnMpXS5tYXAoKGNvbHVtbikgPT4gYFwiJHtjb2x1bW59XCJgKVxuICAgICAgICB1cmwuc2VhcmNoUGFyYW1zLnNldCgnY29sdW1ucycsIHVuaXF1ZUNvbHVtbnMuam9pbignLCcpKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgUG9zdGdyZXN0RmlsdGVyQnVpbGRlcih7XG4gICAgICBtZXRob2QsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzLFxuICAgICAgc2NoZW1hOiB0aGlzLnNjaGVtYSxcbiAgICAgIGJvZHk6IHZhbHVlcyxcbiAgICAgIGZldGNoOiB0aGlzLmZldGNoID8/IGZldGNoLFxuICAgICAgdXJsTGVuZ3RoTGltaXQ6IHRoaXMudXJsTGVuZ3RoTGltaXQsXG4gICAgICByZXRyeTogdGhpcy5yZXRyeSxcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIFBlcmZvcm0gYW4gVVBEQVRFIG9uIHRoZSB0YWJsZSBvciB2aWV3LlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCB1cGRhdGVkIHJvd3MgYXJlIG5vdCByZXR1cm5lZC4gVG8gcmV0dXJuIGl0LCBjaGFpbiB0aGUgY2FsbFxuICAgKiB3aXRoIGAuc2VsZWN0KClgIGFmdGVyIGZpbHRlcnMuXG4gICAqXG4gICAqIEBwYXJhbSB2YWx1ZXMgLSBUaGUgdmFsdWVzIHRvIHVwZGF0ZSB3aXRoXG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5jb3VudCAtIENvdW50IGFsZ29yaXRobSB0byB1c2UgdG8gY291bnQgdXBkYXRlZCByb3dzLlxuICAgKlxuICAgKiBgXCJleGFjdFwiYDogRXhhY3QgYnV0IHNsb3cgY291bnQgYWxnb3JpdGhtLiBQZXJmb3JtcyBhIGBDT1VOVCgqKWAgdW5kZXIgdGhlXG4gICAqIGhvb2QuXG4gICAqXG4gICAqIGBcInBsYW5uZWRcImA6IEFwcHJveGltYXRlZCBidXQgZmFzdCBjb3VudCBhbGdvcml0aG0uIFVzZXMgdGhlIFBvc3RncmVzXG4gICAqIHN0YXRpc3RpY3MgdW5kZXIgdGhlIGhvb2QuXG4gICAqXG4gICAqIGBcImVzdGltYXRlZFwiYDogVXNlcyBleGFjdCBjb3VudCBmb3IgbG93IG51bWJlcnMgYW5kIHBsYW5uZWQgY291bnQgZm9yIGhpZ2hcbiAgICogbnVtYmVycy5cbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gYHVwZGF0ZSgpYCBzaG91bGQgYWx3YXlzIGJlIGNvbWJpbmVkIHdpdGggW0ZpbHRlcnNdKC9kb2NzL3JlZmVyZW5jZS9qYXZhc2NyaXB0L3VzaW5nLWZpbHRlcnMpIHRvIHRhcmdldCB0aGUgaXRlbShzKSB5b3Ugd2lzaCB0byB1cGRhdGUuXG4gICAqXG4gICAqIEBleGFtcGxlIFVwZGF0aW5nIHlvdXIgZGF0YVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdpbnN0cnVtZW50cycpXG4gICAqICAgLnVwZGF0ZSh7IG5hbWU6ICdwaWFubycgfSlcbiAgICogICAuZXEoJ2lkJywgMSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFVwZGF0aW5nIHlvdXIgZGF0YVxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgaW5zdHJ1bWVudHMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgaW5zdHJ1bWVudHMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ2hhcnBzaWNob3JkJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIFVwZGF0aW5nIHlvdXIgZGF0YVxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcInN0YXR1c1wiOiAyMDQsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiTm8gQ29udGVudFwiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gSGFuZGxpbmcgZXJyb3JzXG4gICAqIGBlcnJvci5oaW50YCBmcm9tIFBvc3RncmVzIG9mdGVuIGNvbnRhaW5zIHRoZSBhY3Rpb25hYmxlIGZpeCAoZS5nLiBgXCJHcmFudCB0aGUgcmVxdWlyZWQgcHJpdmlsZWdlcyB0byB0aGUgY3VycmVudCByb2xlIHdpdGg6IEdSQU5UIFVQREFURSBPTiBwdWJsaWMuaW5zdHJ1bWVudHMgVE8gYW5vbjtcImAgZm9yIGEgYDQyNTAxYCBwZXJtaXNzaW9uLWRlbmllZCBlcnJvcikuIExvZyB0aGUgZnVsbCBgZXJyb3JgIG9iamVjdCBzbyBpdCBpc24ndCBoaWRkZW4gYmVoaW5kIGBlcnJvci5tZXNzYWdlYC5cbiAgICpcbiAgICogQGV4YW1wbGUgSGFuZGxpbmcgZXJyb3JzXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ2luc3RydW1lbnRzJykudXBkYXRlKHsgbmFtZTogJ3BpYW5vJyB9KS5lcSgnaWQnLCAxKVxuICAgKiBpZiAoZXJyb3IpIGNvbnNvbGUuZXJyb3IoZXJyb3IpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBVcGRhdGUgYSByZWNvcmQgYW5kIHJldHVybiBpdFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdpbnN0cnVtZW50cycpXG4gICAqICAgLnVwZGF0ZSh7IG5hbWU6ICdwaWFubycgfSlcbiAgICogICAuZXEoJ2lkJywgMSlcbiAgICogICAuc2VsZWN0KClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIFVwZGF0ZSBhIHJlY29yZCBhbmQgcmV0dXJuIGl0XG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBpbnN0cnVtZW50cyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBpbnN0cnVtZW50cyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnaGFycHNpY2hvcmQnKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgVXBkYXRlIGEgcmVjb3JkIGFuZCByZXR1cm4gaXRcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJwaWFub1wiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIFVwZGF0aW5nIEpTT04gZGF0YVxuICAgKiBQb3N0Z3JlcyBvZmZlcnMgc29tZVxuICAgKiBbb3BlcmF0b3JzXSgvZG9jcy9ndWlkZXMvZGF0YWJhc2UvanNvbiNxdWVyeS10aGUtanNvbmItZGF0YSkgZm9yXG4gICAqIHdvcmtpbmcgd2l0aCBKU09OIGRhdGEuIEN1cnJlbnRseSwgaXQgaXMgb25seSBwb3NzaWJsZSB0byB1cGRhdGUgdGhlIGVudGlyZSBKU09OIGRvY3VtZW50LlxuICAgKlxuICAgKiBAZXhhbXBsZSBVcGRhdGluZyBKU09OIGRhdGFcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgndXNlcnMnKVxuICAgKiAgIC51cGRhdGUoe1xuICAgKiAgICAgYWRkcmVzczoge1xuICAgKiAgICAgICBzdHJlZXQ6ICdNZWxyb3NlIFBsYWNlJyxcbiAgICogICAgICAgcG9zdGNvZGU6IDkwMjEwXG4gICAqICAgICB9XG4gICAqICAgfSlcbiAgICogICAuZXEoJ2FkZHJlc3MtPnBvc3Rjb2RlJywgOTAyMTApXG4gICAqICAgLnNlbGVjdCgpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBVcGRhdGluZyBKU09OIGRhdGFcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIHVzZXJzIChcbiAgICogICAgIGlkIGludDggcHJpbWFyeSBrZXksXG4gICAqICAgICBuYW1lIHRleHQsXG4gICAqICAgICBhZGRyZXNzIGpzb25iXG4gICAqICAgKTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICB1c2VycyAoaWQsIG5hbWUsIGFkZHJlc3MpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTWljaGFlbCcsICd7IFwicG9zdGNvZGVcIjogOTAyMTAgfScpO1xuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBVcGRhdGluZyBKU09OIGRhdGFcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJNaWNoYWVsXCIsXG4gICAqICAgICAgIFwiYWRkcmVzc1wiOiB7XG4gICAqICAgICAgICAgXCJzdHJlZXRcIjogXCJNZWxyb3NlIFBsYWNlXCIsXG4gICAqICAgICAgICAgXCJwb3N0Y29kZVwiOiA5MDIxMFxuICAgKiAgICAgICB9XG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgXCJzdGF0dXNUZXh0XCI6IFwiT0tcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgdXBkYXRlPFJvdyBleHRlbmRzIFJlbGF0aW9uIGV4dGVuZHMgeyBVcGRhdGU6IHVua25vd24gfSA/IFJlbGF0aW9uWydVcGRhdGUnXSA6IG5ldmVyPihcbiAgICB2YWx1ZXM6IFJlamVjdEV4Y2Vzc1Byb3BlcnRpZXM8XG4gICAgICBSZWxhdGlvbiBleHRlbmRzIHsgVXBkYXRlOiB1bmtub3duIH0gPyBSZWxhdGlvblsnVXBkYXRlJ10gOiBuZXZlcixcbiAgICAgIFJvd1xuICAgID4sXG4gICAge1xuICAgICAgY291bnQsXG4gICAgfToge1xuICAgICAgY291bnQ/OiAnZXhhY3QnIHwgJ3BsYW5uZWQnIHwgJ2VzdGltYXRlZCcgfCAoc3RyaW5nICYge30pXG4gICAgfSA9IHt9XG4gICk6IFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBTY2hlbWEsXG4gICAgUmVsYXRpb25bJ1JvdyddLFxuICAgIG51bGwsXG4gICAgUmVsYXRpb25OYW1lLFxuICAgIFJlbGF0aW9uc2hpcHMsXG4gICAgJ1BBVENIJ1xuICA+IHtcbiAgICBjb25zdCBtZXRob2QgPSAnUEFUQ0gnXG4gICAgY29uc3QgeyB1cmwsIGhlYWRlcnMgfSA9IHRoaXMuY2xvbmVSZXF1ZXN0U3RhdGUoKVxuXG4gICAgaWYgKGNvdW50KSB7XG4gICAgICBoZWFkZXJzLmFwcGVuZCgnUHJlZmVyJywgYGNvdW50PSR7Y291bnR9YClcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFBvc3RncmVzdEZpbHRlckJ1aWxkZXIoe1xuICAgICAgbWV0aG9kLFxuICAgICAgdXJsLFxuICAgICAgaGVhZGVycyxcbiAgICAgIHNjaGVtYTogdGhpcy5zY2hlbWEsXG4gICAgICBib2R5OiB2YWx1ZXMsXG4gICAgICBmZXRjaDogdGhpcy5mZXRjaCA/PyBmZXRjaCxcbiAgICAgIHVybExlbmd0aExpbWl0OiB0aGlzLnVybExlbmd0aExpbWl0LFxuICAgICAgcmV0cnk6IHRoaXMucmV0cnksXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBQZXJmb3JtIGEgREVMRVRFIG9uIHRoZSB0YWJsZSBvciB2aWV3LlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCBkZWxldGVkIHJvd3MgYXJlIG5vdCByZXR1cm5lZC4gVG8gcmV0dXJuIGl0LCBjaGFpbiB0aGUgY2FsbFxuICAgKiB3aXRoIGAuc2VsZWN0KClgIGFmdGVyIGZpbHRlcnMuXG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucy5jb3VudCAtIENvdW50IGFsZ29yaXRobSB0byB1c2UgdG8gY291bnQgZGVsZXRlZCByb3dzLlxuICAgKlxuICAgKiBgXCJleGFjdFwiYDogRXhhY3QgYnV0IHNsb3cgY291bnQgYWxnb3JpdGhtLiBQZXJmb3JtcyBhIGBDT1VOVCgqKWAgdW5kZXIgdGhlXG4gICAqIGhvb2QuXG4gICAqXG4gICAqIGBcInBsYW5uZWRcImA6IEFwcHJveGltYXRlZCBidXQgZmFzdCBjb3VudCBhbGdvcml0aG0uIFVzZXMgdGhlIFBvc3RncmVzXG4gICAqIHN0YXRpc3RpY3MgdW5kZXIgdGhlIGhvb2QuXG4gICAqXG4gICAqIGBcImVzdGltYXRlZFwiYDogVXNlcyBleGFjdCBjb3VudCBmb3IgbG93IG51bWJlcnMgYW5kIHBsYW5uZWQgY291bnQgZm9yIGhpZ2hcbiAgICogbnVtYmVycy5cbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gYGRlbGV0ZSgpYCBzaG91bGQgYWx3YXlzIGJlIGNvbWJpbmVkIHdpdGggW2ZpbHRlcnNdKC9kb2NzL3JlZmVyZW5jZS9qYXZhc2NyaXB0L3VzaW5nLWZpbHRlcnMpIHRvIHRhcmdldCB0aGUgaXRlbShzKSB5b3Ugd2lzaCB0byBkZWxldGUuXG4gICAqIC0gSWYgeW91IHVzZSBgZGVsZXRlKClgIHdpdGggZmlsdGVycyBhbmQgeW91IGhhdmVcbiAgICogICBbUkxTXSgvZG9jcy9sZWFybi9hdXRoLWRlZXAtZGl2ZS9hdXRoLXJvdy1sZXZlbC1zZWN1cml0eSkgZW5hYmxlZCwgb25seVxuICAgKiAgIHJvd3MgdmlzaWJsZSB0aHJvdWdoIGBTRUxFQ1RgIHBvbGljaWVzIGFyZSBkZWxldGVkLiBOb3RlIHRoYXQgYnkgZGVmYXVsdFxuICAgKiAgIG5vIHJvd3MgYXJlIHZpc2libGUsIHNvIHlvdSBuZWVkIGF0IGxlYXN0IG9uZSBgU0VMRUNUYC9gQUxMYCBwb2xpY3kgdGhhdFxuICAgKiAgIG1ha2VzIHRoZSByb3dzIHZpc2libGUuXG4gICAqIC0gV2hlbiB1c2luZyBgZGVsZXRlKCkuaW4oKWAsIHNwZWNpZnkgYW4gYXJyYXkgb2YgdmFsdWVzIHRvIHRhcmdldCBtdWx0aXBsZSByb3dzIHdpdGggYSBzaW5nbGUgcXVlcnkuIFRoaXMgaXMgcGFydGljdWxhcmx5IHVzZWZ1bCBmb3IgYmF0Y2ggZGVsZXRpbmcgZW50cmllcyB0aGF0IHNoYXJlIGNvbW1vbiBjcml0ZXJpYSwgc3VjaCBhcyBkZWxldGluZyB1c2VycyBieSB0aGVpciBJRHMuIEVuc3VyZSB0aGF0IHRoZSBhcnJheSB5b3UgcHJvdmlkZSBhY2N1cmF0ZWx5IHJlcHJlc2VudHMgYWxsIHJlY29yZHMgeW91IGludGVuZCB0byBkZWxldGUgdG8gYXZvaWQgdW5pbnRlbmRlZCBkYXRhIHJlbW92YWwuXG4gICAqXG4gICAqIEBleGFtcGxlIERlbGV0ZSBhIHNpbmdsZSByZWNvcmRcbiAgICogYGBgdHNcbiAgICogY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjb3VudHJpZXMnKVxuICAgKiAgIC5kZWxldGUoKVxuICAgKiAgIC5lcSgnaWQnLCAxKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgRGVsZXRlIGEgc2luZ2xlIHJlY29yZFxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY291bnRyaWVzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNvdW50cmllcyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnTW9yZG9yJyk7XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIERlbGV0ZSBhIHNpbmdsZSByZWNvcmRcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJzdGF0dXNcIjogMjA0LFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk5vIENvbnRlbnRcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIEhhbmRsaW5nIGVycm9yc1xuICAgKiBgZXJyb3IuaGludGAgZnJvbSBQb3N0Z3JlcyBvZnRlbiBjb250YWlucyB0aGUgYWN0aW9uYWJsZSBmaXggKGUuZy4gYFwiR3JhbnQgdGhlIHJlcXVpcmVkIHByaXZpbGVnZXMgdG8gdGhlIGN1cnJlbnQgcm9sZSB3aXRoOiBHUkFOVCBERUxFVEUgT04gcHVibGljLmNvdW50cmllcyBUTyBhbm9uO1wiYCBmb3IgYSBgNDI1MDFgIHBlcm1pc3Npb24tZGVuaWVkIGVycm9yKS4gTG9nIHRoZSBmdWxsIGBlcnJvcmAgb2JqZWN0IHNvIGl0IGlzbid0IGhpZGRlbiBiZWhpbmQgYGVycm9yLm1lc3NhZ2VgLlxuICAgKlxuICAgKiBAZXhhbXBsZSBIYW5kbGluZyBlcnJvcnNcbiAgICogYGBganNcbiAgICogY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgnY291bnRyaWVzJykuZGVsZXRlKCkuZXEoJ2lkJywgMSlcbiAgICogaWYgKGVycm9yKSBjb25zb2xlLmVycm9yKGVycm9yKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgRGVsZXRlIGEgcmVjb3JkIGFuZCByZXR1cm4gaXRcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuZnJvbSgnY291bnRyaWVzJylcbiAgICogICAuZGVsZXRlKClcbiAgICogICAuZXEoJ2lkJywgMSlcbiAgICogICAuc2VsZWN0KClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIERlbGV0ZSBhIHJlY29yZCBhbmQgcmV0dXJuIGl0XG4gICAqIGBgYHNxbFxuICAgKiBjcmVhdGUgdGFibGVcbiAgICogICBjb3VudHJpZXMgKGlkIGludDggcHJpbWFyeSBrZXksIG5hbWUgdGV4dCk7XG4gICAqXG4gICAqIGluc2VydCBpbnRvXG4gICAqICAgY291bnRyaWVzIChpZCwgbmFtZSlcbiAgICogdmFsdWVzXG4gICAqICAgKDEsICdNb3Jkb3InKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgRGVsZXRlIGEgcmVjb3JkIGFuZCByZXR1cm4gaXRcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgICBcIm5hbWVcIjogXCJNb3Jkb3JcIlxuICAgKiAgICAgfVxuICAgKiAgIF0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgRGVsZXRlIG11bHRpcGxlIHJlY29yZHNcbiAgICogYGBgdHNcbiAgICogY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5mcm9tKCdjb3VudHJpZXMnKVxuICAgKiAgIC5kZWxldGUoKVxuICAgKiAgIC5pbignaWQnLCBbMSwgMiwgM10pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVNxbCBEZWxldGUgbXVsdGlwbGUgcmVjb3Jkc1xuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIHRhYmxlXG4gICAqICAgY291bnRyaWVzIChpZCBpbnQ4IHByaW1hcnkga2V5LCBuYW1lIHRleHQpO1xuICAgKlxuICAgKiBpbnNlcnQgaW50b1xuICAgKiAgIGNvdW50cmllcyAoaWQsIG5hbWUpXG4gICAqIHZhbHVlc1xuICAgKiAgICgxLCAnUm9oYW4nKSwgKDIsICdUaGUgU2hpcmUnKSwgKDMsICdNb3Jkb3InKTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgRGVsZXRlIG11bHRpcGxlIHJlY29yZHNcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJzdGF0dXNcIjogMjA0LFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk5vIENvbnRlbnRcIlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgZGVsZXRlKHtcbiAgICBjb3VudCxcbiAgfToge1xuICAgIGNvdW50PzogJ2V4YWN0JyB8ICdwbGFubmVkJyB8ICdlc3RpbWF0ZWQnIHwgKHN0cmluZyAmIHt9KVxuICB9ID0ge30pOiBQb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyPFxuICAgIENsaWVudE9wdGlvbnMsXG4gICAgU2NoZW1hLFxuICAgIFJlbGF0aW9uWydSb3cnXSxcbiAgICBudWxsLFxuICAgIFJlbGF0aW9uTmFtZSxcbiAgICBSZWxhdGlvbnNoaXBzLFxuICAgICdERUxFVEUnXG4gID4ge1xuICAgIGNvbnN0IG1ldGhvZCA9ICdERUxFVEUnXG4gICAgY29uc3QgeyB1cmwsIGhlYWRlcnMgfSA9IHRoaXMuY2xvbmVSZXF1ZXN0U3RhdGUoKVxuXG4gICAgaWYgKGNvdW50KSB7XG4gICAgICBoZWFkZXJzLmFwcGVuZCgnUHJlZmVyJywgYGNvdW50PSR7Y291bnR9YClcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFBvc3RncmVzdEZpbHRlckJ1aWxkZXIoe1xuICAgICAgbWV0aG9kLFxuICAgICAgdXJsLFxuICAgICAgaGVhZGVycyxcbiAgICAgIHNjaGVtYTogdGhpcy5zY2hlbWEsXG4gICAgICBmZXRjaDogdGhpcy5mZXRjaCA/PyBmZXRjaCxcbiAgICAgIHVybExlbmd0aExpbWl0OiB0aGlzLnVybExlbmd0aExpbWl0LFxuICAgICAgcmV0cnk6IHRoaXMucmV0cnksXG4gICAgfSlcbiAgfVxufVxuIiwiaW1wb3J0IFBvc3RncmVzdFF1ZXJ5QnVpbGRlciBmcm9tICcuL1Bvc3RncmVzdFF1ZXJ5QnVpbGRlcidcbmltcG9ydCBQb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyIGZyb20gJy4vUG9zdGdyZXN0RmlsdGVyQnVpbGRlcidcbmltcG9ydCB7IEZldGNoLCBHZW5lcmljU2NoZW1hLCBDbGllbnRTZXJ2ZXJPcHRpb25zIH0gZnJvbSAnLi90eXBlcy9jb21tb24vY29tbW9uJ1xuaW1wb3J0IHsgR2V0UnBjRnVuY3Rpb25GaWx0ZXJCdWlsZGVyQnlBcmdzIH0gZnJvbSAnLi90eXBlcy9jb21tb24vcnBjJ1xuXG4vKipcbiAqIFBvc3RnUkVTVCBjbGllbnQuXG4gKlxuICogQHR5cGVQYXJhbSBEYXRhYmFzZSAtIFR5cGVzIGZvciB0aGUgc2NoZW1hIGZyb20gdGhlIFt0eXBlXG4gKiBnZW5lcmF0b3JdKGh0dHBzOi8vc3VwYWJhc2UuY29tL2RvY3MvcmVmZXJlbmNlL2phdmFzY3JpcHQvbmV4dC90eXBlc2NyaXB0LXN1cHBvcnQpXG4gKlxuICogQHR5cGVQYXJhbSBTY2hlbWFOYW1lIC0gUG9zdGdyZXMgc2NoZW1hIHRvIHN3aXRjaCB0by4gTXVzdCBiZSBhIHN0cmluZ1xuICogbGl0ZXJhbCwgdGhlIHNhbWUgb25lIHBhc3NlZCB0byB0aGUgY29uc3RydWN0b3IuIElmIHRoZSBzY2hlbWEgaXMgbm90XG4gKiBgXCJwdWJsaWNcImAsIHRoaXMgbXVzdCBiZSBzdXBwbGllZCBtYW51YWxseS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUG9zdGdyZXN0Q2xpZW50PFxuICBEYXRhYmFzZSA9IGFueSxcbiAgQ2xpZW50T3B0aW9ucyBleHRlbmRzIENsaWVudFNlcnZlck9wdGlvbnMgPSBEYXRhYmFzZSBleHRlbmRzIHtcbiAgICBfX0ludGVybmFsU3VwYWJhc2U6IGluZmVyIEkgZXh0ZW5kcyBDbGllbnRTZXJ2ZXJPcHRpb25zXG4gIH1cbiAgICA/IElcbiAgICA6IHt9LFxuICBTY2hlbWFOYW1lIGV4dGVuZHMgc3RyaW5nICZcbiAgICBrZXlvZiBPbWl0PERhdGFiYXNlLCAnX19JbnRlcm5hbFN1cGFiYXNlJz4gPSAncHVibGljJyBleHRlbmRzIGtleW9mIE9taXQ8XG4gICAgRGF0YWJhc2UsXG4gICAgJ19fSW50ZXJuYWxTdXBhYmFzZSdcbiAgPlxuICAgID8gJ3B1YmxpYydcbiAgICA6IHN0cmluZyAmIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPixcbiAgU2NoZW1hIGV4dGVuZHMgR2VuZXJpY1NjaGVtYSA9IE9taXQ8XG4gICAgRGF0YWJhc2UsXG4gICAgJ19fSW50ZXJuYWxTdXBhYmFzZSdcbiAgPltTY2hlbWFOYW1lXSBleHRlbmRzIEdlbmVyaWNTY2hlbWFcbiAgICA/IE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPltTY2hlbWFOYW1lXVxuICAgIDogYW55LFxuPiB7XG4gIHVybDogc3RyaW5nXG4gIGhlYWRlcnM6IEhlYWRlcnNcbiAgc2NoZW1hTmFtZT86IFNjaGVtYU5hbWVcbiAgZmV0Y2g/OiBGZXRjaFxuICB1cmxMZW5ndGhMaW1pdDogbnVtYmVyXG5cbiAgLy8gUmV0cnkgY29uZmlndXJhdGlvbiAtIGVuYWJsZWQgYnkgZGVmYXVsdFxuICByZXRyeT86IGJvb2xlYW5cblxuICAvLyBUT0RPOiBBZGQgYmFjayBzaG91bGRUaHJvd09uRXJyb3Igb25jZSB3ZSBmaWd1cmUgb3V0IHRoZSB0eXBpbmdzXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgUG9zdGdSRVNUIGNsaWVudC5cbiAgICpcbiAgICogQHBhcmFtIHVybCAtIFVSTCBvZiB0aGUgUG9zdGdSRVNUIGVuZHBvaW50XG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKiBAcGFyYW0gb3B0aW9ucy5oZWFkZXJzIC0gQ3VzdG9tIGhlYWRlcnNcbiAgICogQHBhcmFtIG9wdGlvbnMuc2NoZW1hIC0gUG9zdGdyZXMgc2NoZW1hIHRvIHN3aXRjaCB0b1xuICAgKiBAcGFyYW0gb3B0aW9ucy5mZXRjaCAtIEN1c3RvbSBmZXRjaFxuICAgKiBAcGFyYW0gb3B0aW9ucy50aW1lb3V0IC0gT3B0aW9uYWwgdGltZW91dCBpbiBtaWxsaXNlY29uZHMgZm9yIGFsbCByZXF1ZXN0cy4gV2hlbiBzZXQsIHJlcXVlc3RzIHdpbGwgYXV0b21hdGljYWxseSBhYm9ydCBhZnRlciB0aGlzIGR1cmF0aW9uIHRvIHByZXZlbnQgaW5kZWZpbml0ZSBoYW5ncy5cbiAgICogQHBhcmFtIG9wdGlvbnMudXJsTGVuZ3RoTGltaXQgLSBNYXhpbXVtIFVSTCBsZW5ndGggaW4gY2hhcmFjdGVycyBiZWZvcmUgd2FybmluZ3MvZXJyb3JzIGFyZSB0cmlnZ2VyZWQuIERlZmF1bHRzIHRvIDgwMDAuXG4gICAqIEBwYXJhbSBvcHRpb25zLnJldHJ5IC0gRW5hYmxlIG9yIGRpc2FibGUgYXV0b21hdGljIHJldHJpZXMgZm9yIHRyYW5zaWVudCBlcnJvcnMuXG4gICAqICAgV2hlbiBlbmFibGVkLCBpZGVtcG90ZW50IHJlcXVlc3RzIChHRVQsIEhFQUQsIE9QVElPTlMpIHRoYXQgZmFpbCB3aXRoIG5ldHdvcmtcbiAgICogICBlcnJvcnMgb3IgSFRUUCA1MDMvNTIwIHJlc3BvbnNlcyB3aWxsIGJlIGF1dG9tYXRpY2FsbHkgcmV0cmllZCB1cCB0byAzIHRpbWVzXG4gICAqICAgd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmICgxcywgMnMsIDRzKS4gRGVmYXVsdHMgdG8gYHRydWVgLlxuICAgKiBAZXhhbXBsZSBVc2luZyBzdXBhYmFzZS1qcyAocmVjb21tZW5kZWQpXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcydcbiAgICpcbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jbycsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScpXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3Byb2ZpbGVzJykuc2VsZWN0KCcqJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEEgYHRpbWVvdXRgIG9wdGlvbiAoaW4gbWlsbGlzZWNvbmRzKSBjYW4gYmUgc2V0IHRvIGF1dG9tYXRpY2FsbHkgYWJvcnQgcmVxdWVzdHMgdGhhdCB0YWtlIHRvbyBsb25nLlxuICAgKiAtIEEgYHVybExlbmd0aExpbWl0YCBvcHRpb24gKGRlZmF1bHQ6IDgwMDApIGNhbiBiZSBzZXQgdG8gY29udHJvbCB3aGVuIFVSTCBsZW5ndGggd2FybmluZ3MgYXJlIGluY2x1ZGVkIGluIGVycm9yIG1lc3NhZ2VzIGZvciBhYm9ydGVkIHJlcXVlc3RzLlxuICAgKlxuICAgKiBAZXhhbXBsZSBTdGFuZGFsb25lIGltcG9ydCBmb3IgYnVuZGxlLXNlbnNpdGl2ZSBlbnZpcm9ubWVudHNcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgUG9zdGdyZXN0Q2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3Bvc3RncmVzdC1qcydcbiAgICpcbiAgICogY29uc3QgcG9zdGdyZXN0ID0gbmV3IFBvc3RncmVzdENsaWVudCgnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvL3Jlc3QvdjEnLCB7XG4gICAqICAgaGVhZGVyczogeyBhcGlrZXk6ICd5b3VyLXB1Ymxpc2hhYmxlLWtleScgfSxcbiAgICogICBzY2hlbWE6ICdwdWJsaWMnLFxuICAgKiAgIHRpbWVvdXQ6IDMwMDAwLCAvLyAzMCBzZWNvbmQgdGltZW91dFxuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIHVybDogc3RyaW5nLFxuICAgIHtcbiAgICAgIGhlYWRlcnMgPSB7fSxcbiAgICAgIHNjaGVtYSxcbiAgICAgIGZldGNoLFxuICAgICAgdGltZW91dCxcbiAgICAgIHVybExlbmd0aExpbWl0ID0gODAwMCxcbiAgICAgIHJldHJ5LFxuICAgIH06IHtcbiAgICAgIGhlYWRlcnM/OiBIZWFkZXJzSW5pdFxuICAgICAgc2NoZW1hPzogU2NoZW1hTmFtZVxuICAgICAgZmV0Y2g/OiBGZXRjaFxuICAgICAgdGltZW91dD86IG51bWJlclxuICAgICAgdXJsTGVuZ3RoTGltaXQ/OiBudW1iZXJcbiAgICAgIHJldHJ5PzogYm9vbGVhblxuICAgIH0gPSB7fVxuICApIHtcbiAgICB0aGlzLnVybCA9IHVybFxuICAgIHRoaXMuaGVhZGVycyA9IG5ldyBIZWFkZXJzKGhlYWRlcnMpXG4gICAgdGhpcy5zY2hlbWFOYW1lID0gc2NoZW1hXG4gICAgdGhpcy51cmxMZW5ndGhMaW1pdCA9IHVybExlbmd0aExpbWl0XG5cbiAgICBjb25zdCBvcmlnaW5hbEZldGNoID0gZmV0Y2ggPz8gZ2xvYmFsVGhpcy5mZXRjaFxuXG4gICAgLy8gV3JhcCBmZXRjaCB3aXRoIHRpbWVvdXQgaWYgc3BlY2lmaWVkXG4gICAgaWYgKHRpbWVvdXQgIT09IHVuZGVmaW5lZCAmJiB0aW1lb3V0ID4gMCkge1xuICAgICAgdGhpcy5mZXRjaCA9IChpbnB1dCwgaW5pdCkgPT4ge1xuICAgICAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXG4gICAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCB0aW1lb3V0KVxuXG4gICAgICAgIC8vIE1lcmdlIGFib3J0IHNpZ25hbHMgaWYgb25lIGFscmVhZHkgZXhpc3RzXG4gICAgICAgIGNvbnN0IGV4aXN0aW5nU2lnbmFsID0gaW5pdD8uc2lnbmFsXG4gICAgICAgIGlmIChleGlzdGluZ1NpZ25hbCkge1xuICAgICAgICAgIC8vIElmIHRoZSBleGlzdGluZyBzaWduYWwgaXMgYWxyZWFkeSBhYm9ydGVkLCB1c2UgaXQgZGlyZWN0bHlcbiAgICAgICAgICBpZiAoZXhpc3RpbmdTaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZClcbiAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbEZldGNoKGlucHV0LCBpbml0KVxuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIExpc3RlbiB0byBleGlzdGluZyBzaWduYWwgYW5kIGFib3J0IG91ciBjb250cm9sbGVyIHRvb1xuICAgICAgICAgIGNvbnN0IGFib3J0SGFuZGxlciA9ICgpID0+IHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpXG4gICAgICAgICAgICBjb250cm9sbGVyLmFib3J0KClcbiAgICAgICAgICB9XG4gICAgICAgICAgZXhpc3RpbmdTaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydEhhbmRsZXIsIHsgb25jZTogdHJ1ZSB9KVxuXG4gICAgICAgICAgcmV0dXJuIG9yaWdpbmFsRmV0Y2goaW5wdXQsIHtcbiAgICAgICAgICAgIC4uLmluaXQsXG4gICAgICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAgIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZClcbiAgICAgICAgICAgIGV4aXN0aW5nU2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgYWJvcnRIYW5kbGVyKVxuICAgICAgICAgIH0pXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gb3JpZ2luYWxGZXRjaChpbnB1dCwge1xuICAgICAgICAgIC4uLmluaXQsXG4gICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgfSkuZmluYWxseSgoKSA9PiBjbGVhclRpbWVvdXQodGltZW91dElkKSlcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5mZXRjaCA9IG9yaWdpbmFsRmV0Y2hcbiAgICB9XG4gICAgdGhpcy5yZXRyeSA9IHJldHJ5XG4gIH1cbiAgZnJvbTxcbiAgICBUYWJsZU5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBTY2hlbWFbJ1RhYmxlcyddLFxuICAgIFRhYmxlIGV4dGVuZHMgU2NoZW1hWydUYWJsZXMnXVtUYWJsZU5hbWVdLFxuICA+KHJlbGF0aW9uOiBUYWJsZU5hbWUpOiBQb3N0Z3Jlc3RRdWVyeUJ1aWxkZXI8Q2xpZW50T3B0aW9ucywgU2NoZW1hLCBUYWJsZSwgVGFibGVOYW1lPlxuICBmcm9tPFZpZXdOYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgU2NoZW1hWydWaWV3cyddLCBWaWV3IGV4dGVuZHMgU2NoZW1hWydWaWV3cyddW1ZpZXdOYW1lXT4oXG4gICAgcmVsYXRpb246IFZpZXdOYW1lXG4gICk6IFBvc3RncmVzdFF1ZXJ5QnVpbGRlcjxDbGllbnRPcHRpb25zLCBTY2hlbWEsIFZpZXcsIFZpZXdOYW1lPlxuICAvKipcbiAgICogUGVyZm9ybSBhIHF1ZXJ5IG9uIGEgdGFibGUgb3IgYSB2aWV3LlxuICAgKlxuICAgKiBAcGFyYW0gcmVsYXRpb24gLSBUaGUgdGFibGUgb3IgdmlldyBuYW1lIHRvIHF1ZXJ5XG4gICAqXG4gICAqIEBjYXRlZ29yeSBEYXRhYmFzZVxuICAgKi9cbiAgZnJvbShcbiAgICByZWxhdGlvbjogKHN0cmluZyAmIGtleW9mIFNjaGVtYVsnVGFibGVzJ10pIHwgKHN0cmluZyAmIGtleW9mIFNjaGVtYVsnVmlld3MnXSlcbiAgKTogUG9zdGdyZXN0UXVlcnlCdWlsZGVyPENsaWVudE9wdGlvbnMsIFNjaGVtYSwgYW55LCBhbnk+IHtcbiAgICBpZiAoIXJlbGF0aW9uIHx8IHR5cGVvZiByZWxhdGlvbiAhPT0gJ3N0cmluZycgfHwgcmVsYXRpb24udHJpbSgpID09PSAnJykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHJlbGF0aW9uIG5hbWU6IHJlbGF0aW9uIG11c3QgYmUgYSBub24tZW1wdHkgc3RyaW5nLicpXG4gICAgfVxuXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChgJHt0aGlzLnVybH0vJHtyZWxhdGlvbn1gKVxuICAgIHJldHVybiBuZXcgUG9zdGdyZXN0UXVlcnlCdWlsZGVyKHVybCwge1xuICAgICAgaGVhZGVyczogbmV3IEhlYWRlcnModGhpcy5oZWFkZXJzKSxcbiAgICAgIHNjaGVtYTogdGhpcy5zY2hlbWFOYW1lLFxuICAgICAgZmV0Y2g6IHRoaXMuZmV0Y2gsXG4gICAgICB1cmxMZW5ndGhMaW1pdDogdGhpcy51cmxMZW5ndGhMaW1pdCxcbiAgICAgIHJldHJ5OiB0aGlzLnJldHJ5LFxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogU2VsZWN0IGEgc2NoZW1hIHRvIHF1ZXJ5IG9yIHBlcmZvcm0gYW4gZnVuY3Rpb24gKHJwYykgY2FsbC5cbiAgICpcbiAgICogVGhlIHNjaGVtYSBuZWVkcyB0byBiZSBvbiB0aGUgbGlzdCBvZiBleHBvc2VkIHNjaGVtYXMgaW5zaWRlIFN1cGFiYXNlLlxuICAgKlxuICAgKiBAcGFyYW0gc2NoZW1hIC0gVGhlIHNjaGVtYSB0byBxdWVyeVxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRGF0YWJhc2VcbiAgICovXG4gIHNjaGVtYTxEeW5hbWljU2NoZW1hIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgT21pdDxEYXRhYmFzZSwgJ19fSW50ZXJuYWxTdXBhYmFzZSc+PihcbiAgICBzY2hlbWE6IER5bmFtaWNTY2hlbWFcbiAgKTogUG9zdGdyZXN0Q2xpZW50PFxuICAgIERhdGFiYXNlLFxuICAgIENsaWVudE9wdGlvbnMsXG4gICAgRHluYW1pY1NjaGVtYSxcbiAgICBEYXRhYmFzZVtEeW5hbWljU2NoZW1hXSBleHRlbmRzIEdlbmVyaWNTY2hlbWEgPyBEYXRhYmFzZVtEeW5hbWljU2NoZW1hXSA6IGFueVxuICA+IHtcbiAgICByZXR1cm4gbmV3IFBvc3RncmVzdENsaWVudCh0aGlzLnVybCwge1xuICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgc2NoZW1hLFxuICAgICAgZmV0Y2g6IHRoaXMuZmV0Y2gsXG4gICAgICB1cmxMZW5ndGhMaW1pdDogdGhpcy51cmxMZW5ndGhMaW1pdCxcbiAgICAgIHJldHJ5OiB0aGlzLnJldHJ5LFxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogUGVyZm9ybSBhIGZ1bmN0aW9uIGNhbGwuXG4gICAqXG4gICAqIEBwYXJhbSBmbiAtIFRoZSBmdW5jdGlvbiBuYW1lIHRvIGNhbGxcbiAgICogQHBhcmFtIGFyZ3MgLSBUaGUgYXJndW1lbnRzIHRvIHBhc3MgdG8gdGhlIGZ1bmN0aW9uIGNhbGxcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBOYW1lZCBwYXJhbWV0ZXJzXG4gICAqIEBwYXJhbSBvcHRpb25zLmhlYWQgLSBXaGVuIHNldCB0byBgdHJ1ZWAsIGBkYXRhYCB3aWxsIG5vdCBiZSByZXR1cm5lZC5cbiAgICogVXNlZnVsIGlmIHlvdSBvbmx5IG5lZWQgdGhlIGNvdW50LlxuICAgKiBAcGFyYW0gb3B0aW9ucy5nZXQgLSBXaGVuIHNldCB0byBgdHJ1ZWAsIHRoZSBmdW5jdGlvbiB3aWxsIGJlIGNhbGxlZCB3aXRoXG4gICAqIHJlYWQtb25seSBhY2Nlc3MgbW9kZS5cbiAgICogQHBhcmFtIG9wdGlvbnMuY291bnQgLSBDb3VudCBhbGdvcml0aG0gdG8gdXNlIHRvIGNvdW50IHJvd3MgcmV0dXJuZWQgYnkgdGhlXG4gICAqIGZ1bmN0aW9uLiBPbmx5IGFwcGxpY2FibGUgZm9yIFtzZXQtcmV0dXJuaW5nXG4gICAqIGZ1bmN0aW9uc10oaHR0cHM6Ly93d3cucG9zdGdyZXNxbC5vcmcvZG9jcy9jdXJyZW50L2Z1bmN0aW9ucy1zcmYuaHRtbCkuXG4gICAqXG4gICAqIGBcImV4YWN0XCJgOiBFeGFjdCBidXQgc2xvdyBjb3VudCBhbGdvcml0aG0uIFBlcmZvcm1zIGEgYENPVU5UKCopYCB1bmRlciB0aGVcbiAgICogaG9vZC5cbiAgICpcbiAgICogYFwicGxhbm5lZFwiYDogQXBwcm94aW1hdGVkIGJ1dCBmYXN0IGNvdW50IGFsZ29yaXRobS4gVXNlcyB0aGUgUG9zdGdyZXNcbiAgICogc3RhdGlzdGljcyB1bmRlciB0aGUgaG9vZC5cbiAgICpcbiAgICogYFwiZXN0aW1hdGVkXCJgOiBVc2VzIGV4YWN0IGNvdW50IGZvciBsb3cgbnVtYmVycyBhbmQgcGxhbm5lZCBjb3VudCBmb3IgaGlnaFxuICAgKiBudW1iZXJzLlxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBGb3IgY3Jvc3Mtc2NoZW1hIGZ1bmN0aW9ucyB3aGVyZSB0eXBlIGluZmVyZW5jZSBmYWlscywgdXNlIG92ZXJyaWRlVHlwZXM6XG4gICAqIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc2NoZW1hKCdzY2hlbWFfYicpXG4gICAqICAgLnJwYygnZnVuY3Rpb25fYScsIHt9KVxuICAgKiAgIC5vdmVycmlkZVR5cGVzPHsgaWQ6IHN0cmluZzsgdXNlcl9pZDogc3RyaW5nIH1bXT4oKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGNhdGVnb3J5IERhdGFiYXNlXG4gICAqXG4gICAqIEBleGFtcGxlIENhbGwgYSBQb3N0Z3JlcyBmdW5jdGlvbiB3aXRob3V0IGFyZ3VtZW50c1xuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5ycGMoJ2hlbGxvX3dvcmxkJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIENhbGwgYSBQb3N0Z3JlcyBmdW5jdGlvbiB3aXRob3V0IGFyZ3VtZW50c1xuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIGZ1bmN0aW9uIGhlbGxvX3dvcmxkKCkgcmV0dXJucyB0ZXh0IGFzICQkXG4gICAqICAgc2VsZWN0ICdIZWxsbyB3b3JsZCc7XG4gICAqICQkIGxhbmd1YWdlIHNxbDtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQ2FsbCBhIFBvc3RncmVzIGZ1bmN0aW9uIHdpdGhvdXQgYXJndW1lbnRzXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBcIkhlbGxvIHdvcmxkXCIsXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgQ2FsbCBhIFBvc3RncmVzIGZ1bmN0aW9uIHdpdGggYXJndW1lbnRzXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLnJwYygnZWNobycsIHsgc2F5OiAn8J+RiycgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIENhbGwgYSBQb3N0Z3JlcyBmdW5jdGlvbiB3aXRoIGFyZ3VtZW50c1xuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIGZ1bmN0aW9uIGVjaG8oc2F5IHRleHQpIHJldHVybnMgdGV4dCBhcyAkJFxuICAgKiAgIHNlbGVjdCBzYXk7XG4gICAqICQkIGxhbmd1YWdlIHNxbDtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQ2FsbCBhIFBvc3RncmVzIGZ1bmN0aW9uIHdpdGggYXJndW1lbnRzXG4gICAqIGBgYGpzb25cbiAgICogICB7XG4gICAqICAgICBcImRhdGFcIjogXCLwn5GLXCIsXG4gICAqICAgICBcInN0YXR1c1wiOiAyMDAsXG4gICAqICAgICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqICAgfVxuICAgKlxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBCdWxrIHByb2Nlc3NpbmdcbiAgICogWW91IGNhbiBwcm9jZXNzIGxhcmdlIHBheWxvYWRzIGJ5IHBhc3NpbmcgaW4gYW4gYXJyYXkgYXMgYW4gYXJndW1lbnQuXG4gICAqXG4gICAqIEBleGFtcGxlIEJ1bGsgcHJvY2Vzc2luZ1xuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5ycGMoJ2FkZF9vbmVfZWFjaCcsIHsgYXJyOiBbMSwgMiwgM10gfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIEJ1bGsgcHJvY2Vzc2luZ1xuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIGZ1bmN0aW9uIGFkZF9vbmVfZWFjaChhcnIgaW50W10pIHJldHVybnMgaW50W10gYXMgJCRcbiAgICogICBzZWxlY3QgYXJyYXlfYWdnKG4gKyAxKSBmcm9tIHVubmVzdChhcnIpIGFzIG47XG4gICAqICQkIGxhbmd1YWdlIHNxbDtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQnVsayBwcm9jZXNzaW5nXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICAyLFxuICAgKiAgICAgMyxcbiAgICogICAgIDRcbiAgICogICBdLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gQ2FsbCBhIFBvc3RncmVzIGZ1bmN0aW9uIHdpdGggZmlsdGVyc1xuICAgKiBQb3N0Z3JlcyBmdW5jdGlvbnMgdGhhdCByZXR1cm4gdGFibGVzIGNhbiBhbHNvIGJlIGNvbWJpbmVkIHdpdGggW0ZpbHRlcnNdKC9kb2NzL3JlZmVyZW5jZS9qYXZhc2NyaXB0L3VzaW5nLWZpbHRlcnMpIGFuZCBbTW9kaWZpZXJzXSgvZG9jcy9yZWZlcmVuY2UvamF2YXNjcmlwdC91c2luZy1tb2RpZmllcnMpLlxuICAgKlxuICAgKiBAZXhhbXBsZSBDYWxsIGEgUG9zdGdyZXMgZnVuY3Rpb24gd2l0aCBmaWx0ZXJzXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLnJwYygnbGlzdF9zdG9yZWRfY291bnRyaWVzJylcbiAgICogICAuZXEoJ2lkJywgMSlcbiAgICogICAuc2luZ2xlKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlU3FsIENhbGwgYSBQb3N0Z3JlcyBmdW5jdGlvbiB3aXRoIGZpbHRlcnNcbiAgICogYGBgc3FsXG4gICAqIGNyZWF0ZSB0YWJsZVxuICAgKiAgIGNvdW50cmllcyAoaWQgaW50OCBwcmltYXJ5IGtleSwgbmFtZSB0ZXh0KTtcbiAgICpcbiAgICogaW5zZXJ0IGludG9cbiAgICogICBjb3VudHJpZXMgKGlkLCBuYW1lKVxuICAgKiB2YWx1ZXNcbiAgICogICAoMSwgJ1JvaGFuJyksXG4gICAqICAgKDIsICdUaGUgU2hpcmUnKTtcbiAgICpcbiAgICogY3JlYXRlIGZ1bmN0aW9uIGxpc3Rfc3RvcmVkX2NvdW50cmllcygpIHJldHVybnMgc2V0b2YgY291bnRyaWVzIGFzICQkXG4gICAqICAgc2VsZWN0ICogZnJvbSBjb3VudHJpZXM7XG4gICAqICQkIGxhbmd1YWdlIHNxbDtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQ2FsbCBhIFBvc3RncmVzIGZ1bmN0aW9uIHdpdGggZmlsdGVyc1xuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJpZFwiOiAxLFxuICAgKiAgICAgXCJuYW1lXCI6IFwiUm9oYW5cIlxuICAgKiAgIH0sXG4gICAqICAgXCJzdGF0dXNcIjogMjAwLFxuICAgKiAgIFwic3RhdHVzVGV4dFwiOiBcIk9LXCJcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgQ2FsbCBhIHJlYWQtb25seSBQb3N0Z3JlcyBmdW5jdGlvblxuICAgKiBgYGB0c1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5ycGMoJ2hlbGxvX3dvcmxkJywgdW5kZWZpbmVkLCB7IGdldDogdHJ1ZSB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVTcWwgQ2FsbCBhIHJlYWQtb25seSBQb3N0Z3JlcyBmdW5jdGlvblxuICAgKiBgYGBzcWxcbiAgICogY3JlYXRlIGZ1bmN0aW9uIGhlbGxvX3dvcmxkKCkgcmV0dXJucyB0ZXh0IGFzICQkXG4gICAqICAgc2VsZWN0ICdIZWxsbyB3b3JsZCc7XG4gICAqICQkIGxhbmd1YWdlIHNxbDtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgQ2FsbCBhIHJlYWQtb25seSBQb3N0Z3JlcyBmdW5jdGlvblxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogXCJIZWxsbyB3b3JsZFwiLFxuICAgKiAgIFwic3RhdHVzXCI6IDIwMCxcbiAgICogICBcInN0YXR1c1RleHRcIjogXCJPS1wiXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBycGM8XG4gICAgRm5OYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgU2NoZW1hWydGdW5jdGlvbnMnXSxcbiAgICBBcmdzIGV4dGVuZHMgU2NoZW1hWydGdW5jdGlvbnMnXVtGbk5hbWVdWydBcmdzJ10gPSBuZXZlcixcbiAgICBGaWx0ZXJCdWlsZGVyIGV4dGVuZHMgR2V0UnBjRnVuY3Rpb25GaWx0ZXJCdWlsZGVyQnlBcmdzPFxuICAgICAgU2NoZW1hLFxuICAgICAgRm5OYW1lLFxuICAgICAgQXJnc1xuICAgID4gPSBHZXRScGNGdW5jdGlvbkZpbHRlckJ1aWxkZXJCeUFyZ3M8U2NoZW1hLCBGbk5hbWUsIEFyZ3M+LFxuICA+KFxuICAgIGZuOiBGbk5hbWUsXG4gICAgYXJnczogQXJncyA9IHt9IGFzIEFyZ3MsXG4gICAge1xuICAgICAgaGVhZCA9IGZhbHNlLFxuICAgICAgZ2V0ID0gZmFsc2UsXG4gICAgICBjb3VudCxcbiAgICB9OiB7XG4gICAgICBoZWFkPzogYm9vbGVhblxuICAgICAgZ2V0PzogYm9vbGVhblxuICAgICAgY291bnQ/OiAnZXhhY3QnIHwgJ3BsYW5uZWQnIHwgJ2VzdGltYXRlZCcgfCAoc3RyaW5nICYge30pXG4gICAgfSA9IHt9XG4gICk6IFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBTY2hlbWEsXG4gICAgRmlsdGVyQnVpbGRlclsnUm93J10sXG4gICAgRmlsdGVyQnVpbGRlclsnUmVzdWx0J10sXG4gICAgRmlsdGVyQnVpbGRlclsnUmVsYXRpb25OYW1lJ10sXG4gICAgRmlsdGVyQnVpbGRlclsnUmVsYXRpb25zaGlwcyddLFxuICAgICdSUEMnXG4gID4ge1xuICAgIGxldCBtZXRob2Q6ICdIRUFEJyB8ICdHRVQnIHwgJ1BPU1QnXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChgJHt0aGlzLnVybH0vcnBjLyR7Zm59YClcbiAgICBsZXQgYm9keTogdW5rbm93biB8IHVuZGVmaW5lZFxuICAgIC8vIG9iamVjdHMvYXJyYXlzLW9mLW9iamVjdHMgY2FuJ3QgYmUgc2VyaWFsaXplZCB0byBVUkwgcGFyYW1zLCB1c2UgUE9TVCArIHJldHVybj1taW5pbWFsIGluc3RlYWRcbiAgICBjb25zdCBfaXNPYmplY3QgPSAodjogdW5rbm93bik6IGJvb2xlYW4gPT5cbiAgICAgIHYgIT09IG51bGwgJiYgdHlwZW9mIHYgPT09ICdvYmplY3QnICYmICghQXJyYXkuaXNBcnJheSh2KSB8fCB2LnNvbWUoX2lzT2JqZWN0KSlcbiAgICBjb25zdCBfaGFzT2JqZWN0QXJnID0gaGVhZCAmJiBPYmplY3QudmFsdWVzKGFyZ3MgYXMgb2JqZWN0KS5zb21lKF9pc09iamVjdClcbiAgICBpZiAoX2hhc09iamVjdEFyZykge1xuICAgICAgbWV0aG9kID0gJ1BPU1QnXG4gICAgICBib2R5ID0gYXJnc1xuICAgIH0gZWxzZSBpZiAoaGVhZCB8fCBnZXQpIHtcbiAgICAgIG1ldGhvZCA9IGhlYWQgPyAnSEVBRCcgOiAnR0VUJ1xuICAgICAgT2JqZWN0LmVudHJpZXMoYXJncylcbiAgICAgICAgLy8gcGFyYW1zIHdpdGggdW5kZWZpbmVkIHZhbHVlIG5lZWRzIHRvIGJlIGZpbHRlcmVkIG91dCwgb3RoZXJ3aXNlIGl0J2xsXG4gICAgICAgIC8vIHNob3cgdXAgYXMgYD9wYXJhbT11bmRlZmluZWRgXG4gICAgICAgIC5maWx0ZXIoKFtfLCB2YWx1ZV0pID0+IHZhbHVlICE9PSB1bmRlZmluZWQpXG4gICAgICAgIC8vIGFycmF5IHZhbHVlcyBuZWVkIHNwZWNpYWwgc3ludGF4XG4gICAgICAgIC5tYXAoKFtuYW1lLCB2YWx1ZV0pID0+IFtuYW1lLCBBcnJheS5pc0FycmF5KHZhbHVlKSA/IGB7JHt2YWx1ZS5qb2luKCcsJyl9fWAgOiBgJHt2YWx1ZX1gXSlcbiAgICAgICAgLmZvckVhY2goKFtuYW1lLCB2YWx1ZV0pID0+IHtcbiAgICAgICAgICB1cmwuc2VhcmNoUGFyYW1zLmFwcGVuZChuYW1lLCB2YWx1ZSlcbiAgICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgbWV0aG9kID0gJ1BPU1QnXG4gICAgICBib2R5ID0gYXJnc1xuICAgIH1cblxuICAgIGNvbnN0IGhlYWRlcnMgPSBuZXcgSGVhZGVycyh0aGlzLmhlYWRlcnMpXG4gICAgaWYgKF9oYXNPYmplY3RBcmcpIHtcbiAgICAgIGhlYWRlcnMuc2V0KCdQcmVmZXInLCBjb3VudCA/IGBjb3VudD0ke2NvdW50fSxyZXR1cm49bWluaW1hbGAgOiAncmV0dXJuPW1pbmltYWwnKVxuICAgIH0gZWxzZSBpZiAoY291bnQpIHtcbiAgICAgIGhlYWRlcnMuc2V0KCdQcmVmZXInLCBgY291bnQ9JHtjb3VudH1gKVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgUG9zdGdyZXN0RmlsdGVyQnVpbGRlcih7XG4gICAgICBtZXRob2QsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzLFxuICAgICAgc2NoZW1hOiB0aGlzLnNjaGVtYU5hbWUsXG4gICAgICBib2R5LFxuICAgICAgZmV0Y2g6IHRoaXMuZmV0Y2ggPz8gZmV0Y2gsXG4gICAgICB1cmxMZW5ndGhMaW1pdDogdGhpcy51cmxMZW5ndGhMaW1pdCxcbiAgICAgIHJldHJ5OiB0aGlzLnJldHJ5LFxuICAgIH0pXG4gIH1cbn1cbiIsImltcG9ydCBQb3N0Z3Jlc3RDbGllbnQgZnJvbSAnLi9Qb3N0Z3Jlc3RDbGllbnQnXG5pbXBvcnQgUG9zdGdyZXN0UXVlcnlCdWlsZGVyIGZyb20gJy4vUG9zdGdyZXN0UXVlcnlCdWlsZGVyJ1xuaW1wb3J0IFBvc3RncmVzdEZpbHRlckJ1aWxkZXIgZnJvbSAnLi9Qb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyJ1xuaW1wb3J0IFBvc3RncmVzdFRyYW5zZm9ybUJ1aWxkZXIgZnJvbSAnLi9Qb3N0Z3Jlc3RUcmFuc2Zvcm1CdWlsZGVyJ1xuaW1wb3J0IFBvc3RncmVzdEJ1aWxkZXIgZnJvbSAnLi9Qb3N0Z3Jlc3RCdWlsZGVyJ1xuaW1wb3J0IFBvc3RncmVzdEVycm9yIGZyb20gJy4vUG9zdGdyZXN0RXJyb3InXG5cbmV4cG9ydCB7XG4gIFBvc3RncmVzdENsaWVudCxcbiAgUG9zdGdyZXN0UXVlcnlCdWlsZGVyLFxuICBQb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyLFxuICBQb3N0Z3Jlc3RUcmFuc2Zvcm1CdWlsZGVyLFxuICBQb3N0Z3Jlc3RCdWlsZGVyLFxuICBQb3N0Z3Jlc3RFcnJvcixcbn1cbmV4cG9ydCBkZWZhdWx0IHtcbiAgUG9zdGdyZXN0Q2xpZW50LFxuICBQb3N0Z3Jlc3RRdWVyeUJ1aWxkZXIsXG4gIFBvc3RncmVzdEZpbHRlckJ1aWxkZXIsXG4gIFBvc3RncmVzdFRyYW5zZm9ybUJ1aWxkZXIsXG4gIFBvc3RncmVzdEJ1aWxkZXIsXG4gIFBvc3RncmVzdEVycm9yLFxufVxuZXhwb3J0IHR5cGUge1xuICBQb3N0Z3Jlc3RSZXNwb25zZSxcbiAgUG9zdGdyZXN0UmVzcG9uc2VGYWlsdXJlLFxuICBQb3N0Z3Jlc3RSZXNwb25zZVN1Y2Nlc3MsXG4gIFBvc3RncmVzdFNpbmdsZVJlc3BvbnNlLFxuICBQb3N0Z3Jlc3RNYXliZVNpbmdsZVJlc3BvbnNlLFxufSBmcm9tICcuL3R5cGVzL3R5cGVzJ1xuZXhwb3J0IHR5cGUgeyBDbGllbnRTZXJ2ZXJPcHRpb25zIGFzIFBvc3RncmVzdENsaWVudE9wdGlvbnMgfSBmcm9tICcuL3R5cGVzL2NvbW1vbi9jb21tb24nXG4vLyBodHRwczovL2dpdGh1Yi5jb20vc3VwYWJhc2UvcG9zdGdyZXN0LWpzL2lzc3Vlcy81NTFcbi8vIFRvIGJlIHJlcGxhY2VkIHdpdGggYSBoZWxwZXIgdHlwZSB0aGF0IG9ubHkgdXNlcyBwdWJsaWMgdHlwZXNcbmV4cG9ydCB0eXBlIHsgR2V0UmVzdWx0IGFzIFVuc3RhYmxlR2V0UmVzdWx0IH0gZnJvbSAnLi9zZWxlY3QtcXVlcnktcGFyc2VyL3Jlc3VsdCdcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQU9BLE1BQWEsc0JBQXNCOzs7Ozs7OztBQVNuQyxNQUFhLGlCQUFpQixpQkFDNUIsS0FBSyxJQUFJLE1BQU8sS0FBSyxjQUFjLElBQU07Ozs7OztBQU8zQyxNQUFhLHlCQUF5QixDQUFDLEtBQUssSUFBSTs7OztBQUtoRCxNQUFhLG9CQUFvQjtDQUFDO0NBQU87Q0FBUTtDQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTDNELElBQXFCLGlCQUFyQixjQUE0QyxNQUFNOzs7Ozs7Ozs7Ozs7OztDQWtCaEQsWUFBWSxTQUEyRTtBQUNyRixRQUFNLFFBQVEsUUFBUTtBQUN0QixPQUFLLE9BQU87QUFDWixPQUFLLFVBQVUsUUFBUTtBQUN2QixPQUFLLE9BQU8sUUFBUTtBQUNwQixPQUFLLE9BQU8sUUFBUTs7Q0FHdEIsU0FBeUY7QUFDdkYsU0FBTztHQUNMLE1BQU0sS0FBSztHQUNYLFNBQVMsS0FBSztHQUNkLFNBQVMsS0FBSztHQUNkLE1BQU0sS0FBSztHQUNYLE1BQU0sS0FBSztHQUNaOzs7Ozs7Ozs7O0FDbkNMLFNBQVMsTUFBTSxJQUFZLFFBQXFDO0FBQzlELFFBQU8sSUFBSSxTQUFTLFlBQVk7QUFDOUIsc0RBQUksT0FBUSxTQUFTO0FBQ25CLFlBQVM7QUFDVDs7RUFFRixNQUFNLEtBQUssaUJBQWlCO0FBQzFCLGtEQUFRLG9CQUFvQixTQUFTLFFBQVE7QUFDN0MsWUFBUztLQUNSLEdBQUc7RUFDTixTQUFTLFVBQVU7QUFDakIsZ0JBQWEsR0FBRztBQUNoQixZQUFTOztBQUVYLGlEQUFRLGlCQUFpQixTQUFTLFFBQVE7R0FDMUM7Ozs7O0FBTUosU0FBUyxZQUNQLFFBQ0EsUUFDQSxjQUNBLGNBQ1M7QUFFVCxLQUFJLENBQUMsZ0JBQWdCLGdCQUFnQixvQkFDbkMsUUFBTztBQUlULEtBQUksQ0FBQyxrQkFBa0IsU0FBUyxPQUE2QyxDQUMzRSxRQUFPO0FBSVQsS0FBSSxDQUFDLHVCQUF1QixTQUFTLE9BQWtELENBQ3JGLFFBQU87QUFHVCxRQUFPOztBQUdULElBQThCLG1CQUE5QixNQU1FOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1Q0EsWUFBWSxTQWNUOztPQS9DTyxxQkFBcUI7T0FRckIsZUFBd0I7QUF3Q2hDLE9BQUssU0FBUyxRQUFRO0FBQ3RCLE9BQUssTUFBTSxRQUFRO0FBQ25CLE9BQUssVUFBVSxJQUFJLFFBQVEsUUFBUSxRQUFRO0FBQzNDLE9BQUssU0FBUyxRQUFRO0FBQ3RCLE9BQUssT0FBTyxRQUFRO0FBQ3BCLE9BQUssOENBQXFCLFFBQVEsMkZBQXNCO0FBQ3hELE9BQUssU0FBUyxRQUFRO0FBQ3RCLE9BQUsseUNBQWdCLFFBQVEsc0ZBQWlCO0FBQzlDLE9BQUssNENBQW1CLFFBQVEseUZBQW9CO0FBQ3BELE9BQUssMENBQWlCLFFBQVEsdUZBQWtCO0FBQ2hELE9BQUssaUNBQWUsUUFBUSxnRUFBUztBQUVyQyxNQUFJLFFBQVEsTUFDVixNQUFLLFFBQVEsUUFBUTtNQUVyQixNQUFLLFFBQVE7Ozs7Ozs7Ozs7O0NBYWpCLGVBQThEO0FBQzVELE9BQUsscUJBQXFCO0FBQzFCLFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxRFQsYUFBbUI7QUFDakIsTUFBSSxLQUFLLFFBQVEsSUFBSSxTQUFTLEtBQUssV0FDakMsT0FBTSxJQUFJLE1BQU0seUNBQXlDO0FBRTNELE9BQUssbUJBQW1CO0FBQ3hCLFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CVCxVQUFVLE1BQWMsT0FBcUI7QUFDM0MsT0FBSyxVQUFVLElBQUksUUFBUSxLQUFLLFFBQVE7QUFDeEMsT0FBSyxRQUFRLElBQUksTUFBTSxNQUFNO0FBQzdCLFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBd0JULE1BQU0sU0FBd0I7QUFDNUIsT0FBSyxlQUFlO0FBQ3BCLFNBQU87O0NBR1QsS0FNRSxhQVFBLFlBQ2tDOztBQUVsQyxNQUFJLEtBQUssV0FBVyxRQUFXLFlBRXBCLENBQUMsT0FBTyxPQUFPLENBQUMsU0FBUyxLQUFLLE9BQU8sQ0FDOUMsTUFBSyxRQUFRLElBQUksa0JBQWtCLEtBQUssT0FBTztNQUUvQyxNQUFLLFFBQVEsSUFBSSxtQkFBbUIsS0FBSyxPQUFPO0FBRWxELE1BQUksS0FBSyxXQUFXLFNBQVMsS0FBSyxXQUFXLE9BQzNDLE1BQUssUUFBUSxJQUFJLGdCQUFnQixtQkFBbUI7QUFJdEQsTUFBSSxLQUFLLGtCQUFrQjtHQUN6QixNQUFNLGdCQUFnQixLQUFLLFFBQVEsSUFBSSxTQUFTO0FBQ2hELE9BQUksa0JBQWtCLG9DQUNwQixNQUFLLFFBQVEsSUFBSSxVQUFVLG1EQUFtRDtZQUNyRSxDQUFDLGlCQUFpQixrQkFBa0IsbUJBQzdDLE1BQUssUUFBUSxJQUFJLFVBQVUsa0RBQWtEOztFQU1qRixNQUFNLFNBQVMsS0FBSztFQUdwQixNQUFNLG1CQUFtQixZQU1uQjtHQUNKLElBQUksZUFBZTtBQUVuQixVQUFPLE1BQU07SUFNWCxNQUFNQSxVQUFrQyxFQUFFO0FBQzFDLFVBQUssUUFBUSxTQUFTLE9BQU8sUUFBUTtBQUNuQyxhQUFRLE9BQU87TUFDZjtBQUNGLFFBQUksZUFBZSxFQUNqQixTQUFRLG1CQUFtQixPQUFPLGFBQWE7SUFJakQsSUFBSUM7QUFDSixRQUFJO0FBQ0YsYUFBTSxNQUFNLE9BQU9DLE1BQUssSUFBSSxVQUFVLEVBQUU7TUFDdEMsUUFBUUEsTUFBSztNQUNiO01BQ0EsTUFBTSxLQUFLLFVBQVVBLE1BQUssT0FBTyxHQUFHLFVBQ2xDLE9BQU8sVUFBVSxXQUFXLE1BQU0sVUFBVSxHQUFHLE1BQ2hEO01BQ0QsUUFBUUEsTUFBSztNQUNkLENBQUM7YUFLS0MsWUFBaUI7QUFFeEIsa0VBQUksV0FBWSxVQUFTLHlFQUFnQixXQUFZLFVBQVMsWUFDNUQsT0FBTTtBQUlSLFNBQUksQ0FBQyxrQkFBa0IsU0FBU0QsTUFBSyxPQUE2QyxDQUNoRixPQUFNO0FBSVIsU0FBSUEsTUFBSyxnQkFBZ0IsZUFBZSxxQkFBcUI7TUFDM0QsTUFBTSxRQUFRLGNBQWMsYUFBYTtBQUN6QztBQUNBLFlBQU0sTUFBTSxPQUFPQSxNQUFLLE9BQU87QUFDL0I7O0FBSUYsV0FBTTs7QUFJUixRQUFJLFlBQVlBLE1BQUssUUFBUUUsTUFBSSxRQUFRLGNBQWNGLE1BQUssYUFBYSxFQUFFOztLQUN6RSxNQUFNLHVEQUFtQkUsTUFBSSxxRUFBUyxJQUFJLGNBQWMsK0RBQUk7S0FDNUQsTUFBTSxRQUNKLHFCQUFxQixPQUNqQixLQUFLLElBQUksR0FBRyxTQUFTLGtCQUFrQixHQUFHLElBQUksRUFBRSxHQUFHLE1BQ25ELGNBQWMsYUFBYTtBQUNqQyxXQUFNQSxNQUFJLE1BQU07QUFDaEI7QUFDQSxXQUFNLE1BQU0sT0FBT0YsTUFBSyxPQUFPO0FBQy9COztBQUdGLFdBQU8sTUFBTUEsTUFBSyxnQkFBZ0JFLE1BQUk7OztFQUkxQyxJQUFJLE1BQU0sa0JBQWtCO0FBRTVCLE1BQUksQ0FBQyxLQUFLLG1CQUNSLE9BQU0sSUFBSSxPQUFPLGVBQWU7O0dBSTlCLElBQUksZUFBZTtHQUNuQixJQUFJLE9BQU87R0FDWCxJQUFJLE9BQU87R0FHWCxNQUFNLGdFQUFRLFdBQVk7QUFDMUIsT0FBSSxPQUFPOztJQUNULE1BQU0sK0VBQWUsTUFBTyxrRUFBVztJQUN2QyxNQUFNLHlFQUFZLE1BQU8seURBQVE7QUFFakMsbUJBQWUsK0VBQUcsV0FBWSxtRUFBUSxhQUFhLDREQUFJLFdBQVk7QUFDbkUsb0JBQWdCLCtFQUFrQixNQUFPLHlEQUFRLFFBQVEsSUFBSTtBQUM3RCxRQUFJLFVBQ0YsaUJBQWdCLEtBQUssVUFBVTtBQUVqQyxzREFBSSxNQUFPLE1BQ1QsaUJBQWdCLEtBQUssTUFBTTtVQUV4Qjs7QUFFTCxnR0FBZSxXQUFZLHNFQUFTOztHQUl0QyxNQUFNLFlBQVksS0FBSyxJQUFJLFVBQVUsQ0FBQztBQUd0QyxnRUFBSSxXQUFZLFVBQVMseUVBQWdCLFdBQVksVUFBUyxhQUFhO0FBQ3pFLFdBQU87QUFDUCxXQUFPO0FBRVAsUUFBSSxZQUFZLEtBQUssZUFDbkIsU0FBUSwrQkFBK0IsVUFBVTs2REFLbkQsTUFBTyxVQUFTLHlFQUNoQixNQUFPLFVBQVMsNEJBQ2hCO0FBQ0EsV0FBTztBQUNQLFdBQU87QUFFUCxRQUFJLFlBQVksS0FBSyxlQUNuQixTQUFRLHlCQUF5QixVQUFVOztBQUkvQyxVQUFPO0lBQ0wsU0FBUztJQUNULE9BQU87S0FDTCxTQUFTLGdGQUFHLFdBQVkscUVBQVEsYUFBYSw0REFBSSxXQUFZO0tBQzdELFNBQVM7S0FDSDtLQUNBO0tBQ1A7SUFDRCxNQUFNO0lBQ04sT0FBTztJQUNQLFFBQVE7SUFDUixZQUFZO0lBQ2I7SUFDRDtBQUdKLFNBQ0UsSUFLQSxLQUFLLGFBQWEsV0FBVzs7Ozs7Q0FNakMsTUFBYyxnQkFBZ0IsS0FPM0I7O0VBQ0QsSUFBSSxRQUFRO0VBQ1osSUFBSSxPQUFPO0VBQ1gsSUFBSUMsUUFBdUI7RUFDM0IsSUFBSSxTQUFTLElBQUk7RUFDakIsSUFBSSxhQUFhLElBQUk7QUFFckIsTUFBSSxJQUFJLElBQUk7O0FBQ1YsT0FBSUgsT0FBSyxXQUFXLFFBQVE7O0lBQzFCLE1BQU0sT0FBTyxNQUFNLElBQUksTUFBTTtBQUM3QixRQUFJLFNBQVMsSUFBSSxZQUVOQSxPQUFLLFFBQVEsSUFBSSxTQUFTLEtBQUssV0FDeEMsUUFBTzthQUVQQSxPQUFLLFFBQVEsSUFBSSxTQUFTLDBCQUMxQkEsT0FBSyxRQUFRLElBQUksU0FBUyx3RUFBRSxTQUFTLGtDQUFrQyxFQUV2RSxRQUFPO1FBRVAsS0FBSTtBQUNGLFlBQU8sS0FBSyxNQUFNLEtBQUs7c0JBQ2pCO0FBRU4sYUFBUSxFQUFFLFNBQVMsTUFBTTtBQUN6QixZQUFPO0FBRVAsU0FBSUEsT0FBSyxtQkFDUCxPQUFNLElBQUksZUFBZTtNQUFFLFNBQVM7TUFBTSxTQUFTO01BQUksTUFBTTtNQUFJLE1BQU07TUFBSSxDQUFDOzs7R0FNcEYsTUFBTSxvQ0FBY0EsT0FBSyxRQUFRLElBQUksU0FBUywwRUFBRSxNQUFNLGtDQUFrQztHQUN4RixNQUFNLG9DQUFlLElBQUksUUFBUSxJQUFJLGdCQUFnQix3RUFBRSxNQUFNLElBQUk7QUFDakUsT0FBSSxlQUFlLGdCQUFnQixhQUFhLFNBQVMsRUFDdkQsU0FBUSxTQUFTLGFBQWEsR0FBRztBQUluQyxPQUFJQSxPQUFLLGlCQUFpQixNQUFNLFFBQVEsS0FBSyxDQUMzQyxLQUFJLEtBQUssU0FBUyxHQUFHO0FBQ25CLFlBQVE7S0FFTixNQUFNO0tBQ04sU0FBUyxtQkFBbUIsS0FBSyxPQUFPO0tBQ3hDLE1BQU07S0FDTixTQUFTO0tBQ1Y7QUFDRCxXQUFPO0FBQ1AsWUFBUTtBQUNSLGFBQVM7QUFDVCxpQkFBYTtjQUNKLEtBQUssV0FBVyxFQUN6QixRQUFPLEtBQUs7T0FFWixRQUFPO1NBR047R0FDTCxNQUFNLE9BQU8sTUFBTSxJQUFJLE1BQU07QUFFN0IsT0FBSTtBQUNGLFlBQVEsS0FBSyxNQUFNLEtBQUs7QUFHeEIsUUFBSSxNQUFNLFFBQVEsTUFBTSxJQUFJLElBQUksV0FBVyxLQUFLO0FBQzlDLFlBQU8sRUFBRTtBQUNULGFBQVE7QUFDUixjQUFTO0FBQ1Qsa0JBQWE7O3NCQUVUO0FBRU4sUUFBSSxJQUFJLFdBQVcsT0FBTyxTQUFTLElBQUk7QUFDckMsY0FBUztBQUNULGtCQUFhO1VBRWIsU0FBUSxFQUNOLFNBQVMsTUFDVjs7QUFJTCxPQUFJLFNBQVNBLE9BQUssbUJBQ2hCLE9BQU0sSUFBSSxlQUFlLE1BQU07O0FBSW5DLFNBQU87R0FDTCxTQUFTLFVBQVU7R0FDbkI7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNEOzs7Ozs7Ozs7OztDQVlILFVBSUU7O0FBRUEsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUdULGdCQVlFO0FBQ0EsU0FBTzs7Ozs7O0FDM3JCWCxJQUFxQiw0QkFBckIsY0FTVSxpQkFBc0Q7Q0FDOUQsZUFTRTtBQUNBLFNBQU8sTUFBTSxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlEN0IsT0FJRSxTQWNBO0VBRUEsSUFBSSxTQUFTO0VBQ2IsTUFBTSxrQkFBa0IsbURBQVcsS0FDaEMsTUFBTSxHQUFHLENBQ1QsS0FBSyxNQUFNO0FBQ1YsT0FBSSxLQUFLLEtBQUssRUFBRSxJQUFJLENBQUMsT0FDbkIsUUFBTztBQUVULE9BQUksTUFBTSxLQUNSLFVBQVMsQ0FBQztBQUVaLFVBQU87SUFDUCxDQUNELEtBQUssR0FBRztBQUNYLE9BQUssSUFBSSxhQUFhLElBQUksVUFBVSxlQUFlO0FBQ25ELE9BQUssUUFBUSxPQUFPLFVBQVUsd0JBQXdCO0FBQ3RELFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbU9ULE1BQ0UsUUFDQSxFQUNFLFlBQVksTUFDWixZQUNBLGNBQ0Esa0JBQWtCLGlCQU1oQixFQUFFLEVBQ0E7RUFDTixNQUFNLE1BQU0sa0JBQWtCLEdBQUcsZ0JBQWdCLFVBQVU7RUFDM0QsTUFBTSxnQkFBZ0IsS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJO0FBRXBELE9BQUssSUFBSSxhQUFhLElBQ3BCLEtBQ0EsR0FBRyxnQkFBZ0IsR0FBRyxjQUFjLEtBQUssS0FBSyxPQUFPLEdBQUcsWUFBWSxRQUFRLFNBQzFFLGVBQWUsU0FBWSxLQUFLLGFBQWEsZ0JBQWdCLGVBRWhFO0FBQ0QsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUdULE1BQ0UsTUFDQSxFQUNFLGNBQ0Esa0JBQWtCLGlCQUNxQyxFQUFFLEVBQ3JEO0VBQ04sTUFBTSxNQUFNLE9BQU8sb0JBQW9CLGNBQWMsVUFBVSxHQUFHLGdCQUFnQjtBQUNsRixPQUFLLElBQUksYUFBYSxJQUFJLEtBQUssR0FBRyxPQUFPO0FBQ3pDLFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBEVCxNQUNFLE1BQ0EsSUFDQSxFQUNFLGNBQ0Esa0JBQWtCLGlCQUNxQyxFQUFFLEVBQ3JEO0VBQ04sTUFBTSxZQUNKLE9BQU8sb0JBQW9CLGNBQWMsV0FBVyxHQUFHLGdCQUFnQjtFQUN6RSxNQUFNLFdBQVcsT0FBTyxvQkFBb0IsY0FBYyxVQUFVLEdBQUcsZ0JBQWdCO0FBQ3ZGLE9BQUssSUFBSSxhQUFhLElBQUksV0FBVyxHQUFHLE9BQU87QUFFL0MsT0FBSyxJQUFJLGFBQWEsSUFBSSxVQUFVLEdBQUcsS0FBSyxPQUFPLElBQUk7QUFDdkQsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxRVQsWUFBWSxRQUEyQjtBQUNyQyxPQUFLLFNBQVM7QUFDZCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTZDVCxTQUlFO0FBQ0EsT0FBSyxRQUFRLElBQUksVUFBVSxvQ0FBb0M7QUFDL0QsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQ1QsY0FFcUU7QUFHbkUsT0FBSyxnQkFBZ0I7QUFDckIsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQ1QsTUFBNkQ7QUFDM0QsT0FBSyxRQUFRLElBQUksVUFBVSxXQUFXO0FBQ3RDLFNBQU87Ozs7Ozs7O0NBU1QsVUFBa0Y7QUFDaEYsT0FBSyxRQUFRLElBQUksVUFBVSx1QkFBdUI7QUFDbEQsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtR1QsUUFBUSxFQUNOLFVBQVUsT0FDVixVQUFVLE9BQ1YsV0FBVyxPQUNYLFVBQVUsT0FDVixNQUFNLE9BQ04sU0FBUyxXQVFQLEVBQUUsRUFBRTs7RUFDTixNQUFNLFVBQVU7R0FDZCxVQUFVLFlBQVk7R0FDdEIsVUFBVSxZQUFZO0dBQ3RCLFdBQVcsYUFBYTtHQUN4QixVQUFVLFlBQVk7R0FDdEIsTUFBTSxRQUFRO0dBQ2YsQ0FDRSxPQUFPLFFBQVEsQ0FDZixLQUFLLElBQUk7RUFFWixNQUFNLG9DQUFlLEtBQUssUUFBUSxJQUFJLFNBQVMsaUVBQUk7QUFDbkQsT0FBSyxRQUFRLElBQ1gsVUFDQSw4QkFBOEIsT0FBTyxTQUFTLGFBQWEsYUFBYSxRQUFRLEdBQ2pGO0FBQ0QsTUFBSSxXQUFXLE9BQ2IsUUFBTztNQU1QLFFBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQ1gsV0FBaUI7QUFDZixPQUFLLFFBQVEsT0FBTyxVQUFVLGNBQWM7QUFDNUMsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQ1QsVUFTRTtBQUNBLFNBQU87Ozs7Ozs7Ozs7O0NBcUJULFlBQVksTUFLaUU7QUFDM0UsT0FBSyxRQUFRLE9BQU8sVUFBVSxrQkFBa0I7QUFDaEQsT0FBSyxRQUFRLE9BQU8sVUFBVSxnQkFBZ0IsT0FBTztBQUNyRCxTQUFPOzs7Ozs7QUNuK0JYLE1BQU0sK0NBQStCLElBQUksT0FBTyxRQUFRO0FBMkR4RCxJQUFxQix5QkFBckIsY0FTVSwwQkFTUjtDQUNBLGVBU0U7QUFDQSxTQUFPLE1BQU0sY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEQ3QixHQUNFLFFBT0EsT0FLTTtBQUNOLE9BQUssSUFBSSxhQUFhLE9BQU8sUUFBa0IsTUFBTSxRQUFRO0FBQzdELFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0RULElBQ0UsUUFPQSxPQUtNO0FBQ04sT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFrQixPQUFPLFFBQVE7QUFDOUQsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxRFQsR0FBRyxRQUFnQixPQUFzQjtBQUN2QyxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsTUFBTSxRQUFRO0FBQ25ELFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcURULElBQUksUUFBZ0IsT0FBc0I7QUFDeEMsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE9BQU8sUUFBUTtBQUNwRCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaURULEdBQUcsUUFBZ0IsT0FBc0I7QUFDdkMsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE1BQU0sUUFBUTtBQUNuRCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFEVCxJQUFJLFFBQWdCLE9BQXNCO0FBQ3hDLE9BQUssSUFBSSxhQUFhLE9BQU8sUUFBUSxPQUFPLFFBQVE7QUFDcEQsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWlEVCxLQUFLLFFBQWdCLFNBQXVCO0FBQzFDLE9BQUssSUFBSSxhQUFhLE9BQU8sUUFBUSxRQUFRLFVBQVU7QUFDdkQsU0FBTzs7Ozs7Ozs7Ozs7Q0FpQlQsVUFBVSxRQUFnQixVQUFtQztBQUMzRCxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsY0FBYyxTQUFTLEtBQUssSUFBSSxDQUFDLEdBQUc7QUFDekUsU0FBTzs7Ozs7Ozs7Ozs7Q0FpQlQsVUFBVSxRQUFnQixVQUFtQztBQUMzRCxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsY0FBYyxTQUFTLEtBQUssSUFBSSxDQUFDLEdBQUc7QUFDekUsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWlEVCxNQUFNLFFBQWdCLFNBQXVCO0FBQzNDLE9BQUssSUFBSSxhQUFhLE9BQU8sUUFBUSxTQUFTLFVBQVU7QUFDeEQsU0FBTzs7Ozs7Ozs7Ozs7Q0FpQlQsV0FBVyxRQUFnQixVQUFtQztBQUM1RCxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsZUFBZSxTQUFTLEtBQUssSUFBSSxDQUFDLEdBQUc7QUFDMUUsU0FBTzs7Ozs7Ozs7Ozs7Q0FpQlQsV0FBVyxRQUFnQixVQUFtQztBQUM1RCxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsZUFBZSxTQUFTLEtBQUssSUFBSSxDQUFDLEdBQUc7QUFDMUUsU0FBTzs7Ozs7Ozs7O0NBWVQsV0FBVyxRQUFnQixTQUF1QjtBQUNoRCxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsU0FBUyxVQUFVO0FBQ3hELFNBQU87Ozs7Ozs7OztDQVlULFlBQVksUUFBZ0IsU0FBdUI7QUFDakQsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLFVBQVUsVUFBVTtBQUN6RCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQThEVCxHQUFHLFFBQWdCLE9BQTZCO0FBQzlDLE9BQUssSUFBSSxhQUFhLE9BQU8sUUFBUSxNQUFNLFFBQVE7QUFDbkQsU0FBTzs7Ozs7Ozs7Ozs7O0NBYVQsV0FDRSxRQUNBLE9BS007QUFDTixPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsY0FBYyxRQUFRO0FBQzNELFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbURULEdBQ0UsUUFDQSxRQVVNO0VBQ04sTUFBTSxnQkFBZ0IsTUFBTSxLQUFLLElBQUksSUFBSSxPQUFPLENBQUMsQ0FDOUMsS0FBSyxNQUFNO0FBR1YsT0FBSSxPQUFPLE1BQU0sWUFBWSw2QkFBNkIsS0FBSyxFQUFFLENBQUUsUUFBTyxJQUFJLEVBQUU7T0FDM0UsUUFBTyxHQUFHO0lBQ2YsQ0FDRCxLQUFLLElBQUk7QUFDWixPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsT0FBTyxjQUFjLEdBQUc7QUFDN0QsU0FBTzs7Ozs7Ozs7Q0FTVCxNQUNFLFFBQ0EsUUFPTTtFQUNOLE1BQU0sZ0JBQWdCLE1BQU0sS0FBSyxJQUFJLElBQUksT0FBTyxDQUFDLENBQzlDLEtBQUssTUFBTTtBQUdWLE9BQUksT0FBTyxNQUFNLFlBQVksNkJBQTZCLEtBQUssRUFBRSxDQUFFLFFBQU8sSUFBSSxFQUFFO09BQzNFLFFBQU8sR0FBRztJQUNmLENBQ0QsS0FBSyxJQUFJO0FBQ1osT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLFdBQVcsY0FBYyxHQUFHO0FBQ2pFLFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBeUlULFNBQVMsUUFBZ0IsT0FBb0U7QUFDM0YsTUFBSSxPQUFPLFVBQVUsU0FHbkIsTUFBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE1BQU0sUUFBUTtXQUMxQyxNQUFNLFFBQVEsTUFBTSxDQUU3QixNQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsT0FBTyxNQUFNLEtBQUssSUFBSSxDQUFDLEdBQUc7TUFHL0QsTUFBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE1BQU0sS0FBSyxVQUFVLE1BQU0sR0FBRztBQUVyRSxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwSVQsWUFBWSxRQUFnQixPQUFvRTtBQUM5RixNQUFJLE9BQU8sVUFBVSxTQUVuQixNQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsTUFBTSxRQUFRO1dBQzFDLE1BQU0sUUFBUSxNQUFNLENBRTdCLE1BQUssSUFBSSxhQUFhLE9BQU8sUUFBUSxPQUFPLE1BQU0sS0FBSyxJQUFJLENBQUMsR0FBRztNQUcvRCxNQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsTUFBTSxLQUFLLFVBQVUsTUFBTSxHQUFHO0FBRXJFLFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E2RFQsUUFBUSxRQUFnQixPQUFxQjtBQUMzQyxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsTUFBTSxRQUFRO0FBQ25ELFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBOERULFNBQVMsUUFBZ0IsT0FBcUI7QUFDNUMsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE9BQU8sUUFBUTtBQUNwRCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E0RFQsUUFBUSxRQUFnQixPQUFxQjtBQUMzQyxPQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsTUFBTSxRQUFRO0FBQ25ELFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBOERULFNBQVMsUUFBZ0IsT0FBcUI7QUFDNUMsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE9BQU8sUUFBUTtBQUNwRCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkRULGNBQWMsUUFBZ0IsT0FBcUI7QUFDakQsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE9BQU8sUUFBUTtBQUNwRCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0dULFNBQVMsUUFBZ0IsT0FBMEM7QUFDakUsTUFBSSxPQUFPLFVBQVUsU0FFbkIsTUFBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE1BQU0sUUFBUTtNQUduRCxNQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsT0FBTyxNQUFNLEtBQUssSUFBSSxDQUFDLEdBQUc7QUFFakUsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFIVCxXQUNFLFFBQ0EsT0FDQSxFQUFFLFFBQVEsU0FBdUUsRUFBRSxFQUM3RTtFQUNOLElBQUksV0FBVztBQUNmLE1BQUksU0FBUyxRQUNYLFlBQVc7V0FDRixTQUFTLFNBQ2xCLFlBQVc7V0FDRixTQUFTLFlBQ2xCLFlBQVc7RUFFYixNQUFNLGFBQWEsV0FBVyxTQUFZLEtBQUssSUFBSSxPQUFPO0FBQzFELE9BQUssSUFBSSxhQUFhLE9BQU8sUUFBUSxHQUFHLFNBQVMsS0FBSyxXQUFXLEdBQUcsUUFBUTtBQUM1RSxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaURULE1BQU0sT0FBc0M7QUFDMUMsU0FBTyxRQUFRLE1BQU0sQ0FHbEIsUUFBUSxDQUFDLEdBQUcsV0FBVyxVQUFVLE9BQVUsQ0FDM0MsU0FBUyxDQUFDLFFBQVEsV0FBVztBQUM1QixRQUFLLElBQUksYUFBYSxPQUFPLFFBQVEsTUFBTSxRQUFRO0lBQ25EO0FBQ0osU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1GVCxJQUNFLFFBQ0EsVUFDQSxPQVdLO0FBQ0wsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLE9BQU8sU0FBUyxHQUFHLFFBQVE7QUFDaEUsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEpULEdBQ0UsU0FDQSxFQUNFLGNBQ0Esa0JBQWtCLGlCQUNxQyxFQUFFLEVBQ3JEO0VBQ04sTUFBTSxNQUFNLGtCQUFrQixHQUFHLGdCQUFnQixPQUFPO0FBQ3hELE9BQUssSUFBSSxhQUFhLE9BQU8sS0FBSyxJQUFJLFFBQVEsR0FBRztBQUNqRCxTQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEhULE9BQU8sUUFBZ0IsVUFBa0IsT0FBc0I7QUFDN0QsT0FBSyxJQUFJLGFBQWEsT0FBTyxRQUFRLEdBQUcsU0FBUyxHQUFHLFFBQVE7QUFDNUQsU0FBTzs7Ozs7O0FDaG5FWCxJQUFxQix3QkFBckIsTUFNRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0ErQ0EsWUFDRSxLQUNBLEVBQ0UsVUFBVSxFQUFFLEVBQ1osUUFDQSxnQkFDQSxpQkFBaUIsS0FDakIsU0FRRjtBQUNBLE9BQUssTUFBTTtBQUNYLE9BQUssVUFBVSxJQUFJLFFBQVEsUUFBUTtBQUNuQyxPQUFLLFNBQVM7QUFDZCxPQUFLLFFBQVFJO0FBQ2IsT0FBSyxpQkFBaUI7QUFDdEIsT0FBSyxRQUFROzs7OztDQU1mLEFBQVEsb0JBQW9EO0FBQzFELFNBQU87R0FDTCxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksVUFBVSxDQUFDO0dBQ2pDLFNBQVMsSUFBSSxRQUFRLEtBQUssUUFBUTtHQUNuQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXl5QkgsT0FXRSxTQUNBLFNBWUE7RUFDQSxNQUFNLEVBQUUsT0FBTyxPQUFPLFVBQVUsbURBQVcsRUFBRTtFQUU3QyxNQUFNLFNBQVMsT0FBTyxTQUFTO0VBRS9CLElBQUksU0FBUztFQUNiLE1BQU0sa0JBQWtCLG1EQUFXLEtBQ2hDLE1BQU0sR0FBRyxDQUNULEtBQUssTUFBTTtBQUNWLE9BQUksS0FBSyxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQ25CLFFBQU87QUFFVCxPQUFJLE1BQU0sS0FDUixVQUFTLENBQUM7QUFFWixVQUFPO0lBQ1AsQ0FDRCxLQUFLLEdBQUc7RUFFWCxNQUFNLEVBQUUsS0FBSyxZQUFZLEtBQUssbUJBQW1CO0FBQ2pELE1BQUksYUFBYSxJQUFJLFVBQVUsZUFBZTtBQUU5QyxNQUFJLE1BQ0YsU0FBUSxPQUFPLFVBQVUsU0FBUyxRQUFRO0FBRzVDLFNBQU8sSUFBSSx1QkFBdUI7R0FDaEM7R0FDQTtHQUNBO0dBQ0EsUUFBUSxLQUFLO0dBQ2IsT0FBTyxLQUFLO0dBQ1osZ0JBQWdCLEtBQUs7R0FDckIsT0FBTyxLQUFLO0dBQ2IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EySEosT0FDRSxRQVNBLEVBQ0UsT0FDQSxnQkFBZ0IsU0FJZCxFQUFFLEVBU047O0VBQ0EsTUFBTSxTQUFTO0VBQ2YsTUFBTSxFQUFFLEtBQUssWUFBWSxLQUFLLG1CQUFtQjtBQUVqRCxNQUFJLE1BQ0YsU0FBUSxPQUFPLFVBQVUsU0FBUyxRQUFRO0FBRTVDLE1BQUksQ0FBQyxjQUNILFNBQVEsT0FBTyxVQUFVLGtCQUFrQjtBQUc3QyxNQUFJLE1BQU0sUUFBUSxPQUFPLEVBQUU7R0FDekIsTUFBTSxVQUFVLE9BQU8sUUFBUSxLQUFLLE1BQU0sSUFBSSxPQUFPLE9BQU8sS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQWE7QUFDckYsT0FBSSxRQUFRLFNBQVMsR0FBRztJQUN0QixNQUFNLGdCQUFnQixDQUFDLEdBQUcsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLEtBQUssV0FBVyxJQUFJLE9BQU8sR0FBRztBQUMxRSxRQUFJLGFBQWEsSUFBSSxXQUFXLGNBQWMsS0FBSyxJQUFJLENBQUM7OztBQUk1RCxTQUFPLElBQUksdUJBQXVCO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBLFFBQVEsS0FBSztHQUNiLE1BQU07R0FDTixzQkFBTyxLQUFLLDBEQUFTO0dBQ3JCLGdCQUFnQixLQUFLO0dBQ3JCLE9BQU8sS0FBSztHQUNiLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTZOSixPQUNFLFFBU0EsRUFDRSxZQUNBLG1CQUFtQixPQUNuQixPQUNBLGdCQUFnQixTQU1kLEVBQUUsRUFTTjs7RUFDQSxNQUFNLFNBQVM7RUFDZixNQUFNLEVBQUUsS0FBSyxZQUFZLEtBQUssbUJBQW1CO0FBRWpELFVBQVEsT0FBTyxVQUFVLGNBQWMsbUJBQW1CLFdBQVcsUUFBUSxhQUFhO0FBRTFGLE1BQUksZUFBZSxPQUFXLEtBQUksYUFBYSxJQUFJLGVBQWUsV0FBVztBQUM3RSxNQUFJLE1BQ0YsU0FBUSxPQUFPLFVBQVUsU0FBUyxRQUFRO0FBRTVDLE1BQUksQ0FBQyxjQUNILFNBQVEsT0FBTyxVQUFVLGtCQUFrQjtBQUc3QyxNQUFJLE1BQU0sUUFBUSxPQUFPLEVBQUU7R0FDekIsTUFBTSxVQUFVLE9BQU8sUUFBUSxLQUFLLE1BQU0sSUFBSSxPQUFPLE9BQU8sS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQWE7QUFDckYsT0FBSSxRQUFRLFNBQVMsR0FBRztJQUN0QixNQUFNLGdCQUFnQixDQUFDLEdBQUcsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLEtBQUssV0FBVyxJQUFJLE9BQU8sR0FBRztBQUMxRSxRQUFJLGFBQWEsSUFBSSxXQUFXLGNBQWMsS0FBSyxJQUFJLENBQUM7OztBQUk1RCxTQUFPLElBQUksdUJBQXVCO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBLFFBQVEsS0FBSztHQUNiLE1BQU07R0FDTix1QkFBTyxLQUFLLDREQUFTO0dBQ3JCLGdCQUFnQixLQUFLO0dBQ3JCLE9BQU8sS0FBSztHQUNiLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVKSixPQUNFLFFBSUEsRUFDRSxVQUdFLEVBQUUsRUFTTjs7RUFDQSxNQUFNLFNBQVM7RUFDZixNQUFNLEVBQUUsS0FBSyxZQUFZLEtBQUssbUJBQW1CO0FBRWpELE1BQUksTUFDRixTQUFRLE9BQU8sVUFBVSxTQUFTLFFBQVE7QUFHNUMsU0FBTyxJQUFJLHVCQUF1QjtHQUNoQztHQUNBO0dBQ0E7R0FDQSxRQUFRLEtBQUs7R0FDYixNQUFNO0dBQ04sdUJBQU8sS0FBSyw0REFBUztHQUNyQixnQkFBZ0IsS0FBSztHQUNyQixPQUFPLEtBQUs7R0FDYixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrSUosT0FBTyxFQUNMLFVBR0UsRUFBRSxFQVFKOztFQUNBLE1BQU0sU0FBUztFQUNmLE1BQU0sRUFBRSxLQUFLLFlBQVksS0FBSyxtQkFBbUI7QUFFakQsTUFBSSxNQUNGLFNBQVEsT0FBTyxVQUFVLFNBQVMsUUFBUTtBQUc1QyxTQUFPLElBQUksdUJBQXVCO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBLFFBQVEsS0FBSztHQUNiLHVCQUFPLEtBQUssNERBQVM7R0FDckIsZ0JBQWdCLEtBQUs7R0FDckIsT0FBTyxLQUFLO0dBQ2IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3B0RE4sSUFBcUIsa0JBQXJCLE1BQXFCLGdCQW9CbkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrREEsWUFDRSxLQUNBLEVBQ0UsVUFBVSxFQUFFLEVBQ1osUUFDQSxnQkFDQSxTQUNBLGlCQUFpQixLQUNqQixVQVFFLEVBQUUsRUFDTjtBQUNBLE9BQUssTUFBTTtBQUNYLE9BQUssVUFBVSxJQUFJLFFBQVEsUUFBUTtBQUNuQyxPQUFLLGFBQWE7QUFDbEIsT0FBSyxpQkFBaUI7RUFFdEIsTUFBTSxnQkFBZ0JDLG1EQUFTLFdBQVc7QUFHMUMsTUFBSSxZQUFZLFVBQWEsVUFBVSxFQUNyQyxNQUFLLFNBQVMsT0FBTyxTQUFTO0dBQzVCLE1BQU0sYUFBYSxJQUFJLGlCQUFpQjtHQUN4QyxNQUFNLFlBQVksaUJBQWlCLFdBQVcsT0FBTyxFQUFFLFFBQVE7R0FHL0QsTUFBTSw2REFBaUIsS0FBTTtBQUM3QixPQUFJLGdCQUFnQjtBQUVsQixRQUFJLGVBQWUsU0FBUztBQUMxQixrQkFBYSxVQUFVO0FBQ3ZCLFlBQU8sY0FBYyxPQUFPLEtBQUs7O0lBSW5DLE1BQU0scUJBQXFCO0FBQ3pCLGtCQUFhLFVBQVU7QUFDdkIsZ0JBQVcsT0FBTzs7QUFFcEIsbUJBQWUsaUJBQWlCLFNBQVMsY0FBYyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBRXRFLFdBQU8sY0FBYyx5Q0FDaEIsYUFDSCxRQUFRLFdBQVcsVUFDbkIsQ0FBQyxjQUFjO0FBQ2Ysa0JBQWEsVUFBVTtBQUN2QixvQkFBZSxvQkFBb0IsU0FBUyxhQUFhO01BQ3pEOztBQUdKLFVBQU8sY0FBYyx5Q0FDaEIsYUFDSCxRQUFRLFdBQVcsVUFDbkIsQ0FBQyxjQUFjLGFBQWEsVUFBVSxDQUFDOztNQUczQyxNQUFLLFFBQVE7QUFFZixPQUFLLFFBQVE7Ozs7Ozs7OztDQWdCZixLQUNFLFVBQ3dEO0FBQ3hELE1BQUksQ0FBQyxZQUFZLE9BQU8sYUFBYSxZQUFZLFNBQVMsTUFBTSxLQUFLLEdBQ25FLE9BQU0sSUFBSSxNQUFNLDhEQUE4RDtBQUloRixTQUFPLElBQUksc0JBREMsSUFBSSxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsV0FBVyxFQUNSO0dBQ3BDLFNBQVMsSUFBSSxRQUFRLEtBQUssUUFBUTtHQUNsQyxRQUFRLEtBQUs7R0FDYixPQUFPLEtBQUs7R0FDWixnQkFBZ0IsS0FBSztHQUNyQixPQUFPLEtBQUs7R0FDYixDQUFDOzs7Ozs7Ozs7OztDQVlKLE9BQ0UsUUFNQTtBQUNBLFNBQU8sSUFBSSxnQkFBZ0IsS0FBSyxLQUFLO0dBQ25DLFNBQVMsS0FBSztHQUNkO0dBQ0EsT0FBTyxLQUFLO0dBQ1osZ0JBQWdCLEtBQUs7R0FDckIsT0FBTyxLQUFLO0dBQ2IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3S0osSUFTRSxJQUNBLE9BQWEsRUFBRSxFQUNmLEVBQ0UsT0FBTyxPQUNQLE1BQU0sT0FDTixVQUtFLEVBQUUsRUFTTjs7RUFDQSxJQUFJQztFQUNKLE1BQU0sTUFBTSxJQUFJLElBQUksR0FBRyxLQUFLLElBQUksT0FBTyxLQUFLO0VBQzVDLElBQUlDO0VBRUosTUFBTSxhQUFhLE1BQ2pCLE1BQU0sUUFBUSxPQUFPLE1BQU0sYUFBYSxDQUFDLE1BQU0sUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLFVBQVU7RUFDaEYsTUFBTSxnQkFBZ0IsUUFBUSxPQUFPLE9BQU8sS0FBZSxDQUFDLEtBQUssVUFBVTtBQUMzRSxNQUFJLGVBQWU7QUFDakIsWUFBUztBQUNULFVBQU87YUFDRSxRQUFRLEtBQUs7QUFDdEIsWUFBUyxPQUFPLFNBQVM7QUFDekIsVUFBTyxRQUFRLEtBQUssQ0FHakIsUUFBUSxDQUFDLEdBQUcsV0FBVyxVQUFVLE9BQVUsQ0FFM0MsS0FBSyxDQUFDLE1BQU0sV0FBVyxDQUFDLE1BQU0sTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUMxRixTQUFTLENBQUMsTUFBTSxXQUFXO0FBQzFCLFFBQUksYUFBYSxPQUFPLE1BQU0sTUFBTTtLQUNwQztTQUNDO0FBQ0wsWUFBUztBQUNULFVBQU87O0VBR1QsTUFBTSxVQUFVLElBQUksUUFBUSxLQUFLLFFBQVE7QUFDekMsTUFBSSxjQUNGLFNBQVEsSUFBSSxVQUFVLFFBQVEsU0FBUyxNQUFNLG1CQUFtQixpQkFBaUI7V0FDeEUsTUFDVCxTQUFRLElBQUksVUFBVSxTQUFTLFFBQVE7QUFHekMsU0FBTyxJQUFJLHVCQUF1QjtHQUNoQztHQUNBO0dBQ0E7R0FDQSxRQUFRLEtBQUs7R0FDYjtHQUNBLHNCQUFPLEtBQUssMERBQVM7R0FDckIsZ0JBQWdCLEtBQUs7R0FDckIsT0FBTyxLQUFLO0dBQ2IsQ0FBQzs7Ozs7O0FDN2FOLGtCQUFlO0NBQ2I7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0QiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3XX0=