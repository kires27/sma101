import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Container.vue");import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"

const _sfc_main = {
  __name: "Container",
  props: {
	direction: {
		type: String,
		default: 'column',
		validator: (v) => ['row', 'column'].includes(v)
	},
	hAlign: {
		type: String,
		default: 'start',
		validator: (v) => ['start', 'center', 'end', 'between', 'around', 'evenly'].includes(v)
	},
	vAlign: {
		type: String,
		default: 'center',
		validator: (v) => ['start', 'center', 'end', 'stretch'].includes(v)
	},
	gap: {
		type: String,
		default: 'na',
		validator: (v) => ['na', 'sm', 'md', 'lg'].includes(v)
	},
},
  setup(__props, { expose: __expose }) {
  __expose();



const __returned__ = {  }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { renderSlot as _renderSlot, normalizeClass as _normalizeClass, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _tracer(27,1,_createElementBlock("div", {
    class: _normalizeClass([
		'container',
		`container--${$props.direction}`,
		`container--h-${$props.hAlign}`,
		`container--v-${$props.vAlign}`,
		`container--gap-${$props.gap}`,
	])
  }, [
    _renderSlot(_ctx.$slots, "default", {}, undefined, true)
  ], 2 /* CLASS */)))
}


import "/_nuxt/ui/Container.vue?vue&type=style&index=0&scoped=f54b7fa9&lang.css"

_sfc_main.__hmrId = "f54b7fa9"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-f54b7fa9"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Container.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Container.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQ0EwQkMsb0JBUU07SUFSQSxLQUFLOztnQkFBbUMsZ0JBQVM7a0JBQXNCLGFBQU07a0JBQXNCLGFBQU07b0JBQXdCLFVBQUc7OztJQU96SSxZQUFRIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb250YWluZXIudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5kZWZpbmVQcm9wcyh7XG5cdGRpcmVjdGlvbjoge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRkZWZhdWx0OiAnY29sdW1uJyxcblx0XHR2YWxpZGF0b3I6ICh2KSA9PiBbJ3JvdycsICdjb2x1bW4nXS5pbmNsdWRlcyh2KVxuXHR9LFxuXHRoQWxpZ246IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0ZGVmYXVsdDogJ3N0YXJ0Jyxcblx0XHR2YWxpZGF0b3I6ICh2KSA9PiBbJ3N0YXJ0JywgJ2NlbnRlcicsICdlbmQnLCAnYmV0d2VlbicsICdhcm91bmQnLCAnZXZlbmx5J10uaW5jbHVkZXModilcblx0fSxcblx0dkFsaWduOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGRlZmF1bHQ6ICdjZW50ZXInLFxuXHRcdHZhbGlkYXRvcjogKHYpID0+IFsnc3RhcnQnLCAnY2VudGVyJywgJ2VuZCcsICdzdHJldGNoJ10uaW5jbHVkZXModilcblx0fSxcblx0Z2FwOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGRlZmF1bHQ6ICduYScsXG5cdFx0dmFsaWRhdG9yOiAodikgPT4gWyduYScsICdzbScsICdtZCcsICdsZyddLmluY2x1ZGVzKHYpXG5cdH0sXG59KVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cblx0PGRpdiA6Y2xhc3M9XCJbXG5cdFx0J2NvbnRhaW5lcicsXG5cdFx0YGNvbnRhaW5lci0tJHtkaXJlY3Rpb259YCxcblx0XHRgY29udGFpbmVyLS1oLSR7aEFsaWdufWAsXG5cdFx0YGNvbnRhaW5lci0tdi0ke3ZBbGlnbn1gLFxuXHRcdGBjb250YWluZXItLWdhcC0ke2dhcH1gLFxuXHRdXCI+XG5cdFx0PHNsb3QgLz5cblx0PC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c3R5bGUgc2NvcGVkPlxuLmNvbnRhaW5lciB7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGZsZXg6IDE7XG59XG5cbi5jb250YWluZXItLXJvdyB7XG5cdGZsZXgtZGlyZWN0aW9uOiByb3c7XG59XG5cbi5jb250YWluZXItLWNvbHVtbiB7XG5cdGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG5cbi5jb250YWluZXItLWgtc3RhcnQge1xuXHRqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XG59XG5cbi5jb250YWluZXItLWgtY2VudGVyIHtcblx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5jb250YWluZXItLWgtZW5kIHtcblx0anVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbn1cblxuLmNvbnRhaW5lci0taC1iZXR3ZWVuIHtcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuXG4uY29udGFpbmVyLS1oLWFyb3VuZCB7XG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xufVxuXG4uY29udGFpbmVyLS1oLWV2ZW5seSB7XG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xufVxuXG4uY29udGFpbmVyLS12LXN0YXJ0IHtcblx0YWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG59XG5cbi5jb250YWluZXItLXYtY2VudGVyIHtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmNvbnRhaW5lci0tdi1lbmQge1xuXHRhbGlnbi1pdGVtczogZmxleC1lbmQ7XG59XG5cbi5jb250YWluZXItLXYtc3RyZXRjaCB7XG5cdGFsaWduLWl0ZW1zOiBzdHJldGNoO1xufVxuXG4uY29udGFpbmVyLS1nYXAtbmEge1xuXHRnYXA6IDA7XG59XG5cbi5jb250YWluZXItLWdhcC1zbSB7XG5cdGdhcDogMXJlbTtcbn1cblxuLmNvbnRhaW5lci0tZ2FwLW1kIHtcblx0Z2FwOiAycmVtO1xufVxuXG4uY29udGFpbmVyLS1nYXAtbGcge1xuXHRnYXA6IDRyZW07XG59XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvbW50L2tpcmUvUGVyc29uYWwvUHJvZ3JhbW1pbmcvUHJvamVjdHMvTUVJQy93ZWIvYXBwL3VpL0NvbnRhaW5lci52dWUifQ==