import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/layouts/default.vue");import { default as __nuxt_component_0 } from "/_nuxt/ui/Header.vue";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"
const _sfc_main = {  }
import { resolveComponent as _resolveComponent, createVNode as _createVNode, renderSlot as _renderSlot, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

const _hoisted_1 = { id: "content" }

function _sfc_render(_ctx, _cache) {
  const _component_Header = __nuxt_component_0

  return (_openBlock(), _tracer(5,1,_createElementBlock("main", _hoisted_1, [
    _tracer(6,2,_createVNode(_component_Header)),
    _renderSlot(_ctx.$slots, "default", {}, undefined, true)
  ])))
}


import "/_nuxt/layouts/default.vue?vue&type=style&index=0&scoped=433a9abd&lang.css"

_sfc_main.__hmrId = "433a9abd"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-433a9abd"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/layouts/default.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/layouts/default.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7cUJBSU8sRUFBRSxFQUFDLFNBQVM7Ozs7O29DQUFsQixvQkFHTyxRQUhQLFVBR087Z0JBRk4sYUFBVTtJQUNWLFlBQVEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImRlZmF1bHQudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuXHQ8bWFpbiBpZD1cImNvbnRlbnRcIj5cblx0XHQ8SGVhZGVyIC8+XG5cdFx0PHNsb3QgLz5cblx0PC9tYWluPlxuPC90ZW1wbGF0ZT5cblxuPHN0eWxlIHNjb3BlZD5cbm1haW4jY29udGVudCB7XG5cdG1pbi1oZWlnaHQ6IDEwMHZoO1xuXHRkaXNwbGF5OiBmbGV4O1xuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuPC9zdHlsZT4iXSwiZmlsZSI6Ii9tbnQva2lyZS9QZXJzb25hbC9Qcm9ncmFtbWluZy9Qcm9qZWN0cy9NRUlDL3dlYi9hcHAvbGF5b3V0cy9kZWZhdWx0LnZ1ZSJ9