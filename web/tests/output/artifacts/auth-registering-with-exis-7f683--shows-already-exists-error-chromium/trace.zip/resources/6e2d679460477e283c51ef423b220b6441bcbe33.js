/**
 * Returns a localStorage-like object that stores the key-value pairs in
 * memory.
 */
export function memoryLocalStorageAdapter(store = {}) {
    return {
        getItem: (key) => {
            return store[key] || null;
        },
        setItem: (key, value) => {
            store[key] = value;
        },
        removeItem: (key) => {
            delete store[key];
        },
    };
}
                                         
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWwtc3RvcmFnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9saWIvbG9jYWwtc3RvcmFnZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTs7O0dBR0c7QUFDSCxNQUFNLFVBQVUseUJBQXlCLENBQUMsUUFBbUMsRUFBRTtJQUM3RSxPQUFPO1FBQ0wsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDZixPQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUE7UUFDM0IsQ0FBQztRQUVELE9BQU8sRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUN0QixLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFBO1FBQ3BCLENBQUM7UUFFRCxVQUFVLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUNsQixPQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUNuQixDQUFDO0tBQ0YsQ0FBQTtBQUNILENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdXBwb3J0ZWRTdG9yYWdlIH0gZnJvbSAnLi90eXBlcydcblxuLyoqXG4gKiBSZXR1cm5zIGEgbG9jYWxTdG9yYWdlLWxpa2Ugb2JqZWN0IHRoYXQgc3RvcmVzIHRoZSBrZXktdmFsdWUgcGFpcnMgaW5cbiAqIG1lbW9yeS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1lbW9yeUxvY2FsU3RvcmFnZUFkYXB0ZXIoc3RvcmU6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fSk6IFN1cHBvcnRlZFN0b3JhZ2Uge1xuICByZXR1cm4ge1xuICAgIGdldEl0ZW06IChrZXkpID0+IHtcbiAgICAgIHJldHVybiBzdG9yZVtrZXldIHx8IG51bGxcbiAgICB9LFxuXG4gICAgc2V0SXRlbTogKGtleSwgdmFsdWUpID0+IHtcbiAgICAgIHN0b3JlW2tleV0gPSB2YWx1ZVxuICAgIH0sXG5cbiAgICByZW1vdmVJdGVtOiAoa2V5KSA9PiB7XG4gICAgICBkZWxldGUgc3RvcmVba2V5XVxuICAgIH0sXG4gIH1cbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19