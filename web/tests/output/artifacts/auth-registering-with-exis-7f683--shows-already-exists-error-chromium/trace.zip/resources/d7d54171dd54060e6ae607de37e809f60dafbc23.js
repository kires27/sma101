import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Footer.vue");import { default as __nuxt_component_0 } from "/_nuxt/ui/Branding.vue";
import { default as __nuxt_component_1 } from "/_nuxt/ui/Text.vue";
import { default as __nuxt_component_2 } from "/_nuxt/ui/Input.vue";
import { default as __nuxt_component_3 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@nuxt+icon@2.2.3_magicast@0.5.3_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1_c813b3cb56baa84ac167d87721896486/node_modules/@nuxt/icon/dist/runtime/components/index.js?v=583078ff";
import { default as __nuxt_component_4 } from "/_nuxt/ui/Button.vue";
import { default as __nuxt_component_5 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/components/nuxt-link.js?v=583078ff";
import { default as __nuxt_component_6 } from "/_nuxt/ui/Section.vue";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"
import logo from "/_nuxt/assets/brand/logo.png?import"
import { URI } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/shared/constants/routes.js";



import { ref } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
const _sfc_main = {
  __name: "Footer",
  props: {
	fullMode: {
		type: Boolean,
		default: true,
	},
},
  setup(__props, { expose: __expose }) {
  __expose();



const email = ref("")

const footerLinks = {
	product: [
		{ label: "List of symbols", to: URI.listStocks },
		{ label: "Features", to: "/#features" },
		{ label: "Pricing", to: "/#pricing" },
		{ label: "Roadmap", to: "#" },
	],
	resources: [
		{ label: "Help Center", to: "#" },
		{ label: "Tutorials", to: "#" },
		{ label: "Market Data", to: "#" },
		{ label: "API Docs", to: "#" },
	],
	company: [
		{ label: "About", to: URI.about },
		{ label: "Blog", to: "#" },
		{ label: "Contact", to: "#" },
		{ label: "Support", to: "#" },
	],
}

const year = new Date().getFullYear();

const __returned__ = { email, footerLinks, year, get logo() { return logo }, get URI() { return URI } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { resolveComponent as _resolveComponent, createVNode as _createVNode, createTextVNode as _createTextVNode, withCtx as _withCtx, createElementVNode as _createElementVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString, createCommentVNode as _createCommentVNode } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

const _hoisted_1 = { class: "footer" }
const _hoisted_2 = { key: 0 }
const _hoisted_3 = { class: "footer-col--brand" }
const _hoisted_4 = { style: {"display":"flex"} }
const _hoisted_5 = { class: "footer-col" }
const _hoisted_6 = { class: "footer-links" }
const _hoisted_7 = { class: "footer-col" }
const _hoisted_8 = { class: "footer-links" }
const _hoisted_9 = { class: "footer-col footer-col--last" }
const _hoisted_10 = { class: "footer-links" }
const _hoisted_11 = { class: "footer-legal" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Branding = __nuxt_component_0
  const _component_Text = __nuxt_component_1
  const _component_Input = __nuxt_component_2
  const _component_Icon = __nuxt_component_3
  const _component_Button = __nuxt_component_4
  const _component_NuxtLink = __nuxt_component_5
  const _component_Section = __nuxt_component_6

  return (_openBlock(), _tracer(39,1,_createElementBlock("div", _hoisted_1, [
    ($props.fullMode)
      ? (_openBlock(), _tracer(40,2,_createElementBlock("div", _hoisted_2, [
          _tracer(41,3,_createVNode(_component_Section, {
            width: "lg",
            topMargin: "sm",
            bottomMargin: "sm",
            class: "footer-top"
          }, {
            default: _withCtx(() => [
              _tracer(42,4,_createElementVNode("div", _hoisted_3, [
                _tracer(43,5,_createVNode(_component_Branding, { show: "name" })),
                _tracer(45,5,_createVNode(_component_Text, {
                  variant: "body-sm",
                  tone: "muted",
                  class: "footer-desc"
                }, {
                  default: _withCtx(() => [...(_cache[1] || (_cache[1] = [
                    _createTextVNode(" Make investing easy with powerful fundamental analysis tools and smart watchlists. Track, analyze, and grow your portfolio. ", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                })),
                _tracer(49,5,_createElementVNode("div", _hoisted_4, [
                  _tracer(50,6,_createVNode(_component_Input, {
                    modelValue: $setup.email,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.email) = $event)),
                    type: "email",
                    placeholder: "your@email.com",
                    "has-button": ""
                  }, null, 8 /* PROPS */, ["modelValue"])),
                  _tracer(52,6,_createVNode(_component_Button, { size: "md" }, {
                    default: _withCtx(() => [
                      _tracer(53,7,_createVNode(_component_Icon, { name: "material-symbols:search" }))
                    ]),
                    _: 1 /* STABLE */
                  }))
                ]))
              ])),
              _tracer(58,4,_createElementVNode("div", _hoisted_5, [
                _tracer(59,5,_createVNode(_component_Text, {
                  variant: "label",
                  class: "footer-col-title"
                }, {
                  default: _withCtx(() => [...(_cache[2] || (_cache[2] = [
                    _createTextVNode("Product", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                })),
                _tracer(60,5,_createElementVNode("ul", _hoisted_6, [
                  (_openBlock(true), _tracer(61,6,_createElementBlock(_Fragment, null, _renderList($setup.footerLinks.product, (link) => {
                    return (_openBlock(), _tracer(61,6,_createElementBlock("li", {
                      key: link.label
                    }, [
                      _tracer(62,7,_createVNode(_component_NuxtLink, {
                        to: link.to
                      }, {
                        default: _withCtx(() => [
                          _tracer(63,8,_createVNode(_component_Text, {
                            variant: "body-sm",
                            tone: "muted",
                            link: ""
                          }, {
                            default: _withCtx(() => [
                              _createTextVNode(_toDisplayString(link.label), 1 /* TEXT */)
                            ]),
                            _: 2 /* DYNAMIC */
                          }, 1024 /* DYNAMIC_SLOTS */))
                        ]),
                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["to"]))
                    ])))
                  }), 128 /* KEYED_FRAGMENT */)))
                ]))
              ])),
              _tracer(69,4,_createElementVNode("div", _hoisted_7, [
                _tracer(70,5,_createVNode(_component_Text, {
                  variant: "label",
                  class: "footer-col-title"
                }, {
                  default: _withCtx(() => [...(_cache[3] || (_cache[3] = [
                    _createTextVNode("Resources", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                })),
                _tracer(71,5,_createElementVNode("ul", _hoisted_8, [
                  (_openBlock(true), _tracer(72,6,_createElementBlock(_Fragment, null, _renderList($setup.footerLinks.resources, (link) => {
                    return (_openBlock(), _tracer(72,6,_createElementBlock("li", {
                      key: link.label
                    }, [
                      _tracer(73,7,_createVNode(_component_NuxtLink, {
                        to: link.to
                      }, {
                        default: _withCtx(() => [
                          _tracer(74,8,_createVNode(_component_Text, {
                            variant: "body-sm",
                            tone: "muted",
                            link: ""
                          }, {
                            default: _withCtx(() => [
                              _createTextVNode(_toDisplayString(link.label), 1 /* TEXT */)
                            ]),
                            _: 2 /* DYNAMIC */
                          }, 1024 /* DYNAMIC_SLOTS */))
                        ]),
                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["to"]))
                    ])))
                  }), 128 /* KEYED_FRAGMENT */)))
                ]))
              ])),
              _tracer(80,4,_createElementVNode("div", _hoisted_9, [
                _tracer(81,5,_createVNode(_component_Text, {
                  variant: "label",
                  class: "footer-col-title"
                }, {
                  default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
                    _createTextVNode("Company", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                })),
                _tracer(82,5,_createElementVNode("ul", _hoisted_10, [
                  (_openBlock(true), _tracer(83,6,_createElementBlock(_Fragment, null, _renderList($setup.footerLinks.company, (link) => {
                    return (_openBlock(), _tracer(83,6,_createElementBlock("li", {
                      key: link.label
                    }, [
                      _tracer(84,7,_createVNode(_component_NuxtLink, {
                        to: link.to
                      }, {
                        default: _withCtx(() => [
                          _tracer(85,8,_createVNode(_component_Text, {
                            variant: "body-sm",
                            tone: "muted",
                            link: ""
                          }, {
                            default: _withCtx(() => [
                              _createTextVNode(_toDisplayString(link.label), 1 /* TEXT */)
                            ]),
                            _: 2 /* DYNAMIC */
                          }, 1024 /* DYNAMIC_SLOTS */))
                        ]),
                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["to"]))
                    ])))
                  }), 128 /* KEYED_FRAGMENT */)))
                ]))
              ]))
            ]),
            _: 1 /* STABLE */
          }))
        ])))
      : _createCommentVNode("v-if", true),
    _tracer(93,2,_createVNode(_component_Section, { class: "footer-bottom" }, {
      default: _withCtx(() => [
        _tracer(94,3,_createVNode(_component_Text, {
          variant: "body-sm",
          tone: "muted"
        }, {
          default: _withCtx(() => [
            _createTextVNode("©" + _toDisplayString($setup.year) + " Halite. All rights reserved.", 1 /* TEXT */)
          ]),
          _: 1 /* STABLE */
        })),
        _tracer(95,3,_createElementVNode("div", _hoisted_11, [
          _tracer(96,4,_createVNode(_component_NuxtLink, {
            to: $setup.URI.privacy
          }, {
            default: _withCtx(() => [
              _tracer(97,5,_createVNode(_component_Text, {
                variant: "body-sm",
                tone: "muted",
                link: ""
              }, {
                default: _withCtx(() => [...(_cache[5] || (_cache[5] = [
                  _createTextVNode("Privacy Policy", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }))
            ]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["to"])),
          _tracer(99,4,_createVNode(_component_NuxtLink, {
            to: $setup.URI.terms
          }, {
            default: _withCtx(() => [
              _tracer(100,5,_createVNode(_component_Text, {
                variant: "body-sm",
                tone: "muted",
                link: ""
              }, {
                default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
                  _createTextVNode("Terms of Service", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }))
            ]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["to"])),
          _tracer(102,4,_createVNode(_component_NuxtLink, {
            to: $setup.URI.disclaimer
          }, {
            default: _withCtx(() => [
              _tracer(103,5,_createVNode(_component_Text, {
                variant: "body-sm",
                tone: "muted",
                link: ""
              }, {
                default: _withCtx(() => [...(_cache[7] || (_cache[7] = [
                  _createTextVNode("Disclaimer", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }))
            ]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["to"]))
        ]))
      ]),
      _: 1 /* STABLE */
    }))
  ])))
}


import "/_nuxt/ui/Footer.vue?vue&type=style&index=0&scoped=91df9369&lang.css"

_sfc_main.__hmrId = "91df9369"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-91df9369"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Footer.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Footer.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRXBCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUM7QUFDRjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7O3FCQUkvQixLQUFLLEVBQUMsUUFBUTs7cUJBR1gsS0FBSyxFQUFDLG1CQUFtQjtxQkFPeEIsS0FBc0IsRUFBdEIsa0JBQXNCO3FCQVN2QixLQUFLLEVBQUMsWUFBWTtxQkFFbEIsS0FBSyxFQUFDLGNBQWM7cUJBU3BCLEtBQUssRUFBQyxZQUFZO3FCQUVsQixLQUFLLEVBQUMsY0FBYztxQkFTcEIsS0FBSyxFQUFDLDZCQUE2QjtzQkFFbkMsS0FBSyxFQUFDLGNBQWM7c0JBYXJCLEtBQUssRUFBQyxjQUFjOzs7Ozs7Ozs7OztxQ0F4RDNCLG9CQW9FTSxPQXBFTixVQW9FTTtLQW5FTSxlQUFRO29DQUFuQixvQkFtRE07dUJBbERMLGFBaURVO1lBakRELEtBQUssRUFBQyxJQUFJO1lBQUMsU0FBUyxFQUFDLElBQUk7WUFBQyxZQUFZLEVBQUMsSUFBSTtZQUFDLEtBQUssRUFBQzs7OEJBQzFELENBY007MkJBZE4sb0JBY00sT0FkTixVQWNNOzZCQWJMLGFBQXdCLHVCQUFkLElBQUksRUFBQyxNQUFNOzZCQUVyQixhQUdPO2tCQUhELE9BQU8sRUFBQyxTQUFTO2tCQUFDLElBQUksRUFBQyxPQUFPO2tCQUFDLEtBQUssRUFBQzs7b0NBQWMsQ0FHekQ7cUNBSHlELCtIQUd6RDs7Ozs2QkFDQSxvQkFNTSxPQU5OLFVBTU07K0JBTEwsYUFDUTtnQ0FEUSxZQUFLO2lGQUFMLFlBQUs7b0JBQUUsSUFBSSxFQUFDLE9BQU87b0JBQUMsV0FBVyxFQUFDLGdCQUFnQjtvQkFBQyxZQUFVLEVBQVY7OytCQUVqRSxhQUVTLHFCQUZELElBQUksRUFBQyxJQUFJO3NDQUNoQixDQUF1QzttQ0FBdkMsYUFBdUMsbUJBQWpDLElBQUksRUFBQyx5QkFBeUI7Ozs7OzsyQkFLdkMsb0JBU00sT0FUTixVQVNNOzZCQVJMLGFBQTZEO2tCQUF2RCxPQUFPLEVBQUMsT0FBTztrQkFBQyxLQUFLLEVBQUM7O29DQUFtQixDQUFPO3FDQUFQLFNBQU87Ozs7NkJBQ3RELG9CQU1LLE1BTkwsVUFNSztrREFMSixvQkFJSyw2QkFKYyxrQkFBVyxDQUFDLE9BQU8sR0FBM0IsSUFBSTt1REFBZixvQkFJSztzQkFKb0MsR0FBRyxFQUFFLElBQUksQ0FBQzs7bUNBQ2xELGFBRVc7d0JBRkEsRUFBRSxFQUFFLElBQUksQ0FBQzs7MENBQ25CLENBQWlFO3VDQUFqRSxhQUFpRTs0QkFBM0QsT0FBTyxFQUFDLFNBQVM7NEJBQUMsSUFBSSxFQUFDLE9BQU87NEJBQUMsSUFBSSxFQUFKOzs4Q0FBSyxDQUFnQjtnRUFBYixJQUFJLENBQUMsS0FBSzs7Ozs7Ozs7Ozs7MkJBTTNELG9CQVNNLE9BVE4sVUFTTTs2QkFSTCxhQUErRDtrQkFBekQsT0FBTyxFQUFDLE9BQU87a0JBQUMsS0FBSyxFQUFDOztvQ0FBbUIsQ0FBUztxQ0FBVCxXQUFTOzs7OzZCQUN4RCxvQkFNSyxNQU5MLFVBTUs7a0RBTEosb0JBSUssNkJBSmMsa0JBQVcsQ0FBQyxTQUFTLEdBQTdCLElBQUk7dURBQWYsb0JBSUs7c0JBSnNDLEdBQUcsRUFBRSxJQUFJLENBQUM7O21DQUNwRCxhQUVXO3dCQUZBLEVBQUUsRUFBRSxJQUFJLENBQUM7OzBDQUNuQixDQUFpRTt1Q0FBakUsYUFBaUU7NEJBQTNELE9BQU8sRUFBQyxTQUFTOzRCQUFDLElBQUksRUFBQyxPQUFPOzRCQUFDLElBQUksRUFBSjs7OENBQUssQ0FBZ0I7Z0VBQWIsSUFBSSxDQUFDLEtBQUs7Ozs7Ozs7Ozs7OzJCQU0zRCxvQkFTTSxPQVROLFVBU007NkJBUkwsYUFBNkQ7a0JBQXZELE9BQU8sRUFBQyxPQUFPO2tCQUFDLEtBQUssRUFBQzs7b0NBQW1CLENBQU87cUNBQVAsU0FBTzs7Ozs2QkFDdEQsb0JBTUssTUFOTCxXQU1LO2tEQUxKLG9CQUlLLDZCQUpjLGtCQUFXLENBQUMsT0FBTyxHQUEzQixJQUFJO3VEQUFmLG9CQUlLO3NCQUpvQyxHQUFHLEVBQUUsSUFBSSxDQUFDOzttQ0FDbEQsYUFFVzt3QkFGQSxFQUFFLEVBQUUsSUFBSSxDQUFDOzswQ0FDbkIsQ0FBaUU7dUNBQWpFLGFBQWlFOzRCQUEzRCxPQUFPLEVBQUMsU0FBUzs0QkFBQyxJQUFJLEVBQUMsT0FBTzs0QkFBQyxJQUFJLEVBQUo7OzhDQUFLLENBQWdCO2dFQUFiLElBQUksQ0FBQyxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7O2lCQVE3RCxhQWFVLHNCQWJELEtBQUssRUFBQyxlQUFlO3dCQUM3QixDQUFvRjtxQkFBcEYsYUFBb0Y7VUFBOUUsT0FBTyxFQUFDLFNBQVM7VUFBQyxJQUFJLEVBQUM7OzRCQUFRLENBQUM7NkJBQUQsR0FBQyxvQkFBRyxXQUFJLElBQUcsK0JBQTZCOzs7O3FCQUM3RSxvQkFVTSxPQVZOLFdBVU07dUJBVEwsYUFFVztZQUZBLEVBQUUsRUFBRSxVQUFHLENBQUM7OzhCQUNsQixDQUErRDsyQkFBL0QsYUFBK0Q7Z0JBQXpELE9BQU8sRUFBQyxTQUFTO2dCQUFDLElBQUksRUFBQyxPQUFPO2dCQUFDLElBQUksRUFBSjs7a0NBQUssQ0FBYzttQ0FBZCxnQkFBYzs7Ozs7Ozt1QkFFekQsYUFFVztZQUZBLEVBQUUsRUFBRSxVQUFHLENBQUM7OzhCQUNsQixDQUFpRTs0QkFBakUsYUFBaUU7Z0JBQTNELE9BQU8sRUFBQyxTQUFTO2dCQUFDLElBQUksRUFBQyxPQUFPO2dCQUFDLElBQUksRUFBSjs7a0NBQUssQ0FBZ0I7bUNBQWhCLGtCQUFnQjs7Ozs7Ozt3QkFFM0QsYUFFVztZQUZBLEVBQUUsRUFBRSxVQUFHLENBQUM7OzhCQUNsQixDQUEyRDs0QkFBM0QsYUFBMkQ7Z0JBQXJELE9BQU8sRUFBQyxTQUFTO2dCQUFDLElBQUksRUFBQyxPQUFPO2dCQUFDLElBQUksRUFBSjs7a0NBQUssQ0FBVTttQ0FBVixZQUFVIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGb290ZXIudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgbG9nbyBmcm9tIFwifi9hc3NldHMvYnJhbmQvbG9nby5wbmdcIlxuaW1wb3J0IHsgVVJJIH0gZnJvbSBcIn5+L3NoYXJlZC9jb25zdGFudHMvcm91dGVzXCI7XG5cbmRlZmluZVByb3BzKHtcblx0ZnVsbE1vZGU6IHtcblx0XHR0eXBlOiBCb29sZWFuLFxuXHRcdGRlZmF1bHQ6IHRydWUsXG5cdH0sXG59KVxuXG5jb25zdCBlbWFpbCA9IHJlZihcIlwiKVxuXG5jb25zdCBmb290ZXJMaW5rcyA9IHtcblx0cHJvZHVjdDogW1xuXHRcdHsgbGFiZWw6IFwiTGlzdCBvZiBzeW1ib2xzXCIsIHRvOiBVUkkubGlzdFN0b2NrcyB9LFxuXHRcdHsgbGFiZWw6IFwiRmVhdHVyZXNcIiwgdG86IFwiLyNmZWF0dXJlc1wiIH0sXG5cdFx0eyBsYWJlbDogXCJQcmljaW5nXCIsIHRvOiBcIi8jcHJpY2luZ1wiIH0sXG5cdFx0eyBsYWJlbDogXCJSb2FkbWFwXCIsIHRvOiBcIiNcIiB9LFxuXHRdLFxuXHRyZXNvdXJjZXM6IFtcblx0XHR7IGxhYmVsOiBcIkhlbHAgQ2VudGVyXCIsIHRvOiBcIiNcIiB9LFxuXHRcdHsgbGFiZWw6IFwiVHV0b3JpYWxzXCIsIHRvOiBcIiNcIiB9LFxuXHRcdHsgbGFiZWw6IFwiTWFya2V0IERhdGFcIiwgdG86IFwiI1wiIH0sXG5cdFx0eyBsYWJlbDogXCJBUEkgRG9jc1wiLCB0bzogXCIjXCIgfSxcblx0XSxcblx0Y29tcGFueTogW1xuXHRcdHsgbGFiZWw6IFwiQWJvdXRcIiwgdG86IFVSSS5hYm91dCB9LFxuXHRcdHsgbGFiZWw6IFwiQmxvZ1wiLCB0bzogXCIjXCIgfSxcblx0XHR7IGxhYmVsOiBcIkNvbnRhY3RcIiwgdG86IFwiI1wiIH0sXG5cdFx0eyBsYWJlbDogXCJTdXBwb3J0XCIsIHRvOiBcIiNcIiB9LFxuXHRdLFxufVxuXG5jb25zdCB5ZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpO1xuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cblx0PGRpdiBjbGFzcz1cImZvb3RlclwiPlxuXHRcdDxkaXYgdi1pZj1cImZ1bGxNb2RlXCI+XG5cdFx0XHQ8U2VjdGlvbiB3aWR0aD1cImxnXCIgdG9wTWFyZ2luPVwic21cIiBib3R0b21NYXJnaW49XCJzbVwiIGNsYXNzPVwiZm9vdGVyLXRvcFwiPlxuXHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZm9vdGVyLWNvbC0tYnJhbmRcIj5cblx0XHRcdFx0XHQ8QnJhbmRpbmcgc2hvdz1cIm5hbWVcIiAvPlxuXG5cdFx0XHRcdFx0PFRleHQgdmFyaWFudD1cImJvZHktc21cIiB0b25lPVwibXV0ZWRcIiBjbGFzcz1cImZvb3Rlci1kZXNjXCI+XG5cdFx0XHRcdFx0XHRNYWtlIGludmVzdGluZyBlYXN5IHdpdGggcG93ZXJmdWwgZnVuZGFtZW50YWwgYW5hbHlzaXMgdG9vbHMgYW5kIHNtYXJ0XG5cdFx0XHRcdFx0XHR3YXRjaGxpc3RzLiBUcmFjaywgYW5hbHl6ZSwgYW5kIGdyb3cgeW91ciBwb3J0Zm9saW8uXG5cdFx0XHRcdFx0PC9UZXh0PlxuXHRcdFx0XHRcdDxkaXYgc3R5bGU9XCJkaXNwbGF5OiBmbGV4O1wiPlxuXHRcdFx0XHRcdFx0PElucHV0IHYtbW9kZWw9XCJlbWFpbFwiIHR5cGU9XCJlbWFpbFwiIHBsYWNlaG9sZGVyPVwieW91ckBlbWFpbC5jb21cIiBoYXMtYnV0dG9uPlxuXHRcdFx0XHRcdFx0PC9JbnB1dD5cblx0XHRcdFx0XHRcdDxCdXR0b24gc2l6ZT1cIm1kXCI+XG5cdFx0XHRcdFx0XHRcdDxJY29uIG5hbWU9XCJtYXRlcmlhbC1zeW1ib2xzOnNlYXJjaFwiIC8+XG5cdFx0XHRcdFx0XHQ8L0J1dHRvbj5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PC9kaXY+XG5cblx0XHRcdFx0PGRpdiBjbGFzcz1cImZvb3Rlci1jb2xcIj5cblx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwibGFiZWxcIiBjbGFzcz1cImZvb3Rlci1jb2wtdGl0bGVcIj5Qcm9kdWN0PC9UZXh0PlxuXHRcdFx0XHRcdDx1bCBjbGFzcz1cImZvb3Rlci1saW5rc1wiPlxuXHRcdFx0XHRcdFx0PGxpIHYtZm9yPVwibGluayBpbiBmb290ZXJMaW5rcy5wcm9kdWN0XCIgOmtleT1cImxpbmsubGFiZWxcIj5cblx0XHRcdFx0XHRcdFx0PE51eHRMaW5rIDp0bz1cImxpbmsudG9cIj5cblx0XHRcdFx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwiYm9keS1zbVwiIHRvbmU9XCJtdXRlZFwiIGxpbms+e3sgbGluay5sYWJlbCB9fTwvVGV4dD5cblx0XHRcdFx0XHRcdFx0PC9OdXh0TGluaz5cblx0XHRcdFx0XHRcdDwvbGk+XG5cdFx0XHRcdFx0PC91bD5cblx0XHRcdFx0PC9kaXY+XG5cblx0XHRcdFx0PGRpdiBjbGFzcz1cImZvb3Rlci1jb2xcIj5cblx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwibGFiZWxcIiBjbGFzcz1cImZvb3Rlci1jb2wtdGl0bGVcIj5SZXNvdXJjZXM8L1RleHQ+XG5cdFx0XHRcdFx0PHVsIGNsYXNzPVwiZm9vdGVyLWxpbmtzXCI+XG5cdFx0XHRcdFx0XHQ8bGkgdi1mb3I9XCJsaW5rIGluIGZvb3RlckxpbmtzLnJlc291cmNlc1wiIDprZXk9XCJsaW5rLmxhYmVsXCI+XG5cdFx0XHRcdFx0XHRcdDxOdXh0TGluayA6dG89XCJsaW5rLnRvXCI+XG5cdFx0XHRcdFx0XHRcdFx0PFRleHQgdmFyaWFudD1cImJvZHktc21cIiB0b25lPVwibXV0ZWRcIiBsaW5rPnt7IGxpbmsubGFiZWwgfX08L1RleHQ+XG5cdFx0XHRcdFx0XHRcdDwvTnV4dExpbms+XG5cdFx0XHRcdFx0XHQ8L2xpPlxuXHRcdFx0XHRcdDwvdWw+XG5cdFx0XHRcdDwvZGl2PlxuXG5cdFx0XHRcdDxkaXYgY2xhc3M9XCJmb290ZXItY29sIGZvb3Rlci1jb2wtLWxhc3RcIj5cblx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwibGFiZWxcIiBjbGFzcz1cImZvb3Rlci1jb2wtdGl0bGVcIj5Db21wYW55PC9UZXh0PlxuXHRcdFx0XHRcdDx1bCBjbGFzcz1cImZvb3Rlci1saW5rc1wiPlxuXHRcdFx0XHRcdFx0PGxpIHYtZm9yPVwibGluayBpbiBmb290ZXJMaW5rcy5jb21wYW55XCIgOmtleT1cImxpbmsubGFiZWxcIj5cblx0XHRcdFx0XHRcdFx0PE51eHRMaW5rIDp0bz1cImxpbmsudG9cIj5cblx0XHRcdFx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwiYm9keS1zbVwiIHRvbmU9XCJtdXRlZFwiIGxpbms+e3sgbGluay5sYWJlbCB9fTwvVGV4dD5cblx0XHRcdFx0XHRcdFx0PC9OdXh0TGluaz5cblx0XHRcdFx0XHRcdDwvbGk+XG5cdFx0XHRcdFx0PC91bD5cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHQ8L1NlY3Rpb24+XG5cdFx0PC9kaXY+XG5cblx0XHQ8U2VjdGlvbiBjbGFzcz1cImZvb3Rlci1ib3R0b21cIj5cblx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5LXNtXCIgdG9uZT1cIm11dGVkXCI+wql7eyB5ZWFyIH19IEhhbGl0ZS4gQWxsIHJpZ2h0cyByZXNlcnZlZC48L1RleHQ+XG5cdFx0XHQ8ZGl2IGNsYXNzPVwiZm9vdGVyLWxlZ2FsXCI+XG5cdFx0XHRcdDxOdXh0TGluayA6dG89XCJVUkkucHJpdmFjeVwiPlxuXHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5LXNtXCIgdG9uZT1cIm11dGVkXCIgbGluaz5Qcml2YWN5IFBvbGljeTwvVGV4dD5cblx0XHRcdFx0PC9OdXh0TGluaz5cblx0XHRcdFx0PE51eHRMaW5rIDp0bz1cIlVSSS50ZXJtc1wiPlxuXHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5LXNtXCIgdG9uZT1cIm11dGVkXCIgbGluaz5UZXJtcyBvZiBTZXJ2aWNlPC9UZXh0PlxuXHRcdFx0XHQ8L051eHRMaW5rPlxuXHRcdFx0XHQ8TnV4dExpbmsgOnRvPVwiVVJJLmRpc2NsYWltZXJcIj5cblx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwiYm9keS1zbVwiIHRvbmU9XCJtdXRlZFwiIGxpbms+RGlzY2xhaW1lcjwvVGV4dD5cblx0XHRcdFx0PC9OdXh0TGluaz5cblx0XHRcdDwvZGl2PlxuXHRcdDwvU2VjdGlvbj5cblx0PC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c3R5bGUgc2NvcGVkPlxuLmZvb3RlciB7XG5cdGJvcmRlci10b3A6IDFweCBzb2xpZCB2YXIoLS1ib3JkZXIpO1xuXHRkaXNwbGF5OiBmbGV4O1xuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuXHRhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uZm9vdGVyLXRvcCB7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cblxuLmZvb3Rlci1jb2wtLWJyYW5kIHtcblx0d2lkdGg6IDMwMHB4O1xufVxuXG4uZm9vdGVyLWNvbCB7XG5cdHdpZHRoOiAxNTBweDtcbn1cblxuXG4uZm9vdGVyLWRlc2Mge1xuXHRtYXJnaW4tYm90dG9tOiAxLjI1cmVtO1xufVxuXG4uZm9vdGVyLWNvbC10aXRsZSB7XG5cdGRpc3BsYXk6IGJsb2NrO1xuXHRtYXJnaW4tYm90dG9tOiAxLjI1cmVtO1xufVxuXG4uZm9vdGVyLWxpbmtzIHtcblx0ZGlzcGxheTogZmxleDtcblx0ZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblx0Z2FwOiAwLjZyZW07XG59XG5cbi5mb290ZXItYm90dG9tIHtcblx0Ym9yZGVyLXRvcDogMXB4IHNvbGlkIHZhcigtLWJvcmRlcik7XG5cdHBhZGRpbmc6IDFyZW0gM3JlbTtcblx0ZGlzcGxheTogZmxleDtcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXHRhbGlnbi1pdGVtczogY2VudGVyO1xuXHR3aWR0aDogMTAwJTtcbn1cblxuLmZvb3Rlci1sZWdhbCB7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGdhcDogMS41cmVtO1xufVxuPC9zdHlsZT5cbiJdLCJmaWxlIjoiL21udC9raXJlL1BlcnNvbmFsL1Byb2dyYW1taW5nL1Byb2plY3RzL01FSUMvd2ViL2FwcC91aS9Gb290ZXIudnVlIn0=