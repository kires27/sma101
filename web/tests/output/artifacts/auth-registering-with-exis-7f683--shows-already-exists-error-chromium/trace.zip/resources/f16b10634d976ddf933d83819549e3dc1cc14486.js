/**
 * Lock primitives retained for backwards-compatible imports. The auth client
 * coordinates refreshes itself (deduping in-instance callers onto a shared
 * in-flight promise) and lets the GoTrue server resolve cross-instance races,
 * so it does not invoke any primitive from this module. The functions still
 * work for direct callers that need a navigator.locks-backed or in-process
 * exclusive lock of their own.
 */
import { supportsLocalStorage } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/helpers.js?v=583078ff";
/**
 * @deprecated Debug flag for `navigatorLock` / `processLock`. The auth
 * client ignores both, so this has no client-side effect.
 * @experimental
 */
export const internals = {
    /**
     * @experimental
     */
    debug: !!(globalThis &&
        supportsLocalStorage() &&
        globalThis.localStorage &&
        globalThis.localStorage.getItem('supabase.gotrue-js.locks.debug') === 'true'),
};
/**
 * An error thrown when a lock cannot be acquired after some amount of time.
 *
 * @deprecated The auth client doesn't acquire locks around auth operations,
 * so this error never originates from `supabase.auth.*` calls. Direct callers
 * of `navigatorLock` / `processLock` still receive it on acquire timeout.
 */
export class LockAcquireTimeoutError extends Error {
    constructor(message) {
        super(message);
        this.isAcquireTimeout = true;
    }
}
/**
 * @deprecated The auth client doesn't call `navigator.locks`, so this error
 * never originates from `supabase.auth.*` calls. Direct callers of
 * `navigatorLock` still receive it on acquire timeout.
 */
export class NavigatorLockAcquireTimeoutError extends LockAcquireTimeoutError {
}
/**
 * @deprecated The auth client doesn't run `processLock`, so this error
 * never originates from `supabase.auth.*` calls. Direct callers of
 * `processLock` still receive it on acquire timeout.
 */
export class ProcessLockAcquireTimeoutError extends LockAcquireTimeoutError {
}
/**
 * Implements a global exclusive lock using the Navigator LockManager API. It
 * is available on all browsers released after 2022-03-15 with Safari being the
 * last one to release support. If the API is not available, this function will
 * throw. Make sure you check availablility before configuring {@link
 * GoTrueClient}.
 *
 * You can turn on debugging by setting the `supabase.gotrue-js.locks.debug`
 * local storage item to `true`.
 *
 * Internals:
 *
 * Since the LockManager API does not preserve stack traces for the async
 * function passed in the `request` method, a trick is used where acquiring the
 * lock releases a previously started promise to run the operation in the `fn`
 * function. The lock waits for that promise to finish (with or without error),
 * while the function will finally wait for the result anyway.
 *
 * @param name Name of the lock to be acquired.
 * @param acquireTimeout If negative, no timeout. If 0 an error is thrown if
 *                       the lock can't be acquired without waiting. If positive, the lock acquire
 *                       will time out after so many milliseconds. An error is
 *                       a timeout if it has `isAcquireTimeout` set to true.
 * @param fn The operation to run once the lock is acquired.
 *
 * @deprecated The auth client coordinates refreshes itself and the server
 * resolves concurrent refresh races, so passing `{ lock: navigatorLock }`
 * to it has no effect. You can safely drop the import from your client setup.
 */
export async function navigatorLock(name, acquireTimeout, fn) {
    if (internals.debug) {
        console.log('@supabase/gotrue-js: navigatorLock: acquire lock', name, acquireTimeout);
    }
    const abortController = new globalThis.AbortController();
    let acquireTimeoutTimer;
    if (acquireTimeout > 0) {
        acquireTimeoutTimer = setTimeout(() => {
            abortController.abort();
            if (internals.debug) {
                console.log('@supabase/gotrue-js: navigatorLock acquire timed out', name);
            }
        }, acquireTimeout);
    }
    // MDN article: https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request
    // Wrapping navigator.locks.request() with a plain Promise is done as some
    // libraries like zone.js patch the Promise object to track the execution
    // context. However, it appears that most browsers use an internal promise
    // implementation when using the navigator.locks.request() API causing them
    // to lose context and emit confusing log messages or break certain features.
    // This wrapping is believed to help zone.js track the execution context
    // better.
    await Promise.resolve();
    try {
        return await globalThis.navigator.locks.request(name, acquireTimeout === 0
            ? {
                mode: 'exclusive',
                ifAvailable: true,
            }
            : {
                mode: 'exclusive',
                signal: abortController.signal,
            }, async (lock) => {
            if (lock) {
                // Lock acquired — cancel the acquire-timeout timer so it cannot fire
                // while fn() is running. Without this, a delayed timeout abort would
                // set signal.aborted = true even though we already hold the lock,
                // causing a subsequent steal to be misclassified as "our timeout
                // fired" and triggering a spurious steal-back cascade.
                clearTimeout(acquireTimeoutTimer);
                if (internals.debug) {
                    console.log('@supabase/gotrue-js: navigatorLock: acquired', name, lock.name);
                }
                try {
                    return await fn();
                }
                finally {
                    if (internals.debug) {
                        console.log('@supabase/gotrue-js: navigatorLock: released', name, lock.name);
                    }
                }
            }
            else {
                if (acquireTimeout === 0) {
                    if (internals.debug) {
                        console.log('@supabase/gotrue-js: navigatorLock: not immediately available', name);
                    }
                    throw new NavigatorLockAcquireTimeoutError(`Acquiring an exclusive Navigator LockManager lock "${name}" immediately failed`);
                }
                else {
                    if (internals.debug) {
                        try {
                            const result = await globalThis.navigator.locks.query();
                            console.log('@supabase/gotrue-js: Navigator LockManager state', JSON.stringify(result, null, '  '));
                        }
                        catch (e) {
                            console.warn('@supabase/gotrue-js: Error when querying Navigator LockManager state', e);
                        }
                    }
                    // Browser is not following the Navigator LockManager spec, it
                    // returned a null lock when we didn't use ifAvailable. So we can
                    // pretend the lock is acquired in the name of backward compatibility
                    // and user experience and just run the function.
                    console.warn('@supabase/gotrue-js: Navigator LockManager returned a null lock when using #request without ifAvailable set to true, it appears this browser is not following the LockManager spec https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request');
                    clearTimeout(acquireTimeoutTimer);
                    return await fn();
                }
            }
        });
    }
    catch (e) {
        // Always clear the acquire timeout once the request settles, so it cannot
        // fire later and incorrectly abort/log after a rejection.
        if (acquireTimeout > 0) {
            clearTimeout(acquireTimeoutTimer);
        }
        // DOMException does not extend Error in Node.js, so use structural check
        if (e !== null &&
            typeof e === 'object' &&
            'name' in e &&
            e.name === 'AbortError' &&
            acquireTimeout > 0) {
            if (abortController.signal.aborted) {
                // OUR timeout fired — the lock is genuinely orphaned. Steal it.
                //
                // The lock acquisition was aborted because the timeout fired while the
                // request was still pending. This typically means another lock holder is
                // not releasing the lock, possibly due to React Strict Mode's
                // double-mount/unmount behavior or a component unmounting mid-operation,
                // leaving an orphaned lock.
                //
                // Recovery: use { steal: true } to forcefully acquire the lock. Per the
                // Web Locks API spec, this releases any currently held lock with the same
                // name and grants the request immediately, preempting any queued requests.
                // The previous holder's callback continues running to completion but no
                // longer holds the lock for exclusion purposes.
                //
                // See: https://github.com/supabase/supabase/issues/42505
                if (internals.debug) {
                    console.log('@supabase/gotrue-js: navigatorLock: acquire timeout, recovering by stealing lock', name);
                }
                console.warn(`@supabase/gotrue-js: Lock "${name}" was not released within ${acquireTimeout}ms. ` +
                    'This may indicate an orphaned lock from a component unmount (e.g., React Strict Mode). ' +
                    'Forcefully acquiring the lock to recover.');
                return await Promise.resolve().then(() => globalThis.navigator.locks.request(name, {
                    mode: 'exclusive',
                    steal: true,
                }, async (lock) => {
                    if (lock) {
                        if (internals.debug) {
                            console.log('@supabase/gotrue-js: navigatorLock: recovered (stolen)', name, lock.name);
                        }
                        try {
                            return await fn();
                        }
                        finally {
                            if (internals.debug) {
                                console.log('@supabase/gotrue-js: navigatorLock: released (stolen)', name, lock.name);
                            }
                        }
                    }
                    else {
                        // This should not happen with steal: true, but handle gracefully.
                        console.warn('@supabase/gotrue-js: Navigator LockManager returned null lock even with steal: true');
                        return await fn();
                    }
                }));
            }
            else {
                // We HELD the lock but another request stole it from us.
                // Per the Web Locks spec, our fn() callback is still running as an
                // orphaned background task — do NOT steal back. Stealing back would
                // cause a cascade (A steals B, B steals A, ...) and run fn() a second
                // time concurrently, corrupting auth state.
                // Convert to a typed error so callers (e.g. _autoRefreshTokenTick)
                // can handle/filter it without it leaking to Sentry as a raw AbortError.
                if (internals.debug) {
                    console.log('@supabase/gotrue-js: navigatorLock: lock was stolen by another request', name);
                }
                throw new NavigatorLockAcquireTimeoutError(`Lock "${name}" was released because another request stole it`);
            }
        }
        throw e;
    }
}
const PROCESS_LOCKS = {};
/**
 * Implements a global exclusive lock that works only in the current process.
 * Useful for environments like React Native or other non-browser
 * single-process (i.e. no concept of "tabs") environments.
 *
 * Use {@link #navigatorLock} in browser environments.
 *
 * @param name Name of the lock to be acquired.
 * @param acquireTimeout If negative, no timeout. If 0 an error is thrown if
 *                       the lock can't be acquired without waiting. If positive, the lock acquire
 *                       will time out after so many milliseconds. An error is
 *                       a timeout if it has `isAcquireTimeout` set to true.
 * @param fn The operation to run once the lock is acquired.
 *
 * @deprecated The auth client coordinates refreshes itself and the server
 * resolves concurrent refresh races, so passing `{ lock: processLock }`
 * to it has no effect. You can safely drop the import from your client setup.
 *
 * @example
 * ```ts
 * await processLock('migrate', 5000, async () => {
 *   await runMigration()
 * })
 * ```
 */
export async function processLock(name, acquireTimeout, fn) {
    var _a;
    const previousOperation = (_a = PROCESS_LOCKS[name]) !== null && _a !== void 0 ? _a : Promise.resolve();
    // Wrap previousOperation to handle errors without using .catch()
    // This avoids Firefox content script security errors
    const previousOperationHandled = (async () => {
        try {
            await previousOperation;
            return null;
        }
        catch (e) {
            // ignore error of previous operation that we're waiting to finish
            return null;
        }
    })();
    const currentOperation = (async () => {
        let timeoutId = null;
        try {
            // Wait for either previous operation or timeout
            const timeoutPromise = acquireTimeout >= 0
                ? new Promise((_, reject) => {
                    timeoutId = setTimeout(() => {
                        console.warn(`@supabase/gotrue-js: Lock "${name}" acquisition timed out after ${acquireTimeout}ms. ` +
                            'This may be caused by another operation holding the lock. ' +
                            'Consider increasing lockAcquireTimeout or checking for stuck operations.');
                        reject(new ProcessLockAcquireTimeoutError(`Acquiring process lock with name "${name}" timed out`));
                    }, acquireTimeout);
                })
                : null;
            await Promise.race([previousOperationHandled, timeoutPromise].filter((x) => x));
            // If we reach here, previousOperationHandled won the race
            // Clear the timeout to prevent false warnings
            if (timeoutId !== null) {
                clearTimeout(timeoutId);
            }
        }
        catch (e) {
            // Clear the timeout on error path as well
            if (timeoutId !== null) {
                clearTimeout(timeoutId);
            }
            // Re-throw timeout errors, ignore others
            if (e instanceof LockAcquireTimeoutError) {
                throw e;
            }
            // Fall through to run fn() - previous operation finished with error
        }
        // Previous operations finished and we didn't get a race on the acquire
        // timeout, so the current operation can finally start
        return await fn();
    })();
    PROCESS_LOCKS[name] = (async () => {
        try {
            return await currentOperation;
        }
        catch (e) {
            if (e instanceof LockAcquireTimeoutError) {
                // if the current operation timed out, it doesn't mean that the previous
                // operation finished, so we need continue waiting for it to finish
                try {
                    await previousOperation;
                }
                catch (prevError) {
                    // Ignore previous operation errors
                }
                return null;
            }
            throw e;
        }
    })();
    // finally wait for the current operation to finish successfully, with an
    // error or with an acquire timeout error
    return await currentOperation;
}
                                 
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9ja3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvbGliL2xvY2tzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7O0dBT0c7QUFFSCxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSxXQUFXLENBQUE7QUFFaEQ7Ozs7R0FJRztBQUNILE1BQU0sQ0FBQyxNQUFNLFNBQVMsR0FBRztJQUN2Qjs7T0FFRztJQUNILEtBQUssRUFBRSxDQUFDLENBQUMsQ0FDUCxVQUFVO1FBQ1Ysb0JBQW9CLEVBQUU7UUFDdEIsVUFBVSxDQUFDLFlBQVk7UUFDdkIsVUFBVSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsZ0NBQWdDLENBQUMsS0FBSyxNQUFNLENBQzdFO0NBQ0YsQ0FBQTtBQUVEOzs7Ozs7R0FNRztBQUNILE1BQU0sT0FBZ0IsdUJBQXdCLFNBQVEsS0FBSztJQUd6RCxZQUFZLE9BQWU7UUFDekIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBSEEscUJBQWdCLEdBQUcsSUFBSSxDQUFBO0lBSXZDLENBQUM7Q0FDRjtBQUVEOzs7O0dBSUc7QUFDSCxNQUFNLE9BQU8sZ0NBQWlDLFNBQVEsdUJBQXVCO0NBQUc7QUFDaEY7Ozs7R0FJRztBQUNILE1BQU0sT0FBTyw4QkFBK0IsU0FBUSx1QkFBdUI7Q0FBRztBQUU5RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTRCRztBQUNILE1BQU0sQ0FBQyxLQUFLLFVBQVUsYUFBYSxDQUNqQyxJQUFZLEVBQ1osY0FBc0IsRUFDdEIsRUFBb0I7SUFFcEIsSUFBSSxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsRUFBRSxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUE7SUFDdkYsQ0FBQztJQUVELE1BQU0sZUFBZSxHQUFHLElBQUksVUFBVSxDQUFDLGVBQWUsRUFBRSxDQUFBO0lBRXhELElBQUksbUJBQThELENBQUE7SUFFbEUsSUFBSSxjQUFjLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDdkIsbUJBQW1CLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNwQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUE7WUFDdkIsSUFBSSxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0RBQXNELEVBQUUsSUFBSSxDQUFDLENBQUE7WUFDM0UsQ0FBQztRQUNILENBQUMsRUFBRSxjQUFjLENBQUMsQ0FBQTtJQUNwQixDQUFDO0lBRUQsb0ZBQW9GO0lBRXBGLDBFQUEwRTtJQUMxRSx5RUFBeUU7SUFDekUsMEVBQTBFO0lBQzFFLDJFQUEyRTtJQUMzRSw2RUFBNkU7SUFDN0Usd0VBQXdFO0lBQ3hFLFVBQVU7SUFDVixNQUFNLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQTtJQUV2QixJQUFJLENBQUM7UUFDSCxPQUFPLE1BQU0sVUFBVSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUM3QyxJQUFJLEVBQ0osY0FBYyxLQUFLLENBQUM7WUFDbEIsQ0FBQyxDQUFDO2dCQUNFLElBQUksRUFBRSxXQUFXO2dCQUNqQixXQUFXLEVBQUUsSUFBSTthQUNsQjtZQUNILENBQUMsQ0FBQztnQkFDRSxJQUFJLEVBQUUsV0FBVztnQkFDakIsTUFBTSxFQUFFLGVBQWUsQ0FBQyxNQUFNO2FBQy9CLEVBQ0wsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQ2IsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDVCxxRUFBcUU7Z0JBQ3JFLHFFQUFxRTtnQkFDckUsa0VBQWtFO2dCQUNsRSxpRUFBaUU7Z0JBQ2pFLHVEQUF1RDtnQkFDdkQsWUFBWSxDQUFDLG1CQUFtQixDQUFDLENBQUE7Z0JBRWpDLElBQUksU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLDhDQUE4QyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7Z0JBQzlFLENBQUM7Z0JBRUQsSUFBSSxDQUFDO29CQUNILE9BQU8sTUFBTSxFQUFFLEVBQUUsQ0FBQTtnQkFDbkIsQ0FBQzt3QkFBUyxDQUFDO29CQUNULElBQUksU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLDhDQUE4QyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7b0JBQzlFLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLGNBQWMsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFDekIsSUFBSSxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0RBQStELEVBQUUsSUFBSSxDQUFDLENBQUE7b0JBQ3BGLENBQUM7b0JBRUQsTUFBTSxJQUFJLGdDQUFnQyxDQUN4QyxzREFBc0QsSUFBSSxzQkFBc0IsQ0FDakYsQ0FBQTtnQkFDSCxDQUFDO3FCQUFNLENBQUM7b0JBQ04sSUFBSSxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQ3BCLElBQUksQ0FBQzs0QkFDSCxNQUFNLE1BQU0sR0FBRyxNQUFNLFVBQVUsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFBOzRCQUV2RCxPQUFPLENBQUMsR0FBRyxDQUNULGtEQUFrRCxFQUNsRCxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQ25DLENBQUE7d0JBQ0gsQ0FBQzt3QkFBQyxPQUFPLENBQUMsRUFBRSxDQUFDOzRCQUNYLE9BQU8sQ0FBQyxJQUFJLENBQ1Ysc0VBQXNFLEVBQ3RFLENBQUMsQ0FDRixDQUFBO3dCQUNILENBQUM7b0JBQ0gsQ0FBQztvQkFFRCw4REFBOEQ7b0JBQzlELGlFQUFpRTtvQkFDakUscUVBQXFFO29CQUNyRSxpREFBaUQ7b0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQ1YseVBBQXlQLENBQzFQLENBQUE7b0JBRUQsWUFBWSxDQUFDLG1CQUFtQixDQUFDLENBQUE7b0JBQ2pDLE9BQU8sTUFBTSxFQUFFLEVBQUUsQ0FBQTtnQkFDbkIsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQ0YsQ0FBQTtJQUNILENBQUM7SUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQ1gsMEVBQTBFO1FBQzFFLDBEQUEwRDtRQUMxRCxJQUFJLGNBQWMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN2QixZQUFZLENBQUMsbUJBQW1CLENBQUMsQ0FBQTtRQUNuQyxDQUFDO1FBRUQseUVBQXlFO1FBQ3pFLElBQ0UsQ0FBQyxLQUFLLElBQUk7WUFDVixPQUFPLENBQUMsS0FBSyxRQUFRO1lBQ3JCLE1BQU0sSUFBSSxDQUFDO1lBQ1gsQ0FBQyxDQUFDLElBQUksS0FBSyxZQUFZO1lBQ3ZCLGNBQWMsR0FBRyxDQUFDLEVBQ2xCLENBQUM7WUFDRCxJQUFJLGVBQWUsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ25DLGdFQUFnRTtnQkFDaEUsRUFBRTtnQkFDRix1RUFBdUU7Z0JBQ3ZFLHlFQUF5RTtnQkFDekUsOERBQThEO2dCQUM5RCx5RUFBeUU7Z0JBQ3pFLDRCQUE0QjtnQkFDNUIsRUFBRTtnQkFDRix3RUFBd0U7Z0JBQ3hFLDBFQUEwRTtnQkFDMUUsMkVBQTJFO2dCQUMzRSx3RUFBd0U7Z0JBQ3hFLGdEQUFnRDtnQkFDaEQsRUFBRTtnQkFDRix5REFBeUQ7Z0JBQ3pELElBQUksU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNwQixPQUFPLENBQUMsR0FBRyxDQUNULGtGQUFrRixFQUNsRixJQUFJLENBQ0wsQ0FBQTtnQkFDSCxDQUFDO2dCQUVELE9BQU8sQ0FBQyxJQUFJLENBQ1YsOEJBQThCLElBQUksNkJBQTZCLGNBQWMsTUFBTTtvQkFDakYseUZBQXlGO29CQUN6RiwyQ0FBMkMsQ0FDOUMsQ0FBQTtnQkFFRCxPQUFPLE1BQU0sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FDdkMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUNoQyxJQUFJLEVBQ0o7b0JBQ0UsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLEtBQUssRUFBRSxJQUFJO2lCQUNaLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFO29CQUNiLElBQUksSUFBSSxFQUFFLENBQUM7d0JBQ1QsSUFBSSxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7NEJBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQ1Qsd0RBQXdELEVBQ3hELElBQUksRUFDSixJQUFJLENBQUMsSUFBSSxDQUNWLENBQUE7d0JBQ0gsQ0FBQzt3QkFFRCxJQUFJLENBQUM7NEJBQ0gsT0FBTyxNQUFNLEVBQUUsRUFBRSxDQUFBO3dCQUNuQixDQUFDO2dDQUFTLENBQUM7NEJBQ1QsSUFBSSxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7Z0NBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQ1QsdURBQXVELEVBQ3ZELElBQUksRUFDSixJQUFJLENBQUMsSUFBSSxDQUNWLENBQUE7NEJBQ0gsQ0FBQzt3QkFDSCxDQUFDO29CQUNILENBQUM7eUJBQU0sQ0FBQzt3QkFDTixrRUFBa0U7d0JBQ2xFLE9BQU8sQ0FBQyxJQUFJLENBQ1YscUZBQXFGLENBQ3RGLENBQUE7d0JBQ0QsT0FBTyxNQUFNLEVBQUUsRUFBRSxDQUFBO29CQUNuQixDQUFDO2dCQUNILENBQUMsQ0FDRixDQUNGLENBQUE7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04seURBQXlEO2dCQUN6RCxtRUFBbUU7Z0JBQ25FLG9FQUFvRTtnQkFDcEUsc0VBQXNFO2dCQUN0RSw0Q0FBNEM7Z0JBQzVDLG1FQUFtRTtnQkFDbkUseUVBQXlFO2dCQUN6RSxJQUFJLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FDVCx3RUFBd0UsRUFDeEUsSUFBSSxDQUNMLENBQUE7Z0JBQ0gsQ0FBQztnQkFFRCxNQUFNLElBQUksZ0NBQWdDLENBQ3hDLFNBQVMsSUFBSSxpREFBaUQsQ0FDL0QsQ0FBQTtZQUNILENBQUM7UUFDSCxDQUFDO1FBRUQsTUFBTSxDQUFDLENBQUE7SUFDVCxDQUFDO0FBQ0gsQ0FBQztBQUVELE1BQU0sYUFBYSxHQUFxQyxFQUFFLENBQUE7QUFFMUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXdCRztBQUNILE1BQU0sQ0FBQyxLQUFLLFVBQVUsV0FBVyxDQUMvQixJQUFZLEVBQ1osY0FBc0IsRUFDdEIsRUFBb0I7O0lBRXBCLE1BQU0saUJBQWlCLEdBQUcsTUFBQSxhQUFhLENBQUMsSUFBSSxDQUFDLG1DQUFJLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQTtJQUVsRSxpRUFBaUU7SUFDakUscURBQXFEO0lBQ3JELE1BQU0sd0JBQXdCLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRTtRQUMzQyxJQUFJLENBQUM7WUFDSCxNQUFNLGlCQUFpQixDQUFBO1lBQ3ZCLE9BQU8sSUFBSSxDQUFBO1FBQ2IsQ0FBQztRQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDWCxrRUFBa0U7WUFDbEUsT0FBTyxJQUFJLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUVKLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRTtRQUNuQyxJQUFJLFNBQVMsR0FBeUMsSUFBSSxDQUFBO1FBRTFELElBQUksQ0FBQztZQUNILGdEQUFnRDtZQUNoRCxNQUFNLGNBQWMsR0FDbEIsY0FBYyxJQUFJLENBQUM7Z0JBQ2pCLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRTtvQkFDeEIsU0FBUyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEVBQUU7d0JBQzFCLE9BQU8sQ0FBQyxJQUFJLENBQ1YsOEJBQThCLElBQUksaUNBQWlDLGNBQWMsTUFBTTs0QkFDckYsNERBQTREOzRCQUM1RCwwRUFBMEUsQ0FDN0UsQ0FBQTt3QkFFRCxNQUFNLENBQ0osSUFBSSw4QkFBOEIsQ0FDaEMscUNBQXFDLElBQUksYUFBYSxDQUN2RCxDQUNGLENBQUE7b0JBQ0gsQ0FBQyxFQUFFLGNBQWMsQ0FBQyxDQUFBO2dCQUNwQixDQUFDLENBQUM7Z0JBQ0osQ0FBQyxDQUFDLElBQUksQ0FBQTtZQUVWLE1BQU0sT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLHdCQUF3QixFQUFFLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUUvRSwwREFBMEQ7WUFDMUQsOENBQThDO1lBQzlDLElBQUksU0FBUyxLQUFLLElBQUksRUFBRSxDQUFDO2dCQUN2QixZQUFZLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDekIsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ1gsMENBQTBDO1lBQzFDLElBQUksU0FBUyxLQUFLLElBQUksRUFBRSxDQUFDO2dCQUN2QixZQUFZLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDekIsQ0FBQztZQUVELHlDQUF5QztZQUN6QyxJQUFJLENBQUMsWUFBWSx1QkFBdUIsRUFBRSxDQUFDO2dCQUN6QyxNQUFNLENBQUMsQ0FBQTtZQUNULENBQUM7WUFDRCxvRUFBb0U7UUFDdEUsQ0FBQztRQUVELHVFQUF1RTtRQUN2RSxzREFBc0Q7UUFDdEQsT0FBTyxNQUFNLEVBQUUsRUFBRSxDQUFBO0lBQ25CLENBQUMsQ0FBQyxFQUFFLENBQUE7SUFFSixhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRTtRQUNoQyxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sZ0JBQWdCLENBQUE7UUFDL0IsQ0FBQztRQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDWCxJQUFJLENBQUMsWUFBWSx1QkFBdUIsRUFBRSxDQUFDO2dCQUN6Qyx3RUFBd0U7Z0JBQ3hFLG1FQUFtRTtnQkFDbkUsSUFBSSxDQUFDO29CQUNILE1BQU0saUJBQWlCLENBQUE7Z0JBQ3pCLENBQUM7Z0JBQUMsT0FBTyxTQUFTLEVBQUUsQ0FBQztvQkFDbkIsbUNBQW1DO2dCQUNyQyxDQUFDO2dCQUNELE9BQU8sSUFBSSxDQUFBO1lBQ2IsQ0FBQztZQUVELE1BQU0sQ0FBQyxDQUFBO1FBQ1QsQ0FBQztJQUNILENBQUMsQ0FBQyxFQUFFLENBQUE7SUFFSix5RUFBeUU7SUFDekUseUNBQXlDO0lBQ3pDLE9BQU8sTUFBTSxnQkFBZ0IsQ0FBQTtBQUMvQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBMb2NrIHByaW1pdGl2ZXMgcmV0YWluZWQgZm9yIGJhY2t3YXJkcy1jb21wYXRpYmxlIGltcG9ydHMuIFRoZSBhdXRoIGNsaWVudFxuICogY29vcmRpbmF0ZXMgcmVmcmVzaGVzIGl0c2VsZiAoZGVkdXBpbmcgaW4taW5zdGFuY2UgY2FsbGVycyBvbnRvIGEgc2hhcmVkXG4gKiBpbi1mbGlnaHQgcHJvbWlzZSkgYW5kIGxldHMgdGhlIEdvVHJ1ZSBzZXJ2ZXIgcmVzb2x2ZSBjcm9zcy1pbnN0YW5jZSByYWNlcyxcbiAqIHNvIGl0IGRvZXMgbm90IGludm9rZSBhbnkgcHJpbWl0aXZlIGZyb20gdGhpcyBtb2R1bGUuIFRoZSBmdW5jdGlvbnMgc3RpbGxcbiAqIHdvcmsgZm9yIGRpcmVjdCBjYWxsZXJzIHRoYXQgbmVlZCBhIG5hdmlnYXRvci5sb2Nrcy1iYWNrZWQgb3IgaW4tcHJvY2Vzc1xuICogZXhjbHVzaXZlIGxvY2sgb2YgdGhlaXIgb3duLlxuICovXG5cbmltcG9ydCB7IHN1cHBvcnRzTG9jYWxTdG9yYWdlIH0gZnJvbSAnLi9oZWxwZXJzJ1xuXG4vKipcbiAqIEBkZXByZWNhdGVkIERlYnVnIGZsYWcgZm9yIGBuYXZpZ2F0b3JMb2NrYCAvIGBwcm9jZXNzTG9ja2AuIFRoZSBhdXRoXG4gKiBjbGllbnQgaWdub3JlcyBib3RoLCBzbyB0aGlzIGhhcyBubyBjbGllbnQtc2lkZSBlZmZlY3QuXG4gKiBAZXhwZXJpbWVudGFsXG4gKi9cbmV4cG9ydCBjb25zdCBpbnRlcm5hbHMgPSB7XG4gIC8qKlxuICAgKiBAZXhwZXJpbWVudGFsXG4gICAqL1xuICBkZWJ1ZzogISEoXG4gICAgZ2xvYmFsVGhpcyAmJlxuICAgIHN1cHBvcnRzTG9jYWxTdG9yYWdlKCkgJiZcbiAgICBnbG9iYWxUaGlzLmxvY2FsU3RvcmFnZSAmJlxuICAgIGdsb2JhbFRoaXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3N1cGFiYXNlLmdvdHJ1ZS1qcy5sb2Nrcy5kZWJ1ZycpID09PSAndHJ1ZSdcbiAgKSxcbn1cblxuLyoqXG4gKiBBbiBlcnJvciB0aHJvd24gd2hlbiBhIGxvY2sgY2Fubm90IGJlIGFjcXVpcmVkIGFmdGVyIHNvbWUgYW1vdW50IG9mIHRpbWUuXG4gKlxuICogQGRlcHJlY2F0ZWQgVGhlIGF1dGggY2xpZW50IGRvZXNuJ3QgYWNxdWlyZSBsb2NrcyBhcm91bmQgYXV0aCBvcGVyYXRpb25zLFxuICogc28gdGhpcyBlcnJvciBuZXZlciBvcmlnaW5hdGVzIGZyb20gYHN1cGFiYXNlLmF1dGguKmAgY2FsbHMuIERpcmVjdCBjYWxsZXJzXG4gKiBvZiBgbmF2aWdhdG9yTG9ja2AgLyBgcHJvY2Vzc0xvY2tgIHN0aWxsIHJlY2VpdmUgaXQgb24gYWNxdWlyZSB0aW1lb3V0LlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgTG9ja0FjcXVpcmVUaW1lb3V0RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHB1YmxpYyByZWFkb25seSBpc0FjcXVpcmVUaW1lb3V0ID0gdHJ1ZVxuXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHN1cGVyKG1lc3NhZ2UpXG4gIH1cbn1cblxuLyoqXG4gKiBAZGVwcmVjYXRlZCBUaGUgYXV0aCBjbGllbnQgZG9lc24ndCBjYWxsIGBuYXZpZ2F0b3IubG9ja3NgLCBzbyB0aGlzIGVycm9yXG4gKiBuZXZlciBvcmlnaW5hdGVzIGZyb20gYHN1cGFiYXNlLmF1dGguKmAgY2FsbHMuIERpcmVjdCBjYWxsZXJzIG9mXG4gKiBgbmF2aWdhdG9yTG9ja2Agc3RpbGwgcmVjZWl2ZSBpdCBvbiBhY3F1aXJlIHRpbWVvdXQuXG4gKi9cbmV4cG9ydCBjbGFzcyBOYXZpZ2F0b3JMb2NrQWNxdWlyZVRpbWVvdXRFcnJvciBleHRlbmRzIExvY2tBY3F1aXJlVGltZW91dEVycm9yIHt9XG4vKipcbiAqIEBkZXByZWNhdGVkIFRoZSBhdXRoIGNsaWVudCBkb2Vzbid0IHJ1biBgcHJvY2Vzc0xvY2tgLCBzbyB0aGlzIGVycm9yXG4gKiBuZXZlciBvcmlnaW5hdGVzIGZyb20gYHN1cGFiYXNlLmF1dGguKmAgY2FsbHMuIERpcmVjdCBjYWxsZXJzIG9mXG4gKiBgcHJvY2Vzc0xvY2tgIHN0aWxsIHJlY2VpdmUgaXQgb24gYWNxdWlyZSB0aW1lb3V0LlxuICovXG5leHBvcnQgY2xhc3MgUHJvY2Vzc0xvY2tBY3F1aXJlVGltZW91dEVycm9yIGV4dGVuZHMgTG9ja0FjcXVpcmVUaW1lb3V0RXJyb3Ige31cblxuLyoqXG4gKiBJbXBsZW1lbnRzIGEgZ2xvYmFsIGV4Y2x1c2l2ZSBsb2NrIHVzaW5nIHRoZSBOYXZpZ2F0b3IgTG9ja01hbmFnZXIgQVBJLiBJdFxuICogaXMgYXZhaWxhYmxlIG9uIGFsbCBicm93c2VycyByZWxlYXNlZCBhZnRlciAyMDIyLTAzLTE1IHdpdGggU2FmYXJpIGJlaW5nIHRoZVxuICogbGFzdCBvbmUgdG8gcmVsZWFzZSBzdXBwb3J0LiBJZiB0aGUgQVBJIGlzIG5vdCBhdmFpbGFibGUsIHRoaXMgZnVuY3Rpb24gd2lsbFxuICogdGhyb3cuIE1ha2Ugc3VyZSB5b3UgY2hlY2sgYXZhaWxhYmxpbGl0eSBiZWZvcmUgY29uZmlndXJpbmcge0BsaW5rXG4gKiBHb1RydWVDbGllbnR9LlxuICpcbiAqIFlvdSBjYW4gdHVybiBvbiBkZWJ1Z2dpbmcgYnkgc2V0dGluZyB0aGUgYHN1cGFiYXNlLmdvdHJ1ZS1qcy5sb2Nrcy5kZWJ1Z2BcbiAqIGxvY2FsIHN0b3JhZ2UgaXRlbSB0byBgdHJ1ZWAuXG4gKlxuICogSW50ZXJuYWxzOlxuICpcbiAqIFNpbmNlIHRoZSBMb2NrTWFuYWdlciBBUEkgZG9lcyBub3QgcHJlc2VydmUgc3RhY2sgdHJhY2VzIGZvciB0aGUgYXN5bmNcbiAqIGZ1bmN0aW9uIHBhc3NlZCBpbiB0aGUgYHJlcXVlc3RgIG1ldGhvZCwgYSB0cmljayBpcyB1c2VkIHdoZXJlIGFjcXVpcmluZyB0aGVcbiAqIGxvY2sgcmVsZWFzZXMgYSBwcmV2aW91c2x5IHN0YXJ0ZWQgcHJvbWlzZSB0byBydW4gdGhlIG9wZXJhdGlvbiBpbiB0aGUgYGZuYFxuICogZnVuY3Rpb24uIFRoZSBsb2NrIHdhaXRzIGZvciB0aGF0IHByb21pc2UgdG8gZmluaXNoICh3aXRoIG9yIHdpdGhvdXQgZXJyb3IpLFxuICogd2hpbGUgdGhlIGZ1bmN0aW9uIHdpbGwgZmluYWxseSB3YWl0IGZvciB0aGUgcmVzdWx0IGFueXdheS5cbiAqXG4gKiBAcGFyYW0gbmFtZSBOYW1lIG9mIHRoZSBsb2NrIHRvIGJlIGFjcXVpcmVkLlxuICogQHBhcmFtIGFjcXVpcmVUaW1lb3V0IElmIG5lZ2F0aXZlLCBubyB0aW1lb3V0LiBJZiAwIGFuIGVycm9yIGlzIHRocm93biBpZlxuICogICAgICAgICAgICAgICAgICAgICAgIHRoZSBsb2NrIGNhbid0IGJlIGFjcXVpcmVkIHdpdGhvdXQgd2FpdGluZy4gSWYgcG9zaXRpdmUsIHRoZSBsb2NrIGFjcXVpcmVcbiAqICAgICAgICAgICAgICAgICAgICAgICB3aWxsIHRpbWUgb3V0IGFmdGVyIHNvIG1hbnkgbWlsbGlzZWNvbmRzLiBBbiBlcnJvciBpc1xuICogICAgICAgICAgICAgICAgICAgICAgIGEgdGltZW91dCBpZiBpdCBoYXMgYGlzQWNxdWlyZVRpbWVvdXRgIHNldCB0byB0cnVlLlxuICogQHBhcmFtIGZuIFRoZSBvcGVyYXRpb24gdG8gcnVuIG9uY2UgdGhlIGxvY2sgaXMgYWNxdWlyZWQuXG4gKlxuICogQGRlcHJlY2F0ZWQgVGhlIGF1dGggY2xpZW50IGNvb3JkaW5hdGVzIHJlZnJlc2hlcyBpdHNlbGYgYW5kIHRoZSBzZXJ2ZXJcbiAqIHJlc29sdmVzIGNvbmN1cnJlbnQgcmVmcmVzaCByYWNlcywgc28gcGFzc2luZyBgeyBsb2NrOiBuYXZpZ2F0b3JMb2NrIH1gXG4gKiB0byBpdCBoYXMgbm8gZWZmZWN0LiBZb3UgY2FuIHNhZmVseSBkcm9wIHRoZSBpbXBvcnQgZnJvbSB5b3VyIGNsaWVudCBzZXR1cC5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5hdmlnYXRvckxvY2s8Uj4oXG4gIG5hbWU6IHN0cmluZyxcbiAgYWNxdWlyZVRpbWVvdXQ6IG51bWJlcixcbiAgZm46ICgpID0+IFByb21pc2U8Uj5cbik6IFByb21pc2U8Uj4ge1xuICBpZiAoaW50ZXJuYWxzLmRlYnVnKSB7XG4gICAgY29uc29sZS5sb2coJ0BzdXBhYmFzZS9nb3RydWUtanM6IG5hdmlnYXRvckxvY2s6IGFjcXVpcmUgbG9jaycsIG5hbWUsIGFjcXVpcmVUaW1lb3V0KVxuICB9XG5cbiAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IGdsb2JhbFRoaXMuQWJvcnRDb250cm9sbGVyKClcblxuICBsZXQgYWNxdWlyZVRpbWVvdXRUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCB1bmRlZmluZWRcblxuICBpZiAoYWNxdWlyZVRpbWVvdXQgPiAwKSB7XG4gICAgYWNxdWlyZVRpbWVvdXRUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KClcbiAgICAgIGlmIChpbnRlcm5hbHMuZGVidWcpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ0BzdXBhYmFzZS9nb3RydWUtanM6IG5hdmlnYXRvckxvY2sgYWNxdWlyZSB0aW1lZCBvdXQnLCBuYW1lKVxuICAgICAgfVxuICAgIH0sIGFjcXVpcmVUaW1lb3V0KVxuICB9XG5cbiAgLy8gTUROIGFydGljbGU6IGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9Mb2NrTWFuYWdlci9yZXF1ZXN0XG5cbiAgLy8gV3JhcHBpbmcgbmF2aWdhdG9yLmxvY2tzLnJlcXVlc3QoKSB3aXRoIGEgcGxhaW4gUHJvbWlzZSBpcyBkb25lIGFzIHNvbWVcbiAgLy8gbGlicmFyaWVzIGxpa2Ugem9uZS5qcyBwYXRjaCB0aGUgUHJvbWlzZSBvYmplY3QgdG8gdHJhY2sgdGhlIGV4ZWN1dGlvblxuICAvLyBjb250ZXh0LiBIb3dldmVyLCBpdCBhcHBlYXJzIHRoYXQgbW9zdCBicm93c2VycyB1c2UgYW4gaW50ZXJuYWwgcHJvbWlzZVxuICAvLyBpbXBsZW1lbnRhdGlvbiB3aGVuIHVzaW5nIHRoZSBuYXZpZ2F0b3IubG9ja3MucmVxdWVzdCgpIEFQSSBjYXVzaW5nIHRoZW1cbiAgLy8gdG8gbG9zZSBjb250ZXh0IGFuZCBlbWl0IGNvbmZ1c2luZyBsb2cgbWVzc2FnZXMgb3IgYnJlYWsgY2VydGFpbiBmZWF0dXJlcy5cbiAgLy8gVGhpcyB3cmFwcGluZyBpcyBiZWxpZXZlZCB0byBoZWxwIHpvbmUuanMgdHJhY2sgdGhlIGV4ZWN1dGlvbiBjb250ZXh0XG4gIC8vIGJldHRlci5cbiAgYXdhaXQgUHJvbWlzZS5yZXNvbHZlKClcblxuICB0cnkge1xuICAgIHJldHVybiBhd2FpdCBnbG9iYWxUaGlzLm5hdmlnYXRvci5sb2Nrcy5yZXF1ZXN0KFxuICAgICAgbmFtZSxcbiAgICAgIGFjcXVpcmVUaW1lb3V0ID09PSAwXG4gICAgICAgID8ge1xuICAgICAgICAgICAgbW9kZTogJ2V4Y2x1c2l2ZScsXG4gICAgICAgICAgICBpZkF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICB9XG4gICAgICAgIDoge1xuICAgICAgICAgICAgbW9kZTogJ2V4Y2x1c2l2ZScsXG4gICAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXG4gICAgICAgICAgfSxcbiAgICAgIGFzeW5jIChsb2NrKSA9PiB7XG4gICAgICAgIGlmIChsb2NrKSB7XG4gICAgICAgICAgLy8gTG9jayBhY3F1aXJlZCDigJQgY2FuY2VsIHRoZSBhY3F1aXJlLXRpbWVvdXQgdGltZXIgc28gaXQgY2Fubm90IGZpcmVcbiAgICAgICAgICAvLyB3aGlsZSBmbigpIGlzIHJ1bm5pbmcuIFdpdGhvdXQgdGhpcywgYSBkZWxheWVkIHRpbWVvdXQgYWJvcnQgd291bGRcbiAgICAgICAgICAvLyBzZXQgc2lnbmFsLmFib3J0ZWQgPSB0cnVlIGV2ZW4gdGhvdWdoIHdlIGFscmVhZHkgaG9sZCB0aGUgbG9jayxcbiAgICAgICAgICAvLyBjYXVzaW5nIGEgc3Vic2VxdWVudCBzdGVhbCB0byBiZSBtaXNjbGFzc2lmaWVkIGFzIFwib3VyIHRpbWVvdXRcbiAgICAgICAgICAvLyBmaXJlZFwiIGFuZCB0cmlnZ2VyaW5nIGEgc3B1cmlvdXMgc3RlYWwtYmFjayBjYXNjYWRlLlxuICAgICAgICAgIGNsZWFyVGltZW91dChhY3F1aXJlVGltZW91dFRpbWVyKVxuXG4gICAgICAgICAgaWYgKGludGVybmFscy5kZWJ1Zykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ0BzdXBhYmFzZS9nb3RydWUtanM6IG5hdmlnYXRvckxvY2s6IGFjcXVpcmVkJywgbmFtZSwgbG9jay5uYW1lKVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gYXdhaXQgZm4oKVxuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBpZiAoaW50ZXJuYWxzLmRlYnVnKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdAc3VwYWJhc2UvZ290cnVlLWpzOiBuYXZpZ2F0b3JMb2NrOiByZWxlYXNlZCcsIG5hbWUsIGxvY2submFtZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKGFjcXVpcmVUaW1lb3V0ID09PSAwKSB7XG4gICAgICAgICAgICBpZiAoaW50ZXJuYWxzLmRlYnVnKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdAc3VwYWJhc2UvZ290cnVlLWpzOiBuYXZpZ2F0b3JMb2NrOiBub3QgaW1tZWRpYXRlbHkgYXZhaWxhYmxlJywgbmFtZSlcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhyb3cgbmV3IE5hdmlnYXRvckxvY2tBY3F1aXJlVGltZW91dEVycm9yKFxuICAgICAgICAgICAgICBgQWNxdWlyaW5nIGFuIGV4Y2x1c2l2ZSBOYXZpZ2F0b3IgTG9ja01hbmFnZXIgbG9jayBcIiR7bmFtZX1cIiBpbW1lZGlhdGVseSBmYWlsZWRgXG4gICAgICAgICAgICApXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmIChpbnRlcm5hbHMuZGVidWcpIHtcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBnbG9iYWxUaGlzLm5hdmlnYXRvci5sb2Nrcy5xdWVyeSgpXG5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgICAgICAgICdAc3VwYWJhc2UvZ290cnVlLWpzOiBOYXZpZ2F0b3IgTG9ja01hbmFnZXIgc3RhdGUnLFxuICAgICAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkocmVzdWx0LCBudWxsLCAnICAnKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgICAgICdAc3VwYWJhc2UvZ290cnVlLWpzOiBFcnJvciB3aGVuIHF1ZXJ5aW5nIE5hdmlnYXRvciBMb2NrTWFuYWdlciBzdGF0ZScsXG4gICAgICAgICAgICAgICAgICBlXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIEJyb3dzZXIgaXMgbm90IGZvbGxvd2luZyB0aGUgTmF2aWdhdG9yIExvY2tNYW5hZ2VyIHNwZWMsIGl0XG4gICAgICAgICAgICAvLyByZXR1cm5lZCBhIG51bGwgbG9jayB3aGVuIHdlIGRpZG4ndCB1c2UgaWZBdmFpbGFibGUuIFNvIHdlIGNhblxuICAgICAgICAgICAgLy8gcHJldGVuZCB0aGUgbG9jayBpcyBhY3F1aXJlZCBpbiB0aGUgbmFtZSBvZiBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG4gICAgICAgICAgICAvLyBhbmQgdXNlciBleHBlcmllbmNlIGFuZCBqdXN0IHJ1biB0aGUgZnVuY3Rpb24uXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgICAgICdAc3VwYWJhc2UvZ290cnVlLWpzOiBOYXZpZ2F0b3IgTG9ja01hbmFnZXIgcmV0dXJuZWQgYSBudWxsIGxvY2sgd2hlbiB1c2luZyAjcmVxdWVzdCB3aXRob3V0IGlmQXZhaWxhYmxlIHNldCB0byB0cnVlLCBpdCBhcHBlYXJzIHRoaXMgYnJvd3NlciBpcyBub3QgZm9sbG93aW5nIHRoZSBMb2NrTWFuYWdlciBzcGVjIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9Mb2NrTWFuYWdlci9yZXF1ZXN0J1xuICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICBjbGVhclRpbWVvdXQoYWNxdWlyZVRpbWVvdXRUaW1lcilcbiAgICAgICAgICAgIHJldHVybiBhd2FpdCBmbigpXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgKVxuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gQWx3YXlzIGNsZWFyIHRoZSBhY3F1aXJlIHRpbWVvdXQgb25jZSB0aGUgcmVxdWVzdCBzZXR0bGVzLCBzbyBpdCBjYW5ub3RcbiAgICAvLyBmaXJlIGxhdGVyIGFuZCBpbmNvcnJlY3RseSBhYm9ydC9sb2cgYWZ0ZXIgYSByZWplY3Rpb24uXG4gICAgaWYgKGFjcXVpcmVUaW1lb3V0ID4gMCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGFjcXVpcmVUaW1lb3V0VGltZXIpXG4gICAgfVxuXG4gICAgLy8gRE9NRXhjZXB0aW9uIGRvZXMgbm90IGV4dGVuZCBFcnJvciBpbiBOb2RlLmpzLCBzbyB1c2Ugc3RydWN0dXJhbCBjaGVja1xuICAgIGlmIChcbiAgICAgIGUgIT09IG51bGwgJiZcbiAgICAgIHR5cGVvZiBlID09PSAnb2JqZWN0JyAmJlxuICAgICAgJ25hbWUnIGluIGUgJiZcbiAgICAgIGUubmFtZSA9PT0gJ0Fib3J0RXJyb3InICYmXG4gICAgICBhY3F1aXJlVGltZW91dCA+IDBcbiAgICApIHtcbiAgICAgIGlmIChhYm9ydENvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgLy8gT1VSIHRpbWVvdXQgZmlyZWQg4oCUIHRoZSBsb2NrIGlzIGdlbnVpbmVseSBvcnBoYW5lZC4gU3RlYWwgaXQuXG4gICAgICAgIC8vXG4gICAgICAgIC8vIFRoZSBsb2NrIGFjcXVpc2l0aW9uIHdhcyBhYm9ydGVkIGJlY2F1c2UgdGhlIHRpbWVvdXQgZmlyZWQgd2hpbGUgdGhlXG4gICAgICAgIC8vIHJlcXVlc3Qgd2FzIHN0aWxsIHBlbmRpbmcuIFRoaXMgdHlwaWNhbGx5IG1lYW5zIGFub3RoZXIgbG9jayBob2xkZXIgaXNcbiAgICAgICAgLy8gbm90IHJlbGVhc2luZyB0aGUgbG9jaywgcG9zc2libHkgZHVlIHRvIFJlYWN0IFN0cmljdCBNb2RlJ3NcbiAgICAgICAgLy8gZG91YmxlLW1vdW50L3VubW91bnQgYmVoYXZpb3Igb3IgYSBjb21wb25lbnQgdW5tb3VudGluZyBtaWQtb3BlcmF0aW9uLFxuICAgICAgICAvLyBsZWF2aW5nIGFuIG9ycGhhbmVkIGxvY2suXG4gICAgICAgIC8vXG4gICAgICAgIC8vIFJlY292ZXJ5OiB1c2UgeyBzdGVhbDogdHJ1ZSB9IHRvIGZvcmNlZnVsbHkgYWNxdWlyZSB0aGUgbG9jay4gUGVyIHRoZVxuICAgICAgICAvLyBXZWIgTG9ja3MgQVBJIHNwZWMsIHRoaXMgcmVsZWFzZXMgYW55IGN1cnJlbnRseSBoZWxkIGxvY2sgd2l0aCB0aGUgc2FtZVxuICAgICAgICAvLyBuYW1lIGFuZCBncmFudHMgdGhlIHJlcXVlc3QgaW1tZWRpYXRlbHksIHByZWVtcHRpbmcgYW55IHF1ZXVlZCByZXF1ZXN0cy5cbiAgICAgICAgLy8gVGhlIHByZXZpb3VzIGhvbGRlcidzIGNhbGxiYWNrIGNvbnRpbnVlcyBydW5uaW5nIHRvIGNvbXBsZXRpb24gYnV0IG5vXG4gICAgICAgIC8vIGxvbmdlciBob2xkcyB0aGUgbG9jayBmb3IgZXhjbHVzaW9uIHB1cnBvc2VzLlxuICAgICAgICAvL1xuICAgICAgICAvLyBTZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9zdXBhYmFzZS9zdXBhYmFzZS9pc3N1ZXMvNDI1MDVcbiAgICAgICAgaWYgKGludGVybmFscy5kZWJ1Zykge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgJ0BzdXBhYmFzZS9nb3RydWUtanM6IG5hdmlnYXRvckxvY2s6IGFjcXVpcmUgdGltZW91dCwgcmVjb3ZlcmluZyBieSBzdGVhbGluZyBsb2NrJyxcbiAgICAgICAgICAgIG5hbWVcbiAgICAgICAgICApXG4gICAgICAgIH1cblxuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgYEBzdXBhYmFzZS9nb3RydWUtanM6IExvY2sgXCIke25hbWV9XCIgd2FzIG5vdCByZWxlYXNlZCB3aXRoaW4gJHthY3F1aXJlVGltZW91dH1tcy4gYCArXG4gICAgICAgICAgICAnVGhpcyBtYXkgaW5kaWNhdGUgYW4gb3JwaGFuZWQgbG9jayBmcm9tIGEgY29tcG9uZW50IHVubW91bnQgKGUuZy4sIFJlYWN0IFN0cmljdCBNb2RlKS4gJyArXG4gICAgICAgICAgICAnRm9yY2VmdWxseSBhY3F1aXJpbmcgdGhlIGxvY2sgdG8gcmVjb3Zlci4nXG4gICAgICAgIClcblxuICAgICAgICByZXR1cm4gYXdhaXQgUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PlxuICAgICAgICAgIGdsb2JhbFRoaXMubmF2aWdhdG9yLmxvY2tzLnJlcXVlc3QoXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBtb2RlOiAnZXhjbHVzaXZlJyxcbiAgICAgICAgICAgICAgc3RlYWw6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYXN5bmMgKGxvY2spID0+IHtcbiAgICAgICAgICAgICAgaWYgKGxvY2spIHtcbiAgICAgICAgICAgICAgICBpZiAoaW50ZXJuYWxzLmRlYnVnKSB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgICAgICAgICAgJ0BzdXBhYmFzZS9nb3RydWUtanM6IG5hdmlnYXRvckxvY2s6IHJlY292ZXJlZCAoc3RvbGVuKScsXG4gICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGxvY2submFtZVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgZm4oKVxuICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICBpZiAoaW50ZXJuYWxzLmRlYnVnKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICAgICAgICdAc3VwYWJhc2UvZ290cnVlLWpzOiBuYXZpZ2F0b3JMb2NrOiByZWxlYXNlZCAoc3RvbGVuKScsXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICBsb2NrLm5hbWVcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIHNob3VsZCBub3QgaGFwcGVuIHdpdGggc3RlYWw6IHRydWUsIGJ1dCBoYW5kbGUgZ3JhY2VmdWxseS5cbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgICAgICAgICAnQHN1cGFiYXNlL2dvdHJ1ZS1qczogTmF2aWdhdG9yIExvY2tNYW5hZ2VyIHJldHVybmVkIG51bGwgbG9jayBldmVuIHdpdGggc3RlYWw6IHRydWUnXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCBmbigpXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFdlIEhFTEQgdGhlIGxvY2sgYnV0IGFub3RoZXIgcmVxdWVzdCBzdG9sZSBpdCBmcm9tIHVzLlxuICAgICAgICAvLyBQZXIgdGhlIFdlYiBMb2NrcyBzcGVjLCBvdXIgZm4oKSBjYWxsYmFjayBpcyBzdGlsbCBydW5uaW5nIGFzIGFuXG4gICAgICAgIC8vIG9ycGhhbmVkIGJhY2tncm91bmQgdGFzayDigJQgZG8gTk9UIHN0ZWFsIGJhY2suIFN0ZWFsaW5nIGJhY2sgd291bGRcbiAgICAgICAgLy8gY2F1c2UgYSBjYXNjYWRlIChBIHN0ZWFscyBCLCBCIHN0ZWFscyBBLCAuLi4pIGFuZCBydW4gZm4oKSBhIHNlY29uZFxuICAgICAgICAvLyB0aW1lIGNvbmN1cnJlbnRseSwgY29ycnVwdGluZyBhdXRoIHN0YXRlLlxuICAgICAgICAvLyBDb252ZXJ0IHRvIGEgdHlwZWQgZXJyb3Igc28gY2FsbGVycyAoZS5nLiBfYXV0b1JlZnJlc2hUb2tlblRpY2spXG4gICAgICAgIC8vIGNhbiBoYW5kbGUvZmlsdGVyIGl0IHdpdGhvdXQgaXQgbGVha2luZyB0byBTZW50cnkgYXMgYSByYXcgQWJvcnRFcnJvci5cbiAgICAgICAgaWYgKGludGVybmFscy5kZWJ1Zykge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgJ0BzdXBhYmFzZS9nb3RydWUtanM6IG5hdmlnYXRvckxvY2s6IGxvY2sgd2FzIHN0b2xlbiBieSBhbm90aGVyIHJlcXVlc3QnLFxuICAgICAgICAgICAgbmFtZVxuICAgICAgICAgIClcbiAgICAgICAgfVxuXG4gICAgICAgIHRocm93IG5ldyBOYXZpZ2F0b3JMb2NrQWNxdWlyZVRpbWVvdXRFcnJvcihcbiAgICAgICAgICBgTG9jayBcIiR7bmFtZX1cIiB3YXMgcmVsZWFzZWQgYmVjYXVzZSBhbm90aGVyIHJlcXVlc3Qgc3RvbGUgaXRgXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aHJvdyBlXG4gIH1cbn1cblxuY29uc3QgUFJPQ0VTU19MT0NLUzogeyBbbmFtZTogc3RyaW5nXTogUHJvbWlzZTxhbnk+IH0gPSB7fVxuXG4vKipcbiAqIEltcGxlbWVudHMgYSBnbG9iYWwgZXhjbHVzaXZlIGxvY2sgdGhhdCB3b3JrcyBvbmx5IGluIHRoZSBjdXJyZW50IHByb2Nlc3MuXG4gKiBVc2VmdWwgZm9yIGVudmlyb25tZW50cyBsaWtlIFJlYWN0IE5hdGl2ZSBvciBvdGhlciBub24tYnJvd3NlclxuICogc2luZ2xlLXByb2Nlc3MgKGkuZS4gbm8gY29uY2VwdCBvZiBcInRhYnNcIikgZW52aXJvbm1lbnRzLlxuICpcbiAqIFVzZSB7QGxpbmsgI25hdmlnYXRvckxvY2t9IGluIGJyb3dzZXIgZW52aXJvbm1lbnRzLlxuICpcbiAqIEBwYXJhbSBuYW1lIE5hbWUgb2YgdGhlIGxvY2sgdG8gYmUgYWNxdWlyZWQuXG4gKiBAcGFyYW0gYWNxdWlyZVRpbWVvdXQgSWYgbmVnYXRpdmUsIG5vIHRpbWVvdXQuIElmIDAgYW4gZXJyb3IgaXMgdGhyb3duIGlmXG4gKiAgICAgICAgICAgICAgICAgICAgICAgdGhlIGxvY2sgY2FuJ3QgYmUgYWNxdWlyZWQgd2l0aG91dCB3YWl0aW5nLiBJZiBwb3NpdGl2ZSwgdGhlIGxvY2sgYWNxdWlyZVxuICogICAgICAgICAgICAgICAgICAgICAgIHdpbGwgdGltZSBvdXQgYWZ0ZXIgc28gbWFueSBtaWxsaXNlY29uZHMuIEFuIGVycm9yIGlzXG4gKiAgICAgICAgICAgICAgICAgICAgICAgYSB0aW1lb3V0IGlmIGl0IGhhcyBgaXNBY3F1aXJlVGltZW91dGAgc2V0IHRvIHRydWUuXG4gKiBAcGFyYW0gZm4gVGhlIG9wZXJhdGlvbiB0byBydW4gb25jZSB0aGUgbG9jayBpcyBhY3F1aXJlZC5cbiAqXG4gKiBAZGVwcmVjYXRlZCBUaGUgYXV0aCBjbGllbnQgY29vcmRpbmF0ZXMgcmVmcmVzaGVzIGl0c2VsZiBhbmQgdGhlIHNlcnZlclxuICogcmVzb2x2ZXMgY29uY3VycmVudCByZWZyZXNoIHJhY2VzLCBzbyBwYXNzaW5nIGB7IGxvY2s6IHByb2Nlc3NMb2NrIH1gXG4gKiB0byBpdCBoYXMgbm8gZWZmZWN0LiBZb3UgY2FuIHNhZmVseSBkcm9wIHRoZSBpbXBvcnQgZnJvbSB5b3VyIGNsaWVudCBzZXR1cC5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHNcbiAqIGF3YWl0IHByb2Nlc3NMb2NrKCdtaWdyYXRlJywgNTAwMCwgYXN5bmMgKCkgPT4ge1xuICogICBhd2FpdCBydW5NaWdyYXRpb24oKVxuICogfSlcbiAqIGBgYFxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc0xvY2s8Uj4oXG4gIG5hbWU6IHN0cmluZyxcbiAgYWNxdWlyZVRpbWVvdXQ6IG51bWJlcixcbiAgZm46ICgpID0+IFByb21pc2U8Uj5cbik6IFByb21pc2U8Uj4ge1xuICBjb25zdCBwcmV2aW91c09wZXJhdGlvbiA9IFBST0NFU1NfTE9DS1NbbmFtZV0gPz8gUHJvbWlzZS5yZXNvbHZlKClcblxuICAvLyBXcmFwIHByZXZpb3VzT3BlcmF0aW9uIHRvIGhhbmRsZSBlcnJvcnMgd2l0aG91dCB1c2luZyAuY2F0Y2goKVxuICAvLyBUaGlzIGF2b2lkcyBGaXJlZm94IGNvbnRlbnQgc2NyaXB0IHNlY3VyaXR5IGVycm9yc1xuICBjb25zdCBwcmV2aW91c09wZXJhdGlvbkhhbmRsZWQgPSAoYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBwcmV2aW91c09wZXJhdGlvblxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBpZ25vcmUgZXJyb3Igb2YgcHJldmlvdXMgb3BlcmF0aW9uIHRoYXQgd2UncmUgd2FpdGluZyB0byBmaW5pc2hcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuICB9KSgpXG5cbiAgY29uc3QgY3VycmVudE9wZXJhdGlvbiA9IChhc3luYyAoKSA9PiB7XG4gICAgbGV0IHRpbWVvdXRJZDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsID0gbnVsbFxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIFdhaXQgZm9yIGVpdGhlciBwcmV2aW91cyBvcGVyYXRpb24gb3IgdGltZW91dFxuICAgICAgY29uc3QgdGltZW91dFByb21pc2UgPVxuICAgICAgICBhY3F1aXJlVGltZW91dCA+PSAwXG4gICAgICAgICAgPyBuZXcgUHJvbWlzZSgoXywgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgIHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgICAgIGBAc3VwYWJhc2UvZ290cnVlLWpzOiBMb2NrIFwiJHtuYW1lfVwiIGFjcXVpc2l0aW9uIHRpbWVkIG91dCBhZnRlciAke2FjcXVpcmVUaW1lb3V0fW1zLiBgICtcbiAgICAgICAgICAgICAgICAgICAgJ1RoaXMgbWF5IGJlIGNhdXNlZCBieSBhbm90aGVyIG9wZXJhdGlvbiBob2xkaW5nIHRoZSBsb2NrLiAnICtcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnNpZGVyIGluY3JlYXNpbmcgbG9ja0FjcXVpcmVUaW1lb3V0IG9yIGNoZWNraW5nIGZvciBzdHVjayBvcGVyYXRpb25zLidcbiAgICAgICAgICAgICAgICApXG5cbiAgICAgICAgICAgICAgICByZWplY3QoXG4gICAgICAgICAgICAgICAgICBuZXcgUHJvY2Vzc0xvY2tBY3F1aXJlVGltZW91dEVycm9yKFxuICAgICAgICAgICAgICAgICAgICBgQWNxdWlyaW5nIHByb2Nlc3MgbG9jayB3aXRoIG5hbWUgXCIke25hbWV9XCIgdGltZWQgb3V0YFxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfSwgYWNxdWlyZVRpbWVvdXQpXG4gICAgICAgICAgICB9KVxuICAgICAgICAgIDogbnVsbFxuXG4gICAgICBhd2FpdCBQcm9taXNlLnJhY2UoW3ByZXZpb3VzT3BlcmF0aW9uSGFuZGxlZCwgdGltZW91dFByb21pc2VdLmZpbHRlcigoeCkgPT4geCkpXG5cbiAgICAgIC8vIElmIHdlIHJlYWNoIGhlcmUsIHByZXZpb3VzT3BlcmF0aW9uSGFuZGxlZCB3b24gdGhlIHJhY2VcbiAgICAgIC8vIENsZWFyIHRoZSB0aW1lb3V0IHRvIHByZXZlbnQgZmFsc2Ugd2FybmluZ3NcbiAgICAgIGlmICh0aW1lb3V0SWQgIT09IG51bGwpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZClcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBDbGVhciB0aGUgdGltZW91dCBvbiBlcnJvciBwYXRoIGFzIHdlbGxcbiAgICAgIGlmICh0aW1lb3V0SWQgIT09IG51bGwpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZClcbiAgICAgIH1cblxuICAgICAgLy8gUmUtdGhyb3cgdGltZW91dCBlcnJvcnMsIGlnbm9yZSBvdGhlcnNcbiAgICAgIGlmIChlIGluc3RhbmNlb2YgTG9ja0FjcXVpcmVUaW1lb3V0RXJyb3IpIHtcbiAgICAgICAgdGhyb3cgZVxuICAgICAgfVxuICAgICAgLy8gRmFsbCB0aHJvdWdoIHRvIHJ1biBmbigpIC0gcHJldmlvdXMgb3BlcmF0aW9uIGZpbmlzaGVkIHdpdGggZXJyb3JcbiAgICB9XG5cbiAgICAvLyBQcmV2aW91cyBvcGVyYXRpb25zIGZpbmlzaGVkIGFuZCB3ZSBkaWRuJ3QgZ2V0IGEgcmFjZSBvbiB0aGUgYWNxdWlyZVxuICAgIC8vIHRpbWVvdXQsIHNvIHRoZSBjdXJyZW50IG9wZXJhdGlvbiBjYW4gZmluYWxseSBzdGFydFxuICAgIHJldHVybiBhd2FpdCBmbigpXG4gIH0pKClcblxuICBQUk9DRVNTX0xPQ0tTW25hbWVdID0gKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGF3YWl0IGN1cnJlbnRPcGVyYXRpb25cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoZSBpbnN0YW5jZW9mIExvY2tBY3F1aXJlVGltZW91dEVycm9yKSB7XG4gICAgICAgIC8vIGlmIHRoZSBjdXJyZW50IG9wZXJhdGlvbiB0aW1lZCBvdXQsIGl0IGRvZXNuJ3QgbWVhbiB0aGF0IHRoZSBwcmV2aW91c1xuICAgICAgICAvLyBvcGVyYXRpb24gZmluaXNoZWQsIHNvIHdlIG5lZWQgY29udGludWUgd2FpdGluZyBmb3IgaXQgdG8gZmluaXNoXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgcHJldmlvdXNPcGVyYXRpb25cbiAgICAgICAgfSBjYXRjaCAocHJldkVycm9yKSB7XG4gICAgICAgICAgLy8gSWdub3JlIHByZXZpb3VzIG9wZXJhdGlvbiBlcnJvcnNcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbFxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlXG4gICAgfVxuICB9KSgpXG5cbiAgLy8gZmluYWxseSB3YWl0IGZvciB0aGUgY3VycmVudCBvcGVyYXRpb24gdG8gZmluaXNoIHN1Y2Nlc3NmdWxseSwgd2l0aCBhblxuICAvLyBlcnJvciBvciB3aXRoIGFuIGFjcXVpcmUgdGltZW91dCBlcnJvclxuICByZXR1cm4gYXdhaXQgY3VycmVudE9wZXJhdGlvblxufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=