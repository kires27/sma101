/**
* vue v3.5.41
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
import { initCustomFormatter, warn } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+runtime-dom@3.5.41/node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js?v=583078ff";
export * from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+runtime-dom@3.5.41/node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js?v=583078ff";
function initDev() {
  {
    initCustomFormatter();
  }
}
if (true) {
  initDev();
}
const compile = () => {
  if (true) {
    warn(
      `Runtime compilation is not supported in this build of Vue. Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".`
    );
  }
};
export { compile };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZ1ZS5ydW50aW1lLmVzbS1idW5kbGVyLmpzP3Y9NTgzMDc4ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4qIHZ1ZSB2My41LjQxXG4qIChjKSAyMDE4LXByZXNlbnQgWXV4aSAoRXZhbikgWW91IGFuZCBWdWUgY29udHJpYnV0b3JzXG4qIEBsaWNlbnNlIE1JVFxuKiovXG5pbXBvcnQgeyBpbml0Q3VzdG9tRm9ybWF0dGVyLCB3YXJuIH0gZnJvbSAnQHZ1ZS9ydW50aW1lLWRvbSc7XG5leHBvcnQgKiBmcm9tICdAdnVlL3J1bnRpbWUtZG9tJztcblxuZnVuY3Rpb24gaW5pdERldigpIHtcbiAge1xuICAgIGluaXRDdXN0b21Gb3JtYXR0ZXIoKTtcbiAgfVxufVxuXG5pZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICBpbml0RGV2KCk7XG59XG5jb25zdCBjb21waWxlID0gKCkgPT4ge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm4oXG4gICAgICBgUnVudGltZSBjb21waWxhdGlvbiBpcyBub3Qgc3VwcG9ydGVkIGluIHRoaXMgYnVpbGQgb2YgVnVlLmAgKyAoYCBDb25maWd1cmUgeW91ciBidW5kbGVyIHRvIGFsaWFzIFwidnVlXCIgdG8gXCJ2dWUvZGlzdC92dWUuZXNtLWJ1bmRsZXIuanNcIi5gIClcbiAgICApO1xuICB9XG59O1xuXG5leHBvcnQgeyBjb21waWxlIH07XG4iXSwibWFwcGluZ3MiOiJBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLQSxTQUFTLHFCQUFxQixZQUFZO0FBQzFDLGNBQWM7QUFFZCxTQUFTLFVBQVU7QUFDakI7QUFDRSx3QkFBb0I7QUFBQSxFQUN0QjtBQUNGO0FBRUEsSUFBSSxNQUEyQztBQUM3QyxVQUFRO0FBQ1Y7QUFDQSxNQUFNLFVBQVUsTUFBTTtBQUNwQixNQUFJLE1BQTJDO0FBQzdDO0FBQUEsTUFDRTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTOyIsIm5hbWVzIjpbXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==