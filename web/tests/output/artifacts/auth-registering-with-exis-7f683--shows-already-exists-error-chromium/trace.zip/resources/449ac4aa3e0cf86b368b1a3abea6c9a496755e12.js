import { API_VERSION_HEADER_NAME, BASE64URL_REGEX } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/constants.js?v=583078ff";
import { AuthInvalidJwtError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/errors.js?v=583078ff";
import { base64UrlToUint8Array, stringFromBase64URL } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/base64url.js?v=583078ff";
export function expiresAt(expiresIn) {
    const timeNow = Math.round(Date.now() / 1000);
    return timeNow + expiresIn;
}
/**
 * Generates a unique identifier for internal callback subscriptions.
 *
 * This function uses JavaScript Symbols to create guaranteed-unique identifiers
 * for auth state change callbacks. Symbols are ideal for this use case because:
 * - They are guaranteed unique by the JavaScript runtime
 * - They work in all environments (browser, SSR, Node.js)
 * - They avoid issues with Next.js 16 deterministic rendering requirements
 * - They are perfect for internal, non-serializable identifiers
 *
 * Note: This function is only used for internal subscription management,
 * not for security-critical operations like session tokens.
 */
export function generateCallbackId() {
    return Symbol('auth-callback');
}
export const isBrowser = () => typeof window !== 'undefined' && typeof document !== 'undefined';
const localStorageWriteTests = {
    tested: false,
    writable: false,
};
/**
 * Checks whether localStorage is supported on this browser.
 */
export const supportsLocalStorage = () => {
    if (!isBrowser()) {
        return false;
    }
    try {
        if (typeof globalThis.localStorage !== 'object') {
            return false;
        }
    }
    catch (e) {
        // DOM exception when accessing `localStorage`
        return false;
    }
    if (localStorageWriteTests.tested) {
        return localStorageWriteTests.writable;
    }
    const randomKey = `lswt-${Math.random()}${Math.random()}`;
    try {
        globalThis.localStorage.setItem(randomKey, randomKey);
        globalThis.localStorage.removeItem(randomKey);
        localStorageWriteTests.tested = true;
        localStorageWriteTests.writable = true;
    }
    catch (e) {
        // localStorage can't be written to
        // https://www.chromium.org/for-testers/bug-reporting-guidelines/uncaught-securityerror-failed-to-read-the-localstorage-property-from-window-access-is-denied-for-this-document
        localStorageWriteTests.tested = true;
        localStorageWriteTests.writable = false;
    }
    return localStorageWriteTests.writable;
};
/**
 * Extracts parameters encoded in the URL both in the query and fragment.
 */
export function parseParametersFromURL(href) {
    const result = {};
    const url = new URL(href);
    if (url.hash && url.hash[0] === '#') {
        try {
            const hashSearchParams = new URLSearchParams(url.hash.substring(1));
            hashSearchParams.forEach((value, key) => {
                result[key] = value;
            });
        }
        catch (_e) {
            // hash is not a query string
        }
    }
    // search parameters take precedence over hash parameters
    url.searchParams.forEach((value, key) => {
        result[key] = value;
    });
    return result;
}
export const resolveFetch = (customFetch) => {
    if (customFetch) {
        return (...args) => customFetch(...args);
    }
    return (...args) => fetch(...args);
};
export const looksLikeFetchResponse = (maybeResponse) => {
    return (typeof maybeResponse === 'object' &&
        maybeResponse !== null &&
        'status' in maybeResponse &&
        'ok' in maybeResponse &&
        'json' in maybeResponse &&
        typeof maybeResponse.json === 'function');
};
// Storage helpers
export const setItemAsync = async (storage, key, data) => {
    await storage.setItem(key, JSON.stringify(data));
};
export const getItemAsync = async (storage, key) => {
    const value = await storage.getItem(key);
    if (!value) {
        return null;
    }
    try {
        return JSON.parse(value);
    }
    catch (_a) {
        // Storage values are always written as JSON via setItemAsync. A non-JSON
        // value means the entry is corrupted (e.g. mismatched chunked cookies in
        // SSR contexts). Treat as absent so callers do not mutate or re-save the
        // garbage, which would otherwise trigger a TypeError downstream and
        // leak the raw value into error logs.
        return null;
    }
};
export const removeItemAsync = async (storage, key) => {
    await storage.removeItem(key);
};
/**
 * A deferred represents some asynchronous work that is not yet finished, which
 * may or may not culminate in a value.
 * Taken from: https://github.com/mike-north/types/blob/master/src/async.ts
 */
export class Deferred {
    constructor() {
        // eslint-disable-next-line @typescript-eslint/no-extra-semi
        ;
        this.promise = new Deferred.promiseConstructor((res, rej) => {
            // eslint-disable-next-line @typescript-eslint/no-extra-semi
            ;
            this.resolve = res;
            this.reject = rej;
        });
    }
}
Deferred.promiseConstructor = Promise;
export function decodeJWT(token) {
    const parts = token.split('.');
    if (parts.length !== 3) {
        throw new AuthInvalidJwtError('Invalid JWT structure');
    }
    // Regex checks for base64url format
    for (let i = 0; i < parts.length; i++) {
        if (!BASE64URL_REGEX.test(parts[i])) {
            throw new AuthInvalidJwtError('JWT not in base64url format');
        }
    }
    const data = {
        // using base64url lib
        header: JSON.parse(stringFromBase64URL(parts[0])),
        payload: JSON.parse(stringFromBase64URL(parts[1])),
        signature: base64UrlToUint8Array(parts[2]),
        raw: {
            header: parts[0],
            payload: parts[1],
        },
    };
    return data;
}
/**
 * Creates a promise that resolves to null after some time.
 */
export async function sleep(time) {
    return await new Promise((accept) => {
        setTimeout(() => accept(null), time);
    });
}
/**
 * Converts the provided async function into a retryable function. Each result
 * or thrown error is sent to the isRetryable function which should return true
 * if the function should run again.
 */
export function retryable(fn, isRetryable) {
    const promise = new Promise((accept, reject) => {
        // eslint-disable-next-line @typescript-eslint/no-extra-semi
        ;
        (async () => {
            for (let attempt = 0; attempt < Infinity; attempt++) {
                try {
                    const result = await fn(attempt);
                    if (!isRetryable(attempt, null, result)) {
                        accept(result);
                        return;
                    }
                }
                catch (e) {
                    if (!isRetryable(attempt, e)) {
                        reject(e);
                        return;
                    }
                }
            }
        })();
    });
    return promise;
}
function dec2hex(dec) {
    return ('0' + dec.toString(16)).substr(-2);
}
// Functions below taken from: https://stackoverflow.com/questions/63309409/creating-a-code-verifier-and-challenge-for-pkce-auth-on-spotify-api-in-reactjs
export function generatePKCEVerifier() {
    const verifierLength = 56;
    const array = new Uint32Array(verifierLength);
    if (typeof crypto === 'undefined') {
        const charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
        const charSetLen = charSet.length;
        let verifier = '';
        for (let i = 0; i < verifierLength; i++) {
            verifier += charSet.charAt(Math.floor(Math.random() * charSetLen));
        }
        return verifier;
    }
    crypto.getRandomValues(array);
    return Array.from(array, dec2hex).join('');
}
async function sha256(randomString) {
    const encoder = new TextEncoder();
    const encodedData = encoder.encode(randomString);
    const hash = await crypto.subtle.digest('SHA-256', encodedData);
    const bytes = new Uint8Array(hash);
    return Array.from(bytes)
        .map((c) => String.fromCharCode(c))
        .join('');
}
export async function generatePKCEChallenge(verifier) {
    const hasCryptoSupport = typeof crypto !== 'undefined' &&
        typeof crypto.subtle !== 'undefined' &&
        typeof TextEncoder !== 'undefined';
    if (!hasCryptoSupport) {
        console.warn('WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256.');
        return verifier;
    }
    const hashed = await sha256(verifier);
    return btoa(hashed).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export async function getCodeChallengeAndMethod(storage, storageKey, isPasswordRecovery = false) {
    const codeVerifier = generatePKCEVerifier();
    let storedCodeVerifier = codeVerifier;
    if (isPasswordRecovery) {
        storedCodeVerifier += '/recovery';
    }
    await setItemAsync(storage, `${storageKey}-code-verifier`, storedCodeVerifier);
    const codeChallenge = await generatePKCEChallenge(codeVerifier);
    const codeChallengeMethod = codeVerifier === codeChallenge ? 'plain' : 's256';
    return [codeChallenge, codeChallengeMethod];
}
/** Parses the API version which is 2YYY-MM-DD. */
const API_VERSION_REGEX = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;
export function parseResponseAPIVersion(response) {
    const apiVersion = response.headers.get(API_VERSION_HEADER_NAME);
    if (!apiVersion) {
        return null;
    }
    if (!apiVersion.match(API_VERSION_REGEX)) {
        return null;
    }
    try {
        const date = new Date(`${apiVersion}T00:00:00.0Z`);
        return date;
    }
    catch (_e) {
        return null;
    }
}
export function validateExp(exp) {
    if (!exp) {
        throw new Error('Missing exp claim');
    }
    const timeNow = Math.floor(Date.now() / 1000);
    if (exp <= timeNow) {
        throw new Error('JWT has expired');
    }
}
export function getAlgorithm(alg) {
    switch (alg) {
        case 'RS256':
            return {
                name: 'RSASSA-PKCS1-v1_5',
                hash: { name: 'SHA-256' },
            };
        case 'ES256':
            return {
                name: 'ECDSA',
                namedCurve: 'P-256',
                hash: { name: 'SHA-256' },
            };
        default:
            throw new Error('Invalid alg claim');
    }
}
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export function validateUUID(str) {
    if (!UUID_REGEX.test(str)) {
        throw new Error('@supabase/auth-js: Expected parameter to be UUID but is not');
    }
}
export function assertPasskeyExperimentalEnabled(experimental) {
    if (!experimental.passkey) {
        throw new Error('@supabase/auth-js: the passkey API is experimental and disabled by default. Enable it by passing `auth: { experimental: { passkey: true } }` to createClient (or to the GoTrueClient constructor).');
    }
}
export function userNotAvailableProxy() {
    const proxyTarget = {};
    return new Proxy(proxyTarget, {
        get: (target, prop) => {
            if (prop === '__isUserNotAvailableProxy') {
                return true;
            }
            // Preventative check for common problematic symbols during cloning/inspection
            // These symbols might be accessed by structuredClone or other internal mechanisms.
            if (typeof prop === 'symbol') {
                const sProp = prop.toString();
                if (sProp === 'Symbol(Symbol.toPrimitive)' ||
                    sProp === 'Symbol(Symbol.toStringTag)' ||
                    sProp === 'Symbol(util.inspect.custom)') {
                    // Node.js util.inspect
                    return undefined;
                }
            }
            throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Accessing the "${prop}" property of the session object is not supported. Please use getUser() instead.`);
        },
        set: (_target, prop) => {
            throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Setting the "${prop}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`);
        },
        deleteProperty: (_target, prop) => {
            throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Deleting the "${prop}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`);
        },
    });
}
/**
 * Creates a proxy around a user object that warns when properties are accessed on the server.
 * This is used to alert developers that using user data from getSession() on the server is insecure.
 *
 * @param user The actual user object to wrap
 * @param suppressWarningRef An object with a 'value' property that controls warning suppression
 * @returns A proxied user object that warns on property access
 */
export function insecureUserWarningProxy(user, suppressWarningRef) {
    return new Proxy(user, {
        get: (target, prop, receiver) => {
            // Allow internal checks without warning
            if (prop === '__isInsecureUserWarningProxy') {
                return true;
            }
            // Preventative check for common problematic symbols during cloning/inspection
            // These symbols might be accessed by structuredClone or other internal mechanisms
            if (typeof prop === 'symbol') {
                const sProp = prop.toString();
                if (sProp === 'Symbol(Symbol.toPrimitive)' ||
                    sProp === 'Symbol(Symbol.toStringTag)' ||
                    sProp === 'Symbol(util.inspect.custom)' ||
                    sProp === 'Symbol(nodejs.util.inspect.custom)') {
                    // Return the actual value for these symbols to allow proper inspection
                    return Reflect.get(target, prop, receiver);
                }
            }
            // Emit warning on first property access
            if (!suppressWarningRef.value && typeof prop === 'string') {
                console.warn('Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server.');
                suppressWarningRef.value = true;
            }
            return Reflect.get(target, prop, receiver);
        },
    });
}
/**
 * Deep clones a JSON-serializable object using JSON.parse(JSON.stringify(obj)).
 * Note: Only works for JSON-safe data.
 */
export function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}
                                   
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9saWIvaGVscGVycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsZUFBZSxFQUFFLE1BQU0sYUFBYSxDQUFBO0FBQ3RFLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLFVBQVUsQ0FBQTtBQUM5QyxPQUFPLEVBQUUscUJBQXFCLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxhQUFhLENBQUE7QUFJeEUsTUFBTSxVQUFVLFNBQVMsQ0FBQyxTQUFpQjtJQUN6QyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQTtJQUM3QyxPQUFPLE9BQU8sR0FBRyxTQUFTLENBQUE7QUFDNUIsQ0FBQztBQUVEOzs7Ozs7Ozs7Ozs7R0FZRztBQUNILE1BQU0sVUFBVSxrQkFBa0I7SUFDaEMsT0FBTyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUE7QUFDaEMsQ0FBQztBQUVELE1BQU0sQ0FBQyxNQUFNLFNBQVMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxPQUFPLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxDQUFBO0FBRS9GLE1BQU0sc0JBQXNCLEdBQUc7SUFDN0IsTUFBTSxFQUFFLEtBQUs7SUFDYixRQUFRLEVBQUUsS0FBSztDQUNoQixDQUFBO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLENBQUMsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLEVBQUU7SUFDdkMsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUM7UUFDakIsT0FBTyxLQUFLLENBQUE7SUFDZCxDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsSUFBSSxPQUFPLFVBQVUsQ0FBQyxZQUFZLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDaEQsT0FBTyxLQUFLLENBQUE7UUFDZCxDQUFDO0lBQ0gsQ0FBQztJQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7UUFDWCw4Q0FBOEM7UUFDOUMsT0FBTyxLQUFLLENBQUE7SUFDZCxDQUFDO0lBRUQsSUFBSSxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNsQyxPQUFPLHNCQUFzQixDQUFDLFFBQVEsQ0FBQTtJQUN4QyxDQUFDO0lBRUQsTUFBTSxTQUFTLEdBQUcsUUFBUSxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUE7SUFFekQsSUFBSSxDQUFDO1FBQ0gsVUFBVSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFBO1FBQ3JELFVBQVUsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBRTdDLHNCQUFzQixDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUE7UUFDcEMsc0JBQXNCLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQTtJQUN4QyxDQUFDO0lBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztRQUNYLG1DQUFtQztRQUNuQywrS0FBK0s7UUFFL0ssc0JBQXNCLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQTtRQUNwQyxzQkFBc0IsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFBO0lBQ3pDLENBQUM7SUFFRCxPQUFPLHNCQUFzQixDQUFDLFFBQVEsQ0FBQTtBQUN4QyxDQUFDLENBQUE7QUFFRDs7R0FFRztBQUNILE1BQU0sVUFBVSxzQkFBc0IsQ0FBQyxJQUFZO0lBQ2pELE1BQU0sTUFBTSxHQUFvQyxFQUFFLENBQUE7SUFFbEQsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFekIsSUFBSSxHQUFHLENBQUMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLGVBQWUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQ25FLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtnQkFDdEMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQTtZQUNyQixDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO1lBQ1osNkJBQTZCO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRUQseURBQXlEO0lBQ3pELEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO1FBQ3RDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUE7SUFDckIsQ0FBQyxDQUFDLENBQUE7SUFFRixPQUFPLE1BQU0sQ0FBQTtBQUNmLENBQUM7QUFJRCxNQUFNLENBQUMsTUFBTSxZQUFZLEdBQUcsQ0FBQyxXQUFtQixFQUFTLEVBQUU7SUFDekQsSUFBSSxXQUFXLEVBQUUsQ0FBQztRQUNoQixPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFBO0lBQzFDLENBQUM7SUFDRCxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFBO0FBQ3BDLENBQUMsQ0FBQTtBQUVELE1BQU0sQ0FBQyxNQUFNLHNCQUFzQixHQUFHLENBQUMsYUFBc0IsRUFBNkIsRUFBRTtJQUMxRixPQUFPLENBQ0wsT0FBTyxhQUFhLEtBQUssUUFBUTtRQUNqQyxhQUFhLEtBQUssSUFBSTtRQUN0QixRQUFRLElBQUksYUFBYTtRQUN6QixJQUFJLElBQUksYUFBYTtRQUNyQixNQUFNLElBQUksYUFBYTtRQUN2QixPQUFRLGFBQXFCLENBQUMsSUFBSSxLQUFLLFVBQVUsQ0FDbEQsQ0FBQTtBQUNILENBQUMsQ0FBQTtBQUVELGtCQUFrQjtBQUNsQixNQUFNLENBQUMsTUFBTSxZQUFZLEdBQUcsS0FBSyxFQUMvQixPQUF5QixFQUN6QixHQUFXLEVBQ1gsSUFBUyxFQUNNLEVBQUU7SUFDakIsTUFBTSxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7QUFDbEQsQ0FBQyxDQUFBO0FBRUQsTUFBTSxDQUFDLE1BQU0sWUFBWSxHQUFHLEtBQUssRUFBRSxPQUF5QixFQUFFLEdBQVcsRUFBb0IsRUFBRTtJQUM3RixNQUFNLEtBQUssR0FBRyxNQUFNLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUE7SUFFeEMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ1gsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQzFCLENBQUM7SUFBQyxXQUFNLENBQUM7UUFDUCx5RUFBeUU7UUFDekUseUVBQXlFO1FBQ3pFLHlFQUF5RTtRQUN6RSxvRUFBb0U7UUFDcEUsc0NBQXNDO1FBQ3RDLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztBQUNILENBQUMsQ0FBQTtBQUVELE1BQU0sQ0FBQyxNQUFNLGVBQWUsR0FBRyxLQUFLLEVBQUUsT0FBeUIsRUFBRSxHQUFXLEVBQWlCLEVBQUU7SUFDN0YsTUFBTSxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQy9CLENBQUMsQ0FBQTtBQUVEOzs7O0dBSUc7QUFDSCxNQUFNLE9BQU8sUUFBUTtJQVNuQjtRQUNFLDREQUE0RDtRQUM1RCxDQUFDO1FBQUMsSUFBWSxDQUFDLE9BQU8sR0FBRyxJQUFJLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUNwRSw0REFBNEQ7WUFDNUQsQ0FBQztZQUFDLElBQVksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUUzQjtZQUFDLElBQVksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFBO1FBQzdCLENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQzs7QUFoQmEsMkJBQWtCLEdBQXVCLE9BQU8sQ0FBQTtBQW1CaEUsTUFBTSxVQUFVLFNBQVMsQ0FBQyxLQUFhO0lBU3JDLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7SUFFOUIsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ3ZCLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO0lBQ3hELENBQUM7SUFFRCxvQ0FBb0M7SUFDcEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFXLENBQUMsRUFBRSxDQUFDO1lBQzlDLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFBO1FBQzlELENBQUM7SUFDSCxDQUFDO0lBQ0QsTUFBTSxJQUFJLEdBQUc7UUFDWCxzQkFBc0I7UUFDdEIsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakQsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEQsU0FBUyxFQUFFLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMxQyxHQUFHLEVBQUU7WUFDSCxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUNoQixPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztTQUNsQjtLQUNGLENBQUE7SUFDRCxPQUFPLElBQUksQ0FBQTtBQUNiLENBQUM7QUFFRDs7R0FFRztBQUNILE1BQU0sQ0FBQyxLQUFLLFVBQVUsS0FBSyxDQUFDLElBQVk7SUFDdEMsT0FBTyxNQUFNLElBQUksT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUU7UUFDbEMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQTtJQUN0QyxDQUFDLENBQUMsQ0FBQTtBQUNKLENBQUM7QUFFRDs7OztHQUlHO0FBQ0gsTUFBTSxVQUFVLFNBQVMsQ0FDdkIsRUFBbUMsRUFDbkMsV0FBd0U7SUFFeEUsTUFBTSxPQUFPLEdBQUcsSUFBSSxPQUFPLENBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7UUFDaEQsNERBQTREO1FBQzVELENBQUM7UUFBQSxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ1gsS0FBSyxJQUFJLE9BQU8sR0FBRyxDQUFDLEVBQUUsT0FBTyxHQUFHLFFBQVEsRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDO2dCQUNwRCxJQUFJLENBQUM7b0JBQ0gsTUFBTSxNQUFNLEdBQUcsTUFBTSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUE7b0JBRWhDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDO3dCQUN4QyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUE7d0JBQ2QsT0FBTTtvQkFDUixDQUFDO2dCQUNILENBQUM7Z0JBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztvQkFDWCxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO3dCQUM3QixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUE7d0JBQ1QsT0FBTTtvQkFDUixDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUNOLENBQUMsQ0FBQyxDQUFBO0lBRUYsT0FBTyxPQUFPLENBQUE7QUFDaEIsQ0FBQztBQUVELFNBQVMsT0FBTyxDQUFDLEdBQVc7SUFDMUIsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDNUMsQ0FBQztBQUVELDBKQUEwSjtBQUMxSixNQUFNLFVBQVUsb0JBQW9CO0lBQ2xDLE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQTtJQUN6QixNQUFNLEtBQUssR0FBRyxJQUFJLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQTtJQUM3QyxJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVcsRUFBRSxDQUFDO1FBQ2xDLE1BQU0sT0FBTyxHQUFHLG9FQUFvRSxDQUFBO1FBQ3BGLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUE7UUFDakMsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFBO1FBQ2pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxjQUFjLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUN4QyxRQUFRLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFBO1FBQ3BFLENBQUM7UUFDRCxPQUFPLFFBQVEsQ0FBQTtJQUNqQixDQUFDO0lBQ0QsTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUM3QixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUM1QyxDQUFDO0FBRUQsS0FBSyxVQUFVLE1BQU0sQ0FBQyxZQUFvQjtJQUN4QyxNQUFNLE9BQU8sR0FBRyxJQUFJLFdBQVcsRUFBRSxDQUFBO0lBQ2pDLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUE7SUFDaEQsTUFBTSxJQUFJLEdBQUcsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUE7SUFDL0QsTUFBTSxLQUFLLEdBQUcsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFbEMsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztTQUNyQixHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDbEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ2IsQ0FBQztBQUVELE1BQU0sQ0FBQyxLQUFLLFVBQVUscUJBQXFCLENBQUMsUUFBZ0I7SUFDMUQsTUFBTSxnQkFBZ0IsR0FDcEIsT0FBTyxNQUFNLEtBQUssV0FBVztRQUM3QixPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVztRQUNwQyxPQUFPLFdBQVcsS0FBSyxXQUFXLENBQUE7SUFFcEMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDdEIsT0FBTyxDQUFDLElBQUksQ0FDVixvR0FBb0csQ0FDckcsQ0FBQTtRQUNELE9BQU8sUUFBUSxDQUFBO0lBQ2pCLENBQUM7SUFDRCxNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUNyQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQTtBQUNoRixDQUFDO0FBRUQsTUFBTSxDQUFDLEtBQUssVUFBVSx5QkFBeUIsQ0FDN0MsT0FBeUIsRUFDekIsVUFBa0IsRUFDbEIsa0JBQWtCLEdBQUcsS0FBSztJQUUxQixNQUFNLFlBQVksR0FBRyxvQkFBb0IsRUFBRSxDQUFBO0lBQzNDLElBQUksa0JBQWtCLEdBQUcsWUFBWSxDQUFBO0lBQ3JDLElBQUksa0JBQWtCLEVBQUUsQ0FBQztRQUN2QixrQkFBa0IsSUFBSSxXQUFXLENBQUE7SUFDbkMsQ0FBQztJQUNELE1BQU0sWUFBWSxDQUFDLE9BQU8sRUFBRSxHQUFHLFVBQVUsZ0JBQWdCLEVBQUUsa0JBQWtCLENBQUMsQ0FBQTtJQUM5RSxNQUFNLGFBQWEsR0FBRyxNQUFNLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFBO0lBQy9ELE1BQU0sbUJBQW1CLEdBQUcsWUFBWSxLQUFLLGFBQWEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUE7SUFDN0UsT0FBTyxDQUFDLGFBQWEsRUFBRSxtQkFBbUIsQ0FBQyxDQUFBO0FBQzdDLENBQUM7QUFFRCxrREFBa0Q7QUFDbEQsTUFBTSxpQkFBaUIsR0FBRyw0REFBNEQsQ0FBQTtBQUV0RixNQUFNLFVBQVUsdUJBQXVCLENBQUMsUUFBa0I7SUFDeEQsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtJQUVoRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBRUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDO1FBQ3pDLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsVUFBVSxjQUFjLENBQUMsQ0FBQTtRQUNsRCxPQUFPLElBQUksQ0FBQTtJQUNiLENBQUM7SUFBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO1FBQ1osT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0FBQ0gsQ0FBQztBQUVELE1BQU0sVUFBVSxXQUFXLENBQUMsR0FBVztJQUNyQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDVCxNQUFNLElBQUksS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUE7SUFDdEMsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFBO0lBQzdDLElBQUksR0FBRyxJQUFJLE9BQU8sRUFBRSxDQUFDO1FBQ25CLE1BQU0sSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQTtJQUNwQyxDQUFDO0FBQ0gsQ0FBQztBQUVELE1BQU0sVUFBVSxZQUFZLENBQzFCLEdBQWdEO0lBRWhELFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDWixLQUFLLE9BQU87WUFDVixPQUFPO2dCQUNMLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7YUFDMUIsQ0FBQTtRQUNILEtBQUssT0FBTztZQUNWLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsVUFBVSxFQUFFLE9BQU87Z0JBQ25CLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7YUFDMUIsQ0FBQTtRQUNIO1lBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0lBQ3hDLENBQUM7QUFDSCxDQUFDO0FBRUQsTUFBTSxVQUFVLEdBQUcsZ0VBQWdFLENBQUE7QUFFbkYsTUFBTSxVQUFVLFlBQVksQ0FBQyxHQUFXO0lBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDMUIsTUFBTSxJQUFJLEtBQUssQ0FBQyw2REFBNkQsQ0FBQyxDQUFBO0lBQ2hGLENBQUM7QUFDSCxDQUFDO0FBRUQsTUFBTSxVQUFVLGdDQUFnQyxDQUFDLFlBQW1DO0lBQ2xGLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDMUIsTUFBTSxJQUFJLEtBQUssQ0FDYixvTUFBb00sQ0FDck0sQ0FBQTtJQUNILENBQUM7QUFDSCxDQUFDO0FBRUQsTUFBTSxVQUFVLHFCQUFxQjtJQUNuQyxNQUFNLFdBQVcsR0FBRyxFQUFVLENBQUE7SUFFOUIsT0FBTyxJQUFJLEtBQUssQ0FBQyxXQUFXLEVBQUU7UUFDNUIsR0FBRyxFQUFFLENBQUMsTUFBVyxFQUFFLElBQVksRUFBRSxFQUFFO1lBQ2pDLElBQUksSUFBSSxLQUFLLDJCQUEyQixFQUFFLENBQUM7Z0JBQ3pDLE9BQU8sSUFBSSxDQUFBO1lBQ2IsQ0FBQztZQUNELDhFQUE4RTtZQUM5RSxtRkFBbUY7WUFDbkYsSUFBSSxPQUFPLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQztnQkFDN0IsTUFBTSxLQUFLLEdBQUksSUFBZSxDQUFDLFFBQVEsRUFBRSxDQUFBO2dCQUN6QyxJQUNFLEtBQUssS0FBSyw0QkFBNEI7b0JBQ3RDLEtBQUssS0FBSyw0QkFBNEI7b0JBQ3RDLEtBQUssS0FBSyw2QkFBNkIsRUFDdkMsQ0FBQztvQkFDRCx1QkFBdUI7b0JBQ3ZCLE9BQU8sU0FBUyxDQUFBO2dCQUNsQixDQUFDO1lBQ0gsQ0FBQztZQUNELE1BQU0sSUFBSSxLQUFLLENBQ2Isa0lBQWtJLElBQUksa0ZBQWtGLENBQ3pOLENBQUE7UUFDSCxDQUFDO1FBQ0QsR0FBRyxFQUFFLENBQUMsT0FBWSxFQUFFLElBQVksRUFBRSxFQUFFO1lBQ2xDLE1BQU0sSUFBSSxLQUFLLENBQ2IsZ0lBQWdJLElBQUksb0hBQW9ILENBQ3pQLENBQUE7UUFDSCxDQUFDO1FBQ0QsY0FBYyxFQUFFLENBQUMsT0FBWSxFQUFFLElBQVksRUFBRSxFQUFFO1lBQzdDLE1BQU0sSUFBSSxLQUFLLENBQ2IsaUlBQWlJLElBQUksb0hBQW9ILENBQzFQLENBQUE7UUFDSCxDQUFDO0tBQ0YsQ0FBQyxDQUFBO0FBQ0osQ0FBQztBQUVEOzs7Ozs7O0dBT0c7QUFDSCxNQUFNLFVBQVUsd0JBQXdCLENBQUMsSUFBVSxFQUFFLGtCQUFzQztJQUN6RixPQUFPLElBQUksS0FBSyxDQUFDLElBQUksRUFBRTtRQUNyQixHQUFHLEVBQUUsQ0FBQyxNQUFXLEVBQUUsSUFBcUIsRUFBRSxRQUFhLEVBQUUsRUFBRTtZQUN6RCx3Q0FBd0M7WUFDeEMsSUFBSSxJQUFJLEtBQUssOEJBQThCLEVBQUUsQ0FBQztnQkFDNUMsT0FBTyxJQUFJLENBQUE7WUFDYixDQUFDO1lBRUQsOEVBQThFO1lBQzlFLGtGQUFrRjtZQUNsRixJQUFJLE9BQU8sSUFBSSxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUM3QixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUE7Z0JBQzdCLElBQ0UsS0FBSyxLQUFLLDRCQUE0QjtvQkFDdEMsS0FBSyxLQUFLLDRCQUE0QjtvQkFDdEMsS0FBSyxLQUFLLDZCQUE2QjtvQkFDdkMsS0FBSyxLQUFLLG9DQUFvQyxFQUM5QyxDQUFDO29CQUNELHVFQUF1RTtvQkFDdkUsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUE7Z0JBQzVDLENBQUM7WUFDSCxDQUFDO1lBRUQsd0NBQXdDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxFQUFFLENBQUM7Z0JBQzFELE9BQU8sQ0FBQyxJQUFJLENBQ1YsaVdBQWlXLENBQ2xXLENBQUE7Z0JBQ0Qsa0JBQWtCLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQTtZQUNqQyxDQUFDO1lBRUQsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUE7UUFDNUMsQ0FBQztLQUNGLENBQUMsQ0FBQTtBQUNKLENBQUM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLFVBQVUsU0FBUyxDQUFJLEdBQU07SUFDakMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtBQUN4QyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQVBJX1ZFUlNJT05fSEVBREVSX05BTUUsIEJBU0U2NFVSTF9SRUdFWCB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgQXV0aEludmFsaWRKd3RFcnJvciB9IGZyb20gJy4vZXJyb3JzJ1xuaW1wb3J0IHsgYmFzZTY0VXJsVG9VaW50OEFycmF5LCBzdHJpbmdGcm9tQmFzZTY0VVJMIH0gZnJvbSAnLi9iYXNlNjR1cmwnXG5pbXBvcnQgeyBKd3RIZWFkZXIsIEp3dFBheWxvYWQsIFN1cHBvcnRlZFN0b3JhZ2UsIFVzZXIgfSBmcm9tICcuL3R5cGVzJ1xuaW1wb3J0IHsgVWludDhBcnJheV8gfSBmcm9tICcuL3dlYmF1dGhuLmRvbSdcblxuZXhwb3J0IGZ1bmN0aW9uIGV4cGlyZXNBdChleHBpcmVzSW46IG51bWJlcikge1xuICBjb25zdCB0aW1lTm93ID0gTWF0aC5yb3VuZChEYXRlLm5vdygpIC8gMTAwMClcbiAgcmV0dXJuIHRpbWVOb3cgKyBleHBpcmVzSW5cbn1cblxuLyoqXG4gKiBHZW5lcmF0ZXMgYSB1bmlxdWUgaWRlbnRpZmllciBmb3IgaW50ZXJuYWwgY2FsbGJhY2sgc3Vic2NyaXB0aW9ucy5cbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIHVzZXMgSmF2YVNjcmlwdCBTeW1ib2xzIHRvIGNyZWF0ZSBndWFyYW50ZWVkLXVuaXF1ZSBpZGVudGlmaWVyc1xuICogZm9yIGF1dGggc3RhdGUgY2hhbmdlIGNhbGxiYWNrcy4gU3ltYm9scyBhcmUgaWRlYWwgZm9yIHRoaXMgdXNlIGNhc2UgYmVjYXVzZTpcbiAqIC0gVGhleSBhcmUgZ3VhcmFudGVlZCB1bmlxdWUgYnkgdGhlIEphdmFTY3JpcHQgcnVudGltZVxuICogLSBUaGV5IHdvcmsgaW4gYWxsIGVudmlyb25tZW50cyAoYnJvd3NlciwgU1NSLCBOb2RlLmpzKVxuICogLSBUaGV5IGF2b2lkIGlzc3VlcyB3aXRoIE5leHQuanMgMTYgZGV0ZXJtaW5pc3RpYyByZW5kZXJpbmcgcmVxdWlyZW1lbnRzXG4gKiAtIFRoZXkgYXJlIHBlcmZlY3QgZm9yIGludGVybmFsLCBub24tc2VyaWFsaXphYmxlIGlkZW50aWZpZXJzXG4gKlxuICogTm90ZTogVGhpcyBmdW5jdGlvbiBpcyBvbmx5IHVzZWQgZm9yIGludGVybmFsIHN1YnNjcmlwdGlvbiBtYW5hZ2VtZW50LFxuICogbm90IGZvciBzZWN1cml0eS1jcml0aWNhbCBvcGVyYXRpb25zIGxpa2Ugc2Vzc2lvbiB0b2tlbnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZUNhbGxiYWNrSWQoKTogc3ltYm9sIHtcbiAgcmV0dXJuIFN5bWJvbCgnYXV0aC1jYWxsYmFjaycpXG59XG5cbmV4cG9ydCBjb25zdCBpc0Jyb3dzZXIgPSAoKSA9PiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnXG5cbmNvbnN0IGxvY2FsU3RvcmFnZVdyaXRlVGVzdHMgPSB7XG4gIHRlc3RlZDogZmFsc2UsXG4gIHdyaXRhYmxlOiBmYWxzZSxcbn1cblxuLyoqXG4gKiBDaGVja3Mgd2hldGhlciBsb2NhbFN0b3JhZ2UgaXMgc3VwcG9ydGVkIG9uIHRoaXMgYnJvd3Nlci5cbiAqL1xuZXhwb3J0IGNvbnN0IHN1cHBvcnRzTG9jYWxTdG9yYWdlID0gKCkgPT4ge1xuICBpZiAoIWlzQnJvd3NlcigpKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICB0cnkge1xuICAgIGlmICh0eXBlb2YgZ2xvYmFsVGhpcy5sb2NhbFN0b3JhZ2UgIT09ICdvYmplY3QnKSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAvLyBET00gZXhjZXB0aW9uIHdoZW4gYWNjZXNzaW5nIGBsb2NhbFN0b3JhZ2VgXG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBpZiAobG9jYWxTdG9yYWdlV3JpdGVUZXN0cy50ZXN0ZWQpIHtcbiAgICByZXR1cm4gbG9jYWxTdG9yYWdlV3JpdGVUZXN0cy53cml0YWJsZVxuICB9XG5cbiAgY29uc3QgcmFuZG9tS2V5ID0gYGxzd3QtJHtNYXRoLnJhbmRvbSgpfSR7TWF0aC5yYW5kb20oKX1gXG5cbiAgdHJ5IHtcbiAgICBnbG9iYWxUaGlzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKHJhbmRvbUtleSwgcmFuZG9tS2V5KVxuICAgIGdsb2JhbFRoaXMubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0ocmFuZG9tS2V5KVxuXG4gICAgbG9jYWxTdG9yYWdlV3JpdGVUZXN0cy50ZXN0ZWQgPSB0cnVlXG4gICAgbG9jYWxTdG9yYWdlV3JpdGVUZXN0cy53cml0YWJsZSA9IHRydWVcbiAgfSBjYXRjaCAoZSkge1xuICAgIC8vIGxvY2FsU3RvcmFnZSBjYW4ndCBiZSB3cml0dGVuIHRvXG4gICAgLy8gaHR0cHM6Ly93d3cuY2hyb21pdW0ub3JnL2Zvci10ZXN0ZXJzL2J1Zy1yZXBvcnRpbmctZ3VpZGVsaW5lcy91bmNhdWdodC1zZWN1cml0eWVycm9yLWZhaWxlZC10by1yZWFkLXRoZS1sb2NhbHN0b3JhZ2UtcHJvcGVydHktZnJvbS13aW5kb3ctYWNjZXNzLWlzLWRlbmllZC1mb3ItdGhpcy1kb2N1bWVudFxuXG4gICAgbG9jYWxTdG9yYWdlV3JpdGVUZXN0cy50ZXN0ZWQgPSB0cnVlXG4gICAgbG9jYWxTdG9yYWdlV3JpdGVUZXN0cy53cml0YWJsZSA9IGZhbHNlXG4gIH1cblxuICByZXR1cm4gbG9jYWxTdG9yYWdlV3JpdGVUZXN0cy53cml0YWJsZVxufVxuXG4vKipcbiAqIEV4dHJhY3RzIHBhcmFtZXRlcnMgZW5jb2RlZCBpbiB0aGUgVVJMIGJvdGggaW4gdGhlIHF1ZXJ5IGFuZCBmcmFnbWVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlUGFyYW1ldGVyc0Zyb21VUkwoaHJlZjogc3RyaW5nKSB7XG4gIGNvbnN0IHJlc3VsdDogeyBbcGFyYW1ldGVyOiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9XG5cbiAgY29uc3QgdXJsID0gbmV3IFVSTChocmVmKVxuXG4gIGlmICh1cmwuaGFzaCAmJiB1cmwuaGFzaFswXSA9PT0gJyMnKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGhhc2hTZWFyY2hQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHVybC5oYXNoLnN1YnN0cmluZygxKSlcbiAgICAgIGhhc2hTZWFyY2hQYXJhbXMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xuICAgICAgICByZXN1bHRba2V5XSA9IHZhbHVlXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKF9lKSB7XG4gICAgICAvLyBoYXNoIGlzIG5vdCBhIHF1ZXJ5IHN0cmluZ1xuICAgIH1cbiAgfVxuXG4gIC8vIHNlYXJjaCBwYXJhbWV0ZXJzIHRha2UgcHJlY2VkZW5jZSBvdmVyIGhhc2ggcGFyYW1ldGVyc1xuICB1cmwuc2VhcmNoUGFyYW1zLmZvckVhY2goKHZhbHVlLCBrZXkpID0+IHtcbiAgICByZXN1bHRba2V5XSA9IHZhbHVlXG4gIH0pXG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG50eXBlIEZldGNoID0gdHlwZW9mIGZldGNoXG5cbmV4cG9ydCBjb25zdCByZXNvbHZlRmV0Y2ggPSAoY3VzdG9tRmV0Y2g/OiBGZXRjaCk6IEZldGNoID0+IHtcbiAgaWYgKGN1c3RvbUZldGNoKSB7XG4gICAgcmV0dXJuICguLi5hcmdzKSA9PiBjdXN0b21GZXRjaCguLi5hcmdzKVxuICB9XG4gIHJldHVybiAoLi4uYXJncykgPT4gZmV0Y2goLi4uYXJncylcbn1cblxuZXhwb3J0IGNvbnN0IGxvb2tzTGlrZUZldGNoUmVzcG9uc2UgPSAobWF5YmVSZXNwb25zZTogdW5rbm93bik6IG1heWJlUmVzcG9uc2UgaXMgUmVzcG9uc2UgPT4ge1xuICByZXR1cm4gKFxuICAgIHR5cGVvZiBtYXliZVJlc3BvbnNlID09PSAnb2JqZWN0JyAmJlxuICAgIG1heWJlUmVzcG9uc2UgIT09IG51bGwgJiZcbiAgICAnc3RhdHVzJyBpbiBtYXliZVJlc3BvbnNlICYmXG4gICAgJ29rJyBpbiBtYXliZVJlc3BvbnNlICYmXG4gICAgJ2pzb24nIGluIG1heWJlUmVzcG9uc2UgJiZcbiAgICB0eXBlb2YgKG1heWJlUmVzcG9uc2UgYXMgYW55KS5qc29uID09PSAnZnVuY3Rpb24nXG4gIClcbn1cblxuLy8gU3RvcmFnZSBoZWxwZXJzXG5leHBvcnQgY29uc3Qgc2V0SXRlbUFzeW5jID0gYXN5bmMgKFxuICBzdG9yYWdlOiBTdXBwb3J0ZWRTdG9yYWdlLFxuICBrZXk6IHN0cmluZyxcbiAgZGF0YTogYW55XG4pOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgYXdhaXQgc3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpXG59XG5cbmV4cG9ydCBjb25zdCBnZXRJdGVtQXN5bmMgPSBhc3luYyAoc3RvcmFnZTogU3VwcG9ydGVkU3RvcmFnZSwga2V5OiBzdHJpbmcpOiBQcm9taXNlPHVua25vd24+ID0+IHtcbiAgY29uc3QgdmFsdWUgPSBhd2FpdCBzdG9yYWdlLmdldEl0ZW0oa2V5KVxuXG4gIGlmICghdmFsdWUpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSlcbiAgfSBjYXRjaCB7XG4gICAgLy8gU3RvcmFnZSB2YWx1ZXMgYXJlIGFsd2F5cyB3cml0dGVuIGFzIEpTT04gdmlhIHNldEl0ZW1Bc3luYy4gQSBub24tSlNPTlxuICAgIC8vIHZhbHVlIG1lYW5zIHRoZSBlbnRyeSBpcyBjb3JydXB0ZWQgKGUuZy4gbWlzbWF0Y2hlZCBjaHVua2VkIGNvb2tpZXMgaW5cbiAgICAvLyBTU1IgY29udGV4dHMpLiBUcmVhdCBhcyBhYnNlbnQgc28gY2FsbGVycyBkbyBub3QgbXV0YXRlIG9yIHJlLXNhdmUgdGhlXG4gICAgLy8gZ2FyYmFnZSwgd2hpY2ggd291bGQgb3RoZXJ3aXNlIHRyaWdnZXIgYSBUeXBlRXJyb3IgZG93bnN0cmVhbSBhbmRcbiAgICAvLyBsZWFrIHRoZSByYXcgdmFsdWUgaW50byBlcnJvciBsb2dzLlxuICAgIHJldHVybiBudWxsXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IHJlbW92ZUl0ZW1Bc3luYyA9IGFzeW5jIChzdG9yYWdlOiBTdXBwb3J0ZWRTdG9yYWdlLCBrZXk6IHN0cmluZyk6IFByb21pc2U8dm9pZD4gPT4ge1xuICBhd2FpdCBzdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KVxufVxuXG4vKipcbiAqIEEgZGVmZXJyZWQgcmVwcmVzZW50cyBzb21lIGFzeW5jaHJvbm91cyB3b3JrIHRoYXQgaXMgbm90IHlldCBmaW5pc2hlZCwgd2hpY2hcbiAqIG1heSBvciBtYXkgbm90IGN1bG1pbmF0ZSBpbiBhIHZhbHVlLlxuICogVGFrZW4gZnJvbTogaHR0cHM6Ly9naXRodWIuY29tL21pa2Utbm9ydGgvdHlwZXMvYmxvYi9tYXN0ZXIvc3JjL2FzeW5jLnRzXG4gKi9cbmV4cG9ydCBjbGFzcyBEZWZlcnJlZDxUID0gYW55PiB7XG4gIHB1YmxpYyBzdGF0aWMgcHJvbWlzZUNvbnN0cnVjdG9yOiBQcm9taXNlQ29uc3RydWN0b3IgPSBQcm9taXNlXG5cbiAgcHVibGljIHJlYWRvbmx5IHByb21pc2UhOiBQcm9taXNlTGlrZTxUPlxuXG4gIHB1YmxpYyByZWFkb25seSByZXNvbHZlITogKHZhbHVlPzogVCB8IFByb21pc2VMaWtlPFQ+KSA9PiB2b2lkXG5cbiAgcHVibGljIHJlYWRvbmx5IHJlamVjdCE6IChyZWFzb24/OiBhbnkpID0+IGFueVxuXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcigpIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4dHJhLXNlbWlcbiAgICA7KHRoaXMgYXMgYW55KS5wcm9taXNlID0gbmV3IERlZmVycmVkLnByb21pc2VDb25zdHJ1Y3RvcigocmVzLCByZWopID0+IHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXh0cmEtc2VtaVxuICAgICAgOyh0aGlzIGFzIGFueSkucmVzb2x2ZSA9IHJlc1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHRyYS1zZW1pXG4gICAgICA7KHRoaXMgYXMgYW55KS5yZWplY3QgPSByZWpcbiAgICB9KVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVKV1QodG9rZW46IHN0cmluZyk6IHtcbiAgaGVhZGVyOiBKd3RIZWFkZXJcbiAgcGF5bG9hZDogSnd0UGF5bG9hZFxuICBzaWduYXR1cmU6IFVpbnQ4QXJyYXlfXG4gIHJhdzoge1xuICAgIGhlYWRlcjogc3RyaW5nXG4gICAgcGF5bG9hZDogc3RyaW5nXG4gIH1cbn0ge1xuICBjb25zdCBwYXJ0cyA9IHRva2VuLnNwbGl0KCcuJylcblxuICBpZiAocGFydHMubGVuZ3RoICE9PSAzKSB7XG4gICAgdGhyb3cgbmV3IEF1dGhJbnZhbGlkSnd0RXJyb3IoJ0ludmFsaWQgSldUIHN0cnVjdHVyZScpXG4gIH1cblxuICAvLyBSZWdleCBjaGVja3MgZm9yIGJhc2U2NHVybCBmb3JtYXRcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXJ0cy5sZW5ndGg7IGkrKykge1xuICAgIGlmICghQkFTRTY0VVJMX1JFR0VYLnRlc3QocGFydHNbaV0gYXMgc3RyaW5nKSkge1xuICAgICAgdGhyb3cgbmV3IEF1dGhJbnZhbGlkSnd0RXJyb3IoJ0pXVCBub3QgaW4gYmFzZTY0dXJsIGZvcm1hdCcpXG4gICAgfVxuICB9XG4gIGNvbnN0IGRhdGEgPSB7XG4gICAgLy8gdXNpbmcgYmFzZTY0dXJsIGxpYlxuICAgIGhlYWRlcjogSlNPTi5wYXJzZShzdHJpbmdGcm9tQmFzZTY0VVJMKHBhcnRzWzBdKSksXG4gICAgcGF5bG9hZDogSlNPTi5wYXJzZShzdHJpbmdGcm9tQmFzZTY0VVJMKHBhcnRzWzFdKSksXG4gICAgc2lnbmF0dXJlOiBiYXNlNjRVcmxUb1VpbnQ4QXJyYXkocGFydHNbMl0pLFxuICAgIHJhdzoge1xuICAgICAgaGVhZGVyOiBwYXJ0c1swXSxcbiAgICAgIHBheWxvYWQ6IHBhcnRzWzFdLFxuICAgIH0sXG4gIH1cbiAgcmV0dXJuIGRhdGFcbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIG51bGwgYWZ0ZXIgc29tZSB0aW1lLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2xlZXAodGltZTogbnVtYmVyKTogUHJvbWlzZTxudWxsPiB7XG4gIHJldHVybiBhd2FpdCBuZXcgUHJvbWlzZSgoYWNjZXB0KSA9PiB7XG4gICAgc2V0VGltZW91dCgoKSA9PiBhY2NlcHQobnVsbCksIHRpbWUpXG4gIH0pXG59XG5cbi8qKlxuICogQ29udmVydHMgdGhlIHByb3ZpZGVkIGFzeW5jIGZ1bmN0aW9uIGludG8gYSByZXRyeWFibGUgZnVuY3Rpb24uIEVhY2ggcmVzdWx0XG4gKiBvciB0aHJvd24gZXJyb3IgaXMgc2VudCB0byB0aGUgaXNSZXRyeWFibGUgZnVuY3Rpb24gd2hpY2ggc2hvdWxkIHJldHVybiB0cnVlXG4gKiBpZiB0aGUgZnVuY3Rpb24gc2hvdWxkIHJ1biBhZ2Fpbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJldHJ5YWJsZTxUPihcbiAgZm46IChhdHRlbXB0OiBudW1iZXIpID0+IFByb21pc2U8VD4sXG4gIGlzUmV0cnlhYmxlOiAoYXR0ZW1wdDogbnVtYmVyLCBlcnJvcjogYW55IHwgbnVsbCwgcmVzdWx0PzogVCkgPT4gYm9vbGVhblxuKTogUHJvbWlzZTxUPiB7XG4gIGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZTxUPigoYWNjZXB0LCByZWplY3QpID0+IHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4dHJhLXNlbWlcbiAgICA7KGFzeW5jICgpID0+IHtcbiAgICAgIGZvciAobGV0IGF0dGVtcHQgPSAwOyBhdHRlbXB0IDwgSW5maW5pdHk7IGF0dGVtcHQrKykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGZuKGF0dGVtcHQpXG5cbiAgICAgICAgICBpZiAoIWlzUmV0cnlhYmxlKGF0dGVtcHQsIG51bGwsIHJlc3VsdCkpIHtcbiAgICAgICAgICAgIGFjY2VwdChyZXN1bHQpXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBpZiAoIWlzUmV0cnlhYmxlKGF0dGVtcHQsIGUpKSB7XG4gICAgICAgICAgICByZWplY3QoZSlcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pKClcbiAgfSlcblxuICByZXR1cm4gcHJvbWlzZVxufVxuXG5mdW5jdGlvbiBkZWMyaGV4KGRlYzogbnVtYmVyKSB7XG4gIHJldHVybiAoJzAnICsgZGVjLnRvU3RyaW5nKDE2KSkuc3Vic3RyKC0yKVxufVxuXG4vLyBGdW5jdGlvbnMgYmVsb3cgdGFrZW4gZnJvbTogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvNjMzMDk0MDkvY3JlYXRpbmctYS1jb2RlLXZlcmlmaWVyLWFuZC1jaGFsbGVuZ2UtZm9yLXBrY2UtYXV0aC1vbi1zcG90aWZ5LWFwaS1pbi1yZWFjdGpzXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVQS0NFVmVyaWZpZXIoKSB7XG4gIGNvbnN0IHZlcmlmaWVyTGVuZ3RoID0gNTZcbiAgY29uc3QgYXJyYXkgPSBuZXcgVWludDMyQXJyYXkodmVyaWZpZXJMZW5ndGgpXG4gIGlmICh0eXBlb2YgY3J5cHRvID09PSAndW5kZWZpbmVkJykge1xuICAgIGNvbnN0IGNoYXJTZXQgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODktLl9+J1xuICAgIGNvbnN0IGNoYXJTZXRMZW4gPSBjaGFyU2V0Lmxlbmd0aFxuICAgIGxldCB2ZXJpZmllciA9ICcnXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB2ZXJpZmllckxlbmd0aDsgaSsrKSB7XG4gICAgICB2ZXJpZmllciArPSBjaGFyU2V0LmNoYXJBdChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBjaGFyU2V0TGVuKSlcbiAgICB9XG4gICAgcmV0dXJuIHZlcmlmaWVyXG4gIH1cbiAgY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhhcnJheSlcbiAgcmV0dXJuIEFycmF5LmZyb20oYXJyYXksIGRlYzJoZXgpLmpvaW4oJycpXG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNoYTI1NihyYW5kb21TdHJpbmc6IHN0cmluZykge1xuICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKClcbiAgY29uc3QgZW5jb2RlZERhdGEgPSBlbmNvZGVyLmVuY29kZShyYW5kb21TdHJpbmcpXG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGVuY29kZWREYXRhKVxuICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGhhc2gpXG5cbiAgcmV0dXJuIEFycmF5LmZyb20oYnl0ZXMpXG4gICAgLm1hcCgoYykgPT4gU3RyaW5nLmZyb21DaGFyQ29kZShjKSlcbiAgICAuam9pbignJylcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlUEtDRUNoYWxsZW5nZSh2ZXJpZmllcjogc3RyaW5nKSB7XG4gIGNvbnN0IGhhc0NyeXB0b1N1cHBvcnQgPVxuICAgIHR5cGVvZiBjcnlwdG8gIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGNyeXB0by5zdWJ0bGUgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIFRleHRFbmNvZGVyICE9PSAndW5kZWZpbmVkJ1xuXG4gIGlmICghaGFzQ3J5cHRvU3VwcG9ydCkge1xuICAgIGNvbnNvbGUud2FybihcbiAgICAgICdXZWJDcnlwdG8gQVBJIGlzIG5vdCBzdXBwb3J0ZWQuIENvZGUgY2hhbGxlbmdlIG1ldGhvZCB3aWxsIGRlZmF1bHQgdG8gdXNlIHBsYWluIGluc3RlYWQgb2Ygc2hhMjU2LidcbiAgICApXG4gICAgcmV0dXJuIHZlcmlmaWVyXG4gIH1cbiAgY29uc3QgaGFzaGVkID0gYXdhaXQgc2hhMjU2KHZlcmlmaWVyKVxuICByZXR1cm4gYnRvYShoYXNoZWQpLnJlcGxhY2UoL1xcKy9nLCAnLScpLnJlcGxhY2UoL1xcLy9nLCAnXycpLnJlcGxhY2UoLz0rJC8sICcnKVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29kZUNoYWxsZW5nZUFuZE1ldGhvZChcbiAgc3RvcmFnZTogU3VwcG9ydGVkU3RvcmFnZSxcbiAgc3RvcmFnZUtleTogc3RyaW5nLFxuICBpc1Bhc3N3b3JkUmVjb3ZlcnkgPSBmYWxzZVxuKSB7XG4gIGNvbnN0IGNvZGVWZXJpZmllciA9IGdlbmVyYXRlUEtDRVZlcmlmaWVyKClcbiAgbGV0IHN0b3JlZENvZGVWZXJpZmllciA9IGNvZGVWZXJpZmllclxuICBpZiAoaXNQYXNzd29yZFJlY292ZXJ5KSB7XG4gICAgc3RvcmVkQ29kZVZlcmlmaWVyICs9ICcvcmVjb3ZlcnknXG4gIH1cbiAgYXdhaXQgc2V0SXRlbUFzeW5jKHN0b3JhZ2UsIGAke3N0b3JhZ2VLZXl9LWNvZGUtdmVyaWZpZXJgLCBzdG9yZWRDb2RlVmVyaWZpZXIpXG4gIGNvbnN0IGNvZGVDaGFsbGVuZ2UgPSBhd2FpdCBnZW5lcmF0ZVBLQ0VDaGFsbGVuZ2UoY29kZVZlcmlmaWVyKVxuICBjb25zdCBjb2RlQ2hhbGxlbmdlTWV0aG9kID0gY29kZVZlcmlmaWVyID09PSBjb2RlQ2hhbGxlbmdlID8gJ3BsYWluJyA6ICdzMjU2J1xuICByZXR1cm4gW2NvZGVDaGFsbGVuZ2UsIGNvZGVDaGFsbGVuZ2VNZXRob2RdXG59XG5cbi8qKiBQYXJzZXMgdGhlIEFQSSB2ZXJzaW9uIHdoaWNoIGlzIDJZWVktTU0tREQuICovXG5jb25zdCBBUElfVkVSU0lPTl9SRUdFWCA9IC9eMlswLTldezN9LSgwWzEtOV18MVswLTJdKS0oMFsxLTldfDFbMC05XXwyWzAtOV18M1swLTFdKSQvaVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VSZXNwb25zZUFQSVZlcnNpb24ocmVzcG9uc2U6IFJlc3BvbnNlKSB7XG4gIGNvbnN0IGFwaVZlcnNpb24gPSByZXNwb25zZS5oZWFkZXJzLmdldChBUElfVkVSU0lPTl9IRUFERVJfTkFNRSlcblxuICBpZiAoIWFwaVZlcnNpb24pIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgaWYgKCFhcGlWZXJzaW9uLm1hdGNoKEFQSV9WRVJTSU9OX1JFR0VYKSkge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShgJHthcGlWZXJzaW9ufVQwMDowMDowMC4wWmApXG4gICAgcmV0dXJuIGRhdGVcbiAgfSBjYXRjaCAoX2UpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZUV4cChleHA6IG51bWJlcikge1xuICBpZiAoIWV4cCkge1xuICAgIHRocm93IG5ldyBFcnJvcignTWlzc2luZyBleHAgY2xhaW0nKVxuICB9XG4gIGNvbnN0IHRpbWVOb3cgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKVxuICBpZiAoZXhwIDw9IHRpbWVOb3cpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0pXVCBoYXMgZXhwaXJlZCcpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEFsZ29yaXRobShcbiAgYWxnOiAnSFMyNTYnIHwgJ1JTMjU2JyB8ICdFUzI1NicgfCAoc3RyaW5nICYge30pXG4pOiBSc2FIYXNoZWRJbXBvcnRQYXJhbXMgfCBFY0tleUltcG9ydFBhcmFtcyB7XG4gIHN3aXRjaCAoYWxnKSB7XG4gICAgY2FzZSAnUlMyNTYnOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogJ1JTQVNTQS1QS0NTMS12MV81JyxcbiAgICAgICAgaGFzaDogeyBuYW1lOiAnU0hBLTI1NicgfSxcbiAgICAgIH1cbiAgICBjYXNlICdFUzI1Nic6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBuYW1lOiAnRUNEU0EnLFxuICAgICAgICBuYW1lZEN1cnZlOiAnUC0yNTYnLFxuICAgICAgICBoYXNoOiB7IG5hbWU6ICdTSEEtMjU2JyB9LFxuICAgICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgYWxnIGNsYWltJylcbiAgfVxufVxuXG5jb25zdCBVVUlEX1JFR0VYID0gL15bMC05YS1mXXs4fS1bMC05YS1mXXs0fS1bMC05YS1mXXs0fS1bMC05YS1mXXs0fS1bMC05YS1mXXsxMn0kL1xuXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVVVUlEKHN0cjogc3RyaW5nKSB7XG4gIGlmICghVVVJRF9SRUdFWC50ZXN0KHN0cikpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0BzdXBhYmFzZS9hdXRoLWpzOiBFeHBlY3RlZCBwYXJhbWV0ZXIgdG8gYmUgVVVJRCBidXQgaXMgbm90JylcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYXNzZXJ0UGFzc2tleUV4cGVyaW1lbnRhbEVuYWJsZWQoZXhwZXJpbWVudGFsOiB7IHBhc3NrZXk/OiBib29sZWFuIH0pOiB2b2lkIHtcbiAgaWYgKCFleHBlcmltZW50YWwucGFzc2tleSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdAc3VwYWJhc2UvYXV0aC1qczogdGhlIHBhc3NrZXkgQVBJIGlzIGV4cGVyaW1lbnRhbCBhbmQgZGlzYWJsZWQgYnkgZGVmYXVsdC4gRW5hYmxlIGl0IGJ5IHBhc3NpbmcgYGF1dGg6IHsgZXhwZXJpbWVudGFsOiB7IHBhc3NrZXk6IHRydWUgfSB9YCB0byBjcmVhdGVDbGllbnQgKG9yIHRvIHRoZSBHb1RydWVDbGllbnQgY29uc3RydWN0b3IpLidcbiAgICApXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZXJOb3RBdmFpbGFibGVQcm94eSgpOiBVc2VyIHtcbiAgY29uc3QgcHJveHlUYXJnZXQgPSB7fSBhcyBVc2VyXG5cbiAgcmV0dXJuIG5ldyBQcm94eShwcm94eVRhcmdldCwge1xuICAgIGdldDogKHRhcmdldDogYW55LCBwcm9wOiBzdHJpbmcpID0+IHtcbiAgICAgIGlmIChwcm9wID09PSAnX19pc1VzZXJOb3RBdmFpbGFibGVQcm94eScpIHtcbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgIH1cbiAgICAgIC8vIFByZXZlbnRhdGl2ZSBjaGVjayBmb3IgY29tbW9uIHByb2JsZW1hdGljIHN5bWJvbHMgZHVyaW5nIGNsb25pbmcvaW5zcGVjdGlvblxuICAgICAgLy8gVGhlc2Ugc3ltYm9scyBtaWdodCBiZSBhY2Nlc3NlZCBieSBzdHJ1Y3R1cmVkQ2xvbmUgb3Igb3RoZXIgaW50ZXJuYWwgbWVjaGFuaXNtcy5cbiAgICAgIGlmICh0eXBlb2YgcHJvcCA9PT0gJ3N5bWJvbCcpIHtcbiAgICAgICAgY29uc3Qgc1Byb3AgPSAocHJvcCBhcyBzeW1ib2wpLnRvU3RyaW5nKClcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHNQcm9wID09PSAnU3ltYm9sKFN5bWJvbC50b1ByaW1pdGl2ZSknIHx8XG4gICAgICAgICAgc1Byb3AgPT09ICdTeW1ib2woU3ltYm9sLnRvU3RyaW5nVGFnKScgfHxcbiAgICAgICAgICBzUHJvcCA9PT0gJ1N5bWJvbCh1dGlsLmluc3BlY3QuY3VzdG9tKSdcbiAgICAgICAgKSB7XG4gICAgICAgICAgLy8gTm9kZS5qcyB1dGlsLmluc3BlY3RcbiAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEBzdXBhYmFzZS9hdXRoLWpzOiBjbGllbnQgd2FzIGNyZWF0ZWQgd2l0aCB1c2VyU3RvcmFnZSBvcHRpb24gYW5kIHRoZXJlIHdhcyBubyB1c2VyIHN0b3JlZCBpbiB0aGUgdXNlciBzdG9yYWdlLiBBY2Nlc3NpbmcgdGhlIFwiJHtwcm9wfVwiIHByb3BlcnR5IG9mIHRoZSBzZXNzaW9uIG9iamVjdCBpcyBub3Qgc3VwcG9ydGVkLiBQbGVhc2UgdXNlIGdldFVzZXIoKSBpbnN0ZWFkLmBcbiAgICAgIClcbiAgICB9LFxuICAgIHNldDogKF90YXJnZXQ6IGFueSwgcHJvcDogc3RyaW5nKSA9PiB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBAc3VwYWJhc2UvYXV0aC1qczogY2xpZW50IHdhcyBjcmVhdGVkIHdpdGggdXNlclN0b3JhZ2Ugb3B0aW9uIGFuZCB0aGVyZSB3YXMgbm8gdXNlciBzdG9yZWQgaW4gdGhlIHVzZXIgc3RvcmFnZS4gU2V0dGluZyB0aGUgXCIke3Byb3B9XCIgcHJvcGVydHkgb2YgdGhlIHNlc3Npb24gb2JqZWN0IGlzIG5vdCBzdXBwb3J0ZWQuIFBsZWFzZSB1c2UgZ2V0VXNlcigpIHRvIGZldGNoIGEgdXNlciBvYmplY3QgeW91IGNhbiBtYW5pcHVsYXRlLmBcbiAgICAgIClcbiAgICB9LFxuICAgIGRlbGV0ZVByb3BlcnR5OiAoX3RhcmdldDogYW55LCBwcm9wOiBzdHJpbmcpID0+IHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEBzdXBhYmFzZS9hdXRoLWpzOiBjbGllbnQgd2FzIGNyZWF0ZWQgd2l0aCB1c2VyU3RvcmFnZSBvcHRpb24gYW5kIHRoZXJlIHdhcyBubyB1c2VyIHN0b3JlZCBpbiB0aGUgdXNlciBzdG9yYWdlLiBEZWxldGluZyB0aGUgXCIke3Byb3B9XCIgcHJvcGVydHkgb2YgdGhlIHNlc3Npb24gb2JqZWN0IGlzIG5vdCBzdXBwb3J0ZWQuIFBsZWFzZSB1c2UgZ2V0VXNlcigpIHRvIGZldGNoIGEgdXNlciBvYmplY3QgeW91IGNhbiBtYW5pcHVsYXRlLmBcbiAgICAgIClcbiAgICB9LFxuICB9KVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBwcm94eSBhcm91bmQgYSB1c2VyIG9iamVjdCB0aGF0IHdhcm5zIHdoZW4gcHJvcGVydGllcyBhcmUgYWNjZXNzZWQgb24gdGhlIHNlcnZlci5cbiAqIFRoaXMgaXMgdXNlZCB0byBhbGVydCBkZXZlbG9wZXJzIHRoYXQgdXNpbmcgdXNlciBkYXRhIGZyb20gZ2V0U2Vzc2lvbigpIG9uIHRoZSBzZXJ2ZXIgaXMgaW5zZWN1cmUuXG4gKlxuICogQHBhcmFtIHVzZXIgVGhlIGFjdHVhbCB1c2VyIG9iamVjdCB0byB3cmFwXG4gKiBAcGFyYW0gc3VwcHJlc3NXYXJuaW5nUmVmIEFuIG9iamVjdCB3aXRoIGEgJ3ZhbHVlJyBwcm9wZXJ0eSB0aGF0IGNvbnRyb2xzIHdhcm5pbmcgc3VwcHJlc3Npb25cbiAqIEByZXR1cm5zIEEgcHJveGllZCB1c2VyIG9iamVjdCB0aGF0IHdhcm5zIG9uIHByb3BlcnR5IGFjY2Vzc1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5zZWN1cmVVc2VyV2FybmluZ1Byb3h5KHVzZXI6IFVzZXIsIHN1cHByZXNzV2FybmluZ1JlZjogeyB2YWx1ZTogYm9vbGVhbiB9KTogVXNlciB7XG4gIHJldHVybiBuZXcgUHJveHkodXNlciwge1xuICAgIGdldDogKHRhcmdldDogYW55LCBwcm9wOiBzdHJpbmcgfCBzeW1ib2wsIHJlY2VpdmVyOiBhbnkpID0+IHtcbiAgICAgIC8vIEFsbG93IGludGVybmFsIGNoZWNrcyB3aXRob3V0IHdhcm5pbmdcbiAgICAgIGlmIChwcm9wID09PSAnX19pc0luc2VjdXJlVXNlcldhcm5pbmdQcm94eScpIHtcbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgIH1cblxuICAgICAgLy8gUHJldmVudGF0aXZlIGNoZWNrIGZvciBjb21tb24gcHJvYmxlbWF0aWMgc3ltYm9scyBkdXJpbmcgY2xvbmluZy9pbnNwZWN0aW9uXG4gICAgICAvLyBUaGVzZSBzeW1ib2xzIG1pZ2h0IGJlIGFjY2Vzc2VkIGJ5IHN0cnVjdHVyZWRDbG9uZSBvciBvdGhlciBpbnRlcm5hbCBtZWNoYW5pc21zXG4gICAgICBpZiAodHlwZW9mIHByb3AgPT09ICdzeW1ib2wnKSB7XG4gICAgICAgIGNvbnN0IHNQcm9wID0gcHJvcC50b1N0cmluZygpXG4gICAgICAgIGlmIChcbiAgICAgICAgICBzUHJvcCA9PT0gJ1N5bWJvbChTeW1ib2wudG9QcmltaXRpdmUpJyB8fFxuICAgICAgICAgIHNQcm9wID09PSAnU3ltYm9sKFN5bWJvbC50b1N0cmluZ1RhZyknIHx8XG4gICAgICAgICAgc1Byb3AgPT09ICdTeW1ib2wodXRpbC5pbnNwZWN0LmN1c3RvbSknIHx8XG4gICAgICAgICAgc1Byb3AgPT09ICdTeW1ib2wobm9kZWpzLnV0aWwuaW5zcGVjdC5jdXN0b20pJ1xuICAgICAgICApIHtcbiAgICAgICAgICAvLyBSZXR1cm4gdGhlIGFjdHVhbCB2YWx1ZSBmb3IgdGhlc2Ugc3ltYm9scyB0byBhbGxvdyBwcm9wZXIgaW5zcGVjdGlvblxuICAgICAgICAgIHJldHVybiBSZWZsZWN0LmdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEVtaXQgd2FybmluZyBvbiBmaXJzdCBwcm9wZXJ0eSBhY2Nlc3NcbiAgICAgIGlmICghc3VwcHJlc3NXYXJuaW5nUmVmLnZhbHVlICYmIHR5cGVvZiBwcm9wID09PSAnc3RyaW5nJykge1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgJ1VzaW5nIHRoZSB1c2VyIG9iamVjdCBhcyByZXR1cm5lZCBmcm9tIHN1cGFiYXNlLmF1dGguZ2V0U2Vzc2lvbigpIG9yIGZyb20gc29tZSBzdXBhYmFzZS5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKCkgZXZlbnRzIGNvdWxkIGJlIGluc2VjdXJlISBUaGlzIHZhbHVlIGNvbWVzIGRpcmVjdGx5IGZyb20gdGhlIHN0b3JhZ2UgbWVkaXVtICh1c3VhbGx5IGNvb2tpZXMgb24gdGhlIHNlcnZlcikgYW5kIG1heSBub3QgYmUgYXV0aGVudGljLiBVc2Ugc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCkgaW5zdGVhZCB3aGljaCBhdXRoZW50aWNhdGVzIHRoZSBkYXRhIGJ5IGNvbnRhY3RpbmcgdGhlIFN1cGFiYXNlIEF1dGggc2VydmVyLidcbiAgICAgICAgKVxuICAgICAgICBzdXBwcmVzc1dhcm5pbmdSZWYudmFsdWUgPSB0cnVlXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBSZWZsZWN0LmdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKVxuICAgIH0sXG4gIH0pXG59XG5cbi8qKlxuICogRGVlcCBjbG9uZXMgYSBKU09OLXNlcmlhbGl6YWJsZSBvYmplY3QgdXNpbmcgSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShvYmopKS5cbiAqIE5vdGU6IE9ubHkgd29ya3MgZm9yIEpTT04tc2FmZSBkYXRhLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVlcENsb25lPFQ+KG9iajogVCk6IFQge1xuICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShvYmopKVxufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=