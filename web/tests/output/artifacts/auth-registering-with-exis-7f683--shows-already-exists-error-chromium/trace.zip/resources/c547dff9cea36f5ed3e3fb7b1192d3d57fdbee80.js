import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/@id/virtual:nuxt:%2Fmnt%2Fkire%2FPersonal%2FProgramming%2FProjects%2FMEIC%2Fweb%2F.nuxt%2Fnuxt-fonts-global.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/_nuxt/@vite/client"
const __vite__id = "virtual:nuxt:%2Fmnt%2Fkire%2FPersonal%2FProgramming%2FProjects%2FMEIC%2Fweb%2F.nuxt%2Fnuxt-fonts-global.css"
const __vite__css = "\n/*# sourceMappingURL=data:application/json;base64,eyJmaWxlIjoidmlydHVhbDpudXh0OiUyRm1udCUyRmtpcmUlMkZQZXJzb25hbCUyRlByb2dyYW1taW5nJTJGUHJvamVjdHMlMkZNRUlDJTJGd2ViJTJGLm51eHQlMkZudXh0LWZvbnRzLWdsb2JhbC5jc3MiLCJtYXBwaW5ncyI6IiIsIm5hbWVzIjpbXSwic291cmNlcyI6W10sInZlcnNpb24iOjN9 */"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))
document.querySelectorAll(`link[href="/_nuxt/virtual:nuxt:%2Fmnt%2Fkire%2FPersonal%2FProgramming%2FProjects%2FMEIC%2Fweb%2F.nuxt%2Fnuxt-fonts-global.css"]`).forEach(i=>i.remove())
document.querySelectorAll(`link[href="/_nuxt/@fs/virtual:nuxt:%2Fmnt%2Fkire%2FPersonal%2FProgramming%2FProjects%2FMEIC%2Fweb%2F.nuxt%2Fnuxt-fonts-global.css"]`).forEach(i=>i.remove())