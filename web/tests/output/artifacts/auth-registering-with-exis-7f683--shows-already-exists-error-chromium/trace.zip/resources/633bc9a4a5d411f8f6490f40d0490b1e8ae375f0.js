import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Branding.vue");import { default as __nuxt_component_0 } from "/_nuxt/ui/Text.vue";
import { default as __nuxt_component_1 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/components/nuxt-link.js?v=583078ff";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"
import { URI } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/shared/constants/routes.js"
import logo from "/_nuxt/assets/brand/logo.png?import"


const _sfc_main = {
  __name: "Branding",
  props: {
	size: {
		type: String,
		default: "md",
		validator: (v) => ["sm", "md", "lg"].includes(v),
	},
	show: {
		type: String,
		default: "icon",
		validator: (v) => ["icon", "name"].includes(v),
	}
},
  setup(__props, { expose: __expose }) {
  __expose();



const textVariant = { sm: "body", md: "h3", lg: "h2" };

const __returned__ = { textVariant, get URI() { return URI }, get logo() { return logo } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { normalizeStyle as _normalizeStyle, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createBlock as _createBlock, normalizeClass as _normalizeClass } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Text = __nuxt_component_0
  const _component_NuxtLink = __nuxt_component_1

  return (_openBlock(), _tracer(22,1,_createBlock(_component_NuxtLink, {
    to: $setup.URI.home,
    class: _normalizeClass(['logo', `logo--${$props.size}`])
  }, {
    default: _withCtx(() => [
      ($props.show != 'name')
        ? (_openBlock(), _tracer(23,2,_createElementBlock("div", {
            key: 0,
            class: "logo-mark",
            style: _normalizeStyle({ '--mask-url': `url(${$setup.logo})` })
          }, null, 4 /* STYLE */)))
        : _createCommentVNode("v-if", true),
      ($props.show != 'icon')
        ? (_openBlock(), _tracer(25,2,_createBlock(_component_Text, {
            key: 1,
            variant: $setup.textVariant[$props.size],
            weight: "bold"
          }, {
            default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
              _createTextVNode("HALITE", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["variant"])))
        : _createCommentVNode("v-if", true)
    ]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["to", "class"])))
}


import "/_nuxt/ui/Branding.vue?vue&type=style&index=0&scoped=4c3e0742&lang.css"

_sfc_main.__hmrId = "4c3e0742"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-4c3e0742"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Branding.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Branding.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWV6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7cUNBSXJELGFBSVc7SUFKQSxFQUFFLEVBQUUsVUFBRyxDQUFDLElBQUk7SUFBRyxLQUFLLG9DQUFvQixXQUFJOztzQkFDdEQsQ0FBeUY7T0FBOUUsV0FBSTtzQ0FBZixvQkFBeUY7O1lBQTlELEtBQUssRUFBQyxXQUFXO1lBQUUsS0FBSyx5Q0FBeUIsV0FBSTs7O09BRXBFLFdBQUk7c0NBQWhCLGFBQW9GOztZQUF2RCxPQUFPLEVBQUUsa0JBQVcsQ0FBQyxXQUFJO1lBQUcsTUFBTSxFQUFDOzs4QkFBTyxDQUFNOytCQUFOLFFBQU0iLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJyYW5kaW5nLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuaW1wb3J0IHsgVVJJIH0gZnJvbSBcIn5+L3NoYXJlZC9jb25zdGFudHMvcm91dGVzXCJcbmltcG9ydCBsb2dvIGZyb20gXCJ+L2Fzc2V0cy9icmFuZC9sb2dvLnBuZ1wiXG5cbmRlZmluZVByb3BzKHtcblx0c2l6ZToge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRkZWZhdWx0OiBcIm1kXCIsXG5cdFx0dmFsaWRhdG9yOiAodikgPT4gW1wic21cIiwgXCJtZFwiLCBcImxnXCJdLmluY2x1ZGVzKHYpLFxuXHR9LFxuXHRzaG93OiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGRlZmF1bHQ6IFwiaWNvblwiLFxuXHRcdHZhbGlkYXRvcjogKHYpID0+IFtcImljb25cIiwgXCJuYW1lXCJdLmluY2x1ZGVzKHYpLFxuXHR9XG59KVxuXG5jb25zdCB0ZXh0VmFyaWFudCA9IHsgc206IFwiYm9keVwiLCBtZDogXCJoM1wiLCBsZzogXCJoMlwiIH07XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuXHQ8TnV4dExpbmsgOnRvPVwiVVJJLmhvbWVcIiA6Y2xhc3M9XCJbJ2xvZ28nLCBgbG9nby0tJHtzaXplfWBdXCI+XG5cdFx0PGRpdiB2LWlmPVwic2hvdyAhPSAnbmFtZSdcIiBjbGFzcz1cImxvZ28tbWFya1wiIDpzdHlsZT1cInsgJy0tbWFzay11cmwnOiBgdXJsKCR7bG9nb30pYCB9XCIgLz5cblxuXHRcdDxUZXh0IHYtaWY9XCJzaG93ICE9ICdpY29uJ1wiIDp2YXJpYW50PVwidGV4dFZhcmlhbnRbc2l6ZV1cIiB3ZWlnaHQ9XCJib2xkXCI+SEFMSVRFPC9UZXh0PlxuXHQ8L051eHRMaW5rPlxuPC90ZW1wbGF0ZT5cblxuPHN0eWxlIHNjb3BlZD5cbi50ZXh0IHtcblx0d29yZC1zcGFjaW5nOiAycHg7XG59XG5cbi5sb2dvIHtcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRkaXNwbGF5OiBpbmxpbmUtZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmxvZ28tbWFyayB7XG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0bGVmdDogMnB4O1xuXHR6LWluZGV4OiAwO1xuXHRkaXNwbGF5OiBibG9jaztcblx0ZmxleC1zaHJpbms6IDA7XG5cdHdpZHRoOiAzNnB4O1xuXHRoZWlnaHQ6IDM2cHg7XG5cdG9iamVjdC1maXQ6IGNvbnRhaW47XG5cdGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuXG5cdC13ZWJraXQtbWFzazogdmFyKC0tbWFzay11cmwpIG5vLXJlcGVhdCBjZW50ZXI7XG5cdG1hc2s6IHZhcigtLW1hc2stdXJsKSBuby1yZXBlYXQgY2VudGVyO1xuXG5cdC13ZWJraXQtbWFzay1zaXplOiBjb250YWluO1xuXHRtYXNrLXNpemU6IGNvbnRhaW47XG59XG5cbi5sb2dvLS1zbSAubG9nby1tYXJrIHtcblx0d2lkdGg6IDI4cHg7XG5cdGhlaWdodDogMjhweDtcbn1cblxuLmxvZ28tLWxnIC5sb2dvLW1hcmsge1xuXHR3aWR0aDogNDhweDtcblx0aGVpZ2h0OiA0OHB4O1xufVxuPC9zdHlsZT5cbiJdLCJmaWxlIjoiL21udC9raXJlL1BlcnNvbmFsL1Byb2dyYW1taW5nL1Byb2plY3RzL01FSUMvd2ViL2FwcC91aS9CcmFuZGluZy52dWUifQ==