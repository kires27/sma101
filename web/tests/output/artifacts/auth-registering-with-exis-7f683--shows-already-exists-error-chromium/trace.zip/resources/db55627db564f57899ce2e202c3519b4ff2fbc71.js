/*!
* vue-router v5.1.0
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
import { f as assign, g as isRouteComponent, h as isESModule, l as createRouterError, m as isArray, r as matchedRouteKey, y as isBrowser } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue-router@5.1.0_@vue+compiler-sfc@3.5.38_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_ligh_834d8a9034f0ed0e409191762519b088/node_modules/vue-router/dist/useApi-s_02lHjl.js?v=583078ff";
import { getCurrentInstance, inject, onActivated, onDeactivated, onUnmounted, watch } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
import { setupDevtoolsPlugin } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+devtools-api@8.1.3/node_modules/@vue/devtools-api/dist/index.js?v=583078ff";
function warn$1(msg) {
  const args = Array.from(arguments).slice(1);
  console.warn.apply(console, ["[Vue Router warn]: " + msg].concat(args));
}
const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_BRACKET_OPEN_RE = /%5B/g;
const ENC_BRACKET_CLOSE_RE = /%5D/g;
const ENC_CARET_RE = /%5E/g;
const ENC_BACKTICK_RE = /%60/g;
const ENC_CURLY_OPEN_RE = /%7B/g;
const ENC_PIPE_RE = /%7C/g;
const ENC_CURLY_CLOSE_RE = /%7D/g;
const ENC_SPACE_RE = /%20/g;
function commonEncode(text) {
  return text == null ? "" : encodeURI("" + text).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]");
}
function encodeHash(text) {
  return commonEncode(text).replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
function encodeQueryValue(text) {
  return commonEncode(text).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return commonEncode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F");
}
function encodeParam(text) {
  return encodePath(text).replace(SLASH_RE, "%2F");
}
function decode(text) {
  if (text == null) return null;
  try {
    return decodeURIComponent("" + text);
  } catch {
    warn$1(`Error decoding "${text}". Using original value`);
  }
  return "" + text;
}
const TRAILING_SLASH_RE = /\/$/;
const removeTrailingSlash = (path) => path.replace(TRAILING_SLASH_RE, "");
function parseURL(parseQuery2, location, currentLocation = "/") {
  let path, query = {}, searchString = "", hash = "";
  const hashPos = location.indexOf("#");
  let searchPos = location.indexOf("?");
  searchPos = hashPos >= 0 && searchPos > hashPos ? -1 : searchPos;
  if (searchPos >= 0) {
    path = location.slice(0, searchPos);
    searchString = location.slice(searchPos, hashPos > 0 ? hashPos : location.length);
    query = parseQuery2(searchString.slice(1));
  }
  if (hashPos >= 0) {
    path = path || location.slice(0, hashPos);
    hash = location.slice(hashPos, location.length);
  }
  path = resolveRelativePath(path != null ? path : location, currentLocation);
  return {
    fullPath: path + searchString + hash,
    path,
    query,
    hash: decode(hash)
  };
}
function NEW_stringifyURL(stringifyQuery2, path, query, hash = "") {
  const searchText = stringifyQuery2(query);
  return path + (searchText && "?") + searchText + encodeHash(hash);
}
function stringifyURL(stringifyQuery2, location) {
  const query = location.query ? stringifyQuery2(location.query) : "";
  return location.path + (query && "?") + query + (location.hash || "");
}
function stripBase(pathname, base) {
  if (!base || !pathname.toLowerCase().startsWith(base.toLowerCase())) return pathname;
  return pathname.slice(base.length) || "/";
}
function isSameRouteLocation(stringifyQuery2, a, b) {
  const aLastIndex = a.matched.length - 1;
  const bLastIndex = b.matched.length - 1;
  return aLastIndex > -1 && aLastIndex === bLastIndex && isSameRouteRecord(a.matched[aLastIndex], b.matched[bLastIndex]) && isSameRouteLocationParams(a.params, b.params) && stringifyQuery2(a.query) === stringifyQuery2(b.query) && a.hash === b.hash;
}
function isSameRouteRecord(a, b) {
  return (a.aliasOf || a) === (b.aliasOf || b);
}
function isSameRouteLocationParams(a, b) {
  if (Object.keys(a).length !== Object.keys(b).length) return false;
  for (var key in a) if (!isSameRouteLocationParamsValue(a[key], b[key])) return false;
  return true;
}
function isSameRouteLocationParamsValue(a, b) {
  return isArray(a) ? isEquivalentArray(a, b) : isArray(b) ? isEquivalentArray(b, a) : (a && a.valueOf()) === (b && b.valueOf());
}
function isEquivalentArray(a, b) {
  return isArray(b) ? a.length === b.length && a.every((value, i) => value === b[i]) : a.length === 1 && a[0] === b;
}
function resolveRelativePath(to, from) {
  if (to.startsWith("/")) return to;
  if (!from.startsWith("/")) {
    warn$1(`Cannot resolve a relative location without an absolute path. Trying to resolve "${to}" from "${from}". It should look like "/${from}".`);
    return to;
  }
  if (!to) return from;
  const fromSegments = from.split("/");
  const toSegments = to.split("/");
  const lastToSegment = toSegments[toSegments.length - 1];
  if (lastToSegment === ".." || lastToSegment === ".") toSegments.push("");
  let position = fromSegments.length - 1;
  let toPosition;
  let segment;
  for (toPosition = 0; toPosition < toSegments.length; toPosition++) {
    segment = toSegments[toPosition];
    if (segment === ".") continue;
    if (segment === "..") {
      if (position > 1) position--;
    } else break;
  }
  return fromSegments.slice(0, position).join("/") + "/" + toSegments.slice(toPosition).join("/");
}
const START_LOCATION_NORMALIZED = {
  path: "/",
  name: void 0,
  params: {},
  query: {},
  hash: "",
  fullPath: "/",
  matched: [],
  meta: {},
  redirectedFrom: void 0
};
function normalizeBase(base) {
  if (!base) if (isBrowser) {
    const baseEl = document.querySelector("base");
    base = baseEl && baseEl.getAttribute("href") || "/";
    base = base.replace(/^\w+:\/\/[^/]+/, "");
  } else base = "/";
  if (base[0] !== "/" && base[0] !== "#") base = "/" + base;
  return removeTrailingSlash(base);
}
const BEFORE_HASH_RE = /^[^#]+#/;
function createHref(base, location) {
  return base.replace(BEFORE_HASH_RE, "#") + location;
}
function getElementPosition(el, offset) {
  const docRect = document.documentElement.getBoundingClientRect();
  const elRect = el.getBoundingClientRect();
  return {
    behavior: offset.behavior,
    left: elRect.left - docRect.left - (offset.left || 0),
    top: elRect.top - docRect.top - (offset.top || 0)
  };
}
const computeScrollPosition = () => ({
  left: window.scrollX,
  top: window.scrollY
});
function scrollToPosition(position) {
  let scrollToOptions;
  if ("el" in position) {
    const positionEl = position.el;
    const isIdSelector = typeof positionEl === "string" && positionEl.startsWith("#");
    if (typeof position.el === "string") {
      if (!isIdSelector || !document.getElementById(position.el.slice(1))) try {
        const foundEl = document.querySelector(position.el);
        if (isIdSelector && foundEl) {
          warn$1(`The selector "${position.el}" should be passed as "el: document.querySelector('${position.el}')" because it starts with "#".`);
          return;
        }
      } catch {
        warn$1(`The selector "${position.el}" is invalid. If you are using an id selector, make sure to escape it. You can find more information about escaping characters in selectors at https://mathiasbynens.be/notes/css-escapes or use CSS.escape (https://developer.mozilla.org/en-US/docs/Web/API/CSS/escape).`);
        return;
      }
    }
    const el = typeof positionEl === "string" ? isIdSelector ? document.getElementById(positionEl.slice(1)) : document.querySelector(positionEl) : positionEl;
    if (!el) {
      warn$1(`Couldn't find element using selector "${position.el}" returned by scrollBehavior.`);
      return;
    }
    scrollToOptions = getElementPosition(el, position);
  } else scrollToOptions = position;
  if ("scrollBehavior" in document.documentElement.style) window.scrollTo(scrollToOptions);
  else window.scrollTo(scrollToOptions.left != null ? scrollToOptions.left : window.scrollX, scrollToOptions.top != null ? scrollToOptions.top : window.scrollY);
}
function getScrollKey(path, delta) {
  return (history.state ? history.state.position - delta : -1) + path;
}
const scrollPositions = /* @__PURE__ */ new Map();
function saveScrollPosition(key, scrollPosition) {
  scrollPositions.set(key, scrollPosition);
}
function getSavedScrollPosition(key) {
  const scroll = scrollPositions.get(key);
  scrollPositions.delete(key);
  return scroll;
}
function isRouteLocation(route) {
  return typeof route === "string" || route && typeof route === "object";
}
function isRouteName(name) {
  return typeof name === "string" || typeof name === "symbol";
}
function parseQuery(search) {
  const query = {};
  if (search === "" || search === "?") return query;
  const searchParams = (search[0] === "?" ? search.slice(1) : search).split("&");
  for (let i = 0; i < searchParams.length; ++i) {
    const searchParam = searchParams[i].replace(PLUS_RE, " ");
    const eqPos = searchParam.indexOf("=");
    const key = decode(eqPos < 0 ? searchParam : searchParam.slice(0, eqPos));
    const value = eqPos < 0 ? null : decode(searchParam.slice(eqPos + 1));
    if (key in query) {
      let currentValue = query[key];
      if (!isArray(currentValue)) currentValue = query[key] = [currentValue];
      currentValue.push(value);
    } else query[key] = value;
  }
  return query;
}
function stringifyQuery(query) {
  let search = "";
  for (let key in query) {
    const value = query[key];
    key = encodeQueryKey(key);
    if (value == null) {
      if (value !== void 0) search += (search.length ? "&" : "") + key;
      continue;
    }
    (isArray(value) ? value.map((v) => v && encodeQueryValue(v)) : [value && encodeQueryValue(value)]).forEach((value2) => {
      if (value2 !== void 0) {
        search += (search.length ? "&" : "") + key;
        if (value2 != null) search += "=" + value2;
      }
    });
  }
  return search;
}
function normalizeQuery(query) {
  const normalizedQuery = {};
  for (const key in query) {
    const value = query[key];
    if (value !== void 0) normalizedQuery[key] = isArray(value) ? value.map((v) => v == null ? null : "" + v) : value == null ? value : "" + value;
  }
  return normalizedQuery;
}
function useCallbacks() {
  let handlers = [];
  function add(handler) {
    handlers.push(handler);
    return () => {
      const i = handlers.indexOf(handler);
      if (i > -1) handlers.splice(i, 1);
    };
  }
  function reset() {
    handlers = [];
  }
  return {
    add,
    list: () => handlers.slice(),
    reset
  };
}
function registerGuard(activeRecordRef, name, guard) {
  const record = activeRecordRef.value;
  if (!record) {
    if (true) warn$1(`No active route record was found when calling \`${name === "updateGuards" ? "onBeforeRouteUpdate" : "onBeforeRouteLeave"}()\`. Make sure you call this function inside a component child of <router-view>. Maybe you called it inside of App.vue?`);
    return;
  }
  let currentRecord = record;
  const removeFromList = () => {
    currentRecord[name].delete(guard);
  };
  onUnmounted(removeFromList);
  onDeactivated(removeFromList);
  onActivated(() => {
    const newRecord = activeRecordRef.value;
    if (!newRecord) warn$1("No active route record was found when reactivating component with navigation guard. This is likely a bug in vue-router. Please report it.");
    if (newRecord) currentRecord = newRecord;
    currentRecord[name].add(guard);
  });
  currentRecord[name].add(guard);
}
function onBeforeRouteLeave(leaveGuard) {
  if (!getCurrentInstance()) {
    warn$1("getCurrentInstance() returned null. onBeforeRouteLeave() must be called at the top of a setup function");
    return;
  }
  registerGuard(inject(matchedRouteKey, {}), "leaveGuards", leaveGuard);
}
function onBeforeRouteUpdate(updateGuard) {
  if (!getCurrentInstance()) {
    warn$1("getCurrentInstance() returned null. onBeforeRouteUpdate() must be called at the top of a setup function");
    return;
  }
  registerGuard(inject(matchedRouteKey, {}), "updateGuards", updateGuard);
}
function guardToPromiseFn(guard, to, from, record, name, runWithContext = (fn) => fn()) {
  const enterCallbackArray = record && (record.enterCallbacks[name] = record.enterCallbacks[name] || []);
  return () => new Promise((resolve, reject) => {
    const next = (valid) => {
      if (valid === false) reject(createRouterError(4, {
        from,
        to
      }));
      else if (valid instanceof Error) reject(valid);
      else if (isRouteLocation(valid)) reject(createRouterError(2, {
        from: to,
        to: valid
      }));
      else {
        if (enterCallbackArray && record.enterCallbacks[name] === enterCallbackArray && typeof valid === "function") enterCallbackArray.push(valid);
        resolve();
      }
    };
    const guardReturn = runWithContext(() => guard.call(record && record.instances[name], to, from, true ? withDeprecationWarning(canOnlyBeCalledOnce(next, to, from)) : next));
    let guardCall = Promise.resolve(guardReturn);
    if (guard.length < 3) guardCall = guardCall.then(next);
    if (guard.length > 2) {
      const message = `The "next" callback was never called inside of ${guard.name ? '"' + guard.name + '"' : ""}:
${guard.toString()}
. If you are returning a value instead of calling "next", make sure to remove the "next" parameter from your function.`;
      if (typeof guardReturn === "object" && "then" in guardReturn) guardCall = guardCall.then((resolvedValue) => {
        if (!next._called) {
          warn$1(message);
          return Promise.reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
        }
        return resolvedValue;
      });
      else if (guardReturn !== void 0) {
        if (!next._called) {
          warn$1(message);
          reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
          return;
        }
      }
    }
    guardCall.catch((err) => reject(err));
  });
}
function withDeprecationWarning(next) {
  let warned = false;
  return function() {
    if (!warned) {
      warned = true;
      warn$1("The `next()` callback in navigation guards is deprecated. Return the value instead of calling `next(value)`.");
    }
    return next.apply(this, arguments);
  };
}
function canOnlyBeCalledOnce(next, to, from) {
  let called = 0;
  return function() {
    if (called++ === 1) warn$1(`The "next" callback was called more than once in one navigation guard when going from "${from.fullPath}" to "${to.fullPath}". It should be called exactly one time in each navigation guard. This will fail in production.`);
    next._called = true;
    if (called === 1) next.apply(null, arguments);
  };
}
function extractComponentsGuards(matched, guardType, to, from, runWithContext = (fn) => fn()) {
  const guards = [];
  for (const record of matched) {
    if (!record.components && record.children && !record.children.length) warn$1(`Record with path "${record.path}" is either missing a "component(s)" or "children" property.`);
    for (const name in record.components) {
      let rawComponent = record.components[name];
      if (true) {
        if (!rawComponent || typeof rawComponent !== "object" && typeof rawComponent !== "function") {
          warn$1(`Component "${name}" in record with path "${record.path}" is not a valid component. Received "${String(rawComponent)}".`);
          throw new Error("Invalid route component");
        } else if ("then" in rawComponent) {
          warn$1(`Component "${name}" in record with path "${record.path}" is a Promise instead of a function that returns a Promise. Did you write "import('./MyPage.vue')" instead of "() => import('./MyPage.vue')" ? This will break in production if not fixed.`);
          const promise = rawComponent;
          rawComponent = () => promise;
        } else if (rawComponent.__asyncLoader && !rawComponent.__warnedDefineAsync) {
          rawComponent.__warnedDefineAsync = true;
          warn$1(`Component "${name}" in record with path "${record.path}" is defined using "defineAsyncComponent()". Write "() => import('./MyPage.vue')" instead of "defineAsyncComponent(() => import('./MyPage.vue'))".`);
        }
      }
      if (guardType !== "beforeRouteEnter" && !record.instances[name]) continue;
      if (isRouteComponent(rawComponent)) {
        const guard = (rawComponent.__vccOpts || rawComponent)[guardType];
        guard && guards.push(guardToPromiseFn(guard, to, from, record, name, runWithContext));
      } else {
        let componentPromise = rawComponent();
        if (!("catch" in componentPromise)) {
          warn$1(`Component "${name}" in record with path "${record.path}" is a function that does not return a Promise. If you were passing a functional component, make sure to add a "displayName" to the component. This will break in production if not fixed.`);
          componentPromise = Promise.resolve(componentPromise);
        }
        guards.push(() => componentPromise.then((resolved) => {
          if (!resolved) throw new Error(`Couldn't resolve component "${name}" at "${record.path}"`);
          const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
          record.mods[name] = resolved;
          record.components[name] = resolvedComponent;
          const guard = (resolvedComponent.__vccOpts || resolvedComponent)[guardType];
          return guard && guardToPromiseFn(guard, to, from, record, name, runWithContext)();
        }));
      }
    }
  }
  return guards;
}
function loadRouteLocation(route) {
  return route.matched.every((record) => record.redirect) ? Promise.reject(/* @__PURE__ */ new Error("Cannot load a route that redirects.")) : Promise.all(route.matched.map((record) => record.components && Promise.all(Object.keys(record.components).reduce((promises, name) => {
    const rawComponent = record.components[name];
    if (typeof rawComponent === "function" && !("displayName" in rawComponent)) promises.push(rawComponent().then((resolved) => {
      if (!resolved) return Promise.reject(/* @__PURE__ */ new Error(`Couldn't resolve component "${name}" at "${record.path}". Ensure you passed a function that returns a promise.`));
      const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
      record.mods[name] = resolved;
      record.components[name] = resolvedComponent;
    }));
    return promises;
  }, [])))).then(() => route);
}
function extractChangingRecords(to, from) {
  const leavingRecords = [];
  const updatingRecords = [];
  const enteringRecords = [];
  const len = Math.max(from.matched.length, to.matched.length);
  for (let i = 0; i < len; i++) {
    const recordFrom = from.matched[i];
    if (recordFrom) if (to.matched.find((record) => isSameRouteRecord(record, recordFrom))) updatingRecords.push(recordFrom);
    else leavingRecords.push(recordFrom);
    const recordTo = to.matched[i];
    if (recordTo) {
      if (!from.matched.find((record) => isSameRouteRecord(record, recordTo))) enteringRecords.push(recordTo);
    }
  }
  return [
    leavingRecords,
    updatingRecords,
    enteringRecords
  ];
}
function formatRouteLocation(routeLocation, tooltip) {
  const copy = assign({}, routeLocation, { matched: routeLocation.matched.map((matched) => omit(matched, [
    "instances",
    "children",
    "aliasOf"
  ])) });
  return { _custom: {
    type: null,
    readOnly: true,
    display: routeLocation.fullPath,
    tooltip,
    value: copy
  } };
}
function formatDisplay(display) {
  return { _custom: { display } };
}
let routerId = 0;
function addDevtools(app, router, matcher) {
  if (router.__hasDevtools) return;
  router.__hasDevtools = true;
  const id = routerId++;
  setupDevtoolsPlugin({
    id: "org.vuejs.router" + (id ? "." + id : ""),
    label: "Vue Router",
    packageName: "vue-router",
    homepage: "https://router.vuejs.org",
    logo: "https://router.vuejs.org/logo.png",
    componentStateTypes: ["Routing"],
    app
  }, (api) => {
    api.on.inspectComponent((payload) => {
      if (payload.instanceData) payload.instanceData.state.push({
        type: "Routing",
        key: "$route",
        editable: false,
        value: formatRouteLocation(router.currentRoute.value, "Current Route")
      });
    });
    api.on.visitComponentTree(({ treeNode: node, componentInstance }) => {
      if (componentInstance.__vrv_devtools) {
        const info = componentInstance.__vrv_devtools;
        node.tags.push({
          label: (info.name ? `${info.name.toString()}: ` : "") + info.path,
          textColor: 0,
          tooltip: "This component is rendered by &lt;router-view&gt;",
          backgroundColor: PINK_500
        });
      }
      if (isArray(componentInstance.__vrl_devtools)) {
        componentInstance.__devtoolsApi = api;
        componentInstance.__vrl_devtools.forEach((devtoolsData) => {
          let label = devtoolsData.route.path;
          let backgroundColor = ORANGE_400;
          let tooltip = "";
          let textColor = 0;
          if (devtoolsData.error) {
            label = devtoolsData.error;
            backgroundColor = RED_100;
            textColor = RED_700;
          } else if (devtoolsData.isExactActive) {
            backgroundColor = LIME_500;
            tooltip = "This is exactly active";
          } else if (devtoolsData.isActive) {
            backgroundColor = BLUE_600;
            tooltip = "This link is active";
          }
          node.tags.push({
            label,
            textColor,
            tooltip,
            backgroundColor
          });
        });
      }
    });
    watch(router.currentRoute, () => {
      refreshRoutesView();
      api.notifyComponentUpdate();
      api.sendInspectorTree(routerInspectorId);
      api.sendInspectorState(routerInspectorId);
    });
    const navigationsLayerId = "router:navigations:" + id;
    api.addTimelineLayer({
      id: navigationsLayerId,
      label: `Router${id ? " " + id : ""} Navigations`,
      color: 4237508
    });
    router.onError((error, to) => {
      api.addTimelineEvent({
        layerId: navigationsLayerId,
        event: {
          title: "Error during Navigation",
          subtitle: to.fullPath,
          logType: "error",
          time: api.now(),
          data: { error },
          groupId: to.meta.__navigationId
        }
      });
    });
    let navigationId = 0;
    router.beforeEach((to, from) => {
      const data = {
        guard: formatDisplay("beforeEach"),
        from: formatRouteLocation(from, "Current Location during this navigation"),
        to: formatRouteLocation(to, "Target location")
      };
      Object.defineProperty(to.meta, "__navigationId", { value: navigationId++ });
      api.addTimelineEvent({
        layerId: navigationsLayerId,
        event: {
          time: api.now(),
          title: "Start of navigation",
          subtitle: to.fullPath,
          data,
          groupId: to.meta.__navigationId
        }
      });
    });
    router.afterEach((to, from, failure) => {
      const data = { guard: formatDisplay("afterEach") };
      if (failure) {
        data.failure = { _custom: {
          type: Error,
          readOnly: true,
          display: failure ? failure.message : "",
          tooltip: "Navigation Failure",
          value: failure
        } };
        data.status = formatDisplay("❌");
      } else data.status = formatDisplay("✅");
      data.from = formatRouteLocation(from, "Current Location during this navigation");
      data.to = formatRouteLocation(to, "Target location");
      api.addTimelineEvent({
        layerId: navigationsLayerId,
        event: {
          title: "End of navigation",
          subtitle: to.fullPath,
          time: api.now(),
          data,
          logType: failure ? "warning" : "default",
          groupId: to.meta.__navigationId
        }
      });
    });
    const routerInspectorId = "router-inspector:" + id;
    api.addInspector({
      id: routerInspectorId,
      label: "Routes" + (id ? " " + id : ""),
      icon: "book",
      treeFilterPlaceholder: "Search routes"
    });
    function refreshRoutesView() {
      if (!activeRoutesPayload) return;
      const payload = activeRoutesPayload;
      let routes = matcher.getRoutes().filter((route) => !route.parent || !route.parent.record.components);
      routes.forEach(resetMatchStateOnRouteRecord);
      if (payload.filter) routes = routes.filter((route) => isRouteMatching(route, payload.filter.toLowerCase()));
      routes.forEach((route) => markRouteRecordActive(route, router.currentRoute.value));
      payload.rootNodes = routes.map(formatRouteRecordForInspector);
    }
    let activeRoutesPayload;
    api.on.getInspectorTree((payload) => {
      activeRoutesPayload = payload;
      if (payload.app === app && payload.inspectorId === routerInspectorId) refreshRoutesView();
    });
    api.on.getInspectorState((payload) => {
      if (payload.app === app && payload.inspectorId === routerInspectorId) {
        const route = matcher.getRoutes().find((route2) => route2.record.__vd_id === payload.nodeId);
        if (route) payload.state = { options: formatRouteRecordMatcherForStateInspector(route) };
      }
    });
    api.sendInspectorTree(routerInspectorId);
    api.sendInspectorState(routerInspectorId);
  });
}
function modifierForKey(key) {
  if (key.optional) return key.repeatable ? "*" : "?";
  else return key.repeatable ? "+" : "";
}
function formatRouteRecordMatcherForStateInspector(route) {
  const { record } = route;
  const fields = [{
    editable: false,
    key: "path",
    value: record.path
  }];
  if (record.name != null) fields.push({
    editable: false,
    key: "name",
    value: record.name
  });
  fields.push({
    editable: false,
    key: "regexp",
    value: route.re
  });
  if (route.keys.length) fields.push({
    editable: false,
    key: "keys",
    value: { _custom: {
      type: null,
      readOnly: true,
      display: route.keys.map((key) => `${key.name}${modifierForKey(key)}`).join(" "),
      tooltip: "Param keys",
      value: route.keys
    } }
  });
  if (record.redirect != null) fields.push({
    editable: false,
    key: "redirect",
    value: record.redirect
  });
  if (route.alias.length) fields.push({
    editable: false,
    key: "aliases",
    value: route.alias.map((alias) => alias.record.path)
  });
  if (Object.keys(route.record.meta).length) fields.push({
    editable: false,
    key: "meta",
    value: route.record.meta
  });
  fields.push({
    key: "score",
    editable: false,
    value: { _custom: {
      type: null,
      readOnly: true,
      display: route.score.map((score) => score.join(", ")).join(" | "),
      tooltip: "Score used to sort routes",
      value: route.score
    } }
  });
  return fields;
}
const PINK_500 = 15485081;
const BLUE_600 = 2450411;
const LIME_500 = 8702998;
const CYAN_400 = 2282478;
const ORANGE_400 = 16486972;
const DARK = 6710886;
const RED_100 = 16704226;
const RED_700 = 12131356;
function formatRouteRecordForInspector(route) {
  const tags = [];
  const { record } = route;
  if (record.name != null) tags.push({
    label: String(record.name),
    textColor: 0,
    backgroundColor: CYAN_400
  });
  if (record.aliasOf) tags.push({
    label: "alias",
    textColor: 0,
    backgroundColor: ORANGE_400
  });
  if (route.__vd_match) tags.push({
    label: "matches",
    textColor: 0,
    backgroundColor: PINK_500
  });
  if (route.__vd_exactActive) tags.push({
    label: "exact",
    textColor: 0,
    backgroundColor: LIME_500
  });
  if (route.__vd_active) tags.push({
    label: "active",
    textColor: 0,
    backgroundColor: BLUE_600
  });
  if (record.redirect) tags.push({
    label: typeof record.redirect === "string" ? `redirect: ${record.redirect}` : "redirects",
    textColor: 16777215,
    backgroundColor: DARK
  });
  let id = record.__vd_id;
  if (id == null) {
    id = String(routeRecordId++);
    record.__vd_id = id;
  }
  return {
    id,
    label: record.path,
    tags,
    children: route.children.map(formatRouteRecordForInspector)
  };
}
let routeRecordId = 0;
const EXTRACT_REGEXP_RE = /^\/(.*)\/([a-z]*)$/;
function markRouteRecordActive(route, currentRoute) {
  const isExactActive = currentRoute.matched.length && isSameRouteRecord(currentRoute.matched[currentRoute.matched.length - 1], route.record);
  route.__vd_exactActive = route.__vd_active = isExactActive;
  if (!isExactActive) route.__vd_active = currentRoute.matched.some((match) => isSameRouteRecord(match, route.record));
  route.children.forEach((childRoute) => markRouteRecordActive(childRoute, currentRoute));
}
function resetMatchStateOnRouteRecord(route) {
  route.__vd_match = false;
  route.children.forEach(resetMatchStateOnRouteRecord);
}
function isRouteMatching(route, filter) {
  const found = String(route.re).match(EXTRACT_REGEXP_RE);
  route.__vd_match = false;
  if (!found || found.length < 3) return false;
  if (new RegExp(found[1].replace(/\$$/, ""), found[2]).test(filter)) {
    route.children.forEach((child) => isRouteMatching(child, filter));
    if (route.record.path !== "/" || filter === "/") {
      route.__vd_match = route.re.test(filter);
      return true;
    }
    return false;
  }
  const path = route.record.path.toLowerCase();
  const decodedPath = decode(path);
  if (!filter.startsWith("/") && (decodedPath.includes(filter) || path.includes(filter))) return true;
  if (decodedPath.startsWith(filter) || path.startsWith(filter)) return true;
  if (route.record.name && String(route.record.name).includes(filter)) return true;
  return route.children.some((child) => isRouteMatching(child, filter));
}
function omit(obj, keys) {
  const ret = {};
  for (const key in obj) if (!keys.includes(key)) ret[key] = obj[key];
  return ret;
}
export { PLUS_RE as A, isSameRouteLocation as C, resolveRelativePath as D, parseURL as E, warn$1 as F, encodeHash as M, encodeParam as N, stringifyURL as O, encodePath as P, START_LOCATION_NORMALIZED as S, isSameRouteRecord as T, saveScrollPosition as _, loadRouteLocation as a, normalizeBase as b, useCallbacks as c, stringifyQuery as d, isRouteLocation as f, getScrollKey as g, getSavedScrollPosition as h, guardToPromiseFn as i, decode as j, stripBase as k, normalizeQuery as l, computeScrollPosition as m, extractChangingRecords as n, onBeforeRouteLeave as o, isRouteName as p, extractComponentsGuards as r, onBeforeRouteUpdate as s, addDevtools as t, parseQuery as u, scrollToPosition as v, isSameRouteLocationParams as w, NEW_stringifyURL as x, createHref as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldnRvb2xzLURDb1dRb1VfLmpzP3Y9NTgzMDc4ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiLyohXG4qIHZ1ZS1yb3V0ZXIgdjUuMS4wXG4qIChjKSAyMDI2IEVkdWFyZG8gU2FuIE1hcnRpbiBNb3JvdGVcbiogQGxpY2Vuc2UgTUlUXG4qL1xuaW1wb3J0IHsgZiBhcyBhc3NpZ24sIGcgYXMgaXNSb3V0ZUNvbXBvbmVudCwgaCBhcyBpc0VTTW9kdWxlLCBsIGFzIGNyZWF0ZVJvdXRlckVycm9yLCBtIGFzIGlzQXJyYXksIHIgYXMgbWF0Y2hlZFJvdXRlS2V5LCB5IGFzIGlzQnJvd3NlciB9IGZyb20gXCIuL3VzZUFwaS1zXzAybEhqbC5qc1wiO1xuaW1wb3J0IHsgZ2V0Q3VycmVudEluc3RhbmNlLCBpbmplY3QsIG9uQWN0aXZhdGVkLCBvbkRlYWN0aXZhdGVkLCBvblVubW91bnRlZCwgd2F0Y2ggfSBmcm9tIFwidnVlXCI7XG5pbXBvcnQgeyBzZXR1cERldnRvb2xzUGx1Z2luIH0gZnJvbSBcIkB2dWUvZGV2dG9vbHMtYXBpXCI7XG4vLyNyZWdpb24gc3JjL3dhcm5pbmcudHNcbmZ1bmN0aW9uIHdhcm4kMShtc2cpIHtcblx0Y29uc3QgYXJncyA9IEFycmF5LmZyb20oYXJndW1lbnRzKS5zbGljZSgxKTtcblx0Y29uc29sZS53YXJuLmFwcGx5KGNvbnNvbGUsIFtcIltWdWUgUm91dGVyIHdhcm5dOiBcIiArIG1zZ10uY29uY2F0KGFyZ3MpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9lbmNvZGluZy50c1xuLyoqXG4qIEVuY29kaW5nIFJ1bGVzICjikKMgPSBTcGFjZSlcbiogLSBQYXRoOiDikKMgXCIgPCA+ICMgPyB7IH1cbiogLSBRdWVyeTog4pCjIFwiIDwgPiAjICYgPVxuKiAtIEhhc2g6IOKQoyBcIiA8ID4gYFxuKlxuKiBPbiB0b3Agb2YgdGhhdCwgdGhlIFJGQzM5ODYgKGh0dHBzOi8vdG9vbHMuaWV0Zi5vcmcvaHRtbC9yZmMzOTg2I3NlY3Rpb24tMi4yKVxuKiBkZWZpbmVzIHNvbWUgZXh0cmEgY2hhcmFjdGVycyB0byBiZSBlbmNvZGVkLiBNb3N0IGJyb3dzZXJzIGRvIG5vdCBlbmNvZGUgdGhlbVxuKiBpbiBlbmNvZGVVUkkgaHR0cHM6Ly9naXRodWIuY29tL3doYXR3Zy91cmwvaXNzdWVzLzM2OSwgc28gaXQgbWF5IGJlIHNhZmVyIHRvXG4qIGFsc28gZW5jb2RlIGAhJygpKmAuIExlYXZpbmcgdW4tZW5jb2RlZCBvbmx5IEFTQ0lJIGFscGhhbnVtZXJpYyhgYS16QS1aMC05YClcbiogcGx1cyBgLS5ffmAuIFRoaXMgZXh0cmEgc2FmZXR5IHNob3VsZCBiZSBhcHBsaWVkIHRvIHF1ZXJ5IGJ5IHBhdGNoaW5nIHRoZVxuKiBzdHJpbmcgcmV0dXJuZWQgYnkgZW5jb2RlVVJJQ29tcG9uZW50IGVuY29kZVVSSSBhbHNvIGVuY29kZXMgYFtcXF1eYC4gYFxcYFxuKiBzaG91bGQgYmUgZW5jb2RlZCB0byBhdm9pZCBhbWJpZ3VpdHkuIEJyb3dzZXJzIChJRSwgRkYsIEMpIHRyYW5zZm9ybSBhIGBcXGBcbiogaW50byBhIGAvYCBpZiBkaXJlY3RseSB0eXBlZCBpbi4gVGhlIF9iYWNrdGlja18gKGBgYGBgKSBzaG91bGQgYWxzbyBiZVxuKiBlbmNvZGVkIGV2ZXJ5d2hlcmUgYmVjYXVzZSBzb21lIGJyb3dzZXJzIGxpa2UgRkYgZW5jb2RlIGl0IHdoZW4gZGlyZWN0bHlcbiogd3JpdHRlbiB3aGlsZSBvdGhlcnMgZG9uJ3QuIFNhZmFyaSBhbmQgSUUgZG9uJ3QgZW5jb2RlIGBgXCI8Pnt9YGBgIGluIGhhc2guXG4qL1xuY29uc3QgSEFTSF9SRSA9IC8jL2c7XG5jb25zdCBBTVBFUlNBTkRfUkUgPSAvJi9nO1xuY29uc3QgU0xBU0hfUkUgPSAvXFwvL2c7XG5jb25zdCBFUVVBTF9SRSA9IC89L2c7XG5jb25zdCBJTV9SRSA9IC9cXD8vZztcbmNvbnN0IFBMVVNfUkUgPSAvXFwrL2c7XG4vKipcbiogTk9URTogSXQncyBub3QgY2xlYXIgdG8gbWUgaWYgd2Ugc2hvdWxkIGVuY29kZSB0aGUgKyBzeW1ib2wgaW4gcXVlcmllcywgaXRcbiogc2VlbXMgdG8gYmUgbGVzcyBmbGV4aWJsZSB0aGFuIG5vdCBkb2luZyBzbyBhbmQgSSBjYW4ndCBmaW5kIG91dCB0aGUgbGVnYWN5XG4qIHN5c3RlbXMgcmVxdWlyaW5nIHRoaXMgZm9yIHJlZ3VsYXIgcmVxdWVzdHMgbGlrZSB0ZXh0L2h0bWwuIEluIHRoZSBzdGFuZGFyZCxcbiogdGhlIGVuY29kaW5nIG9mIHRoZSBwbHVzIGNoYXJhY3RlciBpcyBvbmx5IG1lbnRpb25lZCBmb3JcbiogYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkXG4qIChodHRwczovL3VybC5zcGVjLndoYXR3Zy5vcmcvI3VybGVuY29kZWQtcGFyc2luZykgYW5kIG1vc3QgYnJvd3NlcnMgc2VlbXMgbG9cbiogbGVhdmUgdGhlIHBsdXMgY2hhcmFjdGVyIGFzIGlzIGluIHF1ZXJpZXMuIFRvIGJlIG1vcmUgZmxleGlibGUsIHdlIGFsbG93IHRoZVxuKiBwbHVzIGNoYXJhY3RlciBvbiB0aGUgcXVlcnksIGJ1dCBpdCBjYW4gYWxzbyBiZSBtYW51YWxseSBlbmNvZGVkIGJ5IHRoZSB1c2VyLlxuKlxuKiBSZXNvdXJjZXM6XG4qIC0gaHR0cHM6Ly91cmwuc3BlYy53aGF0d2cub3JnLyN1cmxlbmNvZGVkLXBhcnNpbmdcbiogLSBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8xNjM0MjcxL3VybC1lbmNvZGluZy10aGUtc3BhY2UtY2hhcmFjdGVyLW9yLTIwXG4qL1xuY29uc3QgRU5DX0JSQUNLRVRfT1BFTl9SRSA9IC8lNUIvZztcbmNvbnN0IEVOQ19CUkFDS0VUX0NMT1NFX1JFID0gLyU1RC9nO1xuY29uc3QgRU5DX0NBUkVUX1JFID0gLyU1RS9nO1xuY29uc3QgRU5DX0JBQ0tUSUNLX1JFID0gLyU2MC9nO1xuY29uc3QgRU5DX0NVUkxZX09QRU5fUkUgPSAvJTdCL2c7XG5jb25zdCBFTkNfUElQRV9SRSA9IC8lN0MvZztcbmNvbnN0IEVOQ19DVVJMWV9DTE9TRV9SRSA9IC8lN0QvZztcbmNvbnN0IEVOQ19TUEFDRV9SRSA9IC8lMjAvZztcbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgcGF0aCwgc2VhcmNoIGFuZCBoYXNoXG4qIHNlY3Rpb25zIG9mIHRoZSBVUkwuXG4qXG4qIEBpbnRlcm5hbFxuKiBAcGFyYW0gdGV4dCAtIHN0cmluZyB0byBlbmNvZGVcbiogQHJldHVybnMgZW5jb2RlZCBzdHJpbmdcbiovXG5mdW5jdGlvbiBjb21tb25FbmNvZGUodGV4dCkge1xuXHRyZXR1cm4gdGV4dCA9PSBudWxsID8gXCJcIiA6IGVuY29kZVVSSShcIlwiICsgdGV4dCkucmVwbGFjZShFTkNfUElQRV9SRSwgXCJ8XCIpLnJlcGxhY2UoRU5DX0JSQUNLRVRfT1BFTl9SRSwgXCJbXCIpLnJlcGxhY2UoRU5DX0JSQUNLRVRfQ0xPU0VfUkUsIFwiXVwiKTtcbn1cbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgaGFzaCBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZUhhc2godGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoRU5DX0NVUkxZX09QRU5fUkUsIFwie1wiKS5yZXBsYWNlKEVOQ19DVVJMWV9DTE9TRV9SRSwgXCJ9XCIpLnJlcGxhY2UoRU5DX0NBUkVUX1JFLCBcIl5cIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgcXVlcnkgdmFsdWVzIG9uIHRoZSBxdWVyeVxuKiBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZVF1ZXJ5VmFsdWUodGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoUExVU19SRSwgXCIlMkJcIikucmVwbGFjZShFTkNfU1BBQ0VfUkUsIFwiK1wiKS5yZXBsYWNlKEhBU0hfUkUsIFwiJTIzXCIpLnJlcGxhY2UoQU1QRVJTQU5EX1JFLCBcIiUyNlwiKS5yZXBsYWNlKEVOQ19CQUNLVElDS19SRSwgXCJgXCIpLnJlcGxhY2UoRU5DX0NVUkxZX09QRU5fUkUsIFwie1wiKS5yZXBsYWNlKEVOQ19DVVJMWV9DTE9TRV9SRSwgXCJ9XCIpLnJlcGxhY2UoRU5DX0NBUkVUX1JFLCBcIl5cIik7XG59XG4vKipcbiogTGlrZSBgZW5jb2RlUXVlcnlWYWx1ZWAgYnV0IGFsc28gZW5jb2RlcyB0aGUgYD1gIGNoYXJhY3Rlci5cbipcbiogQHBhcmFtIHRleHQgLSBzdHJpbmcgdG8gZW5jb2RlXG4qL1xuZnVuY3Rpb24gZW5jb2RlUXVlcnlLZXkodGV4dCkge1xuXHRyZXR1cm4gZW5jb2RlUXVlcnlWYWx1ZSh0ZXh0KS5yZXBsYWNlKEVRVUFMX1JFLCBcIiUzRFwiKTtcbn1cbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgcGF0aCBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZVBhdGgodGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoSEFTSF9SRSwgXCIlMjNcIikucmVwbGFjZShJTV9SRSwgXCIlM0ZcIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgb24gdGhlIHBhdGggc2VjdGlvbiBvZiB0aGUgVVJMIGFzIGFcbiogcGFyYW0uIFRoaXMgZnVuY3Rpb24gZW5jb2RlcyBldmVyeXRoaW5nIHtAbGluayBlbmNvZGVQYXRofSBkb2VzIHBsdXMgdGhlXG4qIHNsYXNoIChgL2ApIGNoYXJhY3Rlci4gSWYgYHRleHRgIGlzIGBudWxsYCBvciBgdW5kZWZpbmVkYCwgcmV0dXJucyBhbiBlbXB0eVxuKiBzdHJpbmcgaW5zdGVhZC5cbipcbiogQHBhcmFtIHRleHQgLSBzdHJpbmcgdG8gZW5jb2RlXG4qIEByZXR1cm5zIGVuY29kZWQgc3RyaW5nXG4qL1xuZnVuY3Rpb24gZW5jb2RlUGFyYW0odGV4dCkge1xuXHRyZXR1cm4gZW5jb2RlUGF0aCh0ZXh0KS5yZXBsYWNlKFNMQVNIX1JFLCBcIiUyRlwiKTtcbn1cbmZ1bmN0aW9uIGRlY29kZSh0ZXh0KSB7XG5cdGlmICh0ZXh0ID09IG51bGwpIHJldHVybiBudWxsO1xuXHR0cnkge1xuXHRcdHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoXCJcIiArIHRleHQpO1xuXHR9IGNhdGNoIHtcblx0XHRwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgd2FybiQxKGBFcnJvciBkZWNvZGluZyBcIiR7dGV4dH1cIi4gVXNpbmcgb3JpZ2luYWwgdmFsdWVgKTtcblx0fVxuXHRyZXR1cm4gXCJcIiArIHRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbG9jYXRpb24udHNcbmNvbnN0IFRSQUlMSU5HX1NMQVNIX1JFID0gL1xcLyQvO1xuY29uc3QgcmVtb3ZlVHJhaWxpbmdTbGFzaCA9IChwYXRoKSA9PiBwYXRoLnJlcGxhY2UoVFJBSUxJTkdfU0xBU0hfUkUsIFwiXCIpO1xuLyoqXG4qIFRyYW5zZm9ybXMgYSBVUkkgaW50byBhIG5vcm1hbGl6ZWQgaGlzdG9yeSBsb2NhdGlvblxuKlxuKiBAcGFyYW0gcGFyc2VRdWVyeVxuKiBAcGFyYW0gbG9jYXRpb24gLSBVUkkgdG8gbm9ybWFsaXplXG4qIEBwYXJhbSBjdXJyZW50TG9jYXRpb24gLSBjdXJyZW50IGFic29sdXRlIGxvY2F0aW9uLiBBbGxvd3MgcmVzb2x2aW5nIHJlbGF0aXZlXG4qIHBhdGhzLiBNdXN0IHN0YXJ0IHdpdGggYC9gLiBEZWZhdWx0cyB0byBgL2BcbiogQHJldHVybnMgYSBub3JtYWxpemVkIGhpc3RvcnkgbG9jYXRpb25cbiovXG5mdW5jdGlvbiBwYXJzZVVSTChwYXJzZVF1ZXJ5LCBsb2NhdGlvbiwgY3VycmVudExvY2F0aW9uID0gXCIvXCIpIHtcblx0bGV0IHBhdGgsIHF1ZXJ5ID0ge30sIHNlYXJjaFN0cmluZyA9IFwiXCIsIGhhc2ggPSBcIlwiO1xuXHRjb25zdCBoYXNoUG9zID0gbG9jYXRpb24uaW5kZXhPZihcIiNcIik7XG5cdGxldCBzZWFyY2hQb3MgPSBsb2NhdGlvbi5pbmRleE9mKFwiP1wiKTtcblx0c2VhcmNoUG9zID0gaGFzaFBvcyA+PSAwICYmIHNlYXJjaFBvcyA+IGhhc2hQb3MgPyAtMSA6IHNlYXJjaFBvcztcblx0aWYgKHNlYXJjaFBvcyA+PSAwKSB7XG5cdFx0cGF0aCA9IGxvY2F0aW9uLnNsaWNlKDAsIHNlYXJjaFBvcyk7XG5cdFx0c2VhcmNoU3RyaW5nID0gbG9jYXRpb24uc2xpY2Uoc2VhcmNoUG9zLCBoYXNoUG9zID4gMCA/IGhhc2hQb3MgOiBsb2NhdGlvbi5sZW5ndGgpO1xuXHRcdHF1ZXJ5ID0gcGFyc2VRdWVyeShzZWFyY2hTdHJpbmcuc2xpY2UoMSkpO1xuXHR9XG5cdGlmIChoYXNoUG9zID49IDApIHtcblx0XHRwYXRoID0gcGF0aCB8fCBsb2NhdGlvbi5zbGljZSgwLCBoYXNoUG9zKTtcblx0XHRoYXNoID0gbG9jYXRpb24uc2xpY2UoaGFzaFBvcywgbG9jYXRpb24ubGVuZ3RoKTtcblx0fVxuXHRwYXRoID0gcmVzb2x2ZVJlbGF0aXZlUGF0aChwYXRoICE9IG51bGwgPyBwYXRoIDogbG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbik7XG5cdHJldHVybiB7XG5cdFx0ZnVsbFBhdGg6IHBhdGggKyBzZWFyY2hTdHJpbmcgKyBoYXNoLFxuXHRcdHBhdGgsXG5cdFx0cXVlcnksXG5cdFx0aGFzaDogZGVjb2RlKGhhc2gpXG5cdH07XG59XG5mdW5jdGlvbiBORVdfc3RyaW5naWZ5VVJMKHN0cmluZ2lmeVF1ZXJ5LCBwYXRoLCBxdWVyeSwgaGFzaCA9IFwiXCIpIHtcblx0Y29uc3Qgc2VhcmNoVGV4dCA9IHN0cmluZ2lmeVF1ZXJ5KHF1ZXJ5KTtcblx0cmV0dXJuIHBhdGggKyAoc2VhcmNoVGV4dCAmJiBcIj9cIikgKyBzZWFyY2hUZXh0ICsgZW5jb2RlSGFzaChoYXNoKTtcbn1cbi8qKlxuKiBTdHJpbmdpZmllcyBhIFVSTCBvYmplY3RcbipcbiogQHBhcmFtIHN0cmluZ2lmeVF1ZXJ5XG4qIEBwYXJhbSBsb2NhdGlvblxuKi9cbmZ1bmN0aW9uIHN0cmluZ2lmeVVSTChzdHJpbmdpZnlRdWVyeSwgbG9jYXRpb24pIHtcblx0Y29uc3QgcXVlcnkgPSBsb2NhdGlvbi5xdWVyeSA/IHN0cmluZ2lmeVF1ZXJ5KGxvY2F0aW9uLnF1ZXJ5KSA6IFwiXCI7XG5cdHJldHVybiBsb2NhdGlvbi5wYXRoICsgKHF1ZXJ5ICYmIFwiP1wiKSArIHF1ZXJ5ICsgKGxvY2F0aW9uLmhhc2ggfHwgXCJcIik7XG59XG4vKipcbiogU3RyaXBzIG9mZiB0aGUgYmFzZSBmcm9tIHRoZSBiZWdpbm5pbmcgb2YgYSBsb2NhdGlvbi5wYXRobmFtZSBpbiBhIG5vbi1jYXNlLXNlbnNpdGl2ZSB3YXkuXG4qXG4qIEBwYXJhbSBwYXRobmFtZSAtIGxvY2F0aW9uLnBhdGhuYW1lXG4qIEBwYXJhbSBiYXNlIC0gYmFzZSB0byBzdHJpcCBvZmZcbiovXG5mdW5jdGlvbiBzdHJpcEJhc2UocGF0aG5hbWUsIGJhc2UpIHtcblx0aWYgKCFiYXNlIHx8ICFwYXRobmFtZS50b0xvd2VyQ2FzZSgpLnN0YXJ0c1dpdGgoYmFzZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHBhdGhuYW1lO1xuXHRyZXR1cm4gcGF0aG5hbWUuc2xpY2UoYmFzZS5sZW5ndGgpIHx8IFwiL1wiO1xufVxuLyoqXG4qIENoZWNrcyBpZiB0d28gUm91dGVMb2NhdGlvbiBhcmUgZXF1YWwuIFRoaXMgbWVhbnMgdGhhdCBib3RoIGxvY2F0aW9ucyBhcmVcbiogcG9pbnRpbmcgdG93YXJkcyB0aGUgc2FtZSB7QGxpbmsgUm91dGVSZWNvcmR9IGFuZCB0aGF0IGFsbCBgcGFyYW1zYCwgYHF1ZXJ5YFxuKiBwYXJhbWV0ZXJzIGFuZCBgaGFzaGAgYXJlIHRoZSBzYW1lXG4qXG4qIEBwYXJhbSBzdHJpbmdpZnlRdWVyeSAtIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHF1ZXJ5IG9iamVjdCBvZiB0eXBlIExvY2F0aW9uUXVlcnlSYXcgYW5kIHJldHVybnMgYSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgaXQuXG4qIEBwYXJhbSBhIC0gZmlyc3Qge0BsaW5rIFJvdXRlTG9jYXRpb259XG4qIEBwYXJhbSBiIC0gc2Vjb25kIHtAbGluayBSb3V0ZUxvY2F0aW9ufVxuKi9cbmZ1bmN0aW9uIGlzU2FtZVJvdXRlTG9jYXRpb24oc3RyaW5naWZ5UXVlcnksIGEsIGIpIHtcblx0Y29uc3QgYUxhc3RJbmRleCA9IGEubWF0Y2hlZC5sZW5ndGggLSAxO1xuXHRjb25zdCBiTGFzdEluZGV4ID0gYi5tYXRjaGVkLmxlbmd0aCAtIDE7XG5cdHJldHVybiBhTGFzdEluZGV4ID4gLTEgJiYgYUxhc3RJbmRleCA9PT0gYkxhc3RJbmRleCAmJiBpc1NhbWVSb3V0ZVJlY29yZChhLm1hdGNoZWRbYUxhc3RJbmRleF0sIGIubWF0Y2hlZFtiTGFzdEluZGV4XSkgJiYgaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcyhhLnBhcmFtcywgYi5wYXJhbXMpICYmIHN0cmluZ2lmeVF1ZXJ5KGEucXVlcnkpID09PSBzdHJpbmdpZnlRdWVyeShiLnF1ZXJ5KSAmJiBhLmhhc2ggPT09IGIuaGFzaDtcbn1cbi8qKlxuKiBDaGVjayBpZiB0d28gYFJvdXRlUmVjb3Jkc2AgYXJlIGVxdWFsLiBUYWtlcyBpbnRvIGFjY291bnQgYWxpYXNlczogdGhleSBhcmVcbiogY29uc2lkZXJlZCBlcXVhbCB0byB0aGUgYFJvdXRlUmVjb3JkYCB0aGV5IGFyZSBhbGlhc2luZy5cbipcbiogQHBhcmFtIGEgLSBmaXJzdCB7QGxpbmsgUm91dGVSZWNvcmR9XG4qIEBwYXJhbSBiIC0gc2Vjb25kIHtAbGluayBSb3V0ZVJlY29yZH1cbiovXG5mdW5jdGlvbiBpc1NhbWVSb3V0ZVJlY29yZChhLCBiKSB7XG5cdHJldHVybiAoYS5hbGlhc09mIHx8IGEpID09PSAoYi5hbGlhc09mIHx8IGIpO1xufVxuZnVuY3Rpb24gaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcyhhLCBiKSB7XG5cdGlmIChPYmplY3Qua2V5cyhhKS5sZW5ndGggIT09IE9iamVjdC5rZXlzKGIpLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRmb3IgKHZhciBrZXkgaW4gYSkgaWYgKCFpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zVmFsdWUoYVtrZXldLCBiW2tleV0pKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtc1ZhbHVlKGEsIGIpIHtcblx0cmV0dXJuIGlzQXJyYXkoYSkgPyBpc0VxdWl2YWxlbnRBcnJheShhLCBiKSA6IGlzQXJyYXkoYikgPyBpc0VxdWl2YWxlbnRBcnJheShiLCBhKSA6IChhICYmIGEudmFsdWVPZigpKSA9PT0gKGIgJiYgYi52YWx1ZU9mKCkpO1xufVxuLyoqXG4qIENoZWNrIGlmIHR3byBhcnJheXMgYXJlIHRoZSBzYW1lIG9yIGlmIGFuIGFycmF5IHdpdGggb25lIHNpbmdsZSBlbnRyeSBpcyB0aGVcbiogc2FtZSBhcyBhbm90aGVyIHByaW1pdGl2ZSB2YWx1ZS4gVXNlZCB0byBjaGVjayBxdWVyeSBhbmQgcGFyYW1ldGVyc1xuKlxuKiBAcGFyYW0gYSAtIGFycmF5IG9mIHZhbHVlc1xuKiBAcGFyYW0gYiAtIGFycmF5IG9mIHZhbHVlcyBvciBhIHNpbmdsZSB2YWx1ZVxuKi9cbmZ1bmN0aW9uIGlzRXF1aXZhbGVudEFycmF5KGEsIGIpIHtcblx0cmV0dXJuIGlzQXJyYXkoYikgPyBhLmxlbmd0aCA9PT0gYi5sZW5ndGggJiYgYS5ldmVyeSgodmFsdWUsIGkpID0+IHZhbHVlID09PSBiW2ldKSA6IGEubGVuZ3RoID09PSAxICYmIGFbMF0gPT09IGI7XG59XG4vKipcbiogUmVzb2x2ZXMgYSByZWxhdGl2ZSBwYXRoIHRoYXQgc3RhcnRzIHdpdGggYC5gLlxuKlxuKiBAcGFyYW0gdG8gLSBwYXRoIGxvY2F0aW9uIHdlIGFyZSByZXNvbHZpbmdcbiogQHBhcmFtIGZyb20gLSBjdXJyZW50TG9jYXRpb24ucGF0aCwgc2hvdWxkIHN0YXJ0IHdpdGggYC9gXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZVJlbGF0aXZlUGF0aCh0bywgZnJvbSkge1xuXHRpZiAodG8uc3RhcnRzV2l0aChcIi9cIikpIHJldHVybiB0bztcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhZnJvbS5zdGFydHNXaXRoKFwiL1wiKSkge1xuXHRcdHdhcm4kMShgQ2Fubm90IHJlc29sdmUgYSByZWxhdGl2ZSBsb2NhdGlvbiB3aXRob3V0IGFuIGFic29sdXRlIHBhdGguIFRyeWluZyB0byByZXNvbHZlIFwiJHt0b31cIiBmcm9tIFwiJHtmcm9tfVwiLiBJdCBzaG91bGQgbG9vayBsaWtlIFwiLyR7ZnJvbX1cIi5gKTtcblx0XHRyZXR1cm4gdG87XG5cdH1cblx0aWYgKCF0bykgcmV0dXJuIGZyb207XG5cdGNvbnN0IGZyb21TZWdtZW50cyA9IGZyb20uc3BsaXQoXCIvXCIpO1xuXHRjb25zdCB0b1NlZ21lbnRzID0gdG8uc3BsaXQoXCIvXCIpO1xuXHRjb25zdCBsYXN0VG9TZWdtZW50ID0gdG9TZWdtZW50c1t0b1NlZ21lbnRzLmxlbmd0aCAtIDFdO1xuXHRpZiAobGFzdFRvU2VnbWVudCA9PT0gXCIuLlwiIHx8IGxhc3RUb1NlZ21lbnQgPT09IFwiLlwiKSB0b1NlZ21lbnRzLnB1c2goXCJcIik7XG5cdGxldCBwb3NpdGlvbiA9IGZyb21TZWdtZW50cy5sZW5ndGggLSAxO1xuXHRsZXQgdG9Qb3NpdGlvbjtcblx0bGV0IHNlZ21lbnQ7XG5cdGZvciAodG9Qb3NpdGlvbiA9IDA7IHRvUG9zaXRpb24gPCB0b1NlZ21lbnRzLmxlbmd0aDsgdG9Qb3NpdGlvbisrKSB7XG5cdFx0c2VnbWVudCA9IHRvU2VnbWVudHNbdG9Qb3NpdGlvbl07XG5cdFx0aWYgKHNlZ21lbnQgPT09IFwiLlwiKSBjb250aW51ZTtcblx0XHRpZiAoc2VnbWVudCA9PT0gXCIuLlwiKSB7XG5cdFx0XHRpZiAocG9zaXRpb24gPiAxKSBwb3NpdGlvbi0tO1xuXHRcdH0gZWxzZSBicmVhaztcblx0fVxuXHRyZXR1cm4gZnJvbVNlZ21lbnRzLnNsaWNlKDAsIHBvc2l0aW9uKS5qb2luKFwiL1wiKSArIFwiL1wiICsgdG9TZWdtZW50cy5zbGljZSh0b1Bvc2l0aW9uKS5qb2luKFwiL1wiKTtcbn1cbi8qKlxuKiBJbml0aWFsIHJvdXRlIGxvY2F0aW9uIHdoZXJlIHRoZSByb3V0ZXIgaXMuIENhbiBiZSB1c2VkIGluIG5hdmlnYXRpb24gZ3VhcmRzXG4qIHRvIGRpZmZlcmVudGlhdGUgdGhlIGluaXRpYWwgbmF2aWdhdGlvbi5cbipcbiogQGV4YW1wbGVcbiogYGBganNcbiogaW1wb3J0IHsgU1RBUlRfTE9DQVRJT04gfSBmcm9tICd2dWUtcm91dGVyJ1xuKlxuKiByb3V0ZXIuYmVmb3JlRWFjaCgodG8sIGZyb20pID0+IHtcbiogICBpZiAoZnJvbSA9PT0gU1RBUlRfTE9DQVRJT04pIHtcbiogICAgIC8vIGluaXRpYWwgbmF2aWdhdGlvblxuKiAgIH1cbiogfSlcbiogYGBgXG4qL1xuY29uc3QgU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCA9IHtcblx0cGF0aDogXCIvXCIsXG5cdG5hbWU6IHZvaWQgMCxcblx0cGFyYW1zOiB7fSxcblx0cXVlcnk6IHt9LFxuXHRoYXNoOiBcIlwiLFxuXHRmdWxsUGF0aDogXCIvXCIsXG5cdG1hdGNoZWQ6IFtdLFxuXHRtZXRhOiB7fSxcblx0cmVkaXJlY3RlZEZyb206IHZvaWQgMFxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9oaXN0b3J5L2NvbW1vbi50c1xuLyoqXG4qIE5vcm1hbGl6ZXMgYSBiYXNlIGJ5IHJlbW92aW5nIGFueSB0cmFpbGluZyBzbGFzaCBhbmQgcmVhZGluZyB0aGUgYmFzZSB0YWcgaWZcbiogcHJlc2VudC5cbipcbiogQHBhcmFtIGJhc2UgLSBiYXNlIHRvIG5vcm1hbGl6ZVxuKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZUJhc2UoYmFzZSkge1xuXHRpZiAoIWJhc2UpIGlmIChpc0Jyb3dzZXIpIHtcblx0XHRjb25zdCBiYXNlRWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYmFzZVwiKTtcblx0XHRiYXNlID0gYmFzZUVsICYmIGJhc2VFbC5nZXRBdHRyaWJ1dGUoXCJocmVmXCIpIHx8IFwiL1wiO1xuXHRcdGJhc2UgPSBiYXNlLnJlcGxhY2UoL15cXHcrOlxcL1xcL1teL10rLywgXCJcIik7XG5cdH0gZWxzZSBiYXNlID0gXCIvXCI7XG5cdGlmIChiYXNlWzBdICE9PSBcIi9cIiAmJiBiYXNlWzBdICE9PSBcIiNcIikgYmFzZSA9IFwiL1wiICsgYmFzZTtcblx0cmV0dXJuIHJlbW92ZVRyYWlsaW5nU2xhc2goYmFzZSk7XG59XG5jb25zdCBCRUZPUkVfSEFTSF9SRSA9IC9eW14jXSsjLztcbmZ1bmN0aW9uIGNyZWF0ZUhyZWYoYmFzZSwgbG9jYXRpb24pIHtcblx0cmV0dXJuIGJhc2UucmVwbGFjZShCRUZPUkVfSEFTSF9SRSwgXCIjXCIpICsgbG9jYXRpb247XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2Nyb2xsQmVoYXZpb3IudHNcbmZ1bmN0aW9uIGdldEVsZW1lbnRQb3NpdGlvbihlbCwgb2Zmc2V0KSB7XG5cdGNvbnN0IGRvY1JlY3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdGNvbnN0IGVsUmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRyZXR1cm4ge1xuXHRcdGJlaGF2aW9yOiBvZmZzZXQuYmVoYXZpb3IsXG5cdFx0bGVmdDogZWxSZWN0LmxlZnQgLSBkb2NSZWN0LmxlZnQgLSAob2Zmc2V0LmxlZnQgfHwgMCksXG5cdFx0dG9wOiBlbFJlY3QudG9wIC0gZG9jUmVjdC50b3AgLSAob2Zmc2V0LnRvcCB8fCAwKVxuXHR9O1xufVxuY29uc3QgY29tcHV0ZVNjcm9sbFBvc2l0aW9uID0gKCkgPT4gKHtcblx0bGVmdDogd2luZG93LnNjcm9sbFgsXG5cdHRvcDogd2luZG93LnNjcm9sbFlcbn0pO1xuZnVuY3Rpb24gc2Nyb2xsVG9Qb3NpdGlvbihwb3NpdGlvbikge1xuXHRsZXQgc2Nyb2xsVG9PcHRpb25zO1xuXHRpZiAoXCJlbFwiIGluIHBvc2l0aW9uKSB7XG5cdFx0Y29uc3QgcG9zaXRpb25FbCA9IHBvc2l0aW9uLmVsO1xuXHRcdGNvbnN0IGlzSWRTZWxlY3RvciA9IHR5cGVvZiBwb3NpdGlvbkVsID09PSBcInN0cmluZ1wiICYmIHBvc2l0aW9uRWwuc3RhcnRzV2l0aChcIiNcIik7XG5cdFx0LyoqXG5cdFx0KiBgaWRgcyBjYW4gYWNjZXB0IHByZXR0eSBtdWNoIGFueSBjaGFyYWN0ZXJzLCBpbmNsdWRpbmcgQ1NTIGNvbWJpbmF0b3JzXG5cdFx0KiBsaWtlIGA+YCBvciBgfmAuIEl0J3Mgc3RpbGwgcG9zc2libGUgdG8gcmV0cmlldmUgZWxlbWVudHMgdXNpbmdcblx0XHQqIGBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnficpYCBidXQgaXQgbmVlZHMgdG8gYmUgZXNjYXBlZCB3aGVuIHVzaW5nXG5cdFx0KiBgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI1xcXFx+JylgIGZvciBpdCB0byBiZSB2YWxpZC4gVGhlIG9ubHlcblx0XHQqIHJlcXVpcmVtZW50cyBmb3IgYGlkYHMgYXJlIHRoZW0gdG8gYmUgdW5pcXVlIG9uIHRoZSBwYWdlIGFuZCB0byBub3QgYmVcblx0XHQqIGVtcHR5IChgaWQ9XCJcImApLiBCZWNhdXNlIG9mIHRoYXQsIHdoZW4gcGFzc2luZyBhbiBpZCBzZWxlY3RvciwgaXQgc2hvdWxkXG5cdFx0KiBiZSBwcm9wZXJseSBlc2NhcGVkIGZvciBpdCB0byB3b3JrIHdpdGggYHF1ZXJ5U2VsZWN0b3JgLiBXZSBjb3VsZCBjaGVja1xuXHRcdCogZm9yIHRoZSBpZCBzZWxlY3RvciB0byBiZSBzaW1wbGUgKG5vIENTUyBjb21iaW5hdG9ycyBgKyA+fmApIGJ1dCB0aGF0XG5cdFx0KiB3b3VsZCBtYWtlIHRoaW5ncyBpbmNvbnNpc3RlbnQgc2luY2UgdGhleSBhcmUgdmFsaWQgY2hhcmFjdGVycyBmb3IgYW5cblx0XHQqIGBpZGAgYnV0IHdvdWxkIG5lZWQgdG8gYmUgZXNjYXBlZCB3aGVuIHVzaW5nIGBxdWVyeVNlbGVjdG9yYCwgYnJlYWtpbmdcblx0XHQqIHRoZWlyIHVzYWdlIGFuZCBlbmRpbmcgdXAgaW4gbm8gc2VsZWN0b3IgcmV0dXJuZWQuIFNlbGVjdG9ycyBuZWVkIHRvIGJlXG5cdFx0KiBlc2NhcGVkOlxuXHRcdCpcblx0XHQqIC0gYCMxLXRoaW5nYCBiZWNvbWVzIGAjXFwzMSAtdGhpbmdgXG5cdFx0KiAtIGAjd2l0aH5zeW1ib2xzYCBiZWNvbWVzIGAjd2l0aFxcXFx+c3ltYm9sc2Bcblx0XHQqXG5cdFx0KiAtIE1vcmUgaW5mb3JtYXRpb24gYWJvdXQgIHRoZSB0b3BpYyBjYW4gYmUgZm91bmQgYXRcblx0XHQqICAgaHR0cHM6Ly9tYXRoaWFzYnluZW5zLmJlL25vdGVzL2h0bWw1LWlkLWNsYXNzLlxuXHRcdCogLSBQcmFjdGljYWwgZXhhbXBsZTogaHR0cHM6Ly9tYXRoaWFzYnluZW5zLmJlL2RlbW8vaHRtbDUtaWRcblx0XHQqL1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgdHlwZW9mIHBvc2l0aW9uLmVsID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRpZiAoIWlzSWRTZWxlY3RvciB8fCAhZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQocG9zaXRpb24uZWwuc2xpY2UoMSkpKSB0cnkge1xuXHRcdFx0XHRjb25zdCBmb3VuZEVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihwb3NpdGlvbi5lbCk7XG5cdFx0XHRcdGlmIChpc0lkU2VsZWN0b3IgJiYgZm91bmRFbCkge1xuXHRcdFx0XHRcdHdhcm4kMShgVGhlIHNlbGVjdG9yIFwiJHtwb3NpdGlvbi5lbH1cIiBzaG91bGQgYmUgcGFzc2VkIGFzIFwiZWw6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyR7cG9zaXRpb24uZWx9JylcIiBiZWNhdXNlIGl0IHN0YXJ0cyB3aXRoIFwiI1wiLmApO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdHdhcm4kMShgVGhlIHNlbGVjdG9yIFwiJHtwb3NpdGlvbi5lbH1cIiBpcyBpbnZhbGlkLiBJZiB5b3UgYXJlIHVzaW5nIGFuIGlkIHNlbGVjdG9yLCBtYWtlIHN1cmUgdG8gZXNjYXBlIGl0LiBZb3UgY2FuIGZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCBlc2NhcGluZyBjaGFyYWN0ZXJzIGluIHNlbGVjdG9ycyBhdCBodHRwczovL21hdGhpYXNieW5lbnMuYmUvbm90ZXMvY3NzLWVzY2FwZXMgb3IgdXNlIENTUy5lc2NhcGUgKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DU1MvZXNjYXBlKS5gKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRjb25zdCBlbCA9IHR5cGVvZiBwb3NpdGlvbkVsID09PSBcInN0cmluZ1wiID8gaXNJZFNlbGVjdG9yID8gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQocG9zaXRpb25FbC5zbGljZSgxKSkgOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHBvc2l0aW9uRWwpIDogcG9zaXRpb25FbDtcblx0XHRpZiAoIWVsKSB7XG5cdFx0XHRwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgd2FybiQxKGBDb3VsZG4ndCBmaW5kIGVsZW1lbnQgdXNpbmcgc2VsZWN0b3IgXCIke3Bvc2l0aW9uLmVsfVwiIHJldHVybmVkIGJ5IHNjcm9sbEJlaGF2aW9yLmApO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRzY3JvbGxUb09wdGlvbnMgPSBnZXRFbGVtZW50UG9zaXRpb24oZWwsIHBvc2l0aW9uKTtcblx0fSBlbHNlIHNjcm9sbFRvT3B0aW9ucyA9IHBvc2l0aW9uO1xuXHRpZiAoXCJzY3JvbGxCZWhhdmlvclwiIGluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZSkgd2luZG93LnNjcm9sbFRvKHNjcm9sbFRvT3B0aW9ucyk7XG5cdGVsc2Ugd2luZG93LnNjcm9sbFRvKHNjcm9sbFRvT3B0aW9ucy5sZWZ0ICE9IG51bGwgPyBzY3JvbGxUb09wdGlvbnMubGVmdCA6IHdpbmRvdy5zY3JvbGxYLCBzY3JvbGxUb09wdGlvbnMudG9wICE9IG51bGwgPyBzY3JvbGxUb09wdGlvbnMudG9wIDogd2luZG93LnNjcm9sbFkpO1xufVxuZnVuY3Rpb24gZ2V0U2Nyb2xsS2V5KHBhdGgsIGRlbHRhKSB7XG5cdHJldHVybiAoaGlzdG9yeS5zdGF0ZSA/IGhpc3Rvcnkuc3RhdGUucG9zaXRpb24gLSBkZWx0YSA6IC0xKSArIHBhdGg7XG59XG5jb25zdCBzY3JvbGxQb3NpdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuZnVuY3Rpb24gc2F2ZVNjcm9sbFBvc2l0aW9uKGtleSwgc2Nyb2xsUG9zaXRpb24pIHtcblx0c2Nyb2xsUG9zaXRpb25zLnNldChrZXksIHNjcm9sbFBvc2l0aW9uKTtcbn1cbmZ1bmN0aW9uIGdldFNhdmVkU2Nyb2xsUG9zaXRpb24oa2V5KSB7XG5cdGNvbnN0IHNjcm9sbCA9IHNjcm9sbFBvc2l0aW9ucy5nZXQoa2V5KTtcblx0c2Nyb2xsUG9zaXRpb25zLmRlbGV0ZShrZXkpO1xuXHRyZXR1cm4gc2Nyb2xsO1xufVxuLyoqXG4qIFNjcm9sbEJlaGF2aW9yIGluc3RhbmNlIHVzZWQgYnkgdGhlIHJvdXRlciB0byBjb21wdXRlIGFuZCByZXN0b3JlIHRoZSBzY3JvbGxcbiogcG9zaXRpb24gd2hlbiBuYXZpZ2F0aW5nLlxuKi9cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy90eXBlcy90eXBlR3VhcmRzLnRzXG5mdW5jdGlvbiBpc1JvdXRlTG9jYXRpb24ocm91dGUpIHtcblx0cmV0dXJuIHR5cGVvZiByb3V0ZSA9PT0gXCJzdHJpbmdcIiB8fCByb3V0ZSAmJiB0eXBlb2Ygcm91dGUgPT09IFwib2JqZWN0XCI7XG59XG5mdW5jdGlvbiBpc1JvdXRlTmFtZShuYW1lKSB7XG5cdHJldHVybiB0eXBlb2YgbmFtZSA9PT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgbmFtZSA9PT0gXCJzeW1ib2xcIjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9xdWVyeS50c1xuLyoqXG4qIFRyYW5zZm9ybXMgYSBxdWVyeVN0cmluZyBpbnRvIGEge0BsaW5rIExvY2F0aW9uUXVlcnl9IG9iamVjdC4gQWNjZXB0IGJvdGgsIGFcbiogdmVyc2lvbiB3aXRoIHRoZSBsZWFkaW5nIGA/YCBhbmQgd2l0aG91dCBTaG91bGQgd29yayBhcyBVUkxTZWFyY2hQYXJhbXNcblxuKiBAaW50ZXJuYWxcbipcbiogQHBhcmFtIHNlYXJjaCAtIHNlYXJjaCBzdHJpbmcgdG8gcGFyc2VcbiogQHJldHVybnMgYSBxdWVyeSBvYmplY3RcbiovXG5mdW5jdGlvbiBwYXJzZVF1ZXJ5KHNlYXJjaCkge1xuXHRjb25zdCBxdWVyeSA9IHt9O1xuXHRpZiAoc2VhcmNoID09PSBcIlwiIHx8IHNlYXJjaCA9PT0gXCI/XCIpIHJldHVybiBxdWVyeTtcblx0Y29uc3Qgc2VhcmNoUGFyYW1zID0gKHNlYXJjaFswXSA9PT0gXCI/XCIgPyBzZWFyY2guc2xpY2UoMSkgOiBzZWFyY2gpLnNwbGl0KFwiJlwiKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzZWFyY2hQYXJhbXMubGVuZ3RoOyArK2kpIHtcblx0XHRjb25zdCBzZWFyY2hQYXJhbSA9IHNlYXJjaFBhcmFtc1tpXS5yZXBsYWNlKFBMVVNfUkUsIFwiIFwiKTtcblx0XHRjb25zdCBlcVBvcyA9IHNlYXJjaFBhcmFtLmluZGV4T2YoXCI9XCIpO1xuXHRcdGNvbnN0IGtleSA9IGRlY29kZShlcVBvcyA8IDAgPyBzZWFyY2hQYXJhbSA6IHNlYXJjaFBhcmFtLnNsaWNlKDAsIGVxUG9zKSk7XG5cdFx0Y29uc3QgdmFsdWUgPSBlcVBvcyA8IDAgPyBudWxsIDogZGVjb2RlKHNlYXJjaFBhcmFtLnNsaWNlKGVxUG9zICsgMSkpO1xuXHRcdGlmIChrZXkgaW4gcXVlcnkpIHtcblx0XHRcdGxldCBjdXJyZW50VmFsdWUgPSBxdWVyeVtrZXldO1xuXHRcdFx0aWYgKCFpc0FycmF5KGN1cnJlbnRWYWx1ZSkpIGN1cnJlbnRWYWx1ZSA9IHF1ZXJ5W2tleV0gPSBbY3VycmVudFZhbHVlXTtcblx0XHRcdGN1cnJlbnRWYWx1ZS5wdXNoKHZhbHVlKTtcblx0XHR9IGVsc2UgcXVlcnlba2V5XSA9IHZhbHVlO1xuXHR9XG5cdHJldHVybiBxdWVyeTtcbn1cbi8qKlxuKiBTdHJpbmdpZmllcyBhIHtAbGluayBMb2NhdGlvblF1ZXJ5UmF3fSBvYmplY3QuIExpa2UgYFVSTFNlYXJjaFBhcmFtc2AsIGl0XG4qIGRvZXNuJ3QgcHJlcGVuZCBhIGA/YFxuKlxuKiBAaW50ZXJuYWxcbipcbiogQHBhcmFtIHF1ZXJ5IC0gcXVlcnkgb2JqZWN0IHRvIHN0cmluZ2lmeVxuKiBAcmV0dXJucyBzdHJpbmcgdmVyc2lvbiBvZiB0aGUgcXVlcnkgd2l0aG91dCB0aGUgbGVhZGluZyBgP2BcbiovXG5mdW5jdGlvbiBzdHJpbmdpZnlRdWVyeShxdWVyeSkge1xuXHRsZXQgc2VhcmNoID0gXCJcIjtcblx0Zm9yIChsZXQga2V5IGluIHF1ZXJ5KSB7XG5cdFx0Y29uc3QgdmFsdWUgPSBxdWVyeVtrZXldO1xuXHRcdGtleSA9IGVuY29kZVF1ZXJ5S2V5KGtleSk7XG5cdFx0aWYgKHZhbHVlID09IG51bGwpIHtcblx0XHRcdGlmICh2YWx1ZSAhPT0gdm9pZCAwKSBzZWFyY2ggKz0gKHNlYXJjaC5sZW5ndGggPyBcIiZcIiA6IFwiXCIpICsga2V5O1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdChpc0FycmF5KHZhbHVlKSA/IHZhbHVlLm1hcCgodikgPT4gdiAmJiBlbmNvZGVRdWVyeVZhbHVlKHYpKSA6IFt2YWx1ZSAmJiBlbmNvZGVRdWVyeVZhbHVlKHZhbHVlKV0pLmZvckVhY2goKHZhbHVlKSA9PiB7XG5cdFx0XHRpZiAodmFsdWUgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRzZWFyY2ggKz0gKHNlYXJjaC5sZW5ndGggPyBcIiZcIiA6IFwiXCIpICsga2V5O1xuXHRcdFx0XHRpZiAodmFsdWUgIT0gbnVsbCkgc2VhcmNoICs9IFwiPVwiICsgdmFsdWU7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHNlYXJjaDtcbn1cbi8qKlxuKiBUcmFuc2Zvcm1zIGEge0BsaW5rIExvY2F0aW9uUXVlcnlSYXd9IGludG8gYSB7QGxpbmsgTG9jYXRpb25RdWVyeX0gYnkgY2FzdGluZ1xuKiBudW1iZXJzIGludG8gc3RyaW5ncywgcmVtb3Zpbmcga2V5cyB3aXRoIGFuIHVuZGVmaW5lZCB2YWx1ZSBhbmQgcmVwbGFjaW5nXG4qIHVuZGVmaW5lZCB3aXRoIG51bGwgaW4gYXJyYXlzXG4qXG4qIEBwYXJhbSBxdWVyeSAtIHF1ZXJ5IG9iamVjdCB0byBub3JtYWxpemVcbiogQHJldHVybnMgYSBub3JtYWxpemVkIHF1ZXJ5IG9iamVjdFxuKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZVF1ZXJ5KHF1ZXJ5KSB7XG5cdGNvbnN0IG5vcm1hbGl6ZWRRdWVyeSA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBxdWVyeSkge1xuXHRcdGNvbnN0IHZhbHVlID0gcXVlcnlba2V5XTtcblx0XHRpZiAodmFsdWUgIT09IHZvaWQgMCkgbm9ybWFsaXplZFF1ZXJ5W2tleV0gPSBpc0FycmF5KHZhbHVlKSA/IHZhbHVlLm1hcCgodikgPT4gdiA9PSBudWxsID8gbnVsbCA6IFwiXCIgKyB2KSA6IHZhbHVlID09IG51bGwgPyB2YWx1ZSA6IFwiXCIgKyB2YWx1ZTtcblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFF1ZXJ5O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL2NhbGxiYWNrcy50c1xuLyoqXG4qIENyZWF0ZSBhIGxpc3Qgb2YgY2FsbGJhY2tzIHRoYXQgY2FuIGJlIHJlc2V0LiBVc2VkIHRvIGNyZWF0ZSBiZWZvcmUgYW5kIGFmdGVyIG5hdmlnYXRpb24gZ3VhcmRzIGxpc3RcbiovXG5mdW5jdGlvbiB1c2VDYWxsYmFja3MoKSB7XG5cdGxldCBoYW5kbGVycyA9IFtdO1xuXHRmdW5jdGlvbiBhZGQoaGFuZGxlcikge1xuXHRcdGhhbmRsZXJzLnB1c2goaGFuZGxlcik7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IGkgPSBoYW5kbGVycy5pbmRleE9mKGhhbmRsZXIpO1xuXHRcdFx0aWYgKGkgPiAtMSkgaGFuZGxlcnMuc3BsaWNlKGksIDEpO1xuXHRcdH07XG5cdH1cblx0ZnVuY3Rpb24gcmVzZXQoKSB7XG5cdFx0aGFuZGxlcnMgPSBbXTtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdGFkZCxcblx0XHRsaXN0OiAoKSA9PiBoYW5kbGVycy5zbGljZSgpLFxuXHRcdHJlc2V0XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbmF2aWdhdGlvbkd1YXJkcy50c1xuZnVuY3Rpb24gcmVnaXN0ZXJHdWFyZChhY3RpdmVSZWNvcmRSZWYsIG5hbWUsIGd1YXJkKSB7XG5cdGNvbnN0IHJlY29yZCA9IGFjdGl2ZVJlY29yZFJlZi52YWx1ZTtcblx0aWYgKCFyZWNvcmQpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB3YXJuJDEoYE5vIGFjdGl2ZSByb3V0ZSByZWNvcmQgd2FzIGZvdW5kIHdoZW4gY2FsbGluZyBcXGAke25hbWUgPT09IFwidXBkYXRlR3VhcmRzXCIgPyBcIm9uQmVmb3JlUm91dGVVcGRhdGVcIiA6IFwib25CZWZvcmVSb3V0ZUxlYXZlXCJ9KClcXGAuIE1ha2Ugc3VyZSB5b3UgY2FsbCB0aGlzIGZ1bmN0aW9uIGluc2lkZSBhIGNvbXBvbmVudCBjaGlsZCBvZiA8cm91dGVyLXZpZXc+LiBNYXliZSB5b3UgY2FsbGVkIGl0IGluc2lkZSBvZiBBcHAudnVlP2ApO1xuXHRcdHJldHVybjtcblx0fVxuXHRsZXQgY3VycmVudFJlY29yZCA9IHJlY29yZDtcblx0Y29uc3QgcmVtb3ZlRnJvbUxpc3QgPSAoKSA9PiB7XG5cdFx0Y3VycmVudFJlY29yZFtuYW1lXS5kZWxldGUoZ3VhcmQpO1xuXHR9O1xuXHRvblVubW91bnRlZChyZW1vdmVGcm9tTGlzdCk7XG5cdG9uRGVhY3RpdmF0ZWQocmVtb3ZlRnJvbUxpc3QpO1xuXHRvbkFjdGl2YXRlZCgoKSA9PiB7XG5cdFx0Y29uc3QgbmV3UmVjb3JkID0gYWN0aXZlUmVjb3JkUmVmLnZhbHVlO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIW5ld1JlY29yZCkgd2FybiQxKFwiTm8gYWN0aXZlIHJvdXRlIHJlY29yZCB3YXMgZm91bmQgd2hlbiByZWFjdGl2YXRpbmcgY29tcG9uZW50IHdpdGggbmF2aWdhdGlvbiBndWFyZC4gVGhpcyBpcyBsaWtlbHkgYSBidWcgaW4gdnVlLXJvdXRlci4gUGxlYXNlIHJlcG9ydCBpdC5cIik7XG5cdFx0aWYgKG5ld1JlY29yZCkgY3VycmVudFJlY29yZCA9IG5ld1JlY29yZDtcblx0XHRjdXJyZW50UmVjb3JkW25hbWVdLmFkZChndWFyZCk7XG5cdH0pO1xuXHRjdXJyZW50UmVjb3JkW25hbWVdLmFkZChndWFyZCk7XG59XG4vKipcbiogQWRkIGEgbmF2aWdhdGlvbiBndWFyZCB0aGF0IHRyaWdnZXJzIHdoZW5ldmVyIHRoZSBjb21wb25lbnQgZm9yIHRoZSBjdXJyZW50XG4qIGxvY2F0aW9uIGlzIGFib3V0IHRvIGJlIGxlZnQuIFNpbWlsYXIgdG8ge0BsaW5rIGJlZm9yZVJvdXRlTGVhdmV9IGJ1dCBjYW4gYmVcbiogdXNlZCBpbiBhbnkgY29tcG9uZW50LiBUaGUgZ3VhcmQgaXMgcmVtb3ZlZCB3aGVuIHRoZSBjb21wb25lbnQgaXMgdW5tb3VudGVkLlxuKlxuKiBAcGFyYW0gbGVhdmVHdWFyZCAtIHtAbGluayBOYXZpZ2F0aW9uR3VhcmR9XG4qL1xuZnVuY3Rpb24gb25CZWZvcmVSb3V0ZUxlYXZlKGxlYXZlR3VhcmQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhZ2V0Q3VycmVudEluc3RhbmNlKCkpIHtcblx0XHR3YXJuJDEoXCJnZXRDdXJyZW50SW5zdGFuY2UoKSByZXR1cm5lZCBudWxsLiBvbkJlZm9yZVJvdXRlTGVhdmUoKSBtdXN0IGJlIGNhbGxlZCBhdCB0aGUgdG9wIG9mIGEgc2V0dXAgZnVuY3Rpb25cIik7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJlZ2lzdGVyR3VhcmQoaW5qZWN0KG1hdGNoZWRSb3V0ZUtleSwge30pLCBcImxlYXZlR3VhcmRzXCIsIGxlYXZlR3VhcmQpO1xufVxuLyoqXG4qIEFkZCBhIG5hdmlnYXRpb24gZ3VhcmQgdGhhdCB0cmlnZ2VycyB3aGVuZXZlciB0aGUgY3VycmVudCBsb2NhdGlvbiBpcyBhYm91dFxuKiB0byBiZSB1cGRhdGVkLiBTaW1pbGFyIHRvIHtAbGluayBiZWZvcmVSb3V0ZVVwZGF0ZX0gYnV0IGNhbiBiZSB1c2VkIGluIGFueVxuKiBjb21wb25lbnQuIFRoZSBndWFyZCBpcyByZW1vdmVkIHdoZW4gdGhlIGNvbXBvbmVudCBpcyB1bm1vdW50ZWQuXG4qXG4qIEBwYXJhbSB1cGRhdGVHdWFyZCAtIHtAbGluayBOYXZpZ2F0aW9uR3VhcmR9XG4qL1xuZnVuY3Rpb24gb25CZWZvcmVSb3V0ZVVwZGF0ZSh1cGRhdGVHdWFyZCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFnZXRDdXJyZW50SW5zdGFuY2UoKSkge1xuXHRcdHdhcm4kMShcImdldEN1cnJlbnRJbnN0YW5jZSgpIHJldHVybmVkIG51bGwuIG9uQmVmb3JlUm91dGVVcGRhdGUoKSBtdXN0IGJlIGNhbGxlZCBhdCB0aGUgdG9wIG9mIGEgc2V0dXAgZnVuY3Rpb25cIik7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJlZ2lzdGVyR3VhcmQoaW5qZWN0KG1hdGNoZWRSb3V0ZUtleSwge30pLCBcInVwZGF0ZUd1YXJkc1wiLCB1cGRhdGVHdWFyZCk7XG59XG5mdW5jdGlvbiBndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSwgcmVjb3JkLCBuYW1lLCBydW5XaXRoQ29udGV4dCA9IChmbikgPT4gZm4oKSkge1xuXHRjb25zdCBlbnRlckNhbGxiYWNrQXJyYXkgPSByZWNvcmQgJiYgKHJlY29yZC5lbnRlckNhbGxiYWNrc1tuYW1lXSA9IHJlY29yZC5lbnRlckNhbGxiYWNrc1tuYW1lXSB8fCBbXSk7XG5cdHJldHVybiAoKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgbmV4dCA9ICh2YWxpZCkgPT4ge1xuXHRcdFx0aWYgKHZhbGlkID09PSBmYWxzZSkgcmVqZWN0KGNyZWF0ZVJvdXRlckVycm9yKDQsIHtcblx0XHRcdFx0ZnJvbSxcblx0XHRcdFx0dG9cblx0XHRcdH0pKTtcblx0XHRcdGVsc2UgaWYgKHZhbGlkIGluc3RhbmNlb2YgRXJyb3IpIHJlamVjdCh2YWxpZCk7XG5cdFx0XHRlbHNlIGlmIChpc1JvdXRlTG9jYXRpb24odmFsaWQpKSByZWplY3QoY3JlYXRlUm91dGVyRXJyb3IoMiwge1xuXHRcdFx0XHRmcm9tOiB0byxcblx0XHRcdFx0dG86IHZhbGlkXG5cdFx0XHR9KSk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0aWYgKGVudGVyQ2FsbGJhY2tBcnJheSAmJiByZWNvcmQuZW50ZXJDYWxsYmFja3NbbmFtZV0gPT09IGVudGVyQ2FsbGJhY2tBcnJheSAmJiB0eXBlb2YgdmFsaWQgPT09IFwiZnVuY3Rpb25cIikgZW50ZXJDYWxsYmFja0FycmF5LnB1c2godmFsaWQpO1xuXHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRjb25zdCBndWFyZFJldHVybiA9IHJ1bldpdGhDb250ZXh0KCgpID0+IGd1YXJkLmNhbGwocmVjb3JkICYmIHJlY29yZC5pbnN0YW5jZXNbbmFtZV0sIHRvLCBmcm9tLCBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3aXRoRGVwcmVjYXRpb25XYXJuaW5nKGNhbk9ubHlCZUNhbGxlZE9uY2UobmV4dCwgdG8sIGZyb20pKSA6IG5leHQpKTtcblx0XHRsZXQgZ3VhcmRDYWxsID0gUHJvbWlzZS5yZXNvbHZlKGd1YXJkUmV0dXJuKTtcblx0XHRpZiAoZ3VhcmQubGVuZ3RoIDwgMykgZ3VhcmRDYWxsID0gZ3VhcmRDYWxsLnRoZW4obmV4dCk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBndWFyZC5sZW5ndGggPiAyKSB7XG5cdFx0XHRjb25zdCBtZXNzYWdlID0gYFRoZSBcIm5leHRcIiBjYWxsYmFjayB3YXMgbmV2ZXIgY2FsbGVkIGluc2lkZSBvZiAke2d1YXJkLm5hbWUgPyBcIlxcXCJcIiArIGd1YXJkLm5hbWUgKyBcIlxcXCJcIiA6IFwiXCJ9OlxcbiR7Z3VhcmQudG9TdHJpbmcoKX1cXG4uIElmIHlvdSBhcmUgcmV0dXJuaW5nIGEgdmFsdWUgaW5zdGVhZCBvZiBjYWxsaW5nIFwibmV4dFwiLCBtYWtlIHN1cmUgdG8gcmVtb3ZlIHRoZSBcIm5leHRcIiBwYXJhbWV0ZXIgZnJvbSB5b3VyIGZ1bmN0aW9uLmA7XG5cdFx0XHRpZiAodHlwZW9mIGd1YXJkUmV0dXJuID09PSBcIm9iamVjdFwiICYmIFwidGhlblwiIGluIGd1YXJkUmV0dXJuKSBndWFyZENhbGwgPSBndWFyZENhbGwudGhlbigocmVzb2x2ZWRWYWx1ZSkgPT4ge1xuXHRcdFx0XHRpZiAoIW5leHQuX2NhbGxlZCkge1xuXHRcdFx0XHRcdHdhcm4kMShtZXNzYWdlKTtcblx0XHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkludmFsaWQgbmF2aWdhdGlvbiBndWFyZFwiKSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHJlc29sdmVkVmFsdWU7XG5cdFx0XHR9KTtcblx0XHRcdGVsc2UgaWYgKGd1YXJkUmV0dXJuICE9PSB2b2lkIDApIHtcblx0XHRcdFx0aWYgKCFuZXh0Ll9jYWxsZWQpIHtcblx0XHRcdFx0XHR3YXJuJDEobWVzc2FnZSk7XG5cdFx0XHRcdFx0cmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJJbnZhbGlkIG5hdmlnYXRpb24gZ3VhcmRcIikpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0XHRndWFyZENhbGwuY2F0Y2goKGVycikgPT4gcmVqZWN0KGVycikpO1xuXHR9KTtcbn1cbi8qKlxuKiBXcmFwcyB0aGUgbmV4dCBjYWxsYmFjayB0byB3YXJuIHdoZW4gaXQgaXMgdXNlZC4gRGV2LW9ubHk6IHdoZW4gX19ERVZfXyBpc1xuKiBmYWxzZSAocHJvZHVjdGlvbiBidWlsZHMpLCB0aGlzIGJyYW5jaCBpcyBkZWFkIGNvZGUgYW5kIGlzIHN0cmlwcGVkIGZyb20gdGhlXG4qIGJ1bmRsZS5cbipcbiogQGludGVybmFsXG4qL1xuZnVuY3Rpb24gd2l0aERlcHJlY2F0aW9uV2FybmluZyhuZXh0KSB7XG5cdGxldCB3YXJuZWQgPSBmYWxzZTtcblx0cmV0dXJuIGZ1bmN0aW9uKCkge1xuXHRcdGlmICghd2FybmVkKSB7XG5cdFx0XHR3YXJuZWQgPSB0cnVlO1xuXHRcdFx0d2FybiQxKFwiVGhlIGBuZXh0KClgIGNhbGxiYWNrIGluIG5hdmlnYXRpb24gZ3VhcmRzIGlzIGRlcHJlY2F0ZWQuIFJldHVybiB0aGUgdmFsdWUgaW5zdGVhZCBvZiBjYWxsaW5nIGBuZXh0KHZhbHVlKWAuXCIpO1xuXHRcdH1cblx0XHRyZXR1cm4gbmV4dC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXHR9O1xufVxuZnVuY3Rpb24gY2FuT25seUJlQ2FsbGVkT25jZShuZXh0LCB0bywgZnJvbSkge1xuXHRsZXQgY2FsbGVkID0gMDtcblx0cmV0dXJuIGZ1bmN0aW9uKCkge1xuXHRcdGlmIChjYWxsZWQrKyA9PT0gMSkgd2FybiQxKGBUaGUgXCJuZXh0XCIgY2FsbGJhY2sgd2FzIGNhbGxlZCBtb3JlIHRoYW4gb25jZSBpbiBvbmUgbmF2aWdhdGlvbiBndWFyZCB3aGVuIGdvaW5nIGZyb20gXCIke2Zyb20uZnVsbFBhdGh9XCIgdG8gXCIke3RvLmZ1bGxQYXRofVwiLiBJdCBzaG91bGQgYmUgY2FsbGVkIGV4YWN0bHkgb25lIHRpbWUgaW4gZWFjaCBuYXZpZ2F0aW9uIGd1YXJkLiBUaGlzIHdpbGwgZmFpbCBpbiBwcm9kdWN0aW9uLmApO1xuXHRcdG5leHQuX2NhbGxlZCA9IHRydWU7XG5cdFx0aWYgKGNhbGxlZCA9PT0gMSkgbmV4dC5hcHBseShudWxsLCBhcmd1bWVudHMpO1xuXHR9O1xufVxuZnVuY3Rpb24gZXh0cmFjdENvbXBvbmVudHNHdWFyZHMobWF0Y2hlZCwgZ3VhcmRUeXBlLCB0bywgZnJvbSwgcnVuV2l0aENvbnRleHQgPSAoZm4pID0+IGZuKCkpIHtcblx0Y29uc3QgZ3VhcmRzID0gW107XG5cdGZvciAoY29uc3QgcmVjb3JkIG9mIG1hdGNoZWQpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFyZWNvcmQuY29tcG9uZW50cyAmJiByZWNvcmQuY2hpbGRyZW4gJiYgIXJlY29yZC5jaGlsZHJlbi5sZW5ndGgpIHdhcm4kMShgUmVjb3JkIHdpdGggcGF0aCBcIiR7cmVjb3JkLnBhdGh9XCIgaXMgZWl0aGVyIG1pc3NpbmcgYSBcImNvbXBvbmVudChzKVwiIG9yIFwiY2hpbGRyZW5cIiBwcm9wZXJ0eS5gKTtcblx0XHRmb3IgKGNvbnN0IG5hbWUgaW4gcmVjb3JkLmNvbXBvbmVudHMpIHtcblx0XHRcdGxldCByYXdDb21wb25lbnQgPSByZWNvcmQuY29tcG9uZW50c1tuYW1lXTtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKCFyYXdDb21wb25lbnQgfHwgdHlwZW9mIHJhd0NvbXBvbmVudCAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgcmF3Q29tcG9uZW50ICE9PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0XHR3YXJuJDEoYENvbXBvbmVudCBcIiR7bmFtZX1cIiBpbiByZWNvcmQgd2l0aCBwYXRoIFwiJHtyZWNvcmQucGF0aH1cIiBpcyBub3QgYSB2YWxpZCBjb21wb25lbnQuIFJlY2VpdmVkIFwiJHtTdHJpbmcocmF3Q29tcG9uZW50KX1cIi5gKTtcblx0XHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHJvdXRlIGNvbXBvbmVudFwiKTtcblx0XHRcdFx0fSBlbHNlIGlmIChcInRoZW5cIiBpbiByYXdDb21wb25lbnQpIHtcblx0XHRcdFx0XHR3YXJuJDEoYENvbXBvbmVudCBcIiR7bmFtZX1cIiBpbiByZWNvcmQgd2l0aCBwYXRoIFwiJHtyZWNvcmQucGF0aH1cIiBpcyBhIFByb21pc2UgaW5zdGVhZCBvZiBhIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UuIERpZCB5b3Ugd3JpdGUgXCJpbXBvcnQoJy4vTXlQYWdlLnZ1ZScpXCIgaW5zdGVhZCBvZiBcIigpID0+IGltcG9ydCgnLi9NeVBhZ2UudnVlJylcIiA/IFRoaXMgd2lsbCBicmVhayBpbiBwcm9kdWN0aW9uIGlmIG5vdCBmaXhlZC5gKTtcblx0XHRcdFx0XHRjb25zdCBwcm9taXNlID0gcmF3Q29tcG9uZW50O1xuXHRcdFx0XHRcdHJhd0NvbXBvbmVudCA9ICgpID0+IHByb21pc2U7XG5cdFx0XHRcdH0gZWxzZSBpZiAocmF3Q29tcG9uZW50Ll9fYXN5bmNMb2FkZXIgJiYgIXJhd0NvbXBvbmVudC5fX3dhcm5lZERlZmluZUFzeW5jKSB7XG5cdFx0XHRcdFx0cmF3Q29tcG9uZW50Ll9fd2FybmVkRGVmaW5lQXN5bmMgPSB0cnVlO1xuXHRcdFx0XHRcdHdhcm4kMShgQ29tcG9uZW50IFwiJHtuYW1lfVwiIGluIHJlY29yZCB3aXRoIHBhdGggXCIke3JlY29yZC5wYXRofVwiIGlzIGRlZmluZWQgdXNpbmcgXCJkZWZpbmVBc3luY0NvbXBvbmVudCgpXCIuIFdyaXRlIFwiKCkgPT4gaW1wb3J0KCcuL015UGFnZS52dWUnKVwiIGluc3RlYWQgb2YgXCJkZWZpbmVBc3luY0NvbXBvbmVudCgoKSA9PiBpbXBvcnQoJy4vTXlQYWdlLnZ1ZScpKVwiLmApO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoZ3VhcmRUeXBlICE9PSBcImJlZm9yZVJvdXRlRW50ZXJcIiAmJiAhcmVjb3JkLmluc3RhbmNlc1tuYW1lXSkgY29udGludWU7XG5cdFx0XHRpZiAoaXNSb3V0ZUNvbXBvbmVudChyYXdDb21wb25lbnQpKSB7XG5cdFx0XHRcdGNvbnN0IGd1YXJkID0gKHJhd0NvbXBvbmVudC5fX3ZjY09wdHMgfHwgcmF3Q29tcG9uZW50KVtndWFyZFR5cGVdO1xuXHRcdFx0XHRndWFyZCAmJiBndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSwgcmVjb3JkLCBuYW1lLCBydW5XaXRoQ29udGV4dCkpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bGV0IGNvbXBvbmVudFByb21pc2UgPSByYXdDb21wb25lbnQoKTtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhKFwiY2F0Y2hcIiBpbiBjb21wb25lbnRQcm9taXNlKSkge1xuXHRcdFx0XHRcdHdhcm4kMShgQ29tcG9uZW50IFwiJHtuYW1lfVwiIGluIHJlY29yZCB3aXRoIHBhdGggXCIke3JlY29yZC5wYXRofVwiIGlzIGEgZnVuY3Rpb24gdGhhdCBkb2VzIG5vdCByZXR1cm4gYSBQcm9taXNlLiBJZiB5b3Ugd2VyZSBwYXNzaW5nIGEgZnVuY3Rpb25hbCBjb21wb25lbnQsIG1ha2Ugc3VyZSB0byBhZGQgYSBcImRpc3BsYXlOYW1lXCIgdG8gdGhlIGNvbXBvbmVudC4gVGhpcyB3aWxsIGJyZWFrIGluIHByb2R1Y3Rpb24gaWYgbm90IGZpeGVkLmApO1xuXHRcdFx0XHRcdGNvbXBvbmVudFByb21pc2UgPSBQcm9taXNlLnJlc29sdmUoY29tcG9uZW50UHJvbWlzZSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0Z3VhcmRzLnB1c2goKCkgPT4gY29tcG9uZW50UHJvbWlzZS50aGVuKChyZXNvbHZlZCkgPT4ge1xuXHRcdFx0XHRcdGlmICghcmVzb2x2ZWQpIHRocm93IG5ldyBFcnJvcihgQ291bGRuJ3QgcmVzb2x2ZSBjb21wb25lbnQgXCIke25hbWV9XCIgYXQgXCIke3JlY29yZC5wYXRofVwiYCk7XG5cdFx0XHRcdFx0Y29uc3QgcmVzb2x2ZWRDb21wb25lbnQgPSBpc0VTTW9kdWxlKHJlc29sdmVkKSA/IHJlc29sdmVkLmRlZmF1bHQgOiByZXNvbHZlZDtcblx0XHRcdFx0XHRyZWNvcmQubW9kc1tuYW1lXSA9IHJlc29sdmVkO1xuXHRcdFx0XHRcdHJlY29yZC5jb21wb25lbnRzW25hbWVdID0gcmVzb2x2ZWRDb21wb25lbnQ7XG5cdFx0XHRcdFx0Y29uc3QgZ3VhcmQgPSAocmVzb2x2ZWRDb21wb25lbnQuX192Y2NPcHRzIHx8IHJlc29sdmVkQ29tcG9uZW50KVtndWFyZFR5cGVdO1xuXHRcdFx0XHRcdHJldHVybiBndWFyZCAmJiBndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSwgcmVjb3JkLCBuYW1lLCBydW5XaXRoQ29udGV4dCkoKTtcblx0XHRcdFx0fSkpO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRyZXR1cm4gZ3VhcmRzO1xufVxuLyoqXG4qIEVuc3VyZXMgYSByb3V0ZSBpcyBsb2FkZWQsIHNvIGl0IGNhbiBiZSBwYXNzZWQgYXMgbyBwcm9wIHRvIGA8Um91dGVyVmlldz5gLlxuKlxuKiBAcGFyYW0gcm91dGUgLSByZXNvbHZlZCByb3V0ZSB0byBsb2FkXG4qL1xuZnVuY3Rpb24gbG9hZFJvdXRlTG9jYXRpb24ocm91dGUpIHtcblx0cmV0dXJuIHJvdXRlLm1hdGNoZWQuZXZlcnkoKHJlY29yZCkgPT4gcmVjb3JkLnJlZGlyZWN0KSA/IFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJDYW5ub3QgbG9hZCBhIHJvdXRlIHRoYXQgcmVkaXJlY3RzLlwiKSkgOiBQcm9taXNlLmFsbChyb3V0ZS5tYXRjaGVkLm1hcCgocmVjb3JkKSA9PiByZWNvcmQuY29tcG9uZW50cyAmJiBQcm9taXNlLmFsbChPYmplY3Qua2V5cyhyZWNvcmQuY29tcG9uZW50cykucmVkdWNlKChwcm9taXNlcywgbmFtZSkgPT4ge1xuXHRcdGNvbnN0IHJhd0NvbXBvbmVudCA9IHJlY29yZC5jb21wb25lbnRzW25hbWVdO1xuXHRcdGlmICh0eXBlb2YgcmF3Q29tcG9uZW50ID09PSBcImZ1bmN0aW9uXCIgJiYgIShcImRpc3BsYXlOYW1lXCIgaW4gcmF3Q29tcG9uZW50KSkgcHJvbWlzZXMucHVzaChyYXdDb21wb25lbnQoKS50aGVuKChyZXNvbHZlZCkgPT4ge1xuXHRcdFx0aWYgKCFyZXNvbHZlZCkgcmV0dXJuIFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoYENvdWxkbid0IHJlc29sdmUgY29tcG9uZW50IFwiJHtuYW1lfVwiIGF0IFwiJHtyZWNvcmQucGF0aH1cIi4gRW5zdXJlIHlvdSBwYXNzZWQgYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBwcm9taXNlLmApKTtcblx0XHRcdGNvbnN0IHJlc29sdmVkQ29tcG9uZW50ID0gaXNFU01vZHVsZShyZXNvbHZlZCkgPyByZXNvbHZlZC5kZWZhdWx0IDogcmVzb2x2ZWQ7XG5cdFx0XHRyZWNvcmQubW9kc1tuYW1lXSA9IHJlc29sdmVkO1xuXHRcdFx0cmVjb3JkLmNvbXBvbmVudHNbbmFtZV0gPSByZXNvbHZlZENvbXBvbmVudDtcblx0XHR9KSk7XG5cdFx0cmV0dXJuIHByb21pc2VzO1xuXHR9LCBbXSkpKSkudGhlbigoKSA9PiByb3V0ZSk7XG59XG4vKipcbiogU3BsaXQgdGhlIGxlYXZpbmcsIHVwZGF0aW5nLCBhbmQgZW50ZXJpbmcgcmVjb3Jkcy5cbiogQGludGVybmFsXG4qXG4qIEBwYXJhbSAgdG8gLSBMb2NhdGlvbiB3ZSBhcmUgbmF2aWdhdGluZyB0b1xuKiBAcGFyYW0gZnJvbSAtIExvY2F0aW9uIHdlIGFyZSBuYXZpZ2F0aW5nIGZyb21cbiovXG5mdW5jdGlvbiBleHRyYWN0Q2hhbmdpbmdSZWNvcmRzKHRvLCBmcm9tKSB7XG5cdGNvbnN0IGxlYXZpbmdSZWNvcmRzID0gW107XG5cdGNvbnN0IHVwZGF0aW5nUmVjb3JkcyA9IFtdO1xuXHRjb25zdCBlbnRlcmluZ1JlY29yZHMgPSBbXTtcblx0Y29uc3QgbGVuID0gTWF0aC5tYXgoZnJvbS5tYXRjaGVkLmxlbmd0aCwgdG8ubWF0Y2hlZC5sZW5ndGgpO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3QgcmVjb3JkRnJvbSA9IGZyb20ubWF0Y2hlZFtpXTtcblx0XHRpZiAocmVjb3JkRnJvbSkgaWYgKHRvLm1hdGNoZWQuZmluZCgocmVjb3JkKSA9PiBpc1NhbWVSb3V0ZVJlY29yZChyZWNvcmQsIHJlY29yZEZyb20pKSkgdXBkYXRpbmdSZWNvcmRzLnB1c2gocmVjb3JkRnJvbSk7XG5cdFx0ZWxzZSBsZWF2aW5nUmVjb3Jkcy5wdXNoKHJlY29yZEZyb20pO1xuXHRcdGNvbnN0IHJlY29yZFRvID0gdG8ubWF0Y2hlZFtpXTtcblx0XHRpZiAocmVjb3JkVG8pIHtcblx0XHRcdGlmICghZnJvbS5tYXRjaGVkLmZpbmQoKHJlY29yZCkgPT4gaXNTYW1lUm91dGVSZWNvcmQocmVjb3JkLCByZWNvcmRUbykpKSBlbnRlcmluZ1JlY29yZHMucHVzaChyZWNvcmRUbyk7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBbXG5cdFx0bGVhdmluZ1JlY29yZHMsXG5cdFx0dXBkYXRpbmdSZWNvcmRzLFxuXHRcdGVudGVyaW5nUmVjb3Jkc1xuXHRdO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2RldnRvb2xzLnRzXG4vKipcbiogQ29waWVzIGEgcm91dGUgbG9jYXRpb24gYW5kIHJlbW92ZXMgYW55IHByb2JsZW1hdGljIHByb3BlcnRpZXMgdGhhdCBjYW5ub3QgYmUgc2hvd24gaW4gZGV2dG9vbHMgKGUuZy4gVnVlIGluc3RhbmNlcykuXG4qXG4qIEBwYXJhbSByb3V0ZUxvY2F0aW9uIC0gcm91dGVMb2NhdGlvbiB0byBmb3JtYXRcbiogQHBhcmFtIHRvb2x0aXAgLSBvcHRpb25hbCB0b29sdGlwXG4qIEByZXR1cm5zIGEgY29weSBvZiB0aGUgcm91dGVMb2NhdGlvblxuKi9cbmZ1bmN0aW9uIGZvcm1hdFJvdXRlTG9jYXRpb24ocm91dGVMb2NhdGlvbiwgdG9vbHRpcCkge1xuXHRjb25zdCBjb3B5ID0gYXNzaWduKHt9LCByb3V0ZUxvY2F0aW9uLCB7IG1hdGNoZWQ6IHJvdXRlTG9jYXRpb24ubWF0Y2hlZC5tYXAoKG1hdGNoZWQpID0+IG9taXQobWF0Y2hlZCwgW1xuXHRcdFwiaW5zdGFuY2VzXCIsXG5cdFx0XCJjaGlsZHJlblwiLFxuXHRcdFwiYWxpYXNPZlwiXG5cdF0pKSB9KTtcblx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdHR5cGU6IG51bGwsXG5cdFx0cmVhZE9ubHk6IHRydWUsXG5cdFx0ZGlzcGxheTogcm91dGVMb2NhdGlvbi5mdWxsUGF0aCxcblx0XHR0b29sdGlwLFxuXHRcdHZhbHVlOiBjb3B5XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGZvcm1hdERpc3BsYXkoZGlzcGxheSkge1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7IGRpc3BsYXkgfSB9O1xufVxubGV0IHJvdXRlcklkID0gMDtcbmZ1bmN0aW9uIGFkZERldnRvb2xzKGFwcCwgcm91dGVyLCBtYXRjaGVyKSB7XG5cdGlmIChyb3V0ZXIuX19oYXNEZXZ0b29scykgcmV0dXJuO1xuXHRyb3V0ZXIuX19oYXNEZXZ0b29scyA9IHRydWU7XG5cdGNvbnN0IGlkID0gcm91dGVySWQrKztcblx0c2V0dXBEZXZ0b29sc1BsdWdpbih7XG5cdFx0aWQ6IFwib3JnLnZ1ZWpzLnJvdXRlclwiICsgKGlkID8gXCIuXCIgKyBpZCA6IFwiXCIpLFxuXHRcdGxhYmVsOiBcIlZ1ZSBSb3V0ZXJcIixcblx0XHRwYWNrYWdlTmFtZTogXCJ2dWUtcm91dGVyXCIsXG5cdFx0aG9tZXBhZ2U6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnXCIsXG5cdFx0bG9nbzogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvbG9nby5wbmdcIixcblx0XHRjb21wb25lbnRTdGF0ZVR5cGVzOiBbXCJSb3V0aW5nXCJdLFxuXHRcdGFwcFxuXHR9LCAoYXBpKSA9PiB7XG5cdFx0YXBpLm9uLmluc3BlY3RDb21wb25lbnQoKHBheWxvYWQpID0+IHtcblx0XHRcdGlmIChwYXlsb2FkLmluc3RhbmNlRGF0YSkgcGF5bG9hZC5pbnN0YW5jZURhdGEuc3RhdGUucHVzaCh7XG5cdFx0XHRcdHR5cGU6IFwiUm91dGluZ1wiLFxuXHRcdFx0XHRrZXk6IFwiJHJvdXRlXCIsXG5cdFx0XHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRcdFx0dmFsdWU6IGZvcm1hdFJvdXRlTG9jYXRpb24ocm91dGVyLmN1cnJlbnRSb3V0ZS52YWx1ZSwgXCJDdXJyZW50IFJvdXRlXCIpXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRhcGkub24udmlzaXRDb21wb25lbnRUcmVlKCh7IHRyZWVOb2RlOiBub2RlLCBjb21wb25lbnRJbnN0YW5jZSB9KSA9PiB7XG5cdFx0XHRpZiAoY29tcG9uZW50SW5zdGFuY2UuX192cnZfZGV2dG9vbHMpIHtcblx0XHRcdFx0Y29uc3QgaW5mbyA9IGNvbXBvbmVudEluc3RhbmNlLl9fdnJ2X2RldnRvb2xzO1xuXHRcdFx0XHRub2RlLnRhZ3MucHVzaCh7XG5cdFx0XHRcdFx0bGFiZWw6IChpbmZvLm5hbWUgPyBgJHtpbmZvLm5hbWUudG9TdHJpbmcoKX06IGAgOiBcIlwiKSArIGluZm8ucGF0aCxcblx0XHRcdFx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0XHRcdFx0dG9vbHRpcDogXCJUaGlzIGNvbXBvbmVudCBpcyByZW5kZXJlZCBieSAmbHQ7cm91dGVyLXZpZXcmZ3Q7XCIsXG5cdFx0XHRcdFx0YmFja2dyb3VuZENvbG9yOiBQSU5LXzUwMFxuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdGlmIChpc0FycmF5KGNvbXBvbmVudEluc3RhbmNlLl9fdnJsX2RldnRvb2xzKSkge1xuXHRcdFx0XHRjb21wb25lbnRJbnN0YW5jZS5fX2RldnRvb2xzQXBpID0gYXBpO1xuXHRcdFx0XHRjb21wb25lbnRJbnN0YW5jZS5fX3ZybF9kZXZ0b29scy5mb3JFYWNoKChkZXZ0b29sc0RhdGEpID0+IHtcblx0XHRcdFx0XHRsZXQgbGFiZWwgPSBkZXZ0b29sc0RhdGEucm91dGUucGF0aDtcblx0XHRcdFx0XHRsZXQgYmFja2dyb3VuZENvbG9yID0gT1JBTkdFXzQwMDtcblx0XHRcdFx0XHRsZXQgdG9vbHRpcCA9IFwiXCI7XG5cdFx0XHRcdFx0bGV0IHRleHRDb2xvciA9IDA7XG5cdFx0XHRcdFx0aWYgKGRldnRvb2xzRGF0YS5lcnJvcikge1xuXHRcdFx0XHRcdFx0bGFiZWwgPSBkZXZ0b29sc0RhdGEuZXJyb3I7XG5cdFx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3IgPSBSRURfMTAwO1xuXHRcdFx0XHRcdFx0dGV4dENvbG9yID0gUkVEXzcwMDtcblx0XHRcdFx0XHR9IGVsc2UgaWYgKGRldnRvb2xzRGF0YS5pc0V4YWN0QWN0aXZlKSB7XG5cdFx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3IgPSBMSU1FXzUwMDtcblx0XHRcdFx0XHRcdHRvb2x0aXAgPSBcIlRoaXMgaXMgZXhhY3RseSBhY3RpdmVcIjtcblx0XHRcdFx0XHR9IGVsc2UgaWYgKGRldnRvb2xzRGF0YS5pc0FjdGl2ZSkge1xuXHRcdFx0XHRcdFx0YmFja2dyb3VuZENvbG9yID0gQkxVRV82MDA7XG5cdFx0XHRcdFx0XHR0b29sdGlwID0gXCJUaGlzIGxpbmsgaXMgYWN0aXZlXCI7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdG5vZGUudGFncy5wdXNoKHtcblx0XHRcdFx0XHRcdGxhYmVsLFxuXHRcdFx0XHRcdFx0dGV4dENvbG9yLFxuXHRcdFx0XHRcdFx0dG9vbHRpcCxcblx0XHRcdFx0XHRcdGJhY2tncm91bmRDb2xvclxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHR9KTtcblx0XHR3YXRjaChyb3V0ZXIuY3VycmVudFJvdXRlLCAoKSA9PiB7XG5cdFx0XHRyZWZyZXNoUm91dGVzVmlldygpO1xuXHRcdFx0YXBpLm5vdGlmeUNvbXBvbmVudFVwZGF0ZSgpO1xuXHRcdFx0YXBpLnNlbmRJbnNwZWN0b3JUcmVlKHJvdXRlckluc3BlY3RvcklkKTtcblx0XHRcdGFwaS5zZW5kSW5zcGVjdG9yU3RhdGUocm91dGVySW5zcGVjdG9ySWQpO1xuXHRcdH0pO1xuXHRcdGNvbnN0IG5hdmlnYXRpb25zTGF5ZXJJZCA9IFwicm91dGVyOm5hdmlnYXRpb25zOlwiICsgaWQ7XG5cdFx0YXBpLmFkZFRpbWVsaW5lTGF5ZXIoe1xuXHRcdFx0aWQ6IG5hdmlnYXRpb25zTGF5ZXJJZCxcblx0XHRcdGxhYmVsOiBgUm91dGVyJHtpZCA/IFwiIFwiICsgaWQgOiBcIlwifSBOYXZpZ2F0aW9uc2AsXG5cdFx0XHRjb2xvcjogNDIzNzUwOFxuXHRcdH0pO1xuXHRcdHJvdXRlci5vbkVycm9yKChlcnJvciwgdG8pID0+IHtcblx0XHRcdGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRcdFx0bGF5ZXJJZDogbmF2aWdhdGlvbnNMYXllcklkLFxuXHRcdFx0XHRldmVudDoge1xuXHRcdFx0XHRcdHRpdGxlOiBcIkVycm9yIGR1cmluZyBOYXZpZ2F0aW9uXCIsXG5cdFx0XHRcdFx0c3VidGl0bGU6IHRvLmZ1bGxQYXRoLFxuXHRcdFx0XHRcdGxvZ1R5cGU6IFwiZXJyb3JcIixcblx0XHRcdFx0XHR0aW1lOiBhcGkubm93KCksXG5cdFx0XHRcdFx0ZGF0YTogeyBlcnJvciB9LFxuXHRcdFx0XHRcdGdyb3VwSWQ6IHRvLm1ldGEuX19uYXZpZ2F0aW9uSWRcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0bGV0IG5hdmlnYXRpb25JZCA9IDA7XG5cdFx0cm91dGVyLmJlZm9yZUVhY2goKHRvLCBmcm9tKSA9PiB7XG5cdFx0XHRjb25zdCBkYXRhID0ge1xuXHRcdFx0XHRndWFyZDogZm9ybWF0RGlzcGxheShcImJlZm9yZUVhY2hcIiksXG5cdFx0XHRcdGZyb206IGZvcm1hdFJvdXRlTG9jYXRpb24oZnJvbSwgXCJDdXJyZW50IExvY2F0aW9uIGR1cmluZyB0aGlzIG5hdmlnYXRpb25cIiksXG5cdFx0XHRcdHRvOiBmb3JtYXRSb3V0ZUxvY2F0aW9uKHRvLCBcIlRhcmdldCBsb2NhdGlvblwiKVxuXHRcdFx0fTtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0by5tZXRhLCBcIl9fbmF2aWdhdGlvbklkXCIsIHsgdmFsdWU6IG5hdmlnYXRpb25JZCsrIH0pO1xuXHRcdFx0YXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdFx0XHRsYXllcklkOiBuYXZpZ2F0aW9uc0xheWVySWQsXG5cdFx0XHRcdGV2ZW50OiB7XG5cdFx0XHRcdFx0dGltZTogYXBpLm5vdygpLFxuXHRcdFx0XHRcdHRpdGxlOiBcIlN0YXJ0IG9mIG5hdmlnYXRpb25cIixcblx0XHRcdFx0XHRzdWJ0aXRsZTogdG8uZnVsbFBhdGgsXG5cdFx0XHRcdFx0ZGF0YSxcblx0XHRcdFx0XHRncm91cElkOiB0by5tZXRhLl9fbmF2aWdhdGlvbklkXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJvdXRlci5hZnRlckVhY2goKHRvLCBmcm9tLCBmYWlsdXJlKSA9PiB7XG5cdFx0XHRjb25zdCBkYXRhID0geyBndWFyZDogZm9ybWF0RGlzcGxheShcImFmdGVyRWFjaFwiKSB9O1xuXHRcdFx0aWYgKGZhaWx1cmUpIHtcblx0XHRcdFx0ZGF0YS5mYWlsdXJlID0geyBfY3VzdG9tOiB7XG5cdFx0XHRcdFx0dHlwZTogRXJyb3IsXG5cdFx0XHRcdFx0cmVhZE9ubHk6IHRydWUsXG5cdFx0XHRcdFx0ZGlzcGxheTogZmFpbHVyZSA/IGZhaWx1cmUubWVzc2FnZSA6IFwiXCIsXG5cdFx0XHRcdFx0dG9vbHRpcDogXCJOYXZpZ2F0aW9uIEZhaWx1cmVcIixcblx0XHRcdFx0XHR2YWx1ZTogZmFpbHVyZVxuXHRcdFx0XHR9IH07XG5cdFx0XHRcdGRhdGEuc3RhdHVzID0gZm9ybWF0RGlzcGxheShcIuKdjFwiKTtcblx0XHRcdH0gZWxzZSBkYXRhLnN0YXR1cyA9IGZvcm1hdERpc3BsYXkoXCLinIVcIik7XG5cdFx0XHRkYXRhLmZyb20gPSBmb3JtYXRSb3V0ZUxvY2F0aW9uKGZyb20sIFwiQ3VycmVudCBMb2NhdGlvbiBkdXJpbmcgdGhpcyBuYXZpZ2F0aW9uXCIpO1xuXHRcdFx0ZGF0YS50byA9IGZvcm1hdFJvdXRlTG9jYXRpb24odG8sIFwiVGFyZ2V0IGxvY2F0aW9uXCIpO1xuXHRcdFx0YXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdFx0XHRsYXllcklkOiBuYXZpZ2F0aW9uc0xheWVySWQsXG5cdFx0XHRcdGV2ZW50OiB7XG5cdFx0XHRcdFx0dGl0bGU6IFwiRW5kIG9mIG5hdmlnYXRpb25cIixcblx0XHRcdFx0XHRzdWJ0aXRsZTogdG8uZnVsbFBhdGgsXG5cdFx0XHRcdFx0dGltZTogYXBpLm5vdygpLFxuXHRcdFx0XHRcdGRhdGEsXG5cdFx0XHRcdFx0bG9nVHlwZTogZmFpbHVyZSA/IFwid2FybmluZ1wiIDogXCJkZWZhdWx0XCIsXG5cdFx0XHRcdFx0Z3JvdXBJZDogdG8ubWV0YS5fX25hdmlnYXRpb25JZFxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHQvKipcblx0XHQqIEluc3BlY3RvciBvZiBFeGlzdGluZyByb3V0ZXNcblx0XHQqL1xuXHRcdGNvbnN0IHJvdXRlckluc3BlY3RvcklkID0gXCJyb3V0ZXItaW5zcGVjdG9yOlwiICsgaWQ7XG5cdFx0YXBpLmFkZEluc3BlY3Rvcih7XG5cdFx0XHRpZDogcm91dGVySW5zcGVjdG9ySWQsXG5cdFx0XHRsYWJlbDogXCJSb3V0ZXNcIiArIChpZCA/IFwiIFwiICsgaWQgOiBcIlwiKSxcblx0XHRcdGljb246IFwiYm9va1wiLFxuXHRcdFx0dHJlZUZpbHRlclBsYWNlaG9sZGVyOiBcIlNlYXJjaCByb3V0ZXNcIlxuXHRcdH0pO1xuXHRcdGZ1bmN0aW9uIHJlZnJlc2hSb3V0ZXNWaWV3KCkge1xuXHRcdFx0aWYgKCFhY3RpdmVSb3V0ZXNQYXlsb2FkKSByZXR1cm47XG5cdFx0XHRjb25zdCBwYXlsb2FkID0gYWN0aXZlUm91dGVzUGF5bG9hZDtcblx0XHRcdGxldCByb3V0ZXMgPSBtYXRjaGVyLmdldFJvdXRlcygpLmZpbHRlcigocm91dGUpID0+ICFyb3V0ZS5wYXJlbnQgfHwgIXJvdXRlLnBhcmVudC5yZWNvcmQuY29tcG9uZW50cyk7XG5cdFx0XHRyb3V0ZXMuZm9yRWFjaChyZXNldE1hdGNoU3RhdGVPblJvdXRlUmVjb3JkKTtcblx0XHRcdGlmIChwYXlsb2FkLmZpbHRlcikgcm91dGVzID0gcm91dGVzLmZpbHRlcigocm91dGUpID0+IGlzUm91dGVNYXRjaGluZyhyb3V0ZSwgcGF5bG9hZC5maWx0ZXIudG9Mb3dlckNhc2UoKSkpO1xuXHRcdFx0cm91dGVzLmZvckVhY2goKHJvdXRlKSA9PiBtYXJrUm91dGVSZWNvcmRBY3RpdmUocm91dGUsIHJvdXRlci5jdXJyZW50Um91dGUudmFsdWUpKTtcblx0XHRcdHBheWxvYWQucm9vdE5vZGVzID0gcm91dGVzLm1hcChmb3JtYXRSb3V0ZVJlY29yZEZvckluc3BlY3Rvcik7XG5cdFx0fVxuXHRcdGxldCBhY3RpdmVSb3V0ZXNQYXlsb2FkO1xuXHRcdGFwaS5vbi5nZXRJbnNwZWN0b3JUcmVlKChwYXlsb2FkKSA9PiB7XG5cdFx0XHRhY3RpdmVSb3V0ZXNQYXlsb2FkID0gcGF5bG9hZDtcblx0XHRcdGlmIChwYXlsb2FkLmFwcCA9PT0gYXBwICYmIHBheWxvYWQuaW5zcGVjdG9ySWQgPT09IHJvdXRlckluc3BlY3RvcklkKSByZWZyZXNoUm91dGVzVmlldygpO1xuXHRcdH0pO1xuXHRcdC8qKlxuXHRcdCogRGlzcGxheSBpbmZvcm1hdGlvbiBhYm91dCB0aGUgY3VycmVudGx5IHNlbGVjdGVkIHJvdXRlIHJlY29yZFxuXHRcdCovXG5cdFx0YXBpLm9uLmdldEluc3BlY3RvclN0YXRlKChwYXlsb2FkKSA9PiB7XG5cdFx0XHRpZiAocGF5bG9hZC5hcHAgPT09IGFwcCAmJiBwYXlsb2FkLmluc3BlY3RvcklkID09PSByb3V0ZXJJbnNwZWN0b3JJZCkge1xuXHRcdFx0XHRjb25zdCByb3V0ZSA9IG1hdGNoZXIuZ2V0Um91dGVzKCkuZmluZCgocm91dGUpID0+IHJvdXRlLnJlY29yZC5fX3ZkX2lkID09PSBwYXlsb2FkLm5vZGVJZCk7XG5cdFx0XHRcdGlmIChyb3V0ZSkgcGF5bG9hZC5zdGF0ZSA9IHsgb3B0aW9uczogZm9ybWF0Um91dGVSZWNvcmRNYXRjaGVyRm9yU3RhdGVJbnNwZWN0b3Iocm91dGUpIH07XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0YXBpLnNlbmRJbnNwZWN0b3JUcmVlKHJvdXRlckluc3BlY3RvcklkKTtcblx0XHRhcGkuc2VuZEluc3BlY3RvclN0YXRlKHJvdXRlckluc3BlY3RvcklkKTtcblx0fSk7XG59XG5mdW5jdGlvbiBtb2RpZmllckZvcktleShrZXkpIHtcblx0aWYgKGtleS5vcHRpb25hbCkgcmV0dXJuIGtleS5yZXBlYXRhYmxlID8gXCIqXCIgOiBcIj9cIjtcblx0ZWxzZSByZXR1cm4ga2V5LnJlcGVhdGFibGUgPyBcIitcIiA6IFwiXCI7XG59XG5mdW5jdGlvbiBmb3JtYXRSb3V0ZVJlY29yZE1hdGNoZXJGb3JTdGF0ZUluc3BlY3Rvcihyb3V0ZSkge1xuXHRjb25zdCB7IHJlY29yZCB9ID0gcm91dGU7XG5cdGNvbnN0IGZpZWxkcyA9IFt7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJwYXRoXCIsXG5cdFx0dmFsdWU6IHJlY29yZC5wYXRoXG5cdH1dO1xuXHRpZiAocmVjb3JkLm5hbWUgIT0gbnVsbCkgZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwibmFtZVwiLFxuXHRcdHZhbHVlOiByZWNvcmQubmFtZVxuXHR9KTtcblx0ZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwicmVnZXhwXCIsXG5cdFx0dmFsdWU6IHJvdXRlLnJlXG5cdH0pO1xuXHRpZiAocm91dGUua2V5cy5sZW5ndGgpIGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcImtleXNcIixcblx0XHR2YWx1ZTogeyBfY3VzdG9tOiB7XG5cdFx0XHR0eXBlOiBudWxsLFxuXHRcdFx0cmVhZE9ubHk6IHRydWUsXG5cdFx0XHRkaXNwbGF5OiByb3V0ZS5rZXlzLm1hcCgoa2V5KSA9PiBgJHtrZXkubmFtZX0ke21vZGlmaWVyRm9yS2V5KGtleSl9YCkuam9pbihcIiBcIiksXG5cdFx0XHR0b29sdGlwOiBcIlBhcmFtIGtleXNcIixcblx0XHRcdHZhbHVlOiByb3V0ZS5rZXlzXG5cdFx0fSB9XG5cdH0pO1xuXHRpZiAocmVjb3JkLnJlZGlyZWN0ICE9IG51bGwpIGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcInJlZGlyZWN0XCIsXG5cdFx0dmFsdWU6IHJlY29yZC5yZWRpcmVjdFxuXHR9KTtcblx0aWYgKHJvdXRlLmFsaWFzLmxlbmd0aCkgZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwiYWxpYXNlc1wiLFxuXHRcdHZhbHVlOiByb3V0ZS5hbGlhcy5tYXAoKGFsaWFzKSA9PiBhbGlhcy5yZWNvcmQucGF0aClcblx0fSk7XG5cdGlmIChPYmplY3Qua2V5cyhyb3V0ZS5yZWNvcmQubWV0YSkubGVuZ3RoKSBmaWVsZHMucHVzaCh7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJtZXRhXCIsXG5cdFx0dmFsdWU6IHJvdXRlLnJlY29yZC5tZXRhXG5cdH0pO1xuXHRmaWVsZHMucHVzaCh7XG5cdFx0a2V5OiBcInNjb3JlXCIsXG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdHZhbHVlOiB7IF9jdXN0b206IHtcblx0XHRcdHR5cGU6IG51bGwsXG5cdFx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRcdGRpc3BsYXk6IHJvdXRlLnNjb3JlLm1hcCgoc2NvcmUpID0+IHNjb3JlLmpvaW4oXCIsIFwiKSkuam9pbihcIiB8IFwiKSxcblx0XHRcdHRvb2x0aXA6IFwiU2NvcmUgdXNlZCB0byBzb3J0IHJvdXRlc1wiLFxuXHRcdFx0dmFsdWU6IHJvdXRlLnNjb3JlXG5cdFx0fSB9XG5cdH0pO1xuXHRyZXR1cm4gZmllbGRzO1xufVxuLyoqXG4qIEV4dHJhY3RlZCBmcm9tIHRhaWx3aW5kIHBhbGV0dGVcbiovXG5jb25zdCBQSU5LXzUwMCA9IDE1NDg1MDgxO1xuY29uc3QgQkxVRV82MDAgPSAyNDUwNDExO1xuY29uc3QgTElNRV81MDAgPSA4NzAyOTk4O1xuY29uc3QgQ1lBTl80MDAgPSAyMjgyNDc4O1xuY29uc3QgT1JBTkdFXzQwMCA9IDE2NDg2OTcyO1xuY29uc3QgREFSSyA9IDY3MTA4ODY7XG5jb25zdCBSRURfMTAwID0gMTY3MDQyMjY7XG5jb25zdCBSRURfNzAwID0gMTIxMzEzNTY7XG5mdW5jdGlvbiBmb3JtYXRSb3V0ZVJlY29yZEZvckluc3BlY3Rvcihyb3V0ZSkge1xuXHRjb25zdCB0YWdzID0gW107XG5cdGNvbnN0IHsgcmVjb3JkIH0gPSByb3V0ZTtcblx0aWYgKHJlY29yZC5uYW1lICE9IG51bGwpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IFN0cmluZyhyZWNvcmQubmFtZSksXG5cdFx0dGV4dENvbG9yOiAwLFxuXHRcdGJhY2tncm91bmRDb2xvcjogQ1lBTl80MDBcblx0fSk7XG5cdGlmIChyZWNvcmQuYWxpYXNPZikgdGFncy5wdXNoKHtcblx0XHRsYWJlbDogXCJhbGlhc1wiLFxuXHRcdHRleHRDb2xvcjogMCxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IE9SQU5HRV80MDBcblx0fSk7XG5cdGlmIChyb3V0ZS5fX3ZkX21hdGNoKSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiBcIm1hdGNoZXNcIixcblx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBQSU5LXzUwMFxuXHR9KTtcblx0aWYgKHJvdXRlLl9fdmRfZXhhY3RBY3RpdmUpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IFwiZXhhY3RcIixcblx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBMSU1FXzUwMFxuXHR9KTtcblx0aWYgKHJvdXRlLl9fdmRfYWN0aXZlKSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiBcImFjdGl2ZVwiLFxuXHRcdHRleHRDb2xvcjogMCxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IEJMVUVfNjAwXG5cdH0pO1xuXHRpZiAocmVjb3JkLnJlZGlyZWN0KSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiB0eXBlb2YgcmVjb3JkLnJlZGlyZWN0ID09PSBcInN0cmluZ1wiID8gYHJlZGlyZWN0OiAke3JlY29yZC5yZWRpcmVjdH1gIDogXCJyZWRpcmVjdHNcIixcblx0XHR0ZXh0Q29sb3I6IDE2Nzc3MjE1LFxuXHRcdGJhY2tncm91bmRDb2xvcjogREFSS1xuXHR9KTtcblx0bGV0IGlkID0gcmVjb3JkLl9fdmRfaWQ7XG5cdGlmIChpZCA9PSBudWxsKSB7XG5cdFx0aWQgPSBTdHJpbmcocm91dGVSZWNvcmRJZCsrKTtcblx0XHRyZWNvcmQuX192ZF9pZCA9IGlkO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0aWQsXG5cdFx0bGFiZWw6IHJlY29yZC5wYXRoLFxuXHRcdHRhZ3MsXG5cdFx0Y2hpbGRyZW46IHJvdXRlLmNoaWxkcmVuLm1hcChmb3JtYXRSb3V0ZVJlY29yZEZvckluc3BlY3Rvcilcblx0fTtcbn1cbmxldCByb3V0ZVJlY29yZElkID0gMDtcbmNvbnN0IEVYVFJBQ1RfUkVHRVhQX1JFID0gL15cXC8oLiopXFwvKFthLXpdKikkLztcbmZ1bmN0aW9uIG1hcmtSb3V0ZVJlY29yZEFjdGl2ZShyb3V0ZSwgY3VycmVudFJvdXRlKSB7XG5cdGNvbnN0IGlzRXhhY3RBY3RpdmUgPSBjdXJyZW50Um91dGUubWF0Y2hlZC5sZW5ndGggJiYgaXNTYW1lUm91dGVSZWNvcmQoY3VycmVudFJvdXRlLm1hdGNoZWRbY3VycmVudFJvdXRlLm1hdGNoZWQubGVuZ3RoIC0gMV0sIHJvdXRlLnJlY29yZCk7XG5cdHJvdXRlLl9fdmRfZXhhY3RBY3RpdmUgPSByb3V0ZS5fX3ZkX2FjdGl2ZSA9IGlzRXhhY3RBY3RpdmU7XG5cdGlmICghaXNFeGFjdEFjdGl2ZSkgcm91dGUuX192ZF9hY3RpdmUgPSBjdXJyZW50Um91dGUubWF0Y2hlZC5zb21lKChtYXRjaCkgPT4gaXNTYW1lUm91dGVSZWNvcmQobWF0Y2gsIHJvdXRlLnJlY29yZCkpO1xuXHRyb3V0ZS5jaGlsZHJlbi5mb3JFYWNoKChjaGlsZFJvdXRlKSA9PiBtYXJrUm91dGVSZWNvcmRBY3RpdmUoY2hpbGRSb3V0ZSwgY3VycmVudFJvdXRlKSk7XG59XG5mdW5jdGlvbiByZXNldE1hdGNoU3RhdGVPblJvdXRlUmVjb3JkKHJvdXRlKSB7XG5cdHJvdXRlLl9fdmRfbWF0Y2ggPSBmYWxzZTtcblx0cm91dGUuY2hpbGRyZW4uZm9yRWFjaChyZXNldE1hdGNoU3RhdGVPblJvdXRlUmVjb3JkKTtcbn1cbmZ1bmN0aW9uIGlzUm91dGVNYXRjaGluZyhyb3V0ZSwgZmlsdGVyKSB7XG5cdGNvbnN0IGZvdW5kID0gU3RyaW5nKHJvdXRlLnJlKS5tYXRjaChFWFRSQUNUX1JFR0VYUF9SRSk7XG5cdHJvdXRlLl9fdmRfbWF0Y2ggPSBmYWxzZTtcblx0aWYgKCFmb3VuZCB8fCBmb3VuZC5sZW5ndGggPCAzKSByZXR1cm4gZmFsc2U7XG5cdGlmIChuZXcgUmVnRXhwKGZvdW5kWzFdLnJlcGxhY2UoL1xcJCQvLCBcIlwiKSwgZm91bmRbMl0pLnRlc3QoZmlsdGVyKSkge1xuXHRcdHJvdXRlLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkKSA9PiBpc1JvdXRlTWF0Y2hpbmcoY2hpbGQsIGZpbHRlcikpO1xuXHRcdGlmIChyb3V0ZS5yZWNvcmQucGF0aCAhPT0gXCIvXCIgfHwgZmlsdGVyID09PSBcIi9cIikge1xuXHRcdFx0cm91dGUuX192ZF9tYXRjaCA9IHJvdXRlLnJlLnRlc3QoZmlsdGVyKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0Y29uc3QgcGF0aCA9IHJvdXRlLnJlY29yZC5wYXRoLnRvTG93ZXJDYXNlKCk7XG5cdGNvbnN0IGRlY29kZWRQYXRoID0gZGVjb2RlKHBhdGgpO1xuXHRpZiAoIWZpbHRlci5zdGFydHNXaXRoKFwiL1wiKSAmJiAoZGVjb2RlZFBhdGguaW5jbHVkZXMoZmlsdGVyKSB8fCBwYXRoLmluY2x1ZGVzKGZpbHRlcikpKSByZXR1cm4gdHJ1ZTtcblx0aWYgKGRlY29kZWRQYXRoLnN0YXJ0c1dpdGgoZmlsdGVyKSB8fCBwYXRoLnN0YXJ0c1dpdGgoZmlsdGVyKSkgcmV0dXJuIHRydWU7XG5cdGlmIChyb3V0ZS5yZWNvcmQubmFtZSAmJiBTdHJpbmcocm91dGUucmVjb3JkLm5hbWUpLmluY2x1ZGVzKGZpbHRlcikpIHJldHVybiB0cnVlO1xuXHRyZXR1cm4gcm91dGUuY2hpbGRyZW4uc29tZSgoY2hpbGQpID0+IGlzUm91dGVNYXRjaGluZyhjaGlsZCwgZmlsdGVyKSk7XG59XG5mdW5jdGlvbiBvbWl0KG9iaiwga2V5cykge1xuXHRjb25zdCByZXQgPSB7fTtcblx0Zm9yIChjb25zdCBrZXkgaW4gb2JqKSBpZiAoIWtleXMuaW5jbHVkZXMoa2V5KSkgcmV0W2tleV0gPSBvYmpba2V5XTtcblx0cmV0dXJuIHJldDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUExVU19SRSBhcyBBLCBpc1NhbWVSb3V0ZUxvY2F0aW9uIGFzIEMsIHJlc29sdmVSZWxhdGl2ZVBhdGggYXMgRCwgcGFyc2VVUkwgYXMgRSwgd2FybiQxIGFzIEYsIGVuY29kZUhhc2ggYXMgTSwgZW5jb2RlUGFyYW0gYXMgTiwgc3RyaW5naWZ5VVJMIGFzIE8sIGVuY29kZVBhdGggYXMgUCwgU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCBhcyBTLCBpc1NhbWVSb3V0ZVJlY29yZCBhcyBULCBzYXZlU2Nyb2xsUG9zaXRpb24gYXMgXywgbG9hZFJvdXRlTG9jYXRpb24gYXMgYSwgbm9ybWFsaXplQmFzZSBhcyBiLCB1c2VDYWxsYmFja3MgYXMgYywgc3RyaW5naWZ5UXVlcnkgYXMgZCwgaXNSb3V0ZUxvY2F0aW9uIGFzIGYsIGdldFNjcm9sbEtleSBhcyBnLCBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uIGFzIGgsIGd1YXJkVG9Qcm9taXNlRm4gYXMgaSwgZGVjb2RlIGFzIGosIHN0cmlwQmFzZSBhcyBrLCBub3JtYWxpemVRdWVyeSBhcyBsLCBjb21wdXRlU2Nyb2xsUG9zaXRpb24gYXMgbSwgZXh0cmFjdENoYW5naW5nUmVjb3JkcyBhcyBuLCBvbkJlZm9yZVJvdXRlTGVhdmUgYXMgbywgaXNSb3V0ZU5hbWUgYXMgcCwgZXh0cmFjdENvbXBvbmVudHNHdWFyZHMgYXMgciwgb25CZWZvcmVSb3V0ZVVwZGF0ZSBhcyBzLCBhZGREZXZ0b29scyBhcyB0LCBwYXJzZVF1ZXJ5IGFzIHUsIHNjcm9sbFRvUG9zaXRpb24gYXMgdiwgaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcyBhcyB3LCBORVdfc3RyaW5naWZ5VVJMIGFzIHgsIGNyZWF0ZUhyZWYgYXMgeSB9O1xuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS0EsU0FBUyxLQUFLLFFBQVEsS0FBSyxrQkFBa0IsS0FBSyxZQUFZLEtBQUssbUJBQW1CLEtBQUssU0FBUyxLQUFLLGlCQUFpQixLQUFLLGlCQUFpQjtBQUNoSixTQUFTLG9CQUFvQixRQUFRLGFBQWEsZUFBZSxhQUFhLGFBQWE7QUFDM0YsU0FBUywyQkFBMkI7QUFFcEMsU0FBUyxPQUFPLEtBQUs7QUFDcEIsUUFBTSxPQUFPLE1BQU0sS0FBSyxTQUFTLEVBQUUsTUFBTSxDQUFDO0FBQzFDLFVBQVEsS0FBSyxNQUFNLFNBQVMsQ0FBQyx3QkFBd0IsR0FBRyxFQUFFLE9BQU8sSUFBSSxDQUFDO0FBQ3ZFO0FBb0JBLE1BQU0sVUFBVTtBQUNoQixNQUFNLGVBQWU7QUFDckIsTUFBTSxXQUFXO0FBQ2pCLE1BQU0sV0FBVztBQUNqQixNQUFNLFFBQVE7QUFDZCxNQUFNLFVBQVU7QUFlaEIsTUFBTSxzQkFBc0I7QUFDNUIsTUFBTSx1QkFBdUI7QUFDN0IsTUFBTSxlQUFlO0FBQ3JCLE1BQU0sa0JBQWtCO0FBQ3hCLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0sY0FBYztBQUNwQixNQUFNLHFCQUFxQjtBQUMzQixNQUFNLGVBQWU7QUFTckIsU0FBUyxhQUFhLE1BQU07QUFDM0IsU0FBTyxRQUFRLE9BQU8sS0FBSyxVQUFVLEtBQUssSUFBSSxFQUFFLFFBQVEsYUFBYSxHQUFHLEVBQUUsUUFBUSxxQkFBcUIsR0FBRyxFQUFFLFFBQVEsc0JBQXNCLEdBQUc7QUFDOUk7QUFPQSxTQUFTLFdBQVcsTUFBTTtBQUN6QixTQUFPLGFBQWEsSUFBSSxFQUFFLFFBQVEsbUJBQW1CLEdBQUcsRUFBRSxRQUFRLG9CQUFvQixHQUFHLEVBQUUsUUFBUSxjQUFjLEdBQUc7QUFDckg7QUFRQSxTQUFTLGlCQUFpQixNQUFNO0FBQy9CLFNBQU8sYUFBYSxJQUFJLEVBQUUsUUFBUSxTQUFTLEtBQUssRUFBRSxRQUFRLGNBQWMsR0FBRyxFQUFFLFFBQVEsU0FBUyxLQUFLLEVBQUUsUUFBUSxjQUFjLEtBQUssRUFBRSxRQUFRLGlCQUFpQixHQUFHLEVBQUUsUUFBUSxtQkFBbUIsR0FBRyxFQUFFLFFBQVEsb0JBQW9CLEdBQUcsRUFBRSxRQUFRLGNBQWMsR0FBRztBQUMzUDtBQU1BLFNBQVMsZUFBZSxNQUFNO0FBQzdCLFNBQU8saUJBQWlCLElBQUksRUFBRSxRQUFRLFVBQVUsS0FBSztBQUN0RDtBQU9BLFNBQVMsV0FBVyxNQUFNO0FBQ3pCLFNBQU8sYUFBYSxJQUFJLEVBQUUsUUFBUSxTQUFTLEtBQUssRUFBRSxRQUFRLE9BQU8sS0FBSztBQUN2RTtBQVVBLFNBQVMsWUFBWSxNQUFNO0FBQzFCLFNBQU8sV0FBVyxJQUFJLEVBQUUsUUFBUSxVQUFVLEtBQUs7QUFDaEQ7QUFDQSxTQUFTLE9BQU8sTUFBTTtBQUNyQixNQUFJLFFBQVEsS0FBTSxRQUFPO0FBQ3pCLE1BQUk7QUFDSCxXQUFPLG1CQUFtQixLQUFLLElBQUk7QUFBQSxFQUNwQyxRQUFRO0FBQ1AsSUFBeUMsT0FBTyxtQkFBbUIsSUFBSSx5QkFBeUI7QUFBQSxFQUNqRztBQUNBLFNBQU8sS0FBSztBQUNiO0FBR0EsTUFBTSxvQkFBb0I7QUFDMUIsTUFBTSxzQkFBc0IsQ0FBQyxTQUFTLEtBQUssUUFBUSxtQkFBbUIsRUFBRTtBQVV4RSxTQUFTLFNBQVNBLGFBQVksVUFBVSxrQkFBa0IsS0FBSztBQUM5RCxNQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsZUFBZSxJQUFJLE9BQU87QUFDaEQsUUFBTSxVQUFVLFNBQVMsUUFBUSxHQUFHO0FBQ3BDLE1BQUksWUFBWSxTQUFTLFFBQVEsR0FBRztBQUNwQyxjQUFZLFdBQVcsS0FBSyxZQUFZLFVBQVUsS0FBSztBQUN2RCxNQUFJLGFBQWEsR0FBRztBQUNuQixXQUFPLFNBQVMsTUFBTSxHQUFHLFNBQVM7QUFDbEMsbUJBQWUsU0FBUyxNQUFNLFdBQVcsVUFBVSxJQUFJLFVBQVUsU0FBUyxNQUFNO0FBQ2hGLFlBQVFBLFlBQVcsYUFBYSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQ3pDO0FBQ0EsTUFBSSxXQUFXLEdBQUc7QUFDakIsV0FBTyxRQUFRLFNBQVMsTUFBTSxHQUFHLE9BQU87QUFDeEMsV0FBTyxTQUFTLE1BQU0sU0FBUyxTQUFTLE1BQU07QUFBQSxFQUMvQztBQUNBLFNBQU8sb0JBQW9CLFFBQVEsT0FBTyxPQUFPLFVBQVUsZUFBZTtBQUMxRSxTQUFPO0FBQUEsSUFDTixVQUFVLE9BQU8sZUFBZTtBQUFBLElBQ2hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsTUFBTSxPQUFPLElBQUk7QUFBQSxFQUNsQjtBQUNEO0FBQ0EsU0FBUyxpQkFBaUJDLGlCQUFnQixNQUFNLE9BQU8sT0FBTyxJQUFJO0FBQ2pFLFFBQU0sYUFBYUEsZ0JBQWUsS0FBSztBQUN2QyxTQUFPLFFBQVEsY0FBYyxPQUFPLGFBQWEsV0FBVyxJQUFJO0FBQ2pFO0FBT0EsU0FBUyxhQUFhQSxpQkFBZ0IsVUFBVTtBQUMvQyxRQUFNLFFBQVEsU0FBUyxRQUFRQSxnQkFBZSxTQUFTLEtBQUssSUFBSTtBQUNoRSxTQUFPLFNBQVMsUUFBUSxTQUFTLE9BQU8sU0FBUyxTQUFTLFFBQVE7QUFDbkU7QUFPQSxTQUFTLFVBQVUsVUFBVSxNQUFNO0FBQ2xDLE1BQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxZQUFZLEVBQUUsV0FBVyxLQUFLLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFDNUUsU0FBTyxTQUFTLE1BQU0sS0FBSyxNQUFNLEtBQUs7QUFDdkM7QUFVQSxTQUFTLG9CQUFvQkEsaUJBQWdCLEdBQUcsR0FBRztBQUNsRCxRQUFNLGFBQWEsRUFBRSxRQUFRLFNBQVM7QUFDdEMsUUFBTSxhQUFhLEVBQUUsUUFBUSxTQUFTO0FBQ3RDLFNBQU8sYUFBYSxNQUFNLGVBQWUsY0FBYyxrQkFBa0IsRUFBRSxRQUFRLFVBQVUsR0FBRyxFQUFFLFFBQVEsVUFBVSxDQUFDLEtBQUssMEJBQTBCLEVBQUUsUUFBUSxFQUFFLE1BQU0sS0FBS0EsZ0JBQWUsRUFBRSxLQUFLLE1BQU1BLGdCQUFlLEVBQUUsS0FBSyxLQUFLLEVBQUUsU0FBUyxFQUFFO0FBQ2hQO0FBUUEsU0FBUyxrQkFBa0IsR0FBRyxHQUFHO0FBQ2hDLFVBQVEsRUFBRSxXQUFXLFFBQVEsRUFBRSxXQUFXO0FBQzNDO0FBQ0EsU0FBUywwQkFBMEIsR0FBRyxHQUFHO0FBQ3hDLE1BQUksT0FBTyxLQUFLLENBQUMsRUFBRSxXQUFXLE9BQU8sS0FBSyxDQUFDLEVBQUUsT0FBUSxRQUFPO0FBQzVELFdBQVMsT0FBTyxFQUFHLEtBQUksQ0FBQywrQkFBK0IsRUFBRSxHQUFHLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRyxRQUFPO0FBQy9FLFNBQU87QUFDUjtBQUNBLFNBQVMsK0JBQStCLEdBQUcsR0FBRztBQUM3QyxTQUFPLFFBQVEsQ0FBQyxJQUFJLGtCQUFrQixHQUFHLENBQUMsSUFBSSxRQUFRLENBQUMsSUFBSSxrQkFBa0IsR0FBRyxDQUFDLEtBQUssS0FBSyxFQUFFLFFBQVEsUUFBUSxLQUFLLEVBQUUsUUFBUTtBQUM3SDtBQVFBLFNBQVMsa0JBQWtCLEdBQUcsR0FBRztBQUNoQyxTQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsT0FBTyxNQUFNLFVBQVUsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLFdBQVcsS0FBSyxFQUFFLENBQUMsTUFBTTtBQUNqSDtBQU9BLFNBQVMsb0JBQW9CLElBQUksTUFBTTtBQUN0QyxNQUFJLEdBQUcsV0FBVyxHQUFHLEVBQUcsUUFBTztBQUMvQixNQUE2QyxDQUFDLEtBQUssV0FBVyxHQUFHLEdBQUc7QUFDbkUsV0FBTyxtRkFBbUYsRUFBRSxXQUFXLElBQUksNEJBQTRCLElBQUksSUFBSTtBQUMvSSxXQUFPO0FBQUEsRUFDUjtBQUNBLE1BQUksQ0FBQyxHQUFJLFFBQU87QUFDaEIsUUFBTSxlQUFlLEtBQUssTUFBTSxHQUFHO0FBQ25DLFFBQU0sYUFBYSxHQUFHLE1BQU0sR0FBRztBQUMvQixRQUFNLGdCQUFnQixXQUFXLFdBQVcsU0FBUyxDQUFDO0FBQ3RELE1BQUksa0JBQWtCLFFBQVEsa0JBQWtCLElBQUssWUFBVyxLQUFLLEVBQUU7QUFDdkUsTUFBSSxXQUFXLGFBQWEsU0FBUztBQUNyQyxNQUFJO0FBQ0osTUFBSTtBQUNKLE9BQUssYUFBYSxHQUFHLGFBQWEsV0FBVyxRQUFRLGNBQWM7QUFDbEUsY0FBVSxXQUFXLFVBQVU7QUFDL0IsUUFBSSxZQUFZLElBQUs7QUFDckIsUUFBSSxZQUFZLE1BQU07QUFDckIsVUFBSSxXQUFXLEVBQUc7QUFBQSxJQUNuQixNQUFPO0FBQUEsRUFDUjtBQUNBLFNBQU8sYUFBYSxNQUFNLEdBQUcsUUFBUSxFQUFFLEtBQUssR0FBRyxJQUFJLE1BQU0sV0FBVyxNQUFNLFVBQVUsRUFBRSxLQUFLLEdBQUc7QUFDL0Y7QUFnQkEsTUFBTSw0QkFBNEI7QUFBQSxFQUNqQyxNQUFNO0FBQUEsRUFDTixNQUFNO0FBQUEsRUFDTixRQUFRLENBQUM7QUFBQSxFQUNULE9BQU8sQ0FBQztBQUFBLEVBQ1IsTUFBTTtBQUFBLEVBQ04sVUFBVTtBQUFBLEVBQ1YsU0FBUyxDQUFDO0FBQUEsRUFDVixNQUFNLENBQUM7QUFBQSxFQUNQLGdCQUFnQjtBQUNqQjtBQVNBLFNBQVMsY0FBYyxNQUFNO0FBQzVCLE1BQUksQ0FBQyxLQUFNLEtBQUksV0FBVztBQUN6QixVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxVQUFVLE9BQU8sYUFBYSxNQUFNLEtBQUs7QUFDaEQsV0FBTyxLQUFLLFFBQVEsa0JBQWtCLEVBQUU7QUFBQSxFQUN6QyxNQUFPLFFBQU87QUFDZCxNQUFJLEtBQUssQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDLE1BQU0sSUFBSyxRQUFPLE1BQU07QUFDckQsU0FBTyxvQkFBb0IsSUFBSTtBQUNoQztBQUNBLE1BQU0saUJBQWlCO0FBQ3ZCLFNBQVMsV0FBVyxNQUFNLFVBQVU7QUFDbkMsU0FBTyxLQUFLLFFBQVEsZ0JBQWdCLEdBQUcsSUFBSTtBQUM1QztBQUdBLFNBQVMsbUJBQW1CLElBQUksUUFBUTtBQUN2QyxRQUFNLFVBQVUsU0FBUyxnQkFBZ0Isc0JBQXNCO0FBQy9ELFFBQU0sU0FBUyxHQUFHLHNCQUFzQjtBQUN4QyxTQUFPO0FBQUEsSUFDTixVQUFVLE9BQU87QUFBQSxJQUNqQixNQUFNLE9BQU8sT0FBTyxRQUFRLFFBQVEsT0FBTyxRQUFRO0FBQUEsSUFDbkQsS0FBSyxPQUFPLE1BQU0sUUFBUSxPQUFPLE9BQU8sT0FBTztBQUFBLEVBQ2hEO0FBQ0Q7QUFDQSxNQUFNLHdCQUF3QixPQUFPO0FBQUEsRUFDcEMsTUFBTSxPQUFPO0FBQUEsRUFDYixLQUFLLE9BQU87QUFDYjtBQUNBLFNBQVMsaUJBQWlCLFVBQVU7QUFDbkMsTUFBSTtBQUNKLE1BQUksUUFBUSxVQUFVO0FBQ3JCLFVBQU0sYUFBYSxTQUFTO0FBQzVCLFVBQU0sZUFBZSxPQUFPLGVBQWUsWUFBWSxXQUFXLFdBQVcsR0FBRztBQXNCaEYsUUFBNkMsT0FBTyxTQUFTLE9BQU8sVUFBVTtBQUM3RSxVQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxlQUFlLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxFQUFHLEtBQUk7QUFDeEUsY0FBTSxVQUFVLFNBQVMsY0FBYyxTQUFTLEVBQUU7QUFDbEQsWUFBSSxnQkFBZ0IsU0FBUztBQUM1QixpQkFBTyxpQkFBaUIsU0FBUyxFQUFFLHNEQUFzRCxTQUFTLEVBQUUsaUNBQWlDO0FBQ3JJO0FBQUEsUUFDRDtBQUFBLE1BQ0QsUUFBUTtBQUNQLGVBQU8saUJBQWlCLFNBQVMsRUFBRSw0UUFBNFE7QUFDL1M7QUFBQSxNQUNEO0FBQUEsSUFDRDtBQUNBLFVBQU0sS0FBSyxPQUFPLGVBQWUsV0FBVyxlQUFlLFNBQVMsZUFBZSxXQUFXLE1BQU0sQ0FBQyxDQUFDLElBQUksU0FBUyxjQUFjLFVBQVUsSUFBSTtBQUMvSSxRQUFJLENBQUMsSUFBSTtBQUNSLE1BQXlDLE9BQU8seUNBQXlDLFNBQVMsRUFBRSwrQkFBK0I7QUFDbkk7QUFBQSxJQUNEO0FBQ0Esc0JBQWtCLG1CQUFtQixJQUFJLFFBQVE7QUFBQSxFQUNsRCxNQUFPLG1CQUFrQjtBQUN6QixNQUFJLG9CQUFvQixTQUFTLGdCQUFnQixNQUFPLFFBQU8sU0FBUyxlQUFlO0FBQUEsTUFDbEYsUUFBTyxTQUFTLGdCQUFnQixRQUFRLE9BQU8sZ0JBQWdCLE9BQU8sT0FBTyxTQUFTLGdCQUFnQixPQUFPLE9BQU8sZ0JBQWdCLE1BQU0sT0FBTyxPQUFPO0FBQzlKO0FBQ0EsU0FBUyxhQUFhLE1BQU0sT0FBTztBQUNsQyxVQUFRLFFBQVEsUUFBUSxRQUFRLE1BQU0sV0FBVyxRQUFRLE1BQU07QUFDaEU7QUFDQSxNQUFNLGtCQUFrQyxvQkFBSSxJQUFJO0FBQ2hELFNBQVMsbUJBQW1CLEtBQUssZ0JBQWdCO0FBQ2hELGtCQUFnQixJQUFJLEtBQUssY0FBYztBQUN4QztBQUNBLFNBQVMsdUJBQXVCLEtBQUs7QUFDcEMsUUFBTSxTQUFTLGdCQUFnQixJQUFJLEdBQUc7QUFDdEMsa0JBQWdCLE9BQU8sR0FBRztBQUMxQixTQUFPO0FBQ1I7QUFPQSxTQUFTLGdCQUFnQixPQUFPO0FBQy9CLFNBQU8sT0FBTyxVQUFVLFlBQVksU0FBUyxPQUFPLFVBQVU7QUFDL0Q7QUFDQSxTQUFTLFlBQVksTUFBTTtBQUMxQixTQUFPLE9BQU8sU0FBUyxZQUFZLE9BQU8sU0FBUztBQUNwRDtBQVlBLFNBQVMsV0FBVyxRQUFRO0FBQzNCLFFBQU0sUUFBUSxDQUFDO0FBQ2YsTUFBSSxXQUFXLE1BQU0sV0FBVyxJQUFLLFFBQU87QUFDNUMsUUFBTSxnQkFBZ0IsT0FBTyxDQUFDLE1BQU0sTUFBTSxPQUFPLE1BQU0sQ0FBQyxJQUFJLFFBQVEsTUFBTSxHQUFHO0FBQzdFLFdBQVMsSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEVBQUUsR0FBRztBQUM3QyxVQUFNLGNBQWMsYUFBYSxDQUFDLEVBQUUsUUFBUSxTQUFTLEdBQUc7QUFDeEQsVUFBTSxRQUFRLFlBQVksUUFBUSxHQUFHO0FBQ3JDLFVBQU0sTUFBTSxPQUFPLFFBQVEsSUFBSSxjQUFjLFlBQVksTUFBTSxHQUFHLEtBQUssQ0FBQztBQUN4RSxVQUFNLFFBQVEsUUFBUSxJQUFJLE9BQU8sT0FBTyxZQUFZLE1BQU0sUUFBUSxDQUFDLENBQUM7QUFDcEUsUUFBSSxPQUFPLE9BQU87QUFDakIsVUFBSSxlQUFlLE1BQU0sR0FBRztBQUM1QixVQUFJLENBQUMsUUFBUSxZQUFZLEVBQUcsZ0JBQWUsTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZO0FBQ3JFLG1CQUFhLEtBQUssS0FBSztBQUFBLElBQ3hCLE1BQU8sT0FBTSxHQUFHLElBQUk7QUFBQSxFQUNyQjtBQUNBLFNBQU87QUFDUjtBQVVBLFNBQVMsZUFBZSxPQUFPO0FBQzlCLE1BQUksU0FBUztBQUNiLFdBQVMsT0FBTyxPQUFPO0FBQ3RCLFVBQU0sUUFBUSxNQUFNLEdBQUc7QUFDdkIsVUFBTSxlQUFlLEdBQUc7QUFDeEIsUUFBSSxTQUFTLE1BQU07QUFDbEIsVUFBSSxVQUFVLE9BQVEsWUFBVyxPQUFPLFNBQVMsTUFBTSxNQUFNO0FBQzdEO0FBQUEsSUFDRDtBQUNBLEtBQUMsUUFBUSxLQUFLLElBQUksTUFBTSxJQUFJLENBQUMsTUFBTSxLQUFLLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsaUJBQWlCLEtBQUssQ0FBQyxHQUFHLFFBQVEsQ0FBQ0MsV0FBVTtBQUNySCxVQUFJQSxXQUFVLFFBQVE7QUFDckIsbUJBQVcsT0FBTyxTQUFTLE1BQU0sTUFBTTtBQUN2QyxZQUFJQSxVQUFTLEtBQU0sV0FBVSxNQUFNQTtBQUFBLE1BQ3BDO0FBQUEsSUFDRCxDQUFDO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDUjtBQVNBLFNBQVMsZUFBZSxPQUFPO0FBQzlCLFFBQU0sa0JBQWtCLENBQUM7QUFDekIsYUFBVyxPQUFPLE9BQU87QUFDeEIsVUFBTSxRQUFRLE1BQU0sR0FBRztBQUN2QixRQUFJLFVBQVUsT0FBUSxpQkFBZ0IsR0FBRyxJQUFJLFFBQVEsS0FBSyxJQUFJLE1BQU0sSUFBSSxDQUFDLE1BQU0sS0FBSyxPQUFPLE9BQU8sS0FBSyxDQUFDLElBQUksU0FBUyxPQUFPLFFBQVEsS0FBSztBQUFBLEVBQzFJO0FBQ0EsU0FBTztBQUNSO0FBTUEsU0FBUyxlQUFlO0FBQ3ZCLE1BQUksV0FBVyxDQUFDO0FBQ2hCLFdBQVMsSUFBSSxTQUFTO0FBQ3JCLGFBQVMsS0FBSyxPQUFPO0FBQ3JCLFdBQU8sTUFBTTtBQUNaLFlBQU0sSUFBSSxTQUFTLFFBQVEsT0FBTztBQUNsQyxVQUFJLElBQUksR0FBSSxVQUFTLE9BQU8sR0FBRyxDQUFDO0FBQUEsSUFDakM7QUFBQSxFQUNEO0FBQ0EsV0FBUyxRQUFRO0FBQ2hCLGVBQVcsQ0FBQztBQUFBLEVBQ2I7QUFDQSxTQUFPO0FBQUEsSUFDTjtBQUFBLElBQ0EsTUFBTSxNQUFNLFNBQVMsTUFBTTtBQUFBLElBQzNCO0FBQUEsRUFDRDtBQUNEO0FBR0EsU0FBUyxjQUFjLGlCQUFpQixNQUFNLE9BQU87QUFDcEQsUUFBTSxTQUFTLGdCQUFnQjtBQUMvQixNQUFJLENBQUMsUUFBUTtBQUNaLFFBQUksS0FBdUMsUUFBTyxtREFBbUQsU0FBUyxpQkFBaUIsd0JBQXdCLG9CQUFvQiwwSEFBMEg7QUFDclM7QUFBQSxFQUNEO0FBQ0EsTUFBSSxnQkFBZ0I7QUFDcEIsUUFBTSxpQkFBaUIsTUFBTTtBQUM1QixrQkFBYyxJQUFJLEVBQUUsT0FBTyxLQUFLO0FBQUEsRUFDakM7QUFDQSxjQUFZLGNBQWM7QUFDMUIsZ0JBQWMsY0FBYztBQUM1QixjQUFZLE1BQU07QUFDakIsVUFBTSxZQUFZLGdCQUFnQjtBQUNsQyxRQUE2QyxDQUFDLFVBQVcsUUFBTywySUFBMkk7QUFDM00sUUFBSSxVQUFXLGlCQUFnQjtBQUMvQixrQkFBYyxJQUFJLEVBQUUsSUFBSSxLQUFLO0FBQUEsRUFDOUIsQ0FBQztBQUNELGdCQUFjLElBQUksRUFBRSxJQUFJLEtBQUs7QUFDOUI7QUFRQSxTQUFTLG1CQUFtQixZQUFZO0FBQ3ZDLE1BQTZDLENBQUMsbUJBQW1CLEdBQUc7QUFDbkUsV0FBTyx3R0FBd0c7QUFDL0c7QUFBQSxFQUNEO0FBQ0EsZ0JBQWMsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsZUFBZSxVQUFVO0FBQ3JFO0FBUUEsU0FBUyxvQkFBb0IsYUFBYTtBQUN6QyxNQUE2QyxDQUFDLG1CQUFtQixHQUFHO0FBQ25FLFdBQU8seUdBQXlHO0FBQ2hIO0FBQUEsRUFDRDtBQUNBLGdCQUFjLE9BQU8saUJBQWlCLENBQUMsQ0FBQyxHQUFHLGdCQUFnQixXQUFXO0FBQ3ZFO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTyxJQUFJLE1BQU0sUUFBUSxNQUFNLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxHQUFHO0FBQ3ZGLFFBQU0scUJBQXFCLFdBQVcsT0FBTyxlQUFlLElBQUksSUFBSSxPQUFPLGVBQWUsSUFBSSxLQUFLLENBQUM7QUFDcEcsU0FBTyxNQUFNLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUM3QyxVQUFNLE9BQU8sQ0FBQyxVQUFVO0FBQ3ZCLFVBQUksVUFBVSxNQUFPLFFBQU8sa0JBQWtCLEdBQUc7QUFBQSxRQUNoRDtBQUFBLFFBQ0E7QUFBQSxNQUNELENBQUMsQ0FBQztBQUFBLGVBQ08saUJBQWlCLE1BQU8sUUFBTyxLQUFLO0FBQUEsZUFDcEMsZ0JBQWdCLEtBQUssRUFBRyxRQUFPLGtCQUFrQixHQUFHO0FBQUEsUUFDNUQsTUFBTTtBQUFBLFFBQ04sSUFBSTtBQUFBLE1BQ0wsQ0FBQyxDQUFDO0FBQUEsV0FDRztBQUNKLFlBQUksc0JBQXNCLE9BQU8sZUFBZSxJQUFJLE1BQU0sc0JBQXNCLE9BQU8sVUFBVSxXQUFZLG9CQUFtQixLQUFLLEtBQUs7QUFDMUksZ0JBQVE7QUFBQSxNQUNUO0FBQUEsSUFDRDtBQUNBLFVBQU0sY0FBYyxlQUFlLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxVQUFVLElBQUksR0FBRyxJQUFJLE1BQU0sT0FBd0MsdUJBQXVCLG9CQUFvQixNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQzNNLFFBQUksWUFBWSxRQUFRLFFBQVEsV0FBVztBQUMzQyxRQUFJLE1BQU0sU0FBUyxFQUFHLGFBQVksVUFBVSxLQUFLLElBQUk7QUFDckQsUUFBNkMsTUFBTSxTQUFTLEdBQUc7QUFDOUQsWUFBTSxVQUFVLGtEQUFrRCxNQUFNLE9BQU8sTUFBTyxNQUFNLE9BQU8sTUFBTyxFQUFFO0FBQUEsRUFBTSxNQUFNLFNBQVMsQ0FBQztBQUFBO0FBQ2xJLFVBQUksT0FBTyxnQkFBZ0IsWUFBWSxVQUFVLFlBQWEsYUFBWSxVQUFVLEtBQUssQ0FBQyxrQkFBa0I7QUFDM0csWUFBSSxDQUFDLEtBQUssU0FBUztBQUNsQixpQkFBTyxPQUFPO0FBQ2QsaUJBQU8sUUFBUSxPQUF1QixvQkFBSSxNQUFNLDBCQUEwQixDQUFDO0FBQUEsUUFDNUU7QUFDQSxlQUFPO0FBQUEsTUFDUixDQUFDO0FBQUEsZUFDUSxnQkFBZ0IsUUFBUTtBQUNoQyxZQUFJLENBQUMsS0FBSyxTQUFTO0FBQ2xCLGlCQUFPLE9BQU87QUFDZCxpQkFBdUIsb0JBQUksTUFBTSwwQkFBMEIsQ0FBQztBQUM1RDtBQUFBLFFBQ0Q7QUFBQSxNQUNEO0FBQUEsSUFDRDtBQUNBLGNBQVUsTUFBTSxDQUFDLFFBQVEsT0FBTyxHQUFHLENBQUM7QUFBQSxFQUNyQyxDQUFDO0FBQ0Y7QUFRQSxTQUFTLHVCQUF1QixNQUFNO0FBQ3JDLE1BQUksU0FBUztBQUNiLFNBQU8sV0FBVztBQUNqQixRQUFJLENBQUMsUUFBUTtBQUNaLGVBQVM7QUFDVCxhQUFPLDhHQUE4RztBQUFBLElBQ3RIO0FBQ0EsV0FBTyxLQUFLLE1BQU0sTUFBTSxTQUFTO0FBQUEsRUFDbEM7QUFDRDtBQUNBLFNBQVMsb0JBQW9CLE1BQU0sSUFBSSxNQUFNO0FBQzVDLE1BQUksU0FBUztBQUNiLFNBQU8sV0FBVztBQUNqQixRQUFJLGFBQWEsRUFBRyxRQUFPLDBGQUEwRixLQUFLLFFBQVEsU0FBUyxHQUFHLFFBQVEsaUdBQWlHO0FBQ3ZQLFNBQUssVUFBVTtBQUNmLFFBQUksV0FBVyxFQUFHLE1BQUssTUFBTSxNQUFNLFNBQVM7QUFBQSxFQUM3QztBQUNEO0FBQ0EsU0FBUyx3QkFBd0IsU0FBUyxXQUFXLElBQUksTUFBTSxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsR0FBRztBQUM3RixRQUFNLFNBQVMsQ0FBQztBQUNoQixhQUFXLFVBQVUsU0FBUztBQUM3QixRQUE2QyxDQUFDLE9BQU8sY0FBYyxPQUFPLFlBQVksQ0FBQyxPQUFPLFNBQVMsT0FBUSxRQUFPLHFCQUFxQixPQUFPLElBQUksOERBQThEO0FBQ3BOLGVBQVcsUUFBUSxPQUFPLFlBQVk7QUFDckMsVUFBSSxlQUFlLE9BQU8sV0FBVyxJQUFJO0FBQ3pDLFVBQUksTUFBdUM7QUFDMUMsWUFBSSxDQUFDLGdCQUFnQixPQUFPLGlCQUFpQixZQUFZLE9BQU8saUJBQWlCLFlBQVk7QUFDNUYsaUJBQU8sY0FBYyxJQUFJLDBCQUEwQixPQUFPLElBQUkseUNBQXlDLE9BQU8sWUFBWSxDQUFDLElBQUk7QUFDL0gsZ0JBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUFBLFFBQzFDLFdBQVcsVUFBVSxjQUFjO0FBQ2xDLGlCQUFPLGNBQWMsSUFBSSwwQkFBMEIsT0FBTyxJQUFJLDZMQUE2TDtBQUMzUCxnQkFBTSxVQUFVO0FBQ2hCLHlCQUFlLE1BQU07QUFBQSxRQUN0QixXQUFXLGFBQWEsaUJBQWlCLENBQUMsYUFBYSxxQkFBcUI7QUFDM0UsdUJBQWEsc0JBQXNCO0FBQ25DLGlCQUFPLGNBQWMsSUFBSSwwQkFBMEIsT0FBTyxJQUFJLG9KQUFvSjtBQUFBLFFBQ25OO0FBQUEsTUFDRDtBQUNBLFVBQUksY0FBYyxzQkFBc0IsQ0FBQyxPQUFPLFVBQVUsSUFBSSxFQUFHO0FBQ2pFLFVBQUksaUJBQWlCLFlBQVksR0FBRztBQUNuQyxjQUFNLFNBQVMsYUFBYSxhQUFhLGNBQWMsU0FBUztBQUNoRSxpQkFBUyxPQUFPLEtBQUssaUJBQWlCLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTSxjQUFjLENBQUM7QUFBQSxNQUNyRixPQUFPO0FBQ04sWUFBSSxtQkFBbUIsYUFBYTtBQUNwQyxZQUE2QyxFQUFFLFdBQVcsbUJBQW1CO0FBQzVFLGlCQUFPLGNBQWMsSUFBSSwwQkFBMEIsT0FBTyxJQUFJLDRMQUE0TDtBQUMxUCw2QkFBbUIsUUFBUSxRQUFRLGdCQUFnQjtBQUFBLFFBQ3BEO0FBQ0EsZUFBTyxLQUFLLE1BQU0saUJBQWlCLEtBQUssQ0FBQyxhQUFhO0FBQ3JELGNBQUksQ0FBQyxTQUFVLE9BQU0sSUFBSSxNQUFNLCtCQUErQixJQUFJLFNBQVMsT0FBTyxJQUFJLEdBQUc7QUFDekYsZ0JBQU0sb0JBQW9CLFdBQVcsUUFBUSxJQUFJLFNBQVMsVUFBVTtBQUNwRSxpQkFBTyxLQUFLLElBQUksSUFBSTtBQUNwQixpQkFBTyxXQUFXLElBQUksSUFBSTtBQUMxQixnQkFBTSxTQUFTLGtCQUFrQixhQUFhLG1CQUFtQixTQUFTO0FBQzFFLGlCQUFPLFNBQVMsaUJBQWlCLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTSxjQUFjLEVBQUU7QUFBQSxRQUNqRixDQUFDLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRDtBQUFBLEVBQ0Q7QUFDQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLGtCQUFrQixPQUFPO0FBQ2pDLFNBQU8sTUFBTSxRQUFRLE1BQU0sQ0FBQyxXQUFXLE9BQU8sUUFBUSxJQUFJLFFBQVEsT0FBdUIsb0JBQUksTUFBTSxxQ0FBcUMsQ0FBQyxJQUFJLFFBQVEsSUFBSSxNQUFNLFFBQVEsSUFBSSxDQUFDLFdBQVcsT0FBTyxjQUFjLFFBQVEsSUFBSSxPQUFPLEtBQUssT0FBTyxVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVUsU0FBUztBQUNqUixVQUFNLGVBQWUsT0FBTyxXQUFXLElBQUk7QUFDM0MsUUFBSSxPQUFPLGlCQUFpQixjQUFjLEVBQUUsaUJBQWlCLGNBQWUsVUFBUyxLQUFLLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTtBQUMzSCxVQUFJLENBQUMsU0FBVSxRQUFPLFFBQVEsT0FBdUIsb0JBQUksTUFBTSwrQkFBK0IsSUFBSSxTQUFTLE9BQU8sSUFBSSx5REFBeUQsQ0FBQztBQUNoTCxZQUFNLG9CQUFvQixXQUFXLFFBQVEsSUFBSSxTQUFTLFVBQVU7QUFDcEUsYUFBTyxLQUFLLElBQUksSUFBSTtBQUNwQixhQUFPLFdBQVcsSUFBSSxJQUFJO0FBQUEsSUFDM0IsQ0FBQyxDQUFDO0FBQ0YsV0FBTztBQUFBLEVBQ1IsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUMzQjtBQVFBLFNBQVMsdUJBQXVCLElBQUksTUFBTTtBQUN6QyxRQUFNLGlCQUFpQixDQUFDO0FBQ3hCLFFBQU0sa0JBQWtCLENBQUM7QUFDekIsUUFBTSxrQkFBa0IsQ0FBQztBQUN6QixRQUFNLE1BQU0sS0FBSyxJQUFJLEtBQUssUUFBUSxRQUFRLEdBQUcsUUFBUSxNQUFNO0FBQzNELFdBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0FBQzdCLFVBQU0sYUFBYSxLQUFLLFFBQVEsQ0FBQztBQUNqQyxRQUFJLFdBQVksS0FBSSxHQUFHLFFBQVEsS0FBSyxDQUFDLFdBQVcsa0JBQWtCLFFBQVEsVUFBVSxDQUFDLEVBQUcsaUJBQWdCLEtBQUssVUFBVTtBQUFBLFFBQ2xILGdCQUFlLEtBQUssVUFBVTtBQUNuQyxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUM7QUFDN0IsUUFBSSxVQUFVO0FBQ2IsVUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUMsV0FBVyxrQkFBa0IsUUFBUSxRQUFRLENBQUMsRUFBRyxpQkFBZ0IsS0FBSyxRQUFRO0FBQUEsSUFDdkc7QUFBQSxFQUNEO0FBQ0EsU0FBTztBQUFBLElBQ047QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Q7QUFDRDtBQVVBLFNBQVMsb0JBQW9CLGVBQWUsU0FBUztBQUNwRCxRQUFNLE9BQU8sT0FBTyxDQUFDLEdBQUcsZUFBZSxFQUFFLFNBQVMsY0FBYyxRQUFRLElBQUksQ0FBQyxZQUFZLEtBQUssU0FBUztBQUFBLElBQ3RHO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNELENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDTCxTQUFPLEVBQUUsU0FBUztBQUFBLElBQ2pCLE1BQU07QUFBQSxJQUNOLFVBQVU7QUFBQSxJQUNWLFNBQVMsY0FBYztBQUFBLElBQ3ZCO0FBQUEsSUFDQSxPQUFPO0FBQUEsRUFDUixFQUFFO0FBQ0g7QUFDQSxTQUFTLGNBQWMsU0FBUztBQUMvQixTQUFPLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRTtBQUMvQjtBQUNBLElBQUksV0FBVztBQUNmLFNBQVMsWUFBWSxLQUFLLFFBQVEsU0FBUztBQUMxQyxNQUFJLE9BQU8sY0FBZTtBQUMxQixTQUFPLGdCQUFnQjtBQUN2QixRQUFNLEtBQUs7QUFDWCxzQkFBb0I7QUFBQSxJQUNuQixJQUFJLHNCQUFzQixLQUFLLE1BQU0sS0FBSztBQUFBLElBQzFDLE9BQU87QUFBQSxJQUNQLGFBQWE7QUFBQSxJQUNiLFVBQVU7QUFBQSxJQUNWLE1BQU07QUFBQSxJQUNOLHFCQUFxQixDQUFDLFNBQVM7QUFBQSxJQUMvQjtBQUFBLEVBQ0QsR0FBRyxDQUFDLFFBQVE7QUFDWCxRQUFJLEdBQUcsaUJBQWlCLENBQUMsWUFBWTtBQUNwQyxVQUFJLFFBQVEsYUFBYyxTQUFRLGFBQWEsTUFBTSxLQUFLO0FBQUEsUUFDekQsTUFBTTtBQUFBLFFBQ04sS0FBSztBQUFBLFFBQ0wsVUFBVTtBQUFBLFFBQ1YsT0FBTyxvQkFBb0IsT0FBTyxhQUFhLE9BQU8sZUFBZTtBQUFBLE1BQ3RFLENBQUM7QUFBQSxJQUNGLENBQUM7QUFDRCxRQUFJLEdBQUcsbUJBQW1CLENBQUMsRUFBRSxVQUFVLE1BQU0sa0JBQWtCLE1BQU07QUFDcEUsVUFBSSxrQkFBa0IsZ0JBQWdCO0FBQ3JDLGNBQU0sT0FBTyxrQkFBa0I7QUFDL0IsYUFBSyxLQUFLLEtBQUs7QUFBQSxVQUNkLFFBQVEsS0FBSyxPQUFPLEdBQUcsS0FBSyxLQUFLLFNBQVMsQ0FBQyxPQUFPLE1BQU0sS0FBSztBQUFBLFVBQzdELFdBQVc7QUFBQSxVQUNYLFNBQVM7QUFBQSxVQUNULGlCQUFpQjtBQUFBLFFBQ2xCLENBQUM7QUFBQSxNQUNGO0FBQ0EsVUFBSSxRQUFRLGtCQUFrQixjQUFjLEdBQUc7QUFDOUMsMEJBQWtCLGdCQUFnQjtBQUNsQywwQkFBa0IsZUFBZSxRQUFRLENBQUMsaUJBQWlCO0FBQzFELGNBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsY0FBSSxrQkFBa0I7QUFDdEIsY0FBSSxVQUFVO0FBQ2QsY0FBSSxZQUFZO0FBQ2hCLGNBQUksYUFBYSxPQUFPO0FBQ3ZCLG9CQUFRLGFBQWE7QUFDckIsOEJBQWtCO0FBQ2xCLHdCQUFZO0FBQUEsVUFDYixXQUFXLGFBQWEsZUFBZTtBQUN0Qyw4QkFBa0I7QUFDbEIsc0JBQVU7QUFBQSxVQUNYLFdBQVcsYUFBYSxVQUFVO0FBQ2pDLDhCQUFrQjtBQUNsQixzQkFBVTtBQUFBLFVBQ1g7QUFDQSxlQUFLLEtBQUssS0FBSztBQUFBLFlBQ2Q7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNELENBQUM7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNGO0FBQUEsSUFDRCxDQUFDO0FBQ0QsVUFBTSxPQUFPLGNBQWMsTUFBTTtBQUNoQyx3QkFBa0I7QUFDbEIsVUFBSSxzQkFBc0I7QUFDMUIsVUFBSSxrQkFBa0IsaUJBQWlCO0FBQ3ZDLFVBQUksbUJBQW1CLGlCQUFpQjtBQUFBLElBQ3pDLENBQUM7QUFDRCxVQUFNLHFCQUFxQix3QkFBd0I7QUFDbkQsUUFBSSxpQkFBaUI7QUFBQSxNQUNwQixJQUFJO0FBQUEsTUFDSixPQUFPLFNBQVMsS0FBSyxNQUFNLEtBQUssRUFBRTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxJQUNSLENBQUM7QUFDRCxXQUFPLFFBQVEsQ0FBQyxPQUFPLE9BQU87QUFDN0IsVUFBSSxpQkFBaUI7QUFBQSxRQUNwQixTQUFTO0FBQUEsUUFDVCxPQUFPO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxVQUFVLEdBQUc7QUFBQSxVQUNiLFNBQVM7QUFBQSxVQUNULE1BQU0sSUFBSSxJQUFJO0FBQUEsVUFDZCxNQUFNLEVBQUUsTUFBTTtBQUFBLFVBQ2QsU0FBUyxHQUFHLEtBQUs7QUFBQSxRQUNsQjtBQUFBLE1BQ0QsQ0FBQztBQUFBLElBQ0YsQ0FBQztBQUNELFFBQUksZUFBZTtBQUNuQixXQUFPLFdBQVcsQ0FBQyxJQUFJLFNBQVM7QUFDL0IsWUFBTSxPQUFPO0FBQUEsUUFDWixPQUFPLGNBQWMsWUFBWTtBQUFBLFFBQ2pDLE1BQU0sb0JBQW9CLE1BQU0seUNBQXlDO0FBQUEsUUFDekUsSUFBSSxvQkFBb0IsSUFBSSxpQkFBaUI7QUFBQSxNQUM5QztBQUNBLGFBQU8sZUFBZSxHQUFHLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxlQUFlLENBQUM7QUFDMUUsVUFBSSxpQkFBaUI7QUFBQSxRQUNwQixTQUFTO0FBQUEsUUFDVCxPQUFPO0FBQUEsVUFDTixNQUFNLElBQUksSUFBSTtBQUFBLFVBQ2QsT0FBTztBQUFBLFVBQ1AsVUFBVSxHQUFHO0FBQUEsVUFDYjtBQUFBLFVBQ0EsU0FBUyxHQUFHLEtBQUs7QUFBQSxRQUNsQjtBQUFBLE1BQ0QsQ0FBQztBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU8sVUFBVSxDQUFDLElBQUksTUFBTSxZQUFZO0FBQ3ZDLFlBQU0sT0FBTyxFQUFFLE9BQU8sY0FBYyxXQUFXLEVBQUU7QUFDakQsVUFBSSxTQUFTO0FBQ1osYUFBSyxVQUFVLEVBQUUsU0FBUztBQUFBLFVBQ3pCLE1BQU07QUFBQSxVQUNOLFVBQVU7QUFBQSxVQUNWLFNBQVMsVUFBVSxRQUFRLFVBQVU7QUFBQSxVQUNyQyxTQUFTO0FBQUEsVUFDVCxPQUFPO0FBQUEsUUFDUixFQUFFO0FBQ0YsYUFBSyxTQUFTLGNBQWMsR0FBRztBQUFBLE1BQ2hDLE1BQU8sTUFBSyxTQUFTLGNBQWMsR0FBRztBQUN0QyxXQUFLLE9BQU8sb0JBQW9CLE1BQU0seUNBQXlDO0FBQy9FLFdBQUssS0FBSyxvQkFBb0IsSUFBSSxpQkFBaUI7QUFDbkQsVUFBSSxpQkFBaUI7QUFBQSxRQUNwQixTQUFTO0FBQUEsUUFDVCxPQUFPO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxVQUFVLEdBQUc7QUFBQSxVQUNiLE1BQU0sSUFBSSxJQUFJO0FBQUEsVUFDZDtBQUFBLFVBQ0EsU0FBUyxVQUFVLFlBQVk7QUFBQSxVQUMvQixTQUFTLEdBQUcsS0FBSztBQUFBLFFBQ2xCO0FBQUEsTUFDRCxDQUFDO0FBQUEsSUFDRixDQUFDO0FBSUQsVUFBTSxvQkFBb0Isc0JBQXNCO0FBQ2hELFFBQUksYUFBYTtBQUFBLE1BQ2hCLElBQUk7QUFBQSxNQUNKLE9BQU8sWUFBWSxLQUFLLE1BQU0sS0FBSztBQUFBLE1BQ25DLE1BQU07QUFBQSxNQUNOLHVCQUF1QjtBQUFBLElBQ3hCLENBQUM7QUFDRCxhQUFTLG9CQUFvQjtBQUM1QixVQUFJLENBQUMsb0JBQXFCO0FBQzFCLFlBQU0sVUFBVTtBQUNoQixVQUFJLFNBQVMsUUFBUSxVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLFVBQVUsQ0FBQyxNQUFNLE9BQU8sT0FBTyxVQUFVO0FBQ25HLGFBQU8sUUFBUSw0QkFBNEI7QUFDM0MsVUFBSSxRQUFRLE9BQVEsVUFBUyxPQUFPLE9BQU8sQ0FBQyxVQUFVLGdCQUFnQixPQUFPLFFBQVEsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMxRyxhQUFPLFFBQVEsQ0FBQyxVQUFVLHNCQUFzQixPQUFPLE9BQU8sYUFBYSxLQUFLLENBQUM7QUFDakYsY0FBUSxZQUFZLE9BQU8sSUFBSSw2QkFBNkI7QUFBQSxJQUM3RDtBQUNBLFFBQUk7QUFDSixRQUFJLEdBQUcsaUJBQWlCLENBQUMsWUFBWTtBQUNwQyw0QkFBc0I7QUFDdEIsVUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLGdCQUFnQixrQkFBbUIsbUJBQWtCO0FBQUEsSUFDekYsQ0FBQztBQUlELFFBQUksR0FBRyxrQkFBa0IsQ0FBQyxZQUFZO0FBQ3JDLFVBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxnQkFBZ0IsbUJBQW1CO0FBQ3JFLGNBQU0sUUFBUSxRQUFRLFVBQVUsRUFBRSxLQUFLLENBQUNDLFdBQVVBLE9BQU0sT0FBTyxZQUFZLFFBQVEsTUFBTTtBQUN6RixZQUFJLE1BQU8sU0FBUSxRQUFRLEVBQUUsU0FBUywwQ0FBMEMsS0FBSyxFQUFFO0FBQUEsTUFDeEY7QUFBQSxJQUNELENBQUM7QUFDRCxRQUFJLGtCQUFrQixpQkFBaUI7QUFDdkMsUUFBSSxtQkFBbUIsaUJBQWlCO0FBQUEsRUFDekMsQ0FBQztBQUNGO0FBQ0EsU0FBUyxlQUFlLEtBQUs7QUFDNUIsTUFBSSxJQUFJLFNBQVUsUUFBTyxJQUFJLGFBQWEsTUFBTTtBQUFBLE1BQzNDLFFBQU8sSUFBSSxhQUFhLE1BQU07QUFDcEM7QUFDQSxTQUFTLDBDQUEwQyxPQUFPO0FBQ3pELFFBQU0sRUFBRSxPQUFPLElBQUk7QUFDbkIsUUFBTSxTQUFTLENBQUM7QUFBQSxJQUNmLFVBQVU7QUFBQSxJQUNWLEtBQUs7QUFBQSxJQUNMLE9BQU8sT0FBTztBQUFBLEVBQ2YsQ0FBQztBQUNELE1BQUksT0FBTyxRQUFRLEtBQU0sUUFBTyxLQUFLO0FBQUEsSUFDcEMsVUFBVTtBQUFBLElBQ1YsS0FBSztBQUFBLElBQ0wsT0FBTyxPQUFPO0FBQUEsRUFDZixDQUFDO0FBQ0QsU0FBTyxLQUFLO0FBQUEsSUFDWCxVQUFVO0FBQUEsSUFDVixLQUFLO0FBQUEsSUFDTCxPQUFPLE1BQU07QUFBQSxFQUNkLENBQUM7QUFDRCxNQUFJLE1BQU0sS0FBSyxPQUFRLFFBQU8sS0FBSztBQUFBLElBQ2xDLFVBQVU7QUFBQSxJQUNWLEtBQUs7QUFBQSxJQUNMLE9BQU8sRUFBRSxTQUFTO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sVUFBVTtBQUFBLE1BQ1YsU0FBUyxNQUFNLEtBQUssSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLElBQUksR0FBRyxlQUFlLEdBQUcsQ0FBQyxFQUFFLEVBQUUsS0FBSyxHQUFHO0FBQUEsTUFDOUUsU0FBUztBQUFBLE1BQ1QsT0FBTyxNQUFNO0FBQUEsSUFDZCxFQUFFO0FBQUEsRUFDSCxDQUFDO0FBQ0QsTUFBSSxPQUFPLFlBQVksS0FBTSxRQUFPLEtBQUs7QUFBQSxJQUN4QyxVQUFVO0FBQUEsSUFDVixLQUFLO0FBQUEsSUFDTCxPQUFPLE9BQU87QUFBQSxFQUNmLENBQUM7QUFDRCxNQUFJLE1BQU0sTUFBTSxPQUFRLFFBQU8sS0FBSztBQUFBLElBQ25DLFVBQVU7QUFBQSxJQUNWLEtBQUs7QUFBQSxJQUNMLE9BQU8sTUFBTSxNQUFNLElBQUksQ0FBQyxVQUFVLE1BQU0sT0FBTyxJQUFJO0FBQUEsRUFDcEQsQ0FBQztBQUNELE1BQUksT0FBTyxLQUFLLE1BQU0sT0FBTyxJQUFJLEVBQUUsT0FBUSxRQUFPLEtBQUs7QUFBQSxJQUN0RCxVQUFVO0FBQUEsSUFDVixLQUFLO0FBQUEsSUFDTCxPQUFPLE1BQU0sT0FBTztBQUFBLEVBQ3JCLENBQUM7QUFDRCxTQUFPLEtBQUs7QUFBQSxJQUNYLEtBQUs7QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLE9BQU8sRUFBRSxTQUFTO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sVUFBVTtBQUFBLE1BQ1YsU0FBUyxNQUFNLE1BQU0sSUFBSSxDQUFDLFVBQVUsTUFBTSxLQUFLLElBQUksQ0FBQyxFQUFFLEtBQUssS0FBSztBQUFBLE1BQ2hFLFNBQVM7QUFBQSxNQUNULE9BQU8sTUFBTTtBQUFBLElBQ2QsRUFBRTtBQUFBLEVBQ0gsQ0FBQztBQUNELFNBQU87QUFDUjtBQUlBLE1BQU0sV0FBVztBQUNqQixNQUFNLFdBQVc7QUFDakIsTUFBTSxXQUFXO0FBQ2pCLE1BQU0sV0FBVztBQUNqQixNQUFNLGFBQWE7QUFDbkIsTUFBTSxPQUFPO0FBQ2IsTUFBTSxVQUFVO0FBQ2hCLE1BQU0sVUFBVTtBQUNoQixTQUFTLDhCQUE4QixPQUFPO0FBQzdDLFFBQU0sT0FBTyxDQUFDO0FBQ2QsUUFBTSxFQUFFLE9BQU8sSUFBSTtBQUNuQixNQUFJLE9BQU8sUUFBUSxLQUFNLE1BQUssS0FBSztBQUFBLElBQ2xDLE9BQU8sT0FBTyxPQUFPLElBQUk7QUFBQSxJQUN6QixXQUFXO0FBQUEsSUFDWCxpQkFBaUI7QUFBQSxFQUNsQixDQUFDO0FBQ0QsTUFBSSxPQUFPLFFBQVMsTUFBSyxLQUFLO0FBQUEsSUFDN0IsT0FBTztBQUFBLElBQ1AsV0FBVztBQUFBLElBQ1gsaUJBQWlCO0FBQUEsRUFDbEIsQ0FBQztBQUNELE1BQUksTUFBTSxXQUFZLE1BQUssS0FBSztBQUFBLElBQy9CLE9BQU87QUFBQSxJQUNQLFdBQVc7QUFBQSxJQUNYLGlCQUFpQjtBQUFBLEVBQ2xCLENBQUM7QUFDRCxNQUFJLE1BQU0saUJBQWtCLE1BQUssS0FBSztBQUFBLElBQ3JDLE9BQU87QUFBQSxJQUNQLFdBQVc7QUFBQSxJQUNYLGlCQUFpQjtBQUFBLEVBQ2xCLENBQUM7QUFDRCxNQUFJLE1BQU0sWUFBYSxNQUFLLEtBQUs7QUFBQSxJQUNoQyxPQUFPO0FBQUEsSUFDUCxXQUFXO0FBQUEsSUFDWCxpQkFBaUI7QUFBQSxFQUNsQixDQUFDO0FBQ0QsTUFBSSxPQUFPLFNBQVUsTUFBSyxLQUFLO0FBQUEsSUFDOUIsT0FBTyxPQUFPLE9BQU8sYUFBYSxXQUFXLGFBQWEsT0FBTyxRQUFRLEtBQUs7QUFBQSxJQUM5RSxXQUFXO0FBQUEsSUFDWCxpQkFBaUI7QUFBQSxFQUNsQixDQUFDO0FBQ0QsTUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBSSxNQUFNLE1BQU07QUFDZixTQUFLLE9BQU8sZUFBZTtBQUMzQixXQUFPLFVBQVU7QUFBQSxFQUNsQjtBQUNBLFNBQU87QUFBQSxJQUNOO0FBQUEsSUFDQSxPQUFPLE9BQU87QUFBQSxJQUNkO0FBQUEsSUFDQSxVQUFVLE1BQU0sU0FBUyxJQUFJLDZCQUE2QjtBQUFBLEVBQzNEO0FBQ0Q7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQixNQUFNLG9CQUFvQjtBQUMxQixTQUFTLHNCQUFzQixPQUFPLGNBQWM7QUFDbkQsUUFBTSxnQkFBZ0IsYUFBYSxRQUFRLFVBQVUsa0JBQWtCLGFBQWEsUUFBUSxhQUFhLFFBQVEsU0FBUyxDQUFDLEdBQUcsTUFBTSxNQUFNO0FBQzFJLFFBQU0sbUJBQW1CLE1BQU0sY0FBYztBQUM3QyxNQUFJLENBQUMsY0FBZSxPQUFNLGNBQWMsYUFBYSxRQUFRLEtBQUssQ0FBQyxVQUFVLGtCQUFrQixPQUFPLE1BQU0sTUFBTSxDQUFDO0FBQ25ILFFBQU0sU0FBUyxRQUFRLENBQUMsZUFBZSxzQkFBc0IsWUFBWSxZQUFZLENBQUM7QUFDdkY7QUFDQSxTQUFTLDZCQUE2QixPQUFPO0FBQzVDLFFBQU0sYUFBYTtBQUNuQixRQUFNLFNBQVMsUUFBUSw0QkFBNEI7QUFDcEQ7QUFDQSxTQUFTLGdCQUFnQixPQUFPLFFBQVE7QUFDdkMsUUFBTSxRQUFRLE9BQU8sTUFBTSxFQUFFLEVBQUUsTUFBTSxpQkFBaUI7QUFDdEQsUUFBTSxhQUFhO0FBQ25CLE1BQUksQ0FBQyxTQUFTLE1BQU0sU0FBUyxFQUFHLFFBQU87QUFDdkMsTUFBSSxJQUFJLE9BQU8sTUFBTSxDQUFDLEVBQUUsUUFBUSxPQUFPLEVBQUUsR0FBRyxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssTUFBTSxHQUFHO0FBQ25FLFVBQU0sU0FBUyxRQUFRLENBQUMsVUFBVSxnQkFBZ0IsT0FBTyxNQUFNLENBQUM7QUFDaEUsUUFBSSxNQUFNLE9BQU8sU0FBUyxPQUFPLFdBQVcsS0FBSztBQUNoRCxZQUFNLGFBQWEsTUFBTSxHQUFHLEtBQUssTUFBTTtBQUN2QyxhQUFPO0FBQUEsSUFDUjtBQUNBLFdBQU87QUFBQSxFQUNSO0FBQ0EsUUFBTSxPQUFPLE1BQU0sT0FBTyxLQUFLLFlBQVk7QUFDM0MsUUFBTSxjQUFjLE9BQU8sSUFBSTtBQUMvQixNQUFJLENBQUMsT0FBTyxXQUFXLEdBQUcsTUFBTSxZQUFZLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxNQUFNLEdBQUksUUFBTztBQUMvRixNQUFJLFlBQVksV0FBVyxNQUFNLEtBQUssS0FBSyxXQUFXLE1BQU0sRUFBRyxRQUFPO0FBQ3RFLE1BQUksTUFBTSxPQUFPLFFBQVEsT0FBTyxNQUFNLE9BQU8sSUFBSSxFQUFFLFNBQVMsTUFBTSxFQUFHLFFBQU87QUFDNUUsU0FBTyxNQUFNLFNBQVMsS0FBSyxDQUFDLFVBQVUsZ0JBQWdCLE9BQU8sTUFBTSxDQUFDO0FBQ3JFO0FBQ0EsU0FBUyxLQUFLLEtBQUssTUFBTTtBQUN4QixRQUFNLE1BQU0sQ0FBQztBQUNiLGFBQVcsT0FBTyxJQUFLLEtBQUksQ0FBQyxLQUFLLFNBQVMsR0FBRyxFQUFHLEtBQUksR0FBRyxJQUFJLElBQUksR0FBRztBQUNsRSxTQUFPO0FBQ1I7QUFFQSxTQUFTLFdBQVcsR0FBRyx1QkFBdUIsR0FBRyx1QkFBdUIsR0FBRyxZQUFZLEdBQUcsVUFBVSxHQUFHLGNBQWMsR0FBRyxlQUFlLEdBQUcsZ0JBQWdCLEdBQUcsY0FBYyxHQUFHLDZCQUE2QixHQUFHLHFCQUFxQixHQUFHLHNCQUFzQixHQUFHLHFCQUFxQixHQUFHLGlCQUFpQixHQUFHLGdCQUFnQixHQUFHLGtCQUFrQixHQUFHLG1CQUFtQixHQUFHLGdCQUFnQixHQUFHLDBCQUEwQixHQUFHLG9CQUFvQixHQUFHLFVBQVUsR0FBRyxhQUFhLEdBQUcsa0JBQWtCLEdBQUcseUJBQXlCLEdBQUcsMEJBQTBCLEdBQUcsc0JBQXNCLEdBQUcsZUFBZSxHQUFHLDJCQUEyQixHQUFHLHVCQUF1QixHQUFHLGVBQWUsR0FBRyxjQUFjLEdBQUcsb0JBQW9CLEdBQUcsNkJBQTZCLEdBQUcsb0JBQW9CLEdBQUcsY0FBYzsiLCJuYW1lcyI6WyJwYXJzZVF1ZXJ5Iiwic3RyaW5naWZ5UXVlcnkiLCJ2YWx1ZSIsInJvdXRlIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=