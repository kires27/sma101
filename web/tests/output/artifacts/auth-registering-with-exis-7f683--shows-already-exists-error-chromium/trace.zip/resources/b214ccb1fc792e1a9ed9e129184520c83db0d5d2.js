import { injectQuery as __vite__injectQuery } from "/_nuxt/@vite/client";import { FunctionRegion, FunctionsClient, FunctionsError, FunctionsFetchError, FunctionsHttpError, FunctionsRelayError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+functions-js@2.108.1/node_modules/@supabase/functions-js/dist/module/index.js?v=583078ff";
import { PostgrestClient, PostgrestError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+postgrest-js@2.108.1/node_modules/@supabase/postgrest-js/dist/index.mjs?v=583078ff";
import { RealtimeClient } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/index.js?v=583078ff";
import { StorageApiError, StorageClient } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+storage-js@2.108.1/node_modules/@supabase/storage-js/dist/index.mjs?v=583078ff";
import { AuthClient } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/index.js?v=583078ff";

export * from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/index.js?v=583078ff"

export * from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/index.js?v=583078ff"

//#region src/lib/version.ts
const version = "2.108.1";

//#endregion
//#region src/lib/constants.ts
let JS_ENV = "";
let JS_RUNTIME_VERSION;
if (typeof Deno !== "undefined") {
	var _Deno$version;
	JS_ENV = "deno";
	JS_RUNTIME_VERSION = (_Deno$version = Deno.version) === null || _Deno$version === void 0 ? void 0 : _Deno$version.deno;
} else if (typeof document !== "undefined") JS_ENV = "web";
else if (typeof navigator !== "undefined" && navigator.product === "ReactNative") JS_ENV = "react-native";
else {
	var _process$version;
	JS_ENV = "node";
	JS_RUNTIME_VERSION = typeof process !== "undefined" ? (_process$version = process.version) === null || _process$version === void 0 ? void 0 : _process$version.replace(/^v/, "") : void 0;
}
const _runtimeMeta = [`runtime=${JS_ENV}`];
if (JS_RUNTIME_VERSION) _runtimeMeta.push(`runtime-version=${JS_RUNTIME_VERSION}`);
const DEFAULT_HEADERS = { "X-Client-Info": `supabase-js/${version}; ${_runtimeMeta.join("; ")}` };
const DEFAULT_GLOBAL_OPTIONS = { headers: DEFAULT_HEADERS };
const DEFAULT_DB_OPTIONS = { schema: "public" };
const DEFAULT_AUTH_OPTIONS = {
	autoRefreshToken: true,
	persistSession: true,
	detectSessionInUrl: true,
	flowType: "implicit"
};
const DEFAULT_REALTIME_OPTIONS = {};
const DEFAULT_TRACE_PROPAGATION_OPTIONS = {
	enabled: false,
	respectSamplingDecision: true
};

//#endregion
//#region ../../../node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs
function __awaiter(thisArg, _arguments, P, generator) {
	function adopt(value) {
		return value instanceof P ? value : new P(function(resolve) {
			resolve(value);
		});
	}
	return new (P || (P = Promise))(function(resolve, reject) {
		function fulfilled(value) {
			try {
				step(generator.next(value));
			} catch (e) {
				reject(e);
			}
		}
		function rejected(value) {
			try {
				step(generator["throw"](value));
			} catch (e) {
				reject(e);
			}
		}
		function step(result) {
			result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
		}
		step((generator = generator.apply(thisArg, _arguments || [])).next());
	});
}

//#endregion
//#region ../../shared/tracing/dist/module/extract.js
let otelModulePromise = null;
const OTEL_PKG = "@opentelemetry/api";
function loadOtel() {
	if (otelModulePromise === null) otelModulePromise = import(/* webpackIgnore: true */ /* turbopackIgnore: true */ /* @vite-ignore */ __vite__injectQuery(OTEL_PKG, 'import')).catch(() => null);
	return otelModulePromise;
}
/**
* Extract trace context from the OpenTelemetry API.
*
* Returns null if `@opentelemetry/api` is not installed or there is no active
* trace context. The dynamic import is cached after the first call.
*
* @returns Trace context with traceparent, tracestate, and baggage headers, or null if unavailable
*/
function extractTraceContext() {
	return __awaiter(this, void 0, void 0, function* () {
		try {
			const otel = yield loadOtel();
			if (!otel || !otel.propagation || !otel.context) return null;
			const carrier = {};
			otel.propagation.inject(otel.context.active(), carrier);
			const traceparent = carrier["traceparent"];
			if (!traceparent) return null;
			return {
				traceparent,
				tracestate: carrier["tracestate"],
				baggage: carrier["baggage"]
			};
		} catch (_a) {
			return null;
		}
	});
}

//#endregion
//#region ../../shared/tracing/dist/module/parse.js
/**
* Parse W3C traceparent header according to the specification.
*
* The traceparent header format is: version-traceid-parentid-traceflags
* - version: 2 hex digits (currently always "00")
* - traceid: 32 hex digits (128-bit trace identifier)
* - parentid: 16 hex digits (64-bit span/parent identifier)
* - traceflags: 2 hex digits (8-bit flags, bit 0 is sampled flag)
*
* @param traceparent - The traceparent header value
* @returns Parsed traceparent object, or null if invalid format
*
* @see https://www.w3.org/TR/trace-context/#traceparent-header
*
* @example
* ```typescript
* const parsed = parseTraceParent('00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01')
*
* console.log(parsed)
* // {
* //   version: '00',
* //   traceId: '0af7651916cd43dd8448eb211c80319c',
* //   parentId: 'b7ad6b7169203331',
* //   traceFlags: '01',
* //   isSampled: true
* // }
* ```
*/
function parseTraceParent(traceparent) {
	if (!traceparent || typeof traceparent !== "string") return null;
	const parts = traceparent.split("-");
	if (parts.length !== 4) return null;
	const [version$1, traceId, parentId, traceFlags] = parts;
	if (version$1.length !== 2 || traceId.length !== 32 || parentId.length !== 16 || traceFlags.length !== 2) return null;
	const hexRegex = /^[0-9a-f]+$/i;
	if (!hexRegex.test(version$1) || !hexRegex.test(traceId) || !hexRegex.test(parentId) || !hexRegex.test(traceFlags)) return null;
	if (traceId === "00000000000000000000000000000000" || parentId === "0000000000000000") return null;
	return {
		version: version$1,
		traceId,
		parentId,
		traceFlags,
		isSampled: (parseInt(traceFlags, 16) & 1) === 1
	};
}

//#endregion
//#region ../../shared/tracing/dist/module/validate.js
/**
* Check if trace context should be propagated to the target URL.
*
* This function checks if the target URL matches any of the configured
* propagation targets. Targets can be:
* - String: Exact hostname match or wildcard domain (*.example.com)
* - RegExp: Pattern matching hostname
* - Function: Custom logic to determine if URL should receive trace context
*
* @param targetUrl - The URL to check
* @param targets - Array of propagation targets
* @returns True if trace context should be propagated, false otherwise
*
* @example
* ```typescript
* const targets = [
*   'myproject.supabase.co',           // Exact match
*   '*.supabase.co',                   // Wildcard domain
*   /.*\.supabase\.co$/,               // Regex pattern
*   (url) => url.hostname === 'localhost' // Custom function
* ]
*
* shouldPropagateToTarget('https://myproject.supabase.co/rest/v1/table', targets)
* // true
*
* shouldPropagateToTarget('https://evil.com/api', targets)
* // false
* ```
*/
function shouldPropagateToTarget(targetUrl, targets) {
	if (!targetUrl || !targets || targets.length === 0) return false;
	let url;
	if (targetUrl instanceof URL) url = targetUrl;
	else try {
		url = new URL(targetUrl);
	} catch (error) {
		return false;
	}
	for (const target of targets) try {
		if (typeof target === "string") {
			if (matchStringTarget(url.hostname, target)) return true;
		} else if (target instanceof RegExp) {
			if (target.test(url.hostname)) return true;
		} else if (typeof target === "function") {
			if (target(url)) return true;
		}
	} catch (error) {
		continue;
	}
	return false;
}
/**
* Match hostname against string target (exact match or wildcard)
*
* @param hostname - The hostname to check
* @param target - The target pattern (exact or wildcard)
* @returns True if hostname matches target
*/
function matchStringTarget(hostname, target) {
	if (target === hostname) return true;
	if (target.startsWith("*.")) {
		const domain = target.slice(2);
		if (hostname.endsWith(domain)) {
			if (hostname === domain || hostname.endsWith("." + domain)) return true;
		}
	}
	return false;
}

//#endregion
//#region ../../shared/tracing/dist/module/defaults.js
/**
* Generate default propagation targets based on the Supabase project URL.
*
* By default, trace context is only propagated to Supabase domains for
* security. This prevents leaking trace context to potentially malicious
* third-party services.
*
* Wildcard strings (e.g. `*.supabase.co`) are matched with linear string
* operations rather than regex, avoiding ReDoS risk.
*
* @param supabaseUrl - The Supabase project URL
* @returns Array of default propagation targets
*/
function getDefaultPropagationTargets(supabaseUrl) {
	const targets = [];
	try {
		const url = new URL(supabaseUrl);
		targets.push(url.hostname);
	} catch (error) {}
	targets.push("*.supabase.co", "*.supabase.in");
	targets.push("localhost", "127.0.0.1", "[::1]");
	return targets;
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/typeof.js
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o$1) {
		return typeof o$1;
	} : function(o$1) {
		return o$1 && "function" == typeof Symbol && o$1.constructor === Symbol && o$1 !== Symbol.prototype ? "symbol" : typeof o$1;
	}, _typeof(o);
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/toPrimitive.js
function toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/toPropertyKey.js
function toPropertyKey(t) {
	var i = toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/defineProperty.js
function _defineProperty(e, r, t) {
	return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/objectSpread2.js
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r$1) {
			return Object.getOwnPropertyDescriptor(e, r$1).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r$1) {
			_defineProperty(e, r$1, t[r$1]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r$1) {
			Object.defineProperty(e, r$1, Object.getOwnPropertyDescriptor(t, r$1));
		});
	}
	return e;
}

//#endregion
//#region src/lib/fetch.ts
const resolveFetch = (customFetch) => {
	if (customFetch) return (...args) => customFetch(...args);
	return (...args) => fetch(...args);
};
const resolveHeadersConstructor = () => {
	return Headers;
};
const fetchWithAuth = (supabaseKey, supabaseUrl, getAccessToken, customFetch, tracePropagationOptions) => {
	const fetch$1 = resolveFetch(customFetch);
	const HeadersConstructor = resolveHeadersConstructor();
	const traceEnabled = (tracePropagationOptions === null || tracePropagationOptions === void 0 ? void 0 : tracePropagationOptions.enabled) === true;
	const respectSampling = (tracePropagationOptions === null || tracePropagationOptions === void 0 ? void 0 : tracePropagationOptions.respectSamplingDecision) !== false;
	const traceTargets = traceEnabled ? getDefaultPropagationTargets(supabaseUrl) : null;
	return async (input, init) => {
		var _await$getAccessToken;
		const accessToken = (_await$getAccessToken = await getAccessToken()) !== null && _await$getAccessToken !== void 0 ? _await$getAccessToken : supabaseKey;
		let headers = new HeadersConstructor(init === null || init === void 0 ? void 0 : init.headers);
		if (!headers.has("apikey")) headers.set("apikey", supabaseKey);
		if (!headers.has("Authorization")) headers.set("Authorization", `Bearer ${accessToken}`);
		if (traceTargets) {
			const traceHeaders = await getTraceHeaders(input, traceTargets, respectSampling);
			if (traceHeaders) {
				if (traceHeaders.traceparent && !headers.has("traceparent")) headers.set("traceparent", traceHeaders.traceparent);
				if (traceHeaders.tracestate && !headers.has("tracestate")) headers.set("tracestate", traceHeaders.tracestate);
				if (traceHeaders.baggage && !headers.has("baggage")) headers.set("baggage", traceHeaders.baggage);
			}
		}
		return fetch$1(input, _objectSpread2(_objectSpread2({}, init), {}, { headers }));
	};
};
async function getTraceHeaders(input, targets, respectSampling) {
	if (!shouldPropagateToTarget(typeof input === "string" ? input : input instanceof URL ? input : input.url, targets)) return null;
	const traceContext = await extractTraceContext();
	if (!traceContext || !traceContext.traceparent) return null;
	if (respectSampling) {
		const parsed = parseTraceParent(traceContext.traceparent);
		if (parsed && !parsed.isSampled) return null;
	}
	return traceContext;
}

//#endregion
//#region src/lib/helpers.ts
function normalizeTracePropagation(value) {
	return typeof value === "boolean" ? { enabled: value } : value;
}
function ensureTrailingSlash(url) {
	return url.endsWith("/") ? url : url + "/";
}
function applySettingDefaults(options, defaults) {
	var _DEFAULT_GLOBAL_OPTIO, _globalOptions$header, _ref, _tracePropagationOpti, _ref2, _tracePropagationOpti2;
	const { db: dbOptions, auth: authOptions, realtime: realtimeOptions, global: globalOptions } = options;
	const { db: DEFAULT_DB_OPTIONS$1, auth: DEFAULT_AUTH_OPTIONS$1, realtime: DEFAULT_REALTIME_OPTIONS$1, global: DEFAULT_GLOBAL_OPTIONS$1 } = defaults;
	const tracePropagationOptions = normalizeTracePropagation(options.tracePropagation);
	const DEFAULT_TRACE_PROPAGATION_OPTIONS$1 = normalizeTracePropagation(defaults.tracePropagation);
	const result = {
		db: _objectSpread2(_objectSpread2({}, DEFAULT_DB_OPTIONS$1), dbOptions),
		auth: _objectSpread2(_objectSpread2({}, DEFAULT_AUTH_OPTIONS$1), authOptions),
		realtime: _objectSpread2(_objectSpread2({}, DEFAULT_REALTIME_OPTIONS$1), realtimeOptions),
		storage: {},
		global: _objectSpread2(_objectSpread2(_objectSpread2({}, DEFAULT_GLOBAL_OPTIONS$1), globalOptions), {}, { headers: _objectSpread2(_objectSpread2({}, (_DEFAULT_GLOBAL_OPTIO = DEFAULT_GLOBAL_OPTIONS$1 === null || DEFAULT_GLOBAL_OPTIONS$1 === void 0 ? void 0 : DEFAULT_GLOBAL_OPTIONS$1.headers) !== null && _DEFAULT_GLOBAL_OPTIO !== void 0 ? _DEFAULT_GLOBAL_OPTIO : {}), (_globalOptions$header = globalOptions === null || globalOptions === void 0 ? void 0 : globalOptions.headers) !== null && _globalOptions$header !== void 0 ? _globalOptions$header : {}) }),
		tracePropagation: {
			enabled: (_ref = (_tracePropagationOpti = tracePropagationOptions === null || tracePropagationOptions === void 0 ? void 0 : tracePropagationOptions.enabled) !== null && _tracePropagationOpti !== void 0 ? _tracePropagationOpti : DEFAULT_TRACE_PROPAGATION_OPTIONS$1 === null || DEFAULT_TRACE_PROPAGATION_OPTIONS$1 === void 0 ? void 0 : DEFAULT_TRACE_PROPAGATION_OPTIONS$1.enabled) !== null && _ref !== void 0 ? _ref : false,
			respectSamplingDecision: (_ref2 = (_tracePropagationOpti2 = tracePropagationOptions === null || tracePropagationOptions === void 0 ? void 0 : tracePropagationOptions.respectSamplingDecision) !== null && _tracePropagationOpti2 !== void 0 ? _tracePropagationOpti2 : DEFAULT_TRACE_PROPAGATION_OPTIONS$1 === null || DEFAULT_TRACE_PROPAGATION_OPTIONS$1 === void 0 ? void 0 : DEFAULT_TRACE_PROPAGATION_OPTIONS$1.respectSamplingDecision) !== null && _ref2 !== void 0 ? _ref2 : true
		},
		accessToken: async () => ""
	};
	if (options.accessToken) result.accessToken = options.accessToken;
	else delete result.accessToken;
	return result;
}
/**
* Validates a Supabase client URL
*
* @param {string} supabaseUrl - The Supabase client URL string.
* @returns {URL} - The validated base URL.
* @throws {Error}
*/
function validateSupabaseUrl(supabaseUrl) {
	const trimmedUrl = supabaseUrl === null || supabaseUrl === void 0 ? void 0 : supabaseUrl.trim();
	if (!trimmedUrl) throw new Error("supabaseUrl is required.");
	if (!trimmedUrl.match(/^https?:\/\//i)) throw new Error("Invalid supabaseUrl: Must be a valid HTTP or HTTPS URL.");
	try {
		return new URL(ensureTrailingSlash(trimmedUrl));
	} catch (_unused) {
		throw Error("Invalid supabaseUrl: Provided URL is malformed.");
	}
}

//#endregion
//#region src/lib/SupabaseAuthClient.ts
var SupabaseAuthClient = class extends AuthClient {
	constructor(options) {
		super(options);
	}
};

//#endregion
//#region src/SupabaseClient.ts
/**
* Supabase Client.
*
* An isomorphic Javascript client for interacting with Postgres.
*/
var SupabaseClient = class {
	/**
	* Create a new client for use in the browser.
	*
	* @category Initializing
	*
	* @param supabaseUrl The unique Supabase URL which is supplied when you create a new project in your project dashboard.
	* @param supabaseKey The unique Supabase Key which is supplied when you create a new project in your project dashboard.
	* @param options.db.schema You can switch in between schemas. The schema needs to be on the list of exposed schemas inside Supabase.
	* @param options.auth.autoRefreshToken Set to "true" if you want to automatically refresh the token before expiring.
	* @param options.auth.persistSession Set to "true" if you want to automatically save the user session into local storage.
	* @param options.auth.detectSessionInUrl Set to "true" if you want to automatically detects OAuth grants in the URL and signs in the user.
	* @param options.realtime Options passed along to realtime-js constructor.
	* @param options.storage Options passed along to the storage-js constructor.
	* @param options.global.fetch A custom fetch implementation.
	* @param options.global.headers Any additional headers to send with each network request.
	*
	* @example Creating a client
	* ```js
	* import { createClient } from '@supabase/supabase-js'
	*
	* // Create a single supabase client for interacting with your database
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	* ```
	*
	* @example With a custom domain
	* ```js
	* import { createClient } from '@supabase/supabase-js'
	*
	* // Use a custom domain as the supabase URL
	* const supabase = createClient('https://my-custom-domain.com', 'your-publishable-key')
	* ```
	*
	* @example With additional parameters
	* ```js
	* import { createClient } from '@supabase/supabase-js'
	*
	* const options = {
	*   db: {
	*     schema: 'public',
	*   },
	*   auth: {
	*     autoRefreshToken: true,
	*     persistSession: true,
	*     detectSessionInUrl: true
	*   },
	*   global: {
	*     headers: { 'x-my-custom-header': 'my-app-name' },
	*   },
	* }
	* const supabase = createClient("https://xyzcompany.supabase.co", "your-publishable-key", options)
	* ```
	*
	* @exampleDescription With custom schemas
	* By default the API server points to the `public` schema. You can enable other database schemas within the Dashboard.
	* Go to [Settings > API > Exposed schemas](/dashboard/project/_/settings/api) and add the schema which you want to expose to the API.
	*
	* Note: each client connection can only access a single schema, so the code above can access the `other_schema` schema but cannot access the `public` schema.
	*
	* @example With custom schemas
	* ```js
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key', {
	*   // Provide a custom schema. Defaults to "public".
	*   db: { schema: 'other_schema' }
	* })
	* ```
	*
	* @exampleDescription Custom fetch implementation
	* `supabase-js` uses the [`cross-fetch`](https://www.npmjs.com/package/cross-fetch) library to make HTTP requests,
	* but an alternative `fetch` implementation can be provided as an option.
	* This is most useful in environments where `cross-fetch` is not compatible (for instance Cloudflare Workers).
	*
	* @example Custom fetch implementation
	* ```js
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key', {
	*   global: { fetch: fetch.bind(globalThis) }
	* })
	* ```
	*
	* @exampleDescription React Native options with AsyncStorage
	* For React Native we recommend using `AsyncStorage` as the storage implementation for Supabase Auth.
	*
	* @example React Native options with AsyncStorage
	* ```js
	* import 'react-native-url-polyfill/auto'
	* import { createClient } from '@supabase/supabase-js'
	* import AsyncStorage from "@react-native-async-storage/async-storage";
	*
	* const supabase = createClient("https://xyzcompany.supabase.co", "your-publishable-key", {
	*   auth: {
	*     storage: AsyncStorage,
	*     autoRefreshToken: true,
	*     persistSession: true,
	*     detectSessionInUrl: false,
	*   },
	* });
	* ```
	*
	* @exampleDescription React Native options with Expo SecureStore
	* If you wish to encrypt the user's session information, you can use `aes-js` and store the encryption key in Expo SecureStore.
	* The `aes-js` library, a reputable JavaScript-only implementation of the AES encryption algorithm in CTR mode.
	* A new 256-bit encryption key is generated using the `react-native-get-random-values` library.
	* This key is stored inside Expo's SecureStore, while the value is encrypted and placed inside AsyncStorage.
	*
	* Please make sure that:
	* - You keep the `expo-secure-store`, `aes-js` and `react-native-get-random-values` libraries up-to-date.
	* - Choose the correct [`SecureStoreOptions`](https://docs.expo.dev/versions/latest/sdk/securestore/#securestoreoptions) for your app's needs.
	*   E.g. [`SecureStore.WHEN_UNLOCKED`](https://docs.expo.dev/versions/latest/sdk/securestore/#securestorewhen_unlocked) regulates when the data can be accessed.
	* - Carefully consider optimizations or other modifications to the above example, as those can lead to introducing subtle security vulnerabilities.
	*
	* @example React Native options with Expo SecureStore
	* ```ts
	* import 'react-native-url-polyfill/auto'
	* import { createClient } from '@supabase/supabase-js'
	* import AsyncStorage from '@react-native-async-storage/async-storage';
	* import * as SecureStore from 'expo-secure-store';
	* import * as aesjs from 'aes-js';
	* import 'react-native-get-random-values';
	*
	* // As Expo's SecureStore does not support values larger than 2048
	* // bytes, an AES-256 key is generated and stored in SecureStore, while
	* // it is used to encrypt/decrypt values stored in AsyncStorage.
	* class LargeSecureStore {
	*   private async _encrypt(key: string, value: string) {
	*     const encryptionKey = crypto.getRandomValues(new Uint8Array(256 / 8));
	*
	*     const cipher = new aesjs.ModeOfOperation.ctr(encryptionKey, new aesjs.Counter(1));
	*     const encryptedBytes = cipher.encrypt(aesjs.utils.utf8.toBytes(value));
	*
	*     await SecureStore.setItemAsync(key, aesjs.utils.hex.fromBytes(encryptionKey));
	*
	*     return aesjs.utils.hex.fromBytes(encryptedBytes);
	*   }
	*
	*   private async _decrypt(key: string, value: string) {
	*     const encryptionKeyHex = await SecureStore.getItemAsync(key);
	*     if (!encryptionKeyHex) {
	*       return encryptionKeyHex;
	*     }
	*
	*     const cipher = new aesjs.ModeOfOperation.ctr(aesjs.utils.hex.toBytes(encryptionKeyHex), new aesjs.Counter(1));
	*     const decryptedBytes = cipher.decrypt(aesjs.utils.hex.toBytes(value));
	*
	*     return aesjs.utils.utf8.fromBytes(decryptedBytes);
	*   }
	*
	*   async getItem(key: string) {
	*     const encrypted = await AsyncStorage.getItem(key);
	*     if (!encrypted) { return encrypted; }
	*
	*     return await this._decrypt(key, encrypted);
	*   }
	*
	*   async removeItem(key: string) {
	*     await AsyncStorage.removeItem(key);
	*     await SecureStore.deleteItemAsync(key);
	*   }
	*
	*   async setItem(key: string, value: string) {
	*     const encrypted = await this._encrypt(key, value);
	*
	*     await AsyncStorage.setItem(key, encrypted);
	*   }
	* }
	*
	* const supabase = createClient("https://xyzcompany.supabase.co", "your-publishable-key", {
	*   auth: {
	*     storage: new LargeSecureStore(),
	*     autoRefreshToken: true,
	*     persistSession: true,
	*     detectSessionInUrl: false,
	*   },
	* });
	* ```
	*
	* @example With a database query
	* ```ts
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	*
	* const { data } = await supabase.from('profiles').select('*')
	* ```
	*
	* @exampleDescription With OpenTelemetry tracing
	* Opt in to W3C trace context propagation so the `trace_id` from your
	* client-side spans is attached to Supabase requests and appears in API
	* Gateway and Edge Function logs. Requires `@opentelemetry/api` to be
	* installed in your application. See [Tracing with the JS SDK](https://supabase.com/docs/guides/telemetry/client-side-tracing).
	*
	* @example With OpenTelemetry tracing
	* ```ts
	* import { createClient } from '@supabase/supabase-js'
	* import { trace } from '@opentelemetry/api'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key', {
	*   tracePropagation: true,
	* })
	*
	* const tracer = trace.getTracer('my-app')
	*
	* await tracer.startActiveSpan('fetch-users', async (span) => {
	*   // Outgoing request carries the active trace context.
	*   const { data, error } = await supabase.from('users').select('*')
	*   span.end()
	* })
	* ```
	*/
	constructor(supabaseUrl, supabaseKey, options) {
		var _settings$auth$storag, _settings$global$head;
		this.supabaseUrl = supabaseUrl;
		this.supabaseKey = supabaseKey;
		const baseUrl = validateSupabaseUrl(supabaseUrl);
		if (!supabaseKey) throw new Error("supabaseKey is required.");
		this.realtimeUrl = new URL("realtime/v1", baseUrl);
		this.realtimeUrl.protocol = this.realtimeUrl.protocol.replace("http", "ws");
		this.authUrl = new URL("auth/v1", baseUrl);
		this.storageUrl = new URL("storage/v1", baseUrl);
		this.functionsUrl = new URL("functions/v1", baseUrl);
		const defaultStorageKey = `sb-${baseUrl.hostname.split(".")[0]}-auth-token`;
		const DEFAULTS = {
			db: DEFAULT_DB_OPTIONS,
			realtime: DEFAULT_REALTIME_OPTIONS,
			auth: _objectSpread2(_objectSpread2({}, DEFAULT_AUTH_OPTIONS), {}, { storageKey: defaultStorageKey }),
			global: DEFAULT_GLOBAL_OPTIONS,
			tracePropagation: DEFAULT_TRACE_PROPAGATION_OPTIONS
		};
		const settings = applySettingDefaults(options !== null && options !== void 0 ? options : {}, DEFAULTS);
		this.settings = settings;
		this.storageKey = (_settings$auth$storag = settings.auth.storageKey) !== null && _settings$auth$storag !== void 0 ? _settings$auth$storag : "";
		this.headers = (_settings$global$head = settings.global.headers) !== null && _settings$global$head !== void 0 ? _settings$global$head : {};
		if (!settings.accessToken) {
			var _settings$auth;
			this.auth = this._initSupabaseAuthClient((_settings$auth = settings.auth) !== null && _settings$auth !== void 0 ? _settings$auth : {}, this.headers, settings.global.fetch);
		} else {
			this.accessToken = settings.accessToken;
			this.auth = new Proxy({}, { get: (_, prop) => {
				throw new Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(prop)} is not possible`);
			} });
		}
		this.fetch = fetchWithAuth(supabaseKey, supabaseUrl, this._getAccessToken.bind(this), settings.global.fetch, settings.tracePropagation);
		this.realtime = this._initRealtimeClient(_objectSpread2({
			headers: this.headers,
			accessToken: this._getAccessToken.bind(this),
			fetch: this.fetch
		}, settings.realtime));
		if (this.accessToken) Promise.resolve(this.accessToken()).then((token) => this.realtime.setAuth(token)).catch((e) => console.warn("Failed to set initial Realtime auth token:", e));
		this.rest = new PostgrestClient(new URL("rest/v1", baseUrl).href, {
			headers: this.headers,
			schema: settings.db.schema,
			fetch: this.fetch,
			timeout: settings.db.timeout,
			urlLengthLimit: settings.db.urlLengthLimit
		});
		this.storage = new StorageClient(this.storageUrl.href, this.headers, this.fetch, options === null || options === void 0 ? void 0 : options.storage);
		if (!settings.accessToken) this._listenForAuthEvents();
	}
	/**
	* Supabase Functions allows you to deploy and invoke edge functions.
	*/
	get functions() {
		return new FunctionsClient(this.functionsUrl.href, {
			headers: this.headers,
			customFetch: this.fetch
		});
	}
	/**
	* Perform a query on a table or a view.
	*
	* @param relation - The table or view name to query
	*/
	from(relation) {
		return this.rest.from(relation);
	}
	/**
	* Select a schema to query or perform an function (rpc) call.
	*
	* The schema needs to be on the list of exposed schemas inside Supabase.
	*
	* @param schema - The schema to query
	*/
	schema(schema) {
		return this.rest.schema(schema);
	}
	/**
	* Perform a function call.
	*
	* @param fn - The function name to call
	* @param args - The arguments to pass to the function call
	* @param options - Named parameters
	* @param options.head - When set to `true`, `data` will not be returned.
	* Useful if you only need the count.
	* @param options.get - When set to `true`, the function will be called with
	* read-only access mode.
	* @param options.count - Count algorithm to use to count rows returned by the
	* function. Only applicable for [set-returning
	* functions](https://www.postgresql.org/docs/current/functions-srf.html).
	*
	* `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
	* hood.
	*
	* `"planned"`: Approximated but fast count algorithm. Uses the Postgres
	* statistics under the hood.
	*
	* `"estimated"`: Uses exact count for low numbers and planned count for high
	* numbers.
	*/
	rpc(fn, args = {}, options = {
		head: false,
		get: false,
		count: void 0
	}) {
		return this.rest.rpc(fn, args, options);
	}
	/**
	* Creates a Realtime channel with Broadcast, Presence, and Postgres Changes.
	*
	* @param {string} name - The name of the Realtime channel.
	* @param {Object} opts - The options to pass to the Realtime channel.
	*
	* @category Realtime
	*/
	channel(name, opts = { config: {} }) {
		return this.realtime.channel(name, opts);
	}
	/**
	* Returns all Realtime channels.
	*
	* @category Realtime
	*
	* @example Get all channels
	* ```js
	* const channels = supabase.getChannels()
	* ```
	*/
	getChannels() {
		return this.realtime.getChannels();
	}
	/**
	* Unsubscribes and removes Realtime channel from Realtime client.
	*
	* @param {RealtimeChannel} channel - The name of the Realtime channel.
	*
	*
	* @category Realtime
	*
	* @remarks
	* - Removing a channel is a great way to maintain the performance of your project's Realtime service as well as your database if you're listening to Postgres changes. Supabase will automatically handle cleanup 30 seconds after a client is disconnected, but unused channels may cause degradation as more clients are simultaneously subscribed.
	*
	* @example Removes a channel
	* ```js
	* supabase.removeChannel(myChannel)
	* ```
	*/
	removeChannel(channel) {
		return this.realtime.removeChannel(channel);
	}
	/**
	* Unsubscribes and removes all Realtime channels from Realtime client.
	*
	* @category Realtime
	*
	* @remarks
	* - Removing channels is a great way to maintain the performance of your project's Realtime service as well as your database if you're listening to Postgres changes. Supabase will automatically handle cleanup 30 seconds after a client is disconnected, but unused channels may cause degradation as more clients are simultaneously subscribed.
	*
	* @example Remove all channels
	* ```js
	* supabase.removeAllChannels()
	* ```
	*/
	removeAllChannels() {
		return this.realtime.removeAllChannels();
	}
	async _getAccessToken() {
		var _this = this;
		var _data$session$access_, _data$session;
		if (_this.accessToken) return await _this.accessToken();
		const { data } = await _this.auth.getSession();
		return (_data$session$access_ = (_data$session = data.session) === null || _data$session === void 0 ? void 0 : _data$session.access_token) !== null && _data$session$access_ !== void 0 ? _data$session$access_ : _this.supabaseKey;
	}
	_initSupabaseAuthClient({ autoRefreshToken, persistSession, detectSessionInUrl, storage, userStorage, storageKey, flowType, lock, debug, throwOnError, experimental, lockAcquireTimeout, skipAutoInitialize }, headers, fetch$1) {
		const authHeaders = {
			Authorization: `Bearer ${this.supabaseKey}`,
			apikey: `${this.supabaseKey}`
		};
		return new SupabaseAuthClient({
			url: this.authUrl.href,
			headers: _objectSpread2(_objectSpread2({}, authHeaders), headers),
			storageKey,
			autoRefreshToken,
			persistSession,
			detectSessionInUrl,
			storage,
			userStorage,
			flowType,
			lock,
			debug,
			throwOnError,
			experimental,
			fetch: fetch$1,
			lockAcquireTimeout,
			skipAutoInitialize,
			hasCustomAuthorizationHeader: Object.keys(this.headers).some((key) => key.toLowerCase() === "authorization")
		});
	}
	_initRealtimeClient(options) {
		return new RealtimeClient(this.realtimeUrl.href, _objectSpread2(_objectSpread2({}, options), {}, { params: _objectSpread2(_objectSpread2({}, { apikey: this.supabaseKey }), options === null || options === void 0 ? void 0 : options.params) }));
	}
	_listenForAuthEvents() {
		return this.auth.onAuthStateChange((event, session) => {
			this._handleTokenChanged(event, "CLIENT", session === null || session === void 0 ? void 0 : session.access_token);
		});
	}
	_handleTokenChanged(event, source, token) {
		if ((event === "TOKEN_REFRESHED" || event === "SIGNED_IN") && this.changedAccessToken !== token) {
			this.changedAccessToken = token;
			this.realtime.setAuth(token);
		} else if (event === "SIGNED_OUT") {
			this.realtime.setAuth();
			if (source == "STORAGE") this.auth.signOut();
			this.changedAccessToken = void 0;
		}
	}
};

//#endregion
//#region src/index.ts
/**
* Creates a new Supabase Client.
*
* @example Creating a Supabase client
* ```ts
* import { createClient } from '@supabase/supabase-js'
*
* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
* const { data, error } = await supabase.from('profiles').select('*')
* ```
*/
const createClient = (supabaseUrl, supabaseKey, options) => {
	return new SupabaseClient(supabaseUrl, supabaseKey, options);
};
function shouldShowDeprecationWarning() {
	if (typeof window !== "undefined") return false;
	const _process = globalThis["process"];
	if (!_process) return false;
	const processVersion = _process["version"];
	if (processVersion === void 0 || processVersion === null) return false;
	const versionMatch = processVersion.match(/^v(\d+)\./);
	if (!versionMatch) return false;
	return parseInt(versionMatch[1], 10) <= 18;
}
if (shouldShowDeprecationWarning()) console.warn("⚠️  Node.js 18 and below are deprecated and will no longer be supported in future versions of @supabase/supabase-js. Please upgrade to Node.js 20 or later. For more information, visit: https://github.com/orgs/supabase/discussions/37217");

//#endregion
export { FunctionRegion, FunctionsError, FunctionsFetchError, FunctionsHttpError, FunctionsRelayError, PostgrestError, StorageApiError, SupabaseClient, createClient };
                                  
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXgubWpzIiwibmFtZXMiOlsiSlNfUlVOVElNRV9WRVJTSU9OOiBzdHJpbmcgfCB1bmRlZmluZWQiLCJERUZBVUxUX0FVVEhfT1BUSU9OUzogU3VwYWJhc2VBdXRoQ2xpZW50T3B0aW9ucyIsIkRFRkFVTFRfUkVBTFRJTUVfT1BUSU9OUzogUmVhbHRpbWVDbGllbnRPcHRpb25zIiwiREVGQVVMVF9UUkFDRV9QUk9QQUdBVElPTl9PUFRJT05TOiBUcmFjZVByb3BhZ2F0aW9uT3B0aW9ucyIsInZlcnNpb24iLCJmZXRjaCIsInRyYWNlVGFyZ2V0czogVHJhY2VQcm9wYWdhdGlvblRhcmdldFtdIHwgbnVsbCIsIkRFRkFVTFRfREJfT1BUSU9OUyIsIkRFRkFVTFRfQVVUSF9PUFRJT05TIiwiREVGQVVMVF9SRUFMVElNRV9PUFRJT05TIiwiREVGQVVMVF9HTE9CQUxfT1BUSU9OUyIsIkRFRkFVTFRfVFJBQ0VfUFJPUEFHQVRJT05fT1BUSU9OUyIsInJlc3VsdDogUmVzb2x2ZWRTdXBhYmFzZUNsaWVudE9wdGlvbnM8U2NoZW1hTmFtZT4iLCJzdXBhYmFzZVVybDogc3RyaW5nIiwic3VwYWJhc2VLZXk6IHN0cmluZyIsIlN1cGFiYXNlU3RvcmFnZUNsaWVudCIsInRoaXMiXSwic291cmNlcyI6WyIuLi9zcmMvbGliL3ZlcnNpb24udHMiLCIuLi9zcmMvbGliL2NvbnN0YW50cy50cyIsIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS90c2xpYkAyLjguMS9ub2RlX21vZHVsZXMvdHNsaWIvdHNsaWIuZXM2Lm1qcyIsIi4uLy4uLy4uL3NoYXJlZC90cmFjaW5nL2Rpc3QvbW9kdWxlL2V4dHJhY3QuanMiLCIuLi8uLi8uLi9zaGFyZWQvdHJhY2luZy9kaXN0L21vZHVsZS9wYXJzZS5qcyIsIi4uLy4uLy4uL3NoYXJlZC90cmFjaW5nL2Rpc3QvbW9kdWxlL3ZhbGlkYXRlLmpzIiwiLi4vLi4vLi4vc2hhcmVkL3RyYWNpbmcvZGlzdC9tb2R1bGUvZGVmYXVsdHMuanMiLCIuLi9zcmMvbGliL2ZldGNoLnRzIiwiLi4vc3JjL2xpYi9oZWxwZXJzLnRzIiwiLi4vc3JjL2xpYi9TdXBhYmFzZUF1dGhDbGllbnQudHMiLCIuLi9zcmMvU3VwYWJhc2VDbGllbnQudHMiLCIuLi9zcmMvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gR2VuZXJhdGVkIGF1dG9tYXRpY2FsbHkgZHVyaW5nIHJlbGVhc2VzIGJ5IHNjcmlwdHMvdXBkYXRlLXZlcnNpb24tZmlsZXMudHNcbi8vIFRoaXMgZmlsZSBwcm92aWRlcyBydW50aW1lIGFjY2VzcyB0byB0aGUgcGFja2FnZSB2ZXJzaW9uIGZvcjpcbi8vIC0gSFRUUCByZXF1ZXN0IGhlYWRlcnMgKGUuZy4sIFgtQ2xpZW50LUluZm8gaGVhZGVyIGZvciBBUEkgcmVxdWVzdHMpXG4vLyAtIERlYnVnZ2luZyBhbmQgc3VwcG9ydCAoaWRlbnRpZnlpbmcgd2hpY2ggdmVyc2lvbiBpcyBydW5uaW5nKVxuLy8gLSBUZWxlbWV0cnkgYW5kIGxvZ2dpbmcgKHZlcnNpb24gcmVwb3J0aW5nIGluIGVycm9ycy9hbmFseXRpY3MpXG4vLyAtIEVuc3VyaW5nIGJ1aWxkIGFydGlmYWN0cyBtYXRjaCB0aGUgcHVibGlzaGVkIHBhY2thZ2UgdmVyc2lvblxuZXhwb3J0IGNvbnN0IHZlcnNpb24gPSAnMi4xMDguMSdcbiIsIi8vIGNvbnN0YW50cy50c1xuaW1wb3J0IHsgUmVhbHRpbWVDbGllbnRPcHRpb25zIH0gZnJvbSAnQHN1cGFiYXNlL3JlYWx0aW1lLWpzJ1xuaW1wb3J0IHsgU3VwYWJhc2VBdXRoQ2xpZW50T3B0aW9ucywgVHJhY2VQcm9wYWdhdGlvbk9wdGlvbnMgfSBmcm9tICcuL3R5cGVzJ1xuaW1wb3J0IHsgdmVyc2lvbiB9IGZyb20gJy4vdmVyc2lvbidcblxubGV0IEpTX0VOViA9ICcnXG5sZXQgSlNfUlVOVElNRV9WRVJTSU9OOiBzdHJpbmcgfCB1bmRlZmluZWRcbi8vIEB0cy1pZ25vcmVcbmlmICh0eXBlb2YgRGVubyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgSlNfRU5WID0gJ2Rlbm8nXG4gIC8vIEB0cy1pZ25vcmVcbiAgSlNfUlVOVElNRV9WRVJTSU9OID0gRGVuby52ZXJzaW9uPy5kZW5vXG59IGVsc2UgaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgSlNfRU5WID0gJ3dlYidcbn0gZWxzZSBpZiAodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLnByb2R1Y3QgPT09ICdSZWFjdE5hdGl2ZScpIHtcbiAgSlNfRU5WID0gJ3JlYWN0LW5hdGl2ZSdcbn0gZWxzZSB7XG4gIEpTX0VOViA9ICdub2RlJ1xuICBKU19SVU5USU1FX1ZFUlNJT04gPVxuICAgIHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJyA/IHByb2Nlc3MudmVyc2lvbj8ucmVwbGFjZSgvXnYvLCAnJykgOiB1bmRlZmluZWRcbn1cblxuY29uc3QgX3J1bnRpbWVNZXRhID0gW2BydW50aW1lPSR7SlNfRU5WfWBdXG5pZiAoSlNfUlVOVElNRV9WRVJTSU9OKSB7XG4gIF9ydW50aW1lTWV0YS5wdXNoKGBydW50aW1lLXZlcnNpb249JHtKU19SVU5USU1FX1ZFUlNJT059YClcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfSEVBREVSUyA9IHtcbiAgJ1gtQ2xpZW50LUluZm8nOiBgc3VwYWJhc2UtanMvJHt2ZXJzaW9ufTsgJHtfcnVudGltZU1ldGEuam9pbignOyAnKX1gLFxufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9HTE9CQUxfT1BUSU9OUyA9IHtcbiAgaGVhZGVyczogREVGQVVMVF9IRUFERVJTLFxufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9EQl9PUFRJT05TID0ge1xuICBzY2hlbWE6ICdwdWJsaWMnLFxufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9BVVRIX09QVElPTlM6IFN1cGFiYXNlQXV0aENsaWVudE9wdGlvbnMgPSB7XG4gIGF1dG9SZWZyZXNoVG9rZW46IHRydWUsXG4gIHBlcnNpc3RTZXNzaW9uOiB0cnVlLFxuICBkZXRlY3RTZXNzaW9uSW5Vcmw6IHRydWUsXG4gIGZsb3dUeXBlOiAnaW1wbGljaXQnLFxufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9SRUFMVElNRV9PUFRJT05TOiBSZWFsdGltZUNsaWVudE9wdGlvbnMgPSB7fVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9UUkFDRV9QUk9QQUdBVElPTl9PUFRJT05TOiBUcmFjZVByb3BhZ2F0aW9uT3B0aW9ucyA9IHtcbiAgZW5hYmxlZDogZmFsc2UsXG4gIHJlc3BlY3RTYW1wbGluZ0RlY2lzaW9uOiB0cnVlLFxufVxuIiwiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uXG5cblBlcm1pc3Npb24gdG8gdXNlLCBjb3B5LCBtb2RpZnksIGFuZC9vciBkaXN0cmlidXRlIHRoaXMgc29mdHdhcmUgZm9yIGFueVxucHVycG9zZSB3aXRoIG9yIHdpdGhvdXQgZmVlIGlzIGhlcmVieSBncmFudGVkLlxuXG5USEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiIEFORCBUSEUgQVVUSE9SIERJU0NMQUlNUyBBTEwgV0FSUkFOVElFUyBXSVRIXG5SRUdBUkQgVE8gVEhJUyBTT0ZUV0FSRSBJTkNMVURJTkcgQUxMIElNUExJRUQgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFlcbkFORCBGSVRORVNTLiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SIEJFIExJQUJMRSBGT1IgQU5ZIFNQRUNJQUwsIERJUkVDVCxcbklORElSRUNULCBPUiBDT05TRVFVRU5USUFMIERBTUFHRVMgT1IgQU5ZIERBTUFHRVMgV0hBVFNPRVZFUiBSRVNVTFRJTkcgRlJPTVxuTE9TUyBPRiBVU0UsIERBVEEgT1IgUFJPRklUUywgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIE5FR0xJR0VOQ0UgT1Jcbk9USEVSIFRPUlRJT1VTIEFDVElPTiwgQVJJU0lORyBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBVU0UgT1JcblBFUkZPUk1BTkNFIE9GIFRISVMgU09GVFdBUkUuXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuLyogZ2xvYmFsIFJlZmxlY3QsIFByb21pc2UsIFN1cHByZXNzZWRFcnJvciwgU3ltYm9sLCBJdGVyYXRvciAqL1xuXG52YXIgZXh0ZW5kU3RhdGljcyA9IGZ1bmN0aW9uKGQsIGIpIHtcbiAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxuICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxuICAgICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGIsIHApKSBkW3BdID0gYltwXTsgfTtcbiAgcmV0dXJuIGV4dGVuZFN0YXRpY3MoZCwgYik7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gX19leHRlbmRzKGQsIGIpIHtcbiAgaWYgKHR5cGVvZiBiICE9PSBcImZ1bmN0aW9uXCIgJiYgYiAhPT0gbnVsbClcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcbiAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcbiAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XG4gIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcbn1cblxuZXhwb3J0IHZhciBfX2Fzc2lnbiA9IGZ1bmN0aW9uKCkge1xuICBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gX19hc3NpZ24odCkge1xuICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkpIHRbcF0gPSBzW3BdO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHQ7XG4gIH1cbiAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xuICB2YXIgdCA9IHt9O1xuICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcbiAgICAgIHRbcF0gPSBzW3BdO1xuICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKVxuICAgICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcbiAgICAgIH1cbiAgcmV0dXJuIHQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2RlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKSB7XG4gIHZhciBjID0gYXJndW1lbnRzLmxlbmd0aCwgciA9IGMgPCAzID8gdGFyZ2V0IDogZGVzYyA9PT0gbnVsbCA/IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KSA6IGRlc2MsIGQ7XG4gIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XG4gIGVsc2UgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIGlmIChkID0gZGVjb3JhdG9yc1tpXSkgciA9IChjIDwgMyA/IGQocikgOiBjID4gMyA/IGQodGFyZ2V0LCBrZXksIHIpIDogZCh0YXJnZXQsIGtleSkpIHx8IHI7XG4gIHJldHVybiBjID4gMyAmJiByICYmIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgciksIHI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3BhcmFtKHBhcmFtSW5kZXgsIGRlY29yYXRvcikge1xuICByZXR1cm4gZnVuY3Rpb24gKHRhcmdldCwga2V5KSB7IGRlY29yYXRvcih0YXJnZXQsIGtleSwgcGFyYW1JbmRleCk7IH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fZXNEZWNvcmF0ZShjdG9yLCBkZXNjcmlwdG9ySW4sIGRlY29yYXRvcnMsIGNvbnRleHRJbiwgaW5pdGlhbGl6ZXJzLCBleHRyYUluaXRpYWxpemVycykge1xuICBmdW5jdGlvbiBhY2NlcHQoZikgeyBpZiAoZiAhPT0gdm9pZCAwICYmIHR5cGVvZiBmICE9PSBcImZ1bmN0aW9uXCIpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJGdW5jdGlvbiBleHBlY3RlZFwiKTsgcmV0dXJuIGY7IH1cbiAgdmFyIGtpbmQgPSBjb250ZXh0SW4ua2luZCwga2V5ID0ga2luZCA9PT0gXCJnZXR0ZXJcIiA/IFwiZ2V0XCIgOiBraW5kID09PSBcInNldHRlclwiID8gXCJzZXRcIiA6IFwidmFsdWVcIjtcbiAgdmFyIHRhcmdldCA9ICFkZXNjcmlwdG9ySW4gJiYgY3RvciA/IGNvbnRleHRJbltcInN0YXRpY1wiXSA/IGN0b3IgOiBjdG9yLnByb3RvdHlwZSA6IG51bGw7XG4gIHZhciBkZXNjcmlwdG9yID0gZGVzY3JpcHRvckluIHx8ICh0YXJnZXQgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwgY29udGV4dEluLm5hbWUpIDoge30pO1xuICB2YXIgXywgZG9uZSA9IGZhbHNlO1xuICBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgdmFyIGNvbnRleHQgPSB7fTtcbiAgICAgIGZvciAodmFyIHAgaW4gY29udGV4dEluKSBjb250ZXh0W3BdID0gcCA9PT0gXCJhY2Nlc3NcIiA/IHt9IDogY29udGV4dEluW3BdO1xuICAgICAgZm9yICh2YXIgcCBpbiBjb250ZXh0SW4uYWNjZXNzKSBjb250ZXh0LmFjY2Vzc1twXSA9IGNvbnRleHRJbi5hY2Nlc3NbcF07XG4gICAgICBjb250ZXh0LmFkZEluaXRpYWxpemVyID0gZnVuY3Rpb24gKGYpIHsgaWYgKGRvbmUpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgYWRkIGluaXRpYWxpemVycyBhZnRlciBkZWNvcmF0aW9uIGhhcyBjb21wbGV0ZWRcIik7IGV4dHJhSW5pdGlhbGl6ZXJzLnB1c2goYWNjZXB0KGYgfHwgbnVsbCkpOyB9O1xuICAgICAgdmFyIHJlc3VsdCA9ICgwLCBkZWNvcmF0b3JzW2ldKShraW5kID09PSBcImFjY2Vzc29yXCIgPyB7IGdldDogZGVzY3JpcHRvci5nZXQsIHNldDogZGVzY3JpcHRvci5zZXQgfSA6IGRlc2NyaXB0b3Jba2V5XSwgY29udGV4dCk7XG4gICAgICBpZiAoa2luZCA9PT0gXCJhY2Nlc3NvclwiKSB7XG4gICAgICAgICAgaWYgKHJlc3VsdCA9PT0gdm9pZCAwKSBjb250aW51ZTtcbiAgICAgICAgICBpZiAocmVzdWx0ID09PSBudWxsIHx8IHR5cGVvZiByZXN1bHQgIT09IFwib2JqZWN0XCIpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJPYmplY3QgZXhwZWN0ZWRcIik7XG4gICAgICAgICAgaWYgKF8gPSBhY2NlcHQocmVzdWx0LmdldCkpIGRlc2NyaXB0b3IuZ2V0ID0gXztcbiAgICAgICAgICBpZiAoXyA9IGFjY2VwdChyZXN1bHQuc2V0KSkgZGVzY3JpcHRvci5zZXQgPSBfO1xuICAgICAgICAgIGlmIChfID0gYWNjZXB0KHJlc3VsdC5pbml0KSkgaW5pdGlhbGl6ZXJzLnVuc2hpZnQoXyk7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChfID0gYWNjZXB0KHJlc3VsdCkpIHtcbiAgICAgICAgICBpZiAoa2luZCA9PT0gXCJmaWVsZFwiKSBpbml0aWFsaXplcnMudW5zaGlmdChfKTtcbiAgICAgICAgICBlbHNlIGRlc2NyaXB0b3Jba2V5XSA9IF87XG4gICAgICB9XG4gIH1cbiAgaWYgKHRhcmdldCkgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgY29udGV4dEluLm5hbWUsIGRlc2NyaXB0b3IpO1xuICBkb25lID0gdHJ1ZTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3J1bkluaXRpYWxpemVycyh0aGlzQXJnLCBpbml0aWFsaXplcnMsIHZhbHVlKSB7XG4gIHZhciB1c2VWYWx1ZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAyO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGluaXRpYWxpemVycy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFsdWUgPSB1c2VWYWx1ZSA/IGluaXRpYWxpemVyc1tpXS5jYWxsKHRoaXNBcmcsIHZhbHVlKSA6IGluaXRpYWxpemVyc1tpXS5jYWxsKHRoaXNBcmcpO1xuICB9XG4gIHJldHVybiB1c2VWYWx1ZSA/IHZhbHVlIDogdm9pZCAwO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fcHJvcEtleSh4KSB7XG4gIHJldHVybiB0eXBlb2YgeCA9PT0gXCJzeW1ib2xcIiA/IHggOiBcIlwiLmNvbmNhdCh4KTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3NldEZ1bmN0aW9uTmFtZShmLCBuYW1lLCBwcmVmaXgpIHtcbiAgaWYgKHR5cGVvZiBuYW1lID09PSBcInN5bWJvbFwiKSBuYW1lID0gbmFtZS5kZXNjcmlwdGlvbiA/IFwiW1wiLmNvbmNhdChuYW1lLmRlc2NyaXB0aW9uLCBcIl1cIikgOiBcIlwiO1xuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGYsIFwibmFtZVwiLCB7IGNvbmZpZ3VyYWJsZTogdHJ1ZSwgdmFsdWU6IHByZWZpeCA/IFwiXCIuY29uY2F0KHByZWZpeCwgXCIgXCIsIG5hbWUpIDogbmFtZSB9KTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX21ldGFkYXRhKG1ldGFkYXRhS2V5LCBtZXRhZGF0YVZhbHVlKSB7XG4gIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5tZXRhZGF0YSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gUmVmbGVjdC5tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XG4gIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxuICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcbiAgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2dlbmVyYXRvcih0aGlzQXJnLCBib2R5KSB7XG4gIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGcgPSBPYmplY3QuY3JlYXRlKCh0eXBlb2YgSXRlcmF0b3IgPT09IFwiZnVuY3Rpb25cIiA/IEl0ZXJhdG9yIDogT2JqZWN0KS5wcm90b3R5cGUpO1xuICByZXR1cm4gZy5uZXh0ID0gdmVyYigwKSwgZ1tcInRocm93XCJdID0gdmVyYigxKSwgZ1tcInJldHVyblwiXSA9IHZlcmIoMiksIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcbiAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XG4gIGZ1bmN0aW9uIHN0ZXAob3ApIHtcbiAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcbiAgICAgIHdoaWxlIChnICYmIChnID0gMCwgb3BbMF0gJiYgKF8gPSAwKSksIF8pIHRyeSB7XG4gICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xuICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcbiAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XG4gICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xuICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xuICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XG4gICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxuICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cbiAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XG4gICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XG4gICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcbiAgfVxufVxuXG5leHBvcnQgdmFyIF9fY3JlYXRlQmluZGluZyA9IE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgdmFyIGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG0sIGspO1xuICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgfVxuICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgazIsIGRlc2MpO1xufSkgOiAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgb1trMl0gPSBtW2tdO1xufSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2V4cG9ydFN0YXIobSwgbykge1xuICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG8sIHApKSBfX2NyZWF0ZUJpbmRpbmcobywgbSwgcCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3ZhbHVlcyhvKSB7XG4gIHZhciBzID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIFN5bWJvbC5pdGVyYXRvciwgbSA9IHMgJiYgb1tzXSwgaSA9IDA7XG4gIGlmIChtKSByZXR1cm4gbS5jYWxsKG8pO1xuICBpZiAobyAmJiB0eXBlb2Ygby5sZW5ndGggPT09IFwibnVtYmVyXCIpIHJldHVybiB7XG4gICAgICBuZXh0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaWYgKG8gJiYgaSA+PSBvLmxlbmd0aCkgbyA9IHZvaWQgMDtcbiAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XG4gICAgICB9XG4gIH07XG4gIHRocm93IG5ldyBUeXBlRXJyb3IocyA/IFwiT2JqZWN0IGlzIG5vdCBpdGVyYWJsZS5cIiA6IFwiU3ltYm9sLml0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XG4gIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXTtcbiAgaWYgKCFtKSByZXR1cm4gbztcbiAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XG4gIHRyeSB7XG4gICAgICB3aGlsZSAoKG4gPT09IHZvaWQgMCB8fCBuLS0gPiAwKSAmJiAhKHIgPSBpLm5leHQoKSkuZG9uZSkgYXIucHVzaChyLnZhbHVlKTtcbiAgfVxuICBjYXRjaCAoZXJyb3IpIHsgZSA9IHsgZXJyb3I6IGVycm9yIH07IH1cbiAgZmluYWxseSB7XG4gICAgICB0cnkge1xuICAgICAgICAgIGlmIChyICYmICFyLmRvbmUgJiYgKG0gPSBpW1wicmV0dXJuXCJdKSkgbS5jYWxsKGkpO1xuICAgICAgfVxuICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XG4gIH1cbiAgcmV0dXJuIGFyO1xufVxuXG4vKiogQGRlcHJlY2F0ZWQgKi9cbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcbiAgZm9yICh2YXIgYXIgPSBbXSwgaSA9IDA7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspXG4gICAgICBhciA9IGFyLmNvbmNhdChfX3JlYWQoYXJndW1lbnRzW2ldKSk7XG4gIHJldHVybiBhcjtcbn1cblxuLyoqIEBkZXByZWNhdGVkICovXG5leHBvcnQgZnVuY3Rpb24gX19zcHJlYWRBcnJheXMoKSB7XG4gIGZvciAodmFyIHMgPSAwLCBpID0gMCwgaWwgPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgaWw7IGkrKykgcyArPSBhcmd1bWVudHNbaV0ubGVuZ3RoO1xuICBmb3IgKHZhciByID0gQXJyYXkocyksIGsgPSAwLCBpID0gMDsgaSA8IGlsOyBpKyspXG4gICAgICBmb3IgKHZhciBhID0gYXJndW1lbnRzW2ldLCBqID0gMCwgamwgPSBhLmxlbmd0aDsgaiA8IGpsOyBqKyssIGsrKylcbiAgICAgICAgICByW2tdID0gYVtqXTtcbiAgcmV0dXJuIHI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZEFycmF5KHRvLCBmcm9tLCBwYWNrKSB7XG4gIGlmIChwYWNrIHx8IGFyZ3VtZW50cy5sZW5ndGggPT09IDIpIGZvciAodmFyIGkgPSAwLCBsID0gZnJvbS5sZW5ndGgsIGFyOyBpIDwgbDsgaSsrKSB7XG4gICAgICBpZiAoYXIgfHwgIShpIGluIGZyb20pKSB7XG4gICAgICAgICAgaWYgKCFhcikgYXIgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChmcm9tLCAwLCBpKTtcbiAgICAgICAgICBhcltpXSA9IGZyb21baV07XG4gICAgICB9XG4gIH1cbiAgcmV0dXJuIHRvLmNvbmNhdChhciB8fCBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChmcm9tKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0KHYpIHtcbiAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xuICBpZiAoIVN5bWJvbC5hc3luY0l0ZXJhdG9yKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3ltYm9sLmFzeW5jSXRlcmF0b3IgaXMgbm90IGRlZmluZWQuXCIpO1xuICB2YXIgZyA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSwgaSwgcSA9IFtdO1xuICByZXR1cm4gaSA9IE9iamVjdC5jcmVhdGUoKHR5cGVvZiBBc3luY0l0ZXJhdG9yID09PSBcImZ1bmN0aW9uXCIgPyBBc3luY0l0ZXJhdG9yIDogT2JqZWN0KS5wcm90b3R5cGUpLCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIsIGF3YWl0UmV0dXJuKSwgaVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9LCBpO1xuICBmdW5jdGlvbiBhd2FpdFJldHVybihmKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHYpLnRoZW4oZiwgcmVqZWN0KTsgfTsgfVxuICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaWYgKGdbbl0pIHsgaVtuXSA9IGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAoYSwgYikgeyBxLnB1c2goW24sIHYsIGEsIGJdKSA+IDEgfHwgcmVzdW1lKG4sIHYpOyB9KTsgfTsgaWYgKGYpIGlbbl0gPSBmKGlbbl0pOyB9IH1cbiAgZnVuY3Rpb24gcmVzdW1lKG4sIHYpIHsgdHJ5IHsgc3RlcChnW25dKHYpKTsgfSBjYXRjaCAoZSkgeyBzZXR0bGUocVswXVszXSwgZSk7IH0gfVxuICBmdW5jdGlvbiBzdGVwKHIpIHsgci52YWx1ZSBpbnN0YW5jZW9mIF9fYXdhaXQgPyBQcm9taXNlLnJlc29sdmUoci52YWx1ZS52KS50aGVuKGZ1bGZpbGwsIHJlamVjdCkgOiBzZXR0bGUocVswXVsyXSwgcik7IH1cbiAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxuICBmdW5jdGlvbiByZWplY3QodmFsdWUpIHsgcmVzdW1lKFwidGhyb3dcIiwgdmFsdWUpOyB9XG4gIGZ1bmN0aW9uIHNldHRsZShmLCB2KSB7IGlmIChmKHYpLCBxLnNoaWZ0KCksIHEubGVuZ3RoKSByZXN1bWUocVswXVswXSwgcVswXVsxXSk7IH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXN5bmNEZWxlZ2F0b3Iobykge1xuICB2YXIgaSwgcDtcbiAgcmV0dXJuIGkgPSB7fSwgdmVyYihcIm5leHRcIiksIHZlcmIoXCJ0aHJvd1wiLCBmdW5jdGlvbiAoZSkgeyB0aHJvdyBlOyB9KSwgdmVyYihcInJldHVyblwiKSwgaVtTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhpczsgfSwgaTtcbiAgZnVuY3Rpb24gdmVyYihuLCBmKSB7IGlbbl0gPSBvW25dID8gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIChwID0gIXApID8geyB2YWx1ZTogX19hd2FpdChvW25dKHYpKSwgZG9uZTogZmFsc2UgfSA6IGYgPyBmKHYpIDogdjsgfSA6IGY7IH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXN5bmNWYWx1ZXMobykge1xuICBpZiAoIVN5bWJvbC5hc3luY0l0ZXJhdG9yKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3ltYm9sLmFzeW5jSXRlcmF0b3IgaXMgbm90IGRlZmluZWQuXCIpO1xuICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xuICByZXR1cm4gbSA/IG0uY2FsbChvKSA6IChvID0gdHlwZW9mIF9fdmFsdWVzID09PSBcImZ1bmN0aW9uXCIgPyBfX3ZhbHVlcyhvKSA6IG9bU3ltYm9sLml0ZXJhdG9yXSgpLCBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLmFzeW5jSXRlcmF0b3JdID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhpczsgfSwgaSk7XG4gIGZ1bmN0aW9uIHZlcmIobikgeyBpW25dID0gb1tuXSAmJiBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkgeyB2ID0gb1tuXSh2KSwgc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgdi5kb25lLCB2LnZhbHVlKTsgfSk7IH07IH1cbiAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcbiAgaWYgKE9iamVjdC5kZWZpbmVQcm9wZXJ0eSkgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoY29va2VkLCBcInJhd1wiLCB7IHZhbHVlOiByYXcgfSk7IH0gZWxzZSB7IGNvb2tlZC5yYXcgPSByYXc7IH1cbiAgcmV0dXJuIGNvb2tlZDtcbn07XG5cbnZhciBfX3NldE1vZHVsZURlZmF1bHQgPSBPYmplY3QuY3JlYXRlID8gKGZ1bmN0aW9uKG8sIHYpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIFwiZGVmYXVsdFwiLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2IH0pO1xufSkgOiBmdW5jdGlvbihvLCB2KSB7XG4gIG9bXCJkZWZhdWx0XCJdID0gdjtcbn07XG5cbnZhciBvd25LZXlzID0gZnVuY3Rpb24obykge1xuICBvd25LZXlzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMgfHwgZnVuY3Rpb24gKG8pIHtcbiAgICB2YXIgYXIgPSBbXTtcbiAgICBmb3IgKHZhciBrIGluIG8pIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwobywgaykpIGFyW2FyLmxlbmd0aF0gPSBrO1xuICAgIHJldHVybiBhcjtcbiAgfTtcbiAgcmV0dXJuIG93bktleXMobyk7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnRTdGFyKG1vZCkge1xuICBpZiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSByZXR1cm4gbW9kO1xuICB2YXIgcmVzdWx0ID0ge307XG4gIGlmIChtb2QgIT0gbnVsbCkgZm9yICh2YXIgayA9IG93bktleXMobW9kKSwgaSA9IDA7IGkgPCBrLmxlbmd0aDsgaSsrKSBpZiAoa1tpXSAhPT0gXCJkZWZhdWx0XCIpIF9fY3JlYXRlQmluZGluZyhyZXN1bHQsIG1vZCwga1tpXSk7XG4gIF9fc2V0TW9kdWxlRGVmYXVsdChyZXN1bHQsIG1vZCk7XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2ltcG9ydERlZmF1bHQobW9kKSB7XG4gIHJldHVybiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSA/IG1vZCA6IHsgZGVmYXVsdDogbW9kIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHJlY2VpdmVyLCBzdGF0ZSwga2luZCwgZikge1xuICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBnZXR0ZXJcIik7XG4gIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHJlYWQgcHJpdmF0ZSBtZW1iZXIgZnJvbSBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xuICByZXR1cm4ga2luZCA9PT0gXCJtXCIgPyBmIDoga2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIpIDogZiA/IGYudmFsdWUgOiBzdGF0ZS5nZXQocmVjZWl2ZXIpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gX19jbGFzc1ByaXZhdGVGaWVsZFNldChyZWNlaXZlciwgc3RhdGUsIHZhbHVlLCBraW5kLCBmKSB7XG4gIGlmIChraW5kID09PSBcIm1cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgbWV0aG9kIGlzIG5vdCB3cml0YWJsZVwiKTtcbiAgaWYgKGtpbmQgPT09IFwiYVwiICYmICFmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBhY2Nlc3NvciB3YXMgZGVmaW5lZCB3aXRob3V0IGEgc2V0dGVyXCIpO1xuICBpZiAodHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciAhPT0gc3RhdGUgfHwgIWYgOiAhc3RhdGUuaGFzKHJlY2VpdmVyKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCB3cml0ZSBwcml2YXRlIG1lbWJlciB0byBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xuICByZXR1cm4gKGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyLCB2YWx1ZSkgOiBmID8gZi52YWx1ZSA9IHZhbHVlIDogc3RhdGUuc2V0KHJlY2VpdmVyLCB2YWx1ZSkpLCB2YWx1ZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fY2xhc3NQcml2YXRlRmllbGRJbihzdGF0ZSwgcmVjZWl2ZXIpIHtcbiAgaWYgKHJlY2VpdmVyID09PSBudWxsIHx8ICh0eXBlb2YgcmVjZWl2ZXIgIT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHJlY2VpdmVyICE9PSBcImZ1bmN0aW9uXCIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHVzZSAnaW4nIG9wZXJhdG9yIG9uIG5vbi1vYmplY3RcIik7XG4gIHJldHVybiB0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyID09PSBzdGF0ZSA6IHN0YXRlLmhhcyhyZWNlaXZlcik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2FkZERpc3Bvc2FibGVSZXNvdXJjZShlbnYsIHZhbHVlLCBhc3luYykge1xuICBpZiAodmFsdWUgIT09IG51bGwgJiYgdmFsdWUgIT09IHZvaWQgMCkge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgIT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHZhbHVlICE9PSBcImZ1bmN0aW9uXCIpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJPYmplY3QgZXhwZWN0ZWQuXCIpO1xuICAgIHZhciBkaXNwb3NlLCBpbm5lcjtcbiAgICBpZiAoYXN5bmMpIHtcbiAgICAgIGlmICghU3ltYm9sLmFzeW5jRGlzcG9zZSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0Rpc3Bvc2UgaXMgbm90IGRlZmluZWQuXCIpO1xuICAgICAgZGlzcG9zZSA9IHZhbHVlW1N5bWJvbC5hc3luY0Rpc3Bvc2VdO1xuICAgIH1cbiAgICBpZiAoZGlzcG9zZSA9PT0gdm9pZCAwKSB7XG4gICAgICBpZiAoIVN5bWJvbC5kaXNwb3NlKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3ltYm9sLmRpc3Bvc2UgaXMgbm90IGRlZmluZWQuXCIpO1xuICAgICAgZGlzcG9zZSA9IHZhbHVlW1N5bWJvbC5kaXNwb3NlXTtcbiAgICAgIGlmIChhc3luYykgaW5uZXIgPSBkaXNwb3NlO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGRpc3Bvc2UgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk9iamVjdCBub3QgZGlzcG9zYWJsZS5cIik7XG4gICAgaWYgKGlubmVyKSBkaXNwb3NlID0gZnVuY3Rpb24oKSB7IHRyeSB7IGlubmVyLmNhbGwodGhpcyk7IH0gY2F0Y2ggKGUpIHsgcmV0dXJuIFByb21pc2UucmVqZWN0KGUpOyB9IH07XG4gICAgZW52LnN0YWNrLnB1c2goeyB2YWx1ZTogdmFsdWUsIGRpc3Bvc2U6IGRpc3Bvc2UsIGFzeW5jOiBhc3luYyB9KTtcbiAgfVxuICBlbHNlIGlmIChhc3luYykge1xuICAgIGVudi5zdGFjay5wdXNoKHsgYXN5bmM6IHRydWUgfSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufVxuXG52YXIgX1N1cHByZXNzZWRFcnJvciA9IHR5cGVvZiBTdXBwcmVzc2VkRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IFN1cHByZXNzZWRFcnJvciA6IGZ1bmN0aW9uIChlcnJvciwgc3VwcHJlc3NlZCwgbWVzc2FnZSkge1xuICB2YXIgZSA9IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgcmV0dXJuIGUubmFtZSA9IFwiU3VwcHJlc3NlZEVycm9yXCIsIGUuZXJyb3IgPSBlcnJvciwgZS5zdXBwcmVzc2VkID0gc3VwcHJlc3NlZCwgZTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2Rpc3Bvc2VSZXNvdXJjZXMoZW52KSB7XG4gIGZ1bmN0aW9uIGZhaWwoZSkge1xuICAgIGVudi5lcnJvciA9IGVudi5oYXNFcnJvciA/IG5ldyBfU3VwcHJlc3NlZEVycm9yKGUsIGVudi5lcnJvciwgXCJBbiBlcnJvciB3YXMgc3VwcHJlc3NlZCBkdXJpbmcgZGlzcG9zYWwuXCIpIDogZTtcbiAgICBlbnYuaGFzRXJyb3IgPSB0cnVlO1xuICB9XG4gIHZhciByLCBzID0gMDtcbiAgZnVuY3Rpb24gbmV4dCgpIHtcbiAgICB3aGlsZSAociA9IGVudi5zdGFjay5wb3AoKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKCFyLmFzeW5jICYmIHMgPT09IDEpIHJldHVybiBzID0gMCwgZW52LnN0YWNrLnB1c2gociksIFByb21pc2UucmVzb2x2ZSgpLnRoZW4obmV4dCk7XG4gICAgICAgIGlmIChyLmRpc3Bvc2UpIHtcbiAgICAgICAgICB2YXIgcmVzdWx0ID0gci5kaXNwb3NlLmNhbGwoci52YWx1ZSk7XG4gICAgICAgICAgaWYgKHIuYXN5bmMpIHJldHVybiBzIHw9IDIsIFByb21pc2UucmVzb2x2ZShyZXN1bHQpLnRoZW4obmV4dCwgZnVuY3Rpb24oZSkgeyBmYWlsKGUpOyByZXR1cm4gbmV4dCgpOyB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHMgfD0gMTtcbiAgICAgIH1cbiAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGZhaWwoZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzID09PSAxKSByZXR1cm4gZW52Lmhhc0Vycm9yID8gUHJvbWlzZS5yZWplY3QoZW52LmVycm9yKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuICAgIGlmIChlbnYuaGFzRXJyb3IpIHRocm93IGVudi5lcnJvcjtcbiAgfVxuICByZXR1cm4gbmV4dCgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gX19yZXdyaXRlUmVsYXRpdmVJbXBvcnRFeHRlbnNpb24ocGF0aCwgcHJlc2VydmVKc3gpIHtcbiAgaWYgKHR5cGVvZiBwYXRoID09PSBcInN0cmluZ1wiICYmIC9eXFwuXFwuP1xcLy8udGVzdChwYXRoKSkge1xuICAgICAgcmV0dXJuIHBhdGgucmVwbGFjZSgvXFwuKHRzeCkkfCgoPzpcXC5kKT8pKCg/OlxcLlteLi9dKz8pPylcXC4oW2NtXT8pdHMkL2ksIGZ1bmN0aW9uIChtLCB0c3gsIGQsIGV4dCwgY20pIHtcbiAgICAgICAgICByZXR1cm4gdHN4ID8gcHJlc2VydmVKc3ggPyBcIi5qc3hcIiA6IFwiLmpzXCIgOiBkICYmICghZXh0IHx8ICFjbSkgPyBtIDogKGQgKyBleHQgKyBcIi5cIiArIGNtLnRvTG93ZXJDYXNlKCkgKyBcImpzXCIpO1xuICAgICAgfSk7XG4gIH1cbiAgcmV0dXJuIHBhdGg7XG59XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgX19leHRlbmRzLFxuICBfX2Fzc2lnbixcbiAgX19yZXN0LFxuICBfX2RlY29yYXRlLFxuICBfX3BhcmFtLFxuICBfX2VzRGVjb3JhdGUsXG4gIF9fcnVuSW5pdGlhbGl6ZXJzLFxuICBfX3Byb3BLZXksXG4gIF9fc2V0RnVuY3Rpb25OYW1lLFxuICBfX21ldGFkYXRhLFxuICBfX2F3YWl0ZXIsXG4gIF9fZ2VuZXJhdG9yLFxuICBfX2NyZWF0ZUJpbmRpbmcsXG4gIF9fZXhwb3J0U3RhcixcbiAgX192YWx1ZXMsXG4gIF9fcmVhZCxcbiAgX19zcHJlYWQsXG4gIF9fc3ByZWFkQXJyYXlzLFxuICBfX3NwcmVhZEFycmF5LFxuICBfX2F3YWl0LFxuICBfX2FzeW5jR2VuZXJhdG9yLFxuICBfX2FzeW5jRGVsZWdhdG9yLFxuICBfX2FzeW5jVmFsdWVzLFxuICBfX21ha2VUZW1wbGF0ZU9iamVjdCxcbiAgX19pbXBvcnRTdGFyLFxuICBfX2ltcG9ydERlZmF1bHQsXG4gIF9fY2xhc3NQcml2YXRlRmllbGRHZXQsXG4gIF9fY2xhc3NQcml2YXRlRmllbGRTZXQsXG4gIF9fY2xhc3NQcml2YXRlRmllbGRJbixcbiAgX19hZGREaXNwb3NhYmxlUmVzb3VyY2UsXG4gIF9fZGlzcG9zZVJlc291cmNlcyxcbiAgX19yZXdyaXRlUmVsYXRpdmVJbXBvcnRFeHRlbnNpb24sXG59O1xuIiwiaW1wb3J0IHsgX19hd2FpdGVyIH0gZnJvbSBcInRzbGliXCI7XG5sZXQgb3RlbE1vZHVsZVByb21pc2UgPSBudWxsO1xuLy8gVmFyaWFibGUgc3BlY2lmaWVyIGtlZXBzIGBAb3BlbnRlbGVtZXRyeS9hcGlgIGZyb20gYmVpbmcgc3RhdGljYWxseSByZXNvbHZlZFxuLy8gYnkgYnVuZGxlcnMuIHN1cGFiYXNlLWpzJ3MgdHNkb3duIGJ1aWxkIGFsc28gcG9zdC1wcm9jZXNzZXMgaXRzIEVTTSBvdXRwdXRcbi8vIHRvIGluamVjdCAvKiB3ZWJwYWNrSWdub3JlICovIC8qIHR1cmJvcGFja0lnbm9yZSAqLyAvKiBAdml0ZS1pZ25vcmUgKi8gb25cbi8vIHRoaXMgZXhwcmVzc2lvbiDigJQgcm9sbGRvd24gc3RyaXBzIG1hZ2ljIGNvbW1lbnRzIGZyb20gc291cmNlLiBTZWUgUFIgIzIzODEuXG5jb25zdCBPVEVMX1BLRyA9ICdAb3BlbnRlbGVtZXRyeS9hcGknO1xuZnVuY3Rpb24gbG9hZE90ZWwoKSB7XG4gICAgaWYgKG90ZWxNb2R1bGVQcm9taXNlID09PSBudWxsKSB7XG4gICAgICAgIG90ZWxNb2R1bGVQcm9taXNlID0gaW1wb3J0KE9URUxfUEtHKS5jYXRjaCgoKSA9PiBudWxsKTtcbiAgICB9XG4gICAgcmV0dXJuIG90ZWxNb2R1bGVQcm9taXNlO1xufVxuLyoqXG4gKiBGb3IgdGVzdHMgb25seS4gUmVzZXRzIHRoZSBjYWNoZWQgT3BlblRlbGVtZXRyeSBpbXBvcnQuXG4gKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBfcmVzZXRPdGVsQ2FjaGUoKSB7XG4gICAgb3RlbE1vZHVsZVByb21pc2UgPSBudWxsO1xufVxuLyoqXG4gKiBFeHRyYWN0IHRyYWNlIGNvbnRleHQgZnJvbSB0aGUgT3BlblRlbGVtZXRyeSBBUEkuXG4gKlxuICogUmV0dXJucyBudWxsIGlmIGBAb3BlbnRlbGVtZXRyeS9hcGlgIGlzIG5vdCBpbnN0YWxsZWQgb3IgdGhlcmUgaXMgbm8gYWN0aXZlXG4gKiB0cmFjZSBjb250ZXh0LiBUaGUgZHluYW1pYyBpbXBvcnQgaXMgY2FjaGVkIGFmdGVyIHRoZSBmaXJzdCBjYWxsLlxuICpcbiAqIEByZXR1cm5zIFRyYWNlIGNvbnRleHQgd2l0aCB0cmFjZXBhcmVudCwgdHJhY2VzdGF0ZSwgYW5kIGJhZ2dhZ2UgaGVhZGVycywgb3IgbnVsbCBpZiB1bmF2YWlsYWJsZVxuICovXG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdFRyYWNlQ29udGV4dCgpIHtcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgb3RlbCA9IHlpZWxkIGxvYWRPdGVsKCk7XG4gICAgICAgICAgICBpZiAoIW90ZWwgfHwgIW90ZWwucHJvcGFnYXRpb24gfHwgIW90ZWwuY29udGV4dCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgY2FycmllciA9IHt9O1xuICAgICAgICAgICAgb3RlbC5wcm9wYWdhdGlvbi5pbmplY3Qob3RlbC5jb250ZXh0LmFjdGl2ZSgpLCBjYXJyaWVyKTtcbiAgICAgICAgICAgIGNvbnN0IHRyYWNlcGFyZW50ID0gY2FycmllclsndHJhY2VwYXJlbnQnXTtcbiAgICAgICAgICAgIGlmICghdHJhY2VwYXJlbnQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdHJhY2VwYXJlbnQsXG4gICAgICAgICAgICAgICAgdHJhY2VzdGF0ZTogY2FycmllclsndHJhY2VzdGF0ZSddLFxuICAgICAgICAgICAgICAgIGJhZ2dhZ2U6IGNhcnJpZXJbJ2JhZ2dhZ2UnXSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXh0cmFjdC5qcy5tYXAiLCIvKipcbiAqIFBhcnNlIFczQyB0cmFjZXBhcmVudCBoZWFkZXIgYWNjb3JkaW5nIHRvIHRoZSBzcGVjaWZpY2F0aW9uLlxuICpcbiAqIFRoZSB0cmFjZXBhcmVudCBoZWFkZXIgZm9ybWF0IGlzOiB2ZXJzaW9uLXRyYWNlaWQtcGFyZW50aWQtdHJhY2VmbGFnc1xuICogLSB2ZXJzaW9uOiAyIGhleCBkaWdpdHMgKGN1cnJlbnRseSBhbHdheXMgXCIwMFwiKVxuICogLSB0cmFjZWlkOiAzMiBoZXggZGlnaXRzICgxMjgtYml0IHRyYWNlIGlkZW50aWZpZXIpXG4gKiAtIHBhcmVudGlkOiAxNiBoZXggZGlnaXRzICg2NC1iaXQgc3Bhbi9wYXJlbnQgaWRlbnRpZmllcilcbiAqIC0gdHJhY2VmbGFnczogMiBoZXggZGlnaXRzICg4LWJpdCBmbGFncywgYml0IDAgaXMgc2FtcGxlZCBmbGFnKVxuICpcbiAqIEBwYXJhbSB0cmFjZXBhcmVudCAtIFRoZSB0cmFjZXBhcmVudCBoZWFkZXIgdmFsdWVcbiAqIEByZXR1cm5zIFBhcnNlZCB0cmFjZXBhcmVudCBvYmplY3QsIG9yIG51bGwgaWYgaW52YWxpZCBmb3JtYXRcbiAqXG4gKiBAc2VlIGh0dHBzOi8vd3d3LnczLm9yZy9UUi90cmFjZS1jb250ZXh0LyN0cmFjZXBhcmVudC1oZWFkZXJcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHlwZXNjcmlwdFxuICogY29uc3QgcGFyc2VkID0gcGFyc2VUcmFjZVBhcmVudCgnMDAtMGFmNzY1MTkxNmNkNDNkZDg0NDhlYjIxMWM4MDMxOWMtYjdhZDZiNzE2OTIwMzMzMS0wMScpXG4gKlxuICogY29uc29sZS5sb2cocGFyc2VkKVxuICogLy8ge1xuICogLy8gICB2ZXJzaW9uOiAnMDAnLFxuICogLy8gICB0cmFjZUlkOiAnMGFmNzY1MTkxNmNkNDNkZDg0NDhlYjIxMWM4MDMxOWMnLFxuICogLy8gICBwYXJlbnRJZDogJ2I3YWQ2YjcxNjkyMDMzMzEnLFxuICogLy8gICB0cmFjZUZsYWdzOiAnMDEnLFxuICogLy8gICBpc1NhbXBsZWQ6IHRydWVcbiAqIC8vIH1cbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VUcmFjZVBhcmVudCh0cmFjZXBhcmVudCkge1xuICAgIGlmICghdHJhY2VwYXJlbnQgfHwgdHlwZW9mIHRyYWNlcGFyZW50ICE9PSAnc3RyaW5nJykge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgLy8gU3BsaXQgYnkgaHlwaGVuXG4gICAgY29uc3QgcGFydHMgPSB0cmFjZXBhcmVudC5zcGxpdCgnLScpO1xuICAgIC8vIE11c3QgaGF2ZSBleGFjdGx5IDQgcGFydHNcbiAgICBpZiAocGFydHMubGVuZ3RoICE9PSA0KSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBbdmVyc2lvbiwgdHJhY2VJZCwgcGFyZW50SWQsIHRyYWNlRmxhZ3NdID0gcGFydHM7XG4gICAgLy8gVmFsaWRhdGUgZmllbGQgbGVuZ3RocyBhY2NvcmRpbmcgdG8gVzNDIHNwZWNcbiAgICBpZiAodmVyc2lvbi5sZW5ndGggIT09IDIgfHxcbiAgICAgICAgdHJhY2VJZC5sZW5ndGggIT09IDMyIHx8XG4gICAgICAgIHBhcmVudElkLmxlbmd0aCAhPT0gMTYgfHxcbiAgICAgICAgdHJhY2VGbGFncy5sZW5ndGggIT09IDIpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8vIFZhbGlkYXRlIHRoYXQgYWxsIGZpZWxkcyBhcmUgdmFsaWQgaGV4YWRlY2ltYWxcbiAgICBjb25zdCBoZXhSZWdleCA9IC9eWzAtOWEtZl0rJC9pO1xuICAgIGlmICghaGV4UmVnZXgudGVzdCh2ZXJzaW9uKSB8fFxuICAgICAgICAhaGV4UmVnZXgudGVzdCh0cmFjZUlkKSB8fFxuICAgICAgICAhaGV4UmVnZXgudGVzdChwYXJlbnRJZCkgfHxcbiAgICAgICAgIWhleFJlZ2V4LnRlc3QodHJhY2VGbGFncykpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8vIFZhbGlkYXRlIHRoYXQgdHJhY2UtaWQgYW5kIHBhcmVudC1pZCBhcmUgbm90IGFsbCB6ZXJvcyAoaW52YWxpZCBwZXIgc3BlYylcbiAgICBpZiAodHJhY2VJZCA9PT0gJzAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwJyB8fCBwYXJlbnRJZCA9PT0gJzAwMDAwMDAwMDAwMDAwMDAnKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICAvLyBQYXJzZSBzYW1wbGluZyBkZWNpc2lvbiBmcm9tIHRyYWNlLWZsYWdzIChiaXQgMClcbiAgICBjb25zdCBmbGFncyA9IHBhcnNlSW50KHRyYWNlRmxhZ3MsIDE2KTtcbiAgICBjb25zdCBpc1NhbXBsZWQgPSAoZmxhZ3MgJiAweDAxKSA9PT0gMHgwMTtcbiAgICByZXR1cm4ge1xuICAgICAgICB2ZXJzaW9uLFxuICAgICAgICB0cmFjZUlkLFxuICAgICAgICBwYXJlbnRJZCxcbiAgICAgICAgdHJhY2VGbGFncyxcbiAgICAgICAgaXNTYW1wbGVkLFxuICAgIH07XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYXJzZS5qcy5tYXAiLCIvKipcbiAqIENoZWNrIGlmIHRyYWNlIGNvbnRleHQgc2hvdWxkIGJlIHByb3BhZ2F0ZWQgdG8gdGhlIHRhcmdldCBVUkwuXG4gKlxuICogVGhpcyBmdW5jdGlvbiBjaGVja3MgaWYgdGhlIHRhcmdldCBVUkwgbWF0Y2hlcyBhbnkgb2YgdGhlIGNvbmZpZ3VyZWRcbiAqIHByb3BhZ2F0aW9uIHRhcmdldHMuIFRhcmdldHMgY2FuIGJlOlxuICogLSBTdHJpbmc6IEV4YWN0IGhvc3RuYW1lIG1hdGNoIG9yIHdpbGRjYXJkIGRvbWFpbiAoKi5leGFtcGxlLmNvbSlcbiAqIC0gUmVnRXhwOiBQYXR0ZXJuIG1hdGNoaW5nIGhvc3RuYW1lXG4gKiAtIEZ1bmN0aW9uOiBDdXN0b20gbG9naWMgdG8gZGV0ZXJtaW5lIGlmIFVSTCBzaG91bGQgcmVjZWl2ZSB0cmFjZSBjb250ZXh0XG4gKlxuICogQHBhcmFtIHRhcmdldFVybCAtIFRoZSBVUkwgdG8gY2hlY2tcbiAqIEBwYXJhbSB0YXJnZXRzIC0gQXJyYXkgb2YgcHJvcGFnYXRpb24gdGFyZ2V0c1xuICogQHJldHVybnMgVHJ1ZSBpZiB0cmFjZSBjb250ZXh0IHNob3VsZCBiZSBwcm9wYWdhdGVkLCBmYWxzZSBvdGhlcndpc2VcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHlwZXNjcmlwdFxuICogY29uc3QgdGFyZ2V0cyA9IFtcbiAqICAgJ215cHJvamVjdC5zdXBhYmFzZS5jbycsICAgICAgICAgICAvLyBFeGFjdCBtYXRjaFxuICogICAnKi5zdXBhYmFzZS5jbycsICAgICAgICAgICAgICAgICAgIC8vIFdpbGRjYXJkIGRvbWFpblxuICogICAvLipcXC5zdXBhYmFzZVxcLmNvJC8sICAgICAgICAgICAgICAgLy8gUmVnZXggcGF0dGVyblxuICogICAodXJsKSA9PiB1cmwuaG9zdG5hbWUgPT09ICdsb2NhbGhvc3QnIC8vIEN1c3RvbSBmdW5jdGlvblxuICogXVxuICpcbiAqIHNob3VsZFByb3BhZ2F0ZVRvVGFyZ2V0KCdodHRwczovL215cHJvamVjdC5zdXBhYmFzZS5jby9yZXN0L3YxL3RhYmxlJywgdGFyZ2V0cylcbiAqIC8vIHRydWVcbiAqXG4gKiBzaG91bGRQcm9wYWdhdGVUb1RhcmdldCgnaHR0cHM6Ly9ldmlsLmNvbS9hcGknLCB0YXJnZXRzKVxuICogLy8gZmFsc2VcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2hvdWxkUHJvcGFnYXRlVG9UYXJnZXQodGFyZ2V0VXJsLCB0YXJnZXRzKSB7XG4gICAgaWYgKCF0YXJnZXRVcmwgfHwgIXRhcmdldHMgfHwgdGFyZ2V0cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBsZXQgdXJsO1xuICAgIGlmICh0YXJnZXRVcmwgaW5zdGFuY2VvZiBVUkwpIHtcbiAgICAgICAgdXJsID0gdGFyZ2V0VXJsO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHVybCA9IG5ldyBVUkwodGFyZ2V0VXJsKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIC8vIEludmFsaWQgVVJMXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gQ2hlY2sgZWFjaCB0YXJnZXRcbiAgICBmb3IgKGNvbnN0IHRhcmdldCBvZiB0YXJnZXRzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICAvLyBTdHJpbmcgbWF0Y2hlcjogZXhhY3QgbWF0Y2ggb3Igd2lsZGNhcmQgZG9tYWluXG4gICAgICAgICAgICAgICAgaWYgKG1hdGNoU3RyaW5nVGFyZ2V0KHVybC5ob3N0bmFtZSwgdGFyZ2V0KSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0YXJnZXQgaW5zdGFuY2VvZiBSZWdFeHApIHtcbiAgICAgICAgICAgICAgICAvLyBSZWdleCBtYXRjaGVyXG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldC50ZXN0KHVybC5ob3N0bmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIC8vIEZ1bmN0aW9uIG1hdGNoZXJcbiAgICAgICAgICAgICAgICBpZiAodGFyZ2V0KHVybCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgLy8gSWdub3JlIGVycm9ycyBmcm9tIGluZGl2aWR1YWwgbWF0Y2hlcnMgYW5kIGNvbnRpbnVlXG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59XG4vKipcbiAqIE1hdGNoIGhvc3RuYW1lIGFnYWluc3Qgc3RyaW5nIHRhcmdldCAoZXhhY3QgbWF0Y2ggb3Igd2lsZGNhcmQpXG4gKlxuICogQHBhcmFtIGhvc3RuYW1lIC0gVGhlIGhvc3RuYW1lIHRvIGNoZWNrXG4gKiBAcGFyYW0gdGFyZ2V0IC0gVGhlIHRhcmdldCBwYXR0ZXJuIChleGFjdCBvciB3aWxkY2FyZClcbiAqIEByZXR1cm5zIFRydWUgaWYgaG9zdG5hbWUgbWF0Y2hlcyB0YXJnZXRcbiAqL1xuZnVuY3Rpb24gbWF0Y2hTdHJpbmdUYXJnZXQoaG9zdG5hbWUsIHRhcmdldCkge1xuICAgIC8vIEV4YWN0IG1hdGNoXG4gICAgaWYgKHRhcmdldCA9PT0gaG9zdG5hbWUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIC8vIFdpbGRjYXJkIGRvbWFpbiBtYXRjaCAoKi5leGFtcGxlLmNvbSlcbiAgICBpZiAodGFyZ2V0LnN0YXJ0c1dpdGgoJyouJykpIHtcbiAgICAgICAgY29uc3QgZG9tYWluID0gdGFyZ2V0LnNsaWNlKDIpOyAvLyBSZW1vdmUgXCIqLlwiXG4gICAgICAgIC8vIENoZWNrIGlmIGhvc3RuYW1lIGVuZHMgd2l0aCB0aGUgZG9tYWluXG4gICAgICAgIGlmIChob3N0bmFtZS5lbmRzV2l0aChkb21haW4pKSB7XG4gICAgICAgICAgICAvLyBFbnN1cmUgaXQncyBlaXRoZXIgYW4gZXhhY3QgbWF0Y2ggb3IgaGFzIGEgc3ViZG9tYWluXG4gICAgICAgICAgICAvLyAocHJldmVudHMgXCJub3RleGFtcGxlLmNvbVwiIGZyb20gbWF0Y2hpbmcgXCIqLmV4YW1wbGUuY29tXCIpXG4gICAgICAgICAgICBpZiAoaG9zdG5hbWUgPT09IGRvbWFpbiB8fCBob3N0bmFtZS5lbmRzV2l0aCgnLicgKyBkb21haW4pKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dmFsaWRhdGUuanMubWFwIiwiLyoqXG4gKiBHZW5lcmF0ZSBkZWZhdWx0IHByb3BhZ2F0aW9uIHRhcmdldHMgYmFzZWQgb24gdGhlIFN1cGFiYXNlIHByb2plY3QgVVJMLlxuICpcbiAqIEJ5IGRlZmF1bHQsIHRyYWNlIGNvbnRleHQgaXMgb25seSBwcm9wYWdhdGVkIHRvIFN1cGFiYXNlIGRvbWFpbnMgZm9yXG4gKiBzZWN1cml0eS4gVGhpcyBwcmV2ZW50cyBsZWFraW5nIHRyYWNlIGNvbnRleHQgdG8gcG90ZW50aWFsbHkgbWFsaWNpb3VzXG4gKiB0aGlyZC1wYXJ0eSBzZXJ2aWNlcy5cbiAqXG4gKiBXaWxkY2FyZCBzdHJpbmdzIChlLmcuIGAqLnN1cGFiYXNlLmNvYCkgYXJlIG1hdGNoZWQgd2l0aCBsaW5lYXIgc3RyaW5nXG4gKiBvcGVyYXRpb25zIHJhdGhlciB0aGFuIHJlZ2V4LCBhdm9pZGluZyBSZURvUyByaXNrLlxuICpcbiAqIEBwYXJhbSBzdXBhYmFzZVVybCAtIFRoZSBTdXBhYmFzZSBwcm9qZWN0IFVSTFxuICogQHJldHVybnMgQXJyYXkgb2YgZGVmYXVsdCBwcm9wYWdhdGlvbiB0YXJnZXRzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZWZhdWx0UHJvcGFnYXRpb25UYXJnZXRzKHN1cGFiYXNlVXJsKSB7XG4gICAgY29uc3QgdGFyZ2V0cyA9IFtdO1xuICAgIC8vIEFkZCBleGFjdCBwcm9qZWN0IGhvc3RuYW1lXG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdXJsID0gbmV3IFVSTChzdXBhYmFzZVVybCk7XG4gICAgICAgIHRhcmdldHMucHVzaCh1cmwuaG9zdG5hbWUpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gSW52YWxpZCBVUkwsIHNraXAgZXhhY3QgaG9zdG5hbWVcbiAgICB9XG4gICAgLy8gU3VwYWJhc2UgY2xvdWQgZG9tYWlucy4gVXNlIHdpbGRjYXJkIHN0cmluZ3MgKG5vdCByZWdleCkg4oCUIHRoZXNlIGFyZVxuICAgIC8vIG1hdGNoZWQgYnkgbGluZWFyIGhvc3RuYW1lLXN1ZmZpeCBjaGVja3MsIHNvIHRoZXJlIGlzIG5vIFJlRG9TIHN1cmZhY2UuXG4gICAgdGFyZ2V0cy5wdXNoKCcqLnN1cGFiYXNlLmNvJywgJyouc3VwYWJhc2UuaW4nKTtcbiAgICAvLyBMb2NhbGhvc3QgYW5kIGxvb3BiYWNrIGFkZHJlc3NlcyBmb3IgbG9jYWwgZGV2ZWxvcG1lbnQuXG4gICAgdGFyZ2V0cy5wdXNoKCdsb2NhbGhvc3QnLCAnMTI3LjAuMC4xJywgJ1s6OjFdJyk7XG4gICAgcmV0dXJuIHRhcmdldHM7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1kZWZhdWx0cy5qcy5tYXAiLCJpbXBvcnQge1xuICBleHRyYWN0VHJhY2VDb250ZXh0LFxuICBwYXJzZVRyYWNlUGFyZW50LFxuICBzaG91bGRQcm9wYWdhdGVUb1RhcmdldCxcbiAgZ2V0RGVmYXVsdFByb3BhZ2F0aW9uVGFyZ2V0cyxcbiAgdHlwZSBUcmFjZUNvbnRleHQsXG4gIHR5cGUgVHJhY2VQcm9wYWdhdGlvblRhcmdldCxcbn0gZnJvbSAnQHN1cGFiYXNlL3RyYWNpbmcnXG5pbXBvcnQgdHlwZSB7IFRyYWNlUHJvcGFnYXRpb25PcHRpb25zIH0gZnJvbSAnLi90eXBlcydcblxudHlwZSBGZXRjaCA9IHR5cGVvZiBmZXRjaFxuXG5leHBvcnQgY29uc3QgcmVzb2x2ZUZldGNoID0gKGN1c3RvbUZldGNoPzogRmV0Y2gpOiBGZXRjaCA9PiB7XG4gIGlmIChjdXN0b21GZXRjaCkge1xuICAgIHJldHVybiAoLi4uYXJnczogUGFyYW1ldGVyczxGZXRjaD4pID0+IGN1c3RvbUZldGNoKC4uLmFyZ3MpXG4gIH1cbiAgcmV0dXJuICguLi5hcmdzOiBQYXJhbWV0ZXJzPEZldGNoPikgPT4gZmV0Y2goLi4uYXJncylcbn1cblxuZXhwb3J0IGNvbnN0IHJlc29sdmVIZWFkZXJzQ29uc3RydWN0b3IgPSAoKSA9PiB7XG4gIHJldHVybiBIZWFkZXJzXG59XG5cbmV4cG9ydCBjb25zdCBmZXRjaFdpdGhBdXRoID0gKFxuICBzdXBhYmFzZUtleTogc3RyaW5nLFxuICBzdXBhYmFzZVVybDogc3RyaW5nLFxuICBnZXRBY2Nlc3NUb2tlbjogKCkgPT4gUHJvbWlzZTxzdHJpbmcgfCBudWxsPixcbiAgY3VzdG9tRmV0Y2g/OiBGZXRjaCxcbiAgdHJhY2VQcm9wYWdhdGlvbk9wdGlvbnM/OiBUcmFjZVByb3BhZ2F0aW9uT3B0aW9uc1xuKTogRmV0Y2ggPT4ge1xuICBjb25zdCBmZXRjaCA9IHJlc29sdmVGZXRjaChjdXN0b21GZXRjaClcbiAgY29uc3QgSGVhZGVyc0NvbnN0cnVjdG9yID0gcmVzb2x2ZUhlYWRlcnNDb25zdHJ1Y3RvcigpXG5cbiAgLy8gUHJlLWNvbXB1dGUgdHJhY2UgcHJvcGFnYXRpb24gc3RhdGUgb25jZS4gV2hlbiBkaXNhYmxlZCwgdGhlIHBlci1yZXF1ZXN0XG4gIC8vIHBhdGggc2tpcHMgYWxsIHRyYWNpbmcgd29yayB3aXRoIGEgc2luZ2xlIHRydXRoeSBjaGVjay5cbiAgY29uc3QgdHJhY2VFbmFibGVkID0gdHJhY2VQcm9wYWdhdGlvbk9wdGlvbnM/LmVuYWJsZWQgPT09IHRydWVcbiAgY29uc3QgcmVzcGVjdFNhbXBsaW5nID0gdHJhY2VQcm9wYWdhdGlvbk9wdGlvbnM/LnJlc3BlY3RTYW1wbGluZ0RlY2lzaW9uICE9PSBmYWxzZVxuICBjb25zdCB0cmFjZVRhcmdldHM6IFRyYWNlUHJvcGFnYXRpb25UYXJnZXRbXSB8IG51bGwgPSB0cmFjZUVuYWJsZWRcbiAgICA/IGdldERlZmF1bHRQcm9wYWdhdGlvblRhcmdldHMoc3VwYWJhc2VVcmwpXG4gICAgOiBudWxsXG5cbiAgcmV0dXJuIGFzeW5jIChpbnB1dCwgaW5pdCkgPT4ge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gKGF3YWl0IGdldEFjY2Vzc1Rva2VuKCkpID8/IHN1cGFiYXNlS2V5XG4gICAgbGV0IGhlYWRlcnMgPSBuZXcgSGVhZGVyc0NvbnN0cnVjdG9yKGluaXQ/LmhlYWRlcnMpXG5cbiAgICBpZiAoIWhlYWRlcnMuaGFzKCdhcGlrZXknKSkge1xuICAgICAgaGVhZGVycy5zZXQoJ2FwaWtleScsIHN1cGFiYXNlS2V5KVxuICAgIH1cblxuICAgIGlmICghaGVhZGVycy5oYXMoJ0F1dGhvcml6YXRpb24nKSkge1xuICAgICAgaGVhZGVycy5zZXQoJ0F1dGhvcml6YXRpb24nLCBgQmVhcmVyICR7YWNjZXNzVG9rZW59YClcbiAgICB9XG5cbiAgICBpZiAodHJhY2VUYXJnZXRzKSB7XG4gICAgICBjb25zdCB0cmFjZUhlYWRlcnMgPSBhd2FpdCBnZXRUcmFjZUhlYWRlcnMoaW5wdXQsIHRyYWNlVGFyZ2V0cywgcmVzcGVjdFNhbXBsaW5nKVxuXG4gICAgICBpZiAodHJhY2VIZWFkZXJzKSB7XG4gICAgICAgIGlmICh0cmFjZUhlYWRlcnMudHJhY2VwYXJlbnQgJiYgIWhlYWRlcnMuaGFzKCd0cmFjZXBhcmVudCcpKSB7XG4gICAgICAgICAgaGVhZGVycy5zZXQoJ3RyYWNlcGFyZW50JywgdHJhY2VIZWFkZXJzLnRyYWNlcGFyZW50KVxuICAgICAgICB9XG4gICAgICAgIGlmICh0cmFjZUhlYWRlcnMudHJhY2VzdGF0ZSAmJiAhaGVhZGVycy5oYXMoJ3RyYWNlc3RhdGUnKSkge1xuICAgICAgICAgIGhlYWRlcnMuc2V0KCd0cmFjZXN0YXRlJywgdHJhY2VIZWFkZXJzLnRyYWNlc3RhdGUpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRyYWNlSGVhZGVycy5iYWdnYWdlICYmICFoZWFkZXJzLmhhcygnYmFnZ2FnZScpKSB7XG4gICAgICAgICAgaGVhZGVycy5zZXQoJ2JhZ2dhZ2UnLCB0cmFjZUhlYWRlcnMuYmFnZ2FnZSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBmZXRjaChpbnB1dCwgeyAuLi5pbml0LCBoZWFkZXJzIH0pXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2V0VHJhY2VIZWFkZXJzKFxuICBpbnB1dDogUmVxdWVzdEluZm8gfCBVUkwsXG4gIHRhcmdldHM6IFRyYWNlUHJvcGFnYXRpb25UYXJnZXRbXSxcbiAgcmVzcGVjdFNhbXBsaW5nOiBib29sZWFuXG4pOiBQcm9taXNlPFRyYWNlQ29udGV4dCB8IG51bGw+IHtcbiAgY29uc3QgdGFyZ2V0VXJsOiBzdHJpbmcgfCBVUkwgPVxuICAgIHR5cGVvZiBpbnB1dCA9PT0gJ3N0cmluZycgPyBpbnB1dCA6IGlucHV0IGluc3RhbmNlb2YgVVJMID8gaW5wdXQgOiBpbnB1dC51cmxcblxuICBpZiAoIXNob3VsZFByb3BhZ2F0ZVRvVGFyZ2V0KHRhcmdldFVybCwgdGFyZ2V0cykpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgY29uc3QgdHJhY2VDb250ZXh0ID0gYXdhaXQgZXh0cmFjdFRyYWNlQ29udGV4dCgpXG5cbiAgaWYgKCF0cmFjZUNvbnRleHQgfHwgIXRyYWNlQ29udGV4dC50cmFjZXBhcmVudCkge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBpZiAocmVzcGVjdFNhbXBsaW5nKSB7XG4gICAgY29uc3QgcGFyc2VkID0gcGFyc2VUcmFjZVBhcmVudCh0cmFjZUNvbnRleHQudHJhY2VwYXJlbnQpXG4gICAgaWYgKHBhcnNlZCAmJiAhcGFyc2VkLmlzU2FtcGxlZCkge1xuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdHJhY2VDb250ZXh0XG59XG4iLCIvLyBoZWxwZXJzLnRzXG5pbXBvcnQgeyBTdXBhYmFzZUNsaWVudE9wdGlvbnMsIFRyYWNlUHJvcGFnYXRpb25PcHRpb25zIH0gZnJvbSAnLi90eXBlcydcblxuZnVuY3Rpb24gbm9ybWFsaXplVHJhY2VQcm9wYWdhdGlvbihcbiAgdmFsdWU6IFRyYWNlUHJvcGFnYXRpb25PcHRpb25zIHwgYm9vbGVhbiB8IHVuZGVmaW5lZFxuKTogVHJhY2VQcm9wYWdhdGlvbk9wdGlvbnMgfCB1bmRlZmluZWQge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicgPyB7IGVuYWJsZWQ6IHZhbHVlIH0gOiB2YWx1ZVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXVpZCgpIHtcbiAgcmV0dXJuICd4eHh4eHh4eC14eHh4LTR4eHgteXh4eC14eHh4eHh4eHh4eHgnLnJlcGxhY2UoL1t4eV0vZywgZnVuY3Rpb24gKGMpIHtcbiAgICB2YXIgciA9IChNYXRoLnJhbmRvbSgpICogMTYpIHwgMCxcbiAgICAgIHYgPSBjID09ICd4JyA/IHIgOiAociAmIDB4MykgfCAweDhcbiAgICByZXR1cm4gdi50b1N0cmluZygxNilcbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGVuc3VyZVRyYWlsaW5nU2xhc2godXJsOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gdXJsLmVuZHNXaXRoKCcvJykgPyB1cmwgOiB1cmwgKyAnLydcbn1cblxuZXhwb3J0IGNvbnN0IGlzQnJvd3NlciA9ICgpID0+IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnXG5cbmV4cG9ydCB0eXBlIFJlc29sdmVkU3VwYWJhc2VDbGllbnRPcHRpb25zPFNjaGVtYU5hbWU+ID0gT21pdDxcbiAgUmVxdWlyZWQ8U3VwYWJhc2VDbGllbnRPcHRpb25zPFNjaGVtYU5hbWU+PixcbiAgJ3RyYWNlUHJvcGFnYXRpb24nXG4+ICYge1xuICB0cmFjZVByb3BhZ2F0aW9uOiBUcmFjZVByb3BhZ2F0aW9uT3B0aW9uc1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlTZXR0aW5nRGVmYXVsdHM8XG4gIERhdGFiYXNlID0gYW55LFxuICBTY2hlbWFOYW1lIGV4dGVuZHMgc3RyaW5nICYga2V5b2YgRGF0YWJhc2UgPSAncHVibGljJyBleHRlbmRzIGtleW9mIERhdGFiYXNlXG4gICAgPyAncHVibGljJ1xuICAgIDogc3RyaW5nICYga2V5b2YgRGF0YWJhc2UsXG4+KFxuICBvcHRpb25zOiBTdXBhYmFzZUNsaWVudE9wdGlvbnM8U2NoZW1hTmFtZT4sXG4gIGRlZmF1bHRzOiBTdXBhYmFzZUNsaWVudE9wdGlvbnM8YW55PlxuKTogUmVzb2x2ZWRTdXBhYmFzZUNsaWVudE9wdGlvbnM8U2NoZW1hTmFtZT4ge1xuICBjb25zdCB7XG4gICAgZGI6IGRiT3B0aW9ucyxcbiAgICBhdXRoOiBhdXRoT3B0aW9ucyxcbiAgICByZWFsdGltZTogcmVhbHRpbWVPcHRpb25zLFxuICAgIGdsb2JhbDogZ2xvYmFsT3B0aW9ucyxcbiAgfSA9IG9wdGlvbnNcbiAgY29uc3Qge1xuICAgIGRiOiBERUZBVUxUX0RCX09QVElPTlMsXG4gICAgYXV0aDogREVGQVVMVF9BVVRIX09QVElPTlMsXG4gICAgcmVhbHRpbWU6IERFRkFVTFRfUkVBTFRJTUVfT1BUSU9OUyxcbiAgICBnbG9iYWw6IERFRkFVTFRfR0xPQkFMX09QVElPTlMsXG4gIH0gPSBkZWZhdWx0c1xuXG4gIC8vIEFjY2VwdCBlaXRoZXIgYSBib29sZWFuIHNob3J0aGFuZCBvciBhbiBvcHRpb25zIG9iamVjdCBvbiBib3RoIHNpZGVzLlxuICBjb25zdCB0cmFjZVByb3BhZ2F0aW9uT3B0aW9ucyA9IG5vcm1hbGl6ZVRyYWNlUHJvcGFnYXRpb24ob3B0aW9ucy50cmFjZVByb3BhZ2F0aW9uKVxuICBjb25zdCBERUZBVUxUX1RSQUNFX1BST1BBR0FUSU9OX09QVElPTlMgPSBub3JtYWxpemVUcmFjZVByb3BhZ2F0aW9uKGRlZmF1bHRzLnRyYWNlUHJvcGFnYXRpb24pXG5cbiAgY29uc3QgcmVzdWx0OiBSZXNvbHZlZFN1cGFiYXNlQ2xpZW50T3B0aW9uczxTY2hlbWFOYW1lPiA9IHtcbiAgICBkYjoge1xuICAgICAgLi4uREVGQVVMVF9EQl9PUFRJT05TLFxuICAgICAgLi4uZGJPcHRpb25zLFxuICAgIH0sXG4gICAgYXV0aDoge1xuICAgICAgLi4uREVGQVVMVF9BVVRIX09QVElPTlMsXG4gICAgICAuLi5hdXRoT3B0aW9ucyxcbiAgICB9LFxuICAgIHJlYWx0aW1lOiB7XG4gICAgICAuLi5ERUZBVUxUX1JFQUxUSU1FX09QVElPTlMsXG4gICAgICAuLi5yZWFsdGltZU9wdGlvbnMsXG4gICAgfSxcbiAgICBzdG9yYWdlOiB7fSxcbiAgICBnbG9iYWw6IHtcbiAgICAgIC4uLkRFRkFVTFRfR0xPQkFMX09QVElPTlMsXG4gICAgICAuLi5nbG9iYWxPcHRpb25zLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAuLi4oREVGQVVMVF9HTE9CQUxfT1BUSU9OUz8uaGVhZGVycyA/PyB7fSksXG4gICAgICAgIC4uLihnbG9iYWxPcHRpb25zPy5oZWFkZXJzID8/IHt9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB0cmFjZVByb3BhZ2F0aW9uOiB7XG4gICAgICBlbmFibGVkOlxuICAgICAgICB0cmFjZVByb3BhZ2F0aW9uT3B0aW9ucz8uZW5hYmxlZCA/PyBERUZBVUxUX1RSQUNFX1BST1BBR0FUSU9OX09QVElPTlM/LmVuYWJsZWQgPz8gZmFsc2UsXG4gICAgICByZXNwZWN0U2FtcGxpbmdEZWNpc2lvbjpcbiAgICAgICAgdHJhY2VQcm9wYWdhdGlvbk9wdGlvbnM/LnJlc3BlY3RTYW1wbGluZ0RlY2lzaW9uID8/XG4gICAgICAgIERFRkFVTFRfVFJBQ0VfUFJPUEFHQVRJT05fT1BUSU9OUz8ucmVzcGVjdFNhbXBsaW5nRGVjaXNpb24gPz9cbiAgICAgICAgdHJ1ZSxcbiAgICB9LFxuICAgIGFjY2Vzc1Rva2VuOiBhc3luYyAoKSA9PiAnJyxcbiAgfVxuXG4gIGlmIChvcHRpb25zLmFjY2Vzc1Rva2VuKSB7XG4gICAgcmVzdWx0LmFjY2Vzc1Rva2VuID0gb3B0aW9ucy5hY2Nlc3NUb2tlblxuICB9IGVsc2Uge1xuICAgIC8vIGhhY2sgYXJvdW5kIFJlcXVpcmVkPD5cbiAgICBkZWxldGUgKHJlc3VsdCBhcyBhbnkpLmFjY2Vzc1Rva2VuXG4gIH1cblxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8qKlxuICogVmFsaWRhdGVzIGEgU3VwYWJhc2UgY2xpZW50IFVSTFxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBzdXBhYmFzZVVybCAtIFRoZSBTdXBhYmFzZSBjbGllbnQgVVJMIHN0cmluZy5cbiAqIEByZXR1cm5zIHtVUkx9IC0gVGhlIHZhbGlkYXRlZCBiYXNlIFVSTC5cbiAqIEB0aHJvd3Mge0Vycm9yfVxuICovXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVTdXBhYmFzZVVybChzdXBhYmFzZVVybDogc3RyaW5nKTogVVJMIHtcbiAgY29uc3QgdHJpbW1lZFVybCA9IHN1cGFiYXNlVXJsPy50cmltKClcblxuICBpZiAoIXRyaW1tZWRVcmwpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3N1cGFiYXNlVXJsIGlzIHJlcXVpcmVkLicpXG4gIH1cblxuICBpZiAoIXRyaW1tZWRVcmwubWF0Y2goL15odHRwcz86XFwvXFwvL2kpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHN1cGFiYXNlVXJsOiBNdXN0IGJlIGEgdmFsaWQgSFRUUCBvciBIVFRQUyBVUkwuJylcbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIG5ldyBVUkwoZW5zdXJlVHJhaWxpbmdTbGFzaCh0cmltbWVkVXJsKSlcbiAgfSBjYXRjaCB7XG4gICAgdGhyb3cgRXJyb3IoJ0ludmFsaWQgc3VwYWJhc2VVcmw6IFByb3ZpZGVkIFVSTCBpcyBtYWxmb3JtZWQuJylcbiAgfVxufVxuIiwiaW1wb3J0IHsgQXV0aENsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9hdXRoLWpzJ1xuaW1wb3J0IHsgU3VwYWJhc2VBdXRoQ2xpZW50T3B0aW9ucyB9IGZyb20gJy4vdHlwZXMnXG5cbmV4cG9ydCBjbGFzcyBTdXBhYmFzZUF1dGhDbGllbnQgZXh0ZW5kcyBBdXRoQ2xpZW50IHtcbiAgY29uc3RydWN0b3Iob3B0aW9uczogU3VwYWJhc2VBdXRoQ2xpZW50T3B0aW9ucykge1xuICAgIHN1cGVyKG9wdGlvbnMpXG4gIH1cbn1cbiIsImltcG9ydCB0eXBlIHsgQXV0aENoYW5nZUV2ZW50IH0gZnJvbSAnQHN1cGFiYXNlL2F1dGgtanMnXG5pbXBvcnQgeyBGdW5jdGlvbnNDbGllbnQgfSBmcm9tICdAc3VwYWJhc2UvZnVuY3Rpb25zLWpzJ1xuaW1wb3J0IHtcbiAgUG9zdGdyZXN0Q2xpZW50LFxuICB0eXBlIFBvc3RncmVzdEZpbHRlckJ1aWxkZXIsXG4gIHR5cGUgUG9zdGdyZXN0UXVlcnlCdWlsZGVyLFxufSBmcm9tICdAc3VwYWJhc2UvcG9zdGdyZXN0LWpzJ1xuaW1wb3J0IHtcbiAgdHlwZSBSZWFsdGltZUNoYW5uZWwsXG4gIHR5cGUgUmVhbHRpbWVDaGFubmVsT3B0aW9ucyxcbiAgUmVhbHRpbWVDbGllbnQsXG4gIHR5cGUgUmVhbHRpbWVDbGllbnRPcHRpb25zLFxuICB0eXBlIFJlYWx0aW1lUmVtb3ZlQ2hhbm5lbFJlc3BvbnNlLFxufSBmcm9tICdAc3VwYWJhc2UvcmVhbHRpbWUtanMnXG5pbXBvcnQgeyBTdG9yYWdlQ2xpZW50IGFzIFN1cGFiYXNlU3RvcmFnZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdG9yYWdlLWpzJ1xuaW1wb3J0IHtcbiAgREVGQVVMVF9BVVRIX09QVElPTlMsXG4gIERFRkFVTFRfREJfT1BUSU9OUyxcbiAgREVGQVVMVF9HTE9CQUxfT1BUSU9OUyxcbiAgREVGQVVMVF9SRUFMVElNRV9PUFRJT05TLFxuICBERUZBVUxUX1RSQUNFX1BST1BBR0FUSU9OX09QVElPTlMsXG59IGZyb20gJy4vbGliL2NvbnN0YW50cydcbmltcG9ydCB7IGZldGNoV2l0aEF1dGggfSBmcm9tICcuL2xpYi9mZXRjaCdcbmltcG9ydCB7XG4gIGFwcGx5U2V0dGluZ0RlZmF1bHRzLFxuICB2YWxpZGF0ZVN1cGFiYXNlVXJsLFxuICB0eXBlIFJlc29sdmVkU3VwYWJhc2VDbGllbnRPcHRpb25zLFxufSBmcm9tICcuL2xpYi9oZWxwZXJzJ1xuaW1wb3J0IHsgU3VwYWJhc2VBdXRoQ2xpZW50IH0gZnJvbSAnLi9saWIvU3VwYWJhc2VBdXRoQ2xpZW50J1xuaW1wb3J0IHR5cGUge1xuICBGZXRjaCxcbiAgR2VuZXJpY1NjaGVtYSxcbiAgU3VwYWJhc2VBdXRoQ2xpZW50T3B0aW9ucyxcbiAgU3VwYWJhc2VDbGllbnRPcHRpb25zLFxufSBmcm9tICcuL2xpYi90eXBlcydcbmltcG9ydCB7IEdldFJwY0Z1bmN0aW9uRmlsdGVyQnVpbGRlckJ5QXJncyB9IGZyb20gJy4vbGliL3Jlc3QvdHlwZXMvY29tbW9uL3JwYydcblxuLyoqXG4gKiBTdXBhYmFzZSBDbGllbnQuXG4gKlxuICogQW4gaXNvbW9ycGhpYyBKYXZhc2NyaXB0IGNsaWVudCBmb3IgaW50ZXJhY3Rpbmcgd2l0aCBQb3N0Z3Jlcy5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU3VwYWJhc2VDbGllbnQ8XG4gIERhdGFiYXNlID0gYW55LFxuICAvLyBUaGUgc2Vjb25kIHR5cGUgcGFyYW1ldGVyIGlzIGFsc28gdXNlZCBmb3Igc3BlY2lmeWluZyBkYl9zY2hlbWEsIHNvIHdlXG4gIC8vIHN1cHBvcnQgYm90aCBjYXNlcy5cbiAgLy8gVE9ETzogQWxsb3cgc2V0dGluZyBkYl9zY2hlbWEgZnJvbSBDbGllbnRPcHRpb25zLlxuICBTY2hlbWFOYW1lT3JDbGllbnRPcHRpb25zIGV4dGVuZHNcbiAgICB8IChzdHJpbmcgJiBrZXlvZiBPbWl0PERhdGFiYXNlLCAnX19JbnRlcm5hbFN1cGFiYXNlJz4pXG4gICAgfCB7IFBvc3RncmVzdFZlcnNpb246IHN0cmluZyB9ID0gJ3B1YmxpYycgZXh0ZW5kcyBrZXlvZiBPbWl0PERhdGFiYXNlLCAnX19JbnRlcm5hbFN1cGFiYXNlJz5cbiAgICA/ICdwdWJsaWMnXG4gICAgOiBzdHJpbmcgJiBrZXlvZiBPbWl0PERhdGFiYXNlLCAnX19JbnRlcm5hbFN1cGFiYXNlJz4sXG4gIFNjaGVtYU5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBPbWl0PERhdGFiYXNlLCAnX19JbnRlcm5hbFN1cGFiYXNlJz4gPVxuICAgIFNjaGVtYU5hbWVPckNsaWVudE9wdGlvbnMgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBPbWl0PERhdGFiYXNlLCAnX19JbnRlcm5hbFN1cGFiYXNlJz5cbiAgICAgID8gU2NoZW1hTmFtZU9yQ2xpZW50T3B0aW9uc1xuICAgICAgOiAncHVibGljJyBleHRlbmRzIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPlxuICAgICAgICA/ICdwdWJsaWMnXG4gICAgICAgIDogc3RyaW5nICYga2V5b2YgT21pdDxPbWl0PERhdGFiYXNlLCAnX19JbnRlcm5hbFN1cGFiYXNlJz4sICdfX0ludGVybmFsU3VwYWJhc2UnPixcbiAgU2NoZW1hIGV4dGVuZHMgT21pdDxEYXRhYmFzZSwgJ19fSW50ZXJuYWxTdXBhYmFzZSc+W1NjaGVtYU5hbWVdIGV4dGVuZHMgR2VuZXJpY1NjaGVtYVxuICAgID8gT21pdDxEYXRhYmFzZSwgJ19fSW50ZXJuYWxTdXBhYmFzZSc+W1NjaGVtYU5hbWVdXG4gICAgOiBuZXZlciA9IE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPltTY2hlbWFOYW1lXSBleHRlbmRzIEdlbmVyaWNTY2hlbWFcbiAgICA/IE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPltTY2hlbWFOYW1lXVxuICAgIDogbmV2ZXIsXG4gIENsaWVudE9wdGlvbnMgZXh0ZW5kcyB7IFBvc3RncmVzdFZlcnNpb246IHN0cmluZyB9ID0gU2NoZW1hTmFtZU9yQ2xpZW50T3B0aW9ucyBleHRlbmRzIHN0cmluZyAmXG4gICAga2V5b2YgT21pdDxEYXRhYmFzZSwgJ19fSW50ZXJuYWxTdXBhYmFzZSc+XG4gICAgPyAvLyBJZiB0aGUgdmVyc2lvbiBpc24ndCBleHBsaWNpdGx5IHNldCwgbG9vayBmb3IgaXQgaW4gdGhlIF9fSW50ZXJuYWxTdXBhYmFzZSBvYmplY3QgdG8gaW5mZXIgdGhlIHJpZ2h0IHZlcnNpb25cbiAgICAgIERhdGFiYXNlIGV4dGVuZHMgeyBfX0ludGVybmFsU3VwYWJhc2U6IHsgUG9zdGdyZXN0VmVyc2lvbjogc3RyaW5nIH0gfVxuICAgICAgPyBEYXRhYmFzZVsnX19JbnRlcm5hbFN1cGFiYXNlJ11cbiAgICAgIDogLy8gb3RoZXJ3aXNlIGRlZmF1bHQgdG8gMTJcbiAgICAgICAgeyBQb3N0Z3Jlc3RWZXJzaW9uOiAnMTInIH1cbiAgICA6IFNjaGVtYU5hbWVPckNsaWVudE9wdGlvbnMgZXh0ZW5kcyB7IFBvc3RncmVzdFZlcnNpb246IHN0cmluZyB9XG4gICAgICA/IFNjaGVtYU5hbWVPckNsaWVudE9wdGlvbnNcbiAgICAgIDogbmV2ZXIsXG4+IHtcbiAgLyoqXG4gICAqIFN1cGFiYXNlIEF1dGggYWxsb3dzIHlvdSB0byBjcmVhdGUgYW5kIG1hbmFnZSB1c2VyIHNlc3Npb25zIGZvciBhY2Nlc3MgdG8gZGF0YSB0aGF0IGlzIHNlY3VyZWQgYnkgYWNjZXNzIHBvbGljaWVzLlxuICAgKi9cbiAgYXV0aDogU3VwYWJhc2VBdXRoQ2xpZW50XG4gIHJlYWx0aW1lOiBSZWFsdGltZUNsaWVudFxuICAvKipcbiAgICogU3VwYWJhc2UgU3RvcmFnZSBhbGxvd3MgeW91IHRvIG1hbmFnZSB1c2VyLWdlbmVyYXRlZCBjb250ZW50LCBzdWNoIGFzIHBob3RvcyBvciB2aWRlb3MuXG4gICAqL1xuICBzdG9yYWdlOiBTdXBhYmFzZVN0b3JhZ2VDbGllbnRcblxuICBwcm90ZWN0ZWQgcmVhbHRpbWVVcmw6IFVSTFxuICBwcm90ZWN0ZWQgYXV0aFVybDogVVJMXG4gIHByb3RlY3RlZCBzdG9yYWdlVXJsOiBVUkxcbiAgcHJvdGVjdGVkIGZ1bmN0aW9uc1VybDogVVJMXG4gIHByb3RlY3RlZCByZXN0OiBQb3N0Z3Jlc3RDbGllbnQ8RGF0YWJhc2UsIENsaWVudE9wdGlvbnMsIFNjaGVtYU5hbWU+XG4gIHByb3RlY3RlZCBzdG9yYWdlS2V5OiBzdHJpbmdcbiAgcHJvdGVjdGVkIGZldGNoPzogRmV0Y2hcbiAgcHJvdGVjdGVkIGNoYW5nZWRBY2Nlc3NUb2tlbj86IHN0cmluZ1xuICBwcm90ZWN0ZWQgYWNjZXNzVG9rZW4/OiAoKSA9PiBQcm9taXNlPHN0cmluZyB8IG51bGw+XG5cbiAgcHJvdGVjdGVkIGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbiAgcHJvdGVjdGVkIHNldHRpbmdzPzogUmVzb2x2ZWRTdXBhYmFzZUNsaWVudE9wdGlvbnM8U2NoZW1hTmFtZT5cblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IGNsaWVudCBmb3IgdXNlIGluIHRoZSBicm93c2VyLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgSW5pdGlhbGl6aW5nXG4gICAqXG4gICAqIEBwYXJhbSBzdXBhYmFzZVVybCBUaGUgdW5pcXVlIFN1cGFiYXNlIFVSTCB3aGljaCBpcyBzdXBwbGllZCB3aGVuIHlvdSBjcmVhdGUgYSBuZXcgcHJvamVjdCBpbiB5b3VyIHByb2plY3QgZGFzaGJvYXJkLlxuICAgKiBAcGFyYW0gc3VwYWJhc2VLZXkgVGhlIHVuaXF1ZSBTdXBhYmFzZSBLZXkgd2hpY2ggaXMgc3VwcGxpZWQgd2hlbiB5b3UgY3JlYXRlIGEgbmV3IHByb2plY3QgaW4geW91ciBwcm9qZWN0IGRhc2hib2FyZC5cbiAgICogQHBhcmFtIG9wdGlvbnMuZGIuc2NoZW1hIFlvdSBjYW4gc3dpdGNoIGluIGJldHdlZW4gc2NoZW1hcy4gVGhlIHNjaGVtYSBuZWVkcyB0byBiZSBvbiB0aGUgbGlzdCBvZiBleHBvc2VkIHNjaGVtYXMgaW5zaWRlIFN1cGFiYXNlLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5hdXRoLmF1dG9SZWZyZXNoVG9rZW4gU2V0IHRvIFwidHJ1ZVwiIGlmIHlvdSB3YW50IHRvIGF1dG9tYXRpY2FsbHkgcmVmcmVzaCB0aGUgdG9rZW4gYmVmb3JlIGV4cGlyaW5nLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5hdXRoLnBlcnNpc3RTZXNzaW9uIFNldCB0byBcInRydWVcIiBpZiB5b3Ugd2FudCB0byBhdXRvbWF0aWNhbGx5IHNhdmUgdGhlIHVzZXIgc2Vzc2lvbiBpbnRvIGxvY2FsIHN0b3JhZ2UuXG4gICAqIEBwYXJhbSBvcHRpb25zLmF1dGguZGV0ZWN0U2Vzc2lvbkluVXJsIFNldCB0byBcInRydWVcIiBpZiB5b3Ugd2FudCB0byBhdXRvbWF0aWNhbGx5IGRldGVjdHMgT0F1dGggZ3JhbnRzIGluIHRoZSBVUkwgYW5kIHNpZ25zIGluIHRoZSB1c2VyLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5yZWFsdGltZSBPcHRpb25zIHBhc3NlZCBhbG9uZyB0byByZWFsdGltZS1qcyBjb25zdHJ1Y3Rvci5cbiAgICogQHBhcmFtIG9wdGlvbnMuc3RvcmFnZSBPcHRpb25zIHBhc3NlZCBhbG9uZyB0byB0aGUgc3RvcmFnZS1qcyBjb25zdHJ1Y3Rvci5cbiAgICogQHBhcmFtIG9wdGlvbnMuZ2xvYmFsLmZldGNoIEEgY3VzdG9tIGZldGNoIGltcGxlbWVudGF0aW9uLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5nbG9iYWwuaGVhZGVycyBBbnkgYWRkaXRpb25hbCBoZWFkZXJzIHRvIHNlbmQgd2l0aCBlYWNoIG5ldHdvcmsgcmVxdWVzdC5cbiAgICpcbiAgICogQGV4YW1wbGUgQ3JlYXRpbmcgYSBjbGllbnRcbiAgICogYGBganNcbiAgICogaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3N1cGFiYXNlLWpzJ1xuICAgKlxuICAgKiAvLyBDcmVhdGUgYSBzaW5nbGUgc3VwYWJhc2UgY2xpZW50IGZvciBpbnRlcmFjdGluZyB3aXRoIHlvdXIgZGF0YWJhc2VcbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jbycsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGEgY3VzdG9tIGRvbWFpblxuICAgKiBgYGBqc1xuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqXG4gICAqIC8vIFVzZSBhIGN1c3RvbSBkb21haW4gYXMgdGhlIHN1cGFiYXNlIFVSTFxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudCgnaHR0cHM6Ly9teS1jdXN0b20tZG9tYWluLmNvbScsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGFkZGl0aW9uYWwgcGFyYW1ldGVyc1xuICAgKiBgYGBqc1xuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqXG4gICAqIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAqICAgZGI6IHtcbiAgICogICAgIHNjaGVtYTogJ3B1YmxpYycsXG4gICAqICAgfSxcbiAgICogICBhdXRoOiB7XG4gICAqICAgICBhdXRvUmVmcmVzaFRva2VuOiB0cnVlLFxuICAgKiAgICAgcGVyc2lzdFNlc3Npb246IHRydWUsXG4gICAqICAgICBkZXRlY3RTZXNzaW9uSW5Vcmw6IHRydWVcbiAgICogICB9LFxuICAgKiAgIGdsb2JhbDoge1xuICAgKiAgICAgaGVhZGVyczogeyAneC1teS1jdXN0b20taGVhZGVyJzogJ215LWFwcC1uYW1lJyB9LFxuICAgKiAgIH0sXG4gICAqIH1cbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXCJodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY29cIiwgXCJ5b3VyLXB1Ymxpc2hhYmxlLWtleVwiLCBvcHRpb25zKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBXaXRoIGN1c3RvbSBzY2hlbWFzXG4gICAqIEJ5IGRlZmF1bHQgdGhlIEFQSSBzZXJ2ZXIgcG9pbnRzIHRvIHRoZSBgcHVibGljYCBzY2hlbWEuIFlvdSBjYW4gZW5hYmxlIG90aGVyIGRhdGFiYXNlIHNjaGVtYXMgd2l0aGluIHRoZSBEYXNoYm9hcmQuXG4gICAqIEdvIHRvIFtTZXR0aW5ncyA+IEFQSSA+IEV4cG9zZWQgc2NoZW1hc10oL2Rhc2hib2FyZC9wcm9qZWN0L18vc2V0dGluZ3MvYXBpKSBhbmQgYWRkIHRoZSBzY2hlbWEgd2hpY2ggeW91IHdhbnQgdG8gZXhwb3NlIHRvIHRoZSBBUEkuXG4gICAqXG4gICAqIE5vdGU6IGVhY2ggY2xpZW50IGNvbm5lY3Rpb24gY2FuIG9ubHkgYWNjZXNzIGEgc2luZ2xlIHNjaGVtYSwgc28gdGhlIGNvZGUgYWJvdmUgY2FuIGFjY2VzcyB0aGUgYG90aGVyX3NjaGVtYWAgc2NoZW1hIGJ1dCBjYW5ub3QgYWNjZXNzIHRoZSBgcHVibGljYCBzY2hlbWEuXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggY3VzdG9tIHNjaGVtYXNcbiAgICogYGBganNcbiAgICogaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3N1cGFiYXNlLWpzJ1xuICAgKlxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudCgnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvJywgJ3lvdXItcHVibGlzaGFibGUta2V5Jywge1xuICAgKiAgIC8vIFByb3ZpZGUgYSBjdXN0b20gc2NoZW1hLiBEZWZhdWx0cyB0byBcInB1YmxpY1wiLlxuICAgKiAgIGRiOiB7IHNjaGVtYTogJ290aGVyX3NjaGVtYScgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBDdXN0b20gZmV0Y2ggaW1wbGVtZW50YXRpb25cbiAgICogYHN1cGFiYXNlLWpzYCB1c2VzIHRoZSBbYGNyb3NzLWZldGNoYF0oaHR0cHM6Ly93d3cubnBtanMuY29tL3BhY2thZ2UvY3Jvc3MtZmV0Y2gpIGxpYnJhcnkgdG8gbWFrZSBIVFRQIHJlcXVlc3RzLFxuICAgKiBidXQgYW4gYWx0ZXJuYXRpdmUgYGZldGNoYCBpbXBsZW1lbnRhdGlvbiBjYW4gYmUgcHJvdmlkZWQgYXMgYW4gb3B0aW9uLlxuICAgKiBUaGlzIGlzIG1vc3QgdXNlZnVsIGluIGVudmlyb25tZW50cyB3aGVyZSBgY3Jvc3MtZmV0Y2hgIGlzIG5vdCBjb21wYXRpYmxlIChmb3IgaW5zdGFuY2UgQ2xvdWRmbGFyZSBXb3JrZXJzKS5cbiAgICpcbiAgICogQGV4YW1wbGUgQ3VzdG9tIGZldGNoIGltcGxlbWVudGF0aW9uXG4gICAqIGBgYGpzXG4gICAqIGltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcydcbiAgICpcbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jbycsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScsIHtcbiAgICogICBnbG9iYWw6IHsgZmV0Y2g6IGZldGNoLmJpbmQoZ2xvYmFsVGhpcykgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBSZWFjdCBOYXRpdmUgb3B0aW9ucyB3aXRoIEFzeW5jU3RvcmFnZVxuICAgKiBGb3IgUmVhY3QgTmF0aXZlIHdlIHJlY29tbWVuZCB1c2luZyBgQXN5bmNTdG9yYWdlYCBhcyB0aGUgc3RvcmFnZSBpbXBsZW1lbnRhdGlvbiBmb3IgU3VwYWJhc2UgQXV0aC5cbiAgICpcbiAgICogQGV4YW1wbGUgUmVhY3QgTmF0aXZlIG9wdGlvbnMgd2l0aCBBc3luY1N0b3JhZ2VcbiAgICogYGBganNcbiAgICogaW1wb3J0ICdyZWFjdC1uYXRpdmUtdXJsLXBvbHlmaWxsL2F1dG8nXG4gICAqIGltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcydcbiAgICogaW1wb3J0IEFzeW5jU3RvcmFnZSBmcm9tIFwiQHJlYWN0LW5hdGl2ZS1hc3luYy1zdG9yYWdlL2FzeW5jLXN0b3JhZ2VcIjtcbiAgICpcbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXCJodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY29cIiwgXCJ5b3VyLXB1Ymxpc2hhYmxlLWtleVwiLCB7XG4gICAqICAgYXV0aDoge1xuICAgKiAgICAgc3RvcmFnZTogQXN5bmNTdG9yYWdlLFxuICAgKiAgICAgYXV0b1JlZnJlc2hUb2tlbjogdHJ1ZSxcbiAgICogICAgIHBlcnNpc3RTZXNzaW9uOiB0cnVlLFxuICAgKiAgICAgZGV0ZWN0U2Vzc2lvbkluVXJsOiBmYWxzZSxcbiAgICogICB9LFxuICAgKiB9KTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gUmVhY3QgTmF0aXZlIG9wdGlvbnMgd2l0aCBFeHBvIFNlY3VyZVN0b3JlXG4gICAqIElmIHlvdSB3aXNoIHRvIGVuY3J5cHQgdGhlIHVzZXIncyBzZXNzaW9uIGluZm9ybWF0aW9uLCB5b3UgY2FuIHVzZSBgYWVzLWpzYCBhbmQgc3RvcmUgdGhlIGVuY3J5cHRpb24ga2V5IGluIEV4cG8gU2VjdXJlU3RvcmUuXG4gICAqIFRoZSBgYWVzLWpzYCBsaWJyYXJ5LCBhIHJlcHV0YWJsZSBKYXZhU2NyaXB0LW9ubHkgaW1wbGVtZW50YXRpb24gb2YgdGhlIEFFUyBlbmNyeXB0aW9uIGFsZ29yaXRobSBpbiBDVFIgbW9kZS5cbiAgICogQSBuZXcgMjU2LWJpdCBlbmNyeXB0aW9uIGtleSBpcyBnZW5lcmF0ZWQgdXNpbmcgdGhlIGByZWFjdC1uYXRpdmUtZ2V0LXJhbmRvbS12YWx1ZXNgIGxpYnJhcnkuXG4gICAqIFRoaXMga2V5IGlzIHN0b3JlZCBpbnNpZGUgRXhwbydzIFNlY3VyZVN0b3JlLCB3aGlsZSB0aGUgdmFsdWUgaXMgZW5jcnlwdGVkIGFuZCBwbGFjZWQgaW5zaWRlIEFzeW5jU3RvcmFnZS5cbiAgICpcbiAgICogUGxlYXNlIG1ha2Ugc3VyZSB0aGF0OlxuICAgKiAtIFlvdSBrZWVwIHRoZSBgZXhwby1zZWN1cmUtc3RvcmVgLCBgYWVzLWpzYCBhbmQgYHJlYWN0LW5hdGl2ZS1nZXQtcmFuZG9tLXZhbHVlc2AgbGlicmFyaWVzIHVwLXRvLWRhdGUuXG4gICAqIC0gQ2hvb3NlIHRoZSBjb3JyZWN0IFtgU2VjdXJlU3RvcmVPcHRpb25zYF0oaHR0cHM6Ly9kb2NzLmV4cG8uZGV2L3ZlcnNpb25zL2xhdGVzdC9zZGsvc2VjdXJlc3RvcmUvI3NlY3VyZXN0b3Jlb3B0aW9ucykgZm9yIHlvdXIgYXBwJ3MgbmVlZHMuXG4gICAqICAgRS5nLiBbYFNlY3VyZVN0b3JlLldIRU5fVU5MT0NLRURgXShodHRwczovL2RvY3MuZXhwby5kZXYvdmVyc2lvbnMvbGF0ZXN0L3Nkay9zZWN1cmVzdG9yZS8jc2VjdXJlc3RvcmV3aGVuX3VubG9ja2VkKSByZWd1bGF0ZXMgd2hlbiB0aGUgZGF0YSBjYW4gYmUgYWNjZXNzZWQuXG4gICAqIC0gQ2FyZWZ1bGx5IGNvbnNpZGVyIG9wdGltaXphdGlvbnMgb3Igb3RoZXIgbW9kaWZpY2F0aW9ucyB0byB0aGUgYWJvdmUgZXhhbXBsZSwgYXMgdGhvc2UgY2FuIGxlYWQgdG8gaW50cm9kdWNpbmcgc3VidGxlIHNlY3VyaXR5IHZ1bG5lcmFiaWxpdGllcy5cbiAgICpcbiAgICogQGV4YW1wbGUgUmVhY3QgTmF0aXZlIG9wdGlvbnMgd2l0aCBFeHBvIFNlY3VyZVN0b3JlXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCAncmVhY3QtbmF0aXZlLXVybC1wb2x5ZmlsbC9hdXRvJ1xuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqIGltcG9ydCBBc3luY1N0b3JhZ2UgZnJvbSAnQHJlYWN0LW5hdGl2ZS1hc3luYy1zdG9yYWdlL2FzeW5jLXN0b3JhZ2UnO1xuICAgKiBpbXBvcnQgKiBhcyBTZWN1cmVTdG9yZSBmcm9tICdleHBvLXNlY3VyZS1zdG9yZSc7XG4gICAqIGltcG9ydCAqIGFzIGFlc2pzIGZyb20gJ2Flcy1qcyc7XG4gICAqIGltcG9ydCAncmVhY3QtbmF0aXZlLWdldC1yYW5kb20tdmFsdWVzJztcbiAgICpcbiAgICogLy8gQXMgRXhwbydzIFNlY3VyZVN0b3JlIGRvZXMgbm90IHN1cHBvcnQgdmFsdWVzIGxhcmdlciB0aGFuIDIwNDhcbiAgICogLy8gYnl0ZXMsIGFuIEFFUy0yNTYga2V5IGlzIGdlbmVyYXRlZCBhbmQgc3RvcmVkIGluIFNlY3VyZVN0b3JlLCB3aGlsZVxuICAgKiAvLyBpdCBpcyB1c2VkIHRvIGVuY3J5cHQvZGVjcnlwdCB2YWx1ZXMgc3RvcmVkIGluIEFzeW5jU3RvcmFnZS5cbiAgICogY2xhc3MgTGFyZ2VTZWN1cmVTdG9yZSB7XG4gICAqICAgcHJpdmF0ZSBhc3luYyBfZW5jcnlwdChrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZykge1xuICAgKiAgICAgY29uc3QgZW5jcnlwdGlvbktleSA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMjU2IC8gOCkpO1xuICAgKlxuICAgKiAgICAgY29uc3QgY2lwaGVyID0gbmV3IGFlc2pzLk1vZGVPZk9wZXJhdGlvbi5jdHIoZW5jcnlwdGlvbktleSwgbmV3IGFlc2pzLkNvdW50ZXIoMSkpO1xuICAgKiAgICAgY29uc3QgZW5jcnlwdGVkQnl0ZXMgPSBjaXBoZXIuZW5jcnlwdChhZXNqcy51dGlscy51dGY4LnRvQnl0ZXModmFsdWUpKTtcbiAgICpcbiAgICogICAgIGF3YWl0IFNlY3VyZVN0b3JlLnNldEl0ZW1Bc3luYyhrZXksIGFlc2pzLnV0aWxzLmhleC5mcm9tQnl0ZXMoZW5jcnlwdGlvbktleSkpO1xuICAgKlxuICAgKiAgICAgcmV0dXJuIGFlc2pzLnV0aWxzLmhleC5mcm9tQnl0ZXMoZW5jcnlwdGVkQnl0ZXMpO1xuICAgKiAgIH1cbiAgICpcbiAgICogICBwcml2YXRlIGFzeW5jIF9kZWNyeXB0KGtleTogc3RyaW5nLCB2YWx1ZTogc3RyaW5nKSB7XG4gICAqICAgICBjb25zdCBlbmNyeXB0aW9uS2V5SGV4ID0gYXdhaXQgU2VjdXJlU3RvcmUuZ2V0SXRlbUFzeW5jKGtleSk7XG4gICAqICAgICBpZiAoIWVuY3J5cHRpb25LZXlIZXgpIHtcbiAgICogICAgICAgcmV0dXJuIGVuY3J5cHRpb25LZXlIZXg7XG4gICAqICAgICB9XG4gICAqXG4gICAqICAgICBjb25zdCBjaXBoZXIgPSBuZXcgYWVzanMuTW9kZU9mT3BlcmF0aW9uLmN0cihhZXNqcy51dGlscy5oZXgudG9CeXRlcyhlbmNyeXB0aW9uS2V5SGV4KSwgbmV3IGFlc2pzLkNvdW50ZXIoMSkpO1xuICAgKiAgICAgY29uc3QgZGVjcnlwdGVkQnl0ZXMgPSBjaXBoZXIuZGVjcnlwdChhZXNqcy51dGlscy5oZXgudG9CeXRlcyh2YWx1ZSkpO1xuICAgKlxuICAgKiAgICAgcmV0dXJuIGFlc2pzLnV0aWxzLnV0ZjguZnJvbUJ5dGVzKGRlY3J5cHRlZEJ5dGVzKTtcbiAgICogICB9XG4gICAqXG4gICAqICAgYXN5bmMgZ2V0SXRlbShrZXk6IHN0cmluZykge1xuICAgKiAgICAgY29uc3QgZW5jcnlwdGVkID0gYXdhaXQgQXN5bmNTdG9yYWdlLmdldEl0ZW0oa2V5KTtcbiAgICogICAgIGlmICghZW5jcnlwdGVkKSB7IHJldHVybiBlbmNyeXB0ZWQ7IH1cbiAgICpcbiAgICogICAgIHJldHVybiBhd2FpdCB0aGlzLl9kZWNyeXB0KGtleSwgZW5jcnlwdGVkKTtcbiAgICogICB9XG4gICAqXG4gICAqICAgYXN5bmMgcmVtb3ZlSXRlbShrZXk6IHN0cmluZykge1xuICAgKiAgICAgYXdhaXQgQXN5bmNTdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KTtcbiAgICogICAgIGF3YWl0IFNlY3VyZVN0b3JlLmRlbGV0ZUl0ZW1Bc3luYyhrZXkpO1xuICAgKiAgIH1cbiAgICpcbiAgICogICBhc3luYyBzZXRJdGVtKGtleTogc3RyaW5nLCB2YWx1ZTogc3RyaW5nKSB7XG4gICAqICAgICBjb25zdCBlbmNyeXB0ZWQgPSBhd2FpdCB0aGlzLl9lbmNyeXB0KGtleSwgdmFsdWUpO1xuICAgKlxuICAgKiAgICAgYXdhaXQgQXN5bmNTdG9yYWdlLnNldEl0ZW0oa2V5LCBlbmNyeXB0ZWQpO1xuICAgKiAgIH1cbiAgICogfVxuICAgKlxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcImh0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jb1wiLCBcInlvdXItcHVibGlzaGFibGUta2V5XCIsIHtcbiAgICogICBhdXRoOiB7XG4gICAqICAgICBzdG9yYWdlOiBuZXcgTGFyZ2VTZWN1cmVTdG9yZSgpLFxuICAgKiAgICAgYXV0b1JlZnJlc2hUb2tlbjogdHJ1ZSxcbiAgICogICAgIHBlcnNpc3RTZXNzaW9uOiB0cnVlLFxuICAgKiAgICAgZGV0ZWN0U2Vzc2lvbkluVXJsOiBmYWxzZSxcbiAgICogICB9LFxuICAgKiB9KTtcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFdpdGggYSBkYXRhYmFzZSBxdWVyeVxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqXG4gICAqIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28nLCAneW91ci1wdWJsaXNoYWJsZS1rZXknKVxuICAgKlxuICAgKiBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3Byb2ZpbGVzJykuc2VsZWN0KCcqJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlRGVzY3JpcHRpb24gV2l0aCBPcGVuVGVsZW1ldHJ5IHRyYWNpbmdcbiAgICogT3B0IGluIHRvIFczQyB0cmFjZSBjb250ZXh0IHByb3BhZ2F0aW9uIHNvIHRoZSBgdHJhY2VfaWRgIGZyb20geW91clxuICAgKiBjbGllbnQtc2lkZSBzcGFucyBpcyBhdHRhY2hlZCB0byBTdXBhYmFzZSByZXF1ZXN0cyBhbmQgYXBwZWFycyBpbiBBUElcbiAgICogR2F0ZXdheSBhbmQgRWRnZSBGdW5jdGlvbiBsb2dzLiBSZXF1aXJlcyBgQG9wZW50ZWxlbWV0cnkvYXBpYCB0byBiZVxuICAgKiBpbnN0YWxsZWQgaW4geW91ciBhcHBsaWNhdGlvbi4gU2VlIFtUcmFjaW5nIHdpdGggdGhlIEpTIFNES10oaHR0cHM6Ly9zdXBhYmFzZS5jb20vZG9jcy9ndWlkZXMvdGVsZW1ldHJ5L2NsaWVudC1zaWRlLXRyYWNpbmcpLlxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIE9wZW5UZWxlbWV0cnkgdHJhY2luZ1xuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqIGltcG9ydCB7IHRyYWNlIH0gZnJvbSAnQG9wZW50ZWxlbWV0cnkvYXBpJ1xuICAgKlxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudCgnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvJywgJ3lvdXItcHVibGlzaGFibGUta2V5Jywge1xuICAgKiAgIHRyYWNlUHJvcGFnYXRpb246IHRydWUsXG4gICAqIH0pXG4gICAqXG4gICAqIGNvbnN0IHRyYWNlciA9IHRyYWNlLmdldFRyYWNlcignbXktYXBwJylcbiAgICpcbiAgICogYXdhaXQgdHJhY2VyLnN0YXJ0QWN0aXZlU3BhbignZmV0Y2gtdXNlcnMnLCBhc3luYyAoc3BhbikgPT4ge1xuICAgKiAgIC8vIE91dGdvaW5nIHJlcXVlc3QgY2FycmllcyB0aGUgYWN0aXZlIHRyYWNlIGNvbnRleHQuXG4gICAqICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgndXNlcnMnKS5zZWxlY3QoJyonKVxuICAgKiAgIHNwYW4uZW5kKClcbiAgICogfSlcbiAgICogYGBgXG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcm90ZWN0ZWQgc3VwYWJhc2VVcmw6IHN0cmluZyxcbiAgICBwcm90ZWN0ZWQgc3VwYWJhc2VLZXk6IHN0cmluZyxcbiAgICBvcHRpb25zPzogU3VwYWJhc2VDbGllbnRPcHRpb25zPFNjaGVtYU5hbWU+XG4gICkge1xuICAgIGNvbnN0IGJhc2VVcmwgPSB2YWxpZGF0ZVN1cGFiYXNlVXJsKHN1cGFiYXNlVXJsKVxuICAgIGlmICghc3VwYWJhc2VLZXkpIHRocm93IG5ldyBFcnJvcignc3VwYWJhc2VLZXkgaXMgcmVxdWlyZWQuJylcblxuICAgIHRoaXMucmVhbHRpbWVVcmwgPSBuZXcgVVJMKCdyZWFsdGltZS92MScsIGJhc2VVcmwpXG4gICAgdGhpcy5yZWFsdGltZVVybC5wcm90b2NvbCA9IHRoaXMucmVhbHRpbWVVcmwucHJvdG9jb2wucmVwbGFjZSgnaHR0cCcsICd3cycpXG4gICAgdGhpcy5hdXRoVXJsID0gbmV3IFVSTCgnYXV0aC92MScsIGJhc2VVcmwpXG4gICAgdGhpcy5zdG9yYWdlVXJsID0gbmV3IFVSTCgnc3RvcmFnZS92MScsIGJhc2VVcmwpXG4gICAgdGhpcy5mdW5jdGlvbnNVcmwgPSBuZXcgVVJMKCdmdW5jdGlvbnMvdjEnLCBiYXNlVXJsKVxuXG4gICAgLy8gZGVmYXVsdCBzdG9yYWdlIGtleSB1c2VzIHRoZSBzdXBhYmFzZSBwcm9qZWN0IHJlZiBhcyBhIG5hbWVzcGFjZVxuICAgIGNvbnN0IGRlZmF1bHRTdG9yYWdlS2V5ID0gYHNiLSR7YmFzZVVybC5ob3N0bmFtZS5zcGxpdCgnLicpWzBdfS1hdXRoLXRva2VuYFxuICAgIGNvbnN0IERFRkFVTFRTID0ge1xuICAgICAgZGI6IERFRkFVTFRfREJfT1BUSU9OUyxcbiAgICAgIHJlYWx0aW1lOiBERUZBVUxUX1JFQUxUSU1FX09QVElPTlMsXG4gICAgICBhdXRoOiB7IC4uLkRFRkFVTFRfQVVUSF9PUFRJT05TLCBzdG9yYWdlS2V5OiBkZWZhdWx0U3RvcmFnZUtleSB9LFxuICAgICAgZ2xvYmFsOiBERUZBVUxUX0dMT0JBTF9PUFRJT05TLFxuICAgICAgdHJhY2VQcm9wYWdhdGlvbjogREVGQVVMVF9UUkFDRV9QUk9QQUdBVElPTl9PUFRJT05TLFxuICAgIH1cblxuICAgIGNvbnN0IHNldHRpbmdzID0gYXBwbHlTZXR0aW5nRGVmYXVsdHMob3B0aW9ucyA/PyB7fSwgREVGQVVMVFMpXG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzXG5cbiAgICB0aGlzLnN0b3JhZ2VLZXkgPSBzZXR0aW5ncy5hdXRoLnN0b3JhZ2VLZXkgPz8gJydcbiAgICB0aGlzLmhlYWRlcnMgPSBzZXR0aW5ncy5nbG9iYWwuaGVhZGVycyA/PyB7fVxuXG4gICAgaWYgKCFzZXR0aW5ncy5hY2Nlc3NUb2tlbikge1xuICAgICAgdGhpcy5hdXRoID0gdGhpcy5faW5pdFN1cGFiYXNlQXV0aENsaWVudChcbiAgICAgICAgc2V0dGluZ3MuYXV0aCA/PyB7fSxcbiAgICAgICAgdGhpcy5oZWFkZXJzLFxuICAgICAgICBzZXR0aW5ncy5nbG9iYWwuZmV0Y2hcbiAgICAgIClcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5hY2Nlc3NUb2tlbiA9IHNldHRpbmdzLmFjY2Vzc1Rva2VuXG5cbiAgICAgIHRoaXMuYXV0aCA9IG5ldyBQcm94eTxTdXBhYmFzZUF1dGhDbGllbnQ+KHt9IGFzIGFueSwge1xuICAgICAgICBnZXQ6IChfLCBwcm9wKSA9PiB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgYEBzdXBhYmFzZS9zdXBhYmFzZS1qczogU3VwYWJhc2UgQ2xpZW50IGlzIGNvbmZpZ3VyZWQgd2l0aCB0aGUgYWNjZXNzVG9rZW4gb3B0aW9uLCBhY2Nlc3Npbmcgc3VwYWJhc2UuYXV0aC4ke1N0cmluZyhcbiAgICAgICAgICAgICAgcHJvcFxuICAgICAgICAgICAgKX0gaXMgbm90IHBvc3NpYmxlYFxuICAgICAgICAgIClcbiAgICAgICAgfSxcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgdGhpcy5mZXRjaCA9IGZldGNoV2l0aEF1dGgoXG4gICAgICBzdXBhYmFzZUtleSxcbiAgICAgIHN1cGFiYXNlVXJsLFxuICAgICAgdGhpcy5fZ2V0QWNjZXNzVG9rZW4uYmluZCh0aGlzKSxcbiAgICAgIHNldHRpbmdzLmdsb2JhbC5mZXRjaCxcbiAgICAgIHNldHRpbmdzLnRyYWNlUHJvcGFnYXRpb25cbiAgICApXG4gICAgdGhpcy5yZWFsdGltZSA9IHRoaXMuX2luaXRSZWFsdGltZUNsaWVudCh7XG4gICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICBhY2Nlc3NUb2tlbjogdGhpcy5fZ2V0QWNjZXNzVG9rZW4uYmluZCh0aGlzKSxcbiAgICAgIGZldGNoOiB0aGlzLmZldGNoLFxuICAgICAgLi4uc2V0dGluZ3MucmVhbHRpbWUsXG4gICAgfSlcbiAgICBpZiAodGhpcy5hY2Nlc3NUb2tlbikge1xuICAgICAgLy8gU3RhcnQgYXV0aCBpbW1lZGlhdGVseSB0byBhdm9pZCByYWNlIGNvbmRpdGlvbiB3aXRoIGNoYW5uZWwgc3Vic2NyaXB0aW9uc1xuICAgICAgLy8gV3JhcCBQcm9taXNlIHRvIGF2b2lkIEZpcmVmb3ggZXh0ZW5zaW9uIGNyb3NzLWNvbnRleHQgUHJvbWlzZSBhY2Nlc3MgZXJyb3JzXG4gICAgICBQcm9taXNlLnJlc29sdmUodGhpcy5hY2Nlc3NUb2tlbigpKVxuICAgICAgICAudGhlbigodG9rZW4pID0+IHRoaXMucmVhbHRpbWUuc2V0QXV0aCh0b2tlbikpXG4gICAgICAgIC5jYXRjaCgoZSkgPT4gY29uc29sZS53YXJuKCdGYWlsZWQgdG8gc2V0IGluaXRpYWwgUmVhbHRpbWUgYXV0aCB0b2tlbjonLCBlKSlcbiAgICB9XG5cbiAgICB0aGlzLnJlc3QgPSBuZXcgUG9zdGdyZXN0Q2xpZW50KG5ldyBVUkwoJ3Jlc3QvdjEnLCBiYXNlVXJsKS5ocmVmLCB7XG4gICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICBzY2hlbWE6IHNldHRpbmdzLmRiLnNjaGVtYSxcbiAgICAgIGZldGNoOiB0aGlzLmZldGNoLFxuICAgICAgdGltZW91dDogc2V0dGluZ3MuZGIudGltZW91dCxcbiAgICAgIHVybExlbmd0aExpbWl0OiBzZXR0aW5ncy5kYi51cmxMZW5ndGhMaW1pdCxcbiAgICB9KVxuXG4gICAgdGhpcy5zdG9yYWdlID0gbmV3IFN1cGFiYXNlU3RvcmFnZUNsaWVudChcbiAgICAgIHRoaXMuc3RvcmFnZVVybC5ocmVmLFxuICAgICAgdGhpcy5oZWFkZXJzLFxuICAgICAgdGhpcy5mZXRjaCxcbiAgICAgIG9wdGlvbnM/LnN0b3JhZ2VcbiAgICApXG5cbiAgICBpZiAoIXNldHRpbmdzLmFjY2Vzc1Rva2VuKSB7XG4gICAgICB0aGlzLl9saXN0ZW5Gb3JBdXRoRXZlbnRzKClcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU3VwYWJhc2UgRnVuY3Rpb25zIGFsbG93cyB5b3UgdG8gZGVwbG95IGFuZCBpbnZva2UgZWRnZSBmdW5jdGlvbnMuXG4gICAqL1xuICBnZXQgZnVuY3Rpb25zKCk6IEZ1bmN0aW9uc0NsaWVudCB7XG4gICAgcmV0dXJuIG5ldyBGdW5jdGlvbnNDbGllbnQodGhpcy5mdW5jdGlvbnNVcmwuaHJlZiwge1xuICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgY3VzdG9tRmV0Y2g6IHRoaXMuZmV0Y2gsXG4gICAgfSlcbiAgfVxuXG4gIC8vIE5PVEU6IHNpZ25hdHVyZXMgbXVzdCBiZSBrZXB0IGluIHN5bmMgd2l0aCBQb3N0Z3Jlc3RDbGllbnQuZnJvbVxuICBmcm9tPFxuICAgIFRhYmxlTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIFNjaGVtYVsnVGFibGVzJ10sXG4gICAgVGFibGUgZXh0ZW5kcyBTY2hlbWFbJ1RhYmxlcyddW1RhYmxlTmFtZV0sXG4gID4ocmVsYXRpb246IFRhYmxlTmFtZSk6IFBvc3RncmVzdFF1ZXJ5QnVpbGRlcjxDbGllbnRPcHRpb25zLCBTY2hlbWEsIFRhYmxlLCBUYWJsZU5hbWU+XG4gIGZyb208Vmlld05hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBTY2hlbWFbJ1ZpZXdzJ10sIFZpZXcgZXh0ZW5kcyBTY2hlbWFbJ1ZpZXdzJ11bVmlld05hbWVdPihcbiAgICByZWxhdGlvbjogVmlld05hbWVcbiAgKTogUG9zdGdyZXN0UXVlcnlCdWlsZGVyPENsaWVudE9wdGlvbnMsIFNjaGVtYSwgVmlldywgVmlld05hbWU+XG4gIC8qKlxuICAgKiBQZXJmb3JtIGEgcXVlcnkgb24gYSB0YWJsZSBvciBhIHZpZXcuXG4gICAqXG4gICAqIEBwYXJhbSByZWxhdGlvbiAtIFRoZSB0YWJsZSBvciB2aWV3IG5hbWUgdG8gcXVlcnlcbiAgICovXG4gIGZyb20ocmVsYXRpb246IHN0cmluZyk6IFBvc3RncmVzdFF1ZXJ5QnVpbGRlcjxDbGllbnRPcHRpb25zLCBTY2hlbWEsIGFueT4ge1xuICAgIHJldHVybiB0aGlzLnJlc3QuZnJvbShyZWxhdGlvbilcbiAgfVxuXG4gIC8vIE5PVEU6IHNpZ25hdHVyZXMgbXVzdCBiZSBrZXB0IGluIHN5bmMgd2l0aCBQb3N0Z3Jlc3RDbGllbnQuc2NoZW1hXG4gIC8qKlxuICAgKiBTZWxlY3QgYSBzY2hlbWEgdG8gcXVlcnkgb3IgcGVyZm9ybSBhbiBmdW5jdGlvbiAocnBjKSBjYWxsLlxuICAgKlxuICAgKiBUaGUgc2NoZW1hIG5lZWRzIHRvIGJlIG9uIHRoZSBsaXN0IG9mIGV4cG9zZWQgc2NoZW1hcyBpbnNpZGUgU3VwYWJhc2UuXG4gICAqXG4gICAqIEBwYXJhbSBzY2hlbWEgLSBUaGUgc2NoZW1hIHRvIHF1ZXJ5XG4gICAqL1xuICBzY2hlbWE8RHluYW1pY1NjaGVtYSBleHRlbmRzIHN0cmluZyAmIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPj4oXG4gICAgc2NoZW1hOiBEeW5hbWljU2NoZW1hXG4gICk6IFBvc3RncmVzdENsaWVudDxcbiAgICBEYXRhYmFzZSxcbiAgICBDbGllbnRPcHRpb25zLFxuICAgIER5bmFtaWNTY2hlbWEsXG4gICAgRGF0YWJhc2VbRHluYW1pY1NjaGVtYV0gZXh0ZW5kcyBHZW5lcmljU2NoZW1hID8gRGF0YWJhc2VbRHluYW1pY1NjaGVtYV0gOiBhbnlcbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMucmVzdC5zY2hlbWE8RHluYW1pY1NjaGVtYT4oc2NoZW1hKVxuICB9XG5cbiAgLy8gTk9URTogc2lnbmF0dXJlcyBtdXN0IGJlIGtlcHQgaW4gc3luYyB3aXRoIFBvc3RncmVzdENsaWVudC5ycGNcbiAgLyoqXG4gICAqIFBlcmZvcm0gYSBmdW5jdGlvbiBjYWxsLlxuICAgKlxuICAgKiBAcGFyYW0gZm4gLSBUaGUgZnVuY3Rpb24gbmFtZSB0byBjYWxsXG4gICAqIEBwYXJhbSBhcmdzIC0gVGhlIGFyZ3VtZW50cyB0byBwYXNzIHRvIHRoZSBmdW5jdGlvbiBjYWxsXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gTmFtZWQgcGFyYW1ldGVyc1xuICAgKiBAcGFyYW0gb3B0aW9ucy5oZWFkIC0gV2hlbiBzZXQgdG8gYHRydWVgLCBgZGF0YWAgd2lsbCBub3QgYmUgcmV0dXJuZWQuXG4gICAqIFVzZWZ1bCBpZiB5b3Ugb25seSBuZWVkIHRoZSBjb3VudC5cbiAgICogQHBhcmFtIG9wdGlvbnMuZ2V0IC0gV2hlbiBzZXQgdG8gYHRydWVgLCB0aGUgZnVuY3Rpb24gd2lsbCBiZSBjYWxsZWQgd2l0aFxuICAgKiByZWFkLW9ubHkgYWNjZXNzIG1vZGUuXG4gICAqIEBwYXJhbSBvcHRpb25zLmNvdW50IC0gQ291bnQgYWxnb3JpdGhtIHRvIHVzZSB0byBjb3VudCByb3dzIHJldHVybmVkIGJ5IHRoZVxuICAgKiBmdW5jdGlvbi4gT25seSBhcHBsaWNhYmxlIGZvciBbc2V0LXJldHVybmluZ1xuICAgKiBmdW5jdGlvbnNdKGh0dHBzOi8vd3d3LnBvc3RncmVzcWwub3JnL2RvY3MvY3VycmVudC9mdW5jdGlvbnMtc3JmLmh0bWwpLlxuICAgKlxuICAgKiBgXCJleGFjdFwiYDogRXhhY3QgYnV0IHNsb3cgY291bnQgYWxnb3JpdGhtLiBQZXJmb3JtcyBhIGBDT1VOVCgqKWAgdW5kZXIgdGhlXG4gICAqIGhvb2QuXG4gICAqXG4gICAqIGBcInBsYW5uZWRcImA6IEFwcHJveGltYXRlZCBidXQgZmFzdCBjb3VudCBhbGdvcml0aG0uIFVzZXMgdGhlIFBvc3RncmVzXG4gICAqIHN0YXRpc3RpY3MgdW5kZXIgdGhlIGhvb2QuXG4gICAqXG4gICAqIGBcImVzdGltYXRlZFwiYDogVXNlcyBleGFjdCBjb3VudCBmb3IgbG93IG51bWJlcnMgYW5kIHBsYW5uZWQgY291bnQgZm9yIGhpZ2hcbiAgICogbnVtYmVycy5cbiAgICovXG4gIHJwYzxcbiAgICBGbk5hbWUgZXh0ZW5kcyBzdHJpbmcgJiBrZXlvZiBTY2hlbWFbJ0Z1bmN0aW9ucyddLFxuICAgIEFyZ3MgZXh0ZW5kcyBTY2hlbWFbJ0Z1bmN0aW9ucyddW0ZuTmFtZV1bJ0FyZ3MnXSA9IG5ldmVyLFxuICAgIEZpbHRlckJ1aWxkZXIgZXh0ZW5kcyBHZXRScGNGdW5jdGlvbkZpbHRlckJ1aWxkZXJCeUFyZ3M8U2NoZW1hLCBGbk5hbWUsIEFyZ3M+ID1cbiAgICAgIEdldFJwY0Z1bmN0aW9uRmlsdGVyQnVpbGRlckJ5QXJnczxTY2hlbWEsIEZuTmFtZSwgQXJncz4sXG4gID4oXG4gICAgZm46IEZuTmFtZSxcbiAgICBhcmdzOiBBcmdzID0ge30gYXMgQXJncyxcbiAgICBvcHRpb25zOiB7XG4gICAgICBoZWFkPzogYm9vbGVhblxuICAgICAgZ2V0PzogYm9vbGVhblxuICAgICAgY291bnQ/OiAnZXhhY3QnIHwgJ3BsYW5uZWQnIHwgJ2VzdGltYXRlZCdcbiAgICB9ID0ge1xuICAgICAgaGVhZDogZmFsc2UsXG4gICAgICBnZXQ6IGZhbHNlLFxuICAgICAgY291bnQ6IHVuZGVmaW5lZCxcbiAgICB9XG4gICk6IFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgQ2xpZW50T3B0aW9ucyxcbiAgICBTY2hlbWEsXG4gICAgRmlsdGVyQnVpbGRlclsnUm93J10sXG4gICAgRmlsdGVyQnVpbGRlclsnUmVzdWx0J10sXG4gICAgRmlsdGVyQnVpbGRlclsnUmVsYXRpb25OYW1lJ10sXG4gICAgRmlsdGVyQnVpbGRlclsnUmVsYXRpb25zaGlwcyddLFxuICAgICdSUEMnXG4gID4ge1xuICAgIHJldHVybiB0aGlzLnJlc3QucnBjKGZuLCBhcmdzLCBvcHRpb25zKSBhcyB1bmtub3duIGFzIFBvc3RncmVzdEZpbHRlckJ1aWxkZXI8XG4gICAgICBDbGllbnRPcHRpb25zLFxuICAgICAgU2NoZW1hLFxuICAgICAgRmlsdGVyQnVpbGRlclsnUm93J10sXG4gICAgICBGaWx0ZXJCdWlsZGVyWydSZXN1bHQnXSxcbiAgICAgIEZpbHRlckJ1aWxkZXJbJ1JlbGF0aW9uTmFtZSddLFxuICAgICAgRmlsdGVyQnVpbGRlclsnUmVsYXRpb25zaGlwcyddLFxuICAgICAgJ1JQQydcbiAgICA+XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIFJlYWx0aW1lIGNoYW5uZWwgd2l0aCBCcm9hZGNhc3QsIFByZXNlbmNlLCBhbmQgUG9zdGdyZXMgQ2hhbmdlcy5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmd9IG5hbWUgLSBUaGUgbmFtZSBvZiB0aGUgUmVhbHRpbWUgY2hhbm5lbC5cbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdHMgLSBUaGUgb3B0aW9ucyB0byBwYXNzIHRvIHRoZSBSZWFsdGltZSBjaGFubmVsLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGNoYW5uZWwobmFtZTogc3RyaW5nLCBvcHRzOiBSZWFsdGltZUNoYW5uZWxPcHRpb25zID0geyBjb25maWc6IHt9IH0pOiBSZWFsdGltZUNoYW5uZWwge1xuICAgIHJldHVybiB0aGlzLnJlYWx0aW1lLmNoYW5uZWwobmFtZSwgb3B0cylcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGFsbCBSZWFsdGltZSBjaGFubmVscy5cbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqXG4gICAqIEBleGFtcGxlIEdldCBhbGwgY2hhbm5lbHNcbiAgICogYGBganNcbiAgICogY29uc3QgY2hhbm5lbHMgPSBzdXBhYmFzZS5nZXRDaGFubmVscygpXG4gICAqIGBgYFxuICAgKi9cbiAgZ2V0Q2hhbm5lbHMoKTogUmVhbHRpbWVDaGFubmVsW10ge1xuICAgIHJldHVybiB0aGlzLnJlYWx0aW1lLmdldENoYW5uZWxzKClcbiAgfVxuXG4gIC8qKlxuICAgKiBVbnN1YnNjcmliZXMgYW5kIHJlbW92ZXMgUmVhbHRpbWUgY2hhbm5lbCBmcm9tIFJlYWx0aW1lIGNsaWVudC5cbiAgICpcbiAgICogQHBhcmFtIHtSZWFsdGltZUNoYW5uZWx9IGNoYW5uZWwgLSBUaGUgbmFtZSBvZiB0aGUgUmVhbHRpbWUgY2hhbm5lbC5cbiAgICpcbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUmVtb3ZpbmcgYSBjaGFubmVsIGlzIGEgZ3JlYXQgd2F5IHRvIG1haW50YWluIHRoZSBwZXJmb3JtYW5jZSBvZiB5b3VyIHByb2plY3QncyBSZWFsdGltZSBzZXJ2aWNlIGFzIHdlbGwgYXMgeW91ciBkYXRhYmFzZSBpZiB5b3UncmUgbGlzdGVuaW5nIHRvIFBvc3RncmVzIGNoYW5nZXMuIFN1cGFiYXNlIHdpbGwgYXV0b21hdGljYWxseSBoYW5kbGUgY2xlYW51cCAzMCBzZWNvbmRzIGFmdGVyIGEgY2xpZW50IGlzIGRpc2Nvbm5lY3RlZCwgYnV0IHVudXNlZCBjaGFubmVscyBtYXkgY2F1c2UgZGVncmFkYXRpb24gYXMgbW9yZSBjbGllbnRzIGFyZSBzaW11bHRhbmVvdXNseSBzdWJzY3JpYmVkLlxuICAgKlxuICAgKiBAZXhhbXBsZSBSZW1vdmVzIGEgY2hhbm5lbFxuICAgKiBgYGBqc1xuICAgKiBzdXBhYmFzZS5yZW1vdmVDaGFubmVsKG15Q2hhbm5lbClcbiAgICogYGBgXG4gICAqL1xuICByZW1vdmVDaGFubmVsKGNoYW5uZWw6IFJlYWx0aW1lQ2hhbm5lbCk6IFByb21pc2U8UmVhbHRpbWVSZW1vdmVDaGFubmVsUmVzcG9uc2U+IHtcbiAgICByZXR1cm4gdGhpcy5yZWFsdGltZS5yZW1vdmVDaGFubmVsKGNoYW5uZWwpXG4gIH1cblxuICAvKipcbiAgICogVW5zdWJzY3JpYmVzIGFuZCByZW1vdmVzIGFsbCBSZWFsdGltZSBjaGFubmVscyBmcm9tIFJlYWx0aW1lIGNsaWVudC5cbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUmVtb3ZpbmcgY2hhbm5lbHMgaXMgYSBncmVhdCB3YXkgdG8gbWFpbnRhaW4gdGhlIHBlcmZvcm1hbmNlIG9mIHlvdXIgcHJvamVjdCdzIFJlYWx0aW1lIHNlcnZpY2UgYXMgd2VsbCBhcyB5b3VyIGRhdGFiYXNlIGlmIHlvdSdyZSBsaXN0ZW5pbmcgdG8gUG9zdGdyZXMgY2hhbmdlcy4gU3VwYWJhc2Ugd2lsbCBhdXRvbWF0aWNhbGx5IGhhbmRsZSBjbGVhbnVwIDMwIHNlY29uZHMgYWZ0ZXIgYSBjbGllbnQgaXMgZGlzY29ubmVjdGVkLCBidXQgdW51c2VkIGNoYW5uZWxzIG1heSBjYXVzZSBkZWdyYWRhdGlvbiBhcyBtb3JlIGNsaWVudHMgYXJlIHNpbXVsdGFuZW91c2x5IHN1YnNjcmliZWQuXG4gICAqXG4gICAqIEBleGFtcGxlIFJlbW92ZSBhbGwgY2hhbm5lbHNcbiAgICogYGBganNcbiAgICogc3VwYWJhc2UucmVtb3ZlQWxsQ2hhbm5lbHMoKVxuICAgKiBgYGBcbiAgICovXG4gIHJlbW92ZUFsbENoYW5uZWxzKCk6IFByb21pc2U8UmVhbHRpbWVSZW1vdmVDaGFubmVsUmVzcG9uc2VbXT4ge1xuICAgIHJldHVybiB0aGlzLnJlYWx0aW1lLnJlbW92ZUFsbENoYW5uZWxzKClcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2dldEFjY2Vzc1Rva2VuKCkge1xuICAgIGlmICh0aGlzLmFjY2Vzc1Rva2VuKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5hY2Nlc3NUb2tlbigpXG4gICAgfVxuXG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCB0aGlzLmF1dGguZ2V0U2Vzc2lvbigpXG5cbiAgICByZXR1cm4gZGF0YS5zZXNzaW9uPy5hY2Nlc3NfdG9rZW4gPz8gdGhpcy5zdXBhYmFzZUtleVxuICB9XG5cbiAgcHJpdmF0ZSBfaW5pdFN1cGFiYXNlQXV0aENsaWVudChcbiAgICB7XG4gICAgICBhdXRvUmVmcmVzaFRva2VuLFxuICAgICAgcGVyc2lzdFNlc3Npb24sXG4gICAgICBkZXRlY3RTZXNzaW9uSW5VcmwsXG4gICAgICBzdG9yYWdlLFxuICAgICAgdXNlclN0b3JhZ2UsXG4gICAgICBzdG9yYWdlS2V5LFxuICAgICAgZmxvd1R5cGUsXG4gICAgICBsb2NrLFxuICAgICAgZGVidWcsXG4gICAgICB0aHJvd09uRXJyb3IsXG4gICAgICBleHBlcmltZW50YWwsXG4gICAgICBsb2NrQWNxdWlyZVRpbWVvdXQsXG4gICAgICBza2lwQXV0b0luaXRpYWxpemUsXG4gICAgfTogU3VwYWJhc2VBdXRoQ2xpZW50T3B0aW9ucyxcbiAgICBoZWFkZXJzPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPixcbiAgICBmZXRjaD86IEZldGNoXG4gICkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXJzID0ge1xuICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc3VwYWJhc2VLZXl9YCxcbiAgICAgIGFwaWtleTogYCR7dGhpcy5zdXBhYmFzZUtleX1gLFxuICAgIH1cbiAgICByZXR1cm4gbmV3IFN1cGFiYXNlQXV0aENsaWVudCh7XG4gICAgICB1cmw6IHRoaXMuYXV0aFVybC5ocmVmLFxuICAgICAgaGVhZGVyczogeyAuLi5hdXRoSGVhZGVycywgLi4uaGVhZGVycyB9LFxuICAgICAgc3RvcmFnZUtleTogc3RvcmFnZUtleSxcbiAgICAgIGF1dG9SZWZyZXNoVG9rZW4sXG4gICAgICBwZXJzaXN0U2Vzc2lvbixcbiAgICAgIGRldGVjdFNlc3Npb25JblVybCxcbiAgICAgIHN0b3JhZ2UsXG4gICAgICB1c2VyU3RvcmFnZSxcbiAgICAgIGZsb3dUeXBlLFxuICAgICAgbG9jayxcbiAgICAgIGRlYnVnLFxuICAgICAgdGhyb3dPbkVycm9yLFxuICAgICAgZXhwZXJpbWVudGFsLFxuICAgICAgZmV0Y2gsXG4gICAgICBsb2NrQWNxdWlyZVRpbWVvdXQsXG4gICAgICBza2lwQXV0b0luaXRpYWxpemUsXG4gICAgICAvLyBhdXRoIGNoZWNrcyBpZiB0aGVyZSBpcyBhIGN1c3RvbSBhdXRob3JpemFpdG9uIGhlYWRlciB1c2luZyB0aGlzIGZsYWdcbiAgICAgIC8vIHNvIGl0IGtub3dzIHdoZXRoZXIgdG8gcmV0dXJuIGFuIGVycm9yIHdoZW4gZ2V0VXNlciBpcyBjYWxsZWQgd2l0aCBubyBzZXNzaW9uXG4gICAgICBoYXNDdXN0b21BdXRob3JpemF0aW9uSGVhZGVyOiBPYmplY3Qua2V5cyh0aGlzLmhlYWRlcnMpLnNvbWUoXG4gICAgICAgIChrZXkpID0+IGtleS50b0xvd2VyQ2FzZSgpID09PSAnYXV0aG9yaXphdGlvbidcbiAgICAgICksXG4gICAgfSlcbiAgfVxuXG4gIHByaXZhdGUgX2luaXRSZWFsdGltZUNsaWVudChvcHRpb25zOiBSZWFsdGltZUNsaWVudE9wdGlvbnMpIHtcbiAgICByZXR1cm4gbmV3IFJlYWx0aW1lQ2xpZW50KHRoaXMucmVhbHRpbWVVcmwuaHJlZiwge1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIHBhcmFtczogeyAuLi57IGFwaWtleTogdGhpcy5zdXBhYmFzZUtleSB9LCAuLi5vcHRpb25zPy5wYXJhbXMgfSxcbiAgICB9KVxuICB9XG5cbiAgcHJpdmF0ZSBfbGlzdGVuRm9yQXV0aEV2ZW50cygpIHtcbiAgICBjb25zdCBkYXRhID0gdGhpcy5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKChldmVudCwgc2Vzc2lvbikgPT4ge1xuICAgICAgdGhpcy5faGFuZGxlVG9rZW5DaGFuZ2VkKGV2ZW50LCAnQ0xJRU5UJywgc2Vzc2lvbj8uYWNjZXNzX3Rva2VuKVxuICAgIH0pXG4gICAgcmV0dXJuIGRhdGFcbiAgfVxuXG4gIHByaXZhdGUgX2hhbmRsZVRva2VuQ2hhbmdlZChcbiAgICBldmVudDogQXV0aENoYW5nZUV2ZW50LFxuICAgIHNvdXJjZTogJ0NMSUVOVCcgfCAnU1RPUkFHRScsXG4gICAgdG9rZW4/OiBzdHJpbmdcbiAgKSB7XG4gICAgaWYgKFxuICAgICAgKGV2ZW50ID09PSAnVE9LRU5fUkVGUkVTSEVEJyB8fCBldmVudCA9PT0gJ1NJR05FRF9JTicpICYmXG4gICAgICB0aGlzLmNoYW5nZWRBY2Nlc3NUb2tlbiAhPT0gdG9rZW5cbiAgICApIHtcbiAgICAgIHRoaXMuY2hhbmdlZEFjY2Vzc1Rva2VuID0gdG9rZW5cbiAgICAgIHRoaXMucmVhbHRpbWUuc2V0QXV0aCh0b2tlbilcbiAgICB9IGVsc2UgaWYgKGV2ZW50ID09PSAnU0lHTkVEX09VVCcpIHtcbiAgICAgIHRoaXMucmVhbHRpbWUuc2V0QXV0aCgpXG4gICAgICBpZiAoc291cmNlID09ICdTVE9SQUdFJykgdGhpcy5hdXRoLnNpZ25PdXQoKVxuICAgICAgdGhpcy5jaGFuZ2VkQWNjZXNzVG9rZW4gPSB1bmRlZmluZWRcbiAgICB9XG4gIH1cbn1cbiIsImltcG9ydCBTdXBhYmFzZUNsaWVudCBmcm9tICcuL1N1cGFiYXNlQ2xpZW50J1xuaW1wb3J0IHR5cGUgeyBTdXBhYmFzZUNsaWVudE9wdGlvbnMgfSBmcm9tICcuL2xpYi90eXBlcydcblxuZXhwb3J0ICogZnJvbSAnQHN1cGFiYXNlL2F1dGgtanMnXG5leHBvcnQgdHlwZSB7IFVzZXIgYXMgQXV0aFVzZXIsIFNlc3Npb24gYXMgQXV0aFNlc3Npb24gfSBmcm9tICdAc3VwYWJhc2UvYXV0aC1qcydcbmV4cG9ydCB0eXBlIHtcbiAgUG9zdGdyZXN0UmVzcG9uc2UsXG4gIFBvc3RncmVzdFNpbmdsZVJlc3BvbnNlLFxuICBQb3N0Z3Jlc3RNYXliZVNpbmdsZVJlc3BvbnNlLFxuICBQb3N0Z3Jlc3RCdWlsZGVyLFxuICBQb3N0Z3Jlc3RGaWx0ZXJCdWlsZGVyLFxuICBQb3N0Z3Jlc3RUcmFuc2Zvcm1CdWlsZGVyLFxuICBQb3N0Z3Jlc3RRdWVyeUJ1aWxkZXIsXG59IGZyb20gJ0BzdXBhYmFzZS9wb3N0Z3Jlc3QtanMnXG5leHBvcnQgeyBQb3N0Z3Jlc3RFcnJvciB9IGZyb20gJ0BzdXBhYmFzZS9wb3N0Z3Jlc3QtanMnXG5leHBvcnQgeyBTdG9yYWdlQXBpRXJyb3IgfSBmcm9tICdAc3VwYWJhc2Uvc3RvcmFnZS1qcydcbmV4cG9ydCB0eXBlIHsgRnVuY3Rpb25JbnZva2VPcHRpb25zIH0gZnJvbSAnQHN1cGFiYXNlL2Z1bmN0aW9ucy1qcydcbmV4cG9ydCB7XG4gIEZ1bmN0aW9uc0h0dHBFcnJvcixcbiAgRnVuY3Rpb25zRmV0Y2hFcnJvcixcbiAgRnVuY3Rpb25zUmVsYXlFcnJvcixcbiAgRnVuY3Rpb25zRXJyb3IsXG4gIEZ1bmN0aW9uUmVnaW9uLFxufSBmcm9tICdAc3VwYWJhc2UvZnVuY3Rpb25zLWpzJ1xuZXhwb3J0ICogZnJvbSAnQHN1cGFiYXNlL3JlYWx0aW1lLWpzJ1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBTdXBhYmFzZUNsaWVudCB9IGZyb20gJy4vU3VwYWJhc2VDbGllbnQnXG5leHBvcnQgdHlwZSB7XG4gIFN1cGFiYXNlQ2xpZW50T3B0aW9ucyxcbiAgVHJhY2VQcm9wYWdhdGlvbk9wdGlvbnMsXG4gIFF1ZXJ5UmVzdWx0LFxuICBRdWVyeURhdGEsXG4gIFF1ZXJ5RXJyb3IsXG4gIERhdGFiYXNlV2l0aG91dEludGVybmFscyxcbn0gZnJvbSAnLi9saWIvdHlwZXMnXG5cbi8qKlxuICogQ3JlYXRlcyBhIG5ldyBTdXBhYmFzZSBDbGllbnQuXG4gKlxuICogQGV4YW1wbGUgQ3JlYXRpbmcgYSBTdXBhYmFzZSBjbGllbnRcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gKlxuICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jbycsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScpXG4gKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdwcm9maWxlcycpLnNlbGVjdCgnKicpXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGNyZWF0ZUNsaWVudCA9IDxcbiAgRGF0YWJhc2UgPSBhbnksXG4gIFNjaGVtYU5hbWVPckNsaWVudE9wdGlvbnMgZXh0ZW5kc1xuICAgIHwgKHN0cmluZyAmIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPilcbiAgICB8IHsgUG9zdGdyZXN0VmVyc2lvbjogc3RyaW5nIH0gPSAncHVibGljJyBleHRlbmRzIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPlxuICAgID8gJ3B1YmxpYydcbiAgICA6IHN0cmluZyAmIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPixcbiAgU2NoZW1hTmFtZSBleHRlbmRzIHN0cmluZyAmIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPiA9XG4gICAgU2NoZW1hTmFtZU9yQ2xpZW50T3B0aW9ucyBleHRlbmRzIHN0cmluZyAmIGtleW9mIE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPlxuICAgICAgPyBTY2hlbWFOYW1lT3JDbGllbnRPcHRpb25zXG4gICAgICA6ICdwdWJsaWMnIGV4dGVuZHMga2V5b2YgT21pdDxEYXRhYmFzZSwgJ19fSW50ZXJuYWxTdXBhYmFzZSc+XG4gICAgICAgID8gJ3B1YmxpYydcbiAgICAgICAgOiBzdHJpbmcgJiBrZXlvZiBPbWl0PE9taXQ8RGF0YWJhc2UsICdfX0ludGVybmFsU3VwYWJhc2UnPiwgJ19fSW50ZXJuYWxTdXBhYmFzZSc+LFxuPihcbiAgc3VwYWJhc2VVcmw6IHN0cmluZyxcbiAgc3VwYWJhc2VLZXk6IHN0cmluZyxcbiAgb3B0aW9ucz86IFN1cGFiYXNlQ2xpZW50T3B0aW9uczxTY2hlbWFOYW1lPlxuKTogU3VwYWJhc2VDbGllbnQ8RGF0YWJhc2UsIFNjaGVtYU5hbWVPckNsaWVudE9wdGlvbnMsIFNjaGVtYU5hbWU+ID0+IHtcbiAgcmV0dXJuIG5ldyBTdXBhYmFzZUNsaWVudDxEYXRhYmFzZSwgU2NoZW1hTmFtZU9yQ2xpZW50T3B0aW9ucywgU2NoZW1hTmFtZT4oXG4gICAgc3VwYWJhc2VVcmwsXG4gICAgc3VwYWJhc2VLZXksXG4gICAgb3B0aW9uc1xuICApXG59XG5cbi8vIENoZWNrIGZvciBOb2RlLmpzIDw9IDE4IGRlcHJlY2F0aW9uXG5mdW5jdGlvbiBzaG91bGRTaG93RGVwcmVjYXRpb25XYXJuaW5nKCk6IGJvb2xlYW4ge1xuICAvLyBTa2lwIGluIGJyb3dzZXIgZW52aXJvbm1lbnRzXG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgLy8gU2tpcCBpZiBwcm9jZXNzIGlzIG5vdCBhdmFpbGFibGUgKGUuZy4sIEVkZ2UgUnVudGltZSlcbiAgLy8gVXNlIGR5bmFtaWMgcHJvcGVydHkgYWNjZXNzIHRvIGF2b2lkIE5leHQuanMgRWRnZSBSdW50aW1lIHN0YXRpYyBhbmFseXNpcyB3YXJuaW5nc1xuICBjb25zdCBfcHJvY2VzcyA9IChnbG9iYWxUaGlzIGFzIGFueSlbJ3Byb2Nlc3MnXVxuICBpZiAoIV9wcm9jZXNzKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBjb25zdCBwcm9jZXNzVmVyc2lvbiA9IF9wcm9jZXNzWyd2ZXJzaW9uJ11cbiAgaWYgKHByb2Nlc3NWZXJzaW9uID09PSB1bmRlZmluZWQgfHwgcHJvY2Vzc1ZlcnNpb24gPT09IG51bGwpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGNvbnN0IHZlcnNpb25NYXRjaCA9IHByb2Nlc3NWZXJzaW9uLm1hdGNoKC9edihcXGQrKVxcLi8pXG4gIGlmICghdmVyc2lvbk1hdGNoKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBjb25zdCBtYWpvclZlcnNpb24gPSBwYXJzZUludCh2ZXJzaW9uTWF0Y2hbMV0sIDEwKVxuICByZXR1cm4gbWFqb3JWZXJzaW9uIDw9IDE4XG59XG5cbmlmIChzaG91bGRTaG93RGVwcmVjYXRpb25XYXJuaW5nKCkpIHtcbiAgY29uc29sZS53YXJuKFxuICAgIGDimqDvuI8gIE5vZGUuanMgMTggYW5kIGJlbG93IGFyZSBkZXByZWNhdGVkIGFuZCB3aWxsIG5vIGxvbmdlciBiZSBzdXBwb3J0ZWQgaW4gZnV0dXJlIHZlcnNpb25zIG9mIEBzdXBhYmFzZS9zdXBhYmFzZS1qcy4gYCArXG4gICAgICBgUGxlYXNlIHVwZ3JhZGUgdG8gTm9kZS5qcyAyMCBvciBsYXRlci4gYCArXG4gICAgICBgRm9yIG1vcmUgaW5mb3JtYXRpb24sIHZpc2l0OiBodHRwczovL2dpdGh1Yi5jb20vb3Jncy9zdXBhYmFzZS9kaXNjdXNzaW9ucy8zNzIxN2BcbiAgKVxufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlsyLDAsMSwzLDQsNSw2LDcsOCw5LDEwLDExXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBTUEsTUFBYSxVQUFVOzs7O0FDRHZCLElBQUksU0FBUztBQUNiLElBQUlBO0FBRUosSUFBSSxPQUFPLFNBQVMsYUFBYTs7QUFDL0IsVUFBUztBQUVULHVDQUFxQixLQUFLLHVFQUFTO1dBQzFCLE9BQU8sYUFBYSxZQUM3QixVQUFTO1NBQ0EsT0FBTyxjQUFjLGVBQWUsVUFBVSxZQUFZLGNBQ25FLFVBQVM7S0FDSjs7QUFDTCxVQUFTO0FBQ1Qsc0JBQ0UsT0FBTyxZQUFZLGtDQUFjLFFBQVEsNkVBQVMsUUFBUSxNQUFNLEdBQUcsR0FBRzs7QUFHMUUsTUFBTSxlQUFlLENBQUMsV0FBVyxTQUFTO0FBQzFDLElBQUksbUJBQ0YsY0FBYSxLQUFLLG1CQUFtQixxQkFBcUI7QUFHNUQsTUFBYSxrQkFBa0IsRUFDN0IsaUJBQWlCLGVBQWUsUUFBUSxJQUFJLGFBQWEsS0FBSyxLQUFLLElBQ3BFO0FBRUQsTUFBYSx5QkFBeUIsRUFDcEMsU0FBUyxpQkFDVjtBQUVELE1BQWEscUJBQXFCLEVBQ2hDLFFBQVEsVUFDVDtBQUVELE1BQWFDLHVCQUFrRDtDQUM3RCxrQkFBa0I7Q0FDbEIsZ0JBQWdCO0NBQ2hCLG9CQUFvQjtDQUNwQixVQUFVO0NBQ1g7QUFFRCxNQUFhQywyQkFBa0QsRUFBRTtBQUVqRSxNQUFhQyxvQ0FBNkQ7Q0FDeEUsU0FBUztDQUNULHlCQUF5QjtDQUMxQjs7OztBQytERCxTQUFnQixVQUFVLFNBQVMsWUFBWSxHQUFHLFdBQVc7Q0FDM0QsU0FBUyxNQUFNLE9BQU87QUFBRSxTQUFPLGlCQUFpQixJQUFJLFFBQVEsSUFBSSxFQUFFLFNBQVUsU0FBUztBQUFFLFdBQVEsTUFBTTtJQUFJOztBQUN6RyxRQUFPLEtBQUssTUFBTSxJQUFJLFVBQVUsU0FBVSxTQUFTLFFBQVE7RUFDdkQsU0FBUyxVQUFVLE9BQU87QUFBRSxPQUFJO0FBQUUsU0FBSyxVQUFVLEtBQUssTUFBTSxDQUFDO1lBQVcsR0FBRztBQUFFLFdBQU8sRUFBRTs7O0VBQ3RGLFNBQVMsU0FBUyxPQUFPO0FBQUUsT0FBSTtBQUFFLFNBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQztZQUFXLEdBQUc7QUFBRSxXQUFPLEVBQUU7OztFQUN6RixTQUFTLEtBQUssUUFBUTtBQUFFLFVBQU8sT0FBTyxRQUFRLE9BQU8sTUFBTSxHQUFHLE1BQU0sT0FBTyxNQUFNLENBQUMsS0FBSyxXQUFXLFNBQVM7O0FBQzNHLFFBQU0sWUFBWSxVQUFVLE1BQU0sU0FBUyxjQUFjLEVBQUUsQ0FBQyxFQUFFLE1BQU0sQ0FBQztHQUN2RTs7Ozs7QUN4SEosSUFBSSxvQkFBb0I7QUFLeEIsTUFBTSxXQUFXO0FBQ2pCLFNBQVMsV0FBVztBQUNoQixLQUFJLHNCQUFzQixLQUN0QixxQkFBb0IsT0FBTyxVQUFVLFlBQVksS0FBSztBQUUxRCxRQUFPOzs7Ozs7Ozs7O0FBa0JYLFNBQWdCLHNCQUFzQjtBQUNsQyxRQUFPLFVBQVUsTUFBTSxLQUFLLEdBQUcsS0FBSyxHQUFHLGFBQWE7QUFDaEQsTUFBSTtHQUNBLE1BQU0sT0FBTyxNQUFNLFVBQVU7QUFDN0IsT0FBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLGVBQWUsQ0FBQyxLQUFLLFFBQ3BDLFFBQU87R0FFWCxNQUFNLFVBQVUsRUFBRTtBQUNsQixRQUFLLFlBQVksT0FBTyxLQUFLLFFBQVEsUUFBUSxFQUFFLFFBQVE7R0FDdkQsTUFBTSxjQUFjLFFBQVE7QUFDNUIsT0FBSSxDQUFDLFlBQ0QsUUFBTztBQUVYLFVBQU87SUFDSDtJQUNBLFlBQVksUUFBUTtJQUNwQixTQUFTLFFBQVE7SUFDcEI7V0FFRSxJQUFJO0FBQ1AsVUFBTzs7R0FFYjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkJOLFNBQWdCLGlCQUFpQixhQUFhO0FBQzFDLEtBQUksQ0FBQyxlQUFlLE9BQU8sZ0JBQWdCLFNBQ3ZDLFFBQU87Q0FHWCxNQUFNLFFBQVEsWUFBWSxNQUFNLElBQUk7QUFFcEMsS0FBSSxNQUFNLFdBQVcsRUFDakIsUUFBTztDQUVYLE1BQU0sQ0FBQ0MsV0FBUyxTQUFTLFVBQVUsY0FBYztBQUVqRCxLQUFJQSxVQUFRLFdBQVcsS0FDbkIsUUFBUSxXQUFXLE1BQ25CLFNBQVMsV0FBVyxNQUNwQixXQUFXLFdBQVcsRUFDdEIsUUFBTztDQUdYLE1BQU0sV0FBVztBQUNqQixLQUFJLENBQUMsU0FBUyxLQUFLQSxVQUFRLElBQ3ZCLENBQUMsU0FBUyxLQUFLLFFBQVEsSUFDdkIsQ0FBQyxTQUFTLEtBQUssU0FBUyxJQUN4QixDQUFDLFNBQVMsS0FBSyxXQUFXLENBQzFCLFFBQU87QUFHWCxLQUFJLFlBQVksc0NBQXNDLGFBQWEsbUJBQy9ELFFBQU87QUFLWCxRQUFPO0VBQ0g7RUFDQTtFQUNBO0VBQ0E7RUFDQSxZQVBVLFNBQVMsWUFBWSxHQUFHLEdBQ1gsT0FBVTtFQU9wQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RDTCxTQUFnQix3QkFBd0IsV0FBVyxTQUFTO0FBQ3hELEtBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxRQUFRLFdBQVcsRUFDN0MsUUFBTztDQUVYLElBQUk7QUFDSixLQUFJLHFCQUFxQixJQUNyQixPQUFNO0tBR04sS0FBSTtBQUNBLFFBQU0sSUFBSSxJQUFJLFVBQVU7VUFFckIsT0FBTztBQUVWLFNBQU87O0FBSWYsTUFBSyxNQUFNLFVBQVUsUUFDakIsS0FBSTtBQUNBLE1BQUksT0FBTyxXQUFXLFVBRWxCO09BQUksa0JBQWtCLElBQUksVUFBVSxPQUFPLENBQ3ZDLFFBQU87YUFHTixrQkFBa0IsUUFFdkI7T0FBSSxPQUFPLEtBQUssSUFBSSxTQUFTLENBQ3pCLFFBQU87YUFHTixPQUFPLFdBQVcsWUFFdkI7T0FBSSxPQUFPLElBQUksQ0FDWCxRQUFPOztVQUlaLE9BQU87QUFFVjs7QUFHUixRQUFPOzs7Ozs7Ozs7QUFTWCxTQUFTLGtCQUFrQixVQUFVLFFBQVE7QUFFekMsS0FBSSxXQUFXLFNBQ1gsUUFBTztBQUdYLEtBQUksT0FBTyxXQUFXLEtBQUssRUFBRTtFQUN6QixNQUFNLFNBQVMsT0FBTyxNQUFNLEVBQUU7QUFFOUIsTUFBSSxTQUFTLFNBQVMsT0FBTyxFQUd6QjtPQUFJLGFBQWEsVUFBVSxTQUFTLFNBQVMsTUFBTSxPQUFPLENBQ3RELFFBQU87OztBQUluQixRQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0RlgsU0FBZ0IsNkJBQTZCLGFBQWE7Q0FDdEQsTUFBTSxVQUFVLEVBQUU7QUFFbEIsS0FBSTtFQUNBLE1BQU0sTUFBTSxJQUFJLElBQUksWUFBWTtBQUNoQyxVQUFRLEtBQUssSUFBSSxTQUFTO1VBRXZCLE9BQU87QUFLZCxTQUFRLEtBQUssaUJBQWlCLGdCQUFnQjtBQUU5QyxTQUFRLEtBQUssYUFBYSxhQUFhLFFBQVE7QUFDL0MsUUFBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQlgsTUFBYSxnQkFBZ0IsZ0JBQStCO0FBQzFELEtBQUksWUFDRixTQUFRLEdBQUcsU0FBNEIsWUFBWSxHQUFHLEtBQUs7QUFFN0QsU0FBUSxHQUFHLFNBQTRCLE1BQU0sR0FBRyxLQUFLOztBQUd2RCxNQUFhLGtDQUFrQztBQUM3QyxRQUFPOztBQUdULE1BQWEsaUJBQ1gsYUFDQSxhQUNBLGdCQUNBLGFBQ0EsNEJBQ1U7Q0FDVixNQUFNQyxVQUFRLGFBQWEsWUFBWTtDQUN2QyxNQUFNLHFCQUFxQiwyQkFBMkI7Q0FJdEQsTUFBTSxrR0FBZSx3QkFBeUIsYUFBWTtDQUMxRCxNQUFNLHFHQUFrQix3QkFBeUIsNkJBQTRCO0NBQzdFLE1BQU1DLGVBQWdELGVBQ2xELDZCQUE2QixZQUFZLEdBQ3pDO0FBRUosUUFBTyxPQUFPLE9BQU8sU0FBUzs7RUFDNUIsTUFBTSx1Q0FBZSxNQUFNLGdCQUFnQix5RUFBSztFQUNoRCxJQUFJLFVBQVUsSUFBSSwrREFBbUIsS0FBTSxRQUFRO0FBRW5ELE1BQUksQ0FBQyxRQUFRLElBQUksU0FBUyxDQUN4QixTQUFRLElBQUksVUFBVSxZQUFZO0FBR3BDLE1BQUksQ0FBQyxRQUFRLElBQUksZ0JBQWdCLENBQy9CLFNBQVEsSUFBSSxpQkFBaUIsVUFBVSxjQUFjO0FBR3ZELE1BQUksY0FBYztHQUNoQixNQUFNLGVBQWUsTUFBTSxnQkFBZ0IsT0FBTyxjQUFjLGdCQUFnQjtBQUVoRixPQUFJLGNBQWM7QUFDaEIsUUFBSSxhQUFhLGVBQWUsQ0FBQyxRQUFRLElBQUksY0FBYyxDQUN6RCxTQUFRLElBQUksZUFBZSxhQUFhLFlBQVk7QUFFdEQsUUFBSSxhQUFhLGNBQWMsQ0FBQyxRQUFRLElBQUksYUFBYSxDQUN2RCxTQUFRLElBQUksY0FBYyxhQUFhLFdBQVc7QUFFcEQsUUFBSSxhQUFhLFdBQVcsQ0FBQyxRQUFRLElBQUksVUFBVSxDQUNqRCxTQUFRLElBQUksV0FBVyxhQUFhLFFBQVE7OztBQUtsRCxTQUFPRCxRQUFNLHlDQUFZLGFBQU0sV0FBVTs7O0FBSTdDLGVBQWUsZ0JBQ2IsT0FDQSxTQUNBLGlCQUM4QjtBQUk5QixLQUFJLENBQUMsd0JBRkgsT0FBTyxVQUFVLFdBQVcsUUFBUSxpQkFBaUIsTUFBTSxRQUFRLE1BQU0sS0FFbkMsUUFBUSxDQUM5QyxRQUFPO0NBR1QsTUFBTSxlQUFlLE1BQU0scUJBQXFCO0FBRWhELEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLFlBQ2pDLFFBQU87QUFHVCxLQUFJLGlCQUFpQjtFQUNuQixNQUFNLFNBQVMsaUJBQWlCLGFBQWEsWUFBWTtBQUN6RCxNQUFJLFVBQVUsQ0FBQyxPQUFPLFVBQ3BCLFFBQU87O0FBSVgsUUFBTzs7Ozs7QUMvRlQsU0FBUywwQkFDUCxPQUNxQztBQUNyQyxRQUFPLE9BQU8sVUFBVSxZQUFZLEVBQUUsU0FBUyxPQUFPLEdBQUc7O0FBVzNELFNBQWdCLG9CQUFvQixLQUFxQjtBQUN2RCxRQUFPLElBQUksU0FBUyxJQUFJLEdBQUcsTUFBTSxNQUFNOztBQVl6QyxTQUFnQixxQkFNZCxTQUNBLFVBQzJDOztDQUMzQyxNQUFNLEVBQ0osSUFBSSxXQUNKLE1BQU0sYUFDTixVQUFVLGlCQUNWLFFBQVEsa0JBQ047Q0FDSixNQUFNLEVBQ0osSUFBSUUsc0JBQ0osTUFBTUMsd0JBQ04sVUFBVUMsNEJBQ1YsUUFBUUMsNkJBQ047Q0FHSixNQUFNLDBCQUEwQiwwQkFBMEIsUUFBUSxpQkFBaUI7Q0FDbkYsTUFBTUMsc0NBQW9DLDBCQUEwQixTQUFTLGlCQUFpQjtDQUU5RixNQUFNQyxTQUFvRDtFQUN4RCxzQ0FDS0wsdUJBQ0E7RUFFTCx3Q0FDS0MseUJBQ0E7RUFFTCw0Q0FDS0MsNkJBQ0E7RUFFTCxTQUFTLEVBQUU7RUFDWCx5REFDS0MsMkJBQ0Esc0JBQ0gsd0pBQ01BLHlCQUF3QixnRkFBVyxFQUFFLDBGQUNyQyxjQUFlLGdGQUFXLEVBQUU7RUFHcEMsa0JBQWtCO0dBQ2hCLDRIQUNFLHdCQUF5QiwwTEFBV0Msb0NBQW1DLDhDQUFXO0dBQ3BGLDhJQUNFLHdCQUF5Qiw0TUFDekJBLG9DQUFtQyxnRUFDbkM7R0FDSDtFQUNELGFBQWEsWUFBWTtFQUMxQjtBQUVELEtBQUksUUFBUSxZQUNWLFFBQU8sY0FBYyxRQUFRO0tBRzdCLFFBQVEsT0FBZTtBQUd6QixRQUFPOzs7Ozs7Ozs7QUFVVCxTQUFnQixvQkFBb0IsYUFBMEI7Q0FDNUQsTUFBTSx1RUFBYSxZQUFhLE1BQU07QUFFdEMsS0FBSSxDQUFDLFdBQ0gsT0FBTSxJQUFJLE1BQU0sMkJBQTJCO0FBRzdDLEtBQUksQ0FBQyxXQUFXLE1BQU0sZ0JBQWdCLENBQ3BDLE9BQU0sSUFBSSxNQUFNLDBEQUEwRDtBQUc1RSxLQUFJO0FBQ0YsU0FBTyxJQUFJLElBQUksb0JBQW9CLFdBQVcsQ0FBQzttQkFDekM7QUFDTixRQUFNLE1BQU0sa0RBQWtEOzs7Ozs7QUNySGxFLElBQWEscUJBQWIsY0FBd0MsV0FBVztDQUNqRCxZQUFZLFNBQW9DO0FBQzlDLFFBQU0sUUFBUTs7Ozs7Ozs7Ozs7QUNxQ2xCLElBQXFCLGlCQUFyQixNQStCRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EyT0EsWUFDRSxBQUFVRSxhQUNWLEFBQVVDLGFBQ1YsU0FDQTs7RUFIVTtFQUNBO0VBR1YsTUFBTSxVQUFVLG9CQUFvQixZQUFZO0FBQ2hELE1BQUksQ0FBQyxZQUFhLE9BQU0sSUFBSSxNQUFNLDJCQUEyQjtBQUU3RCxPQUFLLGNBQWMsSUFBSSxJQUFJLGVBQWUsUUFBUTtBQUNsRCxPQUFLLFlBQVksV0FBVyxLQUFLLFlBQVksU0FBUyxRQUFRLFFBQVEsS0FBSztBQUMzRSxPQUFLLFVBQVUsSUFBSSxJQUFJLFdBQVcsUUFBUTtBQUMxQyxPQUFLLGFBQWEsSUFBSSxJQUFJLGNBQWMsUUFBUTtBQUNoRCxPQUFLLGVBQWUsSUFBSSxJQUFJLGdCQUFnQixRQUFRO0VBR3BELE1BQU0sb0JBQW9CLE1BQU0sUUFBUSxTQUFTLE1BQU0sSUFBSSxDQUFDLEdBQUc7RUFDL0QsTUFBTSxXQUFXO0dBQ2YsSUFBSTtHQUNKLFVBQVU7R0FDVix3Q0FBVyw2QkFBc0IsWUFBWTtHQUM3QyxRQUFRO0dBQ1Isa0JBQWtCO0dBQ25CO0VBRUQsTUFBTSxXQUFXLHFCQUFxQixtREFBVyxFQUFFLEVBQUUsU0FBUztBQUM5RCxPQUFLLFdBQVc7QUFFaEIsT0FBSyxzQ0FBYSxTQUFTLEtBQUssbUZBQWM7QUFDOUMsT0FBSyxtQ0FBVSxTQUFTLE9BQU8sZ0ZBQVcsRUFBRTtBQUU1QyxNQUFJLENBQUMsU0FBUyxhQUFhOztBQUN6QixRQUFLLE9BQU8sS0FBSywwQ0FDZixTQUFTLCtEQUFRLEVBQUUsRUFDbkIsS0FBSyxTQUNMLFNBQVMsT0FBTyxNQUNqQjtTQUNJO0FBQ0wsUUFBSyxjQUFjLFNBQVM7QUFFNUIsUUFBSyxPQUFPLElBQUksTUFBMEIsRUFBRSxFQUFTLEVBQ25ELE1BQU0sR0FBRyxTQUFTO0FBQ2hCLFVBQU0sSUFBSSxNQUNSLDZHQUE2RyxPQUMzRyxLQUNELENBQUMsa0JBQ0g7TUFFSixDQUFDOztBQUdKLE9BQUssUUFBUSxjQUNYLGFBQ0EsYUFDQSxLQUFLLGdCQUFnQixLQUFLLEtBQUssRUFDL0IsU0FBUyxPQUFPLE9BQ2hCLFNBQVMsaUJBQ1Y7QUFDRCxPQUFLLFdBQVcsS0FBSztHQUNuQixTQUFTLEtBQUs7R0FDZCxhQUFhLEtBQUssZ0JBQWdCLEtBQUssS0FBSztHQUM1QyxPQUFPLEtBQUs7S0FDVCxTQUFTLFVBQ1o7QUFDRixNQUFJLEtBQUssWUFHUCxTQUFRLFFBQVEsS0FBSyxhQUFhLENBQUMsQ0FDaEMsTUFBTSxVQUFVLEtBQUssU0FBUyxRQUFRLE1BQU0sQ0FBQyxDQUM3QyxPQUFPLE1BQU0sUUFBUSxLQUFLLDhDQUE4QyxFQUFFLENBQUM7QUFHaEYsT0FBSyxPQUFPLElBQUksZ0JBQWdCLElBQUksSUFBSSxXQUFXLFFBQVEsQ0FBQyxNQUFNO0dBQ2hFLFNBQVMsS0FBSztHQUNkLFFBQVEsU0FBUyxHQUFHO0dBQ3BCLE9BQU8sS0FBSztHQUNaLFNBQVMsU0FBUyxHQUFHO0dBQ3JCLGdCQUFnQixTQUFTLEdBQUc7R0FDN0IsQ0FBQztBQUVGLE9BQUssVUFBVSxJQUFJQyxjQUNqQixLQUFLLFdBQVcsTUFDaEIsS0FBSyxTQUNMLEtBQUsseURBQ0wsUUFBUyxRQUNWO0FBRUQsTUFBSSxDQUFDLFNBQVMsWUFDWixNQUFLLHNCQUFzQjs7Ozs7Q0FPL0IsSUFBSSxZQUE2QjtBQUMvQixTQUFPLElBQUksZ0JBQWdCLEtBQUssYUFBYSxNQUFNO0dBQ2pELFNBQVMsS0FBSztHQUNkLGFBQWEsS0FBSztHQUNuQixDQUFDOzs7Ozs7O0NBZ0JKLEtBQUssVUFBcUU7QUFDeEUsU0FBTyxLQUFLLEtBQUssS0FBSyxTQUFTOzs7Ozs7Ozs7Q0FXakMsT0FDRSxRQU1BO0FBQ0EsU0FBTyxLQUFLLEtBQUssT0FBc0IsT0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCaEQsSUFNRSxJQUNBLE9BQWEsRUFBRSxFQUNmLFVBSUk7RUFDRixNQUFNO0VBQ04sS0FBSztFQUNMLE9BQU87RUFDUixFQVNEO0FBQ0EsU0FBTyxLQUFLLEtBQUssSUFBSSxJQUFJLE1BQU0sUUFBUTs7Ozs7Ozs7OztDQW1CekMsUUFBUSxNQUFjLE9BQStCLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBbUI7QUFDcEYsU0FBTyxLQUFLLFNBQVMsUUFBUSxNQUFNLEtBQUs7Ozs7Ozs7Ozs7OztDQWExQyxjQUFpQztBQUMvQixTQUFPLEtBQUssU0FBUyxhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQnBDLGNBQWMsU0FBa0U7QUFDOUUsU0FBTyxLQUFLLFNBQVMsY0FBYyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Q0FnQjdDLG9CQUE4RDtBQUM1RCxTQUFPLEtBQUssU0FBUyxtQkFBbUI7O0NBRzFDLE1BQWMsa0JBQWtCOzs7QUFDOUIsTUFBSUMsTUFBSyxZQUNQLFFBQU8sTUFBTUEsTUFBSyxhQUFhO0VBR2pDLE1BQU0sRUFBRSxTQUFTLE1BQU1BLE1BQUssS0FBSyxZQUFZO0FBRTdDLG1EQUFPLEtBQUssdUVBQVMscUZBQWdCQSxNQUFLOztDQUc1QyxBQUFRLHdCQUNOLEVBQ0Usa0JBQ0EsZ0JBQ0Esb0JBQ0EsU0FDQSxhQUNBLFlBQ0EsVUFDQSxNQUNBLE9BQ0EsY0FDQSxjQUNBLG9CQUNBLHNCQUVGLFNBQ0EsU0FDQTtFQUNBLE1BQU0sY0FBYztHQUNsQixlQUFlLFVBQVUsS0FBSztHQUM5QixRQUFRLEdBQUcsS0FBSztHQUNqQjtBQUNELFNBQU8sSUFBSSxtQkFBbUI7R0FDNUIsS0FBSyxLQUFLLFFBQVE7R0FDbEIsMkNBQWMsY0FBZ0I7R0FDbEI7R0FDWjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUdBLDhCQUE4QixPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsTUFDckQsUUFBUSxJQUFJLGFBQWEsS0FBSyxnQkFDaEM7R0FDRixDQUFDOztDQUdKLEFBQVEsb0JBQW9CLFNBQWdDO0FBQzFELFNBQU8sSUFBSSxlQUFlLEtBQUssWUFBWSx3Q0FDdEMsZ0JBQ0gsMENBQWEsRUFBRSxRQUFRLEtBQUssYUFBYSxxREFBSyxRQUFTLFdBQ3ZEOztDQUdKLEFBQVEsdUJBQXVCO0FBSTdCLFNBSGEsS0FBSyxLQUFLLG1CQUFtQixPQUFPLFlBQVk7QUFDM0QsUUFBSyxvQkFBb0IsT0FBTyw0REFBVSxRQUFTLGFBQWE7SUFDaEU7O0NBSUosQUFBUSxvQkFDTixPQUNBLFFBQ0EsT0FDQTtBQUNBLE9BQ0csVUFBVSxxQkFBcUIsVUFBVSxnQkFDMUMsS0FBSyx1QkFBdUIsT0FDNUI7QUFDQSxRQUFLLHFCQUFxQjtBQUMxQixRQUFLLFNBQVMsUUFBUSxNQUFNO2FBQ25CLFVBQVUsY0FBYztBQUNqQyxRQUFLLFNBQVMsU0FBUztBQUN2QixPQUFJLFVBQVUsVUFBVyxNQUFLLEtBQUssU0FBUztBQUM1QyxRQUFLLHFCQUFxQjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDam1CaEMsTUFBYSxnQkFjWCxhQUNBLGFBQ0EsWUFDb0U7QUFDcEUsUUFBTyxJQUFJLGVBQ1QsYUFDQSxhQUNBLFFBQ0Q7O0FBSUgsU0FBUywrQkFBd0M7QUFFL0MsS0FBSSxPQUFPLFdBQVcsWUFDcEIsUUFBTztDQUtULE1BQU0sV0FBWSxXQUFtQjtBQUNyQyxLQUFJLENBQUMsU0FDSCxRQUFPO0NBR1QsTUFBTSxpQkFBaUIsU0FBUztBQUNoQyxLQUFJLG1CQUFtQixVQUFhLG1CQUFtQixLQUNyRCxRQUFPO0NBR1QsTUFBTSxlQUFlLGVBQWUsTUFBTSxZQUFZO0FBQ3RELEtBQUksQ0FBQyxhQUNILFFBQU87QUFJVCxRQURxQixTQUFTLGFBQWEsSUFBSSxHQUFHLElBQzNCOztBQUd6QixJQUFJLDhCQUE4QixDQUNoQyxTQUFRLEtBQ04sOE9BR0QifQ==