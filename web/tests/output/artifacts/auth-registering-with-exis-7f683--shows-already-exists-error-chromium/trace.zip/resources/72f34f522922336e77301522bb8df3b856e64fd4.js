export const DEFAULT_COOKIE_OPTIONS = {
    path: "/",
    sameSite: "lax",
    httpOnly: false,
    // https://developer.chrome.com/blog/cookie-max-age-expires
    // https://httpwg.org/http-extensions/draft-ietf-httpbis-rfc6265bis.html#name-cookie-lifetime-limits
    maxAge: 400 * 24 * 60 * 60,
};
                                     
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uc3RhbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3V0aWxzL2NvbnN0YW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQSxNQUFNLENBQUMsTUFBTSxzQkFBc0IsR0FBa0I7SUFDbkQsSUFBSSxFQUFFLEdBQUc7SUFDVCxRQUFRLEVBQUUsS0FBSztJQUNmLFFBQVEsRUFBRSxLQUFLO0lBQ2YsMkRBQTJEO0lBQzNELG9HQUFvRztJQUNwRyxNQUFNLEVBQUUsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRTtDQUMzQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29va2llT3B0aW9ucyB9IGZyb20gXCIuLi90eXBlc1wiO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9DT09LSUVfT1BUSU9OUzogQ29va2llT3B0aW9ucyA9IHtcbiAgcGF0aDogXCIvXCIsXG4gIHNhbWVTaXRlOiBcImxheFwiLFxuICBodHRwT25seTogZmFsc2UsXG4gIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vYmxvZy9jb29raWUtbWF4LWFnZS1leHBpcmVzXG4gIC8vIGh0dHBzOi8vaHR0cHdnLm9yZy9odHRwLWV4dGVuc2lvbnMvZHJhZnQtaWV0Zi1odHRwYmlzLXJmYzYyNjViaXMuaHRtbCNuYW1lLWNvb2tpZS1saWZldGltZS1saW1pdHNcbiAgbWF4QWdlOiA0MDAgKiAyNCAqIDYwICogNjAsXG59O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=