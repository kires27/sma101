import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Header.vue");import { default as __nuxt_component_0 } from "/_nuxt/ui/Branding.vue";
import { default as __nuxt_component_1 } from "/_nuxt/ui/Text.vue";
import { default as __nuxt_component_2 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/components/nuxt-link.js?v=583078ff";
import { default as __nuxt_component_3 } from "/_nuxt/ui/Button.vue";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"
import { URI } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/shared/constants/routes.js"
import { Icon } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@iconify+vue@5.0.1_vue@3.5.38_typescript@5.9.3_/node_modules/@iconify/vue/dist/iconify.mjs"



import { useRoute, navigateTo } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/composables/router.js?v=583078ff";
import { ref, onMounted, watch } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
import { useSupabaseUser } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@nuxtjs+supabase@2.0.9/node_modules/@nuxtjs/supabase/dist/runtime/composables/useSupabaseUser.js?v=583078ff";
import { useSupabaseClient } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@nuxtjs+supabase@2.0.9/node_modules/@nuxtjs/supabase/dist/runtime/composables/useSupabaseClient.js?v=583078ff";
const _sfc_main = {
  __name: "Header",
  setup(__props, { expose: __expose }) {
  __expose();

const user = useSupabaseUser()
const client = useSupabaseClient()
const route = useRoute()

const menuOpen = ref(false)
const isHydrated = ref(false)

onMounted(() => {
	isHydrated.value = true
})

function closeMenu() {
	menuOpen.value = false
}

watch(() => route.fullPath, closeMenu)

async function logout() {
	await client.auth.signOut()
	await navigateTo(URI.user.login)
}

const __returned__ = { user, client, route, menuOpen, isHydrated, closeMenu, logout, get useSupabaseUser() { return useSupabaseUser }, get useSupabaseClient() { return useSupabaseClient }, get URI() { return URI }, get Icon() { return Icon } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createVNode as _createVNode, createElementVNode as _createElementVNode, resolveComponent as _resolveComponent, createTextVNode as _createTextVNode, withCtx as _withCtx, createCommentVNode as _createCommentVNode, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

const _hoisted_1 = { class: "header" }
const _hoisted_2 = { class: "header-inner" }
const _hoisted_3 = { class: "header-left" }
const _hoisted_4 = { class: "branding" }
const _hoisted_5 = { class: "nav" }
const _hoisted_6 = { class: "header-right" }
const _hoisted_7 = {
  key: 1,
  class: "mobile-dropdown"
}
const _hoisted_8 = { class: "mobile-nav" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Branding = __nuxt_component_0
  const _component_Text = __nuxt_component_1
  const _component_NuxtLink = __nuxt_component_2
  const _component_Button = __nuxt_component_3

  return (_openBlock(), _tracer(30,1,_createElementBlock("header", _hoisted_1, [
    _tracer(31,2,_createElementVNode("div", _hoisted_2, [
      _tracer(32,3,_createElementVNode("div", _hoisted_3, [
        _tracer(33,4,_createElementVNode("button", {
          class: "menu-btn",
          "aria-label": "Menu",
          onClick: _cache[0] || (_cache[0] = $event => ($setup.menuOpen = !$setup.menuOpen))
        }, [
          _tracer(34,5,_createVNode($setup["Icon"], {
            icon: $setup.menuOpen ? 'material-symbols:close' : 'material-symbols:menu',
            width: "24"
          }, null, 8 /* PROPS */, ["icon"]))
        ])),
        _tracer(37,4,_createElementVNode("div", _hoisted_4, [
          _tracer(38,5,_createVNode(_component_Branding, {
            show: "name",
            size: "md"
          }))
        ])),
        _tracer(41,4,_createVNode(_component_Text, {
          variant: "body-sm",
          tone: "muted",
          class: "divider"
        }, {
          default: _withCtx(() => [...(_cache[1] || (_cache[1] = [
            _createTextVNode("|", -1 /* CACHED */)
          ]))]),
          _: 1 /* STABLE */
        })),
        _tracer(43,4,_createElementVNode("nav", _hoisted_5, [
          _tracer(44,5,_createVNode(_component_NuxtLink, {
            to: $setup.URI.tool.fa
          }, {
            default: _withCtx(() => [
              _tracer(45,6,_createVNode(_component_Text, {
                variant: "body",
                link: ""
              }, {
                default: _withCtx(() => [...(_cache[2] || (_cache[2] = [
                  _createTextVNode(" investing ", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }))
            ]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["to"])),
          _tracer(49,5,_createVNode(_component_NuxtLink, {
            to: $setup.URI.tool.congress
          }, {
            default: _withCtx(() => [
              _tracer(50,6,_createVNode(_component_Text, {
                variant: "body",
                link: ""
              }, {
                default: _withCtx(() => [...(_cache[3] || (_cache[3] = [
                  _createTextVNode(" trading ", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }))
            ]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["to"])),
          _createCommentVNode(" <NuxtLink :to=\"URI.tool.congress\">\n\t\t\t\t\t<Text variant=\"body\" link>\n\t\t\t\t\t\tCONGRESS\n\t\t\t\t\t</Text>\n\t\t\t\t</NuxtLink> "),
          _tracer(59,5,_createVNode(_component_NuxtLink, {
            to: $setup.URI.tool.watchlist
          }, {
            default: _withCtx(() => [
              _tracer(60,6,_createVNode(_component_Text, {
                variant: "body",
                link: ""
              }, {
                default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
                  _createTextVNode(" watchlists ", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }))
            ]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["to"])),
          _createCommentVNode(" <NuxtLink :to=\"URI.tool.global_index\">\n\t\t\t\t\t\t<Text variant=\"label\" link>\n\t\t\t\t\t\t\tGlobal Index\n\t\t\t\t\t\t</Text>\n\t\t\t\t\t</NuxtLink> ")
        ]))
      ])),
      _tracer(73,3,_createElementVNode("div", _hoisted_6, [
        ($setup.isHydrated && $setup.user)
          ? (_openBlock(), _tracer(74,4,_createElementBlock(_Fragment, { key: 0 }, [
              _tracer(75,5,_createVNode(_component_Button, null, {
                default: _withCtx(() => [
                  _tracer(76,6,_createVNode($setup["Icon"], {
                    icon: "material-symbols:notifications",
                    width: "16",
                    height: "16"
                  }))
                ]),
                _: 1 /* STABLE */
              })),
              _tracer(78,5,_createVNode(_component_NuxtLink, {
                to: $setup.URI.user.settings
              }, {
                default: _withCtx(() => [
                  _tracer(79,5,_createVNode(_component_Button, {
                    variant: "primary",
                    class: "profile-icon"
                  }, {
                    default: _withCtx(() => [
                      _tracer(80,6,_createVNode($setup["Icon"], {
                        icon: "mdi:gear",
                        width: "16",
                        height: "16"
                      }))
                    ]),
                    _: 1 /* STABLE */
                  }))
                ]),
                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["to"])),
              _tracer(83,5,_createVNode(_component_Button, {
                variant: "secondary",
                onClick: $setup.logout
              }, {
                default: _withCtx(() => [...(_cache[5] || (_cache[5] = [
                  _createTextVNode("Logout", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }))
            ], 64 /* STABLE_FRAGMENT */)))
          : (_openBlock(), _tracer(86,4,_createElementBlock(_Fragment, { key: 1 }, [
              _tracer(87,5,_createVNode(_component_NuxtLink, {
                to: $setup.URI.user.login
              }, {
                default: _withCtx(() => [
                  _tracer(88,6,_createVNode(_component_Button, null, {
                    default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
                      _createTextVNode("Sign in", -1 /* CACHED */)
                    ]))]),
                    _: 1 /* STABLE */
                  }))
                ]),
                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["to"])),
              _tracer(90,5,_createVNode(_component_NuxtLink, {
                to: $setup.URI.user.register
              }, {
                default: _withCtx(() => [
                  _tracer(91,6,_createVNode(_component_Button, null, {
                    default: _withCtx(() => [...(_cache[7] || (_cache[7] = [
                      _createTextVNode("Sign up", -1 /* CACHED */)
                    ]))]),
                    _: 1 /* STABLE */
                  }))
                ]),
                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["to"]))
            ], 64 /* STABLE_FRAGMENT */)))
      ]))
    ])),
    ($setup.menuOpen)
      ? (_openBlock(), _tracer(97,2,_createElementBlock("div", {
          key: 0,
          class: "dropdown-overlay",
          onClick: $setup.closeMenu
        })))
      : _createCommentVNode("v-if", true),
    ($setup.menuOpen)
      ? (_openBlock(), _tracer(99,2,_createElementBlock("div", _hoisted_7, [
          _tracer(100,3,_createElementVNode("nav", _hoisted_8, [
            _tracer(101,4,_createVNode(_component_NuxtLink, {
              to: $setup.URI.tool.fa,
              onClick: $setup.closeMenu
            }, {
              default: _withCtx(() => [
                _tracer(102,5,_createVNode(_component_Text, {
                  variant: "body",
                  link: ""
                }, {
                  default: _withCtx(() => [...(_cache[8] || (_cache[8] = [
                    _createTextVNode("investing", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                }))
              ]),
              _: 1 /* STABLE */
            }, 8 /* PROPS */, ["to"])),
            _tracer(104,4,_createVNode(_component_NuxtLink, {
              to: $setup.URI.tool.congress,
              onClick: $setup.closeMenu
            }, {
              default: _withCtx(() => [
                _tracer(105,5,_createVNode(_component_Text, {
                  variant: "body",
                  link: ""
                }, {
                  default: _withCtx(() => [...(_cache[9] || (_cache[9] = [
                    _createTextVNode("trading", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                }))
              ]),
              _: 1 /* STABLE */
            }, 8 /* PROPS */, ["to"])),
            _tracer(107,4,_createVNode(_component_NuxtLink, {
              to: $setup.URI.tool.watchlist,
              onClick: $setup.closeMenu
            }, {
              default: _withCtx(() => [
                _tracer(108,5,_createVNode(_component_Text, {
                  variant: "body",
                  link: ""
                }, {
                  default: _withCtx(() => [...(_cache[10] || (_cache[10] = [
                    _createTextVNode("watchlists", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                }))
              ]),
              _: 1 /* STABLE */
            }, 8 /* PROPS */, ["to"]))
          ]))
        ])))
      : _createCommentVNode("v-if", true)
  ])))
}


import "/_nuxt/ui/Header.vue?vue&type=style&index=0&scoped=e0840704&lang.css"

_sfc_main.__hmrId = "e0840704"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-e0840704"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Header.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Header.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FBRWxDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRXZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUU1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDOztBQUVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEI7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDOzs7Ozs7Ozs7O3FCQUlTLEtBQUssRUFBQyxRQUFRO3FCQUNoQixLQUFLLEVBQUMsY0FBYztxQkFDbkIsS0FBSyxFQUFDLGFBQWE7cUJBS2xCLEtBQUssRUFBQyxVQUFVO3FCQU1oQixLQUFLLEVBQUMsS0FBSztxQkE4QlosS0FBSyxFQUFDLGNBQWM7OztFQTBCTCxLQUFLLEVBQUM7O3FCQUNyQixLQUFLLEVBQUMsWUFBWTs7Ozs7Ozs7cUNBdEV6QixvQkFrRlMsVUFsRlQsVUFrRlM7aUJBakZSLG9CQWdFTSxPQWhFTixVQWdFTTttQkEvREwsb0JBc0NNLE9BdENOLFVBc0NNO3FCQXJDTCxvQkFFUztVQUZELEtBQUssRUFBQyxVQUFVO1VBQUMsWUFBVSxFQUFDLE1BQU07VUFBRSxPQUFLLHVDQUFFLGVBQVEsSUFBSSxlQUFROzt1QkFDdEUsYUFBeUY7WUFBbEYsSUFBSSxFQUFFLGVBQVE7WUFBdUQsS0FBSyxFQUFDOzs7cUJBR25GLG9CQUVNLE9BRk4sVUFFTTt1QkFETCxhQUFrQztZQUF4QixJQUFJLEVBQUMsTUFBTTtZQUFDLElBQUksRUFBQzs7O3FCQUc1QixhQUE2RDtVQUF2RCxPQUFPLEVBQUMsU0FBUztVQUFDLElBQUksRUFBQyxPQUFPO1VBQUMsS0FBSyxFQUFDOzs0QkFBVSxDQUFDOzZCQUFELEdBQUM7Ozs7cUJBRXRELG9CQTBCTSxPQTFCTixVQTBCTTt1QkF6QkwsYUFJVztZQUpBLEVBQUUsRUFBRSxVQUFHLENBQUMsSUFBSSxDQUFDOzs4QkFDdkIsQ0FFTzsyQkFGUCxhQUVPO2dCQUZELE9BQU8sRUFBQyxNQUFNO2dCQUFDLElBQUksRUFBSjs7a0NBQUssQ0FFMUI7bUNBRjBCLGFBRTFCOzs7Ozs7O3VCQUVELGFBSVc7WUFKQSxFQUFFLEVBQUUsVUFBRyxDQUFDLElBQUksQ0FBQzs7OEJBQ3ZCLENBRU87MkJBRlAsYUFFTztnQkFGRCxPQUFPLEVBQUMsTUFBTTtnQkFBQyxJQUFJLEVBQUo7O2tDQUFLLENBRTFCO21DQUYwQixXQUUxQjs7Ozs7OztVQUVELG1LQUljO3VCQUNkLGFBSVc7WUFKQSxFQUFFLEVBQUUsVUFBRyxDQUFDLElBQUksQ0FBQzs7OEJBQ3ZCLENBRU87MkJBRlAsYUFFTztnQkFGRCxPQUFPLEVBQUMsTUFBTTtnQkFBQyxJQUFJLEVBQUo7O2tDQUFLLENBRTFCO21DQUYwQixjQUUxQjs7Ozs7OztVQUVEOzs7bUJBU0Ysb0JBcUJNLE9BckJOLFVBcUJNO1NBcEJXLGlCQUFVLElBQUksV0FBSTt3Q0FBbEMsb0JBVVc7MkJBVFYsYUFFUztrQ0FEUixDQUFxRTsrQkFBckUsYUFBcUU7b0JBQS9ELElBQUksRUFBQyxnQ0FBZ0M7b0JBQUMsS0FBSyxFQUFDLElBQUk7b0JBQUMsTUFBTSxFQUFDOzs7OzsyQkFFL0QsYUFJVztnQkFKQSxFQUFFLEVBQUUsVUFBRyxDQUFDLElBQUksQ0FBQzs7a0NBQ3hCLENBRVM7K0JBRlQsYUFFUztvQkFGRCxPQUFPLEVBQUMsU0FBUztvQkFBQyxLQUFLLEVBQUM7O3NDQUMvQixDQUErQzttQ0FBL0MsYUFBK0M7d0JBQXpDLElBQUksRUFBQyxVQUFVO3dCQUFDLEtBQUssRUFBQyxJQUFJO3dCQUFDLE1BQU0sRUFBQzs7Ozs7Ozs7MkJBR3pDLGFBQTJEO2dCQUFuRCxPQUFPLEVBQUMsV0FBVztnQkFBRSxPQUFLLEVBQUU7O2tDQUFRLENBQU07bUNBQU4sUUFBTTs7Ozs7d0NBR25ELG9CQU9XOzJCQU5WLGFBRVc7Z0JBRkEsRUFBRSxFQUFFLFVBQUcsQ0FBQyxJQUFJLENBQUM7O2tDQUN2QixDQUF3QjsrQkFBeEIsYUFBd0I7c0NBQWhCLENBQU87dUNBQVAsU0FBTzs7Ozs7OzsyQkFFaEIsYUFFVztnQkFGQSxFQUFFLEVBQUUsVUFBRyxDQUFDLElBQUksQ0FBQzs7a0NBQ3ZCLENBQXdCOytCQUF4QixhQUF3QjtzQ0FBaEIsQ0FBTzt1Q0FBUCxTQUFPOzs7Ozs7Ozs7O0tBTVIsZUFBUTtvQ0FBbkIsb0JBQW1FOztVQUE5QyxLQUFLLEVBQUMsa0JBQWtCO1VBQUUsT0FBSyxFQUFFOzs7S0FFM0MsZUFBUTtvQ0FBbkIsb0JBWU0sT0FaTixVQVlNO3dCQVhMLG9CQVVNLE9BVk4sVUFVTTswQkFUTCxhQUVXO2NBRkEsRUFBRSxFQUFFLFVBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtjQUFHLE9BQUssRUFBRTs7Z0NBQ25DLENBQTBDOzhCQUExQyxhQUEwQztrQkFBcEMsT0FBTyxFQUFDLE1BQU07a0JBQUMsSUFBSSxFQUFKOztvQ0FBSyxDQUFTO3FDQUFULFdBQVM7Ozs7Ozs7MEJBRXBDLGFBRVc7Y0FGQSxFQUFFLEVBQUUsVUFBRyxDQUFDLElBQUksQ0FBQyxRQUFRO2NBQUcsT0FBSyxFQUFFOztnQ0FDekMsQ0FBd0M7OEJBQXhDLGFBQXdDO2tCQUFsQyxPQUFPLEVBQUMsTUFBTTtrQkFBQyxJQUFJLEVBQUo7O29DQUFLLENBQU87cUNBQVAsU0FBTzs7Ozs7OzswQkFFbEMsYUFFVztjQUZBLEVBQUUsRUFBRSxVQUFHLENBQUMsSUFBSSxDQUFDLFNBQVM7Y0FBRyxPQUFLLEVBQUU7O2dDQUMxQyxDQUEyQzs4QkFBM0MsYUFBMkM7a0JBQXJDLE9BQU8sRUFBQyxNQUFNO2tCQUFDLElBQUksRUFBSjs7b0NBQUssQ0FBVTtxQ0FBVixZQUFVIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIZWFkZXIudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyB1c2VTdXBhYmFzZVVzZXIsIHVzZVN1cGFiYXNlQ2xpZW50IH0gZnJvbSBcIiNpbXBvcnRzXCJcbmltcG9ydCB7IFVSSSB9IGZyb20gJyNzaGFyZWQvY29uc3RhbnRzL3JvdXRlcydcbmltcG9ydCB7IEljb24gfSBmcm9tICdAaWNvbmlmeS92dWUnXG5cbmNvbnN0IHVzZXIgPSB1c2VTdXBhYmFzZVVzZXIoKVxuY29uc3QgY2xpZW50ID0gdXNlU3VwYWJhc2VDbGllbnQoKVxuY29uc3Qgcm91dGUgPSB1c2VSb3V0ZSgpXG5cbmNvbnN0IG1lbnVPcGVuID0gcmVmKGZhbHNlKVxuY29uc3QgaXNIeWRyYXRlZCA9IHJlZihmYWxzZSlcblxub25Nb3VudGVkKCgpID0+IHtcblx0aXNIeWRyYXRlZC52YWx1ZSA9IHRydWVcbn0pXG5cbmZ1bmN0aW9uIGNsb3NlTWVudSgpIHtcblx0bWVudU9wZW4udmFsdWUgPSBmYWxzZVxufVxuXG53YXRjaCgoKSA9PiByb3V0ZS5mdWxsUGF0aCwgY2xvc2VNZW51KVxuXG5hc3luYyBmdW5jdGlvbiBsb2dvdXQoKSB7XG5cdGF3YWl0IGNsaWVudC5hdXRoLnNpZ25PdXQoKVxuXHRhd2FpdCBuYXZpZ2F0ZVRvKFVSSS51c2VyLmxvZ2luKVxufVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cblx0PGhlYWRlciBjbGFzcz1cImhlYWRlclwiPlxuXHRcdDxkaXYgY2xhc3M9XCJoZWFkZXItaW5uZXJcIj5cblx0XHRcdDxkaXYgY2xhc3M9XCJoZWFkZXItbGVmdFwiPlxuXHRcdFx0XHQ8YnV0dG9uIGNsYXNzPVwibWVudS1idG5cIiBhcmlhLWxhYmVsPVwiTWVudVwiIEBjbGljaz1cIm1lbnVPcGVuID0gIW1lbnVPcGVuXCI+XG5cdFx0XHRcdFx0PEljb24gOmljb249XCJtZW51T3BlbiA/ICdtYXRlcmlhbC1zeW1ib2xzOmNsb3NlJyA6ICdtYXRlcmlhbC1zeW1ib2xzOm1lbnUnXCIgd2lkdGg9XCIyNFwiIC8+XG5cdFx0XHRcdDwvYnV0dG9uPlxuXG5cdFx0XHRcdDxkaXYgY2xhc3M9XCJicmFuZGluZ1wiPlxuXHRcdFx0XHRcdDxCcmFuZGluZyBzaG93PVwibmFtZVwiIHNpemU9XCJtZFwiIC8+XG5cdFx0XHRcdDwvZGl2PlxuXG5cdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5LXNtXCIgdG9uZT1cIm11dGVkXCIgY2xhc3M9XCJkaXZpZGVyXCI+fDwvVGV4dD5cblx0XHRcdFx0XG5cdFx0XHRcdDxuYXYgY2xhc3M9XCJuYXZcIj5cblx0XHRcdFx0XHQ8TnV4dExpbmsgOnRvPVwiVVJJLnRvb2wuZmFcIj5cblx0XHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5XCIgbGluaz5cblx0XHRcdFx0XHRcdFx0aW52ZXN0aW5nXG5cdFx0XHRcdFx0XHQ8L1RleHQ+XG5cdFx0XHRcdFx0PC9OdXh0TGluaz5cblx0XHRcdFx0XHQ8TnV4dExpbmsgOnRvPVwiVVJJLnRvb2wuY29uZ3Jlc3NcIj5cblx0XHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5XCIgbGluaz5cblx0XHRcdFx0XHRcdFx0dHJhZGluZ1xuXHRcdFx0XHRcdFx0PC9UZXh0PlxuXHRcdFx0XHRcdDwvTnV4dExpbms+XG5cdFx0XHRcdFx0PCEtLSA8TnV4dExpbmsgOnRvPVwiVVJJLnRvb2wuY29uZ3Jlc3NcIj5cblx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwiYm9keVwiIGxpbms+XG5cdFx0XHRcdFx0XHRDT05HUkVTU1xuXHRcdFx0XHRcdDwvVGV4dD5cblx0XHRcdFx0PC9OdXh0TGluaz4gLS0+XG5cdFx0XHRcdFx0PE51eHRMaW5rIDp0bz1cIlVSSS50b29sLndhdGNobGlzdFwiPlxuXHRcdFx0XHRcdFx0PFRleHQgdmFyaWFudD1cImJvZHlcIiBsaW5rPlxuXHRcdFx0XHRcdFx0XHR3YXRjaGxpc3RzXG5cdFx0XHRcdFx0XHQ8L1RleHQ+XG5cdFx0XHRcdFx0PC9OdXh0TGluaz5cblx0XHRcdFx0XHQ8IS0tIDxOdXh0TGluayA6dG89XCJVUkkudG9vbC5nbG9iYWxfaW5kZXhcIj5cblx0XHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJsYWJlbFwiIGxpbms+XG5cdFx0XHRcdFx0XHRcdEdsb2JhbCBJbmRleFxuXHRcdFx0XHRcdFx0PC9UZXh0PlxuXHRcdFx0XHRcdDwvTnV4dExpbms+IC0tPlxuXHRcdFx0XHQ8L25hdj5cblx0XHRcdDwvZGl2PlxuXG5cblx0XHRcdDxkaXYgY2xhc3M9XCJoZWFkZXItcmlnaHRcIj5cblx0XHRcdFx0PHRlbXBsYXRlIHYtaWY9XCJpc0h5ZHJhdGVkICYmIHVzZXJcIj5cblx0XHRcdFx0XHQ8QnV0dG9uPlxuXHRcdFx0XHRcdFx0PEljb24gaWNvbj1cIm1hdGVyaWFsLXN5bWJvbHM6bm90aWZpY2F0aW9uc1wiIHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxNlwiIC8+XG5cdFx0XHRcdFx0PC9CdXR0b24+XG5cdFx0XHRcdFx0PE51eHRMaW5rIDp0bz1cIlVSSS51c2VyLnNldHRpbmdzXCI+XG5cdFx0XHRcdFx0PEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIGNsYXNzPVwicHJvZmlsZS1pY29uXCI+XG5cdFx0XHRcdFx0XHQ8SWNvbiBpY29uPVwibWRpOmdlYXJcIiB3aWR0aD1cIjE2XCIgaGVpZ2h0PVwiMTZcIiAvPlxuXHRcdFx0XHRcdDwvQnV0dG9uPlxuXHRcdFx0XHRcdDwvTnV4dExpbms+XG5cdFx0XHRcdFx0PEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgQGNsaWNrPVwibG9nb3V0XCI+TG9nb3V0PC9CdXR0b24+XG5cdFx0XHRcdDwvdGVtcGxhdGU+XG5cblx0XHRcdFx0PHRlbXBsYXRlIHYtZWxzZT5cblx0XHRcdFx0XHQ8TnV4dExpbmsgOnRvPVwiVVJJLnVzZXIubG9naW5cIj5cblx0XHRcdFx0XHRcdDxCdXR0b24+U2lnbiBpbjwvQnV0dG9uPlxuXHRcdFx0XHRcdDwvTnV4dExpbms+XG5cdFx0XHRcdFx0PE51eHRMaW5rIDp0bz1cIlVSSS51c2VyLnJlZ2lzdGVyXCI+XG5cdFx0XHRcdFx0XHQ8QnV0dG9uPlNpZ24gdXA8L0J1dHRvbj5cblx0XHRcdFx0XHQ8L051eHRMaW5rPlxuXHRcdFx0XHQ8L3RlbXBsYXRlPlxuXHRcdFx0PC9kaXY+XG5cdFx0PC9kaXY+XG5cblx0XHQ8ZGl2IHYtaWY9XCJtZW51T3BlblwiIGNsYXNzPVwiZHJvcGRvd24tb3ZlcmxheVwiIEBjbGljaz1cImNsb3NlTWVudVwiIC8+XG5cblx0XHQ8ZGl2IHYtaWY9XCJtZW51T3BlblwiIGNsYXNzPVwibW9iaWxlLWRyb3Bkb3duXCI+XG5cdFx0XHQ8bmF2IGNsYXNzPVwibW9iaWxlLW5hdlwiPlxuXHRcdFx0XHQ8TnV4dExpbmsgOnRvPVwiVVJJLnRvb2wuZmFcIiBAY2xpY2s9XCJjbG9zZU1lbnVcIj5cblx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwiYm9keVwiIGxpbms+aW52ZXN0aW5nPC9UZXh0PlxuXHRcdFx0XHQ8L051eHRMaW5rPlxuXHRcdFx0XHQ8TnV4dExpbmsgOnRvPVwiVVJJLnRvb2wuY29uZ3Jlc3NcIiBAY2xpY2s9XCJjbG9zZU1lbnVcIj5cblx0XHRcdFx0XHQ8VGV4dCB2YXJpYW50PVwiYm9keVwiIGxpbms+dHJhZGluZzwvVGV4dD5cblx0XHRcdFx0PC9OdXh0TGluaz5cblx0XHRcdFx0PE51eHRMaW5rIDp0bz1cIlVSSS50b29sLndhdGNobGlzdFwiIEBjbGljaz1cImNsb3NlTWVudVwiPlxuXHRcdFx0XHRcdDxUZXh0IHZhcmlhbnQ9XCJib2R5XCIgbGluaz53YXRjaGxpc3RzPC9UZXh0PlxuXHRcdFx0XHQ8L051eHRMaW5rPlxuXHRcdFx0PC9uYXY+XG5cdFx0PC9kaXY+XG5cdDwvaGVhZGVyPlxuPC90ZW1wbGF0ZT5cblxuPHN0eWxlIHNjb3BlZD5cbi5oZWFkZXIge1xuXHRwb3NpdGlvbjogc3RpY2t5O1xuXHR0b3A6IDA7XG5cdHotaW5kZXg6IDUwO1xuXHRoZWlnaHQ6IDYycHg7XG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1ib3JkZXIpO1xuXHRiYWNrZ3JvdW5kOiByZ2JhKDEyLCAxMiwgMTUsIDAuOTIpO1xuXHRiYWNrZHJvcC1maWx0ZXI6IGJsdXIoMTJweCk7XG59XG5cbi5oZWFkZXItaW5uZXIge1xuXHQvKiBtYXgtd2lkdGg6IHZhcigtLWNvbnRhaW5lci1tYXgpOyAqL1xuXHQvKiBtYXJnaW46IDAgYXV0bzsgKi9cblx0cGFkZGluZzogMCAycmVtO1xuXHRoZWlnaHQ6IDEwMCU7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cblxuLmhlYWRlci1sZWZ0IHtcblx0ZGlzcGxheTogZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0Z2FwOiAxLjVyZW07XG59XG5cbi5tZW51LWJ0biB7XG5cdGRpc3BsYXk6IG5vbmU7XG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cdGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXHRib3JkZXI6IG5vbmU7XG5cdGJhY2tncm91bmQ6IG5vbmU7XG5cdGNvbG9yOiB2YXIoLS1mZyk7XG5cdGN1cnNvcjogcG9pbnRlcjtcblx0cGFkZGluZzogMC40cmVtO1xufVxuXG4uZGl2aWRlciB7XG5cdGRpc3BsYXk6IGJsb2NrO1xufVxuXG4uaGVhZGVyLXJpZ2h0IHtcblx0ZGlzcGxheTogZmxleDtcblx0Z2FwOiAwLjc1cmVtO1xufVxuXG4ubG9nbyB7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cdGdhcDogMC42cmVtO1xuXHRmb250LXNpemU6IDE1cHg7XG5cdGZvbnQtd2VpZ2h0OiA2MDA7XG5cdGxldHRlci1zcGFjaW5nOiAwLjA4ZW07XG59XG5cbi5sb2dvLW1hcmsge1xuXHR3aWR0aDogMzZweDtcblx0aGVpZ2h0OiAzNnB4O1xuXHRkaXNwbGF5OiBibG9jaztcblx0ZmxleC1zaHJpbms6IDA7XG5cdG9iamVjdC1maXQ6IGNvdmVyO1xuXHRtaXgtYmxlbmQtbW9kZTogc2NyZWVuO1xuXG5cdGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuXG5cdC13ZWJraXQtbWFzazogdmFyKC0tbWFzay11cmwpIG5vLXJlcGVhdCBjZW50ZXI7XG5cdG1hc2s6IHZhcigtLW1hc2stdXJsKSBuby1yZXBlYXQgY2VudGVyO1xuXG5cdC13ZWJraXQtbWFzay1zaXplOiBjb250YWluO1xuXHRtYXNrLXNpemU6IGNvbnRhaW47XG59XG5cbi5sb2dvLXRleHQge1xuXHRjb2xvcjogdmFyKC0tZmcpO1xufVxuXG4ubmF2IHtcblx0ZGlzcGxheTogZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0Z2FwOiAzcmVtO1xuXHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuXG4ucHJvZmlsZS1tZW51IHtcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRkaXNwbGF5OiBmbGV4O1xufVxuXG4ucHJvZmlsZS1pY29uIHtcblx0Zm9udC1zaXplOiAyM3B4O1xuXHRjb2xvcjogdmFyKC0tYmcpO1xuXHQvKiBoZWlnaHQ6IDM2cHg7ICovXG59XG5cbi5kcm9wZG93bi1vdmVybGF5IHtcblx0cG9zaXRpb246IGZpeGVkO1xuXHRpbnNldDogNjJweCAwIDAgMDtcblx0ei1pbmRleDogNDg7XG59XG5cbi5tb2JpbGUtZHJvcGRvd24ge1xuXHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdHRvcDogNjJweDtcblx0bGVmdDogMDtcblx0cmlnaHQ6IDA7XG5cdHotaW5kZXg6IDQ5O1xuXHRwYWRkaW5nOiAwLjVyZW0gMnJlbSAxcmVtO1xuXHRiYWNrZ3JvdW5kOiByZ2JhKDEyLCAxMiwgMTUsIDAuOTIpO1xuXHRiYWNrZHJvcC1maWx0ZXI6IGJsdXIoMTJweCk7XG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1ib3JkZXIpO1xufVxuXG4ubW9iaWxlLW5hdiB7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG5cbi5tb2JpbGUtbmF2IGEge1xuXHRwYWRkaW5nOiAwLjhyZW0gMDtcblx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWJvcmRlcik7XG59XG5cbi5tb2JpbGUtbmF2IGE6bGFzdC1jaGlsZCB7XG5cdGJvcmRlci1ib3R0b206IG5vbmU7XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiA3NTBweCkge1xuXHQuYnJhbmRpbmcsXG5cdC5kaXZpZGVyLFxuXHQubmF2IHtcblx0XHRkaXNwbGF5OiBub25lO1xuXHR9XG5cblx0Lm1lbnUtYnRuIHtcblx0XHRkaXNwbGF5OiBmbGV4O1xuXHR9XG59XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvbW50L2tpcmUvUGVyc29uYWwvUHJvZ3JhbW1pbmcvUHJvamVjdHMvTUVJQy93ZWIvYXBwL3VpL0hlYWRlci52dWUifQ==