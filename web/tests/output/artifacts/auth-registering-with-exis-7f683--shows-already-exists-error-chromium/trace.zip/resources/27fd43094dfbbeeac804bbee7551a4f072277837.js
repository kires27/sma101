// js/phoenix/utils.js
var closure = (value) => {
  if (typeof value === "function") {
    return (
      /** @type {() => T} */
      value
    );
  } else {
    let closure2 = function() {
      return value;
    };
    return closure2;
  }
};

// js/phoenix/constants.js
var globalSelf = typeof self !== "undefined" ? self : null;
var phxWindow = typeof window !== "undefined" ? window : null;
var global = globalSelf || phxWindow || globalThis;
var DEFAULT_VSN = "2.0.0";
var DEFAULT_TIMEOUT = 1e4;
var WS_CLOSE_NORMAL = 1e3;
var SOCKET_STATES = (
  /** @type {const} */
  { connecting: 0, open: 1, closing: 2, closed: 3 }
);
var CHANNEL_STATES = (
  /** @type {const} */
  {
    closed: "closed",
    errored: "errored",
    joined: "joined",
    joining: "joining",
    leaving: "leaving"
  }
);
var CHANNEL_EVENTS = (
  /** @type {const} */
  {
    close: "phx_close",
    error: "phx_error",
    join: "phx_join",
    reply: "phx_reply",
    leave: "phx_leave"
  }
);
var TRANSPORTS = (
  /** @type {const} */
  {
    longpoll: "longpoll",
    websocket: "websocket"
  }
);
var XHR_STATES = (
  /** @type {const} */
  {
    complete: 4
  }
);
var AUTH_TOKEN_PREFIX = "base64url.bearer.phx.";

// js/phoenix/push.js
var Push = class {
  /**
   * Initializes the Push
   * @param {Channel} channel - The Channel
   * @param {ChannelEvent} event - The event, for example `"phx_join"`
   * @param {() => Record<string, unknown>} payload - The payload, for example `{user_id: 123}`
   * @param {number} timeout - The push timeout in milliseconds
   */
  constructor(channel, event, payload, timeout) {
    this.channel = channel;
    this.event = event;
    this.payload = payload || function() {
      return {};
    };
    this.receivedResp = null;
    this.timeout = timeout;
    this.timeoutTimer = null;
    this.recHooks = [];
    this.sent = false;
    this.ref = void 0;
  }
  /**
   *
   * @param {number} timeout
   */
  resend(timeout) {
    this.timeout = timeout;
    this.reset();
    this.send();
  }
  /**
   *
   */
  send() {
    if (this.hasReceived("timeout")) {
      return;
    }
    this.startTimeout();
    this.sent = true;
    this.channel.socket.push({
      topic: this.channel.topic,
      event: this.event,
      payload: this.payload(),
      ref: this.ref,
      join_ref: this.channel.joinRef()
    });
  }
  /**
   *
   * @param {string} status
   * @param {(response: any) => void} callback
   */
  receive(status, callback) {
    if (this.hasReceived(status)) {
      callback(this.receivedResp.response);
    }
    this.recHooks.push({ status, callback });
    return this;
  }
  reset() {
    this.cancelRefEvent();
    this.ref = null;
    this.refEvent = null;
    this.receivedResp = null;
    this.sent = false;
  }
  destroy() {
    this.cancelRefEvent();
    this.cancelTimeout();
  }
  /**
   * @private
   */
  matchReceive({ status, response, _ref }) {
    this.recHooks.filter((h) => h.status === status).forEach((h) => h.callback(response));
  }
  /**
   * @private
   */
  cancelRefEvent() {
    if (!this.refEvent) {
      return;
    }
    this.channel.off(this.refEvent);
  }
  cancelTimeout() {
    clearTimeout(this.timeoutTimer);
    this.timeoutTimer = null;
  }
  startTimeout() {
    if (this.timeoutTimer) {
      this.cancelTimeout();
    }
    this.ref = this.channel.socket.makeRef();
    this.refEvent = this.channel.replyEventName(this.ref);
    this.channel.on(this.refEvent, (payload) => {
      this.cancelRefEvent();
      this.cancelTimeout();
      this.receivedResp = payload;
      this.matchReceive(payload);
    });
    this.timeoutTimer = setTimeout(() => {
      this.trigger("timeout", {});
    }, this.timeout);
  }
  /**
   * @private
   */
  hasReceived(status) {
    return this.receivedResp && this.receivedResp.status === status;
  }
  trigger(status, response) {
    this.channel.trigger(this.refEvent, { status, response });
  }
};

// js/phoenix/timer.js
var Timer = class {
  /**
  * @param {() => void} callback
  * @param {(tries: number) => number} timerCalc
  */
  constructor(callback, timerCalc) {
    this.callback = callback;
    this.timerCalc = timerCalc;
    this.timer = void 0;
    this.tries = 0;
  }
  reset() {
    this.tries = 0;
    clearTimeout(this.timer);
  }
  /**
   * Cancels any previous scheduleTimeout and schedules callback
   */
  scheduleTimeout() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.tries = this.tries + 1;
      this.callback();
    }, this.timerCalc(this.tries + 1));
  }
};

// js/phoenix/channel.js
var Channel = class {
  /**
   * @param {string} topic
   * @param {Params | (() => Params)} params
   * @param {Socket} socket
   */
  constructor(topic, params, socket) {
    this.state = CHANNEL_STATES.closed;
    this.topic = topic;
    this.params = closure(params || {});
    this.socket = socket;
    this.bindings = [];
    this.bindingRef = 0;
    this.timeout = this.socket.timeout;
    this.joinedOnce = false;
    this.joinPush = new Push(this, CHANNEL_EVENTS.join, this.params, this.timeout);
    this.pushBuffer = [];
    this.stateChangeRefs = [];
    this.rejoinTimer = new Timer(() => {
      if (this.socket.isConnected()) {
        this.rejoin();
      }
    }, this.socket.rejoinAfterMs);
    this.stateChangeRefs.push(this.socket.onError(() => this.rejoinTimer.reset()));
    this.stateChangeRefs.push(
      this.socket.onOpen(() => {
        this.rejoinTimer.reset();
        if (this.isErrored()) {
          this.rejoin();
        }
      })
    );
    this.joinPush.receive("ok", () => {
      this.state = CHANNEL_STATES.joined;
      this.rejoinTimer.reset();
      this.pushBuffer.forEach((pushEvent) => pushEvent.send());
      this.pushBuffer = [];
    });
    this.joinPush.receive("error", (reason) => {
      this.state = CHANNEL_STATES.errored;
      if (this.socket.hasLogger()) this.socket.log("channel", `error ${this.topic}`, reason);
      if (this.socket.isConnected()) {
        this.rejoinTimer.scheduleTimeout();
      }
    });
    this.onClose(() => {
      this.rejoinTimer.reset();
      if (this.socket.hasLogger()) this.socket.log("channel", `close ${this.topic}`);
      this.state = CHANNEL_STATES.closed;
      this.socket.remove(this);
    });
    this.onError((reason) => {
      if (this.socket.hasLogger()) this.socket.log("channel", `error ${this.topic}`, reason);
      if (this.isJoining()) {
        this.joinPush.reset();
      }
      this.state = CHANNEL_STATES.errored;
      if (this.socket.isConnected()) {
        this.rejoinTimer.scheduleTimeout();
      }
    });
    this.joinPush.receive("timeout", () => {
      if (this.socket.hasLogger()) this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout);
      let leavePush = new Push(this, CHANNEL_EVENTS.leave, closure({}), this.timeout);
      leavePush.send();
      this.state = CHANNEL_STATES.errored;
      this.joinPush.reset();
      if (this.socket.isConnected()) {
        this.rejoinTimer.scheduleTimeout();
      }
    });
    this.on(CHANNEL_EVENTS.reply, (payload, ref) => {
      this.trigger(this.replyEventName(ref), payload);
    });
  }
  /**
   * Join the channel
   * @param {number} timeout
   * @returns {Push}
   */
  join(timeout = this.timeout) {
    if (this.joinedOnce) {
      throw new Error("tried to join multiple times. 'join' can only be called a single time per channel instance");
    } else {
      this.timeout = timeout;
      this.joinedOnce = true;
      this.rejoin();
      return this.joinPush;
    }
  }
  /**
   * Teardown the channel.
   *
   * Destroys and stops related timers.
   */
  teardown() {
    this.pushBuffer.forEach((push) => push.destroy());
    this.pushBuffer = [];
    this.rejoinTimer.reset();
    this.joinPush.destroy();
    this.state = CHANNEL_STATES.closed;
    this.bindings = [];
  }
  /**
   * Hook into channel close
   * @param {ChannelBindingCallback} callback
   */
  onClose(callback) {
    this.on(CHANNEL_EVENTS.close, callback);
  }
  /**
   * Hook into channel errors
   * @param {ChannelOnErrorCallback} callback
   * @return {number}
   */
  onError(callback) {
    return this.on(CHANNEL_EVENTS.error, (reason) => callback(reason));
  }
  /**
   * Subscribes on channel events
   *
   * Subscription returns a ref counter, which can be used later to
   * unsubscribe the exact event listener
   *
   * @example
   * const ref1 = channel.on("event", do_stuff)
   * const ref2 = channel.on("event", do_other_stuff)
   * channel.off("event", ref1)
   * // Since unsubscription, do_stuff won't fire,
   * // while do_other_stuff will keep firing on the "event"
   *
   * @param {string} event
   * @param {ChannelBindingCallback} callback
   * @returns {number} ref
   */
  on(event, callback) {
    let ref = this.bindingRef++;
    this.bindings.push({ event, ref, callback });
    return ref;
  }
  /**
   * Unsubscribes off of channel events
   *
   * Use the ref returned from a channel.on() to unsubscribe one
   * handler, or pass nothing for the ref to unsubscribe all
   * handlers for the given event.
   *
   * @example
   * // Unsubscribe the do_stuff handler
   * const ref1 = channel.on("event", do_stuff)
   * channel.off("event", ref1)
   *
   * // Unsubscribe all handlers from event
   * channel.off("event")
   *
   * @param {string} event
   * @param {number} [ref]
   */
  off(event, ref) {
    this.bindings = this.bindings.filter((bind) => {
      return !(bind.event === event && (typeof ref === "undefined" || ref === bind.ref));
    });
  }
  /**
   * @private
   */
  canPush() {
    return this.socket.isConnected() && this.isJoined();
  }
  /**
   * Sends a message `event` to phoenix with the payload `payload`.
   * Phoenix receives this in the `handle_in(event, payload, socket)`
   * function. if phoenix replies or it times out (default 10000ms),
   * then optionally the reply can be received.
   *
   * @example
   * channel.push("event")
   *   .receive("ok", payload => console.log("phoenix replied:", payload))
   *   .receive("error", err => console.log("phoenix errored", err))
   *   .receive("timeout", () => console.log("timed out pushing"))
   * @param {string} event
   * @param {Object} payload
   * @param {number} [timeout]
   * @returns {Push}
   */
  push(event, payload, timeout = this.timeout) {
    payload = payload || {};
    if (!this.joinedOnce) {
      throw new Error(`tried to push '${event}' to '${this.topic}' before joining. Use channel.join() before pushing events`);
    }
    let pushEvent = new Push(this, event, function() {
      return payload;
    }, timeout);
    if (this.canPush()) {
      pushEvent.send();
    } else {
      pushEvent.startTimeout();
      this.pushBuffer.push(pushEvent);
    }
    return pushEvent;
  }
  /** Leaves the channel
   *
   * Unsubscribes from server events, and
   * instructs channel to terminate on server
   *
   * Triggers onClose() hooks
   *
   * To receive leave acknowledgements, use the `receive`
   * hook to bind to the server ack, ie:
   *
   * @example
   * channel.leave().receive("ok", () => alert("left!") )
   *
   * @param {number} timeout
   * @returns {Push}
   */
  leave(timeout = this.timeout) {
    this.rejoinTimer.reset();
    this.joinPush.cancelTimeout();
    this.state = CHANNEL_STATES.leaving;
    let onClose = () => {
      if (this.socket.hasLogger()) this.socket.log("channel", `leave ${this.topic}`);
      this.trigger(CHANNEL_EVENTS.close, "leave");
    };
    let leavePush = new Push(this, CHANNEL_EVENTS.leave, closure({}), timeout);
    leavePush.receive("ok", () => onClose()).receive("timeout", () => onClose());
    leavePush.send();
    if (!this.canPush()) {
      leavePush.trigger("ok", {});
    }
    return leavePush;
  }
  /**
   * Overridable message hook
   *
   * Receives all events for specialized message handling
   * before dispatching to the channel callbacks.
   *
   * Must return the payload, modified or unmodified
   * @type{ChannelOnMessage}
   */
  onMessage(_event, payload, _ref) {
    return payload;
  }
  /**
   * Overridable filter hook
   *
   * If this function returns `true`, `binding`'s callback will be called.
   *
   * @type{ChannelFilterBindings}
   */
  filterBindings(_binding, _payload, _ref) {
    return true;
  }
  isMember(topic, event, payload, joinRef) {
    if (this.topic !== topic) {
      return false;
    }
    if (joinRef && joinRef !== this.joinRef()) {
      if (this.socket.hasLogger()) this.socket.log("channel", "dropping outdated message", { topic, event, payload, joinRef });
      return false;
    } else {
      return true;
    }
  }
  joinRef() {
    return this.joinPush.ref;
  }
  /**
   * @private
   */
  rejoin(timeout = this.timeout) {
    if (this.isLeaving()) {
      return;
    }
    this.socket.leaveOpenTopic(this.topic);
    this.state = CHANNEL_STATES.joining;
    this.joinPush.resend(timeout);
  }
  /**
   * @param {string} event
   * @param {unknown} [payload]
   * @param {?string} [ref]
   * @param {?string} [joinRef]
   */
  trigger(event, payload, ref, joinRef) {
    let handledPayload = this.onMessage(event, payload, ref, joinRef);
    if (payload && !handledPayload) {
      throw new Error("channel onMessage callbacks must return the payload, modified or unmodified");
    }
    let eventBindings = this.bindings.filter((bind) => bind.event === event && this.filterBindings(bind, payload, ref));
    for (let i = 0; i < eventBindings.length; i++) {
      let bind = eventBindings[i];
      bind.callback(handledPayload, ref, joinRef || this.joinRef());
    }
  }
  /**
  * @param {string} ref
  */
  replyEventName(ref) {
    return `chan_reply_${ref}`;
  }
  isClosed() {
    return this.state === CHANNEL_STATES.closed;
  }
  isErrored() {
    return this.state === CHANNEL_STATES.errored;
  }
  isJoined() {
    return this.state === CHANNEL_STATES.joined;
  }
  isJoining() {
    return this.state === CHANNEL_STATES.joining;
  }
  isLeaving() {
    return this.state === CHANNEL_STATES.leaving;
  }
};

// js/phoenix/ajax.js
var Ajax = class {
  static request(method, endPoint, headers, body, timeout, ontimeout, callback) {
    if (global.XDomainRequest) {
      let req = new global.XDomainRequest();
      return this.xdomainRequest(req, method, endPoint, body, timeout, ontimeout, callback);
    } else if (global.XMLHttpRequest) {
      let req = new global.XMLHttpRequest();
      return this.xhrRequest(req, method, endPoint, headers, body, timeout, ontimeout, callback);
    } else if (global.fetch && global.AbortController) {
      return this.fetchRequest(method, endPoint, headers, body, timeout, ontimeout, callback);
    } else {
      throw new Error("No suitable XMLHttpRequest implementation found");
    }
  }
  static fetchRequest(method, endPoint, headers, body, timeout, ontimeout, callback) {
    let options = {
      method,
      headers,
      body
    };
    let controller = null;
    if (timeout) {
      controller = new AbortController();
      const _timeoutId = setTimeout(() => controller.abort(), timeout);
      options.signal = controller.signal;
    }
    global.fetch(endPoint, options).then((response) => response.text()).then((data) => this.parseJSON(data)).then((data) => callback && callback(data)).catch((err) => {
      if (err.name === "AbortError" && ontimeout) {
        ontimeout();
      } else {
        callback && callback(null);
      }
    });
    return controller;
  }
  static xdomainRequest(req, method, endPoint, body, timeout, ontimeout, callback) {
    req.timeout = timeout;
    req.open(method, endPoint);
    req.onload = () => {
      let response = this.parseJSON(req.responseText);
      callback && callback(response);
    };
    if (ontimeout) {
      req.ontimeout = ontimeout;
    }
    req.onprogress = () => {
    };
    req.send(body);
    return req;
  }
  static xhrRequest(req, method, endPoint, headers, body, timeout, ontimeout, callback) {
    req.open(method, endPoint, true);
    req.timeout = timeout;
    for (let [key, value] of Object.entries(headers)) {
      req.setRequestHeader(key, value);
    }
    req.onerror = () => callback && callback(null);
    req.onreadystatechange = () => {
      if (req.readyState === XHR_STATES.complete && callback) {
        let response = this.parseJSON(req.responseText);
        callback(response);
      }
    };
    if (ontimeout) {
      req.ontimeout = ontimeout;
    }
    req.send(body);
    return req;
  }
  static parseJSON(resp) {
    if (!resp || resp === "") {
      return null;
    }
    try {
      return JSON.parse(resp);
    } catch {
      console && console.log("failed to parse JSON response", resp);
      return null;
    }
  }
  static serialize(obj, parentKey) {
    let queryStr = [];
    for (var key in obj) {
      if (!Object.prototype.hasOwnProperty.call(obj, key)) {
        continue;
      }
      let paramKey = parentKey ? `${parentKey}[${key}]` : key;
      let paramVal = obj[key];
      if (typeof paramVal === "object") {
        queryStr.push(this.serialize(paramVal, paramKey));
      } else {
        queryStr.push(encodeURIComponent(paramKey) + "=" + encodeURIComponent(paramVal));
      }
    }
    return queryStr.join("&");
  }
  static appendParams(url, params) {
    if (Object.keys(params).length === 0) {
      return url;
    }
    let prefix = url.match(/\?/) ? "&" : "?";
    return `${url}${prefix}${this.serialize(params)}`;
  }
};

// js/phoenix/longpoll.js
var arrayBufferToBase64 = (buffer) => {
  let binary = "";
  let bytes = new Uint8Array(buffer);
  let len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};
var LongPoll = class {
  constructor(endPoint, protocols) {
    if (protocols && protocols.length === 2 && protocols[1].startsWith(AUTH_TOKEN_PREFIX)) {
      this.authToken = atob(protocols[1].slice(AUTH_TOKEN_PREFIX.length));
    }
    this.endPoint = null;
    this.token = null;
    this.skipHeartbeat = true;
    this.reqs = /* @__PURE__ */ new Set();
    this.awaitingBatchAck = false;
    this.currentBatch = null;
    this.currentBatchTimer = null;
    this.batchBuffer = [];
    this.onopen = function() {
    };
    this.onerror = function() {
    };
    this.onmessage = function() {
    };
    this.onclose = function() {
    };
    this.pollEndpoint = this.normalizeEndpoint(endPoint);
    this.readyState = SOCKET_STATES.connecting;
    setTimeout(() => this.poll(), 0);
  }
  normalizeEndpoint(endPoint) {
    return endPoint.replace("ws://", "http://").replace("wss://", "https://").replace(new RegExp("(.*)/" + TRANSPORTS.websocket), "$1/" + TRANSPORTS.longpoll);
  }
  endpointURL() {
    return Ajax.appendParams(this.pollEndpoint, { token: this.token });
  }
  closeAndRetry(code, reason, wasClean) {
    this.close(code, reason, wasClean);
    this.readyState = SOCKET_STATES.connecting;
  }
  ontimeout() {
    this.onerror("timeout");
    this.closeAndRetry(1005, "timeout", false);
  }
  isActive() {
    return this.readyState === SOCKET_STATES.open || this.readyState === SOCKET_STATES.connecting;
  }
  poll() {
    const headers = { "Accept": "application/json" };
    if (this.authToken) {
      headers["X-Phoenix-AuthToken"] = this.authToken;
    }
    this.ajax("GET", headers, null, () => this.ontimeout(), (resp) => {
      if (resp) {
        var { status, token, messages } = resp;
        if (status === 410 && this.token !== null) {
          this.onerror(410);
          this.closeAndRetry(3410, "session_gone", false);
          return;
        }
        this.token = token;
      } else {
        status = 0;
      }
      switch (status) {
        case 200:
          messages.forEach((msg) => {
            setTimeout(() => this.onmessage({ data: msg }), 0);
          });
          this.poll();
          break;
        case 204:
          this.poll();
          break;
        case 410:
          this.readyState = SOCKET_STATES.open;
          this.onopen({});
          this.poll();
          break;
        case 403:
          this.onerror(403);
          this.close(1008, "forbidden", false);
          break;
        case 0:
        case 500:
          this.onerror(500);
          this.closeAndRetry(1011, "internal server error", 500);
          break;
        default:
          throw new Error(`unhandled poll status ${status}`);
      }
    });
  }
  // we collect all pushes within the current event loop by
  // setTimeout 0, which optimizes back-to-back procedural
  // pushes against an empty buffer
  send(body) {
    if (typeof body !== "string") {
      body = arrayBufferToBase64(body);
    }
    if (this.currentBatch) {
      this.currentBatch.push(body);
    } else if (this.awaitingBatchAck) {
      this.batchBuffer.push(body);
    } else {
      this.currentBatch = [body];
      this.currentBatchTimer = setTimeout(() => {
        this.batchSend(this.currentBatch);
        this.currentBatch = null;
      }, 0);
    }
  }
  batchSend(messages) {
    this.awaitingBatchAck = true;
    this.ajax("POST", { "Content-Type": "application/x-ndjson" }, messages.join("\n"), () => this.onerror("timeout"), (resp) => {
      this.awaitingBatchAck = false;
      if (!resp || resp.status !== 200) {
        this.onerror(resp && resp.status);
        this.closeAndRetry(1011, "internal server error", false);
      } else if (this.batchBuffer.length > 0) {
        this.batchSend(this.batchBuffer);
        this.batchBuffer = [];
      }
    });
  }
  close(code, reason, wasClean) {
    for (let req of this.reqs) {
      req.abort();
    }
    this.readyState = SOCKET_STATES.closed;
    let opts = Object.assign({ code: 1e3, reason: void 0, wasClean: true }, { code, reason, wasClean });
    this.batchBuffer = [];
    clearTimeout(this.currentBatchTimer);
    this.currentBatchTimer = null;
    if (typeof CloseEvent !== "undefined") {
      this.onclose(new CloseEvent("close", opts));
    } else {
      this.onclose(opts);
    }
  }
  ajax(method, headers, body, onCallerTimeout, callback) {
    let req;
    let ontimeout = () => {
      this.reqs.delete(req);
      onCallerTimeout();
    };
    req = Ajax.request(method, this.endpointURL(), headers, body, this.timeout, ontimeout, (resp) => {
      this.reqs.delete(req);
      if (this.isActive()) {
        callback(resp);
      }
    });
    this.reqs.add(req);
  }
};

// js/phoenix/presence.js
var Presence = class _Presence {
  /**
   * Initializes the Presence
   * @param {Channel} channel - The Channel
   * @param {PresenceOptions} [opts] - The options, for example `{events: {state: "state", diff: "diff"}}`
   */
  constructor(channel, opts = {}) {
    let events = opts.events || /** @type {PresenceEvents} */
    { state: "presence_state", diff: "presence_diff" };
    this.state = {};
    this.pendingDiffs = [];
    this.channel = channel;
    this.joinRef = null;
    this.caller = {
      onJoin: function() {
      },
      onLeave: function() {
      },
      onSync: function() {
      }
    };
    this.channel.on(events.state, (newState) => {
      let { onJoin, onLeave, onSync } = this.caller;
      this.joinRef = this.channel.joinRef();
      this.state = _Presence.syncState(this.state, newState, onJoin, onLeave);
      this.pendingDiffs.forEach((diff) => {
        this.state = _Presence.syncDiff(this.state, diff, onJoin, onLeave);
      });
      this.pendingDiffs = [];
      onSync();
    });
    this.channel.on(events.diff, (diff) => {
      let { onJoin, onLeave, onSync } = this.caller;
      if (this.inPendingSyncState()) {
        this.pendingDiffs.push(diff);
      } else {
        this.state = _Presence.syncDiff(this.state, diff, onJoin, onLeave);
        onSync();
      }
    });
  }
  /**
   * @param {PresenceOnJoin} callback
   */
  onJoin(callback) {
    this.caller.onJoin = callback;
  }
  /**
   * @param {PresenceOnLeave} callback
   */
  onLeave(callback) {
    this.caller.onLeave = callback;
  }
  /**
   * @param {PresenceOnSync} callback
   */
  onSync(callback) {
    this.caller.onSync = callback;
  }
  /**
   * Returns the array of presences, with selected metadata.
   *
   * @template [T=PresenceState]
   * @param {((key: string, obj: PresenceState) => T)} [by]
   *
   * @returns {T[]}
   */
  list(by) {
    return _Presence.list(this.state, by);
  }
  inPendingSyncState() {
    return !this.joinRef || this.joinRef !== this.channel.joinRef();
  }
  // lower-level public static API
  /**
   * Used to sync the list of presences on the server
   * with the client's state. An optional `onJoin` and `onLeave` callback can
   * be provided to react to changes in the client's local presences across
   * disconnects and reconnects with the server.
   *
   * @param {Record<string, PresenceState>} currentState
   * @param {Record<string, PresenceState>} newState
   * @param {PresenceOnJoin} onJoin
   * @param {PresenceOnLeave} onLeave
   *
   * @returns {Record<string, PresenceState>}
   */
  static syncState(currentState, newState, onJoin, onLeave) {
    let state = this.clone(currentState);
    let joins = {};
    let leaves = {};
    this.map(state, (key, presence) => {
      if (!newState[key]) {
        leaves[key] = presence;
      }
    });
    this.map(newState, (key, newPresence) => {
      let currentPresence = state[key];
      if (currentPresence) {
        let newRefs = newPresence.metas.map((m) => m.phx_ref);
        let curRefs = currentPresence.metas.map((m) => m.phx_ref);
        let joinedMetas = newPresence.metas.filter((m) => curRefs.indexOf(m.phx_ref) < 0);
        let leftMetas = currentPresence.metas.filter((m) => newRefs.indexOf(m.phx_ref) < 0);
        if (joinedMetas.length > 0) {
          joins[key] = newPresence;
          joins[key].metas = joinedMetas;
        }
        if (leftMetas.length > 0) {
          leaves[key] = this.clone(currentPresence);
          leaves[key].metas = leftMetas;
        }
      } else {
        joins[key] = newPresence;
      }
    });
    return this.syncDiff(state, { joins, leaves }, onJoin, onLeave);
  }
  /**
   *
   * Used to sync a diff of presence join and leave
   * events from the server, as they happen. Like `syncState`, `syncDiff`
   * accepts optional `onJoin` and `onLeave` callbacks to react to a user
   * joining or leaving from a device.
   *
   * @param {Record<string, PresenceState>} state
   * @param {PresenceDiff} diff
   * @param {PresenceOnJoin} onJoin
   * @param {PresenceOnLeave} onLeave
   *
   * @returns {Record<string, PresenceState>}
   */
  static syncDiff(state, diff, onJoin, onLeave) {
    let { joins, leaves } = this.clone(diff);
    if (!onJoin) {
      onJoin = function() {
      };
    }
    if (!onLeave) {
      onLeave = function() {
      };
    }
    this.map(joins, (key, newPresence) => {
      let currentPresence = state[key];
      state[key] = this.clone(newPresence);
      if (currentPresence) {
        let joinedRefs = state[key].metas.map((m) => m.phx_ref);
        let curMetas = currentPresence.metas.filter((m) => joinedRefs.indexOf(m.phx_ref) < 0);
        state[key].metas.unshift(...curMetas);
      }
      onJoin(key, currentPresence, newPresence);
    });
    this.map(leaves, (key, leftPresence) => {
      let currentPresence = state[key];
      if (!currentPresence) {
        return;
      }
      let refsToRemove = leftPresence.metas.map((m) => m.phx_ref);
      currentPresence.metas = currentPresence.metas.filter((p) => {
        return refsToRemove.indexOf(p.phx_ref) < 0;
      });
      onLeave(key, currentPresence, leftPresence);
      if (currentPresence.metas.length === 0) {
        delete state[key];
      }
    });
    return state;
  }
  /**
   * Returns the array of presences, with selected metadata.
   *
   * @template [T=PresenceState]
   * @param {Record<string, PresenceState>} presences
   * @param {((key: string, obj: PresenceState) => T)} [chooser]
   *
   * @returns {T[]}
   */
  static list(presences, chooser) {
    if (!chooser) {
      chooser = function(key, pres) {
        return pres;
      };
    }
    return this.map(presences, (key, presence) => {
      return chooser(key, presence);
    });
  }
  // private
  /**
  * @template T
  * @param {Record<string, PresenceState>} obj
  * @param {(key: string, obj: PresenceState) => T} func
  */
  static map(obj, func) {
    return Object.getOwnPropertyNames(obj).map((key) => func(key, obj[key]));
  }
  /**
  * @template T
  * @param {T} obj
  * @returns {T}
  */
  static clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }
};

// js/phoenix/serializer.js
var serializer_default = {
  HEADER_LENGTH: 1,
  META_LENGTH: 4,
  KINDS: { push: 0, reply: 1, broadcast: 2 },
  /**
  * @template T
  * @param {Message<Record<string, any>>} msg
  * @param {(msg: ArrayBuffer | string) => T} callback
  * @returns {T}
  */
  encode(msg, callback) {
    if (msg.payload.constructor === ArrayBuffer) {
      return callback(this.binaryEncode(msg));
    } else {
      let payload = [msg.join_ref, msg.ref, msg.topic, msg.event, msg.payload];
      return callback(JSON.stringify(payload));
    }
  },
  /**
  * @template T
  * @param {ArrayBuffer | string} rawPayload
  * @param {(msg: Message<unknown>) => T} callback
  * @returns {T}
  */
  decode(rawPayload, callback) {
    if (rawPayload.constructor === ArrayBuffer) {
      return callback(this.binaryDecode(rawPayload));
    } else {
      let [join_ref, ref, topic, event, payload] = JSON.parse(rawPayload);
      return callback({ join_ref, ref, topic, event, payload });
    }
  },
  /** @private */
  binaryEncode(message) {
    let { join_ref, ref, event, topic, payload } = message;
    let metaLength = this.META_LENGTH + join_ref.length + ref.length + topic.length + event.length;
    let header = new ArrayBuffer(this.HEADER_LENGTH + metaLength);
    let view = new DataView(header);
    let offset = 0;
    view.setUint8(offset++, this.KINDS.push);
    view.setUint8(offset++, join_ref.length);
    view.setUint8(offset++, ref.length);
    view.setUint8(offset++, topic.length);
    view.setUint8(offset++, event.length);
    Array.from(join_ref, (char) => view.setUint8(offset++, char.charCodeAt(0)));
    Array.from(ref, (char) => view.setUint8(offset++, char.charCodeAt(0)));
    Array.from(topic, (char) => view.setUint8(offset++, char.charCodeAt(0)));
    Array.from(event, (char) => view.setUint8(offset++, char.charCodeAt(0)));
    var combined = new Uint8Array(header.byteLength + payload.byteLength);
    combined.set(new Uint8Array(header), 0);
    combined.set(new Uint8Array(payload), header.byteLength);
    return combined.buffer;
  },
  /**
  * @private
  */
  binaryDecode(buffer) {
    let view = new DataView(buffer);
    let kind = view.getUint8(0);
    let decoder = new TextDecoder();
    switch (kind) {
      case this.KINDS.push:
        return this.decodePush(buffer, view, decoder);
      case this.KINDS.reply:
        return this.decodeReply(buffer, view, decoder);
      case this.KINDS.broadcast:
        return this.decodeBroadcast(buffer, view, decoder);
    }
  },
  /** @private */
  decodePush(buffer, view, decoder) {
    let joinRefSize = view.getUint8(1);
    let topicSize = view.getUint8(2);
    let eventSize = view.getUint8(3);
    let offset = this.HEADER_LENGTH + this.META_LENGTH - 1;
    let joinRef = decoder.decode(buffer.slice(offset, offset + joinRefSize));
    offset = offset + joinRefSize;
    let topic = decoder.decode(buffer.slice(offset, offset + topicSize));
    offset = offset + topicSize;
    let event = decoder.decode(buffer.slice(offset, offset + eventSize));
    offset = offset + eventSize;
    let data = buffer.slice(offset, buffer.byteLength);
    return { join_ref: joinRef, ref: null, topic, event, payload: data };
  },
  /** @private */
  decodeReply(buffer, view, decoder) {
    let joinRefSize = view.getUint8(1);
    let refSize = view.getUint8(2);
    let topicSize = view.getUint8(3);
    let eventSize = view.getUint8(4);
    let offset = this.HEADER_LENGTH + this.META_LENGTH;
    let joinRef = decoder.decode(buffer.slice(offset, offset + joinRefSize));
    offset = offset + joinRefSize;
    let ref = decoder.decode(buffer.slice(offset, offset + refSize));
    offset = offset + refSize;
    let topic = decoder.decode(buffer.slice(offset, offset + topicSize));
    offset = offset + topicSize;
    let event = decoder.decode(buffer.slice(offset, offset + eventSize));
    offset = offset + eventSize;
    let data = buffer.slice(offset, buffer.byteLength);
    let payload = { status: event, response: data };
    return { join_ref: joinRef, ref, topic, event: CHANNEL_EVENTS.reply, payload };
  },
  /** @private */
  decodeBroadcast(buffer, view, decoder) {
    let topicSize = view.getUint8(1);
    let eventSize = view.getUint8(2);
    let offset = this.HEADER_LENGTH + 2;
    let topic = decoder.decode(buffer.slice(offset, offset + topicSize));
    offset = offset + topicSize;
    let event = decoder.decode(buffer.slice(offset, offset + eventSize));
    offset = offset + eventSize;
    let data = buffer.slice(offset, buffer.byteLength);
    return { join_ref: null, ref: null, topic, event, payload: data };
  }
};

// js/phoenix/socket.js
var Socket = class {
  /** Initializes the Socket *
   *
   * For IE8 support use an ES5-shim (https://github.com/es-shims/es5-shim)
   *
   * @constructor
   * @param {string} endPoint - The string WebSocket endpoint, ie, `"ws://example.com/socket"`,
   *                                               `"wss://example.com"`
   *                                               `"/socket"` (inherited host & protocol)
   * @param {SocketOptions} [opts] - Optional configuration
   */
  constructor(endPoint, opts = {}) {
    this.stateChangeCallbacks = { open: [], close: [], error: [], message: [] };
    this.channels = [];
    this.sendBuffer = [];
    this.ref = 0;
    this.fallbackRef = null;
    this.timeout = opts.timeout || DEFAULT_TIMEOUT;
    this.transport = opts.transport || global.WebSocket || LongPoll;
    this.conn = void 0;
    this.primaryPassedHealthCheck = false;
    this.longPollFallbackMs = opts.longPollFallbackMs;
    this.fallbackTimer = null;
    let envSessionStorage = null;
    try {
      envSessionStorage = global && global.sessionStorage;
    } catch {
    }
    this.sessionStore = opts.sessionStorage || envSessionStorage;
    this.establishedConnections = 0;
    this.defaultEncoder = serializer_default.encode.bind(serializer_default);
    this.defaultDecoder = serializer_default.decode.bind(serializer_default);
    this.closeWasClean = true;
    this.disconnecting = false;
    this.binaryType = opts.binaryType || "arraybuffer";
    this.connectClock = 1;
    this.pageHidden = false;
    this.encode = void 0;
    this.decode = void 0;
    if (this.transport !== LongPoll) {
      this.encode = opts.encode || this.defaultEncoder;
      this.decode = opts.decode || this.defaultDecoder;
    } else {
      this.encode = this.defaultEncoder;
      this.decode = this.defaultDecoder;
    }
    let awaitingConnectionOnPageShow = null;
    if (phxWindow && phxWindow.addEventListener) {
      phxWindow.addEventListener("pagehide", (_e) => {
        if (this.conn) {
          this.disconnect();
          awaitingConnectionOnPageShow = this.connectClock;
        }
      });
      phxWindow.addEventListener("pageshow", (_e) => {
        if (awaitingConnectionOnPageShow === this.connectClock) {
          awaitingConnectionOnPageShow = null;
          this.connect();
        }
      });
      phxWindow.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden") {
          this.pageHidden = true;
        } else {
          this.pageHidden = false;
          if (!this.isConnected() && !this.closeWasClean) {
            this.teardown(() => this.connect());
          }
        }
      });
    }
    this.heartbeatIntervalMs = opts.heartbeatIntervalMs || 3e4;
    this.autoSendHeartbeat = opts.autoSendHeartbeat ?? true;
    this.heartbeatCallback = opts.heartbeatCallback ?? (() => {
    });
    this.rejoinAfterMs = (tries) => {
      if (opts.rejoinAfterMs) {
        return opts.rejoinAfterMs(tries);
      } else {
        return [1e3, 2e3, 5e3][tries - 1] || 1e4;
      }
    };
    this.reconnectAfterMs = (tries) => {
      if (opts.reconnectAfterMs) {
        return opts.reconnectAfterMs(tries);
      } else {
        return [10, 50, 100, 150, 200, 250, 500, 1e3, 2e3][tries - 1] || 5e3;
      }
    };
    this.logger = opts.logger || null;
    if (!this.logger && opts.debug) {
      this.logger = (kind, msg, data) => {
        console.log(`${kind}: ${msg}`, data);
      };
    }
    this.longpollerTimeout = opts.longpollerTimeout || 2e4;
    this.params = closure(opts.params || {});
    this.endPoint = `${endPoint}/${TRANSPORTS.websocket}`;
    this.vsn = opts.vsn || DEFAULT_VSN;
    this.heartbeatTimeoutTimer = null;
    this.heartbeatTimer = null;
    this.heartbeatSentAt = null;
    this.pendingHeartbeatRef = null;
    this.reconnectTimer = new Timer(() => {
      if (this.pageHidden) {
        this.log("Not reconnecting as page is hidden!");
        this.teardown();
        return;
      }
      this.teardown(async () => {
        if (opts.beforeReconnect) await opts.beforeReconnect();
        this.connect();
      });
    }, this.reconnectAfterMs);
    this.authToken = opts.authToken;
  }
  /**
   * Returns the LongPoll transport reference
   */
  getLongPollTransport() {
    return LongPoll;
  }
  /**
   * Disconnects and replaces the active transport
   *
   * @param {SocketTransport} newTransport - The new transport class to instantiate
   *
   */
  replaceTransport(newTransport) {
    this.connectClock++;
    this.closeWasClean = true;
    clearTimeout(this.fallbackTimer);
    this.reconnectTimer.reset();
    if (this.conn) {
      this.conn.close();
      this.conn = null;
    }
    this.transport = newTransport;
  }
  /**
   * Returns the socket protocol
   *
   * @returns {"wss" | "ws"}
   */
  protocol() {
    return location.protocol.match(/^https/) ? "wss" : "ws";
  }
  /**
   * The fully qualified socket url
   *
   * @returns {string}
   */
  endPointURL() {
    let uri = Ajax.appendParams(
      Ajax.appendParams(this.endPoint, this.params()),
      { vsn: this.vsn }
    );
    if (uri.charAt(0) !== "/") {
      return uri;
    }
    if (uri.charAt(1) === "/") {
      return `${this.protocol()}:${uri}`;
    }
    return `${this.protocol()}://${location.host}${uri}`;
  }
  /**
   * Disconnects the socket
   *
   * See https://developer.mozilla.org/en-US/docs/Web/API/CloseEvent#Status_codes for valid status codes.
   *
   * @param {() => void} [callback] - Optional callback which is called after socket is disconnected.
   * @param {number} [code] - A status code for disconnection (Optional).
   * @param {string} [reason] - A textual description of the reason to disconnect. (Optional)
   */
  disconnect(callback, code, reason) {
    this.connectClock++;
    this.disconnecting = true;
    this.closeWasClean = true;
    clearTimeout(this.fallbackTimer);
    this.reconnectTimer.reset();
    this.teardown(() => {
      this.disconnecting = false;
      callback && callback();
    }, code, reason);
  }
  /**
   * @param {Params} [params] - [DEPRECATED] The params to send when connecting, for example `{user_id: userToken}`
   *
   * Passing params to connect is deprecated; pass them in the Socket constructor instead:
   * `new Socket("/socket", {params: {user_id: userToken}})`.
   */
  connect(params) {
    if (params) {
      console && console.log("passing params to connect is deprecated. Instead pass :params to the Socket constructor");
      this.params = closure(params);
    }
    if (this.conn && !this.disconnecting) {
      return;
    }
    if (this.longPollFallbackMs && this.transport !== LongPoll) {
      this.connectWithFallback(LongPoll, this.longPollFallbackMs);
    } else {
      this.transportConnect();
    }
  }
  /**
   * Logs the message. Override `this.logger` for specialized logging. noops by default
   * @param {string} kind
   * @param {string} msg
   * @param {Object} data
   */
  log(kind, msg, data) {
    this.logger && this.logger(kind, msg, data);
  }
  /**
   * Returns true if a logger has been set on this socket.
   */
  hasLogger() {
    return this.logger !== null;
  }
  /**
   * Registers callbacks for connection open events
   *
   * @example socket.onOpen(function(){ console.info("the socket was opened") })
   *
   * @param {SocketOnOpen} callback
   */
  onOpen(callback) {
    let ref = this.makeRef();
    this.stateChangeCallbacks.open.push([ref, callback]);
    return ref;
  }
  /**
   * Registers callbacks for connection close events
   * @param {SocketOnClose} callback
   * @returns {string}
   */
  onClose(callback) {
    let ref = this.makeRef();
    this.stateChangeCallbacks.close.push([ref, callback]);
    return ref;
  }
  /**
   * Registers callbacks for connection error events
   *
   * @example socket.onError(function(error){ alert("An error occurred") })
   *
   * @param {SocketOnError} callback
   * @returns {string}
   */
  onError(callback) {
    let ref = this.makeRef();
    this.stateChangeCallbacks.error.push([ref, callback]);
    return ref;
  }
  /**
   * Registers callbacks for connection message events
   * @param {SocketOnMessage} callback
   * @returns {string}
   */
  onMessage(callback) {
    let ref = this.makeRef();
    this.stateChangeCallbacks.message.push([ref, callback]);
    return ref;
  }
  /**
   * Sets a callback that receives lifecycle events for internal heartbeat messages.
   * Useful for instrumenting connection health (e.g. sent/ok/timeout/disconnected).
   * @param {HeartbeatCallback} callback
   */
  onHeartbeat(callback) {
    this.heartbeatCallback = callback;
  }
  /**
   * Pings the server and invokes the callback with the RTT in milliseconds
   * @param {(timeDelta: number) => void} callback
   *
   * Returns true if the ping was pushed or false if unable to be pushed.
   */
  ping(callback) {
    if (!this.isConnected()) {
      return false;
    }
    let ref = this.makeRef();
    let startTime = Date.now();
    this.push({ topic: "phoenix", event: "heartbeat", payload: {}, ref });
    let onMsgRef = this.onMessage((msg) => {
      if (msg.ref === ref) {
        this.off([onMsgRef]);
        callback(Date.now() - startTime);
      }
    });
    return true;
  }
  /**
   * @private
   *
   * @param {Function}
   */
  transportName(transport) {
    switch (transport) {
      case LongPoll:
        return "LongPoll";
      default:
        return transport.name;
    }
  }
  /**
   * @private
   */
  transportConnect() {
    this.connectClock++;
    this.closeWasClean = false;
    let protocols = void 0;
    if (this.authToken) {
      protocols = ["phoenix", `${AUTH_TOKEN_PREFIX}${btoa(this.authToken).replace(/=/g, "")}`];
    }
    this.conn = new this.transport(this.endPointURL(), protocols);
    this.conn.binaryType = this.binaryType;
    this.conn.timeout = this.longpollerTimeout;
    this.conn.onopen = () => this.onConnOpen();
    this.conn.onerror = (error) => this.onConnError(error);
    this.conn.onmessage = (event) => this.onConnMessage(event);
    this.conn.onclose = (event) => this.onConnClose(event);
  }
  getSession(key) {
    return this.sessionStore && this.sessionStore.getItem(key);
  }
  storeSession(key, val) {
    this.sessionStore && this.sessionStore.setItem(key, val);
  }
  connectWithFallback(fallbackTransport, fallbackThreshold = 2500) {
    clearTimeout(this.fallbackTimer);
    let established = false;
    let primaryTransport = true;
    let openRef, errorRef;
    let fallbackTransportName = this.transportName(fallbackTransport);
    let fallback = (reason) => {
      this.log("transport", `falling back to ${fallbackTransportName}...`, reason);
      this.off([openRef, errorRef]);
      primaryTransport = false;
      this.replaceTransport(fallbackTransport);
      this.transportConnect();
    };
    if (this.getSession(`phx:fallback:${fallbackTransportName}`)) {
      return fallback("memorized");
    }
    this.fallbackTimer = setTimeout(fallback, fallbackThreshold);
    errorRef = this.onError((reason) => {
      this.log("transport", "error", reason);
      if (primaryTransport && !established) {
        clearTimeout(this.fallbackTimer);
        fallback(reason);
      }
    });
    if (this.fallbackRef) {
      this.off([this.fallbackRef]);
    }
    this.fallbackRef = this.onOpen(() => {
      established = true;
      if (!primaryTransport) {
        let fallbackTransportName2 = this.transportName(fallbackTransport);
        if (!this.primaryPassedHealthCheck) {
          this.storeSession(`phx:fallback:${fallbackTransportName2}`, "true");
        }
        return this.log("transport", `established ${fallbackTransportName2} fallback`);
      }
      clearTimeout(this.fallbackTimer);
      this.fallbackTimer = setTimeout(fallback, fallbackThreshold);
      this.ping((rtt) => {
        this.log("transport", "connected to primary after", rtt);
        this.primaryPassedHealthCheck = true;
        clearTimeout(this.fallbackTimer);
      });
    });
    this.transportConnect();
  }
  clearHeartbeats() {
    clearTimeout(this.heartbeatTimer);
    clearTimeout(this.heartbeatTimeoutTimer);
  }
  onConnOpen() {
    if (this.hasLogger()) this.log("transport", `connected to ${this.endPointURL()}`);
    this.closeWasClean = false;
    this.disconnecting = false;
    this.establishedConnections++;
    this.flushSendBuffer();
    this.reconnectTimer.reset();
    if (this.autoSendHeartbeat) {
      this.resetHeartbeat();
    }
    this.triggerStateCallbacks("open");
  }
  /**
   * @private
   */
  heartbeatTimeout() {
    if (this.pendingHeartbeatRef) {
      this.pendingHeartbeatRef = null;
      this.heartbeatSentAt = null;
      if (this.hasLogger()) {
        this.log("transport", "heartbeat timeout. Attempting to re-establish connection");
      }
      try {
        this.heartbeatCallback("timeout");
      } catch (e) {
        this.log("error", "error in heartbeat callback", e);
      }
      this.triggerChanError(new Error("heartbeat timeout"));
      this.closeWasClean = false;
      this.teardown(() => this.reconnectTimer.scheduleTimeout(), WS_CLOSE_NORMAL, "heartbeat timeout");
    }
  }
  resetHeartbeat() {
    if (this.conn && this.conn.skipHeartbeat) {
      return;
    }
    this.pendingHeartbeatRef = null;
    this.clearHeartbeats();
    this.heartbeatTimer = setTimeout(() => this.sendHeartbeat(), this.heartbeatIntervalMs);
  }
  teardown(callback, code, reason) {
    if (!this.conn) {
      return callback && callback();
    }
    const connToClose = this.conn;
    this.waitForBufferDone(connToClose, () => {
      if (code) {
        connToClose.close(code, reason || "");
      } else {
        connToClose.close();
      }
      this.waitForSocketClosed(connToClose, () => {
        if (this.conn === connToClose) {
          this.conn.onopen = function() {
          };
          this.conn.onerror = function() {
          };
          this.conn.onmessage = function() {
          };
          this.conn.onclose = function() {
          };
          this.conn = null;
        }
        callback && callback();
      });
    });
  }
  waitForBufferDone(conn, callback, tries = 1) {
    if (tries === 5 || !conn.bufferedAmount) {
      callback();
      return;
    }
    setTimeout(() => {
      this.waitForBufferDone(conn, callback, tries + 1);
    }, 150 * tries);
  }
  waitForSocketClosed(conn, callback, tries = 1) {
    if (tries === 5 || conn.readyState === SOCKET_STATES.closed) {
      callback();
      return;
    }
    setTimeout(() => {
      this.waitForSocketClosed(conn, callback, tries + 1);
    }, 150 * tries);
  }
  /**
  * @param {CloseEvent} event
  */
  onConnClose(event) {
    if (this.conn) this.conn.onclose = () => {
    };
    if (this.hasLogger()) this.log("transport", "close", event);
    this.triggerChanError(event);
    this.clearHeartbeats();
    if (!this.closeWasClean) {
      this.reconnectTimer.scheduleTimeout();
    }
    this.triggerStateCallbacks("close", event);
  }
  /**
   * @private
   * @param {Event} error
   */
  onConnError(error) {
    if (this.hasLogger()) this.log("transport", "error", error);
    let transportBefore = this.transport;
    let establishedBefore = this.establishedConnections;
    this.triggerStateCallbacks("error", error, transportBefore, establishedBefore);
    if (transportBefore === this.transport || establishedBefore > 0) {
      this.triggerChanError(error);
    }
  }
  /**
   * @private
   * @param {unknown} [reason] underlying close/error event forwarded to channel error listeners
   */
  triggerChanError(reason) {
    this.channels.forEach((channel) => {
      if (!(channel.isErrored() || channel.isLeaving() || channel.isClosed())) {
        channel.trigger(CHANNEL_EVENTS.error, reason);
      }
    });
  }
  /**
   * @returns {string}
   */
  connectionState() {
    switch (this.conn && this.conn.readyState) {
      case SOCKET_STATES.connecting:
        return "connecting";
      case SOCKET_STATES.open:
        return "open";
      case SOCKET_STATES.closing:
        return "closing";
      default:
        return "closed";
    }
  }
  /**
   * @returns {boolean}
   */
  isConnected() {
    return this.connectionState() === "open";
  }
  /**
   *
   * @param {Channel} channel
   */
  remove(channel) {
    this.off(channel.stateChangeRefs);
    this.channels = this.channels.filter((c) => c !== channel);
  }
  /**
   * Removes `onOpen`, `onClose`, `onError,` and `onMessage` registrations.
   *
   * @param {string[]} refs - list of refs returned by calls to
   *                 `onOpen`, `onClose`, `onError,` and `onMessage`
   */
  off(refs) {
    for (let key in this.stateChangeCallbacks) {
      this.stateChangeCallbacks[key] = this.stateChangeCallbacks[key].filter(([ref]) => {
        return refs.indexOf(ref) === -1;
      });
    }
  }
  /**
   * Initiates a new channel for the given topic
   *
   * @param {string} topic
   * @param {Params | (() => Params)} [chanParams]- Parameters for the channel
   * @returns {Channel}
   */
  channel(topic, chanParams = {}) {
    let chan = new Channel(topic, chanParams, this);
    this.channels.push(chan);
    return chan;
  }
  /**
   * @param {Message<Record<string, any>>} data
   */
  push(data) {
    if (this.hasLogger()) {
      let { topic, event, payload, ref, join_ref } = data;
      this.log("push", `${topic} ${event} (${join_ref}, ${ref})`, payload);
    }
    if (this.isConnected()) {
      this.encode(data, (result) => this.conn.send(result));
    } else {
      this.sendBuffer.push(() => this.encode(data, (result) => this.conn.send(result)));
    }
  }
  /**
   * Return the next message ref, accounting for overflows
   * @returns {string}
   */
  makeRef() {
    let newRef = this.ref + 1;
    if (newRef === this.ref) {
      this.ref = 0;
    } else {
      this.ref = newRef;
    }
    return this.ref.toString();
  }
  sendHeartbeat() {
    if (!this.isConnected()) {
      try {
        this.heartbeatCallback("disconnected");
      } catch (e) {
        this.log("error", "error in heartbeat callback", e);
      }
      return;
    }
    if (this.pendingHeartbeatRef) {
      this.heartbeatTimeout();
      return;
    }
    this.pendingHeartbeatRef = this.makeRef();
    this.heartbeatSentAt = Date.now();
    this.push({ topic: "phoenix", event: "heartbeat", payload: {}, ref: this.pendingHeartbeatRef });
    try {
      this.heartbeatCallback("sent");
    } catch (e) {
      this.log("error", "error in heartbeat callback", e);
    }
    this.heartbeatTimeoutTimer = setTimeout(() => this.heartbeatTimeout(), this.heartbeatIntervalMs);
  }
  flushSendBuffer() {
    if (this.isConnected() && this.sendBuffer.length > 0) {
      this.sendBuffer.forEach((callback) => callback());
      this.sendBuffer = [];
    }
  }
  /**
  * @param {MessageEvent<any>} rawMessage
  */
  onConnMessage(rawMessage) {
    this.decode(rawMessage.data, (msg) => {
      let { topic, event, payload, ref, join_ref } = msg;
      if (ref && ref === this.pendingHeartbeatRef) {
        const latency = this.heartbeatSentAt ? Date.now() - this.heartbeatSentAt : void 0;
        this.clearHeartbeats();
        try {
          this.heartbeatCallback(payload.status === "ok" ? "ok" : "error", latency);
        } catch (e) {
          this.log("error", "error in heartbeat callback", e);
        }
        this.pendingHeartbeatRef = null;
        this.heartbeatSentAt = null;
        if (this.autoSendHeartbeat) {
          this.heartbeatTimer = setTimeout(() => this.sendHeartbeat(), this.heartbeatIntervalMs);
        }
      }
      if (this.hasLogger()) this.log("receive", `${payload.status || ""} ${topic} ${event} ${ref && "(" + ref + ")" || ""}`.trim(), payload);
      for (let i = 0; i < this.channels.length; i++) {
        const channel = this.channels[i];
        if (!channel.isMember(topic, event, payload, join_ref)) {
          continue;
        }
        channel.trigger(event, payload, ref, join_ref);
      }
      this.triggerStateCallbacks("message", msg);
    });
  }
  /**
   * @private
   * @template {keyof SocketStateChangeCallbacks} K
   * @param {K} event
   * @param {...Parameters<SocketStateChangeCallbacks[K][number][1]>} args
   * @returns {void}
   */
  triggerStateCallbacks(event, ...args) {
    try {
      this.stateChangeCallbacks[event].forEach(([_, callback]) => {
        try {
          callback(...args);
        } catch (e) {
          this.log("error", `error in ${event} callback`, e);
        }
      });
    } catch (e) {
      this.log("error", `error triggering ${event} callbacks`, e);
    }
  }
  leaveOpenTopic(topic) {
    let dupChannel = this.channels.find((c) => c.topic === topic && (c.isJoined() || c.isJoining()));
    if (dupChannel) {
      if (this.hasLogger()) this.log("transport", `leaving duplicate topic "${topic}"`);
      dupChannel.leave();
    }
  }
};
export {
  Channel,
  LongPoll,
  Presence,
  Push,
  serializer_default as Serializer,
  Socket,
  Timer
};
                                    

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL2Fzc2V0cy9qcy9waG9lbml4L3V0aWxzLmpzIiwiLi4vLi4vYXNzZXRzL2pzL3Bob2VuaXgvY29uc3RhbnRzLmpzIiwiLi4vLi4vYXNzZXRzL2pzL3Bob2VuaXgvcHVzaC5qcyIsIi4uLy4uL2Fzc2V0cy9qcy9waG9lbml4L3RpbWVyLmpzIiwiLi4vLi4vYXNzZXRzL2pzL3Bob2VuaXgvY2hhbm5lbC5qcyIsIi4uLy4uL2Fzc2V0cy9qcy9waG9lbml4L2FqYXguanMiLCIuLi8uLi9hc3NldHMvanMvcGhvZW5peC9sb25ncG9sbC5qcyIsIi4uLy4uL2Fzc2V0cy9qcy9waG9lbml4L3ByZXNlbmNlLmpzIiwiLi4vLi4vYXNzZXRzL2pzL3Bob2VuaXgvc2VyaWFsaXplci5qcyIsIi4uLy4uL2Fzc2V0cy9qcy9waG9lbml4L3NvY2tldC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbipcbiogV3JhcHMgdmFsdWUgaW4gY2xvc3VyZSBvciByZXR1cm5zIGNsb3N1cmVcbipcbiogQHRlbXBsYXRlIFRcbiogQHBhcmFtIHtUIHwgKCgpID0+IFQpfSB2YWx1ZVxuKiBAcmV0dXJucyB7KCkgPT4gVH1cbiovXG5leHBvcnQgbGV0IGNsb3N1cmUgPSAodmFsdWUpID0+IHtcbiAgaWYodHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIpe1xuICAgIHJldHVybiAvKiogQHR5cGUgeygpID0+IFR9ICovICh2YWx1ZSlcbiAgfSBlbHNlIHtcbiAgICBsZXQgY2xvc3VyZSA9IGZ1bmN0aW9uICgpeyByZXR1cm4gdmFsdWUgfVxuICAgIHJldHVybiBjbG9zdXJlXG4gIH1cbn1cbiIsImV4cG9ydCBjb25zdCBnbG9iYWxTZWxmID0gdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogbnVsbFxuZXhwb3J0IGNvbnN0IHBoeFdpbmRvdyA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiBudWxsXG5leHBvcnQgY29uc3QgZ2xvYmFsID0gZ2xvYmFsU2VsZiB8fCBwaHhXaW5kb3cgfHwgZ2xvYmFsVGhpc1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfVlNOID0gXCIyLjAuMFwiXG5leHBvcnQgY29uc3QgREVGQVVMVF9USU1FT1VUID0gMTAwMDBcbmV4cG9ydCBjb25zdCBXU19DTE9TRV9OT1JNQUwgPSAxMDAwXG5cbmV4cG9ydCBjb25zdCBTT0NLRVRfU1RBVEVTID0gLyoqIEB0eXBlIHtjb25zdH0gKi8gKHtjb25uZWN0aW5nOiAwLCBvcGVuOiAxLCBjbG9zaW5nOiAyLCBjbG9zZWQ6IDN9KVxuXG5leHBvcnQgY29uc3QgQ0hBTk5FTF9TVEFURVMgPSAvKiogQHR5cGUge2NvbnN0fSAqLyAoe1xuICBjbG9zZWQ6IFwiY2xvc2VkXCIsXG4gIGVycm9yZWQ6IFwiZXJyb3JlZFwiLFxuICBqb2luZWQ6IFwiam9pbmVkXCIsXG4gIGpvaW5pbmc6IFwiam9pbmluZ1wiLFxuICBsZWF2aW5nOiBcImxlYXZpbmdcIixcbn0pXG5cbmV4cG9ydCBjb25zdCBDSEFOTkVMX0VWRU5UUyA9IC8qKiBAdHlwZSB7Y29uc3R9ICovICh7XG4gIGNsb3NlOiBcInBoeF9jbG9zZVwiLFxuICBlcnJvcjogXCJwaHhfZXJyb3JcIixcbiAgam9pbjogXCJwaHhfam9pblwiLFxuICByZXBseTogXCJwaHhfcmVwbHlcIixcbiAgbGVhdmU6IFwicGh4X2xlYXZlXCJcbn0pXG5cbmV4cG9ydCBjb25zdCBUUkFOU1BPUlRTID0gLyoqIEB0eXBlIHtjb25zdH0gKi8gKHtcbiAgbG9uZ3BvbGw6IFwibG9uZ3BvbGxcIixcbiAgd2Vic29ja2V0OiBcIndlYnNvY2tldFwiXG59KVxuXG5leHBvcnQgY29uc3QgWEhSX1NUQVRFUyA9IC8qKiBAdHlwZSB7Y29uc3R9ICovICh7XG4gIGNvbXBsZXRlOiA0XG59KVxuXG5leHBvcnQgY29uc3QgQVVUSF9UT0tFTl9QUkVGSVggPSBcImJhc2U2NHVybC5iZWFyZXIucGh4LlwiXG4iLCIvKipcbiAqIEBpbXBvcnQgQ2hhbm5lbCBmcm9tIFwiLi9jaGFubmVsXCJcbiAqIEBpbXBvcnQgeyBDaGFubmVsRXZlbnQgfSBmcm9tIFwiLi90eXBlc1wiXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFB1c2gge1xuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIFB1c2hcbiAgICogQHBhcmFtIHtDaGFubmVsfSBjaGFubmVsIC0gVGhlIENoYW5uZWxcbiAgICogQHBhcmFtIHtDaGFubmVsRXZlbnR9IGV2ZW50IC0gVGhlIGV2ZW50LCBmb3IgZXhhbXBsZSBgXCJwaHhfam9pblwiYFxuICAgKiBAcGFyYW0geygpID0+IFJlY29yZDxzdHJpbmcsIHVua25vd24+fSBwYXlsb2FkIC0gVGhlIHBheWxvYWQsIGZvciBleGFtcGxlIGB7dXNlcl9pZDogMTIzfWBcbiAgICogQHBhcmFtIHtudW1iZXJ9IHRpbWVvdXQgLSBUaGUgcHVzaCB0aW1lb3V0IGluIG1pbGxpc2Vjb25kc1xuICAgKi9cbiAgY29uc3RydWN0b3IoY2hhbm5lbCwgZXZlbnQsIHBheWxvYWQsIHRpbWVvdXQpe1xuICAgIC8qKiBAdHlwZXtDaGFubmVsfSAqL1xuICAgIHRoaXMuY2hhbm5lbCA9IGNoYW5uZWxcbiAgICAvKiogQHR5cGV7Q2hhbm5lbEV2ZW50fSAqL1xuICAgIHRoaXMuZXZlbnQgPSBldmVudFxuICAgIC8qKiBAdHlwZXsoKSA9PiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPn0gKi9cbiAgICB0aGlzLnBheWxvYWQgPSBwYXlsb2FkIHx8IGZ1bmN0aW9uICgpeyByZXR1cm4ge30gfVxuICAgIHRoaXMucmVjZWl2ZWRSZXNwID0gbnVsbFxuICAgIC8qKiBAdHlwZXtudW1iZXJ9ICovXG4gICAgdGhpcy50aW1lb3V0ID0gdGltZW91dFxuICAgIC8qKiBAdHlwZXsoUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4pIHwgbnVsbH0gKi9cbiAgICB0aGlzLnRpbWVvdXRUaW1lciA9IG51bGxcbiAgICAvKiogQHR5cGV7e3N0YXR1czogc3RyaW5nOyBjYWxsYmFjazogKHJlc3BvbnNlOiBhbnkpID0+IHZvaWR9W119ICovXG4gICAgdGhpcy5yZWNIb29rcyA9IFtdXG4gICAgLyoqIEB0eXBle2Jvb2xlYW59ICovXG4gICAgdGhpcy5zZW50ID0gZmFsc2VcbiAgICAvKiogQHR5cGV7c3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gKi9cbiAgICB0aGlzLnJlZiA9IHVuZGVmaW5lZFxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7bnVtYmVyfSB0aW1lb3V0XG4gICAqL1xuICByZXNlbmQodGltZW91dCl7XG4gICAgdGhpcy50aW1lb3V0ID0gdGltZW91dFxuICAgIHRoaXMucmVzZXQoKVxuICAgIHRoaXMuc2VuZCgpXG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIHNlbmQoKXtcbiAgICBpZih0aGlzLmhhc1JlY2VpdmVkKFwidGltZW91dFwiKSl7IHJldHVybiB9XG4gICAgdGhpcy5zdGFydFRpbWVvdXQoKVxuICAgIHRoaXMuc2VudCA9IHRydWVcbiAgICB0aGlzLmNoYW5uZWwuc29ja2V0LnB1c2goe1xuICAgICAgdG9waWM6IHRoaXMuY2hhbm5lbC50b3BpYyxcbiAgICAgIGV2ZW50OiB0aGlzLmV2ZW50LFxuICAgICAgcGF5bG9hZDogdGhpcy5wYXlsb2FkKCksXG4gICAgICByZWY6IHRoaXMucmVmLFxuICAgICAgam9pbl9yZWY6IHRoaXMuY2hhbm5lbC5qb2luUmVmKClcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBzdGF0dXNcbiAgICogQHBhcmFtIHsocmVzcG9uc2U6IGFueSkgPT4gdm9pZH0gY2FsbGJhY2tcbiAgICovXG4gIHJlY2VpdmUoc3RhdHVzLCBjYWxsYmFjayl7XG4gICAgaWYodGhpcy5oYXNSZWNlaXZlZChzdGF0dXMpKXtcbiAgICAgIGNhbGxiYWNrKHRoaXMucmVjZWl2ZWRSZXNwLnJlc3BvbnNlKVxuICAgIH1cblxuICAgIHRoaXMucmVjSG9va3MucHVzaCh7c3RhdHVzLCBjYWxsYmFja30pXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHJlc2V0KCl7XG4gICAgdGhpcy5jYW5jZWxSZWZFdmVudCgpXG4gICAgdGhpcy5yZWYgPSBudWxsXG4gICAgdGhpcy5yZWZFdmVudCA9IG51bGxcbiAgICB0aGlzLnJlY2VpdmVkUmVzcCA9IG51bGxcbiAgICB0aGlzLnNlbnQgPSBmYWxzZVxuICB9XG5cbiAgZGVzdHJveSgpe1xuICAgIHRoaXMuY2FuY2VsUmVmRXZlbnQoKVxuICAgIHRoaXMuY2FuY2VsVGltZW91dCgpXG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIG1hdGNoUmVjZWl2ZSh7c3RhdHVzLCByZXNwb25zZSwgX3JlZn0pe1xuICAgIHRoaXMucmVjSG9va3MuZmlsdGVyKGggPT4gaC5zdGF0dXMgPT09IHN0YXR1cylcbiAgICAgIC5mb3JFYWNoKGggPT4gaC5jYWxsYmFjayhyZXNwb25zZSkpXG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIGNhbmNlbFJlZkV2ZW50KCl7XG4gICAgaWYoIXRoaXMucmVmRXZlbnQpeyByZXR1cm4gfVxuICAgIHRoaXMuY2hhbm5lbC5vZmYodGhpcy5yZWZFdmVudClcbiAgfVxuXG4gIGNhbmNlbFRpbWVvdXQoKXtcbiAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lb3V0VGltZXIpXG4gICAgdGhpcy50aW1lb3V0VGltZXIgPSBudWxsXG4gIH1cblxuICBzdGFydFRpbWVvdXQoKXtcbiAgICBpZih0aGlzLnRpbWVvdXRUaW1lcil7IHRoaXMuY2FuY2VsVGltZW91dCgpIH1cbiAgICB0aGlzLnJlZiA9IHRoaXMuY2hhbm5lbC5zb2NrZXQubWFrZVJlZigpXG4gICAgdGhpcy5yZWZFdmVudCA9IHRoaXMuY2hhbm5lbC5yZXBseUV2ZW50TmFtZSh0aGlzLnJlZilcblxuICAgIHRoaXMuY2hhbm5lbC5vbih0aGlzLnJlZkV2ZW50LCBwYXlsb2FkID0+IHtcbiAgICAgIHRoaXMuY2FuY2VsUmVmRXZlbnQoKVxuICAgICAgdGhpcy5jYW5jZWxUaW1lb3V0KClcbiAgICAgIHRoaXMucmVjZWl2ZWRSZXNwID0gcGF5bG9hZFxuICAgICAgdGhpcy5tYXRjaFJlY2VpdmUocGF5bG9hZClcbiAgICB9KVxuXG4gICAgdGhpcy50aW1lb3V0VGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMudHJpZ2dlcihcInRpbWVvdXRcIiwge30pXG4gICAgfSwgdGhpcy50aW1lb3V0KVxuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBoYXNSZWNlaXZlZChzdGF0dXMpe1xuICAgIHJldHVybiB0aGlzLnJlY2VpdmVkUmVzcCAmJiB0aGlzLnJlY2VpdmVkUmVzcC5zdGF0dXMgPT09IHN0YXR1c1xuICB9XG5cbiAgdHJpZ2dlcihzdGF0dXMsIHJlc3BvbnNlKXtcbiAgICB0aGlzLmNoYW5uZWwudHJpZ2dlcih0aGlzLnJlZkV2ZW50LCB7c3RhdHVzLCByZXNwb25zZX0pXG4gIH1cbn1cbiIsIi8qKlxuICpcbiAqIENyZWF0ZXMgYSB0aW1lciB0aGF0IGFjY2VwdHMgYSBgdGltZXJDYWxjYCBmdW5jdGlvbiB0byBwZXJmb3JtXG4gKiBjYWxjdWxhdGVkIHRpbWVvdXQgcmV0cmllcywgc3VjaCBhcyBleHBvbmVudGlhbCBiYWNrb2ZmLlxuICpcbiAqIEBleGFtcGxlXG4gKiBsZXQgcmVjb25uZWN0VGltZXIgPSBuZXcgVGltZXIoKCkgPT4gdGhpcy5jb25uZWN0KCksIGZ1bmN0aW9uKHRyaWVzKXtcbiAqICAgcmV0dXJuIFsxMDAwLCA1MDAwLCAxMDAwMF1bdHJpZXMgLSAxXSB8fCAxMDAwMFxuICogfSlcbiAqIHJlY29ubmVjdFRpbWVyLnNjaGVkdWxlVGltZW91dCgpIC8vIGZpcmVzIGFmdGVyIDEwMDBcbiAqIHJlY29ubmVjdFRpbWVyLnNjaGVkdWxlVGltZW91dCgpIC8vIGZpcmVzIGFmdGVyIDUwMDBcbiAqIHJlY29ubmVjdFRpbWVyLnJlc2V0KClcbiAqIHJlY29ubmVjdFRpbWVyLnNjaGVkdWxlVGltZW91dCgpIC8vIGZpcmVzIGFmdGVyIDEwMDBcbiAqXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFRpbWVyIHtcbiAgLyoqXG4gICogQHBhcmFtIHsoKSA9PiB2b2lkfSBjYWxsYmFja1xuICAqIEBwYXJhbSB7KHRyaWVzOiBudW1iZXIpID0+IG51bWJlcn0gdGltZXJDYWxjXG4gICovXG4gIGNvbnN0cnVjdG9yKGNhbGxiYWNrLCB0aW1lckNhbGMpe1xuICAgIC8qKiBAdHlwZSB7KCkgPT4gdm9pZH0gKi9cbiAgICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2tcbiAgICAvKiogQHR5cGUgeyh0cmllczogbnVtYmVyKSA9PiBudW1iZXJ9ICovXG4gICAgdGhpcy50aW1lckNhbGMgPSB0aW1lckNhbGNcbiAgICAvKiogQHR5cGUge1JldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgdW5kZWZpbmVkfSAqL1xuICAgIHRoaXMudGltZXIgPSB1bmRlZmluZWRcbiAgICAvKiogQHR5cGUge251bWJlcn0gKi9cbiAgICB0aGlzLnRyaWVzID0gMFxuICB9XG5cbiAgcmVzZXQoKXtcbiAgICB0aGlzLnRyaWVzID0gMFxuICAgIGNsZWFyVGltZW91dCh0aGlzLnRpbWVyKVxuICB9XG5cbiAgLyoqXG4gICAqIENhbmNlbHMgYW55IHByZXZpb3VzIHNjaGVkdWxlVGltZW91dCBhbmQgc2NoZWR1bGVzIGNhbGxiYWNrXG4gICAqL1xuICBzY2hlZHVsZVRpbWVvdXQoKXtcbiAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lcilcblxuICAgIHRoaXMudGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMudHJpZXMgPSB0aGlzLnRyaWVzICsgMVxuICAgICAgdGhpcy5jYWxsYmFjaygpXG4gICAgfSwgdGhpcy50aW1lckNhbGModGhpcy50cmllcyArIDEpKVxuICB9XG59XG4iLCJpbXBvcnQge2Nsb3N1cmV9IGZyb20gXCIuL3V0aWxzXCJcbmltcG9ydCB7XG4gIENIQU5ORUxfRVZFTlRTLFxuICBDSEFOTkVMX1NUQVRFUyxcbn0gZnJvbSBcIi4vY29uc3RhbnRzXCJcblxuaW1wb3J0IFB1c2ggZnJvbSBcIi4vcHVzaFwiXG5pbXBvcnQgVGltZXIgZnJvbSBcIi4vdGltZXJcIlxuXG4vKipcbiogQGltcG9ydCBTb2NrZXQgZnJvbSBcIi4vc29ja2V0XCJcbiogQGltcG9ydCB7IENoYW5uZWxTdGF0ZSwgUGFyYW1zLCBDaGFubmVsQmluZGluZ0NhbGxiYWNrLCBDaGFubmVsT25NZXNzYWdlLCBDaGFubmVsRmlsdGVyQmluZGluZ3MsIENoYW5uZWxPbkVycm9yQ2FsbGJhY2ssIENoYW5uZWxCaW5kaW5nIH0gZnJvbSBcIi4vdHlwZXNcIlxuKi9cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ2hhbm5lbCB7XG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB0b3BpY1xuICogQHBhcmFtIHtQYXJhbXMgfCAoKCkgPT4gUGFyYW1zKX0gcGFyYW1zXG4gKiBAcGFyYW0ge1NvY2tldH0gc29ja2V0XG4gKi9cbiAgY29uc3RydWN0b3IodG9waWMsIHBhcmFtcywgc29ja2V0KXtcbiAgICAvKiogQHR5cGV7Q2hhbm5lbFN0YXRlfSAqL1xuICAgIHRoaXMuc3RhdGUgPSBDSEFOTkVMX1NUQVRFUy5jbG9zZWRcbiAgICAvKiogQHR5cGV7c3RyaW5nfSAqL1xuICAgIHRoaXMudG9waWMgPSB0b3BpY1xuICAgIC8qKiBAdHlwZXsoKSA9PiBQYXJhbXN9ICovXG4gICAgdGhpcy5wYXJhbXMgPSBjbG9zdXJlKHBhcmFtcyB8fCB7fSlcbiAgICAvKiogQHR5cGUge1NvY2tldH0gKi9cbiAgICB0aGlzLnNvY2tldCA9IHNvY2tldFxuICAgIC8qKiBAdHlwZXtDaGFubmVsQmluZGluZ1tdfSAqL1xuICAgIHRoaXMuYmluZGluZ3MgPSBbXVxuICAgIC8qKiBAdHlwZXtudW1iZXJ9ICovXG4gICAgdGhpcy5iaW5kaW5nUmVmID0gMFxuICAgIC8qKiBAdHlwZXtudW1iZXJ9ICovXG4gICAgdGhpcy50aW1lb3V0ID0gdGhpcy5zb2NrZXQudGltZW91dFxuICAgIC8qKiBAdHlwZXtib29sZWFufSAqL1xuICAgIHRoaXMuam9pbmVkT25jZSA9IGZhbHNlXG4gICAgLyoqIEB0eXBle1B1c2h9ICovXG4gICAgdGhpcy5qb2luUHVzaCA9IG5ldyBQdXNoKHRoaXMsIENIQU5ORUxfRVZFTlRTLmpvaW4sIHRoaXMucGFyYW1zLCB0aGlzLnRpbWVvdXQpXG4gICAgLyoqIEB0eXBle1B1c2hbXX0gKi9cbiAgICB0aGlzLnB1c2hCdWZmZXIgPSBbXVxuICAgIC8qKiBAdHlwZXtzdHJpbmdbXX0gKi9cbiAgICB0aGlzLnN0YXRlQ2hhbmdlUmVmcyA9IFtdXG5cbiAgICAvKiogQHR5cGV7VGltZXJ9ICovXG4gICAgdGhpcy5yZWpvaW5UaW1lciA9IG5ldyBUaW1lcigoKSA9PiB7XG4gICAgICBpZih0aGlzLnNvY2tldC5pc0Nvbm5lY3RlZCgpKXsgdGhpcy5yZWpvaW4oKSB9XG4gICAgfSwgdGhpcy5zb2NrZXQucmVqb2luQWZ0ZXJNcylcbiAgICB0aGlzLnN0YXRlQ2hhbmdlUmVmcy5wdXNoKHRoaXMuc29ja2V0Lm9uRXJyb3IoKCkgPT4gdGhpcy5yZWpvaW5UaW1lci5yZXNldCgpKSlcbiAgICB0aGlzLnN0YXRlQ2hhbmdlUmVmcy5wdXNoKHRoaXMuc29ja2V0Lm9uT3BlbigoKSA9PiB7XG4gICAgICB0aGlzLnJlam9pblRpbWVyLnJlc2V0KClcbiAgICAgIGlmKHRoaXMuaXNFcnJvcmVkKCkpeyB0aGlzLnJlam9pbigpIH1cbiAgICB9KVxuICAgIClcbiAgICB0aGlzLmpvaW5QdXNoLnJlY2VpdmUoXCJva1wiLCAoKSA9PiB7XG4gICAgICB0aGlzLnN0YXRlID0gQ0hBTk5FTF9TVEFURVMuam9pbmVkXG4gICAgICB0aGlzLnJlam9pblRpbWVyLnJlc2V0KClcbiAgICAgIHRoaXMucHVzaEJ1ZmZlci5mb3JFYWNoKHB1c2hFdmVudCA9PiBwdXNoRXZlbnQuc2VuZCgpKVxuICAgICAgdGhpcy5wdXNoQnVmZmVyID0gW11cbiAgICB9KVxuICAgIHRoaXMuam9pblB1c2gucmVjZWl2ZShcImVycm9yXCIsIChyZWFzb24pID0+IHtcbiAgICAgIHRoaXMuc3RhdGUgPSBDSEFOTkVMX1NUQVRFUy5lcnJvcmVkXG4gICAgICBpZih0aGlzLnNvY2tldC5oYXNMb2dnZXIoKSkgdGhpcy5zb2NrZXQubG9nKFwiY2hhbm5lbFwiLCBgZXJyb3IgJHt0aGlzLnRvcGljfWAsIHJlYXNvbilcbiAgICAgIGlmKHRoaXMuc29ja2V0LmlzQ29ubmVjdGVkKCkpeyB0aGlzLnJlam9pblRpbWVyLnNjaGVkdWxlVGltZW91dCgpIH1cbiAgICB9KVxuICAgIHRoaXMub25DbG9zZSgoKSA9PiB7XG4gICAgICB0aGlzLnJlam9pblRpbWVyLnJlc2V0KClcbiAgICAgIGlmKHRoaXMuc29ja2V0Lmhhc0xvZ2dlcigpKSB0aGlzLnNvY2tldC5sb2coXCJjaGFubmVsXCIsIGBjbG9zZSAke3RoaXMudG9waWN9YClcbiAgICAgIHRoaXMuc3RhdGUgPSBDSEFOTkVMX1NUQVRFUy5jbG9zZWRcbiAgICAgIHRoaXMuc29ja2V0LnJlbW92ZSh0aGlzKVxuICAgIH0pXG4gICAgdGhpcy5vbkVycm9yKHJlYXNvbiA9PiB7XG4gICAgICBpZih0aGlzLnNvY2tldC5oYXNMb2dnZXIoKSkgdGhpcy5zb2NrZXQubG9nKFwiY2hhbm5lbFwiLCBgZXJyb3IgJHt0aGlzLnRvcGljfWAsIHJlYXNvbilcbiAgICAgIGlmKHRoaXMuaXNKb2luaW5nKCkpeyB0aGlzLmpvaW5QdXNoLnJlc2V0KCkgfVxuICAgICAgdGhpcy5zdGF0ZSA9IENIQU5ORUxfU1RBVEVTLmVycm9yZWRcbiAgICAgIGlmKHRoaXMuc29ja2V0LmlzQ29ubmVjdGVkKCkpeyB0aGlzLnJlam9pblRpbWVyLnNjaGVkdWxlVGltZW91dCgpIH1cbiAgICB9KVxuICAgIHRoaXMuam9pblB1c2gucmVjZWl2ZShcInRpbWVvdXRcIiwgKCkgPT4ge1xuICAgICAgaWYodGhpcy5zb2NrZXQuaGFzTG9nZ2VyKCkpIHRoaXMuc29ja2V0LmxvZyhcImNoYW5uZWxcIiwgYHRpbWVvdXQgJHt0aGlzLnRvcGljfWAsIHRoaXMuam9pblB1c2gudGltZW91dClcbiAgICAgIGxldCBsZWF2ZVB1c2ggPSBuZXcgUHVzaCh0aGlzLCBDSEFOTkVMX0VWRU5UUy5sZWF2ZSwgY2xvc3VyZSh7fSksIHRoaXMudGltZW91dClcbiAgICAgIGxlYXZlUHVzaC5zZW5kKClcbiAgICAgIHRoaXMuc3RhdGUgPSBDSEFOTkVMX1NUQVRFUy5lcnJvcmVkXG4gICAgICB0aGlzLmpvaW5QdXNoLnJlc2V0KClcbiAgICAgIGlmKHRoaXMuc29ja2V0LmlzQ29ubmVjdGVkKCkpeyB0aGlzLnJlam9pblRpbWVyLnNjaGVkdWxlVGltZW91dCgpIH1cbiAgICB9KVxuICAgIHRoaXMub24oQ0hBTk5FTF9FVkVOVFMucmVwbHksIChwYXlsb2FkLCByZWYpID0+IHtcbiAgICAgIHRoaXMudHJpZ2dlcih0aGlzLnJlcGx5RXZlbnROYW1lKHJlZiksIHBheWxvYWQpXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBKb2luIHRoZSBjaGFubmVsXG4gICAqIEBwYXJhbSB7bnVtYmVyfSB0aW1lb3V0XG4gICAqIEByZXR1cm5zIHtQdXNofVxuICAgKi9cbiAgam9pbih0aW1lb3V0ID0gdGhpcy50aW1lb3V0KXtcbiAgICBpZih0aGlzLmpvaW5lZE9uY2Upe1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwidHJpZWQgdG8gam9pbiBtdWx0aXBsZSB0aW1lcy4gJ2pvaW4nIGNhbiBvbmx5IGJlIGNhbGxlZCBhIHNpbmdsZSB0aW1lIHBlciBjaGFubmVsIGluc3RhbmNlXCIpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMudGltZW91dCA9IHRpbWVvdXRcbiAgICAgIHRoaXMuam9pbmVkT25jZSA9IHRydWVcbiAgICAgIHRoaXMucmVqb2luKClcbiAgICAgIHJldHVybiB0aGlzLmpvaW5QdXNoXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRlYXJkb3duIHRoZSBjaGFubmVsLlxuICAgKlxuICAgKiBEZXN0cm95cyBhbmQgc3RvcHMgcmVsYXRlZCB0aW1lcnMuXG4gICAqL1xuICB0ZWFyZG93bigpe1xuICAgIHRoaXMucHVzaEJ1ZmZlci5mb3JFYWNoKChwdXNoKSA9PiBwdXNoLmRlc3Ryb3koKSlcbiAgICB0aGlzLnB1c2hCdWZmZXIgPSBbXVxuICAgIHRoaXMucmVqb2luVGltZXIucmVzZXQoKVxuICAgIHRoaXMuam9pblB1c2guZGVzdHJveSgpXG4gICAgdGhpcy5zdGF0ZSA9IENIQU5ORUxfU1RBVEVTLmNsb3NlZFxuICAgIHRoaXMuYmluZGluZ3MgPSBbXVxuICB9XG5cbiAgLyoqXG4gICAqIEhvb2sgaW50byBjaGFubmVsIGNsb3NlXG4gICAqIEBwYXJhbSB7Q2hhbm5lbEJpbmRpbmdDYWxsYmFja30gY2FsbGJhY2tcbiAgICovXG4gIG9uQ2xvc2UoY2FsbGJhY2spe1xuICAgIHRoaXMub24oQ0hBTk5FTF9FVkVOVFMuY2xvc2UsIGNhbGxiYWNrKVxuICB9XG5cbiAgLyoqXG4gICAqIEhvb2sgaW50byBjaGFubmVsIGVycm9yc1xuICAgKiBAcGFyYW0ge0NoYW5uZWxPbkVycm9yQ2FsbGJhY2t9IGNhbGxiYWNrXG4gICAqIEByZXR1cm4ge251bWJlcn1cbiAgICovXG4gIG9uRXJyb3IoY2FsbGJhY2spe1xuICAgIHJldHVybiB0aGlzLm9uKENIQU5ORUxfRVZFTlRTLmVycm9yLCByZWFzb24gPT4gY2FsbGJhY2socmVhc29uKSlcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmVzIG9uIGNoYW5uZWwgZXZlbnRzXG4gICAqXG4gICAqIFN1YnNjcmlwdGlvbiByZXR1cm5zIGEgcmVmIGNvdW50ZXIsIHdoaWNoIGNhbiBiZSB1c2VkIGxhdGVyIHRvXG4gICAqIHVuc3Vic2NyaWJlIHRoZSBleGFjdCBldmVudCBsaXN0ZW5lclxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBjb25zdCByZWYxID0gY2hhbm5lbC5vbihcImV2ZW50XCIsIGRvX3N0dWZmKVxuICAgKiBjb25zdCByZWYyID0gY2hhbm5lbC5vbihcImV2ZW50XCIsIGRvX290aGVyX3N0dWZmKVxuICAgKiBjaGFubmVsLm9mZihcImV2ZW50XCIsIHJlZjEpXG4gICAqIC8vIFNpbmNlIHVuc3Vic2NyaXB0aW9uLCBkb19zdHVmZiB3b24ndCBmaXJlLFxuICAgKiAvLyB3aGlsZSBkb19vdGhlcl9zdHVmZiB3aWxsIGtlZXAgZmlyaW5nIG9uIHRoZSBcImV2ZW50XCJcbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmd9IGV2ZW50XG4gICAqIEBwYXJhbSB7Q2hhbm5lbEJpbmRpbmdDYWxsYmFja30gY2FsbGJhY2tcbiAgICogQHJldHVybnMge251bWJlcn0gcmVmXG4gICAqL1xuICBvbihldmVudCwgY2FsbGJhY2spe1xuICAgIGxldCByZWYgPSB0aGlzLmJpbmRpbmdSZWYrK1xuICAgIHRoaXMuYmluZGluZ3MucHVzaCh7ZXZlbnQsIHJlZiwgY2FsbGJhY2t9KVxuICAgIHJldHVybiByZWZcbiAgfVxuXG4gIC8qKlxuICAgKiBVbnN1YnNjcmliZXMgb2ZmIG9mIGNoYW5uZWwgZXZlbnRzXG4gICAqXG4gICAqIFVzZSB0aGUgcmVmIHJldHVybmVkIGZyb20gYSBjaGFubmVsLm9uKCkgdG8gdW5zdWJzY3JpYmUgb25lXG4gICAqIGhhbmRsZXIsIG9yIHBhc3Mgbm90aGluZyBmb3IgdGhlIHJlZiB0byB1bnN1YnNjcmliZSBhbGxcbiAgICogaGFuZGxlcnMgZm9yIHRoZSBnaXZlbiBldmVudC5cbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogLy8gVW5zdWJzY3JpYmUgdGhlIGRvX3N0dWZmIGhhbmRsZXJcbiAgICogY29uc3QgcmVmMSA9IGNoYW5uZWwub24oXCJldmVudFwiLCBkb19zdHVmZilcbiAgICogY2hhbm5lbC5vZmYoXCJldmVudFwiLCByZWYxKVxuICAgKlxuICAgKiAvLyBVbnN1YnNjcmliZSBhbGwgaGFuZGxlcnMgZnJvbSBldmVudFxuICAgKiBjaGFubmVsLm9mZihcImV2ZW50XCIpXG4gICAqXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBldmVudFxuICAgKiBAcGFyYW0ge251bWJlcn0gW3JlZl1cbiAgICovXG4gIG9mZihldmVudCwgcmVmKXtcbiAgICB0aGlzLmJpbmRpbmdzID0gdGhpcy5iaW5kaW5ncy5maWx0ZXIoKGJpbmQpID0+IHtcbiAgICAgIHJldHVybiAhKGJpbmQuZXZlbnQgPT09IGV2ZW50ICYmICh0eXBlb2YgcmVmID09PSBcInVuZGVmaW5lZFwiIHx8IHJlZiA9PT0gYmluZC5yZWYpKVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIGNhblB1c2goKXsgcmV0dXJuIHRoaXMuc29ja2V0LmlzQ29ubmVjdGVkKCkgJiYgdGhpcy5pc0pvaW5lZCgpIH1cblxuICAvKipcbiAgICogU2VuZHMgYSBtZXNzYWdlIGBldmVudGAgdG8gcGhvZW5peCB3aXRoIHRoZSBwYXlsb2FkIGBwYXlsb2FkYC5cbiAgICogUGhvZW5peCByZWNlaXZlcyB0aGlzIGluIHRoZSBgaGFuZGxlX2luKGV2ZW50LCBwYXlsb2FkLCBzb2NrZXQpYFxuICAgKiBmdW5jdGlvbi4gaWYgcGhvZW5peCByZXBsaWVzIG9yIGl0IHRpbWVzIG91dCAoZGVmYXVsdCAxMDAwMG1zKSxcbiAgICogdGhlbiBvcHRpb25hbGx5IHRoZSByZXBseSBjYW4gYmUgcmVjZWl2ZWQuXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGNoYW5uZWwucHVzaChcImV2ZW50XCIpXG4gICAqICAgLnJlY2VpdmUoXCJva1wiLCBwYXlsb2FkID0+IGNvbnNvbGUubG9nKFwicGhvZW5peCByZXBsaWVkOlwiLCBwYXlsb2FkKSlcbiAgICogICAucmVjZWl2ZShcImVycm9yXCIsIGVyciA9PiBjb25zb2xlLmxvZyhcInBob2VuaXggZXJyb3JlZFwiLCBlcnIpKVxuICAgKiAgIC5yZWNlaXZlKFwidGltZW91dFwiLCAoKSA9PiBjb25zb2xlLmxvZyhcInRpbWVkIG91dCBwdXNoaW5nXCIpKVxuICAgKiBAcGFyYW0ge3N0cmluZ30gZXZlbnRcbiAgICogQHBhcmFtIHtPYmplY3R9IHBheWxvYWRcbiAgICogQHBhcmFtIHtudW1iZXJ9IFt0aW1lb3V0XVxuICAgKiBAcmV0dXJucyB7UHVzaH1cbiAgICovXG4gIHB1c2goZXZlbnQsIHBheWxvYWQsIHRpbWVvdXQgPSB0aGlzLnRpbWVvdXQpe1xuICAgIHBheWxvYWQgPSBwYXlsb2FkIHx8IHt9XG4gICAgaWYoIXRoaXMuam9pbmVkT25jZSl7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYHRyaWVkIHRvIHB1c2ggJyR7ZXZlbnR9JyB0byAnJHt0aGlzLnRvcGljfScgYmVmb3JlIGpvaW5pbmcuIFVzZSBjaGFubmVsLmpvaW4oKSBiZWZvcmUgcHVzaGluZyBldmVudHNgKVxuICAgIH1cbiAgICBsZXQgcHVzaEV2ZW50ID0gbmV3IFB1c2godGhpcywgZXZlbnQsIGZ1bmN0aW9uICgpeyByZXR1cm4gcGF5bG9hZCB9LCB0aW1lb3V0KVxuICAgIGlmKHRoaXMuY2FuUHVzaCgpKXtcbiAgICAgIHB1c2hFdmVudC5zZW5kKClcbiAgICB9IGVsc2Uge1xuICAgICAgcHVzaEV2ZW50LnN0YXJ0VGltZW91dCgpXG4gICAgICB0aGlzLnB1c2hCdWZmZXIucHVzaChwdXNoRXZlbnQpXG4gICAgfVxuXG4gICAgcmV0dXJuIHB1c2hFdmVudFxuICB9XG5cbiAgLyoqIExlYXZlcyB0aGUgY2hhbm5lbFxuICAgKlxuICAgKiBVbnN1YnNjcmliZXMgZnJvbSBzZXJ2ZXIgZXZlbnRzLCBhbmRcbiAgICogaW5zdHJ1Y3RzIGNoYW5uZWwgdG8gdGVybWluYXRlIG9uIHNlcnZlclxuICAgKlxuICAgKiBUcmlnZ2VycyBvbkNsb3NlKCkgaG9va3NcbiAgICpcbiAgICogVG8gcmVjZWl2ZSBsZWF2ZSBhY2tub3dsZWRnZW1lbnRzLCB1c2UgdGhlIGByZWNlaXZlYFxuICAgKiBob29rIHRvIGJpbmQgdG8gdGhlIHNlcnZlciBhY2ssIGllOlxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBjaGFubmVsLmxlYXZlKCkucmVjZWl2ZShcIm9rXCIsICgpID0+IGFsZXJ0KFwibGVmdCFcIikgKVxuICAgKlxuICAgKiBAcGFyYW0ge251bWJlcn0gdGltZW91dFxuICAgKiBAcmV0dXJucyB7UHVzaH1cbiAgICovXG4gIGxlYXZlKHRpbWVvdXQgPSB0aGlzLnRpbWVvdXQpe1xuICAgIHRoaXMucmVqb2luVGltZXIucmVzZXQoKVxuICAgIHRoaXMuam9pblB1c2guY2FuY2VsVGltZW91dCgpXG5cbiAgICB0aGlzLnN0YXRlID0gQ0hBTk5FTF9TVEFURVMubGVhdmluZ1xuICAgIGxldCBvbkNsb3NlID0gKCkgPT4ge1xuICAgICAgaWYodGhpcy5zb2NrZXQuaGFzTG9nZ2VyKCkpIHRoaXMuc29ja2V0LmxvZyhcImNoYW5uZWxcIiwgYGxlYXZlICR7dGhpcy50b3BpY31gKVxuICAgICAgdGhpcy50cmlnZ2VyKENIQU5ORUxfRVZFTlRTLmNsb3NlLCBcImxlYXZlXCIpXG4gICAgfVxuICAgIGxldCBsZWF2ZVB1c2ggPSBuZXcgUHVzaCh0aGlzLCBDSEFOTkVMX0VWRU5UUy5sZWF2ZSwgY2xvc3VyZSh7fSksIHRpbWVvdXQpXG4gICAgbGVhdmVQdXNoLnJlY2VpdmUoXCJva1wiLCAoKSA9PiBvbkNsb3NlKCkpXG4gICAgICAucmVjZWl2ZShcInRpbWVvdXRcIiwgKCkgPT4gb25DbG9zZSgpKVxuICAgIGxlYXZlUHVzaC5zZW5kKClcbiAgICBpZighdGhpcy5jYW5QdXNoKCkpeyBsZWF2ZVB1c2gudHJpZ2dlcihcIm9rXCIsIHt9KSB9XG5cbiAgICByZXR1cm4gbGVhdmVQdXNoXG4gIH1cblxuICAvKipcbiAgICogT3ZlcnJpZGFibGUgbWVzc2FnZSBob29rXG4gICAqXG4gICAqIFJlY2VpdmVzIGFsbCBldmVudHMgZm9yIHNwZWNpYWxpemVkIG1lc3NhZ2UgaGFuZGxpbmdcbiAgICogYmVmb3JlIGRpc3BhdGNoaW5nIHRvIHRoZSBjaGFubmVsIGNhbGxiYWNrcy5cbiAgICpcbiAgICogTXVzdCByZXR1cm4gdGhlIHBheWxvYWQsIG1vZGlmaWVkIG9yIHVubW9kaWZpZWRcbiAgICogQHR5cGV7Q2hhbm5lbE9uTWVzc2FnZX1cbiAgICovXG4gIG9uTWVzc2FnZShfZXZlbnQsIHBheWxvYWQsIF9yZWYpeyByZXR1cm4gcGF5bG9hZCB9XG5cbiAgLyoqXG4gICAqIE92ZXJyaWRhYmxlIGZpbHRlciBob29rXG4gICAqXG4gICAqIElmIHRoaXMgZnVuY3Rpb24gcmV0dXJucyBgdHJ1ZWAsIGBiaW5kaW5nYCdzIGNhbGxiYWNrIHdpbGwgYmUgY2FsbGVkLlxuICAgKlxuICAgKiBAdHlwZXtDaGFubmVsRmlsdGVyQmluZGluZ3N9XG4gICAqL1xuICBmaWx0ZXJCaW5kaW5ncyhfYmluZGluZywgX3BheWxvYWQsIF9yZWYpeyByZXR1cm4gdHJ1ZSB9XG5cbiAgaXNNZW1iZXIodG9waWMsIGV2ZW50LCBwYXlsb2FkLCBqb2luUmVmKXtcbiAgICBpZih0aGlzLnRvcGljICE9PSB0b3BpYyl7IHJldHVybiBmYWxzZSB9XG5cbiAgICBpZihqb2luUmVmICYmIGpvaW5SZWYgIT09IHRoaXMuam9pblJlZigpKXtcbiAgICAgIGlmKHRoaXMuc29ja2V0Lmhhc0xvZ2dlcigpKSB0aGlzLnNvY2tldC5sb2coXCJjaGFubmVsXCIsIFwiZHJvcHBpbmcgb3V0ZGF0ZWQgbWVzc2FnZVwiLCB7dG9waWMsIGV2ZW50LCBwYXlsb2FkLCBqb2luUmVmfSlcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgfVxuXG4gIGpvaW5SZWYoKXsgcmV0dXJuIHRoaXMuam9pblB1c2gucmVmIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIHJlam9pbih0aW1lb3V0ID0gdGhpcy50aW1lb3V0KXtcbiAgICBpZih0aGlzLmlzTGVhdmluZygpKXsgcmV0dXJuIH1cbiAgICB0aGlzLnNvY2tldC5sZWF2ZU9wZW5Ub3BpYyh0aGlzLnRvcGljKVxuICAgIHRoaXMuc3RhdGUgPSBDSEFOTkVMX1NUQVRFUy5qb2luaW5nXG4gICAgdGhpcy5qb2luUHVzaC5yZXNlbmQodGltZW91dClcbiAgfVxuXG4gIC8qKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gZXZlbnRcbiAgICogQHBhcmFtIHt1bmtub3dufSBbcGF5bG9hZF1cbiAgICogQHBhcmFtIHs/c3RyaW5nfSBbcmVmXVxuICAgKiBAcGFyYW0gez9zdHJpbmd9IFtqb2luUmVmXVxuICAgKi9cbiAgdHJpZ2dlcihldmVudCwgcGF5bG9hZCwgcmVmLCBqb2luUmVmKXtcbiAgICBsZXQgaGFuZGxlZFBheWxvYWQgPSB0aGlzLm9uTWVzc2FnZShldmVudCwgcGF5bG9hZCwgcmVmLCBqb2luUmVmKVxuICAgIGlmKHBheWxvYWQgJiYgIWhhbmRsZWRQYXlsb2FkKXsgdGhyb3cgbmV3IEVycm9yKFwiY2hhbm5lbCBvbk1lc3NhZ2UgY2FsbGJhY2tzIG11c3QgcmV0dXJuIHRoZSBwYXlsb2FkLCBtb2RpZmllZCBvciB1bm1vZGlmaWVkXCIpIH1cblxuICAgIGxldCBldmVudEJpbmRpbmdzID0gdGhpcy5iaW5kaW5ncy5maWx0ZXIoYmluZCA9PiBiaW5kLmV2ZW50ID09PSBldmVudCAmJiB0aGlzLmZpbHRlckJpbmRpbmdzKGJpbmQsIHBheWxvYWQsIHJlZikpXG5cbiAgICBmb3IobGV0IGkgPSAwOyBpIDwgZXZlbnRCaW5kaW5ncy5sZW5ndGg7IGkrKyl7XG4gICAgICBsZXQgYmluZCA9IGV2ZW50QmluZGluZ3NbaV1cbiAgICAgIGJpbmQuY2FsbGJhY2soaGFuZGxlZFBheWxvYWQsIHJlZiwgam9pblJlZiB8fCB0aGlzLmpvaW5SZWYoKSlcbiAgICB9XG4gIH1cblxuICAvKipcbiAgKiBAcGFyYW0ge3N0cmluZ30gcmVmXG4gICovXG4gIHJlcGx5RXZlbnROYW1lKHJlZil7IHJldHVybiBgY2hhbl9yZXBseV8ke3JlZn1gIH1cblxuICBpc0Nsb3NlZCgpeyByZXR1cm4gdGhpcy5zdGF0ZSA9PT0gQ0hBTk5FTF9TVEFURVMuY2xvc2VkIH1cblxuICBpc0Vycm9yZWQoKXsgcmV0dXJuIHRoaXMuc3RhdGUgPT09IENIQU5ORUxfU1RBVEVTLmVycm9yZWQgfVxuXG4gIGlzSm9pbmVkKCl7IHJldHVybiB0aGlzLnN0YXRlID09PSBDSEFOTkVMX1NUQVRFUy5qb2luZWQgfVxuXG4gIGlzSm9pbmluZygpeyByZXR1cm4gdGhpcy5zdGF0ZSA9PT0gQ0hBTk5FTF9TVEFURVMuam9pbmluZyB9XG5cbiAgaXNMZWF2aW5nKCl7IHJldHVybiB0aGlzLnN0YXRlID09PSBDSEFOTkVMX1NUQVRFUy5sZWF2aW5nIH1cbn1cbiIsImltcG9ydCB7XG4gIGdsb2JhbCxcbiAgWEhSX1NUQVRFU1xufSBmcm9tIFwiLi9jb25zdGFudHNcIlxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBBamF4IHtcblxuICBzdGF0aWMgcmVxdWVzdChtZXRob2QsIGVuZFBvaW50LCBoZWFkZXJzLCBib2R5LCB0aW1lb3V0LCBvbnRpbWVvdXQsIGNhbGxiYWNrKXtcbiAgICBpZihnbG9iYWwuWERvbWFpblJlcXVlc3Qpe1xuICAgICAgbGV0IHJlcSA9IG5ldyBnbG9iYWwuWERvbWFpblJlcXVlc3QoKSAvLyBJRTgsIElFOVxuICAgICAgcmV0dXJuIHRoaXMueGRvbWFpblJlcXVlc3QocmVxLCBtZXRob2QsIGVuZFBvaW50LCBib2R5LCB0aW1lb3V0LCBvbnRpbWVvdXQsIGNhbGxiYWNrKVxuICAgIH0gZWxzZSBpZihnbG9iYWwuWE1MSHR0cFJlcXVlc3Qpe1xuICAgICAgbGV0IHJlcSA9IG5ldyBnbG9iYWwuWE1MSHR0cFJlcXVlc3QoKSAvLyBJRTcrLCBGaXJlZm94LCBDaHJvbWUsIE9wZXJhLCBTYWZhcmlcbiAgICAgIHJldHVybiB0aGlzLnhoclJlcXVlc3QocmVxLCBtZXRob2QsIGVuZFBvaW50LCBoZWFkZXJzLCBib2R5LCB0aW1lb3V0LCBvbnRpbWVvdXQsIGNhbGxiYWNrKVxuICAgIH0gZWxzZSBpZihnbG9iYWwuZmV0Y2ggJiYgZ2xvYmFsLkFib3J0Q29udHJvbGxlcil7XG4gICAgICAvLyBGZXRjaCB3aXRoIEFib3J0Q29udHJvbGxlciBmb3IgbW9kZXJuIGJyb3dzZXJzXG4gICAgICByZXR1cm4gdGhpcy5mZXRjaFJlcXVlc3QobWV0aG9kLCBlbmRQb2ludCwgaGVhZGVycywgYm9keSwgdGltZW91dCwgb250aW1lb3V0LCBjYWxsYmFjaylcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gc3VpdGFibGUgWE1MSHR0cFJlcXVlc3QgaW1wbGVtZW50YXRpb24gZm91bmRcIilcbiAgICB9XG4gIH1cblxuICBzdGF0aWMgZmV0Y2hSZXF1ZXN0KG1ldGhvZCwgZW5kUG9pbnQsIGhlYWRlcnMsIGJvZHksIHRpbWVvdXQsIG9udGltZW91dCwgY2FsbGJhY2spe1xuICAgIGxldCBvcHRpb25zID0ge1xuICAgICAgbWV0aG9kLFxuICAgICAgaGVhZGVycyxcbiAgICAgIGJvZHksXG4gICAgfVxuICAgIGxldCBjb250cm9sbGVyID0gbnVsbFxuICAgIGlmKHRpbWVvdXQpe1xuICAgICAgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxuICAgICAgY29uc3QgX3RpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCB0aW1lb3V0KVxuICAgICAgb3B0aW9ucy5zaWduYWwgPSBjb250cm9sbGVyLnNpZ25hbFxuICAgIH1cbiAgICBnbG9iYWwuZmV0Y2goZW5kUG9pbnQsIG9wdGlvbnMpXG4gICAgICAudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS50ZXh0KCkpXG4gICAgICAudGhlbihkYXRhID0+IHRoaXMucGFyc2VKU09OKGRhdGEpKVxuICAgICAgLnRoZW4oZGF0YSA9PiBjYWxsYmFjayAmJiBjYWxsYmFjayhkYXRhKSlcbiAgICAgIC5jYXRjaChlcnIgPT4ge1xuICAgICAgICBpZihlcnIubmFtZSA9PT0gXCJBYm9ydEVycm9yXCIgJiYgb250aW1lb3V0KXtcbiAgICAgICAgICBvbnRpbWVvdXQoKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKG51bGwpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgcmV0dXJuIGNvbnRyb2xsZXJcbiAgfVxuXG4gIHN0YXRpYyB4ZG9tYWluUmVxdWVzdChyZXEsIG1ldGhvZCwgZW5kUG9pbnQsIGJvZHksIHRpbWVvdXQsIG9udGltZW91dCwgY2FsbGJhY2spe1xuICAgIHJlcS50aW1lb3V0ID0gdGltZW91dFxuICAgIHJlcS5vcGVuKG1ldGhvZCwgZW5kUG9pbnQpXG4gICAgcmVxLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgIGxldCByZXNwb25zZSA9IHRoaXMucGFyc2VKU09OKHJlcS5yZXNwb25zZVRleHQpXG4gICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhyZXNwb25zZSlcbiAgICB9XG4gICAgaWYob250aW1lb3V0KXsgcmVxLm9udGltZW91dCA9IG9udGltZW91dCB9XG5cbiAgICAvLyBXb3JrIGFyb3VuZCBidWcgaW4gSUU5IHRoYXQgcmVxdWlyZXMgYW4gYXR0YWNoZWQgb25wcm9ncmVzcyBoYW5kbGVyXG4gICAgcmVxLm9ucHJvZ3Jlc3MgPSAoKSA9PiB7IH1cblxuICAgIHJlcS5zZW5kKGJvZHkpXG4gICAgcmV0dXJuIHJlcVxuICB9XG5cbiAgc3RhdGljIHhoclJlcXVlc3QocmVxLCBtZXRob2QsIGVuZFBvaW50LCBoZWFkZXJzLCBib2R5LCB0aW1lb3V0LCBvbnRpbWVvdXQsIGNhbGxiYWNrKXtcbiAgICByZXEub3BlbihtZXRob2QsIGVuZFBvaW50LCB0cnVlKVxuICAgIHJlcS50aW1lb3V0ID0gdGltZW91dFxuICAgIGZvcihsZXQgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGhlYWRlcnMpKXtcbiAgICAgIHJlcS5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgdmFsdWUpXG4gICAgfVxuICAgIHJlcS5vbmVycm9yID0gKCkgPT4gY2FsbGJhY2sgJiYgY2FsbGJhY2sobnVsbClcbiAgICByZXEub25yZWFkeXN0YXRlY2hhbmdlID0gKCkgPT4ge1xuICAgICAgaWYocmVxLnJlYWR5U3RhdGUgPT09IFhIUl9TVEFURVMuY29tcGxldGUgJiYgY2FsbGJhY2spe1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSB0aGlzLnBhcnNlSlNPTihyZXEucmVzcG9uc2VUZXh0KVxuICAgICAgICBjYWxsYmFjayhyZXNwb25zZSlcbiAgICAgIH1cbiAgICB9XG4gICAgaWYob250aW1lb3V0KXsgcmVxLm9udGltZW91dCA9IG9udGltZW91dCB9XG5cbiAgICByZXEuc2VuZChib2R5KVxuICAgIHJldHVybiByZXFcbiAgfVxuXG4gIHN0YXRpYyBwYXJzZUpTT04ocmVzcCl7XG4gICAgaWYoIXJlc3AgfHwgcmVzcCA9PT0gXCJcIil7IHJldHVybiBudWxsIH1cblxuICAgIHRyeSB7XG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShyZXNwKVxuICAgIH0gY2F0Y2gge1xuICAgICAgY29uc29sZSAmJiBjb25zb2xlLmxvZyhcImZhaWxlZCB0byBwYXJzZSBKU09OIHJlc3BvbnNlXCIsIHJlc3ApXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyBzZXJpYWxpemUob2JqLCBwYXJlbnRLZXkpe1xuICAgIGxldCBxdWVyeVN0ciA9IFtdXG4gICAgZm9yKHZhciBrZXkgaW4gb2JqKXtcbiAgICAgIGlmKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrZXkpKXsgY29udGludWUgfVxuICAgICAgbGV0IHBhcmFtS2V5ID0gcGFyZW50S2V5ID8gYCR7cGFyZW50S2V5fVske2tleX1dYCA6IGtleVxuICAgICAgbGV0IHBhcmFtVmFsID0gb2JqW2tleV1cbiAgICAgIGlmKHR5cGVvZiBwYXJhbVZhbCA9PT0gXCJvYmplY3RcIil7XG4gICAgICAgIHF1ZXJ5U3RyLnB1c2godGhpcy5zZXJpYWxpemUocGFyYW1WYWwsIHBhcmFtS2V5KSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHF1ZXJ5U3RyLnB1c2goZW5jb2RlVVJJQ29tcG9uZW50KHBhcmFtS2V5KSArIFwiPVwiICsgZW5jb2RlVVJJQ29tcG9uZW50KHBhcmFtVmFsKSlcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHF1ZXJ5U3RyLmpvaW4oXCImXCIpXG4gIH1cblxuICBzdGF0aWMgYXBwZW5kUGFyYW1zKHVybCwgcGFyYW1zKXtcbiAgICBpZihPYmplY3Qua2V5cyhwYXJhbXMpLmxlbmd0aCA9PT0gMCl7IHJldHVybiB1cmwgfVxuXG4gICAgbGV0IHByZWZpeCA9IHVybC5tYXRjaCgvXFw/LykgPyBcIiZcIiA6IFwiP1wiXG4gICAgcmV0dXJuIGAke3VybH0ke3ByZWZpeH0ke3RoaXMuc2VyaWFsaXplKHBhcmFtcyl9YFxuICB9XG59XG4iLCJpbXBvcnQge1xuICBTT0NLRVRfU1RBVEVTLFxuICBUUkFOU1BPUlRTLFxuICBBVVRIX1RPS0VOX1BSRUZJWFxufSBmcm9tIFwiLi9jb25zdGFudHNcIlxuXG5pbXBvcnQgQWpheCBmcm9tIFwiLi9hamF4XCJcblxubGV0IGFycmF5QnVmZmVyVG9CYXNlNjQgPSAoYnVmZmVyKSA9PiB7XG4gIGxldCBiaW5hcnkgPSBcIlwiXG4gIGxldCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlcilcbiAgbGV0IGxlbiA9IGJ5dGVzLmJ5dGVMZW5ndGhcbiAgZm9yKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKXsgYmluYXJ5ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYnl0ZXNbaV0pIH1cbiAgcmV0dXJuIGJ0b2EoYmluYXJ5KVxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMb25nUG9sbCB7XG5cbiAgY29uc3RydWN0b3IoZW5kUG9pbnQsIHByb3RvY29scyl7XG4gICAgLy8gd2Ugb25seSBzdXBwb3J0IHN1YnByb3RvY29scyBmb3IgYXV0aFRva2VuXG4gICAgLy8gW1wicGhvZW5peFwiLCBcImJhc2U2NHVybC5iZWFyZXIucGh4LkJBU0U2NF9FTkNPREVEX1RPS0VOXCJdXG4gICAgaWYocHJvdG9jb2xzICYmIHByb3RvY29scy5sZW5ndGggPT09IDIgJiYgcHJvdG9jb2xzWzFdLnN0YXJ0c1dpdGgoQVVUSF9UT0tFTl9QUkVGSVgpKXtcbiAgICAgIHRoaXMuYXV0aFRva2VuID0gYXRvYihwcm90b2NvbHNbMV0uc2xpY2UoQVVUSF9UT0tFTl9QUkVGSVgubGVuZ3RoKSlcbiAgICB9XG4gICAgdGhpcy5lbmRQb2ludCA9IG51bGxcbiAgICB0aGlzLnRva2VuID0gbnVsbFxuICAgIHRoaXMuc2tpcEhlYXJ0YmVhdCA9IHRydWVcbiAgICB0aGlzLnJlcXMgPSBuZXcgU2V0KClcbiAgICB0aGlzLmF3YWl0aW5nQmF0Y2hBY2sgPSBmYWxzZVxuICAgIHRoaXMuY3VycmVudEJhdGNoID0gbnVsbFxuICAgIHRoaXMuY3VycmVudEJhdGNoVGltZXIgPSBudWxsXG4gICAgdGhpcy5iYXRjaEJ1ZmZlciA9IFtdXG4gICAgdGhpcy5vbm9wZW4gPSBmdW5jdGlvbiAoKXsgfSAvLyBub29wXG4gICAgdGhpcy5vbmVycm9yID0gZnVuY3Rpb24gKCl7IH0gLy8gbm9vcFxuICAgIHRoaXMub25tZXNzYWdlID0gZnVuY3Rpb24gKCl7IH0gLy8gbm9vcFxuICAgIHRoaXMub25jbG9zZSA9IGZ1bmN0aW9uICgpeyB9IC8vIG5vb3BcbiAgICB0aGlzLnBvbGxFbmRwb2ludCA9IHRoaXMubm9ybWFsaXplRW5kcG9pbnQoZW5kUG9pbnQpXG4gICAgdGhpcy5yZWFkeVN0YXRlID0gU09DS0VUX1NUQVRFUy5jb25uZWN0aW5nXG4gICAgLy8gd2UgbXVzdCB3YWl0IGZvciB0aGUgY2FsbGVyIHRvIGZpbmlzaCBzZXR0aW5nIHVwIG91ciBjYWxsYmFja3MgYW5kIHRpbWVvdXQgcHJvcGVydGllc1xuICAgIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5wb2xsKCksIDApXG4gIH1cblxuICBub3JtYWxpemVFbmRwb2ludChlbmRQb2ludCl7XG4gICAgcmV0dXJuIChlbmRQb2ludFxuICAgICAgLnJlcGxhY2UoXCJ3czovL1wiLCBcImh0dHA6Ly9cIilcbiAgICAgIC5yZXBsYWNlKFwid3NzOi8vXCIsIFwiaHR0cHM6Ly9cIilcbiAgICAgIC5yZXBsYWNlKG5ldyBSZWdFeHAoXCIoLiopXFwvXCIgKyBUUkFOU1BPUlRTLndlYnNvY2tldCksIFwiJDEvXCIgKyBUUkFOU1BPUlRTLmxvbmdwb2xsKSlcbiAgfVxuXG4gIGVuZHBvaW50VVJMKCl7XG4gICAgcmV0dXJuIEFqYXguYXBwZW5kUGFyYW1zKHRoaXMucG9sbEVuZHBvaW50LCB7dG9rZW46IHRoaXMudG9rZW59KVxuICB9XG5cbiAgY2xvc2VBbmRSZXRyeShjb2RlLCByZWFzb24sIHdhc0NsZWFuKXtcbiAgICB0aGlzLmNsb3NlKGNvZGUsIHJlYXNvbiwgd2FzQ2xlYW4pXG4gICAgdGhpcy5yZWFkeVN0YXRlID0gU09DS0VUX1NUQVRFUy5jb25uZWN0aW5nXG4gIH1cblxuICBvbnRpbWVvdXQoKXtcbiAgICB0aGlzLm9uZXJyb3IoXCJ0aW1lb3V0XCIpXG4gICAgdGhpcy5jbG9zZUFuZFJldHJ5KDEwMDUsIFwidGltZW91dFwiLCBmYWxzZSlcbiAgfVxuXG4gIGlzQWN0aXZlKCl7IHJldHVybiB0aGlzLnJlYWR5U3RhdGUgPT09IFNPQ0tFVF9TVEFURVMub3BlbiB8fCB0aGlzLnJlYWR5U3RhdGUgPT09IFNPQ0tFVF9TVEFURVMuY29ubmVjdGluZyB9XG5cbiAgcG9sbCgpe1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XCJBY2NlcHRcIjogXCJhcHBsaWNhdGlvbi9qc29uXCJ9XG4gICAgaWYodGhpcy5hdXRoVG9rZW4pe1xuICAgICAgaGVhZGVyc1tcIlgtUGhvZW5peC1BdXRoVG9rZW5cIl0gPSB0aGlzLmF1dGhUb2tlblxuICAgIH1cbiAgICB0aGlzLmFqYXgoXCJHRVRcIiwgaGVhZGVycywgbnVsbCwgKCkgPT4gdGhpcy5vbnRpbWVvdXQoKSwgcmVzcCA9PiB7XG4gICAgICBpZihyZXNwKXtcbiAgICAgICAgdmFyIHtzdGF0dXMsIHRva2VuLCBtZXNzYWdlc30gPSByZXNwXG4gICAgICAgIGlmKHN0YXR1cyA9PT0gNDEwICYmIHRoaXMudG9rZW4gIT09IG51bGwpe1xuICAgICAgICAgIC8vIEluIGNhc2Ugd2UgYWxyZWFkeSBoYXZlIGEgdG9rZW4sIHRoaXMgbWVhbnMgdGhhdCBvdXIgZXhpc3Rpbmcgc2Vzc2lvblxuICAgICAgICAgIC8vIGlzIGdvbmUuIFdlIGZhaWwgc28gdGhhdCB0aGUgY2xpZW50IHJlam9pbnMgaXRzIGNoYW5uZWxzLlxuICAgICAgICAgIHRoaXMub25lcnJvcig0MTApXG4gICAgICAgICAgdGhpcy5jbG9zZUFuZFJldHJ5KDM0MTAsIFwic2Vzc2lvbl9nb25lXCIsIGZhbHNlKVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIHRoaXMudG9rZW4gPSB0b2tlblxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhdHVzID0gMFxuICAgICAgfVxuXG4gICAgICBzd2l0Y2goc3RhdHVzKXtcbiAgICAgICAgY2FzZSAyMDA6XG4gICAgICAgICAgbWVzc2FnZXMuZm9yRWFjaChtc2cgPT4ge1xuICAgICAgICAgICAgLy8gVGFza3MgYXJlIHdoYXQgdGhpbmdzIGxpa2UgZXZlbnQgaGFuZGxlcnMsIHNldFRpbWVvdXQgY2FsbGJhY2tzLFxuICAgICAgICAgICAgLy8gcHJvbWlzZSByZXNvbHZlcyBhbmQgbW9yZSBhcmUgcnVuIHdpdGhpbi5cbiAgICAgICAgICAgIC8vIEluIG1vZGVybiBicm93c2VycywgdGhlcmUgYXJlIHR3byBkaWZmZXJlbnQga2luZHMgb2YgdGFza3MsXG4gICAgICAgICAgICAvLyBtaWNyb3Rhc2tzIGFuZCBtYWNyb3Rhc2tzLlxuICAgICAgICAgICAgLy8gTWljcm90YXNrcyBhcmUgbWFpbmx5IHVzZWQgZm9yIFByb21pc2VzLCB3aGlsZSBtYWNyb3Rhc2tzIGFyZVxuICAgICAgICAgICAgLy8gdXNlZCBmb3IgZXZlcnl0aGluZyBlbHNlLlxuICAgICAgICAgICAgLy8gTWljcm90YXNrcyBhbHdheXMgaGF2ZSBwcmlvcml0eSBvdmVyIG1hY3JvdGFza3MuIElmIHRoZSBKUyBlbmdpbmVcbiAgICAgICAgICAgIC8vIGlzIGxvb2tpbmcgZm9yIGEgdGFzayB0byBydW4sIGl0IHdpbGwgYWx3YXlzIHRyeSB0byBlbXB0eSB0aGVcbiAgICAgICAgICAgIC8vIG1pY3JvdGFzayBxdWV1ZSBiZWZvcmUgYXR0ZW1wdGluZyB0byBydW4gYW55dGhpbmcgZnJvbSB0aGVcbiAgICAgICAgICAgIC8vIG1hY3JvdGFzayBxdWV1ZS5cbiAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAvLyBGb3IgdGhlIFdlYlNvY2tldCB0cmFuc3BvcnQsIG1lc3NhZ2VzIGFsd2F5cyBhcnJpdmUgaW4gdGhlaXIgb3duXG4gICAgICAgICAgICAvLyBldmVudC4gVGhpcyBtZWFucyB0aGF0IGlmIGFueSBwcm9taXNlcyBhcmUgcmVzb2x2ZWQgZnJvbSB3aXRoaW4sXG4gICAgICAgICAgICAvLyB0aGVpciBjYWxsYmFja3Mgd2lsbCBhbHdheXMgZmluaXNoIGV4ZWN1dGlvbiBieSB0aGUgdGltZSB0aGVcbiAgICAgICAgICAgIC8vIG5leHQgbWVzc2FnZSBldmVudCBoYW5kbGVyIGlzIHJ1bi5cbiAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAvLyBJbiBvcmRlciB0byBlbXVsYXRlIHRoaXMgYmVoYXZpb3VyLCB3ZSBuZWVkIHRvIG1ha2Ugc3VyZSBlYWNoXG4gICAgICAgICAgICAvLyBvbm1lc3NhZ2UgaGFuZGxlciBpcyBydW4gd2l0aGluIGl0cyBvd24gbWFjcm90YXNrLlxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB0aGlzLm9ubWVzc2FnZSh7ZGF0YTogbXNnfSksIDApXG4gICAgICAgICAgfSlcbiAgICAgICAgICB0aGlzLnBvbGwoKVxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIGNhc2UgMjA0OlxuICAgICAgICAgIHRoaXMucG9sbCgpXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSA0MTA6XG4gICAgICAgICAgdGhpcy5yZWFkeVN0YXRlID0gU09DS0VUX1NUQVRFUy5vcGVuXG4gICAgICAgICAgdGhpcy5vbm9wZW4oe30pXG4gICAgICAgICAgdGhpcy5wb2xsKClcbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlIDQwMzpcbiAgICAgICAgICB0aGlzLm9uZXJyb3IoNDAzKVxuICAgICAgICAgIHRoaXMuY2xvc2UoMTAwOCwgXCJmb3JiaWRkZW5cIiwgZmFsc2UpXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAwOlxuICAgICAgICBjYXNlIDUwMDpcbiAgICAgICAgICB0aGlzLm9uZXJyb3IoNTAwKVxuICAgICAgICAgIHRoaXMuY2xvc2VBbmRSZXRyeSgxMDExLCBcImludGVybmFsIHNlcnZlciBlcnJvclwiLCA1MDApXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgZGVmYXVsdDogdGhyb3cgbmV3IEVycm9yKGB1bmhhbmRsZWQgcG9sbCBzdGF0dXMgJHtzdGF0dXN9YClcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgLy8gd2UgY29sbGVjdCBhbGwgcHVzaGVzIHdpdGhpbiB0aGUgY3VycmVudCBldmVudCBsb29wIGJ5XG4gIC8vIHNldFRpbWVvdXQgMCwgd2hpY2ggb3B0aW1pemVzIGJhY2stdG8tYmFjayBwcm9jZWR1cmFsXG4gIC8vIHB1c2hlcyBhZ2FpbnN0IGFuIGVtcHR5IGJ1ZmZlclxuXG4gIHNlbmQoYm9keSl7XG4gICAgaWYodHlwZW9mKGJvZHkpICE9PSBcInN0cmluZ1wiKXsgYm9keSA9IGFycmF5QnVmZmVyVG9CYXNlNjQoYm9keSkgfVxuICAgIGlmKHRoaXMuY3VycmVudEJhdGNoKXtcbiAgICAgIHRoaXMuY3VycmVudEJhdGNoLnB1c2goYm9keSlcbiAgICB9IGVsc2UgaWYodGhpcy5hd2FpdGluZ0JhdGNoQWNrKXtcbiAgICAgIHRoaXMuYmF0Y2hCdWZmZXIucHVzaChib2R5KVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmN1cnJlbnRCYXRjaCA9IFtib2R5XVxuICAgICAgdGhpcy5jdXJyZW50QmF0Y2hUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLmJhdGNoU2VuZCh0aGlzLmN1cnJlbnRCYXRjaClcbiAgICAgICAgdGhpcy5jdXJyZW50QmF0Y2ggPSBudWxsXG4gICAgICB9LCAwKVxuICAgIH1cbiAgfVxuXG4gIGJhdGNoU2VuZChtZXNzYWdlcyl7XG4gICAgdGhpcy5hd2FpdGluZ0JhdGNoQWNrID0gdHJ1ZVxuICAgIHRoaXMuYWpheChcIlBPU1RcIiwge1wiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24veC1uZGpzb25cIn0sIG1lc3NhZ2VzLmpvaW4oXCJcXG5cIiksICgpID0+IHRoaXMub25lcnJvcihcInRpbWVvdXRcIiksIHJlc3AgPT4ge1xuICAgICAgdGhpcy5hd2FpdGluZ0JhdGNoQWNrID0gZmFsc2VcbiAgICAgIGlmKCFyZXNwIHx8IHJlc3Auc3RhdHVzICE9PSAyMDApe1xuICAgICAgICB0aGlzLm9uZXJyb3IocmVzcCAmJiByZXNwLnN0YXR1cylcbiAgICAgICAgdGhpcy5jbG9zZUFuZFJldHJ5KDEwMTEsIFwiaW50ZXJuYWwgc2VydmVyIGVycm9yXCIsIGZhbHNlKVxuICAgICAgfSBlbHNlIGlmKHRoaXMuYmF0Y2hCdWZmZXIubGVuZ3RoID4gMCl7XG4gICAgICAgIHRoaXMuYmF0Y2hTZW5kKHRoaXMuYmF0Y2hCdWZmZXIpXG4gICAgICAgIHRoaXMuYmF0Y2hCdWZmZXIgPSBbXVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBjbG9zZShjb2RlLCByZWFzb24sIHdhc0NsZWFuKXtcbiAgICBmb3IobGV0IHJlcSBvZiB0aGlzLnJlcXMpeyByZXEuYWJvcnQoKSB9XG4gICAgdGhpcy5yZWFkeVN0YXRlID0gU09DS0VUX1NUQVRFUy5jbG9zZWRcbiAgICBsZXQgb3B0cyA9IE9iamVjdC5hc3NpZ24oe2NvZGU6IDEwMDAsIHJlYXNvbjogdW5kZWZpbmVkLCB3YXNDbGVhbjogdHJ1ZX0sIHtjb2RlLCByZWFzb24sIHdhc0NsZWFufSlcbiAgICB0aGlzLmJhdGNoQnVmZmVyID0gW11cbiAgICBjbGVhclRpbWVvdXQodGhpcy5jdXJyZW50QmF0Y2hUaW1lcilcbiAgICB0aGlzLmN1cnJlbnRCYXRjaFRpbWVyID0gbnVsbFxuICAgIGlmKHR5cGVvZihDbG9zZUV2ZW50KSAhPT0gXCJ1bmRlZmluZWRcIil7XG4gICAgICB0aGlzLm9uY2xvc2UobmV3IENsb3NlRXZlbnQoXCJjbG9zZVwiLCBvcHRzKSlcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5vbmNsb3NlKG9wdHMpXG4gICAgfVxuICB9XG5cbiAgYWpheChtZXRob2QsIGhlYWRlcnMsIGJvZHksIG9uQ2FsbGVyVGltZW91dCwgY2FsbGJhY2spe1xuICAgIGxldCByZXFcbiAgICBsZXQgb250aW1lb3V0ID0gKCkgPT4ge1xuICAgICAgdGhpcy5yZXFzLmRlbGV0ZShyZXEpXG4gICAgICBvbkNhbGxlclRpbWVvdXQoKVxuICAgIH1cbiAgICByZXEgPSBBamF4LnJlcXVlc3QobWV0aG9kLCB0aGlzLmVuZHBvaW50VVJMKCksIGhlYWRlcnMsIGJvZHksIHRoaXMudGltZW91dCwgb250aW1lb3V0LCByZXNwID0+IHtcbiAgICAgIHRoaXMucmVxcy5kZWxldGUocmVxKVxuICAgICAgaWYodGhpcy5pc0FjdGl2ZSgpKXsgY2FsbGJhY2socmVzcCkgfVxuICAgIH0pXG4gICAgdGhpcy5yZXFzLmFkZChyZXEpXG4gIH1cbn1cbiIsIi8qKlxuICogQGltcG9ydCBDaGFubmVsIGZyb20gXCIuL2NoYW5uZWxcIlxuICogQGltcG9ydCB7IFByZXNlbmNlRXZlbnRzLCBQcmVzZW5jZU9uSm9pbiwgUHJlc2VuY2VPbkxlYXZlLCBQcmVzZW5jZU9uU3luYywgUHJlc2VuY2VTdGF0ZSwgUHJlc2VuY2VEaWZmLCBQcmVzZW5jZU9wdGlvbnMgfSBmcm9tIFwiLi90eXBlc1wiXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFByZXNlbmNlIHtcblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIFByZXNlbmNlXG4gICAqIEBwYXJhbSB7Q2hhbm5lbH0gY2hhbm5lbCAtIFRoZSBDaGFubmVsXG4gICAqIEBwYXJhbSB7UHJlc2VuY2VPcHRpb25zfSBbb3B0c10gLSBUaGUgb3B0aW9ucywgZm9yIGV4YW1wbGUgYHtldmVudHM6IHtzdGF0ZTogXCJzdGF0ZVwiLCBkaWZmOiBcImRpZmZcIn19YFxuICAgKi9cbiAgY29uc3RydWN0b3IoY2hhbm5lbCwgb3B0cyA9IHt9KXtcbiAgICBsZXQgZXZlbnRzID0gb3B0cy5ldmVudHMgfHwgLyoqIEB0eXBlIHtQcmVzZW5jZUV2ZW50c30gKi8gKHtzdGF0ZTogXCJwcmVzZW5jZV9zdGF0ZVwiLCBkaWZmOiBcInByZXNlbmNlX2RpZmZcIn0pXG4gICAgLyoqIEB0eXBle1JlY29yZDxzdHJpbmcsIFByZXNlbmNlU3RhdGU+fSAqL1xuICAgIHRoaXMuc3RhdGUgPSB7fVxuICAgIC8qKiBAdHlwZXtQcmVzZW5jZURpZmZbXX0gKi9cbiAgICB0aGlzLnBlbmRpbmdEaWZmcyA9IFtdXG4gICAgLyoqIEB0eXBle0NoYW5uZWx9ICovXG4gICAgdGhpcy5jaGFubmVsID0gY2hhbm5lbFxuICAgIC8qKiBAdHlwZXs/bnVtYmVyfSAqL1xuICAgIHRoaXMuam9pblJlZiA9IG51bGxcbiAgICAvKiogQHR5cGV7KHsgb25Kb2luOiBQcmVzZW5jZU9uSm9pbjsgb25MZWF2ZTogUHJlc2VuY2VPbkxlYXZlOyBvblN5bmM6IFByZXNlbmNlT25TeW5jIH0pfSAqL1xuICAgIHRoaXMuY2FsbGVyID0ge1xuICAgICAgb25Kb2luOiBmdW5jdGlvbiAoKXsgfSxcbiAgICAgIG9uTGVhdmU6IGZ1bmN0aW9uICgpeyB9LFxuICAgICAgb25TeW5jOiBmdW5jdGlvbiAoKXsgfVxuICAgIH1cblxuICAgIHRoaXMuY2hhbm5lbC5vbihldmVudHMuc3RhdGUsIG5ld1N0YXRlID0+IHtcbiAgICAgIGxldCB7b25Kb2luLCBvbkxlYXZlLCBvblN5bmN9ID0gdGhpcy5jYWxsZXJcblxuICAgICAgdGhpcy5qb2luUmVmID0gdGhpcy5jaGFubmVsLmpvaW5SZWYoKVxuICAgICAgdGhpcy5zdGF0ZSA9IFByZXNlbmNlLnN5bmNTdGF0ZSh0aGlzLnN0YXRlLCBuZXdTdGF0ZSwgb25Kb2luLCBvbkxlYXZlKVxuXG4gICAgICB0aGlzLnBlbmRpbmdEaWZmcy5mb3JFYWNoKGRpZmYgPT4ge1xuICAgICAgICB0aGlzLnN0YXRlID0gUHJlc2VuY2Uuc3luY0RpZmYodGhpcy5zdGF0ZSwgZGlmZiwgb25Kb2luLCBvbkxlYXZlKVxuICAgICAgfSlcbiAgICAgIHRoaXMucGVuZGluZ0RpZmZzID0gW11cbiAgICAgIG9uU3luYygpXG4gICAgfSlcblxuICAgIHRoaXMuY2hhbm5lbC5vbihldmVudHMuZGlmZiwgZGlmZiA9PiB7XG4gICAgICBsZXQge29uSm9pbiwgb25MZWF2ZSwgb25TeW5jfSA9IHRoaXMuY2FsbGVyXG5cbiAgICAgIGlmKHRoaXMuaW5QZW5kaW5nU3luY1N0YXRlKCkpe1xuICAgICAgICB0aGlzLnBlbmRpbmdEaWZmcy5wdXNoKGRpZmYpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnN0YXRlID0gUHJlc2VuY2Uuc3luY0RpZmYodGhpcy5zdGF0ZSwgZGlmZiwgb25Kb2luLCBvbkxlYXZlKVxuICAgICAgICBvblN5bmMoKVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQHBhcmFtIHtQcmVzZW5jZU9uSm9pbn0gY2FsbGJhY2tcbiAgICovXG4gIG9uSm9pbihjYWxsYmFjayl7IHRoaXMuY2FsbGVyLm9uSm9pbiA9IGNhbGxiYWNrIH1cblxuICAvKipcbiAgICogQHBhcmFtIHtQcmVzZW5jZU9uTGVhdmV9IGNhbGxiYWNrXG4gICAqL1xuICBvbkxlYXZlKGNhbGxiYWNrKXsgdGhpcy5jYWxsZXIub25MZWF2ZSA9IGNhbGxiYWNrIH1cblxuICAvKipcbiAgICogQHBhcmFtIHtQcmVzZW5jZU9uU3luY30gY2FsbGJhY2tcbiAgICovXG4gIG9uU3luYyhjYWxsYmFjayl7IHRoaXMuY2FsbGVyLm9uU3luYyA9IGNhbGxiYWNrIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXJyYXkgb2YgcHJlc2VuY2VzLCB3aXRoIHNlbGVjdGVkIG1ldGFkYXRhLlxuICAgKlxuICAgKiBAdGVtcGxhdGUgW1Q9UHJlc2VuY2VTdGF0ZV1cbiAgICogQHBhcmFtIHsoKGtleTogc3RyaW5nLCBvYmo6IFByZXNlbmNlU3RhdGUpID0+IFQpfSBbYnldXG4gICAqXG4gICAqIEByZXR1cm5zIHtUW119XG4gICAqL1xuICBsaXN0KGJ5KXsgcmV0dXJuIFByZXNlbmNlLmxpc3QodGhpcy5zdGF0ZSwgYnkpIH1cblxuICBpblBlbmRpbmdTeW5jU3RhdGUoKXtcbiAgICByZXR1cm4gIXRoaXMuam9pblJlZiB8fCAodGhpcy5qb2luUmVmICE9PSB0aGlzLmNoYW5uZWwuam9pblJlZigpKVxuICB9XG5cbiAgLy8gbG93ZXItbGV2ZWwgcHVibGljIHN0YXRpYyBBUElcblxuICAvKipcbiAgICogVXNlZCB0byBzeW5jIHRoZSBsaXN0IG9mIHByZXNlbmNlcyBvbiB0aGUgc2VydmVyXG4gICAqIHdpdGggdGhlIGNsaWVudCdzIHN0YXRlLiBBbiBvcHRpb25hbCBgb25Kb2luYCBhbmQgYG9uTGVhdmVgIGNhbGxiYWNrIGNhblxuICAgKiBiZSBwcm92aWRlZCB0byByZWFjdCB0byBjaGFuZ2VzIGluIHRoZSBjbGllbnQncyBsb2NhbCBwcmVzZW5jZXMgYWNyb3NzXG4gICAqIGRpc2Nvbm5lY3RzIGFuZCByZWNvbm5lY3RzIHdpdGggdGhlIHNlcnZlci5cbiAgICpcbiAgICogQHBhcmFtIHtSZWNvcmQ8c3RyaW5nLCBQcmVzZW5jZVN0YXRlPn0gY3VycmVudFN0YXRlXG4gICAqIEBwYXJhbSB7UmVjb3JkPHN0cmluZywgUHJlc2VuY2VTdGF0ZT59IG5ld1N0YXRlXG4gICAqIEBwYXJhbSB7UHJlc2VuY2VPbkpvaW59IG9uSm9pblxuICAgKiBAcGFyYW0ge1ByZXNlbmNlT25MZWF2ZX0gb25MZWF2ZVxuICAgKlxuICAgKiBAcmV0dXJucyB7UmVjb3JkPHN0cmluZywgUHJlc2VuY2VTdGF0ZT59XG4gICAqL1xuICBzdGF0aWMgc3luY1N0YXRlKGN1cnJlbnRTdGF0ZSwgbmV3U3RhdGUsIG9uSm9pbiwgb25MZWF2ZSl7XG4gICAgbGV0IHN0YXRlID0gdGhpcy5jbG9uZShjdXJyZW50U3RhdGUpXG4gICAgbGV0IGpvaW5zID0ge31cbiAgICBsZXQgbGVhdmVzID0ge31cblxuICAgIHRoaXMubWFwKHN0YXRlLCAoa2V5LCBwcmVzZW5jZSkgPT4ge1xuICAgICAgaWYoIW5ld1N0YXRlW2tleV0pe1xuICAgICAgICBsZWF2ZXNba2V5XSA9IHByZXNlbmNlXG4gICAgICB9XG4gICAgfSlcbiAgICB0aGlzLm1hcChuZXdTdGF0ZSwgKGtleSwgbmV3UHJlc2VuY2UpID0+IHtcbiAgICAgIGxldCBjdXJyZW50UHJlc2VuY2UgPSBzdGF0ZVtrZXldXG4gICAgICBpZihjdXJyZW50UHJlc2VuY2Upe1xuICAgICAgICBsZXQgbmV3UmVmcyA9IG5ld1ByZXNlbmNlLm1ldGFzLm1hcChtID0+IG0ucGh4X3JlZilcbiAgICAgICAgbGV0IGN1clJlZnMgPSBjdXJyZW50UHJlc2VuY2UubWV0YXMubWFwKG0gPT4gbS5waHhfcmVmKVxuICAgICAgICBsZXQgam9pbmVkTWV0YXMgPSBuZXdQcmVzZW5jZS5tZXRhcy5maWx0ZXIobSA9PiBjdXJSZWZzLmluZGV4T2YobS5waHhfcmVmKSA8IDApXG4gICAgICAgIGxldCBsZWZ0TWV0YXMgPSBjdXJyZW50UHJlc2VuY2UubWV0YXMuZmlsdGVyKG0gPT4gbmV3UmVmcy5pbmRleE9mKG0ucGh4X3JlZikgPCAwKVxuICAgICAgICBpZihqb2luZWRNZXRhcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICBqb2luc1trZXldID0gbmV3UHJlc2VuY2VcbiAgICAgICAgICBqb2luc1trZXldLm1ldGFzID0gam9pbmVkTWV0YXNcbiAgICAgICAgfVxuICAgICAgICBpZihsZWZ0TWV0YXMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgbGVhdmVzW2tleV0gPSB0aGlzLmNsb25lKGN1cnJlbnRQcmVzZW5jZSlcbiAgICAgICAgICBsZWF2ZXNba2V5XS5tZXRhcyA9IGxlZnRNZXRhc1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBqb2luc1trZXldID0gbmV3UHJlc2VuY2VcbiAgICAgIH1cbiAgICB9KVxuICAgIHJldHVybiB0aGlzLnN5bmNEaWZmKHN0YXRlLCB7am9pbnM6IGpvaW5zLCBsZWF2ZXM6IGxlYXZlc30sIG9uSm9pbiwgb25MZWF2ZSlcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBVc2VkIHRvIHN5bmMgYSBkaWZmIG9mIHByZXNlbmNlIGpvaW4gYW5kIGxlYXZlXG4gICAqIGV2ZW50cyBmcm9tIHRoZSBzZXJ2ZXIsIGFzIHRoZXkgaGFwcGVuLiBMaWtlIGBzeW5jU3RhdGVgLCBgc3luY0RpZmZgXG4gICAqIGFjY2VwdHMgb3B0aW9uYWwgYG9uSm9pbmAgYW5kIGBvbkxlYXZlYCBjYWxsYmFja3MgdG8gcmVhY3QgdG8gYSB1c2VyXG4gICAqIGpvaW5pbmcgb3IgbGVhdmluZyBmcm9tIGEgZGV2aWNlLlxuICAgKlxuICAgKiBAcGFyYW0ge1JlY29yZDxzdHJpbmcsIFByZXNlbmNlU3RhdGU+fSBzdGF0ZVxuICAgKiBAcGFyYW0ge1ByZXNlbmNlRGlmZn0gZGlmZlxuICAgKiBAcGFyYW0ge1ByZXNlbmNlT25Kb2lufSBvbkpvaW5cbiAgICogQHBhcmFtIHtQcmVzZW5jZU9uTGVhdmV9IG9uTGVhdmVcbiAgICpcbiAgICogQHJldHVybnMge1JlY29yZDxzdHJpbmcsIFByZXNlbmNlU3RhdGU+fVxuICAgKi9cbiAgc3RhdGljIHN5bmNEaWZmKHN0YXRlLCBkaWZmLCBvbkpvaW4sIG9uTGVhdmUpe1xuICAgIGxldCB7am9pbnMsIGxlYXZlc30gPSB0aGlzLmNsb25lKGRpZmYpXG4gICAgaWYoIW9uSm9pbil7IG9uSm9pbiA9IGZ1bmN0aW9uICgpeyB9IH1cbiAgICBpZighb25MZWF2ZSl7IG9uTGVhdmUgPSBmdW5jdGlvbiAoKXsgfSB9XG5cbiAgICB0aGlzLm1hcChqb2lucywgKGtleSwgbmV3UHJlc2VuY2UpID0+IHtcbiAgICAgIGxldCBjdXJyZW50UHJlc2VuY2UgPSBzdGF0ZVtrZXldXG4gICAgICBzdGF0ZVtrZXldID0gdGhpcy5jbG9uZShuZXdQcmVzZW5jZSlcbiAgICAgIGlmKGN1cnJlbnRQcmVzZW5jZSl7XG4gICAgICAgIGxldCBqb2luZWRSZWZzID0gc3RhdGVba2V5XS5tZXRhcy5tYXAobSA9PiBtLnBoeF9yZWYpXG4gICAgICAgIGxldCBjdXJNZXRhcyA9IGN1cnJlbnRQcmVzZW5jZS5tZXRhcy5maWx0ZXIobSA9PiBqb2luZWRSZWZzLmluZGV4T2YobS5waHhfcmVmKSA8IDApXG4gICAgICAgIHN0YXRlW2tleV0ubWV0YXMudW5zaGlmdCguLi5jdXJNZXRhcylcbiAgICAgIH1cbiAgICAgIG9uSm9pbihrZXksIGN1cnJlbnRQcmVzZW5jZSwgbmV3UHJlc2VuY2UpXG4gICAgfSlcbiAgICB0aGlzLm1hcChsZWF2ZXMsIChrZXksIGxlZnRQcmVzZW5jZSkgPT4ge1xuICAgICAgbGV0IGN1cnJlbnRQcmVzZW5jZSA9IHN0YXRlW2tleV1cbiAgICAgIGlmKCFjdXJyZW50UHJlc2VuY2UpeyByZXR1cm4gfVxuICAgICAgbGV0IHJlZnNUb1JlbW92ZSA9IGxlZnRQcmVzZW5jZS5tZXRhcy5tYXAobSA9PiBtLnBoeF9yZWYpXG4gICAgICBjdXJyZW50UHJlc2VuY2UubWV0YXMgPSBjdXJyZW50UHJlc2VuY2UubWV0YXMuZmlsdGVyKHAgPT4ge1xuICAgICAgICByZXR1cm4gcmVmc1RvUmVtb3ZlLmluZGV4T2YocC5waHhfcmVmKSA8IDBcbiAgICAgIH0pXG4gICAgICBvbkxlYXZlKGtleSwgY3VycmVudFByZXNlbmNlLCBsZWZ0UHJlc2VuY2UpXG4gICAgICBpZihjdXJyZW50UHJlc2VuY2UubWV0YXMubGVuZ3RoID09PSAwKXtcbiAgICAgICAgZGVsZXRlIHN0YXRlW2tleV1cbiAgICAgIH1cbiAgICB9KVxuICAgIHJldHVybiBzdGF0ZVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFycmF5IG9mIHByZXNlbmNlcywgd2l0aCBzZWxlY3RlZCBtZXRhZGF0YS5cbiAgICpcbiAgICogQHRlbXBsYXRlIFtUPVByZXNlbmNlU3RhdGVdXG4gICAqIEBwYXJhbSB7UmVjb3JkPHN0cmluZywgUHJlc2VuY2VTdGF0ZT59IHByZXNlbmNlc1xuICAgKiBAcGFyYW0geygoa2V5OiBzdHJpbmcsIG9iajogUHJlc2VuY2VTdGF0ZSkgPT4gVCl9IFtjaG9vc2VyXVxuICAgKlxuICAgKiBAcmV0dXJucyB7VFtdfVxuICAgKi9cbiAgc3RhdGljIGxpc3QocHJlc2VuY2VzLCBjaG9vc2VyKXtcbiAgICBpZighY2hvb3Nlcil7IGNob29zZXIgPSBmdW5jdGlvbiAoa2V5LCBwcmVzKXsgcmV0dXJuIHByZXMgfSB9XG5cbiAgICByZXR1cm4gdGhpcy5tYXAocHJlc2VuY2VzLCAoa2V5LCBwcmVzZW5jZSkgPT4ge1xuICAgICAgcmV0dXJuIGNob29zZXIoa2V5LCBwcmVzZW5jZSlcbiAgICB9KVxuICB9XG5cbiAgLy8gcHJpdmF0ZVxuXG4gIC8qKlxuICAqIEB0ZW1wbGF0ZSBUXG4gICogQHBhcmFtIHtSZWNvcmQ8c3RyaW5nLCBQcmVzZW5jZVN0YXRlPn0gb2JqXG4gICogQHBhcmFtIHsoa2V5OiBzdHJpbmcsIG9iajogUHJlc2VuY2VTdGF0ZSkgPT4gVH0gZnVuY1xuICAqL1xuICBzdGF0aWMgbWFwKG9iaiwgZnVuYyl7XG4gICAgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKG9iaikubWFwKGtleSA9PiBmdW5jKGtleSwgb2JqW2tleV0pKVxuICB9XG5cbiAgLyoqXG4gICogQHRlbXBsYXRlIFRcbiAgKiBAcGFyYW0ge1R9IG9ialxuICAqIEByZXR1cm5zIHtUfVxuICAqL1xuICBzdGF0aWMgY2xvbmUob2JqKXsgcmV0dXJuIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkob2JqKSkgfVxufVxuIiwiLyogVGhlIGRlZmF1bHQgc2VyaWFsaXplciBmb3IgZW5jb2RpbmcgYW5kIGRlY29kaW5nIG1lc3NhZ2VzICovXG5pbXBvcnQge1xuICBDSEFOTkVMX0VWRU5UU1xufSBmcm9tIFwiLi9jb25zdGFudHNcIlxuXG4vKipcbiAqIEBpbXBvcnQgeyBNZXNzYWdlIH0gZnJvbSBcIi4vdHlwZXNcIlxuICovXG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgSEVBREVSX0xFTkdUSDogMSxcbiAgTUVUQV9MRU5HVEg6IDQsXG4gIEtJTkRTOiB7cHVzaDogMCwgcmVwbHk6IDEsIGJyb2FkY2FzdDogMn0sXG5cbiAgLyoqXG4gICogQHRlbXBsYXRlIFRcbiAgKiBAcGFyYW0ge01lc3NhZ2U8UmVjb3JkPHN0cmluZywgYW55Pj59IG1zZ1xuICAqIEBwYXJhbSB7KG1zZzogQXJyYXlCdWZmZXIgfCBzdHJpbmcpID0+IFR9IGNhbGxiYWNrXG4gICogQHJldHVybnMge1R9XG4gICovXG4gIGVuY29kZShtc2csIGNhbGxiYWNrKXtcbiAgICBpZihtc2cucGF5bG9hZC5jb25zdHJ1Y3RvciA9PT0gQXJyYXlCdWZmZXIpe1xuICAgICAgcmV0dXJuIGNhbGxiYWNrKHRoaXMuYmluYXJ5RW5jb2RlKG1zZykpXG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCBwYXlsb2FkID0gW21zZy5qb2luX3JlZiwgbXNnLnJlZiwgbXNnLnRvcGljLCBtc2cuZXZlbnQsIG1zZy5wYXlsb2FkXVxuICAgICAgcmV0dXJuIGNhbGxiYWNrKEpTT04uc3RyaW5naWZ5KHBheWxvYWQpKVxuICAgIH1cbiAgfSxcblxuICAvKipcbiAgKiBAdGVtcGxhdGUgVFxuICAqIEBwYXJhbSB7QXJyYXlCdWZmZXIgfCBzdHJpbmd9IHJhd1BheWxvYWRcbiAgKiBAcGFyYW0geyhtc2c6IE1lc3NhZ2U8dW5rbm93bj4pID0+IFR9IGNhbGxiYWNrXG4gICogQHJldHVybnMge1R9XG4gICovXG4gIGRlY29kZShyYXdQYXlsb2FkLCBjYWxsYmFjayl7XG4gICAgaWYocmF3UGF5bG9hZC5jb25zdHJ1Y3RvciA9PT0gQXJyYXlCdWZmZXIpe1xuICAgICAgcmV0dXJuIGNhbGxiYWNrKHRoaXMuYmluYXJ5RGVjb2RlKHJhd1BheWxvYWQpKVxuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgW2pvaW5fcmVmLCByZWYsIHRvcGljLCBldmVudCwgcGF5bG9hZF0gPSBKU09OLnBhcnNlKHJhd1BheWxvYWQpXG4gICAgICByZXR1cm4gY2FsbGJhY2soe2pvaW5fcmVmLCByZWYsIHRvcGljLCBldmVudCwgcGF5bG9hZH0pXG4gICAgfVxuICB9LFxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBiaW5hcnlFbmNvZGUobWVzc2FnZSl7XG4gICAgbGV0IHtqb2luX3JlZiwgcmVmLCBldmVudCwgdG9waWMsIHBheWxvYWR9ID0gbWVzc2FnZVxuICAgIGxldCBtZXRhTGVuZ3RoID0gdGhpcy5NRVRBX0xFTkdUSCArIGpvaW5fcmVmLmxlbmd0aCArIHJlZi5sZW5ndGggKyB0b3BpYy5sZW5ndGggKyBldmVudC5sZW5ndGhcbiAgICBsZXQgaGVhZGVyID0gbmV3IEFycmF5QnVmZmVyKHRoaXMuSEVBREVSX0xFTkdUSCArIG1ldGFMZW5ndGgpXG4gICAgbGV0IHZpZXcgPSBuZXcgRGF0YVZpZXcoaGVhZGVyKVxuICAgIGxldCBvZmZzZXQgPSAwXG5cbiAgICB2aWV3LnNldFVpbnQ4KG9mZnNldCsrLCB0aGlzLktJTkRTLnB1c2gpIC8vIGtpbmRcbiAgICB2aWV3LnNldFVpbnQ4KG9mZnNldCsrLCBqb2luX3JlZi5sZW5ndGgpXG4gICAgdmlldy5zZXRVaW50OChvZmZzZXQrKywgcmVmLmxlbmd0aClcbiAgICB2aWV3LnNldFVpbnQ4KG9mZnNldCsrLCB0b3BpYy5sZW5ndGgpXG4gICAgdmlldy5zZXRVaW50OChvZmZzZXQrKywgZXZlbnQubGVuZ3RoKVxuICAgIEFycmF5LmZyb20oam9pbl9yZWYsIGNoYXIgPT4gdmlldy5zZXRVaW50OChvZmZzZXQrKywgY2hhci5jaGFyQ29kZUF0KDApKSlcbiAgICBBcnJheS5mcm9tKHJlZiwgY2hhciA9PiB2aWV3LnNldFVpbnQ4KG9mZnNldCsrLCBjaGFyLmNoYXJDb2RlQXQoMCkpKVxuICAgIEFycmF5LmZyb20odG9waWMsIGNoYXIgPT4gdmlldy5zZXRVaW50OChvZmZzZXQrKywgY2hhci5jaGFyQ29kZUF0KDApKSlcbiAgICBBcnJheS5mcm9tKGV2ZW50LCBjaGFyID0+IHZpZXcuc2V0VWludDgob2Zmc2V0KyssIGNoYXIuY2hhckNvZGVBdCgwKSkpXG5cbiAgICB2YXIgY29tYmluZWQgPSBuZXcgVWludDhBcnJheShoZWFkZXIuYnl0ZUxlbmd0aCArIHBheWxvYWQuYnl0ZUxlbmd0aClcbiAgICBjb21iaW5lZC5zZXQobmV3IFVpbnQ4QXJyYXkoaGVhZGVyKSwgMClcbiAgICBjb21iaW5lZC5zZXQobmV3IFVpbnQ4QXJyYXkocGF5bG9hZCksIGhlYWRlci5ieXRlTGVuZ3RoKVxuXG4gICAgcmV0dXJuIGNvbWJpbmVkLmJ1ZmZlclxuICB9LFxuXG4gIC8qKlxuICAqIEBwcml2YXRlXG4gICovXG4gIGJpbmFyeURlY29kZShidWZmZXIpe1xuICAgIGxldCB2aWV3ID0gbmV3IERhdGFWaWV3KGJ1ZmZlcilcbiAgICBsZXQga2luZCA9IHZpZXcuZ2V0VWludDgoMClcbiAgICBsZXQgZGVjb2RlciA9IG5ldyBUZXh0RGVjb2RlcigpXG4gICAgc3dpdGNoKGtpbmQpe1xuICAgICAgY2FzZSB0aGlzLktJTkRTLnB1c2g6IHJldHVybiB0aGlzLmRlY29kZVB1c2goYnVmZmVyLCB2aWV3LCBkZWNvZGVyKVxuICAgICAgY2FzZSB0aGlzLktJTkRTLnJlcGx5OiByZXR1cm4gdGhpcy5kZWNvZGVSZXBseShidWZmZXIsIHZpZXcsIGRlY29kZXIpXG4gICAgICBjYXNlIHRoaXMuS0lORFMuYnJvYWRjYXN0OiByZXR1cm4gdGhpcy5kZWNvZGVCcm9hZGNhc3QoYnVmZmVyLCB2aWV3LCBkZWNvZGVyKVxuICAgIH1cbiAgfSxcblxuICAvKiogQHByaXZhdGUgKi9cbiAgZGVjb2RlUHVzaChidWZmZXIsIHZpZXcsIGRlY29kZXIpe1xuICAgIGxldCBqb2luUmVmU2l6ZSA9IHZpZXcuZ2V0VWludDgoMSlcbiAgICBsZXQgdG9waWNTaXplID0gdmlldy5nZXRVaW50OCgyKVxuICAgIGxldCBldmVudFNpemUgPSB2aWV3LmdldFVpbnQ4KDMpXG4gICAgbGV0IG9mZnNldCA9IHRoaXMuSEVBREVSX0xFTkdUSCArIHRoaXMuTUVUQV9MRU5HVEggLSAxIC8vIHB1c2hlcyBoYXZlIG5vIHJlZlxuICAgIGxldCBqb2luUmVmID0gZGVjb2Rlci5kZWNvZGUoYnVmZmVyLnNsaWNlKG9mZnNldCwgb2Zmc2V0ICsgam9pblJlZlNpemUpKVxuICAgIG9mZnNldCA9IG9mZnNldCArIGpvaW5SZWZTaXplXG4gICAgbGV0IHRvcGljID0gZGVjb2Rlci5kZWNvZGUoYnVmZmVyLnNsaWNlKG9mZnNldCwgb2Zmc2V0ICsgdG9waWNTaXplKSlcbiAgICBvZmZzZXQgPSBvZmZzZXQgKyB0b3BpY1NpemVcbiAgICBsZXQgZXZlbnQgPSBkZWNvZGVyLmRlY29kZShidWZmZXIuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBldmVudFNpemUpKVxuICAgIG9mZnNldCA9IG9mZnNldCArIGV2ZW50U2l6ZVxuICAgIGxldCBkYXRhID0gYnVmZmVyLnNsaWNlKG9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG4gICAgcmV0dXJuIHtqb2luX3JlZjogam9pblJlZiwgcmVmOiBudWxsLCB0b3BpYzogdG9waWMsIGV2ZW50OiBldmVudCwgcGF5bG9hZDogZGF0YX1cbiAgfSxcblxuICAvKiogQHByaXZhdGUgKi9cbiAgZGVjb2RlUmVwbHkoYnVmZmVyLCB2aWV3LCBkZWNvZGVyKXtcbiAgICBsZXQgam9pblJlZlNpemUgPSB2aWV3LmdldFVpbnQ4KDEpXG4gICAgbGV0IHJlZlNpemUgPSB2aWV3LmdldFVpbnQ4KDIpXG4gICAgbGV0IHRvcGljU2l6ZSA9IHZpZXcuZ2V0VWludDgoMylcbiAgICBsZXQgZXZlbnRTaXplID0gdmlldy5nZXRVaW50OCg0KVxuICAgIGxldCBvZmZzZXQgPSB0aGlzLkhFQURFUl9MRU5HVEggKyB0aGlzLk1FVEFfTEVOR1RIXG4gICAgbGV0IGpvaW5SZWYgPSBkZWNvZGVyLmRlY29kZShidWZmZXIuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBqb2luUmVmU2l6ZSkpXG4gICAgb2Zmc2V0ID0gb2Zmc2V0ICsgam9pblJlZlNpemVcbiAgICBsZXQgcmVmID0gZGVjb2Rlci5kZWNvZGUoYnVmZmVyLnNsaWNlKG9mZnNldCwgb2Zmc2V0ICsgcmVmU2l6ZSkpXG4gICAgb2Zmc2V0ID0gb2Zmc2V0ICsgcmVmU2l6ZVxuICAgIGxldCB0b3BpYyA9IGRlY29kZXIuZGVjb2RlKGJ1ZmZlci5zbGljZShvZmZzZXQsIG9mZnNldCArIHRvcGljU2l6ZSkpXG4gICAgb2Zmc2V0ID0gb2Zmc2V0ICsgdG9waWNTaXplXG4gICAgbGV0IGV2ZW50ID0gZGVjb2Rlci5kZWNvZGUoYnVmZmVyLnNsaWNlKG9mZnNldCwgb2Zmc2V0ICsgZXZlbnRTaXplKSlcbiAgICBvZmZzZXQgPSBvZmZzZXQgKyBldmVudFNpemVcbiAgICBsZXQgZGF0YSA9IGJ1ZmZlci5zbGljZShvZmZzZXQsIGJ1ZmZlci5ieXRlTGVuZ3RoKVxuICAgIGxldCBwYXlsb2FkID0ge3N0YXR1czogZXZlbnQsIHJlc3BvbnNlOiBkYXRhfVxuICAgIHJldHVybiB7am9pbl9yZWY6IGpvaW5SZWYsIHJlZjogcmVmLCB0b3BpYzogdG9waWMsIGV2ZW50OiBDSEFOTkVMX0VWRU5UUy5yZXBseSwgcGF5bG9hZDogcGF5bG9hZH1cbiAgfSxcblxuICAvKiogQHByaXZhdGUgKi9cbiAgZGVjb2RlQnJvYWRjYXN0KGJ1ZmZlciwgdmlldywgZGVjb2Rlcil7XG4gICAgbGV0IHRvcGljU2l6ZSA9IHZpZXcuZ2V0VWludDgoMSlcbiAgICBsZXQgZXZlbnRTaXplID0gdmlldy5nZXRVaW50OCgyKVxuICAgIGxldCBvZmZzZXQgPSB0aGlzLkhFQURFUl9MRU5HVEggKyAyXG4gICAgbGV0IHRvcGljID0gZGVjb2Rlci5kZWNvZGUoYnVmZmVyLnNsaWNlKG9mZnNldCwgb2Zmc2V0ICsgdG9waWNTaXplKSlcbiAgICBvZmZzZXQgPSBvZmZzZXQgKyB0b3BpY1NpemVcbiAgICBsZXQgZXZlbnQgPSBkZWNvZGVyLmRlY29kZShidWZmZXIuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBldmVudFNpemUpKVxuICAgIG9mZnNldCA9IG9mZnNldCArIGV2ZW50U2l6ZVxuICAgIGxldCBkYXRhID0gYnVmZmVyLnNsaWNlKG9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG5cbiAgICByZXR1cm4ge2pvaW5fcmVmOiBudWxsLCByZWY6IG51bGwsIHRvcGljOiB0b3BpYywgZXZlbnQ6IGV2ZW50LCBwYXlsb2FkOiBkYXRhfVxuICB9XG59XG4iLCJpbXBvcnQge1xuICBnbG9iYWwsXG4gIHBoeFdpbmRvdyxcbiAgQ0hBTk5FTF9FVkVOVFMsXG4gIERFRkFVTFRfVElNRU9VVCxcbiAgREVGQVVMVF9WU04sXG4gIFNPQ0tFVF9TVEFURVMsXG4gIFRSQU5TUE9SVFMsXG4gIFdTX0NMT1NFX05PUk1BTCxcbiAgQVVUSF9UT0tFTl9QUkVGSVhcbn0gZnJvbSBcIi4vY29uc3RhbnRzXCJcblxuaW1wb3J0IHtcbiAgY2xvc3VyZVxufSBmcm9tIFwiLi91dGlsc1wiXG5cbmltcG9ydCBBamF4IGZyb20gXCIuL2FqYXhcIlxuaW1wb3J0IENoYW5uZWwgZnJvbSBcIi4vY2hhbm5lbFwiXG5pbXBvcnQgTG9uZ1BvbGwgZnJvbSBcIi4vbG9uZ3BvbGxcIlxuaW1wb3J0IFNlcmlhbGl6ZXIgZnJvbSBcIi4vc2VyaWFsaXplclwiXG5pbXBvcnQgVGltZXIgZnJvbSBcIi4vdGltZXJcIlxuXG4vKipcbiogQGltcG9ydCB7IEVuY29kZSwgRGVjb2RlLCBNZXNzYWdlLCBWc24sIFNvY2tldFRyYW5zcG9ydCwgUGFyYW1zLCBTb2NrZXRPbk9wZW4sIFNvY2tldE9uQ2xvc2UsIFNvY2tldE9uRXJyb3IsIFNvY2tldE9uTWVzc2FnZSwgU29ja2V0T3B0aW9ucywgU29ja2V0U3RhdGVDaGFuZ2VDYWxsYmFja3MsIEhlYXJ0YmVhdENhbGxiYWNrIH0gZnJvbSBcIi4vdHlwZXNcIlxuKi9cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU29ja2V0IHtcbiAgLyoqIEluaXRpYWxpemVzIHRoZSBTb2NrZXQgKlxuICAgKlxuICAgKiBGb3IgSUU4IHN1cHBvcnQgdXNlIGFuIEVTNS1zaGltIChodHRwczovL2dpdGh1Yi5jb20vZXMtc2hpbXMvZXM1LXNoaW0pXG4gICAqXG4gICAqIEBjb25zdHJ1Y3RvclxuICAgKiBAcGFyYW0ge3N0cmluZ30gZW5kUG9pbnQgLSBUaGUgc3RyaW5nIFdlYlNvY2tldCBlbmRwb2ludCwgaWUsIGBcIndzOi8vZXhhbXBsZS5jb20vc29ja2V0XCJgLFxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYFwid3NzOi8vZXhhbXBsZS5jb21cImBcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBcIi9zb2NrZXRcImAgKGluaGVyaXRlZCBob3N0ICYgcHJvdG9jb2wpXG4gICAqIEBwYXJhbSB7U29ja2V0T3B0aW9uc30gW29wdHNdIC0gT3B0aW9uYWwgY29uZmlndXJhdGlvblxuICAgKi9cbiAgY29uc3RydWN0b3IoZW5kUG9pbnQsIG9wdHMgPSB7fSl7XG4gICAgLyoqIEB0eXBle1NvY2tldFN0YXRlQ2hhbmdlQ2FsbGJhY2tzfSAqL1xuICAgIHRoaXMuc3RhdGVDaGFuZ2VDYWxsYmFja3MgPSB7b3BlbjogW10sIGNsb3NlOiBbXSwgZXJyb3I6IFtdLCBtZXNzYWdlOiBbXX1cbiAgICAvKiogQHR5cGV7Q2hhbm5lbFtdfSAqL1xuICAgIHRoaXMuY2hhbm5lbHMgPSBbXVxuICAgIC8qKiBAdHlwZXsoKCkgPT4gdm9pZClbXX0gKi9cbiAgICB0aGlzLnNlbmRCdWZmZXIgPSBbXVxuICAgIC8qKiBAdHlwZXtudW1iZXJ9ICovXG4gICAgdGhpcy5yZWYgPSAwXG4gICAgLyoqIEB0eXBlez9zdHJpbmd9ICovXG4gICAgdGhpcy5mYWxsYmFja1JlZiA9IG51bGxcbiAgICAvKiogQHR5cGV7bnVtYmVyfSAqL1xuICAgIHRoaXMudGltZW91dCA9IG9wdHMudGltZW91dCB8fCBERUZBVUxUX1RJTUVPVVRcbiAgICAvKiogQHR5cGV7U29ja2V0VHJhbnNwb3J0fSAqL1xuICAgIHRoaXMudHJhbnNwb3J0ID0gb3B0cy50cmFuc3BvcnQgfHwgZ2xvYmFsLldlYlNvY2tldCB8fCBMb25nUG9sbFxuICAgIC8qKiBAdHlwZXtJbnN0YW5jZVR5cGU8U29ja2V0VHJhbnNwb3J0PiB8IHVuZGVmaW5lZCB8IG51bGx9ICovXG4gICAgdGhpcy5jb25uID0gdW5kZWZpbmVkXG4gICAgLyoqIEB0eXBle2Jvb2xlYW59ICovXG4gICAgdGhpcy5wcmltYXJ5UGFzc2VkSGVhbHRoQ2hlY2sgPSBmYWxzZVxuICAgIC8qKiBAdHlwZXtudW1iZXIgfCB1bmRlZmluZWR9ICovXG4gICAgdGhpcy5sb25nUG9sbEZhbGxiYWNrTXMgPSBvcHRzLmxvbmdQb2xsRmFsbGJhY2tNc1xuICAgIC8qKiBAdHlwZXtSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0Pn0gKi9cbiAgICB0aGlzLmZhbGxiYWNrVGltZXIgPSBudWxsXG4gICAgLy8gSW4gc29tZSBlbnZpcm9ubWVudHMgKHNhbmRib3hlZCBpZnJhbWVzIHdpdGhvdXQgYGFsbG93LXNhbWUtb3JpZ2luYCxcbiAgICAvLyBpbi1hcHAgd2Vidmlld3MsIFwiYmxvY2sgdGhpcmQtcGFydHkgc3RvcmFnZVwiIHByaXZhY3kgbW9kZXMpLCByZWFkaW5nXG4gICAgLy8gYGdsb2JhbC5zZXNzaW9uU3RvcmFnZWAgdGhyb3dzIFNlY3VyaXR5RXJyb3IgYXQgdGhlIHByb3BlcnR5LWFjY2VzcyBsZXZlbC5cbiAgICAvLyBXcmFwIHRoZSByZWFkIHNvIHRoZSBTb2NrZXQgY29uc3RydWN0b3IgY2Fubm90IHRocm93IHN5bmNocm9ub3VzbHkuXG4gICAgbGV0IGVudlNlc3Npb25TdG9yYWdlID0gbnVsbFxuICAgIHRyeSB7IGVudlNlc3Npb25TdG9yYWdlID0gZ2xvYmFsICYmIGdsb2JhbC5zZXNzaW9uU3RvcmFnZSB9IGNhdGNoIHt9XG4gICAgLyoqIEB0eXBle1N0b3JhZ2V9ICovXG4gICAgdGhpcy5zZXNzaW9uU3RvcmUgPSBvcHRzLnNlc3Npb25TdG9yYWdlIHx8IGVudlNlc3Npb25TdG9yYWdlXG4gICAgLyoqIEB0eXBle251bWJlcn0gKi9cbiAgICB0aGlzLmVzdGFibGlzaGVkQ29ubmVjdGlvbnMgPSAwXG4gICAgLyoqIEB0eXBle0VuY29kZTx2b2lkPn0gKi9cbiAgICB0aGlzLmRlZmF1bHRFbmNvZGVyID0gU2VyaWFsaXplci5lbmNvZGUuYmluZChTZXJpYWxpemVyKVxuICAgIC8qKiBAdHlwZXtEZWNvZGU8dm9pZD59ICovXG4gICAgdGhpcy5kZWZhdWx0RGVjb2RlciA9IFNlcmlhbGl6ZXIuZGVjb2RlLmJpbmQoU2VyaWFsaXplcilcbiAgICAvLyBXZSBzdGFydCB3aXRoIGNsb3NlV2FzQ2xlYW4gdHJ1ZSB0byBhdm9pZCB0aGUgdmlzaWJpbGl0eSBjaGFuZ2VcbiAgICAvLyBsb2dpYyBmcm9tIGNvbm5lY3RpbmcgaWYgdGhlIHNvY2tldCB3YXMgbmV2ZXIgY29ubmVjdGVkIGluIHRoZSBmaXJzdCBwbGFjZS5cbiAgICAvLyB0cmFuc3BvcnRDb25uZWN0IHNldHMgaXQgdG8gZmFsc2Ugb24gb3Blbi5cbiAgICAvKiogQHR5cGV7Ym9vbGVhbn0gKi9cbiAgICB0aGlzLmNsb3NlV2FzQ2xlYW4gPSB0cnVlXG4gICAgLyoqIEB0eXBle2Jvb2xlYW59ICovXG4gICAgdGhpcy5kaXNjb25uZWN0aW5nID0gZmFsc2VcbiAgICAvKiogQHR5cGV7QmluYXJ5VHlwZX0gKi9cbiAgICB0aGlzLmJpbmFyeVR5cGUgPSBvcHRzLmJpbmFyeVR5cGUgfHwgXCJhcnJheWJ1ZmZlclwiXG4gICAgLyoqIEB0eXBle251bWJlcn0gKi9cbiAgICB0aGlzLmNvbm5lY3RDbG9jayA9IDFcbiAgICAvKiogQHR5cGV7Ym9vbGVhbn0gKi9cbiAgICB0aGlzLnBhZ2VIaWRkZW4gPSBmYWxzZVxuICAgIC8qKiBAdHlwZXtFbmNvZGU8dm9pZD59ICovXG4gICAgdGhpcy5lbmNvZGUgPSB1bmRlZmluZWRcbiAgICAvKiogQHR5cGV7RGVjb2RlPHZvaWQ+fSAqL1xuICAgIHRoaXMuZGVjb2RlID0gdW5kZWZpbmVkXG4gICAgaWYodGhpcy50cmFuc3BvcnQgIT09IExvbmdQb2xsKXtcbiAgICAgIHRoaXMuZW5jb2RlID0gb3B0cy5lbmNvZGUgfHwgdGhpcy5kZWZhdWx0RW5jb2RlclxuICAgICAgdGhpcy5kZWNvZGUgPSBvcHRzLmRlY29kZSB8fCB0aGlzLmRlZmF1bHREZWNvZGVyXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZW5jb2RlID0gdGhpcy5kZWZhdWx0RW5jb2RlclxuICAgICAgdGhpcy5kZWNvZGUgPSB0aGlzLmRlZmF1bHREZWNvZGVyXG4gICAgfVxuICAgIC8qKiBAdHlwZXtudW1iZXIgfCBudWxsfSAqL1xuICAgIGxldCBhd2FpdGluZ0Nvbm5lY3Rpb25PblBhZ2VTaG93ID0gbnVsbFxuICAgIGlmKHBoeFdpbmRvdyAmJiBwaHhXaW5kb3cuYWRkRXZlbnRMaXN0ZW5lcil7XG4gICAgICBwaHhXaW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIF9lID0+IHtcbiAgICAgICAgaWYodGhpcy5jb25uKXtcbiAgICAgICAgICB0aGlzLmRpc2Nvbm5lY3QoKVxuICAgICAgICAgIGF3YWl0aW5nQ29ubmVjdGlvbk9uUGFnZVNob3cgPSB0aGlzLmNvbm5lY3RDbG9ja1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgcGh4V2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwYWdlc2hvd1wiLCBfZSA9PiB7XG4gICAgICAgIGlmKGF3YWl0aW5nQ29ubmVjdGlvbk9uUGFnZVNob3cgPT09IHRoaXMuY29ubmVjdENsb2NrKXtcbiAgICAgICAgICBhd2FpdGluZ0Nvbm5lY3Rpb25PblBhZ2VTaG93ID0gbnVsbFxuICAgICAgICAgIHRoaXMuY29ubmVjdCgpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICBwaHhXaW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgICBpZihkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09IFwiaGlkZGVuXCIpe1xuICAgICAgICAgIHRoaXMucGFnZUhpZGRlbiA9IHRydWVcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLnBhZ2VIaWRkZW4gPSBmYWxzZVxuICAgICAgICAgIC8vIHJlY29ubmVjdCBpbW1lZGlhdGVseVxuICAgICAgICAgIGlmKCF0aGlzLmlzQ29ubmVjdGVkKCkgJiYgIXRoaXMuY2xvc2VXYXNDbGVhbil7XG4gICAgICAgICAgICB0aGlzLnRlYXJkb3duKCgpID0+IHRoaXMuY29ubmVjdCgpKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gICAgLyoqIEB0eXBle251bWJlcn0gKi9cbiAgICB0aGlzLmhlYXJ0YmVhdEludGVydmFsTXMgPSBvcHRzLmhlYXJ0YmVhdEludGVydmFsTXMgfHwgMzAwMDBcbiAgICAvKiogQHR5cGV7Ym9vbGVhbn0gKi9cbiAgICB0aGlzLmF1dG9TZW5kSGVhcnRiZWF0ID0gb3B0cy5hdXRvU2VuZEhlYXJ0YmVhdCA/PyB0cnVlXG4gICAgLyoqIEB0eXBle0hlYXJ0YmVhdENhbGxiYWNrfSAqL1xuICAgIHRoaXMuaGVhcnRiZWF0Q2FsbGJhY2sgPSBvcHRzLmhlYXJ0YmVhdENhbGxiYWNrID8/ICgoKSA9PiB7fSlcbiAgICAvKiogQHR5cGV7KHRyaWVzOiBudW1iZXIpID0+IG51bWJlcn0gKi9cbiAgICB0aGlzLnJlam9pbkFmdGVyTXMgPSAodHJpZXMpID0+IHtcbiAgICAgIGlmKG9wdHMucmVqb2luQWZ0ZXJNcyl7XG4gICAgICAgIHJldHVybiBvcHRzLnJlam9pbkFmdGVyTXModHJpZXMpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gWzEwMDAsIDIwMDAsIDUwMDBdW3RyaWVzIC0gMV0gfHwgMTAwMDBcbiAgICAgIH1cbiAgICB9XG4gICAgLyoqIEB0eXBleyh0cmllczogbnVtYmVyKSA9PiBudW1iZXJ9ICovXG4gICAgdGhpcy5yZWNvbm5lY3RBZnRlck1zID0gKHRyaWVzKSA9PiB7XG4gICAgICBpZihvcHRzLnJlY29ubmVjdEFmdGVyTXMpe1xuICAgICAgICByZXR1cm4gb3B0cy5yZWNvbm5lY3RBZnRlck1zKHRyaWVzKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFsxMCwgNTAsIDEwMCwgMTUwLCAyMDAsIDI1MCwgNTAwLCAxMDAwLCAyMDAwXVt0cmllcyAtIDFdIHx8IDUwMDBcbiAgICAgIH1cbiAgICB9XG4gICAgLyoqIEB0eXBleygoa2luZDogc3RyaW5nLCBtc2c6IHN0cmluZywgZGF0YTogYW55KSA9PiB2b2lkKSB8IG51bGx9ICovXG4gICAgdGhpcy5sb2dnZXIgPSBvcHRzLmxvZ2dlciB8fCBudWxsXG4gICAgaWYoIXRoaXMubG9nZ2VyICYmIG9wdHMuZGVidWcpe1xuICAgICAgdGhpcy5sb2dnZXIgPSAoa2luZCwgbXNnLCBkYXRhKSA9PiB7IGNvbnNvbGUubG9nKGAke2tpbmR9OiAke21zZ31gLCBkYXRhKSB9XG4gICAgfVxuICAgIC8qKiBAdHlwZXtudW1iZXJ9ICovXG4gICAgdGhpcy5sb25ncG9sbGVyVGltZW91dCA9IG9wdHMubG9uZ3BvbGxlclRpbWVvdXQgfHwgMjAwMDBcbiAgICAvKiogQHR5cGV7KCkgPT4gUGFyYW1zfSAqL1xuICAgIHRoaXMucGFyYW1zID0gY2xvc3VyZShvcHRzLnBhcmFtcyB8fCB7fSlcbiAgICAvKiogQHR5cGV7c3RyaW5nfSAqL1xuICAgIHRoaXMuZW5kUG9pbnQgPSBgJHtlbmRQb2ludH0vJHtUUkFOU1BPUlRTLndlYnNvY2tldH1gXG4gICAgLyoqIEB0eXBle1Zzbn0gKi9cbiAgICB0aGlzLnZzbiA9IG9wdHMudnNuIHx8IERFRkFVTFRfVlNOXG4gICAgLyoqIEB0eXBle1JldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+fSAqL1xuICAgIHRoaXMuaGVhcnRiZWF0VGltZW91dFRpbWVyID0gbnVsbFxuICAgIC8qKiBAdHlwZXtSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0Pn0gKi9cbiAgICB0aGlzLmhlYXJ0YmVhdFRpbWVyID0gbnVsbFxuICAgIC8qKiBAdHlwZXtudW1iZXIgfCBudWxsfSAqL1xuICAgIHRoaXMuaGVhcnRiZWF0U2VudEF0ID0gbnVsbFxuICAgIC8qKiBAdHlwZXs/c3RyaW5nfSAqL1xuICAgIHRoaXMucGVuZGluZ0hlYXJ0YmVhdFJlZiA9IG51bGxcbiAgICAvKiogQHR5cGV7VGltZXJ9ICovXG4gICAgdGhpcy5yZWNvbm5lY3RUaW1lciA9IG5ldyBUaW1lciggKCkgPT4ge1xuICAgICAgaWYodGhpcy5wYWdlSGlkZGVuKXtcbiAgICAgICAgdGhpcy5sb2coXCJOb3QgcmVjb25uZWN0aW5nIGFzIHBhZ2UgaXMgaGlkZGVuIVwiKVxuICAgICAgICB0aGlzLnRlYXJkb3duKClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIHRoaXMudGVhcmRvd24oYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZihvcHRzLmJlZm9yZVJlY29ubmVjdCkgYXdhaXQgb3B0cy5iZWZvcmVSZWNvbm5lY3QoKVxuICAgICAgICB0aGlzLmNvbm5lY3QoKVxuICAgICAgfSlcbiAgICB9LCB0aGlzLnJlY29ubmVjdEFmdGVyTXMpXG4gICAgLyoqIEB0eXBle3N0cmluZyB8IHVuZGVmaW5lZH0gKi9cbiAgICB0aGlzLmF1dGhUb2tlbiA9IG9wdHMuYXV0aFRva2VuXG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgTG9uZ1BvbGwgdHJhbnNwb3J0IHJlZmVyZW5jZVxuICAgKi9cbiAgZ2V0TG9uZ1BvbGxUcmFuc3BvcnQoKXsgcmV0dXJuIExvbmdQb2xsIH1cblxuICAvKipcbiAgICogRGlzY29ubmVjdHMgYW5kIHJlcGxhY2VzIHRoZSBhY3RpdmUgdHJhbnNwb3J0XG4gICAqXG4gICAqIEBwYXJhbSB7U29ja2V0VHJhbnNwb3J0fSBuZXdUcmFuc3BvcnQgLSBUaGUgbmV3IHRyYW5zcG9ydCBjbGFzcyB0byBpbnN0YW50aWF0ZVxuICAgKlxuICAgKi9cbiAgcmVwbGFjZVRyYW5zcG9ydChuZXdUcmFuc3BvcnQpe1xuICAgIHRoaXMuY29ubmVjdENsb2NrKytcbiAgICB0aGlzLmNsb3NlV2FzQ2xlYW4gPSB0cnVlXG4gICAgY2xlYXJUaW1lb3V0KHRoaXMuZmFsbGJhY2tUaW1lcilcbiAgICB0aGlzLnJlY29ubmVjdFRpbWVyLnJlc2V0KClcbiAgICBpZih0aGlzLmNvbm4pe1xuICAgICAgdGhpcy5jb25uLmNsb3NlKClcbiAgICAgIHRoaXMuY29ubiA9IG51bGxcbiAgICB9XG4gICAgdGhpcy50cmFuc3BvcnQgPSBuZXdUcmFuc3BvcnRcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBzb2NrZXQgcHJvdG9jb2xcbiAgICpcbiAgICogQHJldHVybnMge1wid3NzXCIgfCBcIndzXCJ9XG4gICAqL1xuICBwcm90b2NvbCgpeyByZXR1cm4gbG9jYXRpb24ucHJvdG9jb2wubWF0Y2goL15odHRwcy8pID8gXCJ3c3NcIiA6IFwid3NcIiB9XG5cbiAgLyoqXG4gICAqIFRoZSBmdWxseSBxdWFsaWZpZWQgc29ja2V0IHVybFxuICAgKlxuICAgKiBAcmV0dXJucyB7c3RyaW5nfVxuICAgKi9cbiAgZW5kUG9pbnRVUkwoKXtcbiAgICBsZXQgdXJpID0gQWpheC5hcHBlbmRQYXJhbXMoXG4gICAgICBBamF4LmFwcGVuZFBhcmFtcyh0aGlzLmVuZFBvaW50LCB0aGlzLnBhcmFtcygpKSwge3ZzbjogdGhpcy52c259KVxuICAgIGlmKHVyaS5jaGFyQXQoMCkgIT09IFwiL1wiKXsgcmV0dXJuIHVyaSB9XG4gICAgaWYodXJpLmNoYXJBdCgxKSA9PT0gXCIvXCIpeyByZXR1cm4gYCR7dGhpcy5wcm90b2NvbCgpfToke3VyaX1gIH1cblxuICAgIHJldHVybiBgJHt0aGlzLnByb3RvY29sKCl9Oi8vJHtsb2NhdGlvbi5ob3N0fSR7dXJpfWBcbiAgfVxuXG4gIC8qKlxuICAgKiBEaXNjb25uZWN0cyB0aGUgc29ja2V0XG4gICAqXG4gICAqIFNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvQ2xvc2VFdmVudCNTdGF0dXNfY29kZXMgZm9yIHZhbGlkIHN0YXR1cyBjb2Rlcy5cbiAgICpcbiAgICogQHBhcmFtIHsoKSA9PiB2b2lkfSBbY2FsbGJhY2tdIC0gT3B0aW9uYWwgY2FsbGJhY2sgd2hpY2ggaXMgY2FsbGVkIGFmdGVyIHNvY2tldCBpcyBkaXNjb25uZWN0ZWQuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBbY29kZV0gLSBBIHN0YXR1cyBjb2RlIGZvciBkaXNjb25uZWN0aW9uIChPcHRpb25hbCkuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbcmVhc29uXSAtIEEgdGV4dHVhbCBkZXNjcmlwdGlvbiBvZiB0aGUgcmVhc29uIHRvIGRpc2Nvbm5lY3QuIChPcHRpb25hbClcbiAgICovXG4gIGRpc2Nvbm5lY3QoY2FsbGJhY2ssIGNvZGUsIHJlYXNvbil7XG4gICAgdGhpcy5jb25uZWN0Q2xvY2srK1xuICAgIHRoaXMuZGlzY29ubmVjdGluZyA9IHRydWVcbiAgICB0aGlzLmNsb3NlV2FzQ2xlYW4gPSB0cnVlXG4gICAgY2xlYXJUaW1lb3V0KHRoaXMuZmFsbGJhY2tUaW1lcilcbiAgICB0aGlzLnJlY29ubmVjdFRpbWVyLnJlc2V0KClcbiAgICB0aGlzLnRlYXJkb3duKCgpID0+IHtcbiAgICAgIHRoaXMuZGlzY29ubmVjdGluZyA9IGZhbHNlXG4gICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpXG4gICAgfSwgY29kZSwgcmVhc29uKVxuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7UGFyYW1zfSBbcGFyYW1zXSAtIFtERVBSRUNBVEVEXSBUaGUgcGFyYW1zIHRvIHNlbmQgd2hlbiBjb25uZWN0aW5nLCBmb3IgZXhhbXBsZSBge3VzZXJfaWQ6IHVzZXJUb2tlbn1gXG4gICAqXG4gICAqIFBhc3NpbmcgcGFyYW1zIHRvIGNvbm5lY3QgaXMgZGVwcmVjYXRlZDsgcGFzcyB0aGVtIGluIHRoZSBTb2NrZXQgY29uc3RydWN0b3IgaW5zdGVhZDpcbiAgICogYG5ldyBTb2NrZXQoXCIvc29ja2V0XCIsIHtwYXJhbXM6IHt1c2VyX2lkOiB1c2VyVG9rZW59fSlgLlxuICAgKi9cbiAgY29ubmVjdChwYXJhbXMpe1xuICAgIGlmKHBhcmFtcyl7XG4gICAgICBjb25zb2xlICYmIGNvbnNvbGUubG9nKFwicGFzc2luZyBwYXJhbXMgdG8gY29ubmVjdCBpcyBkZXByZWNhdGVkLiBJbnN0ZWFkIHBhc3MgOnBhcmFtcyB0byB0aGUgU29ja2V0IGNvbnN0cnVjdG9yXCIpXG4gICAgICB0aGlzLnBhcmFtcyA9IGNsb3N1cmUocGFyYW1zKVxuICAgIH1cbiAgICBpZih0aGlzLmNvbm4gJiYgIXRoaXMuZGlzY29ubmVjdGluZyl7IHJldHVybiB9XG4gICAgaWYodGhpcy5sb25nUG9sbEZhbGxiYWNrTXMgJiYgdGhpcy50cmFuc3BvcnQgIT09IExvbmdQb2xsKXtcbiAgICAgIHRoaXMuY29ubmVjdFdpdGhGYWxsYmFjayhMb25nUG9sbCwgdGhpcy5sb25nUG9sbEZhbGxiYWNrTXMpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMudHJhbnNwb3J0Q29ubmVjdCgpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIExvZ3MgdGhlIG1lc3NhZ2UuIE92ZXJyaWRlIGB0aGlzLmxvZ2dlcmAgZm9yIHNwZWNpYWxpemVkIGxvZ2dpbmcuIG5vb3BzIGJ5IGRlZmF1bHRcbiAgICogQHBhcmFtIHtzdHJpbmd9IGtpbmRcbiAgICogQHBhcmFtIHtzdHJpbmd9IG1zZ1xuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVxuICAgKi9cbiAgbG9nKGtpbmQsIG1zZywgZGF0YSl7IHRoaXMubG9nZ2VyICYmIHRoaXMubG9nZ2VyKGtpbmQsIG1zZywgZGF0YSkgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRydWUgaWYgYSBsb2dnZXIgaGFzIGJlZW4gc2V0IG9uIHRoaXMgc29ja2V0LlxuICAgKi9cbiAgaGFzTG9nZ2VyKCl7IHJldHVybiB0aGlzLmxvZ2dlciAhPT0gbnVsbCB9XG5cbiAgLyoqXG4gICAqIFJlZ2lzdGVycyBjYWxsYmFja3MgZm9yIGNvbm5lY3Rpb24gb3BlbiBldmVudHNcbiAgICpcbiAgICogQGV4YW1wbGUgc29ja2V0Lm9uT3BlbihmdW5jdGlvbigpeyBjb25zb2xlLmluZm8oXCJ0aGUgc29ja2V0IHdhcyBvcGVuZWRcIikgfSlcbiAgICpcbiAgICogQHBhcmFtIHtTb2NrZXRPbk9wZW59IGNhbGxiYWNrXG4gICAqL1xuICBvbk9wZW4oY2FsbGJhY2spe1xuICAgIGxldCByZWYgPSB0aGlzLm1ha2VSZWYoKVxuICAgIHRoaXMuc3RhdGVDaGFuZ2VDYWxsYmFja3Mub3Blbi5wdXNoKFtyZWYsIGNhbGxiYWNrXSlcbiAgICByZXR1cm4gcmVmXG4gIH1cblxuICAvKipcbiAgICogUmVnaXN0ZXJzIGNhbGxiYWNrcyBmb3IgY29ubmVjdGlvbiBjbG9zZSBldmVudHNcbiAgICogQHBhcmFtIHtTb2NrZXRPbkNsb3NlfSBjYWxsYmFja1xuICAgKiBAcmV0dXJucyB7c3RyaW5nfVxuICAgKi9cbiAgb25DbG9zZShjYWxsYmFjayl7XG4gICAgbGV0IHJlZiA9IHRoaXMubWFrZVJlZigpXG4gICAgdGhpcy5zdGF0ZUNoYW5nZUNhbGxiYWNrcy5jbG9zZS5wdXNoKFtyZWYsIGNhbGxiYWNrXSlcbiAgICByZXR1cm4gcmVmXG4gIH1cblxuICAvKipcbiAgICogUmVnaXN0ZXJzIGNhbGxiYWNrcyBmb3IgY29ubmVjdGlvbiBlcnJvciBldmVudHNcbiAgICpcbiAgICogQGV4YW1wbGUgc29ja2V0Lm9uRXJyb3IoZnVuY3Rpb24oZXJyb3IpeyBhbGVydChcIkFuIGVycm9yIG9jY3VycmVkXCIpIH0pXG4gICAqXG4gICAqIEBwYXJhbSB7U29ja2V0T25FcnJvcn0gY2FsbGJhY2tcbiAgICogQHJldHVybnMge3N0cmluZ31cbiAgICovXG4gIG9uRXJyb3IoY2FsbGJhY2spe1xuICAgIGxldCByZWYgPSB0aGlzLm1ha2VSZWYoKVxuICAgIHRoaXMuc3RhdGVDaGFuZ2VDYWxsYmFja3MuZXJyb3IucHVzaChbcmVmLCBjYWxsYmFja10pXG4gICAgcmV0dXJuIHJlZlxuICB9XG5cbiAgLyoqXG4gICAqIFJlZ2lzdGVycyBjYWxsYmFja3MgZm9yIGNvbm5lY3Rpb24gbWVzc2FnZSBldmVudHNcbiAgICogQHBhcmFtIHtTb2NrZXRPbk1lc3NhZ2V9IGNhbGxiYWNrXG4gICAqIEByZXR1cm5zIHtzdHJpbmd9XG4gICAqL1xuICBvbk1lc3NhZ2UoY2FsbGJhY2spe1xuICAgIGxldCByZWYgPSB0aGlzLm1ha2VSZWYoKVxuICAgIHRoaXMuc3RhdGVDaGFuZ2VDYWxsYmFja3MubWVzc2FnZS5wdXNoKFtyZWYsIGNhbGxiYWNrXSlcbiAgICByZXR1cm4gcmVmXG4gIH1cblxuICAvKipcbiAgICogU2V0cyBhIGNhbGxiYWNrIHRoYXQgcmVjZWl2ZXMgbGlmZWN5Y2xlIGV2ZW50cyBmb3IgaW50ZXJuYWwgaGVhcnRiZWF0IG1lc3NhZ2VzLlxuICAgKiBVc2VmdWwgZm9yIGluc3RydW1lbnRpbmcgY29ubmVjdGlvbiBoZWFsdGggKGUuZy4gc2VudC9vay90aW1lb3V0L2Rpc2Nvbm5lY3RlZCkuXG4gICAqIEBwYXJhbSB7SGVhcnRiZWF0Q2FsbGJhY2t9IGNhbGxiYWNrXG4gICAqL1xuICBvbkhlYXJ0YmVhdChjYWxsYmFjayl7XG4gICAgdGhpcy5oZWFydGJlYXRDYWxsYmFjayA9IGNhbGxiYWNrXG4gIH1cblxuICAvKipcbiAgICogUGluZ3MgdGhlIHNlcnZlciBhbmQgaW52b2tlcyB0aGUgY2FsbGJhY2sgd2l0aCB0aGUgUlRUIGluIG1pbGxpc2Vjb25kc1xuICAgKiBAcGFyYW0geyh0aW1lRGVsdGE6IG51bWJlcikgPT4gdm9pZH0gY2FsbGJhY2tcbiAgICpcbiAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBwaW5nIHdhcyBwdXNoZWQgb3IgZmFsc2UgaWYgdW5hYmxlIHRvIGJlIHB1c2hlZC5cbiAgICovXG4gIHBpbmcoY2FsbGJhY2spe1xuICAgIGlmKCF0aGlzLmlzQ29ubmVjdGVkKCkpeyByZXR1cm4gZmFsc2UgfVxuICAgIGxldCByZWYgPSB0aGlzLm1ha2VSZWYoKVxuICAgIGxldCBzdGFydFRpbWUgPSBEYXRlLm5vdygpXG4gICAgdGhpcy5wdXNoKHt0b3BpYzogXCJwaG9lbml4XCIsIGV2ZW50OiBcImhlYXJ0YmVhdFwiLCBwYXlsb2FkOiB7fSwgcmVmOiByZWZ9KVxuICAgIGxldCBvbk1zZ1JlZiA9IHRoaXMub25NZXNzYWdlKG1zZyA9PiB7XG4gICAgICBpZihtc2cucmVmID09PSByZWYpe1xuICAgICAgICB0aGlzLm9mZihbb25Nc2dSZWZdKVxuICAgICAgICBjYWxsYmFjayhEYXRlLm5vdygpIC0gc3RhcnRUaW1lKVxuICAgICAgfVxuICAgIH0pXG4gICAgcmV0dXJuIHRydWVcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufVxuICAgKi9cbiAgdHJhbnNwb3J0TmFtZSh0cmFuc3BvcnQpe1xuICAgIC8vIEphdmFTY3JpcHQgbWluaWZpY2F0aW9uLCBlbmFibGVkIGJ5IGRlZmF1bHQgaW4gcHJvZHVjdGlvbiBpbiBQaG9lbml4XG4gICAgLy8gcHJvamVjdHMsIHJlbmFtZXMgc3ltYm9scyB0byByZWR1Y2UgY29kZSBzaXplLlxuICAgIC8vIFNlZSBodHRwczovL2VzYnVpbGQuZ2l0aHViLmlvL2FwaS8ja2VlcC1uYW1lcy5cbiAgICAvLyBUaGlzIGhlbHBlciBlbnN1cmVzIHdlIHJldHVybiB0aGUgY29ycmVjdCBuYW1lIGZvciB0aGUgTG9uZ1BvbGwgdHJhbnNwb3J0XG4gICAgLy8gZXZlbiBhZnRlciBtaW5pZmljYXRpb24uIFRoZSBvdGhlciBjb21tb24gdHJhbnNwb3J0IGlzIFdlYlNvY2tldCwgd2hpY2hcbiAgICAvLyBpcyBuYXRpdmUgdG8gYnJvd3NlcnMgYW5kIGRvZXMgbm90IG5lZWQgc3BlY2lhbCBoYW5kbGluZy5cbiAgICBzd2l0Y2godHJhbnNwb3J0KXtcbiAgICAgIGNhc2UgTG9uZ1BvbGw6IHJldHVybiBcIkxvbmdQb2xsXCJcbiAgICAgIGRlZmF1bHQ6IHJldHVybiB0cmFuc3BvcnQubmFtZVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgdHJhbnNwb3J0Q29ubmVjdCgpe1xuICAgIHRoaXMuY29ubmVjdENsb2NrKytcbiAgICB0aGlzLmNsb3NlV2FzQ2xlYW4gPSBmYWxzZVxuICAgIGxldCBwcm90b2NvbHMgPSB1bmRlZmluZWRcbiAgICAvLyBTZWMtV2ViU29ja2V0LVByb3RvY29sIGJhc2VkIHRva2VuXG4gICAgLy8gKGxvbmdwb2xsIHVzZXMgQXV0aG9yaXphdGlvbiBoZWFkZXIgaW5zdGVhZClcbiAgICBpZih0aGlzLmF1dGhUb2tlbil7XG4gICAgICBwcm90b2NvbHMgPSBbXCJwaG9lbml4XCIsIGAke0FVVEhfVE9LRU5fUFJFRklYfSR7YnRvYSh0aGlzLmF1dGhUb2tlbikucmVwbGFjZSgvPS9nLCBcIlwiKX1gXVxuICAgIH1cbiAgICB0aGlzLmNvbm4gPSBuZXcgdGhpcy50cmFuc3BvcnQodGhpcy5lbmRQb2ludFVSTCgpLCBwcm90b2NvbHMpXG4gICAgdGhpcy5jb25uLmJpbmFyeVR5cGUgPSB0aGlzLmJpbmFyeVR5cGVcbiAgICB0aGlzLmNvbm4udGltZW91dCA9IHRoaXMubG9uZ3BvbGxlclRpbWVvdXRcbiAgICB0aGlzLmNvbm4ub25vcGVuID0gKCkgPT4gdGhpcy5vbkNvbm5PcGVuKClcbiAgICB0aGlzLmNvbm4ub25lcnJvciA9IGVycm9yID0+IHRoaXMub25Db25uRXJyb3IoZXJyb3IpXG4gICAgdGhpcy5jb25uLm9ubWVzc2FnZSA9IGV2ZW50ID0+IHRoaXMub25Db25uTWVzc2FnZShldmVudClcbiAgICB0aGlzLmNvbm4ub25jbG9zZSA9IGV2ZW50ID0+IHRoaXMub25Db25uQ2xvc2UoZXZlbnQpXG4gIH1cblxuICBnZXRTZXNzaW9uKGtleSl7IHJldHVybiB0aGlzLnNlc3Npb25TdG9yZSAmJiB0aGlzLnNlc3Npb25TdG9yZS5nZXRJdGVtKGtleSkgfVxuXG4gIHN0b3JlU2Vzc2lvbihrZXksIHZhbCl7IHRoaXMuc2Vzc2lvblN0b3JlICYmIHRoaXMuc2Vzc2lvblN0b3JlLnNldEl0ZW0oa2V5LCB2YWwpIH1cblxuICBjb25uZWN0V2l0aEZhbGxiYWNrKGZhbGxiYWNrVHJhbnNwb3J0LCBmYWxsYmFja1RocmVzaG9sZCA9IDI1MDApe1xuICAgIGNsZWFyVGltZW91dCh0aGlzLmZhbGxiYWNrVGltZXIpXG4gICAgbGV0IGVzdGFibGlzaGVkID0gZmFsc2VcbiAgICBsZXQgcHJpbWFyeVRyYW5zcG9ydCA9IHRydWVcbiAgICBsZXQgb3BlblJlZiwgZXJyb3JSZWZcbiAgICBsZXQgZmFsbGJhY2tUcmFuc3BvcnROYW1lID0gdGhpcy50cmFuc3BvcnROYW1lKGZhbGxiYWNrVHJhbnNwb3J0KVxuICAgIGxldCBmYWxsYmFjayA9IChyZWFzb24pID0+IHtcbiAgICAgIHRoaXMubG9nKFwidHJhbnNwb3J0XCIsIGBmYWxsaW5nIGJhY2sgdG8gJHtmYWxsYmFja1RyYW5zcG9ydE5hbWV9Li4uYCwgcmVhc29uKVxuICAgICAgdGhpcy5vZmYoW29wZW5SZWYsIGVycm9yUmVmXSlcbiAgICAgIHByaW1hcnlUcmFuc3BvcnQgPSBmYWxzZVxuICAgICAgdGhpcy5yZXBsYWNlVHJhbnNwb3J0KGZhbGxiYWNrVHJhbnNwb3J0KVxuICAgICAgdGhpcy50cmFuc3BvcnRDb25uZWN0KClcbiAgICB9XG4gICAgaWYodGhpcy5nZXRTZXNzaW9uKGBwaHg6ZmFsbGJhY2s6JHtmYWxsYmFja1RyYW5zcG9ydE5hbWV9YCkpeyByZXR1cm4gZmFsbGJhY2soXCJtZW1vcml6ZWRcIikgfVxuXG4gICAgdGhpcy5mYWxsYmFja1RpbWVyID0gc2V0VGltZW91dChmYWxsYmFjaywgZmFsbGJhY2tUaHJlc2hvbGQpXG5cbiAgICBlcnJvclJlZiA9IHRoaXMub25FcnJvcihyZWFzb24gPT4ge1xuICAgICAgdGhpcy5sb2coXCJ0cmFuc3BvcnRcIiwgXCJlcnJvclwiLCByZWFzb24pXG4gICAgICBpZihwcmltYXJ5VHJhbnNwb3J0ICYmICFlc3RhYmxpc2hlZCl7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmZhbGxiYWNrVGltZXIpXG4gICAgICAgIGZhbGxiYWNrKHJlYXNvbilcbiAgICAgIH1cbiAgICB9KVxuICAgIGlmKHRoaXMuZmFsbGJhY2tSZWYpe1xuICAgICAgdGhpcy5vZmYoW3RoaXMuZmFsbGJhY2tSZWZdKVxuICAgIH1cbiAgICB0aGlzLmZhbGxiYWNrUmVmID0gdGhpcy5vbk9wZW4oKCkgPT4ge1xuICAgICAgZXN0YWJsaXNoZWQgPSB0cnVlXG4gICAgICBpZighcHJpbWFyeVRyYW5zcG9ydCl7XG4gICAgICAgIGxldCBmYWxsYmFja1RyYW5zcG9ydE5hbWUgPSB0aGlzLnRyYW5zcG9ydE5hbWUoZmFsbGJhY2tUcmFuc3BvcnQpXG4gICAgICAgIC8vIG9ubHkgbWVtb3JpemUgTFAgaWYgd2UgbmV2ZXIgY29ubmVjdGVkIHRvIHByaW1hcnlcbiAgICAgICAgaWYoIXRoaXMucHJpbWFyeVBhc3NlZEhlYWx0aENoZWNrKXsgdGhpcy5zdG9yZVNlc3Npb24oYHBoeDpmYWxsYmFjazoke2ZhbGxiYWNrVHJhbnNwb3J0TmFtZX1gLCBcInRydWVcIikgfVxuICAgICAgICByZXR1cm4gdGhpcy5sb2coXCJ0cmFuc3BvcnRcIiwgYGVzdGFibGlzaGVkICR7ZmFsbGJhY2tUcmFuc3BvcnROYW1lfSBmYWxsYmFja2ApXG4gICAgICB9XG4gICAgICAvLyBpZiB3ZSd2ZSBlc3RhYmxpc2hlZCBwcmltYXJ5LCBnaXZlIHRoZSBmYWxsYmFjayBhIG5ldyBwZXJpb2QgdG8gYXR0ZW1wdCBwaW5nXG4gICAgICBjbGVhclRpbWVvdXQodGhpcy5mYWxsYmFja1RpbWVyKVxuICAgICAgdGhpcy5mYWxsYmFja1RpbWVyID0gc2V0VGltZW91dChmYWxsYmFjaywgZmFsbGJhY2tUaHJlc2hvbGQpXG4gICAgICB0aGlzLnBpbmcocnR0ID0+IHtcbiAgICAgICAgdGhpcy5sb2coXCJ0cmFuc3BvcnRcIiwgXCJjb25uZWN0ZWQgdG8gcHJpbWFyeSBhZnRlclwiLCBydHQpXG4gICAgICAgIHRoaXMucHJpbWFyeVBhc3NlZEhlYWx0aENoZWNrID0gdHJ1ZVxuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5mYWxsYmFja1RpbWVyKVxuICAgICAgfSlcbiAgICB9KVxuICAgIHRoaXMudHJhbnNwb3J0Q29ubmVjdCgpXG4gIH1cblxuICBjbGVhckhlYXJ0YmVhdHMoKXtcbiAgICBjbGVhclRpbWVvdXQodGhpcy5oZWFydGJlYXRUaW1lcilcbiAgICBjbGVhclRpbWVvdXQodGhpcy5oZWFydGJlYXRUaW1lb3V0VGltZXIpXG4gIH1cblxuICBvbkNvbm5PcGVuKCl7XG4gICAgaWYodGhpcy5oYXNMb2dnZXIoKSkgdGhpcy5sb2coXCJ0cmFuc3BvcnRcIiwgYGNvbm5lY3RlZCB0byAke3RoaXMuZW5kUG9pbnRVUkwoKX1gKVxuICAgIHRoaXMuY2xvc2VXYXNDbGVhbiA9IGZhbHNlXG4gICAgdGhpcy5kaXNjb25uZWN0aW5nID0gZmFsc2VcbiAgICB0aGlzLmVzdGFibGlzaGVkQ29ubmVjdGlvbnMrK1xuICAgIHRoaXMuZmx1c2hTZW5kQnVmZmVyKClcbiAgICB0aGlzLnJlY29ubmVjdFRpbWVyLnJlc2V0KClcbiAgICBpZih0aGlzLmF1dG9TZW5kSGVhcnRiZWF0KXtcbiAgICAgIHRoaXMucmVzZXRIZWFydGJlYXQoKVxuICAgIH1cbiAgICB0aGlzLnRyaWdnZXJTdGF0ZUNhbGxiYWNrcyhcIm9wZW5cIilcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cblxuICBoZWFydGJlYXRUaW1lb3V0KCl7XG4gICAgaWYodGhpcy5wZW5kaW5nSGVhcnRiZWF0UmVmKXtcbiAgICAgIHRoaXMucGVuZGluZ0hlYXJ0YmVhdFJlZiA9IG51bGxcbiAgICAgIHRoaXMuaGVhcnRiZWF0U2VudEF0ID0gbnVsbFxuICAgICAgaWYodGhpcy5oYXNMb2dnZXIoKSl7IHRoaXMubG9nKFwidHJhbnNwb3J0XCIsIFwiaGVhcnRiZWF0IHRpbWVvdXQuIEF0dGVtcHRpbmcgdG8gcmUtZXN0YWJsaXNoIGNvbm5lY3Rpb25cIikgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5oZWFydGJlYXRDYWxsYmFjayhcInRpbWVvdXRcIilcbiAgICAgIH0gY2F0Y2ggKGUpe1xuICAgICAgICB0aGlzLmxvZyhcImVycm9yXCIsIFwiZXJyb3IgaW4gaGVhcnRiZWF0IGNhbGxiYWNrXCIsIGUpXG4gICAgICB9XG4gICAgICB0aGlzLnRyaWdnZXJDaGFuRXJyb3IobmV3IEVycm9yKFwiaGVhcnRiZWF0IHRpbWVvdXRcIikpXG4gICAgICB0aGlzLmNsb3NlV2FzQ2xlYW4gPSBmYWxzZVxuICAgICAgdGhpcy50ZWFyZG93bigoKSA9PiB0aGlzLnJlY29ubmVjdFRpbWVyLnNjaGVkdWxlVGltZW91dCgpLCBXU19DTE9TRV9OT1JNQUwsIFwiaGVhcnRiZWF0IHRpbWVvdXRcIilcbiAgICB9XG4gIH1cblxuICByZXNldEhlYXJ0YmVhdCgpe1xuICAgIGlmKHRoaXMuY29ubiAmJiB0aGlzLmNvbm4uc2tpcEhlYXJ0YmVhdCl7IHJldHVybiB9XG4gICAgdGhpcy5wZW5kaW5nSGVhcnRiZWF0UmVmID0gbnVsbFxuICAgIHRoaXMuY2xlYXJIZWFydGJlYXRzKClcbiAgICB0aGlzLmhlYXJ0YmVhdFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB0aGlzLnNlbmRIZWFydGJlYXQoKSwgdGhpcy5oZWFydGJlYXRJbnRlcnZhbE1zKVxuICB9XG5cbiAgdGVhcmRvd24oY2FsbGJhY2ssIGNvZGUsIHJlYXNvbil7XG4gICAgaWYoIXRoaXMuY29ubil7XG4gICAgICByZXR1cm4gY2FsbGJhY2sgJiYgY2FsbGJhY2soKVxuICAgIH1cblxuICAgIC8vIElmIHNvbWVvbmUgY2FsbHMgY29ubmVjdCBiZWZvcmUgd2UgZmluaXNoIHRlYXJpbmcgZG93bixcbiAgICAvLyB3ZSBjcmVhdGUgYSBuZXcgY29ubmVjdGlvbiwgYnV0IHdlIHN0aWxsIHdhbnQgdG8gZmluaXNoIHRlYXJpbmcgZG93biB0aGUgb2xkIG9uZS5cbiAgICBjb25zdCBjb25uVG9DbG9zZSA9IHRoaXMuY29ublxuXG4gICAgdGhpcy53YWl0Rm9yQnVmZmVyRG9uZShjb25uVG9DbG9zZSwgKCkgPT4ge1xuICAgICAgaWYoY29kZSl7IGNvbm5Ub0Nsb3NlLmNsb3NlKGNvZGUsIHJlYXNvbiB8fCBcIlwiKSB9IGVsc2UgeyBjb25uVG9DbG9zZS5jbG9zZSgpIH1cblxuICAgICAgdGhpcy53YWl0Rm9yU29ja2V0Q2xvc2VkKGNvbm5Ub0Nsb3NlLCAoKSA9PiB7XG4gICAgICAgIGlmKHRoaXMuY29ubiA9PT0gY29ublRvQ2xvc2Upe1xuICAgICAgICAgIHRoaXMuY29ubi5vbm9wZW4gPSBmdW5jdGlvbiAoKXsgfSAvLyBub29wXG4gICAgICAgICAgdGhpcy5jb25uLm9uZXJyb3IgPSBmdW5jdGlvbiAoKXsgfSAvLyBub29wXG4gICAgICAgICAgdGhpcy5jb25uLm9ubWVzc2FnZSA9IGZ1bmN0aW9uICgpeyB9IC8vIG5vb3BcbiAgICAgICAgICB0aGlzLmNvbm4ub25jbG9zZSA9IGZ1bmN0aW9uICgpeyB9IC8vIG5vb3BcbiAgICAgICAgICB0aGlzLmNvbm4gPSBudWxsXG4gICAgICAgIH1cblxuICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpXG4gICAgICB9KVxuICAgIH0pXG4gIH1cblxuICB3YWl0Rm9yQnVmZmVyRG9uZShjb25uLCBjYWxsYmFjaywgdHJpZXMgPSAxKXtcbiAgICBpZih0cmllcyA9PT0gNSB8fCAhY29ubi5idWZmZXJlZEFtb3VudCl7XG4gICAgICBjYWxsYmFjaygpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMud2FpdEZvckJ1ZmZlckRvbmUoY29ubiwgY2FsbGJhY2ssIHRyaWVzICsgMSlcbiAgICB9LCAxNTAgKiB0cmllcylcbiAgfVxuXG4gIHdhaXRGb3JTb2NrZXRDbG9zZWQoY29ubiwgY2FsbGJhY2ssIHRyaWVzID0gMSl7XG4gICAgaWYodHJpZXMgPT09IDUgfHwgY29ubi5yZWFkeVN0YXRlID09PSBTT0NLRVRfU1RBVEVTLmNsb3NlZCl7XG4gICAgICBjYWxsYmFjaygpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMud2FpdEZvclNvY2tldENsb3NlZChjb25uLCBjYWxsYmFjaywgdHJpZXMgKyAxKVxuICAgIH0sIDE1MCAqIHRyaWVzKVxuICB9XG5cbiAgLyoqXG4gICogQHBhcmFtIHtDbG9zZUV2ZW50fSBldmVudFxuICAqL1xuICBvbkNvbm5DbG9zZShldmVudCl7XG4gICAgaWYodGhpcy5jb25uKSB0aGlzLmNvbm4ub25jbG9zZSA9ICgpID0+IHt9IC8vIG5vb3AgdG8gcHJldmVudCByZWN1cnNpdmUgY2FsbHMgaW4gdGVhcmRvd25cbiAgICBpZih0aGlzLmhhc0xvZ2dlcigpKSB0aGlzLmxvZyhcInRyYW5zcG9ydFwiLCBcImNsb3NlXCIsIGV2ZW50KVxuICAgIHRoaXMudHJpZ2dlckNoYW5FcnJvcihldmVudClcbiAgICB0aGlzLmNsZWFySGVhcnRiZWF0cygpXG4gICAgaWYoIXRoaXMuY2xvc2VXYXNDbGVhbil7XG4gICAgICB0aGlzLnJlY29ubmVjdFRpbWVyLnNjaGVkdWxlVGltZW91dCgpXG4gICAgfVxuICAgIHRoaXMudHJpZ2dlclN0YXRlQ2FsbGJhY2tzKFwiY2xvc2VcIiwgZXZlbnQpXG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICogQHBhcmFtIHtFdmVudH0gZXJyb3JcbiAgICovXG4gIG9uQ29ubkVycm9yKGVycm9yKXtcbiAgICBpZih0aGlzLmhhc0xvZ2dlcigpKSB0aGlzLmxvZyhcInRyYW5zcG9ydFwiLCBcImVycm9yXCIsIGVycm9yKVxuICAgIGxldCB0cmFuc3BvcnRCZWZvcmUgPSB0aGlzLnRyYW5zcG9ydFxuICAgIGxldCBlc3RhYmxpc2hlZEJlZm9yZSA9IHRoaXMuZXN0YWJsaXNoZWRDb25uZWN0aW9uc1xuICAgIHRoaXMudHJpZ2dlclN0YXRlQ2FsbGJhY2tzKFwiZXJyb3JcIiwgZXJyb3IsIHRyYW5zcG9ydEJlZm9yZSwgZXN0YWJsaXNoZWRCZWZvcmUpXG4gICAgaWYodHJhbnNwb3J0QmVmb3JlID09PSB0aGlzLnRyYW5zcG9ydCB8fCBlc3RhYmxpc2hlZEJlZm9yZSA+IDApe1xuICAgICAgdGhpcy50cmlnZ2VyQ2hhbkVycm9yKGVycm9yKVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0ge3Vua25vd259IFtyZWFzb25dIHVuZGVybHlpbmcgY2xvc2UvZXJyb3IgZXZlbnQgZm9yd2FyZGVkIHRvIGNoYW5uZWwgZXJyb3IgbGlzdGVuZXJzXG4gICAqL1xuICB0cmlnZ2VyQ2hhbkVycm9yKHJlYXNvbil7XG4gICAgdGhpcy5jaGFubmVscy5mb3JFYWNoKGNoYW5uZWwgPT4ge1xuICAgICAgaWYoIShjaGFubmVsLmlzRXJyb3JlZCgpIHx8IGNoYW5uZWwuaXNMZWF2aW5nKCkgfHwgY2hhbm5lbC5pc0Nsb3NlZCgpKSl7XG4gICAgICAgIGNoYW5uZWwudHJpZ2dlcihDSEFOTkVMX0VWRU5UUy5lcnJvciwgcmVhc29uKVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQHJldHVybnMge3N0cmluZ31cbiAgICovXG4gIGNvbm5lY3Rpb25TdGF0ZSgpe1xuICAgIHN3aXRjaCh0aGlzLmNvbm4gJiYgdGhpcy5jb25uLnJlYWR5U3RhdGUpe1xuICAgICAgY2FzZSBTT0NLRVRfU1RBVEVTLmNvbm5lY3Rpbmc6IHJldHVybiBcImNvbm5lY3RpbmdcIlxuICAgICAgY2FzZSBTT0NLRVRfU1RBVEVTLm9wZW46IHJldHVybiBcIm9wZW5cIlxuICAgICAgY2FzZSBTT0NLRVRfU1RBVEVTLmNsb3Npbmc6IHJldHVybiBcImNsb3NpbmdcIlxuICAgICAgZGVmYXVsdDogcmV0dXJuIFwiY2xvc2VkXCJcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQHJldHVybnMge2Jvb2xlYW59XG4gICAqL1xuICBpc0Nvbm5lY3RlZCgpeyByZXR1cm4gdGhpcy5jb25uZWN0aW9uU3RhdGUoKSA9PT0gXCJvcGVuXCIgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0ge0NoYW5uZWx9IGNoYW5uZWxcbiAgICovXG4gIHJlbW92ZShjaGFubmVsKXtcbiAgICB0aGlzLm9mZihjaGFubmVsLnN0YXRlQ2hhbmdlUmVmcylcbiAgICB0aGlzLmNoYW5uZWxzID0gdGhpcy5jaGFubmVscy5maWx0ZXIoYyA9PiBjICE9PSBjaGFubmVsKVxuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZXMgYG9uT3BlbmAsIGBvbkNsb3NlYCwgYG9uRXJyb3IsYCBhbmQgYG9uTWVzc2FnZWAgcmVnaXN0cmF0aW9ucy5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gcmVmcyAtIGxpc3Qgb2YgcmVmcyByZXR1cm5lZCBieSBjYWxscyB0b1xuICAgKiAgICAgICAgICAgICAgICAgYG9uT3BlbmAsIGBvbkNsb3NlYCwgYG9uRXJyb3IsYCBhbmQgYG9uTWVzc2FnZWBcbiAgICovXG4gIG9mZihyZWZzKXtcbiAgICBmb3IobGV0IGtleSBpbiB0aGlzLnN0YXRlQ2hhbmdlQ2FsbGJhY2tzKXtcbiAgICAgIHRoaXMuc3RhdGVDaGFuZ2VDYWxsYmFja3Nba2V5XSA9IHRoaXMuc3RhdGVDaGFuZ2VDYWxsYmFja3Nba2V5XS5maWx0ZXIoKFtyZWZdKSA9PiB7XG4gICAgICAgIHJldHVybiByZWZzLmluZGV4T2YocmVmKSA9PT0gLTFcbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEluaXRpYXRlcyBhIG5ldyBjaGFubmVsIGZvciB0aGUgZ2l2ZW4gdG9waWNcbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmd9IHRvcGljXG4gICAqIEBwYXJhbSB7UGFyYW1zIHwgKCgpID0+IFBhcmFtcyl9IFtjaGFuUGFyYW1zXS0gUGFyYW1ldGVycyBmb3IgdGhlIGNoYW5uZWxcbiAgICogQHJldHVybnMge0NoYW5uZWx9XG4gICAqL1xuICBjaGFubmVsKHRvcGljLCBjaGFuUGFyYW1zID0ge30pe1xuICAgIGxldCBjaGFuID0gbmV3IENoYW5uZWwodG9waWMsIGNoYW5QYXJhbXMsIHRoaXMpXG4gICAgdGhpcy5jaGFubmVscy5wdXNoKGNoYW4pXG4gICAgcmV0dXJuIGNoYW5cbiAgfVxuXG4gIC8qKlxuICAgKiBAcGFyYW0ge01lc3NhZ2U8UmVjb3JkPHN0cmluZywgYW55Pj59IGRhdGFcbiAgICovXG4gIHB1c2goZGF0YSl7XG4gICAgaWYodGhpcy5oYXNMb2dnZXIoKSl7XG4gICAgICBsZXQge3RvcGljLCBldmVudCwgcGF5bG9hZCwgcmVmLCBqb2luX3JlZn0gPSBkYXRhXG4gICAgICB0aGlzLmxvZyhcInB1c2hcIiwgYCR7dG9waWN9ICR7ZXZlbnR9ICgke2pvaW5fcmVmfSwgJHtyZWZ9KWAsIHBheWxvYWQpXG4gICAgfVxuXG4gICAgaWYodGhpcy5pc0Nvbm5lY3RlZCgpKXtcbiAgICAgIHRoaXMuZW5jb2RlKGRhdGEsIHJlc3VsdCA9PiB0aGlzLmNvbm4uc2VuZChyZXN1bHQpKVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNlbmRCdWZmZXIucHVzaCgoKSA9PiB0aGlzLmVuY29kZShkYXRhLCByZXN1bHQgPT4gdGhpcy5jb25uLnNlbmQocmVzdWx0KSkpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgbmV4dCBtZXNzYWdlIHJlZiwgYWNjb3VudGluZyBmb3Igb3ZlcmZsb3dzXG4gICAqIEByZXR1cm5zIHtzdHJpbmd9XG4gICAqL1xuICBtYWtlUmVmKCl7XG4gICAgbGV0IG5ld1JlZiA9IHRoaXMucmVmICsgMVxuICAgIGlmKG5ld1JlZiA9PT0gdGhpcy5yZWYpeyB0aGlzLnJlZiA9IDAgfSBlbHNlIHsgdGhpcy5yZWYgPSBuZXdSZWYgfVxuXG4gICAgcmV0dXJuIHRoaXMucmVmLnRvU3RyaW5nKClcbiAgfVxuXG4gIHNlbmRIZWFydGJlYXQoKXtcbiAgICBpZighdGhpcy5pc0Nvbm5lY3RlZCgpKXtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRoaXMuaGVhcnRiZWF0Q2FsbGJhY2soXCJkaXNjb25uZWN0ZWRcIilcbiAgICAgIH0gY2F0Y2ggKGUpe1xuICAgICAgICB0aGlzLmxvZyhcImVycm9yXCIsIFwiZXJyb3IgaW4gaGVhcnRiZWF0IGNhbGxiYWNrXCIsIGUpXG4gICAgICB9XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYodGhpcy5wZW5kaW5nSGVhcnRiZWF0UmVmKXtcbiAgICAgIHRoaXMuaGVhcnRiZWF0VGltZW91dCgpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgdGhpcy5wZW5kaW5nSGVhcnRiZWF0UmVmID0gdGhpcy5tYWtlUmVmKClcbiAgICB0aGlzLmhlYXJ0YmVhdFNlbnRBdCA9IERhdGUubm93KClcbiAgICB0aGlzLnB1c2goe3RvcGljOiBcInBob2VuaXhcIiwgZXZlbnQ6IFwiaGVhcnRiZWF0XCIsIHBheWxvYWQ6IHt9LCByZWY6IHRoaXMucGVuZGluZ0hlYXJ0YmVhdFJlZn0pXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuaGVhcnRiZWF0Q2FsbGJhY2soXCJzZW50XCIpXG4gICAgfSBjYXRjaCAoZSl7XG4gICAgICB0aGlzLmxvZyhcImVycm9yXCIsIFwiZXJyb3IgaW4gaGVhcnRiZWF0IGNhbGxiYWNrXCIsIGUpXG4gICAgfVxuICAgIHRoaXMuaGVhcnRiZWF0VGltZW91dFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB0aGlzLmhlYXJ0YmVhdFRpbWVvdXQoKSwgdGhpcy5oZWFydGJlYXRJbnRlcnZhbE1zKVxuICB9XG5cbiAgZmx1c2hTZW5kQnVmZmVyKCl7XG4gICAgaWYodGhpcy5pc0Nvbm5lY3RlZCgpICYmIHRoaXMuc2VuZEJ1ZmZlci5sZW5ndGggPiAwKXtcbiAgICAgIHRoaXMuc2VuZEJ1ZmZlci5mb3JFYWNoKGNhbGxiYWNrID0+IGNhbGxiYWNrKCkpXG4gICAgICB0aGlzLnNlbmRCdWZmZXIgPSBbXVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAqIEBwYXJhbSB7TWVzc2FnZUV2ZW50PGFueT59IHJhd01lc3NhZ2VcbiAgKi9cbiAgb25Db25uTWVzc2FnZShyYXdNZXNzYWdlKXtcbiAgICB0aGlzLmRlY29kZShyYXdNZXNzYWdlLmRhdGEsIG1zZyA9PiB7XG4gICAgICBsZXQge3RvcGljLCBldmVudCwgcGF5bG9hZCwgcmVmLCBqb2luX3JlZn0gPSBtc2dcbiAgICAgIGlmKHJlZiAmJiByZWYgPT09IHRoaXMucGVuZGluZ0hlYXJ0YmVhdFJlZil7XG4gICAgICAgIGNvbnN0IGxhdGVuY3kgPSB0aGlzLmhlYXJ0YmVhdFNlbnRBdCA/IERhdGUubm93KCkgLSB0aGlzLmhlYXJ0YmVhdFNlbnRBdCA6IHVuZGVmaW5lZFxuICAgICAgICB0aGlzLmNsZWFySGVhcnRiZWF0cygpXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgdGhpcy5oZWFydGJlYXRDYWxsYmFjayhwYXlsb2FkLnN0YXR1cyA9PT0gXCJva1wiID8gXCJva1wiIDogXCJlcnJvclwiLCBsYXRlbmN5KVxuICAgICAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgICB0aGlzLmxvZyhcImVycm9yXCIsIFwiZXJyb3IgaW4gaGVhcnRiZWF0IGNhbGxiYWNrXCIsIGUpXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5wZW5kaW5nSGVhcnRiZWF0UmVmID0gbnVsbFxuICAgICAgICB0aGlzLmhlYXJ0YmVhdFNlbnRBdCA9IG51bGxcbiAgICAgICAgaWYodGhpcy5hdXRvU2VuZEhlYXJ0YmVhdCl7XG4gICAgICAgICAgdGhpcy5oZWFydGJlYXRUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4gdGhpcy5zZW5kSGVhcnRiZWF0KCksIHRoaXMuaGVhcnRiZWF0SW50ZXJ2YWxNcylcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZih0aGlzLmhhc0xvZ2dlcigpKSB0aGlzLmxvZyhcInJlY2VpdmVcIiwgYCR7cGF5bG9hZC5zdGF0dXMgfHwgXCJcIn0gJHt0b3BpY30gJHtldmVudH0gJHtyZWYgJiYgXCIoXCIgKyByZWYgKyBcIilcIiB8fCBcIlwifWAudHJpbSgpLCBwYXlsb2FkKVxuXG4gICAgICBmb3IobGV0IGkgPSAwOyBpIDwgdGhpcy5jaGFubmVscy5sZW5ndGg7IGkrKyl7XG4gICAgICAgIGNvbnN0IGNoYW5uZWwgPSB0aGlzLmNoYW5uZWxzW2ldXG4gICAgICAgIGlmKCFjaGFubmVsLmlzTWVtYmVyKHRvcGljLCBldmVudCwgcGF5bG9hZCwgam9pbl9yZWYpKXsgY29udGludWUgfVxuICAgICAgICBjaGFubmVsLnRyaWdnZXIoZXZlbnQsIHBheWxvYWQsIHJlZiwgam9pbl9yZWYpXG4gICAgICB9XG5cbiAgICAgIHRoaXMudHJpZ2dlclN0YXRlQ2FsbGJhY2tzKFwibWVzc2FnZVwiLCBtc2cpXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKiBAdGVtcGxhdGUge2tleW9mIFNvY2tldFN0YXRlQ2hhbmdlQ2FsbGJhY2tzfSBLXG4gICAqIEBwYXJhbSB7S30gZXZlbnRcbiAgICogQHBhcmFtIHsuLi5QYXJhbWV0ZXJzPFNvY2tldFN0YXRlQ2hhbmdlQ2FsbGJhY2tzW0tdW251bWJlcl1bMV0+fSBhcmdzXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgdHJpZ2dlclN0YXRlQ2FsbGJhY2tzKGV2ZW50LCAuLi5hcmdzKXtcbiAgICB0cnkge1xuICAgICAgdGhpcy5zdGF0ZUNoYW5nZUNhbGxiYWNrc1tldmVudF0uZm9yRWFjaCgoW18sIGNhbGxiYWNrXSkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNhbGxiYWNrKC4uLmFyZ3MpXG4gICAgICAgIH0gY2F0Y2ggKGUpe1xuICAgICAgICAgIHRoaXMubG9nKFwiZXJyb3JcIiwgYGVycm9yIGluICR7ZXZlbnR9IGNhbGxiYWNrYCwgZSlcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlKXtcbiAgICAgIHRoaXMubG9nKFwiZXJyb3JcIiwgYGVycm9yIHRyaWdnZXJpbmcgJHtldmVudH0gY2FsbGJhY2tzYCwgZSlcbiAgICB9XG4gIH1cblxuICBsZWF2ZU9wZW5Ub3BpYyh0b3BpYyl7XG4gICAgbGV0IGR1cENoYW5uZWwgPSB0aGlzLmNoYW5uZWxzLmZpbmQoYyA9PiBjLnRvcGljID09PSB0b3BpYyAmJiAoYy5pc0pvaW5lZCgpIHx8IGMuaXNKb2luaW5nKCkpKVxuICAgIGlmKGR1cENoYW5uZWwpe1xuICAgICAgaWYodGhpcy5oYXNMb2dnZXIoKSkgdGhpcy5sb2coXCJ0cmFuc3BvcnRcIiwgYGxlYXZpbmcgZHVwbGljYXRlIHRvcGljIFwiJHt0b3BpY31cImApXG4gICAgICBkdXBDaGFubmVsLmxlYXZlKClcbiAgICB9XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IjtBQVFPLElBQUksVUFBVSxDQUFDLFVBQVU7QUFDOUIsTUFBRyxPQUFPLFVBQVUsWUFBVztBQUM3QjtBQUFBO0FBQUEsTUFBK0I7QUFBQTtBQUFBLEVBQ2pDLE9BQU87QUFDTCxRQUFJQSxXQUFVLFdBQVc7QUFBRSxhQUFPO0FBQUEsSUFBTTtBQUN4QyxXQUFPQTtBQUFBLEVBQ1Q7QUFDRjs7O0FDZk8sSUFBTSxhQUFhLE9BQU8sU0FBUyxjQUFjLE9BQU87QUFDeEQsSUFBTSxZQUFZLE9BQU8sV0FBVyxjQUFjLFNBQVM7QUFDM0QsSUFBTSxTQUFTLGNBQWMsYUFBYTtBQUMxQyxJQUFNLGNBQWM7QUFDcEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBTTtBQUFBO0FBQUEsRUFBc0MsRUFBQyxZQUFZLEdBQUcsTUFBTSxHQUFHLFNBQVMsR0FBRyxRQUFRLEVBQUM7QUFBQTtBQUUxRixJQUFNO0FBQUE7QUFBQSxFQUF1QztBQUFBLElBQ2xELFFBQVE7QUFBQSxJQUNSLFNBQVM7QUFBQSxJQUNULFFBQVE7QUFBQSxJQUNSLFNBQVM7QUFBQSxJQUNULFNBQVM7QUFBQSxFQUNYO0FBQUE7QUFFTyxJQUFNO0FBQUE7QUFBQSxFQUF1QztBQUFBLElBQ2xELE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxFQUNUO0FBQUE7QUFFTyxJQUFNO0FBQUE7QUFBQSxFQUFtQztBQUFBLElBQzlDLFVBQVU7QUFBQSxJQUNWLFdBQVc7QUFBQSxFQUNiO0FBQUE7QUFFTyxJQUFNO0FBQUE7QUFBQSxFQUFtQztBQUFBLElBQzlDLFVBQVU7QUFBQSxFQUNaO0FBQUE7QUFFTyxJQUFNLG9CQUFvQjs7O0FDOUJqQyxJQUFxQixPQUFyQixNQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFReEIsWUFBWSxTQUFTLE9BQU8sU0FBUyxTQUFRO0FBRTNDLFNBQUssVUFBVTtBQUVmLFNBQUssUUFBUTtBQUViLFNBQUssVUFBVSxXQUFXLFdBQVc7QUFBRSxhQUFPLENBQUM7QUFBQSxJQUFFO0FBQ2pELFNBQUssZUFBZTtBQUVwQixTQUFLLFVBQVU7QUFFZixTQUFLLGVBQWU7QUFFcEIsU0FBSyxXQUFXLENBQUM7QUFFakIsU0FBSyxPQUFPO0FBRVosU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxPQUFPLFNBQVE7QUFDYixTQUFLLFVBQVU7QUFDZixTQUFLLE1BQU07QUFDWCxTQUFLLEtBQUs7QUFBQSxFQUNaO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxPQUFNO0FBQ0osUUFBRyxLQUFLLFlBQVksU0FBUyxHQUFFO0FBQUU7QUFBQSxJQUFPO0FBQ3hDLFNBQUssYUFBYTtBQUNsQixTQUFLLE9BQU87QUFDWixTQUFLLFFBQVEsT0FBTyxLQUFLO0FBQUEsTUFDdkIsT0FBTyxLQUFLLFFBQVE7QUFBQSxNQUNwQixPQUFPLEtBQUs7QUFBQSxNQUNaLFNBQVMsS0FBSyxRQUFRO0FBQUEsTUFDdEIsS0FBSyxLQUFLO0FBQUEsTUFDVixVQUFVLEtBQUssUUFBUSxRQUFRO0FBQUEsSUFDakMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxRQUFRLFFBQVEsVUFBUztBQUN2QixRQUFHLEtBQUssWUFBWSxNQUFNLEdBQUU7QUFDMUIsZUFBUyxLQUFLLGFBQWEsUUFBUTtBQUFBLElBQ3JDO0FBRUEsU0FBSyxTQUFTLEtBQUssRUFBQyxRQUFRLFNBQVEsQ0FBQztBQUNyQyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsUUFBTztBQUNMLFNBQUssZUFBZTtBQUNwQixTQUFLLE1BQU07QUFDWCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxlQUFlO0FBQ3BCLFNBQUssT0FBTztBQUFBLEVBQ2Q7QUFBQSxFQUVBLFVBQVM7QUFDUCxTQUFLLGVBQWU7QUFDcEIsU0FBSyxjQUFjO0FBQUEsRUFDckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLGFBQWEsRUFBQyxRQUFRLFVBQVUsS0FBSSxHQUFFO0FBQ3BDLFNBQUssU0FBUyxPQUFPLE9BQUssRUFBRSxXQUFXLE1BQU0sRUFDMUMsUUFBUSxPQUFLLEVBQUUsU0FBUyxRQUFRLENBQUM7QUFBQSxFQUN0QztBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsaUJBQWdCO0FBQ2QsUUFBRyxDQUFDLEtBQUssVUFBUztBQUFFO0FBQUEsSUFBTztBQUMzQixTQUFLLFFBQVEsSUFBSSxLQUFLLFFBQVE7QUFBQSxFQUNoQztBQUFBLEVBRUEsZ0JBQWU7QUFDYixpQkFBYSxLQUFLLFlBQVk7QUFDOUIsU0FBSyxlQUFlO0FBQUEsRUFDdEI7QUFBQSxFQUVBLGVBQWM7QUFDWixRQUFHLEtBQUssY0FBYTtBQUFFLFdBQUssY0FBYztBQUFBLElBQUU7QUFDNUMsU0FBSyxNQUFNLEtBQUssUUFBUSxPQUFPLFFBQVE7QUFDdkMsU0FBSyxXQUFXLEtBQUssUUFBUSxlQUFlLEtBQUssR0FBRztBQUVwRCxTQUFLLFFBQVEsR0FBRyxLQUFLLFVBQVUsYUFBVztBQUN4QyxXQUFLLGVBQWU7QUFDcEIsV0FBSyxjQUFjO0FBQ25CLFdBQUssZUFBZTtBQUNwQixXQUFLLGFBQWEsT0FBTztBQUFBLElBQzNCLENBQUM7QUFFRCxTQUFLLGVBQWUsV0FBVyxNQUFNO0FBQ25DLFdBQUssUUFBUSxXQUFXLENBQUMsQ0FBQztBQUFBLElBQzVCLEdBQUcsS0FBSyxPQUFPO0FBQUEsRUFDakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLFlBQVksUUFBTztBQUNqQixXQUFPLEtBQUssZ0JBQWdCLEtBQUssYUFBYSxXQUFXO0FBQUEsRUFDM0Q7QUFBQSxFQUVBLFFBQVEsUUFBUSxVQUFTO0FBQ3ZCLFNBQUssUUFBUSxRQUFRLEtBQUssVUFBVSxFQUFDLFFBQVEsU0FBUSxDQUFDO0FBQUEsRUFDeEQ7QUFDRjs7O0FDdEhBLElBQXFCLFFBQXJCLE1BQTJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUt6QixZQUFZLFVBQVUsV0FBVTtBQUU5QixTQUFLLFdBQVc7QUFFaEIsU0FBSyxZQUFZO0FBRWpCLFNBQUssUUFBUTtBQUViLFNBQUssUUFBUTtBQUFBLEVBQ2Y7QUFBQSxFQUVBLFFBQU87QUFDTCxTQUFLLFFBQVE7QUFDYixpQkFBYSxLQUFLLEtBQUs7QUFBQSxFQUN6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0Esa0JBQWlCO0FBQ2YsaUJBQWEsS0FBSyxLQUFLO0FBRXZCLFNBQUssUUFBUSxXQUFXLE1BQU07QUFDNUIsV0FBSyxRQUFRLEtBQUssUUFBUTtBQUMxQixXQUFLLFNBQVM7QUFBQSxJQUNoQixHQUFHLEtBQUssVUFBVSxLQUFLLFFBQVEsQ0FBQyxDQUFDO0FBQUEsRUFDbkM7QUFDRjs7O0FDakNBLElBQXFCLFVBQXJCLE1BQTZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTTNCLFlBQVksT0FBTyxRQUFRLFFBQU87QUFFaEMsU0FBSyxRQUFRLGVBQWU7QUFFNUIsU0FBSyxRQUFRO0FBRWIsU0FBSyxTQUFTLFFBQVEsVUFBVSxDQUFDLENBQUM7QUFFbEMsU0FBSyxTQUFTO0FBRWQsU0FBSyxXQUFXLENBQUM7QUFFakIsU0FBSyxhQUFhO0FBRWxCLFNBQUssVUFBVSxLQUFLLE9BQU87QUFFM0IsU0FBSyxhQUFhO0FBRWxCLFNBQUssV0FBVyxJQUFJLEtBQUssTUFBTSxlQUFlLE1BQU0sS0FBSyxRQUFRLEtBQUssT0FBTztBQUU3RSxTQUFLLGFBQWEsQ0FBQztBQUVuQixTQUFLLGtCQUFrQixDQUFDO0FBR3hCLFNBQUssY0FBYyxJQUFJLE1BQU0sTUFBTTtBQUNqQyxVQUFHLEtBQUssT0FBTyxZQUFZLEdBQUU7QUFBRSxhQUFLLE9BQU87QUFBQSxNQUFFO0FBQUEsSUFDL0MsR0FBRyxLQUFLLE9BQU8sYUFBYTtBQUM1QixTQUFLLGdCQUFnQixLQUFLLEtBQUssT0FBTyxRQUFRLE1BQU0sS0FBSyxZQUFZLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFNBQUssZ0JBQWdCO0FBQUEsTUFBSyxLQUFLLE9BQU8sT0FBTyxNQUFNO0FBQ2pELGFBQUssWUFBWSxNQUFNO0FBQ3ZCLFlBQUcsS0FBSyxVQUFVLEdBQUU7QUFBRSxlQUFLLE9BQU87QUFBQSxRQUFFO0FBQUEsTUFDdEMsQ0FBQztBQUFBLElBQ0Q7QUFDQSxTQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU07QUFDaEMsV0FBSyxRQUFRLGVBQWU7QUFDNUIsV0FBSyxZQUFZLE1BQU07QUFDdkIsV0FBSyxXQUFXLFFBQVEsZUFBYSxVQUFVLEtBQUssQ0FBQztBQUNyRCxXQUFLLGFBQWEsQ0FBQztBQUFBLElBQ3JCLENBQUM7QUFDRCxTQUFLLFNBQVMsUUFBUSxTQUFTLENBQUMsV0FBVztBQUN6QyxXQUFLLFFBQVEsZUFBZTtBQUM1QixVQUFHLEtBQUssT0FBTyxVQUFVLEVBQUcsTUFBSyxPQUFPLElBQUksV0FBVyxTQUFTLEtBQUssS0FBSyxJQUFJLE1BQU07QUFDcEYsVUFBRyxLQUFLLE9BQU8sWUFBWSxHQUFFO0FBQUUsYUFBSyxZQUFZLGdCQUFnQjtBQUFBLE1BQUU7QUFBQSxJQUNwRSxDQUFDO0FBQ0QsU0FBSyxRQUFRLE1BQU07QUFDakIsV0FBSyxZQUFZLE1BQU07QUFDdkIsVUFBRyxLQUFLLE9BQU8sVUFBVSxFQUFHLE1BQUssT0FBTyxJQUFJLFdBQVcsU0FBUyxLQUFLLEtBQUssRUFBRTtBQUM1RSxXQUFLLFFBQVEsZUFBZTtBQUM1QixXQUFLLE9BQU8sT0FBTyxJQUFJO0FBQUEsSUFDekIsQ0FBQztBQUNELFNBQUssUUFBUSxZQUFVO0FBQ3JCLFVBQUcsS0FBSyxPQUFPLFVBQVUsRUFBRyxNQUFLLE9BQU8sSUFBSSxXQUFXLFNBQVMsS0FBSyxLQUFLLElBQUksTUFBTTtBQUNwRixVQUFHLEtBQUssVUFBVSxHQUFFO0FBQUUsYUFBSyxTQUFTLE1BQU07QUFBQSxNQUFFO0FBQzVDLFdBQUssUUFBUSxlQUFlO0FBQzVCLFVBQUcsS0FBSyxPQUFPLFlBQVksR0FBRTtBQUFFLGFBQUssWUFBWSxnQkFBZ0I7QUFBQSxNQUFFO0FBQUEsSUFDcEUsQ0FBQztBQUNELFNBQUssU0FBUyxRQUFRLFdBQVcsTUFBTTtBQUNyQyxVQUFHLEtBQUssT0FBTyxVQUFVLEVBQUcsTUFBSyxPQUFPLElBQUksV0FBVyxXQUFXLEtBQUssS0FBSyxJQUFJLEtBQUssU0FBUyxPQUFPO0FBQ3JHLFVBQUksWUFBWSxJQUFJLEtBQUssTUFBTSxlQUFlLE9BQU8sUUFBUSxDQUFDLENBQUMsR0FBRyxLQUFLLE9BQU87QUFDOUUsZ0JBQVUsS0FBSztBQUNmLFdBQUssUUFBUSxlQUFlO0FBQzVCLFdBQUssU0FBUyxNQUFNO0FBQ3BCLFVBQUcsS0FBSyxPQUFPLFlBQVksR0FBRTtBQUFFLGFBQUssWUFBWSxnQkFBZ0I7QUFBQSxNQUFFO0FBQUEsSUFDcEUsQ0FBQztBQUNELFNBQUssR0FBRyxlQUFlLE9BQU8sQ0FBQyxTQUFTLFFBQVE7QUFDOUMsV0FBSyxRQUFRLEtBQUssZUFBZSxHQUFHLEdBQUcsT0FBTztBQUFBLElBQ2hELENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsS0FBSyxVQUFVLEtBQUssU0FBUTtBQUMxQixRQUFHLEtBQUssWUFBVztBQUNqQixZQUFNLElBQUksTUFBTSw0RkFBNEY7QUFBQSxJQUM5RyxPQUFPO0FBQ0wsV0FBSyxVQUFVO0FBQ2YsV0FBSyxhQUFhO0FBQ2xCLFdBQUssT0FBTztBQUNaLGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsV0FBVTtBQUNSLFNBQUssV0FBVyxRQUFRLENBQUMsU0FBUyxLQUFLLFFBQVEsQ0FBQztBQUNoRCxTQUFLLGFBQWEsQ0FBQztBQUNuQixTQUFLLFlBQVksTUFBTTtBQUN2QixTQUFLLFNBQVMsUUFBUTtBQUN0QixTQUFLLFFBQVEsZUFBZTtBQUM1QixTQUFLLFdBQVcsQ0FBQztBQUFBLEVBQ25CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLFFBQVEsVUFBUztBQUNmLFNBQUssR0FBRyxlQUFlLE9BQU8sUUFBUTtBQUFBLEVBQ3hDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsUUFBUSxVQUFTO0FBQ2YsV0FBTyxLQUFLLEdBQUcsZUFBZSxPQUFPLFlBQVUsU0FBUyxNQUFNLENBQUM7QUFBQSxFQUNqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1CQSxHQUFHLE9BQU8sVUFBUztBQUNqQixRQUFJLE1BQU0sS0FBSztBQUNmLFNBQUssU0FBUyxLQUFLLEVBQUMsT0FBTyxLQUFLLFNBQVEsQ0FBQztBQUN6QyxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBb0JBLElBQUksT0FBTyxLQUFJO0FBQ2IsU0FBSyxXQUFXLEtBQUssU0FBUyxPQUFPLENBQUMsU0FBUztBQUM3QyxhQUFPLEVBQUUsS0FBSyxVQUFVLFVBQVUsT0FBTyxRQUFRLGVBQWUsUUFBUSxLQUFLO0FBQUEsSUFDL0UsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLFVBQVM7QUFBRSxXQUFPLEtBQUssT0FBTyxZQUFZLEtBQUssS0FBSyxTQUFTO0FBQUEsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrQi9ELEtBQUssT0FBTyxTQUFTLFVBQVUsS0FBSyxTQUFRO0FBQzFDLGNBQVUsV0FBVyxDQUFDO0FBQ3RCLFFBQUcsQ0FBQyxLQUFLLFlBQVc7QUFDbEIsWUFBTSxJQUFJLE1BQU0sa0JBQWtCLEtBQUssU0FBUyxLQUFLLEtBQUssNERBQTREO0FBQUEsSUFDeEg7QUFDQSxRQUFJLFlBQVksSUFBSSxLQUFLLE1BQU0sT0FBTyxXQUFXO0FBQUUsYUFBTztBQUFBLElBQVEsR0FBRyxPQUFPO0FBQzVFLFFBQUcsS0FBSyxRQUFRLEdBQUU7QUFDaEIsZ0JBQVUsS0FBSztBQUFBLElBQ2pCLE9BQU87QUFDTCxnQkFBVSxhQUFhO0FBQ3ZCLFdBQUssV0FBVyxLQUFLLFNBQVM7QUFBQSxJQUNoQztBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWtCQSxNQUFNLFVBQVUsS0FBSyxTQUFRO0FBQzNCLFNBQUssWUFBWSxNQUFNO0FBQ3ZCLFNBQUssU0FBUyxjQUFjO0FBRTVCLFNBQUssUUFBUSxlQUFlO0FBQzVCLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFVBQUcsS0FBSyxPQUFPLFVBQVUsRUFBRyxNQUFLLE9BQU8sSUFBSSxXQUFXLFNBQVMsS0FBSyxLQUFLLEVBQUU7QUFDNUUsV0FBSyxRQUFRLGVBQWUsT0FBTyxPQUFPO0FBQUEsSUFDNUM7QUFDQSxRQUFJLFlBQVksSUFBSSxLQUFLLE1BQU0sZUFBZSxPQUFPLFFBQVEsQ0FBQyxDQUFDLEdBQUcsT0FBTztBQUN6RSxjQUFVLFFBQVEsTUFBTSxNQUFNLFFBQVEsQ0FBQyxFQUNwQyxRQUFRLFdBQVcsTUFBTSxRQUFRLENBQUM7QUFDckMsY0FBVSxLQUFLO0FBQ2YsUUFBRyxDQUFDLEtBQUssUUFBUSxHQUFFO0FBQUUsZ0JBQVUsUUFBUSxNQUFNLENBQUMsQ0FBQztBQUFBLElBQUU7QUFFakQsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBLFVBQVUsUUFBUSxTQUFTLE1BQUs7QUFBRSxXQUFPO0FBQUEsRUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTakQsZUFBZSxVQUFVLFVBQVUsTUFBSztBQUFFLFdBQU87QUFBQSxFQUFLO0FBQUEsRUFFdEQsU0FBUyxPQUFPLE9BQU8sU0FBUyxTQUFRO0FBQ3RDLFFBQUcsS0FBSyxVQUFVLE9BQU07QUFBRSxhQUFPO0FBQUEsSUFBTTtBQUV2QyxRQUFHLFdBQVcsWUFBWSxLQUFLLFFBQVEsR0FBRTtBQUN2QyxVQUFHLEtBQUssT0FBTyxVQUFVLEVBQUcsTUFBSyxPQUFPLElBQUksV0FBVyw2QkFBNkIsRUFBQyxPQUFPLE9BQU8sU0FBUyxRQUFPLENBQUM7QUFDcEgsYUFBTztBQUFBLElBQ1QsT0FBTztBQUNMLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBLEVBRUEsVUFBUztBQUFFLFdBQU8sS0FBSyxTQUFTO0FBQUEsRUFBSTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS3BDLE9BQU8sVUFBVSxLQUFLLFNBQVE7QUFDNUIsUUFBRyxLQUFLLFVBQVUsR0FBRTtBQUFFO0FBQUEsSUFBTztBQUM3QixTQUFLLE9BQU8sZUFBZSxLQUFLLEtBQUs7QUFDckMsU0FBSyxRQUFRLGVBQWU7QUFDNUIsU0FBSyxTQUFTLE9BQU8sT0FBTztBQUFBLEVBQzlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxRQUFRLE9BQU8sU0FBUyxLQUFLLFNBQVE7QUFDbkMsUUFBSSxpQkFBaUIsS0FBSyxVQUFVLE9BQU8sU0FBUyxLQUFLLE9BQU87QUFDaEUsUUFBRyxXQUFXLENBQUMsZ0JBQWU7QUFBRSxZQUFNLElBQUksTUFBTSw2RUFBNkU7QUFBQSxJQUFFO0FBRS9ILFFBQUksZ0JBQWdCLEtBQUssU0FBUyxPQUFPLFVBQVEsS0FBSyxVQUFVLFNBQVMsS0FBSyxlQUFlLE1BQU0sU0FBUyxHQUFHLENBQUM7QUFFaEgsYUFBUSxJQUFJLEdBQUcsSUFBSSxjQUFjLFFBQVEsS0FBSTtBQUMzQyxVQUFJLE9BQU8sY0FBYyxDQUFDO0FBQzFCLFdBQUssU0FBUyxnQkFBZ0IsS0FBSyxXQUFXLEtBQUssUUFBUSxDQUFDO0FBQUEsSUFDOUQ7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxlQUFlLEtBQUk7QUFBRSxXQUFPLGNBQWMsR0FBRztBQUFBLEVBQUc7QUFBQSxFQUVoRCxXQUFVO0FBQUUsV0FBTyxLQUFLLFVBQVUsZUFBZTtBQUFBLEVBQU87QUFBQSxFQUV4RCxZQUFXO0FBQUUsV0FBTyxLQUFLLFVBQVUsZUFBZTtBQUFBLEVBQVE7QUFBQSxFQUUxRCxXQUFVO0FBQUUsV0FBTyxLQUFLLFVBQVUsZUFBZTtBQUFBLEVBQU87QUFBQSxFQUV4RCxZQUFXO0FBQUUsV0FBTyxLQUFLLFVBQVUsZUFBZTtBQUFBLEVBQVE7QUFBQSxFQUUxRCxZQUFXO0FBQUUsV0FBTyxLQUFLLFVBQVUsZUFBZTtBQUFBLEVBQVE7QUFDNUQ7OztBQ3JVQSxJQUFxQixPQUFyQixNQUEwQjtBQUFBLEVBRXhCLE9BQU8sUUFBUSxRQUFRLFVBQVUsU0FBUyxNQUFNLFNBQVMsV0FBVyxVQUFTO0FBQzNFLFFBQUcsT0FBTyxnQkFBZTtBQUN2QixVQUFJLE1BQU0sSUFBSSxPQUFPLGVBQWU7QUFDcEMsYUFBTyxLQUFLLGVBQWUsS0FBSyxRQUFRLFVBQVUsTUFBTSxTQUFTLFdBQVcsUUFBUTtBQUFBLElBQ3RGLFdBQVUsT0FBTyxnQkFBZTtBQUM5QixVQUFJLE1BQU0sSUFBSSxPQUFPLGVBQWU7QUFDcEMsYUFBTyxLQUFLLFdBQVcsS0FBSyxRQUFRLFVBQVUsU0FBUyxNQUFNLFNBQVMsV0FBVyxRQUFRO0FBQUEsSUFDM0YsV0FBVSxPQUFPLFNBQVMsT0FBTyxpQkFBZ0I7QUFFL0MsYUFBTyxLQUFLLGFBQWEsUUFBUSxVQUFVLFNBQVMsTUFBTSxTQUFTLFdBQVcsUUFBUTtBQUFBLElBQ3hGLE9BQU87QUFDTCxZQUFNLElBQUksTUFBTSxpREFBaUQ7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE9BQU8sYUFBYSxRQUFRLFVBQVUsU0FBUyxNQUFNLFNBQVMsV0FBVyxVQUFTO0FBQ2hGLFFBQUksVUFBVTtBQUFBLE1BQ1o7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFJLGFBQWE7QUFDakIsUUFBRyxTQUFRO0FBQ1QsbUJBQWEsSUFBSSxnQkFBZ0I7QUFDakMsWUFBTSxhQUFhLFdBQVcsTUFBTSxXQUFXLE1BQU0sR0FBRyxPQUFPO0FBQy9ELGNBQVEsU0FBUyxXQUFXO0FBQUEsSUFDOUI7QUFDQSxXQUFPLE1BQU0sVUFBVSxPQUFPLEVBQzNCLEtBQUssY0FBWSxTQUFTLEtBQUssQ0FBQyxFQUNoQyxLQUFLLFVBQVEsS0FBSyxVQUFVLElBQUksQ0FBQyxFQUNqQyxLQUFLLFVBQVEsWUFBWSxTQUFTLElBQUksQ0FBQyxFQUN2QyxNQUFNLFNBQU87QUFDWixVQUFHLElBQUksU0FBUyxnQkFBZ0IsV0FBVTtBQUN4QyxrQkFBVTtBQUFBLE1BQ1osT0FBTztBQUNMLG9CQUFZLFNBQVMsSUFBSTtBQUFBLE1BQzNCO0FBQUEsSUFDRixDQUFDO0FBQ0gsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE9BQU8sZUFBZSxLQUFLLFFBQVEsVUFBVSxNQUFNLFNBQVMsV0FBVyxVQUFTO0FBQzlFLFFBQUksVUFBVTtBQUNkLFFBQUksS0FBSyxRQUFRLFFBQVE7QUFDekIsUUFBSSxTQUFTLE1BQU07QUFDakIsVUFBSSxXQUFXLEtBQUssVUFBVSxJQUFJLFlBQVk7QUFDOUMsa0JBQVksU0FBUyxRQUFRO0FBQUEsSUFDL0I7QUFDQSxRQUFHLFdBQVU7QUFBRSxVQUFJLFlBQVk7QUFBQSxJQUFVO0FBR3pDLFFBQUksYUFBYSxNQUFNO0FBQUEsSUFBRTtBQUV6QixRQUFJLEtBQUssSUFBSTtBQUNiLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxPQUFPLFdBQVcsS0FBSyxRQUFRLFVBQVUsU0FBUyxNQUFNLFNBQVMsV0FBVyxVQUFTO0FBQ25GLFFBQUksS0FBSyxRQUFRLFVBQVUsSUFBSTtBQUMvQixRQUFJLFVBQVU7QUFDZCxhQUFRLENBQUMsS0FBSyxLQUFLLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRTtBQUM5QyxVQUFJLGlCQUFpQixLQUFLLEtBQUs7QUFBQSxJQUNqQztBQUNBLFFBQUksVUFBVSxNQUFNLFlBQVksU0FBUyxJQUFJO0FBQzdDLFFBQUkscUJBQXFCLE1BQU07QUFDN0IsVUFBRyxJQUFJLGVBQWUsV0FBVyxZQUFZLFVBQVM7QUFDcEQsWUFBSSxXQUFXLEtBQUssVUFBVSxJQUFJLFlBQVk7QUFDOUMsaUJBQVMsUUFBUTtBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUNBLFFBQUcsV0FBVTtBQUFFLFVBQUksWUFBWTtBQUFBLElBQVU7QUFFekMsUUFBSSxLQUFLLElBQUk7QUFDYixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsT0FBTyxVQUFVLE1BQUs7QUFDcEIsUUFBRyxDQUFDLFFBQVEsU0FBUyxJQUFHO0FBQUUsYUFBTztBQUFBLElBQUs7QUFFdEMsUUFBSTtBQUNGLGFBQU8sS0FBSyxNQUFNLElBQUk7QUFBQSxJQUN4QixRQUFRO0FBQ04saUJBQVcsUUFBUSxJQUFJLGlDQUFpQyxJQUFJO0FBQzVELGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBLEVBRUEsT0FBTyxVQUFVLEtBQUssV0FBVTtBQUM5QixRQUFJLFdBQVcsQ0FBQztBQUNoQixhQUFRLE9BQU8sS0FBSTtBQUNqQixVQUFHLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxLQUFLLEdBQUcsR0FBRTtBQUFFO0FBQUEsTUFBUztBQUM5RCxVQUFJLFdBQVcsWUFBWSxHQUFHLFNBQVMsSUFBSSxHQUFHLE1BQU07QUFDcEQsVUFBSSxXQUFXLElBQUksR0FBRztBQUN0QixVQUFHLE9BQU8sYUFBYSxVQUFTO0FBQzlCLGlCQUFTLEtBQUssS0FBSyxVQUFVLFVBQVUsUUFBUSxDQUFDO0FBQUEsTUFDbEQsT0FBTztBQUNMLGlCQUFTLEtBQUssbUJBQW1CLFFBQVEsSUFBSSxNQUFNLG1CQUFtQixRQUFRLENBQUM7QUFBQSxNQUNqRjtBQUFBLElBQ0Y7QUFDQSxXQUFPLFNBQVMsS0FBSyxHQUFHO0FBQUEsRUFDMUI7QUFBQSxFQUVBLE9BQU8sYUFBYSxLQUFLLFFBQU87QUFDOUIsUUFBRyxPQUFPLEtBQUssTUFBTSxFQUFFLFdBQVcsR0FBRTtBQUFFLGFBQU87QUFBQSxJQUFJO0FBRWpELFFBQUksU0FBUyxJQUFJLE1BQU0sSUFBSSxJQUFJLE1BQU07QUFDckMsV0FBTyxHQUFHLEdBQUcsR0FBRyxNQUFNLEdBQUcsS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUFBLEVBQ2pEO0FBQ0Y7OztBQzNHQSxJQUFJLHNCQUFzQixDQUFDLFdBQVc7QUFDcEMsTUFBSSxTQUFTO0FBQ2IsTUFBSSxRQUFRLElBQUksV0FBVyxNQUFNO0FBQ2pDLE1BQUksTUFBTSxNQUFNO0FBQ2hCLFdBQVEsSUFBSSxHQUFHLElBQUksS0FBSyxLQUFJO0FBQUUsY0FBVSxPQUFPLGFBQWEsTUFBTSxDQUFDLENBQUM7QUFBQSxFQUFFO0FBQ3RFLFNBQU8sS0FBSyxNQUFNO0FBQ3BCO0FBRUEsSUFBcUIsV0FBckIsTUFBOEI7QUFBQSxFQUU1QixZQUFZLFVBQVUsV0FBVTtBQUc5QixRQUFHLGFBQWEsVUFBVSxXQUFXLEtBQUssVUFBVSxDQUFDLEVBQUUsV0FBVyxpQkFBaUIsR0FBRTtBQUNuRixXQUFLLFlBQVksS0FBSyxVQUFVLENBQUMsRUFBRSxNQUFNLGtCQUFrQixNQUFNLENBQUM7QUFBQSxJQUNwRTtBQUNBLFNBQUssV0FBVztBQUNoQixTQUFLLFFBQVE7QUFDYixTQUFLLGdCQUFnQjtBQUNyQixTQUFLLE9BQU8sb0JBQUksSUFBSTtBQUNwQixTQUFLLG1CQUFtQjtBQUN4QixTQUFLLGVBQWU7QUFDcEIsU0FBSyxvQkFBb0I7QUFDekIsU0FBSyxjQUFjLENBQUM7QUFDcEIsU0FBSyxTQUFTLFdBQVc7QUFBQSxJQUFFO0FBQzNCLFNBQUssVUFBVSxXQUFXO0FBQUEsSUFBRTtBQUM1QixTQUFLLFlBQVksV0FBVztBQUFBLElBQUU7QUFDOUIsU0FBSyxVQUFVLFdBQVc7QUFBQSxJQUFFO0FBQzVCLFNBQUssZUFBZSxLQUFLLGtCQUFrQixRQUFRO0FBQ25ELFNBQUssYUFBYSxjQUFjO0FBRWhDLGVBQVcsTUFBTSxLQUFLLEtBQUssR0FBRyxDQUFDO0FBQUEsRUFDakM7QUFBQSxFQUVBLGtCQUFrQixVQUFTO0FBQ3pCLFdBQVEsU0FDTCxRQUFRLFNBQVMsU0FBUyxFQUMxQixRQUFRLFVBQVUsVUFBVSxFQUM1QixRQUFRLElBQUksT0FBTyxVQUFXLFdBQVcsU0FBUyxHQUFHLFFBQVEsV0FBVyxRQUFRO0FBQUEsRUFDckY7QUFBQSxFQUVBLGNBQWE7QUFDWCxXQUFPLEtBQUssYUFBYSxLQUFLLGNBQWMsRUFBQyxPQUFPLEtBQUssTUFBSyxDQUFDO0FBQUEsRUFDakU7QUFBQSxFQUVBLGNBQWMsTUFBTSxRQUFRLFVBQVM7QUFDbkMsU0FBSyxNQUFNLE1BQU0sUUFBUSxRQUFRO0FBQ2pDLFNBQUssYUFBYSxjQUFjO0FBQUEsRUFDbEM7QUFBQSxFQUVBLFlBQVc7QUFDVCxTQUFLLFFBQVEsU0FBUztBQUN0QixTQUFLLGNBQWMsTUFBTSxXQUFXLEtBQUs7QUFBQSxFQUMzQztBQUFBLEVBRUEsV0FBVTtBQUFFLFdBQU8sS0FBSyxlQUFlLGNBQWMsUUFBUSxLQUFLLGVBQWUsY0FBYztBQUFBLEVBQVc7QUFBQSxFQUUxRyxPQUFNO0FBQ0osVUFBTSxVQUFVLEVBQUMsVUFBVSxtQkFBa0I7QUFDN0MsUUFBRyxLQUFLLFdBQVU7QUFDaEIsY0FBUSxxQkFBcUIsSUFBSSxLQUFLO0FBQUEsSUFDeEM7QUFDQSxTQUFLLEtBQUssT0FBTyxTQUFTLE1BQU0sTUFBTSxLQUFLLFVBQVUsR0FBRyxVQUFRO0FBQzlELFVBQUcsTUFBSztBQUNOLFlBQUksRUFBQyxRQUFRLE9BQU8sU0FBUSxJQUFJO0FBQ2hDLFlBQUcsV0FBVyxPQUFPLEtBQUssVUFBVSxNQUFLO0FBR3ZDLGVBQUssUUFBUSxHQUFHO0FBQ2hCLGVBQUssY0FBYyxNQUFNLGdCQUFnQixLQUFLO0FBQzlDO0FBQUEsUUFDRjtBQUNBLGFBQUssUUFBUTtBQUFBLE1BQ2YsT0FBTztBQUNMLGlCQUFTO0FBQUEsTUFDWDtBQUVBLGNBQU8sUUFBTztBQUFBLFFBQ1osS0FBSztBQUNILG1CQUFTLFFBQVEsU0FBTztBQW1CdEIsdUJBQVcsTUFBTSxLQUFLLFVBQVUsRUFBQyxNQUFNLElBQUcsQ0FBQyxHQUFHLENBQUM7QUFBQSxVQUNqRCxDQUFDO0FBQ0QsZUFBSyxLQUFLO0FBQ1Y7QUFBQSxRQUNGLEtBQUs7QUFDSCxlQUFLLEtBQUs7QUFDVjtBQUFBLFFBQ0YsS0FBSztBQUNILGVBQUssYUFBYSxjQUFjO0FBQ2hDLGVBQUssT0FBTyxDQUFDLENBQUM7QUFDZCxlQUFLLEtBQUs7QUFDVjtBQUFBLFFBQ0YsS0FBSztBQUNILGVBQUssUUFBUSxHQUFHO0FBQ2hCLGVBQUssTUFBTSxNQUFNLGFBQWEsS0FBSztBQUNuQztBQUFBLFFBQ0YsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNILGVBQUssUUFBUSxHQUFHO0FBQ2hCLGVBQUssY0FBYyxNQUFNLHlCQUF5QixHQUFHO0FBQ3JEO0FBQUEsUUFDRjtBQUFTLGdCQUFNLElBQUksTUFBTSx5QkFBeUIsTUFBTSxFQUFFO0FBQUEsTUFDNUQ7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxLQUFLLE1BQUs7QUFDUixRQUFHLE9BQU8sU0FBVSxVQUFTO0FBQUUsYUFBTyxvQkFBb0IsSUFBSTtBQUFBLElBQUU7QUFDaEUsUUFBRyxLQUFLLGNBQWE7QUFDbkIsV0FBSyxhQUFhLEtBQUssSUFBSTtBQUFBLElBQzdCLFdBQVUsS0FBSyxrQkFBaUI7QUFDOUIsV0FBSyxZQUFZLEtBQUssSUFBSTtBQUFBLElBQzVCLE9BQU87QUFDTCxXQUFLLGVBQWUsQ0FBQyxJQUFJO0FBQ3pCLFdBQUssb0JBQW9CLFdBQVcsTUFBTTtBQUN4QyxhQUFLLFVBQVUsS0FBSyxZQUFZO0FBQ2hDLGFBQUssZUFBZTtBQUFBLE1BQ3RCLEdBQUcsQ0FBQztBQUFBLElBQ047QUFBQSxFQUNGO0FBQUEsRUFFQSxVQUFVLFVBQVM7QUFDakIsU0FBSyxtQkFBbUI7QUFDeEIsU0FBSyxLQUFLLFFBQVEsRUFBQyxnQkFBZ0IsdUJBQXNCLEdBQUcsU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLEtBQUssUUFBUSxTQUFTLEdBQUcsVUFBUTtBQUN0SCxXQUFLLG1CQUFtQjtBQUN4QixVQUFHLENBQUMsUUFBUSxLQUFLLFdBQVcsS0FBSTtBQUM5QixhQUFLLFFBQVEsUUFBUSxLQUFLLE1BQU07QUFDaEMsYUFBSyxjQUFjLE1BQU0seUJBQXlCLEtBQUs7QUFBQSxNQUN6RCxXQUFVLEtBQUssWUFBWSxTQUFTLEdBQUU7QUFDcEMsYUFBSyxVQUFVLEtBQUssV0FBVztBQUMvQixhQUFLLGNBQWMsQ0FBQztBQUFBLE1BQ3RCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxNQUFNLFFBQVEsVUFBUztBQUMzQixhQUFRLE9BQU8sS0FBSyxNQUFLO0FBQUUsVUFBSSxNQUFNO0FBQUEsSUFBRTtBQUN2QyxTQUFLLGFBQWEsY0FBYztBQUNoQyxRQUFJLE9BQU8sT0FBTyxPQUFPLEVBQUMsTUFBTSxLQUFNLFFBQVEsUUFBVyxVQUFVLEtBQUksR0FBRyxFQUFDLE1BQU0sUUFBUSxTQUFRLENBQUM7QUFDbEcsU0FBSyxjQUFjLENBQUM7QUFDcEIsaUJBQWEsS0FBSyxpQkFBaUI7QUFDbkMsU0FBSyxvQkFBb0I7QUFDekIsUUFBRyxPQUFPLGVBQWdCLGFBQVk7QUFDcEMsV0FBSyxRQUFRLElBQUksV0FBVyxTQUFTLElBQUksQ0FBQztBQUFBLElBQzVDLE9BQU87QUFDTCxXQUFLLFFBQVEsSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUFBLEVBRUEsS0FBSyxRQUFRLFNBQVMsTUFBTSxpQkFBaUIsVUFBUztBQUNwRCxRQUFJO0FBQ0osUUFBSSxZQUFZLE1BQU07QUFDcEIsV0FBSyxLQUFLLE9BQU8sR0FBRztBQUNwQixzQkFBZ0I7QUFBQSxJQUNsQjtBQUNBLFVBQU0sS0FBSyxRQUFRLFFBQVEsS0FBSyxZQUFZLEdBQUcsU0FBUyxNQUFNLEtBQUssU0FBUyxXQUFXLFVBQVE7QUFDN0YsV0FBSyxLQUFLLE9BQU8sR0FBRztBQUNwQixVQUFHLEtBQUssU0FBUyxHQUFFO0FBQUUsaUJBQVMsSUFBSTtBQUFBLE1BQUU7QUFBQSxJQUN0QyxDQUFDO0FBQ0QsU0FBSyxLQUFLLElBQUksR0FBRztBQUFBLEVBQ25CO0FBQ0Y7OztBQzNMQSxJQUFxQixXQUFyQixNQUFxQixVQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTzVCLFlBQVksU0FBUyxPQUFPLENBQUMsR0FBRTtBQUM3QixRQUFJLFNBQVMsS0FBSztBQUFBLElBQXlDLEVBQUMsT0FBTyxrQkFBa0IsTUFBTSxnQkFBZTtBQUUxRyxTQUFLLFFBQVEsQ0FBQztBQUVkLFNBQUssZUFBZSxDQUFDO0FBRXJCLFNBQUssVUFBVTtBQUVmLFNBQUssVUFBVTtBQUVmLFNBQUssU0FBUztBQUFBLE1BQ1osUUFBUSxXQUFXO0FBQUEsTUFBRTtBQUFBLE1BQ3JCLFNBQVMsV0FBVztBQUFBLE1BQUU7QUFBQSxNQUN0QixRQUFRLFdBQVc7QUFBQSxNQUFFO0FBQUEsSUFDdkI7QUFFQSxTQUFLLFFBQVEsR0FBRyxPQUFPLE9BQU8sY0FBWTtBQUN4QyxVQUFJLEVBQUMsUUFBUSxTQUFTLE9BQU0sSUFBSSxLQUFLO0FBRXJDLFdBQUssVUFBVSxLQUFLLFFBQVEsUUFBUTtBQUNwQyxXQUFLLFFBQVEsVUFBUyxVQUFVLEtBQUssT0FBTyxVQUFVLFFBQVEsT0FBTztBQUVyRSxXQUFLLGFBQWEsUUFBUSxVQUFRO0FBQ2hDLGFBQUssUUFBUSxVQUFTLFNBQVMsS0FBSyxPQUFPLE1BQU0sUUFBUSxPQUFPO0FBQUEsTUFDbEUsQ0FBQztBQUNELFdBQUssZUFBZSxDQUFDO0FBQ3JCLGFBQU87QUFBQSxJQUNULENBQUM7QUFFRCxTQUFLLFFBQVEsR0FBRyxPQUFPLE1BQU0sVUFBUTtBQUNuQyxVQUFJLEVBQUMsUUFBUSxTQUFTLE9BQU0sSUFBSSxLQUFLO0FBRXJDLFVBQUcsS0FBSyxtQkFBbUIsR0FBRTtBQUMzQixhQUFLLGFBQWEsS0FBSyxJQUFJO0FBQUEsTUFDN0IsT0FBTztBQUNMLGFBQUssUUFBUSxVQUFTLFNBQVMsS0FBSyxPQUFPLE1BQU0sUUFBUSxPQUFPO0FBQ2hFLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsT0FBTyxVQUFTO0FBQUUsU0FBSyxPQUFPLFNBQVM7QUFBQSxFQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLaEQsUUFBUSxVQUFTO0FBQUUsU0FBSyxPQUFPLFVBQVU7QUFBQSxFQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLbEQsT0FBTyxVQUFTO0FBQUUsU0FBSyxPQUFPLFNBQVM7QUFBQSxFQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVWhELEtBQUssSUFBRztBQUFFLFdBQU8sVUFBUyxLQUFLLEtBQUssT0FBTyxFQUFFO0FBQUEsRUFBRTtBQUFBLEVBRS9DLHFCQUFvQjtBQUNsQixXQUFPLENBQUMsS0FBSyxXQUFZLEtBQUssWUFBWSxLQUFLLFFBQVEsUUFBUTtBQUFBLEVBQ2pFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBaUJBLE9BQU8sVUFBVSxjQUFjLFVBQVUsUUFBUSxTQUFRO0FBQ3ZELFFBQUksUUFBUSxLQUFLLE1BQU0sWUFBWTtBQUNuQyxRQUFJLFFBQVEsQ0FBQztBQUNiLFFBQUksU0FBUyxDQUFDO0FBRWQsU0FBSyxJQUFJLE9BQU8sQ0FBQyxLQUFLLGFBQWE7QUFDakMsVUFBRyxDQUFDLFNBQVMsR0FBRyxHQUFFO0FBQ2hCLGVBQU8sR0FBRyxJQUFJO0FBQUEsTUFDaEI7QUFBQSxJQUNGLENBQUM7QUFDRCxTQUFLLElBQUksVUFBVSxDQUFDLEtBQUssZ0JBQWdCO0FBQ3ZDLFVBQUksa0JBQWtCLE1BQU0sR0FBRztBQUMvQixVQUFHLGlCQUFnQjtBQUNqQixZQUFJLFVBQVUsWUFBWSxNQUFNLElBQUksT0FBSyxFQUFFLE9BQU87QUFDbEQsWUFBSSxVQUFVLGdCQUFnQixNQUFNLElBQUksT0FBSyxFQUFFLE9BQU87QUFDdEQsWUFBSSxjQUFjLFlBQVksTUFBTSxPQUFPLE9BQUssUUFBUSxRQUFRLEVBQUUsT0FBTyxJQUFJLENBQUM7QUFDOUUsWUFBSSxZQUFZLGdCQUFnQixNQUFNLE9BQU8sT0FBSyxRQUFRLFFBQVEsRUFBRSxPQUFPLElBQUksQ0FBQztBQUNoRixZQUFHLFlBQVksU0FBUyxHQUFFO0FBQ3hCLGdCQUFNLEdBQUcsSUFBSTtBQUNiLGdCQUFNLEdBQUcsRUFBRSxRQUFRO0FBQUEsUUFDckI7QUFDQSxZQUFHLFVBQVUsU0FBUyxHQUFFO0FBQ3RCLGlCQUFPLEdBQUcsSUFBSSxLQUFLLE1BQU0sZUFBZTtBQUN4QyxpQkFBTyxHQUFHLEVBQUUsUUFBUTtBQUFBLFFBQ3RCO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxHQUFHLElBQUk7QUFBQSxNQUNmO0FBQUEsSUFDRixDQUFDO0FBQ0QsV0FBTyxLQUFLLFNBQVMsT0FBTyxFQUFDLE9BQWMsT0FBYyxHQUFHLFFBQVEsT0FBTztBQUFBLEVBQzdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZ0JBLE9BQU8sU0FBUyxPQUFPLE1BQU0sUUFBUSxTQUFRO0FBQzNDLFFBQUksRUFBQyxPQUFPLE9BQU0sSUFBSSxLQUFLLE1BQU0sSUFBSTtBQUNyQyxRQUFHLENBQUMsUUFBTztBQUFFLGVBQVMsV0FBVztBQUFBLE1BQUU7QUFBQSxJQUFFO0FBQ3JDLFFBQUcsQ0FBQyxTQUFRO0FBQUUsZ0JBQVUsV0FBVztBQUFBLE1BQUU7QUFBQSxJQUFFO0FBRXZDLFNBQUssSUFBSSxPQUFPLENBQUMsS0FBSyxnQkFBZ0I7QUFDcEMsVUFBSSxrQkFBa0IsTUFBTSxHQUFHO0FBQy9CLFlBQU0sR0FBRyxJQUFJLEtBQUssTUFBTSxXQUFXO0FBQ25DLFVBQUcsaUJBQWdCO0FBQ2pCLFlBQUksYUFBYSxNQUFNLEdBQUcsRUFBRSxNQUFNLElBQUksT0FBSyxFQUFFLE9BQU87QUFDcEQsWUFBSSxXQUFXLGdCQUFnQixNQUFNLE9BQU8sT0FBSyxXQUFXLFFBQVEsRUFBRSxPQUFPLElBQUksQ0FBQztBQUNsRixjQUFNLEdBQUcsRUFBRSxNQUFNLFFBQVEsR0FBRyxRQUFRO0FBQUEsTUFDdEM7QUFDQSxhQUFPLEtBQUssaUJBQWlCLFdBQVc7QUFBQSxJQUMxQyxDQUFDO0FBQ0QsU0FBSyxJQUFJLFFBQVEsQ0FBQyxLQUFLLGlCQUFpQjtBQUN0QyxVQUFJLGtCQUFrQixNQUFNLEdBQUc7QUFDL0IsVUFBRyxDQUFDLGlCQUFnQjtBQUFFO0FBQUEsTUFBTztBQUM3QixVQUFJLGVBQWUsYUFBYSxNQUFNLElBQUksT0FBSyxFQUFFLE9BQU87QUFDeEQsc0JBQWdCLFFBQVEsZ0JBQWdCLE1BQU0sT0FBTyxPQUFLO0FBQ3hELGVBQU8sYUFBYSxRQUFRLEVBQUUsT0FBTyxJQUFJO0FBQUEsTUFDM0MsQ0FBQztBQUNELGNBQVEsS0FBSyxpQkFBaUIsWUFBWTtBQUMxQyxVQUFHLGdCQUFnQixNQUFNLFdBQVcsR0FBRTtBQUNwQyxlQUFPLE1BQU0sR0FBRztBQUFBLE1BQ2xCO0FBQUEsSUFDRixDQUFDO0FBQ0QsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBLE9BQU8sS0FBSyxXQUFXLFNBQVE7QUFDN0IsUUFBRyxDQUFDLFNBQVE7QUFBRSxnQkFBVSxTQUFVLEtBQUssTUFBSztBQUFFLGVBQU87QUFBQSxNQUFLO0FBQUEsSUFBRTtBQUU1RCxXQUFPLEtBQUssSUFBSSxXQUFXLENBQUMsS0FBSyxhQUFhO0FBQzVDLGFBQU8sUUFBUSxLQUFLLFFBQVE7QUFBQSxJQUM5QixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0EsT0FBTyxJQUFJLEtBQUssTUFBSztBQUNuQixXQUFPLE9BQU8sb0JBQW9CLEdBQUcsRUFBRSxJQUFJLFNBQU8sS0FBSyxLQUFLLElBQUksR0FBRyxDQUFDLENBQUM7QUFBQSxFQUN2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE9BQU8sTUFBTSxLQUFJO0FBQUUsV0FBTyxLQUFLLE1BQU0sS0FBSyxVQUFVLEdBQUcsQ0FBQztBQUFBLEVBQUU7QUFDNUQ7OztBQ3RNQSxJQUFPLHFCQUFRO0FBQUEsRUFDYixlQUFlO0FBQUEsRUFDZixhQUFhO0FBQUEsRUFDYixPQUFPLEVBQUMsTUFBTSxHQUFHLE9BQU8sR0FBRyxXQUFXLEVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVF2QyxPQUFPLEtBQUssVUFBUztBQUNuQixRQUFHLElBQUksUUFBUSxnQkFBZ0IsYUFBWTtBQUN6QyxhQUFPLFNBQVMsS0FBSyxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQ3hDLE9BQU87QUFDTCxVQUFJLFVBQVUsQ0FBQyxJQUFJLFVBQVUsSUFBSSxLQUFLLElBQUksT0FBTyxJQUFJLE9BQU8sSUFBSSxPQUFPO0FBQ3ZFLGFBQU8sU0FBUyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQUEsSUFDekM7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxPQUFPLFlBQVksVUFBUztBQUMxQixRQUFHLFdBQVcsZ0JBQWdCLGFBQVk7QUFDeEMsYUFBTyxTQUFTLEtBQUssYUFBYSxVQUFVLENBQUM7QUFBQSxJQUMvQyxPQUFPO0FBQ0wsVUFBSSxDQUFDLFVBQVUsS0FBSyxPQUFPLE9BQU8sT0FBTyxJQUFJLEtBQUssTUFBTSxVQUFVO0FBQ2xFLGFBQU8sU0FBUyxFQUFDLFVBQVUsS0FBSyxPQUFPLE9BQU8sUUFBTyxDQUFDO0FBQUEsSUFDeEQ7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLGFBQWEsU0FBUTtBQUNuQixRQUFJLEVBQUMsVUFBVSxLQUFLLE9BQU8sT0FBTyxRQUFPLElBQUk7QUFDN0MsUUFBSSxhQUFhLEtBQUssY0FBYyxTQUFTLFNBQVMsSUFBSSxTQUFTLE1BQU0sU0FBUyxNQUFNO0FBQ3hGLFFBQUksU0FBUyxJQUFJLFlBQVksS0FBSyxnQkFBZ0IsVUFBVTtBQUM1RCxRQUFJLE9BQU8sSUFBSSxTQUFTLE1BQU07QUFDOUIsUUFBSSxTQUFTO0FBRWIsU0FBSyxTQUFTLFVBQVUsS0FBSyxNQUFNLElBQUk7QUFDdkMsU0FBSyxTQUFTLFVBQVUsU0FBUyxNQUFNO0FBQ3ZDLFNBQUssU0FBUyxVQUFVLElBQUksTUFBTTtBQUNsQyxTQUFLLFNBQVMsVUFBVSxNQUFNLE1BQU07QUFDcEMsU0FBSyxTQUFTLFVBQVUsTUFBTSxNQUFNO0FBQ3BDLFVBQU0sS0FBSyxVQUFVLFVBQVEsS0FBSyxTQUFTLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3hFLFVBQU0sS0FBSyxLQUFLLFVBQVEsS0FBSyxTQUFTLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ25FLFVBQU0sS0FBSyxPQUFPLFVBQVEsS0FBSyxTQUFTLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3JFLFVBQU0sS0FBSyxPQUFPLFVBQVEsS0FBSyxTQUFTLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBRXJFLFFBQUksV0FBVyxJQUFJLFdBQVcsT0FBTyxhQUFhLFFBQVEsVUFBVTtBQUNwRSxhQUFTLElBQUksSUFBSSxXQUFXLE1BQU0sR0FBRyxDQUFDO0FBQ3RDLGFBQVMsSUFBSSxJQUFJLFdBQVcsT0FBTyxHQUFHLE9BQU8sVUFBVTtBQUV2RCxXQUFPLFNBQVM7QUFBQSxFQUNsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsYUFBYSxRQUFPO0FBQ2xCLFFBQUksT0FBTyxJQUFJLFNBQVMsTUFBTTtBQUM5QixRQUFJLE9BQU8sS0FBSyxTQUFTLENBQUM7QUFDMUIsUUFBSSxVQUFVLElBQUksWUFBWTtBQUM5QixZQUFPLE1BQUs7QUFBQSxNQUNWLEtBQUssS0FBSyxNQUFNO0FBQU0sZUFBTyxLQUFLLFdBQVcsUUFBUSxNQUFNLE9BQU87QUFBQSxNQUNsRSxLQUFLLEtBQUssTUFBTTtBQUFPLGVBQU8sS0FBSyxZQUFZLFFBQVEsTUFBTSxPQUFPO0FBQUEsTUFDcEUsS0FBSyxLQUFLLE1BQU07QUFBVyxlQUFPLEtBQUssZ0JBQWdCLFFBQVEsTUFBTSxPQUFPO0FBQUEsSUFDOUU7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLFdBQVcsUUFBUSxNQUFNLFNBQVE7QUFDL0IsUUFBSSxjQUFjLEtBQUssU0FBUyxDQUFDO0FBQ2pDLFFBQUksWUFBWSxLQUFLLFNBQVMsQ0FBQztBQUMvQixRQUFJLFlBQVksS0FBSyxTQUFTLENBQUM7QUFDL0IsUUFBSSxTQUFTLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUNyRCxRQUFJLFVBQVUsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsV0FBVyxDQUFDO0FBQ3ZFLGFBQVMsU0FBUztBQUNsQixRQUFJLFFBQVEsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsU0FBUyxDQUFDO0FBQ25FLGFBQVMsU0FBUztBQUNsQixRQUFJLFFBQVEsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsU0FBUyxDQUFDO0FBQ25FLGFBQVMsU0FBUztBQUNsQixRQUFJLE9BQU8sT0FBTyxNQUFNLFFBQVEsT0FBTyxVQUFVO0FBQ2pELFdBQU8sRUFBQyxVQUFVLFNBQVMsS0FBSyxNQUFNLE9BQWMsT0FBYyxTQUFTLEtBQUk7QUFBQSxFQUNqRjtBQUFBO0FBQUEsRUFHQSxZQUFZLFFBQVEsTUFBTSxTQUFRO0FBQ2hDLFFBQUksY0FBYyxLQUFLLFNBQVMsQ0FBQztBQUNqQyxRQUFJLFVBQVUsS0FBSyxTQUFTLENBQUM7QUFDN0IsUUFBSSxZQUFZLEtBQUssU0FBUyxDQUFDO0FBQy9CLFFBQUksWUFBWSxLQUFLLFNBQVMsQ0FBQztBQUMvQixRQUFJLFNBQVMsS0FBSyxnQkFBZ0IsS0FBSztBQUN2QyxRQUFJLFVBQVUsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsV0FBVyxDQUFDO0FBQ3ZFLGFBQVMsU0FBUztBQUNsQixRQUFJLE1BQU0sUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsT0FBTyxDQUFDO0FBQy9ELGFBQVMsU0FBUztBQUNsQixRQUFJLFFBQVEsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsU0FBUyxDQUFDO0FBQ25FLGFBQVMsU0FBUztBQUNsQixRQUFJLFFBQVEsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsU0FBUyxDQUFDO0FBQ25FLGFBQVMsU0FBUztBQUNsQixRQUFJLE9BQU8sT0FBTyxNQUFNLFFBQVEsT0FBTyxVQUFVO0FBQ2pELFFBQUksVUFBVSxFQUFDLFFBQVEsT0FBTyxVQUFVLEtBQUk7QUFDNUMsV0FBTyxFQUFDLFVBQVUsU0FBUyxLQUFVLE9BQWMsT0FBTyxlQUFlLE9BQU8sUUFBZ0I7QUFBQSxFQUNsRztBQUFBO0FBQUEsRUFHQSxnQkFBZ0IsUUFBUSxNQUFNLFNBQVE7QUFDcEMsUUFBSSxZQUFZLEtBQUssU0FBUyxDQUFDO0FBQy9CLFFBQUksWUFBWSxLQUFLLFNBQVMsQ0FBQztBQUMvQixRQUFJLFNBQVMsS0FBSyxnQkFBZ0I7QUFDbEMsUUFBSSxRQUFRLFFBQVEsT0FBTyxPQUFPLE1BQU0sUUFBUSxTQUFTLFNBQVMsQ0FBQztBQUNuRSxhQUFTLFNBQVM7QUFDbEIsUUFBSSxRQUFRLFFBQVEsT0FBTyxPQUFPLE1BQU0sUUFBUSxTQUFTLFNBQVMsQ0FBQztBQUNuRSxhQUFTLFNBQVM7QUFDbEIsUUFBSSxPQUFPLE9BQU8sTUFBTSxRQUFRLE9BQU8sVUFBVTtBQUVqRCxXQUFPLEVBQUMsVUFBVSxNQUFNLEtBQUssTUFBTSxPQUFjLE9BQWMsU0FBUyxLQUFJO0FBQUEsRUFDOUU7QUFDRjs7O0FDMUdBLElBQXFCLFNBQXJCLE1BQTRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVcxQixZQUFZLFVBQVUsT0FBTyxDQUFDLEdBQUU7QUFFOUIsU0FBSyx1QkFBdUIsRUFBQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsR0FBRyxPQUFPLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBQztBQUV4RSxTQUFLLFdBQVcsQ0FBQztBQUVqQixTQUFLLGFBQWEsQ0FBQztBQUVuQixTQUFLLE1BQU07QUFFWCxTQUFLLGNBQWM7QUFFbkIsU0FBSyxVQUFVLEtBQUssV0FBVztBQUUvQixTQUFLLFlBQVksS0FBSyxhQUFhLE9BQU8sYUFBYTtBQUV2RCxTQUFLLE9BQU87QUFFWixTQUFLLDJCQUEyQjtBQUVoQyxTQUFLLHFCQUFxQixLQUFLO0FBRS9CLFNBQUssZ0JBQWdCO0FBS3JCLFFBQUksb0JBQW9CO0FBQ3hCLFFBQUk7QUFBRSwwQkFBb0IsVUFBVSxPQUFPO0FBQUEsSUFBZSxRQUFRO0FBQUEsSUFBQztBQUVuRSxTQUFLLGVBQWUsS0FBSyxrQkFBa0I7QUFFM0MsU0FBSyx5QkFBeUI7QUFFOUIsU0FBSyxpQkFBaUIsbUJBQVcsT0FBTyxLQUFLLGtCQUFVO0FBRXZELFNBQUssaUJBQWlCLG1CQUFXLE9BQU8sS0FBSyxrQkFBVTtBQUt2RCxTQUFLLGdCQUFnQjtBQUVyQixTQUFLLGdCQUFnQjtBQUVyQixTQUFLLGFBQWEsS0FBSyxjQUFjO0FBRXJDLFNBQUssZUFBZTtBQUVwQixTQUFLLGFBQWE7QUFFbEIsU0FBSyxTQUFTO0FBRWQsU0FBSyxTQUFTO0FBQ2QsUUFBRyxLQUFLLGNBQWMsVUFBUztBQUM3QixXQUFLLFNBQVMsS0FBSyxVQUFVLEtBQUs7QUFDbEMsV0FBSyxTQUFTLEtBQUssVUFBVSxLQUFLO0FBQUEsSUFDcEMsT0FBTztBQUNMLFdBQUssU0FBUyxLQUFLO0FBQ25CLFdBQUssU0FBUyxLQUFLO0FBQUEsSUFDckI7QUFFQSxRQUFJLCtCQUErQjtBQUNuQyxRQUFHLGFBQWEsVUFBVSxrQkFBaUI7QUFDekMsZ0JBQVUsaUJBQWlCLFlBQVksUUFBTTtBQUMzQyxZQUFHLEtBQUssTUFBSztBQUNYLGVBQUssV0FBVztBQUNoQix5Q0FBK0IsS0FBSztBQUFBLFFBQ3RDO0FBQUEsTUFDRixDQUFDO0FBQ0QsZ0JBQVUsaUJBQWlCLFlBQVksUUFBTTtBQUMzQyxZQUFHLGlDQUFpQyxLQUFLLGNBQWE7QUFDcEQseUNBQStCO0FBQy9CLGVBQUssUUFBUTtBQUFBLFFBQ2Y7QUFBQSxNQUNGLENBQUM7QUFDRCxnQkFBVSxpQkFBaUIsb0JBQW9CLE1BQU07QUFDbkQsWUFBRyxTQUFTLG9CQUFvQixVQUFTO0FBQ3ZDLGVBQUssYUFBYTtBQUFBLFFBQ3BCLE9BQU87QUFDTCxlQUFLLGFBQWE7QUFFbEIsY0FBRyxDQUFDLEtBQUssWUFBWSxLQUFLLENBQUMsS0FBSyxlQUFjO0FBQzVDLGlCQUFLLFNBQVMsTUFBTSxLQUFLLFFBQVEsQ0FBQztBQUFBLFVBQ3BDO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFFQSxTQUFLLHNCQUFzQixLQUFLLHVCQUF1QjtBQUV2RCxTQUFLLG9CQUFvQixLQUFLLHFCQUFxQjtBQUVuRCxTQUFLLG9CQUFvQixLQUFLLHNCQUFzQixNQUFNO0FBQUEsSUFBQztBQUUzRCxTQUFLLGdCQUFnQixDQUFDLFVBQVU7QUFDOUIsVUFBRyxLQUFLLGVBQWM7QUFDcEIsZUFBTyxLQUFLLGNBQWMsS0FBSztBQUFBLE1BQ2pDLE9BQU87QUFDTCxlQUFPLENBQUMsS0FBTSxLQUFNLEdBQUksRUFBRSxRQUFRLENBQUMsS0FBSztBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUVBLFNBQUssbUJBQW1CLENBQUMsVUFBVTtBQUNqQyxVQUFHLEtBQUssa0JBQWlCO0FBQ3ZCLGVBQU8sS0FBSyxpQkFBaUIsS0FBSztBQUFBLE1BQ3BDLE9BQU87QUFDTCxlQUFPLENBQUMsSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFNLEdBQUksRUFBRSxRQUFRLENBQUMsS0FBSztBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUVBLFNBQUssU0FBUyxLQUFLLFVBQVU7QUFDN0IsUUFBRyxDQUFDLEtBQUssVUFBVSxLQUFLLE9BQU07QUFDNUIsV0FBSyxTQUFTLENBQUMsTUFBTSxLQUFLLFNBQVM7QUFBRSxnQkFBUSxJQUFJLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJO0FBQUEsTUFBRTtBQUFBLElBQzVFO0FBRUEsU0FBSyxvQkFBb0IsS0FBSyxxQkFBcUI7QUFFbkQsU0FBSyxTQUFTLFFBQVEsS0FBSyxVQUFVLENBQUMsQ0FBQztBQUV2QyxTQUFLLFdBQVcsR0FBRyxRQUFRLElBQUksV0FBVyxTQUFTO0FBRW5ELFNBQUssTUFBTSxLQUFLLE9BQU87QUFFdkIsU0FBSyx3QkFBd0I7QUFFN0IsU0FBSyxpQkFBaUI7QUFFdEIsU0FBSyxrQkFBa0I7QUFFdkIsU0FBSyxzQkFBc0I7QUFFM0IsU0FBSyxpQkFBaUIsSUFBSSxNQUFPLE1BQU07QUFDckMsVUFBRyxLQUFLLFlBQVc7QUFDakIsYUFBSyxJQUFJLHFDQUFxQztBQUM5QyxhQUFLLFNBQVM7QUFDZDtBQUFBLE1BQ0Y7QUFFQSxXQUFLLFNBQVMsWUFBWTtBQUN4QixZQUFHLEtBQUssZ0JBQWlCLE9BQU0sS0FBSyxnQkFBZ0I7QUFDcEQsYUFBSyxRQUFRO0FBQUEsTUFDZixDQUFDO0FBQUEsSUFDSCxHQUFHLEtBQUssZ0JBQWdCO0FBRXhCLFNBQUssWUFBWSxLQUFLO0FBQUEsRUFDeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLHVCQUFzQjtBQUFFLFdBQU87QUFBQSxFQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFReEMsaUJBQWlCLGNBQWE7QUFDNUIsU0FBSztBQUNMLFNBQUssZ0JBQWdCO0FBQ3JCLGlCQUFhLEtBQUssYUFBYTtBQUMvQixTQUFLLGVBQWUsTUFBTTtBQUMxQixRQUFHLEtBQUssTUFBSztBQUNYLFdBQUssS0FBSyxNQUFNO0FBQ2hCLFdBQUssT0FBTztBQUFBLElBQ2Q7QUFDQSxTQUFLLFlBQVk7QUFBQSxFQUNuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLFdBQVU7QUFBRSxXQUFPLFNBQVMsU0FBUyxNQUFNLFFBQVEsSUFBSSxRQUFRO0FBQUEsRUFBSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9wRSxjQUFhO0FBQ1gsUUFBSSxNQUFNLEtBQUs7QUFBQSxNQUNiLEtBQUssYUFBYSxLQUFLLFVBQVUsS0FBSyxPQUFPLENBQUM7QUFBQSxNQUFHLEVBQUMsS0FBSyxLQUFLLElBQUc7QUFBQSxJQUFDO0FBQ2xFLFFBQUcsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFJO0FBQUUsYUFBTztBQUFBLElBQUk7QUFDdEMsUUFBRyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUk7QUFBRSxhQUFPLEdBQUcsS0FBSyxTQUFTLENBQUMsSUFBSSxHQUFHO0FBQUEsSUFBRztBQUU5RCxXQUFPLEdBQUcsS0FBSyxTQUFTLENBQUMsTUFBTSxTQUFTLElBQUksR0FBRyxHQUFHO0FBQUEsRUFDcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBLFdBQVcsVUFBVSxNQUFNLFFBQU87QUFDaEMsU0FBSztBQUNMLFNBQUssZ0JBQWdCO0FBQ3JCLFNBQUssZ0JBQWdCO0FBQ3JCLGlCQUFhLEtBQUssYUFBYTtBQUMvQixTQUFLLGVBQWUsTUFBTTtBQUMxQixTQUFLLFNBQVMsTUFBTTtBQUNsQixXQUFLLGdCQUFnQjtBQUNyQixrQkFBWSxTQUFTO0FBQUEsSUFDdkIsR0FBRyxNQUFNLE1BQU07QUFBQSxFQUNqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsUUFBUSxRQUFPO0FBQ2IsUUFBRyxRQUFPO0FBQ1IsaUJBQVcsUUFBUSxJQUFJLHlGQUF5RjtBQUNoSCxXQUFLLFNBQVMsUUFBUSxNQUFNO0FBQUEsSUFDOUI7QUFDQSxRQUFHLEtBQUssUUFBUSxDQUFDLEtBQUssZUFBYztBQUFFO0FBQUEsSUFBTztBQUM3QyxRQUFHLEtBQUssc0JBQXNCLEtBQUssY0FBYyxVQUFTO0FBQ3hELFdBQUssb0JBQW9CLFVBQVUsS0FBSyxrQkFBa0I7QUFBQSxJQUM1RCxPQUFPO0FBQ0wsV0FBSyxpQkFBaUI7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBLElBQUksTUFBTSxLQUFLLE1BQUs7QUFBRSxTQUFLLFVBQVUsS0FBSyxPQUFPLE1BQU0sS0FBSyxJQUFJO0FBQUEsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS2xFLFlBQVc7QUFBRSxXQUFPLEtBQUssV0FBVztBQUFBLEVBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU3pDLE9BQU8sVUFBUztBQUNkLFFBQUksTUFBTSxLQUFLLFFBQVE7QUFDdkIsU0FBSyxxQkFBcUIsS0FBSyxLQUFLLENBQUMsS0FBSyxRQUFRLENBQUM7QUFDbkQsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxRQUFRLFVBQVM7QUFDZixRQUFJLE1BQU0sS0FBSyxRQUFRO0FBQ3ZCLFNBQUsscUJBQXFCLE1BQU0sS0FBSyxDQUFDLEtBQUssUUFBUSxDQUFDO0FBQ3BELFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVUEsUUFBUSxVQUFTO0FBQ2YsUUFBSSxNQUFNLEtBQUssUUFBUTtBQUN2QixTQUFLLHFCQUFxQixNQUFNLEtBQUssQ0FBQyxLQUFLLFFBQVEsQ0FBQztBQUNwRCxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLFVBQVUsVUFBUztBQUNqQixRQUFJLE1BQU0sS0FBSyxRQUFRO0FBQ3ZCLFNBQUsscUJBQXFCLFFBQVEsS0FBSyxDQUFDLEtBQUssUUFBUSxDQUFDO0FBQ3RELFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsWUFBWSxVQUFTO0FBQ25CLFNBQUssb0JBQW9CO0FBQUEsRUFDM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBLEtBQUssVUFBUztBQUNaLFFBQUcsQ0FBQyxLQUFLLFlBQVksR0FBRTtBQUFFLGFBQU87QUFBQSxJQUFNO0FBQ3RDLFFBQUksTUFBTSxLQUFLLFFBQVE7QUFDdkIsUUFBSSxZQUFZLEtBQUssSUFBSTtBQUN6QixTQUFLLEtBQUssRUFBQyxPQUFPLFdBQVcsT0FBTyxhQUFhLFNBQVMsQ0FBQyxHQUFHLElBQVEsQ0FBQztBQUN2RSxRQUFJLFdBQVcsS0FBSyxVQUFVLFNBQU87QUFDbkMsVUFBRyxJQUFJLFFBQVEsS0FBSTtBQUNqQixhQUFLLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDbkIsaUJBQVMsS0FBSyxJQUFJLElBQUksU0FBUztBQUFBLE1BQ2pDO0FBQUEsSUFDRixDQUFDO0FBQ0QsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxjQUFjLFdBQVU7QUFPdEIsWUFBTyxXQUFVO0FBQUEsTUFDZixLQUFLO0FBQVUsZUFBTztBQUFBLE1BQ3RCO0FBQVMsZUFBTyxVQUFVO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxtQkFBa0I7QUFDaEIsU0FBSztBQUNMLFNBQUssZ0JBQWdCO0FBQ3JCLFFBQUksWUFBWTtBQUdoQixRQUFHLEtBQUssV0FBVTtBQUNoQixrQkFBWSxDQUFDLFdBQVcsR0FBRyxpQkFBaUIsR0FBRyxLQUFLLEtBQUssU0FBUyxFQUFFLFFBQVEsTUFBTSxFQUFFLENBQUMsRUFBRTtBQUFBLElBQ3pGO0FBQ0EsU0FBSyxPQUFPLElBQUksS0FBSyxVQUFVLEtBQUssWUFBWSxHQUFHLFNBQVM7QUFDNUQsU0FBSyxLQUFLLGFBQWEsS0FBSztBQUM1QixTQUFLLEtBQUssVUFBVSxLQUFLO0FBQ3pCLFNBQUssS0FBSyxTQUFTLE1BQU0sS0FBSyxXQUFXO0FBQ3pDLFNBQUssS0FBSyxVQUFVLFdBQVMsS0FBSyxZQUFZLEtBQUs7QUFDbkQsU0FBSyxLQUFLLFlBQVksV0FBUyxLQUFLLGNBQWMsS0FBSztBQUN2RCxTQUFLLEtBQUssVUFBVSxXQUFTLEtBQUssWUFBWSxLQUFLO0FBQUEsRUFDckQ7QUFBQSxFQUVBLFdBQVcsS0FBSTtBQUFFLFdBQU8sS0FBSyxnQkFBZ0IsS0FBSyxhQUFhLFFBQVEsR0FBRztBQUFBLEVBQUU7QUFBQSxFQUU1RSxhQUFhLEtBQUssS0FBSTtBQUFFLFNBQUssZ0JBQWdCLEtBQUssYUFBYSxRQUFRLEtBQUssR0FBRztBQUFBLEVBQUU7QUFBQSxFQUVqRixvQkFBb0IsbUJBQW1CLG9CQUFvQixNQUFLO0FBQzlELGlCQUFhLEtBQUssYUFBYTtBQUMvQixRQUFJLGNBQWM7QUFDbEIsUUFBSSxtQkFBbUI7QUFDdkIsUUFBSSxTQUFTO0FBQ2IsUUFBSSx3QkFBd0IsS0FBSyxjQUFjLGlCQUFpQjtBQUNoRSxRQUFJLFdBQVcsQ0FBQyxXQUFXO0FBQ3pCLFdBQUssSUFBSSxhQUFhLG1CQUFtQixxQkFBcUIsT0FBTyxNQUFNO0FBQzNFLFdBQUssSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO0FBQzVCLHlCQUFtQjtBQUNuQixXQUFLLGlCQUFpQixpQkFBaUI7QUFDdkMsV0FBSyxpQkFBaUI7QUFBQSxJQUN4QjtBQUNBLFFBQUcsS0FBSyxXQUFXLGdCQUFnQixxQkFBcUIsRUFBRSxHQUFFO0FBQUUsYUFBTyxTQUFTLFdBQVc7QUFBQSxJQUFFO0FBRTNGLFNBQUssZ0JBQWdCLFdBQVcsVUFBVSxpQkFBaUI7QUFFM0QsZUFBVyxLQUFLLFFBQVEsWUFBVTtBQUNoQyxXQUFLLElBQUksYUFBYSxTQUFTLE1BQU07QUFDckMsVUFBRyxvQkFBb0IsQ0FBQyxhQUFZO0FBQ2xDLHFCQUFhLEtBQUssYUFBYTtBQUMvQixpQkFBUyxNQUFNO0FBQUEsTUFDakI7QUFBQSxJQUNGLENBQUM7QUFDRCxRQUFHLEtBQUssYUFBWTtBQUNsQixXQUFLLElBQUksQ0FBQyxLQUFLLFdBQVcsQ0FBQztBQUFBLElBQzdCO0FBQ0EsU0FBSyxjQUFjLEtBQUssT0FBTyxNQUFNO0FBQ25DLG9CQUFjO0FBQ2QsVUFBRyxDQUFDLGtCQUFpQjtBQUNuQixZQUFJQyx5QkFBd0IsS0FBSyxjQUFjLGlCQUFpQjtBQUVoRSxZQUFHLENBQUMsS0FBSywwQkFBeUI7QUFBRSxlQUFLLGFBQWEsZ0JBQWdCQSxzQkFBcUIsSUFBSSxNQUFNO0FBQUEsUUFBRTtBQUN2RyxlQUFPLEtBQUssSUFBSSxhQUFhLGVBQWVBLHNCQUFxQixXQUFXO0FBQUEsTUFDOUU7QUFFQSxtQkFBYSxLQUFLLGFBQWE7QUFDL0IsV0FBSyxnQkFBZ0IsV0FBVyxVQUFVLGlCQUFpQjtBQUMzRCxXQUFLLEtBQUssU0FBTztBQUNmLGFBQUssSUFBSSxhQUFhLDhCQUE4QixHQUFHO0FBQ3ZELGFBQUssMkJBQTJCO0FBQ2hDLHFCQUFhLEtBQUssYUFBYTtBQUFBLE1BQ2pDLENBQUM7QUFBQSxJQUNILENBQUM7QUFDRCxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCO0FBQUEsRUFFQSxrQkFBaUI7QUFDZixpQkFBYSxLQUFLLGNBQWM7QUFDaEMsaUJBQWEsS0FBSyxxQkFBcUI7QUFBQSxFQUN6QztBQUFBLEVBRUEsYUFBWTtBQUNWLFFBQUcsS0FBSyxVQUFVLEVBQUcsTUFBSyxJQUFJLGFBQWEsZ0JBQWdCLEtBQUssWUFBWSxDQUFDLEVBQUU7QUFDL0UsU0FBSyxnQkFBZ0I7QUFDckIsU0FBSyxnQkFBZ0I7QUFDckIsU0FBSztBQUNMLFNBQUssZ0JBQWdCO0FBQ3JCLFNBQUssZUFBZSxNQUFNO0FBQzFCLFFBQUcsS0FBSyxtQkFBa0I7QUFDeEIsV0FBSyxlQUFlO0FBQUEsSUFDdEI7QUFDQSxTQUFLLHNCQUFzQixNQUFNO0FBQUEsRUFDbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLG1CQUFrQjtBQUNoQixRQUFHLEtBQUsscUJBQW9CO0FBQzFCLFdBQUssc0JBQXNCO0FBQzNCLFdBQUssa0JBQWtCO0FBQ3ZCLFVBQUcsS0FBSyxVQUFVLEdBQUU7QUFBRSxhQUFLLElBQUksYUFBYSwwREFBMEQ7QUFBQSxNQUFFO0FBQ3hHLFVBQUk7QUFDRixhQUFLLGtCQUFrQixTQUFTO0FBQUEsTUFDbEMsU0FBUyxHQUFFO0FBQ1QsYUFBSyxJQUFJLFNBQVMsK0JBQStCLENBQUM7QUFBQSxNQUNwRDtBQUNBLFdBQUssaUJBQWlCLElBQUksTUFBTSxtQkFBbUIsQ0FBQztBQUNwRCxXQUFLLGdCQUFnQjtBQUNyQixXQUFLLFNBQVMsTUFBTSxLQUFLLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLG1CQUFtQjtBQUFBLElBQ2pHO0FBQUEsRUFDRjtBQUFBLEVBRUEsaUJBQWdCO0FBQ2QsUUFBRyxLQUFLLFFBQVEsS0FBSyxLQUFLLGVBQWM7QUFBRTtBQUFBLElBQU87QUFDakQsU0FBSyxzQkFBc0I7QUFDM0IsU0FBSyxnQkFBZ0I7QUFDckIsU0FBSyxpQkFBaUIsV0FBVyxNQUFNLEtBQUssY0FBYyxHQUFHLEtBQUssbUJBQW1CO0FBQUEsRUFDdkY7QUFBQSxFQUVBLFNBQVMsVUFBVSxNQUFNLFFBQU87QUFDOUIsUUFBRyxDQUFDLEtBQUssTUFBSztBQUNaLGFBQU8sWUFBWSxTQUFTO0FBQUEsSUFDOUI7QUFJQSxVQUFNLGNBQWMsS0FBSztBQUV6QixTQUFLLGtCQUFrQixhQUFhLE1BQU07QUFDeEMsVUFBRyxNQUFLO0FBQUUsb0JBQVksTUFBTSxNQUFNLFVBQVUsRUFBRTtBQUFBLE1BQUUsT0FBTztBQUFFLG9CQUFZLE1BQU07QUFBQSxNQUFFO0FBRTdFLFdBQUssb0JBQW9CLGFBQWEsTUFBTTtBQUMxQyxZQUFHLEtBQUssU0FBUyxhQUFZO0FBQzNCLGVBQUssS0FBSyxTQUFTLFdBQVc7QUFBQSxVQUFFO0FBQ2hDLGVBQUssS0FBSyxVQUFVLFdBQVc7QUFBQSxVQUFFO0FBQ2pDLGVBQUssS0FBSyxZQUFZLFdBQVc7QUFBQSxVQUFFO0FBQ25DLGVBQUssS0FBSyxVQUFVLFdBQVc7QUFBQSxVQUFFO0FBQ2pDLGVBQUssT0FBTztBQUFBLFFBQ2Q7QUFFQSxvQkFBWSxTQUFTO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLGtCQUFrQixNQUFNLFVBQVUsUUFBUSxHQUFFO0FBQzFDLFFBQUcsVUFBVSxLQUFLLENBQUMsS0FBSyxnQkFBZTtBQUNyQyxlQUFTO0FBQ1Q7QUFBQSxJQUNGO0FBRUEsZUFBVyxNQUFNO0FBQ2YsV0FBSyxrQkFBa0IsTUFBTSxVQUFVLFFBQVEsQ0FBQztBQUFBLElBQ2xELEdBQUcsTUFBTSxLQUFLO0FBQUEsRUFDaEI7QUFBQSxFQUVBLG9CQUFvQixNQUFNLFVBQVUsUUFBUSxHQUFFO0FBQzVDLFFBQUcsVUFBVSxLQUFLLEtBQUssZUFBZSxjQUFjLFFBQU87QUFDekQsZUFBUztBQUNUO0FBQUEsSUFDRjtBQUVBLGVBQVcsTUFBTTtBQUNmLFdBQUssb0JBQW9CLE1BQU0sVUFBVSxRQUFRLENBQUM7QUFBQSxJQUNwRCxHQUFHLE1BQU0sS0FBSztBQUFBLEVBQ2hCO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxZQUFZLE9BQU07QUFDaEIsUUFBRyxLQUFLLEtBQU0sTUFBSyxLQUFLLFVBQVUsTUFBTTtBQUFBLElBQUM7QUFDekMsUUFBRyxLQUFLLFVBQVUsRUFBRyxNQUFLLElBQUksYUFBYSxTQUFTLEtBQUs7QUFDekQsU0FBSyxpQkFBaUIsS0FBSztBQUMzQixTQUFLLGdCQUFnQjtBQUNyQixRQUFHLENBQUMsS0FBSyxlQUFjO0FBQ3JCLFdBQUssZUFBZSxnQkFBZ0I7QUFBQSxJQUN0QztBQUNBLFNBQUssc0JBQXNCLFNBQVMsS0FBSztBQUFBLEVBQzNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLFlBQVksT0FBTTtBQUNoQixRQUFHLEtBQUssVUFBVSxFQUFHLE1BQUssSUFBSSxhQUFhLFNBQVMsS0FBSztBQUN6RCxRQUFJLGtCQUFrQixLQUFLO0FBQzNCLFFBQUksb0JBQW9CLEtBQUs7QUFDN0IsU0FBSyxzQkFBc0IsU0FBUyxPQUFPLGlCQUFpQixpQkFBaUI7QUFDN0UsUUFBRyxvQkFBb0IsS0FBSyxhQUFhLG9CQUFvQixHQUFFO0FBQzdELFdBQUssaUJBQWlCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsaUJBQWlCLFFBQU87QUFDdEIsU0FBSyxTQUFTLFFBQVEsYUFBVztBQUMvQixVQUFHLEVBQUUsUUFBUSxVQUFVLEtBQUssUUFBUSxVQUFVLEtBQUssUUFBUSxTQUFTLElBQUc7QUFDckUsZ0JBQVEsUUFBUSxlQUFlLE9BQU8sTUFBTTtBQUFBLE1BQzlDO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0Esa0JBQWlCO0FBQ2YsWUFBTyxLQUFLLFFBQVEsS0FBSyxLQUFLLFlBQVc7QUFBQSxNQUN2QyxLQUFLLGNBQWM7QUFBWSxlQUFPO0FBQUEsTUFDdEMsS0FBSyxjQUFjO0FBQU0sZUFBTztBQUFBLE1BQ2hDLEtBQUssY0FBYztBQUFTLGVBQU87QUFBQSxNQUNuQztBQUFTLGVBQU87QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLGNBQWE7QUFBRSxXQUFPLEtBQUssZ0JBQWdCLE1BQU07QUFBQSxFQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU14RCxPQUFPLFNBQVE7QUFDYixTQUFLLElBQUksUUFBUSxlQUFlO0FBQ2hDLFNBQUssV0FBVyxLQUFLLFNBQVMsT0FBTyxPQUFLLE1BQU0sT0FBTztBQUFBLEVBQ3pEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxJQUFJLE1BQUs7QUFDUCxhQUFRLE9BQU8sS0FBSyxzQkFBcUI7QUFDdkMsV0FBSyxxQkFBcUIsR0FBRyxJQUFJLEtBQUsscUJBQXFCLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLE1BQU07QUFDaEYsZUFBTyxLQUFLLFFBQVEsR0FBRyxNQUFNO0FBQUEsTUFDL0IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLFFBQVEsT0FBTyxhQUFhLENBQUMsR0FBRTtBQUM3QixRQUFJLE9BQU8sSUFBSSxRQUFRLE9BQU8sWUFBWSxJQUFJO0FBQzlDLFNBQUssU0FBUyxLQUFLLElBQUk7QUFDdkIsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLEtBQUssTUFBSztBQUNSLFFBQUcsS0FBSyxVQUFVLEdBQUU7QUFDbEIsVUFBSSxFQUFDLE9BQU8sT0FBTyxTQUFTLEtBQUssU0FBUSxJQUFJO0FBQzdDLFdBQUssSUFBSSxRQUFRLEdBQUcsS0FBSyxJQUFJLEtBQUssS0FBSyxRQUFRLEtBQUssR0FBRyxLQUFLLE9BQU87QUFBQSxJQUNyRTtBQUVBLFFBQUcsS0FBSyxZQUFZLEdBQUU7QUFDcEIsV0FBSyxPQUFPLE1BQU0sWUFBVSxLQUFLLEtBQUssS0FBSyxNQUFNLENBQUM7QUFBQSxJQUNwRCxPQUFPO0FBQ0wsV0FBSyxXQUFXLEtBQUssTUFBTSxLQUFLLE9BQU8sTUFBTSxZQUFVLEtBQUssS0FBSyxLQUFLLE1BQU0sQ0FBQyxDQUFDO0FBQUEsSUFDaEY7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLFVBQVM7QUFDUCxRQUFJLFNBQVMsS0FBSyxNQUFNO0FBQ3hCLFFBQUcsV0FBVyxLQUFLLEtBQUk7QUFBRSxXQUFLLE1BQU07QUFBQSxJQUFFLE9BQU87QUFBRSxXQUFLLE1BQU07QUFBQSxJQUFPO0FBRWpFLFdBQU8sS0FBSyxJQUFJLFNBQVM7QUFBQSxFQUMzQjtBQUFBLEVBRUEsZ0JBQWU7QUFDYixRQUFHLENBQUMsS0FBSyxZQUFZLEdBQUU7QUFDckIsVUFBSTtBQUNGLGFBQUssa0JBQWtCLGNBQWM7QUFBQSxNQUN2QyxTQUFTLEdBQUU7QUFDVCxhQUFLLElBQUksU0FBUywrQkFBK0IsQ0FBQztBQUFBLE1BQ3BEO0FBQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBRyxLQUFLLHFCQUFvQjtBQUMxQixXQUFLLGlCQUFpQjtBQUN0QjtBQUFBLElBQ0Y7QUFDQSxTQUFLLHNCQUFzQixLQUFLLFFBQVE7QUFDeEMsU0FBSyxrQkFBa0IsS0FBSyxJQUFJO0FBQ2hDLFNBQUssS0FBSyxFQUFDLE9BQU8sV0FBVyxPQUFPLGFBQWEsU0FBUyxDQUFDLEdBQUcsS0FBSyxLQUFLLG9CQUFtQixDQUFDO0FBQzVGLFFBQUk7QUFDRixXQUFLLGtCQUFrQixNQUFNO0FBQUEsSUFDL0IsU0FBUyxHQUFFO0FBQ1QsV0FBSyxJQUFJLFNBQVMsK0JBQStCLENBQUM7QUFBQSxJQUNwRDtBQUNBLFNBQUssd0JBQXdCLFdBQVcsTUFBTSxLQUFLLGlCQUFpQixHQUFHLEtBQUssbUJBQW1CO0FBQUEsRUFDakc7QUFBQSxFQUVBLGtCQUFpQjtBQUNmLFFBQUcsS0FBSyxZQUFZLEtBQUssS0FBSyxXQUFXLFNBQVMsR0FBRTtBQUNsRCxXQUFLLFdBQVcsUUFBUSxjQUFZLFNBQVMsQ0FBQztBQUM5QyxXQUFLLGFBQWEsQ0FBQztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsY0FBYyxZQUFXO0FBQ3ZCLFNBQUssT0FBTyxXQUFXLE1BQU0sU0FBTztBQUNsQyxVQUFJLEVBQUMsT0FBTyxPQUFPLFNBQVMsS0FBSyxTQUFRLElBQUk7QUFDN0MsVUFBRyxPQUFPLFFBQVEsS0FBSyxxQkFBb0I7QUFDekMsY0FBTSxVQUFVLEtBQUssa0JBQWtCLEtBQUssSUFBSSxJQUFJLEtBQUssa0JBQWtCO0FBQzNFLGFBQUssZ0JBQWdCO0FBQ3JCLFlBQUk7QUFDRixlQUFLLGtCQUFrQixRQUFRLFdBQVcsT0FBTyxPQUFPLFNBQVMsT0FBTztBQUFBLFFBQzFFLFNBQVMsR0FBRTtBQUNULGVBQUssSUFBSSxTQUFTLCtCQUErQixDQUFDO0FBQUEsUUFDcEQ7QUFDQSxhQUFLLHNCQUFzQjtBQUMzQixhQUFLLGtCQUFrQjtBQUN2QixZQUFHLEtBQUssbUJBQWtCO0FBQ3hCLGVBQUssaUJBQWlCLFdBQVcsTUFBTSxLQUFLLGNBQWMsR0FBRyxLQUFLLG1CQUFtQjtBQUFBLFFBQ3ZGO0FBQUEsTUFDRjtBQUVBLFVBQUcsS0FBSyxVQUFVLEVBQUcsTUFBSyxJQUFJLFdBQVcsR0FBRyxRQUFRLFVBQVUsRUFBRSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxNQUFNLE1BQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE9BQU87QUFFcEksZUFBUSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsUUFBUSxLQUFJO0FBQzNDLGNBQU0sVUFBVSxLQUFLLFNBQVMsQ0FBQztBQUMvQixZQUFHLENBQUMsUUFBUSxTQUFTLE9BQU8sT0FBTyxTQUFTLFFBQVEsR0FBRTtBQUFFO0FBQUEsUUFBUztBQUNqRSxnQkFBUSxRQUFRLE9BQU8sU0FBUyxLQUFLLFFBQVE7QUFBQSxNQUMvQztBQUVBLFdBQUssc0JBQXNCLFdBQVcsR0FBRztBQUFBLElBQzNDLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLHNCQUFzQixVQUFVLE1BQUs7QUFDbkMsUUFBSTtBQUNGLFdBQUsscUJBQXFCLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQyxHQUFHLFFBQVEsTUFBTTtBQUMxRCxZQUFJO0FBQ0YsbUJBQVMsR0FBRyxJQUFJO0FBQUEsUUFDbEIsU0FBUyxHQUFFO0FBQ1QsZUFBSyxJQUFJLFNBQVMsWUFBWSxLQUFLLGFBQWEsQ0FBQztBQUFBLFFBQ25EO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxTQUFTLEdBQUU7QUFDVCxXQUFLLElBQUksU0FBUyxvQkFBb0IsS0FBSyxjQUFjLENBQUM7QUFBQSxJQUM1RDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLGVBQWUsT0FBTTtBQUNuQixRQUFJLGFBQWEsS0FBSyxTQUFTLEtBQUssT0FBSyxFQUFFLFVBQVUsVUFBVSxFQUFFLFNBQVMsS0FBSyxFQUFFLFVBQVUsRUFBRTtBQUM3RixRQUFHLFlBQVc7QUFDWixVQUFHLEtBQUssVUFBVSxFQUFHLE1BQUssSUFBSSxhQUFhLDRCQUE0QixLQUFLLEdBQUc7QUFDL0UsaUJBQVcsTUFBTTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbImNsb3N1cmUiLCJmYWxsYmFja1RyYW5zcG9ydE5hbWUiXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDldfQ==