import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/app.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/pages/runtime/page.js?v=583078ff";
import { default as __nuxt_component_1 } from "/_nuxt/ui/Toast.vue";
import { default as __nuxt_component_2 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/components/nuxt-layout.js?v=583078ff";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"
import { useToast } from "/_nuxt/utils/toast.js"


const _sfc_main = {
  __name: 'app',
  setup(__props, { expose: __expose }) {
  __expose();

const { toasts, removeToast } = useToast()

const __returned__ = { toasts, removeToast, get useToast() { return useToast } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { resolveComponent as _resolveComponent, createVNode as _createVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, createBlock as _createBlock, createElementVNode as _createElementVNode, withCtx as _withCtx } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

const _hoisted_1 = { class: "toast-stack" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_NuxtPage = __nuxt_component_0
  const _component_Toast = __nuxt_component_1
  const _component_NuxtLayout = __nuxt_component_2

  return (_openBlock(), _tracer(8,1,_createBlock(_component_NuxtLayout, null, {
    default: _withCtx(() => [
      _tracer(9,2,_createVNode(_component_NuxtPage)),
      _tracer(11,2,_createElementVNode("div", _hoisted_1, [
        (_openBlock(true), _tracer(12,3,_createElementBlock(_Fragment, null, _renderList($setup.toasts, (t) => {
          return (_openBlock(), _tracer(12,3,_createBlock(_component_Toast, {
            key: t.id,
            message: t.message,
            theme: t.theme,
            onClose: $event => ($setup.removeToast(t.id))
          }, null, 8 /* PROPS */, ["message", "theme", "onClose"])))
        }), 128 /* KEYED_FRAGMENT */)))
      ]))
    ]),
    _: 1 /* STABLE */
  })))
}


import "/_nuxt/app.vue?vue&type=style&index=0&scoped=938b83b0&lang.css"

_sfc_main.__hmrId = "938b83b0"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-938b83b0"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/app.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/app.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7OztBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7OztBQUV2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7cUJBT2xDLEtBQUssRUFBQyxhQUFhOzs7Ozs7O29DQUh6QixhQU9hO3NCQU5aLENBQVk7a0JBQVosYUFBWTttQkFFWixvQkFHTSxPQUhOLFVBR007d0NBRkwsb0JBQzhCLDZCQURYLGFBQU0sR0FBWCxDQUFDOzZDQUFmLGFBQzhCO1lBREYsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFO1lBQUcsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPO1lBQUcsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLO1lBQ3pFLE9BQUssYUFBRSxrQkFBVyxDQUFDLENBQUMsQ0FBQyxFQUFFIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJhcHAudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCJ+L3V0aWxzL3RvYXN0XCJcblxuY29uc3QgeyB0b2FzdHMsIHJlbW92ZVRvYXN0IH0gPSB1c2VUb2FzdCgpXG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuXHQ8TnV4dExheW91dD5cblx0XHQ8TnV4dFBhZ2UgLz5cblxuXHRcdDxkaXYgY2xhc3M9XCJ0b2FzdC1zdGFja1wiPlxuXHRcdFx0PFRvYXN0IHYtZm9yPVwidCBpbiB0b2FzdHNcIiA6a2V5PVwidC5pZFwiIDptZXNzYWdlPVwidC5tZXNzYWdlXCIgOnRoZW1lPVwidC50aGVtZVwiXG5cdFx0XHRcdEBjbG9zZT1cInJlbW92ZVRvYXN0KHQuaWQpXCIgLz5cblx0XHQ8L2Rpdj5cblx0PC9OdXh0TGF5b3V0PlxuPC90ZW1wbGF0ZT5cblxuPHN0eWxlIHNjb3BlZD5cbi50b2FzdC1zdGFjayB7XG5cdHBvc2l0aW9uOiBmaXhlZDtcblx0Ym90dG9tOiA3MHB4O1xuXHRyaWdodDogMi41cmVtO1xuXHRkaXNwbGF5OiBmbGV4O1xuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uLXJldmVyc2U7XG5cdGdhcDogMC41cmVtO1xuXHR6LWluZGV4OiA5OTk7XG59XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvbW50L2tpcmUvUGVyc29uYWwvUHJvZ3JhbW1pbmcvUHJvamVjdHMvTUVJQy93ZWIvYXBwL2FwcC52dWUifQ==