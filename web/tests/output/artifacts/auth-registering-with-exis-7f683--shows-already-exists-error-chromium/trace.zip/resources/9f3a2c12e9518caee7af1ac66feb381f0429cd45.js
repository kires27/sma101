import WebSocketFactory from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/websocket-factory.js?v=583078ff";
import { CHANNEL_EVENTS, CONNECTION_STATE, DEFAULT_VERSION, DEFAULT_TIMEOUT, DEFAULT_VSN, VSN_1_0_0, VSN_2_0_0, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/constants.js?v=583078ff";
import Serializer from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/serializer.js?v=583078ff";
import { httpEndpointURL } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/lib/transformers.js?v=583078ff";
import RealtimeChannel from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/RealtimeChannel.js?v=583078ff";
import SocketAdapter from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/phoenix/socketAdapter.js?v=583078ff";
// Connection-related constants
const CONNECTION_TIMEOUTS = {
    HEARTBEAT_INTERVAL: 25000,
    RECONNECT_DELAY: 10,
    HEARTBEAT_TIMEOUT_FALLBACK: 100,
};
const RECONNECT_INTERVALS = [1000, 2000, 5000, 10000];
const DEFAULT_RECONNECT_FALLBACK = 10000;
function createMemorySessionStorage() {
    const store = new Map();
    return {
        get length() {
            return store.size;
        },
        clear() {
            store.clear();
        },
        getItem(key) {
            return store.has(key) ? store.get(key) : null;
        },
        key(index) {
            var _a;
            return (_a = Array.from(store.keys())[index]) !== null && _a !== void 0 ? _a : null;
        },
        removeItem(key) {
            store.delete(key);
        },
        setItem(key, value) {
            store.set(key, String(value));
        },
    };
}
function resolveSessionStorage() {
    try {
        if (typeof globalThis !== 'undefined' && globalThis.sessionStorage) {
            return globalThis.sessionStorage;
        }
    }
    catch (_a) {
        // Property access on `sessionStorage` itself throws in restricted-storage browsers.
    }
    return createMemorySessionStorage();
}
const WORKER_SCRIPT = `
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`;
export default class RealtimeClient {
    get endPoint() {
        return this.socketAdapter.endPoint;
    }
    get timeout() {
        return this.socketAdapter.timeout;
    }
    get transport() {
        return this.socketAdapter.transport;
    }
    get heartbeatCallback() {
        return this.socketAdapter.heartbeatCallback;
    }
    get heartbeatIntervalMs() {
        return this.socketAdapter.heartbeatIntervalMs;
    }
    get heartbeatTimer() {
        if (this.worker) {
            return this._workerHeartbeatTimer;
        }
        return this.socketAdapter.heartbeatTimer;
    }
    get pendingHeartbeatRef() {
        if (this.worker) {
            return this._pendingWorkerHeartbeatRef;
        }
        return this.socketAdapter.pendingHeartbeatRef;
    }
    get reconnectTimer() {
        return this.socketAdapter.reconnectTimer;
    }
    get vsn() {
        return this.socketAdapter.vsn;
    }
    get encode() {
        return this.socketAdapter.encode;
    }
    get decode() {
        return this.socketAdapter.decode;
    }
    get reconnectAfterMs() {
        return this.socketAdapter.reconnectAfterMs;
    }
    get sendBuffer() {
        return this.socketAdapter.sendBuffer;
    }
    get stateChangeCallbacks() {
        return this.socketAdapter.stateChangeCallbacks;
    }
    /**
     * Initializes the Socket.
     *
     * @param endPoint The string WebSocket endpoint, ie, "ws://example.com/socket", "wss://example.com", "/socket" (inherited host & protocol)
     * @param httpEndpoint The string HTTP endpoint, ie, "https://example.com", "/" (inherited host & protocol)
     * @param options.transport The Websocket Transport, for example WebSocket. This can be a custom implementation
     * @param options.timeout The default timeout in milliseconds to trigger push timeouts.
     * @param options.params The optional params to pass when connecting.
     * @param options.headers Deprecated: headers cannot be set on websocket connections and this option will be removed in the future.
     * @param options.heartbeatIntervalMs The millisec interval to send a heartbeat message.
     * @param options.heartbeatCallback The optional function to handle heartbeat status and latency.
     * @param options.logger The optional function for specialized logging, ie: logger: (kind, msg, data) => { console.log(`${kind}: ${msg}`, data) }
     * @param options.logLevel Sets the log level for Realtime
     * @param options.encode The function to encode outgoing messages. Defaults to JSON: (payload, callback) => callback(JSON.stringify(payload))
     * @param options.decode The function to decode incoming messages. Defaults to Serializer's decode.
     * @param options.reconnectAfterMs he optional function that returns the millsec reconnect interval. Defaults to stepped backoff off.
     * @param options.worker Use Web Worker to set a side flow. Defaults to false.
     * @param options.workerUrl The URL of the worker script. Defaults to https://realtime.supabase.com/worker.js that includes a heartbeat event call to keep the connection alive.
     * @param options.vsn The protocol version to use when connecting. Supported versions are "1.0.0" and "2.0.0". Defaults to "2.0.0".
     *
     * @category Realtime
     *
     * @example Using supabase-js (recommended)
     * ```ts
     * import { createClient } from '@supabase/supabase-js'
     *
     * const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
     * const channel = supabase.channel('room1')
     * channel
     *   .on('broadcast', { event: 'cursor-pos' }, (payload) => console.log(payload))
     *   .subscribe()
     * ```
     *
     * @example Standalone import for bundle-sensitive environments
     * ```ts
     * import RealtimeClient from '@supabase/realtime-js'
     *
     * const client = new RealtimeClient('https://xyzcompany.supabase.co/realtime/v1', {
     *   params: { apikey: 'your-publishable-key' },
     * })
     * client.connect()
     * ```
     */
    constructor(endPoint, options) {
        var _a;
        this.channels = new Array();
        this.accessTokenValue = null;
        this.accessToken = null;
        this.apiKey = null;
        this.httpEndpoint = '';
        /** @deprecated headers cannot be set on websocket connections */
        this.headers = {};
        this.params = {};
        this.ref = 0;
        this.serializer = new Serializer();
        this._manuallySetToken = false;
        this._authPromise = null;
        this._workerHeartbeatTimer = undefined;
        this._pendingWorkerHeartbeatRef = null;
        this._pendingDisconnectTimer = null;
        this._disconnectOnEmptyChannelsAfterMs = 0;
        /**
         * Use either custom fetch, if provided, or default fetch to make HTTP requests
         *
         * @internal
         */
        this._resolveFetch = (customFetch) => {
            if (customFetch) {
                return (...args) => customFetch(...args);
            }
            return (...args) => fetch(...args);
        };
        // Validate required parameters
        if (!((_a = options === null || options === void 0 ? void 0 : options.params) === null || _a === void 0 ? void 0 : _a.apikey)) {
            throw new Error('API key is required to connect to Realtime');
        }
        this.apiKey = options.params.apikey;
        const socketAdapterOptions = this._initializeOptions(options);
        this.socketAdapter = new SocketAdapter(endPoint, socketAdapterOptions);
        this.httpEndpoint = httpEndpointURL(endPoint);
        this.fetch = this._resolveFetch(options === null || options === void 0 ? void 0 : options.fetch);
    }
    /**
     * Connects the socket, unless already connected.
     *
     * @category Realtime
     */
    connect() {
        // Skip if already connecting, disconnecting, or connected
        if (this.isConnecting() || this.isDisconnecting() || this.isConnected()) {
            return;
        }
        // Trigger auth if needed and not already in progress
        // This ensures auth is called for standalone RealtimeClient usage
        // while avoiding race conditions with SupabaseClient's immediate setAuth call
        if (this.accessToken && !this._authPromise) {
            this._setAuthSafely('connect');
        }
        this._setupConnectionHandlers();
        try {
            this.socketAdapter.connect();
        }
        catch (error) {
            const errorMessage = error.message;
            // Provide helpful error message based on environment
            if (errorMessage.includes('Node.js')) {
                throw new Error(`${errorMessage}\n\n` +
                    'To use Realtime in Node.js, you need to provide a WebSocket implementation:\n\n' +
                    'Option 1: Use Node.js 22+ which has native WebSocket support\n' +
                    'Option 2: Install and provide the "ws" package:\n\n' +
                    '  npm install ws\n\n' +
                    '  import ws from "ws"\n' +
                    '  const client = new RealtimeClient(url, {\n' +
                    '    ...options,\n' +
                    '    transport: ws\n' +
                    '  })');
            }
            throw new Error(`WebSocket not available: ${errorMessage}`);
        }
        this._handleNodeJsRaceCondition();
    }
    /**
     * Returns the URL of the websocket.
     * @returns string The URL of the websocket.
     *
     * @category Realtime
     */
    endpointURL() {
        return this.socketAdapter.endPointURL();
    }
    /**
     * Disconnects the socket.
     *
     * @param code A numeric status code to send on disconnect.
     * @param reason A custom reason for the disconnect.
     *
     * @category Realtime
     */
    async disconnect(code, reason) {
        this._cancelPendingDisconnect();
        if (this.isDisconnecting()) {
            return 'ok';
        }
        return await this.socketAdapter.disconnect(() => {
            clearInterval(this._workerHeartbeatTimer);
            this._terminateWorker();
        }, code, reason);
    }
    /**
     * Returns all created channels
     *
     * @category Realtime
     */
    getChannels() {
        return this.channels;
    }
    /**
     * Unsubscribes, removes and tears down a single channel
     * @param channel A RealtimeChannel instance
     *
     * @category Realtime
     */
    async removeChannel(channel) {
        const status = await channel.unsubscribe();
        if (status === 'ok') {
            channel.teardown();
        }
        return status;
    }
    /**
     * Unsubscribes, removes and tears down all channels
     *
     * @category Realtime
     */
    async removeAllChannels() {
        const promises = this.channels.map(async (channel) => {
            const result = await channel.unsubscribe();
            channel.teardown();
            return result;
        });
        const result = await Promise.all(promises);
        await this.disconnect();
        return result;
    }
    /**
     * Logs the message.
     *
     * For customized logging, `this.logger` can be overridden in Client constructor.
     *
     * @category Realtime
     */
    log(kind, msg, data) {
        this.socketAdapter.log(kind, msg, data);
    }
    /**
     * Returns the current state of the socket.
     *
     * @category Realtime
     */
    connectionState() {
        return this.socketAdapter.connectionState() || CONNECTION_STATE.closed;
    }
    /**
     * Returns `true` is the connection is open.
     *
     * @category Realtime
     */
    isConnected() {
        return this.socketAdapter.isConnected();
    }
    /**
     * Returns `true` if the connection is currently connecting.
     *
     * @category Realtime
     */
    isConnecting() {
        return this.socketAdapter.isConnecting();
    }
    /**
     * Returns `true` if the connection is currently disconnecting.
     *
     * @category Realtime
     */
    isDisconnecting() {
        return this.socketAdapter.isDisconnecting();
    }
    /**
     * Creates (or reuses) a {@link RealtimeChannel} for the provided topic.
     *
     * Topics are automatically prefixed with `realtime:` to match the Realtime service.
     * If a channel with the same topic already exists it will be returned instead of creating
     * a duplicate connection.
     *
     * @category Realtime
     */
    channel(topic, params = { config: {} }) {
        const realtimeTopic = `realtime:${topic}`;
        const exists = this.getChannels().find((c) => c.topic === realtimeTopic);
        if (!exists) {
            const chan = new RealtimeChannel(`realtime:${topic}`, params, this);
            this._cancelPendingDisconnect();
            this.channels.push(chan);
            return chan;
        }
        else {
            return exists;
        }
    }
    /**
     * Push out a message if the socket is connected.
     *
     * If the socket is not connected, the message gets enqueued within a local buffer, and sent out when a connection is next established.
     *
     * @category Realtime
     */
    push(data) {
        this.socketAdapter.push(data);
    }
    /**
     * Sets the JWT access token used for channel subscription authorization and Realtime RLS.
     *
     * If param is null it will use the `accessToken` callback function or the token set on the client.
     *
     * On callback used, it will set the value of the token internal to the client.
     *
     * When a token is explicitly provided, it will be preserved across channel operations
     * (including removeChannel and resubscribe). The `accessToken` callback will not be
     * invoked until `setAuth()` is called without arguments.
     *
     * @param token A JWT string to override the token set on the client.
     *
     * @example Setting the authorization header
     * // Use a manual token (preserved across resubscribes, ignores accessToken callback)
     * client.realtime.setAuth('my-custom-jwt')
     *
     * // Switch back to using the accessToken callback
     * client.realtime.setAuth()
     *
     * @category Realtime
     */
    async setAuth(token = null) {
        this._authPromise = this._performAuth(token);
        try {
            await this._authPromise;
        }
        finally {
            this._authPromise = null;
        }
    }
    /**
     * Returns true if the current access token was explicitly set via setAuth(token),
     * false if it was obtained via the accessToken callback.
     * @internal
     */
    _isManualToken() {
        return this._manuallySetToken;
    }
    /**
     * Sends a heartbeat message if the socket is connected.
     *
     * @category Realtime
     */
    async sendHeartbeat() {
        this.socketAdapter.sendHeartbeat();
    }
    /**
     * Sets a callback that receives lifecycle events for internal heartbeat messages.
     * Useful for instrumenting connection health (e.g. sent/ok/timeout/disconnected).
     *
     * @category Realtime
     */
    onHeartbeat(callback) {
        this.socketAdapter.heartbeatCallback = this._wrapHeartbeatCallback(callback);
    }
    /**
     * Return the next message ref, accounting for overflows
     *
     * @internal
     */
    _makeRef() {
        return this.socketAdapter.makeRef();
    }
    /**
     * Removes a channel from RealtimeClient
     *
     * @param channel An open subscription.
     *
     * @internal
     */
    _remove(channel) {
        this.channels = this.channels.filter((c) => c.topic !== channel.topic);
        if (this.channels.length === 0) {
            this.log('transport', 'no channels remaining, scheduling disconnect');
            this._schedulePendingDisconnect();
        }
    }
    /** @internal */
    _schedulePendingDisconnect() {
        this._cancelPendingDisconnect();
        if (this._disconnectOnEmptyChannelsAfterMs === 0) {
            this.log('transport', 'disconnecting immediately - no channels');
            this.disconnect();
            return;
        }
        this._pendingDisconnectTimer = setTimeout(() => {
            this._pendingDisconnectTimer = null;
            if (this.channels.length === 0) {
                this.log('transport', 'deferred disconnect fired - no channels, disconnecting');
                this.disconnect();
            }
        }, this._disconnectOnEmptyChannelsAfterMs);
        this.log('transport', `deferred disconnect scheduled in ${this._disconnectOnEmptyChannelsAfterMs}ms`);
    }
    /** @internal */
    _cancelPendingDisconnect() {
        if (this._pendingDisconnectTimer !== null) {
            this.log('transport', 'pending disconnect cancelled - channel activity detected');
            clearTimeout(this._pendingDisconnectTimer);
            this._pendingDisconnectTimer = null;
        }
    }
    /**
     * Perform the actual auth operation
     * @internal
     */
    async _performAuth(token = null) {
        let tokenToSend;
        let isManualToken = false;
        if (token) {
            tokenToSend = token;
            // Track if this is a manually-provided token
            isManualToken = true;
        }
        else if (this.accessToken) {
            // Call the accessToken callback to get fresh token
            try {
                tokenToSend = await this.accessToken();
            }
            catch (e) {
                this.log('error', 'Error fetching access token from callback', e);
                // Fall back to cached value if callback fails
                tokenToSend = this.accessTokenValue;
            }
        }
        else {
            tokenToSend = this.accessTokenValue;
        }
        // Track whether this token was manually set or fetched via callback
        if (isManualToken) {
            this._manuallySetToken = true;
        }
        else if (this.accessToken) {
            // If we used the callback, clear the manual flag
            this._manuallySetToken = false;
        }
        if (this.accessTokenValue != tokenToSend) {
            this.accessTokenValue = tokenToSend;
            this.channels.forEach((channel) => {
                const payload = {
                    access_token: tokenToSend,
                    version: DEFAULT_VERSION,
                };
                tokenToSend && channel.updateJoinPayload(payload);
                if (channel.joinedOnce && channel.channelAdapter.isJoined()) {
                    channel.channelAdapter.push(CHANNEL_EVENTS.access_token, {
                        access_token: tokenToSend,
                    });
                }
            });
        }
    }
    /**
     * Wait for any in-flight auth operations to complete
     * @internal
     */
    async _waitForAuthIfNeeded() {
        if (this._authPromise) {
            await this._authPromise;
        }
    }
    /**
     * Safely call setAuth with standardized error handling
     * @internal
     */
    _setAuthSafely(context = 'general') {
        // Only refresh auth if using callback-based tokens
        if (!this._isManualToken()) {
            this.setAuth().catch((e) => {
                this.log('error', `Error setting auth in ${context}`, e);
            });
        }
    }
    /** @internal */
    _setupConnectionHandlers() {
        this.socketAdapter.onOpen(() => {
            const authPromise = this._authPromise ||
                (this.accessToken && !this.accessTokenValue ? this.setAuth() : Promise.resolve());
            authPromise.catch((e) => {
                this.log('error', 'error waiting for auth on connect', e);
            });
            if (this.worker && !this.workerRef) {
                this._startWorkerHeartbeat();
            }
        });
        this.socketAdapter.onClose(() => {
            if (this.worker && this.workerRef) {
                this._terminateWorker();
            }
        });
        this.socketAdapter.onMessage((message) => {
            if (message.ref && message.ref === this._pendingWorkerHeartbeatRef) {
                this._pendingWorkerHeartbeatRef = null;
            }
        });
    }
    /** @internal */
    _handleNodeJsRaceCondition() {
        if (this.socketAdapter.isConnected()) {
            // hack: ensure onConnOpen is called
            this.socketAdapter.getSocket().onConnOpen();
        }
    }
    /** @internal */
    _wrapHeartbeatCallback(heartbeatCallback) {
        return (status, latency) => {
            if (status == 'sent')
                this._setAuthSafely();
            if (heartbeatCallback)
                heartbeatCallback(status, latency);
        };
    }
    /** @internal */
    _startWorkerHeartbeat() {
        if (this.workerUrl) {
            this.log('worker', `starting worker for from ${this.workerUrl}`);
        }
        else {
            this.log('worker', `starting default worker`);
        }
        const objectUrl = this._workerObjectUrl(this.workerUrl);
        this.workerRef = new Worker(objectUrl);
        this.workerRef.onerror = (error) => {
            this.log('worker', 'worker error', error.message);
            this._terminateWorker();
            this.disconnect();
        };
        this.workerRef.onmessage = (event) => {
            if (event.data.event === 'keepAlive') {
                this.sendHeartbeat();
            }
        };
        this.workerRef.postMessage({
            event: 'start',
            interval: this.heartbeatIntervalMs,
        });
    }
    /**
     * Terminate the Web Worker and clear the reference
     * @internal
     */
    _terminateWorker() {
        if (this.workerRef) {
            this.log('worker', 'terminating worker');
            this.workerRef.terminate();
            this.workerRef = undefined;
        }
    }
    /** @internal */
    _workerObjectUrl(url) {
        let result_url;
        if (url) {
            result_url = url;
        }
        else {
            const blob = new Blob([WORKER_SCRIPT], { type: 'application/javascript' });
            result_url = URL.createObjectURL(blob);
        }
        return result_url;
    }
    /**
     * Initialize socket options with defaults
     * @internal
     */
    _initializeOptions(options) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        this.worker = (_a = options === null || options === void 0 ? void 0 : options.worker) !== null && _a !== void 0 ? _a : false;
        this.accessToken = (_b = options === null || options === void 0 ? void 0 : options.accessToken) !== null && _b !== void 0 ? _b : null;
        const result = {};
        result.timeout = (_c = options === null || options === void 0 ? void 0 : options.timeout) !== null && _c !== void 0 ? _c : DEFAULT_TIMEOUT;
        result.heartbeatIntervalMs =
            (_d = options === null || options === void 0 ? void 0 : options.heartbeatIntervalMs) !== null && _d !== void 0 ? _d : CONNECTION_TIMEOUTS.HEARTBEAT_INTERVAL;
        this._disconnectOnEmptyChannelsAfterMs =
            (_e = options === null || options === void 0 ? void 0 : options.disconnectOnEmptyChannelsAfterMs) !== null && _e !== void 0 ? _e : 2 * ((_f = options === null || options === void 0 ? void 0 : options.heartbeatIntervalMs) !== null && _f !== void 0 ? _f : CONNECTION_TIMEOUTS.HEARTBEAT_INTERVAL);
        // @ts-ignore - mismatch between phoenix and supabase
        result.transport = (_g = options === null || options === void 0 ? void 0 : options.transport) !== null && _g !== void 0 ? _g : WebSocketFactory.getWebSocketConstructor();
        result.params = options === null || options === void 0 ? void 0 : options.params;
        result.logger = options === null || options === void 0 ? void 0 : options.logger;
        result.heartbeatCallback = this._wrapHeartbeatCallback(options === null || options === void 0 ? void 0 : options.heartbeatCallback);
        result.sessionStorage = (_h = options === null || options === void 0 ? void 0 : options.sessionStorage) !== null && _h !== void 0 ? _h : resolveSessionStorage();
        result.reconnectAfterMs =
            (_j = options === null || options === void 0 ? void 0 : options.reconnectAfterMs) !== null && _j !== void 0 ? _j : ((tries) => {
                return RECONNECT_INTERVALS[tries - 1] || DEFAULT_RECONNECT_FALLBACK;
            });
        let defaultEncode;
        let defaultDecode;
        const vsn = (_k = options === null || options === void 0 ? void 0 : options.vsn) !== null && _k !== void 0 ? _k : DEFAULT_VSN;
        switch (vsn) {
            case VSN_1_0_0:
                defaultEncode = (payload, callback) => {
                    return callback(JSON.stringify(payload));
                };
                defaultDecode = (payload, callback) => {
                    return callback(JSON.parse(payload));
                };
                break;
            case VSN_2_0_0:
                defaultEncode = this.serializer.encode.bind(this.serializer);
                defaultDecode = this.serializer.decode.bind(this.serializer);
                break;
            default:
                throw new Error(`Unsupported serializer version: ${result.vsn}`);
        }
        result.vsn = vsn;
        result.encode = (_l = options === null || options === void 0 ? void 0 : options.encode) !== null && _l !== void 0 ? _l : defaultEncode;
        result.decode = (_m = options === null || options === void 0 ? void 0 : options.decode) !== null && _m !== void 0 ? _m : defaultDecode;
        result.beforeReconnect = this._reconnectAuth.bind(this);
        if ((options === null || options === void 0 ? void 0 : options.logLevel) || (options === null || options === void 0 ? void 0 : options.log_level)) {
            this.logLevel = options.logLevel || options.log_level;
            result.params = Object.assign(Object.assign({}, result.params), { log_level: this.logLevel });
        }
        // Handle worker setup
        if (this.worker) {
            if (typeof window !== 'undefined' && !window.Worker) {
                throw new Error('Web Worker is not supported');
            }
            this.workerUrl = options === null || options === void 0 ? void 0 : options.workerUrl;
            result.autoSendHeartbeat = !this.worker;
        }
        return result;
    }
    /** @internal */
    async _reconnectAuth() {
        await this._waitForAuthIfNeeded();
        if (!this.isConnected()) {
            this.connect();
        }
    }
}
                                          
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVhbHRpbWVDbGllbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvUmVhbHRpbWVDbGllbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxnQkFBbUMsTUFBTSx5QkFBeUIsQ0FBQTtBQUV6RSxPQUFPLEVBQ0wsY0FBYyxFQUNkLGdCQUFnQixFQUNoQixlQUFlLEVBQ2YsZUFBZSxFQUNmLFdBQVcsRUFDWCxTQUFTLEVBQ1QsU0FBUyxHQUNWLE1BQU0saUJBQWlCLENBQUE7QUFFeEIsT0FBTyxVQUFVLE1BQU0sa0JBQWtCLENBQUE7QUFDekMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLG9CQUFvQixDQUFBO0FBQ3BELE9BQU8sZUFBZSxNQUFNLG1CQUFtQixDQUFBO0FBRS9DLE9BQU8sYUFBYSxNQUFNLHlCQUF5QixDQUFBO0FBMkJuRCwrQkFBK0I7QUFDL0IsTUFBTSxtQkFBbUIsR0FBRztJQUMxQixrQkFBa0IsRUFBRSxLQUFLO0lBQ3pCLGVBQWUsRUFBRSxFQUFFO0lBQ25CLDBCQUEwQixFQUFFLEdBQUc7Q0FDdkIsQ0FBQTtBQUVWLE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLENBQVUsQ0FBQTtBQUM5RCxNQUFNLDBCQUEwQixHQUFHLEtBQUssQ0FBQTtBQXlDeEMsU0FBUywwQkFBMEI7SUFDakMsTUFBTSxLQUFLLEdBQUcsSUFBSSxHQUFHLEVBQWtCLENBQUE7SUFDdkMsT0FBTztRQUNMLElBQUksTUFBTTtZQUNSLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQTtRQUNuQixDQUFDO1FBQ0QsS0FBSztZQUNILEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQTtRQUNmLENBQUM7UUFDRCxPQUFPLENBQUMsR0FBVztZQUNqQixPQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQTtRQUMzRCxDQUFDO1FBQ0QsR0FBRyxDQUFDLEtBQWE7O1lBQ2YsT0FBTyxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLG1DQUFJLElBQUksQ0FBQTtRQUNoRCxDQUFDO1FBQ0QsVUFBVSxDQUFDLEdBQVc7WUFDcEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUNuQixDQUFDO1FBQ0QsT0FBTyxDQUFDLEdBQVcsRUFBRSxLQUFhO1lBQ2hDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFBO1FBQy9CLENBQUM7S0FDRixDQUFBO0FBQ0gsQ0FBQztBQUVELFNBQVMscUJBQXFCO0lBQzVCLElBQUksQ0FBQztRQUNILElBQUksT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNuRSxPQUFPLFVBQVUsQ0FBQyxjQUFjLENBQUE7UUFDbEMsQ0FBQztJQUNILENBQUM7SUFBQyxXQUFNLENBQUM7UUFDUCxvRkFBb0Y7SUFDdEYsQ0FBQztJQUNELE9BQU8sMEJBQTBCLEVBQUUsQ0FBQTtBQUNyQyxDQUFDO0FBRUQsTUFBTSxhQUFhLEdBQUc7Ozs7O01BS2hCLENBQUE7QUFFTixNQUFNLENBQUMsT0FBTyxPQUFPLGNBQWM7SUF5QmpDLElBQUksUUFBUTtRQUNWLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUE7SUFDcEMsQ0FBQztJQUVELElBQUksT0FBTztRQUNULE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUE7SUFDbkMsQ0FBQztJQUVELElBQUksU0FBUztRQUNYLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUE7SUFDckMsQ0FBQztJQUVELElBQUksaUJBQWlCO1FBQ25CLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQTtJQUM3QyxDQUFDO0lBRUQsSUFBSSxtQkFBbUI7UUFDckIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFBO0lBQy9DLENBQUM7SUFFRCxJQUFJLGNBQWM7UUFDaEIsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDaEIsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUE7UUFDbkMsQ0FBQztRQUNELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUE7SUFDMUMsQ0FBQztJQUVELElBQUksbUJBQW1CO1FBQ3JCLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2hCLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFBO1FBQ3hDLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUE7SUFDL0MsQ0FBQztJQUVELElBQUksY0FBYztRQUNoQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFBO0lBQzFDLENBQUM7SUFFRCxJQUFJLEdBQUc7UUFDTCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFBO0lBQy9CLENBQUM7SUFFRCxJQUFJLE1BQU07UUFDUixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFBO0lBQ2xDLENBQUM7SUFFRCxJQUFJLE1BQU07UUFDUixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFBO0lBQ2xDLENBQUM7SUFFRCxJQUFJLGdCQUFnQjtRQUNsQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUE7SUFDNUMsQ0FBQztJQUVELElBQUksVUFBVTtRQUNaLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUE7SUFDdEMsQ0FBQztJQUVELElBQUksb0JBQW9CO1FBTXRCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQTtJQUNoRCxDQUFDO0lBU0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTBDRztJQUNILFlBQVksUUFBZ0IsRUFBRSxPQUErQjs7UUEzSTdELGFBQVEsR0FBc0IsSUFBSSxLQUFLLEVBQUUsQ0FBQTtRQUV6QyxxQkFBZ0IsR0FBa0IsSUFBSSxDQUFBO1FBQ3RDLGdCQUFXLEdBQTBDLElBQUksQ0FBQTtRQUN6RCxXQUFNLEdBQWtCLElBQUksQ0FBQTtRQUU1QixpQkFBWSxHQUFXLEVBQUUsQ0FBQTtRQUN6QixpRUFBaUU7UUFDakUsWUFBTyxHQUErQixFQUFFLENBQUE7UUFDeEMsV0FBTSxHQUErQixFQUFFLENBQUE7UUFFdkMsUUFBRyxHQUFXLENBQUMsQ0FBQTtRQVNmLGVBQVUsR0FBZSxJQUFJLFVBQVUsRUFBRSxDQUFBO1FBcUVqQyxzQkFBaUIsR0FBWSxLQUFLLENBQUE7UUFDbEMsaUJBQVksR0FBeUIsSUFBSSxDQUFBO1FBQ3pDLDBCQUFxQixHQUFtQixTQUFTLENBQUE7UUFDakQsK0JBQTBCLEdBQWtCLElBQUksQ0FBQTtRQUNoRCw0QkFBdUIsR0FBeUMsSUFBSSxDQUFBO1FBQ3BFLHNDQUFpQyxHQUFXLENBQUMsQ0FBQTtRQWtVckQ7Ozs7V0FJRztRQUNILGtCQUFhLEdBQUcsQ0FBQyxXQUFtQixFQUFTLEVBQUU7WUFDN0MsSUFBSSxXQUFXLEVBQUUsQ0FBQztnQkFDaEIsT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQTtZQUMxQyxDQUFDO1lBQ0QsT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQTtRQUNwQyxDQUFDLENBQUE7UUE5UkMsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxDQUFBLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLE1BQU0sMENBQUUsTUFBTSxDQUFBLEVBQUUsQ0FBQztZQUM3QixNQUFNLElBQUksS0FBSyxDQUFDLDRDQUE0QyxDQUFDLENBQUE7UUFDL0QsQ0FBQztRQUNELElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUE7UUFFbkMsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUE7UUFFN0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLGFBQWEsQ0FBQyxRQUFRLEVBQUUsb0JBQW9CLENBQUMsQ0FBQTtRQUN0RSxJQUFJLENBQUMsWUFBWSxHQUFHLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUU3QyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLEtBQUssQ0FBQyxDQUFBO0lBQ2pELENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsT0FBTztRQUNMLDBEQUEwRDtRQUMxRCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUM7WUFDeEUsT0FBTTtRQUNSLENBQUM7UUFFRCxxREFBcUQ7UUFDckQsa0VBQWtFO1FBQ2xFLDhFQUE4RTtRQUM5RSxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDM0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtRQUNoQyxDQUFDO1FBRUQsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUE7UUFFL0IsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsQ0FBQTtRQUM5QixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE1BQU0sWUFBWSxHQUFJLEtBQWUsQ0FBQyxPQUFPLENBQUE7WUFFN0MscURBQXFEO1lBQ3JELElBQUksWUFBWSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO2dCQUNyQyxNQUFNLElBQUksS0FBSyxDQUNiLEdBQUcsWUFBWSxNQUFNO29CQUNuQixpRkFBaUY7b0JBQ2pGLGdFQUFnRTtvQkFDaEUscURBQXFEO29CQUNyRCxzQkFBc0I7b0JBQ3RCLHlCQUF5QjtvQkFDekIsOENBQThDO29CQUM5QyxtQkFBbUI7b0JBQ25CLHFCQUFxQjtvQkFDckIsTUFBTSxDQUNULENBQUE7WUFDSCxDQUFDO1lBQ0QsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsWUFBWSxFQUFFLENBQUMsQ0FBQTtRQUM3RCxDQUFDO1FBRUQsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUE7SUFDbkMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVztRQUNULE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtJQUN6QyxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBYSxFQUFFLE1BQWU7UUFDN0MsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUE7UUFDL0IsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQUUsQ0FBQztZQUMzQixPQUFPLElBQUksQ0FBQTtRQUNiLENBQUM7UUFDRCxPQUFPLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQ3hDLEdBQUcsRUFBRTtZQUNILGFBQWEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQTtZQUN6QyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQTtRQUN6QixDQUFDLEVBQ0QsSUFBSSxFQUNKLE1BQU0sQ0FDUCxDQUFBO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxXQUFXO1FBQ1QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFBO0lBQ3RCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBd0I7UUFDMUMsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUE7UUFFMUMsSUFBSSxNQUFNLEtBQUssSUFBSSxFQUFFLENBQUM7WUFDcEIsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFBO1FBQ3BCLENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQTtJQUNmLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsS0FBSyxDQUFDLGlCQUFpQjtRQUNyQixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDbkQsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUE7WUFDMUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFBO1lBQ2xCLE9BQU8sTUFBTSxDQUFBO1FBQ2YsQ0FBQyxDQUFDLENBQUE7UUFFRixNQUFNLE1BQU0sR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDMUMsTUFBTSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUE7UUFDdkIsT0FBTyxNQUFNLENBQUE7SUFDZixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsR0FBRyxDQUFDLElBQVksRUFBRSxHQUFXLEVBQUUsSUFBVTtRQUN2QyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFBO0lBQ3pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxNQUFNLENBQUE7SUFDeEUsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxXQUFXO1FBQ1QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFBO0lBQ3pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsWUFBWTtRQUNWLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQTtJQUMxQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGVBQWU7UUFDYixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLENBQUE7SUFDN0MsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsT0FBTyxDQUFDLEtBQWEsRUFBRSxTQUFpQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUU7UUFDcEUsTUFBTSxhQUFhLEdBQUcsWUFBWSxLQUFLLEVBQUUsQ0FBQTtRQUN6QyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBa0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxhQUFhLENBQUMsQ0FBQTtRQUV6RixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDWixNQUFNLElBQUksR0FBRyxJQUFJLGVBQWUsQ0FBQyxZQUFZLEtBQUssRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQTtZQUNuRSxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQTtZQUMvQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtZQUV4QixPQUFPLElBQUksQ0FBQTtRQUNiLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxNQUFNLENBQUE7UUFDZixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILElBQUksQ0FBQyxJQUFxQjtRQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUMvQixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXFCRztJQUNILEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBdUIsSUFBSTtRQUN2QyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDNUMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFBO1FBQ3pCLENBQUM7Z0JBQVMsQ0FBQztZQUNULElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFBO1FBQzFCLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGNBQWM7UUFDWixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQTtJQUMvQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILEtBQUssQ0FBQyxhQUFhO1FBQ2pCLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLENBQUE7SUFDcEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLFFBQTJCO1FBQ3JDLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQzlFLENBQUM7SUFjRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsQ0FBQTtJQUNyQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsT0FBTyxDQUFDLE9BQXdCO1FBQzlCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQ3RFLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDL0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsOENBQThDLENBQUMsQ0FBQTtZQUNyRSxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQTtRQUNuQyxDQUFDO0lBQ0gsQ0FBQztJQUVELGdCQUFnQjtJQUNSLDBCQUEwQjtRQUNoQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQTtRQUMvQixJQUFJLElBQUksQ0FBQyxpQ0FBaUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNqRCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSx5Q0FBeUMsQ0FBQyxDQUFBO1lBQ2hFLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQTtZQUNqQixPQUFNO1FBQ1IsQ0FBQztRQUNELElBQUksQ0FBQyx1QkFBdUIsR0FBRyxVQUFVLENBQUMsR0FBRyxFQUFFO1lBQzdDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUE7WUFDbkMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDL0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsd0RBQXdELENBQUMsQ0FBQTtnQkFDL0UsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO1lBQ25CLENBQUM7UUFDSCxDQUFDLEVBQUUsSUFBSSxDQUFDLGlDQUFpQyxDQUFDLENBQUE7UUFDMUMsSUFBSSxDQUFDLEdBQUcsQ0FDTixXQUFXLEVBQ1gsb0NBQW9DLElBQUksQ0FBQyxpQ0FBaUMsSUFBSSxDQUMvRSxDQUFBO0lBQ0gsQ0FBQztJQUVELGdCQUFnQjtJQUNSLHdCQUF3QjtRQUM5QixJQUFJLElBQUksQ0FBQyx1QkFBdUIsS0FBSyxJQUFJLEVBQUUsQ0FBQztZQUMxQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSwwREFBMEQsQ0FBQyxDQUFBO1lBQ2pGLFlBQVksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtZQUMxQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFBO1FBQ3JDLENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssS0FBSyxDQUFDLFlBQVksQ0FBQyxRQUF1QixJQUFJO1FBQ3BELElBQUksV0FBMEIsQ0FBQTtRQUM5QixJQUFJLGFBQWEsR0FBRyxLQUFLLENBQUE7UUFFekIsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNWLFdBQVcsR0FBRyxLQUFLLENBQUE7WUFDbkIsNkNBQTZDO1lBQzdDLGFBQWEsR0FBRyxJQUFJLENBQUE7UUFDdEIsQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVCLG1EQUFtRDtZQUNuRCxJQUFJLENBQUM7Z0JBQ0gsV0FBVyxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFBO1lBQ3hDLENBQUM7WUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO2dCQUNYLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLDJDQUEyQyxFQUFFLENBQUMsQ0FBQyxDQUFBO2dCQUNqRSw4Q0FBOEM7Z0JBQzlDLFdBQVcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUE7WUFDckMsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sV0FBVyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQTtRQUNyQyxDQUFDO1FBRUQsb0VBQW9FO1FBQ3BFLElBQUksYUFBYSxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQTtRQUMvQixDQUFDO2FBQU0sSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDNUIsaURBQWlEO1lBQ2pELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUE7UUFDaEMsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxXQUFXLENBQUE7WUFDbkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtnQkFDaEMsTUFBTSxPQUFPLEdBQUc7b0JBQ2QsWUFBWSxFQUFFLFdBQVc7b0JBQ3pCLE9BQU8sRUFBRSxlQUFlO2lCQUN6QixDQUFBO2dCQUVELFdBQVcsSUFBSSxPQUFPLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUE7Z0JBRWpELElBQUksT0FBTyxDQUFDLFVBQVUsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7b0JBQzVELE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUU7d0JBQ3ZELFlBQVksRUFBRSxXQUFXO3FCQUMxQixDQUFDLENBQUE7Z0JBQ0osQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSyxLQUFLLENBQUMsb0JBQW9CO1FBQ2hDLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQTtRQUN6QixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNLLGNBQWMsQ0FBQyxPQUFPLEdBQUcsU0FBUztRQUN4QyxtREFBbUQ7UUFDbkQsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDO1lBQzNCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDekIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUseUJBQXlCLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFBO1lBQzFELENBQUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFRCxnQkFBZ0I7SUFDUix3QkFBd0I7UUFDOUIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO1lBQzdCLE1BQU0sV0FBVyxHQUNmLElBQUksQ0FBQyxZQUFZO2dCQUNqQixDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7WUFFbkYsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUN0QixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxtQ0FBbUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUMzRCxDQUFDLENBQUMsQ0FBQTtZQUVGLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUE7WUFDOUIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFBO1FBQ0YsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQzlCLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFBO1lBQ3pCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNGLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBcUIsRUFBRSxFQUFFO1lBQ3JELElBQUksT0FBTyxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUMsR0FBRyxLQUFLLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO2dCQUNuRSxJQUFJLENBQUMsMEJBQTBCLEdBQUcsSUFBSSxDQUFBO1lBQ3hDLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxnQkFBZ0I7SUFDUiwwQkFBMEI7UUFDaEMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUM7WUFDckMsb0NBQW9DO1lBQ3BDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLENBQUMsVUFBVSxFQUFFLENBQUE7UUFDN0MsQ0FBQztJQUNILENBQUM7SUFFRCxnQkFBZ0I7SUFDUixzQkFBc0IsQ0FBQyxpQkFBcUM7UUFDbEUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUN6QixJQUFJLE1BQU0sSUFBSSxNQUFNO2dCQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQTtZQUMzQyxJQUFJLGlCQUFpQjtnQkFBRSxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFDM0QsQ0FBQyxDQUFBO0lBQ0gsQ0FBQztJQUVELGdCQUFnQjtJQUNSLHFCQUFxQjtRQUMzQixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSw0QkFBNEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUE7UUFDbEUsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSx5QkFBeUIsQ0FBQyxDQUFBO1FBQy9DLENBQUM7UUFDRCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVUsQ0FBQyxDQUFBO1FBQ3hELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUE7UUFDdEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxjQUFjLEVBQUcsS0FBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUNqRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQTtZQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUE7UUFDbkIsQ0FBQyxDQUFBO1FBQ0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNuQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsRUFBRSxDQUFDO2dCQUNyQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUE7WUFDdEIsQ0FBQztRQUNILENBQUMsQ0FBQTtRQUNELElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDO1lBQ3pCLEtBQUssRUFBRSxPQUFPO1lBQ2QsUUFBUSxFQUFFLElBQUksQ0FBQyxtQkFBbUI7U0FDbkMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVEOzs7T0FHRztJQUNLLGdCQUFnQjtRQUN0QixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxvQkFBb0IsQ0FBQyxDQUFBO1lBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUE7WUFDMUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUE7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFRCxnQkFBZ0I7SUFDUixnQkFBZ0IsQ0FBQyxHQUF1QjtRQUM5QyxJQUFJLFVBQWtCLENBQUE7UUFDdEIsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNSLFVBQVUsR0FBRyxHQUFHLENBQUE7UUFDbEIsQ0FBQzthQUFNLENBQUM7WUFDTixNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLHdCQUF3QixFQUFFLENBQUMsQ0FBQTtZQUMxRSxVQUFVLEdBQUcsR0FBRyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUN4QyxDQUFDO1FBQ0QsT0FBTyxVQUFVLENBQUE7SUFDbkIsQ0FBQztJQUVEOzs7T0FHRztJQUNLLGtCQUFrQixDQUFDLE9BQStCOztRQUN4RCxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLE1BQU0sbUNBQUksS0FBSyxDQUFBO1FBQ3RDLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsV0FBVyxtQ0FBSSxJQUFJLENBQUE7UUFFL0MsTUFBTSxNQUFNLEdBQWtCLEVBQUUsQ0FBQTtRQUNoQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLE9BQU8sbUNBQUksZUFBZSxDQUFBO1FBQ3BELE1BQU0sQ0FBQyxtQkFBbUI7WUFDeEIsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsbUJBQW1CLG1DQUFJLG1CQUFtQixDQUFDLGtCQUFrQixDQUFBO1FBRXhFLElBQUksQ0FBQyxpQ0FBaUM7WUFDcEMsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsZ0NBQWdDLG1DQUN6QyxDQUFDLEdBQUcsQ0FBQyxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxtQkFBbUIsbUNBQUksbUJBQW1CLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtRQUU5RSxxREFBcUQ7UUFDckQsTUFBTSxDQUFDLFNBQVMsR0FBRyxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxTQUFTLG1DQUFJLGdCQUFnQixDQUFDLHVCQUF1QixFQUFFLENBQUE7UUFDbkYsTUFBTSxDQUFDLE1BQU0sR0FBRyxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsTUFBTSxDQUFBO1FBQy9CLE1BQU0sQ0FBQyxNQUFNLEdBQUcsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLE1BQU0sQ0FBQTtRQUMvQixNQUFNLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxpQkFBaUIsQ0FBQyxDQUFBO1FBQ2xGLE1BQU0sQ0FBQyxjQUFjLEdBQUcsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsY0FBYyxtQ0FBSSxxQkFBcUIsRUFBRSxDQUFBO1FBQzFFLE1BQU0sQ0FBQyxnQkFBZ0I7WUFDckIsTUFBQSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsZ0JBQWdCLG1DQUN6QixDQUFDLENBQUMsS0FBYSxFQUFFLEVBQUU7Z0JBQ2pCLE9BQU8sbUJBQW1CLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLDBCQUEwQixDQUFBO1lBQ3JFLENBQUMsQ0FBQyxDQUFBO1FBRUosSUFBSSxhQUEyQixDQUFBO1FBQy9CLElBQUksYUFBMkIsQ0FBQTtRQUUvQixNQUFNLEdBQUcsR0FBRyxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxHQUFHLG1DQUFJLFdBQVcsQ0FBQTtRQUV2QyxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBQ1osS0FBSyxTQUFTO2dCQUNaLGFBQWEsR0FBRyxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsRUFBRTtvQkFDcEMsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFBO2dCQUMxQyxDQUFDLENBQUE7Z0JBQ0QsYUFBYSxHQUFHLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO29CQUNwQyxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQWlCLENBQUMsQ0FBQyxDQUFBO2dCQUNoRCxDQUFDLENBQUE7Z0JBQ0QsTUFBSztZQUNQLEtBQUssU0FBUztnQkFDWixhQUFhLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtnQkFDNUQsYUFBYSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7Z0JBQzVELE1BQUs7WUFDUDtnQkFDRSxNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQTtRQUNwRSxDQUFDO1FBRUQsTUFBTSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUE7UUFDaEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxNQUFNLG1DQUFJLGFBQWEsQ0FBQTtRQUNoRCxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLE1BQU0sbUNBQUksYUFBYSxDQUFBO1FBRWhELE1BQU0sQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7UUFFdkQsSUFBSSxDQUFBLE9BQU8sYUFBUCxPQUFPLHVCQUFQLE9BQU8sQ0FBRSxRQUFRLE1BQUksT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFNBQVMsQ0FBQSxFQUFFLENBQUM7WUFDNUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsUUFBUSxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUE7WUFDckQsTUFBTSxDQUFDLE1BQU0sbUNBQVEsTUFBTSxDQUFDLE1BQU0sS0FBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQWtCLEdBQUUsQ0FBQTtRQUMxRSxDQUFDO1FBRUQsc0JBQXNCO1FBQ3RCLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2hCLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNwRCxNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUE7WUFDaEQsQ0FBQztZQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFNBQVMsQ0FBQTtZQUNuQyxNQUFNLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFBO1FBQ3pDLENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQTtJQUNmLENBQUM7SUFFRCxnQkFBZ0I7SUFDUixLQUFLLENBQUMsY0FBYztRQUMxQixNQUFNLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFBO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUE7UUFDaEIsQ0FBQztJQUNILENBQUM7Q0FDRiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBXZWJTb2NrZXRGYWN0b3J5LCB7IFdlYlNvY2tldExpa2UgfSBmcm9tICcuL2xpYi93ZWJzb2NrZXQtZmFjdG9yeSdcblxuaW1wb3J0IHtcbiAgQ0hBTk5FTF9FVkVOVFMsXG4gIENPTk5FQ1RJT05fU1RBVEUsXG4gIERFRkFVTFRfVkVSU0lPTixcbiAgREVGQVVMVF9USU1FT1VULFxuICBERUZBVUxUX1ZTTixcbiAgVlNOXzFfMF8wLFxuICBWU05fMl8wXzAsXG59IGZyb20gJy4vbGliL2NvbnN0YW50cydcblxuaW1wb3J0IFNlcmlhbGl6ZXIgZnJvbSAnLi9saWIvc2VyaWFsaXplcidcbmltcG9ydCB7IGh0dHBFbmRwb2ludFVSTCB9IGZyb20gJy4vbGliL3RyYW5zZm9ybWVycydcbmltcG9ydCBSZWFsdGltZUNoYW5uZWwgZnJvbSAnLi9SZWFsdGltZUNoYW5uZWwnXG5pbXBvcnQgdHlwZSB7IFJlYWx0aW1lQ2hhbm5lbE9wdGlvbnMgfSBmcm9tICcuL1JlYWx0aW1lQ2hhbm5lbCdcbmltcG9ydCBTb2NrZXRBZGFwdGVyIGZyb20gJy4vcGhvZW5peC9zb2NrZXRBZGFwdGVyJ1xuaW1wb3J0IHR5cGUge1xuICBNZXNzYWdlLFxuICBTb2NrZXRPcHRpb25zLFxuICBIZWFydGJlYXRDYWxsYmFjayxcbiAgRW5jb2RlLFxuICBEZWNvZGUsXG4gIFRpbWVyLFxuICBWc24sXG59IGZyb20gJy4vcGhvZW5peC90eXBlcydcblxudHlwZSBGZXRjaCA9IHR5cGVvZiBmZXRjaFxuXG5leHBvcnQgdHlwZSBMb2dMZXZlbCA9ICdpbmZvJyB8ICd3YXJuJyB8ICdlcnJvcicgfCAoc3RyaW5nICYge30pXG5cbmV4cG9ydCB0eXBlIFJlYWx0aW1lTWVzc2FnZSA9IHtcbiAgdG9waWM6IHN0cmluZ1xuICBldmVudDogc3RyaW5nXG4gIHBheWxvYWQ6IGFueVxuICByZWY6IHN0cmluZ1xuICBqb2luX3JlZj86IHN0cmluZ1xufVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZVJlbW92ZUNoYW5uZWxSZXNwb25zZSA9ICdvaycgfCAndGltZWQgb3V0JyB8ICdlcnJvcicgfCAoc3RyaW5nICYge30pXG5leHBvcnQgdHlwZSBIZWFydGJlYXRTdGF0dXMgPSAnc2VudCcgfCAnb2snIHwgJ2Vycm9yJyB8ICd0aW1lb3V0JyB8ICdkaXNjb25uZWN0ZWQnIHwgKHN0cmluZyAmIHt9KVxuZXhwb3J0IHR5cGUgSGVhcnRiZWF0VGltZXIgPSBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZFxuXG4vLyBDb25uZWN0aW9uLXJlbGF0ZWQgY29uc3RhbnRzXG5jb25zdCBDT05ORUNUSU9OX1RJTUVPVVRTID0ge1xuICBIRUFSVEJFQVRfSU5URVJWQUw6IDI1MDAwLFxuICBSRUNPTk5FQ1RfREVMQVk6IDEwLFxuICBIRUFSVEJFQVRfVElNRU9VVF9GQUxMQkFDSzogMTAwLFxufSBhcyBjb25zdFxuXG5jb25zdCBSRUNPTk5FQ1RfSU5URVJWQUxTID0gWzEwMDAsIDIwMDAsIDUwMDAsIDEwMDAwXSBhcyBjb25zdFxuY29uc3QgREVGQVVMVF9SRUNPTk5FQ1RfRkFMTEJBQ0sgPSAxMDAwMFxuXG4vKipcbiAqIE1pbmltYWwgV2ViU29ja2V0IGNvbnN0cnVjdG9yIGludGVyZmFjZSB0aGF0IFJlYWx0aW1lQ2xpZW50IGNhbiB3b3JrIHdpdGguXG4gKiBTdXBwbHkgYSBjb21wYXRpYmxlIGltcGxlbWVudGF0aW9uIChuYXRpdmUgV2ViU29ja2V0LCBgd3NgLCBldGMpIHdoZW4gcnVubmluZyBvdXRzaWRlIHRoZSBicm93c2VyLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFdlYlNvY2tldExpa2VDb25zdHJ1Y3RvciB7XG4gIG5ldyAoYWRkcmVzczogc3RyaW5nIHwgVVJMLCBzdWJwcm90b2NvbHM/OiBzdHJpbmcgfCBzdHJpbmdbXSB8IHVuZGVmaW5lZCk6IFdlYlNvY2tldExpa2VcbiAgLy8gQWxsb3cgYWRkaXRpb25hbCBwcm9wZXJ0aWVzIHRoYXQgbWF5IGV4aXN0IG9uIFdlYlNvY2tldCBjb25zdHJ1Y3RvcnNcbiAgW2tleTogc3RyaW5nXTogYW55XG59XG5cbmV4cG9ydCB0eXBlIFJlYWx0aW1lQ2xpZW50T3B0aW9ucyA9IHtcbiAgdHJhbnNwb3J0PzogV2ViU29ja2V0TGlrZUNvbnN0cnVjdG9yXG4gIHRpbWVvdXQ/OiBudW1iZXJcbiAgaGVhcnRiZWF0SW50ZXJ2YWxNcz86IG51bWJlclxuICBoZWFydGJlYXRDYWxsYmFjaz86IChzdGF0dXM6IEhlYXJ0YmVhdFN0YXR1cywgbGF0ZW5jeT86IG51bWJlcikgPT4gdm9pZFxuICB2c24/OiBzdHJpbmdcbiAgbG9nZ2VyPzogKGtpbmQ6IHN0cmluZywgbXNnOiBzdHJpbmcsIGRhdGE/OiBhbnkpID0+IHZvaWRcbiAgZW5jb2RlPzogRW5jb2RlPHZvaWQ+XG4gIGRlY29kZT86IERlY29kZTx2b2lkPlxuICByZWNvbm5lY3RBZnRlck1zPzogKHRyaWVzOiBudW1iZXIpID0+IG51bWJlclxuICBoZWFkZXJzPzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfVxuICBwYXJhbXM/OiB7IFtrZXk6IHN0cmluZ106IGFueSB9XG4gIC8vRGVwcmVjYXRlZDogVXNlIGl0IGluIGZhdm91ciBvZiBjb3JyZWN0IGNhc2luZyBgbG9nTGV2ZWxgXG4gIGxvZ19sZXZlbD86IExvZ0xldmVsXG4gIGxvZ0xldmVsPzogTG9nTGV2ZWxcbiAgZmV0Y2g/OiBGZXRjaFxuICB3b3JrZXI/OiBib29sZWFuXG4gIHdvcmtlclVybD86IHN0cmluZ1xuICBhY2Nlc3NUb2tlbj86ICgpID0+IFByb21pc2U8c3RyaW5nIHwgbnVsbD5cbiAgZGlzY29ubmVjdE9uRW1wdHlDaGFubmVsc0FmdGVyTXM/OiBudW1iZXJcbiAgLyoqXG4gICAqIFN0b3JhZ2UgY29tcGF0aWJsZSBvYmplY3QgdXNlZCBieSB0aGUgdW5kZXJseWluZyBzb2NrZXQgZm9yIGxvbmdwb2xsIGZhbGxiYWNrIGhpc3RvcnkuXG4gICAqIFByb3ZpZGUgYSBjdXN0b20gaW1wbGVtZW50YXRpb24gaW4gZW52aXJvbm1lbnRzIHdoZXJlIHJlYWRpbmcgYGdsb2JhbFRoaXMuc2Vzc2lvblN0b3JhZ2VgXG4gICAqIHRocm93cyAoc2FuZGJveGVkIGlmcmFtZXMsIGluLWFwcCB3ZWJ2aWV3cywgXCJibG9jayB0aGlyZC1wYXJ0eSBzdG9yYWdlXCIgcHJpdmFjeSBtb2RlcykuXG4gICAqIERlZmF1bHRzIHRvIGBnbG9iYWxUaGlzLnNlc3Npb25TdG9yYWdlYCB3aGVuIGFjY2Vzc2libGUsIG90aGVyd2lzZSBhbiBpbi1tZW1vcnkgc3RvcmUuXG4gICAqL1xuICBzZXNzaW9uU3RvcmFnZT86IFN0b3JhZ2Vcbn1cblxuZnVuY3Rpb24gY3JlYXRlTWVtb3J5U2Vzc2lvblN0b3JhZ2UoKTogU3RvcmFnZSB7XG4gIGNvbnN0IHN0b3JlID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKVxuICByZXR1cm4ge1xuICAgIGdldCBsZW5ndGgoKSB7XG4gICAgICByZXR1cm4gc3RvcmUuc2l6ZVxuICAgIH0sXG4gICAgY2xlYXIoKSB7XG4gICAgICBzdG9yZS5jbGVhcigpXG4gICAgfSxcbiAgICBnZXRJdGVtKGtleTogc3RyaW5nKSB7XG4gICAgICByZXR1cm4gc3RvcmUuaGFzKGtleSkgPyAoc3RvcmUuZ2V0KGtleSkgYXMgc3RyaW5nKSA6IG51bGxcbiAgICB9LFxuICAgIGtleShpbmRleDogbnVtYmVyKSB7XG4gICAgICByZXR1cm4gQXJyYXkuZnJvbShzdG9yZS5rZXlzKCkpW2luZGV4XSA/PyBudWxsXG4gICAgfSxcbiAgICByZW1vdmVJdGVtKGtleTogc3RyaW5nKSB7XG4gICAgICBzdG9yZS5kZWxldGUoa2V5KVxuICAgIH0sXG4gICAgc2V0SXRlbShrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZykge1xuICAgICAgc3RvcmUuc2V0KGtleSwgU3RyaW5nKHZhbHVlKSlcbiAgICB9LFxuICB9XG59XG5cbmZ1bmN0aW9uIHJlc29sdmVTZXNzaW9uU3RvcmFnZSgpOiBTdG9yYWdlIHtcbiAgdHJ5IHtcbiAgICBpZiAodHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnICYmIGdsb2JhbFRoaXMuc2Vzc2lvblN0b3JhZ2UpIHtcbiAgICAgIHJldHVybiBnbG9iYWxUaGlzLnNlc3Npb25TdG9yYWdlXG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvLyBQcm9wZXJ0eSBhY2Nlc3Mgb24gYHNlc3Npb25TdG9yYWdlYCBpdHNlbGYgdGhyb3dzIGluIHJlc3RyaWN0ZWQtc3RvcmFnZSBicm93c2Vycy5cbiAgfVxuICByZXR1cm4gY3JlYXRlTWVtb3J5U2Vzc2lvblN0b3JhZ2UoKVxufVxuXG5jb25zdCBXT1JLRVJfU0NSSVBUID0gYFxuICBhZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCAoZSkgPT4ge1xuICAgIGlmIChlLmRhdGEuZXZlbnQgPT09IFwic3RhcnRcIikge1xuICAgICAgc2V0SW50ZXJ2YWwoKCkgPT4gcG9zdE1lc3NhZ2UoeyBldmVudDogXCJrZWVwQWxpdmVcIiB9KSwgZS5kYXRhLmludGVydmFsKTtcbiAgICB9XG4gIH0pO2BcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVhbHRpbWVDbGllbnQge1xuICAvKiogQGludGVybmFsICovXG4gIHNvY2tldEFkYXB0ZXI6IFNvY2tldEFkYXB0ZXJcbiAgY2hhbm5lbHM6IFJlYWx0aW1lQ2hhbm5lbFtdID0gbmV3IEFycmF5KClcblxuICBhY2Nlc3NUb2tlblZhbHVlOiBzdHJpbmcgfCBudWxsID0gbnVsbFxuICBhY2Nlc3NUb2tlbjogKCgpID0+IFByb21pc2U8c3RyaW5nIHwgbnVsbD4pIHwgbnVsbCA9IG51bGxcbiAgYXBpS2V5OiBzdHJpbmcgfCBudWxsID0gbnVsbFxuXG4gIGh0dHBFbmRwb2ludDogc3RyaW5nID0gJydcbiAgLyoqIEBkZXByZWNhdGVkIGhlYWRlcnMgY2Fubm90IGJlIHNldCBvbiB3ZWJzb2NrZXQgY29ubmVjdGlvbnMgKi9cbiAgaGVhZGVycz86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fVxuICBwYXJhbXM/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge31cblxuICByZWY6IG51bWJlciA9IDBcblxuICBsb2dMZXZlbD86IExvZ0xldmVsXG5cbiAgZmV0Y2g6IEZldGNoXG4gIHdvcmtlcj86IGJvb2xlYW5cbiAgd29ya2VyVXJsPzogc3RyaW5nXG4gIHdvcmtlclJlZj86IFdvcmtlclxuXG4gIHNlcmlhbGl6ZXI6IFNlcmlhbGl6ZXIgPSBuZXcgU2VyaWFsaXplcigpXG5cbiAgZ2V0IGVuZFBvaW50KCkge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIuZW5kUG9pbnRcbiAgfVxuXG4gIGdldCB0aW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIudGltZW91dFxuICB9XG5cbiAgZ2V0IHRyYW5zcG9ydCgpIHtcbiAgICByZXR1cm4gdGhpcy5zb2NrZXRBZGFwdGVyLnRyYW5zcG9ydFxuICB9XG5cbiAgZ2V0IGhlYXJ0YmVhdENhbGxiYWNrKCkge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIuaGVhcnRiZWF0Q2FsbGJhY2tcbiAgfVxuXG4gIGdldCBoZWFydGJlYXRJbnRlcnZhbE1zKCkge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIuaGVhcnRiZWF0SW50ZXJ2YWxNc1xuICB9XG5cbiAgZ2V0IGhlYXJ0YmVhdFRpbWVyKCkge1xuICAgIGlmICh0aGlzLndvcmtlcikge1xuICAgICAgcmV0dXJuIHRoaXMuX3dvcmtlckhlYXJ0YmVhdFRpbWVyXG4gICAgfVxuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIuaGVhcnRiZWF0VGltZXJcbiAgfVxuXG4gIGdldCBwZW5kaW5nSGVhcnRiZWF0UmVmKCkge1xuICAgIGlmICh0aGlzLndvcmtlcikge1xuICAgICAgcmV0dXJuIHRoaXMuX3BlbmRpbmdXb3JrZXJIZWFydGJlYXRSZWZcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc29ja2V0QWRhcHRlci5wZW5kaW5nSGVhcnRiZWF0UmVmXG4gIH1cblxuICBnZXQgcmVjb25uZWN0VGltZXIoKTogVGltZXIge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIucmVjb25uZWN0VGltZXJcbiAgfVxuXG4gIGdldCB2c24oKTogVnNuIHtcbiAgICByZXR1cm4gdGhpcy5zb2NrZXRBZGFwdGVyLnZzblxuICB9XG5cbiAgZ2V0IGVuY29kZSgpIHtcbiAgICByZXR1cm4gdGhpcy5zb2NrZXRBZGFwdGVyLmVuY29kZVxuICB9XG5cbiAgZ2V0IGRlY29kZSgpIHtcbiAgICByZXR1cm4gdGhpcy5zb2NrZXRBZGFwdGVyLmRlY29kZVxuICB9XG5cbiAgZ2V0IHJlY29ubmVjdEFmdGVyTXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuc29ja2V0QWRhcHRlci5yZWNvbm5lY3RBZnRlck1zXG4gIH1cblxuICBnZXQgc2VuZEJ1ZmZlcigpIHtcbiAgICByZXR1cm4gdGhpcy5zb2NrZXRBZGFwdGVyLnNlbmRCdWZmZXJcbiAgfVxuXG4gIGdldCBzdGF0ZUNoYW5nZUNhbGxiYWNrcygpOiB7XG4gICAgb3BlbjogW3N0cmluZywgRnVuY3Rpb25dW11cbiAgICBjbG9zZTogW3N0cmluZywgRnVuY3Rpb25dW11cbiAgICBlcnJvcjogW3N0cmluZywgRnVuY3Rpb25dW11cbiAgICBtZXNzYWdlOiBbc3RyaW5nLCBGdW5jdGlvbl1bXVxuICB9IHtcbiAgICByZXR1cm4gdGhpcy5zb2NrZXRBZGFwdGVyLnN0YXRlQ2hhbmdlQ2FsbGJhY2tzXG4gIH1cblxuICBwcml2YXRlIF9tYW51YWxseVNldFRva2VuOiBib29sZWFuID0gZmFsc2VcbiAgcHJpdmF0ZSBfYXV0aFByb21pc2U6IFByb21pc2U8dm9pZD4gfCBudWxsID0gbnVsbFxuICBwcml2YXRlIF93b3JrZXJIZWFydGJlYXRUaW1lcjogSGVhcnRiZWF0VGltZXIgPSB1bmRlZmluZWRcbiAgcHJpdmF0ZSBfcGVuZGluZ1dvcmtlckhlYXJ0YmVhdFJlZjogc3RyaW5nIHwgbnVsbCA9IG51bGxcbiAgcHJpdmF0ZSBfcGVuZGluZ0Rpc2Nvbm5lY3RUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsID0gbnVsbFxuICBwcml2YXRlIF9kaXNjb25uZWN0T25FbXB0eUNoYW5uZWxzQWZ0ZXJNczogbnVtYmVyID0gMFxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgU29ja2V0LlxuICAgKlxuICAgKiBAcGFyYW0gZW5kUG9pbnQgVGhlIHN0cmluZyBXZWJTb2NrZXQgZW5kcG9pbnQsIGllLCBcIndzOi8vZXhhbXBsZS5jb20vc29ja2V0XCIsIFwid3NzOi8vZXhhbXBsZS5jb21cIiwgXCIvc29ja2V0XCIgKGluaGVyaXRlZCBob3N0ICYgcHJvdG9jb2wpXG4gICAqIEBwYXJhbSBodHRwRW5kcG9pbnQgVGhlIHN0cmluZyBIVFRQIGVuZHBvaW50LCBpZSwgXCJodHRwczovL2V4YW1wbGUuY29tXCIsIFwiL1wiIChpbmhlcml0ZWQgaG9zdCAmIHByb3RvY29sKVxuICAgKiBAcGFyYW0gb3B0aW9ucy50cmFuc3BvcnQgVGhlIFdlYnNvY2tldCBUcmFuc3BvcnQsIGZvciBleGFtcGxlIFdlYlNvY2tldC4gVGhpcyBjYW4gYmUgYSBjdXN0b20gaW1wbGVtZW50YXRpb25cbiAgICogQHBhcmFtIG9wdGlvbnMudGltZW91dCBUaGUgZGVmYXVsdCB0aW1lb3V0IGluIG1pbGxpc2Vjb25kcyB0byB0cmlnZ2VyIHB1c2ggdGltZW91dHMuXG4gICAqIEBwYXJhbSBvcHRpb25zLnBhcmFtcyBUaGUgb3B0aW9uYWwgcGFyYW1zIHRvIHBhc3Mgd2hlbiBjb25uZWN0aW5nLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5oZWFkZXJzIERlcHJlY2F0ZWQ6IGhlYWRlcnMgY2Fubm90IGJlIHNldCBvbiB3ZWJzb2NrZXQgY29ubmVjdGlvbnMgYW5kIHRoaXMgb3B0aW9uIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgZnV0dXJlLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5oZWFydGJlYXRJbnRlcnZhbE1zIFRoZSBtaWxsaXNlYyBpbnRlcnZhbCB0byBzZW5kIGEgaGVhcnRiZWF0IG1lc3NhZ2UuXG4gICAqIEBwYXJhbSBvcHRpb25zLmhlYXJ0YmVhdENhbGxiYWNrIFRoZSBvcHRpb25hbCBmdW5jdGlvbiB0byBoYW5kbGUgaGVhcnRiZWF0IHN0YXR1cyBhbmQgbGF0ZW5jeS5cbiAgICogQHBhcmFtIG9wdGlvbnMubG9nZ2VyIFRoZSBvcHRpb25hbCBmdW5jdGlvbiBmb3Igc3BlY2lhbGl6ZWQgbG9nZ2luZywgaWU6IGxvZ2dlcjogKGtpbmQsIG1zZywgZGF0YSkgPT4geyBjb25zb2xlLmxvZyhgJHtraW5kfTogJHttc2d9YCwgZGF0YSkgfVxuICAgKiBAcGFyYW0gb3B0aW9ucy5sb2dMZXZlbCBTZXRzIHRoZSBsb2cgbGV2ZWwgZm9yIFJlYWx0aW1lXG4gICAqIEBwYXJhbSBvcHRpb25zLmVuY29kZSBUaGUgZnVuY3Rpb24gdG8gZW5jb2RlIG91dGdvaW5nIG1lc3NhZ2VzLiBEZWZhdWx0cyB0byBKU09OOiAocGF5bG9hZCwgY2FsbGJhY2spID0+IGNhbGxiYWNrKEpTT04uc3RyaW5naWZ5KHBheWxvYWQpKVxuICAgKiBAcGFyYW0gb3B0aW9ucy5kZWNvZGUgVGhlIGZ1bmN0aW9uIHRvIGRlY29kZSBpbmNvbWluZyBtZXNzYWdlcy4gRGVmYXVsdHMgdG8gU2VyaWFsaXplcidzIGRlY29kZS5cbiAgICogQHBhcmFtIG9wdGlvbnMucmVjb25uZWN0QWZ0ZXJNcyBoZSBvcHRpb25hbCBmdW5jdGlvbiB0aGF0IHJldHVybnMgdGhlIG1pbGxzZWMgcmVjb25uZWN0IGludGVydmFsLiBEZWZhdWx0cyB0byBzdGVwcGVkIGJhY2tvZmYgb2ZmLlxuICAgKiBAcGFyYW0gb3B0aW9ucy53b3JrZXIgVXNlIFdlYiBXb3JrZXIgdG8gc2V0IGEgc2lkZSBmbG93LiBEZWZhdWx0cyB0byBmYWxzZS5cbiAgICogQHBhcmFtIG9wdGlvbnMud29ya2VyVXJsIFRoZSBVUkwgb2YgdGhlIHdvcmtlciBzY3JpcHQuIERlZmF1bHRzIHRvIGh0dHBzOi8vcmVhbHRpbWUuc3VwYWJhc2UuY29tL3dvcmtlci5qcyB0aGF0IGluY2x1ZGVzIGEgaGVhcnRiZWF0IGV2ZW50IGNhbGwgdG8ga2VlcCB0aGUgY29ubmVjdGlvbiBhbGl2ZS5cbiAgICogQHBhcmFtIG9wdGlvbnMudnNuIFRoZSBwcm90b2NvbCB2ZXJzaW9uIHRvIHVzZSB3aGVuIGNvbm5lY3RpbmcuIFN1cHBvcnRlZCB2ZXJzaW9ucyBhcmUgXCIxLjAuMFwiIGFuZCBcIjIuMC4wXCIuIERlZmF1bHRzIHRvIFwiMi4wLjBcIi5cbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqXG4gICAqIEBleGFtcGxlIFVzaW5nIHN1cGFiYXNlLWpzIChyZWNvbW1lbmRlZClcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3N1cGFiYXNlLWpzJ1xuICAgKlxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudCgnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvJywgJ3lvdXItcHVibGlzaGFibGUta2V5JylcbiAgICogY29uc3QgY2hhbm5lbCA9IHN1cGFiYXNlLmNoYW5uZWwoJ3Jvb20xJylcbiAgICogY2hhbm5lbFxuICAgKiAgIC5vbignYnJvYWRjYXN0JywgeyBldmVudDogJ2N1cnNvci1wb3MnIH0sIChwYXlsb2FkKSA9PiBjb25zb2xlLmxvZyhwYXlsb2FkKSlcbiAgICogICAuc3Vic2NyaWJlKClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFN0YW5kYWxvbmUgaW1wb3J0IGZvciBidW5kbGUtc2Vuc2l0aXZlIGVudmlyb25tZW50c1xuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgUmVhbHRpbWVDbGllbnQgZnJvbSAnQHN1cGFiYXNlL3JlYWx0aW1lLWpzJ1xuICAgKlxuICAgKiBjb25zdCBjbGllbnQgPSBuZXcgUmVhbHRpbWVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jby9yZWFsdGltZS92MScsIHtcbiAgICogICBwYXJhbXM6IHsgYXBpa2V5OiAneW91ci1wdWJsaXNoYWJsZS1rZXknIH0sXG4gICAqIH0pXG4gICAqIGNsaWVudC5jb25uZWN0KClcbiAgICogYGBgXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbmRQb2ludDogc3RyaW5nLCBvcHRpb25zPzogUmVhbHRpbWVDbGllbnRPcHRpb25zKSB7XG4gICAgLy8gVmFsaWRhdGUgcmVxdWlyZWQgcGFyYW1ldGVyc1xuICAgIGlmICghb3B0aW9ucz8ucGFyYW1zPy5hcGlrZXkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQVBJIGtleSBpcyByZXF1aXJlZCB0byBjb25uZWN0IHRvIFJlYWx0aW1lJylcbiAgICB9XG4gICAgdGhpcy5hcGlLZXkgPSBvcHRpb25zLnBhcmFtcy5hcGlrZXlcblxuICAgIGNvbnN0IHNvY2tldEFkYXB0ZXJPcHRpb25zID0gdGhpcy5faW5pdGlhbGl6ZU9wdGlvbnMob3B0aW9ucylcblxuICAgIHRoaXMuc29ja2V0QWRhcHRlciA9IG5ldyBTb2NrZXRBZGFwdGVyKGVuZFBvaW50LCBzb2NrZXRBZGFwdGVyT3B0aW9ucylcbiAgICB0aGlzLmh0dHBFbmRwb2ludCA9IGh0dHBFbmRwb2ludFVSTChlbmRQb2ludClcblxuICAgIHRoaXMuZmV0Y2ggPSB0aGlzLl9yZXNvbHZlRmV0Y2gob3B0aW9ucz8uZmV0Y2gpXG4gIH1cblxuICAvKipcbiAgICogQ29ubmVjdHMgdGhlIHNvY2tldCwgdW5sZXNzIGFscmVhZHkgY29ubmVjdGVkLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGNvbm5lY3QoKTogdm9pZCB7XG4gICAgLy8gU2tpcCBpZiBhbHJlYWR5IGNvbm5lY3RpbmcsIGRpc2Nvbm5lY3RpbmcsIG9yIGNvbm5lY3RlZFxuICAgIGlmICh0aGlzLmlzQ29ubmVjdGluZygpIHx8IHRoaXMuaXNEaXNjb25uZWN0aW5nKCkgfHwgdGhpcy5pc0Nvbm5lY3RlZCgpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICAvLyBUcmlnZ2VyIGF1dGggaWYgbmVlZGVkIGFuZCBub3QgYWxyZWFkeSBpbiBwcm9ncmVzc1xuICAgIC8vIFRoaXMgZW5zdXJlcyBhdXRoIGlzIGNhbGxlZCBmb3Igc3RhbmRhbG9uZSBSZWFsdGltZUNsaWVudCB1c2FnZVxuICAgIC8vIHdoaWxlIGF2b2lkaW5nIHJhY2UgY29uZGl0aW9ucyB3aXRoIFN1cGFiYXNlQ2xpZW50J3MgaW1tZWRpYXRlIHNldEF1dGggY2FsbFxuICAgIGlmICh0aGlzLmFjY2Vzc1Rva2VuICYmICF0aGlzLl9hdXRoUHJvbWlzZSkge1xuICAgICAgdGhpcy5fc2V0QXV0aFNhZmVseSgnY29ubmVjdCcpXG4gICAgfVxuXG4gICAgdGhpcy5fc2V0dXBDb25uZWN0aW9uSGFuZGxlcnMoKVxuXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuc29ja2V0QWRhcHRlci5jb25uZWN0KClcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc3QgZXJyb3JNZXNzYWdlID0gKGVycm9yIGFzIEVycm9yKS5tZXNzYWdlXG5cbiAgICAgIC8vIFByb3ZpZGUgaGVscGZ1bCBlcnJvciBtZXNzYWdlIGJhc2VkIG9uIGVudmlyb25tZW50XG4gICAgICBpZiAoZXJyb3JNZXNzYWdlLmluY2x1ZGVzKCdOb2RlLmpzJykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGAke2Vycm9yTWVzc2FnZX1cXG5cXG5gICtcbiAgICAgICAgICAgICdUbyB1c2UgUmVhbHRpbWUgaW4gTm9kZS5qcywgeW91IG5lZWQgdG8gcHJvdmlkZSBhIFdlYlNvY2tldCBpbXBsZW1lbnRhdGlvbjpcXG5cXG4nICtcbiAgICAgICAgICAgICdPcHRpb24gMTogVXNlIE5vZGUuanMgMjIrIHdoaWNoIGhhcyBuYXRpdmUgV2ViU29ja2V0IHN1cHBvcnRcXG4nICtcbiAgICAgICAgICAgICdPcHRpb24gMjogSW5zdGFsbCBhbmQgcHJvdmlkZSB0aGUgXCJ3c1wiIHBhY2thZ2U6XFxuXFxuJyArXG4gICAgICAgICAgICAnICBucG0gaW5zdGFsbCB3c1xcblxcbicgK1xuICAgICAgICAgICAgJyAgaW1wb3J0IHdzIGZyb20gXCJ3c1wiXFxuJyArXG4gICAgICAgICAgICAnICBjb25zdCBjbGllbnQgPSBuZXcgUmVhbHRpbWVDbGllbnQodXJsLCB7XFxuJyArXG4gICAgICAgICAgICAnICAgIC4uLm9wdGlvbnMsXFxuJyArXG4gICAgICAgICAgICAnICAgIHRyYW5zcG9ydDogd3NcXG4nICtcbiAgICAgICAgICAgICcgIH0pJ1xuICAgICAgICApXG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFdlYlNvY2tldCBub3QgYXZhaWxhYmxlOiAke2Vycm9yTWVzc2FnZX1gKVxuICAgIH1cblxuICAgIHRoaXMuX2hhbmRsZU5vZGVKc1JhY2VDb25kaXRpb24oKVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIFVSTCBvZiB0aGUgd2Vic29ja2V0LlxuICAgKiBAcmV0dXJucyBzdHJpbmcgVGhlIFVSTCBvZiB0aGUgd2Vic29ja2V0LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGVuZHBvaW50VVJMKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuc29ja2V0QWRhcHRlci5lbmRQb2ludFVSTCgpXG4gIH1cblxuICAvKipcbiAgICogRGlzY29ubmVjdHMgdGhlIHNvY2tldC5cbiAgICpcbiAgICogQHBhcmFtIGNvZGUgQSBudW1lcmljIHN0YXR1cyBjb2RlIHRvIHNlbmQgb24gZGlzY29ubmVjdC5cbiAgICogQHBhcmFtIHJlYXNvbiBBIGN1c3RvbSByZWFzb24gZm9yIHRoZSBkaXNjb25uZWN0LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGFzeW5jIGRpc2Nvbm5lY3QoY29kZT86IG51bWJlciwgcmVhc29uPzogc3RyaW5nKSB7XG4gICAgdGhpcy5fY2FuY2VsUGVuZGluZ0Rpc2Nvbm5lY3QoKVxuICAgIGlmICh0aGlzLmlzRGlzY29ubmVjdGluZygpKSB7XG4gICAgICByZXR1cm4gJ29rJ1xuICAgIH1cbiAgICByZXR1cm4gYXdhaXQgdGhpcy5zb2NrZXRBZGFwdGVyLmRpc2Nvbm5lY3QoXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5fd29ya2VySGVhcnRiZWF0VGltZXIpXG4gICAgICAgIHRoaXMuX3Rlcm1pbmF0ZVdvcmtlcigpXG4gICAgICB9LFxuICAgICAgY29kZSxcbiAgICAgIHJlYXNvblxuICAgIClcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGFsbCBjcmVhdGVkIGNoYW5uZWxzXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgZ2V0Q2hhbm5lbHMoKTogUmVhbHRpbWVDaGFubmVsW10ge1xuICAgIHJldHVybiB0aGlzLmNoYW5uZWxzXG4gIH1cblxuICAvKipcbiAgICogVW5zdWJzY3JpYmVzLCByZW1vdmVzIGFuZCB0ZWFycyBkb3duIGEgc2luZ2xlIGNoYW5uZWxcbiAgICogQHBhcmFtIGNoYW5uZWwgQSBSZWFsdGltZUNoYW5uZWwgaW5zdGFuY2VcbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqL1xuICBhc3luYyByZW1vdmVDaGFubmVsKGNoYW5uZWw6IFJlYWx0aW1lQ2hhbm5lbCk6IFByb21pc2U8UmVhbHRpbWVSZW1vdmVDaGFubmVsUmVzcG9uc2U+IHtcbiAgICBjb25zdCBzdGF0dXMgPSBhd2FpdCBjaGFubmVsLnVuc3Vic2NyaWJlKClcblxuICAgIGlmIChzdGF0dXMgPT09ICdvaycpIHtcbiAgICAgIGNoYW5uZWwudGVhcmRvd24oKVxuICAgIH1cblxuICAgIHJldHVybiBzdGF0dXNcbiAgfVxuXG4gIC8qKlxuICAgKiBVbnN1YnNjcmliZXMsIHJlbW92ZXMgYW5kIHRlYXJzIGRvd24gYWxsIGNoYW5uZWxzXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgYXN5bmMgcmVtb3ZlQWxsQ2hhbm5lbHMoKTogUHJvbWlzZTxSZWFsdGltZVJlbW92ZUNoYW5uZWxSZXNwb25zZVtdPiB7XG4gICAgY29uc3QgcHJvbWlzZXMgPSB0aGlzLmNoYW5uZWxzLm1hcChhc3luYyAoY2hhbm5lbCkgPT4ge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2hhbm5lbC51bnN1YnNjcmliZSgpXG4gICAgICBjaGFubmVsLnRlYXJkb3duKClcbiAgICAgIHJldHVybiByZXN1bHRcbiAgICB9KVxuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgUHJvbWlzZS5hbGwocHJvbWlzZXMpXG4gICAgYXdhaXQgdGhpcy5kaXNjb25uZWN0KClcbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICAvKipcbiAgICogTG9ncyB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogRm9yIGN1c3RvbWl6ZWQgbG9nZ2luZywgYHRoaXMubG9nZ2VyYCBjYW4gYmUgb3ZlcnJpZGRlbiBpbiBDbGllbnQgY29uc3RydWN0b3IuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgbG9nKGtpbmQ6IHN0cmluZywgbXNnOiBzdHJpbmcsIGRhdGE/OiBhbnkpIHtcbiAgICB0aGlzLnNvY2tldEFkYXB0ZXIubG9nKGtpbmQsIG1zZywgZGF0YSlcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBjdXJyZW50IHN0YXRlIG9mIHRoZSBzb2NrZXQuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgY29ubmVjdGlvblN0YXRlKCkge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIuY29ubmVjdGlvblN0YXRlKCkgfHwgQ09OTkVDVElPTl9TVEFURS5jbG9zZWRcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGB0cnVlYCBpcyB0aGUgY29ubmVjdGlvbiBpcyBvcGVuLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGlzQ29ubmVjdGVkKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIuaXNDb25uZWN0ZWQoKVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBjb25uZWN0aW9uIGlzIGN1cnJlbnRseSBjb25uZWN0aW5nLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGlzQ29ubmVjdGluZygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zb2NrZXRBZGFwdGVyLmlzQ29ubmVjdGluZygpXG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGNvbm5lY3Rpb24gaXMgY3VycmVudGx5IGRpc2Nvbm5lY3RpbmcuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBSZWFsdGltZVxuICAgKi9cbiAgaXNEaXNjb25uZWN0aW5nKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIuaXNEaXNjb25uZWN0aW5nKClcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIChvciByZXVzZXMpIGEge0BsaW5rIFJlYWx0aW1lQ2hhbm5lbH0gZm9yIHRoZSBwcm92aWRlZCB0b3BpYy5cbiAgICpcbiAgICogVG9waWNzIGFyZSBhdXRvbWF0aWNhbGx5IHByZWZpeGVkIHdpdGggYHJlYWx0aW1lOmAgdG8gbWF0Y2ggdGhlIFJlYWx0aW1lIHNlcnZpY2UuXG4gICAqIElmIGEgY2hhbm5lbCB3aXRoIHRoZSBzYW1lIHRvcGljIGFscmVhZHkgZXhpc3RzIGl0IHdpbGwgYmUgcmV0dXJuZWQgaW5zdGVhZCBvZiBjcmVhdGluZ1xuICAgKiBhIGR1cGxpY2F0ZSBjb25uZWN0aW9uLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGNoYW5uZWwodG9waWM6IHN0cmluZywgcGFyYW1zOiBSZWFsdGltZUNoYW5uZWxPcHRpb25zID0geyBjb25maWc6IHt9IH0pOiBSZWFsdGltZUNoYW5uZWwge1xuICAgIGNvbnN0IHJlYWx0aW1lVG9waWMgPSBgcmVhbHRpbWU6JHt0b3BpY31gXG4gICAgY29uc3QgZXhpc3RzID0gdGhpcy5nZXRDaGFubmVscygpLmZpbmQoKGM6IFJlYWx0aW1lQ2hhbm5lbCkgPT4gYy50b3BpYyA9PT0gcmVhbHRpbWVUb3BpYylcblxuICAgIGlmICghZXhpc3RzKSB7XG4gICAgICBjb25zdCBjaGFuID0gbmV3IFJlYWx0aW1lQ2hhbm5lbChgcmVhbHRpbWU6JHt0b3BpY31gLCBwYXJhbXMsIHRoaXMpXG4gICAgICB0aGlzLl9jYW5jZWxQZW5kaW5nRGlzY29ubmVjdCgpXG4gICAgICB0aGlzLmNoYW5uZWxzLnB1c2goY2hhbilcblxuICAgICAgcmV0dXJuIGNoYW5cbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGV4aXN0c1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQdXNoIG91dCBhIG1lc3NhZ2UgaWYgdGhlIHNvY2tldCBpcyBjb25uZWN0ZWQuXG4gICAqXG4gICAqIElmIHRoZSBzb2NrZXQgaXMgbm90IGNvbm5lY3RlZCwgdGhlIG1lc3NhZ2UgZ2V0cyBlbnF1ZXVlZCB3aXRoaW4gYSBsb2NhbCBidWZmZXIsIGFuZCBzZW50IG91dCB3aGVuIGEgY29ubmVjdGlvbiBpcyBuZXh0IGVzdGFibGlzaGVkLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIHB1c2goZGF0YTogUmVhbHRpbWVNZXNzYWdlKTogdm9pZCB7XG4gICAgdGhpcy5zb2NrZXRBZGFwdGVyLnB1c2goZGF0YSlcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBKV1QgYWNjZXNzIHRva2VuIHVzZWQgZm9yIGNoYW5uZWwgc3Vic2NyaXB0aW9uIGF1dGhvcml6YXRpb24gYW5kIFJlYWx0aW1lIFJMUy5cbiAgICpcbiAgICogSWYgcGFyYW0gaXMgbnVsbCBpdCB3aWxsIHVzZSB0aGUgYGFjY2Vzc1Rva2VuYCBjYWxsYmFjayBmdW5jdGlvbiBvciB0aGUgdG9rZW4gc2V0IG9uIHRoZSBjbGllbnQuXG4gICAqXG4gICAqIE9uIGNhbGxiYWNrIHVzZWQsIGl0IHdpbGwgc2V0IHRoZSB2YWx1ZSBvZiB0aGUgdG9rZW4gaW50ZXJuYWwgdG8gdGhlIGNsaWVudC5cbiAgICpcbiAgICogV2hlbiBhIHRva2VuIGlzIGV4cGxpY2l0bHkgcHJvdmlkZWQsIGl0IHdpbGwgYmUgcHJlc2VydmVkIGFjcm9zcyBjaGFubmVsIG9wZXJhdGlvbnNcbiAgICogKGluY2x1ZGluZyByZW1vdmVDaGFubmVsIGFuZCByZXN1YnNjcmliZSkuIFRoZSBgYWNjZXNzVG9rZW5gIGNhbGxiYWNrIHdpbGwgbm90IGJlXG4gICAqIGludm9rZWQgdW50aWwgYHNldEF1dGgoKWAgaXMgY2FsbGVkIHdpdGhvdXQgYXJndW1lbnRzLlxuICAgKlxuICAgKiBAcGFyYW0gdG9rZW4gQSBKV1Qgc3RyaW5nIHRvIG92ZXJyaWRlIHRoZSB0b2tlbiBzZXQgb24gdGhlIGNsaWVudC5cbiAgICpcbiAgICogQGV4YW1wbGUgU2V0dGluZyB0aGUgYXV0aG9yaXphdGlvbiBoZWFkZXJcbiAgICogLy8gVXNlIGEgbWFudWFsIHRva2VuIChwcmVzZXJ2ZWQgYWNyb3NzIHJlc3Vic2NyaWJlcywgaWdub3JlcyBhY2Nlc3NUb2tlbiBjYWxsYmFjaylcbiAgICogY2xpZW50LnJlYWx0aW1lLnNldEF1dGgoJ215LWN1c3RvbS1qd3QnKVxuICAgKlxuICAgKiAvLyBTd2l0Y2ggYmFjayB0byB1c2luZyB0aGUgYWNjZXNzVG9rZW4gY2FsbGJhY2tcbiAgICogY2xpZW50LnJlYWx0aW1lLnNldEF1dGgoKVxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGFzeW5jIHNldEF1dGgodG9rZW46IHN0cmluZyB8IG51bGwgPSBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5fYXV0aFByb21pc2UgPSB0aGlzLl9wZXJmb3JtQXV0aCh0b2tlbilcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5fYXV0aFByb21pc2VcbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5fYXV0aFByb21pc2UgPSBudWxsXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgY3VycmVudCBhY2Nlc3MgdG9rZW4gd2FzIGV4cGxpY2l0bHkgc2V0IHZpYSBzZXRBdXRoKHRva2VuKSxcbiAgICogZmFsc2UgaWYgaXQgd2FzIG9idGFpbmVkIHZpYSB0aGUgYWNjZXNzVG9rZW4gY2FsbGJhY2suXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX2lzTWFudWFsVG9rZW4oKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX21hbnVhbGx5U2V0VG9rZW5cbiAgfVxuXG4gIC8qKlxuICAgKiBTZW5kcyBhIGhlYXJ0YmVhdCBtZXNzYWdlIGlmIHRoZSBzb2NrZXQgaXMgY29ubmVjdGVkLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIGFzeW5jIHNlbmRIZWFydGJlYXQoKSB7XG4gICAgdGhpcy5zb2NrZXRBZGFwdGVyLnNlbmRIZWFydGJlYXQoKVxuICB9XG5cbiAgLyoqXG4gICAqIFNldHMgYSBjYWxsYmFjayB0aGF0IHJlY2VpdmVzIGxpZmVjeWNsZSBldmVudHMgZm9yIGludGVybmFsIGhlYXJ0YmVhdCBtZXNzYWdlcy5cbiAgICogVXNlZnVsIGZvciBpbnN0cnVtZW50aW5nIGNvbm5lY3Rpb24gaGVhbHRoIChlLmcuIHNlbnQvb2svdGltZW91dC9kaXNjb25uZWN0ZWQpLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgUmVhbHRpbWVcbiAgICovXG4gIG9uSGVhcnRiZWF0KGNhbGxiYWNrOiBIZWFydGJlYXRDYWxsYmFjaykge1xuICAgIHRoaXMuc29ja2V0QWRhcHRlci5oZWFydGJlYXRDYWxsYmFjayA9IHRoaXMuX3dyYXBIZWFydGJlYXRDYWxsYmFjayhjYWxsYmFjaylcbiAgfVxuXG4gIC8qKlxuICAgKiBVc2UgZWl0aGVyIGN1c3RvbSBmZXRjaCwgaWYgcHJvdmlkZWQsIG9yIGRlZmF1bHQgZmV0Y2ggdG8gbWFrZSBIVFRQIHJlcXVlc3RzXG4gICAqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX3Jlc29sdmVGZXRjaCA9IChjdXN0b21GZXRjaD86IEZldGNoKTogRmV0Y2ggPT4ge1xuICAgIGlmIChjdXN0b21GZXRjaCkge1xuICAgICAgcmV0dXJuICguLi5hcmdzKSA9PiBjdXN0b21GZXRjaCguLi5hcmdzKVxuICAgIH1cbiAgICByZXR1cm4gKC4uLmFyZ3MpID0+IGZldGNoKC4uLmFyZ3MpXG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBuZXh0IG1lc3NhZ2UgcmVmLCBhY2NvdW50aW5nIGZvciBvdmVyZmxvd3NcbiAgICpcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfbWFrZVJlZigpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLnNvY2tldEFkYXB0ZXIubWFrZVJlZigpXG4gIH1cblxuICAvKipcbiAgICogUmVtb3ZlcyBhIGNoYW5uZWwgZnJvbSBSZWFsdGltZUNsaWVudFxuICAgKlxuICAgKiBAcGFyYW0gY2hhbm5lbCBBbiBvcGVuIHN1YnNjcmlwdGlvbi5cbiAgICpcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfcmVtb3ZlKGNoYW5uZWw6IFJlYWx0aW1lQ2hhbm5lbCkge1xuICAgIHRoaXMuY2hhbm5lbHMgPSB0aGlzLmNoYW5uZWxzLmZpbHRlcigoYykgPT4gYy50b3BpYyAhPT0gY2hhbm5lbC50b3BpYylcbiAgICBpZiAodGhpcy5jaGFubmVscy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRoaXMubG9nKCd0cmFuc3BvcnQnLCAnbm8gY2hhbm5lbHMgcmVtYWluaW5nLCBzY2hlZHVsaW5nIGRpc2Nvbm5lY3QnKVxuICAgICAgdGhpcy5fc2NoZWR1bGVQZW5kaW5nRGlzY29ubmVjdCgpXG4gICAgfVxuICB9XG5cbiAgLyoqIEBpbnRlcm5hbCAqL1xuICBwcml2YXRlIF9zY2hlZHVsZVBlbmRpbmdEaXNjb25uZWN0KCkge1xuICAgIHRoaXMuX2NhbmNlbFBlbmRpbmdEaXNjb25uZWN0KClcbiAgICBpZiAodGhpcy5fZGlzY29ubmVjdE9uRW1wdHlDaGFubmVsc0FmdGVyTXMgPT09IDApIHtcbiAgICAgIHRoaXMubG9nKCd0cmFuc3BvcnQnLCAnZGlzY29ubmVjdGluZyBpbW1lZGlhdGVseSAtIG5vIGNoYW5uZWxzJylcbiAgICAgIHRoaXMuZGlzY29ubmVjdCgpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgdGhpcy5fcGVuZGluZ0Rpc2Nvbm5lY3RUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5fcGVuZGluZ0Rpc2Nvbm5lY3RUaW1lciA9IG51bGxcbiAgICAgIGlmICh0aGlzLmNoYW5uZWxzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICB0aGlzLmxvZygndHJhbnNwb3J0JywgJ2RlZmVycmVkIGRpc2Nvbm5lY3QgZmlyZWQgLSBubyBjaGFubmVscywgZGlzY29ubmVjdGluZycpXG4gICAgICAgIHRoaXMuZGlzY29ubmVjdCgpXG4gICAgICB9XG4gICAgfSwgdGhpcy5fZGlzY29ubmVjdE9uRW1wdHlDaGFubmVsc0FmdGVyTXMpXG4gICAgdGhpcy5sb2coXG4gICAgICAndHJhbnNwb3J0JyxcbiAgICAgIGBkZWZlcnJlZCBkaXNjb25uZWN0IHNjaGVkdWxlZCBpbiAke3RoaXMuX2Rpc2Nvbm5lY3RPbkVtcHR5Q2hhbm5lbHNBZnRlck1zfW1zYFxuICAgIClcbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgcHJpdmF0ZSBfY2FuY2VsUGVuZGluZ0Rpc2Nvbm5lY3QoKSB7XG4gICAgaWYgKHRoaXMuX3BlbmRpbmdEaXNjb25uZWN0VGltZXIgIT09IG51bGwpIHtcbiAgICAgIHRoaXMubG9nKCd0cmFuc3BvcnQnLCAncGVuZGluZyBkaXNjb25uZWN0IGNhbmNlbGxlZCAtIGNoYW5uZWwgYWN0aXZpdHkgZGV0ZWN0ZWQnKVxuICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuX3BlbmRpbmdEaXNjb25uZWN0VGltZXIpXG4gICAgICB0aGlzLl9wZW5kaW5nRGlzY29ubmVjdFRpbWVyID0gbnVsbFxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQZXJmb3JtIHRoZSBhY3R1YWwgYXV0aCBvcGVyYXRpb25cbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9wZXJmb3JtQXV0aCh0b2tlbjogc3RyaW5nIHwgbnVsbCA9IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBsZXQgdG9rZW5Ub1NlbmQ6IHN0cmluZyB8IG51bGxcbiAgICBsZXQgaXNNYW51YWxUb2tlbiA9IGZhbHNlXG5cbiAgICBpZiAodG9rZW4pIHtcbiAgICAgIHRva2VuVG9TZW5kID0gdG9rZW5cbiAgICAgIC8vIFRyYWNrIGlmIHRoaXMgaXMgYSBtYW51YWxseS1wcm92aWRlZCB0b2tlblxuICAgICAgaXNNYW51YWxUb2tlbiA9IHRydWVcbiAgICB9IGVsc2UgaWYgKHRoaXMuYWNjZXNzVG9rZW4pIHtcbiAgICAgIC8vIENhbGwgdGhlIGFjY2Vzc1Rva2VuIGNhbGxiYWNrIHRvIGdldCBmcmVzaCB0b2tlblxuICAgICAgdHJ5IHtcbiAgICAgICAgdG9rZW5Ub1NlbmQgPSBhd2FpdCB0aGlzLmFjY2Vzc1Rva2VuKClcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhpcy5sb2coJ2Vycm9yJywgJ0Vycm9yIGZldGNoaW5nIGFjY2VzcyB0b2tlbiBmcm9tIGNhbGxiYWNrJywgZSlcbiAgICAgICAgLy8gRmFsbCBiYWNrIHRvIGNhY2hlZCB2YWx1ZSBpZiBjYWxsYmFjayBmYWlsc1xuICAgICAgICB0b2tlblRvU2VuZCA9IHRoaXMuYWNjZXNzVG9rZW5WYWx1ZVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0b2tlblRvU2VuZCA9IHRoaXMuYWNjZXNzVG9rZW5WYWx1ZVxuICAgIH1cblxuICAgIC8vIFRyYWNrIHdoZXRoZXIgdGhpcyB0b2tlbiB3YXMgbWFudWFsbHkgc2V0IG9yIGZldGNoZWQgdmlhIGNhbGxiYWNrXG4gICAgaWYgKGlzTWFudWFsVG9rZW4pIHtcbiAgICAgIHRoaXMuX21hbnVhbGx5U2V0VG9rZW4gPSB0cnVlXG4gICAgfSBlbHNlIGlmICh0aGlzLmFjY2Vzc1Rva2VuKSB7XG4gICAgICAvLyBJZiB3ZSB1c2VkIHRoZSBjYWxsYmFjaywgY2xlYXIgdGhlIG1hbnVhbCBmbGFnXG4gICAgICB0aGlzLl9tYW51YWxseVNldFRva2VuID0gZmFsc2VcbiAgICB9XG5cbiAgICBpZiAodGhpcy5hY2Nlc3NUb2tlblZhbHVlICE9IHRva2VuVG9TZW5kKSB7XG4gICAgICB0aGlzLmFjY2Vzc1Rva2VuVmFsdWUgPSB0b2tlblRvU2VuZFxuICAgICAgdGhpcy5jaGFubmVscy5mb3JFYWNoKChjaGFubmVsKSA9PiB7XG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICAgICAgYWNjZXNzX3Rva2VuOiB0b2tlblRvU2VuZCxcbiAgICAgICAgICB2ZXJzaW9uOiBERUZBVUxUX1ZFUlNJT04sXG4gICAgICAgIH1cblxuICAgICAgICB0b2tlblRvU2VuZCAmJiBjaGFubmVsLnVwZGF0ZUpvaW5QYXlsb2FkKHBheWxvYWQpXG5cbiAgICAgICAgaWYgKGNoYW5uZWwuam9pbmVkT25jZSAmJiBjaGFubmVsLmNoYW5uZWxBZGFwdGVyLmlzSm9pbmVkKCkpIHtcbiAgICAgICAgICBjaGFubmVsLmNoYW5uZWxBZGFwdGVyLnB1c2goQ0hBTk5FTF9FVkVOVFMuYWNjZXNzX3Rva2VuLCB7XG4gICAgICAgICAgICBhY2Nlc3NfdG9rZW46IHRva2VuVG9TZW5kLFxuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFdhaXQgZm9yIGFueSBpbi1mbGlnaHQgYXV0aCBvcGVyYXRpb25zIHRvIGNvbXBsZXRlXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfd2FpdEZvckF1dGhJZk5lZWRlZCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAodGhpcy5fYXV0aFByb21pc2UpIHtcbiAgICAgIGF3YWl0IHRoaXMuX2F1dGhQcm9taXNlXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFNhZmVseSBjYWxsIHNldEF1dGggd2l0aCBzdGFuZGFyZGl6ZWQgZXJyb3IgaGFuZGxpbmdcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIF9zZXRBdXRoU2FmZWx5KGNvbnRleHQgPSAnZ2VuZXJhbCcpOiB2b2lkIHtcbiAgICAvLyBPbmx5IHJlZnJlc2ggYXV0aCBpZiB1c2luZyBjYWxsYmFjay1iYXNlZCB0b2tlbnNcbiAgICBpZiAoIXRoaXMuX2lzTWFudWFsVG9rZW4oKSkge1xuICAgICAgdGhpcy5zZXRBdXRoKCkuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgdGhpcy5sb2coJ2Vycm9yJywgYEVycm9yIHNldHRpbmcgYXV0aCBpbiAke2NvbnRleHR9YCwgZSlcbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgLyoqIEBpbnRlcm5hbCAqL1xuICBwcml2YXRlIF9zZXR1cENvbm5lY3Rpb25IYW5kbGVycygpOiB2b2lkIHtcbiAgICB0aGlzLnNvY2tldEFkYXB0ZXIub25PcGVuKCgpID0+IHtcbiAgICAgIGNvbnN0IGF1dGhQcm9taXNlID1cbiAgICAgICAgdGhpcy5fYXV0aFByb21pc2UgfHxcbiAgICAgICAgKHRoaXMuYWNjZXNzVG9rZW4gJiYgIXRoaXMuYWNjZXNzVG9rZW5WYWx1ZSA/IHRoaXMuc2V0QXV0aCgpIDogUHJvbWlzZS5yZXNvbHZlKCkpXG5cbiAgICAgIGF1dGhQcm9taXNlLmNhdGNoKChlKSA9PiB7XG4gICAgICAgIHRoaXMubG9nKCdlcnJvcicsICdlcnJvciB3YWl0aW5nIGZvciBhdXRoIG9uIGNvbm5lY3QnLCBlKVxuICAgICAgfSlcblxuICAgICAgaWYgKHRoaXMud29ya2VyICYmICF0aGlzLndvcmtlclJlZikge1xuICAgICAgICB0aGlzLl9zdGFydFdvcmtlckhlYXJ0YmVhdCgpXG4gICAgICB9XG4gICAgfSlcbiAgICB0aGlzLnNvY2tldEFkYXB0ZXIub25DbG9zZSgoKSA9PiB7XG4gICAgICBpZiAodGhpcy53b3JrZXIgJiYgdGhpcy53b3JrZXJSZWYpIHtcbiAgICAgICAgdGhpcy5fdGVybWluYXRlV29ya2VyKClcbiAgICAgIH1cbiAgICB9KVxuICAgIHRoaXMuc29ja2V0QWRhcHRlci5vbk1lc3NhZ2UoKG1lc3NhZ2U6IE1lc3NhZ2U8YW55PikgPT4ge1xuICAgICAgaWYgKG1lc3NhZ2UucmVmICYmIG1lc3NhZ2UucmVmID09PSB0aGlzLl9wZW5kaW5nV29ya2VySGVhcnRiZWF0UmVmKSB7XG4gICAgICAgIHRoaXMuX3BlbmRpbmdXb3JrZXJIZWFydGJlYXRSZWYgPSBudWxsXG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgcHJpdmF0ZSBfaGFuZGxlTm9kZUpzUmFjZUNvbmRpdGlvbigpIHtcbiAgICBpZiAodGhpcy5zb2NrZXRBZGFwdGVyLmlzQ29ubmVjdGVkKCkpIHtcbiAgICAgIC8vIGhhY2s6IGVuc3VyZSBvbkNvbm5PcGVuIGlzIGNhbGxlZFxuICAgICAgdGhpcy5zb2NrZXRBZGFwdGVyLmdldFNvY2tldCgpLm9uQ29ubk9wZW4oKVxuICAgIH1cbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgcHJpdmF0ZSBfd3JhcEhlYXJ0YmVhdENhbGxiYWNrKGhlYXJ0YmVhdENhbGxiYWNrPzogSGVhcnRiZWF0Q2FsbGJhY2spOiBIZWFydGJlYXRDYWxsYmFjayB7XG4gICAgcmV0dXJuIChzdGF0dXMsIGxhdGVuY3kpID0+IHtcbiAgICAgIGlmIChzdGF0dXMgPT0gJ3NlbnQnKSB0aGlzLl9zZXRBdXRoU2FmZWx5KClcbiAgICAgIGlmIChoZWFydGJlYXRDYWxsYmFjaykgaGVhcnRiZWF0Q2FsbGJhY2soc3RhdHVzLCBsYXRlbmN5KVxuICAgIH1cbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgcHJpdmF0ZSBfc3RhcnRXb3JrZXJIZWFydGJlYXQoKSB7XG4gICAgaWYgKHRoaXMud29ya2VyVXJsKSB7XG4gICAgICB0aGlzLmxvZygnd29ya2VyJywgYHN0YXJ0aW5nIHdvcmtlciBmb3IgZnJvbSAke3RoaXMud29ya2VyVXJsfWApXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubG9nKCd3b3JrZXInLCBgc3RhcnRpbmcgZGVmYXVsdCB3b3JrZXJgKVxuICAgIH1cbiAgICBjb25zdCBvYmplY3RVcmwgPSB0aGlzLl93b3JrZXJPYmplY3RVcmwodGhpcy53b3JrZXJVcmwhKVxuICAgIHRoaXMud29ya2VyUmVmID0gbmV3IFdvcmtlcihvYmplY3RVcmwpXG4gICAgdGhpcy53b3JrZXJSZWYub25lcnJvciA9IChlcnJvcikgPT4ge1xuICAgICAgdGhpcy5sb2coJ3dvcmtlcicsICd3b3JrZXIgZXJyb3InLCAoZXJyb3IgYXMgRXJyb3JFdmVudCkubWVzc2FnZSlcbiAgICAgIHRoaXMuX3Rlcm1pbmF0ZVdvcmtlcigpXG4gICAgICB0aGlzLmRpc2Nvbm5lY3QoKVxuICAgIH1cbiAgICB0aGlzLndvcmtlclJlZi5vbm1lc3NhZ2UgPSAoZXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC5kYXRhLmV2ZW50ID09PSAna2VlcEFsaXZlJykge1xuICAgICAgICB0aGlzLnNlbmRIZWFydGJlYXQoKVxuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLndvcmtlclJlZi5wb3N0TWVzc2FnZSh7XG4gICAgICBldmVudDogJ3N0YXJ0JyxcbiAgICAgIGludGVydmFsOiB0aGlzLmhlYXJ0YmVhdEludGVydmFsTXMsXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBUZXJtaW5hdGUgdGhlIFdlYiBXb3JrZXIgYW5kIGNsZWFyIHRoZSByZWZlcmVuY2VcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIF90ZXJtaW5hdGVXb3JrZXIoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMud29ya2VyUmVmKSB7XG4gICAgICB0aGlzLmxvZygnd29ya2VyJywgJ3Rlcm1pbmF0aW5nIHdvcmtlcicpXG4gICAgICB0aGlzLndvcmtlclJlZi50ZXJtaW5hdGUoKVxuICAgICAgdGhpcy53b3JrZXJSZWYgPSB1bmRlZmluZWRcbiAgICB9XG4gIH1cblxuICAvKiogQGludGVybmFsICovXG4gIHByaXZhdGUgX3dvcmtlck9iamVjdFVybCh1cmw6IHN0cmluZyB8IHVuZGVmaW5lZCk6IHN0cmluZyB7XG4gICAgbGV0IHJlc3VsdF91cmw6IHN0cmluZ1xuICAgIGlmICh1cmwpIHtcbiAgICAgIHJlc3VsdF91cmwgPSB1cmxcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtXT1JLRVJfU0NSSVBUXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vamF2YXNjcmlwdCcgfSlcbiAgICAgIHJlc3VsdF91cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gICAgfVxuICAgIHJldHVybiByZXN1bHRfdXJsXG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZSBzb2NrZXQgb3B0aW9ucyB3aXRoIGRlZmF1bHRzXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSBfaW5pdGlhbGl6ZU9wdGlvbnMob3B0aW9ucz86IFJlYWx0aW1lQ2xpZW50T3B0aW9ucyk6IFNvY2tldE9wdGlvbnMge1xuICAgIHRoaXMud29ya2VyID0gb3B0aW9ucz8ud29ya2VyID8/IGZhbHNlXG4gICAgdGhpcy5hY2Nlc3NUb2tlbiA9IG9wdGlvbnM/LmFjY2Vzc1Rva2VuID8/IG51bGxcblxuICAgIGNvbnN0IHJlc3VsdDogU29ja2V0T3B0aW9ucyA9IHt9XG4gICAgcmVzdWx0LnRpbWVvdXQgPSBvcHRpb25zPy50aW1lb3V0ID8/IERFRkFVTFRfVElNRU9VVFxuICAgIHJlc3VsdC5oZWFydGJlYXRJbnRlcnZhbE1zID1cbiAgICAgIG9wdGlvbnM/LmhlYXJ0YmVhdEludGVydmFsTXMgPz8gQ09OTkVDVElPTl9USU1FT1VUUy5IRUFSVEJFQVRfSU5URVJWQUxcblxuICAgIHRoaXMuX2Rpc2Nvbm5lY3RPbkVtcHR5Q2hhbm5lbHNBZnRlck1zID1cbiAgICAgIG9wdGlvbnM/LmRpc2Nvbm5lY3RPbkVtcHR5Q2hhbm5lbHNBZnRlck1zID8/XG4gICAgICAyICogKG9wdGlvbnM/LmhlYXJ0YmVhdEludGVydmFsTXMgPz8gQ09OTkVDVElPTl9USU1FT1VUUy5IRUFSVEJFQVRfSU5URVJWQUwpXG5cbiAgICAvLyBAdHMtaWdub3JlIC0gbWlzbWF0Y2ggYmV0d2VlbiBwaG9lbml4IGFuZCBzdXBhYmFzZVxuICAgIHJlc3VsdC50cmFuc3BvcnQgPSBvcHRpb25zPy50cmFuc3BvcnQgPz8gV2ViU29ja2V0RmFjdG9yeS5nZXRXZWJTb2NrZXRDb25zdHJ1Y3RvcigpXG4gICAgcmVzdWx0LnBhcmFtcyA9IG9wdGlvbnM/LnBhcmFtc1xuICAgIHJlc3VsdC5sb2dnZXIgPSBvcHRpb25zPy5sb2dnZXJcbiAgICByZXN1bHQuaGVhcnRiZWF0Q2FsbGJhY2sgPSB0aGlzLl93cmFwSGVhcnRiZWF0Q2FsbGJhY2sob3B0aW9ucz8uaGVhcnRiZWF0Q2FsbGJhY2spXG4gICAgcmVzdWx0LnNlc3Npb25TdG9yYWdlID0gb3B0aW9ucz8uc2Vzc2lvblN0b3JhZ2UgPz8gcmVzb2x2ZVNlc3Npb25TdG9yYWdlKClcbiAgICByZXN1bHQucmVjb25uZWN0QWZ0ZXJNcyA9XG4gICAgICBvcHRpb25zPy5yZWNvbm5lY3RBZnRlck1zID8/XG4gICAgICAoKHRyaWVzOiBudW1iZXIpID0+IHtcbiAgICAgICAgcmV0dXJuIFJFQ09OTkVDVF9JTlRFUlZBTFNbdHJpZXMgLSAxXSB8fCBERUZBVUxUX1JFQ09OTkVDVF9GQUxMQkFDS1xuICAgICAgfSlcblxuICAgIGxldCBkZWZhdWx0RW5jb2RlOiBFbmNvZGU8dm9pZD5cbiAgICBsZXQgZGVmYXVsdERlY29kZTogRGVjb2RlPHZvaWQ+XG5cbiAgICBjb25zdCB2c24gPSBvcHRpb25zPy52c24gPz8gREVGQVVMVF9WU05cblxuICAgIHN3aXRjaCAodnNuKSB7XG4gICAgICBjYXNlIFZTTl8xXzBfMDpcbiAgICAgICAgZGVmYXVsdEVuY29kZSA9IChwYXlsb2FkLCBjYWxsYmFjaykgPT4ge1xuICAgICAgICAgIHJldHVybiBjYWxsYmFjayhKU09OLnN0cmluZ2lmeShwYXlsb2FkKSlcbiAgICAgICAgfVxuICAgICAgICBkZWZhdWx0RGVjb2RlID0gKHBheWxvYWQsIGNhbGxiYWNrKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKEpTT04ucGFyc2UocGF5bG9hZCBhcyBzdHJpbmcpKVxuICAgICAgICB9XG4gICAgICAgIGJyZWFrXG4gICAgICBjYXNlIFZTTl8yXzBfMDpcbiAgICAgICAgZGVmYXVsdEVuY29kZSA9IHRoaXMuc2VyaWFsaXplci5lbmNvZGUuYmluZCh0aGlzLnNlcmlhbGl6ZXIpXG4gICAgICAgIGRlZmF1bHREZWNvZGUgPSB0aGlzLnNlcmlhbGl6ZXIuZGVjb2RlLmJpbmQodGhpcy5zZXJpYWxpemVyKVxuICAgICAgICBicmVha1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbnN1cHBvcnRlZCBzZXJpYWxpemVyIHZlcnNpb246ICR7cmVzdWx0LnZzbn1gKVxuICAgIH1cblxuICAgIHJlc3VsdC52c24gPSB2c25cbiAgICByZXN1bHQuZW5jb2RlID0gb3B0aW9ucz8uZW5jb2RlID8/IGRlZmF1bHRFbmNvZGVcbiAgICByZXN1bHQuZGVjb2RlID0gb3B0aW9ucz8uZGVjb2RlID8/IGRlZmF1bHREZWNvZGVcblxuICAgIHJlc3VsdC5iZWZvcmVSZWNvbm5lY3QgPSB0aGlzLl9yZWNvbm5lY3RBdXRoLmJpbmQodGhpcylcblxuICAgIGlmIChvcHRpb25zPy5sb2dMZXZlbCB8fCBvcHRpb25zPy5sb2dfbGV2ZWwpIHtcbiAgICAgIHRoaXMubG9nTGV2ZWwgPSBvcHRpb25zLmxvZ0xldmVsIHx8IG9wdGlvbnMubG9nX2xldmVsXG4gICAgICByZXN1bHQucGFyYW1zID0geyAuLi5yZXN1bHQucGFyYW1zLCBsb2dfbGV2ZWw6IHRoaXMubG9nTGV2ZWwgYXMgc3RyaW5nIH1cbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgd29ya2VyIHNldHVwXG4gICAgaWYgKHRoaXMud29ya2VyKSB7XG4gICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgIXdpbmRvdy5Xb3JrZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdXZWIgV29ya2VyIGlzIG5vdCBzdXBwb3J0ZWQnKVxuICAgICAgfVxuICAgICAgdGhpcy53b3JrZXJVcmwgPSBvcHRpb25zPy53b3JrZXJVcmxcbiAgICAgIHJlc3VsdC5hdXRvU2VuZEhlYXJ0YmVhdCA9ICF0aGlzLndvcmtlclxuICAgIH1cblxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIC8qKiBAaW50ZXJuYWwgKi9cbiAgcHJpdmF0ZSBhc3luYyBfcmVjb25uZWN0QXV0aCgpIHtcbiAgICBhd2FpdCB0aGlzLl93YWl0Rm9yQXV0aElmTmVlZGVkKClcbiAgICBpZiAoIXRoaXMuaXNDb25uZWN0ZWQoKSkge1xuICAgICAgdGhpcy5jb25uZWN0KClcbiAgICB9XG4gIH1cbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19