import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/error.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/components/nuxt-link.js?v=583078ff";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"


import { useError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/nuxt@4.4.8_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_3f33abaf1628fd3aa4a59387bad681d3/node_modules/nuxt/dist/app/composables/error.js?v=583078ff";
const _sfc_main = {
  __name: 'error',
  setup(__props, { expose: __expose }) {
  __expose();

const error = useError();

console.log("asdf");

const __returned__ = { error }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { toDisplayString as _toDisplayString, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

const _hoisted_1 = { class: "error-page" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_NuxtLink = __nuxt_component_0

  return (_openBlock(), _tracer(2,1,_createElementBlock("div", _hoisted_1, [
    _tracer(3,2,_createElementVNode("h1", null, _toDisplayString($setup.error.statusCode), 1 /* TEXT */)),
    _tracer(4,2,_createElementVNode("p", null, _toDisplayString($setup.error.message), 1 /* TEXT */)),
    _tracer(5,2,_createVNode(_component_NuxtLink, { to: "/" }, {
      default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
        _createTextVNode("Go back home", -1 /* CACHED */)
      ]))]),
      _: 1 /* STABLE */
    }))
  ])))
}


import "/_nuxt/error.vue?vue&type=style&index=0&scoped=f249f6ff&lang.css"

_sfc_main.__hmrId = "f249f6ff"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-f249f6ff"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/error.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/error.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQVNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7O3FCQVZiLEtBQUssRUFBQyxZQUFZOzs7OztvQ0FBdkIsb0JBSU0sT0FKTixVQUlNO2dCQUhMLG9CQUErQiw2QkFBeEIsWUFBSyxDQUFDLFVBQVU7Z0JBQ3ZCLG9CQUEwQiw0QkFBcEIsWUFBSyxDQUFDLE9BQU87Z0JBQ25CLGFBQXdDLHVCQUE5QixFQUFFLEVBQUMsR0FBRzt3QkFBQyxDQUFZO3lCQUFaLGNBQVkiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImVycm9yLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG5cdDxkaXYgY2xhc3M9XCJlcnJvci1wYWdlXCI+XG5cdFx0PGgxPnt7IGVycm9yLnN0YXR1c0NvZGUgfX08L2gxPlxuXHRcdDxwPnt7IGVycm9yLm1lc3NhZ2UgfX08L3A+XG5cdFx0PE51eHRMaW5rIHRvPVwiL1wiPkdvIGJhY2sgaG9tZTwvTnV4dExpbms+XG5cdDwvZGl2PlxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdCBzZXR1cD5cbmNvbnN0IGVycm9yID0gdXNlRXJyb3IoKTtcblxuY29uc29sZS5sb2coXCJhc2RmXCIpO1xuPC9zY3JpcHQ+XG5cbjxzdHlsZSBzY29wZWQ+XG4uZXJyb3ItcGFnZSB7XG5cdHRleHQtYWxpZ246IGNlbnRlcjtcblx0cGFkZGluZzogNHJlbTtcbn1cblxuLmVycm9yLXBhZ2UgaDEge1xuXHRmb250LXNpemU6IDVyZW07XG5cdGNvbG9yOiAjZmY0ZDRmO1xufVxuXG4uZXJyb3ItcGFnZSBwIHtcblx0Zm9udC1zaXplOiAxLjVyZW07XG5cdG1hcmdpbjogMXJlbSAwO1xufVxuXG4uZXJyb3ItcGFnZSBhIHtcblx0Y29sb3I6ICMxODkwZmY7XG5cdHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xufVxuPC9zdHlsZT5cbiJdLCJmaWxlIjoiL21udC9raXJlL1BlcnNvbmFsL1Byb2dyYW1taW5nL1Byb2plY3RzL01FSUMvd2ViL2FwcC9lcnJvci52dWUifQ==