import { __awaiter } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs?v=583078ff";
import { resolveFetch } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+functions-js@2.108.1/node_modules/@supabase/functions-js/dist/module/helper.js?v=583078ff";
import { FunctionRegion, FunctionsFetchError, FunctionsHttpError, FunctionsRelayError, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+functions-js@2.108.1/node_modules/@supabase/functions-js/dist/module/types.js?v=583078ff";
/**
 * Client for invoking Supabase Edge Functions.
 */
export class FunctionsClient {
    /**
     * Creates a new Functions client bound to an Edge Functions URL.
     *
     * @example Using supabase-js (recommended)
     * ```ts
     * import { createClient } from '@supabase/supabase-js'
     *
     * const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
     * const { data, error } = await supabase.functions.invoke('hello-world')
     * ```
     *
     * @category Edge Functions
     *
     * @example Standalone import for bundle-sensitive environments
     * ```ts
     * import { FunctionsClient, FunctionRegion } from '@supabase/functions-js'
     *
     * const functions = new FunctionsClient('https://xyzcompany.supabase.co/functions/v1', {
     *   headers: { apikey: 'your-publishable-key' },
     *   region: FunctionRegion.UsEast1,
     * })
     * ```
     */
    constructor(url, { headers = {}, customFetch, region = FunctionRegion.Any, } = {}) {
        this.url = url;
        this.headers = headers;
        this.region = region;
        this.fetch = resolveFetch(customFetch);
    }
    /**
     * Updates the authorization header
     * @param token - the new jwt token sent in the authorisation header
     *
     * @category Edge Functions
     *
     * @example Setting the authorization header
     * ```ts
     * functions.setAuth(session.access_token)
     * ```
     */
    setAuth(token) {
        this.headers.Authorization = `Bearer ${token}`;
    }
    /**
     * Invokes a function
     * @param functionName - The name of the Function to invoke.
     * @param options - Options for invoking the Function.
     * @example
     * ```ts
     * const { data, error } = await functions.invoke('hello-world', {
     *   body: { name: 'Ada' },
     * })
     * ```
     *
     * @category Edge Functions
     *
     * @remarks
     * - Requires an Authorization header.
     * - Invoke params generally match the [Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API) spec.
     * - When you pass in a body to your function, we automatically attach the Content-Type header for `Blob`, `ArrayBuffer`, `File`, `FormData` and `String`. If it doesn't match any of these types we assume the payload is `json`, serialize it and attach the `Content-Type` header as `application/json`. You can override this behavior by passing in a `Content-Type` header of your own.
     * - Responses are automatically parsed as `json`, `blob` and `form-data` depending on the `Content-Type` header sent by your function. Responses are parsed as `text` by default.
     *
     * @example Basic invocation
     * ```js
     * const { data, error } = await supabase.functions.invoke('hello', {
     *   body: { foo: 'bar' }
     * })
     * ```
     *
     * @exampleDescription Error handling
     * A `FunctionsHttpError` error is returned if your function throws an error, `FunctionsRelayError` if the Supabase Relay has an error processing your function and `FunctionsFetchError` if there is a network error in calling your function. Log the full error object so fields like `name`, `context`, and any structured body aren't hidden.
     *
     * @example Error handling
     * ```js
     * import { FunctionsHttpError, FunctionsRelayError, FunctionsFetchError } from "@supabase/supabase-js";
     *
     * const { data, error } = await supabase.functions.invoke('hello', {
     *   headers: {
     *     "my-custom-header": 'my-custom-header-value'
     *   },
     *   body: { foo: 'bar' }
     * })
     *
     * if (error instanceof FunctionsHttpError) {
     *   const errorMessage = await error.context.json()
     *   console.error('Function returned an error', errorMessage)
     * } else if (error instanceof FunctionsRelayError) {
     *   console.error('Relay error:', error)
     * } else if (error instanceof FunctionsFetchError) {
     *   console.error('Fetch error:', error)
     * }
     * ```
     *
     * @exampleDescription Passing custom headers
     * You can pass custom headers to your function. Note: supabase-js automatically passes the `Authorization` header with the signed in user's JWT.
     *
     * @example Passing custom headers
     * ```js
     * const { data, error } = await supabase.functions.invoke('hello', {
     *   headers: {
     *     "my-custom-header": 'my-custom-header-value'
     *   },
     *   body: { foo: 'bar' }
     * })
     * ```
     *
     * @exampleDescription Calling with DELETE HTTP verb
     * You can also set the HTTP verb to `DELETE` when calling your Edge Function.
     *
     * @example Calling with DELETE HTTP verb
     * ```js
     * const { data, error } = await supabase.functions.invoke('hello', {
     *   headers: {
     *     "my-custom-header": 'my-custom-header-value'
     *   },
     *   body: { foo: 'bar' },
     *   method: 'DELETE'
     * })
     * ```
     *
     * @exampleDescription Invoking a Function in the UsEast1 region
     * Here are the available regions:
     * - `FunctionRegion.Any`
     * - `FunctionRegion.ApNortheast1`
     * - `FunctionRegion.ApNortheast2`
     * - `FunctionRegion.ApSouth1`
     * - `FunctionRegion.ApSoutheast1`
     * - `FunctionRegion.ApSoutheast2`
     * - `FunctionRegion.CaCentral1`
     * - `FunctionRegion.EuCentral1`
     * - `FunctionRegion.EuWest1`
     * - `FunctionRegion.EuWest2`
     * - `FunctionRegion.EuWest3`
     * - `FunctionRegion.SaEast1`
     * - `FunctionRegion.UsEast1`
     * - `FunctionRegion.UsWest1`
     * - `FunctionRegion.UsWest2`
     *
     * @example Invoking a Function in the UsEast1 region
     * ```js
     * import { createClient, FunctionRegion } from '@supabase/supabase-js'
     *
     * const { data, error } = await supabase.functions.invoke('hello', {
     *   body: { foo: 'bar' },
     *   region: FunctionRegion.UsEast1
     * })
     * ```
     *
     * @exampleDescription Calling with GET HTTP verb
     * You can also set the HTTP verb to `GET` when calling your Edge Function.
     *
     * @example Calling with GET HTTP verb
     * ```js
     * const { data, error } = await supabase.functions.invoke('hello', {
     *   headers: {
     *     "my-custom-header": 'my-custom-header-value'
     *   },
     *   method: 'GET'
     * })
     * ```
     *
     * @example Standalone client invoke
     * ```ts
     * const { data, error } = await functions.invoke('hello-world', {
     *   body: { name: 'Ada' },
     * })
     * ```
     */
    invoke(functionName_1) {
        return __awaiter(this, arguments, void 0, function* (functionName, options = {}) {
            var _a;
            let timeoutId;
            let timeoutController;
            try {
                const { headers, method, body: functionArgs, signal, timeout } = options;
                let _headers = {};
                let { region } = options;
                if (!region) {
                    region = this.region;
                }
                // Add region as query parameter using URL API
                const url = new URL(`${this.url}/${functionName}`);
                if (region && region !== 'any') {
                    _headers['x-region'] = region;
                    url.searchParams.set('forceFunctionRegion', region);
                }
                let body;
                if (functionArgs &&
                    ((headers && !Object.prototype.hasOwnProperty.call(headers, 'Content-Type')) || !headers)) {
                    if ((typeof Blob !== 'undefined' && functionArgs instanceof Blob) ||
                        functionArgs instanceof ArrayBuffer) {
                        // will work for File as File inherits Blob
                        // also works for ArrayBuffer as it is the same underlying structure as a Blob
                        _headers['Content-Type'] = 'application/octet-stream';
                        body = functionArgs;
                    }
                    else if (typeof functionArgs === 'string') {
                        // plain string
                        _headers['Content-Type'] = 'text/plain';
                        body = functionArgs;
                    }
                    else if (typeof FormData !== 'undefined' && functionArgs instanceof FormData) {
                        // don't set content-type headers
                        // Request will automatically add the right boundary value
                        body = functionArgs;
                    }
                    else {
                        // default, assume this is JSON
                        _headers['Content-Type'] = 'application/json';
                        body = JSON.stringify(functionArgs);
                    }
                }
                else {
                    if (functionArgs &&
                        typeof functionArgs !== 'string' &&
                        !(typeof Blob !== 'undefined' && functionArgs instanceof Blob) &&
                        !(functionArgs instanceof ArrayBuffer) &&
                        !(typeof FormData !== 'undefined' && functionArgs instanceof FormData)) {
                        body = JSON.stringify(functionArgs);
                    }
                    else {
                        body = functionArgs;
                    }
                }
                // Handle timeout by creating an AbortController
                let effectiveSignal = signal;
                if (timeout) {
                    timeoutController = new AbortController();
                    timeoutId = setTimeout(() => timeoutController.abort(), timeout);
                    // If user provided their own signal, we need to respect both
                    if (signal) {
                        effectiveSignal = timeoutController.signal;
                        // If the user's signal is aborted, abort our timeout controller too
                        signal.addEventListener('abort', () => timeoutController.abort());
                    }
                    else {
                        effectiveSignal = timeoutController.signal;
                    }
                }
                const response = yield this.fetch(url.toString(), {
                    method: method || 'POST',
                    // headers priority is (high to low):
                    // 1. invoke-level headers
                    // 2. client-level headers
                    // 3. default Content-Type header
                    headers: Object.assign(Object.assign(Object.assign({}, _headers), this.headers), headers),
                    body,
                    signal: effectiveSignal,
                }).catch((fetchError) => {
                    throw new FunctionsFetchError(fetchError);
                });
                const isRelayError = response.headers.get('x-relay-error');
                if (isRelayError && isRelayError === 'true') {
                    throw new FunctionsRelayError(response);
                }
                if (!response.ok) {
                    throw new FunctionsHttpError(response);
                }
                let responseType = ((_a = response.headers.get('Content-Type')) !== null && _a !== void 0 ? _a : 'text/plain').split(';')[0].trim();
                let data;
                if (responseType === 'application/json') {
                    data = yield response.json();
                }
                else if (responseType === 'application/octet-stream' ||
                    responseType === 'application/pdf') {
                    data = yield response.blob();
                }
                else if (responseType === 'text/event-stream') {
                    data = response;
                }
                else if (responseType === 'multipart/form-data') {
                    data = yield response.formData();
                }
                else {
                    // default to text
                    data = yield response.text();
                }
                return { data, error: null, response };
            }
            catch (error) {
                return {
                    data: null,
                    error,
                    response: error instanceof FunctionsHttpError || error instanceof FunctionsRelayError
                        ? error.context
                        : undefined,
                };
            }
            finally {
                // Clear the timeout if it was set
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }
            }
        });
    }
}
                                           
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRnVuY3Rpb25zQ2xpZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL0Z1bmN0aW9uc0NsaWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLFVBQVUsQ0FBQTtBQUN2QyxPQUFPLEVBR0wsY0FBYyxFQUNkLG1CQUFtQixFQUNuQixrQkFBa0IsRUFDbEIsbUJBQW1CLEdBRXBCLE1BQU0sU0FBUyxDQUFBO0FBRWhCOztHQUVHO0FBQ0gsTUFBTSxPQUFPLGVBQWU7SUFNMUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FzQkc7SUFDSCxZQUNFLEdBQVcsRUFDWCxFQUNFLE9BQU8sR0FBRyxFQUFFLEVBQ1osV0FBVyxFQUNYLE1BQU0sR0FBRyxjQUFjLENBQUMsR0FBRyxNQUt6QixFQUFFO1FBRU4sSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUE7UUFDZCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQTtRQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQTtRQUNwQixJQUFJLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQTtJQUN4QyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILE9BQU8sQ0FBQyxLQUFhO1FBQ25CLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLFVBQVUsS0FBSyxFQUFFLENBQUE7SUFDaEQsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BNEhHO0lBQ0csTUFBTTs2REFDVixZQUFvQixFQUNwQixVQUFpQyxFQUFFOztZQUVuQyxJQUFJLFNBQW9ELENBQUE7WUFDeEQsSUFBSSxpQkFBOEMsQ0FBQTtZQUVsRCxJQUFJLENBQUM7Z0JBQ0gsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsT0FBTyxDQUFBO2dCQUN4RSxJQUFJLFFBQVEsR0FBMkIsRUFBRSxDQUFBO2dCQUN6QyxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFBO2dCQUN4QixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ1osTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUE7Z0JBQ3RCLENBQUM7Z0JBQ0QsOENBQThDO2dCQUM5QyxNQUFNLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUMsQ0FBQTtnQkFDbEQsSUFBSSxNQUFNLElBQUksTUFBTSxLQUFLLEtBQUssRUFBRSxDQUFDO29CQUMvQixRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsTUFBTSxDQUFBO29CQUM3QixHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxNQUFNLENBQUMsQ0FBQTtnQkFDckQsQ0FBQztnQkFDRCxJQUFJLElBQVMsQ0FBQTtnQkFDYixJQUNFLFlBQVk7b0JBQ1osQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUN6RixDQUFDO29CQUNELElBQ0UsQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksWUFBWSxZQUFZLElBQUksQ0FBQzt3QkFDN0QsWUFBWSxZQUFZLFdBQVcsRUFDbkMsQ0FBQzt3QkFDRCwyQ0FBMkM7d0JBQzNDLDhFQUE4RTt3QkFDOUUsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLDBCQUEwQixDQUFBO3dCQUNyRCxJQUFJLEdBQUcsWUFBWSxDQUFBO29CQUNyQixDQUFDO3lCQUFNLElBQUksT0FBTyxZQUFZLEtBQUssUUFBUSxFQUFFLENBQUM7d0JBQzVDLGVBQWU7d0JBQ2YsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLFlBQVksQ0FBQTt3QkFDdkMsSUFBSSxHQUFHLFlBQVksQ0FBQTtvQkFDckIsQ0FBQzt5QkFBTSxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFBSSxZQUFZLFlBQVksUUFBUSxFQUFFLENBQUM7d0JBQy9FLGlDQUFpQzt3QkFDakMsMERBQTBEO3dCQUMxRCxJQUFJLEdBQUcsWUFBWSxDQUFBO29CQUNyQixDQUFDO3lCQUFNLENBQUM7d0JBQ04sK0JBQStCO3dCQUMvQixRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsa0JBQWtCLENBQUE7d0JBQzdDLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFBO29CQUNyQyxDQUFDO2dCQUNILENBQUM7cUJBQU0sQ0FBQztvQkFDTixJQUNFLFlBQVk7d0JBQ1osT0FBTyxZQUFZLEtBQUssUUFBUTt3QkFDaEMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxLQUFLLFdBQVcsSUFBSSxZQUFZLFlBQVksSUFBSSxDQUFDO3dCQUM5RCxDQUFDLENBQUMsWUFBWSxZQUFZLFdBQVcsQ0FBQzt3QkFDdEMsQ0FBQyxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFBSSxZQUFZLFlBQVksUUFBUSxDQUFDLEVBQ3RFLENBQUM7d0JBQ0QsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUE7b0JBQ3JDLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixJQUFJLEdBQUcsWUFBWSxDQUFBO29CQUNyQixDQUFDO2dCQUNILENBQUM7Z0JBRUQsZ0RBQWdEO2dCQUNoRCxJQUFJLGVBQWUsR0FBRyxNQUFNLENBQUE7Z0JBQzVCLElBQUksT0FBTyxFQUFFLENBQUM7b0JBQ1osaUJBQWlCLEdBQUcsSUFBSSxlQUFlLEVBQUUsQ0FBQTtvQkFDekMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxpQkFBa0IsQ0FBQyxLQUFLLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQTtvQkFFakUsNkRBQTZEO29CQUM3RCxJQUFJLE1BQU0sRUFBRSxDQUFDO3dCQUNYLGVBQWUsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLENBQUE7d0JBQzFDLG9FQUFvRTt3QkFDcEUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxpQkFBa0IsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFBO29CQUNwRSxDQUFDO3lCQUFNLENBQUM7d0JBQ04sZUFBZSxHQUFHLGlCQUFpQixDQUFDLE1BQU0sQ0FBQTtvQkFDNUMsQ0FBQztnQkFDSCxDQUFDO2dCQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLEVBQUU7b0JBQ2hELE1BQU0sRUFBRSxNQUFNLElBQUksTUFBTTtvQkFDeEIscUNBQXFDO29CQUNyQywwQkFBMEI7b0JBQzFCLDBCQUEwQjtvQkFDMUIsaUNBQWlDO29CQUNqQyxPQUFPLGdEQUFPLFFBQVEsR0FBSyxJQUFJLENBQUMsT0FBTyxHQUFLLE9BQU8sQ0FBRTtvQkFDckQsSUFBSTtvQkFDSixNQUFNLEVBQUUsZUFBZTtpQkFDeEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO29CQUN0QixNQUFNLElBQUksbUJBQW1CLENBQUMsVUFBVSxDQUFDLENBQUE7Z0JBQzNDLENBQUMsQ0FBQyxDQUFBO2dCQUVGLE1BQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO2dCQUMxRCxJQUFJLFlBQVksSUFBSSxZQUFZLEtBQUssTUFBTSxFQUFFLENBQUM7b0JBQzVDLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQTtnQkFDekMsQ0FBQztnQkFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDO29CQUNqQixNQUFNLElBQUksa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUE7Z0JBQ3hDLENBQUM7Z0JBRUQsSUFBSSxZQUFZLEdBQUcsQ0FBQyxNQUFBLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxtQ0FBSSxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUE7Z0JBQzlGLElBQUksSUFBUyxDQUFBO2dCQUNiLElBQUksWUFBWSxLQUFLLGtCQUFrQixFQUFFLENBQUM7b0JBQ3hDLElBQUksR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtnQkFDOUIsQ0FBQztxQkFBTSxJQUNMLFlBQVksS0FBSywwQkFBMEI7b0JBQzNDLFlBQVksS0FBSyxpQkFBaUIsRUFDbEMsQ0FBQztvQkFDRCxJQUFJLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUE7Z0JBQzlCLENBQUM7cUJBQU0sSUFBSSxZQUFZLEtBQUssbUJBQW1CLEVBQUUsQ0FBQztvQkFDaEQsSUFBSSxHQUFHLFFBQVEsQ0FBQTtnQkFDakIsQ0FBQztxQkFBTSxJQUFJLFlBQVksS0FBSyxxQkFBcUIsRUFBRSxDQUFDO29CQUNsRCxJQUFJLEdBQUcsTUFBTSxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUE7Z0JBQ2xDLENBQUM7cUJBQU0sQ0FBQztvQkFDTixrQkFBa0I7b0JBQ2xCLElBQUksR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtnQkFDOUIsQ0FBQztnQkFFRCxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUE7WUFDeEMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTztvQkFDTCxJQUFJLEVBQUUsSUFBSTtvQkFDVixLQUFLO29CQUNMLFFBQVEsRUFDTixLQUFLLFlBQVksa0JBQWtCLElBQUksS0FBSyxZQUFZLG1CQUFtQjt3QkFDekUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPO3dCQUNmLENBQUMsQ0FBQyxTQUFTO2lCQUNoQixDQUFBO1lBQ0gsQ0FBQztvQkFBUyxDQUFDO2dCQUNULGtDQUFrQztnQkFDbEMsSUFBSSxTQUFTLEVBQUUsQ0FBQztvQkFDZCxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUE7Z0JBQ3pCLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztLQUFBO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyByZXNvbHZlRmV0Y2ggfSBmcm9tICcuL2hlbHBlcidcbmltcG9ydCB7XG4gIEZldGNoLFxuICBGdW5jdGlvbkludm9rZU9wdGlvbnMsXG4gIEZ1bmN0aW9uUmVnaW9uLFxuICBGdW5jdGlvbnNGZXRjaEVycm9yLFxuICBGdW5jdGlvbnNIdHRwRXJyb3IsXG4gIEZ1bmN0aW9uc1JlbGF5RXJyb3IsXG4gIEZ1bmN0aW9uc1Jlc3BvbnNlLFxufSBmcm9tICcuL3R5cGVzJ1xuXG4vKipcbiAqIENsaWVudCBmb3IgaW52b2tpbmcgU3VwYWJhc2UgRWRnZSBGdW5jdGlvbnMuXG4gKi9cbmV4cG9ydCBjbGFzcyBGdW5jdGlvbnNDbGllbnQge1xuICBwcm90ZWN0ZWQgdXJsOiBzdHJpbmdcbiAgcHJvdGVjdGVkIGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbiAgcHJvdGVjdGVkIHJlZ2lvbjogRnVuY3Rpb25SZWdpb25cbiAgcHJvdGVjdGVkIGZldGNoOiBGZXRjaFxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IEZ1bmN0aW9ucyBjbGllbnQgYm91bmQgdG8gYW4gRWRnZSBGdW5jdGlvbnMgVVJMLlxuICAgKlxuICAgKiBAZXhhbXBsZSBVc2luZyBzdXBhYmFzZS1qcyAocmVjb21tZW5kZWQpXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcydcbiAgICpcbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jbycsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScpXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZ1bmN0aW9ucy5pbnZva2UoJ2hlbGxvLXdvcmxkJylcbiAgICogYGBgXG4gICAqXG4gICAqIEBjYXRlZ29yeSBFZGdlIEZ1bmN0aW9uc1xuICAgKlxuICAgKiBAZXhhbXBsZSBTdGFuZGFsb25lIGltcG9ydCBmb3IgYnVuZGxlLXNlbnNpdGl2ZSBlbnZpcm9ubWVudHNcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgRnVuY3Rpb25zQ2xpZW50LCBGdW5jdGlvblJlZ2lvbiB9IGZyb20gJ0BzdXBhYmFzZS9mdW5jdGlvbnMtanMnXG4gICAqXG4gICAqIGNvbnN0IGZ1bmN0aW9ucyA9IG5ldyBGdW5jdGlvbnNDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jby9mdW5jdGlvbnMvdjEnLCB7XG4gICAqICAgaGVhZGVyczogeyBhcGlrZXk6ICd5b3VyLXB1Ymxpc2hhYmxlLWtleScgfSxcbiAgICogICByZWdpb246IEZ1bmN0aW9uUmVnaW9uLlVzRWFzdDEsXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgY29uc3RydWN0b3IoXG4gICAgdXJsOiBzdHJpbmcsXG4gICAge1xuICAgICAgaGVhZGVycyA9IHt9LFxuICAgICAgY3VzdG9tRmV0Y2gsXG4gICAgICByZWdpb24gPSBGdW5jdGlvblJlZ2lvbi5BbnksXG4gICAgfToge1xuICAgICAgaGVhZGVycz86IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbiAgICAgIGN1c3RvbUZldGNoPzogRmV0Y2hcbiAgICAgIHJlZ2lvbj86IEZ1bmN0aW9uUmVnaW9uXG4gICAgfSA9IHt9XG4gICkge1xuICAgIHRoaXMudXJsID0gdXJsXG4gICAgdGhpcy5oZWFkZXJzID0gaGVhZGVyc1xuICAgIHRoaXMucmVnaW9uID0gcmVnaW9uXG4gICAgdGhpcy5mZXRjaCA9IHJlc29sdmVGZXRjaChjdXN0b21GZXRjaClcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGVzIHRoZSBhdXRob3JpemF0aW9uIGhlYWRlclxuICAgKiBAcGFyYW0gdG9rZW4gLSB0aGUgbmV3IGp3dCB0b2tlbiBzZW50IGluIHRoZSBhdXRob3Jpc2F0aW9uIGhlYWRlclxuICAgKlxuICAgKiBAY2F0ZWdvcnkgRWRnZSBGdW5jdGlvbnNcbiAgICpcbiAgICogQGV4YW1wbGUgU2V0dGluZyB0aGUgYXV0aG9yaXphdGlvbiBoZWFkZXJcbiAgICogYGBgdHNcbiAgICogZnVuY3Rpb25zLnNldEF1dGgoc2Vzc2lvbi5hY2Nlc3NfdG9rZW4pXG4gICAqIGBgYFxuICAgKi9cbiAgc2V0QXV0aCh0b2tlbjogc3RyaW5nKSB7XG4gICAgdGhpcy5oZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7dG9rZW59YFxuICB9XG5cbiAgLyoqXG4gICAqIEludm9rZXMgYSBmdW5jdGlvblxuICAgKiBAcGFyYW0gZnVuY3Rpb25OYW1lIC0gVGhlIG5hbWUgb2YgdGhlIEZ1bmN0aW9uIHRvIGludm9rZS5cbiAgICogQHBhcmFtIG9wdGlvbnMgLSBPcHRpb25zIGZvciBpbnZva2luZyB0aGUgRnVuY3Rpb24uXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGZ1bmN0aW9ucy5pbnZva2UoJ2hlbGxvLXdvcmxkJywge1xuICAgKiAgIGJvZHk6IHsgbmFtZTogJ0FkYScgfSxcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBjYXRlZ29yeSBFZGdlIEZ1bmN0aW9uc1xuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFJlcXVpcmVzIGFuIEF1dGhvcml6YXRpb24gaGVhZGVyLlxuICAgKiAtIEludm9rZSBwYXJhbXMgZ2VuZXJhbGx5IG1hdGNoIHRoZSBbRmV0Y2ggQVBJXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvRmV0Y2hfQVBJKSBzcGVjLlxuICAgKiAtIFdoZW4geW91IHBhc3MgaW4gYSBib2R5IHRvIHlvdXIgZnVuY3Rpb24sIHdlIGF1dG9tYXRpY2FsbHkgYXR0YWNoIHRoZSBDb250ZW50LVR5cGUgaGVhZGVyIGZvciBgQmxvYmAsIGBBcnJheUJ1ZmZlcmAsIGBGaWxlYCwgYEZvcm1EYXRhYCBhbmQgYFN0cmluZ2AuIElmIGl0IGRvZXNuJ3QgbWF0Y2ggYW55IG9mIHRoZXNlIHR5cGVzIHdlIGFzc3VtZSB0aGUgcGF5bG9hZCBpcyBganNvbmAsIHNlcmlhbGl6ZSBpdCBhbmQgYXR0YWNoIHRoZSBgQ29udGVudC1UeXBlYCBoZWFkZXIgYXMgYGFwcGxpY2F0aW9uL2pzb25gLiBZb3UgY2FuIG92ZXJyaWRlIHRoaXMgYmVoYXZpb3IgYnkgcGFzc2luZyBpbiBhIGBDb250ZW50LVR5cGVgIGhlYWRlciBvZiB5b3VyIG93bi5cbiAgICogLSBSZXNwb25zZXMgYXJlIGF1dG9tYXRpY2FsbHkgcGFyc2VkIGFzIGBqc29uYCwgYGJsb2JgIGFuZCBgZm9ybS1kYXRhYCBkZXBlbmRpbmcgb24gdGhlIGBDb250ZW50LVR5cGVgIGhlYWRlciBzZW50IGJ5IHlvdXIgZnVuY3Rpb24uIFJlc3BvbnNlcyBhcmUgcGFyc2VkIGFzIGB0ZXh0YCBieSBkZWZhdWx0LlxuICAgKlxuICAgKiBAZXhhbXBsZSBCYXNpYyBpbnZvY2F0aW9uXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZ1bmN0aW9ucy5pbnZva2UoJ2hlbGxvJywge1xuICAgKiAgIGJvZHk6IHsgZm9vOiAnYmFyJyB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIEVycm9yIGhhbmRsaW5nXG4gICAqIEEgYEZ1bmN0aW9uc0h0dHBFcnJvcmAgZXJyb3IgaXMgcmV0dXJuZWQgaWYgeW91ciBmdW5jdGlvbiB0aHJvd3MgYW4gZXJyb3IsIGBGdW5jdGlvbnNSZWxheUVycm9yYCBpZiB0aGUgU3VwYWJhc2UgUmVsYXkgaGFzIGFuIGVycm9yIHByb2Nlc3NpbmcgeW91ciBmdW5jdGlvbiBhbmQgYEZ1bmN0aW9uc0ZldGNoRXJyb3JgIGlmIHRoZXJlIGlzIGEgbmV0d29yayBlcnJvciBpbiBjYWxsaW5nIHlvdXIgZnVuY3Rpb24uIExvZyB0aGUgZnVsbCBlcnJvciBvYmplY3Qgc28gZmllbGRzIGxpa2UgYG5hbWVgLCBgY29udGV4dGAsIGFuZCBhbnkgc3RydWN0dXJlZCBib2R5IGFyZW4ndCBoaWRkZW4uXG4gICAqXG4gICAqIEBleGFtcGxlIEVycm9yIGhhbmRsaW5nXG4gICAqIGBgYGpzXG4gICAqIGltcG9ydCB7IEZ1bmN0aW9uc0h0dHBFcnJvciwgRnVuY3Rpb25zUmVsYXlFcnJvciwgRnVuY3Rpb25zRmV0Y2hFcnJvciB9IGZyb20gXCJAc3VwYWJhc2Uvc3VwYWJhc2UtanNcIjtcbiAgICpcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnVuY3Rpb25zLmludm9rZSgnaGVsbG8nLCB7XG4gICAqICAgaGVhZGVyczoge1xuICAgKiAgICAgXCJteS1jdXN0b20taGVhZGVyXCI6ICdteS1jdXN0b20taGVhZGVyLXZhbHVlJ1xuICAgKiAgIH0sXG4gICAqICAgYm9keTogeyBmb286ICdiYXInIH1cbiAgICogfSlcbiAgICpcbiAgICogaWYgKGVycm9yIGluc3RhbmNlb2YgRnVuY3Rpb25zSHR0cEVycm9yKSB7XG4gICAqICAgY29uc3QgZXJyb3JNZXNzYWdlID0gYXdhaXQgZXJyb3IuY29udGV4dC5qc29uKClcbiAgICogICBjb25zb2xlLmVycm9yKCdGdW5jdGlvbiByZXR1cm5lZCBhbiBlcnJvcicsIGVycm9yTWVzc2FnZSlcbiAgICogfSBlbHNlIGlmIChlcnJvciBpbnN0YW5jZW9mIEZ1bmN0aW9uc1JlbGF5RXJyb3IpIHtcbiAgICogICBjb25zb2xlLmVycm9yKCdSZWxheSBlcnJvcjonLCBlcnJvcilcbiAgICogfSBlbHNlIGlmIChlcnJvciBpbnN0YW5jZW9mIEZ1bmN0aW9uc0ZldGNoRXJyb3IpIHtcbiAgICogICBjb25zb2xlLmVycm9yKCdGZXRjaCBlcnJvcjonLCBlcnJvcilcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBQYXNzaW5nIGN1c3RvbSBoZWFkZXJzXG4gICAqIFlvdSBjYW4gcGFzcyBjdXN0b20gaGVhZGVycyB0byB5b3VyIGZ1bmN0aW9uLiBOb3RlOiBzdXBhYmFzZS1qcyBhdXRvbWF0aWNhbGx5IHBhc3NlcyB0aGUgYEF1dGhvcml6YXRpb25gIGhlYWRlciB3aXRoIHRoZSBzaWduZWQgaW4gdXNlcidzIEpXVC5cbiAgICpcbiAgICogQGV4YW1wbGUgUGFzc2luZyBjdXN0b20gaGVhZGVyc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mdW5jdGlvbnMuaW52b2tlKCdoZWxsbycsIHtcbiAgICogICBoZWFkZXJzOiB7XG4gICAqICAgICBcIm15LWN1c3RvbS1oZWFkZXJcIjogJ215LWN1c3RvbS1oZWFkZXItdmFsdWUnXG4gICAqICAgfSxcbiAgICogICBib2R5OiB7IGZvbzogJ2JhcicgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBDYWxsaW5nIHdpdGggREVMRVRFIEhUVFAgdmVyYlxuICAgKiBZb3UgY2FuIGFsc28gc2V0IHRoZSBIVFRQIHZlcmIgdG8gYERFTEVURWAgd2hlbiBjYWxsaW5nIHlvdXIgRWRnZSBGdW5jdGlvbi5cbiAgICpcbiAgICogQGV4YW1wbGUgQ2FsbGluZyB3aXRoIERFTEVURSBIVFRQIHZlcmJcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnVuY3Rpb25zLmludm9rZSgnaGVsbG8nLCB7XG4gICAqICAgaGVhZGVyczoge1xuICAgKiAgICAgXCJteS1jdXN0b20taGVhZGVyXCI6ICdteS1jdXN0b20taGVhZGVyLXZhbHVlJ1xuICAgKiAgIH0sXG4gICAqICAgYm9keTogeyBmb286ICdiYXInIH0sXG4gICAqICAgbWV0aG9kOiAnREVMRVRFJ1xuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVEZXNjcmlwdGlvbiBJbnZva2luZyBhIEZ1bmN0aW9uIGluIHRoZSBVc0Vhc3QxIHJlZ2lvblxuICAgKiBIZXJlIGFyZSB0aGUgYXZhaWxhYmxlIHJlZ2lvbnM6XG4gICAqIC0gYEZ1bmN0aW9uUmVnaW9uLkFueWBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uQXBOb3J0aGVhc3QxYFxuICAgKiAtIGBGdW5jdGlvblJlZ2lvbi5BcE5vcnRoZWFzdDJgXG4gICAqIC0gYEZ1bmN0aW9uUmVnaW9uLkFwU291dGgxYFxuICAgKiAtIGBGdW5jdGlvblJlZ2lvbi5BcFNvdXRoZWFzdDFgXG4gICAqIC0gYEZ1bmN0aW9uUmVnaW9uLkFwU291dGhlYXN0MmBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uQ2FDZW50cmFsMWBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uRXVDZW50cmFsMWBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uRXVXZXN0MWBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uRXVXZXN0MmBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uRXVXZXN0M2BcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uU2FFYXN0MWBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uVXNFYXN0MWBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uVXNXZXN0MWBcbiAgICogLSBgRnVuY3Rpb25SZWdpb24uVXNXZXN0MmBcbiAgICpcbiAgICogQGV4YW1wbGUgSW52b2tpbmcgYSBGdW5jdGlvbiBpbiB0aGUgVXNFYXN0MSByZWdpb25cbiAgICogYGBganNcbiAgICogaW1wb3J0IHsgY3JlYXRlQ2xpZW50LCBGdW5jdGlvblJlZ2lvbiB9IGZyb20gJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcydcbiAgICpcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnVuY3Rpb25zLmludm9rZSgnaGVsbG8nLCB7XG4gICAqICAgYm9keTogeyBmb286ICdiYXInIH0sXG4gICAqICAgcmVnaW9uOiBGdW5jdGlvblJlZ2lvbi5Vc0Vhc3QxXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZURlc2NyaXB0aW9uIENhbGxpbmcgd2l0aCBHRVQgSFRUUCB2ZXJiXG4gICAqIFlvdSBjYW4gYWxzbyBzZXQgdGhlIEhUVFAgdmVyYiB0byBgR0VUYCB3aGVuIGNhbGxpbmcgeW91ciBFZGdlIEZ1bmN0aW9uLlxuICAgKlxuICAgKiBAZXhhbXBsZSBDYWxsaW5nIHdpdGggR0VUIEhUVFAgdmVyYlxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mdW5jdGlvbnMuaW52b2tlKCdoZWxsbycsIHtcbiAgICogICBoZWFkZXJzOiB7XG4gICAqICAgICBcIm15LWN1c3RvbS1oZWFkZXJcIjogJ215LWN1c3RvbS1oZWFkZXItdmFsdWUnXG4gICAqICAgfSxcbiAgICogICBtZXRob2Q6ICdHRVQnXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTdGFuZGFsb25lIGNsaWVudCBpbnZva2VcbiAgICogYGBgdHNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgZnVuY3Rpb25zLmludm9rZSgnaGVsbG8td29ybGQnLCB7XG4gICAqICAgYm9keTogeyBuYW1lOiAnQWRhJyB9LFxuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGludm9rZTxUID0gYW55PihcbiAgICBmdW5jdGlvbk5hbWU6IHN0cmluZyxcbiAgICBvcHRpb25zOiBGdW5jdGlvbkludm9rZU9wdGlvbnMgPSB7fVxuICApOiBQcm9taXNlPEZ1bmN0aW9uc1Jlc3BvbnNlPFQ+PiB7XG4gICAgbGV0IHRpbWVvdXRJZDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCB1bmRlZmluZWRcbiAgICBsZXQgdGltZW91dENvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlciB8IHVuZGVmaW5lZFxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaGVhZGVycywgbWV0aG9kLCBib2R5OiBmdW5jdGlvbkFyZ3MsIHNpZ25hbCwgdGltZW91dCB9ID0gb3B0aW9uc1xuICAgICAgbGV0IF9oZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge31cbiAgICAgIGxldCB7IHJlZ2lvbiB9ID0gb3B0aW9uc1xuICAgICAgaWYgKCFyZWdpb24pIHtcbiAgICAgICAgcmVnaW9uID0gdGhpcy5yZWdpb25cbiAgICAgIH1cbiAgICAgIC8vIEFkZCByZWdpb24gYXMgcXVlcnkgcGFyYW1ldGVyIHVzaW5nIFVSTCBBUElcbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoYCR7dGhpcy51cmx9LyR7ZnVuY3Rpb25OYW1lfWApXG4gICAgICBpZiAocmVnaW9uICYmIHJlZ2lvbiAhPT0gJ2FueScpIHtcbiAgICAgICAgX2hlYWRlcnNbJ3gtcmVnaW9uJ10gPSByZWdpb25cbiAgICAgICAgdXJsLnNlYXJjaFBhcmFtcy5zZXQoJ2ZvcmNlRnVuY3Rpb25SZWdpb24nLCByZWdpb24pXG4gICAgICB9XG4gICAgICBsZXQgYm9keTogYW55XG4gICAgICBpZiAoXG4gICAgICAgIGZ1bmN0aW9uQXJncyAmJlxuICAgICAgICAoKGhlYWRlcnMgJiYgIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChoZWFkZXJzLCAnQ29udGVudC1UeXBlJykpIHx8ICFoZWFkZXJzKVxuICAgICAgKSB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICAodHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnICYmIGZ1bmN0aW9uQXJncyBpbnN0YW5jZW9mIEJsb2IpIHx8XG4gICAgICAgICAgZnVuY3Rpb25BcmdzIGluc3RhbmNlb2YgQXJyYXlCdWZmZXJcbiAgICAgICAgKSB7XG4gICAgICAgICAgLy8gd2lsbCB3b3JrIGZvciBGaWxlIGFzIEZpbGUgaW5oZXJpdHMgQmxvYlxuICAgICAgICAgIC8vIGFsc28gd29ya3MgZm9yIEFycmF5QnVmZmVyIGFzIGl0IGlzIHRoZSBzYW1lIHVuZGVybHlpbmcgc3RydWN0dXJlIGFzIGEgQmxvYlxuICAgICAgICAgIF9oZWFkZXJzWydDb250ZW50LVR5cGUnXSA9ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nXG4gICAgICAgICAgYm9keSA9IGZ1bmN0aW9uQXJnc1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBmdW5jdGlvbkFyZ3MgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgLy8gcGxhaW4gc3RyaW5nXG4gICAgICAgICAgX2hlYWRlcnNbJ0NvbnRlbnQtVHlwZSddID0gJ3RleHQvcGxhaW4nXG4gICAgICAgICAgYm9keSA9IGZ1bmN0aW9uQXJnc1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBGb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiYgZnVuY3Rpb25BcmdzIGluc3RhbmNlb2YgRm9ybURhdGEpIHtcbiAgICAgICAgICAvLyBkb24ndCBzZXQgY29udGVudC10eXBlIGhlYWRlcnNcbiAgICAgICAgICAvLyBSZXF1ZXN0IHdpbGwgYXV0b21hdGljYWxseSBhZGQgdGhlIHJpZ2h0IGJvdW5kYXJ5IHZhbHVlXG4gICAgICAgICAgYm9keSA9IGZ1bmN0aW9uQXJnc1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIGRlZmF1bHQsIGFzc3VtZSB0aGlzIGlzIEpTT05cbiAgICAgICAgICBfaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSAnYXBwbGljYXRpb24vanNvbidcbiAgICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkoZnVuY3Rpb25BcmdzKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgZnVuY3Rpb25BcmdzICYmXG4gICAgICAgICAgdHlwZW9mIGZ1bmN0aW9uQXJncyAhPT0gJ3N0cmluZycgJiZcbiAgICAgICAgICAhKHR5cGVvZiBCbG9iICE9PSAndW5kZWZpbmVkJyAmJiBmdW5jdGlvbkFyZ3MgaW5zdGFuY2VvZiBCbG9iKSAmJlxuICAgICAgICAgICEoZnVuY3Rpb25BcmdzIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpICYmXG4gICAgICAgICAgISh0eXBlb2YgRm9ybURhdGEgIT09ICd1bmRlZmluZWQnICYmIGZ1bmN0aW9uQXJncyBpbnN0YW5jZW9mIEZvcm1EYXRhKVxuICAgICAgICApIHtcbiAgICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkoZnVuY3Rpb25BcmdzKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGJvZHkgPSBmdW5jdGlvbkFyZ3NcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBIYW5kbGUgdGltZW91dCBieSBjcmVhdGluZyBhbiBBYm9ydENvbnRyb2xsZXJcbiAgICAgIGxldCBlZmZlY3RpdmVTaWduYWwgPSBzaWduYWxcbiAgICAgIGlmICh0aW1lb3V0KSB7XG4gICAgICAgIHRpbWVvdXRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXG4gICAgICAgIHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gdGltZW91dENvbnRyb2xsZXIhLmFib3J0KCksIHRpbWVvdXQpXG5cbiAgICAgICAgLy8gSWYgdXNlciBwcm92aWRlZCB0aGVpciBvd24gc2lnbmFsLCB3ZSBuZWVkIHRvIHJlc3BlY3QgYm90aFxuICAgICAgICBpZiAoc2lnbmFsKSB7XG4gICAgICAgICAgZWZmZWN0aXZlU2lnbmFsID0gdGltZW91dENvbnRyb2xsZXIuc2lnbmFsXG4gICAgICAgICAgLy8gSWYgdGhlIHVzZXIncyBzaWduYWwgaXMgYWJvcnRlZCwgYWJvcnQgb3VyIHRpbWVvdXQgY29udHJvbGxlciB0b29cbiAgICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiB0aW1lb3V0Q29udHJvbGxlciEuYWJvcnQoKSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBlZmZlY3RpdmVTaWduYWwgPSB0aW1lb3V0Q29udHJvbGxlci5zaWduYWxcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuZmV0Y2godXJsLnRvU3RyaW5nKCksIHtcbiAgICAgICAgbWV0aG9kOiBtZXRob2QgfHwgJ1BPU1QnLFxuICAgICAgICAvLyBoZWFkZXJzIHByaW9yaXR5IGlzIChoaWdoIHRvIGxvdyk6XG4gICAgICAgIC8vIDEuIGludm9rZS1sZXZlbCBoZWFkZXJzXG4gICAgICAgIC8vIDIuIGNsaWVudC1sZXZlbCBoZWFkZXJzXG4gICAgICAgIC8vIDMuIGRlZmF1bHQgQ29udGVudC1UeXBlIGhlYWRlclxuICAgICAgICBoZWFkZXJzOiB7IC4uLl9oZWFkZXJzLCAuLi50aGlzLmhlYWRlcnMsIC4uLmhlYWRlcnMgfSxcbiAgICAgICAgYm9keSxcbiAgICAgICAgc2lnbmFsOiBlZmZlY3RpdmVTaWduYWwsXG4gICAgICB9KS5jYXRjaCgoZmV0Y2hFcnJvcikgPT4ge1xuICAgICAgICB0aHJvdyBuZXcgRnVuY3Rpb25zRmV0Y2hFcnJvcihmZXRjaEVycm9yKVxuICAgICAgfSlcblxuICAgICAgY29uc3QgaXNSZWxheUVycm9yID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ3gtcmVsYXktZXJyb3InKVxuICAgICAgaWYgKGlzUmVsYXlFcnJvciAmJiBpc1JlbGF5RXJyb3IgPT09ICd0cnVlJykge1xuICAgICAgICB0aHJvdyBuZXcgRnVuY3Rpb25zUmVsYXlFcnJvcihyZXNwb25zZSlcbiAgICAgIH1cblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgRnVuY3Rpb25zSHR0cEVycm9yKHJlc3BvbnNlKVxuICAgICAgfVxuXG4gICAgICBsZXQgcmVzcG9uc2VUeXBlID0gKHJlc3BvbnNlLmhlYWRlcnMuZ2V0KCdDb250ZW50LVR5cGUnKSA/PyAndGV4dC9wbGFpbicpLnNwbGl0KCc7JylbMF0udHJpbSgpXG4gICAgICBsZXQgZGF0YTogYW55XG4gICAgICBpZiAocmVzcG9uc2VUeXBlID09PSAnYXBwbGljYXRpb24vanNvbicpIHtcbiAgICAgICAgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKVxuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgcmVzcG9uc2VUeXBlID09PSAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJyB8fFxuICAgICAgICByZXNwb25zZVR5cGUgPT09ICdhcHBsaWNhdGlvbi9wZGYnXG4gICAgICApIHtcbiAgICAgICAgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmJsb2IoKVxuICAgICAgfSBlbHNlIGlmIChyZXNwb25zZVR5cGUgPT09ICd0ZXh0L2V2ZW50LXN0cmVhbScpIHtcbiAgICAgICAgZGF0YSA9IHJlc3BvbnNlXG4gICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlVHlwZSA9PT0gJ211bHRpcGFydC9mb3JtLWRhdGEnKSB7XG4gICAgICAgIGRhdGEgPSBhd2FpdCByZXNwb25zZS5mb3JtRGF0YSgpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBkZWZhdWx0IHRvIHRleHRcbiAgICAgICAgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4geyBkYXRhLCBlcnJvcjogbnVsbCwgcmVzcG9uc2UgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBkYXRhOiBudWxsLFxuICAgICAgICBlcnJvcixcbiAgICAgICAgcmVzcG9uc2U6XG4gICAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBGdW5jdGlvbnNIdHRwRXJyb3IgfHwgZXJyb3IgaW5zdGFuY2VvZiBGdW5jdGlvbnNSZWxheUVycm9yXG4gICAgICAgICAgICA/IGVycm9yLmNvbnRleHRcbiAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICAvLyBDbGVhciB0aGUgdGltZW91dCBpZiBpdCB3YXMgc2V0XG4gICAgICBpZiAodGltZW91dElkKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpXG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==