import __vite__cjsImport0_cookie from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.cache/vite/client/deps/@nuxtjs_supabase___@supabase_ssr___cookie.js?v=1219a004"; const cookie = ((m) => m?.__esModule ? m : {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m})(__vite__cjsImport0_cookie);
/**
 * @deprecated Since v0.4.0: Please use {@link parseCookieHeader}. `parse` will
 * not be available for import starting v1.0.0 of `@supabase/ssr`.
 */
export const parse = cookie.parse;
/**
 * @deprecated Since v0.4.0: Please use {@link serializeCookieHeader}.
 * `serialize` will not be available for import starting v1.0.0 of
 * `@supabase/ssr`.
 */
export const serialize = cookie.serialize;
/**
 * Parses the `Cookie` HTTP header into an array of cookie name-value objects.
 *
 * @param header The `Cookie` HTTP header. Decodes cookie names and values from
 * URI encoding first.
 */
export function parseCookieHeader(header) {
    const parsed = cookie.parse(header);
    return Object.keys(parsed ?? {}).map((name) => ({
        name,
        value: parsed[name],
    }));
}
/**
 * Converts the arguments to a valid `Set-Cookie` header. Non US-ASCII chars
 * and other forbidden cookie chars will be URI encoded.
 *
 * @param name Name of cookie.
 * @param value Value of cookie.
 */
export function serializeCookieHeader(name, value, options) {
    return cookie.serialize(name, value, options);
}
export function isBrowser() {
    return (typeof window !== "undefined" && typeof window.document !== "undefined");
}
/**
 * Returns a localStorage-like object that stores the key-value pairs in
 * memory.
 */
export function memoryLocalStorageAdapter(store = {}) {
    return {
        getItem: (key) => {
            return store[key] || null;
        },
        setItem: (key, value) => {
            store[key] = value;
        },
        removeItem: (key) => {
            delete store[key];
        },
    };
}
                                   
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy91dGlscy9oZWxwZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sS0FBSyxNQUFNLE1BQU0sUUFBUSxDQUFDO0FBRWpDOzs7R0FHRztBQUNILE1BQU0sQ0FBQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBRWxDOzs7O0dBSUc7QUFDSCxNQUFNLENBQUMsTUFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztBQUUxQzs7Ozs7R0FLRztBQUNILE1BQU0sVUFBVSxpQkFBaUIsQ0FDL0IsTUFBYztJQUVkLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFcEMsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDOUMsSUFBSTtRQUNKLEtBQUssRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDO0tBQ3BCLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUVEOzs7Ozs7R0FNRztBQUNILE1BQU0sVUFBVSxxQkFBcUIsQ0FDbkMsSUFBWSxFQUNaLEtBQWEsRUFDYixPQUF5QjtJQUV6QixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztBQUNoRCxDQUFDO0FBRUQsTUFBTSxVQUFVLFNBQVM7SUFDdkIsT0FBTyxDQUNMLE9BQU8sTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUN4RSxDQUFDO0FBQ0osQ0FBQztBQUVEOzs7R0FHRztBQUNILE1BQU0sVUFBVSx5QkFBeUIsQ0FDdkMsUUFBbUMsRUFBRTtJQUVyQyxPQUFPO1FBQ0wsT0FBTyxFQUFFLENBQUMsR0FBVyxFQUFFLEVBQUU7WUFDdkIsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDO1FBQzVCLENBQUM7UUFFRCxPQUFPLEVBQUUsQ0FBQyxHQUFXLEVBQUUsS0FBYSxFQUFFLEVBQUU7WUFDdEMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUNyQixDQUFDO1FBRUQsVUFBVSxFQUFFLENBQUMsR0FBVyxFQUFFLEVBQUU7WUFDMUIsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEIsQ0FBQztLQUNGLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBTZXJpYWxpemVPcHRpb25zIH0gZnJvbSBcImNvb2tpZVwiO1xuaW1wb3J0ICogYXMgY29va2llIGZyb20gXCJjb29raWVcIjtcblxuLyoqXG4gKiBAZGVwcmVjYXRlZCBTaW5jZSB2MC40LjA6IFBsZWFzZSB1c2Uge0BsaW5rIHBhcnNlQ29va2llSGVhZGVyfS4gYHBhcnNlYCB3aWxsXG4gKiBub3QgYmUgYXZhaWxhYmxlIGZvciBpbXBvcnQgc3RhcnRpbmcgdjEuMC4wIG9mIGBAc3VwYWJhc2Uvc3NyYC5cbiAqL1xuZXhwb3J0IGNvbnN0IHBhcnNlID0gY29va2llLnBhcnNlO1xuXG4vKipcbiAqIEBkZXByZWNhdGVkIFNpbmNlIHYwLjQuMDogUGxlYXNlIHVzZSB7QGxpbmsgc2VyaWFsaXplQ29va2llSGVhZGVyfS5cbiAqIGBzZXJpYWxpemVgIHdpbGwgbm90IGJlIGF2YWlsYWJsZSBmb3IgaW1wb3J0IHN0YXJ0aW5nIHYxLjAuMCBvZlxuICogYEBzdXBhYmFzZS9zc3JgLlxuICovXG5leHBvcnQgY29uc3Qgc2VyaWFsaXplID0gY29va2llLnNlcmlhbGl6ZTtcblxuLyoqXG4gKiBQYXJzZXMgdGhlIGBDb29raWVgIEhUVFAgaGVhZGVyIGludG8gYW4gYXJyYXkgb2YgY29va2llIG5hbWUtdmFsdWUgb2JqZWN0cy5cbiAqXG4gKiBAcGFyYW0gaGVhZGVyIFRoZSBgQ29va2llYCBIVFRQIGhlYWRlci4gRGVjb2RlcyBjb29raWUgbmFtZXMgYW5kIHZhbHVlcyBmcm9tXG4gKiBVUkkgZW5jb2RpbmcgZmlyc3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUNvb2tpZUhlYWRlcihcbiAgaGVhZGVyOiBzdHJpbmcsXG4pOiB7IG5hbWU6IHN0cmluZzsgdmFsdWU/OiBzdHJpbmcgfVtdIHtcbiAgY29uc3QgcGFyc2VkID0gY29va2llLnBhcnNlKGhlYWRlcik7XG5cbiAgcmV0dXJuIE9iamVjdC5rZXlzKHBhcnNlZCA/PyB7fSkubWFwKChuYW1lKSA9PiAoe1xuICAgIG5hbWUsXG4gICAgdmFsdWU6IHBhcnNlZFtuYW1lXSxcbiAgfSkpO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIHRoZSBhcmd1bWVudHMgdG8gYSB2YWxpZCBgU2V0LUNvb2tpZWAgaGVhZGVyLiBOb24gVVMtQVNDSUkgY2hhcnNcbiAqIGFuZCBvdGhlciBmb3JiaWRkZW4gY29va2llIGNoYXJzIHdpbGwgYmUgVVJJIGVuY29kZWQuXG4gKlxuICogQHBhcmFtIG5hbWUgTmFtZSBvZiBjb29raWUuXG4gKiBAcGFyYW0gdmFsdWUgVmFsdWUgb2YgY29va2llLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplQ29va2llSGVhZGVyKFxuICBuYW1lOiBzdHJpbmcsXG4gIHZhbHVlOiBzdHJpbmcsXG4gIG9wdGlvbnM6IFNlcmlhbGl6ZU9wdGlvbnMsXG4pOiBzdHJpbmcge1xuICByZXR1cm4gY29va2llLnNlcmlhbGl6ZShuYW1lLCB2YWx1ZSwgb3B0aW9ucyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0Jyb3dzZXIoKSB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB0eXBlb2Ygd2luZG93LmRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiXG4gICk7XG59XG5cbi8qKlxuICogUmV0dXJucyBhIGxvY2FsU3RvcmFnZS1saWtlIG9iamVjdCB0aGF0IHN0b3JlcyB0aGUga2V5LXZhbHVlIHBhaXJzIGluXG4gKiBtZW1vcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtZW1vcnlMb2NhbFN0b3JhZ2VBZGFwdGVyKFxuICBzdG9yZTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9LFxuKSB7XG4gIHJldHVybiB7XG4gICAgZ2V0SXRlbTogKGtleTogc3RyaW5nKSA9PiB7XG4gICAgICByZXR1cm4gc3RvcmVba2V5XSB8fCBudWxsO1xuICAgIH0sXG5cbiAgICBzZXRJdGVtOiAoa2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICAgIHN0b3JlW2tleV0gPSB2YWx1ZTtcbiAgICB9LFxuXG4gICAgcmVtb3ZlSXRlbTogKGtleTogc3RyaW5nKSA9PiB7XG4gICAgICBkZWxldGUgc3RvcmVba2V5XTtcbiAgICB9LFxuICB9O1xufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=