import { __rest } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs?v=583078ff";
import { base64UrlToUint8Array, bytesToBase64URL } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/base64url.js?v=583078ff";
import { AuthError, AuthUnknownError, isAuthError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/errors.js?v=583078ff";
import { isBrowser } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/helpers.js?v=583078ff";
import { identifyAuthenticationError, identifyRegistrationError, isWebAuthnError, WebAuthnError, WebAuthnUnknownError, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/webauthn.errors.js?v=583078ff";
export { WebAuthnError, isWebAuthnError, identifyRegistrationError, identifyAuthenticationError };
/**
 * WebAuthn abort service to manage ceremony cancellation.
 * Ensures only one WebAuthn ceremony is active at a time to prevent "operation already in progress" errors.
 *
 * @experimental This class is experimental and may change in future releases
 * @see {@link https://w3c.github.io/webauthn/#sctn-automation-webdriver-capability W3C WebAuthn Spec - Aborting Ceremonies}
 */
export class WebAuthnAbortService {
    /**
     * Create an abort signal for a new WebAuthn operation.
     * Automatically cancels any existing operation.
     *
     * @returns {AbortSignal} Signal to pass to navigator.credentials.create() or .get()
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal MDN - AbortSignal}
     */
    createNewAbortSignal() {
        // Abort any existing calls to navigator.credentials.create() or navigator.credentials.get()
        if (this.controller) {
            const abortError = new Error('Cancelling existing WebAuthn API call for new one');
            abortError.name = 'AbortError';
            this.controller.abort(abortError);
        }
        const newController = new AbortController();
        this.controller = newController;
        return newController.signal;
    }
    /**
     * Manually cancel the current WebAuthn operation.
     * Useful for cleaning up when user cancels or navigates away.
     *
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/AbortController/abort MDN - AbortController.abort}
     */
    cancelCeremony() {
        if (this.controller) {
            const abortError = new Error('Manually cancelling existing WebAuthn API call');
            abortError.name = 'AbortError';
            this.controller.abort(abortError);
            this.controller = undefined;
        }
    }
}
/**
 * Singleton instance to ensure only one WebAuthn ceremony is active at a time.
 * This prevents "operation already in progress" errors when retrying WebAuthn operations.
 *
 * @experimental This instance is experimental and may change in future releases
 */
export const webAuthnAbortService = new WebAuthnAbortService();
/**
 * Convert base64url encoded strings in WebAuthn credential creation options to ArrayBuffers
 * as required by the WebAuthn browser API.
 * Supports both native WebAuthn Level 3 parseCreationOptionsFromJSON and manual fallback.
 *
 * @param {ServerCredentialCreationOptions} options - JSON options from server with base64url encoded fields
 * @returns {PublicKeyCredentialCreationOptionsFuture} Options ready for navigator.credentials.create()
 * @see {@link https://w3c.github.io/webauthn/#sctn-parseCreationOptionsFromJSON W3C WebAuthn Spec - parseCreationOptionsFromJSON}
 */
export function deserializeCredentialCreationOptions(options) {
    if (!options) {
        throw new Error('Credential creation options are required');
    }
    // Check if the native parseCreationOptionsFromJSON method is available
    if (typeof PublicKeyCredential !== 'undefined' &&
        'parseCreationOptionsFromJSON' in PublicKeyCredential &&
        typeof PublicKeyCredential
            .parseCreationOptionsFromJSON === 'function') {
        // Use the native WebAuthn Level 3 method
        return PublicKeyCredential.parseCreationOptionsFromJSON(
        /** we assert the options here as typescript still doesn't know about future webauthn types */
        options);
    }
    // Fallback to manual parsing for browsers that don't support the native method
    // Destructure to separate fields that need transformation
    const { challenge: challengeStr, user: userOpts, excludeCredentials } = options, restOptions = __rest(options
    // Convert challenge from base64url to ArrayBuffer
    , ["challenge", "user", "excludeCredentials"]);
    // Convert challenge from base64url to ArrayBuffer
    const challenge = base64UrlToUint8Array(challengeStr).buffer;
    // Convert user.id from base64url to ArrayBuffer
    const user = Object.assign(Object.assign({}, userOpts), { id: base64UrlToUint8Array(userOpts.id).buffer });
    // Build the result object
    const result = Object.assign(Object.assign({}, restOptions), { challenge,
        user });
    // Only add excludeCredentials if it exists
    if (excludeCredentials && excludeCredentials.length > 0) {
        result.excludeCredentials = new Array(excludeCredentials.length);
        for (let i = 0; i < excludeCredentials.length; i++) {
            const cred = excludeCredentials[i];
            result.excludeCredentials[i] = Object.assign(Object.assign({}, cred), { id: base64UrlToUint8Array(cred.id).buffer, type: cred.type || 'public-key', 
                // Cast transports to handle future transport types like "cable"
                transports: cred.transports });
        }
    }
    return result;
}
/**
 * Convert base64url encoded strings in WebAuthn credential request options to ArrayBuffers
 * as required by the WebAuthn browser API.
 * Supports both native WebAuthn Level 3 parseRequestOptionsFromJSON and manual fallback.
 *
 * @param {ServerCredentialRequestOptions} options - JSON options from server with base64url encoded fields
 * @returns {PublicKeyCredentialRequestOptionsFuture} Options ready for navigator.credentials.get()
 * @see {@link https://w3c.github.io/webauthn/#sctn-parseRequestOptionsFromJSON W3C WebAuthn Spec - parseRequestOptionsFromJSON}
 */
export function deserializeCredentialRequestOptions(options) {
    if (!options) {
        throw new Error('Credential request options are required');
    }
    // Check if the native parseRequestOptionsFromJSON method is available
    if (typeof PublicKeyCredential !== 'undefined' &&
        'parseRequestOptionsFromJSON' in PublicKeyCredential &&
        typeof PublicKeyCredential
            .parseRequestOptionsFromJSON === 'function') {
        // Use the native WebAuthn Level 3 method
        return PublicKeyCredential.parseRequestOptionsFromJSON(options);
    }
    // Fallback to manual parsing for browsers that don't support the native method
    // Destructure to separate fields that need transformation
    const { challenge: challengeStr, allowCredentials } = options, restOptions = __rest(options
    // Convert challenge from base64url to ArrayBuffer
    , ["challenge", "allowCredentials"]);
    // Convert challenge from base64url to ArrayBuffer
    const challenge = base64UrlToUint8Array(challengeStr).buffer;
    // Build the result object
    const result = Object.assign(Object.assign({}, restOptions), { challenge });
    // Only add allowCredentials if it exists
    if (allowCredentials && allowCredentials.length > 0) {
        result.allowCredentials = new Array(allowCredentials.length);
        for (let i = 0; i < allowCredentials.length; i++) {
            const cred = allowCredentials[i];
            result.allowCredentials[i] = Object.assign(Object.assign({}, cred), { id: base64UrlToUint8Array(cred.id).buffer, type: cred.type || 'public-key', 
                // Cast transports to handle future transport types like "cable"
                transports: cred.transports });
        }
    }
    return result;
}
/**
 * Convert a registration/enrollment credential response to server format.
 * Serializes binary fields to base64url for JSON transmission.
 * Supports both native WebAuthn Level 3 toJSON and manual fallback.
 *
 * @param {RegistrationCredential} credential - Credential from navigator.credentials.create()
 * @returns {RegistrationResponseJSON} JSON-serializable credential for server
 * @see {@link https://w3c.github.io/webauthn/#dom-publickeycredential-tojson W3C WebAuthn Spec - toJSON}
 */
export function serializeCredentialCreationResponse(credential) {
    var _a;
    // Check if the credential instance has the toJSON method
    if ('toJSON' in credential && typeof credential.toJSON === 'function') {
        // Use the native WebAuthn Level 3 method
        return credential.toJSON();
    }
    const credentialWithAttachment = credential;
    return {
        id: credential.id,
        rawId: credential.id,
        response: {
            attestationObject: bytesToBase64URL(new Uint8Array(credential.response.attestationObject)),
            clientDataJSON: bytesToBase64URL(new Uint8Array(credential.response.clientDataJSON)),
        },
        type: 'public-key',
        clientExtensionResults: credential.getClientExtensionResults(),
        // Convert null to undefined and cast to AuthenticatorAttachment type
        authenticatorAttachment: ((_a = credentialWithAttachment.authenticatorAttachment) !== null && _a !== void 0 ? _a : undefined),
    };
}
/**
 * Convert an authentication/verification credential response to server format.
 * Serializes binary fields to base64url for JSON transmission.
 * Supports both native WebAuthn Level 3 toJSON and manual fallback.
 *
 * @param {AuthenticationCredential} credential - Credential from navigator.credentials.get()
 * @returns {AuthenticationResponseJSON} JSON-serializable credential for server
 * @see {@link https://w3c.github.io/webauthn/#dom-publickeycredential-tojson W3C WebAuthn Spec - toJSON}
 */
export function serializeCredentialRequestResponse(credential) {
    var _a;
    // Check if the credential instance has the toJSON method
    if ('toJSON' in credential && typeof credential.toJSON === 'function') {
        // Use the native WebAuthn Level 3 method
        return credential.toJSON();
    }
    // Fallback to manual conversion for browsers that don't support toJSON
    // Access authenticatorAttachment via type assertion to handle TypeScript version differences
    // @simplewebauthn/types includes this property but base TypeScript 4.7.4 doesn't
    const credentialWithAttachment = credential;
    const clientExtensionResults = credential.getClientExtensionResults();
    const assertionResponse = credential.response;
    return {
        id: credential.id,
        rawId: credential.id, // W3C spec expects rawId to match id for JSON format
        response: {
            authenticatorData: bytesToBase64URL(new Uint8Array(assertionResponse.authenticatorData)),
            clientDataJSON: bytesToBase64URL(new Uint8Array(assertionResponse.clientDataJSON)),
            signature: bytesToBase64URL(new Uint8Array(assertionResponse.signature)),
            userHandle: assertionResponse.userHandle
                ? bytesToBase64URL(new Uint8Array(assertionResponse.userHandle))
                : undefined,
        },
        type: 'public-key',
        clientExtensionResults,
        // Convert null to undefined and cast to AuthenticatorAttachment type
        authenticatorAttachment: ((_a = credentialWithAttachment.authenticatorAttachment) !== null && _a !== void 0 ? _a : undefined),
    };
}
/**
 * A simple test to determine if a hostname is a properly-formatted domain name.
 * Considers localhost valid for development environments.
 *
 * A "valid domain" is defined here: https://url.spec.whatwg.org/#valid-domain
 *
 * Regex sourced from here:
 * https://www.oreilly.com/library/view/regular-expressions-cookbook/9781449327453/ch08s15.html
 *
 * @param {string} hostname - The hostname to validate
 * @returns {boolean} True if valid domain or localhost
 * @see {@link https://url.spec.whatwg.org/#valid-domain WHATWG URL Spec - Valid Domain}
 */
export function isValidDomain(hostname) {
    return (
    // Consider localhost valid as well since it's okay wrt Secure Contexts
    hostname === 'localhost' || /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(hostname));
}
/**
 * Determine if the browser is capable of WebAuthn.
 * Checks for necessary Web APIs: PublicKeyCredential and Credential Management.
 *
 * @returns {boolean} True if browser supports WebAuthn
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/PublicKeyCredential#browser_compatibility MDN - PublicKeyCredential Browser Compatibility}
 */
export function browserSupportsWebAuthn() {
    var _a, _b;
    return !!(isBrowser() &&
        'PublicKeyCredential' in window &&
        window.PublicKeyCredential &&
        'credentials' in navigator &&
        typeof ((_a = navigator === null || navigator === void 0 ? void 0 : navigator.credentials) === null || _a === void 0 ? void 0 : _a.create) === 'function' &&
        typeof ((_b = navigator === null || navigator === void 0 ? void 0 : navigator.credentials) === null || _b === void 0 ? void 0 : _b.get) === 'function');
}
/**
 * Create a WebAuthn credential using the browser's credentials API.
 * Wraps navigator.credentials.create() with error handling.
 *
 * @param {CredentialCreationOptions} options - Options including publicKey parameters
 * @returns {Promise<RequestResult<RegistrationCredential, WebAuthnError>>} Created credential or error
 * @see {@link https://w3c.github.io/webauthn/#sctn-createCredential W3C WebAuthn Spec - Create Credential}
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/CredentialsContainer/create MDN - credentials.create}
 */
export async function createCredential(options) {
    try {
        const response = await navigator.credentials.create(
        /** we assert the type here until typescript types are updated */
        options);
        if (!response) {
            return {
                data: null,
                error: new WebAuthnUnknownError('Empty credential response', response),
            };
        }
        if (!(response instanceof PublicKeyCredential)) {
            return {
                data: null,
                error: new WebAuthnUnknownError('Browser returned unexpected credential type', response),
            };
        }
        return { data: response, error: null };
    }
    catch (err) {
        return {
            data: null,
            error: identifyRegistrationError({
                error: err,
                options,
            }),
        };
    }
}
/**
 * Get a WebAuthn credential using the browser's credentials API.
 * Wraps navigator.credentials.get() with error handling.
 *
 * @param {CredentialRequestOptions} options - Options including publicKey parameters
 * @returns {Promise<RequestResult<AuthenticationCredential, WebAuthnError>>} Retrieved credential or error
 * @see {@link https://w3c.github.io/webauthn/#sctn-getAssertion W3C WebAuthn Spec - Get Assertion}
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/CredentialsContainer/get MDN - credentials.get}
 */
export async function getCredential(options) {
    try {
        const response = await navigator.credentials.get(
        /** we assert the type here until typescript types are updated */
        options);
        if (!response) {
            return {
                data: null,
                error: new WebAuthnUnknownError('Empty credential response', response),
            };
        }
        if (!(response instanceof PublicKeyCredential)) {
            return {
                data: null,
                error: new WebAuthnUnknownError('Browser returned unexpected credential type', response),
            };
        }
        return { data: response, error: null };
    }
    catch (err) {
        return {
            data: null,
            error: identifyAuthenticationError({
                error: err,
                options,
            }),
        };
    }
}
export const DEFAULT_CREATION_OPTIONS = {
    hints: ['security-key'],
    authenticatorSelection: {
        authenticatorAttachment: 'cross-platform',
        requireResidentKey: false,
        /** set to preferred because older yubikeys don't have PIN/Biometric */
        userVerification: 'preferred',
        residentKey: 'discouraged',
    },
    attestation: 'direct',
};
export const DEFAULT_REQUEST_OPTIONS = {
    /** set to preferred because older yubikeys don't have PIN/Biometric */
    userVerification: 'preferred',
    hints: ['security-key'],
    attestation: 'direct',
};
function deepMerge(...sources) {
    const isObject = (val) => val !== null && typeof val === 'object' && !Array.isArray(val);
    const isArrayBufferLike = (val) => val instanceof ArrayBuffer || ArrayBuffer.isView(val);
    const result = {};
    for (const source of sources) {
        if (!source)
            continue;
        for (const key in source) {
            const value = source[key];
            if (value === undefined)
                continue;
            if (Array.isArray(value)) {
                // preserve array reference, including unions like AuthenticatorTransport[]
                result[key] = value;
            }
            else if (isArrayBufferLike(value)) {
                result[key] = value;
            }
            else if (isObject(value)) {
                const existing = result[key];
                if (isObject(existing)) {
                    result[key] = deepMerge(existing, value);
                }
                else {
                    result[key] = deepMerge(value);
                }
            }
            else {
                result[key] = value;
            }
        }
    }
    return result;
}
/**
 * Merges WebAuthn credential creation options with overrides.
 * Sets sensible defaults for authenticator selection and extensions.
 *
 * @param {PublicKeyCredentialCreationOptionsFuture} baseOptions - The base options from the server
 * @param {PublicKeyCredentialCreationOptionsFuture} overrides - Optional overrides to apply
 * @param {string} friendlyName - Optional friendly name for the credential
 * @returns {PublicKeyCredentialCreationOptionsFuture} Merged credential creation options
 * @see {@link https://w3c.github.io/webauthn/#dictdef-authenticatorselectioncriteria W3C WebAuthn Spec - AuthenticatorSelectionCriteria}
 */
export function mergeCredentialCreationOptions(baseOptions, overrides) {
    return deepMerge(DEFAULT_CREATION_OPTIONS, baseOptions, overrides || {});
}
/**
 * Merges WebAuthn credential request options with overrides.
 * Sets sensible defaults for user verification and hints.
 *
 * @param {PublicKeyCredentialRequestOptionsFuture} baseOptions - The base options from the server
 * @param {PublicKeyCredentialRequestOptionsFuture} overrides - Optional overrides to apply
 * @returns {PublicKeyCredentialRequestOptionsFuture} Merged credential request options
 * @see {@link https://w3c.github.io/webauthn/#dictdef-publickeycredentialrequestoptions W3C WebAuthn Spec - PublicKeyCredentialRequestOptions}
 */
export function mergeCredentialRequestOptions(baseOptions, overrides) {
    return deepMerge(DEFAULT_REQUEST_OPTIONS, baseOptions, overrides || {});
}
/**
 * WebAuthn API wrapper for Supabase Auth.
 * Provides methods for enrolling, challenging, verifying, authenticating, and registering WebAuthn credentials.
 *
 * @experimental This API is experimental and may change in future releases
 * @see {@link https://w3c.github.io/webauthn/ W3C WebAuthn Specification}
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/Web_Authentication_API MDN - Web Authentication API}
 */
export class WebAuthnApi {
    constructor(client) {
        this.client = client;
        // Bind all methods so they can be destructured
        this.enroll = this._enroll.bind(this);
        this.challenge = this._challenge.bind(this);
        this.verify = this._verify.bind(this);
        this.authenticate = this._authenticate.bind(this);
        this.register = this._register.bind(this);
    }
    /**
     * Enroll a new WebAuthn factor.
     * Creates an unverified WebAuthn factor that must be verified with a credential.
     *
     * @experimental This method is experimental and may change in future releases
     * @param {Omit<MFAEnrollWebauthnParams, 'factorType'>} params - Enrollment parameters (friendlyName required)
     * @returns {Promise<AuthMFAEnrollWebauthnResponse>} Enrolled factor details or error
     * @see {@link https://w3c.github.io/webauthn/#sctn-registering-a-new-credential W3C WebAuthn Spec - Registering a New Credential}
     */
    async _enroll(params) {
        return this.client.mfa.enroll(Object.assign(Object.assign({}, params), { factorType: 'webauthn' }));
    }
    /**
     * Challenge for WebAuthn credential creation or authentication.
     * Combines server challenge with browser credential operations.
     * Handles both registration (create) and authentication (request) flows.
     *
     * @experimental This method is experimental and may change in future releases
     * @param {MFAChallengeWebauthnParams & { friendlyName?: string; signal?: AbortSignal }} params - Challenge parameters including factorId
     * @param {Object} overrides - Allows you to override the parameters passed to navigator.credentials
     * @param {PublicKeyCredentialCreationOptionsFuture} overrides.create - Override options for credential creation
     * @param {PublicKeyCredentialRequestOptionsFuture} overrides.request - Override options for credential request
     * @returns {Promise<RequestResult>} Challenge response with credential or error
     * @see {@link https://w3c.github.io/webauthn/#sctn-credential-creation W3C WebAuthn Spec - Credential Creation}
     * @see {@link https://w3c.github.io/webauthn/#sctn-verifying-assertion W3C WebAuthn Spec - Verifying Assertion}
     */
    async _challenge({ factorId, webauthn, friendlyName, signal, }, overrides) {
        var _a;
        try {
            // Get challenge from server using the client's MFA methods
            const { data: challengeResponse, error: challengeError } = await this.client.mfa.challenge({
                factorId,
                webauthn,
            });
            if (!challengeResponse) {
                return { data: null, error: challengeError };
            }
            const abortSignal = signal !== null && signal !== void 0 ? signal : webAuthnAbortService.createNewAbortSignal();
            /** webauthn will fail if either of the name/displayname are blank */
            if (challengeResponse.webauthn.type === 'create') {
                const { user } = challengeResponse.webauthn.credential_options.publicKey;
                if (!user.name) {
                    // Preserve original format: use friendlyName if provided, otherwise fetch fallback
                    // This maintains backward compatibility with the ${user.id}:${name} format
                    const nameToUse = friendlyName;
                    if (!nameToUse) {
                        // Only fetch user data if friendlyName is not provided (bug fix for null friendlyName)
                        const currentUser = await this.client.getUser();
                        const userData = currentUser.data.user;
                        const fallbackName = ((_a = userData === null || userData === void 0 ? void 0 : userData.user_metadata) === null || _a === void 0 ? void 0 : _a.name) || (userData === null || userData === void 0 ? void 0 : userData.email) || (userData === null || userData === void 0 ? void 0 : userData.id) || 'User';
                        user.name = `${user.id}:${fallbackName}`;
                    }
                    else {
                        user.name = `${user.id}:${nameToUse}`;
                    }
                }
                if (!user.displayName) {
                    user.displayName = user.name;
                }
            }
            switch (challengeResponse.webauthn.type) {
                case 'create': {
                    const options = mergeCredentialCreationOptions(challengeResponse.webauthn.credential_options.publicKey, overrides === null || overrides === void 0 ? void 0 : overrides.create);
                    const { data, error } = await createCredential({
                        publicKey: options,
                        signal: abortSignal,
                    });
                    if (data) {
                        return {
                            data: {
                                factorId,
                                challengeId: challengeResponse.id,
                                webauthn: {
                                    type: challengeResponse.webauthn.type,
                                    credential_response: data,
                                },
                            },
                            error: null,
                        };
                    }
                    return { data: null, error };
                }
                case 'request': {
                    const options = mergeCredentialRequestOptions(challengeResponse.webauthn.credential_options.publicKey, overrides === null || overrides === void 0 ? void 0 : overrides.request);
                    const { data, error } = await getCredential(Object.assign(Object.assign({}, challengeResponse.webauthn.credential_options), { publicKey: options, signal: abortSignal }));
                    if (data) {
                        return {
                            data: {
                                factorId,
                                challengeId: challengeResponse.id,
                                webauthn: {
                                    type: challengeResponse.webauthn.type,
                                    credential_response: data,
                                },
                            },
                            error: null,
                        };
                    }
                    return { data: null, error };
                }
            }
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            return {
                data: null,
                error: new AuthUnknownError('Unexpected error in challenge', error),
            };
        }
    }
    /**
     * Verify a WebAuthn credential with the server.
     * Completes the WebAuthn ceremony by sending the credential to the server for verification.
     *
     * @experimental This method is experimental and may change in future releases
     * @param {Object} params - Verification parameters
     * @param {string} params.challengeId - ID of the challenge being verified
     * @param {string} params.factorId - ID of the WebAuthn factor
     * @param {MFAVerifyWebauthnParams<T>['webauthn']} params.webauthn - WebAuthn credential response
     * @returns {Promise<AuthMFAVerifyResponse>} Verification result with session or error
     * @see {@link https://w3c.github.io/webauthn/#sctn-verifying-assertion W3C WebAuthn Spec - Verifying an Authentication Assertion}
     * */
    async _verify({ challengeId, factorId, webauthn, }) {
        return this.client.mfa.verify({
            factorId,
            challengeId,
            webauthn: webauthn,
        });
    }
    /**
     * Complete WebAuthn authentication flow.
     * Performs challenge and verification in a single operation for existing credentials.
     *
     * @experimental This method is experimental and may change in future releases
     * @param {Object} params - Authentication parameters
     * @param {string} params.factorId - ID of the WebAuthn factor to authenticate with
     * @param {Object} params.webauthn - WebAuthn configuration
     * @param {string} params.webauthn.rpId - Relying Party ID (defaults to current hostname)
     * @param {string[]} params.webauthn.rpOrigins - Allowed origins (defaults to current origin)
     * @param {AbortSignal} params.webauthn.signal - Optional abort signal
     * @param {PublicKeyCredentialRequestOptionsFuture} overrides - Override options for navigator.credentials.get
     * @returns {Promise<RequestResult<AuthMFAVerifyResponseData, WebAuthnError | AuthError>>} Authentication result
     * @see {@link https://w3c.github.io/webauthn/#sctn-authentication W3C WebAuthn Spec - Authentication Ceremony}
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/PublicKeyCredentialRequestOptions MDN - PublicKeyCredentialRequestOptions}
     */
    async _authenticate({ factorId, webauthn: { rpId = typeof window !== 'undefined' ? window.location.hostname : undefined, rpOrigins = typeof window !== 'undefined' ? [window.location.origin] : undefined, signal, } = {}, }, overrides) {
        if (!rpId) {
            return {
                data: null,
                error: new AuthError('rpId is required for WebAuthn authentication'),
            };
        }
        try {
            if (!browserSupportsWebAuthn()) {
                return {
                    data: null,
                    error: new AuthUnknownError('Browser does not support WebAuthn', null),
                };
            }
            // Get challenge and credential
            const { data: challengeResponse, error: challengeError } = await this.challenge({
                factorId,
                webauthn: { rpId, rpOrigins },
                signal,
            }, { request: overrides });
            if (!challengeResponse) {
                return { data: null, error: challengeError };
            }
            const { webauthn } = challengeResponse;
            // Verify credential
            return this._verify({
                factorId,
                challengeId: challengeResponse.challengeId,
                webauthn: {
                    type: webauthn.type,
                    rpId,
                    rpOrigins,
                    credential_response: webauthn.credential_response,
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            return {
                data: null,
                error: new AuthUnknownError('Unexpected error in authenticate', error),
            };
        }
    }
    /**
     * Complete WebAuthn registration flow.
     * Performs enrollment, challenge, and verification in a single operation for new credentials.
     *
     * @experimental This method is experimental and may change in future releases
     * @param {Object} params - Registration parameters
     * @param {string} params.friendlyName - User-friendly name for the credential
     * @param {string} params.rpId - Relying Party ID (defaults to current hostname)
     * @param {string[]} params.rpOrigins - Allowed origins (defaults to current origin)
     * @param {AbortSignal} params.signal - Optional abort signal
     * @param {PublicKeyCredentialCreationOptionsFuture} overrides - Override options for navigator.credentials.create
     * @returns {Promise<RequestResult<AuthMFAVerifyResponseData, WebAuthnError | AuthError>>} Registration result
     * @see {@link https://w3c.github.io/webauthn/#sctn-registering-a-new-credential W3C WebAuthn Spec - Registration Ceremony}
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/PublicKeyCredentialCreationOptions MDN - PublicKeyCredentialCreationOptions}
     */
    async _register({ friendlyName, webauthn: { rpId = typeof window !== 'undefined' ? window.location.hostname : undefined, rpOrigins = typeof window !== 'undefined' ? [window.location.origin] : undefined, signal, } = {}, }, overrides) {
        if (!rpId) {
            return {
                data: null,
                error: new AuthError('rpId is required for WebAuthn registration'),
            };
        }
        try {
            if (!browserSupportsWebAuthn()) {
                return {
                    data: null,
                    error: new AuthUnknownError('Browser does not support WebAuthn', null),
                };
            }
            // Enroll factor
            const { data: factor, error: enrollError } = await this._enroll({
                friendlyName,
            });
            if (!factor) {
                await this.client.mfa
                    .listFactors()
                    .then((factors) => {
                    var _a;
                    return (_a = factors.data) === null || _a === void 0 ? void 0 : _a.all.find((v) => v.factor_type === 'webauthn' &&
                        v.friendly_name === friendlyName &&
                        v.status !== 'unverified');
                })
                    .then((factor) => (factor ? this.client.mfa.unenroll({ factorId: factor === null || factor === void 0 ? void 0 : factor.id }) : void 0));
                return { data: null, error: enrollError };
            }
            // Get challenge and create credential
            const { data: challengeResponse, error: challengeError } = await this._challenge({
                factorId: factor.id,
                friendlyName: factor.friendly_name,
                webauthn: { rpId, rpOrigins },
                signal,
            }, {
                create: overrides,
            });
            if (!challengeResponse) {
                return { data: null, error: challengeError };
            }
            return this._verify({
                factorId: factor.id,
                challengeId: challengeResponse.challengeId,
                webauthn: {
                    rpId,
                    rpOrigins,
                    type: challengeResponse.webauthn.type,
                    credential_response: challengeResponse.webauthn.credential_response,
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            return {
                data: null,
                error: new AuthUnknownError('Unexpected error in register', error),
            };
        }
    }
}
                                    
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2ViYXV0aG4uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvbGliL3dlYmF1dGhuLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFDQSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxhQUFhLENBQUE7QUFDckUsT0FBTyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxXQUFXLEVBQUUsTUFBTSxVQUFVLENBQUE7QUFZbkUsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLFdBQVcsQ0FBQTtBQWNyQyxPQUFPLEVBQ0wsMkJBQTJCLEVBQzNCLHlCQUF5QixFQUN6QixlQUFlLEVBQ2YsYUFBYSxFQUNiLG9CQUFvQixHQUNyQixNQUFNLG1CQUFtQixDQUFBO0FBRTFCLE9BQU8sRUFBRSxhQUFhLEVBQUUsZUFBZSxFQUFFLHlCQUF5QixFQUFFLDJCQUEyQixFQUFFLENBQUE7QUFJakc7Ozs7OztHQU1HO0FBQ0gsTUFBTSxPQUFPLG9CQUFvQjtJQUcvQjs7Ozs7O09BTUc7SUFDSCxvQkFBb0I7UUFDbEIsNEZBQTRGO1FBQzVGLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLE1BQU0sVUFBVSxHQUFHLElBQUksS0FBSyxDQUFDLG1EQUFtRCxDQUFDLENBQUE7WUFDakYsVUFBVSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUE7WUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUE7UUFDbkMsQ0FBQztRQUVELE1BQU0sYUFBYSxHQUFHLElBQUksZUFBZSxFQUFFLENBQUE7UUFDM0MsSUFBSSxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUE7UUFDL0IsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFBO0lBQzdCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGNBQWM7UUFDWixJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNwQixNQUFNLFVBQVUsR0FBRyxJQUFJLEtBQUssQ0FBQyxnREFBZ0QsQ0FBQyxDQUFBO1lBQzlFLFVBQVUsQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFBO1lBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQ2pDLElBQUksQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFBO1FBQzdCLENBQUM7SUFDSCxDQUFDO0NBQ0Y7QUFFRDs7Ozs7R0FLRztBQUNILE1BQU0sQ0FBQyxNQUFNLG9CQUFvQixHQUFHLElBQUksb0JBQW9CLEVBQUUsQ0FBQTtBQWM5RDs7Ozs7Ozs7R0FRRztBQUNILE1BQU0sVUFBVSxvQ0FBb0MsQ0FDbEQsT0FBd0M7SUFFeEMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQyxDQUFBO0lBQzdELENBQUM7SUFFRCx1RUFBdUU7SUFDdkUsSUFDRSxPQUFPLG1CQUFtQixLQUFLLFdBQVc7UUFDMUMsOEJBQThCLElBQUksbUJBQW1CO1FBQ3JELE9BQVEsbUJBQTREO2FBQ2pFLDRCQUE0QixLQUFLLFVBQVUsRUFDOUMsQ0FBQztRQUNELHlDQUF5QztRQUN6QyxPQUNFLG1CQUNELENBQUMsNEJBQTRCO1FBQzVCLDhGQUE4RjtRQUM5RixPQUFjLENBQzZCLENBQUE7SUFDL0MsQ0FBQztJQUVELCtFQUErRTtJQUMvRSwwREFBMEQ7SUFDMUQsTUFBTSxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsS0FBcUIsT0FBTyxFQUF2QixXQUFXLFVBQUssT0FBTztJQUUvRixrREFBa0Q7TUFGNUMsMkNBQStFLENBQVUsQ0FBQTtJQUUvRixrREFBa0Q7SUFDbEQsTUFBTSxTQUFTLEdBQUcscUJBQXFCLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBcUIsQ0FBQTtJQUUzRSxnREFBZ0Q7SUFDaEQsTUFBTSxJQUFJLG1DQUNMLFFBQVEsS0FDWCxFQUFFLEVBQUUscUJBQXFCLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQXFCLEdBQzdELENBQUE7SUFFRCwwQkFBMEI7SUFDMUIsTUFBTSxNQUFNLG1DQUNQLFdBQVcsS0FDZCxTQUFTO1FBQ1QsSUFBSSxHQUNMLENBQUE7SUFFRCwyQ0FBMkM7SUFDM0MsSUFBSSxrQkFBa0IsSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDeEQsTUFBTSxDQUFDLGtCQUFrQixHQUFHLElBQUksS0FBSyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBRWhFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNuRCxNQUFNLElBQUksR0FBRyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNsQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLG1DQUN2QixJQUFJLEtBQ1AsRUFBRSxFQUFFLHFCQUFxQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLEVBQ3pDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJLFlBQVk7Z0JBQy9CLGdFQUFnRTtnQkFDaEUsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLEdBQzVCLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxVQUFVLG1DQUFtQyxDQUNqRCxPQUF1QztJQUV2QyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDYixNQUFNLElBQUksS0FBSyxDQUFDLHlDQUF5QyxDQUFDLENBQUE7SUFDNUQsQ0FBQztJQUVELHNFQUFzRTtJQUN0RSxJQUNFLE9BQU8sbUJBQW1CLEtBQUssV0FBVztRQUMxQyw2QkFBNkIsSUFBSSxtQkFBbUI7UUFDcEQsT0FBUSxtQkFBNEQ7YUFDakUsMkJBQTJCLEtBQUssVUFBVSxFQUM3QyxDQUFDO1FBQ0QseUNBQXlDO1FBQ3pDLE9BQ0UsbUJBQ0QsQ0FBQywyQkFBMkIsQ0FBQyxPQUFPLENBQTRDLENBQUE7SUFDbkYsQ0FBQztJQUVELCtFQUErRTtJQUMvRSwwREFBMEQ7SUFDMUQsTUFBTSxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsZ0JBQWdCLEtBQXFCLE9BQU8sRUFBdkIsV0FBVyxVQUFLLE9BQU87SUFFN0Usa0RBQWtEO01BRjVDLGlDQUE2RCxDQUFVLENBQUE7SUFFN0Usa0RBQWtEO0lBQ2xELE1BQU0sU0FBUyxHQUFHLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQXFCLENBQUE7SUFFM0UsMEJBQTBCO0lBQzFCLE1BQU0sTUFBTSxtQ0FDUCxXQUFXLEtBQ2QsU0FBUyxHQUNWLENBQUE7SUFFRCx5Q0FBeUM7SUFDekMsSUFBSSxnQkFBZ0IsSUFBSSxnQkFBZ0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDcEQsTUFBTSxDQUFDLGdCQUFnQixHQUFHLElBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBRTVELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNqRCxNQUFNLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNoQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLG1DQUNyQixJQUFJLEtBQ1AsRUFBRSxFQUFFLHFCQUFxQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLEVBQ3pDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJLFlBQVk7Z0JBQy9CLGdFQUFnRTtnQkFDaEUsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLEdBQzVCLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQztBQVFEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxVQUFVLG1DQUFtQyxDQUNqRCxVQUFrQzs7SUFFbEMseURBQXlEO0lBQ3pELElBQUksUUFBUSxJQUFJLFVBQVUsSUFBSSxPQUFPLFVBQVUsQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUFFLENBQUM7UUFDdEUseUNBQXlDO1FBQ3pDLE9BQVEsVUFBcUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQTtJQUN4RCxDQUFDO0lBQ0QsTUFBTSx3QkFBd0IsR0FBRyxVQUdoQyxDQUFBO0lBRUQsT0FBTztRQUNMLEVBQUUsRUFBRSxVQUFVLENBQUMsRUFBRTtRQUNqQixLQUFLLEVBQUUsVUFBVSxDQUFDLEVBQUU7UUFDcEIsUUFBUSxFQUFFO1lBQ1IsaUJBQWlCLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxVQUFVLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQzFGLGNBQWMsRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1NBQ3JGO1FBQ0QsSUFBSSxFQUFFLFlBQVk7UUFDbEIsc0JBQXNCLEVBQUUsVUFBVSxDQUFDLHlCQUF5QixFQUFFO1FBQzlELHFFQUFxRTtRQUNyRSx1QkFBdUIsRUFBRSxDQUFDLE1BQUEsd0JBQXdCLENBQUMsdUJBQXVCLG1DQUFJLFNBQVMsQ0FFMUU7S0FDZCxDQUFBO0FBQ0gsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxVQUFVLGtDQUFrQyxDQUNoRCxVQUFvQzs7SUFFcEMseURBQXlEO0lBQ3pELElBQUksUUFBUSxJQUFJLFVBQVUsSUFBSSxPQUFPLFVBQVUsQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUFFLENBQUM7UUFDdEUseUNBQXlDO1FBQ3pDLE9BQVEsVUFBdUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQTtJQUMxRCxDQUFDO0lBRUQsdUVBQXVFO0lBQ3ZFLDZGQUE2RjtJQUM3RixpRkFBaUY7SUFDakYsTUFBTSx3QkFBd0IsR0FBRyxVQUdoQyxDQUFBO0lBRUQsTUFBTSxzQkFBc0IsR0FBRyxVQUFVLENBQUMseUJBQXlCLEVBQUUsQ0FBQTtJQUNyRSxNQUFNLGlCQUFpQixHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUE7SUFFN0MsT0FBTztRQUNMLEVBQUUsRUFBRSxVQUFVLENBQUMsRUFBRTtRQUNqQixLQUFLLEVBQUUsVUFBVSxDQUFDLEVBQUUsRUFBRSxxREFBcUQ7UUFDM0UsUUFBUSxFQUFFO1lBQ1IsaUJBQWlCLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxVQUFVLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUN4RixjQUFjLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxVQUFVLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDbEYsU0FBUyxFQUFFLGdCQUFnQixDQUFDLElBQUksVUFBVSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hFLFVBQVUsRUFBRSxpQkFBaUIsQ0FBQyxVQUFVO2dCQUN0QyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxVQUFVLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ2hFLENBQUMsQ0FBQyxTQUFTO1NBQ2Q7UUFDRCxJQUFJLEVBQUUsWUFBWTtRQUNsQixzQkFBc0I7UUFDdEIscUVBQXFFO1FBQ3JFLHVCQUF1QixFQUFFLENBQUMsTUFBQSx3QkFBd0IsQ0FBQyx1QkFBdUIsbUNBQUksU0FBUyxDQUUxRTtLQUNkLENBQUE7QUFDSCxDQUFDO0FBRUQ7Ozs7Ozs7Ozs7OztHQVlHO0FBQ0gsTUFBTSxVQUFVLGFBQWEsQ0FBQyxRQUFnQjtJQUM1QyxPQUFPO0lBQ0wsdUVBQXVFO0lBQ3ZFLFFBQVEsS0FBSyxXQUFXLElBQUkseUNBQXlDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUNyRixDQUFBO0FBQ0gsQ0FBQztBQUVEOzs7Ozs7R0FNRztBQUNILE1BQU0sVUFBVSx1QkFBdUI7O0lBQ3JDLE9BQU8sQ0FBQyxDQUFDLENBQ1AsU0FBUyxFQUFFO1FBQ1gscUJBQXFCLElBQUksTUFBTTtRQUMvQixNQUFNLENBQUMsbUJBQW1CO1FBQzFCLGFBQWEsSUFBSSxTQUFTO1FBQzFCLE9BQU8sQ0FBQSxNQUFBLFNBQVMsYUFBVCxTQUFTLHVCQUFULFNBQVMsQ0FBRSxXQUFXLDBDQUFFLE1BQU0sQ0FBQSxLQUFLLFVBQVU7UUFDcEQsT0FBTyxDQUFBLE1BQUEsU0FBUyxhQUFULFNBQVMsdUJBQVQsU0FBUyxDQUFFLFdBQVcsMENBQUUsR0FBRyxDQUFBLEtBQUssVUFBVSxDQUNsRCxDQUFBO0FBQ0gsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxDQUFDLEtBQUssVUFBVSxnQkFBZ0IsQ0FDcEMsT0FFQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNO1FBQ2pELGlFQUFpRTtRQUNqRSxPQUE2RCxDQUM5RCxDQUFBO1FBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2QsT0FBTztnQkFDTCxJQUFJLEVBQUUsSUFBSTtnQkFDVixLQUFLLEVBQUUsSUFBSSxvQkFBb0IsQ0FBQywyQkFBMkIsRUFBRSxRQUFRLENBQUM7YUFDdkUsQ0FBQTtRQUNILENBQUM7UUFDRCxJQUFJLENBQUMsQ0FBQyxRQUFRLFlBQVksbUJBQW1CLENBQUMsRUFBRSxDQUFDO1lBQy9DLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLElBQUksb0JBQW9CLENBQUMsNkNBQTZDLEVBQUUsUUFBUSxDQUFDO2FBQ3pGLENBQUE7UUFDSCxDQUFDO1FBQ0QsT0FBTyxFQUFFLElBQUksRUFBRSxRQUFrQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtJQUNsRSxDQUFDO0lBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNiLE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSTtZQUNWLEtBQUssRUFBRSx5QkFBeUIsQ0FBQztnQkFDL0IsS0FBSyxFQUFFLEdBQVk7Z0JBQ25CLE9BQU87YUFDUixDQUFDO1NBQ0gsQ0FBQTtJQUNILENBQUM7QUFDSCxDQUFDO0FBRUQ7Ozs7Ozs7O0dBUUc7QUFDSCxNQUFNLENBQUMsS0FBSyxVQUFVLGFBQWEsQ0FDakMsT0FFQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHO1FBQzlDLGlFQUFpRTtRQUNqRSxPQUEwRCxDQUMzRCxDQUFBO1FBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2QsT0FBTztnQkFDTCxJQUFJLEVBQUUsSUFBSTtnQkFDVixLQUFLLEVBQUUsSUFBSSxvQkFBb0IsQ0FBQywyQkFBMkIsRUFBRSxRQUFRLENBQUM7YUFDdkUsQ0FBQTtRQUNILENBQUM7UUFDRCxJQUFJLENBQUMsQ0FBQyxRQUFRLFlBQVksbUJBQW1CLENBQUMsRUFBRSxDQUFDO1lBQy9DLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLElBQUksb0JBQW9CLENBQUMsNkNBQTZDLEVBQUUsUUFBUSxDQUFDO2FBQ3pGLENBQUE7UUFDSCxDQUFDO1FBQ0QsT0FBTyxFQUFFLElBQUksRUFBRSxRQUFvQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtJQUNwRSxDQUFDO0lBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNiLE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSTtZQUNWLEtBQUssRUFBRSwyQkFBMkIsQ0FBQztnQkFDakMsS0FBSyxFQUFFLEdBQVk7Z0JBQ25CLE9BQU87YUFDUixDQUFDO1NBQ0gsQ0FBQTtJQUNILENBQUM7QUFDSCxDQUFDO0FBRUQsTUFBTSxDQUFDLE1BQU0sd0JBQXdCLEdBQXNEO0lBQ3pGLEtBQUssRUFBRSxDQUFDLGNBQWMsQ0FBQztJQUN2QixzQkFBc0IsRUFBRTtRQUN0Qix1QkFBdUIsRUFBRSxnQkFBZ0I7UUFDekMsa0JBQWtCLEVBQUUsS0FBSztRQUN6Qix1RUFBdUU7UUFDdkUsZ0JBQWdCLEVBQUUsV0FBVztRQUM3QixXQUFXLEVBQUUsYUFBYTtLQUMzQjtJQUNELFdBQVcsRUFBRSxRQUFRO0NBQ3RCLENBQUE7QUFFRCxNQUFNLENBQUMsTUFBTSx1QkFBdUIsR0FBcUQ7SUFDdkYsdUVBQXVFO0lBQ3ZFLGdCQUFnQixFQUFFLFdBQVc7SUFDN0IsS0FBSyxFQUFFLENBQUMsY0FBYyxDQUFDO0lBQ3ZCLFdBQVcsRUFBRSxRQUFRO0NBQ3RCLENBQUE7QUFFRCxTQUFTLFNBQVMsQ0FBSSxHQUFHLE9BQXFCO0lBQzVDLE1BQU0sUUFBUSxHQUFHLENBQUMsR0FBWSxFQUFrQyxFQUFFLENBQ2hFLEdBQUcsS0FBSyxJQUFJLElBQUksT0FBTyxHQUFHLEtBQUssUUFBUSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUVoRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsR0FBWSxFQUF3QyxFQUFFLENBQy9FLEdBQUcsWUFBWSxXQUFXLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUV2RCxNQUFNLE1BQU0sR0FBZSxFQUFFLENBQUE7SUFFN0IsS0FBSyxNQUFNLE1BQU0sSUFBSSxPQUFPLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsTUFBTTtZQUFFLFNBQVE7UUFFckIsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUN6QixNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7WUFDekIsSUFBSSxLQUFLLEtBQUssU0FBUztnQkFBRSxTQUFRO1lBRWpDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN6QiwyRUFBMkU7Z0JBQzNFLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFzQixDQUFBO1lBQ3RDLENBQUM7aUJBQU0sSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBc0IsQ0FBQTtZQUN0QyxDQUFDO2lCQUFNLElBQUksUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQzNCLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFDNUIsSUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztvQkFDdkIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUE2QixDQUFBO2dCQUN0RSxDQUFDO3FCQUFNLENBQUM7b0JBQ04sTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQTZCLENBQUE7Z0JBQzVELENBQUM7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQXNCLENBQUE7WUFDdEMsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxNQUFXLENBQUE7QUFDcEIsQ0FBQztBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILE1BQU0sVUFBVSw4QkFBOEIsQ0FDNUMsV0FBcUQsRUFDckQsU0FBNkQ7SUFFN0QsT0FBTyxTQUFTLENBQUMsd0JBQXdCLEVBQUUsV0FBVyxFQUFFLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUMxRSxDQUFDO0FBRUQ7Ozs7Ozs7O0dBUUc7QUFDSCxNQUFNLFVBQVUsNkJBQTZCLENBQzNDLFdBQW9ELEVBQ3BELFNBQTREO0lBRTVELE9BQU8sU0FBUyxDQUFDLHVCQUF1QixFQUFFLFdBQVcsRUFBRSxTQUFTLElBQUksRUFBRSxDQUFDLENBQUE7QUFDekUsQ0FBQztBQUVEOzs7Ozs7O0dBT0c7QUFDSCxNQUFNLE9BQU8sV0FBVztJQU90QixZQUFvQixNQUFvQjtRQUFwQixXQUFNLEdBQU4sTUFBTSxDQUFjO1FBQ3RDLCtDQUErQztRQUMvQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQ3JDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDM0MsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUNyQyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQ2pELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDM0MsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0ksS0FBSyxDQUFDLE9BQU8sQ0FDbEIsTUFBbUQ7UUFFbkQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLGlDQUFNLE1BQU0sS0FBRSxVQUFVLEVBQUUsVUFBVSxJQUFHLENBQUE7SUFDdEUsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSSxLQUFLLENBQUMsVUFBVSxDQUNyQixFQUNFLFFBQVEsRUFDUixRQUFRLEVBQ1IsWUFBWSxFQUNaLE1BQU0sR0FDdUUsRUFDL0UsU0FRSzs7UUFZTCxJQUFJLENBQUM7WUFDSCwyREFBMkQ7WUFDM0QsTUFBTSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQ3pGLFFBQVE7Z0JBQ1IsUUFBUTthQUNULENBQUMsQ0FBQTtZQUVGLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLENBQUE7WUFDOUMsQ0FBQztZQUVELE1BQU0sV0FBVyxHQUFHLE1BQU0sYUFBTixNQUFNLGNBQU4sTUFBTSxHQUFJLG9CQUFvQixDQUFDLG9CQUFvQixFQUFFLENBQUE7WUFFekUscUVBQXFFO1lBQ3JFLElBQUksaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQztnQkFDakQsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUE7Z0JBQ3hFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsbUZBQW1GO29CQUNuRiwyRUFBMkU7b0JBQzNFLE1BQU0sU0FBUyxHQUFHLFlBQVksQ0FBQTtvQkFDOUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO3dCQUNmLHVGQUF1Rjt3QkFDdkYsTUFBTSxXQUFXLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFBO3dCQUMvQyxNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQTt3QkFDdEMsTUFBTSxZQUFZLEdBQ2hCLENBQUEsTUFBQSxRQUFRLGFBQVIsUUFBUSx1QkFBUixRQUFRLENBQUUsYUFBYSwwQ0FBRSxJQUFJLE1BQUksUUFBUSxhQUFSLFFBQVEsdUJBQVIsUUFBUSxDQUFFLEtBQUssQ0FBQSxLQUFJLFFBQVEsYUFBUixRQUFRLHVCQUFSLFFBQVEsQ0FBRSxFQUFFLENBQUEsSUFBSSxNQUFNLENBQUE7d0JBQzVFLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsRUFBRSxJQUFJLFlBQVksRUFBRSxDQUFBO29CQUMxQyxDQUFDO3lCQUFNLENBQUM7d0JBQ04sSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxFQUFFLElBQUksU0FBUyxFQUFFLENBQUE7b0JBQ3ZDLENBQUM7Z0JBQ0gsQ0FBQztnQkFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUN0QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUE7Z0JBQzlCLENBQUM7WUFDSCxDQUFDO1lBRUQsUUFBUSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3hDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQztvQkFDZCxNQUFNLE9BQU8sR0FBRyw4QkFBOEIsQ0FDNUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFDdkQsU0FBUyxhQUFULFNBQVMsdUJBQVQsU0FBUyxDQUFFLE1BQU0sQ0FDbEIsQ0FBQTtvQkFFRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sZ0JBQWdCLENBQUM7d0JBQzdDLFNBQVMsRUFBRSxPQUFPO3dCQUNsQixNQUFNLEVBQUUsV0FBVztxQkFDcEIsQ0FBQyxDQUFBO29CQUVGLElBQUksSUFBSSxFQUFFLENBQUM7d0JBQ1QsT0FBTzs0QkFDTCxJQUFJLEVBQUU7Z0NBQ0osUUFBUTtnQ0FDUixXQUFXLEVBQUUsaUJBQWlCLENBQUMsRUFBRTtnQ0FDakMsUUFBUSxFQUFFO29DQUNSLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSTtvQ0FDckMsbUJBQW1CLEVBQUUsSUFBSTtpQ0FDMUI7NkJBQ0Y7NEJBQ0QsS0FBSyxFQUFFLElBQUk7eUJBQ1osQ0FBQTtvQkFDSCxDQUFDO29CQUNELE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO2dCQUM5QixDQUFDO2dCQUVELEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDZixNQUFNLE9BQU8sR0FBRyw2QkFBNkIsQ0FDM0MsaUJBQWlCLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFDdkQsU0FBUyxhQUFULFNBQVMsdUJBQVQsU0FBUyxDQUFFLE9BQU8sQ0FDbkIsQ0FBQTtvQkFFRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sYUFBYSxpQ0FDdEMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLGtCQUFrQixLQUNoRCxTQUFTLEVBQUUsT0FBTyxFQUNsQixNQUFNLEVBQUUsV0FBVyxJQUNuQixDQUFBO29CQUVGLElBQUksSUFBSSxFQUFFLENBQUM7d0JBQ1QsT0FBTzs0QkFDTCxJQUFJLEVBQUU7Z0NBQ0osUUFBUTtnQ0FDUixXQUFXLEVBQUUsaUJBQWlCLENBQUMsRUFBRTtnQ0FDakMsUUFBUSxFQUFFO29DQUNSLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSTtvQ0FDckMsbUJBQW1CLEVBQUUsSUFBSTtpQ0FDMUI7NkJBQ0Y7NEJBQ0QsS0FBSyxFQUFFLElBQUk7eUJBQ1osQ0FBQTtvQkFDSCxDQUFDO29CQUNELE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO2dCQUM5QixDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDOUIsQ0FBQztZQUNELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLElBQUksZ0JBQWdCLENBQUMsK0JBQStCLEVBQUUsS0FBSyxDQUFDO2FBQ3BFLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7OztTQVdLO0lBQ0UsS0FBSyxDQUFDLE9BQU8sQ0FBaUMsRUFDbkQsV0FBVyxFQUNYLFFBQVEsRUFDUixRQUFRLEdBS1Q7UUFDQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztZQUM1QixRQUFRO1lBQ1IsV0FBVztZQUNYLFFBQVEsRUFBRSxRQUFRO1NBQ25CLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSSxLQUFLLENBQUMsYUFBYSxDQUN4QixFQUNFLFFBQVEsRUFDUixRQUFRLEVBQUUsRUFDUixJQUFJLEdBQUcsT0FBTyxNQUFNLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUMzRSxTQUFTLEdBQUcsT0FBTyxNQUFNLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFDaEYsTUFBTSxHQUNQLEdBQUcsRUFBRSxHQVFQLEVBQ0QsU0FBbUQ7UUFFbkQsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ1YsT0FBTztnQkFDTCxJQUFJLEVBQUUsSUFBSTtnQkFDVixLQUFLLEVBQUUsSUFBSSxTQUFTLENBQUMsOENBQThDLENBQUM7YUFDckUsQ0FBQTtRQUNILENBQUM7UUFDRCxJQUFJLENBQUM7WUFDSCxJQUFJLENBQUMsdUJBQXVCLEVBQUUsRUFBRSxDQUFDO2dCQUMvQixPQUFPO29CQUNMLElBQUksRUFBRSxJQUFJO29CQUNWLEtBQUssRUFBRSxJQUFJLGdCQUFnQixDQUFDLG1DQUFtQyxFQUFFLElBQUksQ0FBQztpQkFDdkUsQ0FBQTtZQUNILENBQUM7WUFFRCwrQkFBK0I7WUFDL0IsTUFBTSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUM3RTtnQkFDRSxRQUFRO2dCQUNSLFFBQVEsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7Z0JBQzdCLE1BQU07YUFDUCxFQUNELEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxDQUN2QixDQUFBO1lBRUQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsQ0FBQTtZQUM5QyxDQUFDO1lBRUQsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLGlCQUFpQixDQUFBO1lBRXRDLG9CQUFvQjtZQUNwQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQ2xCLFFBQVE7Z0JBQ1IsV0FBVyxFQUFFLGlCQUFpQixDQUFDLFdBQVc7Z0JBQzFDLFFBQVEsRUFBRTtvQkFDUixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7b0JBQ25CLElBQUk7b0JBQ0osU0FBUztvQkFDVCxtQkFBbUIsRUFBRSxRQUFRLENBQUMsbUJBQW1CO2lCQUNsRDthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDOUIsQ0FBQztZQUNELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLElBQUksZ0JBQWdCLENBQUMsa0NBQWtDLEVBQUUsS0FBSyxDQUFDO2FBQ3ZFLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0ksS0FBSyxDQUFDLFNBQVMsQ0FDcEIsRUFDRSxZQUFZLEVBQ1osUUFBUSxFQUFFLEVBQ1IsSUFBSSxHQUFHLE9BQU8sTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFDM0UsU0FBUyxHQUFHLE9BQU8sTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQ2hGLE1BQU0sR0FDUCxHQUFHLEVBQUUsR0FRUCxFQUNELFNBQTZEO1FBRTdELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNWLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLElBQUksU0FBUyxDQUFDLDRDQUE0QyxDQUFDO2FBQ25FLENBQUE7UUFDSCxDQUFDO1FBQ0QsSUFBSSxDQUFDO1lBQ0gsSUFBSSxDQUFDLHVCQUF1QixFQUFFLEVBQUUsQ0FBQztnQkFDL0IsT0FBTztvQkFDTCxJQUFJLEVBQUUsSUFBSTtvQkFDVixLQUFLLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxtQ0FBbUMsRUFBRSxJQUFJLENBQUM7aUJBQ3ZFLENBQUE7WUFDSCxDQUFDO1lBRUQsZ0JBQWdCO1lBQ2hCLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQzlELFlBQVk7YUFDYixDQUFDLENBQUE7WUFFRixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ1osTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUc7cUJBQ2xCLFdBQVcsRUFBRTtxQkFDYixJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTs7b0JBQ2hCLE9BQUEsTUFBQSxPQUFPLENBQUMsSUFBSSwwQ0FBRSxHQUFHLENBQUMsSUFBSSxDQUNwQixDQUFDLENBQUMsRUFBRSxFQUFFLENBQ0osQ0FBQyxDQUFDLFdBQVcsS0FBSyxVQUFVO3dCQUM1QixDQUFDLENBQUMsYUFBYSxLQUFLLFlBQVk7d0JBQ2hDLENBQUMsQ0FBQyxNQUFNLEtBQUssWUFBWSxDQUM1QixDQUFBO2lCQUFBLENBQ0Y7cUJBQ0EsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsUUFBUSxFQUFFLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQzNGLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsQ0FBQTtZQUMzQyxDQUFDO1lBRUQsc0NBQXNDO1lBQ3RDLE1BQU0sRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FDOUU7Z0JBQ0UsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUNuQixZQUFZLEVBQUUsTUFBTSxDQUFDLGFBQWE7Z0JBQ2xDLFFBQVEsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7Z0JBQzdCLE1BQU07YUFDUCxFQUNEO2dCQUNFLE1BQU0sRUFBRSxTQUFTO2FBQ2xCLENBQ0YsQ0FBQTtZQUVELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLENBQUE7WUFDOUMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztnQkFDbEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUNuQixXQUFXLEVBQUUsaUJBQWlCLENBQUMsV0FBVztnQkFDMUMsUUFBUSxFQUFFO29CQUNSLElBQUk7b0JBQ0osU0FBUztvQkFDVCxJQUFJLEVBQUUsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUk7b0JBQ3JDLG1CQUFtQixFQUFFLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxtQkFBbUI7aUJBQ3BFO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQTtZQUM5QixDQUFDO1lBQ0QsT0FBTztnQkFDTCxJQUFJLEVBQUUsSUFBSTtnQkFDVixLQUFLLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUM7YUFDbkUsQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgR29UcnVlQ2xpZW50IGZyb20gJy4uL0dvVHJ1ZUNsaWVudCdcbmltcG9ydCB7IGJhc2U2NFVybFRvVWludDhBcnJheSwgYnl0ZXNUb0Jhc2U2NFVSTCB9IGZyb20gJy4vYmFzZTY0dXJsJ1xuaW1wb3J0IHsgQXV0aEVycm9yLCBBdXRoVW5rbm93bkVycm9yLCBpc0F1dGhFcnJvciB9IGZyb20gJy4vZXJyb3JzJ1xuaW1wb3J0IHtcbiAgQXV0aE1GQUVucm9sbFdlYmF1dGhuUmVzcG9uc2UsXG4gIEF1dGhNRkFWZXJpZnlSZXNwb25zZSxcbiAgQXV0aE1GQVZlcmlmeVJlc3BvbnNlRGF0YSxcbiAgTUZBQ2hhbGxlbmdlV2ViYXV0aG5QYXJhbXMsXG4gIE1GQUVucm9sbFdlYmF1dGhuUGFyYW1zLFxuICBNRkFWZXJpZnlXZWJhdXRoblBhcmFtRmllbGRzLFxuICBNRkFWZXJpZnlXZWJhdXRoblBhcmFtcyxcbiAgUmVxdWVzdFJlc3VsdCxcbiAgU3RyaWN0T21pdCxcbn0gZnJvbSAnLi90eXBlcydcbmltcG9ydCB7IGlzQnJvd3NlciB9IGZyb20gJy4vaGVscGVycydcbmltcG9ydCB0eXBlIHtcbiAgQXV0aGVudGljYXRpb25DcmVkZW50aWFsLFxuICBBdXRoZW50aWNhdGlvblJlc3BvbnNlSlNPTixcbiAgQXV0aGVudGljYXRvckF0dGFjaG1lbnQsXG4gIFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmUsXG4gIFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNKU09OLFxuICBQdWJsaWNLZXlDcmVkZW50aWFsRnV0dXJlLFxuICBQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmUsXG4gIFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0pTT04sXG4gIFJlZ2lzdHJhdGlvbkNyZWRlbnRpYWwsXG4gIFJlZ2lzdHJhdGlvblJlc3BvbnNlSlNPTixcbn0gZnJvbSAnLi93ZWJhdXRobi5kb20nXG5cbmltcG9ydCB7XG4gIGlkZW50aWZ5QXV0aGVudGljYXRpb25FcnJvcixcbiAgaWRlbnRpZnlSZWdpc3RyYXRpb25FcnJvcixcbiAgaXNXZWJBdXRobkVycm9yLFxuICBXZWJBdXRobkVycm9yLFxuICBXZWJBdXRoblVua25vd25FcnJvcixcbn0gZnJvbSAnLi93ZWJhdXRobi5lcnJvcnMnXG5cbmV4cG9ydCB7IFdlYkF1dGhuRXJyb3IsIGlzV2ViQXV0aG5FcnJvciwgaWRlbnRpZnlSZWdpc3RyYXRpb25FcnJvciwgaWRlbnRpZnlBdXRoZW50aWNhdGlvbkVycm9yIH1cbi8vIFJlLWV4cG9ydCB0aGUgSlNPTiB0eXBlcyBmb3IgdXNlIGluIG90aGVyIGZpbGVzXG5leHBvcnQgdHlwZSB7IFJlZ2lzdHJhdGlvblJlc3BvbnNlSlNPTiwgQXV0aGVudGljYXRpb25SZXNwb25zZUpTT04gfVxuXG4vKipcbiAqIFdlYkF1dGhuIGFib3J0IHNlcnZpY2UgdG8gbWFuYWdlIGNlcmVtb255IGNhbmNlbGxhdGlvbi5cbiAqIEVuc3VyZXMgb25seSBvbmUgV2ViQXV0aG4gY2VyZW1vbnkgaXMgYWN0aXZlIGF0IGEgdGltZSB0byBwcmV2ZW50IFwib3BlcmF0aW9uIGFscmVhZHkgaW4gcHJvZ3Jlc3NcIiBlcnJvcnMuXG4gKlxuICogQGV4cGVyaW1lbnRhbCBUaGlzIGNsYXNzIGlzIGV4cGVyaW1lbnRhbCBhbmQgbWF5IGNoYW5nZSBpbiBmdXR1cmUgcmVsZWFzZXNcbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jc2N0bi1hdXRvbWF0aW9uLXdlYmRyaXZlci1jYXBhYmlsaXR5IFczQyBXZWJBdXRobiBTcGVjIC0gQWJvcnRpbmcgQ2VyZW1vbmllc31cbiAqL1xuZXhwb3J0IGNsYXNzIFdlYkF1dGhuQWJvcnRTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIgfCB1bmRlZmluZWRcblxuICAvKipcbiAgICogQ3JlYXRlIGFuIGFib3J0IHNpZ25hbCBmb3IgYSBuZXcgV2ViQXV0aG4gb3BlcmF0aW9uLlxuICAgKiBBdXRvbWF0aWNhbGx5IGNhbmNlbHMgYW55IGV4aXN0aW5nIG9wZXJhdGlvbi5cbiAgICpcbiAgICogQHJldHVybnMge0Fib3J0U2lnbmFsfSBTaWduYWwgdG8gcGFzcyB0byBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuY3JlYXRlKCkgb3IgLmdldCgpXG4gICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9BYm9ydFNpZ25hbCBNRE4gLSBBYm9ydFNpZ25hbH1cbiAgICovXG4gIGNyZWF0ZU5ld0Fib3J0U2lnbmFsKCk6IEFib3J0U2lnbmFsIHtcbiAgICAvLyBBYm9ydCBhbnkgZXhpc3RpbmcgY2FsbHMgdG8gbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmNyZWF0ZSgpIG9yIG5hdmlnYXRvci5jcmVkZW50aWFscy5nZXQoKVxuICAgIGlmICh0aGlzLmNvbnRyb2xsZXIpIHtcbiAgICAgIGNvbnN0IGFib3J0RXJyb3IgPSBuZXcgRXJyb3IoJ0NhbmNlbGxpbmcgZXhpc3RpbmcgV2ViQXV0aG4gQVBJIGNhbGwgZm9yIG5ldyBvbmUnKVxuICAgICAgYWJvcnRFcnJvci5uYW1lID0gJ0Fib3J0RXJyb3InXG4gICAgICB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoYWJvcnRFcnJvcilcbiAgICB9XG5cbiAgICBjb25zdCBuZXdDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXG4gICAgdGhpcy5jb250cm9sbGVyID0gbmV3Q29udHJvbGxlclxuICAgIHJldHVybiBuZXdDb250cm9sbGVyLnNpZ25hbFxuICB9XG5cbiAgLyoqXG4gICAqIE1hbnVhbGx5IGNhbmNlbCB0aGUgY3VycmVudCBXZWJBdXRobiBvcGVyYXRpb24uXG4gICAqIFVzZWZ1bCBmb3IgY2xlYW5pbmcgdXAgd2hlbiB1c2VyIGNhbmNlbHMgb3IgbmF2aWdhdGVzIGF3YXkuXG4gICAqXG4gICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9BYm9ydENvbnRyb2xsZXIvYWJvcnQgTUROIC0gQWJvcnRDb250cm9sbGVyLmFib3J0fVxuICAgKi9cbiAgY2FuY2VsQ2VyZW1vbnkoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuY29udHJvbGxlcikge1xuICAgICAgY29uc3QgYWJvcnRFcnJvciA9IG5ldyBFcnJvcignTWFudWFsbHkgY2FuY2VsbGluZyBleGlzdGluZyBXZWJBdXRobiBBUEkgY2FsbCcpXG4gICAgICBhYm9ydEVycm9yLm5hbWUgPSAnQWJvcnRFcnJvcidcbiAgICAgIHRoaXMuY29udHJvbGxlci5hYm9ydChhYm9ydEVycm9yKVxuICAgICAgdGhpcy5jb250cm9sbGVyID0gdW5kZWZpbmVkXG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogU2luZ2xldG9uIGluc3RhbmNlIHRvIGVuc3VyZSBvbmx5IG9uZSBXZWJBdXRobiBjZXJlbW9ueSBpcyBhY3RpdmUgYXQgYSB0aW1lLlxuICogVGhpcyBwcmV2ZW50cyBcIm9wZXJhdGlvbiBhbHJlYWR5IGluIHByb2dyZXNzXCIgZXJyb3JzIHdoZW4gcmV0cnlpbmcgV2ViQXV0aG4gb3BlcmF0aW9ucy5cbiAqXG4gKiBAZXhwZXJpbWVudGFsIFRoaXMgaW5zdGFuY2UgaXMgZXhwZXJpbWVudGFsIGFuZCBtYXkgY2hhbmdlIGluIGZ1dHVyZSByZWxlYXNlc1xuICovXG5leHBvcnQgY29uc3Qgd2ViQXV0aG5BYm9ydFNlcnZpY2UgPSBuZXcgV2ViQXV0aG5BYm9ydFNlcnZpY2UoKVxuXG4vKipcbiAqIFNlcnZlciByZXNwb25zZSBmb3JtYXQgZm9yIFdlYkF1dGhuIGNyZWRlbnRpYWwgY3JlYXRpb24gb3B0aW9ucy5cbiAqIFVzZXMgVzNDIHN0YW5kYXJkIEpTT04gZm9ybWF0IHdpdGggYmFzZTY0dXJsLWVuY29kZWQgYmluYXJ5IGZpZWxkcy5cbiAqL1xuZXhwb3J0IHR5cGUgU2VydmVyQ3JlZGVudGlhbENyZWF0aW9uT3B0aW9ucyA9IFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNKU09OXG5cbi8qKlxuICogU2VydmVyIHJlc3BvbnNlIGZvcm1hdCBmb3IgV2ViQXV0aG4gY3JlZGVudGlhbCByZXF1ZXN0IG9wdGlvbnMuXG4gKiBVc2VzIFczQyBzdGFuZGFyZCBKU09OIGZvcm1hdCB3aXRoIGJhc2U2NHVybC1lbmNvZGVkIGJpbmFyeSBmaWVsZHMuXG4gKi9cbmV4cG9ydCB0eXBlIFNlcnZlckNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9ucyA9IFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0pTT05cblxuLyoqXG4gKiBDb252ZXJ0IGJhc2U2NHVybCBlbmNvZGVkIHN0cmluZ3MgaW4gV2ViQXV0aG4gY3JlZGVudGlhbCBjcmVhdGlvbiBvcHRpb25zIHRvIEFycmF5QnVmZmVyc1xuICogYXMgcmVxdWlyZWQgYnkgdGhlIFdlYkF1dGhuIGJyb3dzZXIgQVBJLlxuICogU3VwcG9ydHMgYm90aCBuYXRpdmUgV2ViQXV0aG4gTGV2ZWwgMyBwYXJzZUNyZWF0aW9uT3B0aW9uc0Zyb21KU09OIGFuZCBtYW51YWwgZmFsbGJhY2suXG4gKlxuICogQHBhcmFtIHtTZXJ2ZXJDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zfSBvcHRpb25zIC0gSlNPTiBvcHRpb25zIGZyb20gc2VydmVyIHdpdGggYmFzZTY0dXJsIGVuY29kZWQgZmllbGRzXG4gKiBAcmV0dXJucyB7UHVibGljS2V5Q3JlZGVudGlhbENyZWF0aW9uT3B0aW9uc0Z1dHVyZX0gT3B0aW9ucyByZWFkeSBmb3IgbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmNyZWF0ZSgpXG4gKiBAc2VlIHtAbGluayBodHRwczovL3czYy5naXRodWIuaW8vd2ViYXV0aG4vI3NjdG4tcGFyc2VDcmVhdGlvbk9wdGlvbnNGcm9tSlNPTiBXM0MgV2ViQXV0aG4gU3BlYyAtIHBhcnNlQ3JlYXRpb25PcHRpb25zRnJvbUpTT059XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXNlcmlhbGl6ZUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnMoXG4gIG9wdGlvbnM6IFNlcnZlckNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNcbik6IFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmUge1xuICBpZiAoIW9wdGlvbnMpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0NyZWRlbnRpYWwgY3JlYXRpb24gb3B0aW9ucyBhcmUgcmVxdWlyZWQnKVxuICB9XG5cbiAgLy8gQ2hlY2sgaWYgdGhlIG5hdGl2ZSBwYXJzZUNyZWF0aW9uT3B0aW9uc0Zyb21KU09OIG1ldGhvZCBpcyBhdmFpbGFibGVcbiAgaWYgKFxuICAgIHR5cGVvZiBQdWJsaWNLZXlDcmVkZW50aWFsICE9PSAndW5kZWZpbmVkJyAmJlxuICAgICdwYXJzZUNyZWF0aW9uT3B0aW9uc0Zyb21KU09OJyBpbiBQdWJsaWNLZXlDcmVkZW50aWFsICYmXG4gICAgdHlwZW9mIChQdWJsaWNLZXlDcmVkZW50aWFsIGFzIHVua25vd24gYXMgUHVibGljS2V5Q3JlZGVudGlhbEZ1dHVyZSlcbiAgICAgIC5wYXJzZUNyZWF0aW9uT3B0aW9uc0Zyb21KU09OID09PSAnZnVuY3Rpb24nXG4gICkge1xuICAgIC8vIFVzZSB0aGUgbmF0aXZlIFdlYkF1dGhuIExldmVsIDMgbWV0aG9kXG4gICAgcmV0dXJuIChcbiAgICAgIFB1YmxpY0tleUNyZWRlbnRpYWwgYXMgdW5rbm93biBhcyBQdWJsaWNLZXlDcmVkZW50aWFsRnV0dXJlXG4gICAgKS5wYXJzZUNyZWF0aW9uT3B0aW9uc0Zyb21KU09OKFxuICAgICAgLyoqIHdlIGFzc2VydCB0aGUgb3B0aW9ucyBoZXJlIGFzIHR5cGVzY3JpcHQgc3RpbGwgZG9lc24ndCBrbm93IGFib3V0IGZ1dHVyZSB3ZWJhdXRobiB0eXBlcyAqL1xuICAgICAgb3B0aW9ucyBhcyBhbnlcbiAgICApIGFzIFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmVcbiAgfVxuXG4gIC8vIEZhbGxiYWNrIHRvIG1hbnVhbCBwYXJzaW5nIGZvciBicm93c2VycyB0aGF0IGRvbid0IHN1cHBvcnQgdGhlIG5hdGl2ZSBtZXRob2RcbiAgLy8gRGVzdHJ1Y3R1cmUgdG8gc2VwYXJhdGUgZmllbGRzIHRoYXQgbmVlZCB0cmFuc2Zvcm1hdGlvblxuICBjb25zdCB7IGNoYWxsZW5nZTogY2hhbGxlbmdlU3RyLCB1c2VyOiB1c2VyT3B0cywgZXhjbHVkZUNyZWRlbnRpYWxzLCAuLi5yZXN0T3B0aW9ucyB9ID0gb3B0aW9uc1xuXG4gIC8vIENvbnZlcnQgY2hhbGxlbmdlIGZyb20gYmFzZTY0dXJsIHRvIEFycmF5QnVmZmVyXG4gIGNvbnN0IGNoYWxsZW5nZSA9IGJhc2U2NFVybFRvVWludDhBcnJheShjaGFsbGVuZ2VTdHIpLmJ1ZmZlciBhcyBBcnJheUJ1ZmZlclxuXG4gIC8vIENvbnZlcnQgdXNlci5pZCBmcm9tIGJhc2U2NHVybCB0byBBcnJheUJ1ZmZlclxuICBjb25zdCB1c2VyOiBQdWJsaWNLZXlDcmVkZW50aWFsVXNlckVudGl0eSA9IHtcbiAgICAuLi51c2VyT3B0cyxcbiAgICBpZDogYmFzZTY0VXJsVG9VaW50OEFycmF5KHVzZXJPcHRzLmlkKS5idWZmZXIgYXMgQXJyYXlCdWZmZXIsXG4gIH1cblxuICAvLyBCdWlsZCB0aGUgcmVzdWx0IG9iamVjdFxuICBjb25zdCByZXN1bHQ6IFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmUgPSB7XG4gICAgLi4ucmVzdE9wdGlvbnMsXG4gICAgY2hhbGxlbmdlLFxuICAgIHVzZXIsXG4gIH1cblxuICAvLyBPbmx5IGFkZCBleGNsdWRlQ3JlZGVudGlhbHMgaWYgaXQgZXhpc3RzXG4gIGlmIChleGNsdWRlQ3JlZGVudGlhbHMgJiYgZXhjbHVkZUNyZWRlbnRpYWxzLmxlbmd0aCA+IDApIHtcbiAgICByZXN1bHQuZXhjbHVkZUNyZWRlbnRpYWxzID0gbmV3IEFycmF5KGV4Y2x1ZGVDcmVkZW50aWFscy5sZW5ndGgpXG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGV4Y2x1ZGVDcmVkZW50aWFscy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgY3JlZCA9IGV4Y2x1ZGVDcmVkZW50aWFsc1tpXVxuICAgICAgcmVzdWx0LmV4Y2x1ZGVDcmVkZW50aWFsc1tpXSA9IHtcbiAgICAgICAgLi4uY3JlZCxcbiAgICAgICAgaWQ6IGJhc2U2NFVybFRvVWludDhBcnJheShjcmVkLmlkKS5idWZmZXIsXG4gICAgICAgIHR5cGU6IGNyZWQudHlwZSB8fCAncHVibGljLWtleScsXG4gICAgICAgIC8vIENhc3QgdHJhbnNwb3J0cyB0byBoYW5kbGUgZnV0dXJlIHRyYW5zcG9ydCB0eXBlcyBsaWtlIFwiY2FibGVcIlxuICAgICAgICB0cmFuc3BvcnRzOiBjcmVkLnRyYW5zcG9ydHMsXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG4vKipcbiAqIENvbnZlcnQgYmFzZTY0dXJsIGVuY29kZWQgc3RyaW5ncyBpbiBXZWJBdXRobiBjcmVkZW50aWFsIHJlcXVlc3Qgb3B0aW9ucyB0byBBcnJheUJ1ZmZlcnNcbiAqIGFzIHJlcXVpcmVkIGJ5IHRoZSBXZWJBdXRobiBicm93c2VyIEFQSS5cbiAqIFN1cHBvcnRzIGJvdGggbmF0aXZlIFdlYkF1dGhuIExldmVsIDMgcGFyc2VSZXF1ZXN0T3B0aW9uc0Zyb21KU09OIGFuZCBtYW51YWwgZmFsbGJhY2suXG4gKlxuICogQHBhcmFtIHtTZXJ2ZXJDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnN9IG9wdGlvbnMgLSBKU09OIG9wdGlvbnMgZnJvbSBzZXJ2ZXIgd2l0aCBiYXNlNjR1cmwgZW5jb2RlZCBmaWVsZHNcbiAqIEByZXR1cm5zIHtQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmV9IE9wdGlvbnMgcmVhZHkgZm9yIG5hdmlnYXRvci5jcmVkZW50aWFscy5nZXQoKVxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3dlYmF1dGhuLyNzY3RuLXBhcnNlUmVxdWVzdE9wdGlvbnNGcm9tSlNPTiBXM0MgV2ViQXV0aG4gU3BlYyAtIHBhcnNlUmVxdWVzdE9wdGlvbnNGcm9tSlNPTn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlc2VyaWFsaXplQ3JlZGVudGlhbFJlcXVlc3RPcHRpb25zKFxuICBvcHRpb25zOiBTZXJ2ZXJDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNcbik6IFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0Z1dHVyZSB7XG4gIGlmICghb3B0aW9ucykge1xuICAgIHRocm93IG5ldyBFcnJvcignQ3JlZGVudGlhbCByZXF1ZXN0IG9wdGlvbnMgYXJlIHJlcXVpcmVkJylcbiAgfVxuXG4gIC8vIENoZWNrIGlmIHRoZSBuYXRpdmUgcGFyc2VSZXF1ZXN0T3B0aW9uc0Zyb21KU09OIG1ldGhvZCBpcyBhdmFpbGFibGVcbiAgaWYgKFxuICAgIHR5cGVvZiBQdWJsaWNLZXlDcmVkZW50aWFsICE9PSAndW5kZWZpbmVkJyAmJlxuICAgICdwYXJzZVJlcXVlc3RPcHRpb25zRnJvbUpTT04nIGluIFB1YmxpY0tleUNyZWRlbnRpYWwgJiZcbiAgICB0eXBlb2YgKFB1YmxpY0tleUNyZWRlbnRpYWwgYXMgdW5rbm93biBhcyBQdWJsaWNLZXlDcmVkZW50aWFsRnV0dXJlKVxuICAgICAgLnBhcnNlUmVxdWVzdE9wdGlvbnNGcm9tSlNPTiA9PT0gJ2Z1bmN0aW9uJ1xuICApIHtcbiAgICAvLyBVc2UgdGhlIG5hdGl2ZSBXZWJBdXRobiBMZXZlbCAzIG1ldGhvZFxuICAgIHJldHVybiAoXG4gICAgICBQdWJsaWNLZXlDcmVkZW50aWFsIGFzIHVua25vd24gYXMgUHVibGljS2V5Q3JlZGVudGlhbEZ1dHVyZVxuICAgICkucGFyc2VSZXF1ZXN0T3B0aW9uc0Zyb21KU09OKG9wdGlvbnMpIGFzIFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0Z1dHVyZVxuICB9XG5cbiAgLy8gRmFsbGJhY2sgdG8gbWFudWFsIHBhcnNpbmcgZm9yIGJyb3dzZXJzIHRoYXQgZG9uJ3Qgc3VwcG9ydCB0aGUgbmF0aXZlIG1ldGhvZFxuICAvLyBEZXN0cnVjdHVyZSB0byBzZXBhcmF0ZSBmaWVsZHMgdGhhdCBuZWVkIHRyYW5zZm9ybWF0aW9uXG4gIGNvbnN0IHsgY2hhbGxlbmdlOiBjaGFsbGVuZ2VTdHIsIGFsbG93Q3JlZGVudGlhbHMsIC4uLnJlc3RPcHRpb25zIH0gPSBvcHRpb25zXG5cbiAgLy8gQ29udmVydCBjaGFsbGVuZ2UgZnJvbSBiYXNlNjR1cmwgdG8gQXJyYXlCdWZmZXJcbiAgY29uc3QgY2hhbGxlbmdlID0gYmFzZTY0VXJsVG9VaW50OEFycmF5KGNoYWxsZW5nZVN0cikuYnVmZmVyIGFzIEFycmF5QnVmZmVyXG5cbiAgLy8gQnVpbGQgdGhlIHJlc3VsdCBvYmplY3RcbiAgY29uc3QgcmVzdWx0OiBQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmUgPSB7XG4gICAgLi4ucmVzdE9wdGlvbnMsXG4gICAgY2hhbGxlbmdlLFxuICB9XG5cbiAgLy8gT25seSBhZGQgYWxsb3dDcmVkZW50aWFscyBpZiBpdCBleGlzdHNcbiAgaWYgKGFsbG93Q3JlZGVudGlhbHMgJiYgYWxsb3dDcmVkZW50aWFscy5sZW5ndGggPiAwKSB7XG4gICAgcmVzdWx0LmFsbG93Q3JlZGVudGlhbHMgPSBuZXcgQXJyYXkoYWxsb3dDcmVkZW50aWFscy5sZW5ndGgpXG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFsbG93Q3JlZGVudGlhbHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGNyZWQgPSBhbGxvd0NyZWRlbnRpYWxzW2ldXG4gICAgICByZXN1bHQuYWxsb3dDcmVkZW50aWFsc1tpXSA9IHtcbiAgICAgICAgLi4uY3JlZCxcbiAgICAgICAgaWQ6IGJhc2U2NFVybFRvVWludDhBcnJheShjcmVkLmlkKS5idWZmZXIsXG4gICAgICAgIHR5cGU6IGNyZWQudHlwZSB8fCAncHVibGljLWtleScsXG4gICAgICAgIC8vIENhc3QgdHJhbnNwb3J0cyB0byBoYW5kbGUgZnV0dXJlIHRyYW5zcG9ydCB0eXBlcyBsaWtlIFwiY2FibGVcIlxuICAgICAgICB0cmFuc3BvcnRzOiBjcmVkLnRyYW5zcG9ydHMsXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG4vKipcbiAqIFNlcnZlciBmb3JtYXQgZm9yIGNyZWRlbnRpYWwgcmVzcG9uc2Ugd2l0aCBiYXNlNjR1cmwtZW5jb2RlZCBiaW5hcnkgZmllbGRzXG4gKiBDYW4gYmUgZWl0aGVyIGEgcmVnaXN0cmF0aW9uIG9yIGF1dGhlbnRpY2F0aW9uIHJlc3BvbnNlXG4gKi9cbmV4cG9ydCB0eXBlIFNlcnZlckNyZWRlbnRpYWxSZXNwb25zZSA9IFJlZ2lzdHJhdGlvblJlc3BvbnNlSlNPTiB8IEF1dGhlbnRpY2F0aW9uUmVzcG9uc2VKU09OXG5cbi8qKlxuICogQ29udmVydCBhIHJlZ2lzdHJhdGlvbi9lbnJvbGxtZW50IGNyZWRlbnRpYWwgcmVzcG9uc2UgdG8gc2VydmVyIGZvcm1hdC5cbiAqIFNlcmlhbGl6ZXMgYmluYXJ5IGZpZWxkcyB0byBiYXNlNjR1cmwgZm9yIEpTT04gdHJhbnNtaXNzaW9uLlxuICogU3VwcG9ydHMgYm90aCBuYXRpdmUgV2ViQXV0aG4gTGV2ZWwgMyB0b0pTT04gYW5kIG1hbnVhbCBmYWxsYmFjay5cbiAqXG4gKiBAcGFyYW0ge1JlZ2lzdHJhdGlvbkNyZWRlbnRpYWx9IGNyZWRlbnRpYWwgLSBDcmVkZW50aWFsIGZyb20gbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmNyZWF0ZSgpXG4gKiBAcmV0dXJucyB7UmVnaXN0cmF0aW9uUmVzcG9uc2VKU09OfSBKU09OLXNlcmlhbGl6YWJsZSBjcmVkZW50aWFsIGZvciBzZXJ2ZXJcbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jZG9tLXB1YmxpY2tleWNyZWRlbnRpYWwtdG9qc29uIFczQyBXZWJBdXRobiBTcGVjIC0gdG9KU09OfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplQ3JlZGVudGlhbENyZWF0aW9uUmVzcG9uc2UoXG4gIGNyZWRlbnRpYWw6IFJlZ2lzdHJhdGlvbkNyZWRlbnRpYWxcbik6IFJlZ2lzdHJhdGlvblJlc3BvbnNlSlNPTiB7XG4gIC8vIENoZWNrIGlmIHRoZSBjcmVkZW50aWFsIGluc3RhbmNlIGhhcyB0aGUgdG9KU09OIG1ldGhvZFxuICBpZiAoJ3RvSlNPTicgaW4gY3JlZGVudGlhbCAmJiB0eXBlb2YgY3JlZGVudGlhbC50b0pTT04gPT09ICdmdW5jdGlvbicpIHtcbiAgICAvLyBVc2UgdGhlIG5hdGl2ZSBXZWJBdXRobiBMZXZlbCAzIG1ldGhvZFxuICAgIHJldHVybiAoY3JlZGVudGlhbCBhcyBSZWdpc3RyYXRpb25DcmVkZW50aWFsKS50b0pTT04oKVxuICB9XG4gIGNvbnN0IGNyZWRlbnRpYWxXaXRoQXR0YWNobWVudCA9IGNyZWRlbnRpYWwgYXMgUHVibGljS2V5Q3JlZGVudGlhbCAmIHtcbiAgICByZXNwb25zZTogQXV0aGVudGljYXRvckF0dGVzdGF0aW9uUmVzcG9uc2VcbiAgICBhdXRoZW50aWNhdG9yQXR0YWNobWVudD86IHN0cmluZyB8IG51bGxcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaWQ6IGNyZWRlbnRpYWwuaWQsXG4gICAgcmF3SWQ6IGNyZWRlbnRpYWwuaWQsXG4gICAgcmVzcG9uc2U6IHtcbiAgICAgIGF0dGVzdGF0aW9uT2JqZWN0OiBieXRlc1RvQmFzZTY0VVJMKG5ldyBVaW50OEFycmF5KGNyZWRlbnRpYWwucmVzcG9uc2UuYXR0ZXN0YXRpb25PYmplY3QpKSxcbiAgICAgIGNsaWVudERhdGFKU09OOiBieXRlc1RvQmFzZTY0VVJMKG5ldyBVaW50OEFycmF5KGNyZWRlbnRpYWwucmVzcG9uc2UuY2xpZW50RGF0YUpTT04pKSxcbiAgICB9LFxuICAgIHR5cGU6ICdwdWJsaWMta2V5JyxcbiAgICBjbGllbnRFeHRlbnNpb25SZXN1bHRzOiBjcmVkZW50aWFsLmdldENsaWVudEV4dGVuc2lvblJlc3VsdHMoKSxcbiAgICAvLyBDb252ZXJ0IG51bGwgdG8gdW5kZWZpbmVkIGFuZCBjYXN0IHRvIEF1dGhlbnRpY2F0b3JBdHRhY2htZW50IHR5cGVcbiAgICBhdXRoZW50aWNhdG9yQXR0YWNobWVudDogKGNyZWRlbnRpYWxXaXRoQXR0YWNobWVudC5hdXRoZW50aWNhdG9yQXR0YWNobWVudCA/PyB1bmRlZmluZWQpIGFzXG4gICAgICB8IEF1dGhlbnRpY2F0b3JBdHRhY2htZW50XG4gICAgICB8IHVuZGVmaW5lZCxcbiAgfVxufVxuXG4vKipcbiAqIENvbnZlcnQgYW4gYXV0aGVudGljYXRpb24vdmVyaWZpY2F0aW9uIGNyZWRlbnRpYWwgcmVzcG9uc2UgdG8gc2VydmVyIGZvcm1hdC5cbiAqIFNlcmlhbGl6ZXMgYmluYXJ5IGZpZWxkcyB0byBiYXNlNjR1cmwgZm9yIEpTT04gdHJhbnNtaXNzaW9uLlxuICogU3VwcG9ydHMgYm90aCBuYXRpdmUgV2ViQXV0aG4gTGV2ZWwgMyB0b0pTT04gYW5kIG1hbnVhbCBmYWxsYmFjay5cbiAqXG4gKiBAcGFyYW0ge0F1dGhlbnRpY2F0aW9uQ3JlZGVudGlhbH0gY3JlZGVudGlhbCAtIENyZWRlbnRpYWwgZnJvbSBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuZ2V0KClcbiAqIEByZXR1cm5zIHtBdXRoZW50aWNhdGlvblJlc3BvbnNlSlNPTn0gSlNPTi1zZXJpYWxpemFibGUgY3JlZGVudGlhbCBmb3Igc2VydmVyXG4gKiBAc2VlIHtAbGluayBodHRwczovL3czYy5naXRodWIuaW8vd2ViYXV0aG4vI2RvbS1wdWJsaWNrZXljcmVkZW50aWFsLXRvanNvbiBXM0MgV2ViQXV0aG4gU3BlYyAtIHRvSlNPTn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlcmlhbGl6ZUNyZWRlbnRpYWxSZXF1ZXN0UmVzcG9uc2UoXG4gIGNyZWRlbnRpYWw6IEF1dGhlbnRpY2F0aW9uQ3JlZGVudGlhbFxuKTogQXV0aGVudGljYXRpb25SZXNwb25zZUpTT04ge1xuICAvLyBDaGVjayBpZiB0aGUgY3JlZGVudGlhbCBpbnN0YW5jZSBoYXMgdGhlIHRvSlNPTiBtZXRob2RcbiAgaWYgKCd0b0pTT04nIGluIGNyZWRlbnRpYWwgJiYgdHlwZW9mIGNyZWRlbnRpYWwudG9KU09OID09PSAnZnVuY3Rpb24nKSB7XG4gICAgLy8gVXNlIHRoZSBuYXRpdmUgV2ViQXV0aG4gTGV2ZWwgMyBtZXRob2RcbiAgICByZXR1cm4gKGNyZWRlbnRpYWwgYXMgQXV0aGVudGljYXRpb25DcmVkZW50aWFsKS50b0pTT04oKVxuICB9XG5cbiAgLy8gRmFsbGJhY2sgdG8gbWFudWFsIGNvbnZlcnNpb24gZm9yIGJyb3dzZXJzIHRoYXQgZG9uJ3Qgc3VwcG9ydCB0b0pTT05cbiAgLy8gQWNjZXNzIGF1dGhlbnRpY2F0b3JBdHRhY2htZW50IHZpYSB0eXBlIGFzc2VydGlvbiB0byBoYW5kbGUgVHlwZVNjcmlwdCB2ZXJzaW9uIGRpZmZlcmVuY2VzXG4gIC8vIEBzaW1wbGV3ZWJhdXRobi90eXBlcyBpbmNsdWRlcyB0aGlzIHByb3BlcnR5IGJ1dCBiYXNlIFR5cGVTY3JpcHQgNC43LjQgZG9lc24ndFxuICBjb25zdCBjcmVkZW50aWFsV2l0aEF0dGFjaG1lbnQgPSBjcmVkZW50aWFsIGFzIFB1YmxpY0tleUNyZWRlbnRpYWwgJiB7XG4gICAgcmVzcG9uc2U6IEF1dGhlbnRpY2F0b3JBc3NlcnRpb25SZXNwb25zZVxuICAgIGF1dGhlbnRpY2F0b3JBdHRhY2htZW50Pzogc3RyaW5nIHwgbnVsbFxuICB9XG5cbiAgY29uc3QgY2xpZW50RXh0ZW5zaW9uUmVzdWx0cyA9IGNyZWRlbnRpYWwuZ2V0Q2xpZW50RXh0ZW5zaW9uUmVzdWx0cygpXG4gIGNvbnN0IGFzc2VydGlvblJlc3BvbnNlID0gY3JlZGVudGlhbC5yZXNwb25zZVxuXG4gIHJldHVybiB7XG4gICAgaWQ6IGNyZWRlbnRpYWwuaWQsXG4gICAgcmF3SWQ6IGNyZWRlbnRpYWwuaWQsIC8vIFczQyBzcGVjIGV4cGVjdHMgcmF3SWQgdG8gbWF0Y2ggaWQgZm9yIEpTT04gZm9ybWF0XG4gICAgcmVzcG9uc2U6IHtcbiAgICAgIGF1dGhlbnRpY2F0b3JEYXRhOiBieXRlc1RvQmFzZTY0VVJMKG5ldyBVaW50OEFycmF5KGFzc2VydGlvblJlc3BvbnNlLmF1dGhlbnRpY2F0b3JEYXRhKSksXG4gICAgICBjbGllbnREYXRhSlNPTjogYnl0ZXNUb0Jhc2U2NFVSTChuZXcgVWludDhBcnJheShhc3NlcnRpb25SZXNwb25zZS5jbGllbnREYXRhSlNPTikpLFxuICAgICAgc2lnbmF0dXJlOiBieXRlc1RvQmFzZTY0VVJMKG5ldyBVaW50OEFycmF5KGFzc2VydGlvblJlc3BvbnNlLnNpZ25hdHVyZSkpLFxuICAgICAgdXNlckhhbmRsZTogYXNzZXJ0aW9uUmVzcG9uc2UudXNlckhhbmRsZVxuICAgICAgICA/IGJ5dGVzVG9CYXNlNjRVUkwobmV3IFVpbnQ4QXJyYXkoYXNzZXJ0aW9uUmVzcG9uc2UudXNlckhhbmRsZSkpXG4gICAgICAgIDogdW5kZWZpbmVkLFxuICAgIH0sXG4gICAgdHlwZTogJ3B1YmxpYy1rZXknLFxuICAgIGNsaWVudEV4dGVuc2lvblJlc3VsdHMsXG4gICAgLy8gQ29udmVydCBudWxsIHRvIHVuZGVmaW5lZCBhbmQgY2FzdCB0byBBdXRoZW50aWNhdG9yQXR0YWNobWVudCB0eXBlXG4gICAgYXV0aGVudGljYXRvckF0dGFjaG1lbnQ6IChjcmVkZW50aWFsV2l0aEF0dGFjaG1lbnQuYXV0aGVudGljYXRvckF0dGFjaG1lbnQgPz8gdW5kZWZpbmVkKSBhc1xuICAgICAgfCBBdXRoZW50aWNhdG9yQXR0YWNobWVudFxuICAgICAgfCB1bmRlZmluZWQsXG4gIH1cbn1cblxuLyoqXG4gKiBBIHNpbXBsZSB0ZXN0IHRvIGRldGVybWluZSBpZiBhIGhvc3RuYW1lIGlzIGEgcHJvcGVybHktZm9ybWF0dGVkIGRvbWFpbiBuYW1lLlxuICogQ29uc2lkZXJzIGxvY2FsaG9zdCB2YWxpZCBmb3IgZGV2ZWxvcG1lbnQgZW52aXJvbm1lbnRzLlxuICpcbiAqIEEgXCJ2YWxpZCBkb21haW5cIiBpcyBkZWZpbmVkIGhlcmU6IGh0dHBzOi8vdXJsLnNwZWMud2hhdHdnLm9yZy8jdmFsaWQtZG9tYWluXG4gKlxuICogUmVnZXggc291cmNlZCBmcm9tIGhlcmU6XG4gKiBodHRwczovL3d3dy5vcmVpbGx5LmNvbS9saWJyYXJ5L3ZpZXcvcmVndWxhci1leHByZXNzaW9ucy1jb29rYm9vay85NzgxNDQ5MzI3NDUzL2NoMDhzMTUuaHRtbFxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBob3N0bmFtZSAtIFRoZSBob3N0bmFtZSB0byB2YWxpZGF0ZVxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsaWQgZG9tYWluIG9yIGxvY2FsaG9zdFxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly91cmwuc3BlYy53aGF0d2cub3JnLyN2YWxpZC1kb21haW4gV0hBVFdHIFVSTCBTcGVjIC0gVmFsaWQgRG9tYWlufVxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNWYWxpZERvbWFpbihob3N0bmFtZTogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgLy8gQ29uc2lkZXIgbG9jYWxob3N0IHZhbGlkIGFzIHdlbGwgc2luY2UgaXQncyBva2F5IHdydCBTZWN1cmUgQ29udGV4dHNcbiAgICBob3N0bmFtZSA9PT0gJ2xvY2FsaG9zdCcgfHwgL14oW2EtejAtOV0rKC1bYS16MC05XSspKlxcLikrW2Etel17Mix9JC9pLnRlc3QoaG9zdG5hbWUpXG4gIClcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgdGhlIGJyb3dzZXIgaXMgY2FwYWJsZSBvZiBXZWJBdXRobi5cbiAqIENoZWNrcyBmb3IgbmVjZXNzYXJ5IFdlYiBBUElzOiBQdWJsaWNLZXlDcmVkZW50aWFsIGFuZCBDcmVkZW50aWFsIE1hbmFnZW1lbnQuXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgYnJvd3NlciBzdXBwb3J0cyBXZWJBdXRoblxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1B1YmxpY0tleUNyZWRlbnRpYWwjYnJvd3Nlcl9jb21wYXRpYmlsaXR5IE1ETiAtIFB1YmxpY0tleUNyZWRlbnRpYWwgQnJvd3NlciBDb21wYXRpYmlsaXR5fVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnJvd3NlclN1cHBvcnRzV2ViQXV0aG4oKTogYm9vbGVhbiB7XG4gIHJldHVybiAhIShcbiAgICBpc0Jyb3dzZXIoKSAmJlxuICAgICdQdWJsaWNLZXlDcmVkZW50aWFsJyBpbiB3aW5kb3cgJiZcbiAgICB3aW5kb3cuUHVibGljS2V5Q3JlZGVudGlhbCAmJlxuICAgICdjcmVkZW50aWFscycgaW4gbmF2aWdhdG9yICYmXG4gICAgdHlwZW9mIG5hdmlnYXRvcj8uY3JlZGVudGlhbHM/LmNyZWF0ZSA9PT0gJ2Z1bmN0aW9uJyAmJlxuICAgIHR5cGVvZiBuYXZpZ2F0b3I/LmNyZWRlbnRpYWxzPy5nZXQgPT09ICdmdW5jdGlvbidcbiAgKVxufVxuXG4vKipcbiAqIENyZWF0ZSBhIFdlYkF1dGhuIGNyZWRlbnRpYWwgdXNpbmcgdGhlIGJyb3dzZXIncyBjcmVkZW50aWFscyBBUEkuXG4gKiBXcmFwcyBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuY3JlYXRlKCkgd2l0aCBlcnJvciBoYW5kbGluZy5cbiAqXG4gKiBAcGFyYW0ge0NyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnN9IG9wdGlvbnMgLSBPcHRpb25zIGluY2x1ZGluZyBwdWJsaWNLZXkgcGFyYW1ldGVyc1xuICogQHJldHVybnMge1Byb21pc2U8UmVxdWVzdFJlc3VsdDxSZWdpc3RyYXRpb25DcmVkZW50aWFsLCBXZWJBdXRobkVycm9yPj59IENyZWF0ZWQgY3JlZGVudGlhbCBvciBlcnJvclxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3dlYmF1dGhuLyNzY3RuLWNyZWF0ZUNyZWRlbnRpYWwgVzNDIFdlYkF1dGhuIFNwZWMgLSBDcmVhdGUgQ3JlZGVudGlhbH1cbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DcmVkZW50aWFsc0NvbnRhaW5lci9jcmVhdGUgTUROIC0gY3JlZGVudGlhbHMuY3JlYXRlfVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQ3JlZGVudGlhbChcbiAgb3B0aW9uczogU3RyaWN0T21pdDxDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zLCAncHVibGljS2V5Jz4gJiB7XG4gICAgcHVibGljS2V5OiBQdWJsaWNLZXlDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zRnV0dXJlXG4gIH1cbik6IFByb21pc2U8UmVxdWVzdFJlc3VsdDxSZWdpc3RyYXRpb25DcmVkZW50aWFsLCBXZWJBdXRobkVycm9yPj4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmNyZWF0ZShcbiAgICAgIC8qKiB3ZSBhc3NlcnQgdGhlIHR5cGUgaGVyZSB1bnRpbCB0eXBlc2NyaXB0IHR5cGVzIGFyZSB1cGRhdGVkICovXG4gICAgICBvcHRpb25zIGFzIFBhcmFtZXRlcnM8dHlwZW9mIG5hdmlnYXRvci5jcmVkZW50aWFscy5jcmVhdGU+WzBdXG4gICAgKVxuICAgIGlmICghcmVzcG9uc2UpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGE6IG51bGwsXG4gICAgICAgIGVycm9yOiBuZXcgV2ViQXV0aG5Vbmtub3duRXJyb3IoJ0VtcHR5IGNyZWRlbnRpYWwgcmVzcG9uc2UnLCByZXNwb25zZSksXG4gICAgICB9XG4gICAgfVxuICAgIGlmICghKHJlc3BvbnNlIGluc3RhbmNlb2YgUHVibGljS2V5Q3JlZGVudGlhbCkpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGE6IG51bGwsXG4gICAgICAgIGVycm9yOiBuZXcgV2ViQXV0aG5Vbmtub3duRXJyb3IoJ0Jyb3dzZXIgcmV0dXJuZWQgdW5leHBlY3RlZCBjcmVkZW50aWFsIHR5cGUnLCByZXNwb25zZSksXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IGRhdGE6IHJlc3BvbnNlIGFzIFJlZ2lzdHJhdGlvbkNyZWRlbnRpYWwsIGVycm9yOiBudWxsIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGRhdGE6IG51bGwsXG4gICAgICBlcnJvcjogaWRlbnRpZnlSZWdpc3RyYXRpb25FcnJvcih7XG4gICAgICAgIGVycm9yOiBlcnIgYXMgRXJyb3IsXG4gICAgICAgIG9wdGlvbnMsXG4gICAgICB9KSxcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBHZXQgYSBXZWJBdXRobiBjcmVkZW50aWFsIHVzaW5nIHRoZSBicm93c2VyJ3MgY3JlZGVudGlhbHMgQVBJLlxuICogV3JhcHMgbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmdldCgpIHdpdGggZXJyb3IgaGFuZGxpbmcuXG4gKlxuICogQHBhcmFtIHtDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnN9IG9wdGlvbnMgLSBPcHRpb25zIGluY2x1ZGluZyBwdWJsaWNLZXkgcGFyYW1ldGVyc1xuICogQHJldHVybnMge1Byb21pc2U8UmVxdWVzdFJlc3VsdDxBdXRoZW50aWNhdGlvbkNyZWRlbnRpYWwsIFdlYkF1dGhuRXJyb3I+Pn0gUmV0cmlldmVkIGNyZWRlbnRpYWwgb3IgZXJyb3JcbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jc2N0bi1nZXRBc3NlcnRpb24gVzNDIFdlYkF1dGhuIFNwZWMgLSBHZXQgQXNzZXJ0aW9ufVxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0NyZWRlbnRpYWxzQ29udGFpbmVyL2dldCBNRE4gLSBjcmVkZW50aWFscy5nZXR9XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDcmVkZW50aWFsKFxuICBvcHRpb25zOiBTdHJpY3RPbWl0PENyZWRlbnRpYWxSZXF1ZXN0T3B0aW9ucywgJ3B1YmxpY0tleSc+ICYge1xuICAgIHB1YmxpY0tleTogUHVibGljS2V5Q3JlZGVudGlhbFJlcXVlc3RPcHRpb25zRnV0dXJlXG4gIH1cbik6IFByb21pc2U8UmVxdWVzdFJlc3VsdDxBdXRoZW50aWNhdGlvbkNyZWRlbnRpYWwsIFdlYkF1dGhuRXJyb3I+PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuZ2V0KFxuICAgICAgLyoqIHdlIGFzc2VydCB0aGUgdHlwZSBoZXJlIHVudGlsIHR5cGVzY3JpcHQgdHlwZXMgYXJlIHVwZGF0ZWQgKi9cbiAgICAgIG9wdGlvbnMgYXMgUGFyYW1ldGVyczx0eXBlb2YgbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmdldD5bMF1cbiAgICApXG4gICAgaWYgKCFyZXNwb25zZSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgZXJyb3I6IG5ldyBXZWJBdXRoblVua25vd25FcnJvcignRW1wdHkgY3JlZGVudGlhbCByZXNwb25zZScsIHJlc3BvbnNlKSxcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCEocmVzcG9uc2UgaW5zdGFuY2VvZiBQdWJsaWNLZXlDcmVkZW50aWFsKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgZXJyb3I6IG5ldyBXZWJBdXRoblVua25vd25FcnJvcignQnJvd3NlciByZXR1cm5lZCB1bmV4cGVjdGVkIGNyZWRlbnRpYWwgdHlwZScsIHJlc3BvbnNlKSxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHsgZGF0YTogcmVzcG9uc2UgYXMgQXV0aGVudGljYXRpb25DcmVkZW50aWFsLCBlcnJvcjogbnVsbCB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiB7XG4gICAgICBkYXRhOiBudWxsLFxuICAgICAgZXJyb3I6IGlkZW50aWZ5QXV0aGVudGljYXRpb25FcnJvcih7XG4gICAgICAgIGVycm9yOiBlcnIgYXMgRXJyb3IsXG4gICAgICAgIG9wdGlvbnMsXG4gICAgICB9KSxcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfQ1JFQVRJT05fT1BUSU9OUzogUGFydGlhbDxQdWJsaWNLZXlDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zRnV0dXJlPiA9IHtcbiAgaGludHM6IFsnc2VjdXJpdHkta2V5J10sXG4gIGF1dGhlbnRpY2F0b3JTZWxlY3Rpb246IHtcbiAgICBhdXRoZW50aWNhdG9yQXR0YWNobWVudDogJ2Nyb3NzLXBsYXRmb3JtJyxcbiAgICByZXF1aXJlUmVzaWRlbnRLZXk6IGZhbHNlLFxuICAgIC8qKiBzZXQgdG8gcHJlZmVycmVkIGJlY2F1c2Ugb2xkZXIgeXViaWtleXMgZG9uJ3QgaGF2ZSBQSU4vQmlvbWV0cmljICovXG4gICAgdXNlclZlcmlmaWNhdGlvbjogJ3ByZWZlcnJlZCcsXG4gICAgcmVzaWRlbnRLZXk6ICdkaXNjb3VyYWdlZCcsXG4gIH0sXG4gIGF0dGVzdGF0aW9uOiAnZGlyZWN0Jyxcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfUkVRVUVTVF9PUFRJT05TOiBQYXJ0aWFsPFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0Z1dHVyZT4gPSB7XG4gIC8qKiBzZXQgdG8gcHJlZmVycmVkIGJlY2F1c2Ugb2xkZXIgeXViaWtleXMgZG9uJ3QgaGF2ZSBQSU4vQmlvbWV0cmljICovXG4gIHVzZXJWZXJpZmljYXRpb246ICdwcmVmZXJyZWQnLFxuICBoaW50czogWydzZWN1cml0eS1rZXknXSxcbiAgYXR0ZXN0YXRpb246ICdkaXJlY3QnLFxufVxuXG5mdW5jdGlvbiBkZWVwTWVyZ2U8VD4oLi4uc291cmNlczogUGFydGlhbDxUPltdKTogVCB7XG4gIGNvbnN0IGlzT2JqZWN0ID0gKHZhbDogdW5rbm93bik6IHZhbCBpcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9PlxuICAgIHZhbCAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsID09PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheSh2YWwpXG5cbiAgY29uc3QgaXNBcnJheUJ1ZmZlckxpa2UgPSAodmFsOiB1bmtub3duKTogdmFsIGlzIEFycmF5QnVmZmVyIHwgQXJyYXlCdWZmZXJWaWV3ID0+XG4gICAgdmFsIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIgfHwgQXJyYXlCdWZmZXIuaXNWaWV3KHZhbClcblxuICBjb25zdCByZXN1bHQ6IFBhcnRpYWw8VD4gPSB7fVxuXG4gIGZvciAoY29uc3Qgc291cmNlIG9mIHNvdXJjZXMpIHtcbiAgICBpZiAoIXNvdXJjZSkgY29udGludWVcblxuICAgIGZvciAoY29uc3Qga2V5IGluIHNvdXJjZSkge1xuICAgICAgY29uc3QgdmFsdWUgPSBzb3VyY2Vba2V5XVxuICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlXG5cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICAvLyBwcmVzZXJ2ZSBhcnJheSByZWZlcmVuY2UsIGluY2x1ZGluZyB1bmlvbnMgbGlrZSBBdXRoZW50aWNhdG9yVHJhbnNwb3J0W11cbiAgICAgICAgcmVzdWx0W2tleV0gPSB2YWx1ZSBhcyBUW3R5cGVvZiBrZXldXG4gICAgICB9IGVsc2UgaWYgKGlzQXJyYXlCdWZmZXJMaWtlKHZhbHVlKSkge1xuICAgICAgICByZXN1bHRba2V5XSA9IHZhbHVlIGFzIFRbdHlwZW9mIGtleV1cbiAgICAgIH0gZWxzZSBpZiAoaXNPYmplY3QodmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nID0gcmVzdWx0W2tleV1cbiAgICAgICAgaWYgKGlzT2JqZWN0KGV4aXN0aW5nKSkge1xuICAgICAgICAgIHJlc3VsdFtrZXldID0gZGVlcE1lcmdlKGV4aXN0aW5nLCB2YWx1ZSkgYXMgdW5rbm93biBhcyBUW3R5cGVvZiBrZXldXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzdWx0W2tleV0gPSBkZWVwTWVyZ2UodmFsdWUpIGFzIHVua25vd24gYXMgVFt0eXBlb2Yga2V5XVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXN1bHRba2V5XSA9IHZhbHVlIGFzIFRbdHlwZW9mIGtleV1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gcmVzdWx0IGFzIFRcbn1cblxuLyoqXG4gKiBNZXJnZXMgV2ViQXV0aG4gY3JlZGVudGlhbCBjcmVhdGlvbiBvcHRpb25zIHdpdGggb3ZlcnJpZGVzLlxuICogU2V0cyBzZW5zaWJsZSBkZWZhdWx0cyBmb3IgYXV0aGVudGljYXRvciBzZWxlY3Rpb24gYW5kIGV4dGVuc2lvbnMuXG4gKlxuICogQHBhcmFtIHtQdWJsaWNLZXlDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zRnV0dXJlfSBiYXNlT3B0aW9ucyAtIFRoZSBiYXNlIG9wdGlvbnMgZnJvbSB0aGUgc2VydmVyXG4gKiBAcGFyYW0ge1B1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmV9IG92ZXJyaWRlcyAtIE9wdGlvbmFsIG92ZXJyaWRlcyB0byBhcHBseVxuICogQHBhcmFtIHtzdHJpbmd9IGZyaWVuZGx5TmFtZSAtIE9wdGlvbmFsIGZyaWVuZGx5IG5hbWUgZm9yIHRoZSBjcmVkZW50aWFsXG4gKiBAcmV0dXJucyB7UHVibGljS2V5Q3JlZGVudGlhbENyZWF0aW9uT3B0aW9uc0Z1dHVyZX0gTWVyZ2VkIGNyZWRlbnRpYWwgY3JlYXRpb24gb3B0aW9uc1xuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3dlYmF1dGhuLyNkaWN0ZGVmLWF1dGhlbnRpY2F0b3JzZWxlY3Rpb25jcml0ZXJpYSBXM0MgV2ViQXV0aG4gU3BlYyAtIEF1dGhlbnRpY2F0b3JTZWxlY3Rpb25Dcml0ZXJpYX1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1lcmdlQ3JlZGVudGlhbENyZWF0aW9uT3B0aW9ucyhcbiAgYmFzZU9wdGlvbnM6IFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmUsXG4gIG92ZXJyaWRlcz86IFBhcnRpYWw8UHVibGljS2V5Q3JlZGVudGlhbENyZWF0aW9uT3B0aW9uc0Z1dHVyZT5cbik6IFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmUge1xuICByZXR1cm4gZGVlcE1lcmdlKERFRkFVTFRfQ1JFQVRJT05fT1BUSU9OUywgYmFzZU9wdGlvbnMsIG92ZXJyaWRlcyB8fCB7fSlcbn1cblxuLyoqXG4gKiBNZXJnZXMgV2ViQXV0aG4gY3JlZGVudGlhbCByZXF1ZXN0IG9wdGlvbnMgd2l0aCBvdmVycmlkZXMuXG4gKiBTZXRzIHNlbnNpYmxlIGRlZmF1bHRzIGZvciB1c2VyIHZlcmlmaWNhdGlvbiBhbmQgaGludHMuXG4gKlxuICogQHBhcmFtIHtQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmV9IGJhc2VPcHRpb25zIC0gVGhlIGJhc2Ugb3B0aW9ucyBmcm9tIHRoZSBzZXJ2ZXJcbiAqIEBwYXJhbSB7UHVibGljS2V5Q3JlZGVudGlhbFJlcXVlc3RPcHRpb25zRnV0dXJlfSBvdmVycmlkZXMgLSBPcHRpb25hbCBvdmVycmlkZXMgdG8gYXBwbHlcbiAqIEByZXR1cm5zIHtQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmV9IE1lcmdlZCBjcmVkZW50aWFsIHJlcXVlc3Qgb3B0aW9uc1xuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3dlYmF1dGhuLyNkaWN0ZGVmLXB1YmxpY2tleWNyZWRlbnRpYWxyZXF1ZXN0b3B0aW9ucyBXM0MgV2ViQXV0aG4gU3BlYyAtIFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1lcmdlQ3JlZGVudGlhbFJlcXVlc3RPcHRpb25zKFxuICBiYXNlT3B0aW9uczogUHVibGljS2V5Q3JlZGVudGlhbFJlcXVlc3RPcHRpb25zRnV0dXJlLFxuICBvdmVycmlkZXM/OiBQYXJ0aWFsPFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0Z1dHVyZT5cbik6IFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0Z1dHVyZSB7XG4gIHJldHVybiBkZWVwTWVyZ2UoREVGQVVMVF9SRVFVRVNUX09QVElPTlMsIGJhc2VPcHRpb25zLCBvdmVycmlkZXMgfHwge30pXG59XG5cbi8qKlxuICogV2ViQXV0aG4gQVBJIHdyYXBwZXIgZm9yIFN1cGFiYXNlIEF1dGguXG4gKiBQcm92aWRlcyBtZXRob2RzIGZvciBlbnJvbGxpbmcsIGNoYWxsZW5naW5nLCB2ZXJpZnlpbmcsIGF1dGhlbnRpY2F0aW5nLCBhbmQgcmVnaXN0ZXJpbmcgV2ViQXV0aG4gY3JlZGVudGlhbHMuXG4gKlxuICogQGV4cGVyaW1lbnRhbCBUaGlzIEFQSSBpcyBleHBlcmltZW50YWwgYW5kIG1heSBjaGFuZ2UgaW4gZnV0dXJlIHJlbGVhc2VzXG4gKiBAc2VlIHtAbGluayBodHRwczovL3czYy5naXRodWIuaW8vd2ViYXV0aG4vIFczQyBXZWJBdXRobiBTcGVjaWZpY2F0aW9ufVxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1dlYl9BdXRoZW50aWNhdGlvbl9BUEkgTUROIC0gV2ViIEF1dGhlbnRpY2F0aW9uIEFQSX1cbiAqL1xuZXhwb3J0IGNsYXNzIFdlYkF1dGhuQXBpIHtcbiAgcHVibGljIGVucm9sbDogdHlwZW9mIFdlYkF1dGhuQXBpLnByb3RvdHlwZS5fZW5yb2xsXG4gIHB1YmxpYyBjaGFsbGVuZ2U6IHR5cGVvZiBXZWJBdXRobkFwaS5wcm90b3R5cGUuX2NoYWxsZW5nZVxuICBwdWJsaWMgdmVyaWZ5OiB0eXBlb2YgV2ViQXV0aG5BcGkucHJvdG90eXBlLl92ZXJpZnlcbiAgcHVibGljIGF1dGhlbnRpY2F0ZTogdHlwZW9mIFdlYkF1dGhuQXBpLnByb3RvdHlwZS5fYXV0aGVudGljYXRlXG4gIHB1YmxpYyByZWdpc3RlcjogdHlwZW9mIFdlYkF1dGhuQXBpLnByb3RvdHlwZS5fcmVnaXN0ZXJcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGNsaWVudDogR29UcnVlQ2xpZW50KSB7XG4gICAgLy8gQmluZCBhbGwgbWV0aG9kcyBzbyB0aGV5IGNhbiBiZSBkZXN0cnVjdHVyZWRcbiAgICB0aGlzLmVucm9sbCA9IHRoaXMuX2Vucm9sbC5iaW5kKHRoaXMpXG4gICAgdGhpcy5jaGFsbGVuZ2UgPSB0aGlzLl9jaGFsbGVuZ2UuYmluZCh0aGlzKVxuICAgIHRoaXMudmVyaWZ5ID0gdGhpcy5fdmVyaWZ5LmJpbmQodGhpcylcbiAgICB0aGlzLmF1dGhlbnRpY2F0ZSA9IHRoaXMuX2F1dGhlbnRpY2F0ZS5iaW5kKHRoaXMpXG4gICAgdGhpcy5yZWdpc3RlciA9IHRoaXMuX3JlZ2lzdGVyLmJpbmQodGhpcylcbiAgfVxuXG4gIC8qKlxuICAgKiBFbnJvbGwgYSBuZXcgV2ViQXV0aG4gZmFjdG9yLlxuICAgKiBDcmVhdGVzIGFuIHVudmVyaWZpZWQgV2ViQXV0aG4gZmFjdG9yIHRoYXQgbXVzdCBiZSB2ZXJpZmllZCB3aXRoIGEgY3JlZGVudGlhbC5cbiAgICpcbiAgICogQGV4cGVyaW1lbnRhbCBUaGlzIG1ldGhvZCBpcyBleHBlcmltZW50YWwgYW5kIG1heSBjaGFuZ2UgaW4gZnV0dXJlIHJlbGVhc2VzXG4gICAqIEBwYXJhbSB7T21pdDxNRkFFbnJvbGxXZWJhdXRoblBhcmFtcywgJ2ZhY3RvclR5cGUnPn0gcGFyYW1zIC0gRW5yb2xsbWVudCBwYXJhbWV0ZXJzIChmcmllbmRseU5hbWUgcmVxdWlyZWQpXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPEF1dGhNRkFFbnJvbGxXZWJhdXRoblJlc3BvbnNlPn0gRW5yb2xsZWQgZmFjdG9yIGRldGFpbHMgb3IgZXJyb3JcbiAgICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3dlYmF1dGhuLyNzY3RuLXJlZ2lzdGVyaW5nLWEtbmV3LWNyZWRlbnRpYWwgVzNDIFdlYkF1dGhuIFNwZWMgLSBSZWdpc3RlcmluZyBhIE5ldyBDcmVkZW50aWFsfVxuICAgKi9cbiAgcHVibGljIGFzeW5jIF9lbnJvbGwoXG4gICAgcGFyYW1zOiBPbWl0PE1GQUVucm9sbFdlYmF1dGhuUGFyYW1zLCAnZmFjdG9yVHlwZSc+XG4gICk6IFByb21pc2U8QXV0aE1GQUVucm9sbFdlYmF1dGhuUmVzcG9uc2U+IHtcbiAgICByZXR1cm4gdGhpcy5jbGllbnQubWZhLmVucm9sbCh7IC4uLnBhcmFtcywgZmFjdG9yVHlwZTogJ3dlYmF1dGhuJyB9KVxuICB9XG5cbiAgLyoqXG4gICAqIENoYWxsZW5nZSBmb3IgV2ViQXV0aG4gY3JlZGVudGlhbCBjcmVhdGlvbiBvciBhdXRoZW50aWNhdGlvbi5cbiAgICogQ29tYmluZXMgc2VydmVyIGNoYWxsZW5nZSB3aXRoIGJyb3dzZXIgY3JlZGVudGlhbCBvcGVyYXRpb25zLlxuICAgKiBIYW5kbGVzIGJvdGggcmVnaXN0cmF0aW9uIChjcmVhdGUpIGFuZCBhdXRoZW50aWNhdGlvbiAocmVxdWVzdCkgZmxvd3MuXG4gICAqXG4gICAqIEBleHBlcmltZW50YWwgVGhpcyBtZXRob2QgaXMgZXhwZXJpbWVudGFsIGFuZCBtYXkgY2hhbmdlIGluIGZ1dHVyZSByZWxlYXNlc1xuICAgKiBAcGFyYW0ge01GQUNoYWxsZW5nZVdlYmF1dGhuUGFyYW1zICYgeyBmcmllbmRseU5hbWU/OiBzdHJpbmc7IHNpZ25hbD86IEFib3J0U2lnbmFsIH19IHBhcmFtcyAtIENoYWxsZW5nZSBwYXJhbWV0ZXJzIGluY2x1ZGluZyBmYWN0b3JJZFxuICAgKiBAcGFyYW0ge09iamVjdH0gb3ZlcnJpZGVzIC0gQWxsb3dzIHlvdSB0byBvdmVycmlkZSB0aGUgcGFyYW1ldGVycyBwYXNzZWQgdG8gbmF2aWdhdG9yLmNyZWRlbnRpYWxzXG4gICAqIEBwYXJhbSB7UHVibGljS2V5Q3JlZGVudGlhbENyZWF0aW9uT3B0aW9uc0Z1dHVyZX0gb3ZlcnJpZGVzLmNyZWF0ZSAtIE92ZXJyaWRlIG9wdGlvbnMgZm9yIGNyZWRlbnRpYWwgY3JlYXRpb25cbiAgICogQHBhcmFtIHtQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmV9IG92ZXJyaWRlcy5yZXF1ZXN0IC0gT3ZlcnJpZGUgb3B0aW9ucyBmb3IgY3JlZGVudGlhbCByZXF1ZXN0XG4gICAqIEByZXR1cm5zIHtQcm9taXNlPFJlcXVlc3RSZXN1bHQ+fSBDaGFsbGVuZ2UgcmVzcG9uc2Ugd2l0aCBjcmVkZW50aWFsIG9yIGVycm9yXG4gICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jc2N0bi1jcmVkZW50aWFsLWNyZWF0aW9uIFczQyBXZWJBdXRobiBTcGVjIC0gQ3JlZGVudGlhbCBDcmVhdGlvbn1cbiAgICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3dlYmF1dGhuLyNzY3RuLXZlcmlmeWluZy1hc3NlcnRpb24gVzNDIFdlYkF1dGhuIFNwZWMgLSBWZXJpZnlpbmcgQXNzZXJ0aW9ufVxuICAgKi9cbiAgcHVibGljIGFzeW5jIF9jaGFsbGVuZ2UoXG4gICAge1xuICAgICAgZmFjdG9ySWQsXG4gICAgICB3ZWJhdXRobixcbiAgICAgIGZyaWVuZGx5TmFtZSxcbiAgICAgIHNpZ25hbCxcbiAgICB9OiBNRkFDaGFsbGVuZ2VXZWJhdXRoblBhcmFtcyAmIHsgZnJpZW5kbHlOYW1lPzogc3RyaW5nOyBzaWduYWw/OiBBYm9ydFNpZ25hbCB9LFxuICAgIG92ZXJyaWRlcz86XG4gICAgICB8IHtcbiAgICAgICAgICBjcmVhdGU/OiBQYXJ0aWFsPFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmU+XG4gICAgICAgICAgcmVxdWVzdD86IG5ldmVyXG4gICAgICAgIH1cbiAgICAgIHwge1xuICAgICAgICAgIGNyZWF0ZT86IG5ldmVyXG4gICAgICAgICAgcmVxdWVzdD86IFBhcnRpYWw8UHVibGljS2V5Q3JlZGVudGlhbFJlcXVlc3RPcHRpb25zRnV0dXJlPlxuICAgICAgICB9XG4gICk6IFByb21pc2U8XG4gICAgUmVxdWVzdFJlc3VsdDxcbiAgICAgIHsgZmFjdG9ySWQ6IHN0cmluZzsgY2hhbGxlbmdlSWQ6IHN0cmluZyB9ICYge1xuICAgICAgICB3ZWJhdXRobjogU3RyaWN0T21pdDxcbiAgICAgICAgICBNRkFWZXJpZnlXZWJhdXRoblBhcmFtRmllbGRzPCdjcmVhdGUnIHwgJ3JlcXVlc3QnPlsnd2ViYXV0aG4nXSxcbiAgICAgICAgICAncnBJZCcgfCAncnBPcmlnaW5zJ1xuICAgICAgICA+XG4gICAgICB9LFxuICAgICAgV2ViQXV0aG5FcnJvciB8IEF1dGhFcnJvclxuICAgID5cbiAgPiB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIEdldCBjaGFsbGVuZ2UgZnJvbSBzZXJ2ZXIgdXNpbmcgdGhlIGNsaWVudCdzIE1GQSBtZXRob2RzXG4gICAgICBjb25zdCB7IGRhdGE6IGNoYWxsZW5nZVJlc3BvbnNlLCBlcnJvcjogY2hhbGxlbmdlRXJyb3IgfSA9IGF3YWl0IHRoaXMuY2xpZW50Lm1mYS5jaGFsbGVuZ2Uoe1xuICAgICAgICBmYWN0b3JJZCxcbiAgICAgICAgd2ViYXV0aG4sXG4gICAgICB9KVxuXG4gICAgICBpZiAoIWNoYWxsZW5nZVJlc3BvbnNlKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBjaGFsbGVuZ2VFcnJvciB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGFib3J0U2lnbmFsID0gc2lnbmFsID8/IHdlYkF1dGhuQWJvcnRTZXJ2aWNlLmNyZWF0ZU5ld0Fib3J0U2lnbmFsKClcblxuICAgICAgLyoqIHdlYmF1dGhuIHdpbGwgZmFpbCBpZiBlaXRoZXIgb2YgdGhlIG5hbWUvZGlzcGxheW5hbWUgYXJlIGJsYW5rICovXG4gICAgICBpZiAoY2hhbGxlbmdlUmVzcG9uc2Uud2ViYXV0aG4udHlwZSA9PT0gJ2NyZWF0ZScpIHtcbiAgICAgICAgY29uc3QgeyB1c2VyIH0gPSBjaGFsbGVuZ2VSZXNwb25zZS53ZWJhdXRobi5jcmVkZW50aWFsX29wdGlvbnMucHVibGljS2V5XG4gICAgICAgIGlmICghdXNlci5uYW1lKSB7XG4gICAgICAgICAgLy8gUHJlc2VydmUgb3JpZ2luYWwgZm9ybWF0OiB1c2UgZnJpZW5kbHlOYW1lIGlmIHByb3ZpZGVkLCBvdGhlcndpc2UgZmV0Y2ggZmFsbGJhY2tcbiAgICAgICAgICAvLyBUaGlzIG1haW50YWlucyBiYWNrd2FyZCBjb21wYXRpYmlsaXR5IHdpdGggdGhlICR7dXNlci5pZH06JHtuYW1lfSBmb3JtYXRcbiAgICAgICAgICBjb25zdCBuYW1lVG9Vc2UgPSBmcmllbmRseU5hbWVcbiAgICAgICAgICBpZiAoIW5hbWVUb1VzZSkge1xuICAgICAgICAgICAgLy8gT25seSBmZXRjaCB1c2VyIGRhdGEgaWYgZnJpZW5kbHlOYW1lIGlzIG5vdCBwcm92aWRlZCAoYnVnIGZpeCBmb3IgbnVsbCBmcmllbmRseU5hbWUpXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50VXNlciA9IGF3YWl0IHRoaXMuY2xpZW50LmdldFVzZXIoKVxuICAgICAgICAgICAgY29uc3QgdXNlckRhdGEgPSBjdXJyZW50VXNlci5kYXRhLnVzZXJcbiAgICAgICAgICAgIGNvbnN0IGZhbGxiYWNrTmFtZSA9XG4gICAgICAgICAgICAgIHVzZXJEYXRhPy51c2VyX21ldGFkYXRhPy5uYW1lIHx8IHVzZXJEYXRhPy5lbWFpbCB8fCB1c2VyRGF0YT8uaWQgfHwgJ1VzZXInXG4gICAgICAgICAgICB1c2VyLm5hbWUgPSBgJHt1c2VyLmlkfToke2ZhbGxiYWNrTmFtZX1gXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHVzZXIubmFtZSA9IGAke3VzZXIuaWR9OiR7bmFtZVRvVXNlfWBcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF1c2VyLmRpc3BsYXlOYW1lKSB7XG4gICAgICAgICAgdXNlci5kaXNwbGF5TmFtZSA9IHVzZXIubmFtZVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHN3aXRjaCAoY2hhbGxlbmdlUmVzcG9uc2Uud2ViYXV0aG4udHlwZSkge1xuICAgICAgICBjYXNlICdjcmVhdGUnOiB7XG4gICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IG1lcmdlQ3JlZGVudGlhbENyZWF0aW9uT3B0aW9ucyhcbiAgICAgICAgICAgIGNoYWxsZW5nZVJlc3BvbnNlLndlYmF1dGhuLmNyZWRlbnRpYWxfb3B0aW9ucy5wdWJsaWNLZXksXG4gICAgICAgICAgICBvdmVycmlkZXM/LmNyZWF0ZVxuICAgICAgICAgIClcblxuICAgICAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNyZWF0ZUNyZWRlbnRpYWwoe1xuICAgICAgICAgICAgcHVibGljS2V5OiBvcHRpb25zLFxuICAgICAgICAgICAgc2lnbmFsOiBhYm9ydFNpZ25hbCxcbiAgICAgICAgICB9KVxuXG4gICAgICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBmYWN0b3JJZCxcbiAgICAgICAgICAgICAgICBjaGFsbGVuZ2VJZDogY2hhbGxlbmdlUmVzcG9uc2UuaWQsXG4gICAgICAgICAgICAgICAgd2ViYXV0aG46IHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6IGNoYWxsZW5nZVJlc3BvbnNlLndlYmF1dGhuLnR5cGUsXG4gICAgICAgICAgICAgICAgICBjcmVkZW50aWFsX3Jlc3BvbnNlOiBkYXRhLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICAgIH1cblxuICAgICAgICBjYXNlICdyZXF1ZXN0Jzoge1xuICAgICAgICAgIGNvbnN0IG9wdGlvbnMgPSBtZXJnZUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9ucyhcbiAgICAgICAgICAgIGNoYWxsZW5nZVJlc3BvbnNlLndlYmF1dGhuLmNyZWRlbnRpYWxfb3B0aW9ucy5wdWJsaWNLZXksXG4gICAgICAgICAgICBvdmVycmlkZXM/LnJlcXVlc3RcbiAgICAgICAgICApXG5cbiAgICAgICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBnZXRDcmVkZW50aWFsKHtcbiAgICAgICAgICAgIC4uLmNoYWxsZW5nZVJlc3BvbnNlLndlYmF1dGhuLmNyZWRlbnRpYWxfb3B0aW9ucyxcbiAgICAgICAgICAgIHB1YmxpY0tleTogb3B0aW9ucyxcbiAgICAgICAgICAgIHNpZ25hbDogYWJvcnRTaWduYWwsXG4gICAgICAgICAgfSlcblxuICAgICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgZmFjdG9ySWQsXG4gICAgICAgICAgICAgICAgY2hhbGxlbmdlSWQ6IGNoYWxsZW5nZVJlc3BvbnNlLmlkLFxuICAgICAgICAgICAgICAgIHdlYmF1dGhuOiB7XG4gICAgICAgICAgICAgICAgICB0eXBlOiBjaGFsbGVuZ2VSZXNwb25zZS53ZWJhdXRobi50eXBlLFxuICAgICAgICAgICAgICAgICAgY3JlZGVudGlhbF9yZXNwb25zZTogZGF0YSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3IgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3IgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgZXJyb3I6IG5ldyBBdXRoVW5rbm93bkVycm9yKCdVbmV4cGVjdGVkIGVycm9yIGluIGNoYWxsZW5nZScsIGVycm9yKSxcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmVyaWZ5IGEgV2ViQXV0aG4gY3JlZGVudGlhbCB3aXRoIHRoZSBzZXJ2ZXIuXG4gICAqIENvbXBsZXRlcyB0aGUgV2ViQXV0aG4gY2VyZW1vbnkgYnkgc2VuZGluZyB0aGUgY3JlZGVudGlhbCB0byB0aGUgc2VydmVyIGZvciB2ZXJpZmljYXRpb24uXG4gICAqXG4gICAqIEBleHBlcmltZW50YWwgVGhpcyBtZXRob2QgaXMgZXhwZXJpbWVudGFsIGFuZCBtYXkgY2hhbmdlIGluIGZ1dHVyZSByZWxlYXNlc1xuICAgKiBAcGFyYW0ge09iamVjdH0gcGFyYW1zIC0gVmVyaWZpY2F0aW9uIHBhcmFtZXRlcnNcbiAgICogQHBhcmFtIHtzdHJpbmd9IHBhcmFtcy5jaGFsbGVuZ2VJZCAtIElEIG9mIHRoZSBjaGFsbGVuZ2UgYmVpbmcgdmVyaWZpZWRcbiAgICogQHBhcmFtIHtzdHJpbmd9IHBhcmFtcy5mYWN0b3JJZCAtIElEIG9mIHRoZSBXZWJBdXRobiBmYWN0b3JcbiAgICogQHBhcmFtIHtNRkFWZXJpZnlXZWJhdXRoblBhcmFtczxUPlsnd2ViYXV0aG4nXX0gcGFyYW1zLndlYmF1dGhuIC0gV2ViQXV0aG4gY3JlZGVudGlhbCByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxBdXRoTUZBVmVyaWZ5UmVzcG9uc2U+fSBWZXJpZmljYXRpb24gcmVzdWx0IHdpdGggc2Vzc2lvbiBvciBlcnJvclxuICAgKiBAc2VlIHtAbGluayBodHRwczovL3czYy5naXRodWIuaW8vd2ViYXV0aG4vI3NjdG4tdmVyaWZ5aW5nLWFzc2VydGlvbiBXM0MgV2ViQXV0aG4gU3BlYyAtIFZlcmlmeWluZyBhbiBBdXRoZW50aWNhdGlvbiBBc3NlcnRpb259XG4gICAqICovXG4gIHB1YmxpYyBhc3luYyBfdmVyaWZ5PFQgZXh0ZW5kcyAnY3JlYXRlJyB8ICdyZXF1ZXN0Jz4oe1xuICAgIGNoYWxsZW5nZUlkLFxuICAgIGZhY3RvcklkLFxuICAgIHdlYmF1dGhuLFxuICB9OiB7XG4gICAgY2hhbGxlbmdlSWQ6IHN0cmluZ1xuICAgIGZhY3RvcklkOiBzdHJpbmdcbiAgICB3ZWJhdXRobjogTUZBVmVyaWZ5V2ViYXV0aG5QYXJhbXM8VD5bJ3dlYmF1dGhuJ11cbiAgfSk6IFByb21pc2U8QXV0aE1GQVZlcmlmeVJlc3BvbnNlPiB7XG4gICAgcmV0dXJuIHRoaXMuY2xpZW50Lm1mYS52ZXJpZnkoe1xuICAgICAgZmFjdG9ySWQsXG4gICAgICBjaGFsbGVuZ2VJZCxcbiAgICAgIHdlYmF1dGhuOiB3ZWJhdXRobixcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIENvbXBsZXRlIFdlYkF1dGhuIGF1dGhlbnRpY2F0aW9uIGZsb3cuXG4gICAqIFBlcmZvcm1zIGNoYWxsZW5nZSBhbmQgdmVyaWZpY2F0aW9uIGluIGEgc2luZ2xlIG9wZXJhdGlvbiBmb3IgZXhpc3RpbmcgY3JlZGVudGlhbHMuXG4gICAqXG4gICAqIEBleHBlcmltZW50YWwgVGhpcyBtZXRob2QgaXMgZXhwZXJpbWVudGFsIGFuZCBtYXkgY2hhbmdlIGluIGZ1dHVyZSByZWxlYXNlc1xuICAgKiBAcGFyYW0ge09iamVjdH0gcGFyYW1zIC0gQXV0aGVudGljYXRpb24gcGFyYW1ldGVyc1xuICAgKiBAcGFyYW0ge3N0cmluZ30gcGFyYW1zLmZhY3RvcklkIC0gSUQgb2YgdGhlIFdlYkF1dGhuIGZhY3RvciB0byBhdXRoZW50aWNhdGUgd2l0aFxuICAgKiBAcGFyYW0ge09iamVjdH0gcGFyYW1zLndlYmF1dGhuIC0gV2ViQXV0aG4gY29uZmlndXJhdGlvblxuICAgKiBAcGFyYW0ge3N0cmluZ30gcGFyYW1zLndlYmF1dGhuLnJwSWQgLSBSZWx5aW5nIFBhcnR5IElEIChkZWZhdWx0cyB0byBjdXJyZW50IGhvc3RuYW1lKVxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBwYXJhbXMud2ViYXV0aG4ucnBPcmlnaW5zIC0gQWxsb3dlZCBvcmlnaW5zIChkZWZhdWx0cyB0byBjdXJyZW50IG9yaWdpbilcbiAgICogQHBhcmFtIHtBYm9ydFNpZ25hbH0gcGFyYW1zLndlYmF1dGhuLnNpZ25hbCAtIE9wdGlvbmFsIGFib3J0IHNpZ25hbFxuICAgKiBAcGFyYW0ge1B1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc0Z1dHVyZX0gb3ZlcnJpZGVzIC0gT3ZlcnJpZGUgb3B0aW9ucyBmb3IgbmF2aWdhdG9yLmNyZWRlbnRpYWxzLmdldFxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxSZXF1ZXN0UmVzdWx0PEF1dGhNRkFWZXJpZnlSZXNwb25zZURhdGEsIFdlYkF1dGhuRXJyb3IgfCBBdXRoRXJyb3I+Pn0gQXV0aGVudGljYXRpb24gcmVzdWx0XG4gICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jc2N0bi1hdXRoZW50aWNhdGlvbiBXM0MgV2ViQXV0aG4gU3BlYyAtIEF1dGhlbnRpY2F0aW9uIENlcmVtb255fVxuICAgKiBAc2VlIHtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUHVibGljS2V5Q3JlZGVudGlhbFJlcXVlc3RPcHRpb25zIE1ETiAtIFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9uc31cbiAgICovXG4gIHB1YmxpYyBhc3luYyBfYXV0aGVudGljYXRlKFxuICAgIHtcbiAgICAgIGZhY3RvcklkLFxuICAgICAgd2ViYXV0aG46IHtcbiAgICAgICAgcnBJZCA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gd2luZG93LmxvY2F0aW9uLmhvc3RuYW1lIDogdW5kZWZpbmVkLFxuICAgICAgICBycE9yaWdpbnMgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IFt3aW5kb3cubG9jYXRpb24ub3JpZ2luXSA6IHVuZGVmaW5lZCxcbiAgICAgICAgc2lnbmFsLFxuICAgICAgfSA9IHt9LFxuICAgIH06IHtcbiAgICAgIGZhY3RvcklkOiBzdHJpbmdcbiAgICAgIHdlYmF1dGhuPzoge1xuICAgICAgICBycElkPzogc3RyaW5nXG4gICAgICAgIHJwT3JpZ2lucz86IHN0cmluZ1tdXG4gICAgICAgIHNpZ25hbD86IEFib3J0U2lnbmFsXG4gICAgICB9XG4gICAgfSxcbiAgICBvdmVycmlkZXM/OiBQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnNGdXR1cmVcbiAgKTogUHJvbWlzZTxSZXF1ZXN0UmVzdWx0PEF1dGhNRkFWZXJpZnlSZXNwb25zZURhdGEsIFdlYkF1dGhuRXJyb3IgfCBBdXRoRXJyb3I+PiB7XG4gICAgaWYgKCFycElkKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBkYXRhOiBudWxsLFxuICAgICAgICBlcnJvcjogbmV3IEF1dGhFcnJvcigncnBJZCBpcyByZXF1aXJlZCBmb3IgV2ViQXV0aG4gYXV0aGVudGljYXRpb24nKSxcbiAgICAgIH1cbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIGlmICghYnJvd3NlclN1cHBvcnRzV2ViQXV0aG4oKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGRhdGE6IG51bGwsXG4gICAgICAgICAgZXJyb3I6IG5ldyBBdXRoVW5rbm93bkVycm9yKCdCcm93c2VyIGRvZXMgbm90IHN1cHBvcnQgV2ViQXV0aG4nLCBudWxsKSxcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBHZXQgY2hhbGxlbmdlIGFuZCBjcmVkZW50aWFsXG4gICAgICBjb25zdCB7IGRhdGE6IGNoYWxsZW5nZVJlc3BvbnNlLCBlcnJvcjogY2hhbGxlbmdlRXJyb3IgfSA9IGF3YWl0IHRoaXMuY2hhbGxlbmdlKFxuICAgICAgICB7XG4gICAgICAgICAgZmFjdG9ySWQsXG4gICAgICAgICAgd2ViYXV0aG46IHsgcnBJZCwgcnBPcmlnaW5zIH0sXG4gICAgICAgICAgc2lnbmFsLFxuICAgICAgICB9LFxuICAgICAgICB7IHJlcXVlc3Q6IG92ZXJyaWRlcyB9XG4gICAgICApXG5cbiAgICAgIGlmICghY2hhbGxlbmdlUmVzcG9uc2UpIHtcbiAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3I6IGNoYWxsZW5nZUVycm9yIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgeyB3ZWJhdXRobiB9ID0gY2hhbGxlbmdlUmVzcG9uc2VcblxuICAgICAgLy8gVmVyaWZ5IGNyZWRlbnRpYWxcbiAgICAgIHJldHVybiB0aGlzLl92ZXJpZnkoe1xuICAgICAgICBmYWN0b3JJZCxcbiAgICAgICAgY2hhbGxlbmdlSWQ6IGNoYWxsZW5nZVJlc3BvbnNlLmNoYWxsZW5nZUlkLFxuICAgICAgICB3ZWJhdXRobjoge1xuICAgICAgICAgIHR5cGU6IHdlYmF1dGhuLnR5cGUsXG4gICAgICAgICAgcnBJZCxcbiAgICAgICAgICBycE9yaWdpbnMsXG4gICAgICAgICAgY3JlZGVudGlhbF9yZXNwb25zZTogd2ViYXV0aG4uY3JlZGVudGlhbF9yZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3IgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgZXJyb3I6IG5ldyBBdXRoVW5rbm93bkVycm9yKCdVbmV4cGVjdGVkIGVycm9yIGluIGF1dGhlbnRpY2F0ZScsIGVycm9yKSxcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ29tcGxldGUgV2ViQXV0aG4gcmVnaXN0cmF0aW9uIGZsb3cuXG4gICAqIFBlcmZvcm1zIGVucm9sbG1lbnQsIGNoYWxsZW5nZSwgYW5kIHZlcmlmaWNhdGlvbiBpbiBhIHNpbmdsZSBvcGVyYXRpb24gZm9yIG5ldyBjcmVkZW50aWFscy5cbiAgICpcbiAgICogQGV4cGVyaW1lbnRhbCBUaGlzIG1ldGhvZCBpcyBleHBlcmltZW50YWwgYW5kIG1heSBjaGFuZ2UgaW4gZnV0dXJlIHJlbGVhc2VzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBwYXJhbXMgLSBSZWdpc3RyYXRpb24gcGFyYW1ldGVyc1xuICAgKiBAcGFyYW0ge3N0cmluZ30gcGFyYW1zLmZyaWVuZGx5TmFtZSAtIFVzZXItZnJpZW5kbHkgbmFtZSBmb3IgdGhlIGNyZWRlbnRpYWxcbiAgICogQHBhcmFtIHtzdHJpbmd9IHBhcmFtcy5ycElkIC0gUmVseWluZyBQYXJ0eSBJRCAoZGVmYXVsdHMgdG8gY3VycmVudCBob3N0bmFtZSlcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gcGFyYW1zLnJwT3JpZ2lucyAtIEFsbG93ZWQgb3JpZ2lucyAoZGVmYXVsdHMgdG8gY3VycmVudCBvcmlnaW4pXG4gICAqIEBwYXJhbSB7QWJvcnRTaWduYWx9IHBhcmFtcy5zaWduYWwgLSBPcHRpb25hbCBhYm9ydCBzaWduYWxcbiAgICogQHBhcmFtIHtQdWJsaWNLZXlDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zRnV0dXJlfSBvdmVycmlkZXMgLSBPdmVycmlkZSBvcHRpb25zIGZvciBuYXZpZ2F0b3IuY3JlZGVudGlhbHMuY3JlYXRlXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPFJlcXVlc3RSZXN1bHQ8QXV0aE1GQVZlcmlmeVJlc3BvbnNlRGF0YSwgV2ViQXV0aG5FcnJvciB8IEF1dGhFcnJvcj4+fSBSZWdpc3RyYXRpb24gcmVzdWx0XG4gICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby93ZWJhdXRobi8jc2N0bi1yZWdpc3RlcmluZy1hLW5ldy1jcmVkZW50aWFsIFczQyBXZWJBdXRobiBTcGVjIC0gUmVnaXN0cmF0aW9uIENlcmVtb255fVxuICAgKiBAc2VlIHtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUHVibGljS2V5Q3JlZGVudGlhbENyZWF0aW9uT3B0aW9ucyBNRE4gLSBQdWJsaWNLZXlDcmVkZW50aWFsQ3JlYXRpb25PcHRpb25zfVxuICAgKi9cbiAgcHVibGljIGFzeW5jIF9yZWdpc3RlcihcbiAgICB7XG4gICAgICBmcmllbmRseU5hbWUsXG4gICAgICB3ZWJhdXRobjoge1xuICAgICAgICBycElkID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cubG9jYXRpb24uaG9zdG5hbWUgOiB1bmRlZmluZWQsXG4gICAgICAgIHJwT3JpZ2lucyA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gW3dpbmRvdy5sb2NhdGlvbi5vcmlnaW5dIDogdW5kZWZpbmVkLFxuICAgICAgICBzaWduYWwsXG4gICAgICB9ID0ge30sXG4gICAgfToge1xuICAgICAgZnJpZW5kbHlOYW1lOiBzdHJpbmdcbiAgICAgIHdlYmF1dGhuPzoge1xuICAgICAgICBycElkPzogc3RyaW5nXG4gICAgICAgIHJwT3JpZ2lucz86IHN0cmluZ1tdXG4gICAgICAgIHNpZ25hbD86IEFib3J0U2lnbmFsXG4gICAgICB9XG4gICAgfSxcbiAgICBvdmVycmlkZXM/OiBQYXJ0aWFsPFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNGdXR1cmU+XG4gICk6IFByb21pc2U8UmVxdWVzdFJlc3VsdDxBdXRoTUZBVmVyaWZ5UmVzcG9uc2VEYXRhLCBXZWJBdXRobkVycm9yIHwgQXV0aEVycm9yPj4ge1xuICAgIGlmICghcnBJZCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgZXJyb3I6IG5ldyBBdXRoRXJyb3IoJ3JwSWQgaXMgcmVxdWlyZWQgZm9yIFdlYkF1dGhuIHJlZ2lzdHJhdGlvbicpLFxuICAgICAgfVxuICAgIH1cbiAgICB0cnkge1xuICAgICAgaWYgKCFicm93c2VyU3VwcG9ydHNXZWJBdXRobigpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgICBlcnJvcjogbmV3IEF1dGhVbmtub3duRXJyb3IoJ0Jyb3dzZXIgZG9lcyBub3Qgc3VwcG9ydCBXZWJBdXRobicsIG51bGwpLFxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEVucm9sbCBmYWN0b3JcbiAgICAgIGNvbnN0IHsgZGF0YTogZmFjdG9yLCBlcnJvcjogZW5yb2xsRXJyb3IgfSA9IGF3YWl0IHRoaXMuX2Vucm9sbCh7XG4gICAgICAgIGZyaWVuZGx5TmFtZSxcbiAgICAgIH0pXG5cbiAgICAgIGlmICghZmFjdG9yKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuY2xpZW50Lm1mYVxuICAgICAgICAgIC5saXN0RmFjdG9ycygpXG4gICAgICAgICAgLnRoZW4oKGZhY3RvcnMpID0+XG4gICAgICAgICAgICBmYWN0b3JzLmRhdGE/LmFsbC5maW5kKFxuICAgICAgICAgICAgICAodikgPT5cbiAgICAgICAgICAgICAgICB2LmZhY3Rvcl90eXBlID09PSAnd2ViYXV0aG4nICYmXG4gICAgICAgICAgICAgICAgdi5mcmllbmRseV9uYW1lID09PSBmcmllbmRseU5hbWUgJiZcbiAgICAgICAgICAgICAgICB2LnN0YXR1cyAhPT0gJ3VudmVyaWZpZWQnXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICAgIC50aGVuKChmYWN0b3IpID0+IChmYWN0b3IgPyB0aGlzLmNsaWVudC5tZmEudW5lbnJvbGwoeyBmYWN0b3JJZDogZmFjdG9yPy5pZCB9KSA6IHZvaWQgMCkpXG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBlbnJvbGxFcnJvciB9XG4gICAgICB9XG5cbiAgICAgIC8vIEdldCBjaGFsbGVuZ2UgYW5kIGNyZWF0ZSBjcmVkZW50aWFsXG4gICAgICBjb25zdCB7IGRhdGE6IGNoYWxsZW5nZVJlc3BvbnNlLCBlcnJvcjogY2hhbGxlbmdlRXJyb3IgfSA9IGF3YWl0IHRoaXMuX2NoYWxsZW5nZShcbiAgICAgICAge1xuICAgICAgICAgIGZhY3RvcklkOiBmYWN0b3IuaWQsXG4gICAgICAgICAgZnJpZW5kbHlOYW1lOiBmYWN0b3IuZnJpZW5kbHlfbmFtZSxcbiAgICAgICAgICB3ZWJhdXRobjogeyBycElkLCBycE9yaWdpbnMgfSxcbiAgICAgICAgICBzaWduYWwsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBjcmVhdGU6IG92ZXJyaWRlcyxcbiAgICAgICAgfVxuICAgICAgKVxuXG4gICAgICBpZiAoIWNoYWxsZW5nZVJlc3BvbnNlKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBjaGFsbGVuZ2VFcnJvciB9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLl92ZXJpZnkoe1xuICAgICAgICBmYWN0b3JJZDogZmFjdG9yLmlkLFxuICAgICAgICBjaGFsbGVuZ2VJZDogY2hhbGxlbmdlUmVzcG9uc2UuY2hhbGxlbmdlSWQsXG4gICAgICAgIHdlYmF1dGhuOiB7XG4gICAgICAgICAgcnBJZCxcbiAgICAgICAgICBycE9yaWdpbnMsXG4gICAgICAgICAgdHlwZTogY2hhbGxlbmdlUmVzcG9uc2Uud2ViYXV0aG4udHlwZSxcbiAgICAgICAgICBjcmVkZW50aWFsX3Jlc3BvbnNlOiBjaGFsbGVuZ2VSZXNwb25zZS53ZWJhdXRobi5jcmVkZW50aWFsX3Jlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICBkYXRhOiBudWxsLFxuICAgICAgICBlcnJvcjogbmV3IEF1dGhVbmtub3duRXJyb3IoJ1VuZXhwZWN0ZWQgZXJyb3IgaW4gcmVnaXN0ZXInLCBlcnJvciksXG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==