import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/ui/Toast.vue");import { default as __nuxt_component_0 } from "/_nuxt/ui/Text.vue";
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@7.3.5_@types+node@25.9.3_jiti@2.7.0_lightningcss@1.32_25873cf39478217df92d04054f55eaf3/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=583078ff"


import { onMounted } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff";
const _sfc_main = {
  __name: "Toast",
  props: {
	message: {
		type: String,
		required: true
	},
	duration: {
		type: Number,
		default: 5000
	},
	theme: {
		type: String,
		default: 'info',
		validator: v => ['info', 'error'].includes(v)
	}
},
  emits: ['close'],
  setup(__props, { expose: __expose, emit: __emit }) {
  __expose();

const props = __props

const emit = __emit

// Auto-close after duration
onMounted(() => {
	setTimeout(() => {
		emit('close')
	}, props.duration)
})

const __returned__ = { props, emit }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, normalizeClass as _normalizeClass, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/vue@3.5.41_typescript@5.9.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=583078ff"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Text = __nuxt_component_0

  return (_openBlock(), _tracer(29,1,_createElementBlock("div", {
    class: _normalizeClass(['toast', `toast--${$props.theme}`])
  }, [
    _tracer(30,2,_createVNode(_component_Text, { variant: "label" }, {
      default: _withCtx(() => [
        _createTextVNode(_toDisplayString($props.message), 1 /* TEXT */)
      ]),
      _: 1 /* STABLE */
    }))
  ], 2 /* CLASS */)))
}


import "/_nuxt/ui/Toast.vue?vue&type=style&index=0&scoped=eb2b1c14&lang.css"

_sfc_main.__hmrId = "eb2b1c14"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-eb2b1c14"],['__file',"/mnt/kire/Personal/Programming/Projects/MEIC/web/app/ui/Toast.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("app/ui/Toast.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBZ0JkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRWIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDOzs7Ozs7Ozs7Ozs7O3FDQUlBLG9CQUVNO0lBRkEsS0FBSyxzQ0FBc0IsWUFBSzs7aUJBQ3JDLGFBQTBDLG1CQUFwQyxPQUFPLEVBQUMsT0FBTzt3QkFBQyxDQUFhOzBDQUFWLGNBQU8iLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRvYXN0LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuY29uc3QgcHJvcHMgPSBkZWZpbmVQcm9wcyh7XG5cdG1lc3NhZ2U6IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0cmVxdWlyZWQ6IHRydWVcblx0fSxcblx0ZHVyYXRpb246IHtcblx0XHR0eXBlOiBOdW1iZXIsXG5cdFx0ZGVmYXVsdDogNTAwMFxuXHR9LFxuXHR0aGVtZToge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRkZWZhdWx0OiAnaW5mbycsXG5cdFx0dmFsaWRhdG9yOiB2ID0+IFsnaW5mbycsICdlcnJvciddLmluY2x1ZGVzKHYpXG5cdH1cbn0pXG5cbmNvbnN0IGVtaXQgPSBkZWZpbmVFbWl0cyhbJ2Nsb3NlJ10pXG5cbi8vIEF1dG8tY2xvc2UgYWZ0ZXIgZHVyYXRpb25cbm9uTW91bnRlZCgoKSA9PiB7XG5cdHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdGVtaXQoJ2Nsb3NlJylcblx0fSwgcHJvcHMuZHVyYXRpb24pXG59KVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cblx0PGRpdiA6Y2xhc3M9XCJbJ3RvYXN0JywgYHRvYXN0LS0ke3RoZW1lfWBdXCI+XG5cdFx0PFRleHQgdmFyaWFudD1cImxhYmVsXCI+e3sgbWVzc2FnZSB9fTwvVGV4dD5cblx0PC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c3R5bGUgc2NvcGVkPlxuLnRvYXN0IHtcblx0cGFkZGluZzogMC40cmVtIDAuOXJlbTtcblx0YW5pbWF0aW9uOiBmYWRlLXRvYXN0IDAuM3MgZWFzZTtcbn1cbi50b2FzdC0taW5mbyB7XG5cdGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLXRlYWwtYm9yZGVyKTtcblx0YmFja2dyb3VuZDogdmFyKC0tdGVhbC1kaW0pO1xufVxuLnRvYXN0LS1pbmZvIDpkZWVwKC5sYWJlbCkge1xuXHRjb2xvcjogdmFyKC0tdGVhbCk7XG59XG4udG9hc3QtLWVycm9yIHtcblx0Ym9yZGVyOiAxcHggc29saWQgdmFyKC0tcm9zZSk7XG5cdGJhY2tncm91bmQ6IHZhcigtLXJvc2UtZGltKTtcbn1cbi50b2FzdC0tZXJyb3IgOmRlZXAoLmxhYmVsKSB7XG5cdGNvbG9yOiB2YXIoLS1yb3NlKTtcbn1cblxuQGtleWZyYW1lcyBmYWRlLXRvYXN0IHtcblx0ZnJvbSB7IG9wYWNpdHk6IDA7IHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMHB4KTsgfVxuXHR0byB7IG9wYWNpdHk6IDE7IHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsgfVxufVxuPC9zdHlsZT5cbiJdLCJmaWxlIjoiL21udC9raXJlL1BlcnNvbmFsL1Byb2dyYW1taW5nL1Byb2plY3RzL01FSUMvd2ViL2FwcC91aS9Ub2FzdC52dWUifQ==