/**
* @vue/runtime-core v3.5.41
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
import { pauseTracking, resetTracking, isRef, toRaw, traverse, watch as watch$1, shallowRef, readonly, isReactive, ref, isShallow, isReadonly, shallowReadArray, toReadonly, toReactive, shallowReadonly, track, reactive, customRef, shallowReactive, trigger, ReactiveEffect, isProxy, proxyRefs, markRaw, EffectScope, computed as computed$1 } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+reactivity@3.5.41/node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js?v=583078ff";
export { EffectScope, ReactiveEffect, TrackOpTypes, TriggerOpTypes, customRef, effect, effectScope, getCurrentScope, getCurrentWatcher, isProxy, isReactive, isReadonly, isRef, isShallow, markRaw, onScopeDispose, onWatcherCleanup, proxyRefs, reactive, readonly, ref, shallowReactive, shallowReadonly, shallowRef, stop, toRaw, toRef, toRefs, toValue, triggerRef, unref } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+reactivity@3.5.41/node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js?v=583078ff";
import { isString, isFunction, EMPTY_OBJ, isPromise, isArray, NOOP, getGlobalThis, extend, isBuiltInDirective, NO, hasOwn, remove, def, isOn, isReservedProp, normalizeClass, stringifyStyle, normalizeStyle, isKnownSvgAttr, isBooleanAttr, isKnownHtmlAttr, includeBooleanAttr, isRenderableAttrValue, normalizeCssVarValue, getEscapedCssVarName, isObject, isRegExp, invokeArrayFns, toHandlerKey, camelize, capitalize, isSymbol, isGloballyAllowed, hyphenate, hasChanged, looseToNumber, isModelListener, looseEqual, EMPTY_ARR, toRawType, makeMap, toNumber } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+shared@3.5.41/node_modules/@vue/shared/dist/shared.esm-bundler.js?v=583078ff";
export { camelize, capitalize, normalizeClass, normalizeProps, normalizeStyle, toDisplayString, toHandlerKey } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+shared@3.5.41/node_modules/@vue/shared/dist/shared.esm-bundler.js?v=583078ff";
const stack = [];
function pushWarningContext(vnode) {
  stack.push(vnode);
}
function popWarningContext() {
  stack.pop();
}
let isWarning = false;
function warn$1(msg, ...args) {
  if (isWarning) return;
  isWarning = true;
  pauseTracking();
  const instance = stack.length ? stack[stack.length - 1].component : null;
  const appWarnHandler = instance && instance.appContext.config.warnHandler;
  const trace = getComponentTrace();
  if (appWarnHandler) {
    callWithErrorHandling(
      appWarnHandler,
      instance,
      11,
      [
        // eslint-disable-next-line no-restricted-syntax
        msg + args.map((a) => {
          var _a, _b;
          return (_b = (_a = a.toString) == null ? void 0 : _a.call(a)) != null ? _b : JSON.stringify(a);
        }).join(""),
        instance && instance.proxy,
        trace.map(
          ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
        ).join("\n"),
        trace
      ]
    );
  } else {
    const warnArgs = [`[Vue warn]: ${msg}`, ...args];
    if (trace.length && // avoid spamming console during tests
    true) {
      warnArgs.push(`
`, ...formatTrace(trace));
    }
    console.warn(...warnArgs);
  }
  resetTracking();
  isWarning = false;
}
function getComponentTrace() {
  let currentVNode = stack[stack.length - 1];
  if (!currentVNode) {
    return [];
  }
  const normalizedStack = [];
  while (currentVNode) {
    const last = normalizedStack[0];
    if (last && last.vnode === currentVNode) {
      last.recurseCount++;
    } else {
      normalizedStack.push({
        vnode: currentVNode,
        recurseCount: 0
      });
    }
    const parentInstance = currentVNode.component && currentVNode.component.parent;
    currentVNode = parentInstance && parentInstance.vnode;
  }
  return normalizedStack;
}
function formatTrace(trace) {
  const logs = [];
  trace.forEach((entry, i) => {
    logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
  });
  return logs;
}
function formatTraceEntry({ vnode, recurseCount }) {
  const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
  const isRoot = vnode.component ? vnode.component.parent == null : false;
  const open = ` at <${formatComponentName(
    vnode.component,
    vnode.type,
    isRoot
  )}`;
  const close = `>` + postfix;
  return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
}
function formatProps(props) {
  const res = [];
  const keys = Object.keys(props);
  keys.slice(0, 3).forEach((key) => {
    res.push(...formatProp(key, props[key]));
  });
  if (keys.length > 3) {
    res.push(` ...`);
  }
  return res;
}
function formatProp(key, value, raw) {
  if (isString(value)) {
    value = JSON.stringify(value);
    return raw ? value : [`${key}=${value}`];
  } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
    return raw ? value : [`${key}=${value}`];
  } else if (isRef(value)) {
    value = formatProp(key, toRaw(value.value), true);
    return raw ? value : [`${key}=Ref<`, value, `>`];
  } else if (isFunction(value)) {
    return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
  } else {
    value = toRaw(value);
    return raw ? value : [`${key}=`, value];
  }
}
function assertNumber(val, type) {
  if (false) return;
  if (val === void 0) {
    return;
  } else if (typeof val !== "number") {
    warn$1(`${type} is not a valid number - got ${JSON.stringify(val)}.`);
  } else if (isNaN(val)) {
    warn$1(`${type} is NaN - the duration expression might be incorrect.`);
  }
}
const ErrorCodes = {
  "SETUP_FUNCTION": 0,
  "0": "SETUP_FUNCTION",
  "RENDER_FUNCTION": 1,
  "1": "RENDER_FUNCTION",
  "NATIVE_EVENT_HANDLER": 5,
  "5": "NATIVE_EVENT_HANDLER",
  "COMPONENT_EVENT_HANDLER": 6,
  "6": "COMPONENT_EVENT_HANDLER",
  "VNODE_HOOK": 7,
  "7": "VNODE_HOOK",
  "DIRECTIVE_HOOK": 8,
  "8": "DIRECTIVE_HOOK",
  "TRANSITION_HOOK": 9,
  "9": "TRANSITION_HOOK",
  "APP_ERROR_HANDLER": 10,
  "10": "APP_ERROR_HANDLER",
  "APP_WARN_HANDLER": 11,
  "11": "APP_WARN_HANDLER",
  "FUNCTION_REF": 12,
  "12": "FUNCTION_REF",
  "ASYNC_COMPONENT_LOADER": 13,
  "13": "ASYNC_COMPONENT_LOADER",
  "SCHEDULER": 14,
  "14": "SCHEDULER",
  "COMPONENT_UPDATE": 15,
  "15": "COMPONENT_UPDATE",
  "APP_UNMOUNT_CLEANUP": 16,
  "16": "APP_UNMOUNT_CLEANUP"
};
const ErrorTypeStrings$1 = {
  ["sp"]: "serverPrefetch hook",
  ["bc"]: "beforeCreate hook",
  ["c"]: "created hook",
  ["bm"]: "beforeMount hook",
  ["m"]: "mounted hook",
  ["bu"]: "beforeUpdate hook",
  ["u"]: "updated",
  ["bum"]: "beforeUnmount hook",
  ["um"]: "unmounted hook",
  ["a"]: "activated hook",
  ["da"]: "deactivated hook",
  ["ec"]: "errorCaptured hook",
  ["rtc"]: "renderTracked hook",
  ["rtg"]: "renderTriggered hook",
  [0]: "setup function",
  [1]: "render function",
  [2]: "watcher getter",
  [3]: "watcher callback",
  [4]: "watcher cleanup function",
  [5]: "native event handler",
  [6]: "component event handler",
  [7]: "vnode hook",
  [8]: "directive hook",
  [9]: "transition hook",
  [10]: "app errorHandler",
  [11]: "app warnHandler",
  [12]: "ref function",
  [13]: "async component loader",
  [14]: "scheduler flush",
  [15]: "component update",
  [16]: "app unmount cleanup function"
};
function callWithErrorHandling(fn, instance, type, args) {
  try {
    return args ? fn(...args) : fn();
  } catch (err) {
    handleError(err, instance, type);
  }
}
function callWithAsyncErrorHandling(fn, instance, type, args) {
  if (isFunction(fn)) {
    const res = callWithErrorHandling(fn, instance, type, args);
    if (res && isPromise(res)) {
      res.catch((err) => {
        handleError(err, instance, type);
      });
    }
    return res;
  }
  if (isArray(fn)) {
    const values = [];
    for (let i = 0; i < fn.length; i++) {
      values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
    }
    return values;
  } else if (true) {
    warn$1(
      `Invalid value type passed to callWithAsyncErrorHandling(): ${typeof fn}`
    );
  }
}
function handleError(err, instance, type, throwInDev = true) {
  const contextVNode = instance ? instance.vnode : null;
  const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
  if (instance) {
    let cur = instance.parent;
    const exposedInstance = instance.proxy;
    const errorInfo = true ? ErrorTypeStrings$1[type] : `https://vuejs.org/error-reference/#runtime-${type}`;
    while (cur) {
      const errorCapturedHooks = cur.ec;
      if (errorCapturedHooks) {
        for (let i = 0; i < errorCapturedHooks.length; i++) {
          if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
            return;
          }
        }
      }
      cur = cur.parent;
    }
    if (errorHandler) {
      pauseTracking();
      callWithErrorHandling(errorHandler, null, 10, [
        err,
        exposedInstance,
        errorInfo
      ]);
      resetTracking();
      return;
    }
  }
  logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
}
function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
  if (true) {
    const info = ErrorTypeStrings$1[type];
    if (contextVNode) {
      pushWarningContext(contextVNode);
    }
    warn$1(`Unhandled error${info ? ` during execution of ${info}` : ``}`);
    if (contextVNode) {
      popWarningContext();
    }
    if (throwInDev) {
      throw err;
    } else {
      console.error(err);
    }
  } else if (throwInProd) {
    throw err;
  } else {
    console.error(err);
  }
}
const queue = [];
let flushIndex = -1;
const pendingPostFlushCbs = [];
let activePostFlushCbs = null;
let postFlushIndex = 0;
const resolvedPromise = /* @__PURE__ */ Promise.resolve();
let currentFlushPromise = null;
const RECURSION_LIMIT = 100;
function nextTick(fn) {
  const p = currentFlushPromise || resolvedPromise;
  return fn ? p.then(this ? fn.bind(this) : fn) : p;
}
function findInsertionIndex(id) {
  let start = flushIndex + 1;
  let end = queue.length;
  while (start < end) {
    const middle = start + end >>> 1;
    const middleJob = queue[middle];
    const middleJobId = getId(middleJob);
    if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
      start = middle + 1;
    } else {
      end = middle;
    }
  }
  return start;
}
function queueJob(job) {
  if (!(job.flags & 1)) {
    const jobId = getId(job);
    const lastJob = queue[queue.length - 1];
    if (!lastJob || // fast path when the job id is larger than the tail
    !(job.flags & 2) && jobId >= getId(lastJob)) {
      queue.push(job);
    } else {
      queue.splice(findInsertionIndex(jobId), 0, job);
    }
    job.flags |= 1;
    queueFlush();
  }
}
function queueFlush() {
  if (!currentFlushPromise) {
    currentFlushPromise = resolvedPromise.then(flushJobs);
  }
}
function queuePostFlushCb(cb) {
  if (!isArray(cb)) {
    if (activePostFlushCbs && cb.id === -1) {
      activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
    } else if (!(cb.flags & 1)) {
      pendingPostFlushCbs.push(cb);
      cb.flags |= 1;
    }
  } else {
    for (let i = 0; i < cb.length; i++) {
      pendingPostFlushCbs.push(cb[i]);
    }
  }
  queueFlush();
}
function flushPreFlushCbs(instance, seen, i = flushIndex + 1) {
  if (true) {
    seen = seen || /* @__PURE__ */ new Map();
  }
  for (; i < queue.length; i++) {
    const cb = queue[i];
    if (cb && cb.flags & 2) {
      if (instance && cb.id !== instance.uid) {
        continue;
      }
      if (checkRecursiveUpdates(seen, cb)) {
        continue;
      }
      queue.splice(i, 1);
      i--;
      if (cb.flags & 4) {
        cb.flags &= -2;
      }
      cb();
      if (!(cb.flags & 4)) {
        cb.flags &= -2;
      }
    }
  }
}
function flushPostFlushCbs(seen) {
  if (pendingPostFlushCbs.length) {
    const deduped = [...new Set(pendingPostFlushCbs)].sort(
      (a, b) => getId(a) - getId(b)
    );
    pendingPostFlushCbs.length = 0;
    if (activePostFlushCbs) {
      for (let i = 0; i < deduped.length; i++) {
        activePostFlushCbs.push(deduped[i]);
      }
      return;
    }
    activePostFlushCbs = deduped;
    if (true) {
      seen = seen || /* @__PURE__ */ new Map();
    }
    for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
      const cb = activePostFlushCbs[postFlushIndex];
      if (checkRecursiveUpdates(seen, cb)) {
        continue;
      }
      if (cb.flags & 4) {
        cb.flags &= -2;
      }
      if (!(cb.flags & 8)) cb();
      cb.flags &= -2;
    }
    activePostFlushCbs = null;
    postFlushIndex = 0;
  }
}
const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
function flushJobs(seen) {
  if (true) {
    seen = seen || /* @__PURE__ */ new Map();
  }
  const check = true ? (job) => checkRecursiveUpdates(seen, job) : NOOP;
  try {
    for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
      const job = queue[flushIndex];
      if (job && !(job.flags & 8)) {
        if (check(job)) {
          continue;
        }
        if (job.flags & 4) {
          job.flags &= ~1;
        }
        callWithErrorHandling(
          job,
          job.i,
          job.i ? 15 : 14
        );
        if (!(job.flags & 4)) {
          job.flags &= ~1;
        }
      }
    }
  } finally {
    for (; flushIndex < queue.length; flushIndex++) {
      const job = queue[flushIndex];
      if (job) {
        job.flags &= -2;
      }
    }
    flushIndex = -1;
    queue.length = 0;
    flushPostFlushCbs(seen);
    currentFlushPromise = null;
    if (queue.length || pendingPostFlushCbs.length) {
      flushJobs(seen);
    }
  }
}
function checkRecursiveUpdates(seen, fn) {
  const count = seen.get(fn) || 0;
  if (count > RECURSION_LIMIT) {
    const instance = fn.i;
    const componentName = instance && getComponentName(instance.type);
    handleError(
      `Maximum recursive updates exceeded${componentName ? ` in component <${componentName}>` : ``}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`,
      null,
      10
    );
    return true;
  }
  seen.set(fn, count + 1);
  return false;
}
let isHmrUpdating = false;
const setHmrUpdating = (v) => {
  try {
    return isHmrUpdating;
  } finally {
    isHmrUpdating = v;
  }
};
const hmrDirtyComponents = /* @__PURE__ */ new Map();
if (true) {
  getGlobalThis().__VUE_HMR_RUNTIME__ = {
    createRecord: tryWrap(createRecord),
    rerender: tryWrap(rerender),
    reload: tryWrap(reload)
  };
}
const map = /* @__PURE__ */ new Map();
function registerHMR(instance) {
  const id = instance.type.__hmrId;
  let record = map.get(id);
  if (!record) {
    createRecord(id, instance.type);
    record = map.get(id);
  }
  record.instances.add(instance);
}
function unregisterHMR(instance) {
  map.get(instance.type.__hmrId).instances.delete(instance);
}
function createRecord(id, initialDef) {
  if (map.has(id)) {
    return false;
  }
  map.set(id, {
    initialDef: normalizeClassComponent(initialDef),
    instances: /* @__PURE__ */ new Set()
  });
  return true;
}
function normalizeClassComponent(component) {
  return isClassComponent(component) ? component.__vccOpts : component;
}
function rerender(id, newRender) {
  const record = map.get(id);
  if (!record) {
    return;
  }
  record.initialDef.render = newRender;
  [...record.instances].forEach((instance) => {
    if (newRender) {
      instance.render = newRender;
      normalizeClassComponent(instance.type).render = newRender;
    }
    instance.renderCache = [];
    isHmrUpdating = true;
    if (!(instance.job.flags & 8)) {
      instance.update();
    }
    isHmrUpdating = false;
  });
}
function reload(id, newComp) {
  const record = map.get(id);
  if (!record) return;
  newComp = normalizeClassComponent(newComp);
  updateComponentDef(record.initialDef, newComp);
  const instances = [...record.instances];
  for (let i = 0; i < instances.length; i++) {
    const instance = instances[i];
    const oldComp = normalizeClassComponent(instance.type);
    let dirtyInstances = hmrDirtyComponents.get(oldComp);
    if (!dirtyInstances) {
      if (oldComp !== record.initialDef) {
        updateComponentDef(oldComp, newComp);
      }
      hmrDirtyComponents.set(oldComp, dirtyInstances = /* @__PURE__ */ new Set());
    }
    dirtyInstances.add(instance);
    instance.appContext.propsCache.delete(instance.type);
    instance.appContext.emitsCache.delete(instance.type);
    instance.appContext.optionsCache.delete(instance.type);
    if (instance.ceReload) {
      dirtyInstances.add(instance);
      instance.ceReload(newComp.styles);
      dirtyInstances.delete(instance);
    } else if (instance.parent) {
      queueJob(() => {
        if (!(instance.job.flags & 8)) {
          isHmrUpdating = true;
          instance.parent.update();
          isHmrUpdating = false;
          dirtyInstances.delete(instance);
        }
      });
    } else if (instance.appContext.reload) {
      instance.appContext.reload();
    } else if (typeof window !== "undefined") {
      window.location.reload();
    } else {
      console.warn(
        "[HMR] Root or manually mounted instance modified. Full reload required."
      );
    }
    if (instance.root.ce && instance !== instance.root) {
      instance.root.ce._removeChildStyle(oldComp);
    }
  }
  queuePostFlushCb(() => {
    hmrDirtyComponents.clear();
  });
}
function updateComponentDef(oldComp, newComp) {
  extend(oldComp, newComp);
  for (const key in oldComp) {
    if (key !== "__file" && !(key in newComp)) {
      delete oldComp[key];
    }
  }
}
function tryWrap(fn) {
  return (id, arg) => {
    try {
      return fn(id, arg);
    } catch (e) {
      console.error(e);
      console.warn(
        `[HMR] Something went wrong during Vue component hot-reload. Full reload required.`
      );
    }
  };
}
let devtools$1;
let buffer = [];
let devtoolsNotInstalled = false;
function emit$1(event, ...args) {
  if (devtools$1) {
    devtools$1.emit(event, ...args);
  } else if (!devtoolsNotInstalled) {
    buffer.push({ event, args });
  }
}
function setDevtoolsHook$1(hook, target) {
  var _a, _b;
  devtools$1 = hook;
  if (devtools$1) {
    devtools$1.enabled = true;
    buffer.forEach(({ event, args }) => devtools$1.emit(event, ...args));
    buffer = [];
  } else if (
    // handle late devtools injection - only do this if we are in an actual
    // browser environment to avoid the timer handle stalling test runner exit
    // (#4815)
    typeof window !== "undefined" && // some envs mock window but not fully
    window.HTMLElement && // also exclude jsdom
    // eslint-disable-next-line no-restricted-syntax
    !((_b = (_a = window.navigator) == null ? void 0 : _a.userAgent) == null ? void 0 : _b.includes("jsdom"))
  ) {
    const replay = target.__VUE_DEVTOOLS_HOOK_REPLAY__ = target.__VUE_DEVTOOLS_HOOK_REPLAY__ || [];
    replay.push((newHook) => {
      setDevtoolsHook$1(newHook, target);
    });
    setTimeout(() => {
      if (!devtools$1) {
        target.__VUE_DEVTOOLS_HOOK_REPLAY__ = null;
        devtoolsNotInstalled = true;
        buffer = [];
      }
    }, 3e3);
  } else {
    devtoolsNotInstalled = true;
    buffer = [];
  }
}
function devtoolsInitApp(app, version2) {
  emit$1("app:init", app, version2, {
    Fragment,
    Text,
    Comment,
    Static
  });
}
function devtoolsUnmountApp(app) {
  emit$1("app:unmount", app);
}
const devtoolsComponentAdded = /* @__PURE__ */ createDevtoolsComponentHook(
  "component:added"
  /* COMPONENT_ADDED */
);
const devtoolsComponentUpdated = /* @__PURE__ */ createDevtoolsComponentHook(
  "component:updated"
  /* COMPONENT_UPDATED */
);
const _devtoolsComponentRemoved = /* @__PURE__ */ createDevtoolsComponentHook(
  "component:removed"
  /* COMPONENT_REMOVED */
);
const devtoolsComponentRemoved = (component) => {
  if (devtools$1 && typeof devtools$1.cleanupBuffer === "function" && // remove the component if it wasn't buffered
  !devtools$1.cleanupBuffer(component)) {
    _devtoolsComponentRemoved(component);
  }
};
// @__NO_SIDE_EFFECTS__
function createDevtoolsComponentHook(hook) {
  return (component) => {
    emit$1(
      hook,
      component.appContext.app,
      component.uid,
      component.parent ? component.parent.uid : void 0,
      component
    );
  };
}
const devtoolsPerfStart = /* @__PURE__ */ createDevtoolsPerformanceHook(
  "perf:start"
  /* PERFORMANCE_START */
);
const devtoolsPerfEnd = /* @__PURE__ */ createDevtoolsPerformanceHook(
  "perf:end"
  /* PERFORMANCE_END */
);
function createDevtoolsPerformanceHook(hook) {
  return (component, type, time) => {
    emit$1(hook, component.appContext.app, component.uid, component, type, time);
  };
}
function devtoolsComponentEmit(component, event, params) {
  emit$1(
    "component:emit",
    component.appContext.app,
    component,
    event,
    params
  );
}
let currentRenderingInstance = null;
let currentScopeId = null;
function setCurrentRenderingInstance(instance) {
  const prev = currentRenderingInstance;
  currentRenderingInstance = instance;
  currentScopeId = instance && instance.type.__scopeId || null;
  return prev;
}
function pushScopeId(id) {
  currentScopeId = id;
}
function popScopeId() {
  currentScopeId = null;
}
const withScopeId = (_id) => withCtx;
function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
  if (!ctx) return fn;
  if (fn._n) {
    return fn;
  }
  const renderFnWithContext = (...args) => {
    if (renderFnWithContext._d) {
      setBlockTracking(-1);
    }
    const prevInstance = setCurrentRenderingInstance(ctx);
    const prevStackSize = blockStack.length;
    let res;
    try {
      res = fn(...args);
    } finally {
      for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
      setCurrentRenderingInstance(prevInstance);
      if (renderFnWithContext._d) {
        setBlockTracking(1);
      }
    }
    if (true) {
      devtoolsComponentUpdated(ctx);
    }
    return res;
  };
  renderFnWithContext._n = true;
  renderFnWithContext._c = true;
  renderFnWithContext._d = true;
  return renderFnWithContext;
}
function validateDirectiveName(name) {
  if (isBuiltInDirective(name)) {
    warn$1("Do not use built-in directive ids as custom directive id: " + name);
  }
}
function withDirectives(vnode, directives) {
  if (currentRenderingInstance === null) {
    warn$1(`withDirectives can only be used inside render functions.`);
    return vnode;
  }
  const instance = getComponentPublicInstance(currentRenderingInstance);
  const bindings = vnode.dirs || (vnode.dirs = []);
  for (let i = 0; i < directives.length; i++) {
    let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
    if (dir) {
      if (isFunction(dir)) {
        dir = {
          mounted: dir,
          updated: dir
        };
      }
      if (dir.deep) {
        traverse(value);
      }
      bindings.push({
        dir,
        instance,
        value,
        oldValue: void 0,
        arg,
        modifiers
      });
    }
  }
  return vnode;
}
function invokeDirectiveHook(vnode, prevVNode, instance, name) {
  const bindings = vnode.dirs;
  const oldBindings = prevVNode && prevVNode.dirs;
  for (let i = 0; i < bindings.length; i++) {
    const binding = bindings[i];
    if (oldBindings) {
      binding.oldValue = oldBindings[i].value;
    }
    let hook = binding.dir[name];
    if (hook) {
      pauseTracking();
      callWithAsyncErrorHandling(hook, instance, 8, [
        vnode.el,
        binding,
        vnode,
        prevVNode
      ]);
      resetTracking();
    }
  }
}
function provide(key, value) {
  if (true) {
    if (!currentInstance || currentInstance.isMounted) {
      warn$1(`provide() can only be used inside setup().`);
    }
  }
  if (currentInstance) {
    let provides = currentInstance.provides;
    const parentProvides = currentInstance.parent && currentInstance.parent.provides;
    if (parentProvides === provides) {
      provides = currentInstance.provides = Object.create(parentProvides);
    }
    provides[key] = value;
  }
}
function inject(key, defaultValue, treatDefaultAsFactory = false) {
  const instance = getCurrentInstance();
  if (instance || currentApp) {
    let provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null || instance.ce ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
    if (provides && key in provides) {
      return provides[key];
    } else if (arguments.length > 1) {
      return treatDefaultAsFactory && isFunction(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
    } else if (true) {
      warn$1(`injection "${String(key)}" not found.`);
    }
  } else if (true) {
    warn$1(`inject() can only be used inside setup() or functional components.`);
  }
}
function hasInjectionContext() {
  return !!(getCurrentInstance() || currentApp);
}
const ssrContextKey = /* @__PURE__ */ Symbol.for("v-scx");
const useSSRContext = () => {
  {
    const ctx = inject(ssrContextKey);
    if (!ctx) {
      warn$1(
        `Server rendering context not provided. Make sure to only call useSSRContext() conditionally in the server build.`
      );
    }
    return ctx;
  }
};
function watchEffect(effect2, options) {
  return doWatch(effect2, null, options);
}
function watchPostEffect(effect2, options) {
  return doWatch(
    effect2,
    null,
    true ? extend({}, options, { flush: "post" }) : { flush: "post" }
  );
}
function watchSyncEffect(effect2, options) {
  return doWatch(
    effect2,
    null,
    true ? extend({}, options, { flush: "sync" }) : { flush: "sync" }
  );
}
function watch(source, cb, options) {
  if (!isFunction(cb)) {
    warn$1(
      `\`watch(fn, options?)\` signature has been moved to a separate API. Use \`watchEffect(fn, options?)\` instead. \`watch\` now only supports \`watch(source, cb, options?) signature.`
    );
  }
  return doWatch(source, cb, options);
}
function doWatch(source, cb, options = EMPTY_OBJ) {
  const { immediate, deep, flush, once } = options;
  if (!cb) {
    if (immediate !== void 0) {
      warn$1(
        `watch() "immediate" option is only respected when using the watch(source, callback, options?) signature.`
      );
    }
    if (deep !== void 0) {
      warn$1(
        `watch() "deep" option is only respected when using the watch(source, callback, options?) signature.`
      );
    }
    if (once !== void 0) {
      warn$1(
        `watch() "once" option is only respected when using the watch(source, callback, options?) signature.`
      );
    }
  }
  const baseWatchOptions = extend({}, options);
  if (true) baseWatchOptions.onWarn = warn$1;
  const runsImmediately = cb && immediate || !cb && flush !== "post";
  let ssrCleanup;
  if (isInSSRComponentSetup) {
    if (flush === "sync") {
      const ctx = useSSRContext();
      ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
    } else if (!runsImmediately) {
      const watchStopHandle = () => {
      };
      watchStopHandle.stop = NOOP;
      watchStopHandle.resume = NOOP;
      watchStopHandle.pause = NOOP;
      return watchStopHandle;
    }
  }
  const instance = currentInstance;
  baseWatchOptions.call = (fn, type, args) => callWithAsyncErrorHandling(fn, instance, type, args);
  let isPre = false;
  if (flush === "post") {
    baseWatchOptions.scheduler = (job) => {
      queuePostRenderEffect(job, instance && instance.suspense);
    };
  } else if (flush !== "sync") {
    isPre = true;
    baseWatchOptions.scheduler = (job, isFirstRun) => {
      if (isFirstRun) {
        job();
      } else {
        queueJob(job);
      }
    };
  }
  baseWatchOptions.augmentJob = (job) => {
    if (cb) {
      job.flags |= 4;
    }
    if (isPre) {
      job.flags |= 2;
      if (instance) {
        job.id = instance.uid;
        job.i = instance;
      }
    }
  };
  const watchHandle = watch$1(source, cb, baseWatchOptions);
  if (isInSSRComponentSetup) {
    if (ssrCleanup) {
      ssrCleanup.push(watchHandle);
    } else if (runsImmediately) {
      watchHandle();
    }
  }
  return watchHandle;
}
function instanceWatch(source, value, options) {
  const publicThis = this.proxy;
  const getter = isString(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
  let cb;
  if (isFunction(value)) {
    cb = value;
  } else {
    cb = value.handler;
    options = value;
  }
  const reset = setCurrentInstance(this);
  const res = doWatch(getter, cb.bind(publicThis), options);
  reset();
  return res;
}
function createPathGetter(ctx, path) {
  const segments = path.split(".");
  return () => {
    let cur = ctx;
    for (let i = 0; i < segments.length && cur; i++) {
      cur = cur[segments[i]];
    }
    return cur;
  };
}
const pendingMounts = /* @__PURE__ */ new WeakMap();
const TeleportEndKey = /* @__PURE__ */ Symbol("_vte");
const isTeleport = (type) => type.__isTeleport;
const isTeleportDisabled = (props) => props && (props.disabled || props.disabled === "");
const isTeleportDeferred = (props) => props && (props.defer || props.defer === "");
const isTargetSVG = (target) => typeof SVGElement !== "undefined" && target instanceof SVGElement;
const isTargetMathML = (target) => typeof MathMLElement === "function" && target instanceof MathMLElement;
const resolveTarget = (props, select) => {
  const targetSelector = props && props.to;
  if (isString(targetSelector)) {
    if (!select) {
      warn$1(
        `Current renderer does not support string target for Teleports. (missing querySelector renderer option)`
      );
      return null;
    } else {
      const target = select(targetSelector);
      if (!target && !isTeleportDisabled(props)) {
        warn$1(
          `Failed to locate Teleport target with selector "${targetSelector}". Note the target element must exist before the component is mounted - i.e. the target cannot be rendered by the component itself, and ideally should be outside of the entire Vue component tree.`
        );
      }
      return target;
    }
  } else {
    if (!targetSelector && !isTeleportDisabled(props)) {
      warn$1(`Invalid Teleport target: ${targetSelector}`);
    }
    return targetSelector;
  }
};
const TeleportImpl = {
  name: "Teleport",
  __isTeleport: true,
  process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals) {
    const {
      mc: mountChildren,
      pc: patchChildren,
      pbc: patchBlockChildren,
      o: { insert, querySelector, createText, createComment, parentNode }
    } = internals;
    const disabled = isTeleportDisabled(n2.props);
    let { dynamicChildren } = n2;
    if (isHmrUpdating) {
      optimized = false;
      dynamicChildren = null;
    }
    const mount = (vnode, container2, anchor2) => {
      if (vnode.shapeFlag & 16) {
        mountChildren(
          vnode.children,
          container2,
          anchor2,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
    };
    const mountToTarget = (vnode = n2) => {
      const disabled2 = isTeleportDisabled(vnode.props);
      const target = vnode.target = resolveTarget(vnode.props, querySelector);
      const targetAnchor = prepareAnchor(target, vnode, createText, insert);
      if (target) {
        if (namespace !== "svg" && isTargetSVG(target)) {
          namespace = "svg";
        } else if (namespace !== "mathml" && isTargetMathML(target)) {
          namespace = "mathml";
        }
        if (parentComponent && parentComponent.isCE) {
          (parentComponent.ce._teleportTargets || (parentComponent.ce._teleportTargets = /* @__PURE__ */ new Set())).add(target);
        }
        if (!disabled2) {
          mount(vnode, target, targetAnchor);
          updateCssVars(vnode, false);
        }
      } else if (!disabled2) {
        warn$1("Invalid Teleport target on mount:", target, `(${typeof target})`);
      }
    };
    const queuePendingMount = (vnode) => {
      const mountJob = () => {
        if (pendingMounts.get(vnode) !== mountJob) return;
        pendingMounts.delete(vnode);
        if (isTeleportDisabled(vnode.props)) {
          const mountContainer = parentNode(vnode.el) || container;
          mount(vnode, mountContainer, vnode.anchor);
          updateCssVars(vnode, true);
        }
        mountToTarget(vnode);
      };
      pendingMounts.set(vnode, mountJob);
      queuePostRenderEffect(mountJob, parentSuspense);
    };
    if (n1 == null) {
      const placeholder = n2.el = true ? createComment("teleport start") : createText("");
      const mainAnchor = n2.anchor = true ? createComment("teleport end") : createText("");
      insert(placeholder, container, anchor);
      insert(mainAnchor, container, anchor);
      if (isTeleportDeferred(n2.props) || parentSuspense && parentSuspense.pendingBranch) {
        queuePendingMount(n2);
        return;
      }
      if (disabled) {
        mount(n2, container, mainAnchor);
        updateCssVars(n2, true);
      }
      mountToTarget();
    } else {
      n2.el = n1.el;
      const mainAnchor = n2.anchor = n1.anchor;
      const pendingMount = pendingMounts.get(n1);
      if (pendingMount) {
        pendingMount.flags |= 8;
        pendingMounts.delete(n1);
        queuePendingMount(n2);
        return;
      }
      n2.targetStart = n1.targetStart;
      const target = n2.target = n1.target;
      const targetAnchor = n2.targetAnchor = n1.targetAnchor;
      const wasDisabled = isTeleportDisabled(n1.props);
      const currentContainer = wasDisabled ? container : target;
      const currentAnchor = wasDisabled ? mainAnchor : targetAnchor;
      if (namespace === "svg" || isTargetSVG(target)) {
        namespace = "svg";
      } else if (namespace === "mathml" || isTargetMathML(target)) {
        namespace = "mathml";
      }
      if (dynamicChildren) {
        patchBlockChildren(
          n1.dynamicChildren,
          dynamicChildren,
          currentContainer,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds
        );
        traverseStaticChildren(n1, n2, false);
      } else if (!optimized) {
        patchChildren(
          n1,
          n2,
          currentContainer,
          currentAnchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          false
        );
      }
      if (disabled) {
        if (!wasDisabled) {
          moveTeleport(
            n2,
            container,
            mainAnchor,
            internals,
            1
          );
        } else {
          if (n2.props && n1.props && n2.props.to !== n1.props.to) {
            n2.props.to = n1.props.to;
          }
        }
      } else {
        if ((n2.props && n2.props.to) !== (n1.props && n1.props.to)) {
          const nextTarget = resolveTarget(n2.props, querySelector);
          if (nextTarget) {
            n2.target = nextTarget;
            moveTeleport(
              n2,
              nextTarget,
              null,
              internals,
              0
            );
          } else if (true) {
            warn$1(
              "Invalid Teleport target on update:",
              target,
              `(${typeof target})`
            );
          }
        } else if (wasDisabled) {
          moveTeleport(
            n2,
            target,
            targetAnchor,
            internals,
            1
          );
        }
      }
      updateCssVars(n2, disabled);
    }
  },
  remove(vnode, parentComponent, parentSuspense, { um: unmount, o: { remove: hostRemove } }, doRemove) {
    const {
      shapeFlag,
      children,
      anchor,
      targetStart,
      targetAnchor,
      target,
      props
    } = vnode;
    const disabled = isTeleportDisabled(props);
    const shouldRemove = doRemove || !disabled;
    const pendingMount = pendingMounts.get(vnode);
    if (pendingMount) {
      pendingMount.flags |= 8;
      pendingMounts.delete(vnode);
    }
    if (target) {
      hostRemove(targetStart);
      hostRemove(targetAnchor);
    }
    doRemove && hostRemove(anchor);
    if (!pendingMount && (disabled || target) && shapeFlag & 16) {
      for (let i = 0; i < children.length; i++) {
        const child = children[i];
        unmount(
          child,
          parentComponent,
          parentSuspense,
          shouldRemove,
          !!child.dynamicChildren
        );
      }
    }
  },
  move: moveTeleport,
  hydrate: hydrateTeleport
};
function moveTeleport(vnode, container, parentAnchor, { o: { insert }, m: move }, moveType = 2) {
  if (moveType === 0) {
    insert(vnode.targetAnchor, container, parentAnchor);
  }
  const { el, anchor, shapeFlag, children, props } = vnode;
  const isReorder = moveType === 2;
  if (isReorder) {
    insert(el, container, parentAnchor);
  }
  if (!pendingMounts.has(vnode) && (!isReorder || isTeleportDisabled(props))) {
    if (shapeFlag & 16) {
      for (let i = 0; i < children.length; i++) {
        move(
          children[i],
          container,
          parentAnchor,
          2
        );
      }
    }
  }
  if (isReorder) {
    insert(anchor, container, parentAnchor);
  }
}
function hydrateTeleport(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, {
  o: { nextSibling, parentNode, querySelector, insert, createText }
}, hydrateChildren) {
  function hydrateAnchor(target2, targetNode) {
    let targetAnchor = targetNode;
    while (targetAnchor) {
      if (targetAnchor && targetAnchor.nodeType === 8) {
        if (targetAnchor.data === "teleport start anchor") {
          vnode.targetStart = targetAnchor;
        } else if (targetAnchor.data === "teleport anchor") {
          vnode.targetAnchor = targetAnchor;
          target2._lpa = vnode.targetAnchor && nextSibling(vnode.targetAnchor);
          break;
        }
      }
      targetAnchor = nextSibling(targetAnchor);
    }
  }
  function hydrateDisabledTeleport(node2, vnode2) {
    vnode2.anchor = hydrateChildren(
      nextSibling(node2),
      vnode2,
      parentNode(node2),
      parentComponent,
      parentSuspense,
      slotScopeIds,
      optimized
    );
  }
  const target = vnode.target = resolveTarget(
    vnode.props,
    querySelector
  );
  const disabled = isTeleportDisabled(vnode.props);
  if (target) {
    const targetNode = target._lpa || target.firstChild;
    if (vnode.shapeFlag & 16) {
      if (disabled) {
        hydrateDisabledTeleport(node, vnode);
        hydrateAnchor(target, targetNode);
        if (!vnode.targetAnchor) {
          prepareAnchor(
            target,
            vnode,
            createText,
            insert,
            // if target is the same as the main view, insert anchors before current node
            // to avoid hydrating mismatch
            parentNode(node) === target ? node : null
          );
        }
      } else {
        vnode.anchor = nextSibling(node);
        hydrateAnchor(target, targetNode);
        if (!vnode.targetAnchor) {
          prepareAnchor(target, vnode, createText, insert);
        }
        hydrateChildren(
          targetNode && nextSibling(targetNode),
          vnode,
          target,
          parentComponent,
          parentSuspense,
          slotScopeIds,
          optimized
        );
      }
    }
    updateCssVars(vnode, disabled);
  } else if (disabled) {
    if (vnode.shapeFlag & 16) {
      hydrateDisabledTeleport(node, vnode);
      vnode.targetStart = node;
      vnode.targetAnchor = nextSibling(node);
    }
  }
  return vnode.anchor && nextSibling(vnode.anchor);
}
const Teleport = TeleportImpl;
function updateCssVars(vnode, isDisabled) {
  const ctx = vnode.ctx;
  if (ctx && ctx.ut) {
    let node, anchor;
    if (isDisabled) {
      node = vnode.el;
      anchor = vnode.anchor;
    } else {
      node = vnode.targetStart;
      anchor = vnode.targetAnchor;
    }
    while (node && node !== anchor) {
      if (node.nodeType === 1) node.setAttribute("data-v-owner", ctx.uid);
      node = node.nextSibling;
    }
    ctx.ut();
  }
}
function prepareAnchor(target, vnode, createText, insert, anchor = null) {
  const targetStart = vnode.targetStart = createText("");
  const targetAnchor = vnode.targetAnchor = createText("");
  targetStart[TeleportEndKey] = targetAnchor;
  if (target) {
    insert(targetStart, target, anchor);
    insert(targetAnchor, target, anchor);
  }
  return targetAnchor;
}
const leaveCbKey = /* @__PURE__ */ Symbol("_leaveCb");
const enterCbKey = /* @__PURE__ */ Symbol("_enterCb");
function useTransitionState() {
  const state = {
    isMounted: false,
    isLeaving: false,
    isUnmounting: false,
    leavingVNodes: /* @__PURE__ */ new Map()
  };
  onMounted(() => {
    state.isMounted = true;
  });
  onBeforeUnmount(() => {
    state.isUnmounting = true;
  });
  return state;
}
const TransitionHookValidator = [Function, Array];
const BaseTransitionPropsValidators = {
  mode: String,
  appear: Boolean,
  persisted: Boolean,
  // enter
  onBeforeEnter: TransitionHookValidator,
  onEnter: TransitionHookValidator,
  onAfterEnter: TransitionHookValidator,
  onEnterCancelled: TransitionHookValidator,
  // leave
  onBeforeLeave: TransitionHookValidator,
  onLeave: TransitionHookValidator,
  onAfterLeave: TransitionHookValidator,
  onLeaveCancelled: TransitionHookValidator,
  // appear
  onBeforeAppear: TransitionHookValidator,
  onAppear: TransitionHookValidator,
  onAfterAppear: TransitionHookValidator,
  onAppearCancelled: TransitionHookValidator
};
const recursiveGetSubtree = (instance) => {
  const subTree = instance.subTree;
  return subTree.component ? recursiveGetSubtree(subTree.component) : subTree;
};
const BaseTransitionImpl = {
  name: `BaseTransition`,
  props: BaseTransitionPropsValidators,
  setup(props, { slots }) {
    const instance = getCurrentInstance();
    const state = useTransitionState();
    return () => {
      const children = slots.default && getTransitionRawChildren(slots.default(), true);
      const child = children && children.length ? findNonCommentChild(children) : (
        // Keep explicit default-slot conditionals on the same transition path
        // as regular v-if branches, which render a comment placeholder.
        instance.subTree ? createCommentVNode() : void 0
      );
      if (!child) {
        return;
      }
      const rawProps = toRaw(props);
      const { mode } = rawProps;
      if (mode && mode !== "in-out" && mode !== "out-in" && mode !== "default") {
        warn$1(`invalid <transition> mode: ${mode}`);
      }
      if (state.isLeaving) {
        return emptyPlaceholder(child);
      }
      const innerChild = getInnerChild$1(child);
      if (!innerChild) {
        return emptyPlaceholder(child);
      }
      let enterHooks = resolveTransitionHooks(
        innerChild,
        rawProps,
        state,
        instance,
        // #11061, ensure enterHooks is fresh after clone
        (hooks) => enterHooks = hooks
      );
      if (innerChild.type !== Comment) {
        setTransitionHooks(innerChild, enterHooks);
      }
      let oldInnerChild = instance.subTree && getInnerChild$1(instance.subTree);
      if (oldInnerChild && oldInnerChild.type !== Comment && !isSameVNodeType(oldInnerChild, innerChild) && recursiveGetSubtree(instance).type !== Comment) {
        let leavingHooks = resolveTransitionHooks(
          oldInnerChild,
          rawProps,
          state,
          instance
        );
        setTransitionHooks(oldInnerChild, leavingHooks);
        if (mode === "out-in" && innerChild.type !== Comment) {
          state.isLeaving = true;
          leavingHooks.afterLeave = () => {
            state.isLeaving = false;
            if (!(instance.job.flags & 8)) {
              instance.update();
            }
            delete leavingHooks.afterLeave;
            oldInnerChild = void 0;
          };
          return emptyPlaceholder(child);
        } else if (mode === "in-out" && innerChild.type !== Comment) {
          leavingHooks.delayLeave = (el, earlyRemove, delayedLeave) => {
            const leavingVNodesCache = getLeavingNodesForType(
              state,
              oldInnerChild
            );
            leavingVNodesCache[String(oldInnerChild.key)] = oldInnerChild;
            el[leaveCbKey] = () => {
              earlyRemove();
              el[leaveCbKey] = void 0;
              delete enterHooks.delayedLeave;
              oldInnerChild = void 0;
            };
            enterHooks.delayedLeave = () => {
              delayedLeave();
              delete enterHooks.delayedLeave;
              oldInnerChild = void 0;
            };
          };
        } else {
          oldInnerChild = void 0;
        }
      } else if (oldInnerChild) {
        oldInnerChild = void 0;
      }
      return child;
    };
  }
};
function findNonCommentChild(children) {
  let child = children[0];
  if (children.length > 1) {
    let hasFound = false;
    for (const c of children) {
      if (c.type !== Comment) {
        if (hasFound) {
          warn$1(
            "<transition> can only be used on a single element or component. Use <transition-group> for lists."
          );
          break;
        }
        child = c;
        hasFound = true;
        if (false) break;
      }
    }
  }
  return child;
}
const BaseTransition = BaseTransitionImpl;
function getLeavingNodesForType(state, vnode) {
  const { leavingVNodes } = state;
  let leavingVNodesCache = leavingVNodes.get(vnode.type);
  if (!leavingVNodesCache) {
    leavingVNodesCache = /* @__PURE__ */ Object.create(null);
    leavingVNodes.set(vnode.type, leavingVNodesCache);
  }
  return leavingVNodesCache;
}
function resolveTransitionHooks(vnode, props, state, instance, postClone) {
  const {
    appear,
    mode,
    persisted = false,
    onBeforeEnter,
    onEnter,
    onAfterEnter,
    onEnterCancelled,
    onBeforeLeave,
    onLeave,
    onAfterLeave,
    onLeaveCancelled,
    onBeforeAppear,
    onAppear,
    onAfterAppear,
    onAppearCancelled
  } = props;
  const key = String(vnode.key);
  const leavingVNodesCache = getLeavingNodesForType(state, vnode);
  const callHook2 = (hook, args) => {
    hook && callWithAsyncErrorHandling(
      hook,
      instance,
      9,
      args
    );
  };
  const callAsyncHook = (hook, args) => {
    const done = args[1];
    callHook2(hook, args);
    if (isArray(hook)) {
      if (hook.every((hook2) => hook2.length <= 1)) done();
    } else if (hook.length <= 1) {
      done();
    }
  };
  const hooks = {
    mode,
    persisted,
    beforeEnter(el) {
      let hook = onBeforeEnter;
      if (!state.isMounted) {
        if (appear) {
          hook = onBeforeAppear || onBeforeEnter;
        } else {
          return;
        }
      }
      if (el[leaveCbKey]) {
        el[leaveCbKey](
          true
          /* cancelled */
        );
      }
      const leavingVNode = leavingVNodesCache[key];
      if (leavingVNode && isSameVNodeType(vnode, leavingVNode) && leavingVNode.el[leaveCbKey]) {
        leavingVNode.el[leaveCbKey]();
      }
      callHook2(hook, [el]);
    },
    enter(el) {
      if (!isHmrUpdating && leavingVNodesCache[key] === vnode) return;
      let hook = onEnter;
      let afterHook = onAfterEnter;
      let cancelHook = onEnterCancelled;
      if (!state.isMounted) {
        if (appear) {
          hook = onAppear || onEnter;
          afterHook = onAfterAppear || onAfterEnter;
          cancelHook = onAppearCancelled || onEnterCancelled;
        } else {
          return;
        }
      }
      let called = false;
      el[enterCbKey] = (cancelled) => {
        if (called) return;
        called = true;
        if (cancelled) {
          callHook2(cancelHook, [el]);
        } else {
          callHook2(afterHook, [el]);
        }
        if (hooks.delayedLeave) {
          hooks.delayedLeave();
        }
        el[enterCbKey] = void 0;
      };
      const done = el[enterCbKey].bind(null, false);
      if (hook) {
        callAsyncHook(hook, [el, done]);
      } else {
        done();
      }
    },
    leave(el, remove2) {
      const key2 = String(vnode.key);
      if (el[enterCbKey]) {
        el[enterCbKey](
          true
          /* cancelled */
        );
      }
      if (state.isUnmounting) {
        return remove2();
      }
      callHook2(onBeforeLeave, [el]);
      let called = false;
      el[leaveCbKey] = (cancelled) => {
        if (called) return;
        called = true;
        remove2();
        if (cancelled) {
          callHook2(onLeaveCancelled, [el]);
        } else {
          callHook2(onAfterLeave, [el]);
        }
        el[leaveCbKey] = void 0;
        if (leavingVNodesCache[key2] === vnode) {
          delete leavingVNodesCache[key2];
        }
      };
      const done = el[leaveCbKey].bind(null, false);
      leavingVNodesCache[key2] = vnode;
      if (onLeave) {
        callAsyncHook(onLeave, [el, done]);
      } else {
        done();
      }
    },
    clone(vnode2) {
      const hooks2 = resolveTransitionHooks(
        vnode2,
        props,
        state,
        instance,
        postClone
      );
      if (postClone) postClone(hooks2);
      return hooks2;
    }
  };
  return hooks;
}
function emptyPlaceholder(vnode) {
  if (isKeepAlive(vnode)) {
    vnode = cloneVNode(vnode);
    vnode.children = null;
    return vnode;
  }
}
function getInnerChild$1(vnode) {
  if (!isKeepAlive(vnode)) {
    if (isTeleport(vnode.type) && vnode.children) {
      return findNonCommentChild(vnode.children);
    }
    return vnode;
  }
  if (vnode.component) {
    return vnode.component.subTree;
  }
  const { shapeFlag, children } = vnode;
  if (children) {
    if (shapeFlag & 16) {
      return children[0];
    }
    if (shapeFlag & 32 && isFunction(children.default)) {
      return children.default();
    }
  }
}
function setTransitionHooks(vnode, hooks) {
  if (vnode.shapeFlag & 6 && vnode.component) {
    vnode.transition = hooks;
    const subTree = vnode.component.subTree;
    setTransitionHooks(
      isTeleport(subTree.type) ? getInnerChild$1(subTree) || subTree : subTree,
      hooks
    );
  } else if (vnode.shapeFlag & 128) {
    vnode.ssContent.transition = hooks.clone(vnode.ssContent);
    vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
  } else {
    vnode.transition = hooks;
  }
}
function getTransitionRawChildren(children, keepComment = false, parentKey) {
  let ret = [];
  let keyedFragmentCount = 0;
  for (let i = 0; i < children.length; i++) {
    let child = children[i];
    const key = parentKey == null ? child.key : String(parentKey) + String(child.key != null ? child.key : i);
    if (child.type === Fragment) {
      if (child.patchFlag & 128) keyedFragmentCount++;
      ret = ret.concat(
        getTransitionRawChildren(child.children, keepComment, key)
      );
    } else if (keepComment || child.type !== Comment) {
      ret.push(key != null ? cloneVNode(child, { key }) : child);
    }
  }
  if (keyedFragmentCount > 1) {
    for (let i = 0; i < ret.length; i++) {
      ret[i].patchFlag = -2;
    }
  }
  return ret;
}
// @__NO_SIDE_EFFECTS__
function defineComponent(options, extraOptions) {
  return isFunction(options) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    /* @__PURE__ */ (() => extend({ name: options.name }, extraOptions, { setup: options }))()
  ) : options;
}
function useId() {
  const i = getCurrentInstance();
  if (i) {
    return (i.appContext.config.idPrefix || "v") + "-" + i.ids[0] + i.ids[1]++;
  } else if (true) {
    warn$1(
      `useId() is called when there is no active component instance to be associated with.`
    );
  }
  return "";
}
function markAsyncBoundary(instance) {
  instance.ids = [instance.ids[0] + instance.ids[2]++ + "-", 0, 0];
}
const knownTemplateRefs = /* @__PURE__ */ new WeakSet();
function useTemplateRef(key) {
  const i = getCurrentInstance();
  const r = shallowRef(null);
  if (i) {
    const refs = i.refs === EMPTY_OBJ ? i.refs = {} : i.refs;
    if (isTemplateRefKey(refs, key)) {
      warn$1(`useTemplateRef('${key}') already exists.`);
    } else {
      Object.defineProperty(refs, key, {
        enumerable: true,
        get: () => r.value,
        set: (val) => r.value = val
      });
    }
  } else if (true) {
    warn$1(
      `useTemplateRef() is called when there is no active component instance to be associated with.`
    );
  }
  const ret = true ? readonly(r) : r;
  if (true) {
    knownTemplateRefs.add(ret);
  }
  return ret;
}
function isTemplateRefKey(refs, key) {
  let desc;
  return !!((desc = Object.getOwnPropertyDescriptor(refs, key)) && !desc.configurable);
}
const pendingSetRefMap = /* @__PURE__ */ new WeakMap();
function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
  if (isArray(rawRef)) {
    rawRef.forEach(
      (r, i) => setRef(
        r,
        oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef),
        parentSuspense,
        vnode,
        isUnmount
      )
    );
    return;
  }
  if (isAsyncWrapper(vnode) && !isUnmount) {
    if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) {
      setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
    }
    return;
  }
  const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
  const value = isUnmount ? null : refValue;
  const { i: owner, r: ref3 } = rawRef;
  if (!owner) {
    warn$1(
      `Missing ref owner context. ref cannot be used on hoisted vnodes. A vnode with ref must be created inside the render function.`
    );
    return;
  }
  const oldRef = oldRawRef && oldRawRef.r;
  const refs = owner.refs === EMPTY_OBJ ? owner.refs = {} : owner.refs;
  const setupState = owner.setupState;
  const rawSetupState = toRaw(setupState);
  const canSetSetupRef = setupState === EMPTY_OBJ ? NO : (key) => {
    if (true) {
      if (hasOwn(rawSetupState, key) && !isRef(rawSetupState[key])) {
        warn$1(
          `Template ref "${key}" used on a non-ref value. It will not work in the production build.`
        );
      }
      if (knownTemplateRefs.has(rawSetupState[key])) {
        return false;
      }
    }
    if (isTemplateRefKey(refs, key)) {
      return false;
    }
    return hasOwn(rawSetupState, key);
  };
  const canSetRef = (ref22, key) => {
    if (knownTemplateRefs.has(ref22)) {
      return false;
    }
    if (key && isTemplateRefKey(refs, key)) {
      return false;
    }
    return true;
  };
  if (oldRef != null && oldRef !== ref3) {
    invalidatePendingSetRef(oldRawRef);
    if (isString(oldRef)) {
      refs[oldRef] = null;
      if (canSetSetupRef(oldRef)) {
        setupState[oldRef] = null;
      }
    } else if (isRef(oldRef)) {
      const oldRawRefAtom = oldRawRef;
      if (canSetRef(oldRef, oldRawRefAtom.k)) {
        oldRef.value = null;
      }
      if (oldRawRefAtom.k) refs[oldRawRefAtom.k] = null;
    }
  }
  if (isFunction(ref3)) {
    callWithErrorHandling(ref3, owner, 12, [value, refs]);
  } else {
    const _isString = isString(ref3);
    const _isRef = isRef(ref3);
    if (_isString || _isRef) {
      const doSet = () => {
        if (rawRef.f) {
          const existing = _isString ? canSetSetupRef(ref3) ? setupState[ref3] : refs[ref3] : canSetRef(ref3) || !rawRef.k ? ref3.value : refs[rawRef.k];
          if (isUnmount) {
            isArray(existing) && remove(existing, refValue);
          } else {
            if (!isArray(existing)) {
              if (_isString) {
                refs[ref3] = [refValue];
                if (canSetSetupRef(ref3)) {
                  setupState[ref3] = refs[ref3];
                }
              } else {
                const newVal = [refValue];
                if (canSetRef(ref3, rawRef.k)) {
                  ref3.value = newVal;
                }
                if (rawRef.k) refs[rawRef.k] = newVal;
              }
            } else if (!existing.includes(refValue)) {
              existing.push(refValue);
            }
          }
        } else if (_isString) {
          refs[ref3] = value;
          if (canSetSetupRef(ref3)) {
            setupState[ref3] = value;
          }
        } else if (_isRef) {
          if (canSetRef(ref3, rawRef.k)) {
            ref3.value = value;
          }
          if (rawRef.k) refs[rawRef.k] = value;
        } else if (true) {
          warn$1("Invalid template ref type:", ref3, `(${typeof ref3})`);
        }
      };
      if (value) {
        const job = () => {
          doSet();
          pendingSetRefMap.delete(rawRef);
        };
        job.id = -1;
        pendingSetRefMap.set(rawRef, job);
        queuePostRenderEffect(job, parentSuspense);
      } else {
        invalidatePendingSetRef(rawRef);
        doSet();
      }
    } else if (true) {
      warn$1("Invalid template ref type:", ref3, `(${typeof ref3})`);
    }
  }
}
function invalidatePendingSetRef(rawRef) {
  const pendingSetRef = pendingSetRefMap.get(rawRef);
  if (pendingSetRef) {
    pendingSetRef.flags |= 8;
    pendingSetRefMap.delete(rawRef);
  }
}
let hasLoggedMismatchError = false;
const logMismatchError = () => {
  if (hasLoggedMismatchError) {
    return;
  }
  console.error("Hydration completed but contains mismatches.");
  hasLoggedMismatchError = true;
};
const isSVGContainer = (container) => container.namespaceURI.includes("svg") && container.tagName !== "foreignObject";
const isMathMLContainer = (container) => container.namespaceURI.includes("MathML");
const getContainerType = (container) => {
  if (container.nodeType !== 1) return void 0;
  if (isSVGContainer(container)) return "svg";
  if (isMathMLContainer(container)) return "mathml";
  return void 0;
};
const isComment = (node) => node.nodeType === 8;
function createHydrationFunctions(rendererInternals) {
  const {
    mt: mountComponent,
    p: patch,
    o: {
      patchProp,
      createText,
      nextSibling,
      parentNode,
      remove: remove2,
      insert,
      createComment
    }
  } = rendererInternals;
  const hydrate = (vnode, container) => {
    if (!container.hasChildNodes()) {
      warn$1(
        `Attempting to hydrate existing markup but container is empty. Performing full mount instead.`
      );
      patch(null, vnode, container);
      flushPostFlushCbs();
      container._vnode = vnode;
      return;
    }
    hydrateNode(container.firstChild, vnode, null, null, null);
    flushPostFlushCbs();
    container._vnode = vnode;
  };
  const hydrateNode = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized = false) => {
    optimized = optimized || !!vnode.dynamicChildren;
    const isFragmentStart = isComment(node) && node.data === "[";
    const onMismatch = () => handleMismatch(
      node,
      vnode,
      parentComponent,
      parentSuspense,
      slotScopeIds,
      isFragmentStart
    );
    const { type, ref: ref3, shapeFlag, patchFlag } = vnode;
    let domType = node.nodeType;
    vnode.el = node;
    if (true) {
      def(node, "__vnode", vnode, true);
      def(node, "__vueParentComponent", parentComponent, true);
    }
    if (patchFlag === -2) {
      optimized = false;
      vnode.dynamicChildren = null;
    }
    let nextNode = null;
    switch (type) {
      case Text:
        if (domType !== 3) {
          if (vnode.children === "") {
            insert(vnode.el = createText(""), parentNode(node), node);
            nextNode = node;
          } else {
            nextNode = onMismatch();
          }
        } else {
          if (node.data !== vnode.children) {
            warn$1(
              `Hydration text mismatch in`,
              node.parentNode,
              `
  - rendered on server: ${JSON.stringify(
                node.data
              )}
  - expected on client: ${JSON.stringify(vnode.children)}`
            );
            logMismatchError();
            node.data = vnode.children;
          }
          nextNode = nextSibling(node);
        }
        break;
      case Comment:
        if (isTemplateNode(node)) {
          nextNode = nextSibling(node);
          replaceNode(
            vnode.el = node.content.firstChild,
            node,
            parentComponent
          );
        } else if (domType !== 8 || isFragmentStart) {
          nextNode = onMismatch();
        } else {
          nextNode = nextSibling(node);
        }
        break;
      case Static:
        if (isFragmentStart) {
          node = nextSibling(node);
          domType = node.nodeType;
        }
        if (domType === 1 || domType === 3) {
          nextNode = node;
          const needToAdoptContent = !vnode.children.length;
          for (let i = 0; i < vnode.staticCount; i++) {
            if (needToAdoptContent)
              vnode.children += nextNode.nodeType === 1 ? nextNode.outerHTML : nextNode.data;
            if (i === vnode.staticCount - 1) {
              vnode.anchor = nextNode;
            }
            nextNode = nextSibling(nextNode);
          }
          return isFragmentStart ? nextSibling(nextNode) : nextNode;
        } else {
          onMismatch();
        }
        break;
      case Fragment:
        if (!isFragmentStart) {
          nextNode = onMismatch();
        } else {
          nextNode = hydrateFragment(
            node,
            vnode,
            parentComponent,
            parentSuspense,
            slotScopeIds,
            optimized
          );
        }
        break;
      default:
        if (shapeFlag & 1) {
          if ((domType !== 1 || vnode.type.toLowerCase() !== node.tagName.toLowerCase()) && !isTemplateNode(node)) {
            nextNode = onMismatch();
          } else {
            nextNode = hydrateElement(
              node,
              vnode,
              parentComponent,
              parentSuspense,
              slotScopeIds,
              optimized
            );
          }
        } else if (shapeFlag & 6) {
          vnode.slotScopeIds = slotScopeIds;
          const container = parentNode(node);
          if (isFragmentStart) {
            nextNode = locateClosingAnchor(node);
          } else if (isComment(node) && node.data === "teleport start") {
            nextNode = locateClosingAnchor(node, node.data, "teleport end");
          } else {
            nextNode = nextSibling(node);
          }
          mountComponent(
            vnode,
            container,
            null,
            parentComponent,
            parentSuspense,
            getContainerType(container),
            optimized
          );
          if (isAsyncWrapper(vnode) && !vnode.type.__asyncResolved) {
            let subTree;
            if (isFragmentStart) {
              subTree = createVNode(Fragment);
              subTree.anchor = nextNode ? nextNode.previousSibling : container.lastChild;
            } else {
              subTree = node.nodeType === 3 ? createTextVNode("") : createVNode("div");
            }
            subTree.el = node;
            vnode.component.subTree = subTree;
          }
        } else if (shapeFlag & 64) {
          if (domType !== 8) {
            nextNode = onMismatch();
          } else {
            nextNode = vnode.type.hydrate(
              node,
              vnode,
              parentComponent,
              parentSuspense,
              slotScopeIds,
              optimized,
              rendererInternals,
              hydrateChildren
            );
          }
        } else if (shapeFlag & 128) {
          nextNode = vnode.type.hydrate(
            node,
            vnode,
            parentComponent,
            parentSuspense,
            getContainerType(parentNode(node)),
            slotScopeIds,
            optimized,
            rendererInternals,
            hydrateNode
          );
        } else if (true) {
          warn$1("Invalid HostVNode type:", type, `(${typeof type})`);
        }
    }
    if (ref3 != null) {
      setRef(ref3, null, parentSuspense, vnode);
    }
    return nextNode;
  };
  const hydrateElement = (el, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
    optimized = optimized || !!vnode.dynamicChildren;
    const {
      type,
      dynamicProps,
      props,
      patchFlag,
      shapeFlag,
      dirs,
      transition
    } = vnode;
    const forcePatch = type === "input" || type === "option";
    const hasDynamicProps = !!dynamicProps;
    if (true) {
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "created");
      }
      let needCallTransitionHooks = false;
      if (isTemplateNode(el)) {
        needCallTransitionHooks = needTransition(
          null,
          // no need check parentSuspense in hydration
          transition
        ) && parentComponent && parentComponent.vnode.props && parentComponent.vnode.props.appear;
        const content = el.content.firstChild;
        if (needCallTransitionHooks) {
          const cls = content.getAttribute("class");
          if (cls) content.$cls = cls;
          transition.beforeEnter(content);
        }
        replaceNode(content, el, parentComponent);
        vnode.el = el = content;
      }
      if (shapeFlag & 16 && // skip if element has innerHTML / textContent
      !(props && (props.innerHTML || props.textContent))) {
        let next = hydrateChildren(
          el.firstChild,
          vnode,
          el,
          parentComponent,
          parentSuspense,
          slotScopeIds,
          optimized
        );
        if (next && !isMismatchAllowed(
          el,
          1
          /* CHILDREN */
        )) {
          warn$1(
            `Hydration children mismatch on`,
            el,
            `
Server rendered element contains more child nodes than client vdom.`
          );
          logMismatchError();
        }
        while (next) {
          const cur = next;
          next = next.nextSibling;
          remove2(cur);
        }
      } else if (shapeFlag & 8) {
        let clientText = vnode.children;
        if (clientText[0] === "\n" && (el.tagName === "PRE" || el.tagName === "TEXTAREA")) {
          clientText = clientText.slice(1);
        }
        const { textContent } = el;
        if (textContent !== clientText && // innerHTML normalize \r\n or \r into a single \n in the DOM
        textContent !== clientText.replace(/\r\n|\r/g, "\n")) {
          if (!isMismatchAllowed(
            el,
            0
            /* TEXT */
          )) {
            warn$1(
              `Hydration text content mismatch on`,
              el,
              `
  - rendered on server: ${textContent}
  - expected on client: ${clientText}`
            );
            logMismatchError();
          }
          el.textContent = vnode.children;
        }
      }
      if (props) {
        if (true) {
          const isCustomElement = el.tagName.includes("-");
          const namespace = el.namespaceURI.includes("svg") ? "svg" : el.namespaceURI.includes("MathML") ? "mathml" : void 0;
          for (const key in props) {
            if (// #11189 skip if this node has directives that have created hooks
            // as it could have mutated the DOM in any possible way
            !(dirs && dirs.some((d) => d.dir.created)) && propHasMismatch(el, key, props[key], vnode, parentComponent)) {
              logMismatchError();
            }
            if (forcePatch && (key.endsWith("value") || key === "indeterminate") || isOn(key) && !isReservedProp(key) || // force hydrate v-bind with .prop modifiers
            key[0] === "." || isCustomElement && !isReservedProp(key) || dynamicProps && dynamicProps.includes(key)) {
              if (isUnchangedResourceProp(el, key, props[key])) {
                continue;
              }
              patchProp(el, key, null, props[key], namespace, parentComponent);
            }
          }
        } else if (props.onClick) {
          patchProp(
            el,
            "onClick",
            null,
            props.onClick,
            void 0,
            parentComponent
          );
        } else if (patchFlag & 4 && isReactive(props.style)) {
          for (const key in props.style) props.style[key];
        }
      }
      let vnodeHooks;
      if (vnodeHooks = props && props.onVnodeBeforeMount) {
        invokeVNodeHook(vnodeHooks, parentComponent, vnode);
      }
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
      }
      if ((vnodeHooks = props && props.onVnodeMounted) || dirs || needCallTransitionHooks) {
        queueEffectWithSuspense(() => {
          vnodeHooks && invokeVNodeHook(vnodeHooks, parentComponent, vnode);
          needCallTransitionHooks && transition.enter(el);
          dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
        }, parentSuspense);
      }
    }
    return el.nextSibling;
  };
  const hydrateChildren = (node, parentVNode, container, parentComponent, parentSuspense, slotScopeIds, optimized) => {
    optimized = optimized || !!parentVNode.dynamicChildren;
    const children = parentVNode.children;
    const l = children.length;
    let hasCheckedMismatch = false;
    for (let i = 0; i < l; i++) {
      const vnode = optimized ? children[i] : children[i] = normalizeVNode(children[i]);
      const isText = vnode.type === Text;
      if (node) {
        if (isText && !optimized) {
          if (i + 1 < l && normalizeVNode(children[i + 1]).type === Text) {
            insert(
              createText(
                node.data.slice(vnode.children.length)
              ),
              container,
              nextSibling(node)
            );
            node.data = vnode.children;
          }
        }
        node = hydrateNode(
          node,
          vnode,
          parentComponent,
          parentSuspense,
          slotScopeIds,
          optimized
        );
      } else if (isText && !vnode.children) {
        insert(vnode.el = createText(""), container);
      } else {
        if (!hasCheckedMismatch) {
          hasCheckedMismatch = true;
          if (!isMismatchAllowed(
            container,
            1
            /* CHILDREN */
          )) {
            warn$1(
              `Hydration children mismatch on`,
              container,
              `
Server rendered element contains fewer child nodes than client vdom.`
            );
            logMismatchError();
          }
        }
        patch(
          null,
          vnode,
          container,
          null,
          parentComponent,
          parentSuspense,
          getContainerType(container),
          slotScopeIds
        );
      }
    }
    return node;
  };
  const hydrateFragment = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
    const { slotScopeIds: fragmentSlotScopeIds } = vnode;
    if (fragmentSlotScopeIds) {
      slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
    }
    const container = parentNode(node);
    const next = hydrateChildren(
      nextSibling(node),
      vnode,
      container,
      parentComponent,
      parentSuspense,
      slotScopeIds,
      optimized
    );
    if (next && isComment(next) && next.data === "]") {
      return nextSibling(vnode.anchor = next);
    } else {
      logMismatchError();
      insert(vnode.anchor = createComment(`]`), container, next);
      return next;
    }
  };
  const handleMismatch = (node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragment) => {
    if (!isNodeMismatchAllowed(node, vnode)) {
      warn$1(
        `Hydration node mismatch:
- rendered on server:`,
        node,
        node.nodeType === 3 ? `(text)` : isComment(node) && node.data === "[" ? `(start of fragment)` : ``,
        `
- expected on client:`,
        vnode.type
      );
      logMismatchError();
    }
    vnode.el = null;
    if (isFragment) {
      const end = locateClosingAnchor(node);
      while (true) {
        const next2 = nextSibling(node);
        if (next2 && next2 !== end) {
          remove2(next2);
        } else {
          break;
        }
      }
    }
    const next = nextSibling(node);
    const container = parentNode(node);
    remove2(node);
    patch(
      null,
      vnode,
      container,
      next,
      parentComponent,
      parentSuspense,
      getContainerType(container),
      slotScopeIds
    );
    if (parentComponent) {
      parentComponent.vnode.el = vnode.el;
      updateHOCHostEl(parentComponent, vnode.el);
    }
    return next;
  };
  const locateClosingAnchor = (node, open = "[", close = "]") => {
    let match = 0;
    while (node) {
      node = nextSibling(node);
      if (node && isComment(node)) {
        if (node.data === open) match++;
        if (node.data === close) {
          if (match === 0) {
            return nextSibling(node);
          } else {
            match--;
          }
        }
      }
    }
    return node;
  };
  const replaceNode = (newNode, oldNode, parentComponent) => {
    const parentNode2 = oldNode.parentNode;
    if (parentNode2) {
      parentNode2.replaceChild(newNode, oldNode);
    }
    let parent = parentComponent;
    while (parent) {
      if (parent.vnode.el === oldNode) {
        parent.vnode.el = parent.subTree.el = newNode;
      }
      parent = parent.parent;
    }
  };
  const isTemplateNode = (node) => {
    return node.nodeType === 1 && node.tagName === "TEMPLATE";
  };
  return [hydrate, hydrateNode];
}
const resourceProps = /* @__PURE__ */ new Set(["src", "srcset", "href", "poster"]);
function isUnchangedResourceProp(el, key, clientValue) {
  if (!resourceProps.has(key)) {
    return false;
  }
  return el.getAttribute(key) === (clientValue == null ? null : `${clientValue}`);
}
function propHasMismatch(el, key, clientValue, vnode, instance) {
  let mismatchType;
  let mismatchKey;
  let actual;
  let expected;
  if (key === "class") {
    if (el.$cls) {
      actual = el.$cls;
      delete el.$cls;
    } else {
      actual = el.getAttribute("class");
    }
    expected = normalizeClass(clientValue);
    if (!isSetEqual(toClassSet(actual || ""), toClassSet(expected))) {
      mismatchType = 2;
      mismatchKey = `class`;
    }
  } else if (key === "style") {
    actual = el.getAttribute("style") || "";
    expected = isString(clientValue) ? clientValue : stringifyStyle(normalizeStyle(clientValue));
    const actualMap = toStyleMap(actual);
    const expectedMap = toStyleMap(expected);
    if (vnode.dirs) {
      for (const { dir, value } of vnode.dirs) {
        if (dir.name === "show" && !value) {
          expectedMap.set("display", "none");
        }
      }
    }
    if (instance) {
      resolveCssVars(instance, vnode, expectedMap);
    }
    if (!isMapEqual(actualMap, expectedMap)) {
      mismatchType = 3;
      mismatchKey = "style";
    }
  } else if (el instanceof SVGElement && isKnownSvgAttr(key) || el instanceof HTMLElement && (isBooleanAttr(key) || isKnownHtmlAttr(key))) {
    if (key === "hidden") {
      actual = normalizeHiddenValue(el.getAttribute(key));
      expected = normalizeHiddenValue(clientValue);
    } else if (isBooleanAttr(key)) {
      actual = el.hasAttribute(key);
      expected = includeBooleanAttr(clientValue);
    } else if (clientValue == null) {
      actual = el.hasAttribute(key);
      expected = false;
    } else {
      if (el.hasAttribute(key)) {
        actual = el.getAttribute(key);
      } else if (key === "value" && el.tagName === "TEXTAREA") {
        actual = el.value;
      } else {
        actual = false;
      }
      expected = isRenderableAttrValue(clientValue) ? String(clientValue) : false;
    }
    if (actual !== expected) {
      mismatchType = 4;
      mismatchKey = key;
    }
  }
  if (mismatchType != null && !isMismatchAllowed(el, mismatchType)) {
    const format = (v) => v === false ? `(not rendered)` : `${mismatchKey}="${v}"`;
    const preSegment = `Hydration ${MismatchTypeString[mismatchType]} mismatch on`;
    const postSegment = `
  - rendered on server: ${format(actual)}
  - expected on client: ${format(expected)}
  Note: this mismatch is check-only. The DOM will not be rectified in production due to performance overhead.
  You should fix the source of the mismatch.`;
    {
      warn$1(preSegment, el, postSegment);
    }
    return true;
  }
  return false;
}
function normalizeHiddenValue(value) {
  if (!isRenderableAttrValue(value)) {
    return false;
  }
  if (isString(value)) {
    return value.toLowerCase() === "until-found" ? "until-found" : "";
  }
  return includeBooleanAttr(value) ? "" : false;
}
function toClassSet(str) {
  return new Set(str.trim().split(/\s+/));
}
function isSetEqual(a, b) {
  if (a.size !== b.size) {
    return false;
  }
  for (const s of a) {
    if (!b.has(s)) {
      return false;
    }
  }
  return true;
}
function toStyleMap(str) {
  const styleMap = /* @__PURE__ */ new Map();
  for (const item of str.split(";")) {
    let [key, value] = item.split(":");
    key = key.trim();
    value = value && value.trim();
    if (key && value) {
      styleMap.set(key, value);
    }
  }
  return styleMap;
}
function isMapEqual(a, b) {
  if (a.size !== b.size) {
    return false;
  }
  for (const [key, value] of a) {
    if (value !== b.get(key)) {
      return false;
    }
  }
  return true;
}
function resolveCssVars(instance, vnode, expectedMap) {
  const root = instance.subTree;
  if (instance.getCssVars && (vnode === root || root && root.type === Fragment && root.children.includes(vnode))) {
    const cssVars = instance.getCssVars();
    for (const key in cssVars) {
      const value = normalizeCssVarValue(cssVars[key]);
      expectedMap.set(`--${getEscapedCssVarName(key, false)}`, value);
    }
  }
  if (vnode === root && instance.parent) {
    resolveCssVars(instance.parent, instance.vnode, expectedMap);
  }
}
const allowMismatchAttr = "data-allow-mismatch";
const MismatchTypeString = {
  [
    0
    /* TEXT */
  ]: "text",
  [
    1
    /* CHILDREN */
  ]: "children",
  [
    2
    /* CLASS */
  ]: "class",
  [
    3
    /* STYLE */
  ]: "style",
  [
    4
    /* ATTRIBUTE */
  ]: "attribute"
};
function isMismatchAllowed(el, allowedType) {
  if (allowedType === 0 || allowedType === 1) {
    while (el && !el.hasAttribute(allowMismatchAttr)) {
      el = el.parentElement;
    }
  }
  return isMismatchAllowedByAttr(
    el && el.getAttribute(allowMismatchAttr),
    allowedType
  );
}
function isMismatchAllowedByAttr(allowedAttr, allowedType) {
  if (allowedAttr == null) {
    return false;
  } else if (allowedAttr === "") {
    return true;
  } else {
    const list = allowedAttr.split(",");
    if (allowedType === 0 && list.includes("children")) {
      return true;
    }
    return list.includes(MismatchTypeString[allowedType]);
  }
}
function isNodeMismatchAllowed(node, vnode) {
  return isMismatchAllowed(
    node.parentElement,
    1
    /* CHILDREN */
  ) || isMismatchAllowedByNode(node) || isMismatchAllowedByVNode(vnode);
}
function isMismatchAllowedByNode(node) {
  return node.nodeType === 1 && isMismatchAllowedByAttr(
    node.getAttribute(allowMismatchAttr),
    1
    /* CHILDREN */
  );
}
function isMismatchAllowedByVNode({ props }) {
  const allowedAttr = props && props[allowMismatchAttr];
  return typeof allowedAttr === "string" && isMismatchAllowedByAttr(
    allowedAttr,
    1
    /* CHILDREN */
  );
}
const requestIdleCallback = getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
const cancelIdleCallback = getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
const hydrateOnIdle = (timeout = 1e4) => (hydrate) => {
  const id = requestIdleCallback(hydrate, { timeout });
  return () => cancelIdleCallback(id);
};
function elementIsVisibleInViewport(el) {
  const { top, left, bottom, right } = el.getBoundingClientRect();
  const { innerHeight, innerWidth } = window;
  return (top > 0 && top < innerHeight || bottom > 0 && bottom < innerHeight) && (left > 0 && left < innerWidth || right > 0 && right < innerWidth);
}
const hydrateOnVisible = (opts) => (hydrate, forEach) => {
  const ob = new IntersectionObserver((entries) => {
    for (const e of entries) {
      if (!e.isIntersecting) continue;
      ob.disconnect();
      hydrate();
      break;
    }
  }, opts);
  forEach((el) => {
    if (!(el instanceof Element)) return;
    if (elementIsVisibleInViewport(el)) {
      hydrate();
      ob.disconnect();
      return false;
    }
    ob.observe(el);
  });
  return () => ob.disconnect();
};
const hydrateOnMediaQuery = (query) => (hydrate) => {
  if (query) {
    const mql = matchMedia(query);
    if (mql.matches) {
      hydrate();
    } else {
      mql.addEventListener("change", hydrate, { once: true });
      return () => mql.removeEventListener("change", hydrate);
    }
  }
};
const hydrateOnInteraction = (interactions = []) => (hydrate, forEach) => {
  if (isString(interactions)) interactions = [interactions];
  let hasHydrated = false;
  const doHydrate = (e) => {
    if (!hasHydrated) {
      hasHydrated = true;
      teardown();
      hydrate();
      e.target.dispatchEvent(new e.constructor(e.type, e));
    }
  };
  const teardown = () => {
    forEach((el) => {
      for (const i of interactions) {
        el.removeEventListener(i, doHydrate);
      }
    });
  };
  forEach((el) => {
    for (const i of interactions) {
      el.addEventListener(i, doHydrate, { once: true });
    }
  });
  return teardown;
};
function forEachElement(node, cb) {
  if (isComment(node) && node.data === "[") {
    let depth = 1;
    let next = node.nextSibling;
    while (next) {
      if (next.nodeType === 1) {
        const result = cb(next);
        if (result === false) {
          break;
        }
      } else if (isComment(next)) {
        if (next.data === "]") {
          if (--depth === 0) break;
        } else if (next.data === "[") {
          depth++;
        }
      }
      next = next.nextSibling;
    }
  } else {
    cb(node);
  }
}
const isAsyncWrapper = (i) => !!i.type.__asyncLoader;
// @__NO_SIDE_EFFECTS__
function defineAsyncComponent(source) {
  if (isFunction(source)) {
    source = { loader: source };
  }
  const {
    loader,
    loadingComponent,
    errorComponent,
    delay = 200,
    hydrate: hydrateStrategy,
    timeout,
    // undefined = never times out
    suspensible = true,
    onError: userOnError
  } = source;
  let pendingRequest = null;
  let resolvedComp;
  let retries = 0;
  const retry = () => {
    retries++;
    pendingRequest = null;
    return load();
  };
  const load = () => {
    let thisRequest;
    return pendingRequest || (thisRequest = pendingRequest = loader().catch((err) => {
      err = err instanceof Error ? err : new Error(String(err));
      if (userOnError) {
        return new Promise((resolve2, reject) => {
          const userRetry = () => resolve2(retry());
          const userFail = () => reject(err);
          userOnError(err, userRetry, userFail, retries + 1);
        });
      } else {
        throw err;
      }
    }).then((comp) => {
      if (thisRequest !== pendingRequest && pendingRequest) {
        return pendingRequest;
      }
      if (!comp) {
        warn$1(
          `Async component loader resolved to undefined. If you are using retry(), make sure to return its return value.`
        );
      }
      if (comp && (comp.__esModule || comp[Symbol.toStringTag] === "Module")) {
        comp = comp.default;
      }
      if (comp && !isObject(comp) && !isFunction(comp)) {
        throw new Error(`Invalid async component load result: ${comp}`);
      }
      resolvedComp = comp;
      return comp;
    }));
  };
  return /* @__PURE__ */ defineComponent({
    name: "AsyncComponentWrapper",
    __asyncLoader: load,
    __asyncHydrate(el, instance, hydrate) {
      const wasConnected = el.isConnected;
      let patched = false;
      (instance.bu || (instance.bu = [])).push(() => patched = true);
      const performHydrate = () => {
        if (patched) {
          if (true) {
            warn$1(
              `Skipping lazy hydration for component '${getComponentName(resolvedComp) || resolvedComp.__file}': it was updated before lazy hydration performed.`
            );
          }
          return;
        }
        if (!el.parentNode || wasConnected && !el.isConnected) return;
        hydrate();
      };
      const doHydrate = hydrateStrategy ? () => {
        const teardown = hydrateStrategy(
          performHydrate,
          (cb) => forEachElement(el, cb)
        );
        if (teardown) {
          (instance.bum || (instance.bum = [])).push(teardown);
        }
      } : performHydrate;
      if (resolvedComp) {
        doHydrate();
      } else {
        load().then(() => !instance.isUnmounted && doHydrate());
      }
    },
    get __asyncResolved() {
      return resolvedComp;
    },
    setup() {
      const instance = currentInstance;
      markAsyncBoundary(instance);
      if (resolvedComp) {
        return () => createInnerComp(resolvedComp, instance);
      }
      const onError = (err) => {
        pendingRequest = null;
        handleError(
          err,
          instance,
          13,
          !errorComponent
        );
      };
      if (suspensible && instance.suspense || isInSSRComponentSetup) {
        return load().then((comp) => {
          return () => createInnerComp(comp, instance);
        }).catch((err) => {
          onError(err);
          return () => errorComponent ? createVNode(errorComponent, {
            error: err
          }) : null;
        });
      }
      const loaded = ref(false);
      const error = ref();
      const delayed = ref(!!delay);
      let timeoutTimer;
      let delayTimer;
      onUnmounted(() => {
        if (timeoutTimer != null) clearTimeout(timeoutTimer);
        if (delayTimer != null) clearTimeout(delayTimer);
      });
      if (delay) {
        delayTimer = setTimeout(() => {
          if (instance.isUnmounted) return;
          delayed.value = false;
        }, delay);
      }
      if (timeout != null) {
        timeoutTimer = setTimeout(() => {
          if (instance.isUnmounted) return;
          if (!loaded.value && !error.value) {
            const err = new Error(
              `Async component timed out after ${timeout}ms.`
            );
            onError(err);
            error.value = err;
          }
        }, timeout);
      }
      load().then(() => {
        if (instance.isUnmounted) return;
        loaded.value = true;
        if (instance.parent && isKeepAlive(instance.parent.vnode)) {
          instance.parent.update();
        }
      }).catch((err) => {
        if (instance.isUnmounted) {
          pendingRequest = null;
          return;
        }
        onError(err);
        error.value = err;
      });
      return () => {
        if (loaded.value && resolvedComp) {
          return createInnerComp(resolvedComp, instance);
        } else if (error.value && errorComponent) {
          return createVNode(errorComponent, {
            error: error.value
          });
        } else if (loadingComponent && !delayed.value) {
          return createInnerComp(
            loadingComponent,
            instance
          );
        }
      };
    }
  });
}
function createInnerComp(comp, parent) {
  const { ref: ref22, props, children, ce } = parent.vnode;
  const vnode = createVNode(comp, props, children);
  vnode.ref = ref22;
  vnode.ce = ce;
  delete parent.vnode.ce;
  return vnode;
}
const isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
const KeepAliveImpl = {
  name: `KeepAlive`,
  // Marker for special handling inside the renderer. We are not using a ===
  // check directly on KeepAlive in the renderer, because importing it directly
  // would prevent it from being tree-shaken.
  __isKeepAlive: true,
  props: {
    include: [String, RegExp, Array],
    exclude: [String, RegExp, Array],
    max: [String, Number]
  },
  setup(props, { slots }) {
    const instance = getCurrentInstance();
    const sharedContext = instance.ctx;
    if (!sharedContext.renderer) {
      return () => {
        const children = slots.default && slots.default();
        return children && children.length === 1 ? children[0] : children;
      };
    }
    const cache = /* @__PURE__ */ new Map();
    const keys = /* @__PURE__ */ new Set();
    let current = null;
    if (true) {
      instance.__v_cache = cache;
    }
    const parentSuspense = instance.suspense;
    const {
      renderer: {
        p: patch,
        m: move,
        um: _unmount,
        o: { createElement }
      }
    } = sharedContext;
    const storageContainer = createElement("div");
    sharedContext.activate = (vnode, container, anchor, namespace, optimized) => {
      const instance2 = vnode.component;
      move(vnode, container, anchor, 0, parentSuspense);
      patch(
        instance2.vnode,
        vnode,
        container,
        anchor,
        instance2,
        parentSuspense,
        namespace,
        vnode.slotScopeIds,
        optimized
      );
      queuePostRenderEffect(() => {
        instance2.isDeactivated = false;
        if (instance2.a) {
          invokeArrayFns(instance2.a);
        }
        const vnodeHook = vnode.props && vnode.props.onVnodeMounted;
        if (vnodeHook) {
          invokeVNodeHook(vnodeHook, instance2.parent, vnode);
        }
      }, parentSuspense);
      if (true) {
        devtoolsComponentAdded(instance2);
      }
    };
    sharedContext.deactivate = (vnode) => {
      const instance2 = vnode.component;
      invalidateMount(instance2.m);
      invalidateMount(instance2.a);
      move(vnode, storageContainer, null, 1, parentSuspense);
      queuePostRenderEffect(() => {
        if (instance2.da) {
          invokeArrayFns(instance2.da);
        }
        const vnodeHook = vnode.props && vnode.props.onVnodeUnmounted;
        if (vnodeHook) {
          invokeVNodeHook(vnodeHook, instance2.parent, vnode);
        }
        instance2.isDeactivated = true;
      }, parentSuspense);
      if (true) {
        devtoolsComponentAdded(instance2);
      }
      if (true) {
        instance2.__keepAliveStorageContainer = storageContainer;
      }
    };
    function unmount(vnode) {
      resetShapeFlag(vnode);
      _unmount(vnode, instance, parentSuspense, true);
    }
    function pruneCache(filter) {
      cache.forEach((vnode, key) => {
        const name = getComponentName(
          isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : vnode.type
        );
        if (name && !filter(name)) {
          pruneCacheEntry(key);
        }
      });
    }
    function pruneCacheEntry(key) {
      const cached = cache.get(key);
      if (cached && (!current || !isSameVNodeType(cached, current))) {
        unmount(cached);
      } else if (current) {
        resetShapeFlag(current);
      }
      cache.delete(key);
      keys.delete(key);
    }
    watch(
      () => [props.include, props.exclude],
      ([include, exclude]) => {
        include && pruneCache((name) => matches(include, name));
        exclude && pruneCache((name) => !matches(exclude, name));
      },
      // prune post-render after `current` has been updated
      { flush: "post", deep: true }
    );
    let pendingCacheKey = null;
    const cacheSubtree = () => {
      if (pendingCacheKey != null) {
        if (isSuspense(instance.subTree.type)) {
          queuePostRenderEffect(() => {
            cache.set(pendingCacheKey, getInnerChild(instance.subTree));
          }, instance.subTree.suspense);
        } else {
          cache.set(pendingCacheKey, getInnerChild(instance.subTree));
        }
      }
    };
    onMounted(cacheSubtree);
    onUpdated(cacheSubtree);
    onBeforeUnmount(() => {
      cache.forEach((cached) => {
        const { subTree, suspense } = instance;
        const vnode = getInnerChild(subTree);
        if (cached.type === vnode.type && cached.key === vnode.key) {
          resetShapeFlag(vnode);
          const da = vnode.component.da;
          da && queuePostRenderEffect(da, suspense);
          return;
        }
        unmount(cached);
      });
    });
    return () => {
      pendingCacheKey = null;
      if (!slots.default) {
        return current = null;
      }
      const children = slots.default();
      const rawVNode = children[0];
      if (children.length > 1) {
        if (true) {
          warn$1(`KeepAlive should contain exactly one component child.`);
        }
        current = null;
        return children;
      } else if (!isVNode(rawVNode) || !(rawVNode.shapeFlag & 4) && !(rawVNode.shapeFlag & 128)) {
        current = null;
        return rawVNode;
      }
      let vnode = getInnerChild(rawVNode);
      if (vnode.type === Comment) {
        current = null;
        return vnode;
      }
      const comp = vnode.type;
      const name = getComponentName(
        isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : comp
      );
      const { include, exclude, max } = props;
      if (include && (!name || !matches(include, name)) || exclude && name && matches(exclude, name)) {
        vnode.shapeFlag &= -257;
        current = vnode;
        return rawVNode;
      }
      const key = vnode.key == null ? comp : vnode.key;
      const cachedVNode = cache.get(key);
      if (vnode.el) {
        vnode = cloneVNode(vnode);
        if (rawVNode.shapeFlag & 128) {
          rawVNode.ssContent = vnode;
        }
      }
      pendingCacheKey = key;
      if (cachedVNode) {
        vnode.el = cachedVNode.el;
        vnode.component = cachedVNode.component;
        if (vnode.transition) {
          setTransitionHooks(vnode, vnode.transition);
        }
        vnode.shapeFlag |= 512;
        keys.delete(key);
        keys.add(key);
      } else {
        keys.add(key);
        if (max && keys.size > parseInt(max, 10)) {
          pruneCacheEntry(keys.values().next().value);
        }
      }
      vnode.shapeFlag |= 256;
      current = vnode;
      return isSuspense(rawVNode.type) ? rawVNode : vnode;
    };
  }
};
const KeepAlive = KeepAliveImpl;
function matches(pattern, name) {
  if (isArray(pattern)) {
    return pattern.some((p) => matches(p, name));
  } else if (isString(pattern)) {
    return pattern.split(",").includes(name);
  } else if (isRegExp(pattern)) {
    pattern.lastIndex = 0;
    return pattern.test(name);
  }
  return false;
}
function onActivated(hook, target) {
  registerKeepAliveHook(hook, "a", target);
}
function onDeactivated(hook, target) {
  registerKeepAliveHook(hook, "da", target);
}
function registerKeepAliveHook(hook, type, target = currentInstance) {
  const wrappedHook = hook.__wdc || (hook.__wdc = () => {
    let current = target;
    while (current) {
      if (current.isDeactivated) {
        return;
      }
      current = current.parent;
    }
    return hook();
  });
  injectHook(type, wrappedHook, target);
  if (target) {
    let current = target.parent;
    while (current && current.parent) {
      if (isKeepAlive(current.parent.vnode)) {
        injectToKeepAliveRoot(wrappedHook, type, target, current);
      }
      current = current.parent;
    }
  }
}
function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
  const injected = injectHook(
    type,
    hook,
    keepAliveRoot,
    true
    /* prepend */
  );
  onUnmounted(() => {
    remove(keepAliveRoot[type], injected);
  }, target);
}
function resetShapeFlag(vnode) {
  vnode.shapeFlag &= -257;
  vnode.shapeFlag &= -513;
}
function getInnerChild(vnode) {
  return vnode.shapeFlag & 128 ? vnode.ssContent : vnode;
}
function injectHook(type, hook, target = currentInstance, prepend = false) {
  if (target) {
    const hooks = target[type] || (target[type] = []);
    const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
      pauseTracking();
      const reset = setCurrentInstance(target);
      const res = callWithAsyncErrorHandling(hook, target, type, args);
      reset();
      resetTracking();
      return res;
    });
    if (prepend) {
      hooks.unshift(wrappedHook);
    } else {
      hooks.push(wrappedHook);
    }
    return wrappedHook;
  } else if (true) {
    const apiName = toHandlerKey(ErrorTypeStrings$1[type].replace(/ hook$/, ""));
    warn$1(
      `${apiName} is called when there is no active component instance to be associated with. Lifecycle injection APIs can only be used during execution of setup(). If you are using async setup(), make sure to register lifecycle hooks before the first await statement.`
    );
  }
}
const createHook = (lifecycle) => (hook, target = currentInstance) => {
  if (!isInSSRComponentSetup || lifecycle === "sp") {
    injectHook(lifecycle, (...args) => hook(...args), target);
  }
};
const onBeforeMount = createHook("bm");
const onMounted = createHook("m");
const onBeforeUpdate = createHook(
  "bu"
);
const onUpdated = createHook("u");
const onBeforeUnmount = createHook(
  "bum"
);
const onUnmounted = createHook("um");
const onServerPrefetch = createHook(
  "sp"
);
const onRenderTriggered = createHook("rtg");
const onRenderTracked = createHook("rtc");
function onErrorCaptured(hook, target = currentInstance) {
  injectHook("ec", hook, target);
}
const COMPONENTS = "components";
const DIRECTIVES = "directives";
function resolveComponent(name, maybeSelfReference) {
  return resolveAsset(COMPONENTS, name, true, maybeSelfReference) || name;
}
const NULL_DYNAMIC_COMPONENT = /* @__PURE__ */ Symbol.for("v-ndc");
function resolveDynamicComponent(component) {
  if (isString(component)) {
    return resolveAsset(COMPONENTS, component, false) || component;
  } else {
    return component || NULL_DYNAMIC_COMPONENT;
  }
}
function resolveDirective(name) {
  return resolveAsset(DIRECTIVES, name);
}
function resolveAsset(type, name, warnMissing = true, maybeSelfReference = false) {
  const instance = currentRenderingInstance || currentInstance;
  if (instance) {
    const Component = instance.type;
    if (type === COMPONENTS) {
      const selfName = getComponentName(
        Component,
        false
      );
      if (selfName && (selfName === name || selfName === camelize(name) || selfName === capitalize(camelize(name)))) {
        return Component;
      }
    }
    const res = (
      // local registration
      // check instance[type] first which is resolved for options API
      resolve(instance[type] || Component[type], name) || // global registration
      resolve(instance.appContext[type], name)
    );
    if (!res && maybeSelfReference) {
      return Component;
    }
    if (warnMissing && !res) {
      const extra = type === COMPONENTS ? `
If this is a native custom element, make sure to exclude it from component resolution via compilerOptions.isCustomElement.` : ``;
      warn$1(`Failed to resolve ${type.slice(0, -1)}: ${name}${extra}`);
    }
    return res;
  } else if (true) {
    warn$1(
      `resolve${capitalize(type.slice(0, -1))} can only be used in render() or setup().`
    );
  }
}
function resolve(registry, name) {
  return registry && (registry[name] || registry[camelize(name)] || registry[capitalize(camelize(name))]);
}
function renderList(source, renderItem, cache, index) {
  let ret;
  const cached = cache && cache[index];
  const sourceIsArray = isArray(source);
  if (sourceIsArray || isString(source)) {
    const sourceIsReactiveArray = sourceIsArray && isReactive(source);
    let needsWrap = false;
    let isReadonlySource = false;
    if (sourceIsReactiveArray) {
      needsWrap = !isShallow(source);
      isReadonlySource = isReadonly(source);
      source = shallowReadArray(source);
    }
    ret = new Array(source.length);
    for (let i = 0, l = source.length; i < l; i++) {
      ret[i] = renderItem(
        needsWrap ? isReadonlySource ? toReadonly(toReactive(source[i])) : toReactive(source[i]) : source[i],
        i,
        void 0,
        cached && cached[i]
      );
    }
  } else if (typeof source === "number") {
    if (!Number.isInteger(source) || source < 0) {
      warn$1(
        `The v-for range expects a positive integer value but got ${source}.`
      );
      ret = [];
    } else {
      ret = new Array(source);
      for (let i = 0; i < source; i++) {
        ret[i] = renderItem(i + 1, i, void 0, cached && cached[i]);
      }
    }
  } else if (isObject(source)) {
    if (source[Symbol.iterator]) {
      ret = Array.from(
        source,
        (item, i) => renderItem(item, i, void 0, cached && cached[i])
      );
    } else {
      const keys = Object.keys(source);
      ret = new Array(keys.length);
      for (let i = 0, l = keys.length; i < l; i++) {
        const key = keys[i];
        ret[i] = renderItem(source[key], key, i, cached && cached[i]);
      }
    }
  } else {
    ret = [];
  }
  if (cache) {
    cache[index] = ret;
  }
  return ret;
}
function createSlots(slots, dynamicSlots) {
  for (let i = 0; i < dynamicSlots.length; i++) {
    const slot = dynamicSlots[i];
    if (isArray(slot)) {
      for (let j = 0; j < slot.length; j++) {
        slots[slot[j].name] = slot[j].fn;
      }
    } else if (slot) {
      slots[slot.name] = slot.key ? (...args) => {
        const res = slot.fn(...args);
        if (res) res.key = slot.key;
        return res;
      } : slot.fn;
    }
  }
  return slots;
}
function renderSlot(slots, name, props, fallback, noSlotted, branchKey) {
  if (props == null) props = {};
  if (currentRenderingInstance.ce || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.ce) {
    const slotProps = branchKey != null && props.key == null ? extend({}, props, { key: branchKey }) : props;
    const hasProps = Object.keys(slotProps).length > 0;
    if (name !== "default") slotProps.name = name;
    return openBlock(), createBlock(
      Fragment,
      null,
      [createVNode("slot", slotProps, fallback && fallback())],
      hasProps ? -2 : 64
    );
  }
  let slot = slots[name];
  if (slot && slot.length > 1) {
    warn$1(
      `SSR-optimized slot function detected in a non-SSR-optimized render function. You need to mark this component with $dynamic-slots in the parent template.`
    );
    slot = () => [];
  }
  if (slot && slot._c) {
    slot._d = false;
  }
  const prevStackSize = blockStack.length;
  openBlock();
  let rendered;
  try {
    const validSlotContent = slot && ensureValidVNode(slot(props));
    const slotKey = props.key || branchKey || // slot content array of a dynamic conditional slot may have a branch
    // key attached in the `createSlots` helper, respect that
    validSlotContent && validSlotContent.key;
    rendered = createBlock(
      Fragment,
      {
        key: (slotKey && !isSymbol(slotKey) ? slotKey : `_${name}`) + // #7256 force differentiate fallback content from actual content
        (!validSlotContent && fallback ? "_fb" : "")
      },
      validSlotContent || (fallback ? fallback() : []),
      validSlotContent && slots._ === 1 ? 64 : -2
    );
  } catch (err) {
    for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
    throw err;
  } finally {
    if (slot && slot._c) {
      slot._d = true;
    }
  }
  if (!noSlotted && rendered.scopeId) {
    rendered.slotScopeIds = [rendered.scopeId + "-s"];
  }
  return rendered;
}
function ensureValidVNode(vnodes) {
  return vnodes.some((child) => {
    if (!isVNode(child)) return true;
    if (child.type === Comment) return false;
    if (child.type === Fragment && !ensureValidVNode(child.children))
      return false;
    return true;
  }) ? vnodes : null;
}
function toHandlers(obj, preserveCaseIfNecessary) {
  const ret = {};
  if (!isObject(obj)) {
    warn$1(`v-on with no argument expects an object value.`);
    return ret;
  }
  for (const key in obj) {
    ret[preserveCaseIfNecessary && /[A-Z]/.test(key) ? `on:${key}` : toHandlerKey(key)] = obj[key];
  }
  return ret;
}
const getPublicInstance = (i) => {
  if (!i) return null;
  if (isStatefulComponent(i)) return getComponentPublicInstance(i);
  return getPublicInstance(i.parent);
};
const publicPropertiesMap = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
    $: (i) => i,
    $el: (i) => i.vnode.el,
    $data: (i) => i.data,
    $props: (i) => true ? shallowReadonly(i.props) : i.props,
    $attrs: (i) => true ? shallowReadonly(i.attrs) : i.attrs,
    $slots: (i) => true ? shallowReadonly(i.slots) : i.slots,
    $refs: (i) => true ? shallowReadonly(i.refs) : i.refs,
    $parent: (i) => getPublicInstance(i.parent),
    $root: (i) => getPublicInstance(i.root),
    $host: (i) => i.ce,
    $emit: (i) => i.emit,
    $options: (i) => __VUE_OPTIONS_API__ ? resolveMergedOptions(i) : i.type,
    $forceUpdate: (i) => i.f || (i.f = () => {
      queueJob(i.update);
    }),
    $nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
    $watch: (i) => __VUE_OPTIONS_API__ ? instanceWatch.bind(i) : NOOP
  })
);
const isReservedPrefix = (key) => key === "_" || key === "$";
const hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
const PublicInstanceProxyHandlers = {
  get({ _: instance }, key) {
    if (key === "__v_skip") {
      return true;
    }
    const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
    if (key === "__isVue") {
      return true;
    }
    if (key[0] !== "$") {
      const n = accessCache[key];
      if (n !== void 0) {
        switch (n) {
          case 1:
            return setupState[key];
          case 2:
            return data[key];
          case 4:
            return ctx[key];
          case 3:
            return props[key];
        }
      } else if (hasSetupBinding(setupState, key)) {
        accessCache[key] = 1;
        return setupState[key];
      } else if (__VUE_OPTIONS_API__ && data !== EMPTY_OBJ && hasOwn(data, key)) {
        accessCache[key] = 2;
        return data[key];
      } else if (hasOwn(props, key)) {
        accessCache[key] = 3;
        return props[key];
      } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
        accessCache[key] = 4;
        return ctx[key];
      } else if (!__VUE_OPTIONS_API__ || shouldCacheAccess) {
        accessCache[key] = 0;
      }
    }
    const publicGetter = publicPropertiesMap[key];
    let cssModule, globalProperties;
    if (publicGetter) {
      if (key === "$attrs") {
        track(instance.attrs, "get", "");
        markAttrsAccessed();
      } else if (key === "$slots") {
        track(instance, "get", key);
      }
      return publicGetter(instance);
    } else if (
      // css module (injected by vue-loader)
      (cssModule = type.__cssModules) && (cssModule = cssModule[key])
    ) {
      return cssModule;
    } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
      accessCache[key] = 4;
      return ctx[key];
    } else if (
      // global properties
      globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)
    ) {
      {
        return globalProperties[key];
      }
    } else if (currentRenderingInstance && (!isString(key) || // #1091 avoid internal isRef/isVNode checks on component instance leading
    // to infinite warning loop
    key.indexOf("__v") !== 0)) {
      if (data !== EMPTY_OBJ && isReservedPrefix(key[0]) && hasOwn(data, key)) {
        warn$1(
          `Property ${JSON.stringify(
            key
          )} must be accessed via $data because it starts with a reserved character ("$" or "_") and is not proxied on the render context.`
        );
      } else if (instance === currentRenderingInstance) {
        warn$1(
          `Property ${JSON.stringify(key)} was accessed during render but is not defined on instance.`
        );
      }
    }
  },
  set({ _: instance }, key, value) {
    const { data, setupState, ctx } = instance;
    if (hasSetupBinding(setupState, key)) {
      setupState[key] = value;
      return true;
    } else if (setupState.__isScriptSetup && hasOwn(setupState, key)) {
      warn$1(`Cannot mutate <script setup> binding "${key}" from Options API.`);
      return false;
    } else if (__VUE_OPTIONS_API__ && data !== EMPTY_OBJ && hasOwn(data, key)) {
      data[key] = value;
      return true;
    } else if (hasOwn(instance.props, key)) {
      warn$1(`Attempting to mutate prop "${key}". Props are readonly.`);
      return false;
    }
    if (key[0] === "$" && key.slice(1) in instance) {
      warn$1(
        `Attempting to mutate public property "${key}". Properties starting with $ are reserved and readonly.`
      );
      return false;
    } else {
      if (key in instance.appContext.config.globalProperties) {
        Object.defineProperty(ctx, key, {
          enumerable: true,
          configurable: true,
          value
        });
      } else {
        ctx[key] = value;
      }
    }
    return true;
  },
  has({
    _: { data, setupState, accessCache, ctx, appContext, props, type }
  }, key) {
    let cssModules;
    return !!(accessCache[key] || __VUE_OPTIONS_API__ && data !== EMPTY_OBJ && key[0] !== "$" && hasOwn(data, key) || hasSetupBinding(setupState, key) || hasOwn(props, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key) || (cssModules = type.__cssModules) && cssModules[key]);
  },
  defineProperty(target, key, descriptor) {
    if (descriptor.get != null) {
      target._.accessCache[key] = 0;
    } else if (hasOwn(descriptor, "value")) {
      this.set(target, key, descriptor.value, null);
    }
    return Reflect.defineProperty(target, key, descriptor);
  }
};
if (true) {
  PublicInstanceProxyHandlers.ownKeys = (target) => {
    warn$1(
      `Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead.`
    );
    return Reflect.ownKeys(target);
  };
}
const RuntimeCompiledPublicInstanceProxyHandlers = /* @__PURE__ */ extend({}, PublicInstanceProxyHandlers, {
  get(target, key) {
    if (key === Symbol.unscopables) {
      return;
    }
    return PublicInstanceProxyHandlers.get(target, key, target);
  },
  has(_, key) {
    const has = key[0] !== "_" && !isGloballyAllowed(key);
    if (!has && PublicInstanceProxyHandlers.has(_, key)) {
      warn$1(
        `Property ${JSON.stringify(
          key
        )} should not start with _ which is a reserved prefix for Vue internals.`
      );
    }
    return has;
  }
});
function createDevRenderContext(instance) {
  const target = {};
  Object.defineProperty(target, `_`, {
    configurable: true,
    enumerable: false,
    get: () => instance
  });
  Object.keys(publicPropertiesMap).forEach((key) => {
    Object.defineProperty(target, key, {
      configurable: true,
      enumerable: false,
      get: () => publicPropertiesMap[key](instance),
      // intercepted by the proxy so no need for implementation,
      // but needed to prevent set errors
      set: NOOP
    });
  });
  return target;
}
function exposePropsOnRenderContext(instance) {
  const {
    ctx,
    propsOptions: [propsOptions]
  } = instance;
  if (propsOptions) {
    Object.keys(propsOptions).forEach((key) => {
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => instance.props[key],
        set: NOOP
      });
    });
  }
}
function exposeSetupStateOnRenderContext(instance) {
  const { ctx, setupState } = instance;
  Object.keys(toRaw(setupState)).forEach((key) => {
    if (!setupState.__isScriptSetup) {
      if (isReservedPrefix(key[0])) {
        warn$1(
          `setup() return property ${JSON.stringify(
            key
          )} should not start with "$" or "_" which are reserved prefixes for Vue internals.`
        );
        return;
      }
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => setupState[key],
        set: NOOP
      });
    }
  });
}
const warnRuntimeUsage = (method) => warn$1(
  `${method}() is a compiler-hint helper that is only usable inside <script setup> of a single file component. Its arguments should be compiled away and passing it at runtime has no effect.`
);
function defineProps() {
  if (true) {
    warnRuntimeUsage(`defineProps`);
  }
  return null;
}
function defineEmits() {
  if (true) {
    warnRuntimeUsage(`defineEmits`);
  }
  return null;
}
function defineExpose(exposed) {
  if (true) {
    warnRuntimeUsage(`defineExpose`);
  }
}
function defineOptions(options) {
  if (true) {
    warnRuntimeUsage(`defineOptions`);
  }
}
function defineSlots() {
  if (true) {
    warnRuntimeUsage(`defineSlots`);
  }
  return null;
}
function defineModel() {
  if (true) {
    warnRuntimeUsage("defineModel");
  }
}
function withDefaults(props, defaults) {
  if (true) {
    warnRuntimeUsage(`withDefaults`);
  }
  return null;
}
function useSlots() {
  return getContext("useSlots").slots;
}
function useAttrs() {
  return getContext("useAttrs").attrs;
}
function getContext(calledFunctionName) {
  const i = getCurrentInstance();
  if (!i) {
    warn$1(`${calledFunctionName}() called without active instance.`);
  }
  return i.setupContext || (i.setupContext = createSetupContext(i));
}
function normalizePropsOrEmits(props) {
  return isArray(props) ? props.reduce(
    (normalized, p) => (normalized[p] = null, normalized),
    {}
  ) : props;
}
function mergeDefaults(raw, defaults) {
  const props = normalizePropsOrEmits(raw);
  for (const key in defaults) {
    if (key.startsWith("__skip")) continue;
    let opt = props[key];
    if (opt) {
      if (isArray(opt) || isFunction(opt)) {
        opt = props[key] = { type: opt, default: defaults[key] };
      } else {
        opt.default = defaults[key];
      }
    } else if (opt === null) {
      opt = props[key] = { default: defaults[key] };
    } else if (true) {
      warn$1(`props default key "${key}" has no corresponding declaration.`);
    }
    if (opt && defaults[`__skip_${key}`]) {
      opt.skipFactory = true;
    }
  }
  return props;
}
function mergeModels(a, b) {
  if (!a || !b) return a || b;
  if (isArray(a) && isArray(b)) return a.concat(b);
  return extend({}, normalizePropsOrEmits(a), normalizePropsOrEmits(b));
}
function createPropsRestProxy(props, excludedKeys) {
  const ret = {};
  for (const key in props) {
    if (!excludedKeys.includes(key)) {
      Object.defineProperty(ret, key, {
        enumerable: true,
        get: () => props[key]
      });
    }
  }
  return ret;
}
function withAsyncContext(getAwaitable) {
  const ctx = getCurrentInstance();
  const inSSRSetup = isInSSRComponentSetup;
  if (!ctx) {
    warn$1(
      `withAsyncContext called without active current instance. This is likely a bug.`
    );
  }
  let awaitable = getAwaitable();
  unsetCurrentInstance();
  if (inSSRSetup) {
    setInSSRSetupState(false);
  }
  const restore = () => {
    setCurrentInstance(ctx);
    if (inSSRSetup) {
      setInSSRSetupState(true);
    }
  };
  const cleanup = () => {
    if (getCurrentInstance() !== ctx) ctx.scope.off();
    unsetCurrentInstance();
    if (inSSRSetup) {
      setInSSRSetupState(false);
    }
  };
  if (isPromise(awaitable)) {
    awaitable = awaitable.catch((e) => {
      restore();
      Promise.resolve().then(() => Promise.resolve().then(cleanup));
      throw e;
    });
  }
  return [
    awaitable,
    () => {
      restore();
      Promise.resolve().then(cleanup);
    }
  ];
}
function createDuplicateChecker() {
  const cache = /* @__PURE__ */ Object.create(null);
  return (type, key) => {
    if (cache[key]) {
      warn$1(`${type} property "${key}" is already defined in ${cache[key]}.`);
    } else {
      cache[key] = type;
    }
  };
}
let shouldCacheAccess = true;
function applyOptions(instance) {
  const options = resolveMergedOptions(instance);
  const publicThis = instance.proxy;
  const ctx = instance.ctx;
  shouldCacheAccess = false;
  if (options.beforeCreate) {
    callHook(options.beforeCreate, instance, "bc");
  }
  const {
    // state
    data: dataOptions,
    computed: computedOptions,
    methods,
    watch: watchOptions,
    provide: provideOptions,
    inject: injectOptions,
    // lifecycle
    created,
    beforeMount,
    mounted,
    beforeUpdate,
    updated,
    activated,
    deactivated,
    beforeDestroy,
    beforeUnmount,
    destroyed,
    unmounted,
    render,
    renderTracked,
    renderTriggered,
    errorCaptured,
    serverPrefetch,
    // public API
    expose,
    inheritAttrs,
    // assets
    components,
    directives,
    filters
  } = options;
  const checkDuplicateProperties = true ? createDuplicateChecker() : null;
  if (true) {
    const [propsOptions] = instance.propsOptions;
    if (propsOptions) {
      for (const key in propsOptions) {
        checkDuplicateProperties("Props", key);
      }
    }
  }
  if (injectOptions) {
    resolveInjections(injectOptions, ctx, checkDuplicateProperties);
  }
  if (methods) {
    for (const key in methods) {
      const methodHandler = methods[key];
      if (isFunction(methodHandler)) {
        if (true) {
          Object.defineProperty(ctx, key, {
            value: methodHandler.bind(publicThis),
            configurable: true,
            enumerable: true,
            writable: true
          });
        } else {
          ctx[key] = methodHandler.bind(publicThis);
        }
        if (true) {
          checkDuplicateProperties("Methods", key);
        }
      } else if (true) {
        warn$1(
          `Method "${key}" has type "${typeof methodHandler}" in the component definition. Did you reference the function correctly?`
        );
      }
    }
  }
  if (dataOptions) {
    if (!isFunction(dataOptions)) {
      warn$1(
        `The data option must be a function. Plain object usage is no longer supported.`
      );
    }
    const data = dataOptions.call(publicThis, publicThis);
    if (isPromise(data)) {
      warn$1(
        `data() returned a Promise - note data() cannot be async; If you intend to perform data fetching before component renders, use async setup() + <Suspense>.`
      );
    }
    if (!isObject(data)) {
      warn$1(`data() should return an object.`);
    } else {
      instance.data = reactive(data);
      if (true) {
        for (const key in data) {
          checkDuplicateProperties("Data", key);
          if (!isReservedPrefix(key[0])) {
            Object.defineProperty(ctx, key, {
              configurable: true,
              enumerable: true,
              get: () => data[key],
              set: NOOP
            });
          }
        }
      }
    }
  }
  shouldCacheAccess = true;
  if (computedOptions) {
    for (const key in computedOptions) {
      const opt = computedOptions[key];
      const get = isFunction(opt) ? opt.bind(publicThis, publicThis) : isFunction(opt.get) ? opt.get.bind(publicThis, publicThis) : NOOP;
      if (get === NOOP) {
        warn$1(`Computed property "${key}" has no getter.`);
      }
      const set = !isFunction(opt) && isFunction(opt.set) ? opt.set.bind(publicThis) : true ? () => {
        warn$1(
          `Write operation failed: computed property "${key}" is readonly.`
        );
      } : NOOP;
      const c = computed({
        get,
        set
      });
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => c.value,
        set: (v) => c.value = v
      });
      if (true) {
        checkDuplicateProperties("Computed", key);
      }
    }
  }
  if (watchOptions) {
    for (const key in watchOptions) {
      createWatcher(watchOptions[key], ctx, publicThis, key);
    }
  }
  if (provideOptions) {
    const provides = isFunction(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
    Reflect.ownKeys(provides).forEach((key) => {
      provide(key, provides[key]);
    });
  }
  if (created) {
    callHook(created, instance, "c");
  }
  function registerLifecycleHook(register, hook) {
    if (isArray(hook)) {
      hook.forEach((_hook) => register(_hook.bind(publicThis)));
    } else if (hook) {
      register(hook.bind(publicThis));
    }
  }
  registerLifecycleHook(onBeforeMount, beforeMount);
  registerLifecycleHook(onMounted, mounted);
  registerLifecycleHook(onBeforeUpdate, beforeUpdate);
  registerLifecycleHook(onUpdated, updated);
  registerLifecycleHook(onActivated, activated);
  registerLifecycleHook(onDeactivated, deactivated);
  registerLifecycleHook(onErrorCaptured, errorCaptured);
  registerLifecycleHook(onRenderTracked, renderTracked);
  registerLifecycleHook(onRenderTriggered, renderTriggered);
  registerLifecycleHook(onBeforeUnmount, beforeUnmount);
  registerLifecycleHook(onUnmounted, unmounted);
  registerLifecycleHook(onServerPrefetch, serverPrefetch);
  if (isArray(expose)) {
    if (expose.length) {
      const exposed = instance.exposed || (instance.exposed = {});
      expose.forEach((key) => {
        Object.defineProperty(exposed, key, {
          get: () => publicThis[key],
          set: (val) => publicThis[key] = val,
          enumerable: true
        });
      });
    } else if (!instance.exposed) {
      instance.exposed = {};
    }
  }
  if (render && instance.render === NOOP) {
    instance.render = render;
  }
  if (inheritAttrs != null) {
    instance.inheritAttrs = inheritAttrs;
  }
  if (components) instance.components = components;
  if (directives) instance.directives = directives;
  if (serverPrefetch) {
    markAsyncBoundary(instance);
  }
}
function resolveInjections(injectOptions, ctx, checkDuplicateProperties = NOOP) {
  if (isArray(injectOptions)) {
    injectOptions = normalizeInject(injectOptions);
  }
  for (const key in injectOptions) {
    const opt = injectOptions[key];
    let injected;
    if (isObject(opt)) {
      if ("default" in opt) {
        injected = inject(
          opt.from || key,
          opt.default,
          true
        );
      } else {
        injected = inject(opt.from || key);
      }
    } else {
      injected = inject(opt);
    }
    if (isRef(injected)) {
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => injected.value,
        set: (v) => injected.value = v
      });
    } else {
      ctx[key] = injected;
    }
    if (true) {
      checkDuplicateProperties("Inject", key);
    }
  }
}
function callHook(hook, instance, type) {
  callWithAsyncErrorHandling(
    isArray(hook) ? hook.map((h2) => h2.bind(instance.proxy)) : hook.bind(instance.proxy),
    instance,
    type
  );
}
function createWatcher(raw, ctx, publicThis, key) {
  let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
  if (isString(raw)) {
    const handler = ctx[raw];
    if (isFunction(handler)) {
      {
        watch(getter, handler);
      }
    } else if (true) {
      warn$1(`Invalid watch handler specified by key "${raw}"`, handler);
    }
  } else if (isFunction(raw)) {
    {
      watch(getter, raw.bind(publicThis));
    }
  } else if (isObject(raw)) {
    if (isArray(raw)) {
      raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
    } else {
      const handler = isFunction(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
      if (isFunction(handler)) {
        watch(getter, handler, raw);
      } else if (true) {
        warn$1(`Invalid watch handler specified by key "${raw.handler}"`, handler);
      }
    }
  } else if (true) {
    warn$1(`Invalid watch option: "${key}"`, raw);
  }
}
function resolveMergedOptions(instance) {
  const base = instance.type;
  const { mixins, extends: extendsOptions } = base;
  const {
    mixins: globalMixins,
    optionsCache: cache,
    config: { optionMergeStrategies }
  } = instance.appContext;
  const cached = cache.get(base);
  let resolved;
  if (cached) {
    resolved = cached;
  } else if (!globalMixins.length && !mixins && !extendsOptions) {
    {
      resolved = base;
    }
  } else {
    resolved = {};
    if (globalMixins.length) {
      globalMixins.forEach(
        (m) => mergeOptions(resolved, m, optionMergeStrategies, true)
      );
    }
    mergeOptions(resolved, base, optionMergeStrategies);
  }
  if (isObject(base)) {
    cache.set(base, resolved);
  }
  return resolved;
}
function mergeOptions(to, from, strats, asMixin = false) {
  const { mixins, extends: extendsOptions } = from;
  if (extendsOptions) {
    mergeOptions(to, extendsOptions, strats, true);
  }
  if (mixins) {
    mixins.forEach(
      (m) => mergeOptions(to, m, strats, true)
    );
  }
  for (const key in from) {
    if (asMixin && key === "expose") {
      warn$1(
        `"expose" option is ignored when declared in mixins or extends. It should only be declared in the base component itself.`
      );
    } else {
      const strat = internalOptionMergeStrats[key] || strats && strats[key];
      to[key] = strat ? strat(to[key], from[key]) : from[key];
    }
  }
  return to;
}
const internalOptionMergeStrats = {
  data: mergeDataFn,
  props: mergeEmitsOrPropsOptions,
  emits: mergeEmitsOrPropsOptions,
  // objects
  methods: mergeObjectOptions,
  computed: mergeObjectOptions,
  // lifecycle
  beforeCreate: mergeAsArray,
  created: mergeAsArray,
  beforeMount: mergeAsArray,
  mounted: mergeAsArray,
  beforeUpdate: mergeAsArray,
  updated: mergeAsArray,
  beforeDestroy: mergeAsArray,
  beforeUnmount: mergeAsArray,
  destroyed: mergeAsArray,
  unmounted: mergeAsArray,
  activated: mergeAsArray,
  deactivated: mergeAsArray,
  errorCaptured: mergeAsArray,
  serverPrefetch: mergeAsArray,
  // assets
  components: mergeObjectOptions,
  directives: mergeObjectOptions,
  // watch
  watch: mergeWatchOptions,
  // provide / inject
  provide: mergeDataFn,
  inject: mergeInject
};
function mergeDataFn(to, from) {
  if (!from) {
    return to;
  }
  if (!to) {
    return from;
  }
  return function mergedDataFn() {
    return extend(
      isFunction(to) ? to.call(this, this) : to,
      isFunction(from) ? from.call(this, this) : from
    );
  };
}
function mergeInject(to, from) {
  return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
}
function normalizeInject(raw) {
  if (isArray(raw)) {
    const res = {};
    for (let i = 0; i < raw.length; i++) {
      res[raw[i]] = raw[i];
    }
    return res;
  }
  return raw;
}
function mergeAsArray(to, from) {
  return to ? [...new Set([].concat(to, from))] : from;
}
function mergeObjectOptions(to, from) {
  return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
}
function mergeEmitsOrPropsOptions(to, from) {
  if (to) {
    if (isArray(to) && isArray(from)) {
      return [.../* @__PURE__ */ new Set([...to, ...from])];
    }
    return extend(
      /* @__PURE__ */ Object.create(null),
      normalizePropsOrEmits(to),
      normalizePropsOrEmits(from != null ? from : {})
    );
  } else {
    return from;
  }
}
function mergeWatchOptions(to, from) {
  if (!to) return from;
  if (!from) return to;
  const merged = extend(/* @__PURE__ */ Object.create(null), to);
  for (const key in from) {
    merged[key] = mergeAsArray(to[key], from[key]);
  }
  return merged;
}
function createAppContext() {
  return {
    app: null,
    config: {
      isNativeTag: NO,
      performance: false,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let uid$1 = 0;
function createAppAPI(render, hydrate) {
  return function createApp(rootComponent, rootProps = null) {
    if (!isFunction(rootComponent)) {
      rootComponent = extend({}, rootComponent);
    }
    if (rootProps != null && !isObject(rootProps)) {
      warn$1(`root props passed to app.mount() must be an object.`);
      rootProps = null;
    }
    const context = createAppContext();
    const installedPlugins = /* @__PURE__ */ new WeakSet();
    const pluginCleanupFns = [];
    let isMounted = false;
    const app = context.app = {
      _uid: uid$1++,
      _component: rootComponent,
      _props: rootProps,
      _container: null,
      _context: context,
      _instance: null,
      version,
      get config() {
        return context.config;
      },
      set config(v) {
        if (true) {
          warn$1(
            `app.config cannot be replaced. Modify individual options instead.`
          );
        }
      },
      use(plugin, ...options) {
        if (installedPlugins.has(plugin)) {
          warn$1(`Plugin has already been applied to target app.`);
        } else if (plugin && isFunction(plugin.install)) {
          installedPlugins.add(plugin);
          plugin.install(app, ...options);
        } else if (isFunction(plugin)) {
          installedPlugins.add(plugin);
          plugin(app, ...options);
        } else if (true) {
          warn$1(
            `A plugin must either be a function or an object with an "install" function.`
          );
        }
        return app;
      },
      mixin(mixin) {
        if (__VUE_OPTIONS_API__) {
          if (!context.mixins.includes(mixin)) {
            context.mixins.push(mixin);
          } else if (true) {
            warn$1(
              "Mixin has already been applied to target app" + (mixin.name ? `: ${mixin.name}` : "")
            );
          }
        } else if (true) {
          warn$1("Mixins are only available in builds supporting Options API");
        }
        return app;
      },
      component(name, component) {
        if (true) {
          validateComponentName(name, context.config);
        }
        if (!component) {
          return context.components[name];
        }
        if (context.components[name]) {
          warn$1(`Component "${name}" has already been registered in target app.`);
        }
        context.components[name] = component;
        return app;
      },
      directive(name, directive) {
        if (true) {
          validateDirectiveName(name);
        }
        if (!directive) {
          return context.directives[name];
        }
        if (context.directives[name]) {
          warn$1(`Directive "${name}" has already been registered in target app.`);
        }
        context.directives[name] = directive;
        return app;
      },
      mount(rootContainer, isHydrate, namespace) {
        if (!isMounted) {
          if (rootContainer.__vue_app__) {
            warn$1(
              `There is already an app instance mounted on the host container.
 If you want to mount another app on the same host container, you need to unmount the previous app by calling \`app.unmount()\` first.`
            );
          }
          const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
          vnode.appContext = context;
          if (namespace === true) {
            namespace = "svg";
          } else if (namespace === false) {
            namespace = void 0;
          }
          if (true) {
            context.reload = () => {
              const cloned = cloneVNode(vnode);
              cloned.el = null;
              render(cloned, rootContainer, namespace);
            };
          }
          if (isHydrate && hydrate) {
            hydrate(vnode, rootContainer);
          } else {
            render(vnode, rootContainer, namespace);
          }
          isMounted = true;
          app._container = rootContainer;
          rootContainer.__vue_app__ = app;
          if (true) {
            app._instance = vnode.component;
            devtoolsInitApp(app, version);
          }
          return getComponentPublicInstance(vnode.component);
        } else if (true) {
          warn$1(
            `App has already been mounted.
If you want to remount the same app, move your app creation logic into a factory function and create fresh app instances for each mount - e.g. \`const createMyApp = () => createApp(App)\``
          );
        }
      },
      onUnmount(cleanupFn) {
        if (typeof cleanupFn !== "function") {
          warn$1(
            `Expected function as first argument to app.onUnmount(), but got ${typeof cleanupFn}`
          );
        }
        pluginCleanupFns.push(cleanupFn);
      },
      unmount() {
        if (isMounted) {
          callWithAsyncErrorHandling(
            pluginCleanupFns,
            app._instance,
            16
          );
          render(null, app._container);
          if (true) {
            app._instance = null;
            devtoolsUnmountApp(app);
          }
          delete app._container.__vue_app__;
        } else if (true) {
          warn$1(`Cannot unmount an app that is not mounted.`);
        }
      },
      provide(key, value) {
        if (key in context.provides) {
          if (hasOwn(context.provides, key)) {
            warn$1(
              `App already provides property with key "${String(key)}". It will be overwritten with the new value.`
            );
          } else {
            warn$1(
              `App already provides property with key "${String(key)}" inherited from its parent element. It will be overwritten with the new value.`
            );
          }
        }
        context.provides[key] = value;
        return app;
      },
      runWithContext(fn) {
        const lastApp = currentApp;
        currentApp = app;
        try {
          return fn();
        } finally {
          currentApp = lastApp;
        }
      }
    };
    return app;
  };
}
let currentApp = null;
function useModel(props, name, options = EMPTY_OBJ) {
  const i = getCurrentInstance();
  if (!i) {
    warn$1(`useModel() called without active instance.`);
    return ref();
  }
  const camelizedName = camelize(name);
  if (!i.propsOptions[0][camelizedName]) {
    warn$1(`useModel() called with prop "${name}" which is not declared.`);
    return ref();
  }
  const hyphenatedName = hyphenate(name);
  const modifiers = getModelModifiers(props, camelizedName);
  const res = customRef((track2, trigger2) => {
    let localValue;
    let prevSetValue = EMPTY_OBJ;
    let prevEmittedValue;
    watchSyncEffect(() => {
      const propValue = props[camelizedName];
      if (hasChanged(localValue, propValue)) {
        localValue = propValue;
        trigger2();
      }
    });
    return {
      get() {
        track2();
        return options.get ? options.get(localValue) : localValue;
      },
      set(value) {
        const emittedValue = options.set ? options.set(value) : value;
        if (!hasChanged(emittedValue, localValue) && !(prevSetValue !== EMPTY_OBJ && hasChanged(value, prevSetValue))) {
          return;
        }
        const rawProps = i.vnode.props;
        const hasVModel = !!(rawProps && // check if parent has passed v-model
        (name in rawProps || camelizedName in rawProps || hyphenatedName in rawProps) && (`onUpdate:${name}` in rawProps || `onUpdate:${camelizedName}` in rawProps || `onUpdate:${hyphenatedName}` in rawProps));
        if (!hasVModel) {
          localValue = value;
          trigger2();
        }
        i.emit(`update:${name}`, emittedValue);
        if (hasChanged(value, prevSetValue) && (hasChanged(value, emittedValue) && !hasChanged(emittedValue, prevEmittedValue) || // #13524: browsers differ in when they flush microtasks between
        // event listeners. If a v-model listener emits an intermediate value
        // and a following listener restores the model to its previous prop
        // value before parent updates are flushed, the parent render can be
        // deduped as having no prop change. Force a local update so DOM state
        // such as an input's value is synchronized back to the current model.
        hasVModel && prevSetValue !== EMPTY_OBJ && !hasChanged(emittedValue, localValue))) {
          trigger2();
        }
        prevSetValue = value;
        prevEmittedValue = emittedValue;
      }
    };
  });
  res[Symbol.iterator] = () => {
    let i2 = 0;
    return {
      next() {
        if (i2 < 2) {
          return { value: i2++ ? modifiers || EMPTY_OBJ : res, done: false };
        } else {
          return { done: true };
        }
      }
    };
  };
  return res;
}
const getModelModifiers = (props, modelName) => {
  return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${camelize(modelName)}Modifiers`] || props[`${hyphenate(modelName)}Modifiers`];
};
function emit(instance, event, ...rawArgs) {
  if (instance.isUnmounted) return;
  const props = instance.vnode.props || EMPTY_OBJ;
  if (true) {
    const {
      emitsOptions,
      propsOptions: [propsOptions]
    } = instance;
    if (emitsOptions) {
      if (!(event in emitsOptions) && true) {
        if (!propsOptions || !(toHandlerKey(camelize(event)) in propsOptions)) {
          warn$1(
            `Component emitted event "${event}" but it is neither declared in the emits option nor as an "${toHandlerKey(camelize(event))}" prop.`
          );
        }
      } else {
        const validator = emitsOptions[event];
        if (isFunction(validator)) {
          const isValid = validator(...rawArgs);
          if (!isValid) {
            warn$1(
              `Invalid event arguments: event validation failed for event "${event}".`
            );
          }
        }
      }
    }
  }
  let args = rawArgs;
  const isModelListener2 = event.startsWith("update:");
  const modifiers = isModelListener2 && getModelModifiers(props, event.slice(7));
  if (modifiers) {
    if (modifiers.trim) {
      args = rawArgs.map((a) => isString(a) ? a.trim() : a);
    }
    if (modifiers.number) {
      args = rawArgs.map(looseToNumber);
    }
  }
  if (true) {
    devtoolsComponentEmit(instance, event, args);
  }
  if (true) {
    const lowerCaseEvent = event.toLowerCase();
    if (lowerCaseEvent !== event && props[toHandlerKey(lowerCaseEvent)]) {
      warn$1(
        `Event "${lowerCaseEvent}" is emitted in component ${formatComponentName(
          instance,
          instance.type
        )} but the handler is registered for "${event}". Note that HTML attributes are case-insensitive and you cannot use v-on to listen to camelCase events when using in-DOM templates. You should probably use "${hyphenate(
          event
        )}" instead of "${event}".`
      );
    }
  }
  let handlerName;
  let handler = props[handlerName = toHandlerKey(event)] || // also try camelCase event handler (#2249)
  props[handlerName = toHandlerKey(camelize(event))];
  if (!handler && isModelListener2) {
    handler = props[handlerName = toHandlerKey(hyphenate(event))];
  }
  if (handler) {
    callWithAsyncErrorHandling(
      handler,
      instance,
      6,
      args
    );
  }
  const onceHandler = props[handlerName + `Once`];
  if (onceHandler) {
    if (!instance.emitted) {
      instance.emitted = {};
    } else if (instance.emitted[handlerName]) {
      return;
    }
    instance.emitted[handlerName] = true;
    callWithAsyncErrorHandling(
      onceHandler,
      instance,
      6,
      args
    );
  }
}
const mixinEmitsCache = /* @__PURE__ */ new WeakMap();
function normalizeEmitsOptions(comp, appContext, asMixin = false) {
  const cache = __VUE_OPTIONS_API__ && asMixin ? mixinEmitsCache : appContext.emitsCache;
  const cached = cache.get(comp);
  if (cached !== void 0) {
    return cached;
  }
  const raw = comp.emits;
  let normalized = {};
  let hasExtends = false;
  if (__VUE_OPTIONS_API__ && !isFunction(comp)) {
    const extendEmits = (raw2) => {
      const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
      if (normalizedFromExtend) {
        hasExtends = true;
        extend(normalized, normalizedFromExtend);
      }
    };
    if (!asMixin && appContext.mixins.length) {
      appContext.mixins.forEach(extendEmits);
    }
    if (comp.extends) {
      extendEmits(comp.extends);
    }
    if (comp.mixins) {
      comp.mixins.forEach(extendEmits);
    }
  }
  if (!raw && !hasExtends) {
    if (isObject(comp)) {
      cache.set(comp, null);
    }
    return null;
  }
  if (isArray(raw)) {
    raw.forEach((key) => normalized[key] = null);
  } else {
    extend(normalized, raw);
  }
  if (isObject(comp)) {
    cache.set(comp, normalized);
  }
  return normalized;
}
function isEmitListener(options, key) {
  if (!options || !isOn(key)) {
    return false;
  }
  key = key.slice(2);
  key = key === "Once" ? key : key.replace(/Once$/, "");
  return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, hyphenate(key)) || hasOwn(options, key);
}
let accessedAttrs = false;
function markAttrsAccessed() {
  accessedAttrs = true;
}
function renderComponentRoot(instance) {
  const {
    type: Component,
    vnode,
    proxy,
    withProxy,
    propsOptions: [propsOptions],
    slots,
    attrs,
    emit: emit2,
    render,
    renderCache,
    props,
    data,
    setupState,
    ctx,
    inheritAttrs
  } = instance;
  const prev = setCurrentRenderingInstance(instance);
  let result;
  let fallthroughAttrs;
  if (true) {
    accessedAttrs = false;
  }
  try {
    if (vnode.shapeFlag & 4) {
      const proxyToUse = withProxy || proxy;
      const thisProxy = setupState.__isScriptSetup ? new Proxy(proxyToUse, {
        get(target, key, receiver) {
          warn$1(
            `Property '${String(
              key
            )}' was accessed via 'this'. Avoid using 'this' in templates.`
          );
          return Reflect.get(target, key, receiver);
        }
      }) : proxyToUse;
      result = normalizeVNode(
        render.call(
          thisProxy,
          proxyToUse,
          renderCache,
          true ? shallowReadonly(props) : props,
          setupState,
          data,
          ctx
        )
      );
      fallthroughAttrs = attrs;
    } else {
      const render2 = Component;
      if (attrs === props) {
        markAttrsAccessed();
      }
      result = normalizeVNode(
        render2.length > 1 ? render2(
          true ? shallowReadonly(props) : props,
          true ? {
            get attrs() {
              markAttrsAccessed();
              return shallowReadonly(attrs);
            },
            slots,
            emit: emit2
          } : { attrs, slots, emit: emit2 }
        ) : render2(
          true ? shallowReadonly(props) : props,
          null
        )
      );
      fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
    }
  } catch (err) {
    blockStack.length = 0;
    handleError(err, instance, 1);
    result = createVNode(Comment);
  }
  let root = result;
  let setRoot = void 0;
  if (result.patchFlag > 0 && result.patchFlag & 2048) {
    [root, setRoot] = getChildRoot(result);
  }
  if (fallthroughAttrs && inheritAttrs !== false) {
    const keys = Object.keys(fallthroughAttrs);
    const { shapeFlag } = root;
    if (keys.length) {
      if (shapeFlag & (1 | 6)) {
        if (propsOptions && keys.some(isModelListener)) {
          fallthroughAttrs = filterModelListeners(
            fallthroughAttrs,
            propsOptions
          );
        }
        root = cloneVNode(root, fallthroughAttrs, false, true);
      } else if (!accessedAttrs && root.type !== Comment) {
        const allAttrs = Object.keys(attrs);
        const eventAttrs = [];
        const extraAttrs = [];
        for (let i = 0, l = allAttrs.length; i < l; i++) {
          const key = allAttrs[i];
          if (isOn(key)) {
            if (!isModelListener(key)) {
              eventAttrs.push(key[2].toLowerCase() + key.slice(3));
            }
          } else {
            extraAttrs.push(key);
          }
        }
        if (extraAttrs.length) {
          warn$1(
            `Extraneous non-props attributes (${extraAttrs.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text or teleport root nodes.`
          );
        }
        if (eventAttrs.length) {
          warn$1(
            `Extraneous non-emits event listeners (${eventAttrs.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes. If the listener is intended to be a component custom event listener only, declare it using the "emits" option.`
          );
        }
      }
    }
  }
  if (vnode.dirs) {
    if (!isElementRoot(root)) {
      warn$1(
        `Runtime directive used on component with non-element root node. The directives will not function as intended.`
      );
    }
    root = cloneVNode(root, null, false, true);
    root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
  }
  if (vnode.transition) {
    const child = isTeleport(root.type) ? getInnerChild$1(root) || root : root;
    if (!isElementRoot(child)) {
      warn$1(
        `Component inside <Transition> renders non-element root node that cannot be animated.`
      );
    }
    setTransitionHooks(child, vnode.transition);
  }
  if (setRoot) {
    setRoot(root);
  } else {
    result = root;
  }
  setCurrentRenderingInstance(prev);
  return result;
}
const getChildRoot = (vnode) => {
  const rawChildren = vnode.children;
  const dynamicChildren = vnode.dynamicChildren;
  const childRoot = filterSingleRoot(rawChildren, false);
  if (!childRoot) {
    return [vnode, void 0];
  } else if (childRoot.patchFlag > 0 && childRoot.patchFlag & 2048) {
    return getChildRoot(childRoot);
  }
  const index = rawChildren.indexOf(childRoot);
  const dynamicIndex = dynamicChildren ? dynamicChildren.indexOf(childRoot) : -1;
  const setRoot = (updatedRoot) => {
    rawChildren[index] = updatedRoot;
    if (dynamicChildren) {
      if (dynamicIndex > -1) {
        dynamicChildren[dynamicIndex] = updatedRoot;
      } else if (updatedRoot.patchFlag > 0) {
        vnode.dynamicChildren = [...dynamicChildren, updatedRoot];
      }
    }
  };
  return [normalizeVNode(childRoot), setRoot];
};
function filterSingleRoot(children, recurse = true) {
  let singleRoot;
  for (let i = 0; i < children.length; i++) {
    const child = children[i];
    if (isVNode(child)) {
      if (child.type !== Comment || child.children === "v-if") {
        if (singleRoot) {
          return;
        } else {
          singleRoot = child;
          if (recurse && singleRoot.patchFlag > 0 && singleRoot.patchFlag & 2048) {
            return filterSingleRoot(singleRoot.children);
          }
        }
      }
    } else {
      return;
    }
  }
  return singleRoot;
}
const getFunctionalFallthrough = (attrs) => {
  let res;
  for (const key in attrs) {
    if (key === "class" || key === "style" || isOn(key)) {
      (res || (res = {}))[key] = attrs[key];
    }
  }
  return res;
};
const filterModelListeners = (attrs, props) => {
  const res = {};
  for (const key in attrs) {
    if (!isModelListener(key) || !(key.slice(9) in props)) {
      res[key] = attrs[key];
    }
  }
  return res;
};
const isElementRoot = (vnode) => {
  return vnode.shapeFlag & (6 | 1) || vnode.type === Comment;
};
function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
  const { props: prevProps, children: prevChildren, component } = prevVNode;
  const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
  const emits = component.emitsOptions;
  if ((prevChildren || nextChildren) && isHmrUpdating) {
    return true;
  }
  if (nextVNode.dirs || nextVNode.transition) {
    return true;
  }
  if (optimized && patchFlag >= 0) {
    if (patchFlag & 1024) {
      return true;
    }
    if (patchFlag & 16) {
      if (!prevProps) {
        return !!nextProps;
      }
      return hasPropsChanged(prevProps, nextProps, emits);
    } else if (patchFlag & 8) {
      const dynamicProps = nextVNode.dynamicProps;
      for (let i = 0; i < dynamicProps.length; i++) {
        const key = dynamicProps[i];
        if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emits, key)) {
          return true;
        }
      }
    }
  } else {
    if (prevChildren || nextChildren) {
      if (!nextChildren || !nextChildren.$stable) {
        return true;
      }
    }
    if (prevProps === nextProps) {
      return false;
    }
    if (!prevProps) {
      return !!nextProps;
    }
    if (!nextProps) {
      return true;
    }
    return hasPropsChanged(prevProps, nextProps, emits);
  }
  return false;
}
function hasPropsChanged(prevProps, nextProps, emitsOptions) {
  const nextKeys = Object.keys(nextProps);
  if (nextKeys.length !== Object.keys(prevProps).length) {
    return true;
  }
  for (let i = 0; i < nextKeys.length; i++) {
    const key = nextKeys[i];
    if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emitsOptions, key)) {
      return true;
    }
  }
  return false;
}
function hasPropValueChanged(nextProps, prevProps, key) {
  const nextProp = nextProps[key];
  const prevProp = prevProps[key];
  if (key === "style" && isObject(nextProp) && isObject(prevProp)) {
    return !looseEqual(nextProp, prevProp);
  }
  return nextProp !== prevProp;
}
function updateHOCHostEl({ vnode, parent, suspense }, el) {
  while (parent) {
    const root = parent.subTree;
    if (root.suspense && root.suspense.activeBranch === vnode) {
      root.suspense.vnode.el = root.el = el;
      vnode = root;
    }
    if (root === vnode) {
      (vnode = parent.vnode).el = el;
      parent = parent.parent;
    } else {
      break;
    }
  }
  if (suspense && suspense.activeBranch === vnode) {
    suspense.vnode.el = el;
  }
}
const internalObjectProto = {};
const createInternalObject = () => Object.create(internalObjectProto);
const isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;
function initProps(instance, rawProps, isStateful, isSSR = false) {
  const props = {};
  const attrs = createInternalObject();
  instance.propsDefaults = /* @__PURE__ */ Object.create(null);
  setFullProps(instance, rawProps, props, attrs);
  for (const key in instance.propsOptions[0]) {
    if (!(key in props)) {
      props[key] = void 0;
    }
  }
  if (true) {
    validateProps(rawProps || {}, props, instance);
  }
  if (isStateful) {
    instance.props = isSSR ? props : shallowReactive(props);
  } else {
    if (!instance.type.props) {
      instance.props = attrs;
    } else {
      instance.props = props;
    }
  }
  instance.attrs = attrs;
}
function isInHmrContext(instance) {
  while (instance) {
    if (instance.type.__hmrId) return true;
    instance = instance.parent;
  }
}
function updateProps(instance, rawProps, rawPrevProps, optimized) {
  const {
    props,
    attrs,
    vnode: { patchFlag }
  } = instance;
  const rawCurrentProps = toRaw(props);
  const [options] = instance.propsOptions;
  let hasAttrsChanged = false;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    !isInHmrContext(instance) && (optimized || patchFlag > 0) && !(patchFlag & 16)
  ) {
    if (patchFlag & 8) {
      const propsToUpdate = instance.vnode.dynamicProps;
      for (let i = 0; i < propsToUpdate.length; i++) {
        let key = propsToUpdate[i];
        if (isEmitListener(instance.emitsOptions, key)) {
          continue;
        }
        const value = rawProps[key];
        if (options) {
          if (hasOwn(attrs, key)) {
            if (value !== attrs[key]) {
              attrs[key] = value;
              hasAttrsChanged = true;
            }
          } else {
            const camelizedKey = camelize(key);
            props[camelizedKey] = resolvePropValue(
              options,
              rawCurrentProps,
              camelizedKey,
              value,
              instance,
              false
            );
          }
        } else {
          if (value !== attrs[key]) {
            attrs[key] = value;
            hasAttrsChanged = true;
          }
        }
      }
    }
  } else {
    if (setFullProps(instance, rawProps, props, attrs)) {
      hasAttrsChanged = true;
    }
    let kebabKey;
    for (const key in rawCurrentProps) {
      if (!rawProps || // for camelCase
      !hasOwn(rawProps, key) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((kebabKey = hyphenate(key)) === key || !hasOwn(rawProps, kebabKey))) {
        if (options) {
          if (rawPrevProps && // for camelCase
          (rawPrevProps[key] !== void 0 || // for kebab-case
          rawPrevProps[kebabKey] !== void 0)) {
            props[key] = resolvePropValue(
              options,
              rawCurrentProps,
              key,
              void 0,
              instance,
              true
            );
          }
        } else {
          delete props[key];
        }
      }
    }
    if (attrs !== rawCurrentProps) {
      for (const key in attrs) {
        if (!rawProps || !hasOwn(rawProps, key) && true) {
          delete attrs[key];
          hasAttrsChanged = true;
        }
      }
    }
  }
  if (hasAttrsChanged) {
    trigger(instance.attrs, "set", "");
  }
  if (true) {
    validateProps(rawProps || {}, props, instance);
  }
}
function setFullProps(instance, rawProps, props, attrs) {
  const [options, needCastKeys] = instance.propsOptions;
  let hasAttrsChanged = false;
  let rawCastValues;
  if (rawProps) {
    for (let key in rawProps) {
      if (isReservedProp(key)) {
        continue;
      }
      const value = rawProps[key];
      let camelKey;
      if (options && hasOwn(options, camelKey = camelize(key))) {
        if (!needCastKeys || !needCastKeys.includes(camelKey)) {
          props[camelKey] = value;
        } else {
          (rawCastValues || (rawCastValues = {}))[camelKey] = value;
        }
      } else if (!isEmitListener(instance.emitsOptions, key)) {
        if (!(key in attrs) || value !== attrs[key]) {
          attrs[key] = value;
          hasAttrsChanged = true;
        }
      }
    }
  }
  if (needCastKeys) {
    const rawCurrentProps = toRaw(props);
    const castValues = rawCastValues || EMPTY_OBJ;
    for (let i = 0; i < needCastKeys.length; i++) {
      const key = needCastKeys[i];
      props[key] = resolvePropValue(
        options,
        rawCurrentProps,
        key,
        castValues[key],
        instance,
        !hasOwn(castValues, key)
      );
    }
  }
  return hasAttrsChanged;
}
function resolvePropValue(options, props, key, value, instance, isAbsent) {
  const opt = options[key];
  if (opt != null) {
    const hasDefault = hasOwn(opt, "default");
    if (hasDefault && value === void 0) {
      const defaultValue = opt.default;
      if (opt.type !== Function && !opt.skipFactory && isFunction(defaultValue)) {
        const { propsDefaults } = instance;
        if (key in propsDefaults) {
          value = propsDefaults[key];
        } else {
          const reset = setCurrentInstance(instance);
          value = propsDefaults[key] = defaultValue.call(
            null,
            props
          );
          reset();
        }
      } else {
        value = defaultValue;
      }
      if (instance.ce) {
        instance.ce._setProp(key, value);
      }
    }
    if (opt[
      0
      /* shouldCast */
    ]) {
      if (isAbsent && !hasDefault) {
        value = false;
      } else if (opt[
        1
        /* shouldCastTrue */
      ] && (value === "" || value === hyphenate(key))) {
        value = true;
      }
    }
  }
  return value;
}
const mixinPropsCache = /* @__PURE__ */ new WeakMap();
function normalizePropsOptions(comp, appContext, asMixin = false) {
  const cache = __VUE_OPTIONS_API__ && asMixin ? mixinPropsCache : appContext.propsCache;
  const cached = cache.get(comp);
  if (cached) {
    return cached;
  }
  const raw = comp.props;
  const normalized = {};
  const needCastKeys = [];
  let hasExtends = false;
  if (__VUE_OPTIONS_API__ && !isFunction(comp)) {
    const extendProps = (raw2) => {
      hasExtends = true;
      const [props, keys] = normalizePropsOptions(raw2, appContext, true);
      extend(normalized, props);
      if (keys) needCastKeys.push(...keys);
    };
    if (!asMixin && appContext.mixins.length) {
      appContext.mixins.forEach(extendProps);
    }
    if (comp.extends) {
      extendProps(comp.extends);
    }
    if (comp.mixins) {
      comp.mixins.forEach(extendProps);
    }
  }
  if (!raw && !hasExtends) {
    if (isObject(comp)) {
      cache.set(comp, EMPTY_ARR);
    }
    return EMPTY_ARR;
  }
  if (isArray(raw)) {
    for (let i = 0; i < raw.length; i++) {
      if (!isString(raw[i])) {
        warn$1(`props must be strings when using array syntax.`, raw[i]);
      }
      const normalizedKey = camelize(raw[i]);
      if (validatePropName(normalizedKey)) {
        normalized[normalizedKey] = EMPTY_OBJ;
      }
    }
  } else if (raw) {
    if (!isObject(raw)) {
      warn$1(`invalid props options`, raw);
    }
    for (const key in raw) {
      const normalizedKey = camelize(key);
      if (validatePropName(normalizedKey)) {
        const opt = raw[key];
        const prop = normalized[normalizedKey] = isArray(opt) || isFunction(opt) ? { type: opt } : extend({}, opt);
        const propType = prop.type;
        let shouldCast = false;
        let shouldCastTrue = true;
        if (isArray(propType)) {
          for (let index = 0; index < propType.length; ++index) {
            const type = propType[index];
            const typeName = isFunction(type) && type.name;
            if (typeName === "Boolean") {
              shouldCast = true;
              break;
            } else if (typeName === "String") {
              shouldCastTrue = false;
            }
          }
        } else {
          shouldCast = isFunction(propType) && propType.name === "Boolean";
        }
        prop[
          0
          /* shouldCast */
        ] = shouldCast;
        prop[
          1
          /* shouldCastTrue */
        ] = shouldCastTrue;
        if (shouldCast || hasOwn(prop, "default")) {
          needCastKeys.push(normalizedKey);
        }
      }
    }
  }
  const res = [normalized, needCastKeys];
  if (isObject(comp)) {
    cache.set(comp, res);
  }
  return res;
}
function validatePropName(key) {
  if (key[0] !== "$" && !isReservedProp(key)) {
    return true;
  } else if (true) {
    warn$1(`Invalid prop name: "${key}" is a reserved property.`);
  }
  return false;
}
function getType(ctor) {
  if (ctor === null) {
    return "null";
  }
  if (typeof ctor === "function") {
    return ctor.name || "";
  } else if (typeof ctor === "object") {
    const name = ctor.constructor && ctor.constructor.name;
    return name || "";
  }
  return "";
}
function validateProps(rawProps, props, instance) {
  const resolvedValues = toRaw(props);
  const options = instance.propsOptions[0];
  const camelizePropsKey = Object.keys(rawProps).map((key) => camelize(key));
  for (const key in options) {
    let opt = options[key];
    if (opt == null) continue;
    validateProp(
      key,
      resolvedValues[key],
      opt,
      true ? shallowReadonly(resolvedValues) : resolvedValues,
      !camelizePropsKey.includes(key)
    );
  }
}
function validateProp(name, value, prop, props, isAbsent) {
  const { type, required, validator, skipCheck } = prop;
  if (required && isAbsent) {
    warn$1('Missing required prop: "' + name + '"');
    return;
  }
  if (value == null && !required) {
    return;
  }
  if (type != null && type !== true && !skipCheck) {
    let isValid = false;
    const types = isArray(type) ? type : [type];
    const expectedTypes = [];
    for (let i = 0; i < types.length && !isValid; i++) {
      const { valid, expectedType } = assertType(value, types[i]);
      expectedTypes.push(expectedType || "");
      isValid = valid;
    }
    if (!isValid) {
      warn$1(getInvalidTypeMessage(name, value, expectedTypes));
      return;
    }
  }
  if (validator && !validator(value, props)) {
    warn$1('Invalid prop: custom validator check failed for prop "' + name + '".');
  }
}
const isSimpleType = /* @__PURE__ */ makeMap(
  "String,Number,Boolean,Function,Symbol,BigInt"
);
function assertType(value, type) {
  let valid;
  const expectedType = getType(type);
  if (expectedType === "null") {
    valid = value === null;
  } else if (isSimpleType(expectedType)) {
    const t = typeof value;
    valid = t === expectedType.toLowerCase();
    if (!valid && t === "object") {
      valid = value instanceof type;
    }
  } else if (expectedType === "Object") {
    valid = isObject(value);
  } else if (expectedType === "Array") {
    valid = isArray(value);
  } else {
    valid = value instanceof type;
  }
  return {
    valid,
    expectedType
  };
}
function getInvalidTypeMessage(name, value, expectedTypes) {
  if (expectedTypes.length === 0) {
    return `Prop type [] for prop "${name}" won't match anything. Did you mean to use type Array instead?`;
  }
  let message = `Invalid prop: type check failed for prop "${name}". Expected ${expectedTypes.map(capitalize).join(" | ")}`;
  const expectedType = expectedTypes[0];
  const receivedType = toRawType(value);
  const expectedValue = styleValue(value, expectedType);
  const receivedValue = styleValue(value, receivedType);
  if (expectedTypes.length === 1 && isExplicable(expectedType) && isCoercible(expectedType, receivedType)) {
    message += ` with value ${expectedValue}`;
  }
  message += `, got ${receivedType} `;
  if (isExplicable(receivedType)) {
    message += `with value ${receivedValue}.`;
  }
  return message;
}
function styleValue(value, type) {
  if (isSymbol(value)) {
    return value.toString();
  } else if (type === "String") {
    return `"${value}"`;
  } else if (type === "Number") {
    return `${Number(value)}`;
  } else {
    return `${value}`;
  }
}
function isExplicable(type) {
  const explicitTypes = ["string", "number", "boolean"];
  return explicitTypes.some((elem) => type.toLowerCase() === elem);
}
function isCoercible(...args) {
  return args.every((elem) => {
    const value = elem.toLowerCase();
    return value !== "boolean" && value !== "symbol";
  });
}
const isInternalKey = (key) => key === "_" || key === "_ctx" || key === "$stable";
const normalizeSlotValue = (value) => isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
const normalizeSlot = (key, rawSlot, ctx) => {
  if (rawSlot._n) {
    return rawSlot;
  }
  const normalized = withCtx((...args) => {
    if (currentInstance && !(ctx === null && currentRenderingInstance) && !(ctx && ctx.root !== currentInstance.root)) {
      warn$1(
        `Slot "${key}" invoked outside of the render function: this will not track dependencies used in the slot. Invoke the slot function inside the render function instead.`
      );
    }
    return normalizeSlotValue(rawSlot(...args));
  }, ctx);
  normalized._c = false;
  return normalized;
};
const normalizeObjectSlots = (rawSlots, slots, instance) => {
  const ctx = rawSlots._ctx;
  for (const key in rawSlots) {
    if (isInternalKey(key)) continue;
    const value = rawSlots[key];
    if (isFunction(value)) {
      slots[key] = normalizeSlot(key, value, ctx);
    } else if (value != null) {
      if (true) {
        warn$1(
          `Non-function value encountered for slot "${key}". Prefer function slots for better performance.`
        );
      }
      const normalized = normalizeSlotValue(value);
      slots[key] = () => normalized;
    }
  }
};
const normalizeVNodeSlots = (instance, children) => {
  if (!isKeepAlive(instance.vnode) && true) {
    warn$1(
      `Non-function value encountered for default slot. Prefer function slots for better performance.`
    );
  }
  const normalized = normalizeSlotValue(children);
  instance.slots.default = () => normalized;
};
const assignSlots = (slots, children, optimized) => {
  for (const key in children) {
    if (optimized || !isInternalKey(key)) {
      slots[key] = children[key];
    }
  }
};
const initSlots = (instance, children, optimized) => {
  const slots = instance.slots = createInternalObject();
  if (instance.vnode.shapeFlag & 32) {
    const type = children._;
    if (type) {
      assignSlots(slots, children, optimized);
      if (optimized) {
        def(slots, "_", type, true);
      }
    } else {
      normalizeObjectSlots(children, slots);
    }
  } else if (children) {
    normalizeVNodeSlots(instance, children);
  }
};
const updateSlots = (instance, children, optimized) => {
  const { vnode, slots } = instance;
  let needDeletionCheck = true;
  let deletionComparisonTarget = EMPTY_OBJ;
  if (vnode.shapeFlag & 32) {
    const type = children._;
    if (type) {
      if (isHmrUpdating) {
        assignSlots(slots, children, optimized);
        trigger(instance, "set", "$slots");
      } else if (optimized && type === 1) {
        needDeletionCheck = false;
      } else {
        assignSlots(slots, children, optimized);
      }
    } else {
      needDeletionCheck = !children.$stable;
      normalizeObjectSlots(children, slots);
    }
    deletionComparisonTarget = children;
  } else if (children) {
    normalizeVNodeSlots(instance, children);
    deletionComparisonTarget = { default: 1 };
  }
  if (needDeletionCheck) {
    for (const key in slots) {
      if (!isInternalKey(key) && deletionComparisonTarget[key] == null) {
        delete slots[key];
      }
    }
  }
};
let supported;
let perf;
function startMeasure(instance, type) {
  if (instance.appContext.config.performance && isSupported()) {
    perf.mark(`vue-${type}-${instance.uid}`);
  }
  if (true) {
    devtoolsPerfStart(instance, type, isSupported() ? perf.now() : Date.now());
  }
}
function endMeasure(instance, type) {
  if (instance.appContext.config.performance && isSupported()) {
    const startTag = `vue-${type}-${instance.uid}`;
    const endTag = startTag + `:end`;
    const measureName = `<${formatComponentName(instance, instance.type)}> ${type}`;
    perf.mark(endTag);
    perf.measure(measureName, startTag, endTag);
    perf.clearMeasures(measureName);
    perf.clearMarks(startTag);
    perf.clearMarks(endTag);
  }
  if (true) {
    devtoolsPerfEnd(instance, type, isSupported() ? perf.now() : Date.now());
  }
}
function isSupported() {
  if (supported !== void 0) {
    return supported;
  }
  if (typeof window !== "undefined" && window.performance) {
    supported = true;
    perf = window.performance;
  } else {
    supported = false;
  }
  return supported;
}
function initFeatureFlags() {
  const needWarn = [];
  if (typeof __VUE_OPTIONS_API__ !== "boolean") {
    needWarn.push(`__VUE_OPTIONS_API__`);
    getGlobalThis().__VUE_OPTIONS_API__ = true;
  }
  if (typeof __VUE_PROD_DEVTOOLS__ !== "boolean") {
    needWarn.push(`__VUE_PROD_DEVTOOLS__`);
    getGlobalThis().__VUE_PROD_DEVTOOLS__ = false;
  }
  if (typeof __VUE_PROD_HYDRATION_MISMATCH_DETAILS__ !== "boolean") {
    needWarn.push(`__VUE_PROD_HYDRATION_MISMATCH_DETAILS__`);
    getGlobalThis().__VUE_PROD_HYDRATION_MISMATCH_DETAILS__ = false;
  }
  if (needWarn.length) {
    const multi = needWarn.length > 1;
    console.warn(
      `Feature flag${multi ? `s` : ``} ${needWarn.join(", ")} ${multi ? `are` : `is`} not explicitly defined. You are running the esm-bundler build of Vue, which expects these compile-time feature flags to be globally injected via the bundler config in order to get better tree-shaking in the production bundle.

For more details, see https://link.vuejs.org/feature-flags.`
    );
  }
}
const queuePostRenderEffect = queueEffectWithSuspense;
function createRenderer(options) {
  return baseCreateRenderer(options);
}
function createHydrationRenderer(options) {
  return baseCreateRenderer(options, createHydrationFunctions);
}
function baseCreateRenderer(options, createHydrationFns) {
  {
    initFeatureFlags();
  }
  const target = getGlobalThis();
  target.__VUE__ = true;
  if (true) {
    setDevtoolsHook$1(target.__VUE_DEVTOOLS_GLOBAL_HOOK__, target);
  }
  const {
    insert: hostInsert,
    remove: hostRemove,
    patchProp: hostPatchProp,
    createElement: hostCreateElement,
    createText: hostCreateText,
    createComment: hostCreateComment,
    setText: hostSetText,
    setElementText: hostSetElementText,
    parentNode: hostParentNode,
    nextSibling: hostNextSibling,
    setScopeId: hostSetScopeId = NOOP,
    insertStaticContent: hostInsertStaticContent
  } = options;
  const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized = isHmrUpdating ? false : !!n2.dynamicChildren) => {
    if (n1 === n2) {
      return;
    }
    if (n1 && !isSameVNodeType(n1, n2)) {
      anchor = getNextHostNode(n1);
      unmount(n1, parentComponent, parentSuspense, true);
      n1 = null;
    }
    if (n2.patchFlag === -2) {
      optimized = false;
      n2.dynamicChildren = null;
    }
    const { type, ref: ref3, shapeFlag } = n2;
    switch (type) {
      case Text:
        processText(n1, n2, container, anchor);
        break;
      case Comment:
        processCommentNode(n1, n2, container, anchor);
        break;
      case Static:
        if (n1 == null) {
          mountStaticNode(n2, container, anchor, namespace);
        } else if (true) {
          patchStaticNode(n1, n2, container, namespace);
        }
        break;
      case Fragment:
        processFragment(
          n1,
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        break;
      default:
        if (shapeFlag & 1) {
          processElement(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (shapeFlag & 6) {
          processComponent(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (shapeFlag & 64) {
          type.process(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized,
            internals
          );
        } else if (shapeFlag & 128) {
          type.process(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized,
            internals
          );
        } else if (true) {
          warn$1("Invalid VNode type:", type, `(${typeof type})`);
        }
    }
    if (ref3 != null && parentComponent) {
      setRef(ref3, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
    } else if (ref3 == null && n1 && n1.ref != null) {
      setRef(n1.ref, null, parentSuspense, n1, true);
    }
  };
  const processText = (n1, n2, container, anchor) => {
    if (n1 == null) {
      hostInsert(
        n2.el = hostCreateText(n2.children),
        container,
        anchor
      );
    } else {
      const el = n2.el = n1.el;
      if (n2.children !== n1.children) {
        hostSetText(el, n2.children);
      }
    }
  };
  const processCommentNode = (n1, n2, container, anchor) => {
    if (n1 == null) {
      hostInsert(
        n2.el = hostCreateComment(n2.children || ""),
        container,
        anchor
      );
    } else {
      n2.el = n1.el;
    }
  };
  const mountStaticNode = (n2, container, anchor, namespace) => {
    [n2.el, n2.anchor] = hostInsertStaticContent(
      n2.children,
      container,
      anchor,
      namespace,
      n2.el,
      n2.anchor
    );
  };
  const patchStaticNode = (n1, n2, container, namespace) => {
    if (n2.children !== n1.children) {
      const anchor = hostNextSibling(n1.anchor);
      removeStaticNode(n1);
      [n2.el, n2.anchor] = hostInsertStaticContent(
        n2.children,
        container,
        anchor,
        namespace
      );
    } else {
      n2.el = n1.el;
      n2.anchor = n1.anchor;
    }
  };
  const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
    let next;
    while (el && el !== anchor) {
      next = hostNextSibling(el);
      hostInsert(el, container, nextSibling);
      el = next;
    }
    hostInsert(anchor, container, nextSibling);
  };
  const removeStaticNode = ({ el, anchor }) => {
    let next;
    while (el && el !== anchor) {
      next = hostNextSibling(el);
      hostRemove(el);
      el = next;
    }
    hostRemove(anchor);
  };
  const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    if (n2.type === "svg") {
      namespace = "svg";
    } else if (n2.type === "math") {
      namespace = "mathml";
    }
    if (n1 == null) {
      mountElement(
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    } else {
      const customElement = n1.el && n1.el._isVueCE ? n1.el : null;
      try {
        if (customElement) {
          customElement._beginPatch();
        }
        patchElement(
          n1,
          n2,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } finally {
        if (customElement) {
          customElement._endPatch();
        }
      }
    }
  };
  const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    let el;
    let vnodeHook;
    const { props, shapeFlag, transition, dirs } = vnode;
    el = vnode.el = hostCreateElement(
      vnode.type,
      namespace,
      props && props.is,
      props
    );
    if (shapeFlag & 8) {
      hostSetElementText(el, vnode.children);
    } else if (shapeFlag & 16) {
      mountChildren(
        vnode.children,
        el,
        null,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(vnode, namespace),
        slotScopeIds,
        optimized
      );
    }
    if (dirs) {
      invokeDirectiveHook(vnode, null, parentComponent, "created");
    }
    setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
    if (props) {
      for (const key in props) {
        if (key !== "value" && !isReservedProp(key)) {
          hostPatchProp(el, key, null, props[key], namespace, parentComponent);
        }
      }
      if ("value" in props) {
        hostPatchProp(el, "value", null, props.value, namespace);
      }
      if (vnodeHook = props.onVnodeBeforeMount) {
        invokeVNodeHook(vnodeHook, parentComponent, vnode);
      }
    }
    if (true) {
      def(el, "__vnode", vnode, true);
      def(el, "__vueParentComponent", parentComponent, true);
    }
    if (dirs) {
      invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
    }
    const needCallTransitionHooks = needTransition(parentSuspense, transition);
    if (needCallTransitionHooks) {
      transition.beforeEnter(el);
    }
    hostInsert(el, container, anchor);
    if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) {
      const isHmr = isHmrUpdating;
      queuePostRenderEffect(() => {
        let prev;
        if (true) prev = setHmrUpdating(isHmr);
        try {
          vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
          needCallTransitionHooks && transition.enter(el);
          dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
        } finally {
          if (true) setHmrUpdating(prev);
        }
      }, parentSuspense);
    }
  };
  const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
    if (scopeId) {
      hostSetScopeId(el, scopeId);
    }
    if (slotScopeIds) {
      for (let i = 0; i < slotScopeIds.length; i++) {
        hostSetScopeId(el, slotScopeIds[i]);
      }
    }
    if (parentComponent) {
      let subTree = parentComponent.subTree;
      if (subTree.patchFlag > 0 && subTree.patchFlag & 2048) {
        subTree = filterSingleRoot(subTree.children) || subTree;
      }
      if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
        const parentVNode = parentComponent.vnode;
        setScopeId(
          el,
          parentVNode,
          parentVNode.scopeId,
          parentVNode.slotScopeIds,
          parentComponent.parent
        );
      }
    }
  };
  const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
    for (let i = start; i < children.length; i++) {
      const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
      patch(
        null,
        child,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
  };
  const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    const el = n2.el = n1.el;
    if (true) {
      el.__vnode = n2;
    }
    let { patchFlag, dynamicChildren, dirs } = n2;
    patchFlag |= n1.patchFlag & 16;
    const oldProps = n1.props || EMPTY_OBJ;
    const newProps = n2.props || EMPTY_OBJ;
    let vnodeHook;
    parentComponent && toggleRecurse(parentComponent, false);
    if (vnodeHook = newProps.onVnodeBeforeUpdate) {
      invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
    }
    if (dirs) {
      invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
    }
    parentComponent && toggleRecurse(parentComponent, true);
    if (
      // HMR updated, force full diff
      isHmrUpdating || // #6385 the old vnode may be a user-wrapped non-isomorphic block
      // Force full diff when block metadata is unstable.
      dynamicChildren && (!n1.dynamicChildren || n1.dynamicChildren.length !== dynamicChildren.length)
    ) {
      patchFlag = 0;
      optimized = false;
      dynamicChildren = null;
    }
    if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) {
      hostSetElementText(el, "");
    }
    if (dynamicChildren) {
      patchBlockChildren(
        n1.dynamicChildren,
        dynamicChildren,
        el,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(n2, namespace),
        slotScopeIds
      );
      if (true) {
        traverseStaticChildren(n1, n2);
      }
    } else if (!optimized) {
      patchChildren(
        n1,
        n2,
        el,
        null,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(n2, namespace),
        slotScopeIds,
        false
      );
    }
    if (patchFlag > 0) {
      if (patchFlag & 16) {
        patchProps(el, oldProps, newProps, parentComponent, namespace);
      } else {
        if (patchFlag & 2) {
          if (oldProps.class !== newProps.class) {
            hostPatchProp(el, "class", null, newProps.class, namespace);
          }
        }
        if (patchFlag & 4) {
          hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
        }
        if (patchFlag & 8) {
          const propsToUpdate = n2.dynamicProps;
          for (let i = 0; i < propsToUpdate.length; i++) {
            const key = propsToUpdate[i];
            const prev = oldProps[key];
            const next = newProps[key];
            if (next !== prev || key === "value") {
              hostPatchProp(el, key, prev, next, namespace, parentComponent);
            }
          }
        }
      }
      if (patchFlag & 1) {
        if (n1.children !== n2.children) {
          hostSetElementText(el, n2.children);
        }
      }
    } else if (!optimized && dynamicChildren == null) {
      patchProps(el, oldProps, newProps, parentComponent, namespace);
    }
    if ((vnodeHook = newProps.onVnodeUpdated) || dirs) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
        dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
      }, parentSuspense);
    }
  };
  const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
    for (let i = 0; i < newChildren.length; i++) {
      const oldVNode = oldChildren[i];
      const newVNode = newChildren[i];
      const container = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        oldVNode.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (oldVNode.type === Fragment || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !isSameVNodeType(oldVNode, newVNode) || // - In the case of a component, it could contain anything.
        oldVNode.shapeFlag & (6 | 64 | 128)) ? hostParentNode(oldVNode.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          fallbackContainer
        )
      );
      patch(
        oldVNode,
        newVNode,
        container,
        null,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        true
      );
    }
  };
  const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
    if (oldProps !== newProps) {
      if (oldProps !== EMPTY_OBJ) {
        for (const key in oldProps) {
          if (!isReservedProp(key) && !(key in newProps)) {
            hostPatchProp(
              el,
              key,
              oldProps[key],
              null,
              namespace,
              parentComponent
            );
          }
        }
      }
      for (const key in newProps) {
        if (isReservedProp(key)) continue;
        const next = newProps[key];
        const prev = oldProps[key];
        if (next !== prev && key !== "value") {
          hostPatchProp(el, key, prev, next, namespace, parentComponent);
        }
      }
      if ("value" in newProps) {
        hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
      }
    }
  };
  const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
    const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
    let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
    if (
      // #5523 dev root fragment may inherit directives
      isHmrUpdating || patchFlag & 2048
    ) {
      patchFlag = 0;
      optimized = false;
      dynamicChildren = null;
    }
    if (fragmentSlotScopeIds) {
      slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
    }
    if (n1 == null) {
      hostInsert(fragmentStartAnchor, container, anchor);
      hostInsert(fragmentEndAnchor, container, anchor);
      mountChildren(
        // #10007
        // such fragment like `<></>` will be compiled into
        // a fragment which doesn't have a children.
        // In this case fallback to an empty array
        n2.children || [],
        container,
        fragmentEndAnchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    } else {
      if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && // #2715 the previous fragment could've been a BAILed one as a result
      // of renderSlot() with no valid children
      n1.dynamicChildren && n1.dynamicChildren.length === dynamicChildren.length) {
        patchBlockChildren(
          n1.dynamicChildren,
          dynamicChildren,
          container,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds
        );
        if (true) {
          traverseStaticChildren(n1, n2);
        } else if (
          // #2080 if the stable fragment has a key, it's a <template v-for> that may
          //  get moved around. Make sure all root level vnodes inherit el.
          // #2134 or if it's a component root, it may also get moved around
          // as the component is being moved.
          n2.key != null || parentComponent && n2 === parentComponent.subTree
        ) {
          traverseStaticChildren(
            n1,
            n2,
            true
            /* shallow */
          );
        }
      } else {
        patchChildren(
          n1,
          n2,
          container,
          fragmentEndAnchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
    }
  };
  const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    n2.slotScopeIds = slotScopeIds;
    if (n1 == null) {
      if (n2.shapeFlag & 512) {
        parentComponent.ctx.activate(
          n2,
          container,
          anchor,
          namespace,
          optimized
        );
      } else {
        mountComponent(
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          optimized
        );
      }
    } else {
      updateComponent(n1, n2, optimized);
    }
  };
  const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
    const instance = initialVNode.component = createComponentInstance(
      initialVNode,
      parentComponent,
      parentSuspense
    );
    if (instance.type.__hmrId) {
      registerHMR(instance);
    }
    if (true) {
      pushWarningContext(initialVNode);
      startMeasure(instance, `mount`);
    }
    if (isKeepAlive(initialVNode)) {
      instance.ctx.renderer = internals;
    }
    {
      if (true) {
        startMeasure(instance, `init`);
      }
      setupComponent(instance, false, optimized);
      if (true) {
        endMeasure(instance, `init`);
      }
    }
    if (isHmrUpdating) initialVNode.el = null;
    if (instance.asyncDep) {
      parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized);
      if (!initialVNode.el) {
        const placeholder = instance.subTree = createVNode(Comment);
        processCommentNode(null, placeholder, container, anchor);
        initialVNode.placeholder = placeholder.el;
      }
    } else {
      setupRenderEffect(
        instance,
        initialVNode,
        container,
        anchor,
        parentSuspense,
        namespace,
        optimized
      );
    }
    if (true) {
      popWarningContext();
      endMeasure(instance, `mount`);
    }
  };
  const updateComponent = (n1, n2, optimized) => {
    const instance = n2.component = n1.component;
    if (shouldUpdateComponent(n1, n2, optimized)) {
      if (instance.asyncDep && !instance.asyncResolved) {
        if (true) {
          pushWarningContext(n2);
        }
        updateComponentPreRender(instance, n2, optimized);
        if (true) {
          popWarningContext();
        }
        return;
      } else {
        instance.next = n2;
        instance.update();
      }
    } else {
      n2.el = n1.el;
      instance.vnode = n2;
    }
  };
  const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
    const componentUpdateFn = () => {
      if (!instance.isMounted) {
        let vnodeHook;
        const { el, props } = initialVNode;
        const { bm, m, parent, root, type } = instance;
        const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
        toggleRecurse(instance, false);
        if (bm) {
          invokeArrayFns(bm);
        }
        if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) {
          invokeVNodeHook(vnodeHook, parent, initialVNode);
        }
        toggleRecurse(instance, true);
        if (el && hydrateNode) {
          const hydrateSubTree = () => {
            if (true) {
              startMeasure(instance, `render`);
            }
            instance.subTree = renderComponentRoot(instance);
            if (true) {
              endMeasure(instance, `render`);
            }
            if (true) {
              startMeasure(instance, `hydrate`);
            }
            hydrateNode(
              el,
              instance.subTree,
              instance,
              parentSuspense,
              null
            );
            if (true) {
              endMeasure(instance, `hydrate`);
            }
          };
          if (isAsyncWrapperVNode && type.__asyncHydrate) {
            type.__asyncHydrate(
              el,
              instance,
              hydrateSubTree
            );
          } else {
            hydrateSubTree();
          }
        } else {
          if (root.ce && root.ce._hasShadowRoot()) {
            root.ce._injectChildStyle(
              type,
              instance.parent ? instance.parent.type : void 0
            );
          }
          if (true) {
            startMeasure(instance, `render`);
          }
          const subTree = instance.subTree = renderComponentRoot(instance);
          if (true) {
            endMeasure(instance, `render`);
          }
          if (true) {
            startMeasure(instance, `patch`);
          }
          patch(
            null,
            subTree,
            container,
            anchor,
            instance,
            parentSuspense,
            namespace
          );
          if (true) {
            endMeasure(instance, `patch`);
          }
          initialVNode.el = subTree.el;
        }
        if (m) {
          queuePostRenderEffect(m, parentSuspense);
        }
        if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
          const scopedInitialVNode = initialVNode;
          queuePostRenderEffect(
            () => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode),
            parentSuspense
          );
        }
        if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) {
          instance.a && queuePostRenderEffect(instance.a, parentSuspense);
        }
        instance.isMounted = true;
        if (true) {
          devtoolsComponentAdded(instance);
        }
        initialVNode = container = anchor = null;
      } else {
        let { next, bu, u, parent, vnode } = instance;
        {
          const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
          if (nonHydratedAsyncRoot) {
            if (next) {
              next.el = vnode.el;
              updateComponentPreRender(instance, next, optimized);
            }
            nonHydratedAsyncRoot.asyncDep.then(() => {
              queuePostRenderEffect(() => {
                if (!instance.isUnmounted) update();
              }, parentSuspense);
            });
            return;
          }
        }
        let originNext = next;
        let vnodeHook;
        if (true) {
          pushWarningContext(next || instance.vnode);
        }
        toggleRecurse(instance, false);
        if (next) {
          next.el = vnode.el;
          updateComponentPreRender(instance, next, optimized);
        } else {
          next = vnode;
        }
        if (bu) {
          invokeArrayFns(bu);
        }
        if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) {
          invokeVNodeHook(vnodeHook, parent, next, vnode);
        }
        toggleRecurse(instance, true);
        if (true) {
          startMeasure(instance, `render`);
        }
        const nextTree = renderComponentRoot(instance);
        if (true) {
          endMeasure(instance, `render`);
        }
        const prevTree = instance.subTree;
        instance.subTree = nextTree;
        if (true) {
          startMeasure(instance, `patch`);
        }
        patch(
          prevTree,
          nextTree,
          // parent may have changed if it's in a teleport
          hostParentNode(prevTree.el),
          // anchor may have changed if it's in a fragment
          getNextHostNode(prevTree),
          instance,
          parentSuspense,
          namespace
        );
        if (true) {
          endMeasure(instance, `patch`);
        }
        next.el = nextTree.el;
        if (originNext === null) {
          updateHOCHostEl(instance, nextTree.el);
        }
        if (u) {
          queuePostRenderEffect(u, parentSuspense);
        }
        if (vnodeHook = next.props && next.props.onVnodeUpdated) {
          queuePostRenderEffect(
            () => invokeVNodeHook(vnodeHook, parent, next, vnode),
            parentSuspense
          );
        }
        if (true) {
          devtoolsComponentUpdated(instance);
        }
        if (true) {
          popWarningContext();
        }
      }
    };
    instance.scope.on();
    const effect2 = instance.effect = new ReactiveEffect(componentUpdateFn);
    instance.scope.off();
    const update = instance.update = effect2.run.bind(effect2);
    const job = instance.job = effect2.runIfDirty.bind(effect2);
    job.i = instance;
    job.id = instance.uid;
    effect2.scheduler = () => queueJob(job);
    toggleRecurse(instance, true);
    if (true) {
      effect2.onTrack = instance.rtc ? (e) => invokeArrayFns(instance.rtc, e) : void 0;
      effect2.onTrigger = instance.rtg ? (e) => invokeArrayFns(instance.rtg, e) : void 0;
    }
    update();
  };
  const updateComponentPreRender = (instance, nextVNode, optimized) => {
    nextVNode.component = instance;
    const prevProps = instance.vnode.props;
    instance.vnode = nextVNode;
    instance.next = null;
    updateProps(instance, nextVNode.props, prevProps, optimized);
    updateSlots(instance, nextVNode.children, optimized);
    pauseTracking();
    flushPreFlushCbs(instance);
    resetTracking();
  };
  const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
    const c1 = n1 && n1.children;
    const prevShapeFlag = n1 ? n1.shapeFlag : 0;
    const c2 = n2.children;
    const { patchFlag, shapeFlag } = n2;
    if (patchFlag > 0) {
      if (patchFlag & 128) {
        patchKeyedChildren(
          c1,
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        return;
      } else if (patchFlag & 256) {
        patchUnkeyedChildren(
          c1,
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        return;
      }
    }
    if (shapeFlag & 8) {
      if (prevShapeFlag & 16) {
        unmountChildren(c1, parentComponent, parentSuspense);
      }
      if (c2 !== c1) {
        hostSetElementText(container, c2);
      }
    } else {
      if (prevShapeFlag & 16) {
        if (shapeFlag & 16) {
          patchKeyedChildren(
            c1,
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else {
          unmountChildren(c1, parentComponent, parentSuspense, true);
        }
      } else {
        if (prevShapeFlag & 8) {
          hostSetElementText(container, "");
        }
        if (shapeFlag & 16) {
          mountChildren(
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        }
      }
    }
  };
  const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    c1 = c1 || EMPTY_ARR;
    c2 = c2 || EMPTY_ARR;
    const oldLength = c1.length;
    const newLength = c2.length;
    const commonLength = Math.min(oldLength, newLength);
    let i;
    for (i = 0; i < commonLength; i++) {
      const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
      patch(
        c1[i],
        nextChild,
        container,
        null,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
    if (oldLength > newLength) {
      unmountChildren(
        c1,
        parentComponent,
        parentSuspense,
        true,
        false,
        commonLength
      );
    } else {
      mountChildren(
        c2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
        commonLength
      );
    }
  };
  const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    let i = 0;
    const l2 = c2.length;
    let e1 = c1.length - 1;
    let e2 = l2 - 1;
    while (i <= e1 && i <= e2) {
      const n1 = c1[i];
      const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
      if (isSameVNodeType(n1, n2)) {
        patch(
          n1,
          n2,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        break;
      }
      i++;
    }
    while (i <= e1 && i <= e2) {
      const n1 = c1[e1];
      const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
      if (isSameVNodeType(n1, n2)) {
        patch(
          n1,
          n2,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        break;
      }
      e1--;
      e2--;
    }
    if (i > e1) {
      if (i <= e2) {
        const nextPos = e2 + 1;
        const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
        while (i <= e2) {
          patch(
            null,
            c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]),
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          i++;
        }
      }
    } else if (i > e2) {
      while (i <= e1) {
        unmount(c1[i], parentComponent, parentSuspense, true);
        i++;
      }
    } else {
      const s1 = i;
      const s2 = i;
      const keyToNewIndexMap = /* @__PURE__ */ new Map();
      for (i = s2; i <= e2; i++) {
        const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
        if (nextChild.key != null) {
          if (keyToNewIndexMap.has(nextChild.key)) {
            warn$1(
              `Duplicate keys found during update:`,
              JSON.stringify(nextChild.key),
              `Make sure keys are unique.`
            );
          }
          keyToNewIndexMap.set(nextChild.key, i);
        }
      }
      let j;
      let patched = 0;
      const toBePatched = e2 - s2 + 1;
      let moved = false;
      let maxNewIndexSoFar = 0;
      const newIndexToOldIndexMap = new Array(toBePatched);
      for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
      for (i = s1; i <= e1; i++) {
        const prevChild = c1[i];
        if (patched >= toBePatched) {
          unmount(prevChild, parentComponent, parentSuspense, true);
          continue;
        }
        let newIndex;
        if (prevChild.key != null) {
          newIndex = keyToNewIndexMap.get(prevChild.key);
        } else {
          for (j = s2; j <= e2; j++) {
            if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
              newIndex = j;
              break;
            }
          }
        }
        if (newIndex === void 0) {
          unmount(prevChild, parentComponent, parentSuspense, true);
        } else {
          newIndexToOldIndexMap[newIndex - s2] = i + 1;
          if (newIndex >= maxNewIndexSoFar) {
            maxNewIndexSoFar = newIndex;
          } else {
            moved = true;
          }
          patch(
            prevChild,
            c2[newIndex],
            container,
            null,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          patched++;
        }
      }
      const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
      j = increasingNewIndexSequence.length - 1;
      for (i = toBePatched - 1; i >= 0; i--) {
        const nextIndex = s2 + i;
        const nextChild = c2[nextIndex];
        const anchorVNode = c2[nextIndex + 1];
        const anchor = nextIndex + 1 < l2 ? (
          // #13559, #14173 fallback to el placeholder for unresolved async component
          anchorVNode.el || resolveAsyncComponentPlaceholder(anchorVNode)
        ) : parentAnchor;
        if (newIndexToOldIndexMap[i] === 0) {
          patch(
            null,
            nextChild,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (moved) {
          if (j < 0 || i !== increasingNewIndexSequence[j]) {
            move(nextChild, container, anchor, 2);
          } else {
            j--;
          }
        }
      }
    }
  };
  const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
    const { el, type, transition, children, shapeFlag } = vnode;
    if (shapeFlag & 6) {
      move(vnode.component.subTree, container, anchor, moveType);
      return;
    }
    if (shapeFlag & 128) {
      vnode.suspense.move(container, anchor, moveType);
      return;
    }
    if (shapeFlag & 64) {
      type.move(vnode, container, anchor, internals);
      return;
    }
    if (type === Fragment) {
      hostInsert(el, container, anchor);
      for (let i = 0; i < children.length; i++) {
        move(children[i], container, anchor, moveType);
      }
      hostInsert(vnode.anchor, container, anchor);
      return;
    }
    if (type === Static) {
      moveStaticNode(vnode, container, anchor);
      return;
    }
    const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
    if (needTransition2) {
      if (moveType === 0) {
        if (transition.persisted && !el[leaveCbKey]) {
          hostInsert(el, container, anchor);
        } else {
          transition.beforeEnter(el);
          hostInsert(el, container, anchor);
          queuePostRenderEffect(() => transition.enter(el), parentSuspense);
        }
      } else {
        const { leave, delayLeave, afterLeave } = transition;
        const remove22 = () => {
          if (vnode.ctx.isUnmounted) {
            hostRemove(el);
          } else {
            hostInsert(el, container, anchor);
          }
        };
        const performLeave = () => {
          const wasLeaving = el._isLeaving || !!el[leaveCbKey];
          if (el._isLeaving) {
            el[leaveCbKey](
              true
              /* cancelled */
            );
          }
          if (transition.persisted && !wasLeaving) {
            remove22();
          } else {
            leave(el, () => {
              remove22();
              afterLeave && afterLeave();
            });
          }
        };
        if (delayLeave) {
          delayLeave(el, remove22, performLeave);
        } else {
          performLeave();
        }
      }
    } else {
      hostInsert(el, container, anchor);
    }
  };
  const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
    const {
      type,
      props,
      ref: ref3,
      children,
      dynamicChildren,
      shapeFlag,
      patchFlag,
      dirs,
      cacheIndex,
      memo
    } = vnode;
    if (patchFlag === -2) {
      optimized = false;
    }
    if (ref3 != null) {
      pauseTracking();
      setRef(ref3, null, parentSuspense, vnode, true);
      resetTracking();
    }
    if (cacheIndex != null) {
      parentComponent.renderCache[cacheIndex] = void 0;
    }
    if (shapeFlag & 256) {
      parentComponent.ctx.deactivate(vnode);
      return;
    }
    const shouldInvokeDirs = shapeFlag & 1 && dirs;
    const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
    let vnodeHook;
    if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) {
      invokeVNodeHook(vnodeHook, parentComponent, vnode);
    }
    if (shapeFlag & 6) {
      unmountComponent(vnode.component, parentSuspense, doRemove);
    } else {
      if (shapeFlag & 128) {
        vnode.suspense.unmount(parentSuspense, doRemove);
        return;
      }
      if (shouldInvokeDirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
      }
      if (shapeFlag & 64) {
        vnode.type.remove(
          vnode,
          parentComponent,
          parentSuspense,
          internals,
          doRemove
        );
      } else if (dynamicChildren && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !dynamicChildren.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (type !== Fragment || patchFlag > 0 && patchFlag & 64)) {
        unmountChildren(
          dynamicChildren,
          parentComponent,
          parentSuspense,
          false,
          true
        );
      } else if (type === Fragment && patchFlag & (128 | 256) || !optimized && shapeFlag & 16) {
        unmountChildren(children, parentComponent, parentSuspense);
      }
      if (doRemove) {
        remove2(vnode);
      }
    }
    const shouldInvalidateMemo = memo != null && cacheIndex == null;
    if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs || shouldInvalidateMemo) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
        shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
        if (shouldInvalidateMemo) {
          vnode.el = null;
        }
      }, parentSuspense);
    }
  };
  const remove2 = (vnode) => {
    const { type, el, anchor, transition } = vnode;
    if (type === Fragment) {
      if (vnode.patchFlag > 0 && vnode.patchFlag & 2048 && transition && !transition.persisted) {
        vnode.children.forEach((child) => {
          if (child.type === Comment) {
            hostRemove(child.el);
          } else {
            remove2(child);
          }
        });
      } else {
        removeFragment(el, anchor);
      }
      return;
    }
    if (type === Static) {
      removeStaticNode(vnode);
      return;
    }
    const performRemove = () => {
      hostRemove(el);
      if (transition && !transition.persisted && transition.afterLeave) {
        transition.afterLeave();
      }
    };
    if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
      const { leave, delayLeave } = transition;
      const performLeave = () => leave(el, performRemove);
      if (delayLeave) {
        delayLeave(vnode.el, performRemove, performLeave);
      } else {
        performLeave();
      }
    } else {
      performRemove();
    }
  };
  const removeFragment = (cur, end) => {
    let next;
    while (cur !== end) {
      next = hostNextSibling(cur);
      hostRemove(cur);
      cur = next;
    }
    hostRemove(end);
  };
  const unmountComponent = (instance, parentSuspense, doRemove) => {
    if (instance.type.__hmrId) {
      unregisterHMR(instance);
    }
    const { bum, scope, job, subTree, um, m, a } = instance;
    invalidateMount(m);
    invalidateMount(a);
    if (bum) {
      invokeArrayFns(bum);
    }
    scope.stop();
    if (job) {
      job.flags |= 8;
      unmount(subTree, instance, parentSuspense, doRemove);
    }
    if (um) {
      queuePostRenderEffect(um, parentSuspense);
    }
    queuePostRenderEffect(() => {
      instance.isUnmounted = true;
    }, parentSuspense);
    if (true) {
      devtoolsComponentRemoved(instance);
    }
  };
  const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
    for (let i = start; i < children.length; i++) {
      unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
    }
  };
  const getNextHostNode = (vnode) => {
    if (vnode.shapeFlag & 6) {
      return getNextHostNode(vnode.component.subTree);
    }
    if (vnode.shapeFlag & 128) {
      return vnode.suspense.next();
    }
    const el = hostNextSibling(vnode.anchor || vnode.el);
    const teleportEnd = el && el[TeleportEndKey];
    return teleportEnd ? hostNextSibling(teleportEnd) : el;
  };
  let isFlushing = false;
  const render = (vnode, container, namespace) => {
    let instance;
    if (vnode == null) {
      if (container._vnode) {
        unmount(container._vnode, null, null, true);
        instance = container._vnode.component;
      }
    } else {
      patch(
        container._vnode || null,
        vnode,
        container,
        null,
        null,
        null,
        namespace
      );
    }
    container._vnode = vnode;
    if (!isFlushing) {
      isFlushing = true;
      flushPreFlushCbs(instance);
      flushPostFlushCbs();
      isFlushing = false;
    }
  };
  const internals = {
    p: patch,
    um: unmount,
    m: move,
    r: remove2,
    mt: mountComponent,
    mc: mountChildren,
    pc: patchChildren,
    pbc: patchBlockChildren,
    n: getNextHostNode,
    o: options
  };
  let hydrate;
  let hydrateNode;
  if (createHydrationFns) {
    [hydrate, hydrateNode] = createHydrationFns(
      internals
    );
  }
  return {
    render,
    hydrate,
    createApp: createAppAPI(render, hydrate)
  };
}
function resolveChildrenNamespace({ type, props }, currentNamespace) {
  return currentNamespace === "svg" && type === "foreignObject" || currentNamespace === "mathml" && type === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
}
function toggleRecurse({ effect: effect2, job }, allowed) {
  if (allowed) {
    effect2.flags |= 32;
    job.flags |= 4;
  } else {
    effect2.flags &= -33;
    job.flags &= -5;
  }
}
function needTransition(parentSuspense, transition) {
  return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
}
function traverseStaticChildren(n1, n2, shallow = false) {
  const ch1 = n1.children;
  const ch2 = n2.children;
  if (isArray(ch1) && isArray(ch2)) {
    for (let i = 0; i < ch1.length; i++) {
      const c1 = ch1[i];
      let c2 = ch2[i];
      if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
        if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
          c2 = ch2[i] = cloneIfMounted(ch2[i]);
          c2.el = c1.el;
        }
        if (!shallow && c2.patchFlag !== -2)
          traverseStaticChildren(c1, c2);
      }
      if (c2.type === Text) {
        if (c2.patchFlag === -1) {
          c2 = ch2[i] = cloneIfMounted(c2);
        }
        c2.el = c1.el;
      }
      if (c2.type === Comment && !c2.el) {
        c2.el = c1.el;
      }
      if (true) {
        c2.el && (c2.el.__vnode = c2);
      }
    }
  }
}
function getSequence(arr) {
  const p = arr.slice();
  const result = [0];
  let i, j, u, v, c;
  const len = arr.length;
  for (i = 0; i < len; i++) {
    const arrI = arr[i];
    if (arrI !== 0) {
      j = result[result.length - 1];
      if (arr[j] < arrI) {
        p[i] = j;
        result.push(i);
        continue;
      }
      u = 0;
      v = result.length - 1;
      while (u < v) {
        c = u + v >> 1;
        if (arr[result[c]] < arrI) {
          u = c + 1;
        } else {
          v = c;
        }
      }
      if (arrI < arr[result[u]]) {
        if (u > 0) {
          p[i] = result[u - 1];
        }
        result[u] = i;
      }
    }
  }
  u = result.length;
  v = result[u - 1];
  while (u-- > 0) {
    result[u] = v;
    v = p[v];
  }
  return result;
}
function locateNonHydratedAsyncRoot(instance) {
  const subComponent = instance.subTree.component;
  if (subComponent) {
    if (subComponent.asyncDep && !subComponent.asyncResolved) {
      return subComponent;
    } else {
      return locateNonHydratedAsyncRoot(subComponent);
    }
  }
}
function invalidateMount(hooks) {
  if (hooks) {
    for (let i = 0; i < hooks.length; i++)
      hooks[i].flags |= 8;
  }
}
function resolveAsyncComponentPlaceholder(anchorVnode) {
  if (anchorVnode.placeholder) {
    return anchorVnode.placeholder;
  }
  const instance = anchorVnode.component;
  if (instance) {
    return resolveAsyncComponentPlaceholder(instance.subTree);
  }
  return null;
}
const isSuspense = (type) => type.__isSuspense;
let suspenseId = 0;
const SuspenseImpl = {
  name: "Suspense",
  // In order to make Suspense tree-shakable, we need to avoid importing it
  // directly in the renderer. The renderer checks for the __isSuspense flag
  // on a vnode's type and calls the `process` method, passing in renderer
  // internals.
  __isSuspense: true,
  process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
    if (n1 == null) {
      mountSuspense(
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
        rendererInternals
      );
    } else {
      if (parentSuspense && parentSuspense.deps > 0 && !n1.suspense.isInFallback) {
        n2.suspense = n1.suspense;
        n2.suspense.vnode = n2;
        n2.el = n1.el;
        return;
      }
      patchSuspense(
        n1,
        n2,
        container,
        anchor,
        parentComponent,
        namespace,
        slotScopeIds,
        optimized,
        rendererInternals
      );
    }
  },
  hydrate: hydrateSuspense,
  normalize: normalizeSuspenseChildren
};
const Suspense = SuspenseImpl;
function triggerEvent(vnode, name) {
  const eventListener = vnode.props && vnode.props[name];
  if (isFunction(eventListener)) {
    eventListener();
  }
}
function mountSuspense(vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
  const {
    p: patch,
    o: { createElement }
  } = rendererInternals;
  const hiddenContainer = createElement("div");
  const suspense = vnode.suspense = createSuspenseBoundary(
    vnode,
    parentSuspense,
    parentComponent,
    container,
    hiddenContainer,
    anchor,
    namespace,
    slotScopeIds,
    optimized,
    rendererInternals
  );
  patch(
    null,
    suspense.pendingBranch = vnode.ssContent,
    hiddenContainer,
    null,
    parentComponent,
    suspense,
    namespace,
    slotScopeIds
  );
  if (suspense.deps > 0) {
    triggerEvent(vnode, "onPending");
    triggerEvent(vnode, "onFallback");
    patch(
      null,
      vnode.ssFallback,
      container,
      anchor,
      parentComponent,
      null,
      // fallback tree will not have suspense context
      namespace,
      slotScopeIds
    );
    setActiveBranch(suspense, vnode.ssFallback);
  } else {
    suspense.resolve(false, true);
  }
}
function patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, { p: patch, um: unmount, o: { createElement } }) {
  const suspense = n2.suspense = n1.suspense;
  suspense.vnode = n2;
  n2.el = n1.el;
  const newBranch = n2.ssContent;
  const newFallback = n2.ssFallback;
  const { activeBranch, pendingBranch, isInFallback, isHydrating } = suspense;
  if (pendingBranch) {
    suspense.pendingBranch = newBranch;
    if (isSameVNodeType(pendingBranch, newBranch)) {
      patch(
        pendingBranch,
        newBranch,
        suspense.hiddenContainer,
        null,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      if (suspense.deps <= 0) {
        suspense.resolve();
      } else if (isInFallback) {
        if (!isHydrating) {
          patch(
            activeBranch,
            newFallback,
            container,
            anchor,
            parentComponent,
            null,
            // fallback tree will not have suspense context
            namespace,
            slotScopeIds,
            optimized
          );
          setActiveBranch(suspense, newFallback);
        }
      }
    } else {
      suspense.pendingId = suspenseId++;
      if (isHydrating) {
        suspense.isHydrating = false;
        suspense.activeBranch = pendingBranch;
      } else {
        unmount(pendingBranch, parentComponent, suspense);
      }
      suspense.deps = 0;
      suspense.effects.length = 0;
      suspense.hiddenContainer = createElement("div");
      if (isInFallback) {
        patch(
          null,
          newBranch,
          suspense.hiddenContainer,
          null,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        if (suspense.deps <= 0) {
          suspense.resolve();
        } else {
          patch(
            activeBranch,
            newFallback,
            container,
            anchor,
            parentComponent,
            null,
            // fallback tree will not have suspense context
            namespace,
            slotScopeIds,
            optimized
          );
          setActiveBranch(suspense, newFallback);
        }
      } else if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
        patch(
          activeBranch,
          newBranch,
          container,
          anchor,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        suspense.resolve(true);
      } else {
        patch(
          null,
          newBranch,
          suspense.hiddenContainer,
          null,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        if (suspense.deps <= 0) {
          suspense.resolve();
        }
      }
    }
  } else {
    if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
      patch(
        activeBranch,
        newBranch,
        container,
        anchor,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      setActiveBranch(suspense, newBranch);
    } else {
      triggerEvent(n2, "onPending");
      suspense.pendingBranch = newBranch;
      if (newBranch.shapeFlag & 512) {
        suspense.pendingId = newBranch.component.suspenseId;
      } else {
        suspense.pendingId = suspenseId++;
      }
      patch(
        null,
        newBranch,
        suspense.hiddenContainer,
        null,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      if (suspense.deps <= 0) {
        suspense.resolve();
      } else {
        const { timeout, pendingId } = suspense;
        if (timeout > 0) {
          setTimeout(() => {
            if (suspense.pendingId === pendingId) {
              suspense.fallback(newFallback);
            }
          }, timeout);
        } else if (timeout === 0) {
          suspense.fallback(newFallback);
        }
      }
    }
  }
}
let hasWarned = false;
function createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals, isHydrating = false) {
  if (!hasWarned) {
    hasWarned = true;
    console[console.info ? "info" : "log"](
      `<Suspense> is an experimental feature and its API will likely change.`
    );
  }
  const {
    p: patch,
    m: move,
    um: unmount,
    n: next,
    o: { parentNode, remove: remove2 }
  } = rendererInternals;
  let parentSuspenseId;
  const isSuspensible = isVNodeSuspensible(vnode);
  if (isSuspensible) {
    if (parentSuspense && parentSuspense.pendingBranch) {
      parentSuspenseId = parentSuspense.pendingId;
      parentSuspense.deps++;
    }
  }
  const timeout = vnode.props ? toNumber(vnode.props.timeout) : void 0;
  if (true) {
    assertNumber(timeout, `Suspense timeout`);
  }
  const initialAnchor = anchor;
  const suspense = {
    vnode,
    parent: parentSuspense,
    parentComponent,
    namespace,
    container,
    hiddenContainer,
    deps: 0,
    pendingId: suspenseId++,
    timeout: typeof timeout === "number" ? timeout : -1,
    activeBranch: null,
    isFallbackMountPending: false,
    pendingBranch: null,
    isInFallback: !isHydrating,
    isHydrating,
    isUnmounted: false,
    effects: [],
    resolve(resume = false, sync = false) {
      if (true) {
        if (!resume && !suspense.pendingBranch) {
          throw new Error(
            `suspense.resolve() is called without a pending branch.`
          );
        }
        if (suspense.isUnmounted) {
          throw new Error(
            `suspense.resolve() is called on an already unmounted suspense boundary.`
          );
        }
      }
      const {
        vnode: vnode2,
        activeBranch,
        pendingBranch,
        pendingId,
        effects,
        parentComponent: parentComponent2,
        container: container2,
        isInFallback
      } = suspense;
      let delayEnter = false;
      if (suspense.isHydrating) {
        suspense.isHydrating = false;
      } else if (!resume) {
        delayEnter = activeBranch && pendingBranch.transition && pendingBranch.transition.mode === "out-in";
        let hasUpdatedAnchor = false;
        if (delayEnter) {
          activeBranch.transition.afterLeave = () => {
            if (pendingId === suspense.pendingId) {
              move(
                pendingBranch,
                container2,
                anchor === initialAnchor && !hasUpdatedAnchor ? next(activeBranch) : anchor,
                0
              );
              queuePostFlushCb(effects);
              if (isInFallback && vnode2.ssFallback) {
                vnode2.ssFallback.el = null;
              }
            }
          };
        }
        if (activeBranch && !suspense.isFallbackMountPending) {
          if (parentNode(activeBranch.el) === container2) {
            anchor = next(activeBranch);
            hasUpdatedAnchor = true;
          }
          unmount(activeBranch, parentComponent2, suspense, true);
          if (!delayEnter && isInFallback && vnode2.ssFallback) {
            queuePostRenderEffect(() => vnode2.ssFallback.el = null, suspense);
          }
        }
        if (!delayEnter) {
          move(pendingBranch, container2, anchor, 0);
        }
      }
      suspense.isFallbackMountPending = false;
      setActiveBranch(suspense, pendingBranch);
      suspense.pendingBranch = null;
      suspense.isInFallback = false;
      let parent = suspense.parent;
      let hasUnresolvedAncestor = false;
      while (parent) {
        if (parent.pendingBranch) {
          for (let i = 0; i < effects.length; i++) {
            parent.effects.push(effects[i]);
          }
          hasUnresolvedAncestor = true;
          break;
        }
        parent = parent.parent;
      }
      if (!hasUnresolvedAncestor && !delayEnter) {
        queuePostFlushCb(effects);
      }
      suspense.effects = [];
      if (isSuspensible) {
        if (parentSuspense && parentSuspense.pendingBranch && parentSuspenseId === parentSuspense.pendingId) {
          parentSuspense.deps--;
          if (parentSuspense.deps === 0 && !sync) {
            parentSuspense.resolve();
          }
        }
      }
      triggerEvent(vnode2, "onResolve");
    },
    fallback(fallbackVNode) {
      if (!suspense.pendingBranch) {
        return;
      }
      const { vnode: vnode2, activeBranch, parentComponent: parentComponent2, container: container2, namespace: namespace2 } = suspense;
      triggerEvent(vnode2, "onFallback");
      const anchor2 = next(activeBranch);
      const mountFallback = () => {
        suspense.isFallbackMountPending = false;
        if (!suspense.isInFallback) {
          return;
        }
        patch(
          null,
          fallbackVNode,
          container2,
          anchor2,
          parentComponent2,
          null,
          // fallback tree will not have suspense context
          namespace2,
          slotScopeIds,
          optimized
        );
        setActiveBranch(suspense, fallbackVNode);
      };
      const delayEnter = fallbackVNode.transition && fallbackVNode.transition.mode === "out-in";
      if (delayEnter) {
        suspense.isFallbackMountPending = true;
        activeBranch.transition.afterLeave = mountFallback;
      }
      suspense.isInFallback = true;
      unmount(
        activeBranch,
        parentComponent2,
        null,
        // no suspense so unmount hooks fire now
        true
        // shouldRemove
      );
      if (!delayEnter) {
        mountFallback();
      }
    },
    move(container2, anchor2, type) {
      suspense.activeBranch && move(suspense.activeBranch, container2, anchor2, type);
      suspense.container = container2;
    },
    next() {
      return suspense.activeBranch && next(suspense.activeBranch);
    },
    registerDep(instance, setupRenderEffect, optimized2) {
      const isInPendingSuspense = !!suspense.pendingBranch;
      if (isInPendingSuspense) {
        suspense.deps++;
      }
      const hydratedEl = instance.vnode.el;
      instance.asyncDep.catch((err) => {
        handleError(err, instance, 0);
      }).then((asyncSetupResult) => {
        if (instance.isUnmounted || suspense.isUnmounted || suspense.pendingId !== instance.suspenseId) {
          return;
        }
        unsetCurrentInstance();
        instance.asyncResolved = true;
        const { vnode: vnode2 } = instance;
        if (true) {
          pushWarningContext(vnode2);
        }
        handleSetupResult(instance, asyncSetupResult, false);
        if (hydratedEl) {
          vnode2.el = hydratedEl;
        }
        const placeholder = !hydratedEl && instance.subTree.el;
        setupRenderEffect(
          instance,
          vnode2,
          // component may have been moved before resolve.
          // if this is not a hydration, instance.subTree will be the comment
          // placeholder.
          parentNode(hydratedEl || instance.subTree.el),
          // anchor will not be used if this is hydration, so only need to
          // consider the comment placeholder case.
          hydratedEl ? null : next(instance.subTree),
          suspense,
          namespace,
          optimized2
        );
        if (placeholder) {
          vnode2.placeholder = null;
          remove2(placeholder);
        }
        updateHOCHostEl(instance, vnode2.el);
        if (true) {
          popWarningContext();
        }
        if (isInPendingSuspense && --suspense.deps === 0) {
          suspense.resolve();
        }
      });
    },
    unmount(parentSuspense2, doRemove) {
      suspense.isUnmounted = true;
      if (suspense.activeBranch) {
        unmount(
          suspense.activeBranch,
          parentComponent,
          parentSuspense2,
          doRemove
        );
      }
      if (suspense.pendingBranch) {
        unmount(
          suspense.pendingBranch,
          parentComponent,
          parentSuspense2,
          doRemove
        );
      }
    }
  };
  return suspense;
}
function hydrateSuspense(node, vnode, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals, hydrateNode) {
  const suspense = vnode.suspense = createSuspenseBoundary(
    vnode,
    parentSuspense,
    parentComponent,
    node.parentNode,
    // eslint-disable-next-line no-restricted-globals
    document.createElement("div"),
    null,
    namespace,
    slotScopeIds,
    optimized,
    rendererInternals,
    true
  );
  const result = hydrateNode(
    node,
    suspense.pendingBranch = vnode.ssContent,
    parentComponent,
    suspense,
    slotScopeIds,
    optimized
  );
  if (suspense.deps === 0) {
    suspense.resolve(false, true);
  }
  return result;
}
function normalizeSuspenseChildren(vnode) {
  const { shapeFlag, children } = vnode;
  const isSlotChildren = shapeFlag & 32;
  vnode.ssContent = normalizeSuspenseSlot(
    isSlotChildren ? children.default : children
  );
  vnode.ssFallback = isSlotChildren ? normalizeSuspenseSlot(children.fallback) : createVNode(Comment);
}
function normalizeSuspenseSlot(s) {
  let block;
  if (isFunction(s)) {
    const trackBlock = isBlockTreeEnabled && s._c;
    if (trackBlock) {
      s._d = false;
      openBlock();
    }
    s = s();
    if (trackBlock) {
      s._d = true;
      block = currentBlock;
      closeBlock();
    }
  }
  if (isArray(s)) {
    const singleChild = filterSingleRoot(s);
    if (!singleChild && s.filter((child) => child !== NULL_DYNAMIC_COMPONENT).length > 0) {
      warn$1(`<Suspense> slots expect a single root node.`);
    }
    s = singleChild;
  }
  s = normalizeVNode(s);
  if (block && !s.dynamicChildren) {
    s.dynamicChildren = block.filter((c) => c !== s);
  }
  return s;
}
function queueEffectWithSuspense(fn, suspense) {
  if (suspense && suspense.pendingBranch) {
    if (isArray(fn)) {
      suspense.effects.push(...fn);
    } else {
      suspense.effects.push(fn);
    }
  } else {
    queuePostFlushCb(fn);
  }
}
function setActiveBranch(suspense, branch) {
  suspense.activeBranch = branch;
  const { vnode, parentComponent } = suspense;
  let el = branch.el;
  while (!el && branch.component) {
    branch = branch.component.subTree;
    el = branch.el;
  }
  vnode.el = el;
  if (parentComponent && parentComponent.subTree === vnode) {
    parentComponent.vnode.el = el;
    updateHOCHostEl(parentComponent, el);
  }
}
function isVNodeSuspensible(vnode) {
  const suspensible = vnode.props && vnode.props.suspensible;
  return suspensible != null && suspensible !== false;
}
const Fragment = /* @__PURE__ */ Symbol.for("v-fgt");
const Text = /* @__PURE__ */ Symbol.for("v-txt");
const Comment = /* @__PURE__ */ Symbol.for("v-cmt");
const Static = /* @__PURE__ */ Symbol.for("v-stc");
const blockStack = [];
let currentBlock = null;
function openBlock(disableTracking = false) {
  blockStack.push(currentBlock = disableTracking ? null : []);
}
function closeBlock() {
  blockStack.pop();
  currentBlock = blockStack[blockStack.length - 1] || null;
}
let isBlockTreeEnabled = 1;
function setBlockTracking(value, inVOnce = false) {
  isBlockTreeEnabled += value;
  if (value < 0 && currentBlock && inVOnce) {
    currentBlock.hasOnce = true;
  }
}
function setupBlock(vnode) {
  vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
  closeBlock();
  if (isBlockTreeEnabled > 0 && currentBlock) {
    currentBlock.push(vnode);
  }
  return vnode;
}
function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
  return setupBlock(
    createBaseVNode(
      type,
      props,
      children,
      patchFlag,
      dynamicProps,
      shapeFlag,
      true
    )
  );
}
function createBlock(type, props, children, patchFlag, dynamicProps) {
  return setupBlock(
    createVNode(
      type,
      props,
      children,
      patchFlag,
      dynamicProps,
      true
    )
  );
}
function isVNode(value) {
  return value ? value.__v_isVNode === true : false;
}
function isSameVNodeType(n1, n2) {
  if (n2.shapeFlag & 6 && n1.component) {
    const dirtyInstances = hmrDirtyComponents.get(n2.type);
    if (dirtyInstances && dirtyInstances.has(n1.component)) {
      n1.shapeFlag &= -257;
      n2.shapeFlag &= -513;
      return false;
    }
  }
  return n1.type === n2.type && n1.key === n2.key;
}
let vnodeArgsTransformer;
function transformVNodeArgs(transformer) {
  vnodeArgsTransformer = transformer;
}
const createVNodeWithArgsTransform = (...args) => {
  return _createVNode(
    ...vnodeArgsTransformer ? vnodeArgsTransformer(args, currentRenderingInstance) : args
  );
};
const normalizeKey = ({ key }) => key != null ? key : null;
const normalizeRef = ({
  ref: ref3,
  ref_key,
  ref_for
}) => {
  if (typeof ref3 === "number") {
    ref3 = "" + ref3;
  }
  return ref3 != null ? isString(ref3) || isRef(ref3) || isFunction(ref3) ? { i: currentRenderingInstance, r: ref3, k: ref_key, f: !!ref_for } : ref3 : null;
};
function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
  const vnode = {
    __v_isVNode: true,
    __v_skip: true,
    type,
    props,
    key: props && normalizeKey(props),
    ref: props && normalizeRef(props),
    scopeId: currentScopeId,
    slotScopeIds: null,
    children,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag,
    patchFlag,
    dynamicProps,
    dynamicChildren: null,
    appContext: null,
    ctx: currentRenderingInstance
  };
  if (needFullChildrenNormalization) {
    normalizeChildren(vnode, children);
    if (shapeFlag & 128) {
      type.normalize(vnode);
    }
  } else if (children) {
    vnode.shapeFlag |= isString(children) ? 8 : 16;
  }
  if (vnode.key !== vnode.key) {
    warn$1(`VNode created with invalid key (NaN). VNode type:`, vnode.type);
  }
  if (props && vnode.shapeFlag & 1) {
    const overwritingProp = props.innerHTML != null ? "innerHTML" : props.textContent != null ? "textContent" : null;
    if (overwritingProp && hasContentChildren(vnode.children)) {
      warn$1(
        `The \`${overwritingProp}\` prop on <${vnode.type}> will override its children. Remove either the \`${overwritingProp}\` prop or the children.`
      );
    }
  }
  if (isBlockTreeEnabled > 0 && // avoid a block node from tracking itself
  !isBlockNode && // has current parent block
  currentBlock && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (vnode.patchFlag > 0 || shapeFlag & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  vnode.patchFlag !== 32) {
    currentBlock.push(vnode);
  }
  return vnode;
}
function hasContentChildren(children) {
  if (isString(children)) return children !== "";
  if (isArray(children)) return children.length > 0;
  return false;
}
const createVNode = true ? createVNodeWithArgsTransform : _createVNode;
function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
  if (!type || type === NULL_DYNAMIC_COMPONENT) {
    if (!type) {
      warn$1(`Invalid vnode type when creating vnode: ${type}.`);
    }
    type = Comment;
  }
  if (isVNode(type)) {
    const cloned = cloneVNode(
      type,
      props,
      true
      /* mergeRef: true */
    );
    if (children) {
      normalizeChildren(cloned, children);
    }
    if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
      if (cloned.shapeFlag & 6) {
        currentBlock[currentBlock.indexOf(type)] = cloned;
      } else {
        currentBlock.push(cloned);
      }
    }
    cloned.patchFlag = -2;
    return cloned;
  }
  if (isClassComponent(type)) {
    type = type.__vccOpts;
  }
  if (props) {
    props = guardReactiveProps(props);
    let { class: klass, style } = props;
    if (klass && !isString(klass)) {
      props.class = normalizeClass(klass);
    }
    if (isObject(style)) {
      if (isProxy(style) && !isArray(style)) {
        style = extend({}, style);
      }
      props.style = normalizeStyle(style);
    }
  }
  const shapeFlag = isString(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : isObject(type) ? 4 : isFunction(type) ? 2 : 0;
  if (shapeFlag & 4 && isProxy(type)) {
    type = toRaw(type);
    warn$1(
      `Vue received a Component that was made a reactive object. This can lead to unnecessary performance overhead and should be avoided by marking the component with \`markRaw\` or using \`shallowRef\` instead of \`ref\`.`,
      `
Component that was made reactive: `,
      type
    );
  }
  return createBaseVNode(
    type,
    props,
    children,
    patchFlag,
    dynamicProps,
    shapeFlag,
    isBlockNode,
    true
  );
}
function guardReactiveProps(props) {
  if (!props) return null;
  return isProxy(props) || isInternalObject(props) ? extend({}, props) : props;
}
function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
  const { props, ref: ref3, patchFlag, children, transition } = vnode;
  const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
  const cloned = {
    __v_isVNode: true,
    __v_skip: true,
    type: vnode.type,
    props: mergedProps,
    key: mergedProps && normalizeKey(mergedProps),
    ref: extraProps && extraProps.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      mergeRef && ref3 ? isArray(ref3) ? ref3.concat(normalizeRef(extraProps)) : [ref3, normalizeRef(extraProps)] : normalizeRef(extraProps)
    ) : ref3,
    scopeId: vnode.scopeId,
    slotScopeIds: vnode.slotScopeIds,
    children: patchFlag === -1 && isArray(children) ? children.map(deepCloneVNode) : children,
    target: vnode.target,
    targetStart: vnode.targetStart,
    targetAnchor: vnode.targetAnchor,
    staticCount: vnode.staticCount,
    shapeFlag: vnode.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
    dynamicProps: vnode.dynamicProps,
    dynamicChildren: vnode.dynamicChildren,
    appContext: vnode.appContext,
    dirs: vnode.dirs,
    transition,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: vnode.component,
    suspense: vnode.suspense,
    ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
    ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
    placeholder: vnode.placeholder,
    el: vnode.el,
    anchor: vnode.anchor,
    ctx: vnode.ctx,
    ce: vnode.ce
  };
  if (transition && cloneTransition) {
    setTransitionHooks(
      cloned,
      transition.clone(cloned)
    );
  }
  return cloned;
}
function deepCloneVNode(vnode) {
  const cloned = cloneVNode(vnode);
  if (isArray(vnode.children)) {
    cloned.children = vnode.children.map(deepCloneVNode);
  }
  return cloned;
}
function createTextVNode(text = " ", flag = 0) {
  return createVNode(Text, null, text, flag);
}
function createStaticVNode(content, numberOfNodes) {
  const vnode = createVNode(Static, null, content);
  vnode.staticCount = numberOfNodes;
  return vnode;
}
function createCommentVNode(text = "", asBlock = false) {
  return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
}
function normalizeVNode(child) {
  if (child == null || typeof child === "boolean") {
    return createVNode(Comment);
  } else if (isArray(child)) {
    return createVNode(
      Fragment,
      null,
      // #3666, avoid reference pollution when reusing vnode
      child.slice()
    );
  } else if (isVNode(child)) {
    return cloneIfMounted(child);
  } else {
    return createVNode(Text, null, String(child));
  }
}
function cloneIfMounted(child) {
  return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
}
function normalizeChildren(vnode, children) {
  let type = 0;
  const { shapeFlag } = vnode;
  if (children == null) {
    children = null;
  } else if (isArray(children)) {
    type = 16;
  } else if (typeof children === "object") {
    if (shapeFlag & (1 | 64)) {
      const slot = children.default;
      if (slot) {
        slot._c && (slot._d = false);
        normalizeChildren(vnode, slot());
        slot._c && (slot._d = true);
      }
      return;
    } else {
      type = 32;
      const slotFlag = children._;
      if (!slotFlag && !isInternalObject(children)) {
        children._ctx = currentRenderingInstance;
      } else if (slotFlag === 3 && currentRenderingInstance) {
        if (currentRenderingInstance.slots._ === 1) {
          children._ = 1;
        } else {
          children._ = 2;
          vnode.patchFlag |= 1024;
        }
      }
    }
  } else if (isFunction(children)) {
    if (shapeFlag & (1 | 64)) {
      normalizeChildren(vnode, { default: children });
      return;
    }
    children = { default: children, _ctx: currentRenderingInstance };
    type = 32;
  } else {
    children = String(children);
    if (shapeFlag & 64) {
      type = 16;
      children = [createTextVNode(children)];
    } else {
      type = 8;
    }
  }
  vnode.children = children;
  vnode.shapeFlag |= type;
}
function mergeProps(...args) {
  const ret = {};
  for (let i = 0; i < args.length; i++) {
    const toMerge = args[i];
    for (const key in toMerge) {
      if (key === "class") {
        if (ret.class !== toMerge.class) {
          ret.class = normalizeClass([ret.class, toMerge.class]);
        }
      } else if (key === "style") {
        ret.style = normalizeStyle([ret.style, toMerge.style]);
      } else if (isOn(key)) {
        const existing = ret[key];
        const incoming = toMerge[key];
        if (incoming && existing !== incoming && !(isArray(existing) && existing.includes(incoming))) {
          ret[key] = existing ? [].concat(existing, incoming) : incoming;
        } else if (incoming == null && existing == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
        // the model listener.
        !isModelListener(key)) {
          ret[key] = incoming;
        }
      } else if (key !== "") {
        ret[key] = toMerge[key];
      }
    }
  }
  return ret;
}
function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
  callWithAsyncErrorHandling(hook, instance, 7, [
    vnode,
    prevVNode
  ]);
}
const emptyAppContext = createAppContext();
let uid = 0;
function createComponentInstance(vnode, parent, suspense) {
  const type = vnode.type;
  const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
  const instance = {
    uid: uid++,
    vnode,
    type,
    parent,
    appContext,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new EffectScope(
      true
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: parent ? parent.provides : Object.create(appContext.provides),
    ids: parent ? parent.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: normalizePropsOptions(type, appContext),
    emitsOptions: normalizeEmitsOptions(type, appContext),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: EMPTY_OBJ,
    // inheritAttrs
    inheritAttrs: type.inheritAttrs,
    // state
    ctx: EMPTY_OBJ,
    data: EMPTY_OBJ,
    props: EMPTY_OBJ,
    attrs: EMPTY_OBJ,
    slots: EMPTY_OBJ,
    refs: EMPTY_OBJ,
    setupState: EMPTY_OBJ,
    setupContext: null,
    // suspense related
    suspense,
    suspenseId: suspense ? suspense.pendingId : 0,
    asyncDep: null,
    asyncResolved: false,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: false,
    isUnmounted: false,
    isDeactivated: false,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  if (true) {
    instance.ctx = createDevRenderContext(instance);
  } else {
    instance.ctx = { _: instance };
  }
  instance.root = parent ? parent.root : instance;
  instance.emit = emit.bind(null, instance);
  if (vnode.ce) {
    vnode.ce(instance);
  }
  return instance;
}
let currentInstance = null;
const getCurrentInstance = () => currentInstance || currentRenderingInstance;
let internalSetCurrentInstance;
let setInSSRSetupState;
{
  const g = getGlobalThis();
  const registerGlobalSetter = (key, setter) => {
    let setters;
    if (!(setters = g[key])) setters = g[key] = [];
    setters.push(setter);
    return (v) => {
      if (setters.length > 1) setters.forEach((set) => set(v));
      else setters[0](v);
    };
  };
  internalSetCurrentInstance = registerGlobalSetter(
    `__VUE_INSTANCE_SETTERS__`,
    (v) => currentInstance = v
  );
  setInSSRSetupState = registerGlobalSetter(
    `__VUE_SSR_SETTERS__`,
    (v) => isInSSRComponentSetup = v
  );
}
const setCurrentInstance = (instance) => {
  const prev = currentInstance;
  internalSetCurrentInstance(instance);
  instance.scope.on();
  return () => {
    instance.scope.off();
    internalSetCurrentInstance(prev);
  };
};
const unsetCurrentInstance = () => {
  currentInstance && currentInstance.scope.off();
  internalSetCurrentInstance(null);
};
const isBuiltInTag = /* @__PURE__ */ makeMap("slot,component");
function validateComponentName(name, { isNativeTag }) {
  if (isBuiltInTag(name) || isNativeTag(name)) {
    warn$1(
      "Do not use built-in or reserved HTML elements as component id: " + name
    );
  }
}
function isStatefulComponent(instance) {
  return instance.vnode.shapeFlag & 4;
}
let isInSSRComponentSetup = false;
function setupComponent(instance, isSSR = false, optimized = false) {
  isSSR && setInSSRSetupState(isSSR);
  const { props, children } = instance.vnode;
  const isStateful = isStatefulComponent(instance);
  initProps(instance, props, isStateful, isSSR);
  initSlots(instance, children, optimized || isSSR);
  const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
  isSSR && setInSSRSetupState(false);
  return setupResult;
}
function setupStatefulComponent(instance, isSSR) {
  const Component = instance.type;
  if (true) {
    if (Component.name) {
      validateComponentName(Component.name, instance.appContext.config);
    }
    if (Component.components) {
      const names = Object.keys(Component.components);
      for (let i = 0; i < names.length; i++) {
        validateComponentName(names[i], instance.appContext.config);
      }
    }
    if (Component.directives) {
      const names = Object.keys(Component.directives);
      for (let i = 0; i < names.length; i++) {
        validateDirectiveName(names[i]);
      }
    }
    if (Component.compilerOptions && isRuntimeOnly()) {
      warn$1(
        `"compilerOptions" is only supported when using a build of Vue that includes the runtime compiler. Since you are using a runtime-only build, the options should be passed via your build tool config instead.`
      );
    }
  }
  instance.accessCache = /* @__PURE__ */ Object.create(null);
  instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
  if (true) {
    exposePropsOnRenderContext(instance);
  }
  const { setup } = Component;
  if (setup) {
    pauseTracking();
    const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
    const reset = setCurrentInstance(instance);
    const setupResult = callWithErrorHandling(
      setup,
      instance,
      0,
      [
        true ? shallowReadonly(instance.props) : instance.props,
        setupContext
      ]
    );
    const isAsyncSetup = isPromise(setupResult);
    resetTracking();
    reset();
    if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) {
      markAsyncBoundary(instance);
    }
    if (isAsyncSetup) {
      setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
      if (isSSR) {
        return setupResult.then((resolvedResult) => {
          setInSSRSetupState(true);
          try {
            handleSetupResult(instance, resolvedResult, isSSR);
          } finally {
            setInSSRSetupState(false);
          }
        }).catch((e) => {
          handleError(e, instance, 0);
        });
      } else {
        instance.asyncDep = setupResult;
        if (!instance.suspense) {
          const name = formatComponentName(instance, Component);
          warn$1(
            `Component <${name}>: setup function returned a promise, but no <Suspense> boundary was found in the parent component tree. A component with async setup() must be nested in a <Suspense> in order to be rendered.`
          );
        }
      }
    } else {
      handleSetupResult(instance, setupResult, isSSR);
    }
  } else {
    finishComponentSetup(instance, isSSR);
  }
}
function handleSetupResult(instance, setupResult, isSSR) {
  if (isFunction(setupResult)) {
    if (instance.type.__ssrInlineRender) {
      instance.ssrRender = setupResult;
    } else {
      instance.render = setupResult;
    }
  } else if (isObject(setupResult)) {
    if (isVNode(setupResult)) {
      warn$1(
        `setup() should not return VNodes directly - return a render function instead.`
      );
    }
    if (true) {
      instance.devtoolsRawSetupState = setupResult;
    }
    instance.setupState = proxyRefs(setupResult);
    if (true) {
      exposeSetupStateOnRenderContext(instance);
    }
  } else if (setupResult !== void 0) {
    warn$1(
      `setup() should return an object. Received: ${setupResult === null ? "null" : typeof setupResult}`
    );
  }
  finishComponentSetup(instance, isSSR);
}
let compile;
let installWithProxy;
function registerRuntimeCompiler(_compile) {
  compile = _compile;
  installWithProxy = (i) => {
    if (i.render._rc) {
      i.withProxy = new Proxy(i.ctx, RuntimeCompiledPublicInstanceProxyHandlers);
    }
  };
}
const isRuntimeOnly = () => !compile;
function finishComponentSetup(instance, isSSR, skipOptions) {
  const Component = instance.type;
  if (!instance.render) {
    if (!isSSR && compile && !Component.render) {
      const template = Component.template || __VUE_OPTIONS_API__ && resolveMergedOptions(instance).template;
      if (template) {
        if (true) {
          startMeasure(instance, `compile`);
        }
        const { isCustomElement, compilerOptions } = instance.appContext.config;
        const { delimiters, compilerOptions: componentCompilerOptions } = Component;
        const finalCompilerOptions = extend(
          extend(
            {
              isCustomElement,
              delimiters
            },
            compilerOptions
          ),
          componentCompilerOptions
        );
        Component.render = compile(template, finalCompilerOptions);
        if (true) {
          endMeasure(instance, `compile`);
        }
      }
    }
    instance.render = Component.render || NOOP;
    if (installWithProxy) {
      installWithProxy(instance);
    }
  }
  if (__VUE_OPTIONS_API__ && true) {
    const reset = setCurrentInstance(instance);
    pauseTracking();
    try {
      applyOptions(instance);
    } finally {
      resetTracking();
      reset();
    }
  }
  if (!Component.render && instance.render === NOOP && !isSSR) {
    if (!compile && Component.template) {
      warn$1(
        `Component provided template option but runtime compilation is not supported in this build of Vue. Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".`
      );
    } else {
      warn$1(`Component is missing template or render function: `, Component);
    }
  }
}
const attrsProxyHandlers = true ? {
  get(target, key) {
    markAttrsAccessed();
    track(target, "get", "");
    return target[key];
  },
  set() {
    warn$1(`setupContext.attrs is readonly.`);
    return false;
  },
  deleteProperty() {
    warn$1(`setupContext.attrs is readonly.`);
    return false;
  }
} : {
  get(target, key) {
    track(target, "get", "");
    return target[key];
  }
};
function getSlotsProxy(instance) {
  return new Proxy(instance.slots, {
    get(target, key) {
      track(instance, "get", "$slots");
      return target[key];
    }
  });
}
function createSetupContext(instance) {
  const expose = (exposed) => {
    if (true) {
      if (instance.exposed) {
        warn$1(`expose() should be called only once per setup().`);
      }
      if (exposed != null) {
        let exposedType = typeof exposed;
        if (exposedType === "object") {
          if (isArray(exposed)) {
            exposedType = "array";
          } else if (isRef(exposed)) {
            exposedType = "ref";
          }
        }
        if (exposedType !== "object") {
          warn$1(
            `expose() should be passed a plain object, received ${exposedType}.`
          );
        }
      }
    }
    instance.exposed = exposed || {};
  };
  if (true) {
    let attrsProxy;
    let slotsProxy;
    return Object.freeze({
      get attrs() {
        return attrsProxy || (attrsProxy = new Proxy(instance.attrs, attrsProxyHandlers));
      },
      get slots() {
        return slotsProxy || (slotsProxy = getSlotsProxy(instance));
      },
      get emit() {
        return (event, ...args) => instance.emit(event, ...args);
      },
      expose
    });
  } else {
    return {
      attrs: new Proxy(instance.attrs, attrsProxyHandlers),
      slots: instance.slots,
      emit: instance.emit,
      expose
    };
  }
}
function getComponentPublicInstance(instance) {
  if (instance.exposed) {
    return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
      get(target, key) {
        if (key in target) {
          return target[key];
        } else if (key in publicPropertiesMap) {
          return publicPropertiesMap[key](instance);
        }
      },
      has(target, key) {
        return key in target || key in publicPropertiesMap;
      }
    }));
  } else {
    return instance.proxy;
  }
}
const classifyRE = /(?:^|[-_])\w/g;
const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
function getComponentName(Component, includeInferred = true) {
  return isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
}
function formatComponentName(instance, Component, isRoot = false) {
  let name = getComponentName(Component);
  if (!name && Component.__file) {
    const match = Component.__file.match(/([^/\\]+)\.\w+$/);
    if (match) {
      name = match[1];
    }
  }
  if (!name && instance) {
    const inferFromRegistry = (registry) => {
      for (const key in registry) {
        if (registry[key] === Component) {
          return key;
        }
      }
    };
    name = inferFromRegistry(instance.components) || instance.parent && inferFromRegistry(
      instance.parent.type.components
    ) || inferFromRegistry(instance.appContext.components);
  }
  return name ? classify(name) : isRoot ? `App` : `Anonymous`;
}
function isClassComponent(value) {
  return isFunction(value) && "__vccOpts" in value;
}
const computed = (getterOrOptions, debugOptions) => {
  const c = computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
  if (true) {
    const i = getCurrentInstance();
    if (i && i.appContext.config.warnRecursiveComputed) {
      c._warnRecursive = true;
    }
  }
  return c;
};
function h(type, propsOrChildren, children) {
  try {
    setBlockTracking(-1);
    const l = arguments.length;
    if (l === 2) {
      if (isObject(propsOrChildren) && !isArray(propsOrChildren)) {
        if (isVNode(propsOrChildren)) {
          return createVNode(type, null, [propsOrChildren]);
        }
        return createVNode(type, propsOrChildren);
      } else {
        return createVNode(type, null, propsOrChildren);
      }
    } else {
      if (l > 3) {
        children = Array.prototype.slice.call(arguments, 2);
      } else if (l === 3 && isVNode(children)) {
        children = [children];
      }
      return createVNode(type, propsOrChildren, children);
    }
  } finally {
    setBlockTracking(1);
  }
}
function initCustomFormatter() {
  if (typeof window === "undefined") {
    return;
  }
  const vueStyle = { style: "color:#3ba776" };
  const numberStyle = { style: "color:#1677ff" };
  const stringStyle = { style: "color:#f5222d" };
  const keywordStyle = { style: "color:#eb2f96" };
  const formatter = {
    __vue_custom_formatter: true,
    header(obj) {
      if (!isObject(obj)) {
        return null;
      }
      if (obj.__isVue) {
        return ["div", vueStyle, `VueInstance`];
      } else if (isRef(obj)) {
        pauseTracking();
        const value = obj.value;
        resetTracking();
        return [
          "div",
          {},
          ["span", vueStyle, genRefFlag(obj)],
          "<",
          formatValue(value),
          `>`
        ];
      } else if (isReactive(obj)) {
        return [
          "div",
          {},
          ["span", vueStyle, isShallow(obj) ? "ShallowReactive" : "Reactive"],
          "<",
          formatValue(obj),
          `>${isReadonly(obj) ? ` (readonly)` : ``}`
        ];
      } else if (isReadonly(obj)) {
        return [
          "div",
          {},
          ["span", vueStyle, isShallow(obj) ? "ShallowReadonly" : "Readonly"],
          "<",
          formatValue(obj),
          ">"
        ];
      }
      return null;
    },
    hasBody(obj) {
      return obj && obj.__isVue;
    },
    body(obj) {
      if (obj && obj.__isVue) {
        return [
          "div",
          {},
          ...formatInstance(obj.$)
        ];
      }
    }
  };
  function formatInstance(instance) {
    const blocks = [];
    if (instance.type.props && instance.props) {
      blocks.push(createInstanceBlock("props", toRaw(instance.props)));
    }
    if (instance.setupState !== EMPTY_OBJ) {
      blocks.push(createInstanceBlock("setup", instance.setupState));
    }
    if (instance.data !== EMPTY_OBJ) {
      blocks.push(createInstanceBlock("data", toRaw(instance.data)));
    }
    const computed2 = extractKeys(instance, "computed");
    if (computed2) {
      blocks.push(createInstanceBlock("computed", computed2));
    }
    const injected = extractKeys(instance, "inject");
    if (injected) {
      blocks.push(createInstanceBlock("injected", injected));
    }
    blocks.push([
      "div",
      {},
      [
        "span",
        {
          style: keywordStyle.style + ";opacity:0.66"
        },
        "$ (internal): "
      ],
      ["object", { object: instance }]
    ]);
    return blocks;
  }
  function createInstanceBlock(type, target) {
    target = extend({}, target);
    if (!Object.keys(target).length) {
      return ["span", {}];
    }
    return [
      "div",
      { style: "line-height:1.25em;margin-bottom:0.6em" },
      [
        "div",
        {
          style: "color:#476582"
        },
        type
      ],
      [
        "div",
        {
          style: "padding-left:1.25em"
        },
        ...Object.keys(target).map((key) => {
          return [
            "div",
            {},
            ["span", keywordStyle, key + ": "],
            formatValue(target[key], false)
          ];
        })
      ]
    ];
  }
  function formatValue(v, asRaw = true) {
    if (typeof v === "number") {
      return ["span", numberStyle, v];
    } else if (typeof v === "string") {
      return ["span", stringStyle, JSON.stringify(v)];
    } else if (typeof v === "boolean") {
      return ["span", keywordStyle, v];
    } else if (isObject(v)) {
      return ["object", { object: asRaw ? toRaw(v) : v }];
    } else {
      return ["span", stringStyle, String(v)];
    }
  }
  function extractKeys(instance, type) {
    const Comp = instance.type;
    if (isFunction(Comp)) {
      return;
    }
    const extracted = {};
    for (const key in instance.ctx) {
      if (isKeyOfType(Comp, key, type)) {
        extracted[key] = instance.ctx[key];
      }
    }
    return extracted;
  }
  function isKeyOfType(Comp, key, type) {
    const opts = Comp[type];
    if (isArray(opts) && opts.includes(key) || isObject(opts) && key in opts) {
      return true;
    }
    if (Comp.extends && isKeyOfType(Comp.extends, key, type)) {
      return true;
    }
    if (Comp.mixins && Comp.mixins.some((m) => isKeyOfType(m, key, type))) {
      return true;
    }
  }
  function genRefFlag(v) {
    if (isShallow(v)) {
      return `ShallowRef`;
    }
    if (v.effect) {
      return `ComputedRef`;
    }
    return `Ref`;
  }
  if (window.devtoolsFormatters) {
    window.devtoolsFormatters.push(formatter);
  } else {
    window.devtoolsFormatters = [formatter];
  }
}
function withMemo(memo, render, cache, index) {
  const cached = cache[index];
  if (cached && isMemoSame(cached, memo)) {
    return cached;
  }
  const ret = render();
  ret.memo = memo.slice();
  ret.cacheIndex = index;
  return cache[index] = ret;
}
function isMemoSame(cached, memo) {
  const prev = cached.memo;
  if (prev.length != memo.length) {
    return false;
  }
  for (let i = 0; i < prev.length; i++) {
    if (hasChanged(prev[i], memo[i])) {
      return false;
    }
  }
  if (isBlockTreeEnabled > 0 && currentBlock) {
    currentBlock.push(cached);
  }
  return true;
}
const version = "3.5.41";
const warn = true ? warn$1 : NOOP;
const ErrorTypeStrings = ErrorTypeStrings$1;
const devtools = true ? devtools$1 : void 0;
const setDevtoolsHook = true ? setDevtoolsHook$1 : NOOP;
const _ssrUtils = {
  createComponentInstance,
  setupComponent,
  renderComponentRoot,
  setCurrentRenderingInstance,
  isVNode,
  normalizeVNode,
  getComponentPublicInstance,
  ensureValidVNode,
  pushWarningContext,
  popWarningContext
};
const ssrUtils = _ssrUtils;
const resolveFilter = null;
const compatUtils = null;
const DeprecationTypes = null;
export { BaseTransition, BaseTransitionPropsValidators, Comment, DeprecationTypes, ErrorCodes, ErrorTypeStrings, Fragment, KeepAlive, Static, Suspense, Teleport, Text, assertNumber, callWithAsyncErrorHandling, callWithErrorHandling, cloneVNode, compatUtils, computed, createBlock, createCommentVNode, createElementBlock, createBaseVNode as createElementVNode, createHydrationRenderer, createPropsRestProxy, createRenderer, createSlots, createStaticVNode, createTextVNode, createVNode, defineAsyncComponent, defineComponent, defineEmits, defineExpose, defineModel, defineOptions, defineProps, defineSlots, devtools, getCurrentInstance, getTransitionRawChildren, guardReactiveProps, h, handleError, hasInjectionContext, hydrateOnIdle, hydrateOnInteraction, hydrateOnMediaQuery, hydrateOnVisible, initCustomFormatter, inject, isMemoSame, isRuntimeOnly, isVNode, mergeDefaults, mergeModels, mergeProps, nextTick, onActivated, onBeforeMount, onBeforeUnmount, onBeforeUpdate, onDeactivated, onErrorCaptured, onMounted, onRenderTracked, onRenderTriggered, onServerPrefetch, onUnmounted, onUpdated, openBlock, popScopeId, provide, pushScopeId, queuePostFlushCb, registerRuntimeCompiler, renderList, renderSlot, resolveComponent, resolveDirective, resolveDynamicComponent, resolveFilter, resolveTransitionHooks, setBlockTracking, setDevtoolsHook, setTransitionHooks, ssrContextKey, ssrUtils, toHandlers, transformVNodeArgs, useAttrs, useId, useModel, useSSRContext, useSlots, useTemplateRef, useTransitionState, version, warn, watch, watchEffect, watchPostEffect, watchSyncEffect, withAsyncContext, withCtx, withDefaults, withDirectives, withMemo, withScopeId };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJ1bnRpbWUtY29yZS5lc20tYnVuZGxlci5qcz92PTU4MzA3OGZmIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuKiBAdnVlL3J1bnRpbWUtY29yZSB2My41LjQxXG4qIChjKSAyMDE4LXByZXNlbnQgWXV4aSAoRXZhbikgWW91IGFuZCBWdWUgY29udHJpYnV0b3JzXG4qIEBsaWNlbnNlIE1JVFxuKiovXG5pbXBvcnQgeyBwYXVzZVRyYWNraW5nLCByZXNldFRyYWNraW5nLCBpc1JlZiwgdG9SYXcsIHRyYXZlcnNlLCB3YXRjaCBhcyB3YXRjaCQxLCBzaGFsbG93UmVmLCByZWFkb25seSwgaXNSZWFjdGl2ZSwgcmVmLCBpc1NoYWxsb3csIGlzUmVhZG9ubHksIHNoYWxsb3dSZWFkQXJyYXksIHRvUmVhZG9ubHksIHRvUmVhY3RpdmUsIHNoYWxsb3dSZWFkb25seSwgdHJhY2ssIHJlYWN0aXZlLCBjdXN0b21SZWYsIHNoYWxsb3dSZWFjdGl2ZSwgdHJpZ2dlciwgUmVhY3RpdmVFZmZlY3QsIGlzUHJveHksIHByb3h5UmVmcywgbWFya1JhdywgRWZmZWN0U2NvcGUsIGNvbXB1dGVkIGFzIGNvbXB1dGVkJDEgfSBmcm9tICdAdnVlL3JlYWN0aXZpdHknO1xuZXhwb3J0IHsgRWZmZWN0U2NvcGUsIFJlYWN0aXZlRWZmZWN0LCBUcmFja09wVHlwZXMsIFRyaWdnZXJPcFR5cGVzLCBjdXN0b21SZWYsIGVmZmVjdCwgZWZmZWN0U2NvcGUsIGdldEN1cnJlbnRTY29wZSwgZ2V0Q3VycmVudFdhdGNoZXIsIGlzUHJveHksIGlzUmVhY3RpdmUsIGlzUmVhZG9ubHksIGlzUmVmLCBpc1NoYWxsb3csIG1hcmtSYXcsIG9uU2NvcGVEaXNwb3NlLCBvbldhdGNoZXJDbGVhbnVwLCBwcm94eVJlZnMsIHJlYWN0aXZlLCByZWFkb25seSwgcmVmLCBzaGFsbG93UmVhY3RpdmUsIHNoYWxsb3dSZWFkb25seSwgc2hhbGxvd1JlZiwgc3RvcCwgdG9SYXcsIHRvUmVmLCB0b1JlZnMsIHRvVmFsdWUsIHRyaWdnZXJSZWYsIHVucmVmIH0gZnJvbSAnQHZ1ZS9yZWFjdGl2aXR5JztcbmltcG9ydCB7IGlzU3RyaW5nLCBpc0Z1bmN0aW9uLCBFTVBUWV9PQkosIGlzUHJvbWlzZSwgaXNBcnJheSwgTk9PUCwgZ2V0R2xvYmFsVGhpcywgZXh0ZW5kLCBpc0J1aWx0SW5EaXJlY3RpdmUsIE5PLCBoYXNPd24sIHJlbW92ZSwgZGVmLCBpc09uLCBpc1Jlc2VydmVkUHJvcCwgbm9ybWFsaXplQ2xhc3MsIHN0cmluZ2lmeVN0eWxlLCBub3JtYWxpemVTdHlsZSwgaXNLbm93blN2Z0F0dHIsIGlzQm9vbGVhbkF0dHIsIGlzS25vd25IdG1sQXR0ciwgaW5jbHVkZUJvb2xlYW5BdHRyLCBpc1JlbmRlcmFibGVBdHRyVmFsdWUsIG5vcm1hbGl6ZUNzc1ZhclZhbHVlLCBnZXRFc2NhcGVkQ3NzVmFyTmFtZSwgaXNPYmplY3QsIGlzUmVnRXhwLCBpbnZva2VBcnJheUZucywgdG9IYW5kbGVyS2V5LCBjYW1lbGl6ZSwgY2FwaXRhbGl6ZSwgaXNTeW1ib2wsIGlzR2xvYmFsbHlBbGxvd2VkLCBoeXBoZW5hdGUsIGhhc0NoYW5nZWQsIGxvb3NlVG9OdW1iZXIsIGlzTW9kZWxMaXN0ZW5lciwgbG9vc2VFcXVhbCwgRU1QVFlfQVJSLCB0b1Jhd1R5cGUsIG1ha2VNYXAsIHRvTnVtYmVyIH0gZnJvbSAnQHZ1ZS9zaGFyZWQnO1xuZXhwb3J0IHsgY2FtZWxpemUsIGNhcGl0YWxpemUsIG5vcm1hbGl6ZUNsYXNzLCBub3JtYWxpemVQcm9wcywgbm9ybWFsaXplU3R5bGUsIHRvRGlzcGxheVN0cmluZywgdG9IYW5kbGVyS2V5IH0gZnJvbSAnQHZ1ZS9zaGFyZWQnO1xuXG5jb25zdCBzdGFjayA9IFtdO1xuZnVuY3Rpb24gcHVzaFdhcm5pbmdDb250ZXh0KHZub2RlKSB7XG4gIHN0YWNrLnB1c2godm5vZGUpO1xufVxuZnVuY3Rpb24gcG9wV2FybmluZ0NvbnRleHQoKSB7XG4gIHN0YWNrLnBvcCgpO1xufVxubGV0IGlzV2FybmluZyA9IGZhbHNlO1xuZnVuY3Rpb24gd2FybiQxKG1zZywgLi4uYXJncykge1xuICBpZiAoaXNXYXJuaW5nKSByZXR1cm47XG4gIGlzV2FybmluZyA9IHRydWU7XG4gIHBhdXNlVHJhY2tpbmcoKTtcbiAgY29uc3QgaW5zdGFuY2UgPSBzdGFjay5sZW5ndGggPyBzdGFja1tzdGFjay5sZW5ndGggLSAxXS5jb21wb25lbnQgOiBudWxsO1xuICBjb25zdCBhcHBXYXJuSGFuZGxlciA9IGluc3RhbmNlICYmIGluc3RhbmNlLmFwcENvbnRleHQuY29uZmlnLndhcm5IYW5kbGVyO1xuICBjb25zdCB0cmFjZSA9IGdldENvbXBvbmVudFRyYWNlKCk7XG4gIGlmIChhcHBXYXJuSGFuZGxlcikge1xuICAgIGNhbGxXaXRoRXJyb3JIYW5kbGluZyhcbiAgICAgIGFwcFdhcm5IYW5kbGVyLFxuICAgICAgaW5zdGFuY2UsXG4gICAgICAxMSxcbiAgICAgIFtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtc3ludGF4XG4gICAgICAgIG1zZyArIGFyZ3MubWFwKChhKSA9PiB7XG4gICAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgICByZXR1cm4gKF9iID0gKF9hID0gYS50b1N0cmluZykgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmNhbGwoYSkpICE9IG51bGwgPyBfYiA6IEpTT04uc3RyaW5naWZ5KGEpO1xuICAgICAgICB9KS5qb2luKFwiXCIpLFxuICAgICAgICBpbnN0YW5jZSAmJiBpbnN0YW5jZS5wcm94eSxcbiAgICAgICAgdHJhY2UubWFwKFxuICAgICAgICAgICh7IHZub2RlIH0pID0+IGBhdCA8JHtmb3JtYXRDb21wb25lbnROYW1lKGluc3RhbmNlLCB2bm9kZS50eXBlKX0+YFxuICAgICAgICApLmpvaW4oXCJcXG5cIiksXG4gICAgICAgIHRyYWNlXG4gICAgICBdXG4gICAgKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB3YXJuQXJncyA9IFtgW1Z1ZSB3YXJuXTogJHttc2d9YCwgLi4uYXJnc107XG4gICAgaWYgKHRyYWNlLmxlbmd0aCAmJiAvLyBhdm9pZCBzcGFtbWluZyBjb25zb2xlIGR1cmluZyB0ZXN0c1xuICAgIHRydWUpIHtcbiAgICAgIHdhcm5BcmdzLnB1c2goYFxuYCwgLi4uZm9ybWF0VHJhY2UodHJhY2UpKTtcbiAgICB9XG4gICAgY29uc29sZS53YXJuKC4uLndhcm5BcmdzKTtcbiAgfVxuICByZXNldFRyYWNraW5nKCk7XG4gIGlzV2FybmluZyA9IGZhbHNlO1xufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50VHJhY2UoKSB7XG4gIGxldCBjdXJyZW50Vk5vZGUgPSBzdGFja1tzdGFjay5sZW5ndGggLSAxXTtcbiAgaWYgKCFjdXJyZW50Vk5vZGUpIHtcbiAgICByZXR1cm4gW107XG4gIH1cbiAgY29uc3Qgbm9ybWFsaXplZFN0YWNrID0gW107XG4gIHdoaWxlIChjdXJyZW50Vk5vZGUpIHtcbiAgICBjb25zdCBsYXN0ID0gbm9ybWFsaXplZFN0YWNrWzBdO1xuICAgIGlmIChsYXN0ICYmIGxhc3Qudm5vZGUgPT09IGN1cnJlbnRWTm9kZSkge1xuICAgICAgbGFzdC5yZWN1cnNlQ291bnQrKztcbiAgICB9IGVsc2Uge1xuICAgICAgbm9ybWFsaXplZFN0YWNrLnB1c2goe1xuICAgICAgICB2bm9kZTogY3VycmVudFZOb2RlLFxuICAgICAgICByZWN1cnNlQ291bnQ6IDBcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBwYXJlbnRJbnN0YW5jZSA9IGN1cnJlbnRWTm9kZS5jb21wb25lbnQgJiYgY3VycmVudFZOb2RlLmNvbXBvbmVudC5wYXJlbnQ7XG4gICAgY3VycmVudFZOb2RlID0gcGFyZW50SW5zdGFuY2UgJiYgcGFyZW50SW5zdGFuY2Uudm5vZGU7XG4gIH1cbiAgcmV0dXJuIG5vcm1hbGl6ZWRTdGFjaztcbn1cbmZ1bmN0aW9uIGZvcm1hdFRyYWNlKHRyYWNlKSB7XG4gIGNvbnN0IGxvZ3MgPSBbXTtcbiAgdHJhY2UuZm9yRWFjaCgoZW50cnksIGkpID0+IHtcbiAgICBsb2dzLnB1c2goLi4uaSA9PT0gMCA/IFtdIDogW2BcbmBdLCAuLi5mb3JtYXRUcmFjZUVudHJ5KGVudHJ5KSk7XG4gIH0pO1xuICByZXR1cm4gbG9ncztcbn1cbmZ1bmN0aW9uIGZvcm1hdFRyYWNlRW50cnkoeyB2bm9kZSwgcmVjdXJzZUNvdW50IH0pIHtcbiAgY29uc3QgcG9zdGZpeCA9IHJlY3Vyc2VDb3VudCA+IDAgPyBgLi4uICgke3JlY3Vyc2VDb3VudH0gcmVjdXJzaXZlIGNhbGxzKWAgOiBgYDtcbiAgY29uc3QgaXNSb290ID0gdm5vZGUuY29tcG9uZW50ID8gdm5vZGUuY29tcG9uZW50LnBhcmVudCA9PSBudWxsIDogZmFsc2U7XG4gIGNvbnN0IG9wZW4gPSBgIGF0IDwke2Zvcm1hdENvbXBvbmVudE5hbWUoXG4gICAgdm5vZGUuY29tcG9uZW50LFxuICAgIHZub2RlLnR5cGUsXG4gICAgaXNSb290XG4gICl9YDtcbiAgY29uc3QgY2xvc2UgPSBgPmAgKyBwb3N0Zml4O1xuICByZXR1cm4gdm5vZGUucHJvcHMgPyBbb3BlbiwgLi4uZm9ybWF0UHJvcHModm5vZGUucHJvcHMpLCBjbG9zZV0gOiBbb3BlbiArIGNsb3NlXTtcbn1cbmZ1bmN0aW9uIGZvcm1hdFByb3BzKHByb3BzKSB7XG4gIGNvbnN0IHJlcyA9IFtdO1xuICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMocHJvcHMpO1xuICBrZXlzLnNsaWNlKDAsIDMpLmZvckVhY2goKGtleSkgPT4ge1xuICAgIHJlcy5wdXNoKC4uLmZvcm1hdFByb3Aoa2V5LCBwcm9wc1trZXldKSk7XG4gIH0pO1xuICBpZiAoa2V5cy5sZW5ndGggPiAzKSB7XG4gICAgcmVzLnB1c2goYCAuLi5gKTtcbiAgfVxuICByZXR1cm4gcmVzO1xufVxuZnVuY3Rpb24gZm9ybWF0UHJvcChrZXksIHZhbHVlLCByYXcpIHtcbiAgaWYgKGlzU3RyaW5nKHZhbHVlKSkge1xuICAgIHZhbHVlID0gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIHJldHVybiByYXcgPyB2YWx1ZSA6IFtgJHtrZXl9PSR7dmFsdWV9YF07XG4gIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgfHwgdmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiByYXcgPyB2YWx1ZSA6IFtgJHtrZXl9PSR7dmFsdWV9YF07XG4gIH0gZWxzZSBpZiAoaXNSZWYodmFsdWUpKSB7XG4gICAgdmFsdWUgPSBmb3JtYXRQcm9wKGtleSwgdG9SYXcodmFsdWUudmFsdWUpLCB0cnVlKTtcbiAgICByZXR1cm4gcmF3ID8gdmFsdWUgOiBbYCR7a2V5fT1SZWY8YCwgdmFsdWUsIGA+YF07XG4gIH0gZWxzZSBpZiAoaXNGdW5jdGlvbih2YWx1ZSkpIHtcbiAgICByZXR1cm4gW2Ake2tleX09Zm4ke3ZhbHVlLm5hbWUgPyBgPCR7dmFsdWUubmFtZX0+YCA6IGBgfWBdO1xuICB9IGVsc2Uge1xuICAgIHZhbHVlID0gdG9SYXcodmFsdWUpO1xuICAgIHJldHVybiByYXcgPyB2YWx1ZSA6IFtgJHtrZXl9PWAsIHZhbHVlXTtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0TnVtYmVyKHZhbCwgdHlwZSkge1xuICBpZiAoISEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHJldHVybjtcbiAgaWYgKHZhbCA9PT0gdm9pZCAwKSB7XG4gICAgcmV0dXJuO1xuICB9IGVsc2UgaWYgKHR5cGVvZiB2YWwgIT09IFwibnVtYmVyXCIpIHtcbiAgICB3YXJuJDEoYCR7dHlwZX0gaXMgbm90IGEgdmFsaWQgbnVtYmVyIC0gZ290ICR7SlNPTi5zdHJpbmdpZnkodmFsKX0uYCk7XG4gIH0gZWxzZSBpZiAoaXNOYU4odmFsKSkge1xuICAgIHdhcm4kMShgJHt0eXBlfSBpcyBOYU4gLSB0aGUgZHVyYXRpb24gZXhwcmVzc2lvbiBtaWdodCBiZSBpbmNvcnJlY3QuYCk7XG4gIH1cbn1cblxuY29uc3QgRXJyb3JDb2RlcyA9IHtcbiAgXCJTRVRVUF9GVU5DVElPTlwiOiAwLFxuICBcIjBcIjogXCJTRVRVUF9GVU5DVElPTlwiLFxuICBcIlJFTkRFUl9GVU5DVElPTlwiOiAxLFxuICBcIjFcIjogXCJSRU5ERVJfRlVOQ1RJT05cIixcbiAgXCJOQVRJVkVfRVZFTlRfSEFORExFUlwiOiA1LFxuICBcIjVcIjogXCJOQVRJVkVfRVZFTlRfSEFORExFUlwiLFxuICBcIkNPTVBPTkVOVF9FVkVOVF9IQU5ETEVSXCI6IDYsXG4gIFwiNlwiOiBcIkNPTVBPTkVOVF9FVkVOVF9IQU5ETEVSXCIsXG4gIFwiVk5PREVfSE9PS1wiOiA3LFxuICBcIjdcIjogXCJWTk9ERV9IT09LXCIsXG4gIFwiRElSRUNUSVZFX0hPT0tcIjogOCxcbiAgXCI4XCI6IFwiRElSRUNUSVZFX0hPT0tcIixcbiAgXCJUUkFOU0lUSU9OX0hPT0tcIjogOSxcbiAgXCI5XCI6IFwiVFJBTlNJVElPTl9IT09LXCIsXG4gIFwiQVBQX0VSUk9SX0hBTkRMRVJcIjogMTAsXG4gIFwiMTBcIjogXCJBUFBfRVJST1JfSEFORExFUlwiLFxuICBcIkFQUF9XQVJOX0hBTkRMRVJcIjogMTEsXG4gIFwiMTFcIjogXCJBUFBfV0FSTl9IQU5ETEVSXCIsXG4gIFwiRlVOQ1RJT05fUkVGXCI6IDEyLFxuICBcIjEyXCI6IFwiRlVOQ1RJT05fUkVGXCIsXG4gIFwiQVNZTkNfQ09NUE9ORU5UX0xPQURFUlwiOiAxMyxcbiAgXCIxM1wiOiBcIkFTWU5DX0NPTVBPTkVOVF9MT0FERVJcIixcbiAgXCJTQ0hFRFVMRVJcIjogMTQsXG4gIFwiMTRcIjogXCJTQ0hFRFVMRVJcIixcbiAgXCJDT01QT05FTlRfVVBEQVRFXCI6IDE1LFxuICBcIjE1XCI6IFwiQ09NUE9ORU5UX1VQREFURVwiLFxuICBcIkFQUF9VTk1PVU5UX0NMRUFOVVBcIjogMTYsXG4gIFwiMTZcIjogXCJBUFBfVU5NT1VOVF9DTEVBTlVQXCJcbn07XG5jb25zdCBFcnJvclR5cGVTdHJpbmdzJDEgPSB7XG4gIFtcInNwXCJdOiBcInNlcnZlclByZWZldGNoIGhvb2tcIixcbiAgW1wiYmNcIl06IFwiYmVmb3JlQ3JlYXRlIGhvb2tcIixcbiAgW1wiY1wiXTogXCJjcmVhdGVkIGhvb2tcIixcbiAgW1wiYm1cIl06IFwiYmVmb3JlTW91bnQgaG9va1wiLFxuICBbXCJtXCJdOiBcIm1vdW50ZWQgaG9va1wiLFxuICBbXCJidVwiXTogXCJiZWZvcmVVcGRhdGUgaG9va1wiLFxuICBbXCJ1XCJdOiBcInVwZGF0ZWRcIixcbiAgW1wiYnVtXCJdOiBcImJlZm9yZVVubW91bnQgaG9va1wiLFxuICBbXCJ1bVwiXTogXCJ1bm1vdW50ZWQgaG9va1wiLFxuICBbXCJhXCJdOiBcImFjdGl2YXRlZCBob29rXCIsXG4gIFtcImRhXCJdOiBcImRlYWN0aXZhdGVkIGhvb2tcIixcbiAgW1wiZWNcIl06IFwiZXJyb3JDYXB0dXJlZCBob29rXCIsXG4gIFtcInJ0Y1wiXTogXCJyZW5kZXJUcmFja2VkIGhvb2tcIixcbiAgW1wicnRnXCJdOiBcInJlbmRlclRyaWdnZXJlZCBob29rXCIsXG4gIFswXTogXCJzZXR1cCBmdW5jdGlvblwiLFxuICBbMV06IFwicmVuZGVyIGZ1bmN0aW9uXCIsXG4gIFsyXTogXCJ3YXRjaGVyIGdldHRlclwiLFxuICBbM106IFwid2F0Y2hlciBjYWxsYmFja1wiLFxuICBbNF06IFwid2F0Y2hlciBjbGVhbnVwIGZ1bmN0aW9uXCIsXG4gIFs1XTogXCJuYXRpdmUgZXZlbnQgaGFuZGxlclwiLFxuICBbNl06IFwiY29tcG9uZW50IGV2ZW50IGhhbmRsZXJcIixcbiAgWzddOiBcInZub2RlIGhvb2tcIixcbiAgWzhdOiBcImRpcmVjdGl2ZSBob29rXCIsXG4gIFs5XTogXCJ0cmFuc2l0aW9uIGhvb2tcIixcbiAgWzEwXTogXCJhcHAgZXJyb3JIYW5kbGVyXCIsXG4gIFsxMV06IFwiYXBwIHdhcm5IYW5kbGVyXCIsXG4gIFsxMl06IFwicmVmIGZ1bmN0aW9uXCIsXG4gIFsxM106IFwiYXN5bmMgY29tcG9uZW50IGxvYWRlclwiLFxuICBbMTRdOiBcInNjaGVkdWxlciBmbHVzaFwiLFxuICBbMTVdOiBcImNvbXBvbmVudCB1cGRhdGVcIixcbiAgWzE2XTogXCJhcHAgdW5tb3VudCBjbGVhbnVwIGZ1bmN0aW9uXCJcbn07XG5mdW5jdGlvbiBjYWxsV2l0aEVycm9ySGFuZGxpbmcoZm4sIGluc3RhbmNlLCB0eXBlLCBhcmdzKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGFyZ3MgPyBmbiguLi5hcmdzKSA6IGZuKCk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGhhbmRsZUVycm9yKGVyciwgaW5zdGFuY2UsIHR5cGUpO1xuICB9XG59XG5mdW5jdGlvbiBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZyhmbiwgaW5zdGFuY2UsIHR5cGUsIGFyZ3MpIHtcbiAgaWYgKGlzRnVuY3Rpb24oZm4pKSB7XG4gICAgY29uc3QgcmVzID0gY2FsbFdpdGhFcnJvckhhbmRsaW5nKGZuLCBpbnN0YW5jZSwgdHlwZSwgYXJncyk7XG4gICAgaWYgKHJlcyAmJiBpc1Byb21pc2UocmVzKSkge1xuICAgICAgcmVzLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgaGFuZGxlRXJyb3IoZXJyLCBpbnN0YW5jZSwgdHlwZSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuICBpZiAoaXNBcnJheShmbikpIHtcbiAgICBjb25zdCB2YWx1ZXMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZuLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YWx1ZXMucHVzaChjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZyhmbltpXSwgaW5zdGFuY2UsIHR5cGUsIGFyZ3MpKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlcztcbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FybiQxKFxuICAgICAgYEludmFsaWQgdmFsdWUgdHlwZSBwYXNzZWQgdG8gY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoKTogJHt0eXBlb2YgZm59YFxuICAgICk7XG4gIH1cbn1cbmZ1bmN0aW9uIGhhbmRsZUVycm9yKGVyciwgaW5zdGFuY2UsIHR5cGUsIHRocm93SW5EZXYgPSB0cnVlKSB7XG4gIGNvbnN0IGNvbnRleHRWTm9kZSA9IGluc3RhbmNlID8gaW5zdGFuY2Uudm5vZGUgOiBudWxsO1xuICBjb25zdCB7IGVycm9ySGFuZGxlciwgdGhyb3dVbmhhbmRsZWRFcnJvckluUHJvZHVjdGlvbiB9ID0gaW5zdGFuY2UgJiYgaW5zdGFuY2UuYXBwQ29udGV4dC5jb25maWcgfHwgRU1QVFlfT0JKO1xuICBpZiAoaW5zdGFuY2UpIHtcbiAgICBsZXQgY3VyID0gaW5zdGFuY2UucGFyZW50O1xuICAgIGNvbnN0IGV4cG9zZWRJbnN0YW5jZSA9IGluc3RhbmNlLnByb3h5O1xuICAgIGNvbnN0IGVycm9ySW5mbyA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBFcnJvclR5cGVTdHJpbmdzJDFbdHlwZV0gOiBgaHR0cHM6Ly92dWVqcy5vcmcvZXJyb3ItcmVmZXJlbmNlLyNydW50aW1lLSR7dHlwZX1gO1xuICAgIHdoaWxlIChjdXIpIHtcbiAgICAgIGNvbnN0IGVycm9yQ2FwdHVyZWRIb29rcyA9IGN1ci5lYztcbiAgICAgIGlmIChlcnJvckNhcHR1cmVkSG9va3MpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlcnJvckNhcHR1cmVkSG9va3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoZXJyb3JDYXB0dXJlZEhvb2tzW2ldKGVyciwgZXhwb3NlZEluc3RhbmNlLCBlcnJvckluZm8pID09PSBmYWxzZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY3VyID0gY3VyLnBhcmVudDtcbiAgICB9XG4gICAgaWYgKGVycm9ySGFuZGxlcikge1xuICAgICAgcGF1c2VUcmFja2luZygpO1xuICAgICAgY2FsbFdpdGhFcnJvckhhbmRsaW5nKGVycm9ySGFuZGxlciwgbnVsbCwgMTAsIFtcbiAgICAgICAgZXJyLFxuICAgICAgICBleHBvc2VkSW5zdGFuY2UsXG4gICAgICAgIGVycm9ySW5mb1xuICAgICAgXSk7XG4gICAgICByZXNldFRyYWNraW5nKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICB9XG4gIGxvZ0Vycm9yKGVyciwgdHlwZSwgY29udGV4dFZOb2RlLCB0aHJvd0luRGV2LCB0aHJvd1VuaGFuZGxlZEVycm9ySW5Qcm9kdWN0aW9uKTtcbn1cbmZ1bmN0aW9uIGxvZ0Vycm9yKGVyciwgdHlwZSwgY29udGV4dFZOb2RlLCB0aHJvd0luRGV2ID0gdHJ1ZSwgdGhyb3dJblByb2QgPSBmYWxzZSkge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGNvbnN0IGluZm8gPSBFcnJvclR5cGVTdHJpbmdzJDFbdHlwZV07XG4gICAgaWYgKGNvbnRleHRWTm9kZSkge1xuICAgICAgcHVzaFdhcm5pbmdDb250ZXh0KGNvbnRleHRWTm9kZSk7XG4gICAgfVxuICAgIHdhcm4kMShgVW5oYW5kbGVkIGVycm9yJHtpbmZvID8gYCBkdXJpbmcgZXhlY3V0aW9uIG9mICR7aW5mb31gIDogYGB9YCk7XG4gICAgaWYgKGNvbnRleHRWTm9kZSkge1xuICAgICAgcG9wV2FybmluZ0NvbnRleHQoKTtcbiAgICB9XG4gICAgaWYgKHRocm93SW5EZXYpIHtcbiAgICAgIHRocm93IGVycjtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgIH1cbiAgfSBlbHNlIGlmICh0aHJvd0luUHJvZCkge1xuICAgIHRocm93IGVycjtcbiAgfSBlbHNlIHtcbiAgICBjb25zb2xlLmVycm9yKGVycik7XG4gIH1cbn1cblxuY29uc3QgcXVldWUgPSBbXTtcbmxldCBmbHVzaEluZGV4ID0gLTE7XG5jb25zdCBwZW5kaW5nUG9zdEZsdXNoQ2JzID0gW107XG5sZXQgYWN0aXZlUG9zdEZsdXNoQ2JzID0gbnVsbDtcbmxldCBwb3N0Rmx1c2hJbmRleCA9IDA7XG5jb25zdCByZXNvbHZlZFByb21pc2UgPSAvKiBAX19QVVJFX18gKi8gUHJvbWlzZS5yZXNvbHZlKCk7XG5sZXQgY3VycmVudEZsdXNoUHJvbWlzZSA9IG51bGw7XG5jb25zdCBSRUNVUlNJT05fTElNSVQgPSAxMDA7XG5mdW5jdGlvbiBuZXh0VGljayhmbikge1xuICBjb25zdCBwID0gY3VycmVudEZsdXNoUHJvbWlzZSB8fCByZXNvbHZlZFByb21pc2U7XG4gIHJldHVybiBmbiA/IHAudGhlbih0aGlzID8gZm4uYmluZCh0aGlzKSA6IGZuKSA6IHA7XG59XG5mdW5jdGlvbiBmaW5kSW5zZXJ0aW9uSW5kZXgoaWQpIHtcbiAgbGV0IHN0YXJ0ID0gZmx1c2hJbmRleCArIDE7XG4gIGxldCBlbmQgPSBxdWV1ZS5sZW5ndGg7XG4gIHdoaWxlIChzdGFydCA8IGVuZCkge1xuICAgIGNvbnN0IG1pZGRsZSA9IHN0YXJ0ICsgZW5kID4+PiAxO1xuICAgIGNvbnN0IG1pZGRsZUpvYiA9IHF1ZXVlW21pZGRsZV07XG4gICAgY29uc3QgbWlkZGxlSm9iSWQgPSBnZXRJZChtaWRkbGVKb2IpO1xuICAgIGlmIChtaWRkbGVKb2JJZCA8IGlkIHx8IG1pZGRsZUpvYklkID09PSBpZCAmJiBtaWRkbGVKb2IuZmxhZ3MgJiAyKSB7XG4gICAgICBzdGFydCA9IG1pZGRsZSArIDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIGVuZCA9IG1pZGRsZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0YXJ0O1xufVxuZnVuY3Rpb24gcXVldWVKb2Ioam9iKSB7XG4gIGlmICghKGpvYi5mbGFncyAmIDEpKSB7XG4gICAgY29uc3Qgam9iSWQgPSBnZXRJZChqb2IpO1xuICAgIGNvbnN0IGxhc3RKb2IgPSBxdWV1ZVtxdWV1ZS5sZW5ndGggLSAxXTtcbiAgICBpZiAoIWxhc3RKb2IgfHwgLy8gZmFzdCBwYXRoIHdoZW4gdGhlIGpvYiBpZCBpcyBsYXJnZXIgdGhhbiB0aGUgdGFpbFxuICAgICEoam9iLmZsYWdzICYgMikgJiYgam9iSWQgPj0gZ2V0SWQobGFzdEpvYikpIHtcbiAgICAgIHF1ZXVlLnB1c2goam9iKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcXVldWUuc3BsaWNlKGZpbmRJbnNlcnRpb25JbmRleChqb2JJZCksIDAsIGpvYik7XG4gICAgfVxuICAgIGpvYi5mbGFncyB8PSAxO1xuICAgIHF1ZXVlRmx1c2goKTtcbiAgfVxufVxuZnVuY3Rpb24gcXVldWVGbHVzaCgpIHtcbiAgaWYgKCFjdXJyZW50Rmx1c2hQcm9taXNlKSB7XG4gICAgY3VycmVudEZsdXNoUHJvbWlzZSA9IHJlc29sdmVkUHJvbWlzZS50aGVuKGZsdXNoSm9icyk7XG4gIH1cbn1cbmZ1bmN0aW9uIHF1ZXVlUG9zdEZsdXNoQ2IoY2IpIHtcbiAgaWYgKCFpc0FycmF5KGNiKSkge1xuICAgIGlmIChhY3RpdmVQb3N0Rmx1c2hDYnMgJiYgY2IuaWQgPT09IC0xKSB7XG4gICAgICBhY3RpdmVQb3N0Rmx1c2hDYnMuc3BsaWNlKHBvc3RGbHVzaEluZGV4ICsgMSwgMCwgY2IpO1xuICAgIH0gZWxzZSBpZiAoIShjYi5mbGFncyAmIDEpKSB7XG4gICAgICBwZW5kaW5nUG9zdEZsdXNoQ2JzLnB1c2goY2IpO1xuICAgICAgY2IuZmxhZ3MgfD0gMTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjYi5sZW5ndGg7IGkrKykge1xuICAgICAgcGVuZGluZ1Bvc3RGbHVzaENicy5wdXNoKGNiW2ldKTtcbiAgICB9XG4gIH1cbiAgcXVldWVGbHVzaCgpO1xufVxuZnVuY3Rpb24gZmx1c2hQcmVGbHVzaENicyhpbnN0YW5jZSwgc2VlbiwgaSA9IGZsdXNoSW5kZXggKyAxKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgc2VlbiA9IHNlZW4gfHwgLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgfVxuICBmb3IgKDsgaSA8IHF1ZXVlLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgY2IgPSBxdWV1ZVtpXTtcbiAgICBpZiAoY2IgJiYgY2IuZmxhZ3MgJiAyKSB7XG4gICAgICBpZiAoaW5zdGFuY2UgJiYgY2IuaWQgIT09IGluc3RhbmNlLnVpZCkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGNoZWNrUmVjdXJzaXZlVXBkYXRlcyhzZWVuLCBjYikpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBxdWV1ZS5zcGxpY2UoaSwgMSk7XG4gICAgICBpLS07XG4gICAgICBpZiAoY2IuZmxhZ3MgJiA0KSB7XG4gICAgICAgIGNiLmZsYWdzICY9IC0yO1xuICAgICAgfVxuICAgICAgY2IoKTtcbiAgICAgIGlmICghKGNiLmZsYWdzICYgNCkpIHtcbiAgICAgICAgY2IuZmxhZ3MgJj0gLTI7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBmbHVzaFBvc3RGbHVzaENicyhzZWVuKSB7XG4gIGlmIChwZW5kaW5nUG9zdEZsdXNoQ2JzLmxlbmd0aCkge1xuICAgIGNvbnN0IGRlZHVwZWQgPSBbLi4ubmV3IFNldChwZW5kaW5nUG9zdEZsdXNoQ2JzKV0uc29ydChcbiAgICAgIChhLCBiKSA9PiBnZXRJZChhKSAtIGdldElkKGIpXG4gICAgKTtcbiAgICBwZW5kaW5nUG9zdEZsdXNoQ2JzLmxlbmd0aCA9IDA7XG4gICAgaWYgKGFjdGl2ZVBvc3RGbHVzaENicykge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkZWR1cGVkLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGFjdGl2ZVBvc3RGbHVzaENicy5wdXNoKGRlZHVwZWRbaV0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhY3RpdmVQb3N0Rmx1c2hDYnMgPSBkZWR1cGVkO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBzZWVuID0gc2VlbiB8fCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIH1cbiAgICBmb3IgKHBvc3RGbHVzaEluZGV4ID0gMDsgcG9zdEZsdXNoSW5kZXggPCBhY3RpdmVQb3N0Rmx1c2hDYnMubGVuZ3RoOyBwb3N0Rmx1c2hJbmRleCsrKSB7XG4gICAgICBjb25zdCBjYiA9IGFjdGl2ZVBvc3RGbHVzaENic1twb3N0Rmx1c2hJbmRleF07XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjaGVja1JlY3Vyc2l2ZVVwZGF0ZXMoc2VlbiwgY2IpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKGNiLmZsYWdzICYgNCkge1xuICAgICAgICBjYi5mbGFncyAmPSAtMjtcbiAgICAgIH1cbiAgICAgIGlmICghKGNiLmZsYWdzICYgOCkpIGNiKCk7XG4gICAgICBjYi5mbGFncyAmPSAtMjtcbiAgICB9XG4gICAgYWN0aXZlUG9zdEZsdXNoQ2JzID0gbnVsbDtcbiAgICBwb3N0Rmx1c2hJbmRleCA9IDA7XG4gIH1cbn1cbmNvbnN0IGdldElkID0gKGpvYikgPT4gam9iLmlkID09IG51bGwgPyBqb2IuZmxhZ3MgJiAyID8gLTEgOiBJbmZpbml0eSA6IGpvYi5pZDtcbmZ1bmN0aW9uIGZsdXNoSm9icyhzZWVuKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgc2VlbiA9IHNlZW4gfHwgLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgfVxuICBjb25zdCBjaGVjayA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyAoam9iKSA9PiBjaGVja1JlY3Vyc2l2ZVVwZGF0ZXMoc2Vlbiwgam9iKSA6IE5PT1A7XG4gIHRyeSB7XG4gICAgZm9yIChmbHVzaEluZGV4ID0gMDsgZmx1c2hJbmRleCA8IHF1ZXVlLmxlbmd0aDsgZmx1c2hJbmRleCsrKSB7XG4gICAgICBjb25zdCBqb2IgPSBxdWV1ZVtmbHVzaEluZGV4XTtcbiAgICAgIGlmIChqb2IgJiYgIShqb2IuZmxhZ3MgJiA4KSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjaGVjayhqb2IpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGpvYi5mbGFncyAmIDQpIHtcbiAgICAgICAgICBqb2IuZmxhZ3MgJj0gfjE7XG4gICAgICAgIH1cbiAgICAgICAgY2FsbFdpdGhFcnJvckhhbmRsaW5nKFxuICAgICAgICAgIGpvYixcbiAgICAgICAgICBqb2IuaSxcbiAgICAgICAgICBqb2IuaSA/IDE1IDogMTRcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKCEoam9iLmZsYWdzICYgNCkpIHtcbiAgICAgICAgICBqb2IuZmxhZ3MgJj0gfjE7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gZmluYWxseSB7XG4gICAgZm9yICg7IGZsdXNoSW5kZXggPCBxdWV1ZS5sZW5ndGg7IGZsdXNoSW5kZXgrKykge1xuICAgICAgY29uc3Qgam9iID0gcXVldWVbZmx1c2hJbmRleF07XG4gICAgICBpZiAoam9iKSB7XG4gICAgICAgIGpvYi5mbGFncyAmPSAtMjtcbiAgICAgIH1cbiAgICB9XG4gICAgZmx1c2hJbmRleCA9IC0xO1xuICAgIHF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgZmx1c2hQb3N0Rmx1c2hDYnMoc2Vlbik7XG4gICAgY3VycmVudEZsdXNoUHJvbWlzZSA9IG51bGw7XG4gICAgaWYgKHF1ZXVlLmxlbmd0aCB8fCBwZW5kaW5nUG9zdEZsdXNoQ2JzLmxlbmd0aCkge1xuICAgICAgZmx1c2hKb2JzKHNlZW4pO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gY2hlY2tSZWN1cnNpdmVVcGRhdGVzKHNlZW4sIGZuKSB7XG4gIGNvbnN0IGNvdW50ID0gc2Vlbi5nZXQoZm4pIHx8IDA7XG4gIGlmIChjb3VudCA+IFJFQ1VSU0lPTl9MSU1JVCkge1xuICAgIGNvbnN0IGluc3RhbmNlID0gZm4uaTtcbiAgICBjb25zdCBjb21wb25lbnROYW1lID0gaW5zdGFuY2UgJiYgZ2V0Q29tcG9uZW50TmFtZShpbnN0YW5jZS50eXBlKTtcbiAgICBoYW5kbGVFcnJvcihcbiAgICAgIGBNYXhpbXVtIHJlY3Vyc2l2ZSB1cGRhdGVzIGV4Y2VlZGVkJHtjb21wb25lbnROYW1lID8gYCBpbiBjb21wb25lbnQgPCR7Y29tcG9uZW50TmFtZX0+YCA6IGBgfS4gVGhpcyBtZWFucyB5b3UgaGF2ZSBhIHJlYWN0aXZlIGVmZmVjdCB0aGF0IGlzIG11dGF0aW5nIGl0cyBvd24gZGVwZW5kZW5jaWVzIGFuZCB0aHVzIHJlY3Vyc2l2ZWx5IHRyaWdnZXJpbmcgaXRzZWxmLiBQb3NzaWJsZSBzb3VyY2VzIGluY2x1ZGUgY29tcG9uZW50IHRlbXBsYXRlLCByZW5kZXIgZnVuY3Rpb24sIHVwZGF0ZWQgaG9vayBvciB3YXRjaGVyIHNvdXJjZSBmdW5jdGlvbi5gLFxuICAgICAgbnVsbCxcbiAgICAgIDEwXG4gICAgKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBzZWVuLnNldChmbiwgY291bnQgKyAxKTtcbiAgcmV0dXJuIGZhbHNlO1xufVxuXG5sZXQgaXNIbXJVcGRhdGluZyA9IGZhbHNlO1xuY29uc3Qgc2V0SG1yVXBkYXRpbmcgPSAodikgPT4ge1xuICB0cnkge1xuICAgIHJldHVybiBpc0htclVwZGF0aW5nO1xuICB9IGZpbmFsbHkge1xuICAgIGlzSG1yVXBkYXRpbmcgPSB2O1xuICB9XG59O1xuY29uc3QgaG1yRGlydHlDb21wb25lbnRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbmlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gIGdldEdsb2JhbFRoaXMoKS5fX1ZVRV9ITVJfUlVOVElNRV9fID0ge1xuICAgIGNyZWF0ZVJlY29yZDogdHJ5V3JhcChjcmVhdGVSZWNvcmQpLFxuICAgIHJlcmVuZGVyOiB0cnlXcmFwKHJlcmVuZGVyKSxcbiAgICByZWxvYWQ6IHRyeVdyYXAocmVsb2FkKVxuICB9O1xufVxuY29uc3QgbWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbmZ1bmN0aW9uIHJlZ2lzdGVySE1SKGluc3RhbmNlKSB7XG4gIGNvbnN0IGlkID0gaW5zdGFuY2UudHlwZS5fX2htcklkO1xuICBsZXQgcmVjb3JkID0gbWFwLmdldChpZCk7XG4gIGlmICghcmVjb3JkKSB7XG4gICAgY3JlYXRlUmVjb3JkKGlkLCBpbnN0YW5jZS50eXBlKTtcbiAgICByZWNvcmQgPSBtYXAuZ2V0KGlkKTtcbiAgfVxuICByZWNvcmQuaW5zdGFuY2VzLmFkZChpbnN0YW5jZSk7XG59XG5mdW5jdGlvbiB1bnJlZ2lzdGVySE1SKGluc3RhbmNlKSB7XG4gIG1hcC5nZXQoaW5zdGFuY2UudHlwZS5fX2htcklkKS5pbnN0YW5jZXMuZGVsZXRlKGluc3RhbmNlKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJlY29yZChpZCwgaW5pdGlhbERlZikge1xuICBpZiAobWFwLmhhcyhpZCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgbWFwLnNldChpZCwge1xuICAgIGluaXRpYWxEZWY6IG5vcm1hbGl6ZUNsYXNzQ29tcG9uZW50KGluaXRpYWxEZWYpLFxuICAgIGluc3RhbmNlczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKVxuICB9KTtcbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBub3JtYWxpemVDbGFzc0NvbXBvbmVudChjb21wb25lbnQpIHtcbiAgcmV0dXJuIGlzQ2xhc3NDb21wb25lbnQoY29tcG9uZW50KSA/IGNvbXBvbmVudC5fX3ZjY09wdHMgOiBjb21wb25lbnQ7XG59XG5mdW5jdGlvbiByZXJlbmRlcihpZCwgbmV3UmVuZGVyKSB7XG4gIGNvbnN0IHJlY29yZCA9IG1hcC5nZXQoaWQpO1xuICBpZiAoIXJlY29yZCkge1xuICAgIHJldHVybjtcbiAgfVxuICByZWNvcmQuaW5pdGlhbERlZi5yZW5kZXIgPSBuZXdSZW5kZXI7XG4gIFsuLi5yZWNvcmQuaW5zdGFuY2VzXS5mb3JFYWNoKChpbnN0YW5jZSkgPT4ge1xuICAgIGlmIChuZXdSZW5kZXIpIHtcbiAgICAgIGluc3RhbmNlLnJlbmRlciA9IG5ld1JlbmRlcjtcbiAgICAgIG5vcm1hbGl6ZUNsYXNzQ29tcG9uZW50KGluc3RhbmNlLnR5cGUpLnJlbmRlciA9IG5ld1JlbmRlcjtcbiAgICB9XG4gICAgaW5zdGFuY2UucmVuZGVyQ2FjaGUgPSBbXTtcbiAgICBpc0htclVwZGF0aW5nID0gdHJ1ZTtcbiAgICBpZiAoIShpbnN0YW5jZS5qb2IuZmxhZ3MgJiA4KSkge1xuICAgICAgaW5zdGFuY2UudXBkYXRlKCk7XG4gICAgfVxuICAgIGlzSG1yVXBkYXRpbmcgPSBmYWxzZTtcbiAgfSk7XG59XG5mdW5jdGlvbiByZWxvYWQoaWQsIG5ld0NvbXApIHtcbiAgY29uc3QgcmVjb3JkID0gbWFwLmdldChpZCk7XG4gIGlmICghcmVjb3JkKSByZXR1cm47XG4gIG5ld0NvbXAgPSBub3JtYWxpemVDbGFzc0NvbXBvbmVudChuZXdDb21wKTtcbiAgdXBkYXRlQ29tcG9uZW50RGVmKHJlY29yZC5pbml0aWFsRGVmLCBuZXdDb21wKTtcbiAgY29uc3QgaW5zdGFuY2VzID0gWy4uLnJlY29yZC5pbnN0YW5jZXNdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGluc3RhbmNlcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGluc3RhbmNlID0gaW5zdGFuY2VzW2ldO1xuICAgIGNvbnN0IG9sZENvbXAgPSBub3JtYWxpemVDbGFzc0NvbXBvbmVudChpbnN0YW5jZS50eXBlKTtcbiAgICBsZXQgZGlydHlJbnN0YW5jZXMgPSBobXJEaXJ0eUNvbXBvbmVudHMuZ2V0KG9sZENvbXApO1xuICAgIGlmICghZGlydHlJbnN0YW5jZXMpIHtcbiAgICAgIGlmIChvbGRDb21wICE9PSByZWNvcmQuaW5pdGlhbERlZikge1xuICAgICAgICB1cGRhdGVDb21wb25lbnREZWYob2xkQ29tcCwgbmV3Q29tcCk7XG4gICAgICB9XG4gICAgICBobXJEaXJ0eUNvbXBvbmVudHMuc2V0KG9sZENvbXAsIGRpcnR5SW5zdGFuY2VzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSk7XG4gICAgfVxuICAgIGRpcnR5SW5zdGFuY2VzLmFkZChpbnN0YW5jZSk7XG4gICAgaW5zdGFuY2UuYXBwQ29udGV4dC5wcm9wc0NhY2hlLmRlbGV0ZShpbnN0YW5jZS50eXBlKTtcbiAgICBpbnN0YW5jZS5hcHBDb250ZXh0LmVtaXRzQ2FjaGUuZGVsZXRlKGluc3RhbmNlLnR5cGUpO1xuICAgIGluc3RhbmNlLmFwcENvbnRleHQub3B0aW9uc0NhY2hlLmRlbGV0ZShpbnN0YW5jZS50eXBlKTtcbiAgICBpZiAoaW5zdGFuY2UuY2VSZWxvYWQpIHtcbiAgICAgIGRpcnR5SW5zdGFuY2VzLmFkZChpbnN0YW5jZSk7XG4gICAgICBpbnN0YW5jZS5jZVJlbG9hZChuZXdDb21wLnN0eWxlcyk7XG4gICAgICBkaXJ0eUluc3RhbmNlcy5kZWxldGUoaW5zdGFuY2UpO1xuICAgIH0gZWxzZSBpZiAoaW5zdGFuY2UucGFyZW50KSB7XG4gICAgICBxdWV1ZUpvYigoKSA9PiB7XG4gICAgICAgIGlmICghKGluc3RhbmNlLmpvYi5mbGFncyAmIDgpKSB7XG4gICAgICAgICAgaXNIbXJVcGRhdGluZyA9IHRydWU7XG4gICAgICAgICAgaW5zdGFuY2UucGFyZW50LnVwZGF0ZSgpO1xuICAgICAgICAgIGlzSG1yVXBkYXRpbmcgPSBmYWxzZTtcbiAgICAgICAgICBkaXJ0eUluc3RhbmNlcy5kZWxldGUoaW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKGluc3RhbmNlLmFwcENvbnRleHQucmVsb2FkKSB7XG4gICAgICBpbnN0YW5jZS5hcHBDb250ZXh0LnJlbG9hZCgpO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIFwiW0hNUl0gUm9vdCBvciBtYW51YWxseSBtb3VudGVkIGluc3RhbmNlIG1vZGlmaWVkLiBGdWxsIHJlbG9hZCByZXF1aXJlZC5cIlxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGluc3RhbmNlLnJvb3QuY2UgJiYgaW5zdGFuY2UgIT09IGluc3RhbmNlLnJvb3QpIHtcbiAgICAgIGluc3RhbmNlLnJvb3QuY2UuX3JlbW92ZUNoaWxkU3R5bGUob2xkQ29tcCk7XG4gICAgfVxuICB9XG4gIHF1ZXVlUG9zdEZsdXNoQ2IoKCkgPT4ge1xuICAgIGhtckRpcnR5Q29tcG9uZW50cy5jbGVhcigpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZUNvbXBvbmVudERlZihvbGRDb21wLCBuZXdDb21wKSB7XG4gIGV4dGVuZChvbGRDb21wLCBuZXdDb21wKTtcbiAgZm9yIChjb25zdCBrZXkgaW4gb2xkQ29tcCkge1xuICAgIGlmIChrZXkgIT09IFwiX19maWxlXCIgJiYgIShrZXkgaW4gbmV3Q29tcCkpIHtcbiAgICAgIGRlbGV0ZSBvbGRDb21wW2tleV07XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiB0cnlXcmFwKGZuKSB7XG4gIHJldHVybiAoaWQsIGFyZykgPT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gZm4oaWQsIGFyZyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgYFtITVJdIFNvbWV0aGluZyB3ZW50IHdyb25nIGR1cmluZyBWdWUgY29tcG9uZW50IGhvdC1yZWxvYWQuIEZ1bGwgcmVsb2FkIHJlcXVpcmVkLmBcbiAgICAgICk7XG4gICAgfVxuICB9O1xufVxuXG5sZXQgZGV2dG9vbHMkMTtcbmxldCBidWZmZXIgPSBbXTtcbmxldCBkZXZ0b29sc05vdEluc3RhbGxlZCA9IGZhbHNlO1xuZnVuY3Rpb24gZW1pdCQxKGV2ZW50LCAuLi5hcmdzKSB7XG4gIGlmIChkZXZ0b29scyQxKSB7XG4gICAgZGV2dG9vbHMkMS5lbWl0KGV2ZW50LCAuLi5hcmdzKTtcbiAgfSBlbHNlIGlmICghZGV2dG9vbHNOb3RJbnN0YWxsZWQpIHtcbiAgICBidWZmZXIucHVzaCh7IGV2ZW50LCBhcmdzIH0pO1xuICB9XG59XG5mdW5jdGlvbiBzZXREZXZ0b29sc0hvb2skMShob29rLCB0YXJnZXQpIHtcbiAgdmFyIF9hLCBfYjtcbiAgZGV2dG9vbHMkMSA9IGhvb2s7XG4gIGlmIChkZXZ0b29scyQxKSB7XG4gICAgZGV2dG9vbHMkMS5lbmFibGVkID0gdHJ1ZTtcbiAgICBidWZmZXIuZm9yRWFjaCgoeyBldmVudCwgYXJncyB9KSA9PiBkZXZ0b29scyQxLmVtaXQoZXZlbnQsIC4uLmFyZ3MpKTtcbiAgICBidWZmZXIgPSBbXTtcbiAgfSBlbHNlIGlmIChcbiAgICAvLyBoYW5kbGUgbGF0ZSBkZXZ0b29scyBpbmplY3Rpb24gLSBvbmx5IGRvIHRoaXMgaWYgd2UgYXJlIGluIGFuIGFjdHVhbFxuICAgIC8vIGJyb3dzZXIgZW52aXJvbm1lbnQgdG8gYXZvaWQgdGhlIHRpbWVyIGhhbmRsZSBzdGFsbGluZyB0ZXN0IHJ1bm5lciBleGl0XG4gICAgLy8gKCM0ODE1KVxuICAgIHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgLy8gc29tZSBlbnZzIG1vY2sgd2luZG93IGJ1dCBub3QgZnVsbHlcbiAgICB3aW5kb3cuSFRNTEVsZW1lbnQgJiYgLy8gYWxzbyBleGNsdWRlIGpzZG9tXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtc3ludGF4XG4gICAgISgoX2IgPSAoX2EgPSB3aW5kb3cubmF2aWdhdG9yKSA9PSBudWxsID8gdm9pZCAwIDogX2EudXNlckFnZW50KSA9PSBudWxsID8gdm9pZCAwIDogX2IuaW5jbHVkZXMoXCJqc2RvbVwiKSlcbiAgKSB7XG4gICAgY29uc3QgcmVwbGF5ID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0hPT0tfUkVQTEFZX18gPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfSE9PS19SRVBMQVlfXyB8fCBbXTtcbiAgICByZXBsYXkucHVzaCgobmV3SG9vaykgPT4ge1xuICAgICAgc2V0RGV2dG9vbHNIb29rJDEobmV3SG9vaywgdGFyZ2V0KTtcbiAgICB9KTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICghZGV2dG9vbHMkMSkge1xuICAgICAgICB0YXJnZXQuX19WVUVfREVWVE9PTFNfSE9PS19SRVBMQVlfXyA9IG51bGw7XG4gICAgICAgIGRldnRvb2xzTm90SW5zdGFsbGVkID0gdHJ1ZTtcbiAgICAgICAgYnVmZmVyID0gW107XG4gICAgICB9XG4gICAgfSwgM2UzKTtcbiAgfSBlbHNlIHtcbiAgICBkZXZ0b29sc05vdEluc3RhbGxlZCA9IHRydWU7XG4gICAgYnVmZmVyID0gW107XG4gIH1cbn1cbmZ1bmN0aW9uIGRldnRvb2xzSW5pdEFwcChhcHAsIHZlcnNpb24pIHtcbiAgZW1pdCQxKFwiYXBwOmluaXRcIiAvKiBBUFBfSU5JVCAqLywgYXBwLCB2ZXJzaW9uLCB7XG4gICAgRnJhZ21lbnQsXG4gICAgVGV4dCxcbiAgICBDb21tZW50LFxuICAgIFN0YXRpY1xuICB9KTtcbn1cbmZ1bmN0aW9uIGRldnRvb2xzVW5tb3VudEFwcChhcHApIHtcbiAgZW1pdCQxKFwiYXBwOnVubW91bnRcIiAvKiBBUFBfVU5NT1VOVCAqLywgYXBwKTtcbn1cbmNvbnN0IGRldnRvb2xzQ29tcG9uZW50QWRkZWQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlRGV2dG9vbHNDb21wb25lbnRIb29rKFwiY29tcG9uZW50OmFkZGVkXCIgLyogQ09NUE9ORU5UX0FEREVEICovKTtcbmNvbnN0IGRldnRvb2xzQ29tcG9uZW50VXBkYXRlZCA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVEZXZ0b29sc0NvbXBvbmVudEhvb2soXCJjb21wb25lbnQ6dXBkYXRlZFwiIC8qIENPTVBPTkVOVF9VUERBVEVEICovKTtcbmNvbnN0IF9kZXZ0b29sc0NvbXBvbmVudFJlbW92ZWQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlRGV2dG9vbHNDb21wb25lbnRIb29rKFxuICBcImNvbXBvbmVudDpyZW1vdmVkXCIgLyogQ09NUE9ORU5UX1JFTU9WRUQgKi9cbik7XG5jb25zdCBkZXZ0b29sc0NvbXBvbmVudFJlbW92ZWQgPSAoY29tcG9uZW50KSA9PiB7XG4gIGlmIChkZXZ0b29scyQxICYmIHR5cGVvZiBkZXZ0b29scyQxLmNsZWFudXBCdWZmZXIgPT09IFwiZnVuY3Rpb25cIiAmJiAvLyByZW1vdmUgdGhlIGNvbXBvbmVudCBpZiBpdCB3YXNuJ3QgYnVmZmVyZWRcbiAgIWRldnRvb2xzJDEuY2xlYW51cEJ1ZmZlcihjb21wb25lbnQpKSB7XG4gICAgX2RldnRvb2xzQ29tcG9uZW50UmVtb3ZlZChjb21wb25lbnQpO1xuICB9XG59O1xuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGNyZWF0ZURldnRvb2xzQ29tcG9uZW50SG9vayhob29rKSB7XG4gIHJldHVybiAoY29tcG9uZW50KSA9PiB7XG4gICAgZW1pdCQxKFxuICAgICAgaG9vayxcbiAgICAgIGNvbXBvbmVudC5hcHBDb250ZXh0LmFwcCxcbiAgICAgIGNvbXBvbmVudC51aWQsXG4gICAgICBjb21wb25lbnQucGFyZW50ID8gY29tcG9uZW50LnBhcmVudC51aWQgOiB2b2lkIDAsXG4gICAgICBjb21wb25lbnRcbiAgICApO1xuICB9O1xufVxuY29uc3QgZGV2dG9vbHNQZXJmU3RhcnQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlRGV2dG9vbHNQZXJmb3JtYW5jZUhvb2soXCJwZXJmOnN0YXJ0XCIgLyogUEVSRk9STUFOQ0VfU1RBUlQgKi8pO1xuY29uc3QgZGV2dG9vbHNQZXJmRW5kID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZURldnRvb2xzUGVyZm9ybWFuY2VIb29rKFwicGVyZjplbmRcIiAvKiBQRVJGT1JNQU5DRV9FTkQgKi8pO1xuZnVuY3Rpb24gY3JlYXRlRGV2dG9vbHNQZXJmb3JtYW5jZUhvb2soaG9vaykge1xuICByZXR1cm4gKGNvbXBvbmVudCwgdHlwZSwgdGltZSkgPT4ge1xuICAgIGVtaXQkMShob29rLCBjb21wb25lbnQuYXBwQ29udGV4dC5hcHAsIGNvbXBvbmVudC51aWQsIGNvbXBvbmVudCwgdHlwZSwgdGltZSk7XG4gIH07XG59XG5mdW5jdGlvbiBkZXZ0b29sc0NvbXBvbmVudEVtaXQoY29tcG9uZW50LCBldmVudCwgcGFyYW1zKSB7XG4gIGVtaXQkMShcbiAgICBcImNvbXBvbmVudDplbWl0XCIgLyogQ09NUE9ORU5UX0VNSVQgKi8sXG4gICAgY29tcG9uZW50LmFwcENvbnRleHQuYXBwLFxuICAgIGNvbXBvbmVudCxcbiAgICBldmVudCxcbiAgICBwYXJhbXNcbiAgKTtcbn1cblxubGV0IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSA9IG51bGw7XG5sZXQgY3VycmVudFNjb3BlSWQgPSBudWxsO1xuZnVuY3Rpb24gc2V0Q3VycmVudFJlbmRlcmluZ0luc3RhbmNlKGluc3RhbmNlKSB7XG4gIGNvbnN0IHByZXYgPSBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2U7XG4gIGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSA9IGluc3RhbmNlO1xuICBjdXJyZW50U2NvcGVJZCA9IGluc3RhbmNlICYmIGluc3RhbmNlLnR5cGUuX19zY29wZUlkIHx8IG51bGw7XG4gIHJldHVybiBwcmV2O1xufVxuZnVuY3Rpb24gcHVzaFNjb3BlSWQoaWQpIHtcbiAgY3VycmVudFNjb3BlSWQgPSBpZDtcbn1cbmZ1bmN0aW9uIHBvcFNjb3BlSWQoKSB7XG4gIGN1cnJlbnRTY29wZUlkID0gbnVsbDtcbn1cbmNvbnN0IHdpdGhTY29wZUlkID0gKF9pZCkgPT4gd2l0aEN0eDtcbmZ1bmN0aW9uIHdpdGhDdHgoZm4sIGN0eCA9IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSwgaXNOb25TY29wZWRTbG90KSB7XG4gIGlmICghY3R4KSByZXR1cm4gZm47XG4gIGlmIChmbi5fbikge1xuICAgIHJldHVybiBmbjtcbiAgfVxuICBjb25zdCByZW5kZXJGbldpdGhDb250ZXh0ID0gKC4uLmFyZ3MpID0+IHtcbiAgICBpZiAocmVuZGVyRm5XaXRoQ29udGV4dC5fZCkge1xuICAgICAgc2V0QmxvY2tUcmFja2luZygtMSk7XG4gICAgfVxuICAgIGNvbnN0IHByZXZJbnN0YW5jZSA9IHNldEN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZShjdHgpO1xuICAgIGNvbnN0IHByZXZTdGFja1NpemUgPSBibG9ja1N0YWNrLmxlbmd0aDtcbiAgICBsZXQgcmVzO1xuICAgIHRyeSB7XG4gICAgICByZXMgPSBmbiguLi5hcmdzKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgZm9yIChsZXQgaSA9IGJsb2NrU3RhY2subGVuZ3RoOyBpID4gcHJldlN0YWNrU2l6ZTsgaS0tKSBjbG9zZUJsb2NrKCk7XG4gICAgICBzZXRDdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UocHJldkluc3RhbmNlKTtcbiAgICAgIGlmIChyZW5kZXJGbldpdGhDb250ZXh0Ll9kKSB7XG4gICAgICAgIHNldEJsb2NrVHJhY2tpbmcoMSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgZGV2dG9vbHNDb21wb25lbnRVcGRhdGVkKGN0eCk7XG4gICAgfVxuICAgIHJldHVybiByZXM7XG4gIH07XG4gIHJlbmRlckZuV2l0aENvbnRleHQuX24gPSB0cnVlO1xuICByZW5kZXJGbldpdGhDb250ZXh0Ll9jID0gdHJ1ZTtcbiAgcmVuZGVyRm5XaXRoQ29udGV4dC5fZCA9IHRydWU7XG4gIHJldHVybiByZW5kZXJGbldpdGhDb250ZXh0O1xufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZURpcmVjdGl2ZU5hbWUobmFtZSkge1xuICBpZiAoaXNCdWlsdEluRGlyZWN0aXZlKG5hbWUpKSB7XG4gICAgd2FybiQxKFwiRG8gbm90IHVzZSBidWlsdC1pbiBkaXJlY3RpdmUgaWRzIGFzIGN1c3RvbSBkaXJlY3RpdmUgaWQ6IFwiICsgbmFtZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIHdpdGhEaXJlY3RpdmVzKHZub2RlLCBkaXJlY3RpdmVzKSB7XG4gIGlmIChjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UgPT09IG51bGwpIHtcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShgd2l0aERpcmVjdGl2ZXMgY2FuIG9ubHkgYmUgdXNlZCBpbnNpZGUgcmVuZGVyIGZ1bmN0aW9ucy5gKTtcbiAgICByZXR1cm4gdm5vZGU7XG4gIH1cbiAgY29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRQdWJsaWNJbnN0YW5jZShjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UpO1xuICBjb25zdCBiaW5kaW5ncyA9IHZub2RlLmRpcnMgfHwgKHZub2RlLmRpcnMgPSBbXSk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZGlyZWN0aXZlcy5sZW5ndGg7IGkrKykge1xuICAgIGxldCBbZGlyLCB2YWx1ZSwgYXJnLCBtb2RpZmllcnMgPSBFTVBUWV9PQkpdID0gZGlyZWN0aXZlc1tpXTtcbiAgICBpZiAoZGlyKSB7XG4gICAgICBpZiAoaXNGdW5jdGlvbihkaXIpKSB7XG4gICAgICAgIGRpciA9IHtcbiAgICAgICAgICBtb3VudGVkOiBkaXIsXG4gICAgICAgICAgdXBkYXRlZDogZGlyXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZiAoZGlyLmRlZXApIHtcbiAgICAgICAgdHJhdmVyc2UodmFsdWUpO1xuICAgICAgfVxuICAgICAgYmluZGluZ3MucHVzaCh7XG4gICAgICAgIGRpcixcbiAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgIHZhbHVlLFxuICAgICAgICBvbGRWYWx1ZTogdm9pZCAwLFxuICAgICAgICBhcmcsXG4gICAgICAgIG1vZGlmaWVyc1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiB2bm9kZTtcbn1cbmZ1bmN0aW9uIGludm9rZURpcmVjdGl2ZUhvb2sodm5vZGUsIHByZXZWTm9kZSwgaW5zdGFuY2UsIG5hbWUpIHtcbiAgY29uc3QgYmluZGluZ3MgPSB2bm9kZS5kaXJzO1xuICBjb25zdCBvbGRCaW5kaW5ncyA9IHByZXZWTm9kZSAmJiBwcmV2Vk5vZGUuZGlycztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBiaW5kaW5ncy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGJpbmRpbmcgPSBiaW5kaW5nc1tpXTtcbiAgICBpZiAob2xkQmluZGluZ3MpIHtcbiAgICAgIGJpbmRpbmcub2xkVmFsdWUgPSBvbGRCaW5kaW5nc1tpXS52YWx1ZTtcbiAgICB9XG4gICAgbGV0IGhvb2sgPSBiaW5kaW5nLmRpcltuYW1lXTtcbiAgICBpZiAoaG9vaykge1xuICAgICAgcGF1c2VUcmFja2luZygpO1xuICAgICAgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoaG9vaywgaW5zdGFuY2UsIDgsIFtcbiAgICAgICAgdm5vZGUuZWwsXG4gICAgICAgIGJpbmRpbmcsXG4gICAgICAgIHZub2RlLFxuICAgICAgICBwcmV2Vk5vZGVcbiAgICAgIF0pO1xuICAgICAgcmVzZXRUcmFja2luZygpO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBwcm92aWRlKGtleSwgdmFsdWUpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBpZiAoIWN1cnJlbnRJbnN0YW5jZSB8fCBjdXJyZW50SW5zdGFuY2UuaXNNb3VudGVkKSB7XG4gICAgICB3YXJuJDEoYHByb3ZpZGUoKSBjYW4gb25seSBiZSB1c2VkIGluc2lkZSBzZXR1cCgpLmApO1xuICAgIH1cbiAgfVxuICBpZiAoY3VycmVudEluc3RhbmNlKSB7XG4gICAgbGV0IHByb3ZpZGVzID0gY3VycmVudEluc3RhbmNlLnByb3ZpZGVzO1xuICAgIGNvbnN0IHBhcmVudFByb3ZpZGVzID0gY3VycmVudEluc3RhbmNlLnBhcmVudCAmJiBjdXJyZW50SW5zdGFuY2UucGFyZW50LnByb3ZpZGVzO1xuICAgIGlmIChwYXJlbnRQcm92aWRlcyA9PT0gcHJvdmlkZXMpIHtcbiAgICAgIHByb3ZpZGVzID0gY3VycmVudEluc3RhbmNlLnByb3ZpZGVzID0gT2JqZWN0LmNyZWF0ZShwYXJlbnRQcm92aWRlcyk7XG4gICAgfVxuICAgIHByb3ZpZGVzW2tleV0gPSB2YWx1ZTtcbiAgfVxufVxuZnVuY3Rpb24gaW5qZWN0KGtleSwgZGVmYXVsdFZhbHVlLCB0cmVhdERlZmF1bHRBc0ZhY3RvcnkgPSBmYWxzZSkge1xuICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICBpZiAoaW5zdGFuY2UgfHwgY3VycmVudEFwcCkge1xuICAgIGxldCBwcm92aWRlcyA9IGN1cnJlbnRBcHAgPyBjdXJyZW50QXBwLl9jb250ZXh0LnByb3ZpZGVzIDogaW5zdGFuY2UgPyBpbnN0YW5jZS5wYXJlbnQgPT0gbnVsbCB8fCBpbnN0YW5jZS5jZSA/IGluc3RhbmNlLnZub2RlLmFwcENvbnRleHQgJiYgaW5zdGFuY2Uudm5vZGUuYXBwQ29udGV4dC5wcm92aWRlcyA6IGluc3RhbmNlLnBhcmVudC5wcm92aWRlcyA6IHZvaWQgMDtcbiAgICBpZiAocHJvdmlkZXMgJiYga2V5IGluIHByb3ZpZGVzKSB7XG4gICAgICByZXR1cm4gcHJvdmlkZXNba2V5XTtcbiAgICB9IGVsc2UgaWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICByZXR1cm4gdHJlYXREZWZhdWx0QXNGYWN0b3J5ICYmIGlzRnVuY3Rpb24oZGVmYXVsdFZhbHVlKSA/IGRlZmF1bHRWYWx1ZS5jYWxsKGluc3RhbmNlICYmIGluc3RhbmNlLnByb3h5KSA6IGRlZmF1bHRWYWx1ZTtcbiAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHdhcm4kMShgaW5qZWN0aW9uIFwiJHtTdHJpbmcoa2V5KX1cIiBub3QgZm91bmQuYCk7XG4gICAgfVxuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuJDEoYGluamVjdCgpIGNhbiBvbmx5IGJlIHVzZWQgaW5zaWRlIHNldHVwKCkgb3IgZnVuY3Rpb25hbCBjb21wb25lbnRzLmApO1xuICB9XG59XG5mdW5jdGlvbiBoYXNJbmplY3Rpb25Db250ZXh0KCkge1xuICByZXR1cm4gISEoZ2V0Q3VycmVudEluc3RhbmNlKCkgfHwgY3VycmVudEFwcCk7XG59XG5cbmNvbnN0IHNzckNvbnRleHRLZXkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sLmZvcihcInYtc2N4XCIpO1xuY29uc3QgdXNlU1NSQ29udGV4dCA9ICgpID0+IHtcbiAge1xuICAgIGNvbnN0IGN0eCA9IGluamVjdChzc3JDb250ZXh0S2V5KTtcbiAgICBpZiAoIWN0eCkge1xuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuJDEoXG4gICAgICAgIGBTZXJ2ZXIgcmVuZGVyaW5nIGNvbnRleHQgbm90IHByb3ZpZGVkLiBNYWtlIHN1cmUgdG8gb25seSBjYWxsIHVzZVNTUkNvbnRleHQoKSBjb25kaXRpb25hbGx5IGluIHRoZSBzZXJ2ZXIgYnVpbGQuYFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIGN0eDtcbiAgfVxufTtcblxuZnVuY3Rpb24gd2F0Y2hFZmZlY3QoZWZmZWN0LCBvcHRpb25zKSB7XG4gIHJldHVybiBkb1dhdGNoKGVmZmVjdCwgbnVsbCwgb3B0aW9ucyk7XG59XG5mdW5jdGlvbiB3YXRjaFBvc3RFZmZlY3QoZWZmZWN0LCBvcHRpb25zKSB7XG4gIHJldHVybiBkb1dhdGNoKFxuICAgIGVmZmVjdCxcbiAgICBudWxsLFxuICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBleHRlbmQoe30sIG9wdGlvbnMsIHsgZmx1c2g6IFwicG9zdFwiIH0pIDogeyBmbHVzaDogXCJwb3N0XCIgfVxuICApO1xufVxuZnVuY3Rpb24gd2F0Y2hTeW5jRWZmZWN0KGVmZmVjdCwgb3B0aW9ucykge1xuICByZXR1cm4gZG9XYXRjaChcbiAgICBlZmZlY3QsXG4gICAgbnVsbCxcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gZXh0ZW5kKHt9LCBvcHRpb25zLCB7IGZsdXNoOiBcInN5bmNcIiB9KSA6IHsgZmx1c2g6IFwic3luY1wiIH1cbiAgKTtcbn1cbmZ1bmN0aW9uIHdhdGNoKHNvdXJjZSwgY2IsIG9wdGlvbnMpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzRnVuY3Rpb24oY2IpKSB7XG4gICAgd2FybiQxKFxuICAgICAgYFxcYHdhdGNoKGZuLCBvcHRpb25zPylcXGAgc2lnbmF0dXJlIGhhcyBiZWVuIG1vdmVkIHRvIGEgc2VwYXJhdGUgQVBJLiBVc2UgXFxgd2F0Y2hFZmZlY3QoZm4sIG9wdGlvbnM/KVxcYCBpbnN0ZWFkLiBcXGB3YXRjaFxcYCBub3cgb25seSBzdXBwb3J0cyBcXGB3YXRjaChzb3VyY2UsIGNiLCBvcHRpb25zPykgc2lnbmF0dXJlLmBcbiAgICApO1xuICB9XG4gIHJldHVybiBkb1dhdGNoKHNvdXJjZSwgY2IsIG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gZG9XYXRjaChzb3VyY2UsIGNiLCBvcHRpb25zID0gRU1QVFlfT0JKKSB7XG4gIGNvbnN0IHsgaW1tZWRpYXRlLCBkZWVwLCBmbHVzaCwgb25jZSB9ID0gb3B0aW9ucztcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWNiKSB7XG4gICAgaWYgKGltbWVkaWF0ZSAhPT0gdm9pZCAwKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGB3YXRjaCgpIFwiaW1tZWRpYXRlXCIgb3B0aW9uIGlzIG9ubHkgcmVzcGVjdGVkIHdoZW4gdXNpbmcgdGhlIHdhdGNoKHNvdXJjZSwgY2FsbGJhY2ssIG9wdGlvbnM/KSBzaWduYXR1cmUuYFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGRlZXAgIT09IHZvaWQgMCkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgd2F0Y2goKSBcImRlZXBcIiBvcHRpb24gaXMgb25seSByZXNwZWN0ZWQgd2hlbiB1c2luZyB0aGUgd2F0Y2goc291cmNlLCBjYWxsYmFjaywgb3B0aW9ucz8pIHNpZ25hdHVyZS5gXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAob25jZSAhPT0gdm9pZCAwKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGB3YXRjaCgpIFwib25jZVwiIG9wdGlvbiBpcyBvbmx5IHJlc3BlY3RlZCB3aGVuIHVzaW5nIHRoZSB3YXRjaChzb3VyY2UsIGNhbGxiYWNrLCBvcHRpb25zPykgc2lnbmF0dXJlLmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGNvbnN0IGJhc2VXYXRjaE9wdGlvbnMgPSBleHRlbmQoe30sIG9wdGlvbnMpO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkgYmFzZVdhdGNoT3B0aW9ucy5vbldhcm4gPSB3YXJuJDE7XG4gIGNvbnN0IHJ1bnNJbW1lZGlhdGVseSA9IGNiICYmIGltbWVkaWF0ZSB8fCAhY2IgJiYgZmx1c2ggIT09IFwicG9zdFwiO1xuICBsZXQgc3NyQ2xlYW51cDtcbiAgaWYgKGlzSW5TU1JDb21wb25lbnRTZXR1cCkge1xuICAgIGlmIChmbHVzaCA9PT0gXCJzeW5jXCIpIHtcbiAgICAgIGNvbnN0IGN0eCA9IHVzZVNTUkNvbnRleHQoKTtcbiAgICAgIHNzckNsZWFudXAgPSBjdHguX193YXRjaGVySGFuZGxlcyB8fCAoY3R4Ll9fd2F0Y2hlckhhbmRsZXMgPSBbXSk7XG4gICAgfSBlbHNlIGlmICghcnVuc0ltbWVkaWF0ZWx5KSB7XG4gICAgICBjb25zdCB3YXRjaFN0b3BIYW5kbGUgPSAoKSA9PiB7XG4gICAgICB9O1xuICAgICAgd2F0Y2hTdG9wSGFuZGxlLnN0b3AgPSBOT09QO1xuICAgICAgd2F0Y2hTdG9wSGFuZGxlLnJlc3VtZSA9IE5PT1A7XG4gICAgICB3YXRjaFN0b3BIYW5kbGUucGF1c2UgPSBOT09QO1xuICAgICAgcmV0dXJuIHdhdGNoU3RvcEhhbmRsZTtcbiAgICB9XG4gIH1cbiAgY29uc3QgaW5zdGFuY2UgPSBjdXJyZW50SW5zdGFuY2U7XG4gIGJhc2VXYXRjaE9wdGlvbnMuY2FsbCA9IChmbiwgdHlwZSwgYXJncykgPT4gY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoZm4sIGluc3RhbmNlLCB0eXBlLCBhcmdzKTtcbiAgbGV0IGlzUHJlID0gZmFsc2U7XG4gIGlmIChmbHVzaCA9PT0gXCJwb3N0XCIpIHtcbiAgICBiYXNlV2F0Y2hPcHRpb25zLnNjaGVkdWxlciA9IChqb2IpID0+IHtcbiAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChqb2IsIGluc3RhbmNlICYmIGluc3RhbmNlLnN1c3BlbnNlKTtcbiAgICB9O1xuICB9IGVsc2UgaWYgKGZsdXNoICE9PSBcInN5bmNcIikge1xuICAgIGlzUHJlID0gdHJ1ZTtcbiAgICBiYXNlV2F0Y2hPcHRpb25zLnNjaGVkdWxlciA9IChqb2IsIGlzRmlyc3RSdW4pID0+IHtcbiAgICAgIGlmIChpc0ZpcnN0UnVuKSB7XG4gICAgICAgIGpvYigpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcXVldWVKb2Ioam9iKTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG4gIGJhc2VXYXRjaE9wdGlvbnMuYXVnbWVudEpvYiA9IChqb2IpID0+IHtcbiAgICBpZiAoY2IpIHtcbiAgICAgIGpvYi5mbGFncyB8PSA0O1xuICAgIH1cbiAgICBpZiAoaXNQcmUpIHtcbiAgICAgIGpvYi5mbGFncyB8PSAyO1xuICAgICAgaWYgKGluc3RhbmNlKSB7XG4gICAgICAgIGpvYi5pZCA9IGluc3RhbmNlLnVpZDtcbiAgICAgICAgam9iLmkgPSBpbnN0YW5jZTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGNvbnN0IHdhdGNoSGFuZGxlID0gd2F0Y2gkMShzb3VyY2UsIGNiLCBiYXNlV2F0Y2hPcHRpb25zKTtcbiAgaWYgKGlzSW5TU1JDb21wb25lbnRTZXR1cCkge1xuICAgIGlmIChzc3JDbGVhbnVwKSB7XG4gICAgICBzc3JDbGVhbnVwLnB1c2god2F0Y2hIYW5kbGUpO1xuICAgIH0gZWxzZSBpZiAocnVuc0ltbWVkaWF0ZWx5KSB7XG4gICAgICB3YXRjaEhhbmRsZSgpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gd2F0Y2hIYW5kbGU7XG59XG5mdW5jdGlvbiBpbnN0YW5jZVdhdGNoKHNvdXJjZSwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgY29uc3QgcHVibGljVGhpcyA9IHRoaXMucHJveHk7XG4gIGNvbnN0IGdldHRlciA9IGlzU3RyaW5nKHNvdXJjZSkgPyBzb3VyY2UuaW5jbHVkZXMoXCIuXCIpID8gY3JlYXRlUGF0aEdldHRlcihwdWJsaWNUaGlzLCBzb3VyY2UpIDogKCkgPT4gcHVibGljVGhpc1tzb3VyY2VdIDogc291cmNlLmJpbmQocHVibGljVGhpcywgcHVibGljVGhpcyk7XG4gIGxldCBjYjtcbiAgaWYgKGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgY2IgPSB2YWx1ZTtcbiAgfSBlbHNlIHtcbiAgICBjYiA9IHZhbHVlLmhhbmRsZXI7XG4gICAgb3B0aW9ucyA9IHZhbHVlO1xuICB9XG4gIGNvbnN0IHJlc2V0ID0gc2V0Q3VycmVudEluc3RhbmNlKHRoaXMpO1xuICBjb25zdCByZXMgPSBkb1dhdGNoKGdldHRlciwgY2IuYmluZChwdWJsaWNUaGlzKSwgb3B0aW9ucyk7XG4gIHJlc2V0KCk7XG4gIHJldHVybiByZXM7XG59XG5mdW5jdGlvbiBjcmVhdGVQYXRoR2V0dGVyKGN0eCwgcGF0aCkge1xuICBjb25zdCBzZWdtZW50cyA9IHBhdGguc3BsaXQoXCIuXCIpO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGxldCBjdXIgPSBjdHg7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWdtZW50cy5sZW5ndGggJiYgY3VyOyBpKyspIHtcbiAgICAgIGN1ciA9IGN1cltzZWdtZW50c1tpXV07XG4gICAgfVxuICAgIHJldHVybiBjdXI7XG4gIH07XG59XG5cbmNvbnN0IHBlbmRpbmdNb3VudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IFRlbGVwb3J0RW5kS2V5ID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcIl92dGVcIik7XG5jb25zdCBpc1RlbGVwb3J0ID0gKHR5cGUpID0+IHR5cGUuX19pc1RlbGVwb3J0O1xuY29uc3QgaXNUZWxlcG9ydERpc2FibGVkID0gKHByb3BzKSA9PiBwcm9wcyAmJiAocHJvcHMuZGlzYWJsZWQgfHwgcHJvcHMuZGlzYWJsZWQgPT09IFwiXCIpO1xuY29uc3QgaXNUZWxlcG9ydERlZmVycmVkID0gKHByb3BzKSA9PiBwcm9wcyAmJiAocHJvcHMuZGVmZXIgfHwgcHJvcHMuZGVmZXIgPT09IFwiXCIpO1xuY29uc3QgaXNUYXJnZXRTVkcgPSAodGFyZ2V0KSA9PiB0eXBlb2YgU1ZHRWxlbWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiB0YXJnZXQgaW5zdGFuY2VvZiBTVkdFbGVtZW50O1xuY29uc3QgaXNUYXJnZXRNYXRoTUwgPSAodGFyZ2V0KSA9PiB0eXBlb2YgTWF0aE1MRWxlbWVudCA9PT0gXCJmdW5jdGlvblwiICYmIHRhcmdldCBpbnN0YW5jZW9mIE1hdGhNTEVsZW1lbnQ7XG5jb25zdCByZXNvbHZlVGFyZ2V0ID0gKHByb3BzLCBzZWxlY3QpID0+IHtcbiAgY29uc3QgdGFyZ2V0U2VsZWN0b3IgPSBwcm9wcyAmJiBwcm9wcy50bztcbiAgaWYgKGlzU3RyaW5nKHRhcmdldFNlbGVjdG9yKSkge1xuICAgIGlmICghc2VsZWN0KSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShcbiAgICAgICAgYEN1cnJlbnQgcmVuZGVyZXIgZG9lcyBub3Qgc3VwcG9ydCBzdHJpbmcgdGFyZ2V0IGZvciBUZWxlcG9ydHMuIChtaXNzaW5nIHF1ZXJ5U2VsZWN0b3IgcmVuZGVyZXIgb3B0aW9uKWBcbiAgICAgICk7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gc2VsZWN0KHRhcmdldFNlbGVjdG9yKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICF0YXJnZXQgJiYgIWlzVGVsZXBvcnREaXNhYmxlZChwcm9wcykpIHtcbiAgICAgICAgd2FybiQxKFxuICAgICAgICAgIGBGYWlsZWQgdG8gbG9jYXRlIFRlbGVwb3J0IHRhcmdldCB3aXRoIHNlbGVjdG9yIFwiJHt0YXJnZXRTZWxlY3Rvcn1cIi4gTm90ZSB0aGUgdGFyZ2V0IGVsZW1lbnQgbXVzdCBleGlzdCBiZWZvcmUgdGhlIGNvbXBvbmVudCBpcyBtb3VudGVkIC0gaS5lLiB0aGUgdGFyZ2V0IGNhbm5vdCBiZSByZW5kZXJlZCBieSB0aGUgY29tcG9uZW50IGl0c2VsZiwgYW5kIGlkZWFsbHkgc2hvdWxkIGJlIG91dHNpZGUgb2YgdGhlIGVudGlyZSBWdWUgY29tcG9uZW50IHRyZWUuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIXRhcmdldFNlbGVjdG9yICYmICFpc1RlbGVwb3J0RGlzYWJsZWQocHJvcHMpKSB7XG4gICAgICB3YXJuJDEoYEludmFsaWQgVGVsZXBvcnQgdGFyZ2V0OiAke3RhcmdldFNlbGVjdG9yfWApO1xuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0U2VsZWN0b3I7XG4gIH1cbn07XG5jb25zdCBUZWxlcG9ydEltcGwgPSB7XG4gIG5hbWU6IFwiVGVsZXBvcnRcIixcbiAgX19pc1RlbGVwb3J0OiB0cnVlLFxuICBwcm9jZXNzKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQsIGludGVybmFscykge1xuICAgIGNvbnN0IHtcbiAgICAgIG1jOiBtb3VudENoaWxkcmVuLFxuICAgICAgcGM6IHBhdGNoQ2hpbGRyZW4sXG4gICAgICBwYmM6IHBhdGNoQmxvY2tDaGlsZHJlbixcbiAgICAgIG86IHsgaW5zZXJ0LCBxdWVyeVNlbGVjdG9yLCBjcmVhdGVUZXh0LCBjcmVhdGVDb21tZW50LCBwYXJlbnROb2RlIH1cbiAgICB9ID0gaW50ZXJuYWxzO1xuICAgIGNvbnN0IGRpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKG4yLnByb3BzKTtcbiAgICBsZXQgeyBkeW5hbWljQ2hpbGRyZW4gfSA9IG4yO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzSG1yVXBkYXRpbmcpIHtcbiAgICAgIG9wdGltaXplZCA9IGZhbHNlO1xuICAgICAgZHluYW1pY0NoaWxkcmVuID0gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgbW91bnQgPSAodm5vZGUsIGNvbnRhaW5lcjIsIGFuY2hvcjIpID0+IHtcbiAgICAgIGlmICh2bm9kZS5zaGFwZUZsYWcgJiAxNikge1xuICAgICAgICBtb3VudENoaWxkcmVuKFxuICAgICAgICAgIHZub2RlLmNoaWxkcmVuLFxuICAgICAgICAgIGNvbnRhaW5lcjIsXG4gICAgICAgICAgYW5jaG9yMixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IG1vdW50VG9UYXJnZXQgPSAodm5vZGUgPSBuMikgPT4ge1xuICAgICAgY29uc3QgZGlzYWJsZWQyID0gaXNUZWxlcG9ydERpc2FibGVkKHZub2RlLnByb3BzKTtcbiAgICAgIGNvbnN0IHRhcmdldCA9IHZub2RlLnRhcmdldCA9IHJlc29sdmVUYXJnZXQodm5vZGUucHJvcHMsIHF1ZXJ5U2VsZWN0b3IpO1xuICAgICAgY29uc3QgdGFyZ2V0QW5jaG9yID0gcHJlcGFyZUFuY2hvcih0YXJnZXQsIHZub2RlLCBjcmVhdGVUZXh0LCBpbnNlcnQpO1xuICAgICAgaWYgKHRhcmdldCkge1xuICAgICAgICBpZiAobmFtZXNwYWNlICE9PSBcInN2Z1wiICYmIGlzVGFyZ2V0U1ZHKHRhcmdldCkpIHtcbiAgICAgICAgICBuYW1lc3BhY2UgPSBcInN2Z1wiO1xuICAgICAgICB9IGVsc2UgaWYgKG5hbWVzcGFjZSAhPT0gXCJtYXRobWxcIiAmJiBpc1RhcmdldE1hdGhNTCh0YXJnZXQpKSB7XG4gICAgICAgICAgbmFtZXNwYWNlID0gXCJtYXRobWxcIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGFyZW50Q29tcG9uZW50ICYmIHBhcmVudENvbXBvbmVudC5pc0NFKSB7XG4gICAgICAgICAgKHBhcmVudENvbXBvbmVudC5jZS5fdGVsZXBvcnRUYXJnZXRzIHx8IChwYXJlbnRDb21wb25lbnQuY2UuX3RlbGVwb3J0VGFyZ2V0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpKS5hZGQodGFyZ2V0KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRpc2FibGVkMikge1xuICAgICAgICAgIG1vdW50KHZub2RlLCB0YXJnZXQsIHRhcmdldEFuY2hvcik7XG4gICAgICAgICAgdXBkYXRlQ3NzVmFycyh2bm9kZSwgZmFsc2UpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWRpc2FibGVkMikge1xuICAgICAgICB3YXJuJDEoXCJJbnZhbGlkIFRlbGVwb3J0IHRhcmdldCBvbiBtb3VudDpcIiwgdGFyZ2V0LCBgKCR7dHlwZW9mIHRhcmdldH0pYCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBxdWV1ZVBlbmRpbmdNb3VudCA9ICh2bm9kZSkgPT4ge1xuICAgICAgY29uc3QgbW91bnRKb2IgPSAoKSA9PiB7XG4gICAgICAgIGlmIChwZW5kaW5nTW91bnRzLmdldCh2bm9kZSkgIT09IG1vdW50Sm9iKSByZXR1cm47XG4gICAgICAgIHBlbmRpbmdNb3VudHMuZGVsZXRlKHZub2RlKTtcbiAgICAgICAgaWYgKGlzVGVsZXBvcnREaXNhYmxlZCh2bm9kZS5wcm9wcykpIHtcbiAgICAgICAgICBjb25zdCBtb3VudENvbnRhaW5lciA9IHBhcmVudE5vZGUodm5vZGUuZWwpIHx8IGNvbnRhaW5lcjtcbiAgICAgICAgICBtb3VudCh2bm9kZSwgbW91bnRDb250YWluZXIsIHZub2RlLmFuY2hvcik7XG4gICAgICAgICAgdXBkYXRlQ3NzVmFycyh2bm9kZSwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgbW91bnRUb1RhcmdldCh2bm9kZSk7XG4gICAgICB9O1xuICAgICAgcGVuZGluZ01vdW50cy5zZXQodm5vZGUsIG1vdW50Sm9iKTtcbiAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChtb3VudEpvYiwgcGFyZW50U3VzcGVuc2UpO1xuICAgIH07XG4gICAgaWYgKG4xID09IG51bGwpIHtcbiAgICAgIGNvbnN0IHBsYWNlaG9sZGVyID0gbjIuZWwgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gY3JlYXRlQ29tbWVudChcInRlbGVwb3J0IHN0YXJ0XCIpIDogY3JlYXRlVGV4dChcIlwiKTtcbiAgICAgIGNvbnN0IG1haW5BbmNob3IgPSBuMi5hbmNob3IgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gY3JlYXRlQ29tbWVudChcInRlbGVwb3J0IGVuZFwiKSA6IGNyZWF0ZVRleHQoXCJcIik7XG4gICAgICBpbnNlcnQocGxhY2Vob2xkZXIsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgIGluc2VydChtYWluQW5jaG9yLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICBpZiAoaXNUZWxlcG9ydERlZmVycmVkKG4yLnByb3BzKSB8fCBwYXJlbnRTdXNwZW5zZSAmJiBwYXJlbnRTdXNwZW5zZS5wZW5kaW5nQnJhbmNoKSB7XG4gICAgICAgIHF1ZXVlUGVuZGluZ01vdW50KG4yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgIG1vdW50KG4yLCBjb250YWluZXIsIG1haW5BbmNob3IpO1xuICAgICAgICB1cGRhdGVDc3NWYXJzKG4yLCB0cnVlKTtcbiAgICAgIH1cbiAgICAgIG1vdW50VG9UYXJnZXQoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbjIuZWwgPSBuMS5lbDtcbiAgICAgIGNvbnN0IG1haW5BbmNob3IgPSBuMi5hbmNob3IgPSBuMS5hbmNob3I7XG4gICAgICBjb25zdCBwZW5kaW5nTW91bnQgPSBwZW5kaW5nTW91bnRzLmdldChuMSk7XG4gICAgICBpZiAocGVuZGluZ01vdW50KSB7XG4gICAgICAgIHBlbmRpbmdNb3VudC5mbGFncyB8PSA4O1xuICAgICAgICBwZW5kaW5nTW91bnRzLmRlbGV0ZShuMSk7XG4gICAgICAgIHF1ZXVlUGVuZGluZ01vdW50KG4yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbjIudGFyZ2V0U3RhcnQgPSBuMS50YXJnZXRTdGFydDtcbiAgICAgIGNvbnN0IHRhcmdldCA9IG4yLnRhcmdldCA9IG4xLnRhcmdldDtcbiAgICAgIGNvbnN0IHRhcmdldEFuY2hvciA9IG4yLnRhcmdldEFuY2hvciA9IG4xLnRhcmdldEFuY2hvcjtcbiAgICAgIGNvbnN0IHdhc0Rpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKG4xLnByb3BzKTtcbiAgICAgIGNvbnN0IGN1cnJlbnRDb250YWluZXIgPSB3YXNEaXNhYmxlZCA/IGNvbnRhaW5lciA6IHRhcmdldDtcbiAgICAgIGNvbnN0IGN1cnJlbnRBbmNob3IgPSB3YXNEaXNhYmxlZCA/IG1haW5BbmNob3IgOiB0YXJnZXRBbmNob3I7XG4gICAgICBpZiAobmFtZXNwYWNlID09PSBcInN2Z1wiIHx8IGlzVGFyZ2V0U1ZHKHRhcmdldCkpIHtcbiAgICAgICAgbmFtZXNwYWNlID0gXCJzdmdcIjtcbiAgICAgIH0gZWxzZSBpZiAobmFtZXNwYWNlID09PSBcIm1hdGhtbFwiIHx8IGlzVGFyZ2V0TWF0aE1MKHRhcmdldCkpIHtcbiAgICAgICAgbmFtZXNwYWNlID0gXCJtYXRobWxcIjtcbiAgICAgIH1cbiAgICAgIGlmIChkeW5hbWljQ2hpbGRyZW4pIHtcbiAgICAgICAgcGF0Y2hCbG9ja0NoaWxkcmVuKFxuICAgICAgICAgIG4xLmR5bmFtaWNDaGlsZHJlbixcbiAgICAgICAgICBkeW5hbWljQ2hpbGRyZW4sXG4gICAgICAgICAgY3VycmVudENvbnRhaW5lcixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkc1xuICAgICAgICApO1xuICAgICAgICB0cmF2ZXJzZVN0YXRpY0NoaWxkcmVuKG4xLCBuMiwgISEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpO1xuICAgICAgfSBlbHNlIGlmICghb3B0aW1pemVkKSB7XG4gICAgICAgIHBhdGNoQ2hpbGRyZW4oXG4gICAgICAgICAgbjEsXG4gICAgICAgICAgbjIsXG4gICAgICAgICAgY3VycmVudENvbnRhaW5lcixcbiAgICAgICAgICBjdXJyZW50QW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIGZhbHNlXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgaWYgKCF3YXNEaXNhYmxlZCkge1xuICAgICAgICAgIG1vdmVUZWxlcG9ydChcbiAgICAgICAgICAgIG4yLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgbWFpbkFuY2hvcixcbiAgICAgICAgICAgIGludGVybmFscyxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChuMi5wcm9wcyAmJiBuMS5wcm9wcyAmJiBuMi5wcm9wcy50byAhPT0gbjEucHJvcHMudG8pIHtcbiAgICAgICAgICAgIG4yLnByb3BzLnRvID0gbjEucHJvcHMudG87XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoKG4yLnByb3BzICYmIG4yLnByb3BzLnRvKSAhPT0gKG4xLnByb3BzICYmIG4xLnByb3BzLnRvKSkge1xuICAgICAgICAgIGNvbnN0IG5leHRUYXJnZXQgPSByZXNvbHZlVGFyZ2V0KG4yLnByb3BzLCBxdWVyeVNlbGVjdG9yKTtcbiAgICAgICAgICBpZiAobmV4dFRhcmdldCkge1xuICAgICAgICAgICAgbjIudGFyZ2V0ID0gbmV4dFRhcmdldDtcbiAgICAgICAgICAgIG1vdmVUZWxlcG9ydChcbiAgICAgICAgICAgICAgbjIsXG4gICAgICAgICAgICAgIG5leHRUYXJnZXQsXG4gICAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICAgIGludGVybmFscyxcbiAgICAgICAgICAgICAgMFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgICAgXCJJbnZhbGlkIFRlbGVwb3J0IHRhcmdldCBvbiB1cGRhdGU6XCIsXG4gICAgICAgICAgICAgIHRhcmdldCxcbiAgICAgICAgICAgICAgYCgke3R5cGVvZiB0YXJnZXR9KWBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHdhc0Rpc2FibGVkKSB7XG4gICAgICAgICAgbW92ZVRlbGVwb3J0KFxuICAgICAgICAgICAgbjIsXG4gICAgICAgICAgICB0YXJnZXQsXG4gICAgICAgICAgICB0YXJnZXRBbmNob3IsXG4gICAgICAgICAgICBpbnRlcm5hbHMsXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdXBkYXRlQ3NzVmFycyhuMiwgZGlzYWJsZWQpO1xuICAgIH1cbiAgfSxcbiAgcmVtb3ZlKHZub2RlLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCB7IHVtOiB1bm1vdW50LCBvOiB7IHJlbW92ZTogaG9zdFJlbW92ZSB9IH0sIGRvUmVtb3ZlKSB7XG4gICAgY29uc3Qge1xuICAgICAgc2hhcGVGbGFnLFxuICAgICAgY2hpbGRyZW4sXG4gICAgICBhbmNob3IsXG4gICAgICB0YXJnZXRTdGFydCxcbiAgICAgIHRhcmdldEFuY2hvcixcbiAgICAgIHRhcmdldCxcbiAgICAgIHByb3BzXG4gICAgfSA9IHZub2RlO1xuICAgIGNvbnN0IGRpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKHByb3BzKTtcbiAgICBjb25zdCBzaG91bGRSZW1vdmUgPSBkb1JlbW92ZSB8fCAhZGlzYWJsZWQ7XG4gICAgY29uc3QgcGVuZGluZ01vdW50ID0gcGVuZGluZ01vdW50cy5nZXQodm5vZGUpO1xuICAgIGlmIChwZW5kaW5nTW91bnQpIHtcbiAgICAgIHBlbmRpbmdNb3VudC5mbGFncyB8PSA4O1xuICAgICAgcGVuZGluZ01vdW50cy5kZWxldGUodm5vZGUpO1xuICAgIH1cbiAgICBpZiAodGFyZ2V0KSB7XG4gICAgICBob3N0UmVtb3ZlKHRhcmdldFN0YXJ0KTtcbiAgICAgIGhvc3RSZW1vdmUodGFyZ2V0QW5jaG9yKTtcbiAgICB9XG4gICAgZG9SZW1vdmUgJiYgaG9zdFJlbW92ZShhbmNob3IpO1xuICAgIGlmICghcGVuZGluZ01vdW50ICYmIChkaXNhYmxlZCB8fCB0YXJnZXQpICYmIHNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgICAgIHVubW91bnQoXG4gICAgICAgICAgY2hpbGQsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIHNob3VsZFJlbW92ZSxcbiAgICAgICAgICAhIWNoaWxkLmR5bmFtaWNDaGlsZHJlblxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfSxcbiAgbW92ZTogbW92ZVRlbGVwb3J0LFxuICBoeWRyYXRlOiBoeWRyYXRlVGVsZXBvcnRcbn07XG5mdW5jdGlvbiBtb3ZlVGVsZXBvcnQodm5vZGUsIGNvbnRhaW5lciwgcGFyZW50QW5jaG9yLCB7IG86IHsgaW5zZXJ0IH0sIG06IG1vdmUgfSwgbW92ZVR5cGUgPSAyKSB7XG4gIGlmIChtb3ZlVHlwZSA9PT0gMCkge1xuICAgIGluc2VydCh2bm9kZS50YXJnZXRBbmNob3IsIGNvbnRhaW5lciwgcGFyZW50QW5jaG9yKTtcbiAgfVxuICBjb25zdCB7IGVsLCBhbmNob3IsIHNoYXBlRmxhZywgY2hpbGRyZW4sIHByb3BzIH0gPSB2bm9kZTtcbiAgY29uc3QgaXNSZW9yZGVyID0gbW92ZVR5cGUgPT09IDI7XG4gIGlmIChpc1Jlb3JkZXIpIHtcbiAgICBpbnNlcnQoZWwsIGNvbnRhaW5lciwgcGFyZW50QW5jaG9yKTtcbiAgfVxuICBpZiAoIXBlbmRpbmdNb3VudHMuaGFzKHZub2RlKSAmJiAoIWlzUmVvcmRlciB8fCBpc1RlbGVwb3J0RGlzYWJsZWQocHJvcHMpKSkge1xuICAgIGlmIChzaGFwZUZsYWcgJiAxNikge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgICBtb3ZlKFxuICAgICAgICAgIGNoaWxkcmVuW2ldLFxuICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICBwYXJlbnRBbmNob3IsXG4gICAgICAgICAgMlxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoaXNSZW9yZGVyKSB7XG4gICAgaW5zZXJ0KGFuY2hvciwgY29udGFpbmVyLCBwYXJlbnRBbmNob3IpO1xuICB9XG59XG5mdW5jdGlvbiBoeWRyYXRlVGVsZXBvcnQobm9kZSwgdm5vZGUsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkLCB7XG4gIG86IHsgbmV4dFNpYmxpbmcsIHBhcmVudE5vZGUsIHF1ZXJ5U2VsZWN0b3IsIGluc2VydCwgY3JlYXRlVGV4dCB9XG59LCBoeWRyYXRlQ2hpbGRyZW4pIHtcbiAgZnVuY3Rpb24gaHlkcmF0ZUFuY2hvcih0YXJnZXQyLCB0YXJnZXROb2RlKSB7XG4gICAgbGV0IHRhcmdldEFuY2hvciA9IHRhcmdldE5vZGU7XG4gICAgd2hpbGUgKHRhcmdldEFuY2hvcikge1xuICAgICAgaWYgKHRhcmdldEFuY2hvciAmJiB0YXJnZXRBbmNob3Iubm9kZVR5cGUgPT09IDgpIHtcbiAgICAgICAgaWYgKHRhcmdldEFuY2hvci5kYXRhID09PSBcInRlbGVwb3J0IHN0YXJ0IGFuY2hvclwiKSB7XG4gICAgICAgICAgdm5vZGUudGFyZ2V0U3RhcnQgPSB0YXJnZXRBbmNob3I7XG4gICAgICAgIH0gZWxzZSBpZiAodGFyZ2V0QW5jaG9yLmRhdGEgPT09IFwidGVsZXBvcnQgYW5jaG9yXCIpIHtcbiAgICAgICAgICB2bm9kZS50YXJnZXRBbmNob3IgPSB0YXJnZXRBbmNob3I7XG4gICAgICAgICAgdGFyZ2V0Mi5fbHBhID0gdm5vZGUudGFyZ2V0QW5jaG9yICYmIG5leHRTaWJsaW5nKHZub2RlLnRhcmdldEFuY2hvcik7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRhcmdldEFuY2hvciA9IG5leHRTaWJsaW5nKHRhcmdldEFuY2hvcik7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGh5ZHJhdGVEaXNhYmxlZFRlbGVwb3J0KG5vZGUyLCB2bm9kZTIpIHtcbiAgICB2bm9kZTIuYW5jaG9yID0gaHlkcmF0ZUNoaWxkcmVuKFxuICAgICAgbmV4dFNpYmxpbmcobm9kZTIpLFxuICAgICAgdm5vZGUyLFxuICAgICAgcGFyZW50Tm9kZShub2RlMiksXG4gICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgIG9wdGltaXplZFxuICAgICk7XG4gIH1cbiAgY29uc3QgdGFyZ2V0ID0gdm5vZGUudGFyZ2V0ID0gcmVzb2x2ZVRhcmdldChcbiAgICB2bm9kZS5wcm9wcyxcbiAgICBxdWVyeVNlbGVjdG9yXG4gICk7XG4gIGNvbnN0IGRpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKHZub2RlLnByb3BzKTtcbiAgaWYgKHRhcmdldCkge1xuICAgIGNvbnN0IHRhcmdldE5vZGUgPSB0YXJnZXQuX2xwYSB8fCB0YXJnZXQuZmlyc3RDaGlsZDtcbiAgICBpZiAodm5vZGUuc2hhcGVGbGFnICYgMTYpIHtcbiAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICBoeWRyYXRlRGlzYWJsZWRUZWxlcG9ydChub2RlLCB2bm9kZSk7XG4gICAgICAgIGh5ZHJhdGVBbmNob3IodGFyZ2V0LCB0YXJnZXROb2RlKTtcbiAgICAgICAgaWYgKCF2bm9kZS50YXJnZXRBbmNob3IpIHtcbiAgICAgICAgICBwcmVwYXJlQW5jaG9yKFxuICAgICAgICAgICAgdGFyZ2V0LFxuICAgICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgICBjcmVhdGVUZXh0LFxuICAgICAgICAgICAgaW5zZXJ0LFxuICAgICAgICAgICAgLy8gaWYgdGFyZ2V0IGlzIHRoZSBzYW1lIGFzIHRoZSBtYWluIHZpZXcsIGluc2VydCBhbmNob3JzIGJlZm9yZSBjdXJyZW50IG5vZGVcbiAgICAgICAgICAgIC8vIHRvIGF2b2lkIGh5ZHJhdGluZyBtaXNtYXRjaFxuICAgICAgICAgICAgcGFyZW50Tm9kZShub2RlKSA9PT0gdGFyZ2V0ID8gbm9kZSA6IG51bGxcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2bm9kZS5hbmNob3IgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgICAgaHlkcmF0ZUFuY2hvcih0YXJnZXQsIHRhcmdldE5vZGUpO1xuICAgICAgICBpZiAoIXZub2RlLnRhcmdldEFuY2hvcikge1xuICAgICAgICAgIHByZXBhcmVBbmNob3IodGFyZ2V0LCB2bm9kZSwgY3JlYXRlVGV4dCwgaW5zZXJ0KTtcbiAgICAgICAgfVxuICAgICAgICBoeWRyYXRlQ2hpbGRyZW4oXG4gICAgICAgICAgdGFyZ2V0Tm9kZSAmJiBuZXh0U2libGluZyh0YXJnZXROb2RlKSxcbiAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICB0YXJnZXQsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdXBkYXRlQ3NzVmFycyh2bm9kZSwgZGlzYWJsZWQpO1xuICB9IGVsc2UgaWYgKGRpc2FibGVkKSB7XG4gICAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICBoeWRyYXRlRGlzYWJsZWRUZWxlcG9ydChub2RlLCB2bm9kZSk7XG4gICAgICB2bm9kZS50YXJnZXRTdGFydCA9IG5vZGU7XG4gICAgICB2bm9kZS50YXJnZXRBbmNob3IgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHZub2RlLmFuY2hvciAmJiBuZXh0U2libGluZyh2bm9kZS5hbmNob3IpO1xufVxuY29uc3QgVGVsZXBvcnQgPSBUZWxlcG9ydEltcGw7XG5mdW5jdGlvbiB1cGRhdGVDc3NWYXJzKHZub2RlLCBpc0Rpc2FibGVkKSB7XG4gIGNvbnN0IGN0eCA9IHZub2RlLmN0eDtcbiAgaWYgKGN0eCAmJiBjdHgudXQpIHtcbiAgICBsZXQgbm9kZSwgYW5jaG9yO1xuICAgIGlmIChpc0Rpc2FibGVkKSB7XG4gICAgICBub2RlID0gdm5vZGUuZWw7XG4gICAgICBhbmNob3IgPSB2bm9kZS5hbmNob3I7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5vZGUgPSB2bm9kZS50YXJnZXRTdGFydDtcbiAgICAgIGFuY2hvciA9IHZub2RlLnRhcmdldEFuY2hvcjtcbiAgICB9XG4gICAgd2hpbGUgKG5vZGUgJiYgbm9kZSAhPT0gYW5jaG9yKSB7XG4gICAgICBpZiAobm9kZS5ub2RlVHlwZSA9PT0gMSkgbm9kZS5zZXRBdHRyaWJ1dGUoXCJkYXRhLXYtb3duZXJcIiwgY3R4LnVpZCk7XG4gICAgICBub2RlID0gbm9kZS5uZXh0U2libGluZztcbiAgICB9XG4gICAgY3R4LnV0KCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHByZXBhcmVBbmNob3IodGFyZ2V0LCB2bm9kZSwgY3JlYXRlVGV4dCwgaW5zZXJ0LCBhbmNob3IgPSBudWxsKSB7XG4gIGNvbnN0IHRhcmdldFN0YXJ0ID0gdm5vZGUudGFyZ2V0U3RhcnQgPSBjcmVhdGVUZXh0KFwiXCIpO1xuICBjb25zdCB0YXJnZXRBbmNob3IgPSB2bm9kZS50YXJnZXRBbmNob3IgPSBjcmVhdGVUZXh0KFwiXCIpO1xuICB0YXJnZXRTdGFydFtUZWxlcG9ydEVuZEtleV0gPSB0YXJnZXRBbmNob3I7XG4gIGlmICh0YXJnZXQpIHtcbiAgICBpbnNlcnQodGFyZ2V0U3RhcnQsIHRhcmdldCwgYW5jaG9yKTtcbiAgICBpbnNlcnQodGFyZ2V0QW5jaG9yLCB0YXJnZXQsIGFuY2hvcik7XG4gIH1cbiAgcmV0dXJuIHRhcmdldEFuY2hvcjtcbn1cblxuY29uc3QgbGVhdmVDYktleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfbGVhdmVDYlwiKTtcbmNvbnN0IGVudGVyQ2JLZXkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwiX2VudGVyQ2JcIik7XG5mdW5jdGlvbiB1c2VUcmFuc2l0aW9uU3RhdGUoKSB7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGlzTW91bnRlZDogZmFsc2UsXG4gICAgaXNMZWF2aW5nOiBmYWxzZSxcbiAgICBpc1VubW91bnRpbmc6IGZhbHNlLFxuICAgIGxlYXZpbmdWTm9kZXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKClcbiAgfTtcbiAgb25Nb3VudGVkKCgpID0+IHtcbiAgICBzdGF0ZS5pc01vdW50ZWQgPSB0cnVlO1xuICB9KTtcbiAgb25CZWZvcmVVbm1vdW50KCgpID0+IHtcbiAgICBzdGF0ZS5pc1VubW91bnRpbmcgPSB0cnVlO1xuICB9KTtcbiAgcmV0dXJuIHN0YXRlO1xufVxuY29uc3QgVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IgPSBbRnVuY3Rpb24sIEFycmF5XTtcbmNvbnN0IEJhc2VUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzID0ge1xuICBtb2RlOiBTdHJpbmcsXG4gIGFwcGVhcjogQm9vbGVhbixcbiAgcGVyc2lzdGVkOiBCb29sZWFuLFxuICAvLyBlbnRlclxuICBvbkJlZm9yZUVudGVyOiBUcmFuc2l0aW9uSG9va1ZhbGlkYXRvcixcbiAgb25FbnRlcjogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uQWZ0ZXJFbnRlcjogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uRW50ZXJDYW5jZWxsZWQ6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICAvLyBsZWF2ZVxuICBvbkJlZm9yZUxlYXZlOiBUcmFuc2l0aW9uSG9va1ZhbGlkYXRvcixcbiAgb25MZWF2ZTogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uQWZ0ZXJMZWF2ZTogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uTGVhdmVDYW5jZWxsZWQ6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICAvLyBhcHBlYXJcbiAgb25CZWZvcmVBcHBlYXI6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICBvbkFwcGVhcjogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uQWZ0ZXJBcHBlYXI6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICBvbkFwcGVhckNhbmNlbGxlZDogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3Jcbn07XG5jb25zdCByZWN1cnNpdmVHZXRTdWJ0cmVlID0gKGluc3RhbmNlKSA9PiB7XG4gIGNvbnN0IHN1YlRyZWUgPSBpbnN0YW5jZS5zdWJUcmVlO1xuICByZXR1cm4gc3ViVHJlZS5jb21wb25lbnQgPyByZWN1cnNpdmVHZXRTdWJ0cmVlKHN1YlRyZWUuY29tcG9uZW50KSA6IHN1YlRyZWU7XG59O1xuY29uc3QgQmFzZVRyYW5zaXRpb25JbXBsID0ge1xuICBuYW1lOiBgQmFzZVRyYW5zaXRpb25gLFxuICBwcm9wczogQmFzZVRyYW5zaXRpb25Qcm9wc1ZhbGlkYXRvcnMsXG4gIHNldHVwKHByb3BzLCB7IHNsb3RzIH0pIHtcbiAgICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIGNvbnN0IHN0YXRlID0gdXNlVHJhbnNpdGlvblN0YXRlKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNvbnN0IGNoaWxkcmVuID0gc2xvdHMuZGVmYXVsdCAmJiBnZXRUcmFuc2l0aW9uUmF3Q2hpbGRyZW4oc2xvdHMuZGVmYXVsdCgpLCB0cnVlKTtcbiAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoID8gZmluZE5vbkNvbW1lbnRDaGlsZChjaGlsZHJlbikgOiAoXG4gICAgICAgIC8vIEtlZXAgZXhwbGljaXQgZGVmYXVsdC1zbG90IGNvbmRpdGlvbmFscyBvbiB0aGUgc2FtZSB0cmFuc2l0aW9uIHBhdGhcbiAgICAgICAgLy8gYXMgcmVndWxhciB2LWlmIGJyYW5jaGVzLCB3aGljaCByZW5kZXIgYSBjb21tZW50IHBsYWNlaG9sZGVyLlxuICAgICAgICBpbnN0YW5jZS5zdWJUcmVlID8gY3JlYXRlQ29tbWVudFZOb2RlKCkgOiB2b2lkIDBcbiAgICAgICk7XG4gICAgICBpZiAoIWNoaWxkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJhd1Byb3BzID0gdG9SYXcocHJvcHMpO1xuICAgICAgY29uc3QgeyBtb2RlIH0gPSByYXdQcm9wcztcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIG1vZGUgJiYgbW9kZSAhPT0gXCJpbi1vdXRcIiAmJiBtb2RlICE9PSBcIm91dC1pblwiICYmIG1vZGUgIT09IFwiZGVmYXVsdFwiKSB7XG4gICAgICAgIHdhcm4kMShgaW52YWxpZCA8dHJhbnNpdGlvbj4gbW9kZTogJHttb2RlfWApO1xuICAgICAgfVxuICAgICAgaWYgKHN0YXRlLmlzTGVhdmluZykge1xuICAgICAgICByZXR1cm4gZW1wdHlQbGFjZWhvbGRlcihjaGlsZCk7XG4gICAgICB9XG4gICAgICBjb25zdCBpbm5lckNoaWxkID0gZ2V0SW5uZXJDaGlsZCQxKGNoaWxkKTtcbiAgICAgIGlmICghaW5uZXJDaGlsZCkge1xuICAgICAgICByZXR1cm4gZW1wdHlQbGFjZWhvbGRlcihjaGlsZCk7XG4gICAgICB9XG4gICAgICBsZXQgZW50ZXJIb29rcyA9IHJlc29sdmVUcmFuc2l0aW9uSG9va3MoXG4gICAgICAgIGlubmVyQ2hpbGQsXG4gICAgICAgIHJhd1Byb3BzLFxuICAgICAgICBzdGF0ZSxcbiAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgIC8vICMxMTA2MSwgZW5zdXJlIGVudGVySG9va3MgaXMgZnJlc2ggYWZ0ZXIgY2xvbmVcbiAgICAgICAgKGhvb2tzKSA9PiBlbnRlckhvb2tzID0gaG9va3NcbiAgICAgICk7XG4gICAgICBpZiAoaW5uZXJDaGlsZC50eXBlICE9PSBDb21tZW50KSB7XG4gICAgICAgIHNldFRyYW5zaXRpb25Ib29rcyhpbm5lckNoaWxkLCBlbnRlckhvb2tzKTtcbiAgICAgIH1cbiAgICAgIGxldCBvbGRJbm5lckNoaWxkID0gaW5zdGFuY2Uuc3ViVHJlZSAmJiBnZXRJbm5lckNoaWxkJDEoaW5zdGFuY2Uuc3ViVHJlZSk7XG4gICAgICBpZiAob2xkSW5uZXJDaGlsZCAmJiBvbGRJbm5lckNoaWxkLnR5cGUgIT09IENvbW1lbnQgJiYgIWlzU2FtZVZOb2RlVHlwZShvbGRJbm5lckNoaWxkLCBpbm5lckNoaWxkKSAmJiByZWN1cnNpdmVHZXRTdWJ0cmVlKGluc3RhbmNlKS50eXBlICE9PSBDb21tZW50KSB7XG4gICAgICAgIGxldCBsZWF2aW5nSG9va3MgPSByZXNvbHZlVHJhbnNpdGlvbkhvb2tzKFxuICAgICAgICAgIG9sZElubmVyQ2hpbGQsXG4gICAgICAgICAgcmF3UHJvcHMsXG4gICAgICAgICAgc3RhdGUsXG4gICAgICAgICAgaW5zdGFuY2VcbiAgICAgICAgKTtcbiAgICAgICAgc2V0VHJhbnNpdGlvbkhvb2tzKG9sZElubmVyQ2hpbGQsIGxlYXZpbmdIb29rcyk7XG4gICAgICAgIGlmIChtb2RlID09PSBcIm91dC1pblwiICYmIGlubmVyQ2hpbGQudHlwZSAhPT0gQ29tbWVudCkge1xuICAgICAgICAgIHN0YXRlLmlzTGVhdmluZyA9IHRydWU7XG4gICAgICAgICAgbGVhdmluZ0hvb2tzLmFmdGVyTGVhdmUgPSAoKSA9PiB7XG4gICAgICAgICAgICBzdGF0ZS5pc0xlYXZpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmICghKGluc3RhbmNlLmpvYi5mbGFncyAmIDgpKSB7XG4gICAgICAgICAgICAgIGluc3RhbmNlLnVwZGF0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVsZXRlIGxlYXZpbmdIb29rcy5hZnRlckxlYXZlO1xuICAgICAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHJldHVybiBlbXB0eVBsYWNlaG9sZGVyKGNoaWxkKTtcbiAgICAgICAgfSBlbHNlIGlmIChtb2RlID09PSBcImluLW91dFwiICYmIGlubmVyQ2hpbGQudHlwZSAhPT0gQ29tbWVudCkge1xuICAgICAgICAgIGxlYXZpbmdIb29rcy5kZWxheUxlYXZlID0gKGVsLCBlYXJseVJlbW92ZSwgZGVsYXllZExlYXZlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBsZWF2aW5nVk5vZGVzQ2FjaGUgPSBnZXRMZWF2aW5nTm9kZXNGb3JUeXBlKFxuICAgICAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICAgICAgb2xkSW5uZXJDaGlsZFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGxlYXZpbmdWTm9kZXNDYWNoZVtTdHJpbmcob2xkSW5uZXJDaGlsZC5rZXkpXSA9IG9sZElubmVyQ2hpbGQ7XG4gICAgICAgICAgICBlbFtsZWF2ZUNiS2V5XSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgZWFybHlSZW1vdmUoKTtcbiAgICAgICAgICAgICAgZWxbbGVhdmVDYktleV0gPSB2b2lkIDA7XG4gICAgICAgICAgICAgIGRlbGV0ZSBlbnRlckhvb2tzLmRlbGF5ZWRMZWF2ZTtcbiAgICAgICAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBlbnRlckhvb2tzLmRlbGF5ZWRMZWF2ZSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgZGVsYXllZExlYXZlKCk7XG4gICAgICAgICAgICAgIGRlbGV0ZSBlbnRlckhvb2tzLmRlbGF5ZWRMZWF2ZTtcbiAgICAgICAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvbGRJbm5lckNoaWxkID0gdm9pZCAwO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKG9sZElubmVyQ2hpbGQpIHtcbiAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjaGlsZDtcbiAgICB9O1xuICB9XG59O1xuZnVuY3Rpb24gZmluZE5vbkNvbW1lbnRDaGlsZChjaGlsZHJlbikge1xuICBsZXQgY2hpbGQgPSBjaGlsZHJlblswXTtcbiAgaWYgKGNoaWxkcmVuLmxlbmd0aCA+IDEpIHtcbiAgICBsZXQgaGFzRm91bmQgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IGMgb2YgY2hpbGRyZW4pIHtcbiAgICAgIGlmIChjLnR5cGUgIT09IENvbW1lbnQpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaGFzRm91bmQpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBcIjx0cmFuc2l0aW9uPiBjYW4gb25seSBiZSB1c2VkIG9uIGEgc2luZ2xlIGVsZW1lbnQgb3IgY29tcG9uZW50LiBVc2UgPHRyYW5zaXRpb24tZ3JvdXA+IGZvciBsaXN0cy5cIlxuICAgICAgICAgICk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2hpbGQgPSBjO1xuICAgICAgICBoYXNGb3VuZCA9IHRydWU7XG4gICAgICAgIGlmICghISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBjaGlsZDtcbn1cbmNvbnN0IEJhc2VUcmFuc2l0aW9uID0gQmFzZVRyYW5zaXRpb25JbXBsO1xuZnVuY3Rpb24gZ2V0TGVhdmluZ05vZGVzRm9yVHlwZShzdGF0ZSwgdm5vZGUpIHtcbiAgY29uc3QgeyBsZWF2aW5nVk5vZGVzIH0gPSBzdGF0ZTtcbiAgbGV0IGxlYXZpbmdWTm9kZXNDYWNoZSA9IGxlYXZpbmdWTm9kZXMuZ2V0KHZub2RlLnR5cGUpO1xuICBpZiAoIWxlYXZpbmdWTm9kZXNDYWNoZSkge1xuICAgIGxlYXZpbmdWTm9kZXNDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIGxlYXZpbmdWTm9kZXMuc2V0KHZub2RlLnR5cGUsIGxlYXZpbmdWTm9kZXNDYWNoZSk7XG4gIH1cbiAgcmV0dXJuIGxlYXZpbmdWTm9kZXNDYWNoZTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVUcmFuc2l0aW9uSG9va3Modm5vZGUsIHByb3BzLCBzdGF0ZSwgaW5zdGFuY2UsIHBvc3RDbG9uZSkge1xuICBjb25zdCB7XG4gICAgYXBwZWFyLFxuICAgIG1vZGUsXG4gICAgcGVyc2lzdGVkID0gZmFsc2UsXG4gICAgb25CZWZvcmVFbnRlcixcbiAgICBvbkVudGVyLFxuICAgIG9uQWZ0ZXJFbnRlcixcbiAgICBvbkVudGVyQ2FuY2VsbGVkLFxuICAgIG9uQmVmb3JlTGVhdmUsXG4gICAgb25MZWF2ZSxcbiAgICBvbkFmdGVyTGVhdmUsXG4gICAgb25MZWF2ZUNhbmNlbGxlZCxcbiAgICBvbkJlZm9yZUFwcGVhcixcbiAgICBvbkFwcGVhcixcbiAgICBvbkFmdGVyQXBwZWFyLFxuICAgIG9uQXBwZWFyQ2FuY2VsbGVkXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qga2V5ID0gU3RyaW5nKHZub2RlLmtleSk7XG4gIGNvbnN0IGxlYXZpbmdWTm9kZXNDYWNoZSA9IGdldExlYXZpbmdOb2Rlc0ZvclR5cGUoc3RhdGUsIHZub2RlKTtcbiAgY29uc3QgY2FsbEhvb2sgPSAoaG9vaywgYXJncykgPT4ge1xuICAgIGhvb2sgJiYgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoXG4gICAgICBob29rLFxuICAgICAgaW5zdGFuY2UsXG4gICAgICA5LFxuICAgICAgYXJnc1xuICAgICk7XG4gIH07XG4gIGNvbnN0IGNhbGxBc3luY0hvb2sgPSAoaG9vaywgYXJncykgPT4ge1xuICAgIGNvbnN0IGRvbmUgPSBhcmdzWzFdO1xuICAgIGNhbGxIb29rKGhvb2ssIGFyZ3MpO1xuICAgIGlmIChpc0FycmF5KGhvb2spKSB7XG4gICAgICBpZiAoaG9vay5ldmVyeSgoaG9vazIpID0+IGhvb2syLmxlbmd0aCA8PSAxKSkgZG9uZSgpO1xuICAgIH0gZWxzZSBpZiAoaG9vay5sZW5ndGggPD0gMSkge1xuICAgICAgZG9uZSgpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgaG9va3MgPSB7XG4gICAgbW9kZSxcbiAgICBwZXJzaXN0ZWQsXG4gICAgYmVmb3JlRW50ZXIoZWwpIHtcbiAgICAgIGxldCBob29rID0gb25CZWZvcmVFbnRlcjtcbiAgICAgIGlmICghc3RhdGUuaXNNb3VudGVkKSB7XG4gICAgICAgIGlmIChhcHBlYXIpIHtcbiAgICAgICAgICBob29rID0gb25CZWZvcmVBcHBlYXIgfHwgb25CZWZvcmVFbnRlcjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChlbFtsZWF2ZUNiS2V5XSkge1xuICAgICAgICBlbFtsZWF2ZUNiS2V5XShcbiAgICAgICAgICB0cnVlXG4gICAgICAgICAgLyogY2FuY2VsbGVkICovXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBjb25zdCBsZWF2aW5nVk5vZGUgPSBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5XTtcbiAgICAgIGlmIChsZWF2aW5nVk5vZGUgJiYgaXNTYW1lVk5vZGVUeXBlKHZub2RlLCBsZWF2aW5nVk5vZGUpICYmIGxlYXZpbmdWTm9kZS5lbFtsZWF2ZUNiS2V5XSkge1xuICAgICAgICBsZWF2aW5nVk5vZGUuZWxbbGVhdmVDYktleV0oKTtcbiAgICAgIH1cbiAgICAgIGNhbGxIb29rKGhvb2ssIFtlbF0pO1xuICAgIH0sXG4gICAgZW50ZXIoZWwpIHtcbiAgICAgIGlmICghaXNIbXJVcGRhdGluZyAmJiBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5XSA9PT0gdm5vZGUpIHJldHVybjtcbiAgICAgIGxldCBob29rID0gb25FbnRlcjtcbiAgICAgIGxldCBhZnRlckhvb2sgPSBvbkFmdGVyRW50ZXI7XG4gICAgICBsZXQgY2FuY2VsSG9vayA9IG9uRW50ZXJDYW5jZWxsZWQ7XG4gICAgICBpZiAoIXN0YXRlLmlzTW91bnRlZCkge1xuICAgICAgICBpZiAoYXBwZWFyKSB7XG4gICAgICAgICAgaG9vayA9IG9uQXBwZWFyIHx8IG9uRW50ZXI7XG4gICAgICAgICAgYWZ0ZXJIb29rID0gb25BZnRlckFwcGVhciB8fCBvbkFmdGVyRW50ZXI7XG4gICAgICAgICAgY2FuY2VsSG9vayA9IG9uQXBwZWFyQ2FuY2VsbGVkIHx8IG9uRW50ZXJDYW5jZWxsZWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBsZXQgY2FsbGVkID0gZmFsc2U7XG4gICAgICBlbFtlbnRlckNiS2V5XSA9IChjYW5jZWxsZWQpID0+IHtcbiAgICAgICAgaWYgKGNhbGxlZCkgcmV0dXJuO1xuICAgICAgICBjYWxsZWQgPSB0cnVlO1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgICAgY2FsbEhvb2soY2FuY2VsSG9vaywgW2VsXSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2FsbEhvb2soYWZ0ZXJIb29rLCBbZWxdKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaG9va3MuZGVsYXllZExlYXZlKSB7XG4gICAgICAgICAgaG9va3MuZGVsYXllZExlYXZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxbZW50ZXJDYktleV0gPSB2b2lkIDA7XG4gICAgICB9O1xuICAgICAgY29uc3QgZG9uZSA9IGVsW2VudGVyQ2JLZXldLmJpbmQobnVsbCwgZmFsc2UpO1xuICAgICAgaWYgKGhvb2spIHtcbiAgICAgICAgY2FsbEFzeW5jSG9vayhob29rLCBbZWwsIGRvbmVdKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRvbmUoKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGxlYXZlKGVsLCByZW1vdmUpIHtcbiAgICAgIGNvbnN0IGtleTIgPSBTdHJpbmcodm5vZGUua2V5KTtcbiAgICAgIGlmIChlbFtlbnRlckNiS2V5XSkge1xuICAgICAgICBlbFtlbnRlckNiS2V5XShcbiAgICAgICAgICB0cnVlXG4gICAgICAgICAgLyogY2FuY2VsbGVkICovXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoc3RhdGUuaXNVbm1vdW50aW5nKSB7XG4gICAgICAgIHJldHVybiByZW1vdmUoKTtcbiAgICAgIH1cbiAgICAgIGNhbGxIb29rKG9uQmVmb3JlTGVhdmUsIFtlbF0pO1xuICAgICAgbGV0IGNhbGxlZCA9IGZhbHNlO1xuICAgICAgZWxbbGVhdmVDYktleV0gPSAoY2FuY2VsbGVkKSA9PiB7XG4gICAgICAgIGlmIChjYWxsZWQpIHJldHVybjtcbiAgICAgICAgY2FsbGVkID0gdHJ1ZTtcbiAgICAgICAgcmVtb3ZlKCk7XG4gICAgICAgIGlmIChjYW5jZWxsZWQpIHtcbiAgICAgICAgICBjYWxsSG9vayhvbkxlYXZlQ2FuY2VsbGVkLCBbZWxdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjYWxsSG9vayhvbkFmdGVyTGVhdmUsIFtlbF0pO1xuICAgICAgICB9XG4gICAgICAgIGVsW2xlYXZlQ2JLZXldID0gdm9pZCAwO1xuICAgICAgICBpZiAobGVhdmluZ1ZOb2Rlc0NhY2hlW2tleTJdID09PSB2bm9kZSkge1xuICAgICAgICAgIGRlbGV0ZSBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5Ml07XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCBkb25lID0gZWxbbGVhdmVDYktleV0uYmluZChudWxsLCBmYWxzZSk7XG4gICAgICBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5Ml0gPSB2bm9kZTtcbiAgICAgIGlmIChvbkxlYXZlKSB7XG4gICAgICAgIGNhbGxBc3luY0hvb2sob25MZWF2ZSwgW2VsLCBkb25lXSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkb25lKCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBjbG9uZSh2bm9kZTIpIHtcbiAgICAgIGNvbnN0IGhvb2tzMiA9IHJlc29sdmVUcmFuc2l0aW9uSG9va3MoXG4gICAgICAgIHZub2RlMixcbiAgICAgICAgcHJvcHMsXG4gICAgICAgIHN0YXRlLFxuICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgcG9zdENsb25lXG4gICAgICApO1xuICAgICAgaWYgKHBvc3RDbG9uZSkgcG9zdENsb25lKGhvb2tzMik7XG4gICAgICByZXR1cm4gaG9va3MyO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIGhvb2tzO1xufVxuZnVuY3Rpb24gZW1wdHlQbGFjZWhvbGRlcih2bm9kZSkge1xuICBpZiAoaXNLZWVwQWxpdmUodm5vZGUpKSB7XG4gICAgdm5vZGUgPSBjbG9uZVZOb2RlKHZub2RlKTtcbiAgICB2bm9kZS5jaGlsZHJlbiA9IG51bGw7XG4gICAgcmV0dXJuIHZub2RlO1xuICB9XG59XG5mdW5jdGlvbiBnZXRJbm5lckNoaWxkJDEodm5vZGUpIHtcbiAgaWYgKCFpc0tlZXBBbGl2ZSh2bm9kZSkpIHtcbiAgICBpZiAoaXNUZWxlcG9ydCh2bm9kZS50eXBlKSAmJiB2bm9kZS5jaGlsZHJlbikge1xuICAgICAgcmV0dXJuIGZpbmROb25Db21tZW50Q2hpbGQodm5vZGUuY2hpbGRyZW4pO1xuICAgIH1cbiAgICByZXR1cm4gdm5vZGU7XG4gIH1cbiAgaWYgKHZub2RlLmNvbXBvbmVudCkge1xuICAgIHJldHVybiB2bm9kZS5jb21wb25lbnQuc3ViVHJlZTtcbiAgfVxuICBjb25zdCB7IHNoYXBlRmxhZywgY2hpbGRyZW4gfSA9IHZub2RlO1xuICBpZiAoY2hpbGRyZW4pIHtcbiAgICBpZiAoc2hhcGVGbGFnICYgMTYpIHtcbiAgICAgIHJldHVybiBjaGlsZHJlblswXTtcbiAgICB9XG4gICAgaWYgKHNoYXBlRmxhZyAmIDMyICYmIGlzRnVuY3Rpb24oY2hpbGRyZW4uZGVmYXVsdCkpIHtcbiAgICAgIHJldHVybiBjaGlsZHJlbi5kZWZhdWx0KCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBzZXRUcmFuc2l0aW9uSG9va3Modm5vZGUsIGhvb2tzKSB7XG4gIGlmICh2bm9kZS5zaGFwZUZsYWcgJiA2ICYmIHZub2RlLmNvbXBvbmVudCkge1xuICAgIHZub2RlLnRyYW5zaXRpb24gPSBob29rcztcbiAgICBjb25zdCBzdWJUcmVlID0gdm5vZGUuY29tcG9uZW50LnN1YlRyZWU7XG4gICAgc2V0VHJhbnNpdGlvbkhvb2tzKFxuICAgICAgaXNUZWxlcG9ydChzdWJUcmVlLnR5cGUpID8gZ2V0SW5uZXJDaGlsZCQxKHN1YlRyZWUpIHx8IHN1YlRyZWUgOiBzdWJUcmVlLFxuICAgICAgaG9va3NcbiAgICApO1xuICB9IGVsc2UgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDEyOCkge1xuICAgIHZub2RlLnNzQ29udGVudC50cmFuc2l0aW9uID0gaG9va3MuY2xvbmUodm5vZGUuc3NDb250ZW50KTtcbiAgICB2bm9kZS5zc0ZhbGxiYWNrLnRyYW5zaXRpb24gPSBob29rcy5jbG9uZSh2bm9kZS5zc0ZhbGxiYWNrKTtcbiAgfSBlbHNlIHtcbiAgICB2bm9kZS50cmFuc2l0aW9uID0gaG9va3M7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFRyYW5zaXRpb25SYXdDaGlsZHJlbihjaGlsZHJlbiwga2VlcENvbW1lbnQgPSBmYWxzZSwgcGFyZW50S2V5KSB7XG4gIGxldCByZXQgPSBbXTtcbiAgbGV0IGtleWVkRnJhZ21lbnRDb3VudCA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICBsZXQgY2hpbGQgPSBjaGlsZHJlbltpXTtcbiAgICBjb25zdCBrZXkgPSBwYXJlbnRLZXkgPT0gbnVsbCA/IGNoaWxkLmtleSA6IFN0cmluZyhwYXJlbnRLZXkpICsgU3RyaW5nKGNoaWxkLmtleSAhPSBudWxsID8gY2hpbGQua2V5IDogaSk7XG4gICAgaWYgKGNoaWxkLnR5cGUgPT09IEZyYWdtZW50KSB7XG4gICAgICBpZiAoY2hpbGQucGF0Y2hGbGFnICYgMTI4KSBrZXllZEZyYWdtZW50Q291bnQrKztcbiAgICAgIHJldCA9IHJldC5jb25jYXQoXG4gICAgICAgIGdldFRyYW5zaXRpb25SYXdDaGlsZHJlbihjaGlsZC5jaGlsZHJlbiwga2VlcENvbW1lbnQsIGtleSlcbiAgICAgICk7XG4gICAgfSBlbHNlIGlmIChrZWVwQ29tbWVudCB8fCBjaGlsZC50eXBlICE9PSBDb21tZW50KSB7XG4gICAgICByZXQucHVzaChrZXkgIT0gbnVsbCA/IGNsb25lVk5vZGUoY2hpbGQsIHsga2V5IH0pIDogY2hpbGQpO1xuICAgIH1cbiAgfVxuICBpZiAoa2V5ZWRGcmFnbWVudENvdW50ID4gMSkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICByZXRbaV0ucGF0Y2hGbGFnID0gLTI7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXQ7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBkZWZpbmVDb21wb25lbnQob3B0aW9ucywgZXh0cmFPcHRpb25zKSB7XG4gIHJldHVybiBpc0Z1bmN0aW9uKG9wdGlvbnMpID8gKFxuICAgIC8vICM4MjM2OiBleHRlbmQgY2FsbCBhbmQgb3B0aW9ucy5uYW1lIGFjY2VzcyBhcmUgY29uc2lkZXJlZCBzaWRlLWVmZmVjdHNcbiAgICAvLyBieSBSb2xsdXAsIHNvIHdlIGhhdmUgdG8gd3JhcCBpdCBpbiBhIHB1cmUtYW5ub3RhdGVkIElJRkUuXG4gICAgLyogQF9fUFVSRV9fICovICgoKSA9PiBleHRlbmQoeyBuYW1lOiBvcHRpb25zLm5hbWUgfSwgZXh0cmFPcHRpb25zLCB7IHNldHVwOiBvcHRpb25zIH0pKSgpXG4gICkgOiBvcHRpb25zO1xufVxuXG5mdW5jdGlvbiB1c2VJZCgpIHtcbiAgY29uc3QgaSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICBpZiAoaSkge1xuICAgIHJldHVybiAoaS5hcHBDb250ZXh0LmNvbmZpZy5pZFByZWZpeCB8fCBcInZcIikgKyBcIi1cIiArIGkuaWRzWzBdICsgaS5pZHNbMV0rKztcbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FybiQxKFxuICAgICAgYHVzZUlkKCkgaXMgY2FsbGVkIHdoZW4gdGhlcmUgaXMgbm8gYWN0aXZlIGNvbXBvbmVudCBpbnN0YW5jZSB0byBiZSBhc3NvY2lhdGVkIHdpdGguYFxuICAgICk7XG4gIH1cbiAgcmV0dXJuIFwiXCI7XG59XG5mdW5jdGlvbiBtYXJrQXN5bmNCb3VuZGFyeShpbnN0YW5jZSkge1xuICBpbnN0YW5jZS5pZHMgPSBbaW5zdGFuY2UuaWRzWzBdICsgaW5zdGFuY2UuaWRzWzJdKysgKyBcIi1cIiwgMCwgMF07XG59XG5cbmNvbnN0IGtub3duVGVtcGxhdGVSZWZzID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrU2V0KCk7XG5mdW5jdGlvbiB1c2VUZW1wbGF0ZVJlZihrZXkpIHtcbiAgY29uc3QgaSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICBjb25zdCByID0gc2hhbGxvd1JlZihudWxsKTtcbiAgaWYgKGkpIHtcbiAgICBjb25zdCByZWZzID0gaS5yZWZzID09PSBFTVBUWV9PQkogPyBpLnJlZnMgPSB7fSA6IGkucmVmcztcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpc1RlbXBsYXRlUmVmS2V5KHJlZnMsIGtleSkpIHtcbiAgICAgIHdhcm4kMShgdXNlVGVtcGxhdGVSZWYoJyR7a2V5fScpIGFscmVhZHkgZXhpc3RzLmApO1xuICAgIH0gZWxzZSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocmVmcywga2V5LCB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGdldDogKCkgPT4gci52YWx1ZSxcbiAgICAgICAgc2V0OiAodmFsKSA9PiByLnZhbHVlID0gdmFsXG4gICAgICB9KTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm4kMShcbiAgICAgIGB1c2VUZW1wbGF0ZVJlZigpIGlzIGNhbGxlZCB3aGVuIHRoZXJlIGlzIG5vIGFjdGl2ZSBjb21wb25lbnQgaW5zdGFuY2UgdG8gYmUgYXNzb2NpYXRlZCB3aXRoLmBcbiAgICApO1xuICB9XG4gIGNvbnN0IHJldCA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyByZWFkb25seShyKSA6IHI7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAga25vd25UZW1wbGF0ZVJlZnMuYWRkKHJldCk7XG4gIH1cbiAgcmV0dXJuIHJldDtcbn1cbmZ1bmN0aW9uIGlzVGVtcGxhdGVSZWZLZXkocmVmcywga2V5KSB7XG4gIGxldCBkZXNjO1xuICByZXR1cm4gISEoKGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHJlZnMsIGtleSkpICYmICFkZXNjLmNvbmZpZ3VyYWJsZSk7XG59XG5cbmNvbnN0IHBlbmRpbmdTZXRSZWZNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmZ1bmN0aW9uIHNldFJlZihyYXdSZWYsIG9sZFJhd1JlZiwgcGFyZW50U3VzcGVuc2UsIHZub2RlLCBpc1VubW91bnQgPSBmYWxzZSkge1xuICBpZiAoaXNBcnJheShyYXdSZWYpKSB7XG4gICAgcmF3UmVmLmZvckVhY2goXG4gICAgICAociwgaSkgPT4gc2V0UmVmKFxuICAgICAgICByLFxuICAgICAgICBvbGRSYXdSZWYgJiYgKGlzQXJyYXkob2xkUmF3UmVmKSA/IG9sZFJhd1JlZltpXSA6IG9sZFJhd1JlZiksXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICB2bm9kZSxcbiAgICAgICAgaXNVbm1vdW50XG4gICAgICApXG4gICAgKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGlzQXN5bmNXcmFwcGVyKHZub2RlKSAmJiAhaXNVbm1vdW50KSB7XG4gICAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDUxMiAmJiB2bm9kZS50eXBlLl9fYXN5bmNSZXNvbHZlZCAmJiB2bm9kZS5jb21wb25lbnQuc3ViVHJlZS5jb21wb25lbnQpIHtcbiAgICAgIHNldFJlZihyYXdSZWYsIG9sZFJhd1JlZiwgcGFyZW50U3VzcGVuc2UsIHZub2RlLmNvbXBvbmVudC5zdWJUcmVlKTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHJlZlZhbHVlID0gdm5vZGUuc2hhcGVGbGFnICYgNCA/IGdldENvbXBvbmVudFB1YmxpY0luc3RhbmNlKHZub2RlLmNvbXBvbmVudCkgOiB2bm9kZS5lbDtcbiAgY29uc3QgdmFsdWUgPSBpc1VubW91bnQgPyBudWxsIDogcmVmVmFsdWU7XG4gIGNvbnN0IHsgaTogb3duZXIsIHI6IHJlZiB9ID0gcmF3UmVmO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhb3duZXIpIHtcbiAgICB3YXJuJDEoXG4gICAgICBgTWlzc2luZyByZWYgb3duZXIgY29udGV4dC4gcmVmIGNhbm5vdCBiZSB1c2VkIG9uIGhvaXN0ZWQgdm5vZGVzLiBBIHZub2RlIHdpdGggcmVmIG11c3QgYmUgY3JlYXRlZCBpbnNpZGUgdGhlIHJlbmRlciBmdW5jdGlvbi5gXG4gICAgKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3Qgb2xkUmVmID0gb2xkUmF3UmVmICYmIG9sZFJhd1JlZi5yO1xuICBjb25zdCByZWZzID0gb3duZXIucmVmcyA9PT0gRU1QVFlfT0JKID8gb3duZXIucmVmcyA9IHt9IDogb3duZXIucmVmcztcbiAgY29uc3Qgc2V0dXBTdGF0ZSA9IG93bmVyLnNldHVwU3RhdGU7XG4gIGNvbnN0IHJhd1NldHVwU3RhdGUgPSB0b1JhdyhzZXR1cFN0YXRlKTtcbiAgY29uc3QgY2FuU2V0U2V0dXBSZWYgPSBzZXR1cFN0YXRlID09PSBFTVBUWV9PQkogPyBOTyA6IChrZXkpID0+IHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgaWYgKGhhc093bihyYXdTZXR1cFN0YXRlLCBrZXkpICYmICFpc1JlZihyYXdTZXR1cFN0YXRlW2tleV0pKSB7XG4gICAgICAgIHdhcm4kMShcbiAgICAgICAgICBgVGVtcGxhdGUgcmVmIFwiJHtrZXl9XCIgdXNlZCBvbiBhIG5vbi1yZWYgdmFsdWUuIEl0IHdpbGwgbm90IHdvcmsgaW4gdGhlIHByb2R1Y3Rpb24gYnVpbGQuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKGtub3duVGVtcGxhdGVSZWZzLmhhcyhyYXdTZXR1cFN0YXRlW2tleV0pKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGlzVGVtcGxhdGVSZWZLZXkocmVmcywga2V5KSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gaGFzT3duKHJhd1NldHVwU3RhdGUsIGtleSk7XG4gIH07XG4gIGNvbnN0IGNhblNldFJlZiA9IChyZWYyLCBrZXkpID0+IHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBrbm93blRlbXBsYXRlUmVmcy5oYXMocmVmMikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGtleSAmJiBpc1RlbXBsYXRlUmVmS2V5KHJlZnMsIGtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG4gIGlmIChvbGRSZWYgIT0gbnVsbCAmJiBvbGRSZWYgIT09IHJlZikge1xuICAgIGludmFsaWRhdGVQZW5kaW5nU2V0UmVmKG9sZFJhd1JlZik7XG4gICAgaWYgKGlzU3RyaW5nKG9sZFJlZikpIHtcbiAgICAgIHJlZnNbb2xkUmVmXSA9IG51bGw7XG4gICAgICBpZiAoY2FuU2V0U2V0dXBSZWYob2xkUmVmKSkge1xuICAgICAgICBzZXR1cFN0YXRlW29sZFJlZl0gPSBudWxsO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaXNSZWYob2xkUmVmKSkge1xuICAgICAgY29uc3Qgb2xkUmF3UmVmQXRvbSA9IG9sZFJhd1JlZjtcbiAgICAgIGlmIChjYW5TZXRSZWYob2xkUmVmLCBvbGRSYXdSZWZBdG9tLmspKSB7XG4gICAgICAgIG9sZFJlZi52YWx1ZSA9IG51bGw7XG4gICAgICB9XG4gICAgICBpZiAob2xkUmF3UmVmQXRvbS5rKSByZWZzW29sZFJhd1JlZkF0b20ua10gPSBudWxsO1xuICAgIH1cbiAgfVxuICBpZiAoaXNGdW5jdGlvbihyZWYpKSB7XG4gICAgY2FsbFdpdGhFcnJvckhhbmRsaW5nKHJlZiwgb3duZXIsIDEyLCBbdmFsdWUsIHJlZnNdKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBfaXNTdHJpbmcgPSBpc1N0cmluZyhyZWYpO1xuICAgIGNvbnN0IF9pc1JlZiA9IGlzUmVmKHJlZik7XG4gICAgaWYgKF9pc1N0cmluZyB8fCBfaXNSZWYpIHtcbiAgICAgIGNvbnN0IGRvU2V0ID0gKCkgPT4ge1xuICAgICAgICBpZiAocmF3UmVmLmYpIHtcbiAgICAgICAgICBjb25zdCBleGlzdGluZyA9IF9pc1N0cmluZyA/IGNhblNldFNldHVwUmVmKHJlZikgPyBzZXR1cFN0YXRlW3JlZl0gOiByZWZzW3JlZl0gOiBjYW5TZXRSZWYocmVmKSB8fCAhcmF3UmVmLmsgPyByZWYudmFsdWUgOiByZWZzW3Jhd1JlZi5rXTtcbiAgICAgICAgICBpZiAoaXNVbm1vdW50KSB7XG4gICAgICAgICAgICBpc0FycmF5KGV4aXN0aW5nKSAmJiByZW1vdmUoZXhpc3RpbmcsIHJlZlZhbHVlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKCFpc0FycmF5KGV4aXN0aW5nKSkge1xuICAgICAgICAgICAgICBpZiAoX2lzU3RyaW5nKSB7XG4gICAgICAgICAgICAgICAgcmVmc1tyZWZdID0gW3JlZlZhbHVlXTtcbiAgICAgICAgICAgICAgICBpZiAoY2FuU2V0U2V0dXBSZWYocmVmKSkge1xuICAgICAgICAgICAgICAgICAgc2V0dXBTdGF0ZVtyZWZdID0gcmVmc1tyZWZdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXdWYWwgPSBbcmVmVmFsdWVdO1xuICAgICAgICAgICAgICAgIGlmIChjYW5TZXRSZWYocmVmLCByYXdSZWYuaykpIHtcbiAgICAgICAgICAgICAgICAgIHJlZi52YWx1ZSA9IG5ld1ZhbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHJhd1JlZi5rKSByZWZzW3Jhd1JlZi5rXSA9IG5ld1ZhbDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmICghZXhpc3RpbmcuaW5jbHVkZXMocmVmVmFsdWUpKSB7XG4gICAgICAgICAgICAgIGV4aXN0aW5nLnB1c2gocmVmVmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChfaXNTdHJpbmcpIHtcbiAgICAgICAgICByZWZzW3JlZl0gPSB2YWx1ZTtcbiAgICAgICAgICBpZiAoY2FuU2V0U2V0dXBSZWYocmVmKSkge1xuICAgICAgICAgICAgc2V0dXBTdGF0ZVtyZWZdID0gdmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKF9pc1JlZikge1xuICAgICAgICAgIGlmIChjYW5TZXRSZWYocmVmLCByYXdSZWYuaykpIHtcbiAgICAgICAgICAgIHJlZi52YWx1ZSA9IHZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAocmF3UmVmLmspIHJlZnNbcmF3UmVmLmtdID0gdmFsdWU7XG4gICAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHdhcm4kMShcIkludmFsaWQgdGVtcGxhdGUgcmVmIHR5cGU6XCIsIHJlZiwgYCgke3R5cGVvZiByZWZ9KWApO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IGpvYiA9ICgpID0+IHtcbiAgICAgICAgICBkb1NldCgpO1xuICAgICAgICAgIHBlbmRpbmdTZXRSZWZNYXAuZGVsZXRlKHJhd1JlZik7XG4gICAgICAgIH07XG4gICAgICAgIGpvYi5pZCA9IC0xO1xuICAgICAgICBwZW5kaW5nU2V0UmVmTWFwLnNldChyYXdSZWYsIGpvYik7XG4gICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChqb2IsIHBhcmVudFN1c3BlbnNlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGludmFsaWRhdGVQZW5kaW5nU2V0UmVmKHJhd1JlZik7XG4gICAgICAgIGRvU2V0KCk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICB3YXJuJDEoXCJJbnZhbGlkIHRlbXBsYXRlIHJlZiB0eXBlOlwiLCByZWYsIGAoJHt0eXBlb2YgcmVmfSlgKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGludmFsaWRhdGVQZW5kaW5nU2V0UmVmKHJhd1JlZikge1xuICBjb25zdCBwZW5kaW5nU2V0UmVmID0gcGVuZGluZ1NldFJlZk1hcC5nZXQocmF3UmVmKTtcbiAgaWYgKHBlbmRpbmdTZXRSZWYpIHtcbiAgICBwZW5kaW5nU2V0UmVmLmZsYWdzIHw9IDg7XG4gICAgcGVuZGluZ1NldFJlZk1hcC5kZWxldGUocmF3UmVmKTtcbiAgfVxufVxuXG5sZXQgaGFzTG9nZ2VkTWlzbWF0Y2hFcnJvciA9IGZhbHNlO1xuY29uc3QgbG9nTWlzbWF0Y2hFcnJvciA9ICgpID0+IHtcbiAgaWYgKGhhc0xvZ2dlZE1pc21hdGNoRXJyb3IpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc29sZS5lcnJvcihcIkh5ZHJhdGlvbiBjb21wbGV0ZWQgYnV0IGNvbnRhaW5zIG1pc21hdGNoZXMuXCIpO1xuICBoYXNMb2dnZWRNaXNtYXRjaEVycm9yID0gdHJ1ZTtcbn07XG5jb25zdCBpc1NWR0NvbnRhaW5lciA9IChjb250YWluZXIpID0+IGNvbnRhaW5lci5uYW1lc3BhY2VVUkkuaW5jbHVkZXMoXCJzdmdcIikgJiYgY29udGFpbmVyLnRhZ05hbWUgIT09IFwiZm9yZWlnbk9iamVjdFwiO1xuY29uc3QgaXNNYXRoTUxDb250YWluZXIgPSAoY29udGFpbmVyKSA9PiBjb250YWluZXIubmFtZXNwYWNlVVJJLmluY2x1ZGVzKFwiTWF0aE1MXCIpO1xuY29uc3QgZ2V0Q29udGFpbmVyVHlwZSA9IChjb250YWluZXIpID0+IHtcbiAgaWYgKGNvbnRhaW5lci5ub2RlVHlwZSAhPT0gMSkgcmV0dXJuIHZvaWQgMDtcbiAgaWYgKGlzU1ZHQ29udGFpbmVyKGNvbnRhaW5lcikpIHJldHVybiBcInN2Z1wiO1xuICBpZiAoaXNNYXRoTUxDb250YWluZXIoY29udGFpbmVyKSkgcmV0dXJuIFwibWF0aG1sXCI7XG4gIHJldHVybiB2b2lkIDA7XG59O1xuY29uc3QgaXNDb21tZW50ID0gKG5vZGUpID0+IG5vZGUubm9kZVR5cGUgPT09IDg7XG5mdW5jdGlvbiBjcmVhdGVIeWRyYXRpb25GdW5jdGlvbnMocmVuZGVyZXJJbnRlcm5hbHMpIHtcbiAgY29uc3Qge1xuICAgIG10OiBtb3VudENvbXBvbmVudCxcbiAgICBwOiBwYXRjaCxcbiAgICBvOiB7XG4gICAgICBwYXRjaFByb3AsXG4gICAgICBjcmVhdGVUZXh0LFxuICAgICAgbmV4dFNpYmxpbmcsXG4gICAgICBwYXJlbnROb2RlLFxuICAgICAgcmVtb3ZlLFxuICAgICAgaW5zZXJ0LFxuICAgICAgY3JlYXRlQ29tbWVudFxuICAgIH1cbiAgfSA9IHJlbmRlcmVySW50ZXJuYWxzO1xuICBjb25zdCBoeWRyYXRlID0gKHZub2RlLCBjb250YWluZXIpID0+IHtcbiAgICBpZiAoIWNvbnRhaW5lci5oYXNDaGlsZE5vZGVzKCkpIHtcbiAgICAgICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfSFlEUkFUSU9OX01JU01BVENIX0RFVEFJTFNfXykgJiYgd2FybiQxKFxuICAgICAgICBgQXR0ZW1wdGluZyB0byBoeWRyYXRlIGV4aXN0aW5nIG1hcmt1cCBidXQgY29udGFpbmVyIGlzIGVtcHR5LiBQZXJmb3JtaW5nIGZ1bGwgbW91bnQgaW5zdGVhZC5gXG4gICAgICApO1xuICAgICAgcGF0Y2gobnVsbCwgdm5vZGUsIGNvbnRhaW5lcik7XG4gICAgICBmbHVzaFBvc3RGbHVzaENicygpO1xuICAgICAgY29udGFpbmVyLl92bm9kZSA9IHZub2RlO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBoeWRyYXRlTm9kZShjb250YWluZXIuZmlyc3RDaGlsZCwgdm5vZGUsIG51bGwsIG51bGwsIG51bGwpO1xuICAgIGZsdXNoUG9zdEZsdXNoQ2JzKCk7XG4gICAgY29udGFpbmVyLl92bm9kZSA9IHZub2RlO1xuICB9O1xuICBjb25zdCBoeWRyYXRlTm9kZSA9IChub2RlLCB2bm9kZSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQgPSBmYWxzZSkgPT4ge1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZCB8fCAhIXZub2RlLmR5bmFtaWNDaGlsZHJlbjtcbiAgICBjb25zdCBpc0ZyYWdtZW50U3RhcnQgPSBpc0NvbW1lbnQobm9kZSkgJiYgbm9kZS5kYXRhID09PSBcIltcIjtcbiAgICBjb25zdCBvbk1pc21hdGNoID0gKCkgPT4gaGFuZGxlTWlzbWF0Y2goXG4gICAgICBub2RlLFxuICAgICAgdm5vZGUsXG4gICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgIGlzRnJhZ21lbnRTdGFydFxuICAgICk7XG4gICAgY29uc3QgeyB0eXBlLCByZWYsIHNoYXBlRmxhZywgcGF0Y2hGbGFnIH0gPSB2bm9kZTtcbiAgICBsZXQgZG9tVHlwZSA9IG5vZGUubm9kZVR5cGU7XG4gICAgdm5vZGUuZWwgPSBub2RlO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgZGVmKG5vZGUsIFwiX192bm9kZVwiLCB2bm9kZSwgdHJ1ZSk7XG4gICAgICBkZWYobm9kZSwgXCJfX3Z1ZVBhcmVudENvbXBvbmVudFwiLCBwYXJlbnRDb21wb25lbnQsIHRydWUpO1xuICAgIH1cbiAgICBpZiAocGF0Y2hGbGFnID09PSAtMikge1xuICAgICAgb3B0aW1pemVkID0gZmFsc2U7XG4gICAgICB2bm9kZS5keW5hbWljQ2hpbGRyZW4gPSBudWxsO1xuICAgIH1cbiAgICBsZXQgbmV4dE5vZGUgPSBudWxsO1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSBUZXh0OlxuICAgICAgICBpZiAoZG9tVHlwZSAhPT0gMykge1xuICAgICAgICAgIGlmICh2bm9kZS5jaGlsZHJlbiA9PT0gXCJcIikge1xuICAgICAgICAgICAgaW5zZXJ0KHZub2RlLmVsID0gY3JlYXRlVGV4dChcIlwiKSwgcGFyZW50Tm9kZShub2RlKSwgbm9kZSk7XG4gICAgICAgICAgICBuZXh0Tm9kZSA9IG5vZGU7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5leHROb2RlID0gb25NaXNtYXRjaCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAobm9kZS5kYXRhICE9PSB2bm9kZS5jaGlsZHJlbikge1xuICAgICAgICAgICAgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fKSAmJiB3YXJuJDEoXG4gICAgICAgICAgICAgIGBIeWRyYXRpb24gdGV4dCBtaXNtYXRjaCBpbmAsXG4gICAgICAgICAgICAgIG5vZGUucGFyZW50Tm9kZSxcbiAgICAgICAgICAgICAgYFxuICAtIHJlbmRlcmVkIG9uIHNlcnZlcjogJHtKU09OLnN0cmluZ2lmeShcbiAgICAgICAgICAgICAgICBub2RlLmRhdGFcbiAgICAgICAgICAgICAgKX1cbiAgLSBleHBlY3RlZCBvbiBjbGllbnQ6ICR7SlNPTi5zdHJpbmdpZnkodm5vZGUuY2hpbGRyZW4pfWBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBsb2dNaXNtYXRjaEVycm9yKCk7XG4gICAgICAgICAgICBub2RlLmRhdGEgPSB2bm9kZS5jaGlsZHJlbjtcbiAgICAgICAgICB9XG4gICAgICAgICAgbmV4dE5vZGUgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgQ29tbWVudDpcbiAgICAgICAgaWYgKGlzVGVtcGxhdGVOb2RlKG5vZGUpKSB7XG4gICAgICAgICAgbmV4dE5vZGUgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgICAgICByZXBsYWNlTm9kZShcbiAgICAgICAgICAgIHZub2RlLmVsID0gbm9kZS5jb250ZW50LmZpcnN0Q2hpbGQsXG4gICAgICAgICAgICBub2RlLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50XG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmIChkb21UeXBlICE9PSA4IHx8IGlzRnJhZ21lbnRTdGFydCkge1xuICAgICAgICAgIG5leHROb2RlID0gb25NaXNtYXRjaCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5leHROb2RlID0gbmV4dFNpYmxpbmcobm9kZSk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFN0YXRpYzpcbiAgICAgICAgaWYgKGlzRnJhZ21lbnRTdGFydCkge1xuICAgICAgICAgIG5vZGUgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgICAgICBkb21UeXBlID0gbm9kZS5ub2RlVHlwZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZG9tVHlwZSA9PT0gMSB8fCBkb21UeXBlID09PSAzKSB7XG4gICAgICAgICAgbmV4dE5vZGUgPSBub2RlO1xuICAgICAgICAgIGNvbnN0IG5lZWRUb0Fkb3B0Q29udGVudCA9ICF2bm9kZS5jaGlsZHJlbi5sZW5ndGg7XG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB2bm9kZS5zdGF0aWNDb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAobmVlZFRvQWRvcHRDb250ZW50KVxuICAgICAgICAgICAgICB2bm9kZS5jaGlsZHJlbiArPSBuZXh0Tm9kZS5ub2RlVHlwZSA9PT0gMSA/IG5leHROb2RlLm91dGVySFRNTCA6IG5leHROb2RlLmRhdGE7XG4gICAgICAgICAgICBpZiAoaSA9PT0gdm5vZGUuc3RhdGljQ291bnQgLSAxKSB7XG4gICAgICAgICAgICAgIHZub2RlLmFuY2hvciA9IG5leHROb2RlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbmV4dE5vZGUgPSBuZXh0U2libGluZyhuZXh0Tm9kZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBpc0ZyYWdtZW50U3RhcnQgPyBuZXh0U2libGluZyhuZXh0Tm9kZSkgOiBuZXh0Tm9kZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvbk1pc21hdGNoKCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIEZyYWdtZW50OlxuICAgICAgICBpZiAoIWlzRnJhZ21lbnRTdGFydCkge1xuICAgICAgICAgIG5leHROb2RlID0gb25NaXNtYXRjaCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5leHROb2RlID0gaHlkcmF0ZUZyYWdtZW50KFxuICAgICAgICAgICAgbm9kZSxcbiAgICAgICAgICAgIHZub2RlLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaWYgKHNoYXBlRmxhZyAmIDEpIHtcbiAgICAgICAgICBpZiAoKGRvbVR5cGUgIT09IDEgfHwgdm5vZGUudHlwZS50b0xvd2VyQ2FzZSgpICE9PSBub2RlLnRhZ05hbWUudG9Mb3dlckNhc2UoKSkgJiYgIWlzVGVtcGxhdGVOb2RlKG5vZGUpKSB7XG4gICAgICAgICAgICBuZXh0Tm9kZSA9IG9uTWlzbWF0Y2goKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbmV4dE5vZGUgPSBoeWRyYXRlRWxlbWVudChcbiAgICAgICAgICAgICAgbm9kZSxcbiAgICAgICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChzaGFwZUZsYWcgJiA2KSB7XG4gICAgICAgICAgdm5vZGUuc2xvdFNjb3BlSWRzID0gc2xvdFNjb3BlSWRzO1xuICAgICAgICAgIGNvbnN0IGNvbnRhaW5lciA9IHBhcmVudE5vZGUobm9kZSk7XG4gICAgICAgICAgaWYgKGlzRnJhZ21lbnRTdGFydCkge1xuICAgICAgICAgICAgbmV4dE5vZGUgPSBsb2NhdGVDbG9zaW5nQW5jaG9yKG5vZGUpO1xuICAgICAgICAgIH0gZWxzZSBpZiAoaXNDb21tZW50KG5vZGUpICYmIG5vZGUuZGF0YSA9PT0gXCJ0ZWxlcG9ydCBzdGFydFwiKSB7XG4gICAgICAgICAgICBuZXh0Tm9kZSA9IGxvY2F0ZUNsb3NpbmdBbmNob3Iobm9kZSwgbm9kZS5kYXRhLCBcInRlbGVwb3J0IGVuZFwiKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbmV4dE5vZGUgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbW91bnRDb21wb25lbnQoXG4gICAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICAgIGdldENvbnRhaW5lclR5cGUoY29udGFpbmVyKSxcbiAgICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKGlzQXN5bmNXcmFwcGVyKHZub2RlKSAmJiAhdm5vZGUudHlwZS5fX2FzeW5jUmVzb2x2ZWQpIHtcbiAgICAgICAgICAgIGxldCBzdWJUcmVlO1xuICAgICAgICAgICAgaWYgKGlzRnJhZ21lbnRTdGFydCkge1xuICAgICAgICAgICAgICBzdWJUcmVlID0gY3JlYXRlVk5vZGUoRnJhZ21lbnQpO1xuICAgICAgICAgICAgICBzdWJUcmVlLmFuY2hvciA9IG5leHROb2RlID8gbmV4dE5vZGUucHJldmlvdXNTaWJsaW5nIDogY29udGFpbmVyLmxhc3RDaGlsZDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHN1YlRyZWUgPSBub2RlLm5vZGVUeXBlID09PSAzID8gY3JlYXRlVGV4dFZOb2RlKFwiXCIpIDogY3JlYXRlVk5vZGUoXCJkaXZcIik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdWJUcmVlLmVsID0gbm9kZTtcbiAgICAgICAgICAgIHZub2RlLmNvbXBvbmVudC5zdWJUcmVlID0gc3ViVHJlZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoc2hhcGVGbGFnICYgNjQpIHtcbiAgICAgICAgICBpZiAoZG9tVHlwZSAhPT0gOCkge1xuICAgICAgICAgICAgbmV4dE5vZGUgPSBvbk1pc21hdGNoKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5leHROb2RlID0gdm5vZGUudHlwZS5oeWRyYXRlKFxuICAgICAgICAgICAgICBub2RlLFxuICAgICAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgICBvcHRpbWl6ZWQsXG4gICAgICAgICAgICAgIHJlbmRlcmVySW50ZXJuYWxzLFxuICAgICAgICAgICAgICBoeWRyYXRlQ2hpbGRyZW5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHNoYXBlRmxhZyAmIDEyOCkge1xuICAgICAgICAgIG5leHROb2RlID0gdm5vZGUudHlwZS5oeWRyYXRlKFxuICAgICAgICAgICAgbm9kZSxcbiAgICAgICAgICAgIHZub2RlLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBnZXRDb250YWluZXJUeXBlKHBhcmVudE5vZGUobm9kZSkpLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkLFxuICAgICAgICAgICAgcmVuZGVyZXJJbnRlcm5hbHMsXG4gICAgICAgICAgICBoeWRyYXRlTm9kZVxuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX18pIHtcbiAgICAgICAgICB3YXJuJDEoXCJJbnZhbGlkIEhvc3RWTm9kZSB0eXBlOlwiLCB0eXBlLCBgKCR7dHlwZW9mIHR5cGV9KWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChyZWYgIT0gbnVsbCkge1xuICAgICAgc2V0UmVmKHJlZiwgbnVsbCwgcGFyZW50U3VzcGVuc2UsIHZub2RlKTtcbiAgICB9XG4gICAgcmV0dXJuIG5leHROb2RlO1xuICB9O1xuICBjb25zdCBoeWRyYXRlRWxlbWVudCA9IChlbCwgdm5vZGUsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkKSA9PiB7XG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkIHx8ICEhdm5vZGUuZHluYW1pY0NoaWxkcmVuO1xuICAgIGNvbnN0IHtcbiAgICAgIHR5cGUsXG4gICAgICBkeW5hbWljUHJvcHMsXG4gICAgICBwcm9wcyxcbiAgICAgIHBhdGNoRmxhZyxcbiAgICAgIHNoYXBlRmxhZyxcbiAgICAgIGRpcnMsXG4gICAgICB0cmFuc2l0aW9uXG4gICAgfSA9IHZub2RlO1xuICAgIGNvbnN0IGZvcmNlUGF0Y2ggPSB0eXBlID09PSBcImlucHV0XCIgfHwgdHlwZSA9PT0gXCJvcHRpb25cIjtcbiAgICBjb25zdCBoYXNEeW5hbWljUHJvcHMgPSAhIWR5bmFtaWNQcm9wcztcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBmb3JjZVBhdGNoIHx8IGhhc0R5bmFtaWNQcm9wcyB8fCBwYXRjaEZsYWcgIT09IC0xKSB7XG4gICAgICBpZiAoZGlycykge1xuICAgICAgICBpbnZva2VEaXJlY3RpdmVIb29rKHZub2RlLCBudWxsLCBwYXJlbnRDb21wb25lbnQsIFwiY3JlYXRlZFwiKTtcbiAgICAgIH1cbiAgICAgIGxldCBuZWVkQ2FsbFRyYW5zaXRpb25Ib29rcyA9IGZhbHNlO1xuICAgICAgaWYgKGlzVGVtcGxhdGVOb2RlKGVsKSkge1xuICAgICAgICBuZWVkQ2FsbFRyYW5zaXRpb25Ib29rcyA9IG5lZWRUcmFuc2l0aW9uKFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgLy8gbm8gbmVlZCBjaGVjayBwYXJlbnRTdXNwZW5zZSBpbiBoeWRyYXRpb25cbiAgICAgICAgICB0cmFuc2l0aW9uXG4gICAgICAgICkgJiYgcGFyZW50Q29tcG9uZW50ICYmIHBhcmVudENvbXBvbmVudC52bm9kZS5wcm9wcyAmJiBwYXJlbnRDb21wb25lbnQudm5vZGUucHJvcHMuYXBwZWFyO1xuICAgICAgICBjb25zdCBjb250ZW50ID0gZWwuY29udGVudC5maXJzdENoaWxkO1xuICAgICAgICBpZiAobmVlZENhbGxUcmFuc2l0aW9uSG9va3MpIHtcbiAgICAgICAgICBjb25zdCBjbHMgPSBjb250ZW50LmdldEF0dHJpYnV0ZShcImNsYXNzXCIpO1xuICAgICAgICAgIGlmIChjbHMpIGNvbnRlbnQuJGNscyA9IGNscztcbiAgICAgICAgICB0cmFuc2l0aW9uLmJlZm9yZUVudGVyKGNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJlcGxhY2VOb2RlKGNvbnRlbnQsIGVsLCBwYXJlbnRDb21wb25lbnQpO1xuICAgICAgICB2bm9kZS5lbCA9IGVsID0gY29udGVudDtcbiAgICAgIH1cbiAgICAgIGlmIChzaGFwZUZsYWcgJiAxNiAmJiAvLyBza2lwIGlmIGVsZW1lbnQgaGFzIGlubmVySFRNTCAvIHRleHRDb250ZW50XG4gICAgICAhKHByb3BzICYmIChwcm9wcy5pbm5lckhUTUwgfHwgcHJvcHMudGV4dENvbnRlbnQpKSkge1xuICAgICAgICBsZXQgbmV4dCA9IGh5ZHJhdGVDaGlsZHJlbihcbiAgICAgICAgICBlbC5maXJzdENoaWxkLFxuICAgICAgICAgIHZub2RlLFxuICAgICAgICAgIGVsLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICAgIGlmIChuZXh0ICYmICFpc01pc21hdGNoQWxsb3dlZChlbCwgMSAvKiBDSElMRFJFTiAqLykpIHtcbiAgICAgICAgICAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX18pICYmIHdhcm4kMShcbiAgICAgICAgICAgIGBIeWRyYXRpb24gY2hpbGRyZW4gbWlzbWF0Y2ggb25gLFxuICAgICAgICAgICAgZWwsXG4gICAgICAgICAgICBgXG5TZXJ2ZXIgcmVuZGVyZWQgZWxlbWVudCBjb250YWlucyBtb3JlIGNoaWxkIG5vZGVzIHRoYW4gY2xpZW50IHZkb20uYFxuICAgICAgICAgICk7XG4gICAgICAgICAgbG9nTWlzbWF0Y2hFcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIHdoaWxlIChuZXh0KSB7XG4gICAgICAgICAgY29uc3QgY3VyID0gbmV4dDtcbiAgICAgICAgICBuZXh0ID0gbmV4dC5uZXh0U2libGluZztcbiAgICAgICAgICByZW1vdmUoY3VyKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChzaGFwZUZsYWcgJiA4KSB7XG4gICAgICAgIGxldCBjbGllbnRUZXh0ID0gdm5vZGUuY2hpbGRyZW47XG4gICAgICAgIGlmIChjbGllbnRUZXh0WzBdID09PSBcIlxcblwiICYmIChlbC50YWdOYW1lID09PSBcIlBSRVwiIHx8IGVsLnRhZ05hbWUgPT09IFwiVEVYVEFSRUFcIikpIHtcbiAgICAgICAgICBjbGllbnRUZXh0ID0gY2xpZW50VGV4dC5zbGljZSgxKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IHRleHRDb250ZW50IH0gPSBlbDtcbiAgICAgICAgaWYgKHRleHRDb250ZW50ICE9PSBjbGllbnRUZXh0ICYmIC8vIGlubmVySFRNTCBub3JtYWxpemUgXFxyXFxuIG9yIFxcciBpbnRvIGEgc2luZ2xlIFxcbiBpbiB0aGUgRE9NXG4gICAgICAgIHRleHRDb250ZW50ICE9PSBjbGllbnRUZXh0LnJlcGxhY2UoL1xcclxcbnxcXHIvZywgXCJcXG5cIikpIHtcbiAgICAgICAgICBpZiAoIWlzTWlzbWF0Y2hBbGxvd2VkKGVsLCAwIC8qIFRFWFQgKi8pKSB7XG4gICAgICAgICAgICAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX18pICYmIHdhcm4kMShcbiAgICAgICAgICAgICAgYEh5ZHJhdGlvbiB0ZXh0IGNvbnRlbnQgbWlzbWF0Y2ggb25gLFxuICAgICAgICAgICAgICBlbCxcbiAgICAgICAgICAgICAgYFxuICAtIHJlbmRlcmVkIG9uIHNlcnZlcjogJHt0ZXh0Q29udGVudH1cbiAgLSBleHBlY3RlZCBvbiBjbGllbnQ6ICR7Y2xpZW50VGV4dH1gXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgbG9nTWlzbWF0Y2hFcnJvcigpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBlbC50ZXh0Q29udGVudCA9IHZub2RlLmNoaWxkcmVuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAocHJvcHMpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fIHx8IGZvcmNlUGF0Y2ggfHwgaGFzRHluYW1pY1Byb3BzIHx8ICFvcHRpbWl6ZWQgfHwgcGF0Y2hGbGFnICYgKDE2IHwgMzIpKSB7XG4gICAgICAgICAgY29uc3QgaXNDdXN0b21FbGVtZW50ID0gZWwudGFnTmFtZS5pbmNsdWRlcyhcIi1cIik7XG4gICAgICAgICAgY29uc3QgbmFtZXNwYWNlID0gZWwubmFtZXNwYWNlVVJJLmluY2x1ZGVzKFwic3ZnXCIpID8gXCJzdmdcIiA6IGVsLm5hbWVzcGFjZVVSSS5pbmNsdWRlcyhcIk1hdGhNTFwiKSA/IFwibWF0aG1sXCIgOiB2b2lkIDA7XG4gICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gcHJvcHMpIHtcbiAgICAgICAgICAgIGlmICgoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX18pICYmIC8vICMxMTE4OSBza2lwIGlmIHRoaXMgbm9kZSBoYXMgZGlyZWN0aXZlcyB0aGF0IGhhdmUgY3JlYXRlZCBob29rc1xuICAgICAgICAgICAgLy8gYXMgaXQgY291bGQgaGF2ZSBtdXRhdGVkIHRoZSBET00gaW4gYW55IHBvc3NpYmxlIHdheVxuICAgICAgICAgICAgIShkaXJzICYmIGRpcnMuc29tZSgoZCkgPT4gZC5kaXIuY3JlYXRlZCkpICYmIHByb3BIYXNNaXNtYXRjaChlbCwga2V5LCBwcm9wc1trZXldLCB2bm9kZSwgcGFyZW50Q29tcG9uZW50KSkge1xuICAgICAgICAgICAgICBsb2dNaXNtYXRjaEVycm9yKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZm9yY2VQYXRjaCAmJiAoa2V5LmVuZHNXaXRoKFwidmFsdWVcIikgfHwga2V5ID09PSBcImluZGV0ZXJtaW5hdGVcIikgfHwgaXNPbihrZXkpICYmICFpc1Jlc2VydmVkUHJvcChrZXkpIHx8IC8vIGZvcmNlIGh5ZHJhdGUgdi1iaW5kIHdpdGggLnByb3AgbW9kaWZpZXJzXG4gICAgICAgICAgICBrZXlbMF0gPT09IFwiLlwiIHx8IGlzQ3VzdG9tRWxlbWVudCAmJiAhaXNSZXNlcnZlZFByb3Aoa2V5KSB8fCBkeW5hbWljUHJvcHMgJiYgZHluYW1pY1Byb3BzLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgICAgICAgICAgaWYgKGlzVW5jaGFuZ2VkUmVzb3VyY2VQcm9wKGVsLCBrZXksIHByb3BzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcGF0Y2hQcm9wKGVsLCBrZXksIG51bGwsIHByb3BzW2tleV0sIG5hbWVzcGFjZSwgcGFyZW50Q29tcG9uZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAocHJvcHMub25DbGljaykge1xuICAgICAgICAgIHBhdGNoUHJvcChcbiAgICAgICAgICAgIGVsLFxuICAgICAgICAgICAgXCJvbkNsaWNrXCIsXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgcHJvcHMub25DbGljayxcbiAgICAgICAgICAgIHZvaWQgMCxcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudFxuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSBpZiAocGF0Y2hGbGFnICYgNCAmJiBpc1JlYWN0aXZlKHByb3BzLnN0eWxlKSkge1xuICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIHByb3BzLnN0eWxlKSBwcm9wcy5zdHlsZVtrZXldO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBsZXQgdm5vZGVIb29rcztcbiAgICAgIGlmICh2bm9kZUhvb2tzID0gcHJvcHMgJiYgcHJvcHMub25Wbm9kZUJlZm9yZU1vdW50KSB7XG4gICAgICAgIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2tzLCBwYXJlbnRDb21wb25lbnQsIHZub2RlKTtcbiAgICAgIH1cbiAgICAgIGlmIChkaXJzKSB7XG4gICAgICAgIGludm9rZURpcmVjdGl2ZUhvb2sodm5vZGUsIG51bGwsIHBhcmVudENvbXBvbmVudCwgXCJiZWZvcmVNb3VudFwiKTtcbiAgICAgIH1cbiAgICAgIGlmICgodm5vZGVIb29rcyA9IHByb3BzICYmIHByb3BzLm9uVm5vZGVNb3VudGVkKSB8fCBkaXJzIHx8IG5lZWRDYWxsVHJhbnNpdGlvbkhvb2tzKSB7XG4gICAgICAgIHF1ZXVlRWZmZWN0V2l0aFN1c3BlbnNlKCgpID0+IHtcbiAgICAgICAgICB2bm9kZUhvb2tzICYmIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2tzLCBwYXJlbnRDb21wb25lbnQsIHZub2RlKTtcbiAgICAgICAgICBuZWVkQ2FsbFRyYW5zaXRpb25Ib29rcyAmJiB0cmFuc2l0aW9uLmVudGVyKGVsKTtcbiAgICAgICAgICBkaXJzICYmIGludm9rZURpcmVjdGl2ZUhvb2sodm5vZGUsIG51bGwsIHBhcmVudENvbXBvbmVudCwgXCJtb3VudGVkXCIpO1xuICAgICAgICB9LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBlbC5uZXh0U2libGluZztcbiAgfTtcbiAgY29uc3QgaHlkcmF0ZUNoaWxkcmVuID0gKG5vZGUsIHBhcmVudFZOb2RlLCBjb250YWluZXIsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkKSA9PiB7XG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkIHx8ICEhcGFyZW50Vk5vZGUuZHluYW1pY0NoaWxkcmVuO1xuICAgIGNvbnN0IGNoaWxkcmVuID0gcGFyZW50Vk5vZGUuY2hpbGRyZW47XG4gICAgY29uc3QgbCA9IGNoaWxkcmVuLmxlbmd0aDtcbiAgICBsZXQgaGFzQ2hlY2tlZE1pc21hdGNoID0gZmFsc2U7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsOyBpKyspIHtcbiAgICAgIGNvbnN0IHZub2RlID0gb3B0aW1pemVkID8gY2hpbGRyZW5baV0gOiBjaGlsZHJlbltpXSA9IG5vcm1hbGl6ZVZOb2RlKGNoaWxkcmVuW2ldKTtcbiAgICAgIGNvbnN0IGlzVGV4dCA9IHZub2RlLnR5cGUgPT09IFRleHQ7XG4gICAgICBpZiAobm9kZSkge1xuICAgICAgICBpZiAoaXNUZXh0ICYmICFvcHRpbWl6ZWQpIHtcbiAgICAgICAgICBpZiAoaSArIDEgPCBsICYmIG5vcm1hbGl6ZVZOb2RlKGNoaWxkcmVuW2kgKyAxXSkudHlwZSA9PT0gVGV4dCkge1xuICAgICAgICAgICAgaW5zZXJ0KFxuICAgICAgICAgICAgICBjcmVhdGVUZXh0KFxuICAgICAgICAgICAgICAgIG5vZGUuZGF0YS5zbGljZSh2bm9kZS5jaGlsZHJlbi5sZW5ndGgpXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgICAgbmV4dFNpYmxpbmcobm9kZSlcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBub2RlLmRhdGEgPSB2bm9kZS5jaGlsZHJlbjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbm9kZSA9IGh5ZHJhdGVOb2RlKFxuICAgICAgICAgIG5vZGUsXG4gICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSBpZiAoaXNUZXh0ICYmICF2bm9kZS5jaGlsZHJlbikge1xuICAgICAgICBpbnNlcnQodm5vZGUuZWwgPSBjcmVhdGVUZXh0KFwiXCIpLCBjb250YWluZXIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKCFoYXNDaGVja2VkTWlzbWF0Y2gpIHtcbiAgICAgICAgICBoYXNDaGVja2VkTWlzbWF0Y2ggPSB0cnVlO1xuICAgICAgICAgIGlmICghaXNNaXNtYXRjaEFsbG93ZWQoY29udGFpbmVyLCAxIC8qIENISUxEUkVOICovKSkge1xuICAgICAgICAgICAgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fKSAmJiB3YXJuJDEoXG4gICAgICAgICAgICAgIGBIeWRyYXRpb24gY2hpbGRyZW4gbWlzbWF0Y2ggb25gLFxuICAgICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICAgIGBcblNlcnZlciByZW5kZXJlZCBlbGVtZW50IGNvbnRhaW5zIGZld2VyIGNoaWxkIG5vZGVzIHRoYW4gY2xpZW50IHZkb20uYFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGxvZ01pc21hdGNoRXJyb3IoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcGF0Y2goXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgZ2V0Q29udGFpbmVyVHlwZShjb250YWluZXIpLFxuICAgICAgICAgIHNsb3RTY29wZUlkc1xuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfTtcbiAgY29uc3QgaHlkcmF0ZUZyYWdtZW50ID0gKG5vZGUsIHZub2RlLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCkgPT4ge1xuICAgIGNvbnN0IHsgc2xvdFNjb3BlSWRzOiBmcmFnbWVudFNsb3RTY29wZUlkcyB9ID0gdm5vZGU7XG4gICAgaWYgKGZyYWdtZW50U2xvdFNjb3BlSWRzKSB7XG4gICAgICBzbG90U2NvcGVJZHMgPSBzbG90U2NvcGVJZHMgPyBzbG90U2NvcGVJZHMuY29uY2F0KGZyYWdtZW50U2xvdFNjb3BlSWRzKSA6IGZyYWdtZW50U2xvdFNjb3BlSWRzO1xuICAgIH1cbiAgICBjb25zdCBjb250YWluZXIgPSBwYXJlbnROb2RlKG5vZGUpO1xuICAgIGNvbnN0IG5leHQgPSBoeWRyYXRlQ2hpbGRyZW4oXG4gICAgICBuZXh0U2libGluZyhub2RlKSxcbiAgICAgIHZub2RlLFxuICAgICAgY29udGFpbmVyLFxuICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICBzbG90U2NvcGVJZHMsXG4gICAgICBvcHRpbWl6ZWRcbiAgICApO1xuICAgIGlmIChuZXh0ICYmIGlzQ29tbWVudChuZXh0KSAmJiBuZXh0LmRhdGEgPT09IFwiXVwiKSB7XG4gICAgICByZXR1cm4gbmV4dFNpYmxpbmcodm5vZGUuYW5jaG9yID0gbmV4dCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxvZ01pc21hdGNoRXJyb3IoKTtcbiAgICAgIGluc2VydCh2bm9kZS5hbmNob3IgPSBjcmVhdGVDb21tZW50KGBdYCksIGNvbnRhaW5lciwgbmV4dCk7XG4gICAgICByZXR1cm4gbmV4dDtcbiAgICB9XG4gIH07XG4gIGNvbnN0IGhhbmRsZU1pc21hdGNoID0gKG5vZGUsIHZub2RlLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBzbG90U2NvcGVJZHMsIGlzRnJhZ21lbnQpID0+IHtcbiAgICBpZiAoIWlzTm9kZU1pc21hdGNoQWxsb3dlZChub2RlLCB2bm9kZSkpIHtcbiAgICAgICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfSFlEUkFUSU9OX01JU01BVENIX0RFVEFJTFNfXykgJiYgd2FybiQxKFxuICAgICAgICBgSHlkcmF0aW9uIG5vZGUgbWlzbWF0Y2g6XG4tIHJlbmRlcmVkIG9uIHNlcnZlcjpgLFxuICAgICAgICBub2RlLFxuICAgICAgICBub2RlLm5vZGVUeXBlID09PSAzID8gYCh0ZXh0KWAgOiBpc0NvbW1lbnQobm9kZSkgJiYgbm9kZS5kYXRhID09PSBcIltcIiA/IGAoc3RhcnQgb2YgZnJhZ21lbnQpYCA6IGBgLFxuICAgICAgICBgXG4tIGV4cGVjdGVkIG9uIGNsaWVudDpgLFxuICAgICAgICB2bm9kZS50eXBlXG4gICAgICApO1xuICAgICAgbG9nTWlzbWF0Y2hFcnJvcigpO1xuICAgIH1cbiAgICB2bm9kZS5lbCA9IG51bGw7XG4gICAgaWYgKGlzRnJhZ21lbnQpIHtcbiAgICAgIGNvbnN0IGVuZCA9IGxvY2F0ZUNsb3NpbmdBbmNob3Iobm9kZSk7XG4gICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICBjb25zdCBuZXh0MiA9IG5leHRTaWJsaW5nKG5vZGUpO1xuICAgICAgICBpZiAobmV4dDIgJiYgbmV4dDIgIT09IGVuZCkge1xuICAgICAgICAgIHJlbW92ZShuZXh0Mik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgbmV4dCA9IG5leHRTaWJsaW5nKG5vZGUpO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IHBhcmVudE5vZGUobm9kZSk7XG4gICAgcmVtb3ZlKG5vZGUpO1xuICAgIHBhdGNoKFxuICAgICAgbnVsbCxcbiAgICAgIHZub2RlLFxuICAgICAgY29udGFpbmVyLFxuICAgICAgbmV4dCxcbiAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgZ2V0Q29udGFpbmVyVHlwZShjb250YWluZXIpLFxuICAgICAgc2xvdFNjb3BlSWRzXG4gICAgKTtcbiAgICBpZiAocGFyZW50Q29tcG9uZW50KSB7XG4gICAgICBwYXJlbnRDb21wb25lbnQudm5vZGUuZWwgPSB2bm9kZS5lbDtcbiAgICAgIHVwZGF0ZUhPQ0hvc3RFbChwYXJlbnRDb21wb25lbnQsIHZub2RlLmVsKTtcbiAgICB9XG4gICAgcmV0dXJuIG5leHQ7XG4gIH07XG4gIGNvbnN0IGxvY2F0ZUNsb3NpbmdBbmNob3IgPSAobm9kZSwgb3BlbiA9IFwiW1wiLCBjbG9zZSA9IFwiXVwiKSA9PiB7XG4gICAgbGV0IG1hdGNoID0gMDtcbiAgICB3aGlsZSAobm9kZSkge1xuICAgICAgbm9kZSA9IG5leHRTaWJsaW5nKG5vZGUpO1xuICAgICAgaWYgKG5vZGUgJiYgaXNDb21tZW50KG5vZGUpKSB7XG4gICAgICAgIGlmIChub2RlLmRhdGEgPT09IG9wZW4pIG1hdGNoKys7XG4gICAgICAgIGlmIChub2RlLmRhdGEgPT09IGNsb3NlKSB7XG4gICAgICAgICAgaWYgKG1hdGNoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV4dFNpYmxpbmcobm9kZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG1hdGNoLS07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9O1xuICBjb25zdCByZXBsYWNlTm9kZSA9IChuZXdOb2RlLCBvbGROb2RlLCBwYXJlbnRDb21wb25lbnQpID0+IHtcbiAgICBjb25zdCBwYXJlbnROb2RlMiA9IG9sZE5vZGUucGFyZW50Tm9kZTtcbiAgICBpZiAocGFyZW50Tm9kZTIpIHtcbiAgICAgIHBhcmVudE5vZGUyLnJlcGxhY2VDaGlsZChuZXdOb2RlLCBvbGROb2RlKTtcbiAgICB9XG4gICAgbGV0IHBhcmVudCA9IHBhcmVudENvbXBvbmVudDtcbiAgICB3aGlsZSAocGFyZW50KSB7XG4gICAgICBpZiAocGFyZW50LnZub2RlLmVsID09PSBvbGROb2RlKSB7XG4gICAgICAgIHBhcmVudC52bm9kZS5lbCA9IHBhcmVudC5zdWJUcmVlLmVsID0gbmV3Tm9kZTtcbiAgICAgIH1cbiAgICAgIHBhcmVudCA9IHBhcmVudC5wYXJlbnQ7XG4gICAgfVxuICB9O1xuICBjb25zdCBpc1RlbXBsYXRlTm9kZSA9IChub2RlKSA9PiB7XG4gICAgcmV0dXJuIG5vZGUubm9kZVR5cGUgPT09IDEgJiYgbm9kZS50YWdOYW1lID09PSBcIlRFTVBMQVRFXCI7XG4gIH07XG4gIHJldHVybiBbaHlkcmF0ZSwgaHlkcmF0ZU5vZGVdO1xufVxuY29uc3QgcmVzb3VyY2VQcm9wcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcInNyY1wiLCBcInNyY3NldFwiLCBcImhyZWZcIiwgXCJwb3N0ZXJcIl0pO1xuZnVuY3Rpb24gaXNVbmNoYW5nZWRSZXNvdXJjZVByb3AoZWwsIGtleSwgY2xpZW50VmFsdWUpIHtcbiAgaWYgKCFyZXNvdXJjZVByb3BzLmhhcyhrZXkpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiBlbC5nZXRBdHRyaWJ1dGUoa2V5KSA9PT0gKGNsaWVudFZhbHVlID09IG51bGwgPyBudWxsIDogYCR7Y2xpZW50VmFsdWV9YCk7XG59XG5mdW5jdGlvbiBwcm9wSGFzTWlzbWF0Y2goZWwsIGtleSwgY2xpZW50VmFsdWUsIHZub2RlLCBpbnN0YW5jZSkge1xuICBsZXQgbWlzbWF0Y2hUeXBlO1xuICBsZXQgbWlzbWF0Y2hLZXk7XG4gIGxldCBhY3R1YWw7XG4gIGxldCBleHBlY3RlZDtcbiAgaWYgKGtleSA9PT0gXCJjbGFzc1wiKSB7XG4gICAgaWYgKGVsLiRjbHMpIHtcbiAgICAgIGFjdHVhbCA9IGVsLiRjbHM7XG4gICAgICBkZWxldGUgZWwuJGNscztcbiAgICB9IGVsc2Uge1xuICAgICAgYWN0dWFsID0gZWwuZ2V0QXR0cmlidXRlKFwiY2xhc3NcIik7XG4gICAgfVxuICAgIGV4cGVjdGVkID0gbm9ybWFsaXplQ2xhc3MoY2xpZW50VmFsdWUpO1xuICAgIGlmICghaXNTZXRFcXVhbCh0b0NsYXNzU2V0KGFjdHVhbCB8fCBcIlwiKSwgdG9DbGFzc1NldChleHBlY3RlZCkpKSB7XG4gICAgICBtaXNtYXRjaFR5cGUgPSAyIC8qIENMQVNTICovO1xuICAgICAgbWlzbWF0Y2hLZXkgPSBgY2xhc3NgO1xuICAgIH1cbiAgfSBlbHNlIGlmIChrZXkgPT09IFwic3R5bGVcIikge1xuICAgIGFjdHVhbCA9IGVsLmdldEF0dHJpYnV0ZShcInN0eWxlXCIpIHx8IFwiXCI7XG4gICAgZXhwZWN0ZWQgPSBpc1N0cmluZyhjbGllbnRWYWx1ZSkgPyBjbGllbnRWYWx1ZSA6IHN0cmluZ2lmeVN0eWxlKG5vcm1hbGl6ZVN0eWxlKGNsaWVudFZhbHVlKSk7XG4gICAgY29uc3QgYWN0dWFsTWFwID0gdG9TdHlsZU1hcChhY3R1YWwpO1xuICAgIGNvbnN0IGV4cGVjdGVkTWFwID0gdG9TdHlsZU1hcChleHBlY3RlZCk7XG4gICAgaWYgKHZub2RlLmRpcnMpIHtcbiAgICAgIGZvciAoY29uc3QgeyBkaXIsIHZhbHVlIH0gb2Ygdm5vZGUuZGlycykge1xuICAgICAgICBpZiAoZGlyLm5hbWUgPT09IFwic2hvd1wiICYmICF2YWx1ZSkge1xuICAgICAgICAgIGV4cGVjdGVkTWFwLnNldChcImRpc3BsYXlcIiwgXCJub25lXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChpbnN0YW5jZSkge1xuICAgICAgcmVzb2x2ZUNzc1ZhcnMoaW5zdGFuY2UsIHZub2RlLCBleHBlY3RlZE1hcCk7XG4gICAgfVxuICAgIGlmICghaXNNYXBFcXVhbChhY3R1YWxNYXAsIGV4cGVjdGVkTWFwKSkge1xuICAgICAgbWlzbWF0Y2hUeXBlID0gMyAvKiBTVFlMRSAqLztcbiAgICAgIG1pc21hdGNoS2V5ID0gXCJzdHlsZVwiO1xuICAgIH1cbiAgfSBlbHNlIGlmIChlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQgJiYgaXNLbm93blN2Z0F0dHIoa2V5KSB8fCBlbCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50ICYmIChpc0Jvb2xlYW5BdHRyKGtleSkgfHwgaXNLbm93bkh0bWxBdHRyKGtleSkpKSB7XG4gICAgaWYgKGtleSA9PT0gXCJoaWRkZW5cIikge1xuICAgICAgYWN0dWFsID0gbm9ybWFsaXplSGlkZGVuVmFsdWUoZWwuZ2V0QXR0cmlidXRlKGtleSkpO1xuICAgICAgZXhwZWN0ZWQgPSBub3JtYWxpemVIaWRkZW5WYWx1ZShjbGllbnRWYWx1ZSk7XG4gICAgfSBlbHNlIGlmIChpc0Jvb2xlYW5BdHRyKGtleSkpIHtcbiAgICAgIGFjdHVhbCA9IGVsLmhhc0F0dHJpYnV0ZShrZXkpO1xuICAgICAgZXhwZWN0ZWQgPSBpbmNsdWRlQm9vbGVhbkF0dHIoY2xpZW50VmFsdWUpO1xuICAgIH0gZWxzZSBpZiAoY2xpZW50VmFsdWUgPT0gbnVsbCkge1xuICAgICAgYWN0dWFsID0gZWwuaGFzQXR0cmlidXRlKGtleSk7XG4gICAgICBleHBlY3RlZCA9IGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoZWwuaGFzQXR0cmlidXRlKGtleSkpIHtcbiAgICAgICAgYWN0dWFsID0gZWwuZ2V0QXR0cmlidXRlKGtleSk7XG4gICAgICB9IGVsc2UgaWYgKGtleSA9PT0gXCJ2YWx1ZVwiICYmIGVsLnRhZ05hbWUgPT09IFwiVEVYVEFSRUFcIikge1xuICAgICAgICBhY3R1YWwgPSBlbC52YWx1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFjdHVhbCA9IGZhbHNlO1xuICAgICAgfVxuICAgICAgZXhwZWN0ZWQgPSBpc1JlbmRlcmFibGVBdHRyVmFsdWUoY2xpZW50VmFsdWUpID8gU3RyaW5nKGNsaWVudFZhbHVlKSA6IGZhbHNlO1xuICAgIH1cbiAgICBpZiAoYWN0dWFsICE9PSBleHBlY3RlZCkge1xuICAgICAgbWlzbWF0Y2hUeXBlID0gNCAvKiBBVFRSSUJVVEUgKi87XG4gICAgICBtaXNtYXRjaEtleSA9IGtleTtcbiAgICB9XG4gIH1cbiAgaWYgKG1pc21hdGNoVHlwZSAhPSBudWxsICYmICFpc01pc21hdGNoQWxsb3dlZChlbCwgbWlzbWF0Y2hUeXBlKSkge1xuICAgIGNvbnN0IGZvcm1hdCA9ICh2KSA9PiB2ID09PSBmYWxzZSA/IGAobm90IHJlbmRlcmVkKWAgOiBgJHttaXNtYXRjaEtleX09XCIke3Z9XCJgO1xuICAgIGNvbnN0IHByZVNlZ21lbnQgPSBgSHlkcmF0aW9uICR7TWlzbWF0Y2hUeXBlU3RyaW5nW21pc21hdGNoVHlwZV19IG1pc21hdGNoIG9uYDtcbiAgICBjb25zdCBwb3N0U2VnbWVudCA9IGBcbiAgLSByZW5kZXJlZCBvbiBzZXJ2ZXI6ICR7Zm9ybWF0KGFjdHVhbCl9XG4gIC0gZXhwZWN0ZWQgb24gY2xpZW50OiAke2Zvcm1hdChleHBlY3RlZCl9XG4gIE5vdGU6IHRoaXMgbWlzbWF0Y2ggaXMgY2hlY2stb25seS4gVGhlIERPTSB3aWxsIG5vdCBiZSByZWN0aWZpZWQgaW4gcHJvZHVjdGlvbiBkdWUgdG8gcGVyZm9ybWFuY2Ugb3ZlcmhlYWQuXG4gIFlvdSBzaG91bGQgZml4IHRoZSBzb3VyY2Ugb2YgdGhlIG1pc21hdGNoLmA7XG4gICAge1xuICAgICAgd2FybiQxKHByZVNlZ21lbnQsIGVsLCBwb3N0U2VnbWVudCk7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUhpZGRlblZhbHVlKHZhbHVlKSB7XG4gIGlmICghaXNSZW5kZXJhYmxlQXR0clZhbHVlKHZhbHVlKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlLnRvTG93ZXJDYXNlKCkgPT09IFwidW50aWwtZm91bmRcIiA/IFwidW50aWwtZm91bmRcIiA6IFwiXCI7XG4gIH1cbiAgcmV0dXJuIGluY2x1ZGVCb29sZWFuQXR0cih2YWx1ZSkgPyBcIlwiIDogZmFsc2U7XG59XG5mdW5jdGlvbiB0b0NsYXNzU2V0KHN0cikge1xuICByZXR1cm4gbmV3IFNldChzdHIudHJpbSgpLnNwbGl0KC9cXHMrLykpO1xufVxuZnVuY3Rpb24gaXNTZXRFcXVhbChhLCBiKSB7XG4gIGlmIChhLnNpemUgIT09IGIuc2l6ZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBmb3IgKGNvbnN0IHMgb2YgYSkge1xuICAgIGlmICghYi5oYXMocykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiB0b1N0eWxlTWFwKHN0cikge1xuICBjb25zdCBzdHlsZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIGZvciAoY29uc3QgaXRlbSBvZiBzdHIuc3BsaXQoXCI7XCIpKSB7XG4gICAgbGV0IFtrZXksIHZhbHVlXSA9IGl0ZW0uc3BsaXQoXCI6XCIpO1xuICAgIGtleSA9IGtleS50cmltKCk7XG4gICAgdmFsdWUgPSB2YWx1ZSAmJiB2YWx1ZS50cmltKCk7XG4gICAgaWYgKGtleSAmJiB2YWx1ZSkge1xuICAgICAgc3R5bGVNYXAuc2V0KGtleSwgdmFsdWUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc3R5bGVNYXA7XG59XG5mdW5jdGlvbiBpc01hcEVxdWFsKGEsIGIpIHtcbiAgaWYgKGEuc2l6ZSAhPT0gYi5zaXplKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIGEpIHtcbiAgICBpZiAodmFsdWUgIT09IGIuZ2V0KGtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiByZXNvbHZlQ3NzVmFycyhpbnN0YW5jZSwgdm5vZGUsIGV4cGVjdGVkTWFwKSB7XG4gIGNvbnN0IHJvb3QgPSBpbnN0YW5jZS5zdWJUcmVlO1xuICBpZiAoaW5zdGFuY2UuZ2V0Q3NzVmFycyAmJiAodm5vZGUgPT09IHJvb3QgfHwgcm9vdCAmJiByb290LnR5cGUgPT09IEZyYWdtZW50ICYmIHJvb3QuY2hpbGRyZW4uaW5jbHVkZXModm5vZGUpKSkge1xuICAgIGNvbnN0IGNzc1ZhcnMgPSBpbnN0YW5jZS5nZXRDc3NWYXJzKCk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gY3NzVmFycykge1xuICAgICAgY29uc3QgdmFsdWUgPSBub3JtYWxpemVDc3NWYXJWYWx1ZShjc3NWYXJzW2tleV0pO1xuICAgICAgZXhwZWN0ZWRNYXAuc2V0KGAtLSR7Z2V0RXNjYXBlZENzc1Zhck5hbWUoa2V5LCBmYWxzZSl9YCwgdmFsdWUpO1xuICAgIH1cbiAgfVxuICBpZiAodm5vZGUgPT09IHJvb3QgJiYgaW5zdGFuY2UucGFyZW50KSB7XG4gICAgcmVzb2x2ZUNzc1ZhcnMoaW5zdGFuY2UucGFyZW50LCBpbnN0YW5jZS52bm9kZSwgZXhwZWN0ZWRNYXApO1xuICB9XG59XG5jb25zdCBhbGxvd01pc21hdGNoQXR0ciA9IFwiZGF0YS1hbGxvdy1taXNtYXRjaFwiO1xuY29uc3QgTWlzbWF0Y2hUeXBlU3RyaW5nID0ge1xuICBbMCAvKiBURVhUICovXTogXCJ0ZXh0XCIsXG4gIFsxIC8qIENISUxEUkVOICovXTogXCJjaGlsZHJlblwiLFxuICBbMiAvKiBDTEFTUyAqL106IFwiY2xhc3NcIixcbiAgWzMgLyogU1RZTEUgKi9dOiBcInN0eWxlXCIsXG4gIFs0IC8qIEFUVFJJQlVURSAqL106IFwiYXR0cmlidXRlXCJcbn07XG5mdW5jdGlvbiBpc01pc21hdGNoQWxsb3dlZChlbCwgYWxsb3dlZFR5cGUpIHtcbiAgaWYgKGFsbG93ZWRUeXBlID09PSAwIC8qIFRFWFQgKi8gfHwgYWxsb3dlZFR5cGUgPT09IDEgLyogQ0hJTERSRU4gKi8pIHtcbiAgICB3aGlsZSAoZWwgJiYgIWVsLmhhc0F0dHJpYnV0ZShhbGxvd01pc21hdGNoQXR0cikpIHtcbiAgICAgIGVsID0gZWwucGFyZW50RWxlbWVudDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGlzTWlzbWF0Y2hBbGxvd2VkQnlBdHRyKFxuICAgIGVsICYmIGVsLmdldEF0dHJpYnV0ZShhbGxvd01pc21hdGNoQXR0ciksXG4gICAgYWxsb3dlZFR5cGVcbiAgKTtcbn1cbmZ1bmN0aW9uIGlzTWlzbWF0Y2hBbGxvd2VkQnlBdHRyKGFsbG93ZWRBdHRyLCBhbGxvd2VkVHlwZSkge1xuICBpZiAoYWxsb3dlZEF0dHIgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfSBlbHNlIGlmIChhbGxvd2VkQXR0ciA9PT0gXCJcIikge1xuICAgIHJldHVybiB0cnVlO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGxpc3QgPSBhbGxvd2VkQXR0ci5zcGxpdChcIixcIik7XG4gICAgaWYgKGFsbG93ZWRUeXBlID09PSAwIC8qIFRFWFQgKi8gJiYgbGlzdC5pbmNsdWRlcyhcImNoaWxkcmVuXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGxpc3QuaW5jbHVkZXMoTWlzbWF0Y2hUeXBlU3RyaW5nW2FsbG93ZWRUeXBlXSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGlzTm9kZU1pc21hdGNoQWxsb3dlZChub2RlLCB2bm9kZSkge1xuICByZXR1cm4gaXNNaXNtYXRjaEFsbG93ZWQobm9kZS5wYXJlbnRFbGVtZW50LCAxIC8qIENISUxEUkVOICovKSB8fCBpc01pc21hdGNoQWxsb3dlZEJ5Tm9kZShub2RlKSB8fCBpc01pc21hdGNoQWxsb3dlZEJ5Vk5vZGUodm5vZGUpO1xufVxuZnVuY3Rpb24gaXNNaXNtYXRjaEFsbG93ZWRCeU5vZGUobm9kZSkge1xuICByZXR1cm4gbm9kZS5ub2RlVHlwZSA9PT0gMSAmJiBpc01pc21hdGNoQWxsb3dlZEJ5QXR0cihcbiAgICBub2RlLmdldEF0dHJpYnV0ZShhbGxvd01pc21hdGNoQXR0ciksXG4gICAgMSAvKiBDSElMRFJFTiAqL1xuICApO1xufVxuZnVuY3Rpb24gaXNNaXNtYXRjaEFsbG93ZWRCeVZOb2RlKHsgcHJvcHMgfSkge1xuICBjb25zdCBhbGxvd2VkQXR0ciA9IHByb3BzICYmIHByb3BzW2FsbG93TWlzbWF0Y2hBdHRyXTtcbiAgcmV0dXJuIHR5cGVvZiBhbGxvd2VkQXR0ciA9PT0gXCJzdHJpbmdcIiAmJiBpc01pc21hdGNoQWxsb3dlZEJ5QXR0cihhbGxvd2VkQXR0ciwgMSAvKiBDSElMRFJFTiAqLyk7XG59XG5cbmNvbnN0IHJlcXVlc3RJZGxlQ2FsbGJhY2sgPSBnZXRHbG9iYWxUaGlzKCkucmVxdWVzdElkbGVDYWxsYmFjayB8fCAoKGNiKSA9PiBzZXRUaW1lb3V0KGNiLCAxKSk7XG5jb25zdCBjYW5jZWxJZGxlQ2FsbGJhY2sgPSBnZXRHbG9iYWxUaGlzKCkuY2FuY2VsSWRsZUNhbGxiYWNrIHx8ICgoaWQpID0+IGNsZWFyVGltZW91dChpZCkpO1xuY29uc3QgaHlkcmF0ZU9uSWRsZSA9ICh0aW1lb3V0ID0gMWU0KSA9PiAoaHlkcmF0ZSkgPT4ge1xuICBjb25zdCBpZCA9IHJlcXVlc3RJZGxlQ2FsbGJhY2soaHlkcmF0ZSwgeyB0aW1lb3V0IH0pO1xuICByZXR1cm4gKCkgPT4gY2FuY2VsSWRsZUNhbGxiYWNrKGlkKTtcbn07XG5mdW5jdGlvbiBlbGVtZW50SXNWaXNpYmxlSW5WaWV3cG9ydChlbCkge1xuICBjb25zdCB7IHRvcCwgbGVmdCwgYm90dG9tLCByaWdodCB9ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGNvbnN0IHsgaW5uZXJIZWlnaHQsIGlubmVyV2lkdGggfSA9IHdpbmRvdztcbiAgcmV0dXJuICh0b3AgPiAwICYmIHRvcCA8IGlubmVySGVpZ2h0IHx8IGJvdHRvbSA+IDAgJiYgYm90dG9tIDwgaW5uZXJIZWlnaHQpICYmIChsZWZ0ID4gMCAmJiBsZWZ0IDwgaW5uZXJXaWR0aCB8fCByaWdodCA+IDAgJiYgcmlnaHQgPCBpbm5lcldpZHRoKTtcbn1cbmNvbnN0IGh5ZHJhdGVPblZpc2libGUgPSAob3B0cykgPT4gKGh5ZHJhdGUsIGZvckVhY2gpID0+IHtcbiAgY29uc3Qgb2IgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICBmb3IgKGNvbnN0IGUgb2YgZW50cmllcykge1xuICAgICAgaWYgKCFlLmlzSW50ZXJzZWN0aW5nKSBjb250aW51ZTtcbiAgICAgIG9iLmRpc2Nvbm5lY3QoKTtcbiAgICAgIGh5ZHJhdGUoKTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfSwgb3B0cyk7XG4gIGZvckVhY2goKGVsKSA9PiB7XG4gICAgaWYgKCEoZWwgaW5zdGFuY2VvZiBFbGVtZW50KSkgcmV0dXJuO1xuICAgIGlmIChlbGVtZW50SXNWaXNpYmxlSW5WaWV3cG9ydChlbCkpIHtcbiAgICAgIGh5ZHJhdGUoKTtcbiAgICAgIG9iLmRpc2Nvbm5lY3QoKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgb2Iub2JzZXJ2ZShlbCk7XG4gIH0pO1xuICByZXR1cm4gKCkgPT4gb2IuZGlzY29ubmVjdCgpO1xufTtcbmNvbnN0IGh5ZHJhdGVPbk1lZGlhUXVlcnkgPSAocXVlcnkpID0+IChoeWRyYXRlKSA9PiB7XG4gIGlmIChxdWVyeSkge1xuICAgIGNvbnN0IG1xbCA9IG1hdGNoTWVkaWEocXVlcnkpO1xuICAgIGlmIChtcWwubWF0Y2hlcykge1xuICAgICAgaHlkcmF0ZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBtcWwuYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCBoeWRyYXRlLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgICByZXR1cm4gKCkgPT4gbXFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgaHlkcmF0ZSk7XG4gICAgfVxuICB9XG59O1xuY29uc3QgaHlkcmF0ZU9uSW50ZXJhY3Rpb24gPSAoaW50ZXJhY3Rpb25zID0gW10pID0+IChoeWRyYXRlLCBmb3JFYWNoKSA9PiB7XG4gIGlmIChpc1N0cmluZyhpbnRlcmFjdGlvbnMpKSBpbnRlcmFjdGlvbnMgPSBbaW50ZXJhY3Rpb25zXTtcbiAgbGV0IGhhc0h5ZHJhdGVkID0gZmFsc2U7XG4gIGNvbnN0IGRvSHlkcmF0ZSA9IChlKSA9PiB7XG4gICAgaWYgKCFoYXNIeWRyYXRlZCkge1xuICAgICAgaGFzSHlkcmF0ZWQgPSB0cnVlO1xuICAgICAgdGVhcmRvd24oKTtcbiAgICAgIGh5ZHJhdGUoKTtcbiAgICAgIGUudGFyZ2V0LmRpc3BhdGNoRXZlbnQobmV3IGUuY29uc3RydWN0b3IoZS50eXBlLCBlKSk7XG4gICAgfVxuICB9O1xuICBjb25zdCB0ZWFyZG93biA9ICgpID0+IHtcbiAgICBmb3JFYWNoKChlbCkgPT4ge1xuICAgICAgZm9yIChjb25zdCBpIG9mIGludGVyYWN0aW9ucykge1xuICAgICAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKGksIGRvSHlkcmF0ZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG4gIGZvckVhY2goKGVsKSA9PiB7XG4gICAgZm9yIChjb25zdCBpIG9mIGludGVyYWN0aW9ucykge1xuICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcihpLCBkb0h5ZHJhdGUsIHsgb25jZTogdHJ1ZSB9KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gdGVhcmRvd247XG59O1xuZnVuY3Rpb24gZm9yRWFjaEVsZW1lbnQobm9kZSwgY2IpIHtcbiAgaWYgKGlzQ29tbWVudChub2RlKSAmJiBub2RlLmRhdGEgPT09IFwiW1wiKSB7XG4gICAgbGV0IGRlcHRoID0gMTtcbiAgICBsZXQgbmV4dCA9IG5vZGUubmV4dFNpYmxpbmc7XG4gICAgd2hpbGUgKG5leHQpIHtcbiAgICAgIGlmIChuZXh0Lm5vZGVUeXBlID09PSAxKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGNiKG5leHQpO1xuICAgICAgICBpZiAocmVzdWx0ID09PSBmYWxzZSkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGlzQ29tbWVudChuZXh0KSkge1xuICAgICAgICBpZiAobmV4dC5kYXRhID09PSBcIl1cIikge1xuICAgICAgICAgIGlmICgtLWRlcHRoID09PSAwKSBicmVhaztcbiAgICAgICAgfSBlbHNlIGlmIChuZXh0LmRhdGEgPT09IFwiW1wiKSB7XG4gICAgICAgICAgZGVwdGgrKztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgbmV4dCA9IG5leHQubmV4dFNpYmxpbmc7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGNiKG5vZGUpO1xuICB9XG59XG5cbmNvbnN0IGlzQXN5bmNXcmFwcGVyID0gKGkpID0+ICEhaS50eXBlLl9fYXN5bmNMb2FkZXI7XG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gZGVmaW5lQXN5bmNDb21wb25lbnQoc291cmNlKSB7XG4gIGlmIChpc0Z1bmN0aW9uKHNvdXJjZSkpIHtcbiAgICBzb3VyY2UgPSB7IGxvYWRlcjogc291cmNlIH07XG4gIH1cbiAgY29uc3Qge1xuICAgIGxvYWRlcixcbiAgICBsb2FkaW5nQ29tcG9uZW50LFxuICAgIGVycm9yQ29tcG9uZW50LFxuICAgIGRlbGF5ID0gMjAwLFxuICAgIGh5ZHJhdGU6IGh5ZHJhdGVTdHJhdGVneSxcbiAgICB0aW1lb3V0LFxuICAgIC8vIHVuZGVmaW5lZCA9IG5ldmVyIHRpbWVzIG91dFxuICAgIHN1c3BlbnNpYmxlID0gdHJ1ZSxcbiAgICBvbkVycm9yOiB1c2VyT25FcnJvclxuICB9ID0gc291cmNlO1xuICBsZXQgcGVuZGluZ1JlcXVlc3QgPSBudWxsO1xuICBsZXQgcmVzb2x2ZWRDb21wO1xuICBsZXQgcmV0cmllcyA9IDA7XG4gIGNvbnN0IHJldHJ5ID0gKCkgPT4ge1xuICAgIHJldHJpZXMrKztcbiAgICBwZW5kaW5nUmVxdWVzdCA9IG51bGw7XG4gICAgcmV0dXJuIGxvYWQoKTtcbiAgfTtcbiAgY29uc3QgbG9hZCA9ICgpID0+IHtcbiAgICBsZXQgdGhpc1JlcXVlc3Q7XG4gICAgcmV0dXJuIHBlbmRpbmdSZXF1ZXN0IHx8ICh0aGlzUmVxdWVzdCA9IHBlbmRpbmdSZXF1ZXN0ID0gbG9hZGVyKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgZXJyID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpO1xuICAgICAgaWYgKHVzZXJPbkVycm9yKSB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgY29uc3QgdXNlclJldHJ5ID0gKCkgPT4gcmVzb2x2ZShyZXRyeSgpKTtcbiAgICAgICAgICBjb25zdCB1c2VyRmFpbCA9ICgpID0+IHJlamVjdChlcnIpO1xuICAgICAgICAgIHVzZXJPbkVycm9yKGVyciwgdXNlclJldHJ5LCB1c2VyRmFpbCwgcmV0cmllcyArIDEpO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICB9KS50aGVuKChjb21wKSA9PiB7XG4gICAgICBpZiAodGhpc1JlcXVlc3QgIT09IHBlbmRpbmdSZXF1ZXN0ICYmIHBlbmRpbmdSZXF1ZXN0KSB7XG4gICAgICAgIHJldHVybiBwZW5kaW5nUmVxdWVzdDtcbiAgICAgIH1cbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFjb21wKSB7XG4gICAgICAgIHdhcm4kMShcbiAgICAgICAgICBgQXN5bmMgY29tcG9uZW50IGxvYWRlciByZXNvbHZlZCB0byB1bmRlZmluZWQuIElmIHlvdSBhcmUgdXNpbmcgcmV0cnkoKSwgbWFrZSBzdXJlIHRvIHJldHVybiBpdHMgcmV0dXJuIHZhbHVlLmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChjb21wICYmIChjb21wLl9fZXNNb2R1bGUgfHwgY29tcFtTeW1ib2wudG9TdHJpbmdUYWddID09PSBcIk1vZHVsZVwiKSkge1xuICAgICAgICBjb21wID0gY29tcC5kZWZhdWx0O1xuICAgICAgfVxuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgY29tcCAmJiAhaXNPYmplY3QoY29tcCkgJiYgIWlzRnVuY3Rpb24oY29tcCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGFzeW5jIGNvbXBvbmVudCBsb2FkIHJlc3VsdDogJHtjb21wfWApO1xuICAgICAgfVxuICAgICAgcmVzb2x2ZWRDb21wID0gY29tcDtcbiAgICAgIHJldHVybiBjb21wO1xuICAgIH0pKTtcbiAgfTtcbiAgcmV0dXJuIGRlZmluZUNvbXBvbmVudCh7XG4gICAgbmFtZTogXCJBc3luY0NvbXBvbmVudFdyYXBwZXJcIixcbiAgICBfX2FzeW5jTG9hZGVyOiBsb2FkLFxuICAgIF9fYXN5bmNIeWRyYXRlKGVsLCBpbnN0YW5jZSwgaHlkcmF0ZSkge1xuICAgICAgY29uc3Qgd2FzQ29ubmVjdGVkID0gZWwuaXNDb25uZWN0ZWQ7XG4gICAgICBsZXQgcGF0Y2hlZCA9IGZhbHNlO1xuICAgICAgKGluc3RhbmNlLmJ1IHx8IChpbnN0YW5jZS5idSA9IFtdKSkucHVzaCgoKSA9PiBwYXRjaGVkID0gdHJ1ZSk7XG4gICAgICBjb25zdCBwZXJmb3JtSHlkcmF0ZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKHBhdGNoZWQpIHtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgICBgU2tpcHBpbmcgbGF6eSBoeWRyYXRpb24gZm9yIGNvbXBvbmVudCAnJHtnZXRDb21wb25lbnROYW1lKHJlc29sdmVkQ29tcCkgfHwgcmVzb2x2ZWRDb21wLl9fZmlsZX0nOiBpdCB3YXMgdXBkYXRlZCBiZWZvcmUgbGF6eSBoeWRyYXRpb24gcGVyZm9ybWVkLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWVsLnBhcmVudE5vZGUgfHwgd2FzQ29ubmVjdGVkICYmICFlbC5pc0Nvbm5lY3RlZCkgcmV0dXJuO1xuICAgICAgICBoeWRyYXRlKCk7XG4gICAgICB9O1xuICAgICAgY29uc3QgZG9IeWRyYXRlID0gaHlkcmF0ZVN0cmF0ZWd5ID8gKCkgPT4ge1xuICAgICAgICBjb25zdCB0ZWFyZG93biA9IGh5ZHJhdGVTdHJhdGVneShcbiAgICAgICAgICBwZXJmb3JtSHlkcmF0ZSxcbiAgICAgICAgICAoY2IpID0+IGZvckVhY2hFbGVtZW50KGVsLCBjYilcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHRlYXJkb3duKSB7XG4gICAgICAgICAgKGluc3RhbmNlLmJ1bSB8fCAoaW5zdGFuY2UuYnVtID0gW10pKS5wdXNoKHRlYXJkb3duKTtcbiAgICAgICAgfVxuICAgICAgfSA6IHBlcmZvcm1IeWRyYXRlO1xuICAgICAgaWYgKHJlc29sdmVkQ29tcCkge1xuICAgICAgICBkb0h5ZHJhdGUoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGxvYWQoKS50aGVuKCgpID0+ICFpbnN0YW5jZS5pc1VubW91bnRlZCAmJiBkb0h5ZHJhdGUoKSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBnZXQgX19hc3luY1Jlc29sdmVkKCkge1xuICAgICAgcmV0dXJuIHJlc29sdmVkQ29tcDtcbiAgICB9LFxuICAgIHNldHVwKCkge1xuICAgICAgY29uc3QgaW5zdGFuY2UgPSBjdXJyZW50SW5zdGFuY2U7XG4gICAgICBtYXJrQXN5bmNCb3VuZGFyeShpbnN0YW5jZSk7XG4gICAgICBpZiAocmVzb2x2ZWRDb21wKSB7XG4gICAgICAgIHJldHVybiAoKSA9PiBjcmVhdGVJbm5lckNvbXAocmVzb2x2ZWRDb21wLCBpbnN0YW5jZSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvbkVycm9yID0gKGVycikgPT4ge1xuICAgICAgICBwZW5kaW5nUmVxdWVzdCA9IG51bGw7XG4gICAgICAgIGhhbmRsZUVycm9yKFxuICAgICAgICAgIGVycixcbiAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICAxMyxcbiAgICAgICAgICAhZXJyb3JDb21wb25lbnRcbiAgICAgICAgKTtcbiAgICAgIH07XG4gICAgICBpZiAoc3VzcGVuc2libGUgJiYgaW5zdGFuY2Uuc3VzcGVuc2UgfHwgaXNJblNTUkNvbXBvbmVudFNldHVwKSB7XG4gICAgICAgIHJldHVybiBsb2FkKCkudGhlbigoY29tcCkgPT4ge1xuICAgICAgICAgIHJldHVybiAoKSA9PiBjcmVhdGVJbm5lckNvbXAoY29tcCwgaW5zdGFuY2UpO1xuICAgICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgb25FcnJvcihlcnIpO1xuICAgICAgICAgIHJldHVybiAoKSA9PiBlcnJvckNvbXBvbmVudCA/IGNyZWF0ZVZOb2RlKGVycm9yQ29tcG9uZW50LCB7XG4gICAgICAgICAgICBlcnJvcjogZXJyXG4gICAgICAgICAgfSkgOiBudWxsO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGxvYWRlZCA9IHJlZihmYWxzZSk7XG4gICAgICBjb25zdCBlcnJvciA9IHJlZigpO1xuICAgICAgY29uc3QgZGVsYXllZCA9IHJlZighIWRlbGF5KTtcbiAgICAgIGxldCB0aW1lb3V0VGltZXI7XG4gICAgICBsZXQgZGVsYXlUaW1lcjtcbiAgICAgIG9uVW5tb3VudGVkKCgpID0+IHtcbiAgICAgICAgaWYgKHRpbWVvdXRUaW1lciAhPSBudWxsKSBjbGVhclRpbWVvdXQodGltZW91dFRpbWVyKTtcbiAgICAgICAgaWYgKGRlbGF5VGltZXIgIT0gbnVsbCkgY2xlYXJUaW1lb3V0KGRlbGF5VGltZXIpO1xuICAgICAgfSk7XG4gICAgICBpZiAoZGVsYXkpIHtcbiAgICAgICAgZGVsYXlUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGlmIChpbnN0YW5jZS5pc1VubW91bnRlZCkgcmV0dXJuO1xuICAgICAgICAgIGRlbGF5ZWQudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgfSwgZGVsYXkpO1xuICAgICAgfVxuICAgICAgaWYgKHRpbWVvdXQgIT0gbnVsbCkge1xuICAgICAgICB0aW1lb3V0VGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBpZiAoaW5zdGFuY2UuaXNVbm1vdW50ZWQpIHJldHVybjtcbiAgICAgICAgICBpZiAoIWxvYWRlZC52YWx1ZSAmJiAhZXJyb3IudmFsdWUpIHtcbiAgICAgICAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgYEFzeW5jIGNvbXBvbmVudCB0aW1lZCBvdXQgYWZ0ZXIgJHt0aW1lb3V0fW1zLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBvbkVycm9yKGVycik7XG4gICAgICAgICAgICBlcnJvci52YWx1ZSA9IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIHRpbWVvdXQpO1xuICAgICAgfVxuICAgICAgbG9hZCgpLnRoZW4oKCkgPT4ge1xuICAgICAgICBpZiAoaW5zdGFuY2UuaXNVbm1vdW50ZWQpIHJldHVybjtcbiAgICAgICAgbG9hZGVkLnZhbHVlID0gdHJ1ZTtcbiAgICAgICAgaWYgKGluc3RhbmNlLnBhcmVudCAmJiBpc0tlZXBBbGl2ZShpbnN0YW5jZS5wYXJlbnQudm5vZGUpKSB7XG4gICAgICAgICAgaW5zdGFuY2UucGFyZW50LnVwZGF0ZSgpO1xuICAgICAgICB9XG4gICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGlmIChpbnN0YW5jZS5pc1VubW91bnRlZCkge1xuICAgICAgICAgIHBlbmRpbmdSZXF1ZXN0ID0gbnVsbDtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb25FcnJvcihlcnIpO1xuICAgICAgICBlcnJvci52YWx1ZSA9IGVycjtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgaWYgKGxvYWRlZC52YWx1ZSAmJiByZXNvbHZlZENvbXApIHtcbiAgICAgICAgICByZXR1cm4gY3JlYXRlSW5uZXJDb21wKHJlc29sdmVkQ29tcCwgaW5zdGFuY2UpO1xuICAgICAgICB9IGVsc2UgaWYgKGVycm9yLnZhbHVlICYmIGVycm9yQ29tcG9uZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZVZOb2RlKGVycm9yQ29tcG9uZW50LCB7XG4gICAgICAgICAgICBlcnJvcjogZXJyb3IudmFsdWVcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChsb2FkaW5nQ29tcG9uZW50ICYmICFkZWxheWVkLnZhbHVlKSB7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZUlubmVyQ29tcChcbiAgICAgICAgICAgIGxvYWRpbmdDb21wb25lbnQsXG4gICAgICAgICAgICBpbnN0YW5jZVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUlubmVyQ29tcChjb21wLCBwYXJlbnQpIHtcbiAgY29uc3QgeyByZWY6IHJlZjIsIHByb3BzLCBjaGlsZHJlbiwgY2UgfSA9IHBhcmVudC52bm9kZTtcbiAgY29uc3Qgdm5vZGUgPSBjcmVhdGVWTm9kZShjb21wLCBwcm9wcywgY2hpbGRyZW4pO1xuICB2bm9kZS5yZWYgPSByZWYyO1xuICB2bm9kZS5jZSA9IGNlO1xuICBkZWxldGUgcGFyZW50LnZub2RlLmNlO1xuICByZXR1cm4gdm5vZGU7XG59XG5cbmNvbnN0IGlzS2VlcEFsaXZlID0gKHZub2RlKSA9PiB2bm9kZS50eXBlLl9faXNLZWVwQWxpdmU7XG5jb25zdCBLZWVwQWxpdmVJbXBsID0ge1xuICBuYW1lOiBgS2VlcEFsaXZlYCxcbiAgLy8gTWFya2VyIGZvciBzcGVjaWFsIGhhbmRsaW5nIGluc2lkZSB0aGUgcmVuZGVyZXIuIFdlIGFyZSBub3QgdXNpbmcgYSA9PT1cbiAgLy8gY2hlY2sgZGlyZWN0bHkgb24gS2VlcEFsaXZlIGluIHRoZSByZW5kZXJlciwgYmVjYXVzZSBpbXBvcnRpbmcgaXQgZGlyZWN0bHlcbiAgLy8gd291bGQgcHJldmVudCBpdCBmcm9tIGJlaW5nIHRyZWUtc2hha2VuLlxuICBfX2lzS2VlcEFsaXZlOiB0cnVlLFxuICBwcm9wczoge1xuICAgIGluY2x1ZGU6IFtTdHJpbmcsIFJlZ0V4cCwgQXJyYXldLFxuICAgIGV4Y2x1ZGU6IFtTdHJpbmcsIFJlZ0V4cCwgQXJyYXldLFxuICAgIG1heDogW1N0cmluZywgTnVtYmVyXVxuICB9LFxuICBzZXR1cChwcm9wcywgeyBzbG90cyB9KSB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICBjb25zdCBzaGFyZWRDb250ZXh0ID0gaW5zdGFuY2UuY3R4O1xuICAgIGlmICghc2hhcmVkQ29udGV4dC5yZW5kZXJlcikge1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY29uc3QgY2hpbGRyZW4gPSBzbG90cy5kZWZhdWx0ICYmIHNsb3RzLmRlZmF1bHQoKTtcbiAgICAgICAgcmV0dXJuIGNoaWxkcmVuICYmIGNoaWxkcmVuLmxlbmd0aCA9PT0gMSA/IGNoaWxkcmVuWzBdIDogY2hpbGRyZW47XG4gICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBjYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgY29uc3Qga2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgbGV0IGN1cnJlbnQgPSBudWxsO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgaW5zdGFuY2UuX192X2NhY2hlID0gY2FjaGU7XG4gICAgfVxuICAgIGNvbnN0IHBhcmVudFN1c3BlbnNlID0gaW5zdGFuY2Uuc3VzcGVuc2U7XG4gICAgY29uc3Qge1xuICAgICAgcmVuZGVyZXI6IHtcbiAgICAgICAgcDogcGF0Y2gsXG4gICAgICAgIG06IG1vdmUsXG4gICAgICAgIHVtOiBfdW5tb3VudCxcbiAgICAgICAgbzogeyBjcmVhdGVFbGVtZW50IH1cbiAgICAgIH1cbiAgICB9ID0gc2hhcmVkQ29udGV4dDtcbiAgICBjb25zdCBzdG9yYWdlQ29udGFpbmVyID0gY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBzaGFyZWRDb250ZXh0LmFjdGl2YXRlID0gKHZub2RlLCBjb250YWluZXIsIGFuY2hvciwgbmFtZXNwYWNlLCBvcHRpbWl6ZWQpID0+IHtcbiAgICAgIGNvbnN0IGluc3RhbmNlMiA9IHZub2RlLmNvbXBvbmVudDtcbiAgICAgIG1vdmUodm5vZGUsIGNvbnRhaW5lciwgYW5jaG9yLCAwLCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICBwYXRjaChcbiAgICAgICAgaW5zdGFuY2UyLnZub2RlLFxuICAgICAgICB2bm9kZSxcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIGluc3RhbmNlMixcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgdm5vZGUuc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICk7XG4gICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpbnN0YW5jZTIuaXNEZWFjdGl2YXRlZCA9IGZhbHNlO1xuICAgICAgICBpZiAoaW5zdGFuY2UyLmEpIHtcbiAgICAgICAgICBpbnZva2VBcnJheUZucyhpbnN0YW5jZTIuYSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgdm5vZGVIb29rID0gdm5vZGUucHJvcHMgJiYgdm5vZGUucHJvcHMub25Wbm9kZU1vdW50ZWQ7XG4gICAgICAgIGlmICh2bm9kZUhvb2spIHtcbiAgICAgICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBpbnN0YW5jZTIucGFyZW50LCB2bm9kZSk7XG4gICAgICAgIH1cbiAgICAgIH0sIHBhcmVudFN1c3BlbnNlKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgICBkZXZ0b29sc0NvbXBvbmVudEFkZGVkKGluc3RhbmNlMik7XG4gICAgICB9XG4gICAgfTtcbiAgICBzaGFyZWRDb250ZXh0LmRlYWN0aXZhdGUgPSAodm5vZGUpID0+IHtcbiAgICAgIGNvbnN0IGluc3RhbmNlMiA9IHZub2RlLmNvbXBvbmVudDtcbiAgICAgIGludmFsaWRhdGVNb3VudChpbnN0YW5jZTIubSk7XG4gICAgICBpbnZhbGlkYXRlTW91bnQoaW5zdGFuY2UyLmEpO1xuICAgICAgbW92ZSh2bm9kZSwgc3RvcmFnZUNvbnRhaW5lciwgbnVsbCwgMSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGluc3RhbmNlMi5kYSkge1xuICAgICAgICAgIGludm9rZUFycmF5Rm5zKGluc3RhbmNlMi5kYSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgdm5vZGVIb29rID0gdm5vZGUucHJvcHMgJiYgdm5vZGUucHJvcHMub25Wbm9kZVVubW91bnRlZDtcbiAgICAgICAgaWYgKHZub2RlSG9vaykge1xuICAgICAgICAgIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIGluc3RhbmNlMi5wYXJlbnQsIHZub2RlKTtcbiAgICAgICAgfVxuICAgICAgICBpbnN0YW5jZTIuaXNEZWFjdGl2YXRlZCA9IHRydWU7XG4gICAgICB9LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgICAgZGV2dG9vbHNDb21wb25lbnRBZGRlZChpbnN0YW5jZTIpO1xuICAgICAgfVxuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdHJ1ZSkge1xuICAgICAgICBpbnN0YW5jZTIuX19rZWVwQWxpdmVTdG9yYWdlQ29udGFpbmVyID0gc3RvcmFnZUNvbnRhaW5lcjtcbiAgICAgIH1cbiAgICB9O1xuICAgIGZ1bmN0aW9uIHVubW91bnQodm5vZGUpIHtcbiAgICAgIHJlc2V0U2hhcGVGbGFnKHZub2RlKTtcbiAgICAgIF91bm1vdW50KHZub2RlLCBpbnN0YW5jZSwgcGFyZW50U3VzcGVuc2UsIHRydWUpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwcnVuZUNhY2hlKGZpbHRlcikge1xuICAgICAgY2FjaGUuZm9yRWFjaCgodm5vZGUsIGtleSkgPT4ge1xuICAgICAgICBjb25zdCBuYW1lID0gZ2V0Q29tcG9uZW50TmFtZShcbiAgICAgICAgICBpc0FzeW5jV3JhcHBlcih2bm9kZSkgPyB2bm9kZS50eXBlLl9fYXN5bmNSZXNvbHZlZCB8fCB7fSA6IHZub2RlLnR5cGVcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKG5hbWUgJiYgIWZpbHRlcihuYW1lKSkge1xuICAgICAgICAgIHBydW5lQ2FjaGVFbnRyeShrZXkpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcHJ1bmVDYWNoZUVudHJ5KGtleSkge1xuICAgICAgY29uc3QgY2FjaGVkID0gY2FjaGUuZ2V0KGtleSk7XG4gICAgICBpZiAoY2FjaGVkICYmICghY3VycmVudCB8fCAhaXNTYW1lVk5vZGVUeXBlKGNhY2hlZCwgY3VycmVudCkpKSB7XG4gICAgICAgIHVubW91bnQoY2FjaGVkKTtcbiAgICAgIH0gZWxzZSBpZiAoY3VycmVudCkge1xuICAgICAgICByZXNldFNoYXBlRmxhZyhjdXJyZW50KTtcbiAgICAgIH1cbiAgICAgIGNhY2hlLmRlbGV0ZShrZXkpO1xuICAgICAga2V5cy5kZWxldGUoa2V5KTtcbiAgICB9XG4gICAgd2F0Y2goXG4gICAgICAoKSA9PiBbcHJvcHMuaW5jbHVkZSwgcHJvcHMuZXhjbHVkZV0sXG4gICAgICAoW2luY2x1ZGUsIGV4Y2x1ZGVdKSA9PiB7XG4gICAgICAgIGluY2x1ZGUgJiYgcHJ1bmVDYWNoZSgobmFtZSkgPT4gbWF0Y2hlcyhpbmNsdWRlLCBuYW1lKSk7XG4gICAgICAgIGV4Y2x1ZGUgJiYgcHJ1bmVDYWNoZSgobmFtZSkgPT4gIW1hdGNoZXMoZXhjbHVkZSwgbmFtZSkpO1xuICAgICAgfSxcbiAgICAgIC8vIHBydW5lIHBvc3QtcmVuZGVyIGFmdGVyIGBjdXJyZW50YCBoYXMgYmVlbiB1cGRhdGVkXG4gICAgICB7IGZsdXNoOiBcInBvc3RcIiwgZGVlcDogdHJ1ZSB9XG4gICAgKTtcbiAgICBsZXQgcGVuZGluZ0NhY2hlS2V5ID0gbnVsbDtcbiAgICBjb25zdCBjYWNoZVN1YnRyZWUgPSAoKSA9PiB7XG4gICAgICBpZiAocGVuZGluZ0NhY2hlS2V5ICE9IG51bGwpIHtcbiAgICAgICAgaWYgKGlzU3VzcGVuc2UoaW5zdGFuY2Uuc3ViVHJlZS50eXBlKSkge1xuICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCgoKSA9PiB7XG4gICAgICAgICAgICBjYWNoZS5zZXQocGVuZGluZ0NhY2hlS2V5LCBnZXRJbm5lckNoaWxkKGluc3RhbmNlLnN1YlRyZWUpKTtcbiAgICAgICAgICB9LCBpbnN0YW5jZS5zdWJUcmVlLnN1c3BlbnNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjYWNoZS5zZXQocGVuZGluZ0NhY2hlS2V5LCBnZXRJbm5lckNoaWxkKGluc3RhbmNlLnN1YlRyZWUpKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgb25Nb3VudGVkKGNhY2hlU3VidHJlZSk7XG4gICAgb25VcGRhdGVkKGNhY2hlU3VidHJlZSk7XG4gICAgb25CZWZvcmVVbm1vdW50KCgpID0+IHtcbiAgICAgIGNhY2hlLmZvckVhY2goKGNhY2hlZCkgPT4ge1xuICAgICAgICBjb25zdCB7IHN1YlRyZWUsIHN1c3BlbnNlIH0gPSBpbnN0YW5jZTtcbiAgICAgICAgY29uc3Qgdm5vZGUgPSBnZXRJbm5lckNoaWxkKHN1YlRyZWUpO1xuICAgICAgICBpZiAoY2FjaGVkLnR5cGUgPT09IHZub2RlLnR5cGUgJiYgY2FjaGVkLmtleSA9PT0gdm5vZGUua2V5KSB7XG4gICAgICAgICAgcmVzZXRTaGFwZUZsYWcodm5vZGUpO1xuICAgICAgICAgIGNvbnN0IGRhID0gdm5vZGUuY29tcG9uZW50LmRhO1xuICAgICAgICAgIGRhICYmIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChkYSwgc3VzcGVuc2UpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB1bm1vdW50KGNhY2hlZCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgcGVuZGluZ0NhY2hlS2V5ID0gbnVsbDtcbiAgICAgIGlmICghc2xvdHMuZGVmYXVsdCkge1xuICAgICAgICByZXR1cm4gY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCBjaGlsZHJlbiA9IHNsb3RzLmRlZmF1bHQoKTtcbiAgICAgIGNvbnN0IHJhd1ZOb2RlID0gY2hpbGRyZW5bMF07XG4gICAgICBpZiAoY2hpbGRyZW4ubGVuZ3RoID4gMSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHdhcm4kMShgS2VlcEFsaXZlIHNob3VsZCBjb250YWluIGV4YWN0bHkgb25lIGNvbXBvbmVudCBjaGlsZC5gKTtcbiAgICAgICAgfVxuICAgICAgICBjdXJyZW50ID0gbnVsbDtcbiAgICAgICAgcmV0dXJuIGNoaWxkcmVuO1xuICAgICAgfSBlbHNlIGlmICghaXNWTm9kZShyYXdWTm9kZSkgfHwgIShyYXdWTm9kZS5zaGFwZUZsYWcgJiA0KSAmJiAhKHJhd1ZOb2RlLnNoYXBlRmxhZyAmIDEyOCkpIHtcbiAgICAgICAgY3VycmVudCA9IG51bGw7XG4gICAgICAgIHJldHVybiByYXdWTm9kZTtcbiAgICAgIH1cbiAgICAgIGxldCB2bm9kZSA9IGdldElubmVyQ2hpbGQocmF3Vk5vZGUpO1xuICAgICAgaWYgKHZub2RlLnR5cGUgPT09IENvbW1lbnQpIHtcbiAgICAgICAgY3VycmVudCA9IG51bGw7XG4gICAgICAgIHJldHVybiB2bm9kZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNvbXAgPSB2bm9kZS50eXBlO1xuICAgICAgY29uc3QgbmFtZSA9IGdldENvbXBvbmVudE5hbWUoXG4gICAgICAgIGlzQXN5bmNXcmFwcGVyKHZub2RlKSA/IHZub2RlLnR5cGUuX19hc3luY1Jlc29sdmVkIHx8IHt9IDogY29tcFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHsgaW5jbHVkZSwgZXhjbHVkZSwgbWF4IH0gPSBwcm9wcztcbiAgICAgIGlmIChpbmNsdWRlICYmICghbmFtZSB8fCAhbWF0Y2hlcyhpbmNsdWRlLCBuYW1lKSkgfHwgZXhjbHVkZSAmJiBuYW1lICYmIG1hdGNoZXMoZXhjbHVkZSwgbmFtZSkpIHtcbiAgICAgICAgdm5vZGUuc2hhcGVGbGFnICY9IC0yNTc7XG4gICAgICAgIGN1cnJlbnQgPSB2bm9kZTtcbiAgICAgICAgcmV0dXJuIHJhd1ZOb2RlO1xuICAgICAgfVxuICAgICAgY29uc3Qga2V5ID0gdm5vZGUua2V5ID09IG51bGwgPyBjb21wIDogdm5vZGUua2V5O1xuICAgICAgY29uc3QgY2FjaGVkVk5vZGUgPSBjYWNoZS5nZXQoa2V5KTtcbiAgICAgIGlmICh2bm9kZS5lbCkge1xuICAgICAgICB2bm9kZSA9IGNsb25lVk5vZGUodm5vZGUpO1xuICAgICAgICBpZiAocmF3Vk5vZGUuc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgICAgICAgcmF3Vk5vZGUuc3NDb250ZW50ID0gdm5vZGU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHBlbmRpbmdDYWNoZUtleSA9IGtleTtcbiAgICAgIGlmIChjYWNoZWRWTm9kZSkge1xuICAgICAgICB2bm9kZS5lbCA9IGNhY2hlZFZOb2RlLmVsO1xuICAgICAgICB2bm9kZS5jb21wb25lbnQgPSBjYWNoZWRWTm9kZS5jb21wb25lbnQ7XG4gICAgICAgIGlmICh2bm9kZS50cmFuc2l0aW9uKSB7XG4gICAgICAgICAgc2V0VHJhbnNpdGlvbkhvb2tzKHZub2RlLCB2bm9kZS50cmFuc2l0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICB2bm9kZS5zaGFwZUZsYWcgfD0gNTEyO1xuICAgICAgICBrZXlzLmRlbGV0ZShrZXkpO1xuICAgICAgICBrZXlzLmFkZChrZXkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAga2V5cy5hZGQoa2V5KTtcbiAgICAgICAgaWYgKG1heCAmJiBrZXlzLnNpemUgPiBwYXJzZUludChtYXgsIDEwKSkge1xuICAgICAgICAgIHBydW5lQ2FjaGVFbnRyeShrZXlzLnZhbHVlcygpLm5leHQoKS52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHZub2RlLnNoYXBlRmxhZyB8PSAyNTY7XG4gICAgICBjdXJyZW50ID0gdm5vZGU7XG4gICAgICByZXR1cm4gaXNTdXNwZW5zZShyYXdWTm9kZS50eXBlKSA/IHJhd1ZOb2RlIDogdm5vZGU7XG4gICAgfTtcbiAgfVxufTtcbmNvbnN0IEtlZXBBbGl2ZSA9IEtlZXBBbGl2ZUltcGw7XG5mdW5jdGlvbiBtYXRjaGVzKHBhdHRlcm4sIG5hbWUpIHtcbiAgaWYgKGlzQXJyYXkocGF0dGVybikpIHtcbiAgICByZXR1cm4gcGF0dGVybi5zb21lKChwKSA9PiBtYXRjaGVzKHAsIG5hbWUpKTtcbiAgfSBlbHNlIGlmIChpc1N0cmluZyhwYXR0ZXJuKSkge1xuICAgIHJldHVybiBwYXR0ZXJuLnNwbGl0KFwiLFwiKS5pbmNsdWRlcyhuYW1lKTtcbiAgfSBlbHNlIGlmIChpc1JlZ0V4cChwYXR0ZXJuKSkge1xuICAgIHBhdHRlcm4ubGFzdEluZGV4ID0gMDtcbiAgICByZXR1cm4gcGF0dGVybi50ZXN0KG5hbWUpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIG9uQWN0aXZhdGVkKGhvb2ssIHRhcmdldCkge1xuICByZWdpc3RlcktlZXBBbGl2ZUhvb2soaG9vaywgXCJhXCIsIHRhcmdldCk7XG59XG5mdW5jdGlvbiBvbkRlYWN0aXZhdGVkKGhvb2ssIHRhcmdldCkge1xuICByZWdpc3RlcktlZXBBbGl2ZUhvb2soaG9vaywgXCJkYVwiLCB0YXJnZXQpO1xufVxuZnVuY3Rpb24gcmVnaXN0ZXJLZWVwQWxpdmVIb29rKGhvb2ssIHR5cGUsIHRhcmdldCA9IGN1cnJlbnRJbnN0YW5jZSkge1xuICBjb25zdCB3cmFwcGVkSG9vayA9IGhvb2suX193ZGMgfHwgKGhvb2suX193ZGMgPSAoKSA9PiB7XG4gICAgbGV0IGN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgd2hpbGUgKGN1cnJlbnQpIHtcbiAgICAgIGlmIChjdXJyZW50LmlzRGVhY3RpdmF0ZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY3VycmVudCA9IGN1cnJlbnQucGFyZW50O1xuICAgIH1cbiAgICByZXR1cm4gaG9vaygpO1xuICB9KTtcbiAgaW5qZWN0SG9vayh0eXBlLCB3cmFwcGVkSG9vaywgdGFyZ2V0KTtcbiAgaWYgKHRhcmdldCkge1xuICAgIGxldCBjdXJyZW50ID0gdGFyZ2V0LnBhcmVudDtcbiAgICB3aGlsZSAoY3VycmVudCAmJiBjdXJyZW50LnBhcmVudCkge1xuICAgICAgaWYgKGlzS2VlcEFsaXZlKGN1cnJlbnQucGFyZW50LnZub2RlKSkge1xuICAgICAgICBpbmplY3RUb0tlZXBBbGl2ZVJvb3Qod3JhcHBlZEhvb2ssIHR5cGUsIHRhcmdldCwgY3VycmVudCk7XG4gICAgICB9XG4gICAgICBjdXJyZW50ID0gY3VycmVudC5wYXJlbnQ7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBpbmplY3RUb0tlZXBBbGl2ZVJvb3QoaG9vaywgdHlwZSwgdGFyZ2V0LCBrZWVwQWxpdmVSb290KSB7XG4gIGNvbnN0IGluamVjdGVkID0gaW5qZWN0SG9vayhcbiAgICB0eXBlLFxuICAgIGhvb2ssXG4gICAga2VlcEFsaXZlUm9vdCxcbiAgICB0cnVlXG4gICAgLyogcHJlcGVuZCAqL1xuICApO1xuICBvblVubW91bnRlZCgoKSA9PiB7XG4gICAgcmVtb3ZlKGtlZXBBbGl2ZVJvb3RbdHlwZV0sIGluamVjdGVkKTtcbiAgfSwgdGFyZ2V0KTtcbn1cbmZ1bmN0aW9uIHJlc2V0U2hhcGVGbGFnKHZub2RlKSB7XG4gIHZub2RlLnNoYXBlRmxhZyAmPSAtMjU3O1xuICB2bm9kZS5zaGFwZUZsYWcgJj0gLTUxMztcbn1cbmZ1bmN0aW9uIGdldElubmVyQ2hpbGQodm5vZGUpIHtcbiAgcmV0dXJuIHZub2RlLnNoYXBlRmxhZyAmIDEyOCA/IHZub2RlLnNzQ29udGVudCA6IHZub2RlO1xufVxuXG5mdW5jdGlvbiBpbmplY3RIb29rKHR5cGUsIGhvb2ssIHRhcmdldCA9IGN1cnJlbnRJbnN0YW5jZSwgcHJlcGVuZCA9IGZhbHNlKSB7XG4gIGlmICh0YXJnZXQpIHtcbiAgICBjb25zdCBob29rcyA9IHRhcmdldFt0eXBlXSB8fCAodGFyZ2V0W3R5cGVdID0gW10pO1xuICAgIGNvbnN0IHdyYXBwZWRIb29rID0gaG9vay5fX3dlaCB8fCAoaG9vay5fX3dlaCA9ICguLi5hcmdzKSA9PiB7XG4gICAgICBwYXVzZVRyYWNraW5nKCk7XG4gICAgICBjb25zdCByZXNldCA9IHNldEN1cnJlbnRJbnN0YW5jZSh0YXJnZXQpO1xuICAgICAgY29uc3QgcmVzID0gY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoaG9vaywgdGFyZ2V0LCB0eXBlLCBhcmdzKTtcbiAgICAgIHJlc2V0KCk7XG4gICAgICByZXNldFRyYWNraW5nKCk7XG4gICAgICByZXR1cm4gcmVzO1xuICAgIH0pO1xuICAgIGlmIChwcmVwZW5kKSB7XG4gICAgICBob29rcy51bnNoaWZ0KHdyYXBwZWRIb29rKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaG9va3MucHVzaCh3cmFwcGVkSG9vayk7XG4gICAgfVxuICAgIHJldHVybiB3cmFwcGVkSG9vaztcbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgY29uc3QgYXBpTmFtZSA9IHRvSGFuZGxlcktleShFcnJvclR5cGVTdHJpbmdzJDFbdHlwZV0ucmVwbGFjZSgvIGhvb2skLywgXCJcIikpO1xuICAgIHdhcm4kMShcbiAgICAgIGAke2FwaU5hbWV9IGlzIGNhbGxlZCB3aGVuIHRoZXJlIGlzIG5vIGFjdGl2ZSBjb21wb25lbnQgaW5zdGFuY2UgdG8gYmUgYXNzb2NpYXRlZCB3aXRoLiBMaWZlY3ljbGUgaW5qZWN0aW9uIEFQSXMgY2FuIG9ubHkgYmUgdXNlZCBkdXJpbmcgZXhlY3V0aW9uIG9mIHNldHVwKCkuYCArIChgIElmIHlvdSBhcmUgdXNpbmcgYXN5bmMgc2V0dXAoKSwgbWFrZSBzdXJlIHRvIHJlZ2lzdGVyIGxpZmVjeWNsZSBob29rcyBiZWZvcmUgdGhlIGZpcnN0IGF3YWl0IHN0YXRlbWVudC5gIClcbiAgICApO1xuICB9XG59XG5jb25zdCBjcmVhdGVIb29rID0gKGxpZmVjeWNsZSkgPT4gKGhvb2ssIHRhcmdldCA9IGN1cnJlbnRJbnN0YW5jZSkgPT4ge1xuICBpZiAoIWlzSW5TU1JDb21wb25lbnRTZXR1cCB8fCBsaWZlY3ljbGUgPT09IFwic3BcIikge1xuICAgIGluamVjdEhvb2sobGlmZWN5Y2xlLCAoLi4uYXJncykgPT4gaG9vayguLi5hcmdzKSwgdGFyZ2V0KTtcbiAgfVxufTtcbmNvbnN0IG9uQmVmb3JlTW91bnQgPSBjcmVhdGVIb29rKFwiYm1cIik7XG5jb25zdCBvbk1vdW50ZWQgPSBjcmVhdGVIb29rKFwibVwiKTtcbmNvbnN0IG9uQmVmb3JlVXBkYXRlID0gY3JlYXRlSG9vayhcbiAgXCJidVwiXG4pO1xuY29uc3Qgb25VcGRhdGVkID0gY3JlYXRlSG9vayhcInVcIik7XG5jb25zdCBvbkJlZm9yZVVubW91bnQgPSBjcmVhdGVIb29rKFxuICBcImJ1bVwiXG4pO1xuY29uc3Qgb25Vbm1vdW50ZWQgPSBjcmVhdGVIb29rKFwidW1cIik7XG5jb25zdCBvblNlcnZlclByZWZldGNoID0gY3JlYXRlSG9vayhcbiAgXCJzcFwiXG4pO1xuY29uc3Qgb25SZW5kZXJUcmlnZ2VyZWQgPSBjcmVhdGVIb29rKFwicnRnXCIpO1xuY29uc3Qgb25SZW5kZXJUcmFja2VkID0gY3JlYXRlSG9vayhcInJ0Y1wiKTtcbmZ1bmN0aW9uIG9uRXJyb3JDYXB0dXJlZChob29rLCB0YXJnZXQgPSBjdXJyZW50SW5zdGFuY2UpIHtcbiAgaW5qZWN0SG9vayhcImVjXCIsIGhvb2ssIHRhcmdldCk7XG59XG5cbmNvbnN0IENPTVBPTkVOVFMgPSBcImNvbXBvbmVudHNcIjtcbmNvbnN0IERJUkVDVElWRVMgPSBcImRpcmVjdGl2ZXNcIjtcbmZ1bmN0aW9uIHJlc29sdmVDb21wb25lbnQobmFtZSwgbWF5YmVTZWxmUmVmZXJlbmNlKSB7XG4gIHJldHVybiByZXNvbHZlQXNzZXQoQ09NUE9ORU5UUywgbmFtZSwgdHJ1ZSwgbWF5YmVTZWxmUmVmZXJlbmNlKSB8fCBuYW1lO1xufVxuY29uc3QgTlVMTF9EWU5BTUlDX0NPTVBPTkVOVCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwidi1uZGNcIik7XG5mdW5jdGlvbiByZXNvbHZlRHluYW1pY0NvbXBvbmVudChjb21wb25lbnQpIHtcbiAgaWYgKGlzU3RyaW5nKGNvbXBvbmVudCkpIHtcbiAgICByZXR1cm4gcmVzb2x2ZUFzc2V0KENPTVBPTkVOVFMsIGNvbXBvbmVudCwgZmFsc2UpIHx8IGNvbXBvbmVudDtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY29tcG9uZW50IHx8IE5VTExfRFlOQU1JQ19DT01QT05FTlQ7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlc29sdmVEaXJlY3RpdmUobmFtZSkge1xuICByZXR1cm4gcmVzb2x2ZUFzc2V0KERJUkVDVElWRVMsIG5hbWUpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUFzc2V0KHR5cGUsIG5hbWUsIHdhcm5NaXNzaW5nID0gdHJ1ZSwgbWF5YmVTZWxmUmVmZXJlbmNlID0gZmFsc2UpIHtcbiAgY29uc3QgaW5zdGFuY2UgPSBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UgfHwgY3VycmVudEluc3RhbmNlO1xuICBpZiAoaW5zdGFuY2UpIHtcbiAgICBjb25zdCBDb21wb25lbnQgPSBpbnN0YW5jZS50eXBlO1xuICAgIGlmICh0eXBlID09PSBDT01QT05FTlRTKSB7XG4gICAgICBjb25zdCBzZWxmTmFtZSA9IGdldENvbXBvbmVudE5hbWUoXG4gICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgZmFsc2VcbiAgICAgICk7XG4gICAgICBpZiAoc2VsZk5hbWUgJiYgKHNlbGZOYW1lID09PSBuYW1lIHx8IHNlbGZOYW1lID09PSBjYW1lbGl6ZShuYW1lKSB8fCBzZWxmTmFtZSA9PT0gY2FwaXRhbGl6ZShjYW1lbGl6ZShuYW1lKSkpKSB7XG4gICAgICAgIHJldHVybiBDb21wb25lbnQ7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHJlcyA9IChcbiAgICAgIC8vIGxvY2FsIHJlZ2lzdHJhdGlvblxuICAgICAgLy8gY2hlY2sgaW5zdGFuY2VbdHlwZV0gZmlyc3Qgd2hpY2ggaXMgcmVzb2x2ZWQgZm9yIG9wdGlvbnMgQVBJXG4gICAgICByZXNvbHZlKGluc3RhbmNlW3R5cGVdIHx8IENvbXBvbmVudFt0eXBlXSwgbmFtZSkgfHwgLy8gZ2xvYmFsIHJlZ2lzdHJhdGlvblxuICAgICAgcmVzb2x2ZShpbnN0YW5jZS5hcHBDb250ZXh0W3R5cGVdLCBuYW1lKVxuICAgICk7XG4gICAgaWYgKCFyZXMgJiYgbWF5YmVTZWxmUmVmZXJlbmNlKSB7XG4gICAgICByZXR1cm4gQ29tcG9uZW50O1xuICAgIH1cbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuTWlzc2luZyAmJiAhcmVzKSB7XG4gICAgICBjb25zdCBleHRyYSA9IHR5cGUgPT09IENPTVBPTkVOVFMgPyBgXG5JZiB0aGlzIGlzIGEgbmF0aXZlIGN1c3RvbSBlbGVtZW50LCBtYWtlIHN1cmUgdG8gZXhjbHVkZSBpdCBmcm9tIGNvbXBvbmVudCByZXNvbHV0aW9uIHZpYSBjb21waWxlck9wdGlvbnMuaXNDdXN0b21FbGVtZW50LmAgOiBgYDtcbiAgICAgIHdhcm4kMShgRmFpbGVkIHRvIHJlc29sdmUgJHt0eXBlLnNsaWNlKDAsIC0xKX06ICR7bmFtZX0ke2V4dHJhfWApO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuJDEoXG4gICAgICBgcmVzb2x2ZSR7Y2FwaXRhbGl6ZSh0eXBlLnNsaWNlKDAsIC0xKSl9IGNhbiBvbmx5IGJlIHVzZWQgaW4gcmVuZGVyKCkgb3Igc2V0dXAoKS5gXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gcmVzb2x2ZShyZWdpc3RyeSwgbmFtZSkge1xuICByZXR1cm4gcmVnaXN0cnkgJiYgKHJlZ2lzdHJ5W25hbWVdIHx8IHJlZ2lzdHJ5W2NhbWVsaXplKG5hbWUpXSB8fCByZWdpc3RyeVtjYXBpdGFsaXplKGNhbWVsaXplKG5hbWUpKV0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJMaXN0KHNvdXJjZSwgcmVuZGVySXRlbSwgY2FjaGUsIGluZGV4KSB7XG4gIGxldCByZXQ7XG4gIGNvbnN0IGNhY2hlZCA9IGNhY2hlICYmIGNhY2hlW2luZGV4XTtcbiAgY29uc3Qgc291cmNlSXNBcnJheSA9IGlzQXJyYXkoc291cmNlKTtcbiAgaWYgKHNvdXJjZUlzQXJyYXkgfHwgaXNTdHJpbmcoc291cmNlKSkge1xuICAgIGNvbnN0IHNvdXJjZUlzUmVhY3RpdmVBcnJheSA9IHNvdXJjZUlzQXJyYXkgJiYgaXNSZWFjdGl2ZShzb3VyY2UpO1xuICAgIGxldCBuZWVkc1dyYXAgPSBmYWxzZTtcbiAgICBsZXQgaXNSZWFkb25seVNvdXJjZSA9IGZhbHNlO1xuICAgIGlmIChzb3VyY2VJc1JlYWN0aXZlQXJyYXkpIHtcbiAgICAgIG5lZWRzV3JhcCA9ICFpc1NoYWxsb3coc291cmNlKTtcbiAgICAgIGlzUmVhZG9ubHlTb3VyY2UgPSBpc1JlYWRvbmx5KHNvdXJjZSk7XG4gICAgICBzb3VyY2UgPSBzaGFsbG93UmVhZEFycmF5KHNvdXJjZSk7XG4gICAgfVxuICAgIHJldCA9IG5ldyBBcnJheShzb3VyY2UubGVuZ3RoKTtcbiAgICBmb3IgKGxldCBpID0gMCwgbCA9IHNvdXJjZS5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgIHJldFtpXSA9IHJlbmRlckl0ZW0oXG4gICAgICAgIG5lZWRzV3JhcCA/IGlzUmVhZG9ubHlTb3VyY2UgPyB0b1JlYWRvbmx5KHRvUmVhY3RpdmUoc291cmNlW2ldKSkgOiB0b1JlYWN0aXZlKHNvdXJjZVtpXSkgOiBzb3VyY2VbaV0sXG4gICAgICAgIGksXG4gICAgICAgIHZvaWQgMCxcbiAgICAgICAgY2FjaGVkICYmIGNhY2hlZFtpXVxuICAgICAgKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAodHlwZW9mIHNvdXJjZSA9PT0gXCJudW1iZXJcIikge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICghTnVtYmVyLmlzSW50ZWdlcihzb3VyY2UpIHx8IHNvdXJjZSA8IDApKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBUaGUgdi1mb3IgcmFuZ2UgZXhwZWN0cyBhIHBvc2l0aXZlIGludGVnZXIgdmFsdWUgYnV0IGdvdCAke3NvdXJjZX0uYFxuICAgICAgKTtcbiAgICAgIHJldCA9IFtdO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXQgPSBuZXcgQXJyYXkoc291cmNlKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlOyBpKyspIHtcbiAgICAgICAgcmV0W2ldID0gcmVuZGVySXRlbShpICsgMSwgaSwgdm9pZCAwLCBjYWNoZWQgJiYgY2FjaGVkW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNPYmplY3Qoc291cmNlKSkge1xuICAgIGlmIChzb3VyY2VbU3ltYm9sLml0ZXJhdG9yXSkge1xuICAgICAgcmV0ID0gQXJyYXkuZnJvbShcbiAgICAgICAgc291cmNlLFxuICAgICAgICAoaXRlbSwgaSkgPT4gcmVuZGVySXRlbShpdGVtLCBpLCB2b2lkIDAsIGNhY2hlZCAmJiBjYWNoZWRbaV0pXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoc291cmNlKTtcbiAgICAgIHJldCA9IG5ldyBBcnJheShrZXlzLmxlbmd0aCk7XG4gICAgICBmb3IgKGxldCBpID0gMCwgbCA9IGtleXMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IGtleXNbaV07XG4gICAgICAgIHJldFtpXSA9IHJlbmRlckl0ZW0oc291cmNlW2tleV0sIGtleSwgaSwgY2FjaGVkICYmIGNhY2hlZFtpXSk7XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJldCA9IFtdO1xuICB9XG4gIGlmIChjYWNoZSkge1xuICAgIGNhY2hlW2luZGV4XSA9IHJldDtcbiAgfVxuICByZXR1cm4gcmV0O1xufVxuXG5mdW5jdGlvbiBjcmVhdGVTbG90cyhzbG90cywgZHluYW1pY1Nsb3RzKSB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZHluYW1pY1Nsb3RzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3Qgc2xvdCA9IGR5bmFtaWNTbG90c1tpXTtcbiAgICBpZiAoaXNBcnJheShzbG90KSkge1xuICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBzbG90Lmxlbmd0aDsgaisrKSB7XG4gICAgICAgIHNsb3RzW3Nsb3Rbal0ubmFtZV0gPSBzbG90W2pdLmZuO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoc2xvdCkge1xuICAgICAgc2xvdHNbc2xvdC5uYW1lXSA9IHNsb3Qua2V5ID8gKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gc2xvdC5mbiguLi5hcmdzKTtcbiAgICAgICAgaWYgKHJlcykgcmVzLmtleSA9IHNsb3Qua2V5O1xuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSA6IHNsb3QuZm47XG4gICAgfVxuICB9XG4gIHJldHVybiBzbG90cztcbn1cblxuZnVuY3Rpb24gcmVuZGVyU2xvdChzbG90cywgbmFtZSwgcHJvcHMsIGZhbGxiYWNrLCBub1Nsb3R0ZWQsIGJyYW5jaEtleSkge1xuICBpZiAocHJvcHMgPT0gbnVsbCkgcHJvcHMgPSB7fTtcbiAgaWYgKGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZS5jZSB8fCBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UucGFyZW50ICYmIGlzQXN5bmNXcmFwcGVyKGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZS5wYXJlbnQpICYmIGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZS5wYXJlbnQuY2UpIHtcbiAgICBjb25zdCBzbG90UHJvcHMgPSBicmFuY2hLZXkgIT0gbnVsbCAmJiBwcm9wcy5rZXkgPT0gbnVsbCA/IGV4dGVuZCh7fSwgcHJvcHMsIHsga2V5OiBicmFuY2hLZXkgfSkgOiBwcm9wcztcbiAgICBjb25zdCBoYXNQcm9wcyA9IE9iamVjdC5rZXlzKHNsb3RQcm9wcykubGVuZ3RoID4gMDtcbiAgICBpZiAobmFtZSAhPT0gXCJkZWZhdWx0XCIpIHNsb3RQcm9wcy5uYW1lID0gbmFtZTtcbiAgICByZXR1cm4gb3BlbkJsb2NrKCksIGNyZWF0ZUJsb2NrKFxuICAgICAgRnJhZ21lbnQsXG4gICAgICBudWxsLFxuICAgICAgW2NyZWF0ZVZOb2RlKFwic2xvdFwiLCBzbG90UHJvcHMsIGZhbGxiYWNrICYmIGZhbGxiYWNrKCkpXSxcbiAgICAgIGhhc1Byb3BzID8gLTIgOiA2NFxuICAgICk7XG4gIH1cbiAgbGV0IHNsb3QgPSBzbG90c1tuYW1lXTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgc2xvdCAmJiBzbG90Lmxlbmd0aCA+IDEpIHtcbiAgICB3YXJuJDEoXG4gICAgICBgU1NSLW9wdGltaXplZCBzbG90IGZ1bmN0aW9uIGRldGVjdGVkIGluIGEgbm9uLVNTUi1vcHRpbWl6ZWQgcmVuZGVyIGZ1bmN0aW9uLiBZb3UgbmVlZCB0byBtYXJrIHRoaXMgY29tcG9uZW50IHdpdGggJGR5bmFtaWMtc2xvdHMgaW4gdGhlIHBhcmVudCB0ZW1wbGF0ZS5gXG4gICAgKTtcbiAgICBzbG90ID0gKCkgPT4gW107XG4gIH1cbiAgaWYgKHNsb3QgJiYgc2xvdC5fYykge1xuICAgIHNsb3QuX2QgPSBmYWxzZTtcbiAgfVxuICBjb25zdCBwcmV2U3RhY2tTaXplID0gYmxvY2tTdGFjay5sZW5ndGg7XG4gIG9wZW5CbG9jaygpO1xuICBsZXQgcmVuZGVyZWQ7XG4gIHRyeSB7XG4gICAgY29uc3QgdmFsaWRTbG90Q29udGVudCA9IHNsb3QgJiYgZW5zdXJlVmFsaWRWTm9kZShzbG90KHByb3BzKSk7XG4gICAgY29uc3Qgc2xvdEtleSA9IHByb3BzLmtleSB8fCBicmFuY2hLZXkgfHwgLy8gc2xvdCBjb250ZW50IGFycmF5IG9mIGEgZHluYW1pYyBjb25kaXRpb25hbCBzbG90IG1heSBoYXZlIGEgYnJhbmNoXG4gICAgLy8ga2V5IGF0dGFjaGVkIGluIHRoZSBgY3JlYXRlU2xvdHNgIGhlbHBlciwgcmVzcGVjdCB0aGF0XG4gICAgdmFsaWRTbG90Q29udGVudCAmJiB2YWxpZFNsb3RDb250ZW50LmtleTtcbiAgICByZW5kZXJlZCA9IGNyZWF0ZUJsb2NrKFxuICAgICAgRnJhZ21lbnQsXG4gICAgICB7XG4gICAgICAgIGtleTogKHNsb3RLZXkgJiYgIWlzU3ltYm9sKHNsb3RLZXkpID8gc2xvdEtleSA6IGBfJHtuYW1lfWApICsgLy8gIzcyNTYgZm9yY2UgZGlmZmVyZW50aWF0ZSBmYWxsYmFjayBjb250ZW50IGZyb20gYWN0dWFsIGNvbnRlbnRcbiAgICAgICAgKCF2YWxpZFNsb3RDb250ZW50ICYmIGZhbGxiYWNrID8gXCJfZmJcIiA6IFwiXCIpXG4gICAgICB9LFxuICAgICAgdmFsaWRTbG90Q29udGVudCB8fCAoZmFsbGJhY2sgPyBmYWxsYmFjaygpIDogW10pLFxuICAgICAgdmFsaWRTbG90Q29udGVudCAmJiBzbG90cy5fID09PSAxID8gNjQgOiAtMlxuICAgICk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGZvciAobGV0IGkgPSBibG9ja1N0YWNrLmxlbmd0aDsgaSA+IHByZXZTdGFja1NpemU7IGktLSkgY2xvc2VCbG9jaygpO1xuICAgIHRocm93IGVycjtcbiAgfSBmaW5hbGx5IHtcbiAgICBpZiAoc2xvdCAmJiBzbG90Ll9jKSB7XG4gICAgICBzbG90Ll9kID0gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgaWYgKCFub1Nsb3R0ZWQgJiYgcmVuZGVyZWQuc2NvcGVJZCkge1xuICAgIHJlbmRlcmVkLnNsb3RTY29wZUlkcyA9IFtyZW5kZXJlZC5zY29wZUlkICsgXCItc1wiXTtcbiAgfVxuICByZXR1cm4gcmVuZGVyZWQ7XG59XG5mdW5jdGlvbiBlbnN1cmVWYWxpZFZOb2RlKHZub2Rlcykge1xuICByZXR1cm4gdm5vZGVzLnNvbWUoKGNoaWxkKSA9PiB7XG4gICAgaWYgKCFpc1ZOb2RlKGNoaWxkKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKGNoaWxkLnR5cGUgPT09IENvbW1lbnQpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoY2hpbGQudHlwZSA9PT0gRnJhZ21lbnQgJiYgIWVuc3VyZVZhbGlkVk5vZGUoY2hpbGQuY2hpbGRyZW4pKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIHJldHVybiB0cnVlO1xuICB9KSA/IHZub2RlcyA6IG51bGw7XG59XG5cbmZ1bmN0aW9uIHRvSGFuZGxlcnMob2JqLCBwcmVzZXJ2ZUNhc2VJZk5lY2Vzc2FyeSkge1xuICBjb25zdCByZXQgPSB7fTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzT2JqZWN0KG9iaikpIHtcbiAgICB3YXJuJDEoYHYtb24gd2l0aCBubyBhcmd1bWVudCBleHBlY3RzIGFuIG9iamVjdCB2YWx1ZS5gKTtcbiAgICByZXR1cm4gcmV0O1xuICB9XG4gIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgIHJldFtwcmVzZXJ2ZUNhc2VJZk5lY2Vzc2FyeSAmJiAvW0EtWl0vLnRlc3Qoa2V5KSA/IGBvbjoke2tleX1gIDogdG9IYW5kbGVyS2V5KGtleSldID0gb2JqW2tleV07XG4gIH1cbiAgcmV0dXJuIHJldDtcbn1cblxuY29uc3QgZ2V0UHVibGljSW5zdGFuY2UgPSAoaSkgPT4ge1xuICBpZiAoIWkpIHJldHVybiBudWxsO1xuICBpZiAoaXNTdGF0ZWZ1bENvbXBvbmVudChpKSkgcmV0dXJuIGdldENvbXBvbmVudFB1YmxpY0luc3RhbmNlKGkpO1xuICByZXR1cm4gZ2V0UHVibGljSW5zdGFuY2UoaS5wYXJlbnQpO1xufTtcbmNvbnN0IHB1YmxpY1Byb3BlcnRpZXNNYXAgPSAoXG4gIC8vIE1vdmUgUFVSRSBtYXJrZXIgdG8gbmV3IGxpbmUgdG8gd29ya2Fyb3VuZCBjb21waWxlciBkaXNjYXJkaW5nIGl0XG4gIC8vIGR1ZSB0byB0eXBlIGFubm90YXRpb25cbiAgLyogQF9fUFVSRV9fICovIGV4dGVuZCgvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKSwge1xuICAgICQ6IChpKSA9PiBpLFxuICAgICRlbDogKGkpID0+IGkudm5vZGUuZWwsXG4gICAgJGRhdGE6IChpKSA9PiBpLmRhdGEsXG4gICAgJHByb3BzOiAoaSkgPT4gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShpLnByb3BzKSA6IGkucHJvcHMsXG4gICAgJGF0dHJzOiAoaSkgPT4gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShpLmF0dHJzKSA6IGkuYXR0cnMsXG4gICAgJHNsb3RzOiAoaSkgPT4gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShpLnNsb3RzKSA6IGkuc2xvdHMsXG4gICAgJHJlZnM6IChpKSA9PiAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gc2hhbGxvd1JlYWRvbmx5KGkucmVmcykgOiBpLnJlZnMsXG4gICAgJHBhcmVudDogKGkpID0+IGdldFB1YmxpY0luc3RhbmNlKGkucGFyZW50KSxcbiAgICAkcm9vdDogKGkpID0+IGdldFB1YmxpY0luc3RhbmNlKGkucm9vdCksXG4gICAgJGhvc3Q6IChpKSA9PiBpLmNlLFxuICAgICRlbWl0OiAoaSkgPT4gaS5lbWl0LFxuICAgICRvcHRpb25zOiAoaSkgPT4gX19WVUVfT1BUSU9OU19BUElfXyA/IHJlc29sdmVNZXJnZWRPcHRpb25zKGkpIDogaS50eXBlLFxuICAgICRmb3JjZVVwZGF0ZTogKGkpID0+IGkuZiB8fCAoaS5mID0gKCkgPT4ge1xuICAgICAgcXVldWVKb2IoaS51cGRhdGUpO1xuICAgIH0pLFxuICAgICRuZXh0VGljazogKGkpID0+IGkubiB8fCAoaS5uID0gbmV4dFRpY2suYmluZChpLnByb3h5KSksXG4gICAgJHdhdGNoOiAoaSkgPT4gX19WVUVfT1BUSU9OU19BUElfXyA/IGluc3RhbmNlV2F0Y2guYmluZChpKSA6IE5PT1BcbiAgfSlcbik7XG5jb25zdCBpc1Jlc2VydmVkUHJlZml4ID0gKGtleSkgPT4ga2V5ID09PSBcIl9cIiB8fCBrZXkgPT09IFwiJFwiO1xuY29uc3QgaGFzU2V0dXBCaW5kaW5nID0gKHN0YXRlLCBrZXkpID0+IHN0YXRlICE9PSBFTVBUWV9PQkogJiYgIXN0YXRlLl9faXNTY3JpcHRTZXR1cCAmJiBoYXNPd24oc3RhdGUsIGtleSk7XG5jb25zdCBQdWJsaWNJbnN0YW5jZVByb3h5SGFuZGxlcnMgPSB7XG4gIGdldCh7IF86IGluc3RhbmNlIH0sIGtleSkge1xuICAgIGlmIChrZXkgPT09IFwiX192X3NraXBcIikge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGNvbnN0IHsgY3R4LCBzZXR1cFN0YXRlLCBkYXRhLCBwcm9wcywgYWNjZXNzQ2FjaGUsIHR5cGUsIGFwcENvbnRleHQgfSA9IGluc3RhbmNlO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGtleSA9PT0gXCJfX2lzVnVlXCIpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoa2V5WzBdICE9PSBcIiRcIikge1xuICAgICAgY29uc3QgbiA9IGFjY2Vzc0NhY2hlW2tleV07XG4gICAgICBpZiAobiAhPT0gdm9pZCAwKSB7XG4gICAgICAgIHN3aXRjaCAobikge1xuICAgICAgICAgIGNhc2UgMSAvKiBTRVRVUCAqLzpcbiAgICAgICAgICAgIHJldHVybiBzZXR1cFN0YXRlW2tleV07XG4gICAgICAgICAgY2FzZSAyIC8qIERBVEEgKi86XG4gICAgICAgICAgICByZXR1cm4gZGF0YVtrZXldO1xuICAgICAgICAgIGNhc2UgNCAvKiBDT05URVhUICovOlxuICAgICAgICAgICAgcmV0dXJuIGN0eFtrZXldO1xuICAgICAgICAgIGNhc2UgMyAvKiBQUk9QUyAqLzpcbiAgICAgICAgICAgIHJldHVybiBwcm9wc1trZXldO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGhhc1NldHVwQmluZGluZyhzZXR1cFN0YXRlLCBrZXkpKSB7XG4gICAgICAgIGFjY2Vzc0NhY2hlW2tleV0gPSAxIC8qIFNFVFVQICovO1xuICAgICAgICByZXR1cm4gc2V0dXBTdGF0ZVtrZXldO1xuICAgICAgfSBlbHNlIGlmIChfX1ZVRV9PUFRJT05TX0FQSV9fICYmIGRhdGEgIT09IEVNUFRZX09CSiAmJiBoYXNPd24oZGF0YSwga2V5KSkge1xuICAgICAgICBhY2Nlc3NDYWNoZVtrZXldID0gMiAvKiBEQVRBICovO1xuICAgICAgICByZXR1cm4gZGF0YVtrZXldO1xuICAgICAgfSBlbHNlIGlmIChoYXNPd24ocHJvcHMsIGtleSkpIHtcbiAgICAgICAgYWNjZXNzQ2FjaGVba2V5XSA9IDMgLyogUFJPUFMgKi87XG4gICAgICAgIHJldHVybiBwcm9wc1trZXldO1xuICAgICAgfSBlbHNlIGlmIChjdHggIT09IEVNUFRZX09CSiAmJiBoYXNPd24oY3R4LCBrZXkpKSB7XG4gICAgICAgIGFjY2Vzc0NhY2hlW2tleV0gPSA0IC8qIENPTlRFWFQgKi87XG4gICAgICAgIHJldHVybiBjdHhba2V5XTtcbiAgICAgIH0gZWxzZSBpZiAoIV9fVlVFX09QVElPTlNfQVBJX18gfHwgc2hvdWxkQ2FjaGVBY2Nlc3MpIHtcbiAgICAgICAgYWNjZXNzQ2FjaGVba2V5XSA9IDAgLyogT1RIRVIgKi87XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHB1YmxpY0dldHRlciA9IHB1YmxpY1Byb3BlcnRpZXNNYXBba2V5XTtcbiAgICBsZXQgY3NzTW9kdWxlLCBnbG9iYWxQcm9wZXJ0aWVzO1xuICAgIGlmIChwdWJsaWNHZXR0ZXIpIHtcbiAgICAgIGlmIChrZXkgPT09IFwiJGF0dHJzXCIpIHtcbiAgICAgICAgdHJhY2soaW5zdGFuY2UuYXR0cnMsIFwiZ2V0XCIsIFwiXCIpO1xuICAgICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIG1hcmtBdHRyc0FjY2Vzc2VkKCk7XG4gICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYga2V5ID09PSBcIiRzbG90c1wiKSB7XG4gICAgICAgIHRyYWNrKGluc3RhbmNlLCBcImdldFwiLCBrZXkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHB1YmxpY0dldHRlcihpbnN0YW5jZSk7XG4gICAgfSBlbHNlIGlmIChcbiAgICAgIC8vIGNzcyBtb2R1bGUgKGluamVjdGVkIGJ5IHZ1ZS1sb2FkZXIpXG4gICAgICAoY3NzTW9kdWxlID0gdHlwZS5fX2Nzc01vZHVsZXMpICYmIChjc3NNb2R1bGUgPSBjc3NNb2R1bGVba2V5XSlcbiAgICApIHtcbiAgICAgIHJldHVybiBjc3NNb2R1bGU7XG4gICAgfSBlbHNlIGlmIChjdHggIT09IEVNUFRZX09CSiAmJiBoYXNPd24oY3R4LCBrZXkpKSB7XG4gICAgICBhY2Nlc3NDYWNoZVtrZXldID0gNCAvKiBDT05URVhUICovO1xuICAgICAgcmV0dXJuIGN0eFtrZXldO1xuICAgIH0gZWxzZSBpZiAoXG4gICAgICAvLyBnbG9iYWwgcHJvcGVydGllc1xuICAgICAgZ2xvYmFsUHJvcGVydGllcyA9IGFwcENvbnRleHQuY29uZmlnLmdsb2JhbFByb3BlcnRpZXMsIGhhc093bihnbG9iYWxQcm9wZXJ0aWVzLCBrZXkpXG4gICAgKSB7XG4gICAgICB7XG4gICAgICAgIHJldHVybiBnbG9iYWxQcm9wZXJ0aWVzW2tleV07XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSAmJiAoIWlzU3RyaW5nKGtleSkgfHwgLy8gIzEwOTEgYXZvaWQgaW50ZXJuYWwgaXNSZWYvaXNWTm9kZSBjaGVja3Mgb24gY29tcG9uZW50IGluc3RhbmNlIGxlYWRpbmdcbiAgICAvLyB0byBpbmZpbml0ZSB3YXJuaW5nIGxvb3BcbiAgICBrZXkuaW5kZXhPZihcIl9fdlwiKSAhPT0gMCkpIHtcbiAgICAgIGlmIChkYXRhICE9PSBFTVBUWV9PQkogJiYgaXNSZXNlcnZlZFByZWZpeChrZXlbMF0pICYmIGhhc093bihkYXRhLCBrZXkpKSB7XG4gICAgICAgIHdhcm4kMShcbiAgICAgICAgICBgUHJvcGVydHkgJHtKU09OLnN0cmluZ2lmeShcbiAgICAgICAgICAgIGtleVxuICAgICAgICAgICl9IG11c3QgYmUgYWNjZXNzZWQgdmlhICRkYXRhIGJlY2F1c2UgaXQgc3RhcnRzIHdpdGggYSByZXNlcnZlZCBjaGFyYWN0ZXIgKFwiJFwiIG9yIFwiX1wiKSBhbmQgaXMgbm90IHByb3hpZWQgb24gdGhlIHJlbmRlciBjb250ZXh0LmBcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSBpZiAoaW5zdGFuY2UgPT09IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSkge1xuICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgYFByb3BlcnR5ICR7SlNPTi5zdHJpbmdpZnkoa2V5KX0gd2FzIGFjY2Vzc2VkIGR1cmluZyByZW5kZXIgYnV0IGlzIG5vdCBkZWZpbmVkIG9uIGluc3RhbmNlLmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sXG4gIHNldCh7IF86IGluc3RhbmNlIH0sIGtleSwgdmFsdWUpIHtcbiAgICBjb25zdCB7IGRhdGEsIHNldHVwU3RhdGUsIGN0eCB9ID0gaW5zdGFuY2U7XG4gICAgaWYgKGhhc1NldHVwQmluZGluZyhzZXR1cFN0YXRlLCBrZXkpKSB7XG4gICAgICBzZXR1cFN0YXRlW2tleV0gPSB2YWx1ZTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBzZXR1cFN0YXRlLl9faXNTY3JpcHRTZXR1cCAmJiBoYXNPd24oc2V0dXBTdGF0ZSwga2V5KSkge1xuICAgICAgd2FybiQxKGBDYW5ub3QgbXV0YXRlIDxzY3JpcHQgc2V0dXA+IGJpbmRpbmcgXCIke2tleX1cIiBmcm9tIE9wdGlvbnMgQVBJLmApO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0gZWxzZSBpZiAoX19WVUVfT1BUSU9OU19BUElfXyAmJiBkYXRhICE9PSBFTVBUWV9PQkogJiYgaGFzT3duKGRhdGEsIGtleSkpIHtcbiAgICAgIGRhdGFba2V5XSA9IHZhbHVlO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIGlmIChoYXNPd24oaW5zdGFuY2UucHJvcHMsIGtleSkpIHtcbiAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgd2FybiQxKGBBdHRlbXB0aW5nIHRvIG11dGF0ZSBwcm9wIFwiJHtrZXl9XCIuIFByb3BzIGFyZSByZWFkb25seS5gKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGtleVswXSA9PT0gXCIkXCIgJiYga2V5LnNsaWNlKDEpIGluIGluc3RhbmNlKSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShcbiAgICAgICAgYEF0dGVtcHRpbmcgdG8gbXV0YXRlIHB1YmxpYyBwcm9wZXJ0eSBcIiR7a2V5fVwiLiBQcm9wZXJ0aWVzIHN0YXJ0aW5nIHdpdGggJCBhcmUgcmVzZXJ2ZWQgYW5kIHJlYWRvbmx5LmBcbiAgICAgICk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGtleSBpbiBpbnN0YW5jZS5hcHBDb250ZXh0LmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzKSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjdHgsIGtleSwge1xuICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgIHZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY3R4W2tleV0gPSB2YWx1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIGhhcyh7XG4gICAgXzogeyBkYXRhLCBzZXR1cFN0YXRlLCBhY2Nlc3NDYWNoZSwgY3R4LCBhcHBDb250ZXh0LCBwcm9wcywgdHlwZSB9XG4gIH0sIGtleSkge1xuICAgIGxldCBjc3NNb2R1bGVzO1xuICAgIHJldHVybiAhIShhY2Nlc3NDYWNoZVtrZXldIHx8IF9fVlVFX09QVElPTlNfQVBJX18gJiYgZGF0YSAhPT0gRU1QVFlfT0JKICYmIGtleVswXSAhPT0gXCIkXCIgJiYgaGFzT3duKGRhdGEsIGtleSkgfHwgaGFzU2V0dXBCaW5kaW5nKHNldHVwU3RhdGUsIGtleSkgfHwgaGFzT3duKHByb3BzLCBrZXkpIHx8IGhhc093bihjdHgsIGtleSkgfHwgaGFzT3duKHB1YmxpY1Byb3BlcnRpZXNNYXAsIGtleSkgfHwgaGFzT3duKGFwcENvbnRleHQuY29uZmlnLmdsb2JhbFByb3BlcnRpZXMsIGtleSkgfHwgKGNzc01vZHVsZXMgPSB0eXBlLl9fY3NzTW9kdWxlcykgJiYgY3NzTW9kdWxlc1trZXldKTtcbiAgfSxcbiAgZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIGRlc2NyaXB0b3IpIHtcbiAgICBpZiAoZGVzY3JpcHRvci5nZXQgIT0gbnVsbCkge1xuICAgICAgdGFyZ2V0Ll8uYWNjZXNzQ2FjaGVba2V5XSA9IDA7XG4gICAgfSBlbHNlIGlmIChoYXNPd24oZGVzY3JpcHRvciwgXCJ2YWx1ZVwiKSkge1xuICAgICAgdGhpcy5zZXQodGFyZ2V0LCBrZXksIGRlc2NyaXB0b3IudmFsdWUsIG51bGwpO1xuICAgIH1cbiAgICByZXR1cm4gUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgZGVzY3JpcHRvcik7XG4gIH1cbn07XG5pZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB0cnVlKSB7XG4gIFB1YmxpY0luc3RhbmNlUHJveHlIYW5kbGVycy5vd25LZXlzID0gKHRhcmdldCkgPT4ge1xuICAgIHdhcm4kMShcbiAgICAgIGBBdm9pZCBhcHAgbG9naWMgdGhhdCByZWxpZXMgb24gZW51bWVyYXRpbmcga2V5cyBvbiBhIGNvbXBvbmVudCBpbnN0YW5jZS4gVGhlIGtleXMgd2lsbCBiZSBlbXB0eSBpbiBwcm9kdWN0aW9uIG1vZGUgdG8gYXZvaWQgcGVyZm9ybWFuY2Ugb3ZlcmhlYWQuYFxuICAgICk7XG4gICAgcmV0dXJuIFJlZmxlY3Qub3duS2V5cyh0YXJnZXQpO1xuICB9O1xufVxuY29uc3QgUnVudGltZUNvbXBpbGVkUHVibGljSW5zdGFuY2VQcm94eUhhbmRsZXJzID0gLyogQF9fUFVSRV9fICovIGV4dGVuZCh7fSwgUHVibGljSW5zdGFuY2VQcm94eUhhbmRsZXJzLCB7XG4gIGdldCh0YXJnZXQsIGtleSkge1xuICAgIGlmIChrZXkgPT09IFN5bWJvbC51bnNjb3BhYmxlcykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gUHVibGljSW5zdGFuY2VQcm94eUhhbmRsZXJzLmdldCh0YXJnZXQsIGtleSwgdGFyZ2V0KTtcbiAgfSxcbiAgaGFzKF8sIGtleSkge1xuICAgIGNvbnN0IGhhcyA9IGtleVswXSAhPT0gXCJfXCIgJiYgIWlzR2xvYmFsbHlBbGxvd2VkKGtleSk7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWhhcyAmJiBQdWJsaWNJbnN0YW5jZVByb3h5SGFuZGxlcnMuaGFzKF8sIGtleSkpIHtcbiAgICAgIHdhcm4kMShcbiAgICAgICAgYFByb3BlcnR5ICR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAga2V5XG4gICAgICAgICl9IHNob3VsZCBub3Qgc3RhcnQgd2l0aCBfIHdoaWNoIGlzIGEgcmVzZXJ2ZWQgcHJlZml4IGZvciBWdWUgaW50ZXJuYWxzLmBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBoYXM7XG4gIH1cbn0pO1xuZnVuY3Rpb24gY3JlYXRlRGV2UmVuZGVyQ29udGV4dChpbnN0YW5jZSkge1xuICBjb25zdCB0YXJnZXQgPSB7fTtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgYF9gLCB7XG4gICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgIGdldDogKCkgPT4gaW5zdGFuY2VcbiAgfSk7XG4gIE9iamVjdC5rZXlzKHB1YmxpY1Byb3BlcnRpZXNNYXApLmZvckVhY2goKGtleSkgPT4ge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwge1xuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICBnZXQ6ICgpID0+IHB1YmxpY1Byb3BlcnRpZXNNYXBba2V5XShpbnN0YW5jZSksXG4gICAgICAvLyBpbnRlcmNlcHRlZCBieSB0aGUgcHJveHkgc28gbm8gbmVlZCBmb3IgaW1wbGVtZW50YXRpb24sXG4gICAgICAvLyBidXQgbmVlZGVkIHRvIHByZXZlbnQgc2V0IGVycm9yc1xuICAgICAgc2V0OiBOT09QXG4gICAgfSk7XG4gIH0pO1xuICByZXR1cm4gdGFyZ2V0O1xufVxuZnVuY3Rpb24gZXhwb3NlUHJvcHNPblJlbmRlckNvbnRleHQoaW5zdGFuY2UpIHtcbiAgY29uc3Qge1xuICAgIGN0eCxcbiAgICBwcm9wc09wdGlvbnM6IFtwcm9wc09wdGlvbnNdXG4gIH0gPSBpbnN0YW5jZTtcbiAgaWYgKHByb3BzT3B0aW9ucykge1xuICAgIE9iamVjdC5rZXlzKHByb3BzT3B0aW9ucykuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY3R4LCBrZXksIHtcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICBnZXQ6ICgpID0+IGluc3RhbmNlLnByb3BzW2tleV0sXG4gICAgICAgIHNldDogTk9PUFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGV4cG9zZVNldHVwU3RhdGVPblJlbmRlckNvbnRleHQoaW5zdGFuY2UpIHtcbiAgY29uc3QgeyBjdHgsIHNldHVwU3RhdGUgfSA9IGluc3RhbmNlO1xuICBPYmplY3Qua2V5cyh0b1JhdyhzZXR1cFN0YXRlKSkuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgaWYgKCFzZXR1cFN0YXRlLl9faXNTY3JpcHRTZXR1cCkge1xuICAgICAgaWYgKGlzUmVzZXJ2ZWRQcmVmaXgoa2V5WzBdKSkge1xuICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgYHNldHVwKCkgcmV0dXJuIHByb3BlcnR5ICR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgICBrZXlcbiAgICAgICAgICApfSBzaG91bGQgbm90IHN0YXJ0IHdpdGggXCIkXCIgb3IgXCJfXCIgd2hpY2ggYXJlIHJlc2VydmVkIHByZWZpeGVzIGZvciBWdWUgaW50ZXJuYWxzLmBcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGN0eCwga2V5LCB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgZ2V0OiAoKSA9PiBzZXR1cFN0YXRlW2tleV0sXG4gICAgICAgIHNldDogTk9PUFxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbn1cblxuY29uc3Qgd2FyblJ1bnRpbWVVc2FnZSA9IChtZXRob2QpID0+IHdhcm4kMShcbiAgYCR7bWV0aG9kfSgpIGlzIGEgY29tcGlsZXItaGludCBoZWxwZXIgdGhhdCBpcyBvbmx5IHVzYWJsZSBpbnNpZGUgPHNjcmlwdCBzZXR1cD4gb2YgYSBzaW5nbGUgZmlsZSBjb21wb25lbnQuIEl0cyBhcmd1bWVudHMgc2hvdWxkIGJlIGNvbXBpbGVkIGF3YXkgYW5kIHBhc3NpbmcgaXQgYXQgcnVudGltZSBoYXMgbm8gZWZmZWN0LmBcbik7XG5mdW5jdGlvbiBkZWZpbmVQcm9wcygpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuUnVudGltZVVzYWdlKGBkZWZpbmVQcm9wc2ApO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gZGVmaW5lRW1pdHMoKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FyblJ1bnRpbWVVc2FnZShgZGVmaW5lRW1pdHNgKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIGRlZmluZUV4cG9zZShleHBvc2VkKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FyblJ1bnRpbWVVc2FnZShgZGVmaW5lRXhwb3NlYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGRlZmluZU9wdGlvbnMob3B0aW9ucykge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm5SdW50aW1lVXNhZ2UoYGRlZmluZU9wdGlvbnNgKTtcbiAgfVxufVxuZnVuY3Rpb24gZGVmaW5lU2xvdHMoKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FyblJ1bnRpbWVVc2FnZShgZGVmaW5lU2xvdHNgKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIGRlZmluZU1vZGVsKCkge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm5SdW50aW1lVXNhZ2UoXCJkZWZpbmVNb2RlbFwiKTtcbiAgfVxufVxuZnVuY3Rpb24gd2l0aERlZmF1bHRzKHByb3BzLCBkZWZhdWx0cykge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm5SdW50aW1lVXNhZ2UoYHdpdGhEZWZhdWx0c2ApO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gdXNlU2xvdHMoKSB7XG4gIHJldHVybiBnZXRDb250ZXh0KFwidXNlU2xvdHNcIikuc2xvdHM7XG59XG5mdW5jdGlvbiB1c2VBdHRycygpIHtcbiAgcmV0dXJuIGdldENvbnRleHQoXCJ1c2VBdHRyc1wiKS5hdHRycztcbn1cbmZ1bmN0aW9uIGdldENvbnRleHQoY2FsbGVkRnVuY3Rpb25OYW1lKSB7XG4gIGNvbnN0IGkgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWkpIHtcbiAgICB3YXJuJDEoYCR7Y2FsbGVkRnVuY3Rpb25OYW1lfSgpIGNhbGxlZCB3aXRob3V0IGFjdGl2ZSBpbnN0YW5jZS5gKTtcbiAgfVxuICByZXR1cm4gaS5zZXR1cENvbnRleHQgfHwgKGkuc2V0dXBDb250ZXh0ID0gY3JlYXRlU2V0dXBDb250ZXh0KGkpKTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVByb3BzT3JFbWl0cyhwcm9wcykge1xuICByZXR1cm4gaXNBcnJheShwcm9wcykgPyBwcm9wcy5yZWR1Y2UoXG4gICAgKG5vcm1hbGl6ZWQsIHApID0+IChub3JtYWxpemVkW3BdID0gbnVsbCwgbm9ybWFsaXplZCksXG4gICAge31cbiAgKSA6IHByb3BzO1xufVxuZnVuY3Rpb24gbWVyZ2VEZWZhdWx0cyhyYXcsIGRlZmF1bHRzKSB7XG4gIGNvbnN0IHByb3BzID0gbm9ybWFsaXplUHJvcHNPckVtaXRzKHJhdyk7XG4gIGZvciAoY29uc3Qga2V5IGluIGRlZmF1bHRzKSB7XG4gICAgaWYgKGtleS5zdGFydHNXaXRoKFwiX19za2lwXCIpKSBjb250aW51ZTtcbiAgICBsZXQgb3B0ID0gcHJvcHNba2V5XTtcbiAgICBpZiAob3B0KSB7XG4gICAgICBpZiAoaXNBcnJheShvcHQpIHx8IGlzRnVuY3Rpb24ob3B0KSkge1xuICAgICAgICBvcHQgPSBwcm9wc1trZXldID0geyB0eXBlOiBvcHQsIGRlZmF1bHQ6IGRlZmF1bHRzW2tleV0gfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9wdC5kZWZhdWx0ID0gZGVmYXVsdHNba2V5XTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKG9wdCA9PT0gbnVsbCkge1xuICAgICAgb3B0ID0gcHJvcHNba2V5XSA9IHsgZGVmYXVsdDogZGVmYXVsdHNba2V5XSB9O1xuICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgd2FybiQxKGBwcm9wcyBkZWZhdWx0IGtleSBcIiR7a2V5fVwiIGhhcyBubyBjb3JyZXNwb25kaW5nIGRlY2xhcmF0aW9uLmApO1xuICAgIH1cbiAgICBpZiAob3B0ICYmIGRlZmF1bHRzW2BfX3NraXBfJHtrZXl9YF0pIHtcbiAgICAgIG9wdC5za2lwRmFjdG9yeSA9IHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBwcm9wcztcbn1cbmZ1bmN0aW9uIG1lcmdlTW9kZWxzKGEsIGIpIHtcbiAgaWYgKCFhIHx8ICFiKSByZXR1cm4gYSB8fCBiO1xuICBpZiAoaXNBcnJheShhKSAmJiBpc0FycmF5KGIpKSByZXR1cm4gYS5jb25jYXQoYik7XG4gIHJldHVybiBleHRlbmQoe30sIG5vcm1hbGl6ZVByb3BzT3JFbWl0cyhhKSwgbm9ybWFsaXplUHJvcHNPckVtaXRzKGIpKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVByb3BzUmVzdFByb3h5KHByb3BzLCBleGNsdWRlZEtleXMpIHtcbiAgY29uc3QgcmV0ID0ge307XG4gIGZvciAoY29uc3Qga2V5IGluIHByb3BzKSB7XG4gICAgaWYgKCFleGNsdWRlZEtleXMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJldCwga2V5LCB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGdldDogKCkgPT4gcHJvcHNba2V5XVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXQ7XG59XG5mdW5jdGlvbiB3aXRoQXN5bmNDb250ZXh0KGdldEF3YWl0YWJsZSkge1xuICBjb25zdCBjdHggPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgY29uc3QgaW5TU1JTZXR1cCA9IGlzSW5TU1JDb21wb25lbnRTZXR1cDtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWN0eCkge1xuICAgIHdhcm4kMShcbiAgICAgIGB3aXRoQXN5bmNDb250ZXh0IGNhbGxlZCB3aXRob3V0IGFjdGl2ZSBjdXJyZW50IGluc3RhbmNlLiBUaGlzIGlzIGxpa2VseSBhIGJ1Zy5gXG4gICAgKTtcbiAgfVxuICBsZXQgYXdhaXRhYmxlID0gZ2V0QXdhaXRhYmxlKCk7XG4gIHVuc2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGlmIChpblNTUlNldHVwKSB7XG4gICAgc2V0SW5TU1JTZXR1cFN0YXRlKGZhbHNlKTtcbiAgfVxuICBjb25zdCByZXN0b3JlID0gKCkgPT4ge1xuICAgIHNldEN1cnJlbnRJbnN0YW5jZShjdHgpO1xuICAgIGlmIChpblNTUlNldHVwKSB7XG4gICAgICBzZXRJblNTUlNldHVwU3RhdGUodHJ1ZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuICAgIGlmIChnZXRDdXJyZW50SW5zdGFuY2UoKSAhPT0gY3R4KSBjdHguc2NvcGUub2ZmKCk7XG4gICAgdW5zZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICBpZiAoaW5TU1JTZXR1cCkge1xuICAgICAgc2V0SW5TU1JTZXR1cFN0YXRlKGZhbHNlKTtcbiAgICB9XG4gIH07XG4gIGlmIChpc1Byb21pc2UoYXdhaXRhYmxlKSkge1xuICAgIGF3YWl0YWJsZSA9IGF3YWl0YWJsZS5jYXRjaCgoZSkgPT4ge1xuICAgICAgcmVzdG9yZSgpO1xuICAgICAgUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKS50aGVuKGNsZWFudXApKTtcbiAgICAgIHRocm93IGU7XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIFtcbiAgICBhd2FpdGFibGUsXG4gICAgKCkgPT4ge1xuICAgICAgcmVzdG9yZSgpO1xuICAgICAgUHJvbWlzZS5yZXNvbHZlKCkudGhlbihjbGVhbnVwKTtcbiAgICB9XG4gIF07XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZUR1cGxpY2F0ZUNoZWNrZXIoKSB7XG4gIGNvbnN0IGNhY2hlID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiAodHlwZSwga2V5KSA9PiB7XG4gICAgaWYgKGNhY2hlW2tleV0pIHtcbiAgICAgIHdhcm4kMShgJHt0eXBlfSBwcm9wZXJ0eSBcIiR7a2V5fVwiIGlzIGFscmVhZHkgZGVmaW5lZCBpbiAke2NhY2hlW2tleV19LmApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjYWNoZVtrZXldID0gdHlwZTtcbiAgICB9XG4gIH07XG59XG5sZXQgc2hvdWxkQ2FjaGVBY2Nlc3MgPSB0cnVlO1xuZnVuY3Rpb24gYXBwbHlPcHRpb25zKGluc3RhbmNlKSB7XG4gIGNvbnN0IG9wdGlvbnMgPSByZXNvbHZlTWVyZ2VkT3B0aW9ucyhpbnN0YW5jZSk7XG4gIGNvbnN0IHB1YmxpY1RoaXMgPSBpbnN0YW5jZS5wcm94eTtcbiAgY29uc3QgY3R4ID0gaW5zdGFuY2UuY3R4O1xuICBzaG91bGRDYWNoZUFjY2VzcyA9IGZhbHNlO1xuICBpZiAob3B0aW9ucy5iZWZvcmVDcmVhdGUpIHtcbiAgICBjYWxsSG9vayhvcHRpb25zLmJlZm9yZUNyZWF0ZSwgaW5zdGFuY2UsIFwiYmNcIik7XG4gIH1cbiAgY29uc3Qge1xuICAgIC8vIHN0YXRlXG4gICAgZGF0YTogZGF0YU9wdGlvbnMsXG4gICAgY29tcHV0ZWQ6IGNvbXB1dGVkT3B0aW9ucyxcbiAgICBtZXRob2RzLFxuICAgIHdhdGNoOiB3YXRjaE9wdGlvbnMsXG4gICAgcHJvdmlkZTogcHJvdmlkZU9wdGlvbnMsXG4gICAgaW5qZWN0OiBpbmplY3RPcHRpb25zLFxuICAgIC8vIGxpZmVjeWNsZVxuICAgIGNyZWF0ZWQsXG4gICAgYmVmb3JlTW91bnQsXG4gICAgbW91bnRlZCxcbiAgICBiZWZvcmVVcGRhdGUsXG4gICAgdXBkYXRlZCxcbiAgICBhY3RpdmF0ZWQsXG4gICAgZGVhY3RpdmF0ZWQsXG4gICAgYmVmb3JlRGVzdHJveSxcbiAgICBiZWZvcmVVbm1vdW50LFxuICAgIGRlc3Ryb3llZCxcbiAgICB1bm1vdW50ZWQsXG4gICAgcmVuZGVyLFxuICAgIHJlbmRlclRyYWNrZWQsXG4gICAgcmVuZGVyVHJpZ2dlcmVkLFxuICAgIGVycm9yQ2FwdHVyZWQsXG4gICAgc2VydmVyUHJlZmV0Y2gsXG4gICAgLy8gcHVibGljIEFQSVxuICAgIGV4cG9zZSxcbiAgICBpbmhlcml0QXR0cnMsXG4gICAgLy8gYXNzZXRzXG4gICAgY29tcG9uZW50cyxcbiAgICBkaXJlY3RpdmVzLFxuICAgIGZpbHRlcnNcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGNoZWNrRHVwbGljYXRlUHJvcGVydGllcyA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBjcmVhdGVEdXBsaWNhdGVDaGVja2VyKCkgOiBudWxsO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGNvbnN0IFtwcm9wc09wdGlvbnNdID0gaW5zdGFuY2UucHJvcHNPcHRpb25zO1xuICAgIGlmIChwcm9wc09wdGlvbnMpIHtcbiAgICAgIGZvciAoY29uc3Qga2V5IGluIHByb3BzT3B0aW9ucykge1xuICAgICAgICBjaGVja0R1cGxpY2F0ZVByb3BlcnRpZXMoXCJQcm9wc1wiIC8qIFBST1BTICovLCBrZXkpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoaW5qZWN0T3B0aW9ucykge1xuICAgIHJlc29sdmVJbmplY3Rpb25zKGluamVjdE9wdGlvbnMsIGN0eCwgY2hlY2tEdXBsaWNhdGVQcm9wZXJ0aWVzKTtcbiAgfVxuICBpZiAobWV0aG9kcykge1xuICAgIGZvciAoY29uc3Qga2V5IGluIG1ldGhvZHMpIHtcbiAgICAgIGNvbnN0IG1ldGhvZEhhbmRsZXIgPSBtZXRob2RzW2tleV07XG4gICAgICBpZiAoaXNGdW5jdGlvbihtZXRob2RIYW5kbGVyKSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjdHgsIGtleSwge1xuICAgICAgICAgICAgdmFsdWU6IG1ldGhvZEhhbmRsZXIuYmluZChwdWJsaWNUaGlzKSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZVxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGN0eFtrZXldID0gbWV0aG9kSGFuZGxlci5iaW5kKHB1YmxpY1RoaXMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgY2hlY2tEdXBsaWNhdGVQcm9wZXJ0aWVzKFwiTWV0aG9kc1wiIC8qIE1FVEhPRFMgKi8sIGtleSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgYE1ldGhvZCBcIiR7a2V5fVwiIGhhcyB0eXBlIFwiJHt0eXBlb2YgbWV0aG9kSGFuZGxlcn1cIiBpbiB0aGUgY29tcG9uZW50IGRlZmluaXRpb24uIERpZCB5b3UgcmVmZXJlbmNlIHRoZSBmdW5jdGlvbiBjb3JyZWN0bHk/YFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoZGF0YU9wdGlvbnMpIHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhaXNGdW5jdGlvbihkYXRhT3B0aW9ucykpIHtcbiAgICAgIHdhcm4kMShcbiAgICAgICAgYFRoZSBkYXRhIG9wdGlvbiBtdXN0IGJlIGEgZnVuY3Rpb24uIFBsYWluIG9iamVjdCB1c2FnZSBpcyBubyBsb25nZXIgc3VwcG9ydGVkLmBcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IGRhdGEgPSBkYXRhT3B0aW9ucy5jYWxsKHB1YmxpY1RoaXMsIHB1YmxpY1RoaXMpO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzUHJvbWlzZShkYXRhKSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgZGF0YSgpIHJldHVybmVkIGEgUHJvbWlzZSAtIG5vdGUgZGF0YSgpIGNhbm5vdCBiZSBhc3luYzsgSWYgeW91IGludGVuZCB0byBwZXJmb3JtIGRhdGEgZmV0Y2hpbmcgYmVmb3JlIGNvbXBvbmVudCByZW5kZXJzLCB1c2UgYXN5bmMgc2V0dXAoKSArIDxTdXNwZW5zZT4uYFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCFpc09iamVjdChkYXRhKSkge1xuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuJDEoYGRhdGEoKSBzaG91bGQgcmV0dXJuIGFuIG9iamVjdC5gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW5zdGFuY2UuZGF0YSA9IHJlYWN0aXZlKGRhdGEpO1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICAgIGNoZWNrRHVwbGljYXRlUHJvcGVydGllcyhcIkRhdGFcIiAvKiBEQVRBICovLCBrZXkpO1xuICAgICAgICAgIGlmICghaXNSZXNlcnZlZFByZWZpeChrZXlbMF0pKSB7XG4gICAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY3R4LCBrZXksIHtcbiAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICBnZXQ6ICgpID0+IGRhdGFba2V5XSxcbiAgICAgICAgICAgICAgc2V0OiBOT09QXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgc2hvdWxkQ2FjaGVBY2Nlc3MgPSB0cnVlO1xuICBpZiAoY29tcHV0ZWRPcHRpb25zKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gY29tcHV0ZWRPcHRpb25zKSB7XG4gICAgICBjb25zdCBvcHQgPSBjb21wdXRlZE9wdGlvbnNba2V5XTtcbiAgICAgIGNvbnN0IGdldCA9IGlzRnVuY3Rpb24ob3B0KSA/IG9wdC5iaW5kKHB1YmxpY1RoaXMsIHB1YmxpY1RoaXMpIDogaXNGdW5jdGlvbihvcHQuZ2V0KSA/IG9wdC5nZXQuYmluZChwdWJsaWNUaGlzLCBwdWJsaWNUaGlzKSA6IE5PT1A7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBnZXQgPT09IE5PT1ApIHtcbiAgICAgICAgd2FybiQxKGBDb21wdXRlZCBwcm9wZXJ0eSBcIiR7a2V5fVwiIGhhcyBubyBnZXR0ZXIuYCk7XG4gICAgICB9XG4gICAgICBjb25zdCBzZXQgPSAhaXNGdW5jdGlvbihvcHQpICYmIGlzRnVuY3Rpb24ob3B0LnNldCkgPyBvcHQuc2V0LmJpbmQocHVibGljVGhpcykgOiAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gKCkgPT4ge1xuICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgYFdyaXRlIG9wZXJhdGlvbiBmYWlsZWQ6IGNvbXB1dGVkIHByb3BlcnR5IFwiJHtrZXl9XCIgaXMgcmVhZG9ubHkuYFxuICAgICAgICApO1xuICAgICAgfSA6IE5PT1A7XG4gICAgICBjb25zdCBjID0gY29tcHV0ZWQoe1xuICAgICAgICBnZXQsXG4gICAgICAgIHNldFxuICAgICAgfSk7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY3R4LCBrZXksIHtcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICBnZXQ6ICgpID0+IGMudmFsdWUsXG4gICAgICAgIHNldDogKHYpID0+IGMudmFsdWUgPSB2XG4gICAgICB9KTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIGNoZWNrRHVwbGljYXRlUHJvcGVydGllcyhcIkNvbXB1dGVkXCIgLyogQ09NUFVURUQgKi8sIGtleSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGlmICh3YXRjaE9wdGlvbnMpIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiB3YXRjaE9wdGlvbnMpIHtcbiAgICAgIGNyZWF0ZVdhdGNoZXIod2F0Y2hPcHRpb25zW2tleV0sIGN0eCwgcHVibGljVGhpcywga2V5KTtcbiAgICB9XG4gIH1cbiAgaWYgKHByb3ZpZGVPcHRpb25zKSB7XG4gICAgY29uc3QgcHJvdmlkZXMgPSBpc0Z1bmN0aW9uKHByb3ZpZGVPcHRpb25zKSA/IHByb3ZpZGVPcHRpb25zLmNhbGwocHVibGljVGhpcykgOiBwcm92aWRlT3B0aW9ucztcbiAgICBSZWZsZWN0Lm93bktleXMocHJvdmlkZXMpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgcHJvdmlkZShrZXksIHByb3ZpZGVzW2tleV0pO1xuICAgIH0pO1xuICB9XG4gIGlmIChjcmVhdGVkKSB7XG4gICAgY2FsbEhvb2soY3JlYXRlZCwgaW5zdGFuY2UsIFwiY1wiKTtcbiAgfVxuICBmdW5jdGlvbiByZWdpc3RlckxpZmVjeWNsZUhvb2socmVnaXN0ZXIsIGhvb2spIHtcbiAgICBpZiAoaXNBcnJheShob29rKSkge1xuICAgICAgaG9vay5mb3JFYWNoKChfaG9vaykgPT4gcmVnaXN0ZXIoX2hvb2suYmluZChwdWJsaWNUaGlzKSkpO1xuICAgIH0gZWxzZSBpZiAoaG9vaykge1xuICAgICAgcmVnaXN0ZXIoaG9vay5iaW5kKHB1YmxpY1RoaXMpKTtcbiAgICB9XG4gIH1cbiAgcmVnaXN0ZXJMaWZlY3ljbGVIb29rKG9uQmVmb3JlTW91bnQsIGJlZm9yZU1vdW50KTtcbiAgcmVnaXN0ZXJMaWZlY3ljbGVIb29rKG9uTW91bnRlZCwgbW91bnRlZCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvbkJlZm9yZVVwZGF0ZSwgYmVmb3JlVXBkYXRlKTtcbiAgcmVnaXN0ZXJMaWZlY3ljbGVIb29rKG9uVXBkYXRlZCwgdXBkYXRlZCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvbkFjdGl2YXRlZCwgYWN0aXZhdGVkKTtcbiAgcmVnaXN0ZXJMaWZlY3ljbGVIb29rKG9uRGVhY3RpdmF0ZWQsIGRlYWN0aXZhdGVkKTtcbiAgcmVnaXN0ZXJMaWZlY3ljbGVIb29rKG9uRXJyb3JDYXB0dXJlZCwgZXJyb3JDYXB0dXJlZCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvblJlbmRlclRyYWNrZWQsIHJlbmRlclRyYWNrZWQpO1xuICByZWdpc3RlckxpZmVjeWNsZUhvb2sob25SZW5kZXJUcmlnZ2VyZWQsIHJlbmRlclRyaWdnZXJlZCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvbkJlZm9yZVVubW91bnQsIGJlZm9yZVVubW91bnQpO1xuICByZWdpc3RlckxpZmVjeWNsZUhvb2sob25Vbm1vdW50ZWQsIHVubW91bnRlZCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvblNlcnZlclByZWZldGNoLCBzZXJ2ZXJQcmVmZXRjaCk7XG4gIGlmIChpc0FycmF5KGV4cG9zZSkpIHtcbiAgICBpZiAoZXhwb3NlLmxlbmd0aCkge1xuICAgICAgY29uc3QgZXhwb3NlZCA9IGluc3RhbmNlLmV4cG9zZWQgfHwgKGluc3RhbmNlLmV4cG9zZWQgPSB7fSk7XG4gICAgICBleHBvc2UuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvc2VkLCBrZXksIHtcbiAgICAgICAgICBnZXQ6ICgpID0+IHB1YmxpY1RoaXNba2V5XSxcbiAgICAgICAgICBzZXQ6ICh2YWwpID0+IHB1YmxpY1RoaXNba2V5XSA9IHZhbCxcbiAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICghaW5zdGFuY2UuZXhwb3NlZCkge1xuICAgICAgaW5zdGFuY2UuZXhwb3NlZCA9IHt9O1xuICAgIH1cbiAgfVxuICBpZiAocmVuZGVyICYmIGluc3RhbmNlLnJlbmRlciA9PT0gTk9PUCkge1xuICAgIGluc3RhbmNlLnJlbmRlciA9IHJlbmRlcjtcbiAgfVxuICBpZiAoaW5oZXJpdEF0dHJzICE9IG51bGwpIHtcbiAgICBpbnN0YW5jZS5pbmhlcml0QXR0cnMgPSBpbmhlcml0QXR0cnM7XG4gIH1cbiAgaWYgKGNvbXBvbmVudHMpIGluc3RhbmNlLmNvbXBvbmVudHMgPSBjb21wb25lbnRzO1xuICBpZiAoZGlyZWN0aXZlcykgaW5zdGFuY2UuZGlyZWN0aXZlcyA9IGRpcmVjdGl2ZXM7XG4gIGlmIChzZXJ2ZXJQcmVmZXRjaCkge1xuICAgIG1hcmtBc3luY0JvdW5kYXJ5KGluc3RhbmNlKTtcbiAgfVxufVxuZnVuY3Rpb24gcmVzb2x2ZUluamVjdGlvbnMoaW5qZWN0T3B0aW9ucywgY3R4LCBjaGVja0R1cGxpY2F0ZVByb3BlcnRpZXMgPSBOT09QKSB7XG4gIGlmIChpc0FycmF5KGluamVjdE9wdGlvbnMpKSB7XG4gICAgaW5qZWN0T3B0aW9ucyA9IG5vcm1hbGl6ZUluamVjdChpbmplY3RPcHRpb25zKTtcbiAgfVxuICBmb3IgKGNvbnN0IGtleSBpbiBpbmplY3RPcHRpb25zKSB7XG4gICAgY29uc3Qgb3B0ID0gaW5qZWN0T3B0aW9uc1trZXldO1xuICAgIGxldCBpbmplY3RlZDtcbiAgICBpZiAoaXNPYmplY3Qob3B0KSkge1xuICAgICAgaWYgKFwiZGVmYXVsdFwiIGluIG9wdCkge1xuICAgICAgICBpbmplY3RlZCA9IGluamVjdChcbiAgICAgICAgICBvcHQuZnJvbSB8fCBrZXksXG4gICAgICAgICAgb3B0LmRlZmF1bHQsXG4gICAgICAgICAgdHJ1ZVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaW5qZWN0ZWQgPSBpbmplY3Qob3B0LmZyb20gfHwga2V5KTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaW5qZWN0ZWQgPSBpbmplY3Qob3B0KTtcbiAgICB9XG4gICAgaWYgKGlzUmVmKGluamVjdGVkKSkge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGN0eCwga2V5LCB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgZ2V0OiAoKSA9PiBpbmplY3RlZC52YWx1ZSxcbiAgICAgICAgc2V0OiAodikgPT4gaW5qZWN0ZWQudmFsdWUgPSB2XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY3R4W2tleV0gPSBpbmplY3RlZDtcbiAgICB9XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIGNoZWNrRHVwbGljYXRlUHJvcGVydGllcyhcIkluamVjdFwiIC8qIElOSkVDVCAqLywga2V5KTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGNhbGxIb29rKGhvb2ssIGluc3RhbmNlLCB0eXBlKSB7XG4gIGNhbGxXaXRoQXN5bmNFcnJvckhhbmRsaW5nKFxuICAgIGlzQXJyYXkoaG9vaykgPyBob29rLm1hcCgoaCkgPT4gaC5iaW5kKGluc3RhbmNlLnByb3h5KSkgOiBob29rLmJpbmQoaW5zdGFuY2UucHJveHkpLFxuICAgIGluc3RhbmNlLFxuICAgIHR5cGVcbiAgKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVdhdGNoZXIocmF3LCBjdHgsIHB1YmxpY1RoaXMsIGtleSkge1xuICBsZXQgZ2V0dGVyID0ga2V5LmluY2x1ZGVzKFwiLlwiKSA/IGNyZWF0ZVBhdGhHZXR0ZXIocHVibGljVGhpcywga2V5KSA6ICgpID0+IHB1YmxpY1RoaXNba2V5XTtcbiAgaWYgKGlzU3RyaW5nKHJhdykpIHtcbiAgICBjb25zdCBoYW5kbGVyID0gY3R4W3Jhd107XG4gICAgaWYgKGlzRnVuY3Rpb24oaGFuZGxlcikpIHtcbiAgICAgIHtcbiAgICAgICAgd2F0Y2goZ2V0dGVyLCBoYW5kbGVyKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHdhcm4kMShgSW52YWxpZCB3YXRjaCBoYW5kbGVyIHNwZWNpZmllZCBieSBrZXkgXCIke3Jhd31cImAsIGhhbmRsZXIpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChpc0Z1bmN0aW9uKHJhdykpIHtcbiAgICB7XG4gICAgICB3YXRjaChnZXR0ZXIsIHJhdy5iaW5kKHB1YmxpY1RoaXMpKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNPYmplY3QocmF3KSkge1xuICAgIGlmIChpc0FycmF5KHJhdykpIHtcbiAgICAgIHJhdy5mb3JFYWNoKChyKSA9PiBjcmVhdGVXYXRjaGVyKHIsIGN0eCwgcHVibGljVGhpcywga2V5KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGhhbmRsZXIgPSBpc0Z1bmN0aW9uKHJhdy5oYW5kbGVyKSA/IHJhdy5oYW5kbGVyLmJpbmQocHVibGljVGhpcykgOiBjdHhbcmF3LmhhbmRsZXJdO1xuICAgICAgaWYgKGlzRnVuY3Rpb24oaGFuZGxlcikpIHtcbiAgICAgICAgd2F0Y2goZ2V0dGVyLCBoYW5kbGVyLCByYXcpO1xuICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIHdhcm4kMShgSW52YWxpZCB3YXRjaCBoYW5kbGVyIHNwZWNpZmllZCBieSBrZXkgXCIke3Jhdy5oYW5kbGVyfVwiYCwgaGFuZGxlcik7XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuJDEoYEludmFsaWQgd2F0Y2ggb3B0aW9uOiBcIiR7a2V5fVwiYCwgcmF3KTtcbiAgfVxufVxuZnVuY3Rpb24gcmVzb2x2ZU1lcmdlZE9wdGlvbnMoaW5zdGFuY2UpIHtcbiAgY29uc3QgYmFzZSA9IGluc3RhbmNlLnR5cGU7XG4gIGNvbnN0IHsgbWl4aW5zLCBleHRlbmRzOiBleHRlbmRzT3B0aW9ucyB9ID0gYmFzZTtcbiAgY29uc3Qge1xuICAgIG1peGluczogZ2xvYmFsTWl4aW5zLFxuICAgIG9wdGlvbnNDYWNoZTogY2FjaGUsXG4gICAgY29uZmlnOiB7IG9wdGlvbk1lcmdlU3RyYXRlZ2llcyB9XG4gIH0gPSBpbnN0YW5jZS5hcHBDb250ZXh0O1xuICBjb25zdCBjYWNoZWQgPSBjYWNoZS5nZXQoYmFzZSk7XG4gIGxldCByZXNvbHZlZDtcbiAgaWYgKGNhY2hlZCkge1xuICAgIHJlc29sdmVkID0gY2FjaGVkO1xuICB9IGVsc2UgaWYgKCFnbG9iYWxNaXhpbnMubGVuZ3RoICYmICFtaXhpbnMgJiYgIWV4dGVuZHNPcHRpb25zKSB7XG4gICAge1xuICAgICAgcmVzb2x2ZWQgPSBiYXNlO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICByZXNvbHZlZCA9IHt9O1xuICAgIGlmIChnbG9iYWxNaXhpbnMubGVuZ3RoKSB7XG4gICAgICBnbG9iYWxNaXhpbnMuZm9yRWFjaChcbiAgICAgICAgKG0pID0+IG1lcmdlT3B0aW9ucyhyZXNvbHZlZCwgbSwgb3B0aW9uTWVyZ2VTdHJhdGVnaWVzLCB0cnVlKVxuICAgICAgKTtcbiAgICB9XG4gICAgbWVyZ2VPcHRpb25zKHJlc29sdmVkLCBiYXNlLCBvcHRpb25NZXJnZVN0cmF0ZWdpZXMpO1xuICB9XG4gIGlmIChpc09iamVjdChiYXNlKSkge1xuICAgIGNhY2hlLnNldChiYXNlLCByZXNvbHZlZCk7XG4gIH1cbiAgcmV0dXJuIHJlc29sdmVkO1xufVxuZnVuY3Rpb24gbWVyZ2VPcHRpb25zKHRvLCBmcm9tLCBzdHJhdHMsIGFzTWl4aW4gPSBmYWxzZSkge1xuICBjb25zdCB7IG1peGlucywgZXh0ZW5kczogZXh0ZW5kc09wdGlvbnMgfSA9IGZyb207XG4gIGlmIChleHRlbmRzT3B0aW9ucykge1xuICAgIG1lcmdlT3B0aW9ucyh0bywgZXh0ZW5kc09wdGlvbnMsIHN0cmF0cywgdHJ1ZSk7XG4gIH1cbiAgaWYgKG1peGlucykge1xuICAgIG1peGlucy5mb3JFYWNoKFxuICAgICAgKG0pID0+IG1lcmdlT3B0aW9ucyh0bywgbSwgc3RyYXRzLCB0cnVlKVxuICAgICk7XG4gIH1cbiAgZm9yIChjb25zdCBrZXkgaW4gZnJvbSkge1xuICAgIGlmIChhc01peGluICYmIGtleSA9PT0gXCJleHBvc2VcIikge1xuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuJDEoXG4gICAgICAgIGBcImV4cG9zZVwiIG9wdGlvbiBpcyBpZ25vcmVkIHdoZW4gZGVjbGFyZWQgaW4gbWl4aW5zIG9yIGV4dGVuZHMuIEl0IHNob3VsZCBvbmx5IGJlIGRlY2xhcmVkIGluIHRoZSBiYXNlIGNvbXBvbmVudCBpdHNlbGYuYFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgc3RyYXQgPSBpbnRlcm5hbE9wdGlvbk1lcmdlU3RyYXRzW2tleV0gfHwgc3RyYXRzICYmIHN0cmF0c1trZXldO1xuICAgICAgdG9ba2V5XSA9IHN0cmF0ID8gc3RyYXQodG9ba2V5XSwgZnJvbVtrZXldKSA6IGZyb21ba2V5XTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRvO1xufVxuY29uc3QgaW50ZXJuYWxPcHRpb25NZXJnZVN0cmF0cyA9IHtcbiAgZGF0YTogbWVyZ2VEYXRhRm4sXG4gIHByb3BzOiBtZXJnZUVtaXRzT3JQcm9wc09wdGlvbnMsXG4gIGVtaXRzOiBtZXJnZUVtaXRzT3JQcm9wc09wdGlvbnMsXG4gIC8vIG9iamVjdHNcbiAgbWV0aG9kczogbWVyZ2VPYmplY3RPcHRpb25zLFxuICBjb21wdXRlZDogbWVyZ2VPYmplY3RPcHRpb25zLFxuICAvLyBsaWZlY3ljbGVcbiAgYmVmb3JlQ3JlYXRlOiBtZXJnZUFzQXJyYXksXG4gIGNyZWF0ZWQ6IG1lcmdlQXNBcnJheSxcbiAgYmVmb3JlTW91bnQ6IG1lcmdlQXNBcnJheSxcbiAgbW91bnRlZDogbWVyZ2VBc0FycmF5LFxuICBiZWZvcmVVcGRhdGU6IG1lcmdlQXNBcnJheSxcbiAgdXBkYXRlZDogbWVyZ2VBc0FycmF5LFxuICBiZWZvcmVEZXN0cm95OiBtZXJnZUFzQXJyYXksXG4gIGJlZm9yZVVubW91bnQ6IG1lcmdlQXNBcnJheSxcbiAgZGVzdHJveWVkOiBtZXJnZUFzQXJyYXksXG4gIHVubW91bnRlZDogbWVyZ2VBc0FycmF5LFxuICBhY3RpdmF0ZWQ6IG1lcmdlQXNBcnJheSxcbiAgZGVhY3RpdmF0ZWQ6IG1lcmdlQXNBcnJheSxcbiAgZXJyb3JDYXB0dXJlZDogbWVyZ2VBc0FycmF5LFxuICBzZXJ2ZXJQcmVmZXRjaDogbWVyZ2VBc0FycmF5LFxuICAvLyBhc3NldHNcbiAgY29tcG9uZW50czogbWVyZ2VPYmplY3RPcHRpb25zLFxuICBkaXJlY3RpdmVzOiBtZXJnZU9iamVjdE9wdGlvbnMsXG4gIC8vIHdhdGNoXG4gIHdhdGNoOiBtZXJnZVdhdGNoT3B0aW9ucyxcbiAgLy8gcHJvdmlkZSAvIGluamVjdFxuICBwcm92aWRlOiBtZXJnZURhdGFGbixcbiAgaW5qZWN0OiBtZXJnZUluamVjdFxufTtcbmZ1bmN0aW9uIG1lcmdlRGF0YUZuKHRvLCBmcm9tKSB7XG4gIGlmICghZnJvbSkge1xuICAgIHJldHVybiB0bztcbiAgfVxuICBpZiAoIXRvKSB7XG4gICAgcmV0dXJuIGZyb207XG4gIH1cbiAgcmV0dXJuIGZ1bmN0aW9uIG1lcmdlZERhdGFGbigpIHtcbiAgICByZXR1cm4gKGV4dGVuZCkoXG4gICAgICBpc0Z1bmN0aW9uKHRvKSA/IHRvLmNhbGwodGhpcywgdGhpcykgOiB0byxcbiAgICAgIGlzRnVuY3Rpb24oZnJvbSkgPyBmcm9tLmNhbGwodGhpcywgdGhpcykgOiBmcm9tXG4gICAgKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIG1lcmdlSW5qZWN0KHRvLCBmcm9tKSB7XG4gIHJldHVybiBtZXJnZU9iamVjdE9wdGlvbnMobm9ybWFsaXplSW5qZWN0KHRvKSwgbm9ybWFsaXplSW5qZWN0KGZyb20pKTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUluamVjdChyYXcpIHtcbiAgaWYgKGlzQXJyYXkocmF3KSkge1xuICAgIGNvbnN0IHJlcyA9IHt9O1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Lmxlbmd0aDsgaSsrKSB7XG4gICAgICByZXNbcmF3W2ldXSA9IHJhd1tpXTtcbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuICByZXR1cm4gcmF3O1xufVxuZnVuY3Rpb24gbWVyZ2VBc0FycmF5KHRvLCBmcm9tKSB7XG4gIHJldHVybiB0byA/IFsuLi5uZXcgU2V0KFtdLmNvbmNhdCh0bywgZnJvbSkpXSA6IGZyb207XG59XG5mdW5jdGlvbiBtZXJnZU9iamVjdE9wdGlvbnModG8sIGZyb20pIHtcbiAgcmV0dXJuIHRvID8gZXh0ZW5kKC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpLCB0bywgZnJvbSkgOiBmcm9tO1xufVxuZnVuY3Rpb24gbWVyZ2VFbWl0c09yUHJvcHNPcHRpb25zKHRvLCBmcm9tKSB7XG4gIGlmICh0bykge1xuICAgIGlmIChpc0FycmF5KHRvKSAmJiBpc0FycmF5KGZyb20pKSB7XG4gICAgICByZXR1cm4gWy4uLi8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFsuLi50bywgLi4uZnJvbV0pXTtcbiAgICB9XG4gICAgcmV0dXJuIGV4dGVuZChcbiAgICAgIC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpLFxuICAgICAgbm9ybWFsaXplUHJvcHNPckVtaXRzKHRvKSxcbiAgICAgIG5vcm1hbGl6ZVByb3BzT3JFbWl0cyhmcm9tICE9IG51bGwgPyBmcm9tIDoge30pXG4gICAgKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gZnJvbTtcbiAgfVxufVxuZnVuY3Rpb24gbWVyZ2VXYXRjaE9wdGlvbnModG8sIGZyb20pIHtcbiAgaWYgKCF0bykgcmV0dXJuIGZyb207XG4gIGlmICghZnJvbSkgcmV0dXJuIHRvO1xuICBjb25zdCBtZXJnZWQgPSBleHRlbmQoLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCksIHRvKTtcbiAgZm9yIChjb25zdCBrZXkgaW4gZnJvbSkge1xuICAgIG1lcmdlZFtrZXldID0gbWVyZ2VBc0FycmF5KHRvW2tleV0sIGZyb21ba2V5XSk7XG4gIH1cbiAgcmV0dXJuIG1lcmdlZDtcbn1cblxuZnVuY3Rpb24gY3JlYXRlQXBwQ29udGV4dCgpIHtcbiAgcmV0dXJuIHtcbiAgICBhcHA6IG51bGwsXG4gICAgY29uZmlnOiB7XG4gICAgICBpc05hdGl2ZVRhZzogTk8sXG4gICAgICBwZXJmb3JtYW5jZTogZmFsc2UsXG4gICAgICBnbG9iYWxQcm9wZXJ0aWVzOiB7fSxcbiAgICAgIG9wdGlvbk1lcmdlU3RyYXRlZ2llczoge30sXG4gICAgICBlcnJvckhhbmRsZXI6IHZvaWQgMCxcbiAgICAgIHdhcm5IYW5kbGVyOiB2b2lkIDAsXG4gICAgICBjb21waWxlck9wdGlvbnM6IHt9XG4gICAgfSxcbiAgICBtaXhpbnM6IFtdLFxuICAgIGNvbXBvbmVudHM6IHt9LFxuICAgIGRpcmVjdGl2ZXM6IHt9LFxuICAgIHByb3ZpZGVzOiAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKSxcbiAgICBvcHRpb25zQ2FjaGU6IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpLFxuICAgIHByb3BzQ2FjaGU6IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpLFxuICAgIGVtaXRzQ2FjaGU6IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpXG4gIH07XG59XG5sZXQgdWlkJDEgPSAwO1xuZnVuY3Rpb24gY3JlYXRlQXBwQVBJKHJlbmRlciwgaHlkcmF0ZSkge1xuICByZXR1cm4gZnVuY3Rpb24gY3JlYXRlQXBwKHJvb3RDb21wb25lbnQsIHJvb3RQcm9wcyA9IG51bGwpIHtcbiAgICBpZiAoIWlzRnVuY3Rpb24ocm9vdENvbXBvbmVudCkpIHtcbiAgICAgIHJvb3RDb21wb25lbnQgPSBleHRlbmQoe30sIHJvb3RDb21wb25lbnQpO1xuICAgIH1cbiAgICBpZiAocm9vdFByb3BzICE9IG51bGwgJiYgIWlzT2JqZWN0KHJvb3RQcm9wcykpIHtcbiAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgd2FybiQxKGByb290IHByb3BzIHBhc3NlZCB0byBhcHAubW91bnQoKSBtdXN0IGJlIGFuIG9iamVjdC5gKTtcbiAgICAgIHJvb3RQcm9wcyA9IG51bGw7XG4gICAgfVxuICAgIGNvbnN0IGNvbnRleHQgPSBjcmVhdGVBcHBDb250ZXh0KCk7XG4gICAgY29uc3QgaW5zdGFsbGVkUGx1Z2lucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha1NldCgpO1xuICAgIGNvbnN0IHBsdWdpbkNsZWFudXBGbnMgPSBbXTtcbiAgICBsZXQgaXNNb3VudGVkID0gZmFsc2U7XG4gICAgY29uc3QgYXBwID0gY29udGV4dC5hcHAgPSB7XG4gICAgICBfdWlkOiB1aWQkMSsrLFxuICAgICAgX2NvbXBvbmVudDogcm9vdENvbXBvbmVudCxcbiAgICAgIF9wcm9wczogcm9vdFByb3BzLFxuICAgICAgX2NvbnRhaW5lcjogbnVsbCxcbiAgICAgIF9jb250ZXh0OiBjb250ZXh0LFxuICAgICAgX2luc3RhbmNlOiBudWxsLFxuICAgICAgdmVyc2lvbixcbiAgICAgIGdldCBjb25maWcoKSB7XG4gICAgICAgIHJldHVybiBjb250ZXh0LmNvbmZpZztcbiAgICAgIH0sXG4gICAgICBzZXQgY29uZmlnKHYpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgYXBwLmNvbmZpZyBjYW5ub3QgYmUgcmVwbGFjZWQuIE1vZGlmeSBpbmRpdmlkdWFsIG9wdGlvbnMgaW5zdGVhZC5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHVzZShwbHVnaW4sIC4uLm9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGluc3RhbGxlZFBsdWdpbnMuaGFzKHBsdWdpbikpIHtcbiAgICAgICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShgUGx1Z2luIGhhcyBhbHJlYWR5IGJlZW4gYXBwbGllZCB0byB0YXJnZXQgYXBwLmApO1xuICAgICAgICB9IGVsc2UgaWYgKHBsdWdpbiAmJiBpc0Z1bmN0aW9uKHBsdWdpbi5pbnN0YWxsKSkge1xuICAgICAgICAgIGluc3RhbGxlZFBsdWdpbnMuYWRkKHBsdWdpbik7XG4gICAgICAgICAgcGx1Z2luLmluc3RhbGwoYXBwLCAuLi5vcHRpb25zKTtcbiAgICAgICAgfSBlbHNlIGlmIChpc0Z1bmN0aW9uKHBsdWdpbikpIHtcbiAgICAgICAgICBpbnN0YWxsZWRQbHVnaW5zLmFkZChwbHVnaW4pO1xuICAgICAgICAgIHBsdWdpbihhcHAsIC4uLm9wdGlvbnMpO1xuICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgQSBwbHVnaW4gbXVzdCBlaXRoZXIgYmUgYSBmdW5jdGlvbiBvciBhbiBvYmplY3Qgd2l0aCBhbiBcImluc3RhbGxcIiBmdW5jdGlvbi5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXBwO1xuICAgICAgfSxcbiAgICAgIG1peGluKG1peGluKSB7XG4gICAgICAgIGlmIChfX1ZVRV9PUFRJT05TX0FQSV9fKSB7XG4gICAgICAgICAgaWYgKCFjb250ZXh0Lm1peGlucy5pbmNsdWRlcyhtaXhpbikpIHtcbiAgICAgICAgICAgIGNvbnRleHQubWl4aW5zLnB1c2gobWl4aW4pO1xuICAgICAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgICBcIk1peGluIGhhcyBhbHJlYWR5IGJlZW4gYXBwbGllZCB0byB0YXJnZXQgYXBwXCIgKyAobWl4aW4ubmFtZSA/IGA6ICR7bWl4aW4ubmFtZX1gIDogXCJcIilcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB3YXJuJDEoXCJNaXhpbnMgYXJlIG9ubHkgYXZhaWxhYmxlIGluIGJ1aWxkcyBzdXBwb3J0aW5nIE9wdGlvbnMgQVBJXCIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhcHA7XG4gICAgICB9LFxuICAgICAgY29tcG9uZW50KG5hbWUsIGNvbXBvbmVudCkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHZhbGlkYXRlQ29tcG9uZW50TmFtZShuYW1lLCBjb250ZXh0LmNvbmZpZyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFjb21wb25lbnQpIHtcbiAgICAgICAgICByZXR1cm4gY29udGV4dC5jb21wb25lbnRzW25hbWVdO1xuICAgICAgICB9XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGNvbnRleHQuY29tcG9uZW50c1tuYW1lXSkge1xuICAgICAgICAgIHdhcm4kMShgQ29tcG9uZW50IFwiJHtuYW1lfVwiIGhhcyBhbHJlYWR5IGJlZW4gcmVnaXN0ZXJlZCBpbiB0YXJnZXQgYXBwLmApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQuY29tcG9uZW50c1tuYW1lXSA9IGNvbXBvbmVudDtcbiAgICAgICAgcmV0dXJuIGFwcDtcbiAgICAgIH0sXG4gICAgICBkaXJlY3RpdmUobmFtZSwgZGlyZWN0aXZlKSB7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgdmFsaWRhdGVEaXJlY3RpdmVOYW1lKG5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZGlyZWN0aXZlKSB7XG4gICAgICAgICAgcmV0dXJuIGNvbnRleHQuZGlyZWN0aXZlc1tuYW1lXTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjb250ZXh0LmRpcmVjdGl2ZXNbbmFtZV0pIHtcbiAgICAgICAgICB3YXJuJDEoYERpcmVjdGl2ZSBcIiR7bmFtZX1cIiBoYXMgYWxyZWFkeSBiZWVuIHJlZ2lzdGVyZWQgaW4gdGFyZ2V0IGFwcC5gKTtcbiAgICAgICAgfVxuICAgICAgICBjb250ZXh0LmRpcmVjdGl2ZXNbbmFtZV0gPSBkaXJlY3RpdmU7XG4gICAgICAgIHJldHVybiBhcHA7XG4gICAgICB9LFxuICAgICAgbW91bnQocm9vdENvbnRhaW5lciwgaXNIeWRyYXRlLCBuYW1lc3BhY2UpIHtcbiAgICAgICAgaWYgKCFpc01vdW50ZWQpIHtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiByb290Q29udGFpbmVyLl9fdnVlX2FwcF9fKSB7XG4gICAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICAgIGBUaGVyZSBpcyBhbHJlYWR5IGFuIGFwcCBpbnN0YW5jZSBtb3VudGVkIG9uIHRoZSBob3N0IGNvbnRhaW5lci5cbiBJZiB5b3Ugd2FudCB0byBtb3VudCBhbm90aGVyIGFwcCBvbiB0aGUgc2FtZSBob3N0IGNvbnRhaW5lciwgeW91IG5lZWQgdG8gdW5tb3VudCB0aGUgcHJldmlvdXMgYXBwIGJ5IGNhbGxpbmcgXFxgYXBwLnVubW91bnQoKVxcYCBmaXJzdC5gXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCB2bm9kZSA9IGFwcC5fY2VWTm9kZSB8fCBjcmVhdGVWTm9kZShyb290Q29tcG9uZW50LCByb290UHJvcHMpO1xuICAgICAgICAgIHZub2RlLmFwcENvbnRleHQgPSBjb250ZXh0O1xuICAgICAgICAgIGlmIChuYW1lc3BhY2UgPT09IHRydWUpIHtcbiAgICAgICAgICAgIG5hbWVzcGFjZSA9IFwic3ZnXCI7XG4gICAgICAgICAgfSBlbHNlIGlmIChuYW1lc3BhY2UgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICBuYW1lc3BhY2UgPSB2b2lkIDA7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgICBjb250ZXh0LnJlbG9hZCA9ICgpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgY2xvbmVkID0gY2xvbmVWTm9kZSh2bm9kZSk7XG4gICAgICAgICAgICAgIGNsb25lZC5lbCA9IG51bGw7XG4gICAgICAgICAgICAgIHJlbmRlcihjbG9uZWQsIHJvb3RDb250YWluZXIsIG5hbWVzcGFjZSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoaXNIeWRyYXRlICYmIGh5ZHJhdGUpIHtcbiAgICAgICAgICAgIGh5ZHJhdGUodm5vZGUsIHJvb3RDb250YWluZXIpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZW5kZXIodm5vZGUsIHJvb3RDb250YWluZXIsIG5hbWVzcGFjZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlzTW91bnRlZCA9IHRydWU7XG4gICAgICAgICAgYXBwLl9jb250YWluZXIgPSByb290Q29udGFpbmVyO1xuICAgICAgICAgIHJvb3RDb250YWluZXIuX192dWVfYXBwX18gPSBhcHA7XG4gICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICAgICAgICBhcHAuX2luc3RhbmNlID0gdm5vZGUuY29tcG9uZW50O1xuICAgICAgICAgICAgZGV2dG9vbHNJbml0QXBwKGFwcCwgdmVyc2lvbik7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBnZXRDb21wb25lbnRQdWJsaWNJbnN0YW5jZSh2bm9kZS5jb21wb25lbnQpO1xuICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgQXBwIGhhcyBhbHJlYWR5IGJlZW4gbW91bnRlZC5cbklmIHlvdSB3YW50IHRvIHJlbW91bnQgdGhlIHNhbWUgYXBwLCBtb3ZlIHlvdXIgYXBwIGNyZWF0aW9uIGxvZ2ljIGludG8gYSBmYWN0b3J5IGZ1bmN0aW9uIGFuZCBjcmVhdGUgZnJlc2ggYXBwIGluc3RhbmNlcyBmb3IgZWFjaCBtb3VudCAtIGUuZy4gXFxgY29uc3QgY3JlYXRlTXlBcHAgPSAoKSA9PiBjcmVhdGVBcHAoQXBwKVxcYGBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25Vbm1vdW50KGNsZWFudXBGbikge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB0eXBlb2YgY2xlYW51cEZuICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgRXhwZWN0ZWQgZnVuY3Rpb24gYXMgZmlyc3QgYXJndW1lbnQgdG8gYXBwLm9uVW5tb3VudCgpLCBidXQgZ290ICR7dHlwZW9mIGNsZWFudXBGbn1gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBwbHVnaW5DbGVhbnVwRm5zLnB1c2goY2xlYW51cEZuKTtcbiAgICAgIH0sXG4gICAgICB1bm1vdW50KCkge1xuICAgICAgICBpZiAoaXNNb3VudGVkKSB7XG4gICAgICAgICAgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoXG4gICAgICAgICAgICBwbHVnaW5DbGVhbnVwRm5zLFxuICAgICAgICAgICAgYXBwLl9pbnN0YW5jZSxcbiAgICAgICAgICAgIDE2XG4gICAgICAgICAgKTtcbiAgICAgICAgICByZW5kZXIobnVsbCwgYXBwLl9jb250YWluZXIpO1xuICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgICAgICAgYXBwLl9pbnN0YW5jZSA9IG51bGw7XG4gICAgICAgICAgICBkZXZ0b29sc1VubW91bnRBcHAoYXBwKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZGVsZXRlIGFwcC5fY29udGFpbmVyLl9fdnVlX2FwcF9fO1xuICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB3YXJuJDEoYENhbm5vdCB1bm1vdW50IGFuIGFwcCB0aGF0IGlzIG5vdCBtb3VudGVkLmApO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcHJvdmlkZShrZXksIHZhbHVlKSB7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGtleSBpbiBjb250ZXh0LnByb3ZpZGVzKSB7XG4gICAgICAgICAgaWYgKGhhc093bihjb250ZXh0LnByb3ZpZGVzLCBrZXkpKSB7XG4gICAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICAgIGBBcHAgYWxyZWFkeSBwcm92aWRlcyBwcm9wZXJ0eSB3aXRoIGtleSBcIiR7U3RyaW5nKGtleSl9XCIuIEl0IHdpbGwgYmUgb3ZlcndyaXR0ZW4gd2l0aCB0aGUgbmV3IHZhbHVlLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgICAgYEFwcCBhbHJlYWR5IHByb3ZpZGVzIHByb3BlcnR5IHdpdGgga2V5IFwiJHtTdHJpbmcoa2V5KX1cIiBpbmhlcml0ZWQgZnJvbSBpdHMgcGFyZW50IGVsZW1lbnQuIEl0IHdpbGwgYmUgb3ZlcndyaXR0ZW4gd2l0aCB0aGUgbmV3IHZhbHVlLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQucHJvdmlkZXNba2V5XSA9IHZhbHVlO1xuICAgICAgICByZXR1cm4gYXBwO1xuICAgICAgfSxcbiAgICAgIHJ1bldpdGhDb250ZXh0KGZuKSB7XG4gICAgICAgIGNvbnN0IGxhc3RBcHAgPSBjdXJyZW50QXBwO1xuICAgICAgICBjdXJyZW50QXBwID0gYXBwO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJldHVybiBmbigpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGN1cnJlbnRBcHAgPSBsYXN0QXBwO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gYXBwO1xuICB9O1xufVxubGV0IGN1cnJlbnRBcHAgPSBudWxsO1xuXG5mdW5jdGlvbiB1c2VNb2RlbChwcm9wcywgbmFtZSwgb3B0aW9ucyA9IEVNUFRZX09CSikge1xuICBjb25zdCBpID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFpKSB7XG4gICAgd2FybiQxKGB1c2VNb2RlbCgpIGNhbGxlZCB3aXRob3V0IGFjdGl2ZSBpbnN0YW5jZS5gKTtcbiAgICByZXR1cm4gcmVmKCk7XG4gIH1cbiAgY29uc3QgY2FtZWxpemVkTmFtZSA9IGNhbWVsaXplKG5hbWUpO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhaS5wcm9wc09wdGlvbnNbMF1bY2FtZWxpemVkTmFtZV0pIHtcbiAgICB3YXJuJDEoYHVzZU1vZGVsKCkgY2FsbGVkIHdpdGggcHJvcCBcIiR7bmFtZX1cIiB3aGljaCBpcyBub3QgZGVjbGFyZWQuYCk7XG4gICAgcmV0dXJuIHJlZigpO1xuICB9XG4gIGNvbnN0IGh5cGhlbmF0ZWROYW1lID0gaHlwaGVuYXRlKG5hbWUpO1xuICBjb25zdCBtb2RpZmllcnMgPSBnZXRNb2RlbE1vZGlmaWVycyhwcm9wcywgY2FtZWxpemVkTmFtZSk7XG4gIGNvbnN0IHJlcyA9IGN1c3RvbVJlZigodHJhY2ssIHRyaWdnZXIpID0+IHtcbiAgICBsZXQgbG9jYWxWYWx1ZTtcbiAgICBsZXQgcHJldlNldFZhbHVlID0gRU1QVFlfT0JKO1xuICAgIGxldCBwcmV2RW1pdHRlZFZhbHVlO1xuICAgIHdhdGNoU3luY0VmZmVjdCgoKSA9PiB7XG4gICAgICBjb25zdCBwcm9wVmFsdWUgPSBwcm9wc1tjYW1lbGl6ZWROYW1lXTtcbiAgICAgIGlmIChoYXNDaGFuZ2VkKGxvY2FsVmFsdWUsIHByb3BWYWx1ZSkpIHtcbiAgICAgICAgbG9jYWxWYWx1ZSA9IHByb3BWYWx1ZTtcbiAgICAgICAgdHJpZ2dlcigpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiB7XG4gICAgICBnZXQoKSB7XG4gICAgICAgIHRyYWNrKCk7XG4gICAgICAgIHJldHVybiBvcHRpb25zLmdldCA/IG9wdGlvbnMuZ2V0KGxvY2FsVmFsdWUpIDogbG9jYWxWYWx1ZTtcbiAgICAgIH0sXG4gICAgICBzZXQodmFsdWUpIHtcbiAgICAgICAgY29uc3QgZW1pdHRlZFZhbHVlID0gb3B0aW9ucy5zZXQgPyBvcHRpb25zLnNldCh2YWx1ZSkgOiB2YWx1ZTtcbiAgICAgICAgaWYgKCFoYXNDaGFuZ2VkKGVtaXR0ZWRWYWx1ZSwgbG9jYWxWYWx1ZSkgJiYgIShwcmV2U2V0VmFsdWUgIT09IEVNUFRZX09CSiAmJiBoYXNDaGFuZ2VkKHZhbHVlLCBwcmV2U2V0VmFsdWUpKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByYXdQcm9wcyA9IGkudm5vZGUucHJvcHM7XG4gICAgICAgIGNvbnN0IGhhc1ZNb2RlbCA9ICEhKHJhd1Byb3BzICYmIC8vIGNoZWNrIGlmIHBhcmVudCBoYXMgcGFzc2VkIHYtbW9kZWxcbiAgICAgICAgKG5hbWUgaW4gcmF3UHJvcHMgfHwgY2FtZWxpemVkTmFtZSBpbiByYXdQcm9wcyB8fCBoeXBoZW5hdGVkTmFtZSBpbiByYXdQcm9wcykgJiYgKGBvblVwZGF0ZToke25hbWV9YCBpbiByYXdQcm9wcyB8fCBgb25VcGRhdGU6JHtjYW1lbGl6ZWROYW1lfWAgaW4gcmF3UHJvcHMgfHwgYG9uVXBkYXRlOiR7aHlwaGVuYXRlZE5hbWV9YCBpbiByYXdQcm9wcykpO1xuICAgICAgICBpZiAoIWhhc1ZNb2RlbCkge1xuICAgICAgICAgIGxvY2FsVmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICB0cmlnZ2VyKCk7XG4gICAgICAgIH1cbiAgICAgICAgaS5lbWl0KGB1cGRhdGU6JHtuYW1lfWAsIGVtaXR0ZWRWYWx1ZSk7XG4gICAgICAgIGlmIChoYXNDaGFuZ2VkKHZhbHVlLCBwcmV2U2V0VmFsdWUpICYmIChoYXNDaGFuZ2VkKHZhbHVlLCBlbWl0dGVkVmFsdWUpICYmICFoYXNDaGFuZ2VkKGVtaXR0ZWRWYWx1ZSwgcHJldkVtaXR0ZWRWYWx1ZSkgfHwgLy8gIzEzNTI0OiBicm93c2VycyBkaWZmZXIgaW4gd2hlbiB0aGV5IGZsdXNoIG1pY3JvdGFza3MgYmV0d2VlblxuICAgICAgICAvLyBldmVudCBsaXN0ZW5lcnMuIElmIGEgdi1tb2RlbCBsaXN0ZW5lciBlbWl0cyBhbiBpbnRlcm1lZGlhdGUgdmFsdWVcbiAgICAgICAgLy8gYW5kIGEgZm9sbG93aW5nIGxpc3RlbmVyIHJlc3RvcmVzIHRoZSBtb2RlbCB0byBpdHMgcHJldmlvdXMgcHJvcFxuICAgICAgICAvLyB2YWx1ZSBiZWZvcmUgcGFyZW50IHVwZGF0ZXMgYXJlIGZsdXNoZWQsIHRoZSBwYXJlbnQgcmVuZGVyIGNhbiBiZVxuICAgICAgICAvLyBkZWR1cGVkIGFzIGhhdmluZyBubyBwcm9wIGNoYW5nZS4gRm9yY2UgYSBsb2NhbCB1cGRhdGUgc28gRE9NIHN0YXRlXG4gICAgICAgIC8vIHN1Y2ggYXMgYW4gaW5wdXQncyB2YWx1ZSBpcyBzeW5jaHJvbml6ZWQgYmFjayB0byB0aGUgY3VycmVudCBtb2RlbC5cbiAgICAgICAgaGFzVk1vZGVsICYmIHByZXZTZXRWYWx1ZSAhPT0gRU1QVFlfT0JKICYmICFoYXNDaGFuZ2VkKGVtaXR0ZWRWYWx1ZSwgbG9jYWxWYWx1ZSkpKSB7XG4gICAgICAgICAgdHJpZ2dlcigpO1xuICAgICAgICB9XG4gICAgICAgIHByZXZTZXRWYWx1ZSA9IHZhbHVlO1xuICAgICAgICBwcmV2RW1pdHRlZFZhbHVlID0gZW1pdHRlZFZhbHVlO1xuICAgICAgfVxuICAgIH07XG4gIH0pO1xuICByZXNbU3ltYm9sLml0ZXJhdG9yXSA9ICgpID0+IHtcbiAgICBsZXQgaTIgPSAwO1xuICAgIHJldHVybiB7XG4gICAgICBuZXh0KCkge1xuICAgICAgICBpZiAoaTIgPCAyKSB7XG4gICAgICAgICAgcmV0dXJuIHsgdmFsdWU6IGkyKysgPyBtb2RpZmllcnMgfHwgRU1QVFlfT0JKIDogcmVzLCBkb25lOiBmYWxzZSB9O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB7IGRvbmU6IHRydWUgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gIH07XG4gIHJldHVybiByZXM7XG59XG5jb25zdCBnZXRNb2RlbE1vZGlmaWVycyA9IChwcm9wcywgbW9kZWxOYW1lKSA9PiB7XG4gIHJldHVybiBtb2RlbE5hbWUgPT09IFwibW9kZWxWYWx1ZVwiIHx8IG1vZGVsTmFtZSA9PT0gXCJtb2RlbC12YWx1ZVwiID8gcHJvcHMubW9kZWxNb2RpZmllcnMgOiBwcm9wc1tgJHttb2RlbE5hbWV9TW9kaWZpZXJzYF0gfHwgcHJvcHNbYCR7Y2FtZWxpemUobW9kZWxOYW1lKX1Nb2RpZmllcnNgXSB8fCBwcm9wc1tgJHtoeXBoZW5hdGUobW9kZWxOYW1lKX1Nb2RpZmllcnNgXTtcbn07XG5cbmZ1bmN0aW9uIGVtaXQoaW5zdGFuY2UsIGV2ZW50LCAuLi5yYXdBcmdzKSB7XG4gIGlmIChpbnN0YW5jZS5pc1VubW91bnRlZCkgcmV0dXJuO1xuICBjb25zdCBwcm9wcyA9IGluc3RhbmNlLnZub2RlLnByb3BzIHx8IEVNUFRZX09CSjtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBjb25zdCB7XG4gICAgICBlbWl0c09wdGlvbnMsXG4gICAgICBwcm9wc09wdGlvbnM6IFtwcm9wc09wdGlvbnNdXG4gICAgfSA9IGluc3RhbmNlO1xuICAgIGlmIChlbWl0c09wdGlvbnMpIHtcbiAgICAgIGlmICghKGV2ZW50IGluIGVtaXRzT3B0aW9ucykgJiYgdHJ1ZSkge1xuICAgICAgICBpZiAoIXByb3BzT3B0aW9ucyB8fCAhKHRvSGFuZGxlcktleShjYW1lbGl6ZShldmVudCkpIGluIHByb3BzT3B0aW9ucykpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgQ29tcG9uZW50IGVtaXR0ZWQgZXZlbnQgXCIke2V2ZW50fVwiIGJ1dCBpdCBpcyBuZWl0aGVyIGRlY2xhcmVkIGluIHRoZSBlbWl0cyBvcHRpb24gbm9yIGFzIGFuIFwiJHt0b0hhbmRsZXJLZXkoY2FtZWxpemUoZXZlbnQpKX1cIiBwcm9wLmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCB2YWxpZGF0b3IgPSBlbWl0c09wdGlvbnNbZXZlbnRdO1xuICAgICAgICBpZiAoaXNGdW5jdGlvbih2YWxpZGF0b3IpKSB7XG4gICAgICAgICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRvciguLi5yYXdBcmdzKTtcbiAgICAgICAgICBpZiAoIWlzVmFsaWQpIHtcbiAgICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgICAgYEludmFsaWQgZXZlbnQgYXJndW1lbnRzOiBldmVudCB2YWxpZGF0aW9uIGZhaWxlZCBmb3IgZXZlbnQgXCIke2V2ZW50fVwiLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGxldCBhcmdzID0gcmF3QXJncztcbiAgY29uc3QgaXNNb2RlbExpc3RlbmVyID0gZXZlbnQuc3RhcnRzV2l0aChcInVwZGF0ZTpcIik7XG4gIGNvbnN0IG1vZGlmaWVycyA9IGlzTW9kZWxMaXN0ZW5lciAmJiBnZXRNb2RlbE1vZGlmaWVycyhwcm9wcywgZXZlbnQuc2xpY2UoNykpO1xuICBpZiAobW9kaWZpZXJzKSB7XG4gICAgaWYgKG1vZGlmaWVycy50cmltKSB7XG4gICAgICBhcmdzID0gcmF3QXJncy5tYXAoKGEpID0+IGlzU3RyaW5nKGEpID8gYS50cmltKCkgOiBhKTtcbiAgICB9XG4gICAgaWYgKG1vZGlmaWVycy5udW1iZXIpIHtcbiAgICAgIGFyZ3MgPSByYXdBcmdzLm1hcChsb29zZVRvTnVtYmVyKTtcbiAgICB9XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgZGV2dG9vbHNDb21wb25lbnRFbWl0KGluc3RhbmNlLCBldmVudCwgYXJncyk7XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBjb25zdCBsb3dlckNhc2VFdmVudCA9IGV2ZW50LnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKGxvd2VyQ2FzZUV2ZW50ICE9PSBldmVudCAmJiBwcm9wc1t0b0hhbmRsZXJLZXkobG93ZXJDYXNlRXZlbnQpXSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgRXZlbnQgXCIke2xvd2VyQ2FzZUV2ZW50fVwiIGlzIGVtaXR0ZWQgaW4gY29tcG9uZW50ICR7Zm9ybWF0Q29tcG9uZW50TmFtZShcbiAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICBpbnN0YW5jZS50eXBlXG4gICAgICAgICl9IGJ1dCB0aGUgaGFuZGxlciBpcyByZWdpc3RlcmVkIGZvciBcIiR7ZXZlbnR9XCIuIE5vdGUgdGhhdCBIVE1MIGF0dHJpYnV0ZXMgYXJlIGNhc2UtaW5zZW5zaXRpdmUgYW5kIHlvdSBjYW5ub3QgdXNlIHYtb24gdG8gbGlzdGVuIHRvIGNhbWVsQ2FzZSBldmVudHMgd2hlbiB1c2luZyBpbi1ET00gdGVtcGxhdGVzLiBZb3Ugc2hvdWxkIHByb2JhYmx5IHVzZSBcIiR7aHlwaGVuYXRlKFxuICAgICAgICAgIGV2ZW50XG4gICAgICAgICl9XCIgaW5zdGVhZCBvZiBcIiR7ZXZlbnR9XCIuYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgbGV0IGhhbmRsZXJOYW1lO1xuICBsZXQgaGFuZGxlciA9IHByb3BzW2hhbmRsZXJOYW1lID0gdG9IYW5kbGVyS2V5KGV2ZW50KV0gfHwgLy8gYWxzbyB0cnkgY2FtZWxDYXNlIGV2ZW50IGhhbmRsZXIgKCMyMjQ5KVxuICBwcm9wc1toYW5kbGVyTmFtZSA9IHRvSGFuZGxlcktleShjYW1lbGl6ZShldmVudCkpXTtcbiAgaWYgKCFoYW5kbGVyICYmIGlzTW9kZWxMaXN0ZW5lcikge1xuICAgIGhhbmRsZXIgPSBwcm9wc1toYW5kbGVyTmFtZSA9IHRvSGFuZGxlcktleShoeXBoZW5hdGUoZXZlbnQpKV07XG4gIH1cbiAgaWYgKGhhbmRsZXIpIHtcbiAgICBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZyhcbiAgICAgIGhhbmRsZXIsXG4gICAgICBpbnN0YW5jZSxcbiAgICAgIDYsXG4gICAgICBhcmdzXG4gICAgKTtcbiAgfVxuICBjb25zdCBvbmNlSGFuZGxlciA9IHByb3BzW2hhbmRsZXJOYW1lICsgYE9uY2VgXTtcbiAgaWYgKG9uY2VIYW5kbGVyKSB7XG4gICAgaWYgKCFpbnN0YW5jZS5lbWl0dGVkKSB7XG4gICAgICBpbnN0YW5jZS5lbWl0dGVkID0ge307XG4gICAgfSBlbHNlIGlmIChpbnN0YW5jZS5lbWl0dGVkW2hhbmRsZXJOYW1lXSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpbnN0YW5jZS5lbWl0dGVkW2hhbmRsZXJOYW1lXSA9IHRydWU7XG4gICAgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoXG4gICAgICBvbmNlSGFuZGxlcixcbiAgICAgIGluc3RhbmNlLFxuICAgICAgNixcbiAgICAgIGFyZ3NcbiAgICApO1xuICB9XG59XG5jb25zdCBtaXhpbkVtaXRzQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZUVtaXRzT3B0aW9ucyhjb21wLCBhcHBDb250ZXh0LCBhc01peGluID0gZmFsc2UpIHtcbiAgY29uc3QgY2FjaGUgPSBfX1ZVRV9PUFRJT05TX0FQSV9fICYmIGFzTWl4aW4gPyBtaXhpbkVtaXRzQ2FjaGUgOiBhcHBDb250ZXh0LmVtaXRzQ2FjaGU7XG4gIGNvbnN0IGNhY2hlZCA9IGNhY2hlLmdldChjb21wKTtcbiAgaWYgKGNhY2hlZCAhPT0gdm9pZCAwKSB7XG4gICAgcmV0dXJuIGNhY2hlZDtcbiAgfVxuICBjb25zdCByYXcgPSBjb21wLmVtaXRzO1xuICBsZXQgbm9ybWFsaXplZCA9IHt9O1xuICBsZXQgaGFzRXh0ZW5kcyA9IGZhbHNlO1xuICBpZiAoX19WVUVfT1BUSU9OU19BUElfXyAmJiAhaXNGdW5jdGlvbihjb21wKSkge1xuICAgIGNvbnN0IGV4dGVuZEVtaXRzID0gKHJhdzIpID0+IHtcbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWRGcm9tRXh0ZW5kID0gbm9ybWFsaXplRW1pdHNPcHRpb25zKHJhdzIsIGFwcENvbnRleHQsIHRydWUpO1xuICAgICAgaWYgKG5vcm1hbGl6ZWRGcm9tRXh0ZW5kKSB7XG4gICAgICAgIGhhc0V4dGVuZHMgPSB0cnVlO1xuICAgICAgICBleHRlbmQobm9ybWFsaXplZCwgbm9ybWFsaXplZEZyb21FeHRlbmQpO1xuICAgICAgfVxuICAgIH07XG4gICAgaWYgKCFhc01peGluICYmIGFwcENvbnRleHQubWl4aW5zLmxlbmd0aCkge1xuICAgICAgYXBwQ29udGV4dC5taXhpbnMuZm9yRWFjaChleHRlbmRFbWl0cyk7XG4gICAgfVxuICAgIGlmIChjb21wLmV4dGVuZHMpIHtcbiAgICAgIGV4dGVuZEVtaXRzKGNvbXAuZXh0ZW5kcyk7XG4gICAgfVxuICAgIGlmIChjb21wLm1peGlucykge1xuICAgICAgY29tcC5taXhpbnMuZm9yRWFjaChleHRlbmRFbWl0cyk7XG4gICAgfVxuICB9XG4gIGlmICghcmF3ICYmICFoYXNFeHRlbmRzKSB7XG4gICAgaWYgKGlzT2JqZWN0KGNvbXApKSB7XG4gICAgICBjYWNoZS5zZXQoY29tcCwgbnVsbCk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmIChpc0FycmF5KHJhdykpIHtcbiAgICByYXcuZm9yRWFjaCgoa2V5KSA9PiBub3JtYWxpemVkW2tleV0gPSBudWxsKTtcbiAgfSBlbHNlIHtcbiAgICBleHRlbmQobm9ybWFsaXplZCwgcmF3KTtcbiAgfVxuICBpZiAoaXNPYmplY3QoY29tcCkpIHtcbiAgICBjYWNoZS5zZXQoY29tcCwgbm9ybWFsaXplZCk7XG4gIH1cbiAgcmV0dXJuIG5vcm1hbGl6ZWQ7XG59XG5mdW5jdGlvbiBpc0VtaXRMaXN0ZW5lcihvcHRpb25zLCBrZXkpIHtcbiAgaWYgKCFvcHRpb25zIHx8ICFpc09uKGtleSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAga2V5ID0ga2V5LnNsaWNlKDIpO1xuICBrZXkgPSBrZXkgPT09IFwiT25jZVwiID8ga2V5IDoga2V5LnJlcGxhY2UoL09uY2UkLywgXCJcIik7XG4gIHJldHVybiBoYXNPd24ob3B0aW9ucywga2V5WzBdLnRvTG93ZXJDYXNlKCkgKyBrZXkuc2xpY2UoMSkpIHx8IGhhc093bihvcHRpb25zLCBoeXBoZW5hdGUoa2V5KSkgfHwgaGFzT3duKG9wdGlvbnMsIGtleSk7XG59XG5cbmxldCBhY2Nlc3NlZEF0dHJzID0gZmFsc2U7XG5mdW5jdGlvbiBtYXJrQXR0cnNBY2Nlc3NlZCgpIHtcbiAgYWNjZXNzZWRBdHRycyA9IHRydWU7XG59XG5mdW5jdGlvbiByZW5kZXJDb21wb25lbnRSb290KGluc3RhbmNlKSB7XG4gIGNvbnN0IHtcbiAgICB0eXBlOiBDb21wb25lbnQsXG4gICAgdm5vZGUsXG4gICAgcHJveHksXG4gICAgd2l0aFByb3h5LFxuICAgIHByb3BzT3B0aW9uczogW3Byb3BzT3B0aW9uc10sXG4gICAgc2xvdHMsXG4gICAgYXR0cnMsXG4gICAgZW1pdCxcbiAgICByZW5kZXIsXG4gICAgcmVuZGVyQ2FjaGUsXG4gICAgcHJvcHMsXG4gICAgZGF0YSxcbiAgICBzZXR1cFN0YXRlLFxuICAgIGN0eCxcbiAgICBpbmhlcml0QXR0cnNcbiAgfSA9IGluc3RhbmNlO1xuICBjb25zdCBwcmV2ID0gc2V0Q3VycmVudFJlbmRlcmluZ0luc3RhbmNlKGluc3RhbmNlKTtcbiAgbGV0IHJlc3VsdDtcbiAgbGV0IGZhbGx0aHJvdWdoQXR0cnM7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgYWNjZXNzZWRBdHRycyA9IGZhbHNlO1xuICB9XG4gIHRyeSB7XG4gICAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDQpIHtcbiAgICAgIGNvbnN0IHByb3h5VG9Vc2UgPSB3aXRoUHJveHkgfHwgcHJveHk7XG4gICAgICBjb25zdCB0aGlzUHJveHkgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHNldHVwU3RhdGUuX19pc1NjcmlwdFNldHVwID8gbmV3IFByb3h5KHByb3h5VG9Vc2UsIHtcbiAgICAgICAgZ2V0KHRhcmdldCwga2V5LCByZWNlaXZlcikge1xuICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgIGBQcm9wZXJ0eSAnJHtTdHJpbmcoXG4gICAgICAgICAgICAgIGtleVxuICAgICAgICAgICAgKX0nIHdhcyBhY2Nlc3NlZCB2aWEgJ3RoaXMnLiBBdm9pZCB1c2luZyAndGhpcycgaW4gdGVtcGxhdGVzLmBcbiAgICAgICAgICApO1xuICAgICAgICAgIHJldHVybiBSZWZsZWN0LmdldCh0YXJnZXQsIGtleSwgcmVjZWl2ZXIpO1xuICAgICAgICB9XG4gICAgICB9KSA6IHByb3h5VG9Vc2U7XG4gICAgICByZXN1bHQgPSBub3JtYWxpemVWTm9kZShcbiAgICAgICAgcmVuZGVyLmNhbGwoXG4gICAgICAgICAgdGhpc1Byb3h5LFxuICAgICAgICAgIHByb3h5VG9Vc2UsXG4gICAgICAgICAgcmVuZGVyQ2FjaGUsXG4gICAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShwcm9wcykgOiBwcm9wcyxcbiAgICAgICAgICBzZXR1cFN0YXRlLFxuICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgY3R4XG4gICAgICAgIClcbiAgICAgICk7XG4gICAgICBmYWxsdGhyb3VnaEF0dHJzID0gYXR0cnM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHJlbmRlcjIgPSBDb21wb25lbnQ7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBhdHRycyA9PT0gcHJvcHMpIHtcbiAgICAgICAgbWFya0F0dHJzQWNjZXNzZWQoKTtcbiAgICAgIH1cbiAgICAgIHJlc3VsdCA9IG5vcm1hbGl6ZVZOb2RlKFxuICAgICAgICByZW5kZXIyLmxlbmd0aCA+IDEgPyByZW5kZXIyKFxuICAgICAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzaGFsbG93UmVhZG9ubHkocHJvcHMpIDogcHJvcHMsXG4gICAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHtcbiAgICAgICAgICAgIGdldCBhdHRycygpIHtcbiAgICAgICAgICAgICAgbWFya0F0dHJzQWNjZXNzZWQoKTtcbiAgICAgICAgICAgICAgcmV0dXJuIHNoYWxsb3dSZWFkb25seShhdHRycyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2xvdHMsXG4gICAgICAgICAgICBlbWl0XG4gICAgICAgICAgfSA6IHsgYXR0cnMsIHNsb3RzLCBlbWl0IH1cbiAgICAgICAgKSA6IHJlbmRlcjIoXG4gICAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShwcm9wcykgOiBwcm9wcyxcbiAgICAgICAgICBudWxsXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgICBmYWxsdGhyb3VnaEF0dHJzID0gQ29tcG9uZW50LnByb3BzID8gYXR0cnMgOiBnZXRGdW5jdGlvbmFsRmFsbHRocm91Z2goYXR0cnMpO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYmxvY2tTdGFjay5sZW5ndGggPSAwO1xuICAgIGhhbmRsZUVycm9yKGVyciwgaW5zdGFuY2UsIDEpO1xuICAgIHJlc3VsdCA9IGNyZWF0ZVZOb2RlKENvbW1lbnQpO1xuICB9XG4gIGxldCByb290ID0gcmVzdWx0O1xuICBsZXQgc2V0Um9vdCA9IHZvaWQgMDtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgcmVzdWx0LnBhdGNoRmxhZyA+IDAgJiYgcmVzdWx0LnBhdGNoRmxhZyAmIDIwNDgpIHtcbiAgICBbcm9vdCwgc2V0Um9vdF0gPSBnZXRDaGlsZFJvb3QocmVzdWx0KTtcbiAgfVxuICBpZiAoZmFsbHRocm91Z2hBdHRycyAmJiBpbmhlcml0QXR0cnMgIT09IGZhbHNlKSB7XG4gICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGZhbGx0aHJvdWdoQXR0cnMpO1xuICAgIGNvbnN0IHsgc2hhcGVGbGFnIH0gPSByb290O1xuICAgIGlmIChrZXlzLmxlbmd0aCkge1xuICAgICAgaWYgKHNoYXBlRmxhZyAmICgxIHwgNikpIHtcbiAgICAgICAgaWYgKHByb3BzT3B0aW9ucyAmJiBrZXlzLnNvbWUoaXNNb2RlbExpc3RlbmVyKSkge1xuICAgICAgICAgIGZhbGx0aHJvdWdoQXR0cnMgPSBmaWx0ZXJNb2RlbExpc3RlbmVycyhcbiAgICAgICAgICAgIGZhbGx0aHJvdWdoQXR0cnMsXG4gICAgICAgICAgICBwcm9wc09wdGlvbnNcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJvb3QgPSBjbG9uZVZOb2RlKHJvb3QsIGZhbGx0aHJvdWdoQXR0cnMsIGZhbHNlLCB0cnVlKTtcbiAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhYWNjZXNzZWRBdHRycyAmJiByb290LnR5cGUgIT09IENvbW1lbnQpIHtcbiAgICAgICAgY29uc3QgYWxsQXR0cnMgPSBPYmplY3Qua2V5cyhhdHRycyk7XG4gICAgICAgIGNvbnN0IGV2ZW50QXR0cnMgPSBbXTtcbiAgICAgICAgY29uc3QgZXh0cmFBdHRycyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbCA9IGFsbEF0dHJzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGtleSA9IGFsbEF0dHJzW2ldO1xuICAgICAgICAgIGlmIChpc09uKGtleSkpIHtcbiAgICAgICAgICAgIGlmICghaXNNb2RlbExpc3RlbmVyKGtleSkpIHtcbiAgICAgICAgICAgICAgZXZlbnRBdHRycy5wdXNoKGtleVsyXS50b0xvd2VyQ2FzZSgpICsga2V5LnNsaWNlKDMpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZXh0cmFBdHRycy5wdXNoKGtleSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChleHRyYUF0dHJzLmxlbmd0aCkge1xuICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgIGBFeHRyYW5lb3VzIG5vbi1wcm9wcyBhdHRyaWJ1dGVzICgke2V4dHJhQXR0cnMuam9pbihcIiwgXCIpfSkgd2VyZSBwYXNzZWQgdG8gY29tcG9uZW50IGJ1dCBjb3VsZCBub3QgYmUgYXV0b21hdGljYWxseSBpbmhlcml0ZWQgYmVjYXVzZSBjb21wb25lbnQgcmVuZGVycyBmcmFnbWVudCBvciB0ZXh0IG9yIHRlbGVwb3J0IHJvb3Qgbm9kZXMuYFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV2ZW50QXR0cnMubGVuZ3RoKSB7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYEV4dHJhbmVvdXMgbm9uLWVtaXRzIGV2ZW50IGxpc3RlbmVycyAoJHtldmVudEF0dHJzLmpvaW4oXCIsIFwiKX0pIHdlcmUgcGFzc2VkIHRvIGNvbXBvbmVudCBidXQgY291bGQgbm90IGJlIGF1dG9tYXRpY2FsbHkgaW5oZXJpdGVkIGJlY2F1c2UgY29tcG9uZW50IHJlbmRlcnMgZnJhZ21lbnQgb3IgdGV4dCByb290IG5vZGVzLiBJZiB0aGUgbGlzdGVuZXIgaXMgaW50ZW5kZWQgdG8gYmUgYSBjb21wb25lbnQgY3VzdG9tIGV2ZW50IGxpc3RlbmVyIG9ubHksIGRlY2xhcmUgaXQgdXNpbmcgdGhlIFwiZW1pdHNcIiBvcHRpb24uYFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKHZub2RlLmRpcnMpIHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhaXNFbGVtZW50Um9vdChyb290KSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgUnVudGltZSBkaXJlY3RpdmUgdXNlZCBvbiBjb21wb25lbnQgd2l0aCBub24tZWxlbWVudCByb290IG5vZGUuIFRoZSBkaXJlY3RpdmVzIHdpbGwgbm90IGZ1bmN0aW9uIGFzIGludGVuZGVkLmBcbiAgICAgICk7XG4gICAgfVxuICAgIHJvb3QgPSBjbG9uZVZOb2RlKHJvb3QsIG51bGwsIGZhbHNlLCB0cnVlKTtcbiAgICByb290LmRpcnMgPSByb290LmRpcnMgPyByb290LmRpcnMuY29uY2F0KHZub2RlLmRpcnMpIDogdm5vZGUuZGlycztcbiAgfVxuICBpZiAodm5vZGUudHJhbnNpdGlvbikge1xuICAgIGNvbnN0IGNoaWxkID0gaXNUZWxlcG9ydChyb290LnR5cGUpID8gZ2V0SW5uZXJDaGlsZCQxKHJvb3QpIHx8IHJvb3QgOiByb290O1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFpc0VsZW1lbnRSb290KGNoaWxkKSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgQ29tcG9uZW50IGluc2lkZSA8VHJhbnNpdGlvbj4gcmVuZGVycyBub24tZWxlbWVudCByb290IG5vZGUgdGhhdCBjYW5ub3QgYmUgYW5pbWF0ZWQuYFxuICAgICAgKTtcbiAgICB9XG4gICAgc2V0VHJhbnNpdGlvbkhvb2tzKGNoaWxkLCB2bm9kZS50cmFuc2l0aW9uKTtcbiAgfVxuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBzZXRSb290KSB7XG4gICAgc2V0Um9vdChyb290KTtcbiAgfSBlbHNlIHtcbiAgICByZXN1bHQgPSByb290O1xuICB9XG4gIHNldEN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZShwcmV2KTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmNvbnN0IGdldENoaWxkUm9vdCA9ICh2bm9kZSkgPT4ge1xuICBjb25zdCByYXdDaGlsZHJlbiA9IHZub2RlLmNoaWxkcmVuO1xuICBjb25zdCBkeW5hbWljQ2hpbGRyZW4gPSB2bm9kZS5keW5hbWljQ2hpbGRyZW47XG4gIGNvbnN0IGNoaWxkUm9vdCA9IGZpbHRlclNpbmdsZVJvb3QocmF3Q2hpbGRyZW4sIGZhbHNlKTtcbiAgaWYgKCFjaGlsZFJvb3QpIHtcbiAgICByZXR1cm4gW3Zub2RlLCB2b2lkIDBdO1xuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgY2hpbGRSb290LnBhdGNoRmxhZyA+IDAgJiYgY2hpbGRSb290LnBhdGNoRmxhZyAmIDIwNDgpIHtcbiAgICByZXR1cm4gZ2V0Q2hpbGRSb290KGNoaWxkUm9vdCk7XG4gIH1cbiAgY29uc3QgaW5kZXggPSByYXdDaGlsZHJlbi5pbmRleE9mKGNoaWxkUm9vdCk7XG4gIGNvbnN0IGR5bmFtaWNJbmRleCA9IGR5bmFtaWNDaGlsZHJlbiA/IGR5bmFtaWNDaGlsZHJlbi5pbmRleE9mKGNoaWxkUm9vdCkgOiAtMTtcbiAgY29uc3Qgc2V0Um9vdCA9ICh1cGRhdGVkUm9vdCkgPT4ge1xuICAgIHJhd0NoaWxkcmVuW2luZGV4XSA9IHVwZGF0ZWRSb290O1xuICAgIGlmIChkeW5hbWljQ2hpbGRyZW4pIHtcbiAgICAgIGlmIChkeW5hbWljSW5kZXggPiAtMSkge1xuICAgICAgICBkeW5hbWljQ2hpbGRyZW5bZHluYW1pY0luZGV4XSA9IHVwZGF0ZWRSb290O1xuICAgICAgfSBlbHNlIGlmICh1cGRhdGVkUm9vdC5wYXRjaEZsYWcgPiAwKSB7XG4gICAgICAgIHZub2RlLmR5bmFtaWNDaGlsZHJlbiA9IFsuLi5keW5hbWljQ2hpbGRyZW4sIHVwZGF0ZWRSb290XTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHJldHVybiBbbm9ybWFsaXplVk5vZGUoY2hpbGRSb290KSwgc2V0Um9vdF07XG59O1xuZnVuY3Rpb24gZmlsdGVyU2luZ2xlUm9vdChjaGlsZHJlbiwgcmVjdXJzZSA9IHRydWUpIHtcbiAgbGV0IHNpbmdsZVJvb3Q7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjaGlsZCA9IGNoaWxkcmVuW2ldO1xuICAgIGlmIChpc1ZOb2RlKGNoaWxkKSkge1xuICAgICAgaWYgKGNoaWxkLnR5cGUgIT09IENvbW1lbnQgfHwgY2hpbGQuY2hpbGRyZW4gPT09IFwidi1pZlwiKSB7XG4gICAgICAgIGlmIChzaW5nbGVSb290KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNpbmdsZVJvb3QgPSBjaGlsZDtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiByZWN1cnNlICYmIHNpbmdsZVJvb3QucGF0Y2hGbGFnID4gMCAmJiBzaW5nbGVSb290LnBhdGNoRmxhZyAmIDIwNDgpIHtcbiAgICAgICAgICAgIHJldHVybiBmaWx0ZXJTaW5nbGVSb290KHNpbmdsZVJvb3QuY2hpbGRyZW4pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICB9XG4gIHJldHVybiBzaW5nbGVSb290O1xufVxuY29uc3QgZ2V0RnVuY3Rpb25hbEZhbGx0aHJvdWdoID0gKGF0dHJzKSA9PiB7XG4gIGxldCByZXM7XG4gIGZvciAoY29uc3Qga2V5IGluIGF0dHJzKSB7XG4gICAgaWYgKGtleSA9PT0gXCJjbGFzc1wiIHx8IGtleSA9PT0gXCJzdHlsZVwiIHx8IGlzT24oa2V5KSkge1xuICAgICAgKHJlcyB8fCAocmVzID0ge30pKVtrZXldID0gYXR0cnNba2V5XTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlcztcbn07XG5jb25zdCBmaWx0ZXJNb2RlbExpc3RlbmVycyA9IChhdHRycywgcHJvcHMpID0+IHtcbiAgY29uc3QgcmVzID0ge307XG4gIGZvciAoY29uc3Qga2V5IGluIGF0dHJzKSB7XG4gICAgaWYgKCFpc01vZGVsTGlzdGVuZXIoa2V5KSB8fCAhKGtleS5zbGljZSg5KSBpbiBwcm9wcykpIHtcbiAgICAgIHJlc1trZXldID0gYXR0cnNba2V5XTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlcztcbn07XG5jb25zdCBpc0VsZW1lbnRSb290ID0gKHZub2RlKSA9PiB7XG4gIHJldHVybiB2bm9kZS5zaGFwZUZsYWcgJiAoNiB8IDEpIHx8IHZub2RlLnR5cGUgPT09IENvbW1lbnQ7XG59O1xuZnVuY3Rpb24gc2hvdWxkVXBkYXRlQ29tcG9uZW50KHByZXZWTm9kZSwgbmV4dFZOb2RlLCBvcHRpbWl6ZWQpIHtcbiAgY29uc3QgeyBwcm9wczogcHJldlByb3BzLCBjaGlsZHJlbjogcHJldkNoaWxkcmVuLCBjb21wb25lbnQgfSA9IHByZXZWTm9kZTtcbiAgY29uc3QgeyBwcm9wczogbmV4dFByb3BzLCBjaGlsZHJlbjogbmV4dENoaWxkcmVuLCBwYXRjaEZsYWcgfSA9IG5leHRWTm9kZTtcbiAgY29uc3QgZW1pdHMgPSBjb21wb25lbnQuZW1pdHNPcHRpb25zO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAocHJldkNoaWxkcmVuIHx8IG5leHRDaGlsZHJlbikgJiYgaXNIbXJVcGRhdGluZykge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChuZXh0Vk5vZGUuZGlycyB8fCBuZXh0Vk5vZGUudHJhbnNpdGlvbikge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChvcHRpbWl6ZWQgJiYgcGF0Y2hGbGFnID49IDApIHtcbiAgICBpZiAocGF0Y2hGbGFnICYgMTAyNCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChwYXRjaEZsYWcgJiAxNikge1xuICAgICAgaWYgKCFwcmV2UHJvcHMpIHtcbiAgICAgICAgcmV0dXJuICEhbmV4dFByb3BzO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGhhc1Byb3BzQ2hhbmdlZChwcmV2UHJvcHMsIG5leHRQcm9wcywgZW1pdHMpO1xuICAgIH0gZWxzZSBpZiAocGF0Y2hGbGFnICYgOCkge1xuICAgICAgY29uc3QgZHluYW1pY1Byb3BzID0gbmV4dFZOb2RlLmR5bmFtaWNQcm9wcztcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZHluYW1pY1Byb3BzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IGR5bmFtaWNQcm9wc1tpXTtcbiAgICAgICAgaWYgKGhhc1Byb3BWYWx1ZUNoYW5nZWQobmV4dFByb3BzLCBwcmV2UHJvcHMsIGtleSkgJiYgIWlzRW1pdExpc3RlbmVyKGVtaXRzLCBrZXkpKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKHByZXZDaGlsZHJlbiB8fCBuZXh0Q2hpbGRyZW4pIHtcbiAgICAgIGlmICghbmV4dENoaWxkcmVuIHx8ICFuZXh0Q2hpbGRyZW4uJHN0YWJsZSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHByZXZQcm9wcyA9PT0gbmV4dFByb3BzKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICghcHJldlByb3BzKSB7XG4gICAgICByZXR1cm4gISFuZXh0UHJvcHM7XG4gICAgfVxuICAgIGlmICghbmV4dFByb3BzKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGhhc1Byb3BzQ2hhbmdlZChwcmV2UHJvcHMsIG5leHRQcm9wcywgZW1pdHMpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGhhc1Byb3BzQ2hhbmdlZChwcmV2UHJvcHMsIG5leHRQcm9wcywgZW1pdHNPcHRpb25zKSB7XG4gIGNvbnN0IG5leHRLZXlzID0gT2JqZWN0LmtleXMobmV4dFByb3BzKTtcbiAgaWYgKG5leHRLZXlzLmxlbmd0aCAhPT0gT2JqZWN0LmtleXMocHJldlByb3BzKS5sZW5ndGgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IG5leHRLZXlzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3Qga2V5ID0gbmV4dEtleXNbaV07XG4gICAgaWYgKGhhc1Byb3BWYWx1ZUNoYW5nZWQobmV4dFByb3BzLCBwcmV2UHJvcHMsIGtleSkgJiYgIWlzRW1pdExpc3RlbmVyKGVtaXRzT3B0aW9ucywga2V5KSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGhhc1Byb3BWYWx1ZUNoYW5nZWQobmV4dFByb3BzLCBwcmV2UHJvcHMsIGtleSkge1xuICBjb25zdCBuZXh0UHJvcCA9IG5leHRQcm9wc1trZXldO1xuICBjb25zdCBwcmV2UHJvcCA9IHByZXZQcm9wc1trZXldO1xuICBpZiAoa2V5ID09PSBcInN0eWxlXCIgJiYgaXNPYmplY3QobmV4dFByb3ApICYmIGlzT2JqZWN0KHByZXZQcm9wKSkge1xuICAgIHJldHVybiAhbG9vc2VFcXVhbChuZXh0UHJvcCwgcHJldlByb3ApO1xuICB9XG4gIHJldHVybiBuZXh0UHJvcCAhPT0gcHJldlByb3A7XG59XG5mdW5jdGlvbiB1cGRhdGVIT0NIb3N0RWwoeyB2bm9kZSwgcGFyZW50LCBzdXNwZW5zZSB9LCBlbCkge1xuICB3aGlsZSAocGFyZW50KSB7XG4gICAgY29uc3Qgcm9vdCA9IHBhcmVudC5zdWJUcmVlO1xuICAgIGlmIChyb290LnN1c3BlbnNlICYmIHJvb3Quc3VzcGVuc2UuYWN0aXZlQnJhbmNoID09PSB2bm9kZSkge1xuICAgICAgcm9vdC5zdXNwZW5zZS52bm9kZS5lbCA9IHJvb3QuZWwgPSBlbDtcbiAgICAgIHZub2RlID0gcm9vdDtcbiAgICB9XG4gICAgaWYgKHJvb3QgPT09IHZub2RlKSB7XG4gICAgICAodm5vZGUgPSBwYXJlbnQudm5vZGUpLmVsID0gZWw7XG4gICAgICBwYXJlbnQgPSBwYXJlbnQucGFyZW50O1xuICAgIH0gZWxzZSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgaWYgKHN1c3BlbnNlICYmIHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCA9PT0gdm5vZGUpIHtcbiAgICBzdXNwZW5zZS52bm9kZS5lbCA9IGVsO1xuICB9XG59XG5cbmNvbnN0IGludGVybmFsT2JqZWN0UHJvdG8gPSB7fTtcbmNvbnN0IGNyZWF0ZUludGVybmFsT2JqZWN0ID0gKCkgPT4gT2JqZWN0LmNyZWF0ZShpbnRlcm5hbE9iamVjdFByb3RvKTtcbmNvbnN0IGlzSW50ZXJuYWxPYmplY3QgPSAob2JqKSA9PiBPYmplY3QuZ2V0UHJvdG90eXBlT2Yob2JqKSA9PT0gaW50ZXJuYWxPYmplY3RQcm90bztcblxuZnVuY3Rpb24gaW5pdFByb3BzKGluc3RhbmNlLCByYXdQcm9wcywgaXNTdGF0ZWZ1bCwgaXNTU1IgPSBmYWxzZSkge1xuICBjb25zdCBwcm9wcyA9IHt9O1xuICBjb25zdCBhdHRycyA9IGNyZWF0ZUludGVybmFsT2JqZWN0KCk7XG4gIGluc3RhbmNlLnByb3BzRGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgc2V0RnVsbFByb3BzKGluc3RhbmNlLCByYXdQcm9wcywgcHJvcHMsIGF0dHJzKTtcbiAgZm9yIChjb25zdCBrZXkgaW4gaW5zdGFuY2UucHJvcHNPcHRpb25zWzBdKSB7XG4gICAgaWYgKCEoa2V5IGluIHByb3BzKSkge1xuICAgICAgcHJvcHNba2V5XSA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB2YWxpZGF0ZVByb3BzKHJhd1Byb3BzIHx8IHt9LCBwcm9wcywgaW5zdGFuY2UpO1xuICB9XG4gIGlmIChpc1N0YXRlZnVsKSB7XG4gICAgaW5zdGFuY2UucHJvcHMgPSBpc1NTUiA/IHByb3BzIDogc2hhbGxvd1JlYWN0aXZlKHByb3BzKTtcbiAgfSBlbHNlIHtcbiAgICBpZiAoIWluc3RhbmNlLnR5cGUucHJvcHMpIHtcbiAgICAgIGluc3RhbmNlLnByb3BzID0gYXR0cnM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGluc3RhbmNlLnByb3BzID0gcHJvcHM7XG4gICAgfVxuICB9XG4gIGluc3RhbmNlLmF0dHJzID0gYXR0cnM7XG59XG5mdW5jdGlvbiBpc0luSG1yQ29udGV4dChpbnN0YW5jZSkge1xuICB3aGlsZSAoaW5zdGFuY2UpIHtcbiAgICBpZiAoaW5zdGFuY2UudHlwZS5fX2htcklkKSByZXR1cm4gdHJ1ZTtcbiAgICBpbnN0YW5jZSA9IGluc3RhbmNlLnBhcmVudDtcbiAgfVxufVxuZnVuY3Rpb24gdXBkYXRlUHJvcHMoaW5zdGFuY2UsIHJhd1Byb3BzLCByYXdQcmV2UHJvcHMsIG9wdGltaXplZCkge1xuICBjb25zdCB7XG4gICAgcHJvcHMsXG4gICAgYXR0cnMsXG4gICAgdm5vZGU6IHsgcGF0Y2hGbGFnIH1cbiAgfSA9IGluc3RhbmNlO1xuICBjb25zdCByYXdDdXJyZW50UHJvcHMgPSB0b1Jhdyhwcm9wcyk7XG4gIGNvbnN0IFtvcHRpb25zXSA9IGluc3RhbmNlLnByb3BzT3B0aW9ucztcbiAgbGV0IGhhc0F0dHJzQ2hhbmdlZCA9IGZhbHNlO1xuICBpZiAoXG4gICAgLy8gYWx3YXlzIGZvcmNlIGZ1bGwgZGlmZiBpbiBkZXZcbiAgICAvLyAtICMxOTQyIGlmIGhtciBpcyBlbmFibGVkIHdpdGggc2ZjIGNvbXBvbmVudFxuICAgIC8vIC0gdml0ZSM4NzIgbm9uLXNmYyBjb21wb25lbnQgdXNlZCBieSBzZmMgY29tcG9uZW50XG4gICAgISghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzSW5IbXJDb250ZXh0KGluc3RhbmNlKSkgJiYgKG9wdGltaXplZCB8fCBwYXRjaEZsYWcgPiAwKSAmJiAhKHBhdGNoRmxhZyAmIDE2KVxuICApIHtcbiAgICBpZiAocGF0Y2hGbGFnICYgOCkge1xuICAgICAgY29uc3QgcHJvcHNUb1VwZGF0ZSA9IGluc3RhbmNlLnZub2RlLmR5bmFtaWNQcm9wcztcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvcHNUb1VwZGF0ZS5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZXQga2V5ID0gcHJvcHNUb1VwZGF0ZVtpXTtcbiAgICAgICAgaWYgKGlzRW1pdExpc3RlbmVyKGluc3RhbmNlLmVtaXRzT3B0aW9ucywga2V5KSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHZhbHVlID0gcmF3UHJvcHNba2V5XTtcbiAgICAgICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgICBpZiAoaGFzT3duKGF0dHJzLCBrZXkpKSB7XG4gICAgICAgICAgICBpZiAodmFsdWUgIT09IGF0dHJzW2tleV0pIHtcbiAgICAgICAgICAgICAgYXR0cnNba2V5XSA9IHZhbHVlO1xuICAgICAgICAgICAgICBoYXNBdHRyc0NoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBjYW1lbGl6ZWRLZXkgPSBjYW1lbGl6ZShrZXkpO1xuICAgICAgICAgICAgcHJvcHNbY2FtZWxpemVkS2V5XSA9IHJlc29sdmVQcm9wVmFsdWUoXG4gICAgICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgICAgIHJhd0N1cnJlbnRQcm9wcyxcbiAgICAgICAgICAgICAgY2FtZWxpemVkS2V5LFxuICAgICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgICAgICAgIGZhbHNlXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAodmFsdWUgIT09IGF0dHJzW2tleV0pIHtcbiAgICAgICAgICAgIGF0dHJzW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgICAgIGhhc0F0dHJzQ2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmIChzZXRGdWxsUHJvcHMoaW5zdGFuY2UsIHJhd1Byb3BzLCBwcm9wcywgYXR0cnMpKSB7XG4gICAgICBoYXNBdHRyc0NoYW5nZWQgPSB0cnVlO1xuICAgIH1cbiAgICBsZXQga2ViYWJLZXk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gcmF3Q3VycmVudFByb3BzKSB7XG4gICAgICBpZiAoIXJhd1Byb3BzIHx8IC8vIGZvciBjYW1lbENhc2VcbiAgICAgICFoYXNPd24ocmF3UHJvcHMsIGtleSkgJiYgLy8gaXQncyBwb3NzaWJsZSB0aGUgb3JpZ2luYWwgcHJvcHMgd2FzIHBhc3NlZCBpbiBhcyBrZWJhYi1jYXNlXG4gICAgICAvLyBhbmQgY29udmVydGVkIHRvIGNhbWVsQ2FzZSAoIzk1NSlcbiAgICAgICgoa2ViYWJLZXkgPSBoeXBoZW5hdGUoa2V5KSkgPT09IGtleSB8fCAhaGFzT3duKHJhd1Byb3BzLCBrZWJhYktleSkpKSB7XG4gICAgICAgIGlmIChvcHRpb25zKSB7XG4gICAgICAgICAgaWYgKHJhd1ByZXZQcm9wcyAmJiAvLyBmb3IgY2FtZWxDYXNlXG4gICAgICAgICAgKHJhd1ByZXZQcm9wc1trZXldICE9PSB2b2lkIDAgfHwgLy8gZm9yIGtlYmFiLWNhc2VcbiAgICAgICAgICByYXdQcmV2UHJvcHNba2ViYWJLZXldICE9PSB2b2lkIDApKSB7XG4gICAgICAgICAgICBwcm9wc1trZXldID0gcmVzb2x2ZVByb3BWYWx1ZShcbiAgICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgICAgcmF3Q3VycmVudFByb3BzLFxuICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgIHZvaWQgMCxcbiAgICAgICAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgICAgICAgIHRydWVcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGRlbGV0ZSBwcm9wc1trZXldO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChhdHRycyAhPT0gcmF3Q3VycmVudFByb3BzKSB7XG4gICAgICBmb3IgKGNvbnN0IGtleSBpbiBhdHRycykge1xuICAgICAgICBpZiAoIXJhd1Byb3BzIHx8ICFoYXNPd24ocmF3UHJvcHMsIGtleSkgJiYgdHJ1ZSkge1xuICAgICAgICAgIGRlbGV0ZSBhdHRyc1trZXldO1xuICAgICAgICAgIGhhc0F0dHJzQ2hhbmdlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGhhc0F0dHJzQ2hhbmdlZCkge1xuICAgIHRyaWdnZXIoaW5zdGFuY2UuYXR0cnMsIFwic2V0XCIsIFwiXCIpO1xuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgdmFsaWRhdGVQcm9wcyhyYXdQcm9wcyB8fCB7fSwgcHJvcHMsIGluc3RhbmNlKTtcbiAgfVxufVxuZnVuY3Rpb24gc2V0RnVsbFByb3BzKGluc3RhbmNlLCByYXdQcm9wcywgcHJvcHMsIGF0dHJzKSB7XG4gIGNvbnN0IFtvcHRpb25zLCBuZWVkQ2FzdEtleXNdID0gaW5zdGFuY2UucHJvcHNPcHRpb25zO1xuICBsZXQgaGFzQXR0cnNDaGFuZ2VkID0gZmFsc2U7XG4gIGxldCByYXdDYXN0VmFsdWVzO1xuICBpZiAocmF3UHJvcHMpIHtcbiAgICBmb3IgKGxldCBrZXkgaW4gcmF3UHJvcHMpIHtcbiAgICAgIGlmIChpc1Jlc2VydmVkUHJvcChrZXkpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgdmFsdWUgPSByYXdQcm9wc1trZXldO1xuICAgICAgbGV0IGNhbWVsS2V5O1xuICAgICAgaWYgKG9wdGlvbnMgJiYgaGFzT3duKG9wdGlvbnMsIGNhbWVsS2V5ID0gY2FtZWxpemUoa2V5KSkpIHtcbiAgICAgICAgaWYgKCFuZWVkQ2FzdEtleXMgfHwgIW5lZWRDYXN0S2V5cy5pbmNsdWRlcyhjYW1lbEtleSkpIHtcbiAgICAgICAgICBwcm9wc1tjYW1lbEtleV0gPSB2YWx1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAocmF3Q2FzdFZhbHVlcyB8fCAocmF3Q2FzdFZhbHVlcyA9IHt9KSlbY2FtZWxLZXldID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoIWlzRW1pdExpc3RlbmVyKGluc3RhbmNlLmVtaXRzT3B0aW9ucywga2V5KSkge1xuICAgICAgICBpZiAoIShrZXkgaW4gYXR0cnMpIHx8IHZhbHVlICE9PSBhdHRyc1trZXldKSB7XG4gICAgICAgICAgYXR0cnNba2V5XSA9IHZhbHVlO1xuICAgICAgICAgIGhhc0F0dHJzQ2hhbmdlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKG5lZWRDYXN0S2V5cykge1xuICAgIGNvbnN0IHJhd0N1cnJlbnRQcm9wcyA9IHRvUmF3KHByb3BzKTtcbiAgICBjb25zdCBjYXN0VmFsdWVzID0gcmF3Q2FzdFZhbHVlcyB8fCBFTVBUWV9PQko7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBuZWVkQ2FzdEtleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGtleSA9IG5lZWRDYXN0S2V5c1tpXTtcbiAgICAgIHByb3BzW2tleV0gPSByZXNvbHZlUHJvcFZhbHVlKFxuICAgICAgICBvcHRpb25zLFxuICAgICAgICByYXdDdXJyZW50UHJvcHMsXG4gICAgICAgIGtleSxcbiAgICAgICAgY2FzdFZhbHVlc1trZXldLFxuICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgIWhhc093bihjYXN0VmFsdWVzLCBrZXkpXG4gICAgICApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gaGFzQXR0cnNDaGFuZ2VkO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVByb3BWYWx1ZShvcHRpb25zLCBwcm9wcywga2V5LCB2YWx1ZSwgaW5zdGFuY2UsIGlzQWJzZW50KSB7XG4gIGNvbnN0IG9wdCA9IG9wdGlvbnNba2V5XTtcbiAgaWYgKG9wdCAhPSBudWxsKSB7XG4gICAgY29uc3QgaGFzRGVmYXVsdCA9IGhhc093bihvcHQsIFwiZGVmYXVsdFwiKTtcbiAgICBpZiAoaGFzRGVmYXVsdCAmJiB2YWx1ZSA9PT0gdm9pZCAwKSB7XG4gICAgICBjb25zdCBkZWZhdWx0VmFsdWUgPSBvcHQuZGVmYXVsdDtcbiAgICAgIGlmIChvcHQudHlwZSAhPT0gRnVuY3Rpb24gJiYgIW9wdC5za2lwRmFjdG9yeSAmJiBpc0Z1bmN0aW9uKGRlZmF1bHRWYWx1ZSkpIHtcbiAgICAgICAgY29uc3QgeyBwcm9wc0RlZmF1bHRzIH0gPSBpbnN0YW5jZTtcbiAgICAgICAgaWYgKGtleSBpbiBwcm9wc0RlZmF1bHRzKSB7XG4gICAgICAgICAgdmFsdWUgPSBwcm9wc0RlZmF1bHRzW2tleV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgcmVzZXQgPSBzZXRDdXJyZW50SW5zdGFuY2UoaW5zdGFuY2UpO1xuICAgICAgICAgIHZhbHVlID0gcHJvcHNEZWZhdWx0c1trZXldID0gZGVmYXVsdFZhbHVlLmNhbGwoXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgcHJvcHNcbiAgICAgICAgICApO1xuICAgICAgICAgIHJlc2V0KCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhbHVlID0gZGVmYXVsdFZhbHVlO1xuICAgICAgfVxuICAgICAgaWYgKGluc3RhbmNlLmNlKSB7XG4gICAgICAgIGluc3RhbmNlLmNlLl9zZXRQcm9wKGtleSwgdmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAob3B0WzAgLyogc2hvdWxkQ2FzdCAqL10pIHtcbiAgICAgIGlmIChpc0Fic2VudCAmJiAhaGFzRGVmYXVsdCkge1xuICAgICAgICB2YWx1ZSA9IGZhbHNlO1xuICAgICAgfSBlbHNlIGlmIChvcHRbMSAvKiBzaG91bGRDYXN0VHJ1ZSAqL10gJiYgKHZhbHVlID09PSBcIlwiIHx8IHZhbHVlID09PSBoeXBoZW5hdGUoa2V5KSkpIHtcbiAgICAgICAgdmFsdWUgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5jb25zdCBtaXhpblByb3BzQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZVByb3BzT3B0aW9ucyhjb21wLCBhcHBDb250ZXh0LCBhc01peGluID0gZmFsc2UpIHtcbiAgY29uc3QgY2FjaGUgPSBfX1ZVRV9PUFRJT05TX0FQSV9fICYmIGFzTWl4aW4gPyBtaXhpblByb3BzQ2FjaGUgOiBhcHBDb250ZXh0LnByb3BzQ2FjaGU7XG4gIGNvbnN0IGNhY2hlZCA9IGNhY2hlLmdldChjb21wKTtcbiAgaWYgKGNhY2hlZCkge1xuICAgIHJldHVybiBjYWNoZWQ7XG4gIH1cbiAgY29uc3QgcmF3ID0gY29tcC5wcm9wcztcbiAgY29uc3Qgbm9ybWFsaXplZCA9IHt9O1xuICBjb25zdCBuZWVkQ2FzdEtleXMgPSBbXTtcbiAgbGV0IGhhc0V4dGVuZHMgPSBmYWxzZTtcbiAgaWYgKF9fVlVFX09QVElPTlNfQVBJX18gJiYgIWlzRnVuY3Rpb24oY29tcCkpIHtcbiAgICBjb25zdCBleHRlbmRQcm9wcyA9IChyYXcyKSA9PiB7XG4gICAgICBoYXNFeHRlbmRzID0gdHJ1ZTtcbiAgICAgIGNvbnN0IFtwcm9wcywga2V5c10gPSBub3JtYWxpemVQcm9wc09wdGlvbnMocmF3MiwgYXBwQ29udGV4dCwgdHJ1ZSk7XG4gICAgICBleHRlbmQobm9ybWFsaXplZCwgcHJvcHMpO1xuICAgICAgaWYgKGtleXMpIG5lZWRDYXN0S2V5cy5wdXNoKC4uLmtleXMpO1xuICAgIH07XG4gICAgaWYgKCFhc01peGluICYmIGFwcENvbnRleHQubWl4aW5zLmxlbmd0aCkge1xuICAgICAgYXBwQ29udGV4dC5taXhpbnMuZm9yRWFjaChleHRlbmRQcm9wcyk7XG4gICAgfVxuICAgIGlmIChjb21wLmV4dGVuZHMpIHtcbiAgICAgIGV4dGVuZFByb3BzKGNvbXAuZXh0ZW5kcyk7XG4gICAgfVxuICAgIGlmIChjb21wLm1peGlucykge1xuICAgICAgY29tcC5taXhpbnMuZm9yRWFjaChleHRlbmRQcm9wcyk7XG4gICAgfVxuICB9XG4gIGlmICghcmF3ICYmICFoYXNFeHRlbmRzKSB7XG4gICAgaWYgKGlzT2JqZWN0KGNvbXApKSB7XG4gICAgICBjYWNoZS5zZXQoY29tcCwgRU1QVFlfQVJSKTtcbiAgICB9XG4gICAgcmV0dXJuIEVNUFRZX0FSUjtcbiAgfVxuICBpZiAoaXNBcnJheShyYXcpKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCByYXcubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFpc1N0cmluZyhyYXdbaV0pKSB7XG4gICAgICAgIHdhcm4kMShgcHJvcHMgbXVzdCBiZSBzdHJpbmdzIHdoZW4gdXNpbmcgYXJyYXkgc3ludGF4LmAsIHJhd1tpXSk7XG4gICAgICB9XG4gICAgICBjb25zdCBub3JtYWxpemVkS2V5ID0gY2FtZWxpemUocmF3W2ldKTtcbiAgICAgIGlmICh2YWxpZGF0ZVByb3BOYW1lKG5vcm1hbGl6ZWRLZXkpKSB7XG4gICAgICAgIG5vcm1hbGl6ZWRbbm9ybWFsaXplZEtleV0gPSBFTVBUWV9PQko7XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2UgaWYgKHJhdykge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFpc09iamVjdChyYXcpKSB7XG4gICAgICB3YXJuJDEoYGludmFsaWQgcHJvcHMgb3B0aW9uc2AsIHJhdyk7XG4gICAgfVxuICAgIGZvciAoY29uc3Qga2V5IGluIHJhdykge1xuICAgICAgY29uc3Qgbm9ybWFsaXplZEtleSA9IGNhbWVsaXplKGtleSk7XG4gICAgICBpZiAodmFsaWRhdGVQcm9wTmFtZShub3JtYWxpemVkS2V5KSkge1xuICAgICAgICBjb25zdCBvcHQgPSByYXdba2V5XTtcbiAgICAgICAgY29uc3QgcHJvcCA9IG5vcm1hbGl6ZWRbbm9ybWFsaXplZEtleV0gPSBpc0FycmF5KG9wdCkgfHwgaXNGdW5jdGlvbihvcHQpID8geyB0eXBlOiBvcHQgfSA6IGV4dGVuZCh7fSwgb3B0KTtcbiAgICAgICAgY29uc3QgcHJvcFR5cGUgPSBwcm9wLnR5cGU7XG4gICAgICAgIGxldCBzaG91bGRDYXN0ID0gZmFsc2U7XG4gICAgICAgIGxldCBzaG91bGRDYXN0VHJ1ZSA9IHRydWU7XG4gICAgICAgIGlmIChpc0FycmF5KHByb3BUeXBlKSkge1xuICAgICAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBwcm9wVHlwZS5sZW5ndGg7ICsraW5kZXgpIHtcbiAgICAgICAgICAgIGNvbnN0IHR5cGUgPSBwcm9wVHlwZVtpbmRleF07XG4gICAgICAgICAgICBjb25zdCB0eXBlTmFtZSA9IGlzRnVuY3Rpb24odHlwZSkgJiYgdHlwZS5uYW1lO1xuICAgICAgICAgICAgaWYgKHR5cGVOYW1lID09PSBcIkJvb2xlYW5cIikge1xuICAgICAgICAgICAgICBzaG91bGRDYXN0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVOYW1lID09PSBcIlN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgIHNob3VsZENhc3RUcnVlID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNob3VsZENhc3QgPSBpc0Z1bmN0aW9uKHByb3BUeXBlKSAmJiBwcm9wVHlwZS5uYW1lID09PSBcIkJvb2xlYW5cIjtcbiAgICAgICAgfVxuICAgICAgICBwcm9wWzAgLyogc2hvdWxkQ2FzdCAqL10gPSBzaG91bGRDYXN0O1xuICAgICAgICBwcm9wWzEgLyogc2hvdWxkQ2FzdFRydWUgKi9dID0gc2hvdWxkQ2FzdFRydWU7XG4gICAgICAgIGlmIChzaG91bGRDYXN0IHx8IGhhc093bihwcm9wLCBcImRlZmF1bHRcIikpIHtcbiAgICAgICAgICBuZWVkQ2FzdEtleXMucHVzaChub3JtYWxpemVkS2V5KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBjb25zdCByZXMgPSBbbm9ybWFsaXplZCwgbmVlZENhc3RLZXlzXTtcbiAgaWYgKGlzT2JqZWN0KGNvbXApKSB7XG4gICAgY2FjaGUuc2V0KGNvbXAsIHJlcyk7XG4gIH1cbiAgcmV0dXJuIHJlcztcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlUHJvcE5hbWUoa2V5KSB7XG4gIGlmIChrZXlbMF0gIT09IFwiJFwiICYmICFpc1Jlc2VydmVkUHJvcChrZXkpKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm4kMShgSW52YWxpZCBwcm9wIG5hbWU6IFwiJHtrZXl9XCIgaXMgYSByZXNlcnZlZCBwcm9wZXJ0eS5gKTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBnZXRUeXBlKGN0b3IpIHtcbiAgaWYgKGN0b3IgPT09IG51bGwpIHtcbiAgICByZXR1cm4gXCJudWxsXCI7XG4gIH1cbiAgaWYgKHR5cGVvZiBjdG9yID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4gY3Rvci5uYW1lIHx8IFwiXCI7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGN0b3IgPT09IFwib2JqZWN0XCIpIHtcbiAgICBjb25zdCBuYW1lID0gY3Rvci5jb25zdHJ1Y3RvciAmJiBjdG9yLmNvbnN0cnVjdG9yLm5hbWU7XG4gICAgcmV0dXJuIG5hbWUgfHwgXCJcIjtcbiAgfVxuICByZXR1cm4gXCJcIjtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlUHJvcHMocmF3UHJvcHMsIHByb3BzLCBpbnN0YW5jZSkge1xuICBjb25zdCByZXNvbHZlZFZhbHVlcyA9IHRvUmF3KHByb3BzKTtcbiAgY29uc3Qgb3B0aW9ucyA9IGluc3RhbmNlLnByb3BzT3B0aW9uc1swXTtcbiAgY29uc3QgY2FtZWxpemVQcm9wc0tleSA9IE9iamVjdC5rZXlzKHJhd1Byb3BzKS5tYXAoKGtleSkgPT4gY2FtZWxpemUoa2V5KSk7XG4gIGZvciAoY29uc3Qga2V5IGluIG9wdGlvbnMpIHtcbiAgICBsZXQgb3B0ID0gb3B0aW9uc1trZXldO1xuICAgIGlmIChvcHQgPT0gbnVsbCkgY29udGludWU7XG4gICAgdmFsaWRhdGVQcm9wKFxuICAgICAga2V5LFxuICAgICAgcmVzb2x2ZWRWYWx1ZXNba2V5XSxcbiAgICAgIG9wdCxcbiAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzaGFsbG93UmVhZG9ubHkocmVzb2x2ZWRWYWx1ZXMpIDogcmVzb2x2ZWRWYWx1ZXMsXG4gICAgICAhY2FtZWxpemVQcm9wc0tleS5pbmNsdWRlcyhrZXkpXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gdmFsaWRhdGVQcm9wKG5hbWUsIHZhbHVlLCBwcm9wLCBwcm9wcywgaXNBYnNlbnQpIHtcbiAgY29uc3QgeyB0eXBlLCByZXF1aXJlZCwgdmFsaWRhdG9yLCBza2lwQ2hlY2sgfSA9IHByb3A7XG4gIGlmIChyZXF1aXJlZCAmJiBpc0Fic2VudCkge1xuICAgIHdhcm4kMSgnTWlzc2luZyByZXF1aXJlZCBwcm9wOiBcIicgKyBuYW1lICsgJ1wiJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh2YWx1ZSA9PSBudWxsICYmICFyZXF1aXJlZCkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodHlwZSAhPSBudWxsICYmIHR5cGUgIT09IHRydWUgJiYgIXNraXBDaGVjaykge1xuICAgIGxldCBpc1ZhbGlkID0gZmFsc2U7XG4gICAgY29uc3QgdHlwZXMgPSBpc0FycmF5KHR5cGUpID8gdHlwZSA6IFt0eXBlXTtcbiAgICBjb25zdCBleHBlY3RlZFR5cGVzID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0eXBlcy5sZW5ndGggJiYgIWlzVmFsaWQ7IGkrKykge1xuICAgICAgY29uc3QgeyB2YWxpZCwgZXhwZWN0ZWRUeXBlIH0gPSBhc3NlcnRUeXBlKHZhbHVlLCB0eXBlc1tpXSk7XG4gICAgICBleHBlY3RlZFR5cGVzLnB1c2goZXhwZWN0ZWRUeXBlIHx8IFwiXCIpO1xuICAgICAgaXNWYWxpZCA9IHZhbGlkO1xuICAgIH1cbiAgICBpZiAoIWlzVmFsaWQpIHtcbiAgICAgIHdhcm4kMShnZXRJbnZhbGlkVHlwZU1lc3NhZ2UobmFtZSwgdmFsdWUsIGV4cGVjdGVkVHlwZXMpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbiAgaWYgKHZhbGlkYXRvciAmJiAhdmFsaWRhdG9yKHZhbHVlLCBwcm9wcykpIHtcbiAgICB3YXJuJDEoJ0ludmFsaWQgcHJvcDogY3VzdG9tIHZhbGlkYXRvciBjaGVjayBmYWlsZWQgZm9yIHByb3AgXCInICsgbmFtZSArICdcIi4nKTtcbiAgfVxufVxuY29uc3QgaXNTaW1wbGVUeXBlID0gLyogQF9fUFVSRV9fICovIG1ha2VNYXAoXG4gIFwiU3RyaW5nLE51bWJlcixCb29sZWFuLEZ1bmN0aW9uLFN5bWJvbCxCaWdJbnRcIlxuKTtcbmZ1bmN0aW9uIGFzc2VydFR5cGUodmFsdWUsIHR5cGUpIHtcbiAgbGV0IHZhbGlkO1xuICBjb25zdCBleHBlY3RlZFR5cGUgPSBnZXRUeXBlKHR5cGUpO1xuICBpZiAoZXhwZWN0ZWRUeXBlID09PSBcIm51bGxcIikge1xuICAgIHZhbGlkID0gdmFsdWUgPT09IG51bGw7XG4gIH0gZWxzZSBpZiAoaXNTaW1wbGVUeXBlKGV4cGVjdGVkVHlwZSkpIHtcbiAgICBjb25zdCB0ID0gdHlwZW9mIHZhbHVlO1xuICAgIHZhbGlkID0gdCA9PT0gZXhwZWN0ZWRUeXBlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKCF2YWxpZCAmJiB0ID09PSBcIm9iamVjdFwiKSB7XG4gICAgICB2YWxpZCA9IHZhbHVlIGluc3RhbmNlb2YgdHlwZTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoZXhwZWN0ZWRUeXBlID09PSBcIk9iamVjdFwiKSB7XG4gICAgdmFsaWQgPSBpc09iamVjdCh2YWx1ZSk7XG4gIH0gZWxzZSBpZiAoZXhwZWN0ZWRUeXBlID09PSBcIkFycmF5XCIpIHtcbiAgICB2YWxpZCA9IGlzQXJyYXkodmFsdWUpO1xuICB9IGVsc2Uge1xuICAgIHZhbGlkID0gdmFsdWUgaW5zdGFuY2VvZiB0eXBlO1xuICB9XG4gIHJldHVybiB7XG4gICAgdmFsaWQsXG4gICAgZXhwZWN0ZWRUeXBlXG4gIH07XG59XG5mdW5jdGlvbiBnZXRJbnZhbGlkVHlwZU1lc3NhZ2UobmFtZSwgdmFsdWUsIGV4cGVjdGVkVHlwZXMpIHtcbiAgaWYgKGV4cGVjdGVkVHlwZXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIGBQcm9wIHR5cGUgW10gZm9yIHByb3AgXCIke25hbWV9XCIgd29uJ3QgbWF0Y2ggYW55dGhpbmcuIERpZCB5b3UgbWVhbiB0byB1c2UgdHlwZSBBcnJheSBpbnN0ZWFkP2A7XG4gIH1cbiAgbGV0IG1lc3NhZ2UgPSBgSW52YWxpZCBwcm9wOiB0eXBlIGNoZWNrIGZhaWxlZCBmb3IgcHJvcCBcIiR7bmFtZX1cIi4gRXhwZWN0ZWQgJHtleHBlY3RlZFR5cGVzLm1hcChjYXBpdGFsaXplKS5qb2luKFwiIHwgXCIpfWA7XG4gIGNvbnN0IGV4cGVjdGVkVHlwZSA9IGV4cGVjdGVkVHlwZXNbMF07XG4gIGNvbnN0IHJlY2VpdmVkVHlwZSA9IHRvUmF3VHlwZSh2YWx1ZSk7XG4gIGNvbnN0IGV4cGVjdGVkVmFsdWUgPSBzdHlsZVZhbHVlKHZhbHVlLCBleHBlY3RlZFR5cGUpO1xuICBjb25zdCByZWNlaXZlZFZhbHVlID0gc3R5bGVWYWx1ZSh2YWx1ZSwgcmVjZWl2ZWRUeXBlKTtcbiAgaWYgKGV4cGVjdGVkVHlwZXMubGVuZ3RoID09PSAxICYmIGlzRXhwbGljYWJsZShleHBlY3RlZFR5cGUpICYmIGlzQ29lcmNpYmxlKGV4cGVjdGVkVHlwZSwgcmVjZWl2ZWRUeXBlKSkge1xuICAgIG1lc3NhZ2UgKz0gYCB3aXRoIHZhbHVlICR7ZXhwZWN0ZWRWYWx1ZX1gO1xuICB9XG4gIG1lc3NhZ2UgKz0gYCwgZ290ICR7cmVjZWl2ZWRUeXBlfSBgO1xuICBpZiAoaXNFeHBsaWNhYmxlKHJlY2VpdmVkVHlwZSkpIHtcbiAgICBtZXNzYWdlICs9IGB3aXRoIHZhbHVlICR7cmVjZWl2ZWRWYWx1ZX0uYDtcbiAgfVxuICByZXR1cm4gbWVzc2FnZTtcbn1cbmZ1bmN0aW9uIHN0eWxlVmFsdWUodmFsdWUsIHR5cGUpIHtcbiAgaWYgKGlzU3ltYm9sKHZhbHVlKSkge1xuICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICB9IGVsc2UgaWYgKHR5cGUgPT09IFwiU3RyaW5nXCIpIHtcbiAgICByZXR1cm4gYFwiJHt2YWx1ZX1cImA7XG4gIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJOdW1iZXJcIikge1xuICAgIHJldHVybiBgJHtOdW1iZXIodmFsdWUpfWA7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGAke3ZhbHVlfWA7XG4gIH1cbn1cbmZ1bmN0aW9uIGlzRXhwbGljYWJsZSh0eXBlKSB7XG4gIGNvbnN0IGV4cGxpY2l0VHlwZXMgPSBbXCJzdHJpbmdcIiwgXCJudW1iZXJcIiwgXCJib29sZWFuXCJdO1xuICByZXR1cm4gZXhwbGljaXRUeXBlcy5zb21lKChlbGVtKSA9PiB0eXBlLnRvTG93ZXJDYXNlKCkgPT09IGVsZW0pO1xufVxuZnVuY3Rpb24gaXNDb2VyY2libGUoLi4uYXJncykge1xuICByZXR1cm4gYXJncy5ldmVyeSgoZWxlbSkgPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gZWxlbS50b0xvd2VyQ2FzZSgpO1xuICAgIHJldHVybiB2YWx1ZSAhPT0gXCJib29sZWFuXCIgJiYgdmFsdWUgIT09IFwic3ltYm9sXCI7XG4gIH0pO1xufVxuXG5jb25zdCBpc0ludGVybmFsS2V5ID0gKGtleSkgPT4ga2V5ID09PSBcIl9cIiB8fCBrZXkgPT09IFwiX2N0eFwiIHx8IGtleSA9PT0gXCIkc3RhYmxlXCI7XG5jb25zdCBub3JtYWxpemVTbG90VmFsdWUgPSAodmFsdWUpID0+IGlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKG5vcm1hbGl6ZVZOb2RlKSA6IFtub3JtYWxpemVWTm9kZSh2YWx1ZSldO1xuY29uc3Qgbm9ybWFsaXplU2xvdCA9IChrZXksIHJhd1Nsb3QsIGN0eCkgPT4ge1xuICBpZiAocmF3U2xvdC5fbikge1xuICAgIHJldHVybiByYXdTbG90O1xuICB9XG4gIGNvbnN0IG5vcm1hbGl6ZWQgPSB3aXRoQ3R4KCguLi5hcmdzKSA9PiB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgY3VycmVudEluc3RhbmNlICYmICEoY3R4ID09PSBudWxsICYmIGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSkgJiYgIShjdHggJiYgY3R4LnJvb3QgIT09IGN1cnJlbnRJbnN0YW5jZS5yb290KSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgU2xvdCBcIiR7a2V5fVwiIGludm9rZWQgb3V0c2lkZSBvZiB0aGUgcmVuZGVyIGZ1bmN0aW9uOiB0aGlzIHdpbGwgbm90IHRyYWNrIGRlcGVuZGVuY2llcyB1c2VkIGluIHRoZSBzbG90LiBJbnZva2UgdGhlIHNsb3QgZnVuY3Rpb24gaW5zaWRlIHRoZSByZW5kZXIgZnVuY3Rpb24gaW5zdGVhZC5gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gbm9ybWFsaXplU2xvdFZhbHVlKHJhd1Nsb3QoLi4uYXJncykpO1xuICB9LCBjdHgpO1xuICBub3JtYWxpemVkLl9jID0gZmFsc2U7XG4gIHJldHVybiBub3JtYWxpemVkO1xufTtcbmNvbnN0IG5vcm1hbGl6ZU9iamVjdFNsb3RzID0gKHJhd1Nsb3RzLCBzbG90cywgaW5zdGFuY2UpID0+IHtcbiAgY29uc3QgY3R4ID0gcmF3U2xvdHMuX2N0eDtcbiAgZm9yIChjb25zdCBrZXkgaW4gcmF3U2xvdHMpIHtcbiAgICBpZiAoaXNJbnRlcm5hbEtleShrZXkpKSBjb250aW51ZTtcbiAgICBjb25zdCB2YWx1ZSA9IHJhd1Nsb3RzW2tleV07XG4gICAgaWYgKGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgICBzbG90c1trZXldID0gbm9ybWFsaXplU2xvdChrZXksIHZhbHVlLCBjdHgpO1xuICAgIH0gZWxzZSBpZiAodmFsdWUgIT0gbnVsbCkge1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdHJ1ZSkge1xuICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgYE5vbi1mdW5jdGlvbiB2YWx1ZSBlbmNvdW50ZXJlZCBmb3Igc2xvdCBcIiR7a2V5fVwiLiBQcmVmZXIgZnVuY3Rpb24gc2xvdHMgZm9yIGJldHRlciBwZXJmb3JtYW5jZS5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBjb25zdCBub3JtYWxpemVkID0gbm9ybWFsaXplU2xvdFZhbHVlKHZhbHVlKTtcbiAgICAgIHNsb3RzW2tleV0gPSAoKSA9PiBub3JtYWxpemVkO1xuICAgIH1cbiAgfVxufTtcbmNvbnN0IG5vcm1hbGl6ZVZOb2RlU2xvdHMgPSAoaW5zdGFuY2UsIGNoaWxkcmVuKSA9PiB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFpc0tlZXBBbGl2ZShpbnN0YW5jZS52bm9kZSkgJiYgdHJ1ZSkge1xuICAgIHdhcm4kMShcbiAgICAgIGBOb24tZnVuY3Rpb24gdmFsdWUgZW5jb3VudGVyZWQgZm9yIGRlZmF1bHQgc2xvdC4gUHJlZmVyIGZ1bmN0aW9uIHNsb3RzIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2UuYFxuICAgICk7XG4gIH1cbiAgY29uc3Qgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZVNsb3RWYWx1ZShjaGlsZHJlbik7XG4gIGluc3RhbmNlLnNsb3RzLmRlZmF1bHQgPSAoKSA9PiBub3JtYWxpemVkO1xufTtcbmNvbnN0IGFzc2lnblNsb3RzID0gKHNsb3RzLCBjaGlsZHJlbiwgb3B0aW1pemVkKSA9PiB7XG4gIGZvciAoY29uc3Qga2V5IGluIGNoaWxkcmVuKSB7XG4gICAgaWYgKG9wdGltaXplZCB8fCAhaXNJbnRlcm5hbEtleShrZXkpKSB7XG4gICAgICBzbG90c1trZXldID0gY2hpbGRyZW5ba2V5XTtcbiAgICB9XG4gIH1cbn07XG5jb25zdCBpbml0U2xvdHMgPSAoaW5zdGFuY2UsIGNoaWxkcmVuLCBvcHRpbWl6ZWQpID0+IHtcbiAgY29uc3Qgc2xvdHMgPSBpbnN0YW5jZS5zbG90cyA9IGNyZWF0ZUludGVybmFsT2JqZWN0KCk7XG4gIGlmIChpbnN0YW5jZS52bm9kZS5zaGFwZUZsYWcgJiAzMikge1xuICAgIGNvbnN0IHR5cGUgPSBjaGlsZHJlbi5fO1xuICAgIGlmICh0eXBlKSB7XG4gICAgICBhc3NpZ25TbG90cyhzbG90cywgY2hpbGRyZW4sIG9wdGltaXplZCk7XG4gICAgICBpZiAob3B0aW1pemVkKSB7XG4gICAgICAgIGRlZihzbG90cywgXCJfXCIsIHR5cGUsIHRydWUpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBub3JtYWxpemVPYmplY3RTbG90cyhjaGlsZHJlbiwgc2xvdHMpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChjaGlsZHJlbikge1xuICAgIG5vcm1hbGl6ZVZOb2RlU2xvdHMoaW5zdGFuY2UsIGNoaWxkcmVuKTtcbiAgfVxufTtcbmNvbnN0IHVwZGF0ZVNsb3RzID0gKGluc3RhbmNlLCBjaGlsZHJlbiwgb3B0aW1pemVkKSA9PiB7XG4gIGNvbnN0IHsgdm5vZGUsIHNsb3RzIH0gPSBpbnN0YW5jZTtcbiAgbGV0IG5lZWREZWxldGlvbkNoZWNrID0gdHJ1ZTtcbiAgbGV0IGRlbGV0aW9uQ29tcGFyaXNvblRhcmdldCA9IEVNUFRZX09CSjtcbiAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDMyKSB7XG4gICAgY29uc3QgdHlwZSA9IGNoaWxkcmVuLl87XG4gICAgaWYgKHR5cGUpIHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzSG1yVXBkYXRpbmcpIHtcbiAgICAgICAgYXNzaWduU2xvdHMoc2xvdHMsIGNoaWxkcmVuLCBvcHRpbWl6ZWQpO1xuICAgICAgICB0cmlnZ2VyKGluc3RhbmNlLCBcInNldFwiLCBcIiRzbG90c1wiKTtcbiAgICAgIH0gZWxzZSBpZiAob3B0aW1pemVkICYmIHR5cGUgPT09IDEpIHtcbiAgICAgICAgbmVlZERlbGV0aW9uQ2hlY2sgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFzc2lnblNsb3RzKHNsb3RzLCBjaGlsZHJlbiwgb3B0aW1pemVkKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgbmVlZERlbGV0aW9uQ2hlY2sgPSAhY2hpbGRyZW4uJHN0YWJsZTtcbiAgICAgIG5vcm1hbGl6ZU9iamVjdFNsb3RzKGNoaWxkcmVuLCBzbG90cyk7XG4gICAgfVxuICAgIGRlbGV0aW9uQ29tcGFyaXNvblRhcmdldCA9IGNoaWxkcmVuO1xuICB9IGVsc2UgaWYgKGNoaWxkcmVuKSB7XG4gICAgbm9ybWFsaXplVk5vZGVTbG90cyhpbnN0YW5jZSwgY2hpbGRyZW4pO1xuICAgIGRlbGV0aW9uQ29tcGFyaXNvblRhcmdldCA9IHsgZGVmYXVsdDogMSB9O1xuICB9XG4gIGlmIChuZWVkRGVsZXRpb25DaGVjaykge1xuICAgIGZvciAoY29uc3Qga2V5IGluIHNsb3RzKSB7XG4gICAgICBpZiAoIWlzSW50ZXJuYWxLZXkoa2V5KSAmJiBkZWxldGlvbkNvbXBhcmlzb25UYXJnZXRba2V5XSA9PSBudWxsKSB7XG4gICAgICAgIGRlbGV0ZSBzbG90c1trZXldO1xuICAgICAgfVxuICAgIH1cbiAgfVxufTtcblxubGV0IHN1cHBvcnRlZDtcbmxldCBwZXJmO1xuZnVuY3Rpb24gc3RhcnRNZWFzdXJlKGluc3RhbmNlLCB0eXBlKSB7XG4gIGlmIChpbnN0YW5jZS5hcHBDb250ZXh0LmNvbmZpZy5wZXJmb3JtYW5jZSAmJiBpc1N1cHBvcnRlZCgpKSB7XG4gICAgcGVyZi5tYXJrKGB2dWUtJHt0eXBlfS0ke2luc3RhbmNlLnVpZH1gKTtcbiAgfVxuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICBkZXZ0b29sc1BlcmZTdGFydChpbnN0YW5jZSwgdHlwZSwgaXNTdXBwb3J0ZWQoKSA/IHBlcmYubm93KCkgOiBEYXRlLm5vdygpKTtcbiAgfVxufVxuZnVuY3Rpb24gZW5kTWVhc3VyZShpbnN0YW5jZSwgdHlwZSkge1xuICBpZiAoaW5zdGFuY2UuYXBwQ29udGV4dC5jb25maWcucGVyZm9ybWFuY2UgJiYgaXNTdXBwb3J0ZWQoKSkge1xuICAgIGNvbnN0IHN0YXJ0VGFnID0gYHZ1ZS0ke3R5cGV9LSR7aW5zdGFuY2UudWlkfWA7XG4gICAgY29uc3QgZW5kVGFnID0gc3RhcnRUYWcgKyBgOmVuZGA7XG4gICAgY29uc3QgbWVhc3VyZU5hbWUgPSBgPCR7Zm9ybWF0Q29tcG9uZW50TmFtZShpbnN0YW5jZSwgaW5zdGFuY2UudHlwZSl9PiAke3R5cGV9YDtcbiAgICBwZXJmLm1hcmsoZW5kVGFnKTtcbiAgICBwZXJmLm1lYXN1cmUobWVhc3VyZU5hbWUsIHN0YXJ0VGFnLCBlbmRUYWcpO1xuICAgIHBlcmYuY2xlYXJNZWFzdXJlcyhtZWFzdXJlTmFtZSk7XG4gICAgcGVyZi5jbGVhck1hcmtzKHN0YXJ0VGFnKTtcbiAgICBwZXJmLmNsZWFyTWFya3MoZW5kVGFnKTtcbiAgfVxuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICBkZXZ0b29sc1BlcmZFbmQoaW5zdGFuY2UsIHR5cGUsIGlzU3VwcG9ydGVkKCkgPyBwZXJmLm5vdygpIDogRGF0ZS5ub3coKSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGlzU3VwcG9ydGVkKCkge1xuICBpZiAoc3VwcG9ydGVkICE9PSB2b2lkIDApIHtcbiAgICByZXR1cm4gc3VwcG9ydGVkO1xuICB9XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5wZXJmb3JtYW5jZSkge1xuICAgIHN1cHBvcnRlZCA9IHRydWU7XG4gICAgcGVyZiA9IHdpbmRvdy5wZXJmb3JtYW5jZTtcbiAgfSBlbHNlIHtcbiAgICBzdXBwb3J0ZWQgPSBmYWxzZTtcbiAgfVxuICByZXR1cm4gc3VwcG9ydGVkO1xufVxuXG5mdW5jdGlvbiBpbml0RmVhdHVyZUZsYWdzKCkge1xuICBjb25zdCBuZWVkV2FybiA9IFtdO1xuICBpZiAodHlwZW9mIF9fVlVFX09QVElPTlNfQVBJX18gIT09IFwiYm9vbGVhblwiKSB7XG4gICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBuZWVkV2Fybi5wdXNoKGBfX1ZVRV9PUFRJT05TX0FQSV9fYCk7XG4gICAgZ2V0R2xvYmFsVGhpcygpLl9fVlVFX09QVElPTlNfQVBJX18gPSB0cnVlO1xuICB9XG4gIGlmICh0eXBlb2YgX19WVUVfUFJPRF9ERVZUT09MU19fICE9PSBcImJvb2xlYW5cIikge1xuICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgbmVlZFdhcm4ucHVzaChgX19WVUVfUFJPRF9ERVZUT09MU19fYCk7XG4gICAgZ2V0R2xvYmFsVGhpcygpLl9fVlVFX1BST0RfREVWVE9PTFNfXyA9IGZhbHNlO1xuICB9XG4gIGlmICh0eXBlb2YgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fICE9PSBcImJvb2xlYW5cIikge1xuICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgbmVlZFdhcm4ucHVzaChgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fYCk7XG4gICAgZ2V0R2xvYmFsVGhpcygpLl9fVlVFX1BST0RfSFlEUkFUSU9OX01JU01BVENIX0RFVEFJTFNfXyA9IGZhbHNlO1xuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIG5lZWRXYXJuLmxlbmd0aCkge1xuICAgIGNvbnN0IG11bHRpID0gbmVlZFdhcm4ubGVuZ3RoID4gMTtcbiAgICBjb25zb2xlLndhcm4oXG4gICAgICBgRmVhdHVyZSBmbGFnJHttdWx0aSA/IGBzYCA6IGBgfSAke25lZWRXYXJuLmpvaW4oXCIsIFwiKX0gJHttdWx0aSA/IGBhcmVgIDogYGlzYH0gbm90IGV4cGxpY2l0bHkgZGVmaW5lZC4gWW91IGFyZSBydW5uaW5nIHRoZSBlc20tYnVuZGxlciBidWlsZCBvZiBWdWUsIHdoaWNoIGV4cGVjdHMgdGhlc2UgY29tcGlsZS10aW1lIGZlYXR1cmUgZmxhZ3MgdG8gYmUgZ2xvYmFsbHkgaW5qZWN0ZWQgdmlhIHRoZSBidW5kbGVyIGNvbmZpZyBpbiBvcmRlciB0byBnZXQgYmV0dGVyIHRyZWUtc2hha2luZyBpbiB0aGUgcHJvZHVjdGlvbiBidW5kbGUuXG5cbkZvciBtb3JlIGRldGFpbHMsIHNlZSBodHRwczovL2xpbmsudnVlanMub3JnL2ZlYXR1cmUtZmxhZ3MuYFxuICAgICk7XG4gIH1cbn1cblxuY29uc3QgcXVldWVQb3N0UmVuZGVyRWZmZWN0ID0gcXVldWVFZmZlY3RXaXRoU3VzcGVuc2UgO1xuZnVuY3Rpb24gY3JlYXRlUmVuZGVyZXIob3B0aW9ucykge1xuICByZXR1cm4gYmFzZUNyZWF0ZVJlbmRlcmVyKG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gY3JlYXRlSHlkcmF0aW9uUmVuZGVyZXIob3B0aW9ucykge1xuICByZXR1cm4gYmFzZUNyZWF0ZVJlbmRlcmVyKG9wdGlvbnMsIGNyZWF0ZUh5ZHJhdGlvbkZ1bmN0aW9ucyk7XG59XG5mdW5jdGlvbiBiYXNlQ3JlYXRlUmVuZGVyZXIob3B0aW9ucywgY3JlYXRlSHlkcmF0aW9uRm5zKSB7XG4gIHtcbiAgICBpbml0RmVhdHVyZUZsYWdzKCk7XG4gIH1cbiAgY29uc3QgdGFyZ2V0ID0gZ2V0R2xvYmFsVGhpcygpO1xuICB0YXJnZXQuX19WVUVfXyA9IHRydWU7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgIHNldERldnRvb2xzSG9vayQxKHRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fLCB0YXJnZXQpO1xuICB9XG4gIGNvbnN0IHtcbiAgICBpbnNlcnQ6IGhvc3RJbnNlcnQsXG4gICAgcmVtb3ZlOiBob3N0UmVtb3ZlLFxuICAgIHBhdGNoUHJvcDogaG9zdFBhdGNoUHJvcCxcbiAgICBjcmVhdGVFbGVtZW50OiBob3N0Q3JlYXRlRWxlbWVudCxcbiAgICBjcmVhdGVUZXh0OiBob3N0Q3JlYXRlVGV4dCxcbiAgICBjcmVhdGVDb21tZW50OiBob3N0Q3JlYXRlQ29tbWVudCxcbiAgICBzZXRUZXh0OiBob3N0U2V0VGV4dCxcbiAgICBzZXRFbGVtZW50VGV4dDogaG9zdFNldEVsZW1lbnRUZXh0LFxuICAgIHBhcmVudE5vZGU6IGhvc3RQYXJlbnROb2RlLFxuICAgIG5leHRTaWJsaW5nOiBob3N0TmV4dFNpYmxpbmcsXG4gICAgc2V0U2NvcGVJZDogaG9zdFNldFNjb3BlSWQgPSBOT09QLFxuICAgIGluc2VydFN0YXRpY0NvbnRlbnQ6IGhvc3RJbnNlcnRTdGF0aWNDb250ZW50XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBwYXRjaCA9IChuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yID0gbnVsbCwgcGFyZW50Q29tcG9uZW50ID0gbnVsbCwgcGFyZW50U3VzcGVuc2UgPSBudWxsLCBuYW1lc3BhY2UgPSB2b2lkIDAsIHNsb3RTY29wZUlkcyA9IG51bGwsIG9wdGltaXplZCA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaXNIbXJVcGRhdGluZyA/IGZhbHNlIDogISFuMi5keW5hbWljQ2hpbGRyZW4pID0+IHtcbiAgICBpZiAobjEgPT09IG4yKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChuMSAmJiAhaXNTYW1lVk5vZGVUeXBlKG4xLCBuMikpIHtcbiAgICAgIGFuY2hvciA9IGdldE5leHRIb3N0Tm9kZShuMSk7XG4gICAgICB1bm1vdW50KG4xLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCB0cnVlKTtcbiAgICAgIG4xID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKG4yLnBhdGNoRmxhZyA9PT0gLTIpIHtcbiAgICAgIG9wdGltaXplZCA9IGZhbHNlO1xuICAgICAgbjIuZHluYW1pY0NoaWxkcmVuID0gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgeyB0eXBlLCByZWYsIHNoYXBlRmxhZyB9ID0gbjI7XG4gICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICBjYXNlIFRleHQ6XG4gICAgICAgIHByb2Nlc3NUZXh0KG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgQ29tbWVudDpcbiAgICAgICAgcHJvY2Vzc0NvbW1lbnROb2RlKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgU3RhdGljOlxuICAgICAgICBpZiAobjEgPT0gbnVsbCkge1xuICAgICAgICAgIG1vdW50U3RhdGljTm9kZShuMiwgY29udGFpbmVyLCBhbmNob3IsIG5hbWVzcGFjZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHBhdGNoU3RhdGljTm9kZShuMSwgbjIsIGNvbnRhaW5lciwgbmFtZXNwYWNlKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgRnJhZ21lbnQ6XG4gICAgICAgIHByb2Nlc3NGcmFnbWVudChcbiAgICAgICAgICBuMSxcbiAgICAgICAgICBuMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGlmIChzaGFwZUZsYWcgJiAxKSB7XG4gICAgICAgICAgcHJvY2Vzc0VsZW1lbnQoXG4gICAgICAgICAgICBuMSxcbiAgICAgICAgICAgIG4yLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2UgaWYgKHNoYXBlRmxhZyAmIDYpIHtcbiAgICAgICAgICBwcm9jZXNzQ29tcG9uZW50KFxuICAgICAgICAgICAgbjEsXG4gICAgICAgICAgICBuMixcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmIChzaGFwZUZsYWcgJiA2NCkge1xuICAgICAgICAgIHR5cGUucHJvY2VzcyhcbiAgICAgICAgICAgIG4xLFxuICAgICAgICAgICAgbjIsXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgIG9wdGltaXplZCxcbiAgICAgICAgICAgIGludGVybmFsc1xuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSBpZiAoc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgICAgICAgdHlwZS5wcm9jZXNzKFxuICAgICAgICAgICAgbjEsXG4gICAgICAgICAgICBuMixcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkLFxuICAgICAgICAgICAgaW50ZXJuYWxzXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgd2FybiQxKFwiSW52YWxpZCBWTm9kZSB0eXBlOlwiLCB0eXBlLCBgKCR7dHlwZW9mIHR5cGV9KWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChyZWYgIT0gbnVsbCAmJiBwYXJlbnRDb21wb25lbnQpIHtcbiAgICAgIHNldFJlZihyZWYsIG4xICYmIG4xLnJlZiwgcGFyZW50U3VzcGVuc2UsIG4yIHx8IG4xLCAhbjIpO1xuICAgIH0gZWxzZSBpZiAocmVmID09IG51bGwgJiYgbjEgJiYgbjEucmVmICE9IG51bGwpIHtcbiAgICAgIHNldFJlZihuMS5yZWYsIG51bGwsIHBhcmVudFN1c3BlbnNlLCBuMSwgdHJ1ZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCBwcm9jZXNzVGV4dCA9IChuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yKSA9PiB7XG4gICAgaWYgKG4xID09IG51bGwpIHtcbiAgICAgIGhvc3RJbnNlcnQoXG4gICAgICAgIG4yLmVsID0gaG9zdENyZWF0ZVRleHQobjIuY2hpbGRyZW4pLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIGFuY2hvclxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgZWwgPSBuMi5lbCA9IG4xLmVsO1xuICAgICAgaWYgKG4yLmNoaWxkcmVuICE9PSBuMS5jaGlsZHJlbikge1xuICAgICAgICBob3N0U2V0VGV4dChlbCwgbjIuY2hpbGRyZW4pO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgcHJvY2Vzc0NvbW1lbnROb2RlID0gKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IpID0+IHtcbiAgICBpZiAobjEgPT0gbnVsbCkge1xuICAgICAgaG9zdEluc2VydChcbiAgICAgICAgbjIuZWwgPSBob3N0Q3JlYXRlQ29tbWVudChuMi5jaGlsZHJlbiB8fCBcIlwiKSxcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3JcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG4yLmVsID0gbjEuZWw7XG4gICAgfVxuICB9O1xuICBjb25zdCBtb3VudFN0YXRpY05vZGUgPSAobjIsIGNvbnRhaW5lciwgYW5jaG9yLCBuYW1lc3BhY2UpID0+IHtcbiAgICBbbjIuZWwsIG4yLmFuY2hvcl0gPSBob3N0SW5zZXJ0U3RhdGljQ29udGVudChcbiAgICAgIG4yLmNoaWxkcmVuLFxuICAgICAgY29udGFpbmVyLFxuICAgICAgYW5jaG9yLFxuICAgICAgbmFtZXNwYWNlLFxuICAgICAgbjIuZWwsXG4gICAgICBuMi5hbmNob3JcbiAgICApO1xuICB9O1xuICBjb25zdCBwYXRjaFN0YXRpY05vZGUgPSAobjEsIG4yLCBjb250YWluZXIsIG5hbWVzcGFjZSkgPT4ge1xuICAgIGlmIChuMi5jaGlsZHJlbiAhPT0gbjEuY2hpbGRyZW4pIHtcbiAgICAgIGNvbnN0IGFuY2hvciA9IGhvc3ROZXh0U2libGluZyhuMS5hbmNob3IpO1xuICAgICAgcmVtb3ZlU3RhdGljTm9kZShuMSk7XG4gICAgICBbbjIuZWwsIG4yLmFuY2hvcl0gPSBob3N0SW5zZXJ0U3RhdGljQ29udGVudChcbiAgICAgICAgbjIuY2hpbGRyZW4sXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgYW5jaG9yLFxuICAgICAgICBuYW1lc3BhY2VcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG4yLmVsID0gbjEuZWw7XG4gICAgICBuMi5hbmNob3IgPSBuMS5hbmNob3I7XG4gICAgfVxuICB9O1xuICBjb25zdCBtb3ZlU3RhdGljTm9kZSA9ICh7IGVsLCBhbmNob3IgfSwgY29udGFpbmVyLCBuZXh0U2libGluZykgPT4ge1xuICAgIGxldCBuZXh0O1xuICAgIHdoaWxlIChlbCAmJiBlbCAhPT0gYW5jaG9yKSB7XG4gICAgICBuZXh0ID0gaG9zdE5leHRTaWJsaW5nKGVsKTtcbiAgICAgIGhvc3RJbnNlcnQoZWwsIGNvbnRhaW5lciwgbmV4dFNpYmxpbmcpO1xuICAgICAgZWwgPSBuZXh0O1xuICAgIH1cbiAgICBob3N0SW5zZXJ0KGFuY2hvciwgY29udGFpbmVyLCBuZXh0U2libGluZyk7XG4gIH07XG4gIGNvbnN0IHJlbW92ZVN0YXRpY05vZGUgPSAoeyBlbCwgYW5jaG9yIH0pID0+IHtcbiAgICBsZXQgbmV4dDtcbiAgICB3aGlsZSAoZWwgJiYgZWwgIT09IGFuY2hvcikge1xuICAgICAgbmV4dCA9IGhvc3ROZXh0U2libGluZyhlbCk7XG4gICAgICBob3N0UmVtb3ZlKGVsKTtcbiAgICAgIGVsID0gbmV4dDtcbiAgICB9XG4gICAgaG9zdFJlbW92ZShhbmNob3IpO1xuICB9O1xuICBjb25zdCBwcm9jZXNzRWxlbWVudCA9IChuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkKSA9PiB7XG4gICAgaWYgKG4yLnR5cGUgPT09IFwic3ZnXCIpIHtcbiAgICAgIG5hbWVzcGFjZSA9IFwic3ZnXCI7XG4gICAgfSBlbHNlIGlmIChuMi50eXBlID09PSBcIm1hdGhcIikge1xuICAgICAgbmFtZXNwYWNlID0gXCJtYXRobWxcIjtcbiAgICB9XG4gICAgaWYgKG4xID09IG51bGwpIHtcbiAgICAgIG1vdW50RWxlbWVudChcbiAgICAgICAgbjIsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgYW5jaG9yLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBjdXN0b21FbGVtZW50ID0gbjEuZWwgJiYgbjEuZWwuX2lzVnVlQ0UgPyBuMS5lbCA6IG51bGw7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoY3VzdG9tRWxlbWVudCkge1xuICAgICAgICAgIGN1c3RvbUVsZW1lbnQuX2JlZ2luUGF0Y2goKTtcbiAgICAgICAgfVxuICAgICAgICBwYXRjaEVsZW1lbnQoXG4gICAgICAgICAgbjEsXG4gICAgICAgICAgbjIsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoY3VzdG9tRWxlbWVudCkge1xuICAgICAgICAgIGN1c3RvbUVsZW1lbnQuX2VuZFBhdGNoKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGNvbnN0IG1vdW50RWxlbWVudCA9ICh2bm9kZSwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBsZXQgZWw7XG4gICAgbGV0IHZub2RlSG9vaztcbiAgICBjb25zdCB7IHByb3BzLCBzaGFwZUZsYWcsIHRyYW5zaXRpb24sIGRpcnMgfSA9IHZub2RlO1xuICAgIGVsID0gdm5vZGUuZWwgPSBob3N0Q3JlYXRlRWxlbWVudChcbiAgICAgIHZub2RlLnR5cGUsXG4gICAgICBuYW1lc3BhY2UsXG4gICAgICBwcm9wcyAmJiBwcm9wcy5pcyxcbiAgICAgIHByb3BzXG4gICAgKTtcbiAgICBpZiAoc2hhcGVGbGFnICYgOCkge1xuICAgICAgaG9zdFNldEVsZW1lbnRUZXh0KGVsLCB2bm9kZS5jaGlsZHJlbik7XG4gICAgfSBlbHNlIGlmIChzaGFwZUZsYWcgJiAxNikge1xuICAgICAgbW91bnRDaGlsZHJlbihcbiAgICAgICAgdm5vZGUuY2hpbGRyZW4sXG4gICAgICAgIGVsLFxuICAgICAgICBudWxsLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICByZXNvbHZlQ2hpbGRyZW5OYW1lc3BhY2Uodm5vZGUsIG5hbWVzcGFjZSksXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoZGlycykge1xuICAgICAgaW52b2tlRGlyZWN0aXZlSG9vayh2bm9kZSwgbnVsbCwgcGFyZW50Q29tcG9uZW50LCBcImNyZWF0ZWRcIik7XG4gICAgfVxuICAgIHNldFNjb3BlSWQoZWwsIHZub2RlLCB2bm9kZS5zY29wZUlkLCBzbG90U2NvcGVJZHMsIHBhcmVudENvbXBvbmVudCk7XG4gICAgaWYgKHByb3BzKSB7XG4gICAgICBmb3IgKGNvbnN0IGtleSBpbiBwcm9wcykge1xuICAgICAgICBpZiAoa2V5ICE9PSBcInZhbHVlXCIgJiYgIWlzUmVzZXJ2ZWRQcm9wKGtleSkpIHtcbiAgICAgICAgICBob3N0UGF0Y2hQcm9wKGVsLCBrZXksIG51bGwsIHByb3BzW2tleV0sIG5hbWVzcGFjZSwgcGFyZW50Q29tcG9uZW50KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKFwidmFsdWVcIiBpbiBwcm9wcykge1xuICAgICAgICBob3N0UGF0Y2hQcm9wKGVsLCBcInZhbHVlXCIsIG51bGwsIHByb3BzLnZhbHVlLCBuYW1lc3BhY2UpO1xuICAgICAgfVxuICAgICAgaWYgKHZub2RlSG9vayA9IHByb3BzLm9uVm5vZGVCZWZvcmVNb3VudCkge1xuICAgICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnRDb21wb25lbnQsIHZub2RlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICBkZWYoZWwsIFwiX192bm9kZVwiLCB2bm9kZSwgdHJ1ZSk7XG4gICAgICBkZWYoZWwsIFwiX192dWVQYXJlbnRDb21wb25lbnRcIiwgcGFyZW50Q29tcG9uZW50LCB0cnVlKTtcbiAgICB9XG4gICAgaWYgKGRpcnMpIHtcbiAgICAgIGludm9rZURpcmVjdGl2ZUhvb2sodm5vZGUsIG51bGwsIHBhcmVudENvbXBvbmVudCwgXCJiZWZvcmVNb3VudFwiKTtcbiAgICB9XG4gICAgY29uc3QgbmVlZENhbGxUcmFuc2l0aW9uSG9va3MgPSBuZWVkVHJhbnNpdGlvbihwYXJlbnRTdXNwZW5zZSwgdHJhbnNpdGlvbik7XG4gICAgaWYgKG5lZWRDYWxsVHJhbnNpdGlvbkhvb2tzKSB7XG4gICAgICB0cmFuc2l0aW9uLmJlZm9yZUVudGVyKGVsKTtcbiAgICB9XG4gICAgaG9zdEluc2VydChlbCwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgIGlmICgodm5vZGVIb29rID0gcHJvcHMgJiYgcHJvcHMub25Wbm9kZU1vdW50ZWQpIHx8IG5lZWRDYWxsVHJhbnNpdGlvbkhvb2tzIHx8IGRpcnMpIHtcbiAgICAgIGNvbnN0IGlzSG1yID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpc0htclVwZGF0aW5nO1xuICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHtcbiAgICAgICAgbGV0IHByZXY7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSBwcmV2ID0gc2V0SG1yVXBkYXRpbmcoaXNIbXIpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHZub2RlSG9vayAmJiBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnRDb21wb25lbnQsIHZub2RlKTtcbiAgICAgICAgICBuZWVkQ2FsbFRyYW5zaXRpb25Ib29rcyAmJiB0cmFuc2l0aW9uLmVudGVyKGVsKTtcbiAgICAgICAgICBkaXJzICYmIGludm9rZURpcmVjdGl2ZUhvb2sodm5vZGUsIG51bGwsIHBhcmVudENvbXBvbmVudCwgXCJtb3VudGVkXCIpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSBzZXRIbXJVcGRhdGluZyhwcmV2KTtcbiAgICAgICAgfVxuICAgICAgfSwgcGFyZW50U3VzcGVuc2UpO1xuICAgIH1cbiAgfTtcbiAgY29uc3Qgc2V0U2NvcGVJZCA9IChlbCwgdm5vZGUsIHNjb3BlSWQsIHNsb3RTY29wZUlkcywgcGFyZW50Q29tcG9uZW50KSA9PiB7XG4gICAgaWYgKHNjb3BlSWQpIHtcbiAgICAgIGhvc3RTZXRTY29wZUlkKGVsLCBzY29wZUlkKTtcbiAgICB9XG4gICAgaWYgKHNsb3RTY29wZUlkcykge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzbG90U2NvcGVJZHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaG9zdFNldFNjb3BlSWQoZWwsIHNsb3RTY29wZUlkc1tpXSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChwYXJlbnRDb21wb25lbnQpIHtcbiAgICAgIGxldCBzdWJUcmVlID0gcGFyZW50Q29tcG9uZW50LnN1YlRyZWU7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBzdWJUcmVlLnBhdGNoRmxhZyA+IDAgJiYgc3ViVHJlZS5wYXRjaEZsYWcgJiAyMDQ4KSB7XG4gICAgICAgIHN1YlRyZWUgPSBmaWx0ZXJTaW5nbGVSb290KHN1YlRyZWUuY2hpbGRyZW4pIHx8IHN1YlRyZWU7XG4gICAgICB9XG4gICAgICBpZiAodm5vZGUgPT09IHN1YlRyZWUgfHwgaXNTdXNwZW5zZShzdWJUcmVlLnR5cGUpICYmIChzdWJUcmVlLnNzQ29udGVudCA9PT0gdm5vZGUgfHwgc3ViVHJlZS5zc0ZhbGxiYWNrID09PSB2bm9kZSkpIHtcbiAgICAgICAgY29uc3QgcGFyZW50Vk5vZGUgPSBwYXJlbnRDb21wb25lbnQudm5vZGU7XG4gICAgICAgIHNldFNjb3BlSWQoXG4gICAgICAgICAgZWwsXG4gICAgICAgICAgcGFyZW50Vk5vZGUsXG4gICAgICAgICAgcGFyZW50Vk5vZGUuc2NvcGVJZCxcbiAgICAgICAgICBwYXJlbnRWTm9kZS5zbG90U2NvcGVJZHMsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LnBhcmVudFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgbW91bnRDaGlsZHJlbiA9IChjaGlsZHJlbiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQsIHN0YXJ0ID0gMCkgPT4ge1xuICAgIGZvciAobGV0IGkgPSBzdGFydDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBjaGlsZCA9IGNoaWxkcmVuW2ldID0gb3B0aW1pemVkID8gY2xvbmVJZk1vdW50ZWQoY2hpbGRyZW5baV0pIDogbm9ybWFsaXplVk5vZGUoY2hpbGRyZW5baV0pO1xuICAgICAgcGF0Y2goXG4gICAgICAgIG51bGwsXG4gICAgICAgIGNoaWxkLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIGFuY2hvcixcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIG9wdGltaXplZFxuICAgICAgKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHBhdGNoRWxlbWVudCA9IChuMSwgbjIsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBjb25zdCBlbCA9IG4yLmVsID0gbjEuZWw7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICBlbC5fX3Zub2RlID0gbjI7XG4gICAgfVxuICAgIGxldCB7IHBhdGNoRmxhZywgZHluYW1pY0NoaWxkcmVuLCBkaXJzIH0gPSBuMjtcbiAgICBwYXRjaEZsYWcgfD0gbjEucGF0Y2hGbGFnICYgMTY7XG4gICAgY29uc3Qgb2xkUHJvcHMgPSBuMS5wcm9wcyB8fCBFTVBUWV9PQko7XG4gICAgY29uc3QgbmV3UHJvcHMgPSBuMi5wcm9wcyB8fCBFTVBUWV9PQko7XG4gICAgbGV0IHZub2RlSG9vaztcbiAgICBwYXJlbnRDb21wb25lbnQgJiYgdG9nZ2xlUmVjdXJzZShwYXJlbnRDb21wb25lbnQsIGZhbHNlKTtcbiAgICBpZiAodm5vZGVIb29rID0gbmV3UHJvcHMub25Wbm9kZUJlZm9yZVVwZGF0ZSkge1xuICAgICAgaW52b2tlVk5vZGVIb29rKHZub2RlSG9vaywgcGFyZW50Q29tcG9uZW50LCBuMiwgbjEpO1xuICAgIH1cbiAgICBpZiAoZGlycykge1xuICAgICAgaW52b2tlRGlyZWN0aXZlSG9vayhuMiwgbjEsIHBhcmVudENvbXBvbmVudCwgXCJiZWZvcmVVcGRhdGVcIik7XG4gICAgfVxuICAgIHBhcmVudENvbXBvbmVudCAmJiB0b2dnbGVSZWN1cnNlKHBhcmVudENvbXBvbmVudCwgdHJ1ZSk7XG4gICAgaWYgKFxuICAgICAgLy8gSE1SIHVwZGF0ZWQsIGZvcmNlIGZ1bGwgZGlmZlxuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpc0htclVwZGF0aW5nIHx8IC8vICM2Mzg1IHRoZSBvbGQgdm5vZGUgbWF5IGJlIGEgdXNlci13cmFwcGVkIG5vbi1pc29tb3JwaGljIGJsb2NrXG4gICAgICAvLyBGb3JjZSBmdWxsIGRpZmYgd2hlbiBibG9jayBtZXRhZGF0YSBpcyB1bnN0YWJsZS5cbiAgICAgIGR5bmFtaWNDaGlsZHJlbiAmJiAoIW4xLmR5bmFtaWNDaGlsZHJlbiB8fCBuMS5keW5hbWljQ2hpbGRyZW4ubGVuZ3RoICE9PSBkeW5hbWljQ2hpbGRyZW4ubGVuZ3RoKVxuICAgICkge1xuICAgICAgcGF0Y2hGbGFnID0gMDtcbiAgICAgIG9wdGltaXplZCA9IGZhbHNlO1xuICAgICAgZHluYW1pY0NoaWxkcmVuID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKG9sZFByb3BzLmlubmVySFRNTCAmJiBuZXdQcm9wcy5pbm5lckhUTUwgPT0gbnVsbCB8fCBvbGRQcm9wcy50ZXh0Q29udGVudCAmJiBuZXdQcm9wcy50ZXh0Q29udGVudCA9PSBudWxsKSB7XG4gICAgICBob3N0U2V0RWxlbWVudFRleHQoZWwsIFwiXCIpO1xuICAgIH1cbiAgICBpZiAoZHluYW1pY0NoaWxkcmVuKSB7XG4gICAgICBwYXRjaEJsb2NrQ2hpbGRyZW4oXG4gICAgICAgIG4xLmR5bmFtaWNDaGlsZHJlbixcbiAgICAgICAgZHluYW1pY0NoaWxkcmVuLFxuICAgICAgICBlbCxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgcmVzb2x2ZUNoaWxkcmVuTmFtZXNwYWNlKG4yLCBuYW1lc3BhY2UpLFxuICAgICAgICBzbG90U2NvcGVJZHNcbiAgICAgICk7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICB0cmF2ZXJzZVN0YXRpY0NoaWxkcmVuKG4xLCBuMik7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghb3B0aW1pemVkKSB7XG4gICAgICBwYXRjaENoaWxkcmVuKFxuICAgICAgICBuMSxcbiAgICAgICAgbjIsXG4gICAgICAgIGVsLFxuICAgICAgICBudWxsLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICByZXNvbHZlQ2hpbGRyZW5OYW1lc3BhY2UobjIsIG5hbWVzcGFjZSksXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgZmFsc2VcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChwYXRjaEZsYWcgPiAwKSB7XG4gICAgICBpZiAocGF0Y2hGbGFnICYgMTYpIHtcbiAgICAgICAgcGF0Y2hQcm9wcyhlbCwgb2xkUHJvcHMsIG5ld1Byb3BzLCBwYXJlbnRDb21wb25lbnQsIG5hbWVzcGFjZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAocGF0Y2hGbGFnICYgMikge1xuICAgICAgICAgIGlmIChvbGRQcm9wcy5jbGFzcyAhPT0gbmV3UHJvcHMuY2xhc3MpIHtcbiAgICAgICAgICAgIGhvc3RQYXRjaFByb3AoZWwsIFwiY2xhc3NcIiwgbnVsbCwgbmV3UHJvcHMuY2xhc3MsIG5hbWVzcGFjZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChwYXRjaEZsYWcgJiA0KSB7XG4gICAgICAgICAgaG9zdFBhdGNoUHJvcChlbCwgXCJzdHlsZVwiLCBvbGRQcm9wcy5zdHlsZSwgbmV3UHJvcHMuc3R5bGUsIG5hbWVzcGFjZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBhdGNoRmxhZyAmIDgpIHtcbiAgICAgICAgICBjb25zdCBwcm9wc1RvVXBkYXRlID0gbjIuZHluYW1pY1Byb3BzO1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvcHNUb1VwZGF0ZS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qga2V5ID0gcHJvcHNUb1VwZGF0ZVtpXTtcbiAgICAgICAgICAgIGNvbnN0IHByZXYgPSBvbGRQcm9wc1trZXldO1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ld1Byb3BzW2tleV07XG4gICAgICAgICAgICBpZiAobmV4dCAhPT0gcHJldiB8fCBrZXkgPT09IFwidmFsdWVcIikge1xuICAgICAgICAgICAgICBob3N0UGF0Y2hQcm9wKGVsLCBrZXksIHByZXYsIG5leHQsIG5hbWVzcGFjZSwgcGFyZW50Q29tcG9uZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChwYXRjaEZsYWcgJiAxKSB7XG4gICAgICAgIGlmIChuMS5jaGlsZHJlbiAhPT0gbjIuY2hpbGRyZW4pIHtcbiAgICAgICAgICBob3N0U2V0RWxlbWVudFRleHQoZWwsIG4yLmNoaWxkcmVuKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoIW9wdGltaXplZCAmJiBkeW5hbWljQ2hpbGRyZW4gPT0gbnVsbCkge1xuICAgICAgcGF0Y2hQcm9wcyhlbCwgb2xkUHJvcHMsIG5ld1Byb3BzLCBwYXJlbnRDb21wb25lbnQsIG5hbWVzcGFjZSk7XG4gICAgfVxuICAgIGlmICgodm5vZGVIb29rID0gbmV3UHJvcHMub25Wbm9kZVVwZGF0ZWQpIHx8IGRpcnMpIHtcbiAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHZub2RlSG9vayAmJiBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnRDb21wb25lbnQsIG4yLCBuMSk7XG4gICAgICAgIGRpcnMgJiYgaW52b2tlRGlyZWN0aXZlSG9vayhuMiwgbjEsIHBhcmVudENvbXBvbmVudCwgXCJ1cGRhdGVkXCIpO1xuICAgICAgfSwgcGFyZW50U3VzcGVuc2UpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcGF0Y2hCbG9ja0NoaWxkcmVuID0gKG9sZENoaWxkcmVuLCBuZXdDaGlsZHJlbiwgZmFsbGJhY2tDb250YWluZXIsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzKSA9PiB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBuZXdDaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3Qgb2xkVk5vZGUgPSBvbGRDaGlsZHJlbltpXTtcbiAgICAgIGNvbnN0IG5ld1ZOb2RlID0gbmV3Q2hpbGRyZW5baV07XG4gICAgICBjb25zdCBjb250YWluZXIgPSAoXG4gICAgICAgIC8vIG9sZFZOb2RlIG1heSBiZSBhbiBlcnJvcmVkIGFzeW5jIHNldHVwKCkgY29tcG9uZW50IGluc2lkZSBTdXNwZW5zZVxuICAgICAgICAvLyB3aGljaCB3aWxsIG5vdCBoYXZlIGEgbW91bnRlZCBlbGVtZW50XG4gICAgICAgIG9sZFZOb2RlLmVsICYmIC8vIC0gSW4gdGhlIGNhc2Ugb2YgYSBGcmFnbWVudCwgd2UgbmVlZCB0byBwcm92aWRlIHRoZSBhY3R1YWwgcGFyZW50XG4gICAgICAgIC8vIG9mIHRoZSBGcmFnbWVudCBpdHNlbGYgc28gaXQgY2FuIG1vdmUgaXRzIGNoaWxkcmVuLlxuICAgICAgICAob2xkVk5vZGUudHlwZSA9PT0gRnJhZ21lbnQgfHwgLy8gLSBJbiB0aGUgY2FzZSBvZiBkaWZmZXJlbnQgbm9kZXMsIHRoZXJlIGlzIGdvaW5nIHRvIGJlIGEgcmVwbGFjZW1lbnRcbiAgICAgICAgLy8gd2hpY2ggYWxzbyByZXF1aXJlcyB0aGUgY29ycmVjdCBwYXJlbnQgY29udGFpbmVyXG4gICAgICAgICFpc1NhbWVWTm9kZVR5cGUob2xkVk5vZGUsIG5ld1ZOb2RlKSB8fCAvLyAtIEluIHRoZSBjYXNlIG9mIGEgY29tcG9uZW50LCBpdCBjb3VsZCBjb250YWluIGFueXRoaW5nLlxuICAgICAgICBvbGRWTm9kZS5zaGFwZUZsYWcgJiAoNiB8IDY0IHwgMTI4KSkgPyBob3N0UGFyZW50Tm9kZShvbGRWTm9kZS5lbCkgOiAoXG4gICAgICAgICAgLy8gSW4gb3RoZXIgY2FzZXMsIHRoZSBwYXJlbnQgY29udGFpbmVyIGlzIG5vdCBhY3R1YWxseSB1c2VkIHNvIHdlXG4gICAgICAgICAgLy8ganVzdCBwYXNzIHRoZSBibG9jayBlbGVtZW50IGhlcmUgdG8gYXZvaWQgYSBET00gcGFyZW50Tm9kZSBjYWxsLlxuICAgICAgICAgIGZhbGxiYWNrQ29udGFpbmVyXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgICBwYXRjaChcbiAgICAgICAgb2xkVk5vZGUsXG4gICAgICAgIG5ld1ZOb2RlLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIG51bGwsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICB0cnVlXG4gICAgICApO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcGF0Y2hQcm9wcyA9IChlbCwgb2xkUHJvcHMsIG5ld1Byb3BzLCBwYXJlbnRDb21wb25lbnQsIG5hbWVzcGFjZSkgPT4ge1xuICAgIGlmIChvbGRQcm9wcyAhPT0gbmV3UHJvcHMpIHtcbiAgICAgIGlmIChvbGRQcm9wcyAhPT0gRU1QVFlfT0JKKSB7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IGluIG9sZFByb3BzKSB7XG4gICAgICAgICAgaWYgKCFpc1Jlc2VydmVkUHJvcChrZXkpICYmICEoa2V5IGluIG5ld1Byb3BzKSkge1xuICAgICAgICAgICAgaG9zdFBhdGNoUHJvcChcbiAgICAgICAgICAgICAgZWwsXG4gICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgb2xkUHJvcHNba2V5XSxcbiAgICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgICBwYXJlbnRDb21wb25lbnRcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGtleSBpbiBuZXdQcm9wcykge1xuICAgICAgICBpZiAoaXNSZXNlcnZlZFByb3Aoa2V5KSkgY29udGludWU7XG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXdQcm9wc1trZXldO1xuICAgICAgICBjb25zdCBwcmV2ID0gb2xkUHJvcHNba2V5XTtcbiAgICAgICAgaWYgKG5leHQgIT09IHByZXYgJiYga2V5ICE9PSBcInZhbHVlXCIpIHtcbiAgICAgICAgICBob3N0UGF0Y2hQcm9wKGVsLCBrZXksIHByZXYsIG5leHQsIG5hbWVzcGFjZSwgcGFyZW50Q29tcG9uZW50KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKFwidmFsdWVcIiBpbiBuZXdQcm9wcykge1xuICAgICAgICBob3N0UGF0Y2hQcm9wKGVsLCBcInZhbHVlXCIsIG9sZFByb3BzLnZhbHVlLCBuZXdQcm9wcy52YWx1ZSwgbmFtZXNwYWNlKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGNvbnN0IHByb2Nlc3NGcmFnbWVudCA9IChuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkKSA9PiB7XG4gICAgY29uc3QgZnJhZ21lbnRTdGFydEFuY2hvciA9IG4yLmVsID0gbjEgPyBuMS5lbCA6IGhvc3RDcmVhdGVUZXh0KFwiXCIpO1xuICAgIGNvbnN0IGZyYWdtZW50RW5kQW5jaG9yID0gbjIuYW5jaG9yID0gbjEgPyBuMS5hbmNob3IgOiBob3N0Q3JlYXRlVGV4dChcIlwiKTtcbiAgICBsZXQgeyBwYXRjaEZsYWcsIGR5bmFtaWNDaGlsZHJlbiwgc2xvdFNjb3BlSWRzOiBmcmFnbWVudFNsb3RTY29wZUlkcyB9ID0gbjI7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgLy8gIzU1MjMgZGV2IHJvb3QgZnJhZ21lbnQgbWF5IGluaGVyaXQgZGlyZWN0aXZlc1xuICAgIChpc0htclVwZGF0aW5nIHx8IHBhdGNoRmxhZyAmIDIwNDgpKSB7XG4gICAgICBwYXRjaEZsYWcgPSAwO1xuICAgICAgb3B0aW1pemVkID0gZmFsc2U7XG4gICAgICBkeW5hbWljQ2hpbGRyZW4gPSBudWxsO1xuICAgIH1cbiAgICBpZiAoZnJhZ21lbnRTbG90U2NvcGVJZHMpIHtcbiAgICAgIHNsb3RTY29wZUlkcyA9IHNsb3RTY29wZUlkcyA/IHNsb3RTY29wZUlkcy5jb25jYXQoZnJhZ21lbnRTbG90U2NvcGVJZHMpIDogZnJhZ21lbnRTbG90U2NvcGVJZHM7XG4gICAgfVxuICAgIGlmIChuMSA9PSBudWxsKSB7XG4gICAgICBob3N0SW5zZXJ0KGZyYWdtZW50U3RhcnRBbmNob3IsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgIGhvc3RJbnNlcnQoZnJhZ21lbnRFbmRBbmNob3IsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgIG1vdW50Q2hpbGRyZW4oXG4gICAgICAgIC8vICMxMDAwN1xuICAgICAgICAvLyBzdWNoIGZyYWdtZW50IGxpa2UgYDw+PC8+YCB3aWxsIGJlIGNvbXBpbGVkIGludG9cbiAgICAgICAgLy8gYSBmcmFnbWVudCB3aGljaCBkb2Vzbid0IGhhdmUgYSBjaGlsZHJlbi5cbiAgICAgICAgLy8gSW4gdGhpcyBjYXNlIGZhbGxiYWNrIHRvIGFuIGVtcHR5IGFycmF5XG4gICAgICAgIG4yLmNoaWxkcmVuIHx8IFtdLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIGZyYWdtZW50RW5kQW5jaG9yLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAocGF0Y2hGbGFnID4gMCAmJiBwYXRjaEZsYWcgJiA2NCAmJiBkeW5hbWljQ2hpbGRyZW4gJiYgLy8gIzI3MTUgdGhlIHByZXZpb3VzIGZyYWdtZW50IGNvdWxkJ3ZlIGJlZW4gYSBCQUlMZWQgb25lIGFzIGEgcmVzdWx0XG4gICAgICAvLyBvZiByZW5kZXJTbG90KCkgd2l0aCBubyB2YWxpZCBjaGlsZHJlblxuICAgICAgbjEuZHluYW1pY0NoaWxkcmVuICYmIG4xLmR5bmFtaWNDaGlsZHJlbi5sZW5ndGggPT09IGR5bmFtaWNDaGlsZHJlbi5sZW5ndGgpIHtcbiAgICAgICAgcGF0Y2hCbG9ja0NoaWxkcmVuKFxuICAgICAgICAgIG4xLmR5bmFtaWNDaGlsZHJlbixcbiAgICAgICAgICBkeW5hbWljQ2hpbGRyZW4sXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzXG4gICAgICAgICk7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgdHJhdmVyc2VTdGF0aWNDaGlsZHJlbihuMSwgbjIpO1xuICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgIC8vICMyMDgwIGlmIHRoZSBzdGFibGUgZnJhZ21lbnQgaGFzIGEga2V5LCBpdCdzIGEgPHRlbXBsYXRlIHYtZm9yPiB0aGF0IG1heVxuICAgICAgICAgIC8vICBnZXQgbW92ZWQgYXJvdW5kLiBNYWtlIHN1cmUgYWxsIHJvb3QgbGV2ZWwgdm5vZGVzIGluaGVyaXQgZWwuXG4gICAgICAgICAgLy8gIzIxMzQgb3IgaWYgaXQncyBhIGNvbXBvbmVudCByb290LCBpdCBtYXkgYWxzbyBnZXQgbW92ZWQgYXJvdW5kXG4gICAgICAgICAgLy8gYXMgdGhlIGNvbXBvbmVudCBpcyBiZWluZyBtb3ZlZC5cbiAgICAgICAgICBuMi5rZXkgIT0gbnVsbCB8fCBwYXJlbnRDb21wb25lbnQgJiYgbjIgPT09IHBhcmVudENvbXBvbmVudC5zdWJUcmVlXG4gICAgICAgICkge1xuICAgICAgICAgIHRyYXZlcnNlU3RhdGljQ2hpbGRyZW4oXG4gICAgICAgICAgICBuMSxcbiAgICAgICAgICAgIG4yLFxuICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgLyogc2hhbGxvdyAqL1xuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBhdGNoQ2hpbGRyZW4oXG4gICAgICAgICAgbjEsXG4gICAgICAgICAgbjIsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIGZyYWdtZW50RW5kQW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgcHJvY2Vzc0NvbXBvbmVudCA9IChuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkKSA9PiB7XG4gICAgbjIuc2xvdFNjb3BlSWRzID0gc2xvdFNjb3BlSWRzO1xuICAgIGlmIChuMSA9PSBudWxsKSB7XG4gICAgICBpZiAobjIuc2hhcGVGbGFnICYgNTEyKSB7XG4gICAgICAgIHBhcmVudENvbXBvbmVudC5jdHguYWN0aXZhdGUoXG4gICAgICAgICAgbjIsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBtb3VudENvbXBvbmVudChcbiAgICAgICAgICBuMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHVwZGF0ZUNvbXBvbmVudChuMSwgbjIsIG9wdGltaXplZCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBtb3VudENvbXBvbmVudCA9IChpbml0aWFsVk5vZGUsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIG9wdGltaXplZCkgPT4ge1xuICAgIGNvbnN0IGluc3RhbmNlID0gKGluaXRpYWxWTm9kZS5jb21wb25lbnQgPSBjcmVhdGVDb21wb25lbnRJbnN0YW5jZShcbiAgICAgIGluaXRpYWxWTm9kZSxcbiAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgIHBhcmVudFN1c3BlbnNlXG4gICAgKSk7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaW5zdGFuY2UudHlwZS5fX2htcklkKSB7XG4gICAgICByZWdpc3RlckhNUihpbnN0YW5jZSk7XG4gICAgfVxuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBwdXNoV2FybmluZ0NvbnRleHQoaW5pdGlhbFZOb2RlKTtcbiAgICAgIHN0YXJ0TWVhc3VyZShpbnN0YW5jZSwgYG1vdW50YCk7XG4gICAgfVxuICAgIGlmIChpc0tlZXBBbGl2ZShpbml0aWFsVk5vZGUpKSB7XG4gICAgICBpbnN0YW5jZS5jdHgucmVuZGVyZXIgPSBpbnRlcm5hbHM7XG4gICAgfVxuICAgIHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIHN0YXJ0TWVhc3VyZShpbnN0YW5jZSwgYGluaXRgKTtcbiAgICAgIH1cbiAgICAgIHNldHVwQ29tcG9uZW50KGluc3RhbmNlLCBmYWxzZSwgb3B0aW1pemVkKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGBpbml0YCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzSG1yVXBkYXRpbmcpIGluaXRpYWxWTm9kZS5lbCA9IG51bGw7XG4gICAgaWYgKGluc3RhbmNlLmFzeW5jRGVwKSB7XG4gICAgICBwYXJlbnRTdXNwZW5zZSAmJiBwYXJlbnRTdXNwZW5zZS5yZWdpc3RlckRlcChpbnN0YW5jZSwgc2V0dXBSZW5kZXJFZmZlY3QsIG9wdGltaXplZCk7XG4gICAgICBpZiAoIWluaXRpYWxWTm9kZS5lbCkge1xuICAgICAgICBjb25zdCBwbGFjZWhvbGRlciA9IGluc3RhbmNlLnN1YlRyZWUgPSBjcmVhdGVWTm9kZShDb21tZW50KTtcbiAgICAgICAgcHJvY2Vzc0NvbW1lbnROb2RlKG51bGwsIHBsYWNlaG9sZGVyLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICAgIGluaXRpYWxWTm9kZS5wbGFjZWhvbGRlciA9IHBsYWNlaG9sZGVyLmVsO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXR1cFJlbmRlckVmZmVjdChcbiAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgIGluaXRpYWxWTm9kZSxcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIG9wdGltaXplZFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHBvcFdhcm5pbmdDb250ZXh0KCk7XG4gICAgICBlbmRNZWFzdXJlKGluc3RhbmNlLCBgbW91bnRgKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHVwZGF0ZUNvbXBvbmVudCA9IChuMSwgbjIsIG9wdGltaXplZCkgPT4ge1xuICAgIGNvbnN0IGluc3RhbmNlID0gbjIuY29tcG9uZW50ID0gbjEuY29tcG9uZW50O1xuICAgIGlmIChzaG91bGRVcGRhdGVDb21wb25lbnQobjEsIG4yLCBvcHRpbWl6ZWQpKSB7XG4gICAgICBpZiAoaW5zdGFuY2UuYXN5bmNEZXAgJiYgIWluc3RhbmNlLmFzeW5jUmVzb2x2ZWQpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBwdXNoV2FybmluZ0NvbnRleHQobjIpO1xuICAgICAgICB9XG4gICAgICAgIHVwZGF0ZUNvbXBvbmVudFByZVJlbmRlcihpbnN0YW5jZSwgbjIsIG9wdGltaXplZCk7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgcG9wV2FybmluZ0NvbnRleHQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbnN0YW5jZS5uZXh0ID0gbjI7XG4gICAgICAgIGluc3RhbmNlLnVwZGF0ZSgpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBuMi5lbCA9IG4xLmVsO1xuICAgICAgaW5zdGFuY2Uudm5vZGUgPSBuMjtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHNldHVwUmVuZGVyRWZmZWN0ID0gKGluc3RhbmNlLCBpbml0aWFsVk5vZGUsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBjb25zdCBjb21wb25lbnRVcGRhdGVGbiA9ICgpID0+IHtcbiAgICAgIGlmICghaW5zdGFuY2UuaXNNb3VudGVkKSB7XG4gICAgICAgIGxldCB2bm9kZUhvb2s7XG4gICAgICAgIGNvbnN0IHsgZWwsIHByb3BzIH0gPSBpbml0aWFsVk5vZGU7XG4gICAgICAgIGNvbnN0IHsgYm0sIG0sIHBhcmVudCwgcm9vdCwgdHlwZSB9ID0gaW5zdGFuY2U7XG4gICAgICAgIGNvbnN0IGlzQXN5bmNXcmFwcGVyVk5vZGUgPSBpc0FzeW5jV3JhcHBlcihpbml0aWFsVk5vZGUpO1xuICAgICAgICB0b2dnbGVSZWN1cnNlKGluc3RhbmNlLCBmYWxzZSk7XG4gICAgICAgIGlmIChibSkge1xuICAgICAgICAgIGludm9rZUFycmF5Rm5zKGJtKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzQXN5bmNXcmFwcGVyVk5vZGUgJiYgKHZub2RlSG9vayA9IHByb3BzICYmIHByb3BzLm9uVm5vZGVCZWZvcmVNb3VudCkpIHtcbiAgICAgICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnQsIGluaXRpYWxWTm9kZSk7XG4gICAgICAgIH1cbiAgICAgICAgdG9nZ2xlUmVjdXJzZShpbnN0YW5jZSwgdHJ1ZSk7XG4gICAgICAgIGlmIChlbCAmJiBoeWRyYXRlTm9kZSkge1xuICAgICAgICAgIGNvbnN0IGh5ZHJhdGVTdWJUcmVlID0gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICAgICAgc3RhcnRNZWFzdXJlKGluc3RhbmNlLCBgcmVuZGVyYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpbnN0YW5jZS5zdWJUcmVlID0gcmVuZGVyQ29tcG9uZW50Um9vdChpbnN0YW5jZSk7XG4gICAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgICBlbmRNZWFzdXJlKGluc3RhbmNlLCBgcmVuZGVyYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgICBzdGFydE1lYXN1cmUoaW5zdGFuY2UsIGBoeWRyYXRlYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBoeWRyYXRlTm9kZShcbiAgICAgICAgICAgICAgZWwsXG4gICAgICAgICAgICAgIGluc3RhbmNlLnN1YlRyZWUsXG4gICAgICAgICAgICAgIGluc3RhbmNlLFxuICAgICAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICAgICAgbnVsbFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGBoeWRyYXRlYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgICBpZiAoaXNBc3luY1dyYXBwZXJWTm9kZSAmJiB0eXBlLl9fYXN5bmNIeWRyYXRlKSB7XG4gICAgICAgICAgICB0eXBlLl9fYXN5bmNIeWRyYXRlKFxuICAgICAgICAgICAgICBlbCxcbiAgICAgICAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgICAgICAgIGh5ZHJhdGVTdWJUcmVlXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBoeWRyYXRlU3ViVHJlZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAocm9vdC5jZSAmJiByb290LmNlLl9oYXNTaGFkb3dSb290KCkpIHtcbiAgICAgICAgICAgIHJvb3QuY2UuX2luamVjdENoaWxkU3R5bGUoXG4gICAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICAgIGluc3RhbmNlLnBhcmVudCA/IGluc3RhbmNlLnBhcmVudC50eXBlIDogdm9pZCAwXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgc3RhcnRNZWFzdXJlKGluc3RhbmNlLCBgcmVuZGVyYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHN1YlRyZWUgPSBpbnN0YW5jZS5zdWJUcmVlID0gcmVuZGVyQ29tcG9uZW50Um9vdChpbnN0YW5jZSk7XG4gICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGByZW5kZXJgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICAgIHN0YXJ0TWVhc3VyZShpbnN0YW5jZSwgYHBhdGNoYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHBhdGNoKFxuICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgIHN1YlRyZWUsXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgZW5kTWVhc3VyZShpbnN0YW5jZSwgYHBhdGNoYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGluaXRpYWxWTm9kZS5lbCA9IHN1YlRyZWUuZWw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG0pIHtcbiAgICAgICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QobSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghaXNBc3luY1dyYXBwZXJWTm9kZSAmJiAodm5vZGVIb29rID0gcHJvcHMgJiYgcHJvcHMub25Wbm9kZU1vdW50ZWQpKSB7XG4gICAgICAgICAgY29uc3Qgc2NvcGVkSW5pdGlhbFZOb2RlID0gaW5pdGlhbFZOb2RlO1xuICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChcbiAgICAgICAgICAgICgpID0+IGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudCwgc2NvcGVkSW5pdGlhbFZOb2RlKSxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5pdGlhbFZOb2RlLnNoYXBlRmxhZyAmIDI1NiB8fCBwYXJlbnQgJiYgaXNBc3luY1dyYXBwZXIocGFyZW50LnZub2RlKSAmJiBwYXJlbnQudm5vZGUuc2hhcGVGbGFnICYgMjU2KSB7XG4gICAgICAgICAgaW5zdGFuY2UuYSAmJiBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QoaW5zdGFuY2UuYSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgICB9XG4gICAgICAgIGluc3RhbmNlLmlzTW91bnRlZCA9IHRydWU7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgICAgIGRldnRvb2xzQ29tcG9uZW50QWRkZWQoaW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICAgIGluaXRpYWxWTm9kZSA9IGNvbnRhaW5lciA9IGFuY2hvciA9IG51bGw7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZXQgeyBuZXh0LCBidSwgdSwgcGFyZW50LCB2bm9kZSB9ID0gaW5zdGFuY2U7XG4gICAgICAgIHtcbiAgICAgICAgICBjb25zdCBub25IeWRyYXRlZEFzeW5jUm9vdCA9IGxvY2F0ZU5vbkh5ZHJhdGVkQXN5bmNSb290KGluc3RhbmNlKTtcbiAgICAgICAgICBpZiAobm9uSHlkcmF0ZWRBc3luY1Jvb3QpIHtcbiAgICAgICAgICAgIGlmIChuZXh0KSB7XG4gICAgICAgICAgICAgIG5leHQuZWwgPSB2bm9kZS5lbDtcbiAgICAgICAgICAgICAgdXBkYXRlQ29tcG9uZW50UHJlUmVuZGVyKGluc3RhbmNlLCBuZXh0LCBvcHRpbWl6ZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbm9uSHlkcmF0ZWRBc3luY1Jvb3QuYXN5bmNEZXAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFpbnN0YW5jZS5pc1VubW91bnRlZCkgdXBkYXRlKCk7XG4gICAgICAgICAgICAgIH0sIHBhcmVudFN1c3BlbnNlKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBsZXQgb3JpZ2luTmV4dCA9IG5leHQ7XG4gICAgICAgIGxldCB2bm9kZUhvb2s7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgcHVzaFdhcm5pbmdDb250ZXh0KG5leHQgfHwgaW5zdGFuY2Uudm5vZGUpO1xuICAgICAgICB9XG4gICAgICAgIHRvZ2dsZVJlY3Vyc2UoaW5zdGFuY2UsIGZhbHNlKTtcbiAgICAgICAgaWYgKG5leHQpIHtcbiAgICAgICAgICBuZXh0LmVsID0gdm5vZGUuZWw7XG4gICAgICAgICAgdXBkYXRlQ29tcG9uZW50UHJlUmVuZGVyKGluc3RhbmNlLCBuZXh0LCBvcHRpbWl6ZWQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5leHQgPSB2bm9kZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYnUpIHtcbiAgICAgICAgICBpbnZva2VBcnJheUZucyhidSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZub2RlSG9vayA9IG5leHQucHJvcHMgJiYgbmV4dC5wcm9wcy5vblZub2RlQmVmb3JlVXBkYXRlKSB7XG4gICAgICAgICAgaW52b2tlVk5vZGVIb29rKHZub2RlSG9vaywgcGFyZW50LCBuZXh0LCB2bm9kZSk7XG4gICAgICAgIH1cbiAgICAgICAgdG9nZ2xlUmVjdXJzZShpbnN0YW5jZSwgdHJ1ZSk7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgc3RhcnRNZWFzdXJlKGluc3RhbmNlLCBgcmVuZGVyYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbmV4dFRyZWUgPSByZW5kZXJDb21wb25lbnRSb290KGluc3RhbmNlKTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBlbmRNZWFzdXJlKGluc3RhbmNlLCBgcmVuZGVyYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJldlRyZWUgPSBpbnN0YW5jZS5zdWJUcmVlO1xuICAgICAgICBpbnN0YW5jZS5zdWJUcmVlID0gbmV4dFRyZWU7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgc3RhcnRNZWFzdXJlKGluc3RhbmNlLCBgcGF0Y2hgKTtcbiAgICAgICAgfVxuICAgICAgICBwYXRjaChcbiAgICAgICAgICBwcmV2VHJlZSxcbiAgICAgICAgICBuZXh0VHJlZSxcbiAgICAgICAgICAvLyBwYXJlbnQgbWF5IGhhdmUgY2hhbmdlZCBpZiBpdCdzIGluIGEgdGVsZXBvcnRcbiAgICAgICAgICBob3N0UGFyZW50Tm9kZShwcmV2VHJlZS5lbCksXG4gICAgICAgICAgLy8gYW5jaG9yIG1heSBoYXZlIGNoYW5nZWQgaWYgaXQncyBpbiBhIGZyYWdtZW50XG4gICAgICAgICAgZ2V0TmV4dEhvc3ROb2RlKHByZXZUcmVlKSxcbiAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2VcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBlbmRNZWFzdXJlKGluc3RhbmNlLCBgcGF0Y2hgKTtcbiAgICAgICAgfVxuICAgICAgICBuZXh0LmVsID0gbmV4dFRyZWUuZWw7XG4gICAgICAgIGlmIChvcmlnaW5OZXh0ID09PSBudWxsKSB7XG4gICAgICAgICAgdXBkYXRlSE9DSG9zdEVsKGluc3RhbmNlLCBuZXh0VHJlZS5lbCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHUpIHtcbiAgICAgICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QodSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2bm9kZUhvb2sgPSBuZXh0LnByb3BzICYmIG5leHQucHJvcHMub25Wbm9kZVVwZGF0ZWQpIHtcbiAgICAgICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QoXG4gICAgICAgICAgICAoKSA9PiBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnQsIG5leHQsIHZub2RlKSxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgICAgICBkZXZ0b29sc0NvbXBvbmVudFVwZGF0ZWQoaW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgcG9wV2FybmluZ0NvbnRleHQoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgaW5zdGFuY2Uuc2NvcGUub24oKTtcbiAgICBjb25zdCBlZmZlY3QgPSBpbnN0YW5jZS5lZmZlY3QgPSBuZXcgUmVhY3RpdmVFZmZlY3QoY29tcG9uZW50VXBkYXRlRm4pO1xuICAgIGluc3RhbmNlLnNjb3BlLm9mZigpO1xuICAgIGNvbnN0IHVwZGF0ZSA9IGluc3RhbmNlLnVwZGF0ZSA9IGVmZmVjdC5ydW4uYmluZChlZmZlY3QpO1xuICAgIGNvbnN0IGpvYiA9IGluc3RhbmNlLmpvYiA9IGVmZmVjdC5ydW5JZkRpcnR5LmJpbmQoZWZmZWN0KTtcbiAgICBqb2IuaSA9IGluc3RhbmNlO1xuICAgIGpvYi5pZCA9IGluc3RhbmNlLnVpZDtcbiAgICBlZmZlY3Quc2NoZWR1bGVyID0gKCkgPT4gcXVldWVKb2Ioam9iKTtcbiAgICB0b2dnbGVSZWN1cnNlKGluc3RhbmNlLCB0cnVlKTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgZWZmZWN0Lm9uVHJhY2sgPSBpbnN0YW5jZS5ydGMgPyAoZSkgPT4gaW52b2tlQXJyYXlGbnMoaW5zdGFuY2UucnRjLCBlKSA6IHZvaWQgMDtcbiAgICAgIGVmZmVjdC5vblRyaWdnZXIgPSBpbnN0YW5jZS5ydGcgPyAoZSkgPT4gaW52b2tlQXJyYXlGbnMoaW5zdGFuY2UucnRnLCBlKSA6IHZvaWQgMDtcbiAgICB9XG4gICAgdXBkYXRlKCk7XG4gIH07XG4gIGNvbnN0IHVwZGF0ZUNvbXBvbmVudFByZVJlbmRlciA9IChpbnN0YW5jZSwgbmV4dFZOb2RlLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBuZXh0Vk5vZGUuY29tcG9uZW50ID0gaW5zdGFuY2U7XG4gICAgY29uc3QgcHJldlByb3BzID0gaW5zdGFuY2Uudm5vZGUucHJvcHM7XG4gICAgaW5zdGFuY2Uudm5vZGUgPSBuZXh0Vk5vZGU7XG4gICAgaW5zdGFuY2UubmV4dCA9IG51bGw7XG4gICAgdXBkYXRlUHJvcHMoaW5zdGFuY2UsIG5leHRWTm9kZS5wcm9wcywgcHJldlByb3BzLCBvcHRpbWl6ZWQpO1xuICAgIHVwZGF0ZVNsb3RzKGluc3RhbmNlLCBuZXh0Vk5vZGUuY2hpbGRyZW4sIG9wdGltaXplZCk7XG4gICAgcGF1c2VUcmFja2luZygpO1xuICAgIGZsdXNoUHJlRmx1c2hDYnMoaW5zdGFuY2UpO1xuICAgIHJlc2V0VHJhY2tpbmcoKTtcbiAgfTtcbiAgY29uc3QgcGF0Y2hDaGlsZHJlbiA9IChuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkID0gZmFsc2UpID0+IHtcbiAgICBjb25zdCBjMSA9IG4xICYmIG4xLmNoaWxkcmVuO1xuICAgIGNvbnN0IHByZXZTaGFwZUZsYWcgPSBuMSA/IG4xLnNoYXBlRmxhZyA6IDA7XG4gICAgY29uc3QgYzIgPSBuMi5jaGlsZHJlbjtcbiAgICBjb25zdCB7IHBhdGNoRmxhZywgc2hhcGVGbGFnIH0gPSBuMjtcbiAgICBpZiAocGF0Y2hGbGFnID4gMCkge1xuICAgICAgaWYgKHBhdGNoRmxhZyAmIDEyOCkge1xuICAgICAgICBwYXRjaEtleWVkQ2hpbGRyZW4oXG4gICAgICAgICAgYzEsXG4gICAgICAgICAgYzIsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIGlmIChwYXRjaEZsYWcgJiAyNTYpIHtcbiAgICAgICAgcGF0Y2hVbmtleWVkQ2hpbGRyZW4oXG4gICAgICAgICAgYzEsXG4gICAgICAgICAgYzIsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoc2hhcGVGbGFnICYgOCkge1xuICAgICAgaWYgKHByZXZTaGFwZUZsYWcgJiAxNikge1xuICAgICAgICB1bm1vdW50Q2hpbGRyZW4oYzEsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgfVxuICAgICAgaWYgKGMyICE9PSBjMSkge1xuICAgICAgICBob3N0U2V0RWxlbWVudFRleHQoY29udGFpbmVyLCBjMik7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChwcmV2U2hhcGVGbGFnICYgMTYpIHtcbiAgICAgICAgaWYgKHNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICAgICAgcGF0Y2hLZXllZENoaWxkcmVuKFxuICAgICAgICAgICAgYzEsXG4gICAgICAgICAgICBjMixcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB1bm1vdW50Q2hpbGRyZW4oYzEsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHRydWUpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAocHJldlNoYXBlRmxhZyAmIDgpIHtcbiAgICAgICAgICBob3N0U2V0RWxlbWVudFRleHQoY29udGFpbmVyLCBcIlwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc2hhcGVGbGFnICYgMTYpIHtcbiAgICAgICAgICBtb3VudENoaWxkcmVuKFxuICAgICAgICAgICAgYzIsXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGNvbnN0IHBhdGNoVW5rZXllZENoaWxkcmVuID0gKGMxLCBjMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBjMSA9IGMxIHx8IEVNUFRZX0FSUjtcbiAgICBjMiA9IGMyIHx8IEVNUFRZX0FSUjtcbiAgICBjb25zdCBvbGRMZW5ndGggPSBjMS5sZW5ndGg7XG4gICAgY29uc3QgbmV3TGVuZ3RoID0gYzIubGVuZ3RoO1xuICAgIGNvbnN0IGNvbW1vbkxlbmd0aCA9IE1hdGgubWluKG9sZExlbmd0aCwgbmV3TGVuZ3RoKTtcbiAgICBsZXQgaTtcbiAgICBmb3IgKGkgPSAwOyBpIDwgY29tbW9uTGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IG5leHRDaGlsZCA9IGMyW2ldID0gb3B0aW1pemVkID8gY2xvbmVJZk1vdW50ZWQoYzJbaV0pIDogbm9ybWFsaXplVk5vZGUoYzJbaV0pO1xuICAgICAgcGF0Y2goXG4gICAgICAgIGMxW2ldLFxuICAgICAgICBuZXh0Q2hpbGQsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgbnVsbCxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIG9wdGltaXplZFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKG9sZExlbmd0aCA+IG5ld0xlbmd0aCkge1xuICAgICAgdW5tb3VudENoaWxkcmVuKFxuICAgICAgICBjMSxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgdHJ1ZSxcbiAgICAgICAgZmFsc2UsXG4gICAgICAgIGNvbW1vbkxlbmd0aFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbW91bnRDaGlsZHJlbihcbiAgICAgICAgYzIsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgYW5jaG9yLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkLFxuICAgICAgICBjb21tb25MZW5ndGhcbiAgICAgICk7XG4gICAgfVxuICB9O1xuICBjb25zdCBwYXRjaEtleWVkQ2hpbGRyZW4gPSAoYzEsIGMyLCBjb250YWluZXIsIHBhcmVudEFuY2hvciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCkgPT4ge1xuICAgIGxldCBpID0gMDtcbiAgICBjb25zdCBsMiA9IGMyLmxlbmd0aDtcbiAgICBsZXQgZTEgPSBjMS5sZW5ndGggLSAxO1xuICAgIGxldCBlMiA9IGwyIC0gMTtcbiAgICB3aGlsZSAoaSA8PSBlMSAmJiBpIDw9IGUyKSB7XG4gICAgICBjb25zdCBuMSA9IGMxW2ldO1xuICAgICAgY29uc3QgbjIgPSBjMltpXSA9IG9wdGltaXplZCA/IGNsb25lSWZNb3VudGVkKGMyW2ldKSA6IG5vcm1hbGl6ZVZOb2RlKGMyW2ldKTtcbiAgICAgIGlmIChpc1NhbWVWTm9kZVR5cGUobjEsIG4yKSkge1xuICAgICAgICBwYXRjaChcbiAgICAgICAgICBuMSxcbiAgICAgICAgICBuMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgaSsrO1xuICAgIH1cbiAgICB3aGlsZSAoaSA8PSBlMSAmJiBpIDw9IGUyKSB7XG4gICAgICBjb25zdCBuMSA9IGMxW2UxXTtcbiAgICAgIGNvbnN0IG4yID0gYzJbZTJdID0gb3B0aW1pemVkID8gY2xvbmVJZk1vdW50ZWQoYzJbZTJdKSA6IG5vcm1hbGl6ZVZOb2RlKGMyW2UyXSk7XG4gICAgICBpZiAoaXNTYW1lVk5vZGVUeXBlKG4xLCBuMikpIHtcbiAgICAgICAgcGF0Y2goXG4gICAgICAgICAgbjEsXG4gICAgICAgICAgbjIsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGUxLS07XG4gICAgICBlMi0tO1xuICAgIH1cbiAgICBpZiAoaSA+IGUxKSB7XG4gICAgICBpZiAoaSA8PSBlMikge1xuICAgICAgICBjb25zdCBuZXh0UG9zID0gZTIgKyAxO1xuICAgICAgICBjb25zdCBhbmNob3IgPSBuZXh0UG9zIDwgbDIgPyBjMltuZXh0UG9zXS5lbCA6IHBhcmVudEFuY2hvcjtcbiAgICAgICAgd2hpbGUgKGkgPD0gZTIpIHtcbiAgICAgICAgICBwYXRjaChcbiAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICBjMltpXSA9IG9wdGltaXplZCA/IGNsb25lSWZNb3VudGVkKGMyW2ldKSA6IG5vcm1hbGl6ZVZOb2RlKGMyW2ldKSxcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpKys7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGkgPiBlMikge1xuICAgICAgd2hpbGUgKGkgPD0gZTEpIHtcbiAgICAgICAgdW5tb3VudChjMVtpXSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgdHJ1ZSk7XG4gICAgICAgIGkrKztcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgczEgPSBpO1xuICAgICAgY29uc3QgczIgPSBpO1xuICAgICAgY29uc3Qga2V5VG9OZXdJbmRleE1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgICBmb3IgKGkgPSBzMjsgaSA8PSBlMjsgaSsrKSB7XG4gICAgICAgIGNvbnN0IG5leHRDaGlsZCA9IGMyW2ldID0gb3B0aW1pemVkID8gY2xvbmVJZk1vdW50ZWQoYzJbaV0pIDogbm9ybWFsaXplVk5vZGUoYzJbaV0pO1xuICAgICAgICBpZiAobmV4dENoaWxkLmtleSAhPSBudWxsKSB7XG4gICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYga2V5VG9OZXdJbmRleE1hcC5oYXMobmV4dENoaWxkLmtleSkpIHtcbiAgICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgICAgYER1cGxpY2F0ZSBrZXlzIGZvdW5kIGR1cmluZyB1cGRhdGU6YCxcbiAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkobmV4dENoaWxkLmtleSksXG4gICAgICAgICAgICAgIGBNYWtlIHN1cmUga2V5cyBhcmUgdW5pcXVlLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGtleVRvTmV3SW5kZXhNYXAuc2V0KG5leHRDaGlsZC5rZXksIGkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBsZXQgajtcbiAgICAgIGxldCBwYXRjaGVkID0gMDtcbiAgICAgIGNvbnN0IHRvQmVQYXRjaGVkID0gZTIgLSBzMiArIDE7XG4gICAgICBsZXQgbW92ZWQgPSBmYWxzZTtcbiAgICAgIGxldCBtYXhOZXdJbmRleFNvRmFyID0gMDtcbiAgICAgIGNvbnN0IG5ld0luZGV4VG9PbGRJbmRleE1hcCA9IG5ldyBBcnJheSh0b0JlUGF0Y2hlZCk7XG4gICAgICBmb3IgKGkgPSAwOyBpIDwgdG9CZVBhdGNoZWQ7IGkrKykgbmV3SW5kZXhUb09sZEluZGV4TWFwW2ldID0gMDtcbiAgICAgIGZvciAoaSA9IHMxOyBpIDw9IGUxOyBpKyspIHtcbiAgICAgICAgY29uc3QgcHJldkNoaWxkID0gYzFbaV07XG4gICAgICAgIGlmIChwYXRjaGVkID49IHRvQmVQYXRjaGVkKSB7XG4gICAgICAgICAgdW5tb3VudChwcmV2Q2hpbGQsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHRydWUpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGxldCBuZXdJbmRleDtcbiAgICAgICAgaWYgKHByZXZDaGlsZC5rZXkgIT0gbnVsbCkge1xuICAgICAgICAgIG5ld0luZGV4ID0ga2V5VG9OZXdJbmRleE1hcC5nZXQocHJldkNoaWxkLmtleSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZm9yIChqID0gczI7IGogPD0gZTI7IGorKykge1xuICAgICAgICAgICAgaWYgKG5ld0luZGV4VG9PbGRJbmRleE1hcFtqIC0gczJdID09PSAwICYmIGlzU2FtZVZOb2RlVHlwZShwcmV2Q2hpbGQsIGMyW2pdKSkge1xuICAgICAgICAgICAgICBuZXdJbmRleCA9IGo7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAobmV3SW5kZXggPT09IHZvaWQgMCkge1xuICAgICAgICAgIHVubW91bnQocHJldkNoaWxkLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCB0cnVlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBuZXdJbmRleFRvT2xkSW5kZXhNYXBbbmV3SW5kZXggLSBzMl0gPSBpICsgMTtcbiAgICAgICAgICBpZiAobmV3SW5kZXggPj0gbWF4TmV3SW5kZXhTb0Zhcikge1xuICAgICAgICAgICAgbWF4TmV3SW5kZXhTb0ZhciA9IG5ld0luZGV4O1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBtb3ZlZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHBhdGNoKFxuICAgICAgICAgICAgcHJldkNoaWxkLFxuICAgICAgICAgICAgYzJbbmV3SW5kZXhdLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgKTtcbiAgICAgICAgICBwYXRjaGVkKys7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IGluY3JlYXNpbmdOZXdJbmRleFNlcXVlbmNlID0gbW92ZWQgPyBnZXRTZXF1ZW5jZShuZXdJbmRleFRvT2xkSW5kZXhNYXApIDogRU1QVFlfQVJSO1xuICAgICAgaiA9IGluY3JlYXNpbmdOZXdJbmRleFNlcXVlbmNlLmxlbmd0aCAtIDE7XG4gICAgICBmb3IgKGkgPSB0b0JlUGF0Y2hlZCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgIGNvbnN0IG5leHRJbmRleCA9IHMyICsgaTtcbiAgICAgICAgY29uc3QgbmV4dENoaWxkID0gYzJbbmV4dEluZGV4XTtcbiAgICAgICAgY29uc3QgYW5jaG9yVk5vZGUgPSBjMltuZXh0SW5kZXggKyAxXTtcbiAgICAgICAgY29uc3QgYW5jaG9yID0gbmV4dEluZGV4ICsgMSA8IGwyID8gKFxuICAgICAgICAgIC8vICMxMzU1OSwgIzE0MTczIGZhbGxiYWNrIHRvIGVsIHBsYWNlaG9sZGVyIGZvciB1bnJlc29sdmVkIGFzeW5jIGNvbXBvbmVudFxuICAgICAgICAgIGFuY2hvclZOb2RlLmVsIHx8IHJlc29sdmVBc3luY0NvbXBvbmVudFBsYWNlaG9sZGVyKGFuY2hvclZOb2RlKVxuICAgICAgICApIDogcGFyZW50QW5jaG9yO1xuICAgICAgICBpZiAobmV3SW5kZXhUb09sZEluZGV4TWFwW2ldID09PSAwKSB7XG4gICAgICAgICAgcGF0Y2goXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgbmV4dENoaWxkLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2UgaWYgKG1vdmVkKSB7XG4gICAgICAgICAgaWYgKGogPCAwIHx8IGkgIT09IGluY3JlYXNpbmdOZXdJbmRleFNlcXVlbmNlW2pdKSB7XG4gICAgICAgICAgICBtb3ZlKG5leHRDaGlsZCwgY29udGFpbmVyLCBhbmNob3IsIDIpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBqLS07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBjb25zdCBtb3ZlID0gKHZub2RlLCBjb250YWluZXIsIGFuY2hvciwgbW92ZVR5cGUsIHBhcmVudFN1c3BlbnNlID0gbnVsbCkgPT4ge1xuICAgIGNvbnN0IHsgZWwsIHR5cGUsIHRyYW5zaXRpb24sIGNoaWxkcmVuLCBzaGFwZUZsYWcgfSA9IHZub2RlO1xuICAgIGlmIChzaGFwZUZsYWcgJiA2KSB7XG4gICAgICBtb3ZlKHZub2RlLmNvbXBvbmVudC5zdWJUcmVlLCBjb250YWluZXIsIGFuY2hvciwgbW92ZVR5cGUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgICB2bm9kZS5zdXNwZW5zZS5tb3ZlKGNvbnRhaW5lciwgYW5jaG9yLCBtb3ZlVHlwZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChzaGFwZUZsYWcgJiA2NCkge1xuICAgICAgdHlwZS5tb3ZlKHZub2RlLCBjb250YWluZXIsIGFuY2hvciwgaW50ZXJuYWxzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHR5cGUgPT09IEZyYWdtZW50KSB7XG4gICAgICBob3N0SW5zZXJ0KGVsLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIG1vdmUoY2hpbGRyZW5baV0sIGNvbnRhaW5lciwgYW5jaG9yLCBtb3ZlVHlwZSk7XG4gICAgICB9XG4gICAgICBob3N0SW5zZXJ0KHZub2RlLmFuY2hvciwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodHlwZSA9PT0gU3RhdGljKSB7XG4gICAgICBtb3ZlU3RhdGljTm9kZSh2bm9kZSwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBuZWVkVHJhbnNpdGlvbjIgPSBtb3ZlVHlwZSAhPT0gMiAmJiBzaGFwZUZsYWcgJiAxICYmIHRyYW5zaXRpb247XG4gICAgaWYgKG5lZWRUcmFuc2l0aW9uMikge1xuICAgICAgaWYgKG1vdmVUeXBlID09PSAwKSB7XG4gICAgICAgIGlmICh0cmFuc2l0aW9uLnBlcnNpc3RlZCAmJiAhZWxbbGVhdmVDYktleV0pIHtcbiAgICAgICAgICBob3N0SW5zZXJ0KGVsLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdHJhbnNpdGlvbi5iZWZvcmVFbnRlcihlbCk7XG4gICAgICAgICAgaG9zdEluc2VydChlbCwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCgoKSA9PiB0cmFuc2l0aW9uLmVudGVyKGVsKSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCB7IGxlYXZlLCBkZWxheUxlYXZlLCBhZnRlckxlYXZlIH0gPSB0cmFuc2l0aW9uO1xuICAgICAgICBjb25zdCByZW1vdmUyID0gKCkgPT4ge1xuICAgICAgICAgIGlmICh2bm9kZS5jdHguaXNVbm1vdW50ZWQpIHtcbiAgICAgICAgICAgIGhvc3RSZW1vdmUoZWwpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBob3N0SW5zZXJ0KGVsLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBwZXJmb3JtTGVhdmUgPSAoKSA9PiB7XG4gICAgICAgICAgY29uc3Qgd2FzTGVhdmluZyA9IGVsLl9pc0xlYXZpbmcgfHwgISFlbFtsZWF2ZUNiS2V5XTtcbiAgICAgICAgICBpZiAoZWwuX2lzTGVhdmluZykge1xuICAgICAgICAgICAgZWxbbGVhdmVDYktleV0oXG4gICAgICAgICAgICAgIHRydWVcbiAgICAgICAgICAgICAgLyogY2FuY2VsbGVkICovXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodHJhbnNpdGlvbi5wZXJzaXN0ZWQgJiYgIXdhc0xlYXZpbmcpIHtcbiAgICAgICAgICAgIHJlbW92ZTIoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbGVhdmUoZWwsICgpID0+IHtcbiAgICAgICAgICAgICAgcmVtb3ZlMigpO1xuICAgICAgICAgICAgICBhZnRlckxlYXZlICYmIGFmdGVyTGVhdmUoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgaWYgKGRlbGF5TGVhdmUpIHtcbiAgICAgICAgICBkZWxheUxlYXZlKGVsLCByZW1vdmUyLCBwZXJmb3JtTGVhdmUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHBlcmZvcm1MZWF2ZSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGhvc3RJbnNlcnQoZWwsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHVubW91bnQgPSAodm5vZGUsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIGRvUmVtb3ZlID0gZmFsc2UsIG9wdGltaXplZCA9IGZhbHNlKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgdHlwZSxcbiAgICAgIHByb3BzLFxuICAgICAgcmVmLFxuICAgICAgY2hpbGRyZW4sXG4gICAgICBkeW5hbWljQ2hpbGRyZW4sXG4gICAgICBzaGFwZUZsYWcsXG4gICAgICBwYXRjaEZsYWcsXG4gICAgICBkaXJzLFxuICAgICAgY2FjaGVJbmRleCxcbiAgICAgIG1lbW9cbiAgICB9ID0gdm5vZGU7XG4gICAgaWYgKHBhdGNoRmxhZyA9PT0gLTIpIHtcbiAgICAgIG9wdGltaXplZCA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAocmVmICE9IG51bGwpIHtcbiAgICAgIHBhdXNlVHJhY2tpbmcoKTtcbiAgICAgIHNldFJlZihyZWYsIG51bGwsIHBhcmVudFN1c3BlbnNlLCB2bm9kZSwgdHJ1ZSk7XG4gICAgICByZXNldFRyYWNraW5nKCk7XG4gICAgfVxuICAgIGlmIChjYWNoZUluZGV4ICE9IG51bGwpIHtcbiAgICAgIHBhcmVudENvbXBvbmVudC5yZW5kZXJDYWNoZVtjYWNoZUluZGV4XSA9IHZvaWQgMDtcbiAgICB9XG4gICAgaWYgKHNoYXBlRmxhZyAmIDI1Nikge1xuICAgICAgcGFyZW50Q29tcG9uZW50LmN0eC5kZWFjdGl2YXRlKHZub2RlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc2hvdWxkSW52b2tlRGlycyA9IHNoYXBlRmxhZyAmIDEgJiYgZGlycztcbiAgICBjb25zdCBzaG91bGRJbnZva2VWbm9kZUhvb2sgPSAhaXNBc3luY1dyYXBwZXIodm5vZGUpO1xuICAgIGxldCB2bm9kZUhvb2s7XG4gICAgaWYgKHNob3VsZEludm9rZVZub2RlSG9vayAmJiAodm5vZGVIb29rID0gcHJvcHMgJiYgcHJvcHMub25Wbm9kZUJlZm9yZVVubW91bnQpKSB7XG4gICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnRDb21wb25lbnQsIHZub2RlKTtcbiAgICB9XG4gICAgaWYgKHNoYXBlRmxhZyAmIDYpIHtcbiAgICAgIHVubW91bnRDb21wb25lbnQodm5vZGUuY29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgZG9SZW1vdmUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgICAgIHZub2RlLnN1c3BlbnNlLnVubW91bnQocGFyZW50U3VzcGVuc2UsIGRvUmVtb3ZlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHNob3VsZEludm9rZURpcnMpIHtcbiAgICAgICAgaW52b2tlRGlyZWN0aXZlSG9vayh2bm9kZSwgbnVsbCwgcGFyZW50Q29tcG9uZW50LCBcImJlZm9yZVVubW91bnRcIik7XG4gICAgICB9XG4gICAgICBpZiAoc2hhcGVGbGFnICYgNjQpIHtcbiAgICAgICAgdm5vZGUudHlwZS5yZW1vdmUoXG4gICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIGludGVybmFscyxcbiAgICAgICAgICBkb1JlbW92ZVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIGlmIChkeW5hbWljQ2hpbGRyZW4gJiYgLy8gIzUxNTRcbiAgICAgIC8vIHdoZW4gdi1vbmNlIGlzIHVzZWQgaW5zaWRlIGEgYmxvY2ssIHNldEJsb2NrVHJhY2tpbmcoLTEpIG1hcmtzIHRoZVxuICAgICAgLy8gcGFyZW50IGJsb2NrIHdpdGggaGFzT25jZTogdHJ1ZVxuICAgICAgLy8gc28gdGhhdCBpdCBkb2Vzbid0IHRha2UgdGhlIGZhc3QgcGF0aCBkdXJpbmcgdW5tb3VudCAtIG90aGVyd2lzZVxuICAgICAgLy8gY29tcG9uZW50cyBuZXN0ZWQgaW4gdi1vbmNlIGFyZSBuZXZlciB1bm1vdW50ZWQuXG4gICAgICAhZHluYW1pY0NoaWxkcmVuLmhhc09uY2UgJiYgLy8gIzExNTM6IGZhc3QgcGF0aCBzaG91bGQgbm90IGJlIHRha2VuIGZvciBub24tc3RhYmxlICh2LWZvcikgZnJhZ21lbnRzXG4gICAgICAodHlwZSAhPT0gRnJhZ21lbnQgfHwgcGF0Y2hGbGFnID4gMCAmJiBwYXRjaEZsYWcgJiA2NCkpIHtcbiAgICAgICAgdW5tb3VudENoaWxkcmVuKFxuICAgICAgICAgIGR5bmFtaWNDaGlsZHJlbixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgZmFsc2UsXG4gICAgICAgICAgdHJ1ZVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIGlmICh0eXBlID09PSBGcmFnbWVudCAmJiBwYXRjaEZsYWcgJiAoMTI4IHwgMjU2KSB8fCAhb3B0aW1pemVkICYmIHNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICAgIHVubW91bnRDaGlsZHJlbihjaGlsZHJlbiwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICB9XG4gICAgICBpZiAoZG9SZW1vdmUpIHtcbiAgICAgICAgcmVtb3ZlKHZub2RlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc2hvdWxkSW52YWxpZGF0ZU1lbW8gPSBtZW1vICE9IG51bGwgJiYgY2FjaGVJbmRleCA9PSBudWxsO1xuICAgIGlmIChzaG91bGRJbnZva2VWbm9kZUhvb2sgJiYgKHZub2RlSG9vayA9IHByb3BzICYmIHByb3BzLm9uVm5vZGVVbm1vdW50ZWQpIHx8IHNob3VsZEludm9rZURpcnMgfHwgc2hvdWxkSW52YWxpZGF0ZU1lbW8pIHtcbiAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHZub2RlSG9vayAmJiBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnRDb21wb25lbnQsIHZub2RlKTtcbiAgICAgICAgc2hvdWxkSW52b2tlRGlycyAmJiBpbnZva2VEaXJlY3RpdmVIb29rKHZub2RlLCBudWxsLCBwYXJlbnRDb21wb25lbnQsIFwidW5tb3VudGVkXCIpO1xuICAgICAgICBpZiAoc2hvdWxkSW52YWxpZGF0ZU1lbW8pIHtcbiAgICAgICAgICB2bm9kZS5lbCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH0sIHBhcmVudFN1c3BlbnNlKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHJlbW92ZSA9ICh2bm9kZSkgPT4ge1xuICAgIGNvbnN0IHsgdHlwZSwgZWwsIGFuY2hvciwgdHJhbnNpdGlvbiB9ID0gdm5vZGU7XG4gICAgaWYgKHR5cGUgPT09IEZyYWdtZW50KSB7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB2bm9kZS5wYXRjaEZsYWcgPiAwICYmIHZub2RlLnBhdGNoRmxhZyAmIDIwNDggJiYgdHJhbnNpdGlvbiAmJiAhdHJhbnNpdGlvbi5wZXJzaXN0ZWQpIHtcbiAgICAgICAgdm5vZGUuY2hpbGRyZW4uZm9yRWFjaCgoY2hpbGQpID0+IHtcbiAgICAgICAgICBpZiAoY2hpbGQudHlwZSA9PT0gQ29tbWVudCkge1xuICAgICAgICAgICAgaG9zdFJlbW92ZShjaGlsZC5lbCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlbW92ZShjaGlsZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlbW92ZUZyYWdtZW50KGVsLCBhbmNob3IpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodHlwZSA9PT0gU3RhdGljKSB7XG4gICAgICByZW1vdmVTdGF0aWNOb2RlKHZub2RlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcGVyZm9ybVJlbW92ZSA9ICgpID0+IHtcbiAgICAgIGhvc3RSZW1vdmUoZWwpO1xuICAgICAgaWYgKHRyYW5zaXRpb24gJiYgIXRyYW5zaXRpb24ucGVyc2lzdGVkICYmIHRyYW5zaXRpb24uYWZ0ZXJMZWF2ZSkge1xuICAgICAgICB0cmFuc2l0aW9uLmFmdGVyTGVhdmUoKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGlmICh2bm9kZS5zaGFwZUZsYWcgJiAxICYmIHRyYW5zaXRpb24gJiYgIXRyYW5zaXRpb24ucGVyc2lzdGVkKSB7XG4gICAgICBjb25zdCB7IGxlYXZlLCBkZWxheUxlYXZlIH0gPSB0cmFuc2l0aW9uO1xuICAgICAgY29uc3QgcGVyZm9ybUxlYXZlID0gKCkgPT4gbGVhdmUoZWwsIHBlcmZvcm1SZW1vdmUpO1xuICAgICAgaWYgKGRlbGF5TGVhdmUpIHtcbiAgICAgICAgZGVsYXlMZWF2ZSh2bm9kZS5lbCwgcGVyZm9ybVJlbW92ZSwgcGVyZm9ybUxlYXZlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBlcmZvcm1MZWF2ZSgpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBwZXJmb3JtUmVtb3ZlKCk7XG4gICAgfVxuICB9O1xuICBjb25zdCByZW1vdmVGcmFnbWVudCA9IChjdXIsIGVuZCkgPT4ge1xuICAgIGxldCBuZXh0O1xuICAgIHdoaWxlIChjdXIgIT09IGVuZCkge1xuICAgICAgbmV4dCA9IGhvc3ROZXh0U2libGluZyhjdXIpO1xuICAgICAgaG9zdFJlbW92ZShjdXIpO1xuICAgICAgY3VyID0gbmV4dDtcbiAgICB9XG4gICAgaG9zdFJlbW92ZShlbmQpO1xuICB9O1xuICBjb25zdCB1bm1vdW50Q29tcG9uZW50ID0gKGluc3RhbmNlLCBwYXJlbnRTdXNwZW5zZSwgZG9SZW1vdmUpID0+IHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpbnN0YW5jZS50eXBlLl9faG1ySWQpIHtcbiAgICAgIHVucmVnaXN0ZXJITVIoaW5zdGFuY2UpO1xuICAgIH1cbiAgICBjb25zdCB7IGJ1bSwgc2NvcGUsIGpvYiwgc3ViVHJlZSwgdW0sIG0sIGEgfSA9IGluc3RhbmNlO1xuICAgIGludmFsaWRhdGVNb3VudChtKTtcbiAgICBpbnZhbGlkYXRlTW91bnQoYSk7XG4gICAgaWYgKGJ1bSkge1xuICAgICAgaW52b2tlQXJyYXlGbnMoYnVtKTtcbiAgICB9XG4gICAgc2NvcGUuc3RvcCgpO1xuICAgIGlmIChqb2IpIHtcbiAgICAgIGpvYi5mbGFncyB8PSA4O1xuICAgICAgdW5tb3VudChzdWJUcmVlLCBpbnN0YW5jZSwgcGFyZW50U3VzcGVuc2UsIGRvUmVtb3ZlKTtcbiAgICB9XG4gICAgaWYgKHVtKSB7XG4gICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QodW0sIHBhcmVudFN1c3BlbnNlKTtcbiAgICB9XG4gICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHtcbiAgICAgIGluc3RhbmNlLmlzVW5tb3VudGVkID0gdHJ1ZTtcbiAgICB9LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICBkZXZ0b29sc0NvbXBvbmVudFJlbW92ZWQoaW5zdGFuY2UpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgdW5tb3VudENoaWxkcmVuID0gKGNoaWxkcmVuLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBkb1JlbW92ZSA9IGZhbHNlLCBvcHRpbWl6ZWQgPSBmYWxzZSwgc3RhcnQgPSAwKSA9PiB7XG4gICAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgIHVubW91bnQoY2hpbGRyZW5baV0sIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIGRvUmVtb3ZlLCBvcHRpbWl6ZWQpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgZ2V0TmV4dEhvc3ROb2RlID0gKHZub2RlKSA9PiB7XG4gICAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDYpIHtcbiAgICAgIHJldHVybiBnZXROZXh0SG9zdE5vZGUodm5vZGUuY29tcG9uZW50LnN1YlRyZWUpO1xuICAgIH1cbiAgICBpZiAodm5vZGUuc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgICByZXR1cm4gdm5vZGUuc3VzcGVuc2UubmV4dCgpO1xuICAgIH1cbiAgICBjb25zdCBlbCA9IGhvc3ROZXh0U2libGluZyh2bm9kZS5hbmNob3IgfHwgdm5vZGUuZWwpO1xuICAgIGNvbnN0IHRlbGVwb3J0RW5kID0gZWwgJiYgZWxbVGVsZXBvcnRFbmRLZXldO1xuICAgIHJldHVybiB0ZWxlcG9ydEVuZCA/IGhvc3ROZXh0U2libGluZyh0ZWxlcG9ydEVuZCkgOiBlbDtcbiAgfTtcbiAgbGV0IGlzRmx1c2hpbmcgPSBmYWxzZTtcbiAgY29uc3QgcmVuZGVyID0gKHZub2RlLCBjb250YWluZXIsIG5hbWVzcGFjZSkgPT4ge1xuICAgIGxldCBpbnN0YW5jZTtcbiAgICBpZiAodm5vZGUgPT0gbnVsbCkge1xuICAgICAgaWYgKGNvbnRhaW5lci5fdm5vZGUpIHtcbiAgICAgICAgdW5tb3VudChjb250YWluZXIuX3Zub2RlLCBudWxsLCBudWxsLCB0cnVlKTtcbiAgICAgICAgaW5zdGFuY2UgPSBjb250YWluZXIuX3Zub2RlLmNvbXBvbmVudDtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcGF0Y2goXG4gICAgICAgIGNvbnRhaW5lci5fdm5vZGUgfHwgbnVsbCxcbiAgICAgICAgdm5vZGUsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgbnVsbCxcbiAgICAgICAgbnVsbCxcbiAgICAgICAgbnVsbCxcbiAgICAgICAgbmFtZXNwYWNlXG4gICAgICApO1xuICAgIH1cbiAgICBjb250YWluZXIuX3Zub2RlID0gdm5vZGU7XG4gICAgaWYgKCFpc0ZsdXNoaW5nKSB7XG4gICAgICBpc0ZsdXNoaW5nID0gdHJ1ZTtcbiAgICAgIGZsdXNoUHJlRmx1c2hDYnMoaW5zdGFuY2UpO1xuICAgICAgZmx1c2hQb3N0Rmx1c2hDYnMoKTtcbiAgICAgIGlzRmx1c2hpbmcgPSBmYWxzZTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IGludGVybmFscyA9IHtcbiAgICBwOiBwYXRjaCxcbiAgICB1bTogdW5tb3VudCxcbiAgICBtOiBtb3ZlLFxuICAgIHI6IHJlbW92ZSxcbiAgICBtdDogbW91bnRDb21wb25lbnQsXG4gICAgbWM6IG1vdW50Q2hpbGRyZW4sXG4gICAgcGM6IHBhdGNoQ2hpbGRyZW4sXG4gICAgcGJjOiBwYXRjaEJsb2NrQ2hpbGRyZW4sXG4gICAgbjogZ2V0TmV4dEhvc3ROb2RlLFxuICAgIG86IG9wdGlvbnNcbiAgfTtcbiAgbGV0IGh5ZHJhdGU7XG4gIGxldCBoeWRyYXRlTm9kZTtcbiAgaWYgKGNyZWF0ZUh5ZHJhdGlvbkZucykge1xuICAgIFtoeWRyYXRlLCBoeWRyYXRlTm9kZV0gPSBjcmVhdGVIeWRyYXRpb25GbnMoXG4gICAgICBpbnRlcm5hbHNcbiAgICApO1xuICB9XG4gIHJldHVybiB7XG4gICAgcmVuZGVyLFxuICAgIGh5ZHJhdGUsXG4gICAgY3JlYXRlQXBwOiBjcmVhdGVBcHBBUEkocmVuZGVyLCBoeWRyYXRlKVxuICB9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZUNoaWxkcmVuTmFtZXNwYWNlKHsgdHlwZSwgcHJvcHMgfSwgY3VycmVudE5hbWVzcGFjZSkge1xuICByZXR1cm4gY3VycmVudE5hbWVzcGFjZSA9PT0gXCJzdmdcIiAmJiB0eXBlID09PSBcImZvcmVpZ25PYmplY3RcIiB8fCBjdXJyZW50TmFtZXNwYWNlID09PSBcIm1hdGhtbFwiICYmIHR5cGUgPT09IFwiYW5ub3RhdGlvbi14bWxcIiAmJiBwcm9wcyAmJiBwcm9wcy5lbmNvZGluZyAmJiBwcm9wcy5lbmNvZGluZy5pbmNsdWRlcyhcImh0bWxcIikgPyB2b2lkIDAgOiBjdXJyZW50TmFtZXNwYWNlO1xufVxuZnVuY3Rpb24gdG9nZ2xlUmVjdXJzZSh7IGVmZmVjdCwgam9iIH0sIGFsbG93ZWQpIHtcbiAgaWYgKGFsbG93ZWQpIHtcbiAgICBlZmZlY3QuZmxhZ3MgfD0gMzI7XG4gICAgam9iLmZsYWdzIHw9IDQ7XG4gIH0gZWxzZSB7XG4gICAgZWZmZWN0LmZsYWdzICY9IC0zMztcbiAgICBqb2IuZmxhZ3MgJj0gLTU7XG4gIH1cbn1cbmZ1bmN0aW9uIG5lZWRUcmFuc2l0aW9uKHBhcmVudFN1c3BlbnNlLCB0cmFuc2l0aW9uKSB7XG4gIHJldHVybiAoIXBhcmVudFN1c3BlbnNlIHx8IHBhcmVudFN1c3BlbnNlICYmICFwYXJlbnRTdXNwZW5zZS5wZW5kaW5nQnJhbmNoKSAmJiB0cmFuc2l0aW9uICYmICF0cmFuc2l0aW9uLnBlcnNpc3RlZDtcbn1cbmZ1bmN0aW9uIHRyYXZlcnNlU3RhdGljQ2hpbGRyZW4objEsIG4yLCBzaGFsbG93ID0gZmFsc2UpIHtcbiAgY29uc3QgY2gxID0gbjEuY2hpbGRyZW47XG4gIGNvbnN0IGNoMiA9IG4yLmNoaWxkcmVuO1xuICBpZiAoaXNBcnJheShjaDEpICYmIGlzQXJyYXkoY2gyKSkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2gxLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBjMSA9IGNoMVtpXTtcbiAgICAgIGxldCBjMiA9IGNoMltpXTtcbiAgICAgIGlmIChjMi5zaGFwZUZsYWcgJiAxICYmICFjMi5keW5hbWljQ2hpbGRyZW4pIHtcbiAgICAgICAgaWYgKGMyLnBhdGNoRmxhZyA8PSAwIHx8IGMyLnBhdGNoRmxhZyA9PT0gMzIpIHtcbiAgICAgICAgICBjMiA9IGNoMltpXSA9IGNsb25lSWZNb3VudGVkKGNoMltpXSk7XG4gICAgICAgICAgYzIuZWwgPSBjMS5lbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXNoYWxsb3cgJiYgYzIucGF0Y2hGbGFnICE9PSAtMilcbiAgICAgICAgICB0cmF2ZXJzZVN0YXRpY0NoaWxkcmVuKGMxLCBjMik7XG4gICAgICB9XG4gICAgICBpZiAoYzIudHlwZSA9PT0gVGV4dCkge1xuICAgICAgICBpZiAoYzIucGF0Y2hGbGFnID09PSAtMSkge1xuICAgICAgICAgIGMyID0gY2gyW2ldID0gY2xvbmVJZk1vdW50ZWQoYzIpO1xuICAgICAgICB9XG4gICAgICAgIGMyLmVsID0gYzEuZWw7XG4gICAgICB9XG4gICAgICBpZiAoYzIudHlwZSA9PT0gQ29tbWVudCAmJiAhYzIuZWwpIHtcbiAgICAgICAgYzIuZWwgPSBjMS5lbDtcbiAgICAgIH1cbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIGMyLmVsICYmIChjMi5lbC5fX3Zub2RlID0gYzIpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gZ2V0U2VxdWVuY2UoYXJyKSB7XG4gIGNvbnN0IHAgPSBhcnIuc2xpY2UoKTtcbiAgY29uc3QgcmVzdWx0ID0gWzBdO1xuICBsZXQgaSwgaiwgdSwgdiwgYztcbiAgY29uc3QgbGVuID0gYXJyLmxlbmd0aDtcbiAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgY29uc3QgYXJySSA9IGFycltpXTtcbiAgICBpZiAoYXJySSAhPT0gMCkge1xuICAgICAgaiA9IHJlc3VsdFtyZXN1bHQubGVuZ3RoIC0gMV07XG4gICAgICBpZiAoYXJyW2pdIDwgYXJySSkge1xuICAgICAgICBwW2ldID0gajtcbiAgICAgICAgcmVzdWx0LnB1c2goaSk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgdSA9IDA7XG4gICAgICB2ID0gcmVzdWx0Lmxlbmd0aCAtIDE7XG4gICAgICB3aGlsZSAodSA8IHYpIHtcbiAgICAgICAgYyA9IHUgKyB2ID4+IDE7XG4gICAgICAgIGlmIChhcnJbcmVzdWx0W2NdXSA8IGFyckkpIHtcbiAgICAgICAgICB1ID0gYyArIDE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdiA9IGM7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChhcnJJIDwgYXJyW3Jlc3VsdFt1XV0pIHtcbiAgICAgICAgaWYgKHUgPiAwKSB7XG4gICAgICAgICAgcFtpXSA9IHJlc3VsdFt1IC0gMV07XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0W3VdID0gaTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgdSA9IHJlc3VsdC5sZW5ndGg7XG4gIHYgPSByZXN1bHRbdSAtIDFdO1xuICB3aGlsZSAodS0tID4gMCkge1xuICAgIHJlc3VsdFt1XSA9IHY7XG4gICAgdiA9IHBbdl07XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGxvY2F0ZU5vbkh5ZHJhdGVkQXN5bmNSb290KGluc3RhbmNlKSB7XG4gIGNvbnN0IHN1YkNvbXBvbmVudCA9IGluc3RhbmNlLnN1YlRyZWUuY29tcG9uZW50O1xuICBpZiAoc3ViQ29tcG9uZW50KSB7XG4gICAgaWYgKHN1YkNvbXBvbmVudC5hc3luY0RlcCAmJiAhc3ViQ29tcG9uZW50LmFzeW5jUmVzb2x2ZWQpIHtcbiAgICAgIHJldHVybiBzdWJDb21wb25lbnQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBsb2NhdGVOb25IeWRyYXRlZEFzeW5jUm9vdChzdWJDb21wb25lbnQpO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gaW52YWxpZGF0ZU1vdW50KGhvb2tzKSB7XG4gIGlmIChob29rcykge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaG9va3MubGVuZ3RoOyBpKyspXG4gICAgICBob29rc1tpXS5mbGFncyB8PSA4O1xuICB9XG59XG5mdW5jdGlvbiByZXNvbHZlQXN5bmNDb21wb25lbnRQbGFjZWhvbGRlcihhbmNob3JWbm9kZSkge1xuICBpZiAoYW5jaG9yVm5vZGUucGxhY2Vob2xkZXIpIHtcbiAgICByZXR1cm4gYW5jaG9yVm5vZGUucGxhY2Vob2xkZXI7XG4gIH1cbiAgY29uc3QgaW5zdGFuY2UgPSBhbmNob3JWbm9kZS5jb21wb25lbnQ7XG4gIGlmIChpbnN0YW5jZSkge1xuICAgIHJldHVybiByZXNvbHZlQXN5bmNDb21wb25lbnRQbGFjZWhvbGRlcihpbnN0YW5jZS5zdWJUcmVlKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuY29uc3QgaXNTdXNwZW5zZSA9ICh0eXBlKSA9PiB0eXBlLl9faXNTdXNwZW5zZTtcbmxldCBzdXNwZW5zZUlkID0gMDtcbmNvbnN0IFN1c3BlbnNlSW1wbCA9IHtcbiAgbmFtZTogXCJTdXNwZW5zZVwiLFxuICAvLyBJbiBvcmRlciB0byBtYWtlIFN1c3BlbnNlIHRyZWUtc2hha2FibGUsIHdlIG5lZWQgdG8gYXZvaWQgaW1wb3J0aW5nIGl0XG4gIC8vIGRpcmVjdGx5IGluIHRoZSByZW5kZXJlci4gVGhlIHJlbmRlcmVyIGNoZWNrcyBmb3IgdGhlIF9faXNTdXNwZW5zZSBmbGFnXG4gIC8vIG9uIGEgdm5vZGUncyB0eXBlIGFuZCBjYWxscyB0aGUgYHByb2Nlc3NgIG1ldGhvZCwgcGFzc2luZyBpbiByZW5kZXJlclxuICAvLyBpbnRlcm5hbHMuXG4gIF9faXNTdXNwZW5zZTogdHJ1ZSxcbiAgcHJvY2VzcyhuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkLCByZW5kZXJlckludGVybmFscykge1xuICAgIGlmIChuMSA9PSBudWxsKSB7XG4gICAgICBtb3VudFN1c3BlbnNlKFxuICAgICAgICBuMixcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWQsXG4gICAgICAgIHJlbmRlcmVySW50ZXJuYWxzXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAocGFyZW50U3VzcGVuc2UgJiYgcGFyZW50U3VzcGVuc2UuZGVwcyA+IDAgJiYgIW4xLnN1c3BlbnNlLmlzSW5GYWxsYmFjaykge1xuICAgICAgICBuMi5zdXNwZW5zZSA9IG4xLnN1c3BlbnNlO1xuICAgICAgICBuMi5zdXNwZW5zZS52bm9kZSA9IG4yO1xuICAgICAgICBuMi5lbCA9IG4xLmVsO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBwYXRjaFN1c3BlbnNlKFxuICAgICAgICBuMSxcbiAgICAgICAgbjIsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgYW5jaG9yLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWQsXG4gICAgICAgIHJlbmRlcmVySW50ZXJuYWxzXG4gICAgICApO1xuICAgIH1cbiAgfSxcbiAgaHlkcmF0ZTogaHlkcmF0ZVN1c3BlbnNlLFxuICBub3JtYWxpemU6IG5vcm1hbGl6ZVN1c3BlbnNlQ2hpbGRyZW5cbn07XG5jb25zdCBTdXNwZW5zZSA9IFN1c3BlbnNlSW1wbCA7XG5mdW5jdGlvbiB0cmlnZ2VyRXZlbnQodm5vZGUsIG5hbWUpIHtcbiAgY29uc3QgZXZlbnRMaXN0ZW5lciA9IHZub2RlLnByb3BzICYmIHZub2RlLnByb3BzW25hbWVdO1xuICBpZiAoaXNGdW5jdGlvbihldmVudExpc3RlbmVyKSkge1xuICAgIGV2ZW50TGlzdGVuZXIoKTtcbiAgfVxufVxuZnVuY3Rpb24gbW91bnRTdXNwZW5zZSh2bm9kZSwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQsIHJlbmRlcmVySW50ZXJuYWxzKSB7XG4gIGNvbnN0IHtcbiAgICBwOiBwYXRjaCxcbiAgICBvOiB7IGNyZWF0ZUVsZW1lbnQgfVxuICB9ID0gcmVuZGVyZXJJbnRlcm5hbHM7XG4gIGNvbnN0IGhpZGRlbkNvbnRhaW5lciA9IGNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gIGNvbnN0IHN1c3BlbnNlID0gdm5vZGUuc3VzcGVuc2UgPSBjcmVhdGVTdXNwZW5zZUJvdW5kYXJ5KFxuICAgIHZub2RlLFxuICAgIHBhcmVudFN1c3BlbnNlLFxuICAgIHBhcmVudENvbXBvbmVudCxcbiAgICBjb250YWluZXIsXG4gICAgaGlkZGVuQ29udGFpbmVyLFxuICAgIGFuY2hvcixcbiAgICBuYW1lc3BhY2UsXG4gICAgc2xvdFNjb3BlSWRzLFxuICAgIG9wdGltaXplZCxcbiAgICByZW5kZXJlckludGVybmFsc1xuICApO1xuICBwYXRjaChcbiAgICBudWxsLFxuICAgIHN1c3BlbnNlLnBlbmRpbmdCcmFuY2ggPSB2bm9kZS5zc0NvbnRlbnQsXG4gICAgaGlkZGVuQ29udGFpbmVyLFxuICAgIG51bGwsXG4gICAgcGFyZW50Q29tcG9uZW50LFxuICAgIHN1c3BlbnNlLFxuICAgIG5hbWVzcGFjZSxcbiAgICBzbG90U2NvcGVJZHNcbiAgKTtcbiAgaWYgKHN1c3BlbnNlLmRlcHMgPiAwKSB7XG4gICAgdHJpZ2dlckV2ZW50KHZub2RlLCBcIm9uUGVuZGluZ1wiKTtcbiAgICB0cmlnZ2VyRXZlbnQodm5vZGUsIFwib25GYWxsYmFja1wiKTtcbiAgICBwYXRjaChcbiAgICAgIG51bGwsXG4gICAgICB2bm9kZS5zc0ZhbGxiYWNrLFxuICAgICAgY29udGFpbmVyLFxuICAgICAgYW5jaG9yLFxuICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgbnVsbCxcbiAgICAgIC8vIGZhbGxiYWNrIHRyZWUgd2lsbCBub3QgaGF2ZSBzdXNwZW5zZSBjb250ZXh0XG4gICAgICBuYW1lc3BhY2UsXG4gICAgICBzbG90U2NvcGVJZHNcbiAgICApO1xuICAgIHNldEFjdGl2ZUJyYW5jaChzdXNwZW5zZSwgdm5vZGUuc3NGYWxsYmFjayk7XG4gIH0gZWxzZSB7XG4gICAgc3VzcGVuc2UucmVzb2x2ZShmYWxzZSwgdHJ1ZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIHBhdGNoU3VzcGVuc2UobjEsIG4yLCBjb250YWluZXIsIGFuY2hvciwgcGFyZW50Q29tcG9uZW50LCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkLCB7IHA6IHBhdGNoLCB1bTogdW5tb3VudCwgbzogeyBjcmVhdGVFbGVtZW50IH0gfSkge1xuICBjb25zdCBzdXNwZW5zZSA9IG4yLnN1c3BlbnNlID0gbjEuc3VzcGVuc2U7XG4gIHN1c3BlbnNlLnZub2RlID0gbjI7XG4gIG4yLmVsID0gbjEuZWw7XG4gIGNvbnN0IG5ld0JyYW5jaCA9IG4yLnNzQ29udGVudDtcbiAgY29uc3QgbmV3RmFsbGJhY2sgPSBuMi5zc0ZhbGxiYWNrO1xuICBjb25zdCB7IGFjdGl2ZUJyYW5jaCwgcGVuZGluZ0JyYW5jaCwgaXNJbkZhbGxiYWNrLCBpc0h5ZHJhdGluZyB9ID0gc3VzcGVuc2U7XG4gIGlmIChwZW5kaW5nQnJhbmNoKSB7XG4gICAgc3VzcGVuc2UucGVuZGluZ0JyYW5jaCA9IG5ld0JyYW5jaDtcbiAgICBpZiAoaXNTYW1lVk5vZGVUeXBlKHBlbmRpbmdCcmFuY2gsIG5ld0JyYW5jaCkpIHtcbiAgICAgIHBhdGNoKFxuICAgICAgICBwZW5kaW5nQnJhbmNoLFxuICAgICAgICBuZXdCcmFuY2gsXG4gICAgICAgIHN1c3BlbnNlLmhpZGRlbkNvbnRhaW5lcixcbiAgICAgICAgbnVsbCxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBzdXNwZW5zZSxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIG9wdGltaXplZFxuICAgICAgKTtcbiAgICAgIGlmIChzdXNwZW5zZS5kZXBzIDw9IDApIHtcbiAgICAgICAgc3VzcGVuc2UucmVzb2x2ZSgpO1xuICAgICAgfSBlbHNlIGlmIChpc0luRmFsbGJhY2spIHtcbiAgICAgICAgaWYgKCFpc0h5ZHJhdGluZykge1xuICAgICAgICAgIHBhdGNoKFxuICAgICAgICAgICAgYWN0aXZlQnJhbmNoLFxuICAgICAgICAgICAgbmV3RmFsbGJhY2ssXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgLy8gZmFsbGJhY2sgdHJlZSB3aWxsIG5vdCBoYXZlIHN1c3BlbnNlIGNvbnRleHRcbiAgICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICAgICk7XG4gICAgICAgICAgc2V0QWN0aXZlQnJhbmNoKHN1c3BlbnNlLCBuZXdGYWxsYmFjayk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc3VzcGVuc2UucGVuZGluZ0lkID0gc3VzcGVuc2VJZCsrO1xuICAgICAgaWYgKGlzSHlkcmF0aW5nKSB7XG4gICAgICAgIHN1c3BlbnNlLmlzSHlkcmF0aW5nID0gZmFsc2U7XG4gICAgICAgIHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCA9IHBlbmRpbmdCcmFuY2g7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB1bm1vdW50KHBlbmRpbmdCcmFuY2gsIHBhcmVudENvbXBvbmVudCwgc3VzcGVuc2UpO1xuICAgICAgfVxuICAgICAgc3VzcGVuc2UuZGVwcyA9IDA7XG4gICAgICBzdXNwZW5zZS5lZmZlY3RzLmxlbmd0aCA9IDA7XG4gICAgICBzdXNwZW5zZS5oaWRkZW5Db250YWluZXIgPSBjcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgaWYgKGlzSW5GYWxsYmFjaykge1xuICAgICAgICBwYXRjaChcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIG5ld0JyYW5jaCxcbiAgICAgICAgICBzdXNwZW5zZS5oaWRkZW5Db250YWluZXIsXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgc3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHN1c3BlbnNlLmRlcHMgPD0gMCkge1xuICAgICAgICAgIHN1c3BlbnNlLnJlc29sdmUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwYXRjaChcbiAgICAgICAgICAgIGFjdGl2ZUJyYW5jaCxcbiAgICAgICAgICAgIG5ld0ZhbGxiYWNrLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgIC8vIGZhbGxiYWNrIHRyZWUgd2lsbCBub3QgaGF2ZSBzdXNwZW5zZSBjb250ZXh0XG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICAgIHNldEFjdGl2ZUJyYW5jaChzdXNwZW5zZSwgbmV3RmFsbGJhY2spO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGFjdGl2ZUJyYW5jaCAmJiBpc1NhbWVWTm9kZVR5cGUoYWN0aXZlQnJhbmNoLCBuZXdCcmFuY2gpKSB7XG4gICAgICAgIHBhdGNoKFxuICAgICAgICAgIGFjdGl2ZUJyYW5jaCxcbiAgICAgICAgICBuZXdCcmFuY2gsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgc3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgICAgc3VzcGVuc2UucmVzb2x2ZSh0cnVlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBhdGNoKFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgbmV3QnJhbmNoLFxuICAgICAgICAgIHN1c3BlbnNlLmhpZGRlbkNvbnRhaW5lcixcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBzdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICBpZiAoc3VzcGVuc2UuZGVwcyA8PSAwKSB7XG4gICAgICAgICAgc3VzcGVuc2UucmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmIChhY3RpdmVCcmFuY2ggJiYgaXNTYW1lVk5vZGVUeXBlKGFjdGl2ZUJyYW5jaCwgbmV3QnJhbmNoKSkge1xuICAgICAgcGF0Y2goXG4gICAgICAgIGFjdGl2ZUJyYW5jaCxcbiAgICAgICAgbmV3QnJhbmNoLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIGFuY2hvcixcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBzdXNwZW5zZSxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIG9wdGltaXplZFxuICAgICAgKTtcbiAgICAgIHNldEFjdGl2ZUJyYW5jaChzdXNwZW5zZSwgbmV3QnJhbmNoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdHJpZ2dlckV2ZW50KG4yLCBcIm9uUGVuZGluZ1wiKTtcbiAgICAgIHN1c3BlbnNlLnBlbmRpbmdCcmFuY2ggPSBuZXdCcmFuY2g7XG4gICAgICBpZiAobmV3QnJhbmNoLnNoYXBlRmxhZyAmIDUxMikge1xuICAgICAgICBzdXNwZW5zZS5wZW5kaW5nSWQgPSBuZXdCcmFuY2guY29tcG9uZW50LnN1c3BlbnNlSWQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdXNwZW5zZS5wZW5kaW5nSWQgPSBzdXNwZW5zZUlkKys7XG4gICAgICB9XG4gICAgICBwYXRjaChcbiAgICAgICAgbnVsbCxcbiAgICAgICAgbmV3QnJhbmNoLFxuICAgICAgICBzdXNwZW5zZS5oaWRkZW5Db250YWluZXIsXG4gICAgICAgIG51bGwsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgc3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICk7XG4gICAgICBpZiAoc3VzcGVuc2UuZGVwcyA8PSAwKSB7XG4gICAgICAgIHN1c3BlbnNlLnJlc29sdmUoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHsgdGltZW91dCwgcGVuZGluZ0lkIH0gPSBzdXNwZW5zZTtcbiAgICAgICAgaWYgKHRpbWVvdXQgPiAwKSB7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBpZiAoc3VzcGVuc2UucGVuZGluZ0lkID09PSBwZW5kaW5nSWQpIHtcbiAgICAgICAgICAgICAgc3VzcGVuc2UuZmFsbGJhY2sobmV3RmFsbGJhY2spO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sIHRpbWVvdXQpO1xuICAgICAgICB9IGVsc2UgaWYgKHRpbWVvdXQgPT09IDApIHtcbiAgICAgICAgICBzdXNwZW5zZS5mYWxsYmFjayhuZXdGYWxsYmFjayk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmxldCBoYXNXYXJuZWQgPSBmYWxzZTtcbmZ1bmN0aW9uIGNyZWF0ZVN1c3BlbnNlQm91bmRhcnkodm5vZGUsIHBhcmVudFN1c3BlbnNlLCBwYXJlbnRDb21wb25lbnQsIGNvbnRhaW5lciwgaGlkZGVuQ29udGFpbmVyLCBhbmNob3IsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQsIHJlbmRlcmVySW50ZXJuYWxzLCBpc0h5ZHJhdGluZyA9IGZhbHNlKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHRydWUgJiYgIWhhc1dhcm5lZCkge1xuICAgIGhhc1dhcm5lZCA9IHRydWU7XG4gICAgY29uc29sZVtjb25zb2xlLmluZm8gPyBcImluZm9cIiA6IFwibG9nXCJdKFxuICAgICAgYDxTdXNwZW5zZT4gaXMgYW4gZXhwZXJpbWVudGFsIGZlYXR1cmUgYW5kIGl0cyBBUEkgd2lsbCBsaWtlbHkgY2hhbmdlLmBcbiAgICApO1xuICB9XG4gIGNvbnN0IHtcbiAgICBwOiBwYXRjaCxcbiAgICBtOiBtb3ZlLFxuICAgIHVtOiB1bm1vdW50LFxuICAgIG46IG5leHQsXG4gICAgbzogeyBwYXJlbnROb2RlLCByZW1vdmUgfVxuICB9ID0gcmVuZGVyZXJJbnRlcm5hbHM7XG4gIGxldCBwYXJlbnRTdXNwZW5zZUlkO1xuICBjb25zdCBpc1N1c3BlbnNpYmxlID0gaXNWTm9kZVN1c3BlbnNpYmxlKHZub2RlKTtcbiAgaWYgKGlzU3VzcGVuc2libGUpIHtcbiAgICBpZiAocGFyZW50U3VzcGVuc2UgJiYgcGFyZW50U3VzcGVuc2UucGVuZGluZ0JyYW5jaCkge1xuICAgICAgcGFyZW50U3VzcGVuc2VJZCA9IHBhcmVudFN1c3BlbnNlLnBlbmRpbmdJZDtcbiAgICAgIHBhcmVudFN1c3BlbnNlLmRlcHMrKztcbiAgICB9XG4gIH1cbiAgY29uc3QgdGltZW91dCA9IHZub2RlLnByb3BzID8gdG9OdW1iZXIodm5vZGUucHJvcHMudGltZW91dCkgOiB2b2lkIDA7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgYXNzZXJ0TnVtYmVyKHRpbWVvdXQsIGBTdXNwZW5zZSB0aW1lb3V0YCk7XG4gIH1cbiAgY29uc3QgaW5pdGlhbEFuY2hvciA9IGFuY2hvcjtcbiAgY29uc3Qgc3VzcGVuc2UgPSB7XG4gICAgdm5vZGUsXG4gICAgcGFyZW50OiBwYXJlbnRTdXNwZW5zZSxcbiAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgbmFtZXNwYWNlLFxuICAgIGNvbnRhaW5lcixcbiAgICBoaWRkZW5Db250YWluZXIsXG4gICAgZGVwczogMCxcbiAgICBwZW5kaW5nSWQ6IHN1c3BlbnNlSWQrKyxcbiAgICB0aW1lb3V0OiB0eXBlb2YgdGltZW91dCA9PT0gXCJudW1iZXJcIiA/IHRpbWVvdXQgOiAtMSxcbiAgICBhY3RpdmVCcmFuY2g6IG51bGwsXG4gICAgaXNGYWxsYmFja01vdW50UGVuZGluZzogZmFsc2UsXG4gICAgcGVuZGluZ0JyYW5jaDogbnVsbCxcbiAgICBpc0luRmFsbGJhY2s6ICFpc0h5ZHJhdGluZyxcbiAgICBpc0h5ZHJhdGluZyxcbiAgICBpc1VubW91bnRlZDogZmFsc2UsXG4gICAgZWZmZWN0czogW10sXG4gICAgcmVzb2x2ZShyZXN1bWUgPSBmYWxzZSwgc3luYyA9IGZhbHNlKSB7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICBpZiAoIXJlc3VtZSAmJiAhc3VzcGVuc2UucGVuZGluZ0JyYW5jaCkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBzdXNwZW5zZS5yZXNvbHZlKCkgaXMgY2FsbGVkIHdpdGhvdXQgYSBwZW5kaW5nIGJyYW5jaC5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3VzcGVuc2UuaXNVbm1vdW50ZWQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICBgc3VzcGVuc2UucmVzb2x2ZSgpIGlzIGNhbGxlZCBvbiBhbiBhbHJlYWR5IHVubW91bnRlZCBzdXNwZW5zZSBib3VuZGFyeS5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3Qge1xuICAgICAgICB2bm9kZTogdm5vZGUyLFxuICAgICAgICBhY3RpdmVCcmFuY2gsXG4gICAgICAgIHBlbmRpbmdCcmFuY2gsXG4gICAgICAgIHBlbmRpbmdJZCxcbiAgICAgICAgZWZmZWN0cyxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50OiBwYXJlbnRDb21wb25lbnQyLFxuICAgICAgICBjb250YWluZXI6IGNvbnRhaW5lcjIsXG4gICAgICAgIGlzSW5GYWxsYmFja1xuICAgICAgfSA9IHN1c3BlbnNlO1xuICAgICAgbGV0IGRlbGF5RW50ZXIgPSBmYWxzZTtcbiAgICAgIGlmIChzdXNwZW5zZS5pc0h5ZHJhdGluZykge1xuICAgICAgICBzdXNwZW5zZS5pc0h5ZHJhdGluZyA9IGZhbHNlO1xuICAgICAgfSBlbHNlIGlmICghcmVzdW1lKSB7XG4gICAgICAgIGRlbGF5RW50ZXIgPSBhY3RpdmVCcmFuY2ggJiYgcGVuZGluZ0JyYW5jaC50cmFuc2l0aW9uICYmIHBlbmRpbmdCcmFuY2gudHJhbnNpdGlvbi5tb2RlID09PSBcIm91dC1pblwiO1xuICAgICAgICBsZXQgaGFzVXBkYXRlZEFuY2hvciA9IGZhbHNlO1xuICAgICAgICBpZiAoZGVsYXlFbnRlcikge1xuICAgICAgICAgIGFjdGl2ZUJyYW5jaC50cmFuc2l0aW9uLmFmdGVyTGVhdmUgPSAoKSA9PiB7XG4gICAgICAgICAgICBpZiAocGVuZGluZ0lkID09PSBzdXNwZW5zZS5wZW5kaW5nSWQpIHtcbiAgICAgICAgICAgICAgbW92ZShcbiAgICAgICAgICAgICAgICBwZW5kaW5nQnJhbmNoLFxuICAgICAgICAgICAgICAgIGNvbnRhaW5lcjIsXG4gICAgICAgICAgICAgICAgYW5jaG9yID09PSBpbml0aWFsQW5jaG9yICYmICFoYXNVcGRhdGVkQW5jaG9yID8gbmV4dChhY3RpdmVCcmFuY2gpIDogYW5jaG9yLFxuICAgICAgICAgICAgICAgIDBcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgcXVldWVQb3N0Rmx1c2hDYihlZmZlY3RzKTtcbiAgICAgICAgICAgICAgaWYgKGlzSW5GYWxsYmFjayAmJiB2bm9kZTIuc3NGYWxsYmFjaykge1xuICAgICAgICAgICAgICAgIHZub2RlMi5zc0ZhbGxiYWNrLmVsID0gbnVsbDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFjdGl2ZUJyYW5jaCAmJiAhc3VzcGVuc2UuaXNGYWxsYmFja01vdW50UGVuZGluZykge1xuICAgICAgICAgIGlmIChwYXJlbnROb2RlKGFjdGl2ZUJyYW5jaC5lbCkgPT09IGNvbnRhaW5lcjIpIHtcbiAgICAgICAgICAgIGFuY2hvciA9IG5leHQoYWN0aXZlQnJhbmNoKTtcbiAgICAgICAgICAgIGhhc1VwZGF0ZWRBbmNob3IgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB1bm1vdW50KGFjdGl2ZUJyYW5jaCwgcGFyZW50Q29tcG9uZW50Miwgc3VzcGVuc2UsIHRydWUpO1xuICAgICAgICAgIGlmICghZGVsYXlFbnRlciAmJiBpc0luRmFsbGJhY2sgJiYgdm5vZGUyLnNzRmFsbGJhY2spIHtcbiAgICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCgoKSA9PiB2bm9kZTIuc3NGYWxsYmFjay5lbCA9IG51bGwsIHN1c3BlbnNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFkZWxheUVudGVyKSB7XG4gICAgICAgICAgbW92ZShwZW5kaW5nQnJhbmNoLCBjb250YWluZXIyLCBhbmNob3IsIDApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBzdXNwZW5zZS5pc0ZhbGxiYWNrTW91bnRQZW5kaW5nID0gZmFsc2U7XG4gICAgICBzZXRBY3RpdmVCcmFuY2goc3VzcGVuc2UsIHBlbmRpbmdCcmFuY2gpO1xuICAgICAgc3VzcGVuc2UucGVuZGluZ0JyYW5jaCA9IG51bGw7XG4gICAgICBzdXNwZW5zZS5pc0luRmFsbGJhY2sgPSBmYWxzZTtcbiAgICAgIGxldCBwYXJlbnQgPSBzdXNwZW5zZS5wYXJlbnQ7XG4gICAgICBsZXQgaGFzVW5yZXNvbHZlZEFuY2VzdG9yID0gZmFsc2U7XG4gICAgICB3aGlsZSAocGFyZW50KSB7XG4gICAgICAgIGlmIChwYXJlbnQucGVuZGluZ0JyYW5jaCkge1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZWZmZWN0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgcGFyZW50LmVmZmVjdHMucHVzaChlZmZlY3RzW2ldKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaGFzVW5yZXNvbHZlZEFuY2VzdG9yID0gdHJ1ZTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBwYXJlbnQgPSBwYXJlbnQucGFyZW50O1xuICAgICAgfVxuICAgICAgaWYgKCFoYXNVbnJlc29sdmVkQW5jZXN0b3IgJiYgIWRlbGF5RW50ZXIpIHtcbiAgICAgICAgcXVldWVQb3N0Rmx1c2hDYihlZmZlY3RzKTtcbiAgICAgIH1cbiAgICAgIHN1c3BlbnNlLmVmZmVjdHMgPSBbXTtcbiAgICAgIGlmIChpc1N1c3BlbnNpYmxlKSB7XG4gICAgICAgIGlmIChwYXJlbnRTdXNwZW5zZSAmJiBwYXJlbnRTdXNwZW5zZS5wZW5kaW5nQnJhbmNoICYmIHBhcmVudFN1c3BlbnNlSWQgPT09IHBhcmVudFN1c3BlbnNlLnBlbmRpbmdJZCkge1xuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLmRlcHMtLTtcbiAgICAgICAgICBpZiAocGFyZW50U3VzcGVuc2UuZGVwcyA9PT0gMCAmJiAhc3luYykge1xuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UucmVzb2x2ZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdHJpZ2dlckV2ZW50KHZub2RlMiwgXCJvblJlc29sdmVcIik7XG4gICAgfSxcbiAgICBmYWxsYmFjayhmYWxsYmFja1ZOb2RlKSB7XG4gICAgICBpZiAoIXN1c3BlbnNlLnBlbmRpbmdCcmFuY2gpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB2bm9kZTogdm5vZGUyLCBhY3RpdmVCcmFuY2gsIHBhcmVudENvbXBvbmVudDogcGFyZW50Q29tcG9uZW50MiwgY29udGFpbmVyOiBjb250YWluZXIyLCBuYW1lc3BhY2U6IG5hbWVzcGFjZTIgfSA9IHN1c3BlbnNlO1xuICAgICAgdHJpZ2dlckV2ZW50KHZub2RlMiwgXCJvbkZhbGxiYWNrXCIpO1xuICAgICAgY29uc3QgYW5jaG9yMiA9IG5leHQoYWN0aXZlQnJhbmNoKTtcbiAgICAgIGNvbnN0IG1vdW50RmFsbGJhY2sgPSAoKSA9PiB7XG4gICAgICAgIHN1c3BlbnNlLmlzRmFsbGJhY2tNb3VudFBlbmRpbmcgPSBmYWxzZTtcbiAgICAgICAgaWYgKCFzdXNwZW5zZS5pc0luRmFsbGJhY2spIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgcGF0Y2goXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICBmYWxsYmFja1ZOb2RlLFxuICAgICAgICAgIGNvbnRhaW5lcjIsXG4gICAgICAgICAgYW5jaG9yMixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQyLFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgLy8gZmFsbGJhY2sgdHJlZSB3aWxsIG5vdCBoYXZlIHN1c3BlbnNlIGNvbnRleHRcbiAgICAgICAgICBuYW1lc3BhY2UyLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgICAgc2V0QWN0aXZlQnJhbmNoKHN1c3BlbnNlLCBmYWxsYmFja1ZOb2RlKTtcbiAgICAgIH07XG4gICAgICBjb25zdCBkZWxheUVudGVyID0gZmFsbGJhY2tWTm9kZS50cmFuc2l0aW9uICYmIGZhbGxiYWNrVk5vZGUudHJhbnNpdGlvbi5tb2RlID09PSBcIm91dC1pblwiO1xuICAgICAgaWYgKGRlbGF5RW50ZXIpIHtcbiAgICAgICAgc3VzcGVuc2UuaXNGYWxsYmFja01vdW50UGVuZGluZyA9IHRydWU7XG4gICAgICAgIGFjdGl2ZUJyYW5jaC50cmFuc2l0aW9uLmFmdGVyTGVhdmUgPSBtb3VudEZhbGxiYWNrO1xuICAgICAgfVxuICAgICAgc3VzcGVuc2UuaXNJbkZhbGxiYWNrID0gdHJ1ZTtcbiAgICAgIHVubW91bnQoXG4gICAgICAgIGFjdGl2ZUJyYW5jaCxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50MixcbiAgICAgICAgbnVsbCxcbiAgICAgICAgLy8gbm8gc3VzcGVuc2Ugc28gdW5tb3VudCBob29rcyBmaXJlIG5vd1xuICAgICAgICB0cnVlXG4gICAgICAgIC8vIHNob3VsZFJlbW92ZVxuICAgICAgKTtcbiAgICAgIGlmICghZGVsYXlFbnRlcikge1xuICAgICAgICBtb3VudEZhbGxiYWNrKCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBtb3ZlKGNvbnRhaW5lcjIsIGFuY2hvcjIsIHR5cGUpIHtcbiAgICAgIHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCAmJiBtb3ZlKHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCwgY29udGFpbmVyMiwgYW5jaG9yMiwgdHlwZSk7XG4gICAgICBzdXNwZW5zZS5jb250YWluZXIgPSBjb250YWluZXIyO1xuICAgIH0sXG4gICAgbmV4dCgpIHtcbiAgICAgIHJldHVybiBzdXNwZW5zZS5hY3RpdmVCcmFuY2ggJiYgbmV4dChzdXNwZW5zZS5hY3RpdmVCcmFuY2gpO1xuICAgIH0sXG4gICAgcmVnaXN0ZXJEZXAoaW5zdGFuY2UsIHNldHVwUmVuZGVyRWZmZWN0LCBvcHRpbWl6ZWQyKSB7XG4gICAgICBjb25zdCBpc0luUGVuZGluZ1N1c3BlbnNlID0gISFzdXNwZW5zZS5wZW5kaW5nQnJhbmNoO1xuICAgICAgaWYgKGlzSW5QZW5kaW5nU3VzcGVuc2UpIHtcbiAgICAgICAgc3VzcGVuc2UuZGVwcysrO1xuICAgICAgfVxuICAgICAgY29uc3QgaHlkcmF0ZWRFbCA9IGluc3RhbmNlLnZub2RlLmVsO1xuICAgICAgaW5zdGFuY2UuYXN5bmNEZXAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBoYW5kbGVFcnJvcihlcnIsIGluc3RhbmNlLCAwKTtcbiAgICAgIH0pLnRoZW4oKGFzeW5jU2V0dXBSZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGluc3RhbmNlLmlzVW5tb3VudGVkIHx8IHN1c3BlbnNlLmlzVW5tb3VudGVkIHx8IHN1c3BlbnNlLnBlbmRpbmdJZCAhPT0gaW5zdGFuY2Uuc3VzcGVuc2VJZCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB1bnNldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgICAgICBpbnN0YW5jZS5hc3luY1Jlc29sdmVkID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgeyB2bm9kZTogdm5vZGUyIH0gPSBpbnN0YW5jZTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBwdXNoV2FybmluZ0NvbnRleHQodm5vZGUyKTtcbiAgICAgICAgfVxuICAgICAgICBoYW5kbGVTZXR1cFJlc3VsdChpbnN0YW5jZSwgYXN5bmNTZXR1cFJlc3VsdCwgZmFsc2UpO1xuICAgICAgICBpZiAoaHlkcmF0ZWRFbCkge1xuICAgICAgICAgIHZub2RlMi5lbCA9IGh5ZHJhdGVkRWw7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGxhY2Vob2xkZXIgPSAhaHlkcmF0ZWRFbCAmJiBpbnN0YW5jZS5zdWJUcmVlLmVsO1xuICAgICAgICBzZXR1cFJlbmRlckVmZmVjdChcbiAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICB2bm9kZTIsXG4gICAgICAgICAgLy8gY29tcG9uZW50IG1heSBoYXZlIGJlZW4gbW92ZWQgYmVmb3JlIHJlc29sdmUuXG4gICAgICAgICAgLy8gaWYgdGhpcyBpcyBub3QgYSBoeWRyYXRpb24sIGluc3RhbmNlLnN1YlRyZWUgd2lsbCBiZSB0aGUgY29tbWVudFxuICAgICAgICAgIC8vIHBsYWNlaG9sZGVyLlxuICAgICAgICAgIHBhcmVudE5vZGUoaHlkcmF0ZWRFbCB8fCBpbnN0YW5jZS5zdWJUcmVlLmVsKSxcbiAgICAgICAgICAvLyBhbmNob3Igd2lsbCBub3QgYmUgdXNlZCBpZiB0aGlzIGlzIGh5ZHJhdGlvbiwgc28gb25seSBuZWVkIHRvXG4gICAgICAgICAgLy8gY29uc2lkZXIgdGhlIGNvbW1lbnQgcGxhY2Vob2xkZXIgY2FzZS5cbiAgICAgICAgICBoeWRyYXRlZEVsID8gbnVsbCA6IG5leHQoaW5zdGFuY2Uuc3ViVHJlZSksXG4gICAgICAgICAgc3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIG9wdGltaXplZDJcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHBsYWNlaG9sZGVyKSB7XG4gICAgICAgICAgdm5vZGUyLnBsYWNlaG9sZGVyID0gbnVsbDtcbiAgICAgICAgICByZW1vdmUocGxhY2Vob2xkZXIpO1xuICAgICAgICB9XG4gICAgICAgIHVwZGF0ZUhPQ0hvc3RFbChpbnN0YW5jZSwgdm5vZGUyLmVsKTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBwb3BXYXJuaW5nQ29udGV4dCgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0luUGVuZGluZ1N1c3BlbnNlICYmIC0tc3VzcGVuc2UuZGVwcyA9PT0gMCkge1xuICAgICAgICAgIHN1c3BlbnNlLnJlc29sdmUoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSxcbiAgICB1bm1vdW50KHBhcmVudFN1c3BlbnNlMiwgZG9SZW1vdmUpIHtcbiAgICAgIHN1c3BlbnNlLmlzVW5tb3VudGVkID0gdHJ1ZTtcbiAgICAgIGlmIChzdXNwZW5zZS5hY3RpdmVCcmFuY2gpIHtcbiAgICAgICAgdW5tb3VudChcbiAgICAgICAgICBzdXNwZW5zZS5hY3RpdmVCcmFuY2gsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlMixcbiAgICAgICAgICBkb1JlbW92ZVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKHN1c3BlbnNlLnBlbmRpbmdCcmFuY2gpIHtcbiAgICAgICAgdW5tb3VudChcbiAgICAgICAgICBzdXNwZW5zZS5wZW5kaW5nQnJhbmNoLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZTIsXG4gICAgICAgICAgZG9SZW1vdmVcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHJldHVybiBzdXNwZW5zZTtcbn1cbmZ1bmN0aW9uIGh5ZHJhdGVTdXNwZW5zZShub2RlLCB2bm9kZSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCwgcmVuZGVyZXJJbnRlcm5hbHMsIGh5ZHJhdGVOb2RlKSB7XG4gIGNvbnN0IHN1c3BlbnNlID0gdm5vZGUuc3VzcGVuc2UgPSBjcmVhdGVTdXNwZW5zZUJvdW5kYXJ5KFxuICAgIHZub2RlLFxuICAgIHBhcmVudFN1c3BlbnNlLFxuICAgIHBhcmVudENvbXBvbmVudCxcbiAgICBub2RlLnBhcmVudE5vZGUsXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtZ2xvYmFsc1xuICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksXG4gICAgbnVsbCxcbiAgICBuYW1lc3BhY2UsXG4gICAgc2xvdFNjb3BlSWRzLFxuICAgIG9wdGltaXplZCxcbiAgICByZW5kZXJlckludGVybmFscyxcbiAgICB0cnVlXG4gICk7XG4gIGNvbnN0IHJlc3VsdCA9IGh5ZHJhdGVOb2RlKFxuICAgIG5vZGUsXG4gICAgc3VzcGVuc2UucGVuZGluZ0JyYW5jaCA9IHZub2RlLnNzQ29udGVudCxcbiAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgc3VzcGVuc2UsXG4gICAgc2xvdFNjb3BlSWRzLFxuICAgIG9wdGltaXplZFxuICApO1xuICBpZiAoc3VzcGVuc2UuZGVwcyA9PT0gMCkge1xuICAgIHN1c3BlbnNlLnJlc29sdmUoZmFsc2UsIHRydWUpO1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBub3JtYWxpemVTdXNwZW5zZUNoaWxkcmVuKHZub2RlKSB7XG4gIGNvbnN0IHsgc2hhcGVGbGFnLCBjaGlsZHJlbiB9ID0gdm5vZGU7XG4gIGNvbnN0IGlzU2xvdENoaWxkcmVuID0gc2hhcGVGbGFnICYgMzI7XG4gIHZub2RlLnNzQ29udGVudCA9IG5vcm1hbGl6ZVN1c3BlbnNlU2xvdChcbiAgICBpc1Nsb3RDaGlsZHJlbiA/IGNoaWxkcmVuLmRlZmF1bHQgOiBjaGlsZHJlblxuICApO1xuICB2bm9kZS5zc0ZhbGxiYWNrID0gaXNTbG90Q2hpbGRyZW4gPyBub3JtYWxpemVTdXNwZW5zZVNsb3QoY2hpbGRyZW4uZmFsbGJhY2spIDogY3JlYXRlVk5vZGUoQ29tbWVudCk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVTdXNwZW5zZVNsb3Qocykge1xuICBsZXQgYmxvY2s7XG4gIGlmIChpc0Z1bmN0aW9uKHMpKSB7XG4gICAgY29uc3QgdHJhY2tCbG9jayA9IGlzQmxvY2tUcmVlRW5hYmxlZCAmJiBzLl9jO1xuICAgIGlmICh0cmFja0Jsb2NrKSB7XG4gICAgICBzLl9kID0gZmFsc2U7XG4gICAgICBvcGVuQmxvY2soKTtcbiAgICB9XG4gICAgcyA9IHMoKTtcbiAgICBpZiAodHJhY2tCbG9jaykge1xuICAgICAgcy5fZCA9IHRydWU7XG4gICAgICBibG9jayA9IGN1cnJlbnRCbG9jaztcbiAgICAgIGNsb3NlQmxvY2soKTtcbiAgICB9XG4gIH1cbiAgaWYgKGlzQXJyYXkocykpIHtcbiAgICBjb25zdCBzaW5nbGVDaGlsZCA9IGZpbHRlclNpbmdsZVJvb3Qocyk7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIXNpbmdsZUNoaWxkICYmIHMuZmlsdGVyKChjaGlsZCkgPT4gY2hpbGQgIT09IE5VTExfRFlOQU1JQ19DT01QT05FTlQpLmxlbmd0aCA+IDApIHtcbiAgICAgIHdhcm4kMShgPFN1c3BlbnNlPiBzbG90cyBleHBlY3QgYSBzaW5nbGUgcm9vdCBub2RlLmApO1xuICAgIH1cbiAgICBzID0gc2luZ2xlQ2hpbGQ7XG4gIH1cbiAgcyA9IG5vcm1hbGl6ZVZOb2RlKHMpO1xuICBpZiAoYmxvY2sgJiYgIXMuZHluYW1pY0NoaWxkcmVuKSB7XG4gICAgcy5keW5hbWljQ2hpbGRyZW4gPSBibG9jay5maWx0ZXIoKGMpID0+IGMgIT09IHMpO1xuICB9XG4gIHJldHVybiBzO1xufVxuZnVuY3Rpb24gcXVldWVFZmZlY3RXaXRoU3VzcGVuc2UoZm4sIHN1c3BlbnNlKSB7XG4gIGlmIChzdXNwZW5zZSAmJiBzdXNwZW5zZS5wZW5kaW5nQnJhbmNoKSB7XG4gICAgaWYgKGlzQXJyYXkoZm4pKSB7XG4gICAgICBzdXNwZW5zZS5lZmZlY3RzLnB1c2goLi4uZm4pO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdXNwZW5zZS5lZmZlY3RzLnB1c2goZm4pO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBxdWV1ZVBvc3RGbHVzaENiKGZuKTtcbiAgfVxufVxuZnVuY3Rpb24gc2V0QWN0aXZlQnJhbmNoKHN1c3BlbnNlLCBicmFuY2gpIHtcbiAgc3VzcGVuc2UuYWN0aXZlQnJhbmNoID0gYnJhbmNoO1xuICBjb25zdCB7IHZub2RlLCBwYXJlbnRDb21wb25lbnQgfSA9IHN1c3BlbnNlO1xuICBsZXQgZWwgPSBicmFuY2guZWw7XG4gIHdoaWxlICghZWwgJiYgYnJhbmNoLmNvbXBvbmVudCkge1xuICAgIGJyYW5jaCA9IGJyYW5jaC5jb21wb25lbnQuc3ViVHJlZTtcbiAgICBlbCA9IGJyYW5jaC5lbDtcbiAgfVxuICB2bm9kZS5lbCA9IGVsO1xuICBpZiAocGFyZW50Q29tcG9uZW50ICYmIHBhcmVudENvbXBvbmVudC5zdWJUcmVlID09PSB2bm9kZSkge1xuICAgIHBhcmVudENvbXBvbmVudC52bm9kZS5lbCA9IGVsO1xuICAgIHVwZGF0ZUhPQ0hvc3RFbChwYXJlbnRDb21wb25lbnQsIGVsKTtcbiAgfVxufVxuZnVuY3Rpb24gaXNWTm9kZVN1c3BlbnNpYmxlKHZub2RlKSB7XG4gIGNvbnN0IHN1c3BlbnNpYmxlID0gdm5vZGUucHJvcHMgJiYgdm5vZGUucHJvcHMuc3VzcGVuc2libGU7XG4gIHJldHVybiBzdXNwZW5zaWJsZSAhPSBudWxsICYmIHN1c3BlbnNpYmxlICE9PSBmYWxzZTtcbn1cblxuY29uc3QgRnJhZ21lbnQgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sLmZvcihcInYtZmd0XCIpO1xuY29uc3QgVGV4dCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwidi10eHRcIik7XG5jb25zdCBDb21tZW50ID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJ2LWNtdFwiKTtcbmNvbnN0IFN0YXRpYyA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwidi1zdGNcIik7XG5jb25zdCBibG9ja1N0YWNrID0gW107XG5sZXQgY3VycmVudEJsb2NrID0gbnVsbDtcbmZ1bmN0aW9uIG9wZW5CbG9jayhkaXNhYmxlVHJhY2tpbmcgPSBmYWxzZSkge1xuICBibG9ja1N0YWNrLnB1c2goY3VycmVudEJsb2NrID0gZGlzYWJsZVRyYWNraW5nID8gbnVsbCA6IFtdKTtcbn1cbmZ1bmN0aW9uIGNsb3NlQmxvY2soKSB7XG4gIGJsb2NrU3RhY2sucG9wKCk7XG4gIGN1cnJlbnRCbG9jayA9IGJsb2NrU3RhY2tbYmxvY2tTdGFjay5sZW5ndGggLSAxXSB8fCBudWxsO1xufVxubGV0IGlzQmxvY2tUcmVlRW5hYmxlZCA9IDE7XG5mdW5jdGlvbiBzZXRCbG9ja1RyYWNraW5nKHZhbHVlLCBpblZPbmNlID0gZmFsc2UpIHtcbiAgaXNCbG9ja1RyZWVFbmFibGVkICs9IHZhbHVlO1xuICBpZiAodmFsdWUgPCAwICYmIGN1cnJlbnRCbG9jayAmJiBpblZPbmNlKSB7XG4gICAgY3VycmVudEJsb2NrLmhhc09uY2UgPSB0cnVlO1xuICB9XG59XG5mdW5jdGlvbiBzZXR1cEJsb2NrKHZub2RlKSB7XG4gIHZub2RlLmR5bmFtaWNDaGlsZHJlbiA9IGlzQmxvY2tUcmVlRW5hYmxlZCA+IDAgPyBjdXJyZW50QmxvY2sgfHwgRU1QVFlfQVJSIDogbnVsbDtcbiAgY2xvc2VCbG9jaygpO1xuICBpZiAoaXNCbG9ja1RyZWVFbmFibGVkID4gMCAmJiBjdXJyZW50QmxvY2spIHtcbiAgICBjdXJyZW50QmxvY2sucHVzaCh2bm9kZSk7XG4gIH1cbiAgcmV0dXJuIHZub2RlO1xufVxuZnVuY3Rpb24gY3JlYXRlRWxlbWVudEJsb2NrKHR5cGUsIHByb3BzLCBjaGlsZHJlbiwgcGF0Y2hGbGFnLCBkeW5hbWljUHJvcHMsIHNoYXBlRmxhZykge1xuICByZXR1cm4gc2V0dXBCbG9jayhcbiAgICBjcmVhdGVCYXNlVk5vZGUoXG4gICAgICB0eXBlLFxuICAgICAgcHJvcHMsXG4gICAgICBjaGlsZHJlbixcbiAgICAgIHBhdGNoRmxhZyxcbiAgICAgIGR5bmFtaWNQcm9wcyxcbiAgICAgIHNoYXBlRmxhZyxcbiAgICAgIHRydWVcbiAgICApXG4gICk7XG59XG5mdW5jdGlvbiBjcmVhdGVCbG9jayh0eXBlLCBwcm9wcywgY2hpbGRyZW4sIHBhdGNoRmxhZywgZHluYW1pY1Byb3BzKSB7XG4gIHJldHVybiBzZXR1cEJsb2NrKFxuICAgIGNyZWF0ZVZOb2RlKFxuICAgICAgdHlwZSxcbiAgICAgIHByb3BzLFxuICAgICAgY2hpbGRyZW4sXG4gICAgICBwYXRjaEZsYWcsXG4gICAgICBkeW5hbWljUHJvcHMsXG4gICAgICB0cnVlXG4gICAgKVxuICApO1xufVxuZnVuY3Rpb24gaXNWTm9kZSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgPyB2YWx1ZS5fX3ZfaXNWTm9kZSA9PT0gdHJ1ZSA6IGZhbHNlO1xufVxuZnVuY3Rpb24gaXNTYW1lVk5vZGVUeXBlKG4xLCBuMikge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBuMi5zaGFwZUZsYWcgJiA2ICYmIG4xLmNvbXBvbmVudCkge1xuICAgIGNvbnN0IGRpcnR5SW5zdGFuY2VzID0gaG1yRGlydHlDb21wb25lbnRzLmdldChuMi50eXBlKTtcbiAgICBpZiAoZGlydHlJbnN0YW5jZXMgJiYgZGlydHlJbnN0YW5jZXMuaGFzKG4xLmNvbXBvbmVudCkpIHtcbiAgICAgIG4xLnNoYXBlRmxhZyAmPSAtMjU3O1xuICAgICAgbjIuc2hhcGVGbGFnICY9IC01MTM7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIHJldHVybiBuMS50eXBlID09PSBuMi50eXBlICYmIG4xLmtleSA9PT0gbjIua2V5O1xufVxubGV0IHZub2RlQXJnc1RyYW5zZm9ybWVyO1xuZnVuY3Rpb24gdHJhbnNmb3JtVk5vZGVBcmdzKHRyYW5zZm9ybWVyKSB7XG4gIHZub2RlQXJnc1RyYW5zZm9ybWVyID0gdHJhbnNmb3JtZXI7XG59XG5jb25zdCBjcmVhdGVWTm9kZVdpdGhBcmdzVHJhbnNmb3JtID0gKC4uLmFyZ3MpID0+IHtcbiAgcmV0dXJuIF9jcmVhdGVWTm9kZShcbiAgICAuLi52bm9kZUFyZ3NUcmFuc2Zvcm1lciA/IHZub2RlQXJnc1RyYW5zZm9ybWVyKGFyZ3MsIGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSkgOiBhcmdzXG4gICk7XG59O1xuY29uc3Qgbm9ybWFsaXplS2V5ID0gKHsga2V5IH0pID0+IGtleSAhPSBudWxsID8ga2V5IDogbnVsbDtcbmNvbnN0IG5vcm1hbGl6ZVJlZiA9ICh7XG4gIHJlZixcbiAgcmVmX2tleSxcbiAgcmVmX2ZvclxufSkgPT4ge1xuICBpZiAodHlwZW9mIHJlZiA9PT0gXCJudW1iZXJcIikge1xuICAgIHJlZiA9IFwiXCIgKyByZWY7XG4gIH1cbiAgcmV0dXJuIHJlZiAhPSBudWxsID8gaXNTdHJpbmcocmVmKSB8fCBpc1JlZihyZWYpIHx8IGlzRnVuY3Rpb24ocmVmKSA/IHsgaTogY3VycmVudFJlbmRlcmluZ0luc3RhbmNlLCByOiByZWYsIGs6IHJlZl9rZXksIGY6ICEhcmVmX2ZvciB9IDogcmVmIDogbnVsbDtcbn07XG5mdW5jdGlvbiBjcmVhdGVCYXNlVk5vZGUodHlwZSwgcHJvcHMgPSBudWxsLCBjaGlsZHJlbiA9IG51bGwsIHBhdGNoRmxhZyA9IDAsIGR5bmFtaWNQcm9wcyA9IG51bGwsIHNoYXBlRmxhZyA9IHR5cGUgPT09IEZyYWdtZW50ID8gMCA6IDEsIGlzQmxvY2tOb2RlID0gZmFsc2UsIG5lZWRGdWxsQ2hpbGRyZW5Ob3JtYWxpemF0aW9uID0gZmFsc2UpIHtcbiAgY29uc3Qgdm5vZGUgPSB7XG4gICAgX192X2lzVk5vZGU6IHRydWUsXG4gICAgX192X3NraXA6IHRydWUsXG4gICAgdHlwZSxcbiAgICBwcm9wcyxcbiAgICBrZXk6IHByb3BzICYmIG5vcm1hbGl6ZUtleShwcm9wcyksXG4gICAgcmVmOiBwcm9wcyAmJiBub3JtYWxpemVSZWYocHJvcHMpLFxuICAgIHNjb3BlSWQ6IGN1cnJlbnRTY29wZUlkLFxuICAgIHNsb3RTY29wZUlkczogbnVsbCxcbiAgICBjaGlsZHJlbixcbiAgICBjb21wb25lbnQ6IG51bGwsXG4gICAgc3VzcGVuc2U6IG51bGwsXG4gICAgc3NDb250ZW50OiBudWxsLFxuICAgIHNzRmFsbGJhY2s6IG51bGwsXG4gICAgZGlyczogbnVsbCxcbiAgICB0cmFuc2l0aW9uOiBudWxsLFxuICAgIGVsOiBudWxsLFxuICAgIGFuY2hvcjogbnVsbCxcbiAgICB0YXJnZXQ6IG51bGwsXG4gICAgdGFyZ2V0U3RhcnQ6IG51bGwsXG4gICAgdGFyZ2V0QW5jaG9yOiBudWxsLFxuICAgIHN0YXRpY0NvdW50OiAwLFxuICAgIHNoYXBlRmxhZyxcbiAgICBwYXRjaEZsYWcsXG4gICAgZHluYW1pY1Byb3BzLFxuICAgIGR5bmFtaWNDaGlsZHJlbjogbnVsbCxcbiAgICBhcHBDb250ZXh0OiBudWxsLFxuICAgIGN0eDogY3VycmVudFJlbmRlcmluZ0luc3RhbmNlXG4gIH07XG4gIGlmIChuZWVkRnVsbENoaWxkcmVuTm9ybWFsaXphdGlvbikge1xuICAgIG5vcm1hbGl6ZUNoaWxkcmVuKHZub2RlLCBjaGlsZHJlbik7XG4gICAgaWYgKHNoYXBlRmxhZyAmIDEyOCkge1xuICAgICAgdHlwZS5ub3JtYWxpemUodm5vZGUpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChjaGlsZHJlbikge1xuICAgIHZub2RlLnNoYXBlRmxhZyB8PSBpc1N0cmluZyhjaGlsZHJlbikgPyA4IDogMTY7XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdm5vZGUua2V5ICE9PSB2bm9kZS5rZXkpIHtcbiAgICB3YXJuJDEoYFZOb2RlIGNyZWF0ZWQgd2l0aCBpbnZhbGlkIGtleSAoTmFOKS4gVk5vZGUgdHlwZTpgLCB2bm9kZS50eXBlKTtcbiAgfVxuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBwcm9wcyAmJiB2bm9kZS5zaGFwZUZsYWcgJiAxKSB7XG4gICAgY29uc3Qgb3ZlcndyaXRpbmdQcm9wID0gcHJvcHMuaW5uZXJIVE1MICE9IG51bGwgPyBcImlubmVySFRNTFwiIDogcHJvcHMudGV4dENvbnRlbnQgIT0gbnVsbCA/IFwidGV4dENvbnRlbnRcIiA6IG51bGw7XG4gICAgaWYgKG92ZXJ3cml0aW5nUHJvcCAmJiBoYXNDb250ZW50Q2hpbGRyZW4odm5vZGUuY2hpbGRyZW4pKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBUaGUgXFxgJHtvdmVyd3JpdGluZ1Byb3B9XFxgIHByb3Agb24gPCR7dm5vZGUudHlwZX0+IHdpbGwgb3ZlcnJpZGUgaXRzIGNoaWxkcmVuLiBSZW1vdmUgZWl0aGVyIHRoZSBcXGAke292ZXJ3cml0aW5nUHJvcH1cXGAgcHJvcCBvciB0aGUgY2hpbGRyZW4uYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgaWYgKGlzQmxvY2tUcmVlRW5hYmxlZCA+IDAgJiYgLy8gYXZvaWQgYSBibG9jayBub2RlIGZyb20gdHJhY2tpbmcgaXRzZWxmXG4gICFpc0Jsb2NrTm9kZSAmJiAvLyBoYXMgY3VycmVudCBwYXJlbnQgYmxvY2tcbiAgY3VycmVudEJsb2NrICYmIC8vIHByZXNlbmNlIG9mIGEgcGF0Y2ggZmxhZyBpbmRpY2F0ZXMgdGhpcyBub2RlIG5lZWRzIHBhdGNoaW5nIG9uIHVwZGF0ZXMuXG4gIC8vIGNvbXBvbmVudCBub2RlcyBhbHNvIHNob3VsZCBhbHdheXMgYmUgcGF0Y2hlZCwgYmVjYXVzZSBldmVuIGlmIHRoZVxuICAvLyBjb21wb25lbnQgZG9lc24ndCBuZWVkIHRvIHVwZGF0ZSwgaXQgbmVlZHMgdG8gcGVyc2lzdCB0aGUgaW5zdGFuY2Ugb24gdG9cbiAgLy8gdGhlIG5leHQgdm5vZGUgc28gdGhhdCBpdCBjYW4gYmUgcHJvcGVybHkgdW5tb3VudGVkIGxhdGVyLlxuICAodm5vZGUucGF0Y2hGbGFnID4gMCB8fCBzaGFwZUZsYWcgJiA2KSAmJiAvLyB0aGUgRVZFTlRTIGZsYWcgaXMgb25seSBmb3IgaHlkcmF0aW9uIGFuZCBpZiBpdCBpcyB0aGUgb25seSBmbGFnLCB0aGVcbiAgLy8gdm5vZGUgc2hvdWxkIG5vdCBiZSBjb25zaWRlcmVkIGR5bmFtaWMgZHVlIHRvIGhhbmRsZXIgY2FjaGluZy5cbiAgdm5vZGUucGF0Y2hGbGFnICE9PSAzMikge1xuICAgIGN1cnJlbnRCbG9jay5wdXNoKHZub2RlKTtcbiAgfVxuICByZXR1cm4gdm5vZGU7XG59XG5mdW5jdGlvbiBoYXNDb250ZW50Q2hpbGRyZW4oY2hpbGRyZW4pIHtcbiAgaWYgKGlzU3RyaW5nKGNoaWxkcmVuKSkgcmV0dXJuIGNoaWxkcmVuICE9PSBcIlwiO1xuICBpZiAoaXNBcnJheShjaGlsZHJlbikpIHJldHVybiBjaGlsZHJlbi5sZW5ndGggPiAwO1xuICByZXR1cm4gZmFsc2U7XG59XG5jb25zdCBjcmVhdGVWTm9kZSA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBjcmVhdGVWTm9kZVdpdGhBcmdzVHJhbnNmb3JtIDogX2NyZWF0ZVZOb2RlO1xuZnVuY3Rpb24gX2NyZWF0ZVZOb2RlKHR5cGUsIHByb3BzID0gbnVsbCwgY2hpbGRyZW4gPSBudWxsLCBwYXRjaEZsYWcgPSAwLCBkeW5hbWljUHJvcHMgPSBudWxsLCBpc0Jsb2NrTm9kZSA9IGZhbHNlKSB7XG4gIGlmICghdHlwZSB8fCB0eXBlID09PSBOVUxMX0RZTkFNSUNfQ09NUE9ORU5UKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIXR5cGUpIHtcbiAgICAgIHdhcm4kMShgSW52YWxpZCB2bm9kZSB0eXBlIHdoZW4gY3JlYXRpbmcgdm5vZGU6ICR7dHlwZX0uYCk7XG4gICAgfVxuICAgIHR5cGUgPSBDb21tZW50O1xuICB9XG4gIGlmIChpc1ZOb2RlKHR5cGUpKSB7XG4gICAgY29uc3QgY2xvbmVkID0gY2xvbmVWTm9kZShcbiAgICAgIHR5cGUsXG4gICAgICBwcm9wcyxcbiAgICAgIHRydWVcbiAgICAgIC8qIG1lcmdlUmVmOiB0cnVlICovXG4gICAgKTtcbiAgICBpZiAoY2hpbGRyZW4pIHtcbiAgICAgIG5vcm1hbGl6ZUNoaWxkcmVuKGNsb25lZCwgY2hpbGRyZW4pO1xuICAgIH1cbiAgICBpZiAoaXNCbG9ja1RyZWVFbmFibGVkID4gMCAmJiAhaXNCbG9ja05vZGUgJiYgY3VycmVudEJsb2NrKSB7XG4gICAgICBpZiAoY2xvbmVkLnNoYXBlRmxhZyAmIDYpIHtcbiAgICAgICAgY3VycmVudEJsb2NrW2N1cnJlbnRCbG9jay5pbmRleE9mKHR5cGUpXSA9IGNsb25lZDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGN1cnJlbnRCbG9jay5wdXNoKGNsb25lZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGNsb25lZC5wYXRjaEZsYWcgPSAtMjtcbiAgICByZXR1cm4gY2xvbmVkO1xuICB9XG4gIGlmIChpc0NsYXNzQ29tcG9uZW50KHR5cGUpKSB7XG4gICAgdHlwZSA9IHR5cGUuX192Y2NPcHRzO1xuICB9XG4gIGlmIChwcm9wcykge1xuICAgIHByb3BzID0gZ3VhcmRSZWFjdGl2ZVByb3BzKHByb3BzKTtcbiAgICBsZXQgeyBjbGFzczoga2xhc3MsIHN0eWxlIH0gPSBwcm9wcztcbiAgICBpZiAoa2xhc3MgJiYgIWlzU3RyaW5nKGtsYXNzKSkge1xuICAgICAgcHJvcHMuY2xhc3MgPSBub3JtYWxpemVDbGFzcyhrbGFzcyk7XG4gICAgfVxuICAgIGlmIChpc09iamVjdChzdHlsZSkpIHtcbiAgICAgIGlmIChpc1Byb3h5KHN0eWxlKSAmJiAhaXNBcnJheShzdHlsZSkpIHtcbiAgICAgICAgc3R5bGUgPSBleHRlbmQoe30sIHN0eWxlKTtcbiAgICAgIH1cbiAgICAgIHByb3BzLnN0eWxlID0gbm9ybWFsaXplU3R5bGUoc3R5bGUpO1xuICAgIH1cbiAgfVxuICBjb25zdCBzaGFwZUZsYWcgPSBpc1N0cmluZyh0eXBlKSA/IDEgOiBpc1N1c3BlbnNlKHR5cGUpID8gMTI4IDogaXNUZWxlcG9ydCh0eXBlKSA/IDY0IDogaXNPYmplY3QodHlwZSkgPyA0IDogaXNGdW5jdGlvbih0eXBlKSA/IDIgOiAwO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBzaGFwZUZsYWcgJiA0ICYmIGlzUHJveHkodHlwZSkpIHtcbiAgICB0eXBlID0gdG9SYXcodHlwZSk7XG4gICAgd2FybiQxKFxuICAgICAgYFZ1ZSByZWNlaXZlZCBhIENvbXBvbmVudCB0aGF0IHdhcyBtYWRlIGEgcmVhY3RpdmUgb2JqZWN0LiBUaGlzIGNhbiBsZWFkIHRvIHVubmVjZXNzYXJ5IHBlcmZvcm1hbmNlIG92ZXJoZWFkIGFuZCBzaG91bGQgYmUgYXZvaWRlZCBieSBtYXJraW5nIHRoZSBjb21wb25lbnQgd2l0aCBcXGBtYXJrUmF3XFxgIG9yIHVzaW5nIFxcYHNoYWxsb3dSZWZcXGAgaW5zdGVhZCBvZiBcXGByZWZcXGAuYCxcbiAgICAgIGBcbkNvbXBvbmVudCB0aGF0IHdhcyBtYWRlIHJlYWN0aXZlOiBgLFxuICAgICAgdHlwZVxuICAgICk7XG4gIH1cbiAgcmV0dXJuIGNyZWF0ZUJhc2VWTm9kZShcbiAgICB0eXBlLFxuICAgIHByb3BzLFxuICAgIGNoaWxkcmVuLFxuICAgIHBhdGNoRmxhZyxcbiAgICBkeW5hbWljUHJvcHMsXG4gICAgc2hhcGVGbGFnLFxuICAgIGlzQmxvY2tOb2RlLFxuICAgIHRydWVcbiAgKTtcbn1cbmZ1bmN0aW9uIGd1YXJkUmVhY3RpdmVQcm9wcyhwcm9wcykge1xuICBpZiAoIXByb3BzKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGlzUHJveHkocHJvcHMpIHx8IGlzSW50ZXJuYWxPYmplY3QocHJvcHMpID8gZXh0ZW5kKHt9LCBwcm9wcykgOiBwcm9wcztcbn1cbmZ1bmN0aW9uIGNsb25lVk5vZGUodm5vZGUsIGV4dHJhUHJvcHMsIG1lcmdlUmVmID0gZmFsc2UsIGNsb25lVHJhbnNpdGlvbiA9IGZhbHNlKSB7XG4gIGNvbnN0IHsgcHJvcHMsIHJlZiwgcGF0Y2hGbGFnLCBjaGlsZHJlbiwgdHJhbnNpdGlvbiB9ID0gdm5vZGU7XG4gIGNvbnN0IG1lcmdlZFByb3BzID0gZXh0cmFQcm9wcyA/IG1lcmdlUHJvcHMocHJvcHMgfHwge30sIGV4dHJhUHJvcHMpIDogcHJvcHM7XG4gIGNvbnN0IGNsb25lZCA9IHtcbiAgICBfX3ZfaXNWTm9kZTogdHJ1ZSxcbiAgICBfX3Zfc2tpcDogdHJ1ZSxcbiAgICB0eXBlOiB2bm9kZS50eXBlLFxuICAgIHByb3BzOiBtZXJnZWRQcm9wcyxcbiAgICBrZXk6IG1lcmdlZFByb3BzICYmIG5vcm1hbGl6ZUtleShtZXJnZWRQcm9wcyksXG4gICAgcmVmOiBleHRyYVByb3BzICYmIGV4dHJhUHJvcHMucmVmID8gKFxuICAgICAgLy8gIzIwNzggaW4gdGhlIGNhc2Ugb2YgPGNvbXBvbmVudCA6aXM9XCJ2bm9kZVwiIHJlZj1cImV4dHJhXCIvPlxuICAgICAgLy8gaWYgdGhlIHZub2RlIGl0c2VsZiBhbHJlYWR5IGhhcyBhIHJlZiwgY2xvbmVWTm9kZSB3aWxsIG5lZWQgdG8gbWVyZ2VcbiAgICAgIC8vIHRoZSByZWZzIHNvIHRoZSBzaW5nbGUgdm5vZGUgY2FuIGJlIHNldCBvbiBtdWx0aXBsZSByZWZzXG4gICAgICBtZXJnZVJlZiAmJiByZWYgPyBpc0FycmF5KHJlZikgPyByZWYuY29uY2F0KG5vcm1hbGl6ZVJlZihleHRyYVByb3BzKSkgOiBbcmVmLCBub3JtYWxpemVSZWYoZXh0cmFQcm9wcyldIDogbm9ybWFsaXplUmVmKGV4dHJhUHJvcHMpXG4gICAgKSA6IHJlZixcbiAgICBzY29wZUlkOiB2bm9kZS5zY29wZUlkLFxuICAgIHNsb3RTY29wZUlkczogdm5vZGUuc2xvdFNjb3BlSWRzLFxuICAgIGNoaWxkcmVuOiAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHBhdGNoRmxhZyA9PT0gLTEgJiYgaXNBcnJheShjaGlsZHJlbikgPyBjaGlsZHJlbi5tYXAoZGVlcENsb25lVk5vZGUpIDogY2hpbGRyZW4sXG4gICAgdGFyZ2V0OiB2bm9kZS50YXJnZXQsXG4gICAgdGFyZ2V0U3RhcnQ6IHZub2RlLnRhcmdldFN0YXJ0LFxuICAgIHRhcmdldEFuY2hvcjogdm5vZGUudGFyZ2V0QW5jaG9yLFxuICAgIHN0YXRpY0NvdW50OiB2bm9kZS5zdGF0aWNDb3VudCxcbiAgICBzaGFwZUZsYWc6IHZub2RlLnNoYXBlRmxhZyxcbiAgICAvLyBpZiB0aGUgdm5vZGUgaXMgY2xvbmVkIHdpdGggZXh0cmEgcHJvcHMsIHdlIGNhbiBubyBsb25nZXIgYXNzdW1lIGl0c1xuICAgIC8vIGV4aXN0aW5nIHBhdGNoIGZsYWcgdG8gYmUgcmVsaWFibGUgYW5kIG5lZWQgdG8gYWRkIHRoZSBGVUxMX1BST1BTIGZsYWcuXG4gICAgLy8gbm90ZTogcHJlc2VydmUgZmxhZyBmb3IgZnJhZ21lbnRzIHNpbmNlIHRoZXkgdXNlIHRoZSBmbGFnIGZvciBjaGlsZHJlblxuICAgIC8vIGZhc3QgcGF0aHMgb25seS5cbiAgICBwYXRjaEZsYWc6IGV4dHJhUHJvcHMgJiYgdm5vZGUudHlwZSAhPT0gRnJhZ21lbnQgPyBwYXRjaEZsYWcgPT09IC0xID8gMTYgOiBwYXRjaEZsYWcgfCAxNiA6IHBhdGNoRmxhZyxcbiAgICBkeW5hbWljUHJvcHM6IHZub2RlLmR5bmFtaWNQcm9wcyxcbiAgICBkeW5hbWljQ2hpbGRyZW46IHZub2RlLmR5bmFtaWNDaGlsZHJlbixcbiAgICBhcHBDb250ZXh0OiB2bm9kZS5hcHBDb250ZXh0LFxuICAgIGRpcnM6IHZub2RlLmRpcnMsXG4gICAgdHJhbnNpdGlvbixcbiAgICAvLyBUaGVzZSBzaG91bGQgdGVjaG5pY2FsbHkgb25seSBiZSBub24tbnVsbCBvbiBtb3VudGVkIFZOb2Rlcy4gSG93ZXZlcixcbiAgICAvLyB0aGV5ICpzaG91bGQqIGJlIGNvcGllZCBmb3Iga2VwdC1hbGl2ZSB2bm9kZXMuIFNvIHdlIGp1c3QgYWx3YXlzIGNvcHlcbiAgICAvLyB0aGVtIHNpbmNlIHRoZW0gYmVpbmcgbm9uLW51bGwgZHVyaW5nIGEgbW91bnQgZG9lc24ndCBhZmZlY3QgdGhlIGxvZ2ljIGFzXG4gICAgLy8gdGhleSB3aWxsIHNpbXBseSBiZSBvdmVyd3JpdHRlbi5cbiAgICBjb21wb25lbnQ6IHZub2RlLmNvbXBvbmVudCxcbiAgICBzdXNwZW5zZTogdm5vZGUuc3VzcGVuc2UsXG4gICAgc3NDb250ZW50OiB2bm9kZS5zc0NvbnRlbnQgJiYgY2xvbmVWTm9kZSh2bm9kZS5zc0NvbnRlbnQpLFxuICAgIHNzRmFsbGJhY2s6IHZub2RlLnNzRmFsbGJhY2sgJiYgY2xvbmVWTm9kZSh2bm9kZS5zc0ZhbGxiYWNrKSxcbiAgICBwbGFjZWhvbGRlcjogdm5vZGUucGxhY2Vob2xkZXIsXG4gICAgZWw6IHZub2RlLmVsLFxuICAgIGFuY2hvcjogdm5vZGUuYW5jaG9yLFxuICAgIGN0eDogdm5vZGUuY3R4LFxuICAgIGNlOiB2bm9kZS5jZVxuICB9O1xuICBpZiAodHJhbnNpdGlvbiAmJiBjbG9uZVRyYW5zaXRpb24pIHtcbiAgICBzZXRUcmFuc2l0aW9uSG9va3MoXG4gICAgICBjbG9uZWQsXG4gICAgICB0cmFuc2l0aW9uLmNsb25lKGNsb25lZClcbiAgICApO1xuICB9XG4gIHJldHVybiBjbG9uZWQ7XG59XG5mdW5jdGlvbiBkZWVwQ2xvbmVWTm9kZSh2bm9kZSkge1xuICBjb25zdCBjbG9uZWQgPSBjbG9uZVZOb2RlKHZub2RlKTtcbiAgaWYgKGlzQXJyYXkodm5vZGUuY2hpbGRyZW4pKSB7XG4gICAgY2xvbmVkLmNoaWxkcmVuID0gdm5vZGUuY2hpbGRyZW4ubWFwKGRlZXBDbG9uZVZOb2RlKTtcbiAgfVxuICByZXR1cm4gY2xvbmVkO1xufVxuZnVuY3Rpb24gY3JlYXRlVGV4dFZOb2RlKHRleHQgPSBcIiBcIiwgZmxhZyA9IDApIHtcbiAgcmV0dXJuIGNyZWF0ZVZOb2RlKFRleHQsIG51bGwsIHRleHQsIGZsYWcpO1xufVxuZnVuY3Rpb24gY3JlYXRlU3RhdGljVk5vZGUoY29udGVudCwgbnVtYmVyT2ZOb2Rlcykge1xuICBjb25zdCB2bm9kZSA9IGNyZWF0ZVZOb2RlKFN0YXRpYywgbnVsbCwgY29udGVudCk7XG4gIHZub2RlLnN0YXRpY0NvdW50ID0gbnVtYmVyT2ZOb2RlcztcbiAgcmV0dXJuIHZub2RlO1xufVxuZnVuY3Rpb24gY3JlYXRlQ29tbWVudFZOb2RlKHRleHQgPSBcIlwiLCBhc0Jsb2NrID0gZmFsc2UpIHtcbiAgcmV0dXJuIGFzQmxvY2sgPyAob3BlbkJsb2NrKCksIGNyZWF0ZUJsb2NrKENvbW1lbnQsIG51bGwsIHRleHQpKSA6IGNyZWF0ZVZOb2RlKENvbW1lbnQsIG51bGwsIHRleHQpO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplVk5vZGUoY2hpbGQpIHtcbiAgaWYgKGNoaWxkID09IG51bGwgfHwgdHlwZW9mIGNoaWxkID09PSBcImJvb2xlYW5cIikge1xuICAgIHJldHVybiBjcmVhdGVWTm9kZShDb21tZW50KTtcbiAgfSBlbHNlIGlmIChpc0FycmF5KGNoaWxkKSkge1xuICAgIHJldHVybiBjcmVhdGVWTm9kZShcbiAgICAgIEZyYWdtZW50LFxuICAgICAgbnVsbCxcbiAgICAgIC8vICMzNjY2LCBhdm9pZCByZWZlcmVuY2UgcG9sbHV0aW9uIHdoZW4gcmV1c2luZyB2bm9kZVxuICAgICAgY2hpbGQuc2xpY2UoKVxuICAgICk7XG4gIH0gZWxzZSBpZiAoaXNWTm9kZShjaGlsZCkpIHtcbiAgICByZXR1cm4gY2xvbmVJZk1vdW50ZWQoY2hpbGQpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBjcmVhdGVWTm9kZShUZXh0LCBudWxsLCBTdHJpbmcoY2hpbGQpKTtcbiAgfVxufVxuZnVuY3Rpb24gY2xvbmVJZk1vdW50ZWQoY2hpbGQpIHtcbiAgcmV0dXJuIGNoaWxkLmVsID09PSBudWxsICYmIGNoaWxkLnBhdGNoRmxhZyAhPT0gLTEgfHwgY2hpbGQubWVtbyA/IGNoaWxkIDogY2xvbmVWTm9kZShjaGlsZCk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVDaGlsZHJlbih2bm9kZSwgY2hpbGRyZW4pIHtcbiAgbGV0IHR5cGUgPSAwO1xuICBjb25zdCB7IHNoYXBlRmxhZyB9ID0gdm5vZGU7XG4gIGlmIChjaGlsZHJlbiA9PSBudWxsKSB7XG4gICAgY2hpbGRyZW4gPSBudWxsO1xuICB9IGVsc2UgaWYgKGlzQXJyYXkoY2hpbGRyZW4pKSB7XG4gICAgdHlwZSA9IDE2O1xuICB9IGVsc2UgaWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJvYmplY3RcIikge1xuICAgIGlmIChzaGFwZUZsYWcgJiAoMSB8IDY0KSkge1xuICAgICAgY29uc3Qgc2xvdCA9IGNoaWxkcmVuLmRlZmF1bHQ7XG4gICAgICBpZiAoc2xvdCkge1xuICAgICAgICBzbG90Ll9jICYmIChzbG90Ll9kID0gZmFsc2UpO1xuICAgICAgICBub3JtYWxpemVDaGlsZHJlbih2bm9kZSwgc2xvdCgpKTtcbiAgICAgICAgc2xvdC5fYyAmJiAoc2xvdC5fZCA9IHRydWUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSB7XG4gICAgICB0eXBlID0gMzI7XG4gICAgICBjb25zdCBzbG90RmxhZyA9IGNoaWxkcmVuLl87XG4gICAgICBpZiAoIXNsb3RGbGFnICYmICFpc0ludGVybmFsT2JqZWN0KGNoaWxkcmVuKSkge1xuICAgICAgICBjaGlsZHJlbi5fY3R4ID0gY3VycmVudFJlbmRlcmluZ0luc3RhbmNlO1xuICAgICAgfSBlbHNlIGlmIChzbG90RmxhZyA9PT0gMyAmJiBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UpIHtcbiAgICAgICAgaWYgKGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZS5zbG90cy5fID09PSAxKSB7XG4gICAgICAgICAgY2hpbGRyZW4uXyA9IDE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2hpbGRyZW4uXyA9IDI7XG4gICAgICAgICAgdm5vZGUucGF0Y2hGbGFnIHw9IDEwMjQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNGdW5jdGlvbihjaGlsZHJlbikpIHtcbiAgICBpZiAoc2hhcGVGbGFnICYgKDEgfCA2NCkpIHtcbiAgICAgIG5vcm1hbGl6ZUNoaWxkcmVuKHZub2RlLCB7IGRlZmF1bHQ6IGNoaWxkcmVuIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjaGlsZHJlbiA9IHsgZGVmYXVsdDogY2hpbGRyZW4sIF9jdHg6IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSB9O1xuICAgIHR5cGUgPSAzMjtcbiAgfSBlbHNlIHtcbiAgICBjaGlsZHJlbiA9IFN0cmluZyhjaGlsZHJlbik7XG4gICAgaWYgKHNoYXBlRmxhZyAmIDY0KSB7XG4gICAgICB0eXBlID0gMTY7XG4gICAgICBjaGlsZHJlbiA9IFtjcmVhdGVUZXh0Vk5vZGUoY2hpbGRyZW4pXTtcbiAgICB9IGVsc2Uge1xuICAgICAgdHlwZSA9IDg7XG4gICAgfVxuICB9XG4gIHZub2RlLmNoaWxkcmVuID0gY2hpbGRyZW47XG4gIHZub2RlLnNoYXBlRmxhZyB8PSB0eXBlO1xufVxuZnVuY3Rpb24gbWVyZ2VQcm9wcyguLi5hcmdzKSB7XG4gIGNvbnN0IHJldCA9IHt9O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGFyZ3MubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCB0b01lcmdlID0gYXJnc1tpXTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiB0b01lcmdlKSB7XG4gICAgICBpZiAoa2V5ID09PSBcImNsYXNzXCIpIHtcbiAgICAgICAgaWYgKHJldC5jbGFzcyAhPT0gdG9NZXJnZS5jbGFzcykge1xuICAgICAgICAgIHJldC5jbGFzcyA9IG5vcm1hbGl6ZUNsYXNzKFtyZXQuY2xhc3MsIHRvTWVyZ2UuY2xhc3NdKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwic3R5bGVcIikge1xuICAgICAgICByZXQuc3R5bGUgPSBub3JtYWxpemVTdHlsZShbcmV0LnN0eWxlLCB0b01lcmdlLnN0eWxlXSk7XG4gICAgICB9IGVsc2UgaWYgKGlzT24oa2V5KSkge1xuICAgICAgICBjb25zdCBleGlzdGluZyA9IHJldFtrZXldO1xuICAgICAgICBjb25zdCBpbmNvbWluZyA9IHRvTWVyZ2Vba2V5XTtcbiAgICAgICAgaWYgKGluY29taW5nICYmIGV4aXN0aW5nICE9PSBpbmNvbWluZyAmJiAhKGlzQXJyYXkoZXhpc3RpbmcpICYmIGV4aXN0aW5nLmluY2x1ZGVzKGluY29taW5nKSkpIHtcbiAgICAgICAgICByZXRba2V5XSA9IGV4aXN0aW5nID8gW10uY29uY2F0KGV4aXN0aW5nLCBpbmNvbWluZykgOiBpbmNvbWluZztcbiAgICAgICAgfSBlbHNlIGlmIChpbmNvbWluZyA9PSBudWxsICYmIGV4aXN0aW5nID09IG51bGwgJiYgLy8gbWVyZ2VQcm9wcyh7ICdvblVwZGF0ZTptb2RlbFZhbHVlJzogdW5kZWZpbmVkIH0pIHNob3VsZCBub3QgcmV0YWluXG4gICAgICAgIC8vIHRoZSBtb2RlbCBsaXN0ZW5lci5cbiAgICAgICAgIWlzTW9kZWxMaXN0ZW5lcihrZXkpKSB7XG4gICAgICAgICAgcmV0W2tleV0gPSBpbmNvbWluZztcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChrZXkgIT09IFwiXCIpIHtcbiAgICAgICAgcmV0W2tleV0gPSB0b01lcmdlW2tleV07XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiByZXQ7XG59XG5mdW5jdGlvbiBpbnZva2VWTm9kZUhvb2soaG9vaywgaW5zdGFuY2UsIHZub2RlLCBwcmV2Vk5vZGUgPSBudWxsKSB7XG4gIGNhbGxXaXRoQXN5bmNFcnJvckhhbmRsaW5nKGhvb2ssIGluc3RhbmNlLCA3LCBbXG4gICAgdm5vZGUsXG4gICAgcHJldlZOb2RlXG4gIF0pO1xufVxuXG5jb25zdCBlbXB0eUFwcENvbnRleHQgPSBjcmVhdGVBcHBDb250ZXh0KCk7XG5sZXQgdWlkID0gMDtcbmZ1bmN0aW9uIGNyZWF0ZUNvbXBvbmVudEluc3RhbmNlKHZub2RlLCBwYXJlbnQsIHN1c3BlbnNlKSB7XG4gIGNvbnN0IHR5cGUgPSB2bm9kZS50eXBlO1xuICBjb25zdCBhcHBDb250ZXh0ID0gKHBhcmVudCA/IHBhcmVudC5hcHBDb250ZXh0IDogdm5vZGUuYXBwQ29udGV4dCkgfHwgZW1wdHlBcHBDb250ZXh0O1xuICBjb25zdCBpbnN0YW5jZSA9IHtcbiAgICB1aWQ6IHVpZCsrLFxuICAgIHZub2RlLFxuICAgIHR5cGUsXG4gICAgcGFyZW50LFxuICAgIGFwcENvbnRleHQsXG4gICAgcm9vdDogbnVsbCxcbiAgICAvLyB0byBiZSBpbW1lZGlhdGVseSBzZXRcbiAgICBuZXh0OiBudWxsLFxuICAgIHN1YlRyZWU6IG51bGwsXG4gICAgLy8gd2lsbCBiZSBzZXQgc3luY2hyb25vdXNseSByaWdodCBhZnRlciBjcmVhdGlvblxuICAgIGVmZmVjdDogbnVsbCxcbiAgICB1cGRhdGU6IG51bGwsXG4gICAgLy8gd2lsbCBiZSBzZXQgc3luY2hyb25vdXNseSByaWdodCBhZnRlciBjcmVhdGlvblxuICAgIGpvYjogbnVsbCxcbiAgICBzY29wZTogbmV3IEVmZmVjdFNjb3BlKFxuICAgICAgdHJ1ZVxuICAgICAgLyogZGV0YWNoZWQgKi9cbiAgICApLFxuICAgIHJlbmRlcjogbnVsbCxcbiAgICBwcm94eTogbnVsbCxcbiAgICBleHBvc2VkOiBudWxsLFxuICAgIGV4cG9zZVByb3h5OiBudWxsLFxuICAgIHdpdGhQcm94eTogbnVsbCxcbiAgICBwcm92aWRlczogcGFyZW50ID8gcGFyZW50LnByb3ZpZGVzIDogT2JqZWN0LmNyZWF0ZShhcHBDb250ZXh0LnByb3ZpZGVzKSxcbiAgICBpZHM6IHBhcmVudCA/IHBhcmVudC5pZHMgOiBbXCJcIiwgMCwgMF0sXG4gICAgYWNjZXNzQ2FjaGU6IG51bGwsXG4gICAgcmVuZGVyQ2FjaGU6IFtdLFxuICAgIC8vIGxvY2FsIHJlc29sdmVkIGFzc2V0c1xuICAgIGNvbXBvbmVudHM6IG51bGwsXG4gICAgZGlyZWN0aXZlczogbnVsbCxcbiAgICAvLyByZXNvbHZlZCBwcm9wcyBhbmQgZW1pdHMgb3B0aW9uc1xuICAgIHByb3BzT3B0aW9uczogbm9ybWFsaXplUHJvcHNPcHRpb25zKHR5cGUsIGFwcENvbnRleHQpLFxuICAgIGVtaXRzT3B0aW9uczogbm9ybWFsaXplRW1pdHNPcHRpb25zKHR5cGUsIGFwcENvbnRleHQpLFxuICAgIC8vIGVtaXRcbiAgICBlbWl0OiBudWxsLFxuICAgIC8vIHRvIGJlIHNldCBpbW1lZGlhdGVseVxuICAgIGVtaXR0ZWQ6IG51bGwsXG4gICAgLy8gcHJvcHMgZGVmYXVsdCB2YWx1ZVxuICAgIHByb3BzRGVmYXVsdHM6IEVNUFRZX09CSixcbiAgICAvLyBpbmhlcml0QXR0cnNcbiAgICBpbmhlcml0QXR0cnM6IHR5cGUuaW5oZXJpdEF0dHJzLFxuICAgIC8vIHN0YXRlXG4gICAgY3R4OiBFTVBUWV9PQkosXG4gICAgZGF0YTogRU1QVFlfT0JKLFxuICAgIHByb3BzOiBFTVBUWV9PQkosXG4gICAgYXR0cnM6IEVNUFRZX09CSixcbiAgICBzbG90czogRU1QVFlfT0JKLFxuICAgIHJlZnM6IEVNUFRZX09CSixcbiAgICBzZXR1cFN0YXRlOiBFTVBUWV9PQkosXG4gICAgc2V0dXBDb250ZXh0OiBudWxsLFxuICAgIC8vIHN1c3BlbnNlIHJlbGF0ZWRcbiAgICBzdXNwZW5zZSxcbiAgICBzdXNwZW5zZUlkOiBzdXNwZW5zZSA/IHN1c3BlbnNlLnBlbmRpbmdJZCA6IDAsXG4gICAgYXN5bmNEZXA6IG51bGwsXG4gICAgYXN5bmNSZXNvbHZlZDogZmFsc2UsXG4gICAgLy8gbGlmZWN5Y2xlIGhvb2tzXG4gICAgLy8gbm90IHVzaW5nIGVudW1zIGhlcmUgYmVjYXVzZSBpdCByZXN1bHRzIGluIGNvbXB1dGVkIHByb3BlcnRpZXNcbiAgICBpc01vdW50ZWQ6IGZhbHNlLFxuICAgIGlzVW5tb3VudGVkOiBmYWxzZSxcbiAgICBpc0RlYWN0aXZhdGVkOiBmYWxzZSxcbiAgICBiYzogbnVsbCxcbiAgICBjOiBudWxsLFxuICAgIGJtOiBudWxsLFxuICAgIG06IG51bGwsXG4gICAgYnU6IG51bGwsXG4gICAgdTogbnVsbCxcbiAgICB1bTogbnVsbCxcbiAgICBidW06IG51bGwsXG4gICAgZGE6IG51bGwsXG4gICAgYTogbnVsbCxcbiAgICBydGc6IG51bGwsXG4gICAgcnRjOiBudWxsLFxuICAgIGVjOiBudWxsLFxuICAgIHNwOiBudWxsXG4gIH07XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgaW5zdGFuY2UuY3R4ID0gY3JlYXRlRGV2UmVuZGVyQ29udGV4dChpbnN0YW5jZSk7XG4gIH0gZWxzZSB7XG4gICAgaW5zdGFuY2UuY3R4ID0geyBfOiBpbnN0YW5jZSB9O1xuICB9XG4gIGluc3RhbmNlLnJvb3QgPSBwYXJlbnQgPyBwYXJlbnQucm9vdCA6IGluc3RhbmNlO1xuICBpbnN0YW5jZS5lbWl0ID0gZW1pdC5iaW5kKG51bGwsIGluc3RhbmNlKTtcbiAgaWYgKHZub2RlLmNlKSB7XG4gICAgdm5vZGUuY2UoaW5zdGFuY2UpO1xuICB9XG4gIHJldHVybiBpbnN0YW5jZTtcbn1cbmxldCBjdXJyZW50SW5zdGFuY2UgPSBudWxsO1xuY29uc3QgZ2V0Q3VycmVudEluc3RhbmNlID0gKCkgPT4gY3VycmVudEluc3RhbmNlIHx8IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZTtcbmxldCBpbnRlcm5hbFNldEN1cnJlbnRJbnN0YW5jZTtcbmxldCBzZXRJblNTUlNldHVwU3RhdGU7XG57XG4gIGNvbnN0IGcgPSBnZXRHbG9iYWxUaGlzKCk7XG4gIGNvbnN0IHJlZ2lzdGVyR2xvYmFsU2V0dGVyID0gKGtleSwgc2V0dGVyKSA9PiB7XG4gICAgbGV0IHNldHRlcnM7XG4gICAgaWYgKCEoc2V0dGVycyA9IGdba2V5XSkpIHNldHRlcnMgPSBnW2tleV0gPSBbXTtcbiAgICBzZXR0ZXJzLnB1c2goc2V0dGVyKTtcbiAgICByZXR1cm4gKHYpID0+IHtcbiAgICAgIGlmIChzZXR0ZXJzLmxlbmd0aCA+IDEpIHNldHRlcnMuZm9yRWFjaCgoc2V0KSA9PiBzZXQodikpO1xuICAgICAgZWxzZSBzZXR0ZXJzWzBdKHYpO1xuICAgIH07XG4gIH07XG4gIGludGVybmFsU2V0Q3VycmVudEluc3RhbmNlID0gcmVnaXN0ZXJHbG9iYWxTZXR0ZXIoXG4gICAgYF9fVlVFX0lOU1RBTkNFX1NFVFRFUlNfX2AsXG4gICAgKHYpID0+IGN1cnJlbnRJbnN0YW5jZSA9IHZcbiAgKTtcbiAgc2V0SW5TU1JTZXR1cFN0YXRlID0gcmVnaXN0ZXJHbG9iYWxTZXR0ZXIoXG4gICAgYF9fVlVFX1NTUl9TRVRURVJTX19gLFxuICAgICh2KSA9PiBpc0luU1NSQ29tcG9uZW50U2V0dXAgPSB2XG4gICk7XG59XG5jb25zdCBzZXRDdXJyZW50SW5zdGFuY2UgPSAoaW5zdGFuY2UpID0+IHtcbiAgY29uc3QgcHJldiA9IGN1cnJlbnRJbnN0YW5jZTtcbiAgaW50ZXJuYWxTZXRDdXJyZW50SW5zdGFuY2UoaW5zdGFuY2UpO1xuICBpbnN0YW5jZS5zY29wZS5vbigpO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGluc3RhbmNlLnNjb3BlLm9mZigpO1xuICAgIGludGVybmFsU2V0Q3VycmVudEluc3RhbmNlKHByZXYpO1xuICB9O1xufTtcbmNvbnN0IHVuc2V0Q3VycmVudEluc3RhbmNlID0gKCkgPT4ge1xuICBjdXJyZW50SW5zdGFuY2UgJiYgY3VycmVudEluc3RhbmNlLnNjb3BlLm9mZigpO1xuICBpbnRlcm5hbFNldEN1cnJlbnRJbnN0YW5jZShudWxsKTtcbn07XG5jb25zdCBpc0J1aWx0SW5UYWcgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChcInNsb3QsY29tcG9uZW50XCIpO1xuZnVuY3Rpb24gdmFsaWRhdGVDb21wb25lbnROYW1lKG5hbWUsIHsgaXNOYXRpdmVUYWcgfSkge1xuICBpZiAoaXNCdWlsdEluVGFnKG5hbWUpIHx8IGlzTmF0aXZlVGFnKG5hbWUpKSB7XG4gICAgd2FybiQxKFxuICAgICAgXCJEbyBub3QgdXNlIGJ1aWx0LWluIG9yIHJlc2VydmVkIEhUTUwgZWxlbWVudHMgYXMgY29tcG9uZW50IGlkOiBcIiArIG5hbWVcbiAgICApO1xuICB9XG59XG5mdW5jdGlvbiBpc1N0YXRlZnVsQ29tcG9uZW50KGluc3RhbmNlKSB7XG4gIHJldHVybiBpbnN0YW5jZS52bm9kZS5zaGFwZUZsYWcgJiA0O1xufVxubGV0IGlzSW5TU1JDb21wb25lbnRTZXR1cCA9IGZhbHNlO1xuZnVuY3Rpb24gc2V0dXBDb21wb25lbnQoaW5zdGFuY2UsIGlzU1NSID0gZmFsc2UsIG9wdGltaXplZCA9IGZhbHNlKSB7XG4gIGlzU1NSICYmIHNldEluU1NSU2V0dXBTdGF0ZShpc1NTUik7XG4gIGNvbnN0IHsgcHJvcHMsIGNoaWxkcmVuIH0gPSBpbnN0YW5jZS52bm9kZTtcbiAgY29uc3QgaXNTdGF0ZWZ1bCA9IGlzU3RhdGVmdWxDb21wb25lbnQoaW5zdGFuY2UpO1xuICBpbml0UHJvcHMoaW5zdGFuY2UsIHByb3BzLCBpc1N0YXRlZnVsLCBpc1NTUik7XG4gIGluaXRTbG90cyhpbnN0YW5jZSwgY2hpbGRyZW4sIG9wdGltaXplZCB8fCBpc1NTUik7XG4gIGNvbnN0IHNldHVwUmVzdWx0ID0gaXNTdGF0ZWZ1bCA/IHNldHVwU3RhdGVmdWxDb21wb25lbnQoaW5zdGFuY2UsIGlzU1NSKSA6IHZvaWQgMDtcbiAgaXNTU1IgJiYgc2V0SW5TU1JTZXR1cFN0YXRlKGZhbHNlKTtcbiAgcmV0dXJuIHNldHVwUmVzdWx0O1xufVxuZnVuY3Rpb24gc2V0dXBTdGF0ZWZ1bENvbXBvbmVudChpbnN0YW5jZSwgaXNTU1IpIHtcbiAgY29uc3QgQ29tcG9uZW50ID0gaW5zdGFuY2UudHlwZTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBpZiAoQ29tcG9uZW50Lm5hbWUpIHtcbiAgICAgIHZhbGlkYXRlQ29tcG9uZW50TmFtZShDb21wb25lbnQubmFtZSwgaW5zdGFuY2UuYXBwQ29udGV4dC5jb25maWcpO1xuICAgIH1cbiAgICBpZiAoQ29tcG9uZW50LmNvbXBvbmVudHMpIHtcbiAgICAgIGNvbnN0IG5hbWVzID0gT2JqZWN0LmtleXMoQ29tcG9uZW50LmNvbXBvbmVudHMpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBuYW1lcy5sZW5ndGg7IGkrKykge1xuICAgICAgICB2YWxpZGF0ZUNvbXBvbmVudE5hbWUobmFtZXNbaV0sIGluc3RhbmNlLmFwcENvbnRleHQuY29uZmlnKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKENvbXBvbmVudC5kaXJlY3RpdmVzKSB7XG4gICAgICBjb25zdCBuYW1lcyA9IE9iamVjdC5rZXlzKENvbXBvbmVudC5kaXJlY3RpdmVzKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbmFtZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFsaWRhdGVEaXJlY3RpdmVOYW1lKG5hbWVzW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKENvbXBvbmVudC5jb21waWxlck9wdGlvbnMgJiYgaXNSdW50aW1lT25seSgpKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBcImNvbXBpbGVyT3B0aW9uc1wiIGlzIG9ubHkgc3VwcG9ydGVkIHdoZW4gdXNpbmcgYSBidWlsZCBvZiBWdWUgdGhhdCBpbmNsdWRlcyB0aGUgcnVudGltZSBjb21waWxlci4gU2luY2UgeW91IGFyZSB1c2luZyBhIHJ1bnRpbWUtb25seSBidWlsZCwgdGhlIG9wdGlvbnMgc2hvdWxkIGJlIHBhc3NlZCB2aWEgeW91ciBidWlsZCB0b29sIGNvbmZpZyBpbnN0ZWFkLmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGluc3RhbmNlLmFjY2Vzc0NhY2hlID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGluc3RhbmNlLnByb3h5ID0gbmV3IFByb3h5KGluc3RhbmNlLmN0eCwgUHVibGljSW5zdGFuY2VQcm94eUhhbmRsZXJzKTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBleHBvc2VQcm9wc09uUmVuZGVyQ29udGV4dChpbnN0YW5jZSk7XG4gIH1cbiAgY29uc3QgeyBzZXR1cCB9ID0gQ29tcG9uZW50O1xuICBpZiAoc2V0dXApIHtcbiAgICBwYXVzZVRyYWNraW5nKCk7XG4gICAgY29uc3Qgc2V0dXBDb250ZXh0ID0gaW5zdGFuY2Uuc2V0dXBDb250ZXh0ID0gc2V0dXAubGVuZ3RoID4gMSA/IGNyZWF0ZVNldHVwQ29udGV4dChpbnN0YW5jZSkgOiBudWxsO1xuICAgIGNvbnN0IHJlc2V0ID0gc2V0Q3VycmVudEluc3RhbmNlKGluc3RhbmNlKTtcbiAgICBjb25zdCBzZXR1cFJlc3VsdCA9IGNhbGxXaXRoRXJyb3JIYW5kbGluZyhcbiAgICAgIHNldHVwLFxuICAgICAgaW5zdGFuY2UsXG4gICAgICAwLFxuICAgICAgW1xuICAgICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gc2hhbGxvd1JlYWRvbmx5KGluc3RhbmNlLnByb3BzKSA6IGluc3RhbmNlLnByb3BzLFxuICAgICAgICBzZXR1cENvbnRleHRcbiAgICAgIF1cbiAgICApO1xuICAgIGNvbnN0IGlzQXN5bmNTZXR1cCA9IGlzUHJvbWlzZShzZXR1cFJlc3VsdCk7XG4gICAgcmVzZXRUcmFja2luZygpO1xuICAgIHJlc2V0KCk7XG4gICAgaWYgKChpc0FzeW5jU2V0dXAgfHwgaW5zdGFuY2Uuc3ApICYmICFpc0FzeW5jV3JhcHBlcihpbnN0YW5jZSkpIHtcbiAgICAgIG1hcmtBc3luY0JvdW5kYXJ5KGluc3RhbmNlKTtcbiAgICB9XG4gICAgaWYgKGlzQXN5bmNTZXR1cCkge1xuICAgICAgc2V0dXBSZXN1bHQudGhlbih1bnNldEN1cnJlbnRJbnN0YW5jZSwgdW5zZXRDdXJyZW50SW5zdGFuY2UpO1xuICAgICAgaWYgKGlzU1NSKSB7XG4gICAgICAgIHJldHVybiBzZXR1cFJlc3VsdC50aGVuKChyZXNvbHZlZFJlc3VsdCkgPT4ge1xuICAgICAgICAgIHNldEluU1NSU2V0dXBTdGF0ZSh0cnVlKTtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgaGFuZGxlU2V0dXBSZXN1bHQoaW5zdGFuY2UsIHJlc29sdmVkUmVzdWx0LCBpc1NTUik7XG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldEluU1NSU2V0dXBTdGF0ZShmYWxzZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KS5jYXRjaCgoZSkgPT4ge1xuICAgICAgICAgIGhhbmRsZUVycm9yKGUsIGluc3RhbmNlLCAwKTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbnN0YW5jZS5hc3luY0RlcCA9IHNldHVwUmVzdWx0O1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhaW5zdGFuY2Uuc3VzcGVuc2UpIHtcbiAgICAgICAgICBjb25zdCBuYW1lID0gZm9ybWF0Q29tcG9uZW50TmFtZShpbnN0YW5jZSwgQ29tcG9uZW50KTtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgQ29tcG9uZW50IDwke25hbWV9Pjogc2V0dXAgZnVuY3Rpb24gcmV0dXJuZWQgYSBwcm9taXNlLCBidXQgbm8gPFN1c3BlbnNlPiBib3VuZGFyeSB3YXMgZm91bmQgaW4gdGhlIHBhcmVudCBjb21wb25lbnQgdHJlZS4gQSBjb21wb25lbnQgd2l0aCBhc3luYyBzZXR1cCgpIG11c3QgYmUgbmVzdGVkIGluIGEgPFN1c3BlbnNlPiBpbiBvcmRlciB0byBiZSByZW5kZXJlZC5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBoYW5kbGVTZXR1cFJlc3VsdChpbnN0YW5jZSwgc2V0dXBSZXN1bHQsIGlzU1NSKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZmluaXNoQ29tcG9uZW50U2V0dXAoaW5zdGFuY2UsIGlzU1NSKTtcbiAgfVxufVxuZnVuY3Rpb24gaGFuZGxlU2V0dXBSZXN1bHQoaW5zdGFuY2UsIHNldHVwUmVzdWx0LCBpc1NTUikge1xuICBpZiAoaXNGdW5jdGlvbihzZXR1cFJlc3VsdCkpIHtcbiAgICBpZiAoaW5zdGFuY2UudHlwZS5fX3NzcklubGluZVJlbmRlcikge1xuICAgICAgaW5zdGFuY2Uuc3NyUmVuZGVyID0gc2V0dXBSZXN1bHQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGluc3RhbmNlLnJlbmRlciA9IHNldHVwUmVzdWx0O1xuICAgIH1cbiAgfSBlbHNlIGlmIChpc09iamVjdChzZXR1cFJlc3VsdCkpIHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpc1ZOb2RlKHNldHVwUmVzdWx0KSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgc2V0dXAoKSBzaG91bGQgbm90IHJldHVybiBWTm9kZXMgZGlyZWN0bHkgLSByZXR1cm4gYSByZW5kZXIgZnVuY3Rpb24gaW5zdGVhZC5gXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgIGluc3RhbmNlLmRldnRvb2xzUmF3U2V0dXBTdGF0ZSA9IHNldHVwUmVzdWx0O1xuICAgIH1cbiAgICBpbnN0YW5jZS5zZXR1cFN0YXRlID0gcHJveHlSZWZzKHNldHVwUmVzdWx0KTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgZXhwb3NlU2V0dXBTdGF0ZU9uUmVuZGVyQ29udGV4dChpbnN0YW5jZSk7XG4gICAgfVxuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgc2V0dXBSZXN1bHQgIT09IHZvaWQgMCkge1xuICAgIHdhcm4kMShcbiAgICAgIGBzZXR1cCgpIHNob3VsZCByZXR1cm4gYW4gb2JqZWN0LiBSZWNlaXZlZDogJHtzZXR1cFJlc3VsdCA9PT0gbnVsbCA/IFwibnVsbFwiIDogdHlwZW9mIHNldHVwUmVzdWx0fWBcbiAgICApO1xuICB9XG4gIGZpbmlzaENvbXBvbmVudFNldHVwKGluc3RhbmNlLCBpc1NTUik7XG59XG5sZXQgY29tcGlsZTtcbmxldCBpbnN0YWxsV2l0aFByb3h5O1xuZnVuY3Rpb24gcmVnaXN0ZXJSdW50aW1lQ29tcGlsZXIoX2NvbXBpbGUpIHtcbiAgY29tcGlsZSA9IF9jb21waWxlO1xuICBpbnN0YWxsV2l0aFByb3h5ID0gKGkpID0+IHtcbiAgICBpZiAoaS5yZW5kZXIuX3JjKSB7XG4gICAgICBpLndpdGhQcm94eSA9IG5ldyBQcm94eShpLmN0eCwgUnVudGltZUNvbXBpbGVkUHVibGljSW5zdGFuY2VQcm94eUhhbmRsZXJzKTtcbiAgICB9XG4gIH07XG59XG5jb25zdCBpc1J1bnRpbWVPbmx5ID0gKCkgPT4gIWNvbXBpbGU7XG5mdW5jdGlvbiBmaW5pc2hDb21wb25lbnRTZXR1cChpbnN0YW5jZSwgaXNTU1IsIHNraXBPcHRpb25zKSB7XG4gIGNvbnN0IENvbXBvbmVudCA9IGluc3RhbmNlLnR5cGU7XG4gIGlmICghaW5zdGFuY2UucmVuZGVyKSB7XG4gICAgaWYgKCFpc1NTUiAmJiBjb21waWxlICYmICFDb21wb25lbnQucmVuZGVyKSB7XG4gICAgICBjb25zdCB0ZW1wbGF0ZSA9IENvbXBvbmVudC50ZW1wbGF0ZSB8fCBfX1ZVRV9PUFRJT05TX0FQSV9fICYmIHJlc29sdmVNZXJnZWRPcHRpb25zKGluc3RhbmNlKS50ZW1wbGF0ZTtcbiAgICAgIGlmICh0ZW1wbGF0ZSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHN0YXJ0TWVhc3VyZShpbnN0YW5jZSwgYGNvbXBpbGVgKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGlzQ3VzdG9tRWxlbWVudCwgY29tcGlsZXJPcHRpb25zIH0gPSBpbnN0YW5jZS5hcHBDb250ZXh0LmNvbmZpZztcbiAgICAgICAgY29uc3QgeyBkZWxpbWl0ZXJzLCBjb21waWxlck9wdGlvbnM6IGNvbXBvbmVudENvbXBpbGVyT3B0aW9ucyB9ID0gQ29tcG9uZW50O1xuICAgICAgICBjb25zdCBmaW5hbENvbXBpbGVyT3B0aW9ucyA9IGV4dGVuZChcbiAgICAgICAgICBleHRlbmQoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlzQ3VzdG9tRWxlbWVudCxcbiAgICAgICAgICAgICAgZGVsaW1pdGVyc1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbXBpbGVyT3B0aW9uc1xuICAgICAgICAgICksXG4gICAgICAgICAgY29tcG9uZW50Q29tcGlsZXJPcHRpb25zXG4gICAgICAgICk7XG4gICAgICAgIENvbXBvbmVudC5yZW5kZXIgPSBjb21waWxlKHRlbXBsYXRlLCBmaW5hbENvbXBpbGVyT3B0aW9ucyk7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgZW5kTWVhc3VyZShpbnN0YW5jZSwgYGNvbXBpbGVgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpbnN0YW5jZS5yZW5kZXIgPSBDb21wb25lbnQucmVuZGVyIHx8IE5PT1A7XG4gICAgaWYgKGluc3RhbGxXaXRoUHJveHkpIHtcbiAgICAgIGluc3RhbGxXaXRoUHJveHkoaW5zdGFuY2UpO1xuICAgIH1cbiAgfVxuICBpZiAoX19WVUVfT1BUSU9OU19BUElfXyAmJiB0cnVlKSB7XG4gICAgY29uc3QgcmVzZXQgPSBzZXRDdXJyZW50SW5zdGFuY2UoaW5zdGFuY2UpO1xuICAgIHBhdXNlVHJhY2tpbmcoKTtcbiAgICB0cnkge1xuICAgICAgYXBwbHlPcHRpb25zKGluc3RhbmNlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgcmVzZXRUcmFja2luZygpO1xuICAgICAgcmVzZXQoKTtcbiAgICB9XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIUNvbXBvbmVudC5yZW5kZXIgJiYgaW5zdGFuY2UucmVuZGVyID09PSBOT09QICYmICFpc1NTUikge1xuICAgIGlmICghY29tcGlsZSAmJiBDb21wb25lbnQudGVtcGxhdGUpIHtcbiAgICAgIHdhcm4kMShcbiAgICAgICAgYENvbXBvbmVudCBwcm92aWRlZCB0ZW1wbGF0ZSBvcHRpb24gYnV0IHJ1bnRpbWUgY29tcGlsYXRpb24gaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGJ1aWxkIG9mIFZ1ZS5gICsgKGAgQ29uZmlndXJlIHlvdXIgYnVuZGxlciB0byBhbGlhcyBcInZ1ZVwiIHRvIFwidnVlL2Rpc3QvdnVlLmVzbS1idW5kbGVyLmpzXCIuYCApXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICB3YXJuJDEoYENvbXBvbmVudCBpcyBtaXNzaW5nIHRlbXBsYXRlIG9yIHJlbmRlciBmdW5jdGlvbjogYCwgQ29tcG9uZW50KTtcbiAgICB9XG4gIH1cbn1cbmNvbnN0IGF0dHJzUHJveHlIYW5kbGVycyA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyB7XG4gIGdldCh0YXJnZXQsIGtleSkge1xuICAgIG1hcmtBdHRyc0FjY2Vzc2VkKCk7XG4gICAgdHJhY2sodGFyZ2V0LCBcImdldFwiLCBcIlwiKTtcbiAgICByZXR1cm4gdGFyZ2V0W2tleV07XG4gIH0sXG4gIHNldCgpIHtcbiAgICB3YXJuJDEoYHNldHVwQ29udGV4dC5hdHRycyBpcyByZWFkb25seS5gKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH0sXG4gIGRlbGV0ZVByb3BlcnR5KCkge1xuICAgIHdhcm4kMShgc2V0dXBDb250ZXh0LmF0dHJzIGlzIHJlYWRvbmx5LmApO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufSA6IHtcbiAgZ2V0KHRhcmdldCwga2V5KSB7XG4gICAgdHJhY2sodGFyZ2V0LCBcImdldFwiLCBcIlwiKTtcbiAgICByZXR1cm4gdGFyZ2V0W2tleV07XG4gIH1cbn07XG5mdW5jdGlvbiBnZXRTbG90c1Byb3h5KGluc3RhbmNlKSB7XG4gIHJldHVybiBuZXcgUHJveHkoaW5zdGFuY2Uuc2xvdHMsIHtcbiAgICBnZXQodGFyZ2V0LCBrZXkpIHtcbiAgICAgIHRyYWNrKGluc3RhbmNlLCBcImdldFwiLCBcIiRzbG90c1wiKTtcbiAgICAgIHJldHVybiB0YXJnZXRba2V5XTtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlU2V0dXBDb250ZXh0KGluc3RhbmNlKSB7XG4gIGNvbnN0IGV4cG9zZSA9IChleHBvc2VkKSA9PiB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIGlmIChpbnN0YW5jZS5leHBvc2VkKSB7XG4gICAgICAgIHdhcm4kMShgZXhwb3NlKCkgc2hvdWxkIGJlIGNhbGxlZCBvbmx5IG9uY2UgcGVyIHNldHVwKCkuYCk7XG4gICAgICB9XG4gICAgICBpZiAoZXhwb3NlZCAhPSBudWxsKSB7XG4gICAgICAgIGxldCBleHBvc2VkVHlwZSA9IHR5cGVvZiBleHBvc2VkO1xuICAgICAgICBpZiAoZXhwb3NlZFR5cGUgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgICAgICBpZiAoaXNBcnJheShleHBvc2VkKSkge1xuICAgICAgICAgICAgZXhwb3NlZFR5cGUgPSBcImFycmF5XCI7XG4gICAgICAgICAgfSBlbHNlIGlmIChpc1JlZihleHBvc2VkKSkge1xuICAgICAgICAgICAgZXhwb3NlZFR5cGUgPSBcInJlZlwiO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZXhwb3NlZFR5cGUgIT09IFwib2JqZWN0XCIpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgZXhwb3NlKCkgc2hvdWxkIGJlIHBhc3NlZCBhIHBsYWluIG9iamVjdCwgcmVjZWl2ZWQgJHtleHBvc2VkVHlwZX0uYFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaW5zdGFuY2UuZXhwb3NlZCA9IGV4cG9zZWQgfHwge307XG4gIH07XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgbGV0IGF0dHJzUHJveHk7XG4gICAgbGV0IHNsb3RzUHJveHk7XG4gICAgcmV0dXJuIE9iamVjdC5mcmVlemUoe1xuICAgICAgZ2V0IGF0dHJzKCkge1xuICAgICAgICByZXR1cm4gYXR0cnNQcm94eSB8fCAoYXR0cnNQcm94eSA9IG5ldyBQcm94eShpbnN0YW5jZS5hdHRycywgYXR0cnNQcm94eUhhbmRsZXJzKSk7XG4gICAgICB9LFxuICAgICAgZ2V0IHNsb3RzKCkge1xuICAgICAgICByZXR1cm4gc2xvdHNQcm94eSB8fCAoc2xvdHNQcm94eSA9IGdldFNsb3RzUHJveHkoaW5zdGFuY2UpKTtcbiAgICAgIH0sXG4gICAgICBnZXQgZW1pdCgpIHtcbiAgICAgICAgcmV0dXJuIChldmVudCwgLi4uYXJncykgPT4gaW5zdGFuY2UuZW1pdChldmVudCwgLi4uYXJncyk7XG4gICAgICB9LFxuICAgICAgZXhwb3NlXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGF0dHJzOiBuZXcgUHJveHkoaW5zdGFuY2UuYXR0cnMsIGF0dHJzUHJveHlIYW5kbGVycyksXG4gICAgICBzbG90czogaW5zdGFuY2Uuc2xvdHMsXG4gICAgICBlbWl0OiBpbnN0YW5jZS5lbWl0LFxuICAgICAgZXhwb3NlXG4gICAgfTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50UHVibGljSW5zdGFuY2UoaW5zdGFuY2UpIHtcbiAgaWYgKGluc3RhbmNlLmV4cG9zZWQpIHtcbiAgICByZXR1cm4gaW5zdGFuY2UuZXhwb3NlUHJveHkgfHwgKGluc3RhbmNlLmV4cG9zZVByb3h5ID0gbmV3IFByb3h5KHByb3h5UmVmcyhtYXJrUmF3KGluc3RhbmNlLmV4cG9zZWQpKSwge1xuICAgICAgZ2V0KHRhcmdldCwga2V5KSB7XG4gICAgICAgIGlmIChrZXkgaW4gdGFyZ2V0KSB7XG4gICAgICAgICAgcmV0dXJuIHRhcmdldFtrZXldO1xuICAgICAgICB9IGVsc2UgaWYgKGtleSBpbiBwdWJsaWNQcm9wZXJ0aWVzTWFwKSB7XG4gICAgICAgICAgcmV0dXJuIHB1YmxpY1Byb3BlcnRpZXNNYXBba2V5XShpbnN0YW5jZSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBoYXModGFyZ2V0LCBrZXkpIHtcbiAgICAgICAgcmV0dXJuIGtleSBpbiB0YXJnZXQgfHwga2V5IGluIHB1YmxpY1Byb3BlcnRpZXNNYXA7XG4gICAgICB9XG4gICAgfSkpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBpbnN0YW5jZS5wcm94eTtcbiAgfVxufVxuY29uc3QgY2xhc3NpZnlSRSA9IC8oPzpefFstX10pXFx3L2c7XG5jb25zdCBjbGFzc2lmeSA9IChzdHIpID0+IHN0ci5yZXBsYWNlKGNsYXNzaWZ5UkUsIChjKSA9PiBjLnRvVXBwZXJDYXNlKCkpLnJlcGxhY2UoL1stX10vZywgXCJcIik7XG5mdW5jdGlvbiBnZXRDb21wb25lbnROYW1lKENvbXBvbmVudCwgaW5jbHVkZUluZmVycmVkID0gdHJ1ZSkge1xuICByZXR1cm4gaXNGdW5jdGlvbihDb21wb25lbnQpID8gQ29tcG9uZW50LmRpc3BsYXlOYW1lIHx8IENvbXBvbmVudC5uYW1lIDogQ29tcG9uZW50Lm5hbWUgfHwgaW5jbHVkZUluZmVycmVkICYmIENvbXBvbmVudC5fX25hbWU7XG59XG5mdW5jdGlvbiBmb3JtYXRDb21wb25lbnROYW1lKGluc3RhbmNlLCBDb21wb25lbnQsIGlzUm9vdCA9IGZhbHNlKSB7XG4gIGxldCBuYW1lID0gZ2V0Q29tcG9uZW50TmFtZShDb21wb25lbnQpO1xuICBpZiAoIW5hbWUgJiYgQ29tcG9uZW50Ll9fZmlsZSkge1xuICAgIGNvbnN0IG1hdGNoID0gQ29tcG9uZW50Ll9fZmlsZS5tYXRjaCgvKFteL1xcXFxdKylcXC5cXHcrJC8pO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgbmFtZSA9IG1hdGNoWzFdO1xuICAgIH1cbiAgfVxuICBpZiAoIW5hbWUgJiYgaW5zdGFuY2UpIHtcbiAgICBjb25zdCBpbmZlckZyb21SZWdpc3RyeSA9IChyZWdpc3RyeSkgPT4ge1xuICAgICAgZm9yIChjb25zdCBrZXkgaW4gcmVnaXN0cnkpIHtcbiAgICAgICAgaWYgKHJlZ2lzdHJ5W2tleV0gPT09IENvbXBvbmVudCkge1xuICAgICAgICAgIHJldHVybiBrZXk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIG5hbWUgPSBpbmZlckZyb21SZWdpc3RyeShpbnN0YW5jZS5jb21wb25lbnRzKSB8fCBpbnN0YW5jZS5wYXJlbnQgJiYgaW5mZXJGcm9tUmVnaXN0cnkoXG4gICAgICBpbnN0YW5jZS5wYXJlbnQudHlwZS5jb21wb25lbnRzXG4gICAgKSB8fCBpbmZlckZyb21SZWdpc3RyeShpbnN0YW5jZS5hcHBDb250ZXh0LmNvbXBvbmVudHMpO1xuICB9XG4gIHJldHVybiBuYW1lID8gY2xhc3NpZnkobmFtZSkgOiBpc1Jvb3QgPyBgQXBwYCA6IGBBbm9ueW1vdXNgO1xufVxuZnVuY3Rpb24gaXNDbGFzc0NvbXBvbmVudCh2YWx1ZSkge1xuICByZXR1cm4gaXNGdW5jdGlvbih2YWx1ZSkgJiYgXCJfX3ZjY09wdHNcIiBpbiB2YWx1ZTtcbn1cblxuY29uc3QgY29tcHV0ZWQgPSAoZ2V0dGVyT3JPcHRpb25zLCBkZWJ1Z09wdGlvbnMpID0+IHtcbiAgY29uc3QgYyA9IGNvbXB1dGVkJDEoZ2V0dGVyT3JPcHRpb25zLCBkZWJ1Z09wdGlvbnMsIGlzSW5TU1JDb21wb25lbnRTZXR1cCk7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgY29uc3QgaSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIGlmIChpICYmIGkuYXBwQ29udGV4dC5jb25maWcud2FyblJlY3Vyc2l2ZUNvbXB1dGVkKSB7XG4gICAgICBjLl93YXJuUmVjdXJzaXZlID0gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGM7XG59O1xuXG5mdW5jdGlvbiBoKHR5cGUsIHByb3BzT3JDaGlsZHJlbiwgY2hpbGRyZW4pIHtcbiAgdHJ5IHtcbiAgICBzZXRCbG9ja1RyYWNraW5nKC0xKTtcbiAgICBjb25zdCBsID0gYXJndW1lbnRzLmxlbmd0aDtcbiAgICBpZiAobCA9PT0gMikge1xuICAgICAgaWYgKGlzT2JqZWN0KHByb3BzT3JDaGlsZHJlbikgJiYgIWlzQXJyYXkocHJvcHNPckNoaWxkcmVuKSkge1xuICAgICAgICBpZiAoaXNWTm9kZShwcm9wc09yQ2hpbGRyZW4pKSB7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZVZOb2RlKHR5cGUsIG51bGwsIFtwcm9wc09yQ2hpbGRyZW5dKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY3JlYXRlVk5vZGUodHlwZSwgcHJvcHNPckNoaWxkcmVuKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBjcmVhdGVWTm9kZSh0eXBlLCBudWxsLCBwcm9wc09yQ2hpbGRyZW4pO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAobCA+IDMpIHtcbiAgICAgICAgY2hpbGRyZW4gPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDIpO1xuICAgICAgfSBlbHNlIGlmIChsID09PSAzICYmIGlzVk5vZGUoY2hpbGRyZW4pKSB7XG4gICAgICAgIGNoaWxkcmVuID0gW2NoaWxkcmVuXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjcmVhdGVWTm9kZSh0eXBlLCBwcm9wc09yQ2hpbGRyZW4sIGNoaWxkcmVuKTtcbiAgICB9XG4gIH0gZmluYWxseSB7XG4gICAgc2V0QmxvY2tUcmFja2luZygxKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpbml0Q3VzdG9tRm9ybWF0dGVyKCkge1xuICBpZiAoISEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB2dWVTdHlsZSA9IHsgc3R5bGU6IFwiY29sb3I6IzNiYTc3NlwiIH07XG4gIGNvbnN0IG51bWJlclN0eWxlID0geyBzdHlsZTogXCJjb2xvcjojMTY3N2ZmXCIgfTtcbiAgY29uc3Qgc3RyaW5nU3R5bGUgPSB7IHN0eWxlOiBcImNvbG9yOiNmNTIyMmRcIiB9O1xuICBjb25zdCBrZXl3b3JkU3R5bGUgPSB7IHN0eWxlOiBcImNvbG9yOiNlYjJmOTZcIiB9O1xuICBjb25zdCBmb3JtYXR0ZXIgPSB7XG4gICAgX192dWVfY3VzdG9tX2Zvcm1hdHRlcjogdHJ1ZSxcbiAgICBoZWFkZXIob2JqKSB7XG4gICAgICBpZiAoIWlzT2JqZWN0KG9iaikpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBpZiAob2JqLl9faXNWdWUpIHtcbiAgICAgICAgcmV0dXJuIFtcImRpdlwiLCB2dWVTdHlsZSwgYFZ1ZUluc3RhbmNlYF07XG4gICAgICB9IGVsc2UgaWYgKGlzUmVmKG9iaikpIHtcbiAgICAgICAgcGF1c2VUcmFja2luZygpO1xuICAgICAgICBjb25zdCB2YWx1ZSA9IG9iai52YWx1ZTtcbiAgICAgICAgcmVzZXRUcmFja2luZygpO1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAge30sXG4gICAgICAgICAgW1wic3BhblwiLCB2dWVTdHlsZSwgZ2VuUmVmRmxhZyhvYmopXSxcbiAgICAgICAgICBcIjxcIixcbiAgICAgICAgICBmb3JtYXRWYWx1ZSh2YWx1ZSksXG4gICAgICAgICAgYD5gXG4gICAgICAgIF07XG4gICAgICB9IGVsc2UgaWYgKGlzUmVhY3RpdmUob2JqKSkge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAge30sXG4gICAgICAgICAgW1wic3BhblwiLCB2dWVTdHlsZSwgaXNTaGFsbG93KG9iaikgPyBcIlNoYWxsb3dSZWFjdGl2ZVwiIDogXCJSZWFjdGl2ZVwiXSxcbiAgICAgICAgICBcIjxcIixcbiAgICAgICAgICBmb3JtYXRWYWx1ZShvYmopLFxuICAgICAgICAgIGA+JHtpc1JlYWRvbmx5KG9iaikgPyBgIChyZWFkb25seSlgIDogYGB9YFxuICAgICAgICBdO1xuICAgICAgfSBlbHNlIGlmIChpc1JlYWRvbmx5KG9iaikpIHtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIFtcInNwYW5cIiwgdnVlU3R5bGUsIGlzU2hhbGxvdyhvYmopID8gXCJTaGFsbG93UmVhZG9ubHlcIiA6IFwiUmVhZG9ubHlcIl0sXG4gICAgICAgICAgXCI8XCIsXG4gICAgICAgICAgZm9ybWF0VmFsdWUob2JqKSxcbiAgICAgICAgICBcIj5cIlxuICAgICAgICBdO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfSxcbiAgICBoYXNCb2R5KG9iaikge1xuICAgICAgcmV0dXJuIG9iaiAmJiBvYmouX19pc1Z1ZTtcbiAgICB9LFxuICAgIGJvZHkob2JqKSB7XG4gICAgICBpZiAob2JqICYmIG9iai5fX2lzVnVlKSB7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICB7fSxcbiAgICAgICAgICAuLi5mb3JtYXRJbnN0YW5jZShvYmouJClcbiAgICAgICAgXTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGZ1bmN0aW9uIGZvcm1hdEluc3RhbmNlKGluc3RhbmNlKSB7XG4gICAgY29uc3QgYmxvY2tzID0gW107XG4gICAgaWYgKGluc3RhbmNlLnR5cGUucHJvcHMgJiYgaW5zdGFuY2UucHJvcHMpIHtcbiAgICAgIGJsb2Nrcy5wdXNoKGNyZWF0ZUluc3RhbmNlQmxvY2soXCJwcm9wc1wiLCB0b1JhdyhpbnN0YW5jZS5wcm9wcykpKTtcbiAgICB9XG4gICAgaWYgKGluc3RhbmNlLnNldHVwU3RhdGUgIT09IEVNUFRZX09CSikge1xuICAgICAgYmxvY2tzLnB1c2goY3JlYXRlSW5zdGFuY2VCbG9jayhcInNldHVwXCIsIGluc3RhbmNlLnNldHVwU3RhdGUpKTtcbiAgICB9XG4gICAgaWYgKGluc3RhbmNlLmRhdGEgIT09IEVNUFRZX09CSikge1xuICAgICAgYmxvY2tzLnB1c2goY3JlYXRlSW5zdGFuY2VCbG9jayhcImRhdGFcIiwgdG9SYXcoaW5zdGFuY2UuZGF0YSkpKTtcbiAgICB9XG4gICAgY29uc3QgY29tcHV0ZWQgPSBleHRyYWN0S2V5cyhpbnN0YW5jZSwgXCJjb21wdXRlZFwiKTtcbiAgICBpZiAoY29tcHV0ZWQpIHtcbiAgICAgIGJsb2Nrcy5wdXNoKGNyZWF0ZUluc3RhbmNlQmxvY2soXCJjb21wdXRlZFwiLCBjb21wdXRlZCkpO1xuICAgIH1cbiAgICBjb25zdCBpbmplY3RlZCA9IGV4dHJhY3RLZXlzKGluc3RhbmNlLCBcImluamVjdFwiKTtcbiAgICBpZiAoaW5qZWN0ZWQpIHtcbiAgICAgIGJsb2Nrcy5wdXNoKGNyZWF0ZUluc3RhbmNlQmxvY2soXCJpbmplY3RlZFwiLCBpbmplY3RlZCkpO1xuICAgIH1cbiAgICBibG9ja3MucHVzaChbXG4gICAgICBcImRpdlwiLFxuICAgICAge30sXG4gICAgICBbXG4gICAgICAgIFwic3BhblwiLFxuICAgICAgICB7XG4gICAgICAgICAgc3R5bGU6IGtleXdvcmRTdHlsZS5zdHlsZSArIFwiO29wYWNpdHk6MC42NlwiXG4gICAgICAgIH0sXG4gICAgICAgIFwiJCAoaW50ZXJuYWwpOiBcIlxuICAgICAgXSxcbiAgICAgIFtcIm9iamVjdFwiLCB7IG9iamVjdDogaW5zdGFuY2UgfV1cbiAgICBdKTtcbiAgICByZXR1cm4gYmxvY2tzO1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZUluc3RhbmNlQmxvY2sodHlwZSwgdGFyZ2V0KSB7XG4gICAgdGFyZ2V0ID0gZXh0ZW5kKHt9LCB0YXJnZXQpO1xuICAgIGlmICghT2JqZWN0LmtleXModGFyZ2V0KS5sZW5ndGgpIHtcbiAgICAgIHJldHVybiBbXCJzcGFuXCIsIHt9XTtcbiAgICB9XG4gICAgcmV0dXJuIFtcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IHN0eWxlOiBcImxpbmUtaGVpZ2h0OjEuMjVlbTttYXJnaW4tYm90dG9tOjAuNmVtXCIgfSxcbiAgICAgIFtcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAge1xuICAgICAgICAgIHN0eWxlOiBcImNvbG9yOiM0NzY1ODJcIlxuICAgICAgICB9LFxuICAgICAgICB0eXBlXG4gICAgICBdLFxuICAgICAgW1xuICAgICAgICBcImRpdlwiLFxuICAgICAgICB7XG4gICAgICAgICAgc3R5bGU6IFwicGFkZGluZy1sZWZ0OjEuMjVlbVwiXG4gICAgICAgIH0sXG4gICAgICAgIC4uLk9iamVjdC5rZXlzKHRhcmdldCkubWFwKChrZXkpID0+IHtcbiAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgW1wic3BhblwiLCBrZXl3b3JkU3R5bGUsIGtleSArIFwiOiBcIl0sXG4gICAgICAgICAgICBmb3JtYXRWYWx1ZSh0YXJnZXRba2V5XSwgZmFsc2UpXG4gICAgICAgICAgXTtcbiAgICAgICAgfSlcbiAgICAgIF1cbiAgICBdO1xuICB9XG4gIGZ1bmN0aW9uIGZvcm1hdFZhbHVlKHYsIGFzUmF3ID0gdHJ1ZSkge1xuICAgIGlmICh0eXBlb2YgdiA9PT0gXCJudW1iZXJcIikge1xuICAgICAgcmV0dXJuIFtcInNwYW5cIiwgbnVtYmVyU3R5bGUsIHZdO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiBbXCJzcGFuXCIsIHN0cmluZ1N0eWxlLCBKU09OLnN0cmluZ2lmeSh2KV07XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gXCJib29sZWFuXCIpIHtcbiAgICAgIHJldHVybiBbXCJzcGFuXCIsIGtleXdvcmRTdHlsZSwgdl07XG4gICAgfSBlbHNlIGlmIChpc09iamVjdCh2KSkge1xuICAgICAgcmV0dXJuIFtcIm9iamVjdFwiLCB7IG9iamVjdDogYXNSYXcgPyB0b1Jhdyh2KSA6IHYgfV07XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBbXCJzcGFuXCIsIHN0cmluZ1N0eWxlLCBTdHJpbmcodildO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBleHRyYWN0S2V5cyhpbnN0YW5jZSwgdHlwZSkge1xuICAgIGNvbnN0IENvbXAgPSBpbnN0YW5jZS50eXBlO1xuICAgIGlmIChpc0Z1bmN0aW9uKENvbXApKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGV4dHJhY3RlZCA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IGluIGluc3RhbmNlLmN0eCkge1xuICAgICAgaWYgKGlzS2V5T2ZUeXBlKENvbXAsIGtleSwgdHlwZSkpIHtcbiAgICAgICAgZXh0cmFjdGVkW2tleV0gPSBpbnN0YW5jZS5jdHhba2V5XTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGV4dHJhY3RlZDtcbiAgfVxuICBmdW5jdGlvbiBpc0tleU9mVHlwZShDb21wLCBrZXksIHR5cGUpIHtcbiAgICBjb25zdCBvcHRzID0gQ29tcFt0eXBlXTtcbiAgICBpZiAoaXNBcnJheShvcHRzKSAmJiBvcHRzLmluY2x1ZGVzKGtleSkgfHwgaXNPYmplY3Qob3B0cykgJiYga2V5IGluIG9wdHMpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoQ29tcC5leHRlbmRzICYmIGlzS2V5T2ZUeXBlKENvbXAuZXh0ZW5kcywga2V5LCB0eXBlKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChDb21wLm1peGlucyAmJiBDb21wLm1peGlucy5zb21lKChtKSA9PiBpc0tleU9mVHlwZShtLCBrZXksIHR5cGUpKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGdlblJlZkZsYWcodikge1xuICAgIGlmIChpc1NoYWxsb3codikpIHtcbiAgICAgIHJldHVybiBgU2hhbGxvd1JlZmA7XG4gICAgfVxuICAgIGlmICh2LmVmZmVjdCkge1xuICAgICAgcmV0dXJuIGBDb21wdXRlZFJlZmA7XG4gICAgfVxuICAgIHJldHVybiBgUmVmYDtcbiAgfVxuICBpZiAod2luZG93LmRldnRvb2xzRm9ybWF0dGVycykge1xuICAgIHdpbmRvdy5kZXZ0b29sc0Zvcm1hdHRlcnMucHVzaChmb3JtYXR0ZXIpO1xuICB9IGVsc2Uge1xuICAgIHdpbmRvdy5kZXZ0b29sc0Zvcm1hdHRlcnMgPSBbZm9ybWF0dGVyXTtcbiAgfVxufVxuXG5mdW5jdGlvbiB3aXRoTWVtbyhtZW1vLCByZW5kZXIsIGNhY2hlLCBpbmRleCkge1xuICBjb25zdCBjYWNoZWQgPSBjYWNoZVtpbmRleF07XG4gIGlmIChjYWNoZWQgJiYgaXNNZW1vU2FtZShjYWNoZWQsIG1lbW8pKSB7XG4gICAgcmV0dXJuIGNhY2hlZDtcbiAgfVxuICBjb25zdCByZXQgPSByZW5kZXIoKTtcbiAgcmV0Lm1lbW8gPSBtZW1vLnNsaWNlKCk7XG4gIHJldC5jYWNoZUluZGV4ID0gaW5kZXg7XG4gIHJldHVybiBjYWNoZVtpbmRleF0gPSByZXQ7XG59XG5mdW5jdGlvbiBpc01lbW9TYW1lKGNhY2hlZCwgbWVtbykge1xuICBjb25zdCBwcmV2ID0gY2FjaGVkLm1lbW87XG4gIGlmIChwcmV2Lmxlbmd0aCAhPSBtZW1vLmxlbmd0aCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IHByZXYubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoaGFzQ2hhbmdlZChwcmV2W2ldLCBtZW1vW2ldKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICBpZiAoaXNCbG9ja1RyZWVFbmFibGVkID4gMCAmJiBjdXJyZW50QmxvY2spIHtcbiAgICBjdXJyZW50QmxvY2sucHVzaChjYWNoZWQpO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG5jb25zdCB2ZXJzaW9uID0gXCIzLjUuNDFcIjtcbmNvbnN0IHdhcm4gPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gd2FybiQxIDogTk9PUDtcbmNvbnN0IEVycm9yVHlwZVN0cmluZ3MgPSBFcnJvclR5cGVTdHJpbmdzJDEgO1xuY29uc3QgZGV2dG9vbHMgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IHRydWUgPyBkZXZ0b29scyQxIDogdm9pZCAwO1xuY29uc3Qgc2V0RGV2dG9vbHNIb29rID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCB0cnVlID8gc2V0RGV2dG9vbHNIb29rJDEgOiBOT09QO1xuY29uc3QgX3NzclV0aWxzID0ge1xuICBjcmVhdGVDb21wb25lbnRJbnN0YW5jZSxcbiAgc2V0dXBDb21wb25lbnQsXG4gIHJlbmRlckNvbXBvbmVudFJvb3QsXG4gIHNldEN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSxcbiAgaXNWTm9kZTogaXNWTm9kZSxcbiAgbm9ybWFsaXplVk5vZGUsXG4gIGdldENvbXBvbmVudFB1YmxpY0luc3RhbmNlLFxuICBlbnN1cmVWYWxpZFZOb2RlLFxuICBwdXNoV2FybmluZ0NvbnRleHQsXG4gIHBvcFdhcm5pbmdDb250ZXh0XG59O1xuY29uc3Qgc3NyVXRpbHMgPSBfc3NyVXRpbHMgO1xuY29uc3QgcmVzb2x2ZUZpbHRlciA9IG51bGw7XG5jb25zdCBjb21wYXRVdGlscyA9IG51bGw7XG5jb25zdCBEZXByZWNhdGlvblR5cGVzID0gbnVsbDtcblxuZXhwb3J0IHsgQmFzZVRyYW5zaXRpb24sIEJhc2VUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzLCBDb21tZW50LCBEZXByZWNhdGlvblR5cGVzLCBFcnJvckNvZGVzLCBFcnJvclR5cGVTdHJpbmdzLCBGcmFnbWVudCwgS2VlcEFsaXZlLCBTdGF0aWMsIFN1c3BlbnNlLCBUZWxlcG9ydCwgVGV4dCwgYXNzZXJ0TnVtYmVyLCBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZywgY2FsbFdpdGhFcnJvckhhbmRsaW5nLCBjbG9uZVZOb2RlLCBjb21wYXRVdGlscywgY29tcHV0ZWQsIGNyZWF0ZUJsb2NrLCBjcmVhdGVDb21tZW50Vk5vZGUsIGNyZWF0ZUVsZW1lbnRCbG9jaywgY3JlYXRlQmFzZVZOb2RlIGFzIGNyZWF0ZUVsZW1lbnRWTm9kZSwgY3JlYXRlSHlkcmF0aW9uUmVuZGVyZXIsIGNyZWF0ZVByb3BzUmVzdFByb3h5LCBjcmVhdGVSZW5kZXJlciwgY3JlYXRlU2xvdHMsIGNyZWF0ZVN0YXRpY1ZOb2RlLCBjcmVhdGVUZXh0Vk5vZGUsIGNyZWF0ZVZOb2RlLCBkZWZpbmVBc3luY0NvbXBvbmVudCwgZGVmaW5lQ29tcG9uZW50LCBkZWZpbmVFbWl0cywgZGVmaW5lRXhwb3NlLCBkZWZpbmVNb2RlbCwgZGVmaW5lT3B0aW9ucywgZGVmaW5lUHJvcHMsIGRlZmluZVNsb3RzLCBkZXZ0b29scywgZ2V0Q3VycmVudEluc3RhbmNlLCBnZXRUcmFuc2l0aW9uUmF3Q2hpbGRyZW4sIGd1YXJkUmVhY3RpdmVQcm9wcywgaCwgaGFuZGxlRXJyb3IsIGhhc0luamVjdGlvbkNvbnRleHQsIGh5ZHJhdGVPbklkbGUsIGh5ZHJhdGVPbkludGVyYWN0aW9uLCBoeWRyYXRlT25NZWRpYVF1ZXJ5LCBoeWRyYXRlT25WaXNpYmxlLCBpbml0Q3VzdG9tRm9ybWF0dGVyLCBpbmplY3QsIGlzTWVtb1NhbWUsIGlzUnVudGltZU9ubHksIGlzVk5vZGUsIG1lcmdlRGVmYXVsdHMsIG1lcmdlTW9kZWxzLCBtZXJnZVByb3BzLCBuZXh0VGljaywgb25BY3RpdmF0ZWQsIG9uQmVmb3JlTW91bnQsIG9uQmVmb3JlVW5tb3VudCwgb25CZWZvcmVVcGRhdGUsIG9uRGVhY3RpdmF0ZWQsIG9uRXJyb3JDYXB0dXJlZCwgb25Nb3VudGVkLCBvblJlbmRlclRyYWNrZWQsIG9uUmVuZGVyVHJpZ2dlcmVkLCBvblNlcnZlclByZWZldGNoLCBvblVubW91bnRlZCwgb25VcGRhdGVkLCBvcGVuQmxvY2ssIHBvcFNjb3BlSWQsIHByb3ZpZGUsIHB1c2hTY29wZUlkLCBxdWV1ZVBvc3RGbHVzaENiLCByZWdpc3RlclJ1bnRpbWVDb21waWxlciwgcmVuZGVyTGlzdCwgcmVuZGVyU2xvdCwgcmVzb2x2ZUNvbXBvbmVudCwgcmVzb2x2ZURpcmVjdGl2ZSwgcmVzb2x2ZUR5bmFtaWNDb21wb25lbnQsIHJlc29sdmVGaWx0ZXIsIHJlc29sdmVUcmFuc2l0aW9uSG9va3MsIHNldEJsb2NrVHJhY2tpbmcsIHNldERldnRvb2xzSG9vaywgc2V0VHJhbnNpdGlvbkhvb2tzLCBzc3JDb250ZXh0S2V5LCBzc3JVdGlscywgdG9IYW5kbGVycywgdHJhbnNmb3JtVk5vZGVBcmdzLCB1c2VBdHRycywgdXNlSWQsIHVzZU1vZGVsLCB1c2VTU1JDb250ZXh0LCB1c2VTbG90cywgdXNlVGVtcGxhdGVSZWYsIHVzZVRyYW5zaXRpb25TdGF0ZSwgdmVyc2lvbiwgd2Fybiwgd2F0Y2gsIHdhdGNoRWZmZWN0LCB3YXRjaFBvc3RFZmZlY3QsIHdhdGNoU3luY0VmZmVjdCwgd2l0aEFzeW5jQ29udGV4dCwgd2l0aEN0eCwgd2l0aERlZmF1bHRzLCB3aXRoRGlyZWN0aXZlcywgd2l0aE1lbW8sIHdpdGhTY29wZUlkIH07XG4iXSwibWFwcGluZ3MiOiJBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLQSxTQUFTLGVBQWUsZUFBZSxPQUFPLE9BQU8sVUFBVSxTQUFTLFNBQVMsWUFBWSxVQUFVLFlBQVksS0FBSyxXQUFXLFlBQVksa0JBQWtCLFlBQVksWUFBWSxpQkFBaUIsT0FBTyxVQUFVLFdBQVcsaUJBQWlCLFNBQVMsZ0JBQWdCLFNBQVMsV0FBVyxTQUFTLGFBQWEsWUFBWSxrQkFBa0I7QUFDeFYsU0FBUyxhQUFhLGdCQUFnQixjQUFjLGdCQUFnQixXQUFXLFFBQVEsYUFBYSxpQkFBaUIsbUJBQW1CLFNBQVMsWUFBWSxZQUFZLE9BQU8sV0FBVyxTQUFTLGdCQUFnQixrQkFBa0IsV0FBVyxVQUFVLFVBQVUsS0FBSyxpQkFBaUIsaUJBQWlCLFlBQVksTUFBTSxPQUFPLE9BQU8sUUFBUSxTQUFTLFlBQVksYUFBYTtBQUN0WCxTQUFTLFVBQVUsWUFBWSxXQUFXLFdBQVcsU0FBUyxNQUFNLGVBQWUsUUFBUSxvQkFBb0IsSUFBSSxRQUFRLFFBQVEsS0FBSyxNQUFNLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLGdCQUFnQixnQkFBZ0IsZUFBZSxpQkFBaUIsb0JBQW9CLHVCQUF1QixzQkFBc0Isc0JBQXNCLFVBQVUsVUFBVSxnQkFBZ0IsY0FBYyxVQUFVLFlBQVksVUFBVSxtQkFBbUIsV0FBVyxZQUFZLGVBQWUsaUJBQWlCLFlBQVksV0FBVyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzVpQixTQUFTLFVBQVUsWUFBWSxnQkFBZ0IsZ0JBQWdCLGdCQUFnQixpQkFBaUIsb0JBQW9CO0FBRXBILE1BQU0sUUFBUSxDQUFDO0FBQ2YsU0FBUyxtQkFBbUIsT0FBTztBQUNqQyxRQUFNLEtBQUssS0FBSztBQUNsQjtBQUNBLFNBQVMsb0JBQW9CO0FBQzNCLFFBQU0sSUFBSTtBQUNaO0FBQ0EsSUFBSSxZQUFZO0FBQ2hCLFNBQVMsT0FBTyxRQUFRLE1BQU07QUFDNUIsTUFBSSxVQUFXO0FBQ2YsY0FBWTtBQUNaLGdCQUFjO0FBQ2QsUUFBTSxXQUFXLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxDQUFDLEVBQUUsWUFBWTtBQUNwRSxRQUFNLGlCQUFpQixZQUFZLFNBQVMsV0FBVyxPQUFPO0FBQzlELFFBQU0sUUFBUSxrQkFBa0I7QUFDaEMsTUFBSSxnQkFBZ0I7QUFDbEI7QUFBQSxNQUNFO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUE7QUFBQSxRQUVFLE1BQU0sS0FBSyxJQUFJLENBQUMsTUFBTTtBQUNwQixjQUFJLElBQUk7QUFDUixrQkFBUSxNQUFNLEtBQUssRUFBRSxhQUFhLE9BQU8sU0FBUyxHQUFHLEtBQUssQ0FBQyxNQUFNLE9BQU8sS0FBSyxLQUFLLFVBQVUsQ0FBQztBQUFBLFFBQy9GLENBQUMsRUFBRSxLQUFLLEVBQUU7QUFBQSxRQUNWLFlBQVksU0FBUztBQUFBLFFBQ3JCLE1BQU07QUFBQSxVQUNKLENBQUMsRUFBRSxNQUFNLE1BQU0sT0FBTyxvQkFBb0IsVUFBVSxNQUFNLElBQUksQ0FBQztBQUFBLFFBQ2pFLEVBQUUsS0FBSyxJQUFJO0FBQUEsUUFDWDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixPQUFPO0FBQ0wsVUFBTSxXQUFXLENBQUMsZUFBZSxHQUFHLElBQUksR0FBRyxJQUFJO0FBQy9DLFFBQUksTUFBTTtBQUFBLElBQ1YsTUFBTTtBQUNKLGVBQVMsS0FBSztBQUFBLEdBQ2pCLEdBQUcsWUFBWSxLQUFLLENBQUM7QUFBQSxJQUNwQjtBQUNBLFlBQVEsS0FBSyxHQUFHLFFBQVE7QUFBQSxFQUMxQjtBQUNBLGdCQUFjO0FBQ2QsY0FBWTtBQUNkO0FBQ0EsU0FBUyxvQkFBb0I7QUFDM0IsTUFBSSxlQUFlLE1BQU0sTUFBTSxTQUFTLENBQUM7QUFDekMsTUFBSSxDQUFDLGNBQWM7QUFDakIsV0FBTyxDQUFDO0FBQUEsRUFDVjtBQUNBLFFBQU0sa0JBQWtCLENBQUM7QUFDekIsU0FBTyxjQUFjO0FBQ25CLFVBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUM5QixRQUFJLFFBQVEsS0FBSyxVQUFVLGNBQWM7QUFDdkMsV0FBSztBQUFBLElBQ1AsT0FBTztBQUNMLHNCQUFnQixLQUFLO0FBQUEsUUFDbkIsT0FBTztBQUFBLFFBQ1AsY0FBYztBQUFBLE1BQ2hCLENBQUM7QUFBQSxJQUNIO0FBQ0EsVUFBTSxpQkFBaUIsYUFBYSxhQUFhLGFBQWEsVUFBVTtBQUN4RSxtQkFBZSxrQkFBa0IsZUFBZTtBQUFBLEVBQ2xEO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxZQUFZLE9BQU87QUFDMUIsUUFBTSxPQUFPLENBQUM7QUFDZCxRQUFNLFFBQVEsQ0FBQyxPQUFPLE1BQU07QUFDMUIsU0FBSyxLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQUEsQ0FDaEMsR0FBRyxHQUFHLGlCQUFpQixLQUFLLENBQUM7QUFBQSxFQUM1QixDQUFDO0FBQ0QsU0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsRUFBRSxPQUFPLGFBQWEsR0FBRztBQUNqRCxRQUFNLFVBQVUsZUFBZSxJQUFJLFFBQVEsWUFBWSxzQkFBc0I7QUFDN0UsUUFBTSxTQUFTLE1BQU0sWUFBWSxNQUFNLFVBQVUsVUFBVSxPQUFPO0FBQ2xFLFFBQU0sT0FBTyxRQUFRO0FBQUEsSUFDbkIsTUFBTTtBQUFBLElBQ04sTUFBTTtBQUFBLElBQ047QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLFFBQVEsTUFBTTtBQUNwQixTQUFPLE1BQU0sUUFBUSxDQUFDLE1BQU0sR0FBRyxZQUFZLE1BQU0sS0FBSyxHQUFHLEtBQUssSUFBSSxDQUFDLE9BQU8sS0FBSztBQUNqRjtBQUNBLFNBQVMsWUFBWSxPQUFPO0FBQzFCLFFBQU0sTUFBTSxDQUFDO0FBQ2IsUUFBTSxPQUFPLE9BQU8sS0FBSyxLQUFLO0FBQzlCLE9BQUssTUFBTSxHQUFHLENBQUMsRUFBRSxRQUFRLENBQUMsUUFBUTtBQUNoQyxRQUFJLEtBQUssR0FBRyxXQUFXLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztBQUFBLEVBQ3pDLENBQUM7QUFDRCxNQUFJLEtBQUssU0FBUyxHQUFHO0FBQ25CLFFBQUksS0FBSyxNQUFNO0FBQUEsRUFDakI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsS0FBSyxPQUFPLEtBQUs7QUFDbkMsTUFBSSxTQUFTLEtBQUssR0FBRztBQUNuQixZQUFRLEtBQUssVUFBVSxLQUFLO0FBQzVCLFdBQU8sTUFBTSxRQUFRLENBQUMsR0FBRyxHQUFHLElBQUksS0FBSyxFQUFFO0FBQUEsRUFDekMsV0FBVyxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsYUFBYSxTQUFTLE1BQU07QUFDbkYsV0FBTyxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxLQUFLLEVBQUU7QUFBQSxFQUN6QyxXQUFXLE1BQU0sS0FBSyxHQUFHO0FBQ3ZCLFlBQVEsV0FBVyxLQUFLLE1BQU0sTUFBTSxLQUFLLEdBQUcsSUFBSTtBQUNoRCxXQUFPLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxTQUFTLE9BQU8sR0FBRztBQUFBLEVBQ2pELFdBQVcsV0FBVyxLQUFLLEdBQUc7QUFDNUIsV0FBTyxDQUFDLEdBQUcsR0FBRyxNQUFNLE1BQU0sT0FBTyxJQUFJLE1BQU0sSUFBSSxNQUFNLEVBQUUsRUFBRTtBQUFBLEVBQzNELE9BQU87QUFDTCxZQUFRLE1BQU0sS0FBSztBQUNuQixXQUFPLE1BQU0sUUFBUSxDQUFDLEdBQUcsR0FBRyxLQUFLLEtBQUs7QUFBQSxFQUN4QztBQUNGO0FBQ0EsU0FBUyxhQUFhLEtBQUssTUFBTTtBQUMvQixNQUFJLE1BQTRDO0FBQ2hELE1BQUksUUFBUSxRQUFRO0FBQ2xCO0FBQUEsRUFDRixXQUFXLE9BQU8sUUFBUSxVQUFVO0FBQ2xDLFdBQU8sR0FBRyxJQUFJLGdDQUFnQyxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQUc7QUFBQSxFQUN0RSxXQUFXLE1BQU0sR0FBRyxHQUFHO0FBQ3JCLFdBQU8sR0FBRyxJQUFJLHVEQUF1RDtBQUFBLEVBQ3ZFO0FBQ0Y7QUFFQSxNQUFNLGFBQWE7QUFBQSxFQUNqQixrQkFBa0I7QUFBQSxFQUNsQixLQUFLO0FBQUEsRUFDTCxtQkFBbUI7QUFBQSxFQUNuQixLQUFLO0FBQUEsRUFDTCx3QkFBd0I7QUFBQSxFQUN4QixLQUFLO0FBQUEsRUFDTCwyQkFBMkI7QUFBQSxFQUMzQixLQUFLO0FBQUEsRUFDTCxjQUFjO0FBQUEsRUFDZCxLQUFLO0FBQUEsRUFDTCxrQkFBa0I7QUFBQSxFQUNsQixLQUFLO0FBQUEsRUFDTCxtQkFBbUI7QUFBQSxFQUNuQixLQUFLO0FBQUEsRUFDTCxxQkFBcUI7QUFBQSxFQUNyQixNQUFNO0FBQUEsRUFDTixvQkFBb0I7QUFBQSxFQUNwQixNQUFNO0FBQUEsRUFDTixnQkFBZ0I7QUFBQSxFQUNoQixNQUFNO0FBQUEsRUFDTiwwQkFBMEI7QUFBQSxFQUMxQixNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixNQUFNO0FBQUEsRUFDTixvQkFBb0I7QUFBQSxFQUNwQixNQUFNO0FBQUEsRUFDTix1QkFBdUI7QUFBQSxFQUN2QixNQUFNO0FBQ1I7QUFDQSxNQUFNLHFCQUFxQjtBQUFBLEVBQ3pCLENBQUMsSUFBSSxHQUFHO0FBQUEsRUFDUixDQUFDLElBQUksR0FBRztBQUFBLEVBQ1IsQ0FBQyxHQUFHLEdBQUc7QUFBQSxFQUNQLENBQUMsSUFBSSxHQUFHO0FBQUEsRUFDUixDQUFDLEdBQUcsR0FBRztBQUFBLEVBQ1AsQ0FBQyxJQUFJLEdBQUc7QUFBQSxFQUNSLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDUCxDQUFDLEtBQUssR0FBRztBQUFBLEVBQ1QsQ0FBQyxJQUFJLEdBQUc7QUFBQSxFQUNSLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDUCxDQUFDLElBQUksR0FBRztBQUFBLEVBQ1IsQ0FBQyxJQUFJLEdBQUc7QUFBQSxFQUNSLENBQUMsS0FBSyxHQUFHO0FBQUEsRUFDVCxDQUFDLEtBQUssR0FBRztBQUFBLEVBQ1QsQ0FBQyxDQUFDLEdBQUc7QUFBQSxFQUNMLENBQUMsQ0FBQyxHQUFHO0FBQUEsRUFDTCxDQUFDLENBQUMsR0FBRztBQUFBLEVBQ0wsQ0FBQyxDQUFDLEdBQUc7QUFBQSxFQUNMLENBQUMsQ0FBQyxHQUFHO0FBQUEsRUFDTCxDQUFDLENBQUMsR0FBRztBQUFBLEVBQ0wsQ0FBQyxDQUFDLEdBQUc7QUFBQSxFQUNMLENBQUMsQ0FBQyxHQUFHO0FBQUEsRUFDTCxDQUFDLENBQUMsR0FBRztBQUFBLEVBQ0wsQ0FBQyxDQUFDLEdBQUc7QUFBQSxFQUNMLENBQUMsRUFBRSxHQUFHO0FBQUEsRUFDTixDQUFDLEVBQUUsR0FBRztBQUFBLEVBQ04sQ0FBQyxFQUFFLEdBQUc7QUFBQSxFQUNOLENBQUMsRUFBRSxHQUFHO0FBQUEsRUFDTixDQUFDLEVBQUUsR0FBRztBQUFBLEVBQ04sQ0FBQyxFQUFFLEdBQUc7QUFBQSxFQUNOLENBQUMsRUFBRSxHQUFHO0FBQ1I7QUFDQSxTQUFTLHNCQUFzQixJQUFJLFVBQVUsTUFBTSxNQUFNO0FBQ3ZELE1BQUk7QUFDRixXQUFPLE9BQU8sR0FBRyxHQUFHLElBQUksSUFBSSxHQUFHO0FBQUEsRUFDakMsU0FBUyxLQUFLO0FBQ1osZ0JBQVksS0FBSyxVQUFVLElBQUk7QUFBQSxFQUNqQztBQUNGO0FBQ0EsU0FBUywyQkFBMkIsSUFBSSxVQUFVLE1BQU0sTUFBTTtBQUM1RCxNQUFJLFdBQVcsRUFBRSxHQUFHO0FBQ2xCLFVBQU0sTUFBTSxzQkFBc0IsSUFBSSxVQUFVLE1BQU0sSUFBSTtBQUMxRCxRQUFJLE9BQU8sVUFBVSxHQUFHLEdBQUc7QUFDekIsVUFBSSxNQUFNLENBQUMsUUFBUTtBQUNqQixvQkFBWSxLQUFLLFVBQVUsSUFBSTtBQUFBLE1BQ2pDLENBQUM7QUFBQSxJQUNIO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFFBQVEsRUFBRSxHQUFHO0FBQ2YsVUFBTSxTQUFTLENBQUM7QUFDaEIsYUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsS0FBSztBQUNsQyxhQUFPLEtBQUssMkJBQTJCLEdBQUcsQ0FBQyxHQUFHLFVBQVUsTUFBTSxJQUFJLENBQUM7QUFBQSxJQUNyRTtBQUNBLFdBQU87QUFBQSxFQUNULFdBQVcsTUFBMkM7QUFDcEQ7QUFBQSxNQUNFLDhEQUE4RCxPQUFPLEVBQUU7QUFBQSxJQUN6RTtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsWUFBWSxLQUFLLFVBQVUsTUFBTSxhQUFhLE1BQU07QUFDM0QsUUFBTSxlQUFlLFdBQVcsU0FBUyxRQUFRO0FBQ2pELFFBQU0sRUFBRSxjQUFjLGdDQUFnQyxJQUFJLFlBQVksU0FBUyxXQUFXLFVBQVU7QUFDcEcsTUFBSSxVQUFVO0FBQ1osUUFBSSxNQUFNLFNBQVM7QUFDbkIsVUFBTSxrQkFBa0IsU0FBUztBQUNqQyxVQUFNLFlBQVksT0FBNEMsbUJBQW1CLElBQUksSUFBSSw4Q0FBOEMsSUFBSTtBQUMzSSxXQUFPLEtBQUs7QUFDVixZQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQUksb0JBQW9CO0FBQ3RCLGlCQUFTLElBQUksR0FBRyxJQUFJLG1CQUFtQixRQUFRLEtBQUs7QUFDbEQsY0FBSSxtQkFBbUIsQ0FBQyxFQUFFLEtBQUssaUJBQWlCLFNBQVMsTUFBTSxPQUFPO0FBQ3BFO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsWUFBTSxJQUFJO0FBQUEsSUFDWjtBQUNBLFFBQUksY0FBYztBQUNoQixvQkFBYztBQUNkLDRCQUFzQixjQUFjLE1BQU0sSUFBSTtBQUFBLFFBQzVDO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFDRCxvQkFBYztBQUNkO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxXQUFTLEtBQUssTUFBTSxjQUFjLFlBQVksK0JBQStCO0FBQy9FO0FBQ0EsU0FBUyxTQUFTLEtBQUssTUFBTSxjQUFjLGFBQWEsTUFBTSxjQUFjLE9BQU87QUFDakYsTUFBSSxNQUEyQztBQUM3QyxVQUFNLE9BQU8sbUJBQW1CLElBQUk7QUFDcEMsUUFBSSxjQUFjO0FBQ2hCLHlCQUFtQixZQUFZO0FBQUEsSUFDakM7QUFDQSxXQUFPLGtCQUFrQixPQUFPLHdCQUF3QixJQUFJLEtBQUssRUFBRSxFQUFFO0FBQ3JFLFFBQUksY0FBYztBQUNoQix3QkFBa0I7QUFBQSxJQUNwQjtBQUNBLFFBQUksWUFBWTtBQUNkLFlBQU07QUFBQSxJQUNSLE9BQU87QUFDTCxjQUFRLE1BQU0sR0FBRztBQUFBLElBQ25CO0FBQUEsRUFDRixXQUFXLGFBQWE7QUFDdEIsVUFBTTtBQUFBLEVBQ1IsT0FBTztBQUNMLFlBQVEsTUFBTSxHQUFHO0FBQUEsRUFDbkI7QUFDRjtBQUVBLE1BQU0sUUFBUSxDQUFDO0FBQ2YsSUFBSSxhQUFhO0FBQ2pCLE1BQU0sc0JBQXNCLENBQUM7QUFDN0IsSUFBSSxxQkFBcUI7QUFDekIsSUFBSSxpQkFBaUI7QUFDckIsTUFBTSxrQkFBa0Msd0JBQVEsUUFBUTtBQUN4RCxJQUFJLHNCQUFzQjtBQUMxQixNQUFNLGtCQUFrQjtBQUN4QixTQUFTLFNBQVMsSUFBSTtBQUNwQixRQUFNLElBQUksdUJBQXVCO0FBQ2pDLFNBQU8sS0FBSyxFQUFFLEtBQUssT0FBTyxHQUFHLEtBQUssSUFBSSxJQUFJLEVBQUUsSUFBSTtBQUNsRDtBQUNBLFNBQVMsbUJBQW1CLElBQUk7QUFDOUIsTUFBSSxRQUFRLGFBQWE7QUFDekIsTUFBSSxNQUFNLE1BQU07QUFDaEIsU0FBTyxRQUFRLEtBQUs7QUFDbEIsVUFBTSxTQUFTLFFBQVEsUUFBUTtBQUMvQixVQUFNLFlBQVksTUFBTSxNQUFNO0FBQzlCLFVBQU0sY0FBYyxNQUFNLFNBQVM7QUFDbkMsUUFBSSxjQUFjLE1BQU0sZ0JBQWdCLE1BQU0sVUFBVSxRQUFRLEdBQUc7QUFDakUsY0FBUSxTQUFTO0FBQUEsSUFDbkIsT0FBTztBQUNMLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsU0FBUyxLQUFLO0FBQ3JCLE1BQUksRUFBRSxJQUFJLFFBQVEsSUFBSTtBQUNwQixVQUFNLFFBQVEsTUFBTSxHQUFHO0FBQ3ZCLFVBQU0sVUFBVSxNQUFNLE1BQU0sU0FBUyxDQUFDO0FBQ3RDLFFBQUksQ0FBQztBQUFBLElBQ0wsRUFBRSxJQUFJLFFBQVEsTUFBTSxTQUFTLE1BQU0sT0FBTyxHQUFHO0FBQzNDLFlBQU0sS0FBSyxHQUFHO0FBQUEsSUFDaEIsT0FBTztBQUNMLFlBQU0sT0FBTyxtQkFBbUIsS0FBSyxHQUFHLEdBQUcsR0FBRztBQUFBLElBQ2hEO0FBQ0EsUUFBSSxTQUFTO0FBQ2IsZUFBVztBQUFBLEVBQ2I7QUFDRjtBQUNBLFNBQVMsYUFBYTtBQUNwQixNQUFJLENBQUMscUJBQXFCO0FBQ3hCLDBCQUFzQixnQkFBZ0IsS0FBSyxTQUFTO0FBQUEsRUFDdEQ7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLElBQUk7QUFDNUIsTUFBSSxDQUFDLFFBQVEsRUFBRSxHQUFHO0FBQ2hCLFFBQUksc0JBQXNCLEdBQUcsT0FBTyxJQUFJO0FBQ3RDLHlCQUFtQixPQUFPLGlCQUFpQixHQUFHLEdBQUcsRUFBRTtBQUFBLElBQ3JELFdBQVcsRUFBRSxHQUFHLFFBQVEsSUFBSTtBQUMxQiwwQkFBb0IsS0FBSyxFQUFFO0FBQzNCLFNBQUcsU0FBUztBQUFBLElBQ2Q7QUFBQSxFQUNGLE9BQU87QUFDTCxhQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsUUFBUSxLQUFLO0FBQ2xDLDBCQUFvQixLQUFLLEdBQUcsQ0FBQyxDQUFDO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBQ0EsYUFBVztBQUNiO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVSxNQUFNLElBQUksYUFBYSxHQUFHO0FBQzVELE1BQUksTUFBMkM7QUFDN0MsV0FBTyxRQUF3QixvQkFBSSxJQUFJO0FBQUEsRUFDekM7QUFDQSxTQUFPLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDNUIsVUFBTSxLQUFLLE1BQU0sQ0FBQztBQUNsQixRQUFJLE1BQU0sR0FBRyxRQUFRLEdBQUc7QUFDdEIsVUFBSSxZQUFZLEdBQUcsT0FBTyxTQUFTLEtBQUs7QUFDdEM7QUFBQSxNQUNGO0FBQ0EsVUFBaUQsc0JBQXNCLE1BQU0sRUFBRSxHQUFHO0FBQ2hGO0FBQUEsTUFDRjtBQUNBLFlBQU0sT0FBTyxHQUFHLENBQUM7QUFDakI7QUFDQSxVQUFJLEdBQUcsUUFBUSxHQUFHO0FBQ2hCLFdBQUcsU0FBUztBQUFBLE1BQ2Q7QUFDQSxTQUFHO0FBQ0gsVUFBSSxFQUFFLEdBQUcsUUFBUSxJQUFJO0FBQ25CLFdBQUcsU0FBUztBQUFBLE1BQ2Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtBQUMvQixNQUFJLG9CQUFvQixRQUFRO0FBQzlCLFVBQU0sVUFBVSxDQUFDLEdBQUcsSUFBSSxJQUFJLG1CQUFtQixDQUFDLEVBQUU7QUFBQSxNQUNoRCxDQUFDLEdBQUcsTUFBTSxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUM7QUFBQSxJQUM5QjtBQUNBLHdCQUFvQixTQUFTO0FBQzdCLFFBQUksb0JBQW9CO0FBQ3RCLGVBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7QUFDdkMsMkJBQW1CLEtBQUssUUFBUSxDQUFDLENBQUM7QUFBQSxNQUNwQztBQUNBO0FBQUEsSUFDRjtBQUNBLHlCQUFxQjtBQUNyQixRQUFJLE1BQTJDO0FBQzdDLGFBQU8sUUFBd0Isb0JBQUksSUFBSTtBQUFBLElBQ3pDO0FBQ0EsU0FBSyxpQkFBaUIsR0FBRyxpQkFBaUIsbUJBQW1CLFFBQVEsa0JBQWtCO0FBQ3JGLFlBQU0sS0FBSyxtQkFBbUIsY0FBYztBQUM1QyxVQUFpRCxzQkFBc0IsTUFBTSxFQUFFLEdBQUc7QUFDaEY7QUFBQSxNQUNGO0FBQ0EsVUFBSSxHQUFHLFFBQVEsR0FBRztBQUNoQixXQUFHLFNBQVM7QUFBQSxNQUNkO0FBQ0EsVUFBSSxFQUFFLEdBQUcsUUFBUSxHQUFJLElBQUc7QUFDeEIsU0FBRyxTQUFTO0FBQUEsSUFDZDtBQUNBLHlCQUFxQjtBQUNyQixxQkFBaUI7QUFBQSxFQUNuQjtBQUNGO0FBQ0EsTUFBTSxRQUFRLENBQUMsUUFBUSxJQUFJLE1BQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSxLQUFLLFdBQVcsSUFBSTtBQUM1RSxTQUFTLFVBQVUsTUFBTTtBQUN2QixNQUFJLE1BQTJDO0FBQzdDLFdBQU8sUUFBd0Isb0JBQUksSUFBSTtBQUFBLEVBQ3pDO0FBQ0EsUUFBTSxRQUFRLE9BQTRDLENBQUMsUUFBUSxzQkFBc0IsTUFBTSxHQUFHLElBQUk7QUFDdEcsTUFBSTtBQUNGLFNBQUssYUFBYSxHQUFHLGFBQWEsTUFBTSxRQUFRLGNBQWM7QUFDNUQsWUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFJLE9BQU8sRUFBRSxJQUFJLFFBQVEsSUFBSTtBQUMzQixZQUFpRCxNQUFNLEdBQUcsR0FBRztBQUMzRDtBQUFBLFFBQ0Y7QUFDQSxZQUFJLElBQUksUUFBUSxHQUFHO0FBQ2pCLGNBQUksU0FBUyxDQUFDO0FBQUEsUUFDaEI7QUFDQTtBQUFBLFVBQ0U7QUFBQSxVQUNBLElBQUk7QUFBQSxVQUNKLElBQUksSUFBSSxLQUFLO0FBQUEsUUFDZjtBQUNBLFlBQUksRUFBRSxJQUFJLFFBQVEsSUFBSTtBQUNwQixjQUFJLFNBQVMsQ0FBQztBQUFBLFFBQ2hCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGLFVBQUU7QUFDQSxXQUFPLGFBQWEsTUFBTSxRQUFRLGNBQWM7QUFDOUMsWUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFJLEtBQUs7QUFDUCxZQUFJLFNBQVM7QUFBQSxNQUNmO0FBQUEsSUFDRjtBQUNBLGlCQUFhO0FBQ2IsVUFBTSxTQUFTO0FBQ2Ysc0JBQWtCLElBQUk7QUFDdEIsMEJBQXNCO0FBQ3RCLFFBQUksTUFBTSxVQUFVLG9CQUFvQixRQUFRO0FBQzlDLGdCQUFVLElBQUk7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLE1BQU0sSUFBSTtBQUN2QyxRQUFNLFFBQVEsS0FBSyxJQUFJLEVBQUUsS0FBSztBQUM5QixNQUFJLFFBQVEsaUJBQWlCO0FBQzNCLFVBQU0sV0FBVyxHQUFHO0FBQ3BCLFVBQU0sZ0JBQWdCLFlBQVksaUJBQWlCLFNBQVMsSUFBSTtBQUNoRTtBQUFBLE1BQ0UscUNBQXFDLGdCQUFnQixrQkFBa0IsYUFBYSxNQUFNLEVBQUU7QUFBQSxNQUM1RjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxPQUFLLElBQUksSUFBSSxRQUFRLENBQUM7QUFDdEIsU0FBTztBQUNUO0FBRUEsSUFBSSxnQkFBZ0I7QUFDcEIsTUFBTSxpQkFBaUIsQ0FBQyxNQUFNO0FBQzVCLE1BQUk7QUFDRixXQUFPO0FBQUEsRUFDVCxVQUFFO0FBQ0Esb0JBQWdCO0FBQUEsRUFDbEI7QUFDRjtBQUNBLE1BQU0scUJBQXFDLG9CQUFJLElBQUk7QUFDbkQsSUFBSSxNQUEyQztBQUM3QyxnQkFBYyxFQUFFLHNCQUFzQjtBQUFBLElBQ3BDLGNBQWMsUUFBUSxZQUFZO0FBQUEsSUFDbEMsVUFBVSxRQUFRLFFBQVE7QUFBQSxJQUMxQixRQUFRLFFBQVEsTUFBTTtBQUFBLEVBQ3hCO0FBQ0Y7QUFDQSxNQUFNLE1BQXNCLG9CQUFJLElBQUk7QUFDcEMsU0FBUyxZQUFZLFVBQVU7QUFDN0IsUUFBTSxLQUFLLFNBQVMsS0FBSztBQUN6QixNQUFJLFNBQVMsSUFBSSxJQUFJLEVBQUU7QUFDdkIsTUFBSSxDQUFDLFFBQVE7QUFDWCxpQkFBYSxJQUFJLFNBQVMsSUFBSTtBQUM5QixhQUFTLElBQUksSUFBSSxFQUFFO0FBQUEsRUFDckI7QUFDQSxTQUFPLFVBQVUsSUFBSSxRQUFRO0FBQy9CO0FBQ0EsU0FBUyxjQUFjLFVBQVU7QUFDL0IsTUFBSSxJQUFJLFNBQVMsS0FBSyxPQUFPLEVBQUUsVUFBVSxPQUFPLFFBQVE7QUFDMUQ7QUFDQSxTQUFTLGFBQWEsSUFBSSxZQUFZO0FBQ3BDLE1BQUksSUFBSSxJQUFJLEVBQUUsR0FBRztBQUNmLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxJQUFJLElBQUk7QUFBQSxJQUNWLFlBQVksd0JBQXdCLFVBQVU7QUFBQSxJQUM5QyxXQUEyQixvQkFBSSxJQUFJO0FBQUEsRUFDckMsQ0FBQztBQUNELFNBQU87QUFDVDtBQUNBLFNBQVMsd0JBQXdCLFdBQVc7QUFDMUMsU0FBTyxpQkFBaUIsU0FBUyxJQUFJLFVBQVUsWUFBWTtBQUM3RDtBQUNBLFNBQVMsU0FBUyxJQUFJLFdBQVc7QUFDL0IsUUFBTSxTQUFTLElBQUksSUFBSSxFQUFFO0FBQ3pCLE1BQUksQ0FBQyxRQUFRO0FBQ1g7QUFBQSxFQUNGO0FBQ0EsU0FBTyxXQUFXLFNBQVM7QUFDM0IsR0FBQyxHQUFHLE9BQU8sU0FBUyxFQUFFLFFBQVEsQ0FBQyxhQUFhO0FBQzFDLFFBQUksV0FBVztBQUNiLGVBQVMsU0FBUztBQUNsQiw4QkFBd0IsU0FBUyxJQUFJLEVBQUUsU0FBUztBQUFBLElBQ2xEO0FBQ0EsYUFBUyxjQUFjLENBQUM7QUFDeEIsb0JBQWdCO0FBQ2hCLFFBQUksRUFBRSxTQUFTLElBQUksUUFBUSxJQUFJO0FBQzdCLGVBQVMsT0FBTztBQUFBLElBQ2xCO0FBQ0Esb0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUNIO0FBQ0EsU0FBUyxPQUFPLElBQUksU0FBUztBQUMzQixRQUFNLFNBQVMsSUFBSSxJQUFJLEVBQUU7QUFDekIsTUFBSSxDQUFDLE9BQVE7QUFDYixZQUFVLHdCQUF3QixPQUFPO0FBQ3pDLHFCQUFtQixPQUFPLFlBQVksT0FBTztBQUM3QyxRQUFNLFlBQVksQ0FBQyxHQUFHLE9BQU8sU0FBUztBQUN0QyxXQUFTLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0FBQ3pDLFVBQU0sV0FBVyxVQUFVLENBQUM7QUFDNUIsVUFBTSxVQUFVLHdCQUF3QixTQUFTLElBQUk7QUFDckQsUUFBSSxpQkFBaUIsbUJBQW1CLElBQUksT0FBTztBQUNuRCxRQUFJLENBQUMsZ0JBQWdCO0FBQ25CLFVBQUksWUFBWSxPQUFPLFlBQVk7QUFDakMsMkJBQW1CLFNBQVMsT0FBTztBQUFBLE1BQ3JDO0FBQ0EseUJBQW1CLElBQUksU0FBUyxpQkFBaUMsb0JBQUksSUFBSSxDQUFDO0FBQUEsSUFDNUU7QUFDQSxtQkFBZSxJQUFJLFFBQVE7QUFDM0IsYUFBUyxXQUFXLFdBQVcsT0FBTyxTQUFTLElBQUk7QUFDbkQsYUFBUyxXQUFXLFdBQVcsT0FBTyxTQUFTLElBQUk7QUFDbkQsYUFBUyxXQUFXLGFBQWEsT0FBTyxTQUFTLElBQUk7QUFDckQsUUFBSSxTQUFTLFVBQVU7QUFDckIscUJBQWUsSUFBSSxRQUFRO0FBQzNCLGVBQVMsU0FBUyxRQUFRLE1BQU07QUFDaEMscUJBQWUsT0FBTyxRQUFRO0FBQUEsSUFDaEMsV0FBVyxTQUFTLFFBQVE7QUFDMUIsZUFBUyxNQUFNO0FBQ2IsWUFBSSxFQUFFLFNBQVMsSUFBSSxRQUFRLElBQUk7QUFDN0IsMEJBQWdCO0FBQ2hCLG1CQUFTLE9BQU8sT0FBTztBQUN2QiwwQkFBZ0I7QUFDaEIseUJBQWUsT0FBTyxRQUFRO0FBQUEsUUFDaEM7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFdBQVcsU0FBUyxXQUFXLFFBQVE7QUFDckMsZUFBUyxXQUFXLE9BQU87QUFBQSxJQUM3QixXQUFXLE9BQU8sV0FBVyxhQUFhO0FBQ3hDLGFBQU8sU0FBUyxPQUFPO0FBQUEsSUFDekIsT0FBTztBQUNMLGNBQVE7QUFBQSxRQUNOO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsS0FBSyxNQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ2xELGVBQVMsS0FBSyxHQUFHLGtCQUFrQixPQUFPO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBQ0EsbUJBQWlCLE1BQU07QUFDckIsdUJBQW1CLE1BQU07QUFBQSxFQUMzQixDQUFDO0FBQ0g7QUFDQSxTQUFTLG1CQUFtQixTQUFTLFNBQVM7QUFDNUMsU0FBTyxTQUFTLE9BQU87QUFDdkIsYUFBVyxPQUFPLFNBQVM7QUFDekIsUUFBSSxRQUFRLFlBQVksRUFBRSxPQUFPLFVBQVU7QUFDekMsYUFBTyxRQUFRLEdBQUc7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsUUFBUSxJQUFJO0FBQ25CLFNBQU8sQ0FBQyxJQUFJLFFBQVE7QUFDbEIsUUFBSTtBQUNGLGFBQU8sR0FBRyxJQUFJLEdBQUc7QUFBQSxJQUNuQixTQUFTLEdBQUc7QUFDVixjQUFRLE1BQU0sQ0FBQztBQUNmLGNBQVE7QUFBQSxRQUNOO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxJQUFJO0FBQ0osSUFBSSxTQUFTLENBQUM7QUFDZCxJQUFJLHVCQUF1QjtBQUMzQixTQUFTLE9BQU8sVUFBVSxNQUFNO0FBQzlCLE1BQUksWUFBWTtBQUNkLGVBQVcsS0FBSyxPQUFPLEdBQUcsSUFBSTtBQUFBLEVBQ2hDLFdBQVcsQ0FBQyxzQkFBc0I7QUFDaEMsV0FBTyxLQUFLLEVBQUUsT0FBTyxLQUFLLENBQUM7QUFBQSxFQUM3QjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTSxRQUFRO0FBQ3ZDLE1BQUksSUFBSTtBQUNSLGVBQWE7QUFDYixNQUFJLFlBQVk7QUFDZCxlQUFXLFVBQVU7QUFDckIsV0FBTyxRQUFRLENBQUMsRUFBRSxPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssT0FBTyxHQUFHLElBQUksQ0FBQztBQUNuRSxhQUFTLENBQUM7QUFBQSxFQUNaO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJRSxPQUFPLFdBQVc7QUFBQSxJQUNsQixPQUFPO0FBQUE7QUFBQSxJQUVQLEdBQUcsTUFBTSxLQUFLLE9BQU8sY0FBYyxPQUFPLFNBQVMsR0FBRyxjQUFjLE9BQU8sU0FBUyxHQUFHLFNBQVMsT0FBTztBQUFBLElBQ3ZHO0FBQ0EsVUFBTSxTQUFTLE9BQU8sK0JBQStCLE9BQU8sZ0NBQWdDLENBQUM7QUFDN0YsV0FBTyxLQUFLLENBQUMsWUFBWTtBQUN2Qix3QkFBa0IsU0FBUyxNQUFNO0FBQUEsSUFDbkMsQ0FBQztBQUNELGVBQVcsTUFBTTtBQUNmLFVBQUksQ0FBQyxZQUFZO0FBQ2YsZUFBTywrQkFBK0I7QUFDdEMsK0JBQXVCO0FBQ3ZCLGlCQUFTLENBQUM7QUFBQSxNQUNaO0FBQUEsSUFDRixHQUFHLEdBQUc7QUFBQSxFQUNSLE9BQU87QUFDTCwyQkFBdUI7QUFDdkIsYUFBUyxDQUFDO0FBQUEsRUFDWjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsS0FBS0EsVUFBUztBQUNyQyxTQUFPLFlBQTJCLEtBQUtBLFVBQVM7QUFBQSxJQUM5QztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxtQkFBbUIsS0FBSztBQUMvQixTQUFPLGVBQWlDLEdBQUc7QUFDN0M7QUFDQSxNQUFNLHlCQUF5QztBQUFBLEVBQTRCO0FBQUE7QUFBdUM7QUFDbEgsTUFBTSwyQkFBMkM7QUFBQSxFQUE0QjtBQUFBO0FBQTJDO0FBQ3hILE1BQU0sNEJBQTRDO0FBQUEsRUFDaEQ7QUFBQTtBQUNGO0FBQ0EsTUFBTSwyQkFBMkIsQ0FBQyxjQUFjO0FBQzlDLE1BQUksY0FBYyxPQUFPLFdBQVcsa0JBQWtCO0FBQUEsRUFDdEQsQ0FBQyxXQUFXLGNBQWMsU0FBUyxHQUFHO0FBQ3BDLDhCQUEwQixTQUFTO0FBQUEsRUFDckM7QUFDRjtBQUFBO0FBRUEsU0FBUyw0QkFBNEIsTUFBTTtBQUN6QyxTQUFPLENBQUMsY0FBYztBQUNwQjtBQUFBLE1BQ0U7QUFBQSxNQUNBLFVBQVUsV0FBVztBQUFBLE1BQ3JCLFVBQVU7QUFBQSxNQUNWLFVBQVUsU0FBUyxVQUFVLE9BQU8sTUFBTTtBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLE1BQU0sb0JBQW9DO0FBQUEsRUFBOEI7QUFBQTtBQUFvQztBQUM1RyxNQUFNLGtCQUFrQztBQUFBLEVBQThCO0FBQUE7QUFBZ0M7QUFDdEcsU0FBUyw4QkFBOEIsTUFBTTtBQUMzQyxTQUFPLENBQUMsV0FBVyxNQUFNLFNBQVM7QUFDaEMsV0FBTyxNQUFNLFVBQVUsV0FBVyxLQUFLLFVBQVUsS0FBSyxXQUFXLE1BQU0sSUFBSTtBQUFBLEVBQzdFO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQixXQUFXLE9BQU8sUUFBUTtBQUN2RDtBQUFBLElBQ0U7QUFBQSxJQUNBLFVBQVUsV0FBVztBQUFBLElBQ3JCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxJQUFJLDJCQUEyQjtBQUMvQixJQUFJLGlCQUFpQjtBQUNyQixTQUFTLDRCQUE0QixVQUFVO0FBQzdDLFFBQU0sT0FBTztBQUNiLDZCQUEyQjtBQUMzQixtQkFBaUIsWUFBWSxTQUFTLEtBQUssYUFBYTtBQUN4RCxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFlBQVksSUFBSTtBQUN2QixtQkFBaUI7QUFDbkI7QUFDQSxTQUFTLGFBQWE7QUFDcEIsbUJBQWlCO0FBQ25CO0FBQ0EsTUFBTSxjQUFjLENBQUMsUUFBUTtBQUM3QixTQUFTLFFBQVEsSUFBSSxNQUFNLDBCQUEwQixpQkFBaUI7QUFDcEUsTUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixNQUFJLEdBQUcsSUFBSTtBQUNULFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxzQkFBc0IsSUFBSSxTQUFTO0FBQ3ZDLFFBQUksb0JBQW9CLElBQUk7QUFDMUIsdUJBQWlCLEVBQUU7QUFBQSxJQUNyQjtBQUNBLFVBQU0sZUFBZSw0QkFBNEIsR0FBRztBQUNwRCxVQUFNLGdCQUFnQixXQUFXO0FBQ2pDLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxHQUFHLEdBQUcsSUFBSTtBQUFBLElBQ2xCLFVBQUU7QUFDQSxlQUFTLElBQUksV0FBVyxRQUFRLElBQUksZUFBZSxJQUFLLFlBQVc7QUFDbkUsa0NBQTRCLFlBQVk7QUFDeEMsVUFBSSxvQkFBb0IsSUFBSTtBQUMxQix5QkFBaUIsQ0FBQztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBLFFBQUksTUFBb0U7QUFDdEUsK0JBQXlCLEdBQUc7QUFBQSxJQUM5QjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0Esc0JBQW9CLEtBQUs7QUFDekIsc0JBQW9CLEtBQUs7QUFDekIsc0JBQW9CLEtBQUs7QUFDekIsU0FBTztBQUNUO0FBRUEsU0FBUyxzQkFBc0IsTUFBTTtBQUNuQyxNQUFJLG1CQUFtQixJQUFJLEdBQUc7QUFDNUIsV0FBTywrREFBK0QsSUFBSTtBQUFBLEVBQzVFO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsT0FBTyxZQUFZO0FBQ3pDLE1BQUksNkJBQTZCLE1BQU07QUFDckMsSUFBNkMsT0FBTywwREFBMEQ7QUFDOUcsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFdBQVcsMkJBQTJCLHdCQUF3QjtBQUNwRSxRQUFNLFdBQVcsTUFBTSxTQUFTLE1BQU0sT0FBTyxDQUFDO0FBQzlDLFdBQVMsSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEtBQUs7QUFDMUMsUUFBSSxDQUFDLEtBQUssT0FBTyxLQUFLLFlBQVksU0FBUyxJQUFJLFdBQVcsQ0FBQztBQUMzRCxRQUFJLEtBQUs7QUFDUCxVQUFJLFdBQVcsR0FBRyxHQUFHO0FBQ25CLGNBQU07QUFBQSxVQUNKLFNBQVM7QUFBQSxVQUNULFNBQVM7QUFBQSxRQUNYO0FBQUEsTUFDRjtBQUNBLFVBQUksSUFBSSxNQUFNO0FBQ1osaUJBQVMsS0FBSztBQUFBLE1BQ2hCO0FBQ0EsZUFBUyxLQUFLO0FBQUEsUUFDWjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVO0FBQUEsUUFDVjtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsb0JBQW9CLE9BQU8sV0FBVyxVQUFVLE1BQU07QUFDN0QsUUFBTSxXQUFXLE1BQU07QUFDdkIsUUFBTSxjQUFjLGFBQWEsVUFBVTtBQUMzQyxXQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3hDLFVBQU0sVUFBVSxTQUFTLENBQUM7QUFDMUIsUUFBSSxhQUFhO0FBQ2YsY0FBUSxXQUFXLFlBQVksQ0FBQyxFQUFFO0FBQUEsSUFDcEM7QUFDQSxRQUFJLE9BQU8sUUFBUSxJQUFJLElBQUk7QUFDM0IsUUFBSSxNQUFNO0FBQ1Isb0JBQWM7QUFDZCxpQ0FBMkIsTUFBTSxVQUFVLEdBQUc7QUFBQSxRQUM1QyxNQUFNO0FBQUEsUUFDTjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQ0Qsb0JBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsUUFBUSxLQUFLLE9BQU87QUFDM0IsTUFBSSxNQUEyQztBQUM3QyxRQUFJLENBQUMsbUJBQW1CLGdCQUFnQixXQUFXO0FBQ2pELGFBQU8sNENBQTRDO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxpQkFBaUI7QUFDbkIsUUFBSSxXQUFXLGdCQUFnQjtBQUMvQixVQUFNLGlCQUFpQixnQkFBZ0IsVUFBVSxnQkFBZ0IsT0FBTztBQUN4RSxRQUFJLG1CQUFtQixVQUFVO0FBQy9CLGlCQUFXLGdCQUFnQixXQUFXLE9BQU8sT0FBTyxjQUFjO0FBQUEsSUFDcEU7QUFDQSxhQUFTLEdBQUcsSUFBSTtBQUFBLEVBQ2xCO0FBQ0Y7QUFDQSxTQUFTLE9BQU8sS0FBSyxjQUFjLHdCQUF3QixPQUFPO0FBQ2hFLFFBQU0sV0FBVyxtQkFBbUI7QUFDcEMsTUFBSSxZQUFZLFlBQVk7QUFDMUIsUUFBSSxXQUFXLGFBQWEsV0FBVyxTQUFTLFdBQVcsV0FBVyxTQUFTLFVBQVUsUUFBUSxTQUFTLEtBQUssU0FBUyxNQUFNLGNBQWMsU0FBUyxNQUFNLFdBQVcsV0FBVyxTQUFTLE9BQU8sV0FBVztBQUM1TSxRQUFJLFlBQVksT0FBTyxVQUFVO0FBQy9CLGFBQU8sU0FBUyxHQUFHO0FBQUEsSUFDckIsV0FBVyxVQUFVLFNBQVMsR0FBRztBQUMvQixhQUFPLHlCQUF5QixXQUFXLFlBQVksSUFBSSxhQUFhLEtBQUssWUFBWSxTQUFTLEtBQUssSUFBSTtBQUFBLElBQzdHLFdBQVcsTUFBMkM7QUFDcEQsYUFBTyxjQUFjLE9BQU8sR0FBRyxDQUFDLGNBQWM7QUFBQSxJQUNoRDtBQUFBLEVBQ0YsV0FBVyxNQUEyQztBQUNwRCxXQUFPLG9FQUFvRTtBQUFBLEVBQzdFO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQjtBQUM3QixTQUFPLENBQUMsRUFBRSxtQkFBbUIsS0FBSztBQUNwQztBQUVBLE1BQU0sZ0JBQWdDLHVCQUFPLElBQUksT0FBTztBQUN4RCxNQUFNLGdCQUFnQixNQUFNO0FBQzFCO0FBQ0UsVUFBTSxNQUFNLE9BQU8sYUFBYTtBQUNoQyxRQUFJLENBQUMsS0FBSztBQUNSLE1BQTZDO0FBQUEsUUFDM0M7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLFlBQVlDLFNBQVEsU0FBUztBQUNwQyxTQUFPLFFBQVFBLFNBQVEsTUFBTSxPQUFPO0FBQ3RDO0FBQ0EsU0FBUyxnQkFBZ0JBLFNBQVEsU0FBUztBQUN4QyxTQUFPO0FBQUEsSUFDTEE7QUFBQSxJQUNBO0FBQUEsSUFDQSxPQUE0QyxPQUFPLENBQUMsR0FBRyxTQUFTLEVBQUUsT0FBTyxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sT0FBTztBQUFBLEVBQ3ZHO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQkEsU0FBUSxTQUFTO0FBQ3hDLFNBQU87QUFBQSxJQUNMQTtBQUFBLElBQ0E7QUFBQSxJQUNBLE9BQTRDLE9BQU8sQ0FBQyxHQUFHLFNBQVMsRUFBRSxPQUFPLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxPQUFPO0FBQUEsRUFDdkc7QUFDRjtBQUNBLFNBQVMsTUFBTSxRQUFRLElBQUksU0FBUztBQUNsQyxNQUFpRCxDQUFDLFdBQVcsRUFBRSxHQUFHO0FBQ2hFO0FBQUEsTUFDRTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTyxRQUFRLFFBQVEsSUFBSSxPQUFPO0FBQ3BDO0FBQ0EsU0FBUyxRQUFRLFFBQVEsSUFBSSxVQUFVLFdBQVc7QUFDaEQsUUFBTSxFQUFFLFdBQVcsTUFBTSxPQUFPLEtBQUssSUFBSTtBQUN6QyxNQUFpRCxDQUFDLElBQUk7QUFDcEQsUUFBSSxjQUFjLFFBQVE7QUFDeEI7QUFBQSxRQUNFO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsUUFBUTtBQUNuQjtBQUFBLFFBQ0U7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksU0FBUyxRQUFRO0FBQ25CO0FBQUEsUUFDRTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0sbUJBQW1CLE9BQU8sQ0FBQyxHQUFHLE9BQU87QUFDM0MsTUFBSSxLQUEyQyxrQkFBaUIsU0FBUztBQUN6RSxRQUFNLGtCQUFrQixNQUFNLGFBQWEsQ0FBQyxNQUFNLFVBQVU7QUFDNUQsTUFBSTtBQUNKLE1BQUksdUJBQXVCO0FBQ3pCLFFBQUksVUFBVSxRQUFRO0FBQ3BCLFlBQU0sTUFBTSxjQUFjO0FBQzFCLG1CQUFhLElBQUkscUJBQXFCLElBQUksbUJBQW1CLENBQUM7QUFBQSxJQUNoRSxXQUFXLENBQUMsaUJBQWlCO0FBQzNCLFlBQU0sa0JBQWtCLE1BQU07QUFBQSxNQUM5QjtBQUNBLHNCQUFnQixPQUFPO0FBQ3ZCLHNCQUFnQixTQUFTO0FBQ3pCLHNCQUFnQixRQUFRO0FBQ3hCLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFFBQU0sV0FBVztBQUNqQixtQkFBaUIsT0FBTyxDQUFDLElBQUksTUFBTSxTQUFTLDJCQUEyQixJQUFJLFVBQVUsTUFBTSxJQUFJO0FBQy9GLE1BQUksUUFBUTtBQUNaLE1BQUksVUFBVSxRQUFRO0FBQ3BCLHFCQUFpQixZQUFZLENBQUMsUUFBUTtBQUNwQyw0QkFBc0IsS0FBSyxZQUFZLFNBQVMsUUFBUTtBQUFBLElBQzFEO0FBQUEsRUFDRixXQUFXLFVBQVUsUUFBUTtBQUMzQixZQUFRO0FBQ1IscUJBQWlCLFlBQVksQ0FBQyxLQUFLLGVBQWU7QUFDaEQsVUFBSSxZQUFZO0FBQ2QsWUFBSTtBQUFBLE1BQ04sT0FBTztBQUNMLGlCQUFTLEdBQUc7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxtQkFBaUIsYUFBYSxDQUFDLFFBQVE7QUFDckMsUUFBSSxJQUFJO0FBQ04sVUFBSSxTQUFTO0FBQUEsSUFDZjtBQUNBLFFBQUksT0FBTztBQUNULFVBQUksU0FBUztBQUNiLFVBQUksVUFBVTtBQUNaLFlBQUksS0FBSyxTQUFTO0FBQ2xCLFlBQUksSUFBSTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0sY0FBYyxRQUFRLFFBQVEsSUFBSSxnQkFBZ0I7QUFDeEQsTUFBSSx1QkFBdUI7QUFDekIsUUFBSSxZQUFZO0FBQ2QsaUJBQVcsS0FBSyxXQUFXO0FBQUEsSUFDN0IsV0FBVyxpQkFBaUI7QUFDMUIsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxRQUFRLE9BQU8sU0FBUztBQUM3QyxRQUFNLGFBQWEsS0FBSztBQUN4QixRQUFNLFNBQVMsU0FBUyxNQUFNLElBQUksT0FBTyxTQUFTLEdBQUcsSUFBSSxpQkFBaUIsWUFBWSxNQUFNLElBQUksTUFBTSxXQUFXLE1BQU0sSUFBSSxPQUFPLEtBQUssWUFBWSxVQUFVO0FBQzdKLE1BQUk7QUFDSixNQUFJLFdBQVcsS0FBSyxHQUFHO0FBQ3JCLFNBQUs7QUFBQSxFQUNQLE9BQU87QUFDTCxTQUFLLE1BQU07QUFDWCxjQUFVO0FBQUEsRUFDWjtBQUNBLFFBQU0sUUFBUSxtQkFBbUIsSUFBSTtBQUNyQyxRQUFNLE1BQU0sUUFBUSxRQUFRLEdBQUcsS0FBSyxVQUFVLEdBQUcsT0FBTztBQUN4RCxRQUFNO0FBQ04sU0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsS0FBSyxNQUFNO0FBQ25DLFFBQU0sV0FBVyxLQUFLLE1BQU0sR0FBRztBQUMvQixTQUFPLE1BQU07QUFDWCxRQUFJLE1BQU07QUFDVixhQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsVUFBVSxLQUFLLEtBQUs7QUFDL0MsWUFBTSxJQUFJLFNBQVMsQ0FBQyxDQUFDO0FBQUEsSUFDdkI7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsTUFBTSxnQkFBZ0Msb0JBQUksUUFBUTtBQUNsRCxNQUFNLGlCQUFpQyx1QkFBTyxNQUFNO0FBQ3BELE1BQU0sYUFBYSxDQUFDLFNBQVMsS0FBSztBQUNsQyxNQUFNLHFCQUFxQixDQUFDLFVBQVUsVUFBVSxNQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JGLE1BQU0scUJBQXFCLENBQUMsVUFBVSxVQUFVLE1BQU0sU0FBUyxNQUFNLFVBQVU7QUFDL0UsTUFBTSxjQUFjLENBQUMsV0FBVyxPQUFPLGVBQWUsZUFBZSxrQkFBa0I7QUFDdkYsTUFBTSxpQkFBaUIsQ0FBQyxXQUFXLE9BQU8sa0JBQWtCLGNBQWMsa0JBQWtCO0FBQzVGLE1BQU0sZ0JBQWdCLENBQUMsT0FBTyxXQUFXO0FBQ3ZDLFFBQU0saUJBQWlCLFNBQVMsTUFBTTtBQUN0QyxNQUFJLFNBQVMsY0FBYyxHQUFHO0FBQzVCLFFBQUksQ0FBQyxRQUFRO0FBQ1gsTUFBNkM7QUFBQSxRQUMzQztBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVCxPQUFPO0FBQ0wsWUFBTSxTQUFTLE9BQU8sY0FBYztBQUNwQyxVQUFpRCxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsS0FBSyxHQUFHO0FBQ3RGO0FBQUEsVUFDRSxtREFBbUQsY0FBYztBQUFBLFFBQ25FO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRixPQUFPO0FBQ0wsUUFBaUQsQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsS0FBSyxHQUFHO0FBQzlGLGFBQU8sNEJBQTRCLGNBQWMsRUFBRTtBQUFBLElBQ3JEO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLE1BQU0sZUFBZTtBQUFBLEVBQ25CLE1BQU07QUFBQSxFQUNOLGNBQWM7QUFBQSxFQUNkLFFBQVEsSUFBSSxJQUFJLFdBQVcsUUFBUSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxXQUFXLFdBQVc7QUFDakgsVUFBTTtBQUFBLE1BQ0osSUFBSTtBQUFBLE1BQ0osSUFBSTtBQUFBLE1BQ0osS0FBSztBQUFBLE1BQ0wsR0FBRyxFQUFFLFFBQVEsZUFBZSxZQUFZLGVBQWUsV0FBVztBQUFBLElBQ3BFLElBQUk7QUFDSixVQUFNLFdBQVcsbUJBQW1CLEdBQUcsS0FBSztBQUM1QyxRQUFJLEVBQUUsZ0JBQWdCLElBQUk7QUFDMUIsUUFBaUQsZUFBZTtBQUM5RCxrQkFBWTtBQUNaLHdCQUFrQjtBQUFBLElBQ3BCO0FBQ0EsVUFBTSxRQUFRLENBQUMsT0FBTyxZQUFZLFlBQVk7QUFDNUMsVUFBSSxNQUFNLFlBQVksSUFBSTtBQUN4QjtBQUFBLFVBQ0UsTUFBTTtBQUFBLFVBQ047QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixDQUFDLFFBQVEsT0FBTztBQUNwQyxZQUFNLFlBQVksbUJBQW1CLE1BQU0sS0FBSztBQUNoRCxZQUFNLFNBQVMsTUFBTSxTQUFTLGNBQWMsTUFBTSxPQUFPLGFBQWE7QUFDdEUsWUFBTSxlQUFlLGNBQWMsUUFBUSxPQUFPLFlBQVksTUFBTTtBQUNwRSxVQUFJLFFBQVE7QUFDVixZQUFJLGNBQWMsU0FBUyxZQUFZLE1BQU0sR0FBRztBQUM5QyxzQkFBWTtBQUFBLFFBQ2QsV0FBVyxjQUFjLFlBQVksZUFBZSxNQUFNLEdBQUc7QUFDM0Qsc0JBQVk7QUFBQSxRQUNkO0FBQ0EsWUFBSSxtQkFBbUIsZ0JBQWdCLE1BQU07QUFDM0MsV0FBQyxnQkFBZ0IsR0FBRyxxQkFBcUIsZ0JBQWdCLEdBQUcsbUJBQW1DLG9CQUFJLElBQUksSUFBSSxJQUFJLE1BQU07QUFBQSxRQUN2SDtBQUNBLFlBQUksQ0FBQyxXQUFXO0FBQ2QsZ0JBQU0sT0FBTyxRQUFRLFlBQVk7QUFDakMsd0JBQWMsT0FBTyxLQUFLO0FBQUEsUUFDNUI7QUFBQSxNQUNGLFdBQXdELENBQUMsV0FBVztBQUNsRSxlQUFPLHFDQUFxQyxRQUFRLElBQUksT0FBTyxNQUFNLEdBQUc7QUFBQSxNQUMxRTtBQUFBLElBQ0Y7QUFDQSxVQUFNLG9CQUFvQixDQUFDLFVBQVU7QUFDbkMsWUFBTSxXQUFXLE1BQU07QUFDckIsWUFBSSxjQUFjLElBQUksS0FBSyxNQUFNLFNBQVU7QUFDM0Msc0JBQWMsT0FBTyxLQUFLO0FBQzFCLFlBQUksbUJBQW1CLE1BQU0sS0FBSyxHQUFHO0FBQ25DLGdCQUFNLGlCQUFpQixXQUFXLE1BQU0sRUFBRSxLQUFLO0FBQy9DLGdCQUFNLE9BQU8sZ0JBQWdCLE1BQU0sTUFBTTtBQUN6Qyx3QkFBYyxPQUFPLElBQUk7QUFBQSxRQUMzQjtBQUNBLHNCQUFjLEtBQUs7QUFBQSxNQUNyQjtBQUNBLG9CQUFjLElBQUksT0FBTyxRQUFRO0FBQ2pDLDRCQUFzQixVQUFVLGNBQWM7QUFBQSxJQUNoRDtBQUNBLFFBQUksTUFBTSxNQUFNO0FBQ2QsWUFBTSxjQUFjLEdBQUcsS0FBSyxPQUE0QyxjQUFjLGdCQUFnQixJQUFJLFdBQVcsRUFBRTtBQUN2SCxZQUFNLGFBQWEsR0FBRyxTQUFTLE9BQTRDLGNBQWMsY0FBYyxJQUFJLFdBQVcsRUFBRTtBQUN4SCxhQUFPLGFBQWEsV0FBVyxNQUFNO0FBQ3JDLGFBQU8sWUFBWSxXQUFXLE1BQU07QUFDcEMsVUFBSSxtQkFBbUIsR0FBRyxLQUFLLEtBQUssa0JBQWtCLGVBQWUsZUFBZTtBQUNsRiwwQkFBa0IsRUFBRTtBQUNwQjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFVBQVU7QUFDWixjQUFNLElBQUksV0FBVyxVQUFVO0FBQy9CLHNCQUFjLElBQUksSUFBSTtBQUFBLE1BQ3hCO0FBQ0Esb0JBQWM7QUFBQSxJQUNoQixPQUFPO0FBQ0wsU0FBRyxLQUFLLEdBQUc7QUFDWCxZQUFNLGFBQWEsR0FBRyxTQUFTLEdBQUc7QUFDbEMsWUFBTSxlQUFlLGNBQWMsSUFBSSxFQUFFO0FBQ3pDLFVBQUksY0FBYztBQUNoQixxQkFBYSxTQUFTO0FBQ3RCLHNCQUFjLE9BQU8sRUFBRTtBQUN2QiwwQkFBa0IsRUFBRTtBQUNwQjtBQUFBLE1BQ0Y7QUFDQSxTQUFHLGNBQWMsR0FBRztBQUNwQixZQUFNLFNBQVMsR0FBRyxTQUFTLEdBQUc7QUFDOUIsWUFBTSxlQUFlLEdBQUcsZUFBZSxHQUFHO0FBQzFDLFlBQU0sY0FBYyxtQkFBbUIsR0FBRyxLQUFLO0FBQy9DLFlBQU0sbUJBQW1CLGNBQWMsWUFBWTtBQUNuRCxZQUFNLGdCQUFnQixjQUFjLGFBQWE7QUFDakQsVUFBSSxjQUFjLFNBQVMsWUFBWSxNQUFNLEdBQUc7QUFDOUMsb0JBQVk7QUFBQSxNQUNkLFdBQVcsY0FBYyxZQUFZLGVBQWUsTUFBTSxHQUFHO0FBQzNELG9CQUFZO0FBQUEsTUFDZDtBQUNBLFVBQUksaUJBQWlCO0FBQ25CO0FBQUEsVUFDRSxHQUFHO0FBQUEsVUFDSDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLCtCQUF1QixJQUFJLElBQUksS0FBMEM7QUFBQSxNQUMzRSxXQUFXLENBQUMsV0FBVztBQUNyQjtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxVQUFVO0FBQ1osWUFBSSxDQUFDLGFBQWE7QUFDaEI7QUFBQSxZQUNFO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLE9BQU87QUFDTCxjQUFJLEdBQUcsU0FBUyxHQUFHLFNBQVMsR0FBRyxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUk7QUFDdkQsZUFBRyxNQUFNLEtBQUssR0FBRyxNQUFNO0FBQUEsVUFDekI7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsYUFBSyxHQUFHLFNBQVMsR0FBRyxNQUFNLFNBQVMsR0FBRyxTQUFTLEdBQUcsTUFBTSxLQUFLO0FBQzNELGdCQUFNLGFBQWEsY0FBYyxHQUFHLE9BQU8sYUFBYTtBQUN4RCxjQUFJLFlBQVk7QUFDZCxlQUFHLFNBQVM7QUFDWjtBQUFBLGNBQ0U7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUFBLFVBQ0YsV0FBVyxNQUEyQztBQUNwRDtBQUFBLGNBQ0U7QUFBQSxjQUNBO0FBQUEsY0FDQSxJQUFJLE9BQU8sTUFBTTtBQUFBLFlBQ25CO0FBQUEsVUFDRjtBQUFBLFFBQ0YsV0FBVyxhQUFhO0FBQ3RCO0FBQUEsWUFDRTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxvQkFBYyxJQUFJLFFBQVE7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE9BQU8sT0FBTyxpQkFBaUIsZ0JBQWdCLEVBQUUsSUFBSSxTQUFTLEdBQUcsRUFBRSxRQUFRLFdBQVcsRUFBRSxHQUFHLFVBQVU7QUFDbkcsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLElBQUk7QUFDSixVQUFNLFdBQVcsbUJBQW1CLEtBQUs7QUFDekMsVUFBTSxlQUFlLFlBQVksQ0FBQztBQUNsQyxVQUFNLGVBQWUsY0FBYyxJQUFJLEtBQUs7QUFDNUMsUUFBSSxjQUFjO0FBQ2hCLG1CQUFhLFNBQVM7QUFDdEIsb0JBQWMsT0FBTyxLQUFLO0FBQUEsSUFDNUI7QUFDQSxRQUFJLFFBQVE7QUFDVixpQkFBVyxXQUFXO0FBQ3RCLGlCQUFXLFlBQVk7QUFBQSxJQUN6QjtBQUNBLGdCQUFZLFdBQVcsTUFBTTtBQUM3QixRQUFJLENBQUMsaUJBQWlCLFlBQVksV0FBVyxZQUFZLElBQUk7QUFDM0QsZUFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUN4QyxjQUFNLFFBQVEsU0FBUyxDQUFDO0FBQ3hCO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxDQUFDLE1BQU07QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFNO0FBQUEsRUFDTixTQUFTO0FBQ1g7QUFDQSxTQUFTLGFBQWEsT0FBTyxXQUFXLGNBQWMsRUFBRSxHQUFHLEVBQUUsT0FBTyxHQUFHLEdBQUcsS0FBSyxHQUFHLFdBQVcsR0FBRztBQUM5RixNQUFJLGFBQWEsR0FBRztBQUNsQixXQUFPLE1BQU0sY0FBYyxXQUFXLFlBQVk7QUFBQSxFQUNwRDtBQUNBLFFBQU0sRUFBRSxJQUFJLFFBQVEsV0FBVyxVQUFVLE1BQU0sSUFBSTtBQUNuRCxRQUFNLFlBQVksYUFBYTtBQUMvQixNQUFJLFdBQVc7QUFDYixXQUFPLElBQUksV0FBVyxZQUFZO0FBQUEsRUFDcEM7QUFDQSxNQUFJLENBQUMsY0FBYyxJQUFJLEtBQUssTUFBTSxDQUFDLGFBQWEsbUJBQW1CLEtBQUssSUFBSTtBQUMxRSxRQUFJLFlBQVksSUFBSTtBQUNsQixlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3hDO0FBQUEsVUFDRSxTQUFTLENBQUM7QUFBQSxVQUNWO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxXQUFXO0FBQ2IsV0FBTyxRQUFRLFdBQVcsWUFBWTtBQUFBLEVBQ3hDO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixNQUFNLE9BQU8saUJBQWlCLGdCQUFnQixjQUFjLFdBQVc7QUFBQSxFQUM5RixHQUFHLEVBQUUsYUFBYSxZQUFZLGVBQWUsUUFBUSxXQUFXO0FBQ2xFLEdBQUcsaUJBQWlCO0FBQ2xCLFdBQVMsY0FBYyxTQUFTLFlBQVk7QUFDMUMsUUFBSSxlQUFlO0FBQ25CLFdBQU8sY0FBYztBQUNuQixVQUFJLGdCQUFnQixhQUFhLGFBQWEsR0FBRztBQUMvQyxZQUFJLGFBQWEsU0FBUyx5QkFBeUI7QUFDakQsZ0JBQU0sY0FBYztBQUFBLFFBQ3RCLFdBQVcsYUFBYSxTQUFTLG1CQUFtQjtBQUNsRCxnQkFBTSxlQUFlO0FBQ3JCLGtCQUFRLE9BQU8sTUFBTSxnQkFBZ0IsWUFBWSxNQUFNLFlBQVk7QUFDbkU7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLHFCQUFlLFlBQVksWUFBWTtBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUNBLFdBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUM5QyxXQUFPLFNBQVM7QUFBQSxNQUNkLFlBQVksS0FBSztBQUFBLE1BQ2pCO0FBQUEsTUFDQSxXQUFXLEtBQUs7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLE1BQU0sU0FBUztBQUFBLElBQzVCLE1BQU07QUFBQSxJQUNOO0FBQUEsRUFDRjtBQUNBLFFBQU0sV0FBVyxtQkFBbUIsTUFBTSxLQUFLO0FBQy9DLE1BQUksUUFBUTtBQUNWLFVBQU0sYUFBYSxPQUFPLFFBQVEsT0FBTztBQUN6QyxRQUFJLE1BQU0sWUFBWSxJQUFJO0FBQ3hCLFVBQUksVUFBVTtBQUNaLGdDQUF3QixNQUFNLEtBQUs7QUFDbkMsc0JBQWMsUUFBUSxVQUFVO0FBQ2hDLFlBQUksQ0FBQyxNQUFNLGNBQWM7QUFDdkI7QUFBQSxZQUNFO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUE7QUFBQTtBQUFBLFlBR0EsV0FBVyxJQUFJLE1BQU0sU0FBUyxPQUFPO0FBQUEsVUFDdkM7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxTQUFTLFlBQVksSUFBSTtBQUMvQixzQkFBYyxRQUFRLFVBQVU7QUFDaEMsWUFBSSxDQUFDLE1BQU0sY0FBYztBQUN2Qix3QkFBYyxRQUFRLE9BQU8sWUFBWSxNQUFNO0FBQUEsUUFDakQ7QUFDQTtBQUFBLFVBQ0UsY0FBYyxZQUFZLFVBQVU7QUFBQSxVQUNwQztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0Esa0JBQWMsT0FBTyxRQUFRO0FBQUEsRUFDL0IsV0FBVyxVQUFVO0FBQ25CLFFBQUksTUFBTSxZQUFZLElBQUk7QUFDeEIsOEJBQXdCLE1BQU0sS0FBSztBQUNuQyxZQUFNLGNBQWM7QUFDcEIsWUFBTSxlQUFlLFlBQVksSUFBSTtBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUNBLFNBQU8sTUFBTSxVQUFVLFlBQVksTUFBTSxNQUFNO0FBQ2pEO0FBQ0EsTUFBTSxXQUFXO0FBQ2pCLFNBQVMsY0FBYyxPQUFPLFlBQVk7QUFDeEMsUUFBTSxNQUFNLE1BQU07QUFDbEIsTUFBSSxPQUFPLElBQUksSUFBSTtBQUNqQixRQUFJLE1BQU07QUFDVixRQUFJLFlBQVk7QUFDZCxhQUFPLE1BQU07QUFDYixlQUFTLE1BQU07QUFBQSxJQUNqQixPQUFPO0FBQ0wsYUFBTyxNQUFNO0FBQ2IsZUFBUyxNQUFNO0FBQUEsSUFDakI7QUFDQSxXQUFPLFFBQVEsU0FBUyxRQUFRO0FBQzlCLFVBQUksS0FBSyxhQUFhLEVBQUcsTUFBSyxhQUFhLGdCQUFnQixJQUFJLEdBQUc7QUFDbEUsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUNBLFFBQUksR0FBRztBQUFBLEVBQ1Q7QUFDRjtBQUNBLFNBQVMsY0FBYyxRQUFRLE9BQU8sWUFBWSxRQUFRLFNBQVMsTUFBTTtBQUN2RSxRQUFNLGNBQWMsTUFBTSxjQUFjLFdBQVcsRUFBRTtBQUNyRCxRQUFNLGVBQWUsTUFBTSxlQUFlLFdBQVcsRUFBRTtBQUN2RCxjQUFZLGNBQWMsSUFBSTtBQUM5QixNQUFJLFFBQVE7QUFDVixXQUFPLGFBQWEsUUFBUSxNQUFNO0FBQ2xDLFdBQU8sY0FBYyxRQUFRLE1BQU07QUFBQSxFQUNyQztBQUNBLFNBQU87QUFDVDtBQUVBLE1BQU0sYUFBNkIsdUJBQU8sVUFBVTtBQUNwRCxNQUFNLGFBQTZCLHVCQUFPLFVBQVU7QUFDcEQsU0FBUyxxQkFBcUI7QUFDNUIsUUFBTSxRQUFRO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxXQUFXO0FBQUEsSUFDWCxjQUFjO0FBQUEsSUFDZCxlQUErQixvQkFBSSxJQUFJO0FBQUEsRUFDekM7QUFDQSxZQUFVLE1BQU07QUFDZCxVQUFNLFlBQVk7QUFBQSxFQUNwQixDQUFDO0FBQ0Qsa0JBQWdCLE1BQU07QUFDcEIsVUFBTSxlQUFlO0FBQUEsRUFDdkIsQ0FBQztBQUNELFNBQU87QUFDVDtBQUNBLE1BQU0sMEJBQTBCLENBQUMsVUFBVSxLQUFLO0FBQ2hELE1BQU0sZ0NBQWdDO0FBQUEsRUFDcEMsTUFBTTtBQUFBLEVBQ04sUUFBUTtBQUFBLEVBQ1IsV0FBVztBQUFBO0FBQUEsRUFFWCxlQUFlO0FBQUEsRUFDZixTQUFTO0FBQUEsRUFDVCxjQUFjO0FBQUEsRUFDZCxrQkFBa0I7QUFBQTtBQUFBLEVBRWxCLGVBQWU7QUFBQSxFQUNmLFNBQVM7QUFBQSxFQUNULGNBQWM7QUFBQSxFQUNkLGtCQUFrQjtBQUFBO0FBQUEsRUFFbEIsZ0JBQWdCO0FBQUEsRUFDaEIsVUFBVTtBQUFBLEVBQ1YsZUFBZTtBQUFBLEVBQ2YsbUJBQW1CO0FBQ3JCO0FBQ0EsTUFBTSxzQkFBc0IsQ0FBQyxhQUFhO0FBQ3hDLFFBQU0sVUFBVSxTQUFTO0FBQ3pCLFNBQU8sUUFBUSxZQUFZLG9CQUFvQixRQUFRLFNBQVMsSUFBSTtBQUN0RTtBQUNBLE1BQU0scUJBQXFCO0FBQUEsRUFDekIsTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsTUFBTSxPQUFPLEVBQUUsTUFBTSxHQUFHO0FBQ3RCLFVBQU0sV0FBVyxtQkFBbUI7QUFDcEMsVUFBTSxRQUFRLG1CQUFtQjtBQUNqQyxXQUFPLE1BQU07QUFDWCxZQUFNLFdBQVcsTUFBTSxXQUFXLHlCQUF5QixNQUFNLFFBQVEsR0FBRyxJQUFJO0FBQ2hGLFlBQU0sUUFBUSxZQUFZLFNBQVMsU0FBUyxvQkFBb0IsUUFBUTtBQUFBO0FBQUE7QUFBQSxRQUd0RSxTQUFTLFVBQVUsbUJBQW1CLElBQUk7QUFBQTtBQUU1QyxVQUFJLENBQUMsT0FBTztBQUNWO0FBQUEsTUFDRjtBQUNBLFlBQU0sV0FBVyxNQUFNLEtBQUs7QUFDNUIsWUFBTSxFQUFFLEtBQUssSUFBSTtBQUNqQixVQUFpRCxRQUFRLFNBQVMsWUFBWSxTQUFTLFlBQVksU0FBUyxXQUFXO0FBQ3JILGVBQU8sOEJBQThCLElBQUksRUFBRTtBQUFBLE1BQzdDO0FBQ0EsVUFBSSxNQUFNLFdBQVc7QUFDbkIsZUFBTyxpQkFBaUIsS0FBSztBQUFBLE1BQy9CO0FBQ0EsWUFBTSxhQUFhLGdCQUFnQixLQUFLO0FBQ3hDLFVBQUksQ0FBQyxZQUFZO0FBQ2YsZUFBTyxpQkFBaUIsS0FBSztBQUFBLE1BQy9CO0FBQ0EsVUFBSSxhQUFhO0FBQUEsUUFDZjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBO0FBQUEsUUFFQSxDQUFDLFVBQVUsYUFBYTtBQUFBLE1BQzFCO0FBQ0EsVUFBSSxXQUFXLFNBQVMsU0FBUztBQUMvQiwyQkFBbUIsWUFBWSxVQUFVO0FBQUEsTUFDM0M7QUFDQSxVQUFJLGdCQUFnQixTQUFTLFdBQVcsZ0JBQWdCLFNBQVMsT0FBTztBQUN4RSxVQUFJLGlCQUFpQixjQUFjLFNBQVMsV0FBVyxDQUFDLGdCQUFnQixlQUFlLFVBQVUsS0FBSyxvQkFBb0IsUUFBUSxFQUFFLFNBQVMsU0FBUztBQUNwSixZQUFJLGVBQWU7QUFBQSxVQUNqQjtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSwyQkFBbUIsZUFBZSxZQUFZO0FBQzlDLFlBQUksU0FBUyxZQUFZLFdBQVcsU0FBUyxTQUFTO0FBQ3BELGdCQUFNLFlBQVk7QUFDbEIsdUJBQWEsYUFBYSxNQUFNO0FBQzlCLGtCQUFNLFlBQVk7QUFDbEIsZ0JBQUksRUFBRSxTQUFTLElBQUksUUFBUSxJQUFJO0FBQzdCLHVCQUFTLE9BQU87QUFBQSxZQUNsQjtBQUNBLG1CQUFPLGFBQWE7QUFDcEIsNEJBQWdCO0FBQUEsVUFDbEI7QUFDQSxpQkFBTyxpQkFBaUIsS0FBSztBQUFBLFFBQy9CLFdBQVcsU0FBUyxZQUFZLFdBQVcsU0FBUyxTQUFTO0FBQzNELHVCQUFhLGFBQWEsQ0FBQyxJQUFJLGFBQWEsaUJBQWlCO0FBQzNELGtCQUFNLHFCQUFxQjtBQUFBLGNBQ3pCO0FBQUEsY0FDQTtBQUFBLFlBQ0Y7QUFDQSwrQkFBbUIsT0FBTyxjQUFjLEdBQUcsQ0FBQyxJQUFJO0FBQ2hELGVBQUcsVUFBVSxJQUFJLE1BQU07QUFDckIsMEJBQVk7QUFDWixpQkFBRyxVQUFVLElBQUk7QUFDakIscUJBQU8sV0FBVztBQUNsQiw4QkFBZ0I7QUFBQSxZQUNsQjtBQUNBLHVCQUFXLGVBQWUsTUFBTTtBQUM5QiwyQkFBYTtBQUNiLHFCQUFPLFdBQVc7QUFDbEIsOEJBQWdCO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQUEsUUFDRixPQUFPO0FBQ0wsMEJBQWdCO0FBQUEsUUFDbEI7QUFBQSxNQUNGLFdBQVcsZUFBZTtBQUN4Qix3QkFBZ0I7QUFBQSxNQUNsQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxvQkFBb0IsVUFBVTtBQUNyQyxNQUFJLFFBQVEsU0FBUyxDQUFDO0FBQ3RCLE1BQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsUUFBSSxXQUFXO0FBQ2YsZUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBSSxFQUFFLFNBQVMsU0FBUztBQUN0QixZQUFpRCxVQUFVO0FBQ3pEO0FBQUEsWUFDRTtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFDQSxnQkFBUTtBQUNSLG1CQUFXO0FBQ1gsWUFBSSxNQUE0QztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxNQUFNLGlCQUFpQjtBQUN2QixTQUFTLHVCQUF1QixPQUFPLE9BQU87QUFDNUMsUUFBTSxFQUFFLGNBQWMsSUFBSTtBQUMxQixNQUFJLHFCQUFxQixjQUFjLElBQUksTUFBTSxJQUFJO0FBQ3JELE1BQUksQ0FBQyxvQkFBb0I7QUFDdkIseUJBQXFDLHVCQUFPLE9BQU8sSUFBSTtBQUN2RCxrQkFBYyxJQUFJLE1BQU0sTUFBTSxrQkFBa0I7QUFBQSxFQUNsRDtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsdUJBQXVCLE9BQU8sT0FBTyxPQUFPLFVBQVUsV0FBVztBQUN4RSxRQUFNO0FBQUEsSUFDSjtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGLElBQUk7QUFDSixRQUFNLE1BQU0sT0FBTyxNQUFNLEdBQUc7QUFDNUIsUUFBTSxxQkFBcUIsdUJBQXVCLE9BQU8sS0FBSztBQUM5RCxRQUFNQyxZQUFXLENBQUMsTUFBTSxTQUFTO0FBQy9CLFlBQVE7QUFBQSxNQUNOO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGdCQUFnQixDQUFDLE1BQU0sU0FBUztBQUNwQyxVQUFNLE9BQU8sS0FBSyxDQUFDO0FBQ25CLElBQUFBLFVBQVMsTUFBTSxJQUFJO0FBQ25CLFFBQUksUUFBUSxJQUFJLEdBQUc7QUFDakIsVUFBSSxLQUFLLE1BQU0sQ0FBQyxVQUFVLE1BQU0sVUFBVSxDQUFDLEVBQUcsTUFBSztBQUFBLElBQ3JELFdBQVcsS0FBSyxVQUFVLEdBQUc7QUFDM0IsV0FBSztBQUFBLElBQ1A7QUFBQSxFQUNGO0FBQ0EsUUFBTSxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVksSUFBSTtBQUNkLFVBQUksT0FBTztBQUNYLFVBQUksQ0FBQyxNQUFNLFdBQVc7QUFDcEIsWUFBSSxRQUFRO0FBQ1YsaUJBQU8sa0JBQWtCO0FBQUEsUUFDM0IsT0FBTztBQUNMO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEdBQUcsVUFBVSxHQUFHO0FBQ2xCLFdBQUcsVUFBVTtBQUFBLFVBQ1g7QUFBQTtBQUFBLFFBRUY7QUFBQSxNQUNGO0FBQ0EsWUFBTSxlQUFlLG1CQUFtQixHQUFHO0FBQzNDLFVBQUksZ0JBQWdCLGdCQUFnQixPQUFPLFlBQVksS0FBSyxhQUFhLEdBQUcsVUFBVSxHQUFHO0FBQ3ZGLHFCQUFhLEdBQUcsVUFBVSxFQUFFO0FBQUEsTUFDOUI7QUFDQSxNQUFBQSxVQUFTLE1BQU0sQ0FBQyxFQUFFLENBQUM7QUFBQSxJQUNyQjtBQUFBLElBQ0EsTUFBTSxJQUFJO0FBQ1IsVUFBSSxDQUFDLGlCQUFpQixtQkFBbUIsR0FBRyxNQUFNLE1BQU87QUFDekQsVUFBSSxPQUFPO0FBQ1gsVUFBSSxZQUFZO0FBQ2hCLFVBQUksYUFBYTtBQUNqQixVQUFJLENBQUMsTUFBTSxXQUFXO0FBQ3BCLFlBQUksUUFBUTtBQUNWLGlCQUFPLFlBQVk7QUFDbkIsc0JBQVksaUJBQWlCO0FBQzdCLHVCQUFhLHFCQUFxQjtBQUFBLFFBQ3BDLE9BQU87QUFDTDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxTQUFTO0FBQ2IsU0FBRyxVQUFVLElBQUksQ0FBQyxjQUFjO0FBQzlCLFlBQUksT0FBUTtBQUNaLGlCQUFTO0FBQ1QsWUFBSSxXQUFXO0FBQ2IsVUFBQUEsVUFBUyxZQUFZLENBQUMsRUFBRSxDQUFDO0FBQUEsUUFDM0IsT0FBTztBQUNMLFVBQUFBLFVBQVMsV0FBVyxDQUFDLEVBQUUsQ0FBQztBQUFBLFFBQzFCO0FBQ0EsWUFBSSxNQUFNLGNBQWM7QUFDdEIsZ0JBQU0sYUFBYTtBQUFBLFFBQ3JCO0FBQ0EsV0FBRyxVQUFVLElBQUk7QUFBQSxNQUNuQjtBQUNBLFlBQU0sT0FBTyxHQUFHLFVBQVUsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUM1QyxVQUFJLE1BQU07QUFDUixzQkFBYyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUM7QUFBQSxNQUNoQyxPQUFPO0FBQ0wsYUFBSztBQUFBLE1BQ1A7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNLElBQUlDLFNBQVE7QUFDaEIsWUFBTSxPQUFPLE9BQU8sTUFBTSxHQUFHO0FBQzdCLFVBQUksR0FBRyxVQUFVLEdBQUc7QUFDbEIsV0FBRyxVQUFVO0FBQUEsVUFDWDtBQUFBO0FBQUEsUUFFRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLE1BQU0sY0FBYztBQUN0QixlQUFPQSxRQUFPO0FBQUEsTUFDaEI7QUFDQSxNQUFBRCxVQUFTLGVBQWUsQ0FBQyxFQUFFLENBQUM7QUFDNUIsVUFBSSxTQUFTO0FBQ2IsU0FBRyxVQUFVLElBQUksQ0FBQyxjQUFjO0FBQzlCLFlBQUksT0FBUTtBQUNaLGlCQUFTO0FBQ1QsUUFBQUMsUUFBTztBQUNQLFlBQUksV0FBVztBQUNiLFVBQUFELFVBQVMsa0JBQWtCLENBQUMsRUFBRSxDQUFDO0FBQUEsUUFDakMsT0FBTztBQUNMLFVBQUFBLFVBQVMsY0FBYyxDQUFDLEVBQUUsQ0FBQztBQUFBLFFBQzdCO0FBQ0EsV0FBRyxVQUFVLElBQUk7QUFDakIsWUFBSSxtQkFBbUIsSUFBSSxNQUFNLE9BQU87QUFDdEMsaUJBQU8sbUJBQW1CLElBQUk7QUFBQSxRQUNoQztBQUFBLE1BQ0Y7QUFDQSxZQUFNLE9BQU8sR0FBRyxVQUFVLEVBQUUsS0FBSyxNQUFNLEtBQUs7QUFDNUMseUJBQW1CLElBQUksSUFBSTtBQUMzQixVQUFJLFNBQVM7QUFDWCxzQkFBYyxTQUFTLENBQUMsSUFBSSxJQUFJLENBQUM7QUFBQSxNQUNuQyxPQUFPO0FBQ0wsYUFBSztBQUFBLE1BQ1A7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNLFFBQVE7QUFDWixZQUFNLFNBQVM7QUFBQSxRQUNiO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFVBQVcsV0FBVSxNQUFNO0FBQy9CLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLE9BQU87QUFDL0IsTUFBSSxZQUFZLEtBQUssR0FBRztBQUN0QixZQUFRLFdBQVcsS0FBSztBQUN4QixVQUFNLFdBQVc7QUFDakIsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLE9BQU87QUFDOUIsTUFBSSxDQUFDLFlBQVksS0FBSyxHQUFHO0FBQ3ZCLFFBQUksV0FBVyxNQUFNLElBQUksS0FBSyxNQUFNLFVBQVU7QUFDNUMsYUFBTyxvQkFBb0IsTUFBTSxRQUFRO0FBQUEsSUFDM0M7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksTUFBTSxXQUFXO0FBQ25CLFdBQU8sTUFBTSxVQUFVO0FBQUEsRUFDekI7QUFDQSxRQUFNLEVBQUUsV0FBVyxTQUFTLElBQUk7QUFDaEMsTUFBSSxVQUFVO0FBQ1osUUFBSSxZQUFZLElBQUk7QUFDbEIsYUFBTyxTQUFTLENBQUM7QUFBQSxJQUNuQjtBQUNBLFFBQUksWUFBWSxNQUFNLFdBQVcsU0FBUyxPQUFPLEdBQUc7QUFDbEQsYUFBTyxTQUFTLFFBQVE7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLE9BQU8sT0FBTztBQUN4QyxNQUFJLE1BQU0sWUFBWSxLQUFLLE1BQU0sV0FBVztBQUMxQyxVQUFNLGFBQWE7QUFDbkIsVUFBTSxVQUFVLE1BQU0sVUFBVTtBQUNoQztBQUFBLE1BQ0UsV0FBVyxRQUFRLElBQUksSUFBSSxnQkFBZ0IsT0FBTyxLQUFLLFVBQVU7QUFBQSxNQUNqRTtBQUFBLElBQ0Y7QUFBQSxFQUNGLFdBQVcsTUFBTSxZQUFZLEtBQUs7QUFDaEMsVUFBTSxVQUFVLGFBQWEsTUFBTSxNQUFNLE1BQU0sU0FBUztBQUN4RCxVQUFNLFdBQVcsYUFBYSxNQUFNLE1BQU0sTUFBTSxVQUFVO0FBQUEsRUFDNUQsT0FBTztBQUNMLFVBQU0sYUFBYTtBQUFBLEVBQ3JCO0FBQ0Y7QUFDQSxTQUFTLHlCQUF5QixVQUFVLGNBQWMsT0FBTyxXQUFXO0FBQzFFLE1BQUksTUFBTSxDQUFDO0FBQ1gsTUFBSSxxQkFBcUI7QUFDekIsV0FBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUN4QyxRQUFJLFFBQVEsU0FBUyxDQUFDO0FBQ3RCLFVBQU0sTUFBTSxhQUFhLE9BQU8sTUFBTSxNQUFNLE9BQU8sU0FBUyxJQUFJLE9BQU8sTUFBTSxPQUFPLE9BQU8sTUFBTSxNQUFNLENBQUM7QUFDeEcsUUFBSSxNQUFNLFNBQVMsVUFBVTtBQUMzQixVQUFJLE1BQU0sWUFBWSxJQUFLO0FBQzNCLFlBQU0sSUFBSTtBQUFBLFFBQ1IseUJBQXlCLE1BQU0sVUFBVSxhQUFhLEdBQUc7QUFBQSxNQUMzRDtBQUFBLElBQ0YsV0FBVyxlQUFlLE1BQU0sU0FBUyxTQUFTO0FBQ2hELFVBQUksS0FBSyxPQUFPLE9BQU8sV0FBVyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksS0FBSztBQUFBLElBQzNEO0FBQUEsRUFDRjtBQUNBLE1BQUkscUJBQXFCLEdBQUc7QUFDMUIsYUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztBQUNuQyxVQUFJLENBQUMsRUFBRSxZQUFZO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQUE7QUFHQSxTQUFTLGdCQUFnQixTQUFTLGNBQWM7QUFDOUMsU0FBTyxXQUFXLE9BQU87QUFBQTtBQUFBO0FBQUEsSUFHTix1QkFBTSxPQUFPLEVBQUUsTUFBTSxRQUFRLEtBQUssR0FBRyxjQUFjLEVBQUUsT0FBTyxRQUFRLENBQUMsR0FBRztBQUFBLE1BQ3ZGO0FBQ047QUFFQSxTQUFTLFFBQVE7QUFDZixRQUFNLElBQUksbUJBQW1CO0FBQzdCLE1BQUksR0FBRztBQUNMLFlBQVEsRUFBRSxXQUFXLE9BQU8sWUFBWSxPQUFPLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLEVBQ3pFLFdBQVcsTUFBMkM7QUFDcEQ7QUFBQSxNQUNFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixVQUFVO0FBQ25DLFdBQVMsTUFBTSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxLQUFLLEdBQUcsQ0FBQztBQUNqRTtBQUVBLE1BQU0sb0JBQW9DLG9CQUFJLFFBQVE7QUFDdEQsU0FBUyxlQUFlLEtBQUs7QUFDM0IsUUFBTSxJQUFJLG1CQUFtQjtBQUM3QixRQUFNLElBQUksV0FBVyxJQUFJO0FBQ3pCLE1BQUksR0FBRztBQUNMLFVBQU0sT0FBTyxFQUFFLFNBQVMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUU7QUFDcEQsUUFBaUQsaUJBQWlCLE1BQU0sR0FBRyxHQUFHO0FBQzVFLGFBQU8sbUJBQW1CLEdBQUcsb0JBQW9CO0FBQUEsSUFDbkQsT0FBTztBQUNMLGFBQU8sZUFBZSxNQUFNLEtBQUs7QUFBQSxRQUMvQixZQUFZO0FBQUEsUUFDWixLQUFLLE1BQU0sRUFBRTtBQUFBLFFBQ2IsS0FBSyxDQUFDLFFBQVEsRUFBRSxRQUFRO0FBQUEsTUFDMUIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFdBQVcsTUFBMkM7QUFDcEQ7QUFBQSxNQUNFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE1BQU0sT0FBNEMsU0FBUyxDQUFDLElBQUk7QUFDdEUsTUFBSSxNQUEyQztBQUM3QyxzQkFBa0IsSUFBSSxHQUFHO0FBQUEsRUFDM0I7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixNQUFNLEtBQUs7QUFDbkMsTUFBSTtBQUNKLFNBQU8sQ0FBQyxHQUFHLE9BQU8sT0FBTyx5QkFBeUIsTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLO0FBQ3pFO0FBRUEsTUFBTSxtQkFBbUMsb0JBQUksUUFBUTtBQUNyRCxTQUFTLE9BQU8sUUFBUSxXQUFXLGdCQUFnQixPQUFPLFlBQVksT0FBTztBQUMzRSxNQUFJLFFBQVEsTUFBTSxHQUFHO0FBQ25CLFdBQU87QUFBQSxNQUNMLENBQUMsR0FBRyxNQUFNO0FBQUEsUUFDUjtBQUFBLFFBQ0EsY0FBYyxRQUFRLFNBQVMsSUFBSSxVQUFVLENBQUMsSUFBSTtBQUFBLFFBQ2xEO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksZUFBZSxLQUFLLEtBQUssQ0FBQyxXQUFXO0FBQ3ZDLFFBQUksTUFBTSxZQUFZLE9BQU8sTUFBTSxLQUFLLG1CQUFtQixNQUFNLFVBQVUsUUFBUSxXQUFXO0FBQzVGLGFBQU8sUUFBUSxXQUFXLGdCQUFnQixNQUFNLFVBQVUsT0FBTztBQUFBLElBQ25FO0FBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxXQUFXLE1BQU0sWUFBWSxJQUFJLDJCQUEyQixNQUFNLFNBQVMsSUFBSSxNQUFNO0FBQzNGLFFBQU0sUUFBUSxZQUFZLE9BQU87QUFDakMsUUFBTSxFQUFFLEdBQUcsT0FBTyxHQUFHRSxLQUFJLElBQUk7QUFDN0IsTUFBaUQsQ0FBQyxPQUFPO0FBQ3ZEO0FBQUEsTUFDRTtBQUFBLElBQ0Y7QUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsYUFBYSxVQUFVO0FBQ3RDLFFBQU0sT0FBTyxNQUFNLFNBQVMsWUFBWSxNQUFNLE9BQU8sQ0FBQyxJQUFJLE1BQU07QUFDaEUsUUFBTSxhQUFhLE1BQU07QUFDekIsUUFBTSxnQkFBZ0IsTUFBTSxVQUFVO0FBQ3RDLFFBQU0saUJBQWlCLGVBQWUsWUFBWSxLQUFLLENBQUMsUUFBUTtBQUM5RCxRQUFJLE1BQTJDO0FBQzdDLFVBQUksT0FBTyxlQUFlLEdBQUcsS0FBSyxDQUFDLE1BQU0sY0FBYyxHQUFHLENBQUMsR0FBRztBQUM1RDtBQUFBLFVBQ0UsaUJBQWlCLEdBQUc7QUFBQSxRQUN0QjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLGtCQUFrQixJQUFJLGNBQWMsR0FBRyxDQUFDLEdBQUc7QUFDN0MsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsUUFBSSxpQkFBaUIsTUFBTSxHQUFHLEdBQUc7QUFDL0IsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLE9BQU8sZUFBZSxHQUFHO0FBQUEsRUFDbEM7QUFDQSxRQUFNLFlBQVksQ0FBQ0MsT0FBTSxRQUFRO0FBQy9CLFFBQWlELGtCQUFrQixJQUFJQSxLQUFJLEdBQUc7QUFDNUUsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLE9BQU8saUJBQWlCLE1BQU0sR0FBRyxHQUFHO0FBQ3RDLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFVBQVUsUUFBUSxXQUFXRCxNQUFLO0FBQ3BDLDRCQUF3QixTQUFTO0FBQ2pDLFFBQUksU0FBUyxNQUFNLEdBQUc7QUFDcEIsV0FBSyxNQUFNLElBQUk7QUFDZixVQUFJLGVBQWUsTUFBTSxHQUFHO0FBQzFCLG1CQUFXLE1BQU0sSUFBSTtBQUFBLE1BQ3ZCO0FBQUEsSUFDRixXQUFXLE1BQU0sTUFBTSxHQUFHO0FBQ3hCLFlBQU0sZ0JBQWdCO0FBQ3RCLFVBQUksVUFBVSxRQUFRLGNBQWMsQ0FBQyxHQUFHO0FBQ3RDLGVBQU8sUUFBUTtBQUFBLE1BQ2pCO0FBQ0EsVUFBSSxjQUFjLEVBQUcsTUFBSyxjQUFjLENBQUMsSUFBSTtBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUNBLE1BQUksV0FBV0EsSUFBRyxHQUFHO0FBQ25CLDBCQUFzQkEsTUFBSyxPQUFPLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQztBQUFBLEVBQ3JELE9BQU87QUFDTCxVQUFNLFlBQVksU0FBU0EsSUFBRztBQUM5QixVQUFNLFNBQVMsTUFBTUEsSUFBRztBQUN4QixRQUFJLGFBQWEsUUFBUTtBQUN2QixZQUFNLFFBQVEsTUFBTTtBQUNsQixZQUFJLE9BQU8sR0FBRztBQUNaLGdCQUFNLFdBQVcsWUFBWSxlQUFlQSxJQUFHLElBQUksV0FBV0EsSUFBRyxJQUFJLEtBQUtBLElBQUcsSUFBSSxVQUFVQSxJQUFHLEtBQUssQ0FBQyxPQUFPLElBQUlBLEtBQUksUUFBUSxLQUFLLE9BQU8sQ0FBQztBQUN4SSxjQUFJLFdBQVc7QUFDYixvQkFBUSxRQUFRLEtBQUssT0FBTyxVQUFVLFFBQVE7QUFBQSxVQUNoRCxPQUFPO0FBQ0wsZ0JBQUksQ0FBQyxRQUFRLFFBQVEsR0FBRztBQUN0QixrQkFBSSxXQUFXO0FBQ2IscUJBQUtBLElBQUcsSUFBSSxDQUFDLFFBQVE7QUFDckIsb0JBQUksZUFBZUEsSUFBRyxHQUFHO0FBQ3ZCLDZCQUFXQSxJQUFHLElBQUksS0FBS0EsSUFBRztBQUFBLGdCQUM1QjtBQUFBLGNBQ0YsT0FBTztBQUNMLHNCQUFNLFNBQVMsQ0FBQyxRQUFRO0FBQ3hCLG9CQUFJLFVBQVVBLE1BQUssT0FBTyxDQUFDLEdBQUc7QUFDNUIsa0JBQUFBLEtBQUksUUFBUTtBQUFBLGdCQUNkO0FBQ0Esb0JBQUksT0FBTyxFQUFHLE1BQUssT0FBTyxDQUFDLElBQUk7QUFBQSxjQUNqQztBQUFBLFlBQ0YsV0FBVyxDQUFDLFNBQVMsU0FBUyxRQUFRLEdBQUc7QUFDdkMsdUJBQVMsS0FBSyxRQUFRO0FBQUEsWUFDeEI7QUFBQSxVQUNGO0FBQUEsUUFDRixXQUFXLFdBQVc7QUFDcEIsZUFBS0EsSUFBRyxJQUFJO0FBQ1osY0FBSSxlQUFlQSxJQUFHLEdBQUc7QUFDdkIsdUJBQVdBLElBQUcsSUFBSTtBQUFBLFVBQ3BCO0FBQUEsUUFDRixXQUFXLFFBQVE7QUFDakIsY0FBSSxVQUFVQSxNQUFLLE9BQU8sQ0FBQyxHQUFHO0FBQzVCLFlBQUFBLEtBQUksUUFBUTtBQUFBLFVBQ2Q7QUFDQSxjQUFJLE9BQU8sRUFBRyxNQUFLLE9BQU8sQ0FBQyxJQUFJO0FBQUEsUUFDakMsV0FBVyxNQUEyQztBQUNwRCxpQkFBTyw4QkFBOEJBLE1BQUssSUFBSSxPQUFPQSxJQUFHLEdBQUc7QUFBQSxRQUM3RDtBQUFBLE1BQ0Y7QUFDQSxVQUFJLE9BQU87QUFDVCxjQUFNLE1BQU0sTUFBTTtBQUNoQixnQkFBTTtBQUNOLDJCQUFpQixPQUFPLE1BQU07QUFBQSxRQUNoQztBQUNBLFlBQUksS0FBSztBQUNULHlCQUFpQixJQUFJLFFBQVEsR0FBRztBQUNoQyw4QkFBc0IsS0FBSyxjQUFjO0FBQUEsTUFDM0MsT0FBTztBQUNMLGdDQUF3QixNQUFNO0FBQzlCLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRixXQUFXLE1BQTJDO0FBQ3BELGFBQU8sOEJBQThCQSxNQUFLLElBQUksT0FBT0EsSUFBRyxHQUFHO0FBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHdCQUF3QixRQUFRO0FBQ3ZDLFFBQU0sZ0JBQWdCLGlCQUFpQixJQUFJLE1BQU07QUFDakQsTUFBSSxlQUFlO0FBQ2pCLGtCQUFjLFNBQVM7QUFDdkIscUJBQWlCLE9BQU8sTUFBTTtBQUFBLEVBQ2hDO0FBQ0Y7QUFFQSxJQUFJLHlCQUF5QjtBQUM3QixNQUFNLG1CQUFtQixNQUFNO0FBQzdCLE1BQUksd0JBQXdCO0FBQzFCO0FBQUEsRUFDRjtBQUNBLFVBQVEsTUFBTSw4Q0FBOEM7QUFDNUQsMkJBQXlCO0FBQzNCO0FBQ0EsTUFBTSxpQkFBaUIsQ0FBQyxjQUFjLFVBQVUsYUFBYSxTQUFTLEtBQUssS0FBSyxVQUFVLFlBQVk7QUFDdEcsTUFBTSxvQkFBb0IsQ0FBQyxjQUFjLFVBQVUsYUFBYSxTQUFTLFFBQVE7QUFDakYsTUFBTSxtQkFBbUIsQ0FBQyxjQUFjO0FBQ3RDLE1BQUksVUFBVSxhQUFhLEVBQUcsUUFBTztBQUNyQyxNQUFJLGVBQWUsU0FBUyxFQUFHLFFBQU87QUFDdEMsTUFBSSxrQkFBa0IsU0FBUyxFQUFHLFFBQU87QUFDekMsU0FBTztBQUNUO0FBQ0EsTUFBTSxZQUFZLENBQUMsU0FBUyxLQUFLLGFBQWE7QUFDOUMsU0FBUyx5QkFBeUIsbUJBQW1CO0FBQ25ELFFBQU07QUFBQSxJQUNKLElBQUk7QUFBQSxJQUNKLEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxNQUNEO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxRQUFBRDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0YsSUFBSTtBQUNKLFFBQU0sVUFBVSxDQUFDLE9BQU8sY0FBYztBQUNwQyxRQUFJLENBQUMsVUFBVSxjQUFjLEdBQUc7QUFDOUIsTUFBMEY7QUFBQSxRQUN4RjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLE1BQU0sT0FBTyxTQUFTO0FBQzVCLHdCQUFrQjtBQUNsQixnQkFBVSxTQUFTO0FBQ25CO0FBQUEsSUFDRjtBQUNBLGdCQUFZLFVBQVUsWUFBWSxPQUFPLE1BQU0sTUFBTSxJQUFJO0FBQ3pELHNCQUFrQjtBQUNsQixjQUFVLFNBQVM7QUFBQSxFQUNyQjtBQUNBLFFBQU0sY0FBYyxDQUFDLE1BQU0sT0FBTyxpQkFBaUIsZ0JBQWdCLGNBQWMsWUFBWSxVQUFVO0FBQ3JHLGdCQUFZLGFBQWEsQ0FBQyxDQUFDLE1BQU07QUFDakMsVUFBTSxrQkFBa0IsVUFBVSxJQUFJLEtBQUssS0FBSyxTQUFTO0FBQ3pELFVBQU0sYUFBYSxNQUFNO0FBQUEsTUFDdkI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLEVBQUUsTUFBTSxLQUFBQyxNQUFLLFdBQVcsVUFBVSxJQUFJO0FBQzVDLFFBQUksVUFBVSxLQUFLO0FBQ25CLFVBQU0sS0FBSztBQUNYLFFBQUksTUFBb0U7QUFDdEUsVUFBSSxNQUFNLFdBQVcsT0FBTyxJQUFJO0FBQ2hDLFVBQUksTUFBTSx3QkFBd0IsaUJBQWlCLElBQUk7QUFBQSxJQUN6RDtBQUNBLFFBQUksY0FBYyxJQUFJO0FBQ3BCLGtCQUFZO0FBQ1osWUFBTSxrQkFBa0I7QUFBQSxJQUMxQjtBQUNBLFFBQUksV0FBVztBQUNmLFlBQVEsTUFBTTtBQUFBLE1BQ1osS0FBSztBQUNILFlBQUksWUFBWSxHQUFHO0FBQ2pCLGNBQUksTUFBTSxhQUFhLElBQUk7QUFDekIsbUJBQU8sTUFBTSxLQUFLLFdBQVcsRUFBRSxHQUFHLFdBQVcsSUFBSSxHQUFHLElBQUk7QUFDeEQsdUJBQVc7QUFBQSxVQUNiLE9BQU87QUFDTCx1QkFBVyxXQUFXO0FBQUEsVUFDeEI7QUFBQSxRQUNGLE9BQU87QUFDTCxjQUFJLEtBQUssU0FBUyxNQUFNLFVBQVU7QUFDaEMsWUFBMEY7QUFBQSxjQUN4RjtBQUFBLGNBQ0EsS0FBSztBQUFBLGNBQ0w7QUFBQSwwQkFDWSxLQUFLO0FBQUEsZ0JBQ2YsS0FBSztBQUFBLGNBQ1AsQ0FBQztBQUFBLDBCQUNXLEtBQUssVUFBVSxNQUFNLFFBQVEsQ0FBQztBQUFBLFlBQzVDO0FBQ0EsNkJBQWlCO0FBQ2pCLGlCQUFLLE9BQU8sTUFBTTtBQUFBLFVBQ3BCO0FBQ0EscUJBQVcsWUFBWSxJQUFJO0FBQUEsUUFDN0I7QUFDQTtBQUFBLE1BQ0YsS0FBSztBQUNILFlBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIscUJBQVcsWUFBWSxJQUFJO0FBQzNCO0FBQUEsWUFDRSxNQUFNLEtBQUssS0FBSyxRQUFRO0FBQUEsWUFDeEI7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0YsV0FBVyxZQUFZLEtBQUssaUJBQWlCO0FBQzNDLHFCQUFXLFdBQVc7QUFBQSxRQUN4QixPQUFPO0FBQ0wscUJBQVcsWUFBWSxJQUFJO0FBQUEsUUFDN0I7QUFDQTtBQUFBLE1BQ0YsS0FBSztBQUNILFlBQUksaUJBQWlCO0FBQ25CLGlCQUFPLFlBQVksSUFBSTtBQUN2QixvQkFBVSxLQUFLO0FBQUEsUUFDakI7QUFDQSxZQUFJLFlBQVksS0FBSyxZQUFZLEdBQUc7QUFDbEMscUJBQVc7QUFDWCxnQkFBTSxxQkFBcUIsQ0FBQyxNQUFNLFNBQVM7QUFDM0MsbUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxhQUFhLEtBQUs7QUFDMUMsZ0JBQUk7QUFDRixvQkFBTSxZQUFZLFNBQVMsYUFBYSxJQUFJLFNBQVMsWUFBWSxTQUFTO0FBQzVFLGdCQUFJLE1BQU0sTUFBTSxjQUFjLEdBQUc7QUFDL0Isb0JBQU0sU0FBUztBQUFBLFlBQ2pCO0FBQ0EsdUJBQVcsWUFBWSxRQUFRO0FBQUEsVUFDakM7QUFDQSxpQkFBTyxrQkFBa0IsWUFBWSxRQUFRLElBQUk7QUFBQSxRQUNuRCxPQUFPO0FBQ0wscUJBQVc7QUFBQSxRQUNiO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCxZQUFJLENBQUMsaUJBQWlCO0FBQ3BCLHFCQUFXLFdBQVc7QUFBQSxRQUN4QixPQUFPO0FBQ0wscUJBQVc7QUFBQSxZQUNUO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUNFLFlBQUksWUFBWSxHQUFHO0FBQ2pCLGVBQUssWUFBWSxLQUFLLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxRQUFRLFlBQVksTUFBTSxDQUFDLGVBQWUsSUFBSSxHQUFHO0FBQ3ZHLHVCQUFXLFdBQVc7QUFBQSxVQUN4QixPQUFPO0FBQ0wsdUJBQVc7QUFBQSxjQUNUO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0YsV0FBVyxZQUFZLEdBQUc7QUFDeEIsZ0JBQU0sZUFBZTtBQUNyQixnQkFBTSxZQUFZLFdBQVcsSUFBSTtBQUNqQyxjQUFJLGlCQUFpQjtBQUNuQix1QkFBVyxvQkFBb0IsSUFBSTtBQUFBLFVBQ3JDLFdBQVcsVUFBVSxJQUFJLEtBQUssS0FBSyxTQUFTLGtCQUFrQjtBQUM1RCx1QkFBVyxvQkFBb0IsTUFBTSxLQUFLLE1BQU0sY0FBYztBQUFBLFVBQ2hFLE9BQU87QUFDTCx1QkFBVyxZQUFZLElBQUk7QUFBQSxVQUM3QjtBQUNBO0FBQUEsWUFDRTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLGlCQUFpQixTQUFTO0FBQUEsWUFDMUI7QUFBQSxVQUNGO0FBQ0EsY0FBSSxlQUFlLEtBQUssS0FBSyxDQUFDLE1BQU0sS0FBSyxpQkFBaUI7QUFDeEQsZ0JBQUk7QUFDSixnQkFBSSxpQkFBaUI7QUFDbkIsd0JBQVUsWUFBWSxRQUFRO0FBQzlCLHNCQUFRLFNBQVMsV0FBVyxTQUFTLGtCQUFrQixVQUFVO0FBQUEsWUFDbkUsT0FBTztBQUNMLHdCQUFVLEtBQUssYUFBYSxJQUFJLGdCQUFnQixFQUFFLElBQUksWUFBWSxLQUFLO0FBQUEsWUFDekU7QUFDQSxvQkFBUSxLQUFLO0FBQ2Isa0JBQU0sVUFBVSxVQUFVO0FBQUEsVUFDNUI7QUFBQSxRQUNGLFdBQVcsWUFBWSxJQUFJO0FBQ3pCLGNBQUksWUFBWSxHQUFHO0FBQ2pCLHVCQUFXLFdBQVc7QUFBQSxVQUN4QixPQUFPO0FBQ0wsdUJBQVcsTUFBTSxLQUFLO0FBQUEsY0FDcEI7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsWUFBWSxLQUFLO0FBQzFCLHFCQUFXLE1BQU0sS0FBSztBQUFBLFlBQ3BCO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQSxpQkFBaUIsV0FBVyxJQUFJLENBQUM7QUFBQSxZQUNqQztBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsTUFBc0Y7QUFDL0YsaUJBQU8sMkJBQTJCLE1BQU0sSUFBSSxPQUFPLElBQUksR0FBRztBQUFBLFFBQzVEO0FBQUEsSUFDSjtBQUNBLFFBQUlBLFFBQU8sTUFBTTtBQUNmLGFBQU9BLE1BQUssTUFBTSxnQkFBZ0IsS0FBSztBQUFBLElBQ3pDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGlCQUFpQixDQUFDLElBQUksT0FBTyxpQkFBaUIsZ0JBQWdCLGNBQWMsY0FBYztBQUM5RixnQkFBWSxhQUFhLENBQUMsQ0FBQyxNQUFNO0FBQ2pDLFVBQU07QUFBQSxNQUNKO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixJQUFJO0FBQ0osVUFBTSxhQUFhLFNBQVMsV0FBVyxTQUFTO0FBQ2hELFVBQU0sa0JBQWtCLENBQUMsQ0FBQztBQUMxQixRQUFJLE1BQWdHO0FBQ2xHLFVBQUksTUFBTTtBQUNSLDRCQUFvQixPQUFPLE1BQU0saUJBQWlCLFNBQVM7QUFBQSxNQUM3RDtBQUNBLFVBQUksMEJBQTBCO0FBQzlCLFVBQUksZUFBZSxFQUFFLEdBQUc7QUFDdEIsa0NBQTBCO0FBQUEsVUFDeEI7QUFBQTtBQUFBLFVBRUE7QUFBQSxRQUNGLEtBQUssbUJBQW1CLGdCQUFnQixNQUFNLFNBQVMsZ0JBQWdCLE1BQU0sTUFBTTtBQUNuRixjQUFNLFVBQVUsR0FBRyxRQUFRO0FBQzNCLFlBQUkseUJBQXlCO0FBQzNCLGdCQUFNLE1BQU0sUUFBUSxhQUFhLE9BQU87QUFDeEMsY0FBSSxJQUFLLFNBQVEsT0FBTztBQUN4QixxQkFBVyxZQUFZLE9BQU87QUFBQSxRQUNoQztBQUNBLG9CQUFZLFNBQVMsSUFBSSxlQUFlO0FBQ3hDLGNBQU0sS0FBSyxLQUFLO0FBQUEsTUFDbEI7QUFDQSxVQUFJLFlBQVk7QUFBQSxNQUNoQixFQUFFLFVBQVUsTUFBTSxhQUFhLE1BQU0sZUFBZTtBQUNsRCxZQUFJLE9BQU87QUFBQSxVQUNULEdBQUc7QUFBQSxVQUNIO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsWUFBSSxRQUFRLENBQUM7QUFBQSxVQUFrQjtBQUFBLFVBQUk7QUFBQTtBQUFBLFFBQWdCLEdBQUc7QUFDcEQsVUFBMEY7QUFBQSxZQUN4RjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUE7QUFBQSxVQUVGO0FBQ0EsMkJBQWlCO0FBQUEsUUFDbkI7QUFDQSxlQUFPLE1BQU07QUFDWCxnQkFBTSxNQUFNO0FBQ1osaUJBQU8sS0FBSztBQUNaLFVBQUFELFFBQU8sR0FBRztBQUFBLFFBQ1o7QUFBQSxNQUNGLFdBQVcsWUFBWSxHQUFHO0FBQ3hCLFlBQUksYUFBYSxNQUFNO0FBQ3ZCLFlBQUksV0FBVyxDQUFDLE1BQU0sU0FBUyxHQUFHLFlBQVksU0FBUyxHQUFHLFlBQVksYUFBYTtBQUNqRix1QkFBYSxXQUFXLE1BQU0sQ0FBQztBQUFBLFFBQ2pDO0FBQ0EsY0FBTSxFQUFFLFlBQVksSUFBSTtBQUN4QixZQUFJLGdCQUFnQjtBQUFBLFFBQ3BCLGdCQUFnQixXQUFXLFFBQVEsWUFBWSxJQUFJLEdBQUc7QUFDcEQsY0FBSSxDQUFDO0FBQUEsWUFBa0I7QUFBQSxZQUFJO0FBQUE7QUFBQSxVQUFZLEdBQUc7QUFDeEMsWUFBMEY7QUFBQSxjQUN4RjtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsMEJBQ1ksV0FBVztBQUFBLDBCQUNYLFVBQVU7QUFBQSxZQUN4QjtBQUNBLDZCQUFpQjtBQUFBLFVBQ25CO0FBQ0EsYUFBRyxjQUFjLE1BQU07QUFBQSxRQUN6QjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLE9BQU87QUFDVCxZQUFJLE1BQThKO0FBQ2hLLGdCQUFNLGtCQUFrQixHQUFHLFFBQVEsU0FBUyxHQUFHO0FBQy9DLGdCQUFNLFlBQVksR0FBRyxhQUFhLFNBQVMsS0FBSyxJQUFJLFFBQVEsR0FBRyxhQUFhLFNBQVMsUUFBUSxJQUFJLFdBQVc7QUFDNUcscUJBQVcsT0FBTyxPQUFPO0FBQ3ZCO0FBQUE7QUFBQSxZQUVBLEVBQUUsUUFBUSxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxPQUFPLE1BQU0sZ0JBQWdCLElBQUksS0FBSyxNQUFNLEdBQUcsR0FBRyxPQUFPLGVBQWUsR0FBRztBQUMxRywrQkFBaUI7QUFBQSxZQUNuQjtBQUNBLGdCQUFJLGVBQWUsSUFBSSxTQUFTLE9BQU8sS0FBSyxRQUFRLG9CQUFvQixLQUFLLEdBQUcsS0FBSyxDQUFDLGVBQWUsR0FBRztBQUFBLFlBQ3hHLElBQUksQ0FBQyxNQUFNLE9BQU8sbUJBQW1CLENBQUMsZUFBZSxHQUFHLEtBQUssZ0JBQWdCLGFBQWEsU0FBUyxHQUFHLEdBQUc7QUFDdkcsa0JBQUksd0JBQXdCLElBQUksS0FBSyxNQUFNLEdBQUcsQ0FBQyxHQUFHO0FBQ2hEO0FBQUEsY0FDRjtBQUNBLHdCQUFVLElBQUksS0FBSyxNQUFNLE1BQU0sR0FBRyxHQUFHLFdBQVcsZUFBZTtBQUFBLFlBQ2pFO0FBQUEsVUFDRjtBQUFBLFFBQ0YsV0FBVyxNQUFNLFNBQVM7QUFDeEI7QUFBQSxZQUNFO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLE1BQU07QUFBQSxZQUNOO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsWUFBWSxLQUFLLFdBQVcsTUFBTSxLQUFLLEdBQUc7QUFDbkQscUJBQVcsT0FBTyxNQUFNLE1BQU8sT0FBTSxNQUFNLEdBQUc7QUFBQSxRQUNoRDtBQUFBLE1BQ0Y7QUFDQSxVQUFJO0FBQ0osVUFBSSxhQUFhLFNBQVMsTUFBTSxvQkFBb0I7QUFDbEQsd0JBQWdCLFlBQVksaUJBQWlCLEtBQUs7QUFBQSxNQUNwRDtBQUNBLFVBQUksTUFBTTtBQUNSLDRCQUFvQixPQUFPLE1BQU0saUJBQWlCLGFBQWE7QUFBQSxNQUNqRTtBQUNBLFdBQUssYUFBYSxTQUFTLE1BQU0sbUJBQW1CLFFBQVEseUJBQXlCO0FBQ25GLGdDQUF3QixNQUFNO0FBQzVCLHdCQUFjLGdCQUFnQixZQUFZLGlCQUFpQixLQUFLO0FBQ2hFLHFDQUEyQixXQUFXLE1BQU0sRUFBRTtBQUM5QyxrQkFBUSxvQkFBb0IsT0FBTyxNQUFNLGlCQUFpQixTQUFTO0FBQUEsUUFDckUsR0FBRyxjQUFjO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQ0EsV0FBTyxHQUFHO0FBQUEsRUFDWjtBQUNBLFFBQU0sa0JBQWtCLENBQUMsTUFBTSxhQUFhLFdBQVcsaUJBQWlCLGdCQUFnQixjQUFjLGNBQWM7QUFDbEgsZ0JBQVksYUFBYSxDQUFDLENBQUMsWUFBWTtBQUN2QyxVQUFNLFdBQVcsWUFBWTtBQUM3QixVQUFNLElBQUksU0FBUztBQUNuQixRQUFJLHFCQUFxQjtBQUN6QixhQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMxQixZQUFNLFFBQVEsWUFBWSxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsSUFBSSxlQUFlLFNBQVMsQ0FBQyxDQUFDO0FBQ2hGLFlBQU0sU0FBUyxNQUFNLFNBQVM7QUFDOUIsVUFBSSxNQUFNO0FBQ1IsWUFBSSxVQUFVLENBQUMsV0FBVztBQUN4QixjQUFJLElBQUksSUFBSSxLQUFLLGVBQWUsU0FBUyxJQUFJLENBQUMsQ0FBQyxFQUFFLFNBQVMsTUFBTTtBQUM5RDtBQUFBLGNBQ0U7QUFBQSxnQkFDRSxLQUFLLEtBQUssTUFBTSxNQUFNLFNBQVMsTUFBTTtBQUFBLGNBQ3ZDO0FBQUEsY0FDQTtBQUFBLGNBQ0EsWUFBWSxJQUFJO0FBQUEsWUFDbEI7QUFDQSxpQkFBSyxPQUFPLE1BQU07QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0YsV0FBVyxVQUFVLENBQUMsTUFBTSxVQUFVO0FBQ3BDLGVBQU8sTUFBTSxLQUFLLFdBQVcsRUFBRSxHQUFHLFNBQVM7QUFBQSxNQUM3QyxPQUFPO0FBQ0wsWUFBSSxDQUFDLG9CQUFvQjtBQUN2QiwrQkFBcUI7QUFDckIsY0FBSSxDQUFDO0FBQUEsWUFBa0I7QUFBQSxZQUFXO0FBQUE7QUFBQSxVQUFnQixHQUFHO0FBQ25ELFlBQTBGO0FBQUEsY0FDeEY7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBO0FBQUEsWUFFRjtBQUNBLDZCQUFpQjtBQUFBLFVBQ25CO0FBQUEsUUFDRjtBQUNBO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxpQkFBaUIsU0FBUztBQUFBLFVBQzFCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGtCQUFrQixDQUFDLE1BQU0sT0FBTyxpQkFBaUIsZ0JBQWdCLGNBQWMsY0FBYztBQUNqRyxVQUFNLEVBQUUsY0FBYyxxQkFBcUIsSUFBSTtBQUMvQyxRQUFJLHNCQUFzQjtBQUN4QixxQkFBZSxlQUFlLGFBQWEsT0FBTyxvQkFBb0IsSUFBSTtBQUFBLElBQzVFO0FBQ0EsVUFBTSxZQUFZLFdBQVcsSUFBSTtBQUNqQyxVQUFNLE9BQU87QUFBQSxNQUNYLFlBQVksSUFBSTtBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFVBQVUsSUFBSSxLQUFLLEtBQUssU0FBUyxLQUFLO0FBQ2hELGFBQU8sWUFBWSxNQUFNLFNBQVMsSUFBSTtBQUFBLElBQ3hDLE9BQU87QUFDTCx1QkFBaUI7QUFDakIsYUFBTyxNQUFNLFNBQVMsY0FBYyxHQUFHLEdBQUcsV0FBVyxJQUFJO0FBQ3pELGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFFBQU0saUJBQWlCLENBQUMsTUFBTSxPQUFPLGlCQUFpQixnQkFBZ0IsY0FBYyxlQUFlO0FBQ2pHLFFBQUksQ0FBQyxzQkFBc0IsTUFBTSxLQUFLLEdBQUc7QUFDdkMsTUFBMEY7QUFBQSxRQUN4RjtBQUFBO0FBQUEsUUFFQTtBQUFBLFFBQ0EsS0FBSyxhQUFhLElBQUksV0FBVyxVQUFVLElBQUksS0FBSyxLQUFLLFNBQVMsTUFBTSx3QkFBd0I7QUFBQSxRQUNoRztBQUFBO0FBQUEsUUFFQSxNQUFNO0FBQUEsTUFDUjtBQUNBLHVCQUFpQjtBQUFBLElBQ25CO0FBQ0EsVUFBTSxLQUFLO0FBQ1gsUUFBSSxZQUFZO0FBQ2QsWUFBTSxNQUFNLG9CQUFvQixJQUFJO0FBQ3BDLGFBQU8sTUFBTTtBQUNYLGNBQU0sUUFBUSxZQUFZLElBQUk7QUFDOUIsWUFBSSxTQUFTLFVBQVUsS0FBSztBQUMxQixVQUFBQSxRQUFPLEtBQUs7QUFBQSxRQUNkLE9BQU87QUFDTDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxZQUFZLElBQUk7QUFDN0IsVUFBTSxZQUFZLFdBQVcsSUFBSTtBQUNqQyxJQUFBQSxRQUFPLElBQUk7QUFDWDtBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0EsaUJBQWlCLFNBQVM7QUFBQSxNQUMxQjtBQUFBLElBQ0Y7QUFDQSxRQUFJLGlCQUFpQjtBQUNuQixzQkFBZ0IsTUFBTSxLQUFLLE1BQU07QUFDakMsc0JBQWdCLGlCQUFpQixNQUFNLEVBQUU7QUFBQSxJQUMzQztBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxzQkFBc0IsQ0FBQyxNQUFNLE9BQU8sS0FBSyxRQUFRLFFBQVE7QUFDN0QsUUFBSSxRQUFRO0FBQ1osV0FBTyxNQUFNO0FBQ1gsYUFBTyxZQUFZLElBQUk7QUFDdkIsVUFBSSxRQUFRLFVBQVUsSUFBSSxHQUFHO0FBQzNCLFlBQUksS0FBSyxTQUFTLEtBQU07QUFDeEIsWUFBSSxLQUFLLFNBQVMsT0FBTztBQUN2QixjQUFJLFVBQVUsR0FBRztBQUNmLG1CQUFPLFlBQVksSUFBSTtBQUFBLFVBQ3pCLE9BQU87QUFDTDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sY0FBYyxDQUFDLFNBQVMsU0FBUyxvQkFBb0I7QUFDekQsVUFBTSxjQUFjLFFBQVE7QUFDNUIsUUFBSSxhQUFhO0FBQ2Ysa0JBQVksYUFBYSxTQUFTLE9BQU87QUFBQSxJQUMzQztBQUNBLFFBQUksU0FBUztBQUNiLFdBQU8sUUFBUTtBQUNiLFVBQUksT0FBTyxNQUFNLE9BQU8sU0FBUztBQUMvQixlQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsS0FBSztBQUFBLE1BQ3hDO0FBQ0EsZUFBUyxPQUFPO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxpQkFBaUIsQ0FBQyxTQUFTO0FBQy9CLFdBQU8sS0FBSyxhQUFhLEtBQUssS0FBSyxZQUFZO0FBQUEsRUFDakQ7QUFDQSxTQUFPLENBQUMsU0FBUyxXQUFXO0FBQzlCO0FBQ0EsTUFBTSxnQkFBZ0Msb0JBQUksSUFBSSxDQUFDLE9BQU8sVUFBVSxRQUFRLFFBQVEsQ0FBQztBQUNqRixTQUFTLHdCQUF3QixJQUFJLEtBQUssYUFBYTtBQUNyRCxNQUFJLENBQUMsY0FBYyxJQUFJLEdBQUcsR0FBRztBQUMzQixXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU8sR0FBRyxhQUFhLEdBQUcsT0FBTyxlQUFlLE9BQU8sT0FBTyxHQUFHLFdBQVc7QUFDOUU7QUFDQSxTQUFTLGdCQUFnQixJQUFJLEtBQUssYUFBYSxPQUFPLFVBQVU7QUFDOUQsTUFBSTtBQUNKLE1BQUk7QUFDSixNQUFJO0FBQ0osTUFBSTtBQUNKLE1BQUksUUFBUSxTQUFTO0FBQ25CLFFBQUksR0FBRyxNQUFNO0FBQ1gsZUFBUyxHQUFHO0FBQ1osYUFBTyxHQUFHO0FBQUEsSUFDWixPQUFPO0FBQ0wsZUFBUyxHQUFHLGFBQWEsT0FBTztBQUFBLElBQ2xDO0FBQ0EsZUFBVyxlQUFlLFdBQVc7QUFDckMsUUFBSSxDQUFDLFdBQVcsV0FBVyxVQUFVLEVBQUUsR0FBRyxXQUFXLFFBQVEsQ0FBQyxHQUFHO0FBQy9ELHFCQUFlO0FBQ2Ysb0JBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0YsV0FBVyxRQUFRLFNBQVM7QUFDMUIsYUFBUyxHQUFHLGFBQWEsT0FBTyxLQUFLO0FBQ3JDLGVBQVcsU0FBUyxXQUFXLElBQUksY0FBYyxlQUFlLGVBQWUsV0FBVyxDQUFDO0FBQzNGLFVBQU0sWUFBWSxXQUFXLE1BQU07QUFDbkMsVUFBTSxjQUFjLFdBQVcsUUFBUTtBQUN2QyxRQUFJLE1BQU0sTUFBTTtBQUNkLGlCQUFXLEVBQUUsS0FBSyxNQUFNLEtBQUssTUFBTSxNQUFNO0FBQ3ZDLFlBQUksSUFBSSxTQUFTLFVBQVUsQ0FBQyxPQUFPO0FBQ2pDLHNCQUFZLElBQUksV0FBVyxNQUFNO0FBQUEsUUFDbkM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksVUFBVTtBQUNaLHFCQUFlLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDN0M7QUFDQSxRQUFJLENBQUMsV0FBVyxXQUFXLFdBQVcsR0FBRztBQUN2QyxxQkFBZTtBQUNmLG9CQUFjO0FBQUEsSUFDaEI7QUFBQSxFQUNGLFdBQVcsY0FBYyxjQUFjLGVBQWUsR0FBRyxLQUFLLGNBQWMsZ0JBQWdCLGNBQWMsR0FBRyxLQUFLLGdCQUFnQixHQUFHLElBQUk7QUFDdkksUUFBSSxRQUFRLFVBQVU7QUFDcEIsZUFBUyxxQkFBcUIsR0FBRyxhQUFhLEdBQUcsQ0FBQztBQUNsRCxpQkFBVyxxQkFBcUIsV0FBVztBQUFBLElBQzdDLFdBQVcsY0FBYyxHQUFHLEdBQUc7QUFDN0IsZUFBUyxHQUFHLGFBQWEsR0FBRztBQUM1QixpQkFBVyxtQkFBbUIsV0FBVztBQUFBLElBQzNDLFdBQVcsZUFBZSxNQUFNO0FBQzlCLGVBQVMsR0FBRyxhQUFhLEdBQUc7QUFDNUIsaUJBQVc7QUFBQSxJQUNiLE9BQU87QUFDTCxVQUFJLEdBQUcsYUFBYSxHQUFHLEdBQUc7QUFDeEIsaUJBQVMsR0FBRyxhQUFhLEdBQUc7QUFBQSxNQUM5QixXQUFXLFFBQVEsV0FBVyxHQUFHLFlBQVksWUFBWTtBQUN2RCxpQkFBUyxHQUFHO0FBQUEsTUFDZCxPQUFPO0FBQ0wsaUJBQVM7QUFBQSxNQUNYO0FBQ0EsaUJBQVcsc0JBQXNCLFdBQVcsSUFBSSxPQUFPLFdBQVcsSUFBSTtBQUFBLElBQ3hFO0FBQ0EsUUFBSSxXQUFXLFVBQVU7QUFDdkIscUJBQWU7QUFDZixvQkFBYztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNBLE1BQUksZ0JBQWdCLFFBQVEsQ0FBQyxrQkFBa0IsSUFBSSxZQUFZLEdBQUc7QUFDaEUsVUFBTSxTQUFTLENBQUMsTUFBTSxNQUFNLFFBQVEsbUJBQW1CLEdBQUcsV0FBVyxLQUFLLENBQUM7QUFDM0UsVUFBTSxhQUFhLGFBQWEsbUJBQW1CLFlBQVksQ0FBQztBQUNoRSxVQUFNLGNBQWM7QUFBQSwwQkFDRSxPQUFPLE1BQU0sQ0FBQztBQUFBLDBCQUNkLE9BQU8sUUFBUSxDQUFDO0FBQUE7QUFBQTtBQUd0QztBQUNFLGFBQU8sWUFBWSxJQUFJLFdBQVc7QUFBQSxJQUNwQztBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTztBQUNuQyxNQUFJLENBQUMsc0JBQXNCLEtBQUssR0FBRztBQUNqQyxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksU0FBUyxLQUFLLEdBQUc7QUFDbkIsV0FBTyxNQUFNLFlBQVksTUFBTSxnQkFBZ0IsZ0JBQWdCO0FBQUEsRUFDakU7QUFDQSxTQUFPLG1CQUFtQixLQUFLLElBQUksS0FBSztBQUMxQztBQUNBLFNBQVMsV0FBVyxLQUFLO0FBQ3ZCLFNBQU8sSUFBSSxJQUFJLElBQUksS0FBSyxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQ3hDO0FBQ0EsU0FBUyxXQUFXLEdBQUcsR0FBRztBQUN4QixNQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU07QUFDckIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxhQUFXLEtBQUssR0FBRztBQUNqQixRQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRztBQUNiLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsV0FBVyxLQUFLO0FBQ3ZCLFFBQU0sV0FBMkIsb0JBQUksSUFBSTtBQUN6QyxhQUFXLFFBQVEsSUFBSSxNQUFNLEdBQUcsR0FBRztBQUNqQyxRQUFJLENBQUMsS0FBSyxLQUFLLElBQUksS0FBSyxNQUFNLEdBQUc7QUFDakMsVUFBTSxJQUFJLEtBQUs7QUFDZixZQUFRLFNBQVMsTUFBTSxLQUFLO0FBQzVCLFFBQUksT0FBTyxPQUFPO0FBQ2hCLGVBQVMsSUFBSSxLQUFLLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsR0FBRyxHQUFHO0FBQ3hCLE1BQUksRUFBRSxTQUFTLEVBQUUsTUFBTTtBQUNyQixXQUFPO0FBQUEsRUFDVDtBQUNBLGFBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQzVCLFFBQUksVUFBVSxFQUFFLElBQUksR0FBRyxHQUFHO0FBQ3hCLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUNwRCxRQUFNLE9BQU8sU0FBUztBQUN0QixNQUFJLFNBQVMsZUFBZSxVQUFVLFFBQVEsUUFBUSxLQUFLLFNBQVMsWUFBWSxLQUFLLFNBQVMsU0FBUyxLQUFLLElBQUk7QUFDOUcsVUFBTSxVQUFVLFNBQVMsV0FBVztBQUNwQyxlQUFXLE9BQU8sU0FBUztBQUN6QixZQUFNLFFBQVEscUJBQXFCLFFBQVEsR0FBRyxDQUFDO0FBQy9DLGtCQUFZLElBQUksS0FBSyxxQkFBcUIsS0FBSyxLQUFLLENBQUMsSUFBSSxLQUFLO0FBQUEsSUFDaEU7QUFBQSxFQUNGO0FBQ0EsTUFBSSxVQUFVLFFBQVEsU0FBUyxRQUFRO0FBQ3JDLG1CQUFlLFNBQVMsUUFBUSxTQUFTLE9BQU8sV0FBVztBQUFBLEVBQzdEO0FBQ0Y7QUFDQSxNQUFNLG9CQUFvQjtBQUMxQixNQUFNLHFCQUFxQjtBQUFBLEVBQ3pCO0FBQUEsSUFBQztBQUFBO0FBQUEsRUFBWSxHQUFHO0FBQUEsRUFDaEI7QUFBQSxJQUFDO0FBQUE7QUFBQSxFQUFnQixHQUFHO0FBQUEsRUFDcEI7QUFBQSxJQUFDO0FBQUE7QUFBQSxFQUFhLEdBQUc7QUFBQSxFQUNqQjtBQUFBLElBQUM7QUFBQTtBQUFBLEVBQWEsR0FBRztBQUFBLEVBQ2pCO0FBQUEsSUFBQztBQUFBO0FBQUEsRUFBaUIsR0FBRztBQUN2QjtBQUNBLFNBQVMsa0JBQWtCLElBQUksYUFBYTtBQUMxQyxNQUFJLGdCQUFnQixLQUFnQixnQkFBZ0IsR0FBa0I7QUFDcEUsV0FBTyxNQUFNLENBQUMsR0FBRyxhQUFhLGlCQUFpQixHQUFHO0FBQ2hELFdBQUssR0FBRztBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsTUFBTSxHQUFHLGFBQWEsaUJBQWlCO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHdCQUF3QixhQUFhLGFBQWE7QUFDekQsTUFBSSxlQUFlLE1BQU07QUFDdkIsV0FBTztBQUFBLEVBQ1QsV0FBVyxnQkFBZ0IsSUFBSTtBQUM3QixXQUFPO0FBQUEsRUFDVCxPQUFPO0FBQ0wsVUFBTSxPQUFPLFlBQVksTUFBTSxHQUFHO0FBQ2xDLFFBQUksZ0JBQWdCLEtBQWdCLEtBQUssU0FBUyxVQUFVLEdBQUc7QUFDN0QsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLEtBQUssU0FBUyxtQkFBbUIsV0FBVyxDQUFDO0FBQUEsRUFDdEQ7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLE1BQU0sT0FBTztBQUMxQyxTQUFPO0FBQUEsSUFBa0IsS0FBSztBQUFBLElBQWU7QUFBQTtBQUFBLEVBQWdCLEtBQUssd0JBQXdCLElBQUksS0FBSyx5QkFBeUIsS0FBSztBQUNuSTtBQUNBLFNBQVMsd0JBQXdCLE1BQU07QUFDckMsU0FBTyxLQUFLLGFBQWEsS0FBSztBQUFBLElBQzVCLEtBQUssYUFBYSxpQkFBaUI7QUFBQSxJQUNuQztBQUFBO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyx5QkFBeUIsRUFBRSxNQUFNLEdBQUc7QUFDM0MsUUFBTSxjQUFjLFNBQVMsTUFBTSxpQkFBaUI7QUFDcEQsU0FBTyxPQUFPLGdCQUFnQixZQUFZO0FBQUEsSUFBd0I7QUFBQSxJQUFhO0FBQUE7QUFBQSxFQUFnQjtBQUNqRztBQUVBLE1BQU0sc0JBQXNCLGNBQWMsRUFBRSx3QkFBd0IsQ0FBQyxPQUFPLFdBQVcsSUFBSSxDQUFDO0FBQzVGLE1BQU0scUJBQXFCLGNBQWMsRUFBRSx1QkFBdUIsQ0FBQyxPQUFPLGFBQWEsRUFBRTtBQUN6RixNQUFNLGdCQUFnQixDQUFDLFVBQVUsUUFBUSxDQUFDLFlBQVk7QUFDcEQsUUFBTSxLQUFLLG9CQUFvQixTQUFTLEVBQUUsUUFBUSxDQUFDO0FBQ25ELFNBQU8sTUFBTSxtQkFBbUIsRUFBRTtBQUNwQztBQUNBLFNBQVMsMkJBQTJCLElBQUk7QUFDdEMsUUFBTSxFQUFFLEtBQUssTUFBTSxRQUFRLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUM5RCxRQUFNLEVBQUUsYUFBYSxXQUFXLElBQUk7QUFDcEMsVUFBUSxNQUFNLEtBQUssTUFBTSxlQUFlLFNBQVMsS0FBSyxTQUFTLGlCQUFpQixPQUFPLEtBQUssT0FBTyxjQUFjLFFBQVEsS0FBSyxRQUFRO0FBQ3hJO0FBQ0EsTUFBTSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsU0FBUyxZQUFZO0FBQ3ZELFFBQU0sS0FBSyxJQUFJLHFCQUFxQixDQUFDLFlBQVk7QUFDL0MsZUFBVyxLQUFLLFNBQVM7QUFDdkIsVUFBSSxDQUFDLEVBQUUsZUFBZ0I7QUFDdkIsU0FBRyxXQUFXO0FBQ2QsY0FBUTtBQUNSO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxJQUFJO0FBQ1AsVUFBUSxDQUFDLE9BQU87QUFDZCxRQUFJLEVBQUUsY0FBYyxTQUFVO0FBQzlCLFFBQUksMkJBQTJCLEVBQUUsR0FBRztBQUNsQyxjQUFRO0FBQ1IsU0FBRyxXQUFXO0FBQ2QsYUFBTztBQUFBLElBQ1Q7QUFDQSxPQUFHLFFBQVEsRUFBRTtBQUFBLEVBQ2YsQ0FBQztBQUNELFNBQU8sTUFBTSxHQUFHLFdBQVc7QUFDN0I7QUFDQSxNQUFNLHNCQUFzQixDQUFDLFVBQVUsQ0FBQyxZQUFZO0FBQ2xELE1BQUksT0FBTztBQUNULFVBQU0sTUFBTSxXQUFXLEtBQUs7QUFDNUIsUUFBSSxJQUFJLFNBQVM7QUFDZixjQUFRO0FBQUEsSUFDVixPQUFPO0FBQ0wsVUFBSSxpQkFBaUIsVUFBVSxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDdEQsYUFBTyxNQUFNLElBQUksb0JBQW9CLFVBQVUsT0FBTztBQUFBLElBQ3hEO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSx1QkFBdUIsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFNBQVMsWUFBWTtBQUN4RSxNQUFJLFNBQVMsWUFBWSxFQUFHLGdCQUFlLENBQUMsWUFBWTtBQUN4RCxNQUFJLGNBQWM7QUFDbEIsUUFBTSxZQUFZLENBQUMsTUFBTTtBQUN2QixRQUFJLENBQUMsYUFBYTtBQUNoQixvQkFBYztBQUNkLGVBQVM7QUFDVCxjQUFRO0FBQ1IsUUFBRSxPQUFPLGNBQWMsSUFBSSxFQUFFLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQztBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUNBLFFBQU0sV0FBVyxNQUFNO0FBQ3JCLFlBQVEsQ0FBQyxPQUFPO0FBQ2QsaUJBQVcsS0FBSyxjQUFjO0FBQzVCLFdBQUcsb0JBQW9CLEdBQUcsU0FBUztBQUFBLE1BQ3JDO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFVBQVEsQ0FBQyxPQUFPO0FBQ2QsZUFBVyxLQUFLLGNBQWM7QUFDNUIsU0FBRyxpQkFBaUIsR0FBRyxXQUFXLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0YsQ0FBQztBQUNELFNBQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxNQUFNLElBQUk7QUFDaEMsTUFBSSxVQUFVLElBQUksS0FBSyxLQUFLLFNBQVMsS0FBSztBQUN4QyxRQUFJLFFBQVE7QUFDWixRQUFJLE9BQU8sS0FBSztBQUNoQixXQUFPLE1BQU07QUFDWCxVQUFJLEtBQUssYUFBYSxHQUFHO0FBQ3ZCLGNBQU0sU0FBUyxHQUFHLElBQUk7QUFDdEIsWUFBSSxXQUFXLE9BQU87QUFDcEI7QUFBQSxRQUNGO0FBQUEsTUFDRixXQUFXLFVBQVUsSUFBSSxHQUFHO0FBQzFCLFlBQUksS0FBSyxTQUFTLEtBQUs7QUFDckIsY0FBSSxFQUFFLFVBQVUsRUFBRztBQUFBLFFBQ3JCLFdBQVcsS0FBSyxTQUFTLEtBQUs7QUFDNUI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFBQSxFQUNGLE9BQU87QUFDTCxPQUFHLElBQUk7QUFBQSxFQUNUO0FBQ0Y7QUFFQSxNQUFNLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSztBQUFBO0FBRXZDLFNBQVMscUJBQXFCLFFBQVE7QUFDcEMsTUFBSSxXQUFXLE1BQU0sR0FBRztBQUN0QixhQUFTLEVBQUUsUUFBUSxPQUFPO0FBQUEsRUFDNUI7QUFDQSxRQUFNO0FBQUEsSUFDSjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxRQUFRO0FBQUEsSUFDUixTQUFTO0FBQUEsSUFDVDtBQUFBO0FBQUEsSUFFQSxjQUFjO0FBQUEsSUFDZCxTQUFTO0FBQUEsRUFDWCxJQUFJO0FBQ0osTUFBSSxpQkFBaUI7QUFDckIsTUFBSTtBQUNKLE1BQUksVUFBVTtBQUNkLFFBQU0sUUFBUSxNQUFNO0FBQ2xCO0FBQ0EscUJBQWlCO0FBQ2pCLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxRQUFNLE9BQU8sTUFBTTtBQUNqQixRQUFJO0FBQ0osV0FBTyxtQkFBbUIsY0FBYyxpQkFBaUIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQy9FLFlBQU0sZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDO0FBQ3hELFVBQUksYUFBYTtBQUNmLGVBQU8sSUFBSSxRQUFRLENBQUNHLFVBQVMsV0FBVztBQUN0QyxnQkFBTSxZQUFZLE1BQU1BLFNBQVEsTUFBTSxDQUFDO0FBQ3ZDLGdCQUFNLFdBQVcsTUFBTSxPQUFPLEdBQUc7QUFDakMsc0JBQVksS0FBSyxXQUFXLFVBQVUsVUFBVSxDQUFDO0FBQUEsUUFDbkQsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRixDQUFDLEVBQUUsS0FBSyxDQUFDLFNBQVM7QUFDaEIsVUFBSSxnQkFBZ0Isa0JBQWtCLGdCQUFnQjtBQUNwRCxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQWlELENBQUMsTUFBTTtBQUN0RDtBQUFBLFVBQ0U7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFVBQUksU0FBUyxLQUFLLGNBQWMsS0FBSyxPQUFPLFdBQVcsTUFBTSxXQUFXO0FBQ3RFLGVBQU8sS0FBSztBQUFBLE1BQ2Q7QUFDQSxVQUFpRCxRQUFRLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxXQUFXLElBQUksR0FBRztBQUM3RixjQUFNLElBQUksTUFBTSx3Q0FBd0MsSUFBSSxFQUFFO0FBQUEsTUFDaEU7QUFDQSxxQkFBZTtBQUNmLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBQ0EsU0FBTyxnQ0FBZ0I7QUFBQSxJQUNyQixNQUFNO0FBQUEsSUFDTixlQUFlO0FBQUEsSUFDZixlQUFlLElBQUksVUFBVSxTQUFTO0FBQ3BDLFlBQU0sZUFBZSxHQUFHO0FBQ3hCLFVBQUksVUFBVTtBQUNkLE9BQUMsU0FBUyxPQUFPLFNBQVMsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNLFVBQVUsSUFBSTtBQUM3RCxZQUFNLGlCQUFpQixNQUFNO0FBQzNCLFlBQUksU0FBUztBQUNYLGNBQUksTUFBMkM7QUFDN0M7QUFBQSxjQUNFLDBDQUEwQyxpQkFBaUIsWUFBWSxLQUFLLGFBQWEsTUFBTTtBQUFBLFlBQ2pHO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyxHQUFHLGNBQWMsZ0JBQWdCLENBQUMsR0FBRyxZQUFhO0FBQ3ZELGdCQUFRO0FBQUEsTUFDVjtBQUNBLFlBQU0sWUFBWSxrQkFBa0IsTUFBTTtBQUN4QyxjQUFNLFdBQVc7QUFBQSxVQUNmO0FBQUEsVUFDQSxDQUFDLE9BQU8sZUFBZSxJQUFJLEVBQUU7QUFBQSxRQUMvQjtBQUNBLFlBQUksVUFBVTtBQUNaLFdBQUMsU0FBUyxRQUFRLFNBQVMsTUFBTSxDQUFDLElBQUksS0FBSyxRQUFRO0FBQUEsUUFDckQ7QUFBQSxNQUNGLElBQUk7QUFDSixVQUFJLGNBQWM7QUFDaEIsa0JBQVU7QUFBQSxNQUNaLE9BQU87QUFDTCxhQUFLLEVBQUUsS0FBSyxNQUFNLENBQUMsU0FBUyxlQUFlLFVBQVUsQ0FBQztBQUFBLE1BQ3hEO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxrQkFBa0I7QUFDcEIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLFFBQVE7QUFDTixZQUFNLFdBQVc7QUFDakIsd0JBQWtCLFFBQVE7QUFDMUIsVUFBSSxjQUFjO0FBQ2hCLGVBQU8sTUFBTSxnQkFBZ0IsY0FBYyxRQUFRO0FBQUEsTUFDckQ7QUFDQSxZQUFNLFVBQVUsQ0FBQyxRQUFRO0FBQ3ZCLHlCQUFpQjtBQUNqQjtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQ0EsVUFBSSxlQUFlLFNBQVMsWUFBWSx1QkFBdUI7QUFDN0QsZUFBTyxLQUFLLEVBQUUsS0FBSyxDQUFDLFNBQVM7QUFDM0IsaUJBQU8sTUFBTSxnQkFBZ0IsTUFBTSxRQUFRO0FBQUEsUUFDN0MsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ2hCLGtCQUFRLEdBQUc7QUFDWCxpQkFBTyxNQUFNLGlCQUFpQixZQUFZLGdCQUFnQjtBQUFBLFlBQ3hELE9BQU87QUFBQSxVQUNULENBQUMsSUFBSTtBQUFBLFFBQ1AsQ0FBQztBQUFBLE1BQ0g7QUFDQSxZQUFNLFNBQVMsSUFBSSxLQUFLO0FBQ3hCLFlBQU0sUUFBUSxJQUFJO0FBQ2xCLFlBQU0sVUFBVSxJQUFJLENBQUMsQ0FBQyxLQUFLO0FBQzNCLFVBQUk7QUFDSixVQUFJO0FBQ0osa0JBQVksTUFBTTtBQUNoQixZQUFJLGdCQUFnQixLQUFNLGNBQWEsWUFBWTtBQUNuRCxZQUFJLGNBQWMsS0FBTSxjQUFhLFVBQVU7QUFBQSxNQUNqRCxDQUFDO0FBQ0QsVUFBSSxPQUFPO0FBQ1QscUJBQWEsV0FBVyxNQUFNO0FBQzVCLGNBQUksU0FBUyxZQUFhO0FBQzFCLGtCQUFRLFFBQVE7QUFBQSxRQUNsQixHQUFHLEtBQUs7QUFBQSxNQUNWO0FBQ0EsVUFBSSxXQUFXLE1BQU07QUFDbkIsdUJBQWUsV0FBVyxNQUFNO0FBQzlCLGNBQUksU0FBUyxZQUFhO0FBQzFCLGNBQUksQ0FBQyxPQUFPLFNBQVMsQ0FBQyxNQUFNLE9BQU87QUFDakMsa0JBQU0sTUFBTSxJQUFJO0FBQUEsY0FDZCxtQ0FBbUMsT0FBTztBQUFBLFlBQzVDO0FBQ0Esb0JBQVEsR0FBRztBQUNYLGtCQUFNLFFBQVE7QUFBQSxVQUNoQjtBQUFBLFFBQ0YsR0FBRyxPQUFPO0FBQUEsTUFDWjtBQUNBLFdBQUssRUFBRSxLQUFLLE1BQU07QUFDaEIsWUFBSSxTQUFTLFlBQWE7QUFDMUIsZUFBTyxRQUFRO0FBQ2YsWUFBSSxTQUFTLFVBQVUsWUFBWSxTQUFTLE9BQU8sS0FBSyxHQUFHO0FBQ3pELG1CQUFTLE9BQU8sT0FBTztBQUFBLFFBQ3pCO0FBQUEsTUFDRixDQUFDLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDaEIsWUFBSSxTQUFTLGFBQWE7QUFDeEIsMkJBQWlCO0FBQ2pCO0FBQUEsUUFDRjtBQUNBLGdCQUFRLEdBQUc7QUFDWCxjQUFNLFFBQVE7QUFBQSxNQUNoQixDQUFDO0FBQ0QsYUFBTyxNQUFNO0FBQ1gsWUFBSSxPQUFPLFNBQVMsY0FBYztBQUNoQyxpQkFBTyxnQkFBZ0IsY0FBYyxRQUFRO0FBQUEsUUFDL0MsV0FBVyxNQUFNLFNBQVMsZ0JBQWdCO0FBQ3hDLGlCQUFPLFlBQVksZ0JBQWdCO0FBQUEsWUFDakMsT0FBTyxNQUFNO0FBQUEsVUFDZixDQUFDO0FBQUEsUUFDSCxXQUFXLG9CQUFvQixDQUFDLFFBQVEsT0FBTztBQUM3QyxpQkFBTztBQUFBLFlBQ0w7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxRQUFRO0FBQ3JDLFFBQU0sRUFBRSxLQUFLRCxPQUFNLE9BQU8sVUFBVSxHQUFHLElBQUksT0FBTztBQUNsRCxRQUFNLFFBQVEsWUFBWSxNQUFNLE9BQU8sUUFBUTtBQUMvQyxRQUFNLE1BQU1BO0FBQ1osUUFBTSxLQUFLO0FBQ1gsU0FBTyxPQUFPLE1BQU07QUFDcEIsU0FBTztBQUNUO0FBRUEsTUFBTSxjQUFjLENBQUMsVUFBVSxNQUFNLEtBQUs7QUFDMUMsTUFBTSxnQkFBZ0I7QUFBQSxFQUNwQixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJTixlQUFlO0FBQUEsRUFDZixPQUFPO0FBQUEsSUFDTCxTQUFTLENBQUMsUUFBUSxRQUFRLEtBQUs7QUFBQSxJQUMvQixTQUFTLENBQUMsUUFBUSxRQUFRLEtBQUs7QUFBQSxJQUMvQixLQUFLLENBQUMsUUFBUSxNQUFNO0FBQUEsRUFDdEI7QUFBQSxFQUNBLE1BQU0sT0FBTyxFQUFFLE1BQU0sR0FBRztBQUN0QixVQUFNLFdBQVcsbUJBQW1CO0FBQ3BDLFVBQU0sZ0JBQWdCLFNBQVM7QUFDL0IsUUFBSSxDQUFDLGNBQWMsVUFBVTtBQUMzQixhQUFPLE1BQU07QUFDWCxjQUFNLFdBQVcsTUFBTSxXQUFXLE1BQU0sUUFBUTtBQUNoRCxlQUFPLFlBQVksU0FBUyxXQUFXLElBQUksU0FBUyxDQUFDLElBQUk7QUFBQSxNQUMzRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFFBQXdCLG9CQUFJLElBQUk7QUFDdEMsVUFBTSxPQUF1QixvQkFBSSxJQUFJO0FBQ3JDLFFBQUksVUFBVTtBQUNkLFFBQUksTUFBb0U7QUFDdEUsZUFBUyxZQUFZO0FBQUEsSUFDdkI7QUFDQSxVQUFNLGlCQUFpQixTQUFTO0FBQ2hDLFVBQU07QUFBQSxNQUNKLFVBQVU7QUFBQSxRQUNSLEdBQUc7QUFBQSxRQUNILEdBQUc7QUFBQSxRQUNILElBQUk7QUFBQSxRQUNKLEdBQUcsRUFBRSxjQUFjO0FBQUEsTUFDckI7QUFBQSxJQUNGLElBQUk7QUFDSixVQUFNLG1CQUFtQixjQUFjLEtBQUs7QUFDNUMsa0JBQWMsV0FBVyxDQUFDLE9BQU8sV0FBVyxRQUFRLFdBQVcsY0FBYztBQUMzRSxZQUFNLFlBQVksTUFBTTtBQUN4QixXQUFLLE9BQU8sV0FBVyxRQUFRLEdBQUcsY0FBYztBQUNoRDtBQUFBLFFBQ0UsVUFBVTtBQUFBLFFBQ1Y7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsTUFBTTtBQUFBLFFBQ047QUFBQSxNQUNGO0FBQ0EsNEJBQXNCLE1BQU07QUFDMUIsa0JBQVUsZ0JBQWdCO0FBQzFCLFlBQUksVUFBVSxHQUFHO0FBQ2YseUJBQWUsVUFBVSxDQUFDO0FBQUEsUUFDNUI7QUFDQSxjQUFNLFlBQVksTUFBTSxTQUFTLE1BQU0sTUFBTTtBQUM3QyxZQUFJLFdBQVc7QUFDYiwwQkFBZ0IsV0FBVyxVQUFVLFFBQVEsS0FBSztBQUFBLFFBQ3BEO0FBQUEsTUFDRixHQUFHLGNBQWM7QUFDakIsVUFBSSxNQUFvRTtBQUN0RSwrQkFBdUIsU0FBUztBQUFBLE1BQ2xDO0FBQUEsSUFDRjtBQUNBLGtCQUFjLGFBQWEsQ0FBQyxVQUFVO0FBQ3BDLFlBQU0sWUFBWSxNQUFNO0FBQ3hCLHNCQUFnQixVQUFVLENBQUM7QUFDM0Isc0JBQWdCLFVBQVUsQ0FBQztBQUMzQixXQUFLLE9BQU8sa0JBQWtCLE1BQU0sR0FBRyxjQUFjO0FBQ3JELDRCQUFzQixNQUFNO0FBQzFCLFlBQUksVUFBVSxJQUFJO0FBQ2hCLHlCQUFlLFVBQVUsRUFBRTtBQUFBLFFBQzdCO0FBQ0EsY0FBTSxZQUFZLE1BQU0sU0FBUyxNQUFNLE1BQU07QUFDN0MsWUFBSSxXQUFXO0FBQ2IsMEJBQWdCLFdBQVcsVUFBVSxRQUFRLEtBQUs7QUFBQSxRQUNwRDtBQUNBLGtCQUFVLGdCQUFnQjtBQUFBLE1BQzVCLEdBQUcsY0FBYztBQUNqQixVQUFJLE1BQW9FO0FBQ3RFLCtCQUF1QixTQUFTO0FBQUEsTUFDbEM7QUFDQSxVQUFpRCxNQUFNO0FBQ3JELGtCQUFVLDhCQUE4QjtBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUNBLGFBQVMsUUFBUSxPQUFPO0FBQ3RCLHFCQUFlLEtBQUs7QUFDcEIsZUFBUyxPQUFPLFVBQVUsZ0JBQWdCLElBQUk7QUFBQSxJQUNoRDtBQUNBLGFBQVMsV0FBVyxRQUFRO0FBQzFCLFlBQU0sUUFBUSxDQUFDLE9BQU8sUUFBUTtBQUM1QixjQUFNLE9BQU87QUFBQSxVQUNYLGVBQWUsS0FBSyxJQUFJLE1BQU0sS0FBSyxtQkFBbUIsQ0FBQyxJQUFJLE1BQU07QUFBQSxRQUNuRTtBQUNBLFlBQUksUUFBUSxDQUFDLE9BQU8sSUFBSSxHQUFHO0FBQ3pCLDBCQUFnQixHQUFHO0FBQUEsUUFDckI7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQ0EsYUFBUyxnQkFBZ0IsS0FBSztBQUM1QixZQUFNLFNBQVMsTUFBTSxJQUFJLEdBQUc7QUFDNUIsVUFBSSxXQUFXLENBQUMsV0FBVyxDQUFDLGdCQUFnQixRQUFRLE9BQU8sSUFBSTtBQUM3RCxnQkFBUSxNQUFNO0FBQUEsTUFDaEIsV0FBVyxTQUFTO0FBQ2xCLHVCQUFlLE9BQU87QUFBQSxNQUN4QjtBQUNBLFlBQU0sT0FBTyxHQUFHO0FBQ2hCLFdBQUssT0FBTyxHQUFHO0FBQUEsSUFDakI7QUFDQTtBQUFBLE1BQ0UsTUFBTSxDQUFDLE1BQU0sU0FBUyxNQUFNLE9BQU87QUFBQSxNQUNuQyxDQUFDLENBQUMsU0FBUyxPQUFPLE1BQU07QUFDdEIsbUJBQVcsV0FBVyxDQUFDLFNBQVMsUUFBUSxTQUFTLElBQUksQ0FBQztBQUN0RCxtQkFBVyxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsU0FBUyxJQUFJLENBQUM7QUFBQSxNQUN6RDtBQUFBO0FBQUEsTUFFQSxFQUFFLE9BQU8sUUFBUSxNQUFNLEtBQUs7QUFBQSxJQUM5QjtBQUNBLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sZUFBZSxNQUFNO0FBQ3pCLFVBQUksbUJBQW1CLE1BQU07QUFDM0IsWUFBSSxXQUFXLFNBQVMsUUFBUSxJQUFJLEdBQUc7QUFDckMsZ0NBQXNCLE1BQU07QUFDMUIsa0JBQU0sSUFBSSxpQkFBaUIsY0FBYyxTQUFTLE9BQU8sQ0FBQztBQUFBLFVBQzVELEdBQUcsU0FBUyxRQUFRLFFBQVE7QUFBQSxRQUM5QixPQUFPO0FBQ0wsZ0JBQU0sSUFBSSxpQkFBaUIsY0FBYyxTQUFTLE9BQU8sQ0FBQztBQUFBLFFBQzVEO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxjQUFVLFlBQVk7QUFDdEIsY0FBVSxZQUFZO0FBQ3RCLG9CQUFnQixNQUFNO0FBQ3BCLFlBQU0sUUFBUSxDQUFDLFdBQVc7QUFDeEIsY0FBTSxFQUFFLFNBQVMsU0FBUyxJQUFJO0FBQzlCLGNBQU0sUUFBUSxjQUFjLE9BQU87QUFDbkMsWUFBSSxPQUFPLFNBQVMsTUFBTSxRQUFRLE9BQU8sUUFBUSxNQUFNLEtBQUs7QUFDMUQseUJBQWUsS0FBSztBQUNwQixnQkFBTSxLQUFLLE1BQU0sVUFBVTtBQUMzQixnQkFBTSxzQkFBc0IsSUFBSSxRQUFRO0FBQ3hDO0FBQUEsUUFDRjtBQUNBLGdCQUFRLE1BQU07QUFBQSxNQUNoQixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQ0QsV0FBTyxNQUFNO0FBQ1gsd0JBQWtCO0FBQ2xCLFVBQUksQ0FBQyxNQUFNLFNBQVM7QUFDbEIsZUFBTyxVQUFVO0FBQUEsTUFDbkI7QUFDQSxZQUFNLFdBQVcsTUFBTSxRQUFRO0FBQy9CLFlBQU0sV0FBVyxTQUFTLENBQUM7QUFDM0IsVUFBSSxTQUFTLFNBQVMsR0FBRztBQUN2QixZQUFJLE1BQTJDO0FBQzdDLGlCQUFPLHVEQUF1RDtBQUFBLFFBQ2hFO0FBQ0Esa0JBQVU7QUFDVixlQUFPO0FBQUEsTUFDVCxXQUFXLENBQUMsUUFBUSxRQUFRLEtBQUssRUFBRSxTQUFTLFlBQVksTUFBTSxFQUFFLFNBQVMsWUFBWSxNQUFNO0FBQ3pGLGtCQUFVO0FBQ1YsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsY0FBYyxRQUFRO0FBQ2xDLFVBQUksTUFBTSxTQUFTLFNBQVM7QUFDMUIsa0JBQVU7QUFDVixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sT0FBTyxNQUFNO0FBQ25CLFlBQU0sT0FBTztBQUFBLFFBQ1gsZUFBZSxLQUFLLElBQUksTUFBTSxLQUFLLG1CQUFtQixDQUFDLElBQUk7QUFBQSxNQUM3RDtBQUNBLFlBQU0sRUFBRSxTQUFTLFNBQVMsSUFBSSxJQUFJO0FBQ2xDLFVBQUksWUFBWSxDQUFDLFFBQVEsQ0FBQyxRQUFRLFNBQVMsSUFBSSxNQUFNLFdBQVcsUUFBUSxRQUFRLFNBQVMsSUFBSSxHQUFHO0FBQzlGLGNBQU0sYUFBYTtBQUNuQixrQkFBVTtBQUNWLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLE9BQU8sTUFBTTtBQUM3QyxZQUFNLGNBQWMsTUFBTSxJQUFJLEdBQUc7QUFDakMsVUFBSSxNQUFNLElBQUk7QUFDWixnQkFBUSxXQUFXLEtBQUs7QUFDeEIsWUFBSSxTQUFTLFlBQVksS0FBSztBQUM1QixtQkFBUyxZQUFZO0FBQUEsUUFDdkI7QUFBQSxNQUNGO0FBQ0Esd0JBQWtCO0FBQ2xCLFVBQUksYUFBYTtBQUNmLGNBQU0sS0FBSyxZQUFZO0FBQ3ZCLGNBQU0sWUFBWSxZQUFZO0FBQzlCLFlBQUksTUFBTSxZQUFZO0FBQ3BCLDZCQUFtQixPQUFPLE1BQU0sVUFBVTtBQUFBLFFBQzVDO0FBQ0EsY0FBTSxhQUFhO0FBQ25CLGFBQUssT0FBTyxHQUFHO0FBQ2YsYUFBSyxJQUFJLEdBQUc7QUFBQSxNQUNkLE9BQU87QUFDTCxhQUFLLElBQUksR0FBRztBQUNaLFlBQUksT0FBTyxLQUFLLE9BQU8sU0FBUyxLQUFLLEVBQUUsR0FBRztBQUN4QywwQkFBZ0IsS0FBSyxPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUs7QUFBQSxRQUM1QztBQUFBLE1BQ0Y7QUFDQSxZQUFNLGFBQWE7QUFDbkIsZ0JBQVU7QUFDVixhQUFPLFdBQVcsU0FBUyxJQUFJLElBQUksV0FBVztBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxZQUFZO0FBQ2xCLFNBQVMsUUFBUSxTQUFTLE1BQU07QUFDOUIsTUFBSSxRQUFRLE9BQU8sR0FBRztBQUNwQixXQUFPLFFBQVEsS0FBSyxDQUFDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQztBQUFBLEVBQzdDLFdBQVcsU0FBUyxPQUFPLEdBQUc7QUFDNUIsV0FBTyxRQUFRLE1BQU0sR0FBRyxFQUFFLFNBQVMsSUFBSTtBQUFBLEVBQ3pDLFdBQVcsU0FBUyxPQUFPLEdBQUc7QUFDNUIsWUFBUSxZQUFZO0FBQ3BCLFdBQU8sUUFBUSxLQUFLLElBQUk7QUFBQSxFQUMxQjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsWUFBWSxNQUFNLFFBQVE7QUFDakMsd0JBQXNCLE1BQU0sS0FBSyxNQUFNO0FBQ3pDO0FBQ0EsU0FBUyxjQUFjLE1BQU0sUUFBUTtBQUNuQyx3QkFBc0IsTUFBTSxNQUFNLE1BQU07QUFDMUM7QUFDQSxTQUFTLHNCQUFzQixNQUFNLE1BQU0sU0FBUyxpQkFBaUI7QUFDbkUsUUFBTSxjQUFjLEtBQUssVUFBVSxLQUFLLFFBQVEsTUFBTTtBQUNwRCxRQUFJLFVBQVU7QUFDZCxXQUFPLFNBQVM7QUFDZCxVQUFJLFFBQVEsZUFBZTtBQUN6QjtBQUFBLE1BQ0Y7QUFDQSxnQkFBVSxRQUFRO0FBQUEsSUFDcEI7QUFDQSxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsYUFBVyxNQUFNLGFBQWEsTUFBTTtBQUNwQyxNQUFJLFFBQVE7QUFDVixRQUFJLFVBQVUsT0FBTztBQUNyQixXQUFPLFdBQVcsUUFBUSxRQUFRO0FBQ2hDLFVBQUksWUFBWSxRQUFRLE9BQU8sS0FBSyxHQUFHO0FBQ3JDLDhCQUFzQixhQUFhLE1BQU0sUUFBUSxPQUFPO0FBQUEsTUFDMUQ7QUFDQSxnQkFBVSxRQUFRO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQixNQUFNLE1BQU0sUUFBUSxlQUFlO0FBQ2hFLFFBQU0sV0FBVztBQUFBLElBQ2Y7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQTtBQUFBLEVBRUY7QUFDQSxjQUFZLE1BQU07QUFDaEIsV0FBTyxjQUFjLElBQUksR0FBRyxRQUFRO0FBQUEsRUFDdEMsR0FBRyxNQUFNO0FBQ1g7QUFDQSxTQUFTLGVBQWUsT0FBTztBQUM3QixRQUFNLGFBQWE7QUFDbkIsUUFBTSxhQUFhO0FBQ3JCO0FBQ0EsU0FBUyxjQUFjLE9BQU87QUFDNUIsU0FBTyxNQUFNLFlBQVksTUFBTSxNQUFNLFlBQVk7QUFDbkQ7QUFFQSxTQUFTLFdBQVcsTUFBTSxNQUFNLFNBQVMsaUJBQWlCLFVBQVUsT0FBTztBQUN6RSxNQUFJLFFBQVE7QUFDVixVQUFNLFFBQVEsT0FBTyxJQUFJLE1BQU0sT0FBTyxJQUFJLElBQUksQ0FBQztBQUMvQyxVQUFNLGNBQWMsS0FBSyxVQUFVLEtBQUssUUFBUSxJQUFJLFNBQVM7QUFDM0Qsb0JBQWM7QUFDZCxZQUFNLFFBQVEsbUJBQW1CLE1BQU07QUFDdkMsWUFBTSxNQUFNLDJCQUEyQixNQUFNLFFBQVEsTUFBTSxJQUFJO0FBQy9ELFlBQU07QUFDTixvQkFBYztBQUNkLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxTQUFTO0FBQ1gsWUFBTSxRQUFRLFdBQVc7QUFBQSxJQUMzQixPQUFPO0FBQ0wsWUFBTSxLQUFLLFdBQVc7QUFBQSxJQUN4QjtBQUNBLFdBQU87QUFBQSxFQUNULFdBQVcsTUFBMkM7QUFDcEQsVUFBTSxVQUFVLGFBQWEsbUJBQW1CLElBQUksRUFBRSxRQUFRLFVBQVUsRUFBRSxDQUFDO0FBQzNFO0FBQUEsTUFDRSxHQUFHLE9BQU87QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxhQUFhLENBQUMsY0FBYyxDQUFDLE1BQU0sU0FBUyxvQkFBb0I7QUFDcEUsTUFBSSxDQUFDLHlCQUF5QixjQUFjLE1BQU07QUFDaEQsZUFBVyxXQUFXLElBQUksU0FBUyxLQUFLLEdBQUcsSUFBSSxHQUFHLE1BQU07QUFBQSxFQUMxRDtBQUNGO0FBQ0EsTUFBTSxnQkFBZ0IsV0FBVyxJQUFJO0FBQ3JDLE1BQU0sWUFBWSxXQUFXLEdBQUc7QUFDaEMsTUFBTSxpQkFBaUI7QUFBQSxFQUNyQjtBQUNGO0FBQ0EsTUFBTSxZQUFZLFdBQVcsR0FBRztBQUNoQyxNQUFNLGtCQUFrQjtBQUFBLEVBQ3RCO0FBQ0Y7QUFDQSxNQUFNLGNBQWMsV0FBVyxJQUFJO0FBQ25DLE1BQU0sbUJBQW1CO0FBQUEsRUFDdkI7QUFDRjtBQUNBLE1BQU0sb0JBQW9CLFdBQVcsS0FBSztBQUMxQyxNQUFNLGtCQUFrQixXQUFXLEtBQUs7QUFDeEMsU0FBUyxnQkFBZ0IsTUFBTSxTQUFTLGlCQUFpQjtBQUN2RCxhQUFXLE1BQU0sTUFBTSxNQUFNO0FBQy9CO0FBRUEsTUFBTSxhQUFhO0FBQ25CLE1BQU0sYUFBYTtBQUNuQixTQUFTLGlCQUFpQixNQUFNLG9CQUFvQjtBQUNsRCxTQUFPLGFBQWEsWUFBWSxNQUFNLE1BQU0sa0JBQWtCLEtBQUs7QUFDckU7QUFDQSxNQUFNLHlCQUF5Qyx1QkFBTyxJQUFJLE9BQU87QUFDakUsU0FBUyx3QkFBd0IsV0FBVztBQUMxQyxNQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLFdBQU8sYUFBYSxZQUFZLFdBQVcsS0FBSyxLQUFLO0FBQUEsRUFDdkQsT0FBTztBQUNMLFdBQU8sYUFBYTtBQUFBLEVBQ3RCO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixNQUFNO0FBQzlCLFNBQU8sYUFBYSxZQUFZLElBQUk7QUFDdEM7QUFDQSxTQUFTLGFBQWEsTUFBTSxNQUFNLGNBQWMsTUFBTSxxQkFBcUIsT0FBTztBQUNoRixRQUFNLFdBQVcsNEJBQTRCO0FBQzdDLE1BQUksVUFBVTtBQUNaLFVBQU0sWUFBWSxTQUFTO0FBQzNCLFFBQUksU0FBUyxZQUFZO0FBQ3ZCLFlBQU0sV0FBVztBQUFBLFFBQ2Y7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFVBQUksYUFBYSxhQUFhLFFBQVEsYUFBYSxTQUFTLElBQUksS0FBSyxhQUFhLFdBQVcsU0FBUyxJQUFJLENBQUMsSUFBSTtBQUM3RyxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQSxVQUFNO0FBQUE7QUFBQTtBQUFBLE1BR0osUUFBUSxTQUFTLElBQUksS0FBSyxVQUFVLElBQUksR0FBRyxJQUFJO0FBQUEsTUFDL0MsUUFBUSxTQUFTLFdBQVcsSUFBSSxHQUFHLElBQUk7QUFBQTtBQUV6QyxRQUFJLENBQUMsT0FBTyxvQkFBb0I7QUFDOUIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFpRCxlQUFlLENBQUMsS0FBSztBQUNwRSxZQUFNLFFBQVEsU0FBUyxhQUFhO0FBQUEsOEhBQ29GO0FBQ3hILGFBQU8scUJBQXFCLEtBQUssTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLLElBQUksR0FBRyxLQUFLLEVBQUU7QUFBQSxJQUNsRTtBQUNBLFdBQU87QUFBQSxFQUNULFdBQVcsTUFBMkM7QUFDcEQ7QUFBQSxNQUNFLFVBQVUsV0FBVyxLQUFLLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxRQUFRLFVBQVUsTUFBTTtBQUMvQixTQUFPLGFBQWEsU0FBUyxJQUFJLEtBQUssU0FBUyxTQUFTLElBQUksQ0FBQyxLQUFLLFNBQVMsV0FBVyxTQUFTLElBQUksQ0FBQyxDQUFDO0FBQ3ZHO0FBRUEsU0FBUyxXQUFXLFFBQVEsWUFBWSxPQUFPLE9BQU87QUFDcEQsTUFBSTtBQUNKLFFBQU0sU0FBUyxTQUFTLE1BQU0sS0FBSztBQUNuQyxRQUFNLGdCQUFnQixRQUFRLE1BQU07QUFDcEMsTUFBSSxpQkFBaUIsU0FBUyxNQUFNLEdBQUc7QUFDckMsVUFBTSx3QkFBd0IsaUJBQWlCLFdBQVcsTUFBTTtBQUNoRSxRQUFJLFlBQVk7QUFDaEIsUUFBSSxtQkFBbUI7QUFDdkIsUUFBSSx1QkFBdUI7QUFDekIsa0JBQVksQ0FBQyxVQUFVLE1BQU07QUFDN0IseUJBQW1CLFdBQVcsTUFBTTtBQUNwQyxlQUFTLGlCQUFpQixNQUFNO0FBQUEsSUFDbEM7QUFDQSxVQUFNLElBQUksTUFBTSxPQUFPLE1BQU07QUFDN0IsYUFBUyxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsSUFBSSxHQUFHLEtBQUs7QUFDN0MsVUFBSSxDQUFDLElBQUk7QUFBQSxRQUNQLFlBQVksbUJBQW1CLFdBQVcsV0FBVyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksV0FBVyxPQUFPLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQztBQUFBLFFBQ25HO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxPQUFPLENBQUM7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFBQSxFQUNGLFdBQVcsT0FBTyxXQUFXLFVBQVU7QUFDckMsUUFBa0QsQ0FBQyxPQUFPLFVBQVUsTUFBTSxLQUFLLFNBQVMsR0FBSTtBQUMxRjtBQUFBLFFBQ0UsNERBQTRELE1BQU07QUFBQSxNQUNwRTtBQUNBLFlBQU0sQ0FBQztBQUFBLElBQ1QsT0FBTztBQUNMLFlBQU0sSUFBSSxNQUFNLE1BQU07QUFDdEIsZUFBUyxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7QUFDL0IsWUFBSSxDQUFDLElBQUksV0FBVyxJQUFJLEdBQUcsR0FBRyxRQUFRLFVBQVUsT0FBTyxDQUFDLENBQUM7QUFBQSxNQUMzRDtBQUFBLElBQ0Y7QUFBQSxFQUNGLFdBQVcsU0FBUyxNQUFNLEdBQUc7QUFDM0IsUUFBSSxPQUFPLE9BQU8sUUFBUSxHQUFHO0FBQzNCLFlBQU0sTUFBTTtBQUFBLFFBQ1Y7QUFBQSxRQUNBLENBQUMsTUFBTSxNQUFNLFdBQVcsTUFBTSxHQUFHLFFBQVEsVUFBVSxPQUFPLENBQUMsQ0FBQztBQUFBLE1BQzlEO0FBQUEsSUFDRixPQUFPO0FBQ0wsWUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNO0FBQy9CLFlBQU0sSUFBSSxNQUFNLEtBQUssTUFBTTtBQUMzQixlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLEdBQUcsS0FBSztBQUMzQyxjQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFlBQUksQ0FBQyxJQUFJLFdBQVcsT0FBTyxHQUFHLEdBQUcsS0FBSyxHQUFHLFVBQVUsT0FBTyxDQUFDLENBQUM7QUFBQSxNQUM5RDtBQUFBLElBQ0Y7QUFBQSxFQUNGLE9BQU87QUFDTCxVQUFNLENBQUM7QUFBQSxFQUNUO0FBQ0EsTUFBSSxPQUFPO0FBQ1QsVUFBTSxLQUFLLElBQUk7QUFBQSxFQUNqQjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsWUFBWSxPQUFPLGNBQWM7QUFDeEMsV0FBUyxJQUFJLEdBQUcsSUFBSSxhQUFhLFFBQVEsS0FBSztBQUM1QyxVQUFNLE9BQU8sYUFBYSxDQUFDO0FBQzNCLFFBQUksUUFBUSxJQUFJLEdBQUc7QUFDakIsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztBQUNwQyxjQUFNLEtBQUssQ0FBQyxFQUFFLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRTtBQUFBLE1BQ2hDO0FBQUEsSUFDRixXQUFXLE1BQU07QUFDZixZQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxJQUFJLFNBQVM7QUFDekMsY0FBTSxNQUFNLEtBQUssR0FBRyxHQUFHLElBQUk7QUFDM0IsWUFBSSxJQUFLLEtBQUksTUFBTSxLQUFLO0FBQ3hCLGVBQU87QUFBQSxNQUNULElBQUksS0FBSztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE9BQU8sTUFBTSxPQUFPLFVBQVUsV0FBVyxXQUFXO0FBQ3RFLE1BQUksU0FBUyxLQUFNLFNBQVEsQ0FBQztBQUM1QixNQUFJLHlCQUF5QixNQUFNLHlCQUF5QixVQUFVLGVBQWUseUJBQXlCLE1BQU0sS0FBSyx5QkFBeUIsT0FBTyxJQUFJO0FBQzNKLFVBQU0sWUFBWSxhQUFhLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsT0FBTyxFQUFFLEtBQUssVUFBVSxDQUFDLElBQUk7QUFDbkcsVUFBTSxXQUFXLE9BQU8sS0FBSyxTQUFTLEVBQUUsU0FBUztBQUNqRCxRQUFJLFNBQVMsVUFBVyxXQUFVLE9BQU87QUFDekMsV0FBTyxVQUFVLEdBQUc7QUFBQSxNQUNsQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLENBQUMsWUFBWSxRQUFRLFdBQVcsWUFBWSxTQUFTLENBQUMsQ0FBQztBQUFBLE1BQ3ZELFdBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUNBLE1BQUksT0FBTyxNQUFNLElBQUk7QUFDckIsTUFBaUQsUUFBUSxLQUFLLFNBQVMsR0FBRztBQUN4RTtBQUFBLE1BQ0U7QUFBQSxJQUNGO0FBQ0EsV0FBTyxNQUFNLENBQUM7QUFBQSxFQUNoQjtBQUNBLE1BQUksUUFBUSxLQUFLLElBQUk7QUFDbkIsU0FBSyxLQUFLO0FBQUEsRUFDWjtBQUNBLFFBQU0sZ0JBQWdCLFdBQVc7QUFDakMsWUFBVTtBQUNWLE1BQUk7QUFDSixNQUFJO0FBQ0YsVUFBTSxtQkFBbUIsUUFBUSxpQkFBaUIsS0FBSyxLQUFLLENBQUM7QUFDN0QsVUFBTSxVQUFVLE1BQU0sT0FBTztBQUFBO0FBQUEsSUFFN0Isb0JBQW9CLGlCQUFpQjtBQUNyQyxlQUFXO0FBQUEsTUFDVDtBQUFBLE1BQ0E7QUFBQSxRQUNFLE1BQU0sV0FBVyxDQUFDLFNBQVMsT0FBTyxJQUFJLFVBQVUsSUFBSSxJQUFJO0FBQUEsU0FDdkQsQ0FBQyxvQkFBb0IsV0FBVyxRQUFRO0FBQUEsTUFDM0M7QUFBQSxNQUNBLHFCQUFxQixXQUFXLFNBQVMsSUFBSSxDQUFDO0FBQUEsTUFDOUMsb0JBQW9CLE1BQU0sTUFBTSxJQUFJLEtBQUs7QUFBQSxJQUMzQztBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osYUFBUyxJQUFJLFdBQVcsUUFBUSxJQUFJLGVBQWUsSUFBSyxZQUFXO0FBQ25FLFVBQU07QUFBQSxFQUNSLFVBQUU7QUFDQSxRQUFJLFFBQVEsS0FBSyxJQUFJO0FBQ25CLFdBQUssS0FBSztBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLGFBQWEsU0FBUyxTQUFTO0FBQ2xDLGFBQVMsZUFBZSxDQUFDLFNBQVMsVUFBVSxJQUFJO0FBQUEsRUFDbEQ7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixRQUFRO0FBQ2hDLFNBQU8sT0FBTyxLQUFLLENBQUMsVUFBVTtBQUM1QixRQUFJLENBQUMsUUFBUSxLQUFLLEVBQUcsUUFBTztBQUM1QixRQUFJLE1BQU0sU0FBUyxRQUFTLFFBQU87QUFDbkMsUUFBSSxNQUFNLFNBQVMsWUFBWSxDQUFDLGlCQUFpQixNQUFNLFFBQVE7QUFDN0QsYUFBTztBQUNULFdBQU87QUFBQSxFQUNULENBQUMsSUFBSSxTQUFTO0FBQ2hCO0FBRUEsU0FBUyxXQUFXLEtBQUsseUJBQXlCO0FBQ2hELFFBQU0sTUFBTSxDQUFDO0FBQ2IsTUFBaUQsQ0FBQyxTQUFTLEdBQUcsR0FBRztBQUMvRCxXQUFPLGdEQUFnRDtBQUN2RCxXQUFPO0FBQUEsRUFDVDtBQUNBLGFBQVcsT0FBTyxLQUFLO0FBQ3JCLFFBQUksMkJBQTJCLFFBQVEsS0FBSyxHQUFHLElBQUksTUFBTSxHQUFHLEtBQUssYUFBYSxHQUFHLENBQUMsSUFBSSxJQUFJLEdBQUc7QUFBQSxFQUMvRjtBQUNBLFNBQU87QUFDVDtBQUVBLE1BQU0sb0JBQW9CLENBQUMsTUFBTTtBQUMvQixNQUFJLENBQUMsRUFBRyxRQUFPO0FBQ2YsTUFBSSxvQkFBb0IsQ0FBQyxFQUFHLFFBQU8sMkJBQTJCLENBQUM7QUFDL0QsU0FBTyxrQkFBa0IsRUFBRSxNQUFNO0FBQ25DO0FBQ0EsTUFBTTtBQUFBO0FBQUE7QUFBQSxFQUdZLHVCQUF1Qix1QkFBTyxPQUFPLElBQUksR0FBRztBQUFBLElBQzFELEdBQUcsQ0FBQyxNQUFNO0FBQUEsSUFDVixLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU07QUFBQSxJQUNwQixPQUFPLENBQUMsTUFBTSxFQUFFO0FBQUEsSUFDaEIsUUFBUSxDQUFDLE1BQU0sT0FBNEMsZ0JBQWdCLEVBQUUsS0FBSyxJQUFJLEVBQUU7QUFBQSxJQUN4RixRQUFRLENBQUMsTUFBTSxPQUE0QyxnQkFBZ0IsRUFBRSxLQUFLLElBQUksRUFBRTtBQUFBLElBQ3hGLFFBQVEsQ0FBQyxNQUFNLE9BQTRDLGdCQUFnQixFQUFFLEtBQUssSUFBSSxFQUFFO0FBQUEsSUFDeEYsT0FBTyxDQUFDLE1BQU0sT0FBNEMsZ0JBQWdCLEVBQUUsSUFBSSxJQUFJLEVBQUU7QUFBQSxJQUN0RixTQUFTLENBQUMsTUFBTSxrQkFBa0IsRUFBRSxNQUFNO0FBQUEsSUFDMUMsT0FBTyxDQUFDLE1BQU0sa0JBQWtCLEVBQUUsSUFBSTtBQUFBLElBQ3RDLE9BQU8sQ0FBQyxNQUFNLEVBQUU7QUFBQSxJQUNoQixPQUFPLENBQUMsTUFBTSxFQUFFO0FBQUEsSUFDaEIsVUFBVSxDQUFDLE1BQU0sc0JBQXNCLHFCQUFxQixDQUFDLElBQUksRUFBRTtBQUFBLElBQ25FLGNBQWMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksTUFBTTtBQUN2QyxlQUFTLEVBQUUsTUFBTTtBQUFBLElBQ25CO0FBQUEsSUFDQSxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLFNBQVMsS0FBSyxFQUFFLEtBQUs7QUFBQSxJQUNyRCxRQUFRLENBQUMsTUFBTSxzQkFBc0IsY0FBYyxLQUFLLENBQUMsSUFBSTtBQUFBLEVBQy9ELENBQUM7QUFBQTtBQUVILE1BQU0sbUJBQW1CLENBQUMsUUFBUSxRQUFRLE9BQU8sUUFBUTtBQUN6RCxNQUFNLGtCQUFrQixDQUFDLE9BQU8sUUFBUSxVQUFVLGFBQWEsQ0FBQyxNQUFNLG1CQUFtQixPQUFPLE9BQU8sR0FBRztBQUMxRyxNQUFNLDhCQUE4QjtBQUFBLEVBQ2xDLElBQUksRUFBRSxHQUFHLFNBQVMsR0FBRyxLQUFLO0FBQ3hCLFFBQUksUUFBUSxZQUFZO0FBQ3RCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSxFQUFFLEtBQUssWUFBWSxNQUFNLE9BQU8sYUFBYSxNQUFNLFdBQVcsSUFBSTtBQUN4RSxRQUFpRCxRQUFRLFdBQVc7QUFDbEUsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLElBQUksQ0FBQyxNQUFNLEtBQUs7QUFDbEIsWUFBTSxJQUFJLFlBQVksR0FBRztBQUN6QixVQUFJLE1BQU0sUUFBUTtBQUNoQixnQkFBUSxHQUFHO0FBQUEsVUFDVCxLQUFLO0FBQ0gsbUJBQU8sV0FBVyxHQUFHO0FBQUEsVUFDdkIsS0FBSztBQUNILG1CQUFPLEtBQUssR0FBRztBQUFBLFVBQ2pCLEtBQUs7QUFDSCxtQkFBTyxJQUFJLEdBQUc7QUFBQSxVQUNoQixLQUFLO0FBQ0gsbUJBQU8sTUFBTSxHQUFHO0FBQUEsUUFDcEI7QUFBQSxNQUNGLFdBQVcsZ0JBQWdCLFlBQVksR0FBRyxHQUFHO0FBQzNDLG9CQUFZLEdBQUcsSUFBSTtBQUNuQixlQUFPLFdBQVcsR0FBRztBQUFBLE1BQ3ZCLFdBQVcsdUJBQXVCLFNBQVMsYUFBYSxPQUFPLE1BQU0sR0FBRyxHQUFHO0FBQ3pFLG9CQUFZLEdBQUcsSUFBSTtBQUNuQixlQUFPLEtBQUssR0FBRztBQUFBLE1BQ2pCLFdBQVcsT0FBTyxPQUFPLEdBQUcsR0FBRztBQUM3QixvQkFBWSxHQUFHLElBQUk7QUFDbkIsZUFBTyxNQUFNLEdBQUc7QUFBQSxNQUNsQixXQUFXLFFBQVEsYUFBYSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ2hELG9CQUFZLEdBQUcsSUFBSTtBQUNuQixlQUFPLElBQUksR0FBRztBQUFBLE1BQ2hCLFdBQVcsQ0FBQyx1QkFBdUIsbUJBQW1CO0FBQ3BELG9CQUFZLEdBQUcsSUFBSTtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUNBLFVBQU0sZUFBZSxvQkFBb0IsR0FBRztBQUM1QyxRQUFJLFdBQVc7QUFDZixRQUFJLGNBQWM7QUFDaEIsVUFBSSxRQUFRLFVBQVU7QUFDcEIsY0FBTSxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBQy9CLFFBQTZDLGtCQUFrQjtBQUFBLE1BQ2pFLFdBQXdELFFBQVEsVUFBVTtBQUN4RSxjQUFNLFVBQVUsT0FBTyxHQUFHO0FBQUEsTUFDNUI7QUFDQSxhQUFPLGFBQWEsUUFBUTtBQUFBLElBQzlCO0FBQUE7QUFBQSxPQUVHLFlBQVksS0FBSyxrQkFBa0IsWUFBWSxVQUFVLEdBQUc7QUFBQSxNQUM3RDtBQUNBLGFBQU87QUFBQSxJQUNULFdBQVcsUUFBUSxhQUFhLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDaEQsa0JBQVksR0FBRyxJQUFJO0FBQ25CLGFBQU8sSUFBSSxHQUFHO0FBQUEsSUFDaEI7QUFBQTtBQUFBLE1BRUUsbUJBQW1CLFdBQVcsT0FBTyxrQkFBa0IsT0FBTyxrQkFBa0IsR0FBRztBQUFBLE1BQ25GO0FBQ0E7QUFDRSxlQUFPLGlCQUFpQixHQUFHO0FBQUEsTUFDN0I7QUFBQSxJQUNGLFdBQXdELDZCQUE2QixDQUFDLFNBQVMsR0FBRztBQUFBO0FBQUEsSUFFbEcsSUFBSSxRQUFRLEtBQUssTUFBTSxJQUFJO0FBQ3pCLFVBQUksU0FBUyxhQUFhLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxLQUFLLE9BQU8sTUFBTSxHQUFHLEdBQUc7QUFDdkU7QUFBQSxVQUNFLFlBQVksS0FBSztBQUFBLFlBQ2Y7QUFBQSxVQUNGLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRixXQUFXLGFBQWEsMEJBQTBCO0FBQ2hEO0FBQUEsVUFDRSxZQUFZLEtBQUssVUFBVSxHQUFHLENBQUM7QUFBQSxRQUNqQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsSUFBSSxFQUFFLEdBQUcsU0FBUyxHQUFHLEtBQUssT0FBTztBQUMvQixVQUFNLEVBQUUsTUFBTSxZQUFZLElBQUksSUFBSTtBQUNsQyxRQUFJLGdCQUFnQixZQUFZLEdBQUcsR0FBRztBQUNwQyxpQkFBVyxHQUFHLElBQUk7QUFDbEIsYUFBTztBQUFBLElBQ1QsV0FBd0QsV0FBVyxtQkFBbUIsT0FBTyxZQUFZLEdBQUcsR0FBRztBQUM3RyxhQUFPLHlDQUF5QyxHQUFHLHFCQUFxQjtBQUN4RSxhQUFPO0FBQUEsSUFDVCxXQUFXLHVCQUF1QixTQUFTLGFBQWEsT0FBTyxNQUFNLEdBQUcsR0FBRztBQUN6RSxXQUFLLEdBQUcsSUFBSTtBQUNaLGFBQU87QUFBQSxJQUNULFdBQVcsT0FBTyxTQUFTLE9BQU8sR0FBRyxHQUFHO0FBQ3RDLE1BQTZDLE9BQU8sOEJBQThCLEdBQUcsd0JBQXdCO0FBQzdHLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxJQUFJLENBQUMsTUFBTSxPQUFPLElBQUksTUFBTSxDQUFDLEtBQUssVUFBVTtBQUM5QyxNQUE2QztBQUFBLFFBQzNDLHlDQUF5QyxHQUFHO0FBQUEsTUFDOUM7QUFDQSxhQUFPO0FBQUEsSUFDVCxPQUFPO0FBQ0wsVUFBaUQsT0FBTyxTQUFTLFdBQVcsT0FBTyxrQkFBa0I7QUFDbkcsZUFBTyxlQUFlLEtBQUssS0FBSztBQUFBLFVBQzlCLFlBQVk7QUFBQSxVQUNaLGNBQWM7QUFBQSxVQUNkO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0wsWUFBSSxHQUFHLElBQUk7QUFBQSxNQUNiO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxJQUFJO0FBQUEsSUFDRixHQUFHLEVBQUUsTUFBTSxZQUFZLGFBQWEsS0FBSyxZQUFZLE9BQU8sS0FBSztBQUFBLEVBQ25FLEdBQUcsS0FBSztBQUNOLFFBQUk7QUFDSixXQUFPLENBQUMsRUFBRSxZQUFZLEdBQUcsS0FBSyx1QkFBdUIsU0FBUyxhQUFhLElBQUksQ0FBQyxNQUFNLE9BQU8sT0FBTyxNQUFNLEdBQUcsS0FBSyxnQkFBZ0IsWUFBWSxHQUFHLEtBQUssT0FBTyxPQUFPLEdBQUcsS0FBSyxPQUFPLEtBQUssR0FBRyxLQUFLLE9BQU8scUJBQXFCLEdBQUcsS0FBSyxPQUFPLFdBQVcsT0FBTyxrQkFBa0IsR0FBRyxNQUFNLGFBQWEsS0FBSyxpQkFBaUIsV0FBVyxHQUFHO0FBQUEsRUFDM1U7QUFBQSxFQUNBLGVBQWUsUUFBUSxLQUFLLFlBQVk7QUFDdEMsUUFBSSxXQUFXLE9BQU8sTUFBTTtBQUMxQixhQUFPLEVBQUUsWUFBWSxHQUFHLElBQUk7QUFBQSxJQUM5QixXQUFXLE9BQU8sWUFBWSxPQUFPLEdBQUc7QUFDdEMsV0FBSyxJQUFJLFFBQVEsS0FBSyxXQUFXLE9BQU8sSUFBSTtBQUFBLElBQzlDO0FBQ0EsV0FBTyxRQUFRLGVBQWUsUUFBUSxLQUFLLFVBQVU7QUFBQSxFQUN2RDtBQUNGO0FBQ0EsSUFBaUQsTUFBTTtBQUNyRCw4QkFBNEIsVUFBVSxDQUFDLFdBQVc7QUFDaEQ7QUFBQSxNQUNFO0FBQUEsSUFDRjtBQUNBLFdBQU8sUUFBUSxRQUFRLE1BQU07QUFBQSxFQUMvQjtBQUNGO0FBQ0EsTUFBTSw2Q0FBNkQsdUJBQU8sQ0FBQyxHQUFHLDZCQUE2QjtBQUFBLEVBQ3pHLElBQUksUUFBUSxLQUFLO0FBQ2YsUUFBSSxRQUFRLE9BQU8sYUFBYTtBQUM5QjtBQUFBLElBQ0Y7QUFDQSxXQUFPLDRCQUE0QixJQUFJLFFBQVEsS0FBSyxNQUFNO0FBQUEsRUFDNUQ7QUFBQSxFQUNBLElBQUksR0FBRyxLQUFLO0FBQ1YsVUFBTSxNQUFNLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxrQkFBa0IsR0FBRztBQUNwRCxRQUFpRCxDQUFDLE9BQU8sNEJBQTRCLElBQUksR0FBRyxHQUFHLEdBQUc7QUFDaEc7QUFBQSxRQUNFLFlBQVksS0FBSztBQUFBLFVBQ2Y7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0YsQ0FBQztBQUNELFNBQVMsdUJBQXVCLFVBQVU7QUFDeEMsUUFBTSxTQUFTLENBQUM7QUFDaEIsU0FBTyxlQUFlLFFBQVEsS0FBSztBQUFBLElBQ2pDLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLEtBQUssTUFBTTtBQUFBLEVBQ2IsQ0FBQztBQUNELFNBQU8sS0FBSyxtQkFBbUIsRUFBRSxRQUFRLENBQUMsUUFBUTtBQUNoRCxXQUFPLGVBQWUsUUFBUSxLQUFLO0FBQUEsTUFDakMsY0FBYztBQUFBLE1BQ2QsWUFBWTtBQUFBLE1BQ1osS0FBSyxNQUFNLG9CQUFvQixHQUFHLEVBQUUsUUFBUTtBQUFBO0FBQUE7QUFBQSxNQUc1QyxLQUFLO0FBQUEsSUFDUCxDQUFDO0FBQUEsRUFDSCxDQUFDO0FBQ0QsU0FBTztBQUNUO0FBQ0EsU0FBUywyQkFBMkIsVUFBVTtBQUM1QyxRQUFNO0FBQUEsSUFDSjtBQUFBLElBQ0EsY0FBYyxDQUFDLFlBQVk7QUFBQSxFQUM3QixJQUFJO0FBQ0osTUFBSSxjQUFjO0FBQ2hCLFdBQU8sS0FBSyxZQUFZLEVBQUUsUUFBUSxDQUFDLFFBQVE7QUFDekMsYUFBTyxlQUFlLEtBQUssS0FBSztBQUFBLFFBQzlCLFlBQVk7QUFBQSxRQUNaLGNBQWM7QUFBQSxRQUNkLEtBQUssTUFBTSxTQUFTLE1BQU0sR0FBRztBQUFBLFFBQzdCLEtBQUs7QUFBQSxNQUNQLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFDQSxTQUFTLGdDQUFnQyxVQUFVO0FBQ2pELFFBQU0sRUFBRSxLQUFLLFdBQVcsSUFBSTtBQUM1QixTQUFPLEtBQUssTUFBTSxVQUFVLENBQUMsRUFBRSxRQUFRLENBQUMsUUFBUTtBQUM5QyxRQUFJLENBQUMsV0FBVyxpQkFBaUI7QUFDL0IsVUFBSSxpQkFBaUIsSUFBSSxDQUFDLENBQUMsR0FBRztBQUM1QjtBQUFBLFVBQ0UsMkJBQTJCLEtBQUs7QUFBQSxZQUM5QjtBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxhQUFPLGVBQWUsS0FBSyxLQUFLO0FBQUEsUUFDOUIsWUFBWTtBQUFBLFFBQ1osY0FBYztBQUFBLFFBQ2QsS0FBSyxNQUFNLFdBQVcsR0FBRztBQUFBLFFBQ3pCLEtBQUs7QUFBQSxNQUNQLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFFQSxNQUFNLG1CQUFtQixDQUFDLFdBQVc7QUFBQSxFQUNuQyxHQUFHLE1BQU07QUFDWDtBQUNBLFNBQVMsY0FBYztBQUNyQixNQUFJLE1BQTJDO0FBQzdDLHFCQUFpQixhQUFhO0FBQUEsRUFDaEM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWM7QUFDckIsTUFBSSxNQUEyQztBQUM3QyxxQkFBaUIsYUFBYTtBQUFBLEVBQ2hDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLFNBQVM7QUFDN0IsTUFBSSxNQUEyQztBQUM3QyxxQkFBaUIsY0FBYztBQUFBLEVBQ2pDO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsU0FBUztBQUM5QixNQUFJLE1BQTJDO0FBQzdDLHFCQUFpQixlQUFlO0FBQUEsRUFDbEM7QUFDRjtBQUNBLFNBQVMsY0FBYztBQUNyQixNQUFJLE1BQTJDO0FBQzdDLHFCQUFpQixhQUFhO0FBQUEsRUFDaEM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWM7QUFDckIsTUFBSSxNQUEyQztBQUM3QyxxQkFBaUIsYUFBYTtBQUFBLEVBQ2hDO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsT0FBTyxVQUFVO0FBQ3JDLE1BQUksTUFBMkM7QUFDN0MscUJBQWlCLGNBQWM7QUFBQSxFQUNqQztBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsV0FBVztBQUNsQixTQUFPLFdBQVcsVUFBVSxFQUFFO0FBQ2hDO0FBQ0EsU0FBUyxXQUFXO0FBQ2xCLFNBQU8sV0FBVyxVQUFVLEVBQUU7QUFDaEM7QUFDQSxTQUFTLFdBQVcsb0JBQW9CO0FBQ3RDLFFBQU0sSUFBSSxtQkFBbUI7QUFDN0IsTUFBaUQsQ0FBQyxHQUFHO0FBQ25ELFdBQU8sR0FBRyxrQkFBa0Isb0NBQW9DO0FBQUEsRUFDbEU7QUFDQSxTQUFPLEVBQUUsaUJBQWlCLEVBQUUsZUFBZSxtQkFBbUIsQ0FBQztBQUNqRTtBQUNBLFNBQVMsc0JBQXNCLE9BQU87QUFDcEMsU0FBTyxRQUFRLEtBQUssSUFBSSxNQUFNO0FBQUEsSUFDNUIsQ0FBQyxZQUFZLE9BQU8sV0FBVyxDQUFDLElBQUksTUFBTTtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNILElBQUk7QUFDTjtBQUNBLFNBQVMsY0FBYyxLQUFLLFVBQVU7QUFDcEMsUUFBTSxRQUFRLHNCQUFzQixHQUFHO0FBQ3ZDLGFBQVcsT0FBTyxVQUFVO0FBQzFCLFFBQUksSUFBSSxXQUFXLFFBQVEsRUFBRztBQUM5QixRQUFJLE1BQU0sTUFBTSxHQUFHO0FBQ25CLFFBQUksS0FBSztBQUNQLFVBQUksUUFBUSxHQUFHLEtBQUssV0FBVyxHQUFHLEdBQUc7QUFDbkMsY0FBTSxNQUFNLEdBQUcsSUFBSSxFQUFFLE1BQU0sS0FBSyxTQUFTLFNBQVMsR0FBRyxFQUFFO0FBQUEsTUFDekQsT0FBTztBQUNMLFlBQUksVUFBVSxTQUFTLEdBQUc7QUFBQSxNQUM1QjtBQUFBLElBQ0YsV0FBVyxRQUFRLE1BQU07QUFDdkIsWUFBTSxNQUFNLEdBQUcsSUFBSSxFQUFFLFNBQVMsU0FBUyxHQUFHLEVBQUU7QUFBQSxJQUM5QyxXQUFXLE1BQTJDO0FBQ3BELGFBQU8sc0JBQXNCLEdBQUcscUNBQXFDO0FBQUEsSUFDdkU7QUFDQSxRQUFJLE9BQU8sU0FBUyxVQUFVLEdBQUcsRUFBRSxHQUFHO0FBQ3BDLFVBQUksY0FBYztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7QUFDekIsTUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFHLFFBQU8sS0FBSztBQUMxQixNQUFJLFFBQVEsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxFQUFHLFFBQU8sRUFBRSxPQUFPLENBQUM7QUFDL0MsU0FBTyxPQUFPLENBQUMsR0FBRyxzQkFBc0IsQ0FBQyxHQUFHLHNCQUFzQixDQUFDLENBQUM7QUFDdEU7QUFDQSxTQUFTLHFCQUFxQixPQUFPLGNBQWM7QUFDakQsUUFBTSxNQUFNLENBQUM7QUFDYixhQUFXLE9BQU8sT0FBTztBQUN2QixRQUFJLENBQUMsYUFBYSxTQUFTLEdBQUcsR0FBRztBQUMvQixhQUFPLGVBQWUsS0FBSyxLQUFLO0FBQUEsUUFDOUIsWUFBWTtBQUFBLFFBQ1osS0FBSyxNQUFNLE1BQU0sR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLGNBQWM7QUFDdEMsUUFBTSxNQUFNLG1CQUFtQjtBQUMvQixRQUFNLGFBQWE7QUFDbkIsTUFBaUQsQ0FBQyxLQUFLO0FBQ3JEO0FBQUEsTUFDRTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxZQUFZLGFBQWE7QUFDN0IsdUJBQXFCO0FBQ3JCLE1BQUksWUFBWTtBQUNkLHVCQUFtQixLQUFLO0FBQUEsRUFDMUI7QUFDQSxRQUFNLFVBQVUsTUFBTTtBQUNwQix1QkFBbUIsR0FBRztBQUN0QixRQUFJLFlBQVk7QUFDZCx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUNBLFFBQU0sVUFBVSxNQUFNO0FBQ3BCLFFBQUksbUJBQW1CLE1BQU0sSUFBSyxLQUFJLE1BQU0sSUFBSTtBQUNoRCx5QkFBcUI7QUFDckIsUUFBSSxZQUFZO0FBQ2QseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFVBQVUsU0FBUyxHQUFHO0FBQ3hCLGdCQUFZLFVBQVUsTUFBTSxDQUFDLE1BQU07QUFDakMsY0FBUTtBQUNSLGNBQVEsUUFBUSxFQUFFLEtBQUssTUFBTSxRQUFRLFFBQVEsRUFBRSxLQUFLLE9BQU8sQ0FBQztBQUM1RCxZQUFNO0FBQUEsSUFDUixDQUFDO0FBQUEsRUFDSDtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxNQUFNO0FBQ0osY0FBUTtBQUNSLGNBQVEsUUFBUSxFQUFFLEtBQUssT0FBTztBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx5QkFBeUI7QUFDaEMsUUFBTSxRQUF3Qix1QkFBTyxPQUFPLElBQUk7QUFDaEQsU0FBTyxDQUFDLE1BQU0sUUFBUTtBQUNwQixRQUFJLE1BQU0sR0FBRyxHQUFHO0FBQ2QsYUFBTyxHQUFHLElBQUksY0FBYyxHQUFHLDJCQUEyQixNQUFNLEdBQUcsQ0FBQyxHQUFHO0FBQUEsSUFDekUsT0FBTztBQUNMLFlBQU0sR0FBRyxJQUFJO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLElBQUksb0JBQW9CO0FBQ3hCLFNBQVMsYUFBYSxVQUFVO0FBQzlCLFFBQU0sVUFBVSxxQkFBcUIsUUFBUTtBQUM3QyxRQUFNLGFBQWEsU0FBUztBQUM1QixRQUFNLE1BQU0sU0FBUztBQUNyQixzQkFBb0I7QUFDcEIsTUFBSSxRQUFRLGNBQWM7QUFDeEIsYUFBUyxRQUFRLGNBQWMsVUFBVSxJQUFJO0FBQUEsRUFDL0M7QUFDQSxRQUFNO0FBQUE7QUFBQSxJQUVKLE1BQU07QUFBQSxJQUNOLFVBQVU7QUFBQSxJQUNWO0FBQUEsSUFDQSxPQUFPO0FBQUEsSUFDUCxTQUFTO0FBQUEsSUFDVCxRQUFRO0FBQUE7QUFBQSxJQUVSO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUE7QUFBQSxJQUVBO0FBQUEsSUFDQTtBQUFBO0FBQUEsSUFFQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRixJQUFJO0FBQ0osUUFBTSwyQkFBMkIsT0FBNEMsdUJBQXVCLElBQUk7QUFDeEcsTUFBSSxNQUEyQztBQUM3QyxVQUFNLENBQUMsWUFBWSxJQUFJLFNBQVM7QUFDaEMsUUFBSSxjQUFjO0FBQ2hCLGlCQUFXLE9BQU8sY0FBYztBQUM5QixpQ0FBeUIsU0FBcUIsR0FBRztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGVBQWU7QUFDakIsc0JBQWtCLGVBQWUsS0FBSyx3QkFBd0I7QUFBQSxFQUNoRTtBQUNBLE1BQUksU0FBUztBQUNYLGVBQVcsT0FBTyxTQUFTO0FBQ3pCLFlBQU0sZ0JBQWdCLFFBQVEsR0FBRztBQUNqQyxVQUFJLFdBQVcsYUFBYSxHQUFHO0FBQzdCLFlBQUksTUFBMkM7QUFDN0MsaUJBQU8sZUFBZSxLQUFLLEtBQUs7QUFBQSxZQUM5QixPQUFPLGNBQWMsS0FBSyxVQUFVO0FBQUEsWUFDcEMsY0FBYztBQUFBLFlBQ2QsWUFBWTtBQUFBLFlBQ1osVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUFBLFFBQ0gsT0FBTztBQUNMLGNBQUksR0FBRyxJQUFJLGNBQWMsS0FBSyxVQUFVO0FBQUEsUUFDMUM7QUFDQSxZQUFJLE1BQTJDO0FBQzdDLG1DQUF5QixXQUF5QixHQUFHO0FBQUEsUUFDdkQ7QUFBQSxNQUNGLFdBQVcsTUFBMkM7QUFDcEQ7QUFBQSxVQUNFLFdBQVcsR0FBRyxlQUFlLE9BQU8sYUFBYTtBQUFBLFFBQ25EO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxhQUFhO0FBQ2YsUUFBaUQsQ0FBQyxXQUFXLFdBQVcsR0FBRztBQUN6RTtBQUFBLFFBQ0U7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxZQUFZLEtBQUssWUFBWSxVQUFVO0FBQ3BELFFBQWlELFVBQVUsSUFBSSxHQUFHO0FBQ2hFO0FBQUEsUUFDRTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLFNBQVMsSUFBSSxHQUFHO0FBQ25CLE1BQTZDLE9BQU8saUNBQWlDO0FBQUEsSUFDdkYsT0FBTztBQUNMLGVBQVMsT0FBTyxTQUFTLElBQUk7QUFDN0IsVUFBSSxNQUEyQztBQUM3QyxtQkFBVyxPQUFPLE1BQU07QUFDdEIsbUNBQXlCLFFBQW1CLEdBQUc7QUFDL0MsY0FBSSxDQUFDLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxHQUFHO0FBQzdCLG1CQUFPLGVBQWUsS0FBSyxLQUFLO0FBQUEsY0FDOUIsY0FBYztBQUFBLGNBQ2QsWUFBWTtBQUFBLGNBQ1osS0FBSyxNQUFNLEtBQUssR0FBRztBQUFBLGNBQ25CLEtBQUs7QUFBQSxZQUNQLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLHNCQUFvQjtBQUNwQixNQUFJLGlCQUFpQjtBQUNuQixlQUFXLE9BQU8saUJBQWlCO0FBQ2pDLFlBQU0sTUFBTSxnQkFBZ0IsR0FBRztBQUMvQixZQUFNLE1BQU0sV0FBVyxHQUFHLElBQUksSUFBSSxLQUFLLFlBQVksVUFBVSxJQUFJLFdBQVcsSUFBSSxHQUFHLElBQUksSUFBSSxJQUFJLEtBQUssWUFBWSxVQUFVLElBQUk7QUFDOUgsVUFBaUQsUUFBUSxNQUFNO0FBQzdELGVBQU8sc0JBQXNCLEdBQUcsa0JBQWtCO0FBQUEsTUFDcEQ7QUFDQSxZQUFNLE1BQU0sQ0FBQyxXQUFXLEdBQUcsS0FBSyxXQUFXLElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxLQUFLLFVBQVUsSUFBSSxPQUE0QyxNQUFNO0FBQ2pJO0FBQUEsVUFDRSw4Q0FBOEMsR0FBRztBQUFBLFFBQ25EO0FBQUEsTUFDRixJQUFJO0FBQ0osWUFBTSxJQUFJLFNBQVM7QUFBQSxRQUNqQjtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFDRCxhQUFPLGVBQWUsS0FBSyxLQUFLO0FBQUEsUUFDOUIsWUFBWTtBQUFBLFFBQ1osY0FBYztBQUFBLFFBQ2QsS0FBSyxNQUFNLEVBQUU7QUFBQSxRQUNiLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUTtBQUFBLE1BQ3hCLENBQUM7QUFDRCxVQUFJLE1BQTJDO0FBQzdDLGlDQUF5QixZQUEyQixHQUFHO0FBQUEsTUFDekQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLE1BQUksY0FBYztBQUNoQixlQUFXLE9BQU8sY0FBYztBQUM5QixvQkFBYyxhQUFhLEdBQUcsR0FBRyxLQUFLLFlBQVksR0FBRztBQUFBLElBQ3ZEO0FBQUEsRUFDRjtBQUNBLE1BQUksZ0JBQWdCO0FBQ2xCLFVBQU0sV0FBVyxXQUFXLGNBQWMsSUFBSSxlQUFlLEtBQUssVUFBVSxJQUFJO0FBQ2hGLFlBQVEsUUFBUSxRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVE7QUFDekMsY0FBUSxLQUFLLFNBQVMsR0FBRyxDQUFDO0FBQUEsSUFDNUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLFNBQVM7QUFDWCxhQUFTLFNBQVMsVUFBVSxHQUFHO0FBQUEsRUFDakM7QUFDQSxXQUFTLHNCQUFzQixVQUFVLE1BQU07QUFDN0MsUUFBSSxRQUFRLElBQUksR0FBRztBQUNqQixXQUFLLFFBQVEsQ0FBQyxVQUFVLFNBQVMsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDMUQsV0FBVyxNQUFNO0FBQ2YsZUFBUyxLQUFLLEtBQUssVUFBVSxDQUFDO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBQ0Esd0JBQXNCLGVBQWUsV0FBVztBQUNoRCx3QkFBc0IsV0FBVyxPQUFPO0FBQ3hDLHdCQUFzQixnQkFBZ0IsWUFBWTtBQUNsRCx3QkFBc0IsV0FBVyxPQUFPO0FBQ3hDLHdCQUFzQixhQUFhLFNBQVM7QUFDNUMsd0JBQXNCLGVBQWUsV0FBVztBQUNoRCx3QkFBc0IsaUJBQWlCLGFBQWE7QUFDcEQsd0JBQXNCLGlCQUFpQixhQUFhO0FBQ3BELHdCQUFzQixtQkFBbUIsZUFBZTtBQUN4RCx3QkFBc0IsaUJBQWlCLGFBQWE7QUFDcEQsd0JBQXNCLGFBQWEsU0FBUztBQUM1Qyx3QkFBc0Isa0JBQWtCLGNBQWM7QUFDdEQsTUFBSSxRQUFRLE1BQU0sR0FBRztBQUNuQixRQUFJLE9BQU8sUUFBUTtBQUNqQixZQUFNLFVBQVUsU0FBUyxZQUFZLFNBQVMsVUFBVSxDQUFDO0FBQ3pELGFBQU8sUUFBUSxDQUFDLFFBQVE7QUFDdEIsZUFBTyxlQUFlLFNBQVMsS0FBSztBQUFBLFVBQ2xDLEtBQUssTUFBTSxXQUFXLEdBQUc7QUFBQSxVQUN6QixLQUFLLENBQUMsUUFBUSxXQUFXLEdBQUcsSUFBSTtBQUFBLFVBQ2hDLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNILENBQUM7QUFBQSxJQUNILFdBQVcsQ0FBQyxTQUFTLFNBQVM7QUFDNUIsZUFBUyxVQUFVLENBQUM7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFVBQVUsU0FBUyxXQUFXLE1BQU07QUFDdEMsYUFBUyxTQUFTO0FBQUEsRUFDcEI7QUFDQSxNQUFJLGdCQUFnQixNQUFNO0FBQ3hCLGFBQVMsZUFBZTtBQUFBLEVBQzFCO0FBQ0EsTUFBSSxXQUFZLFVBQVMsYUFBYTtBQUN0QyxNQUFJLFdBQVksVUFBUyxhQUFhO0FBQ3RDLE1BQUksZ0JBQWdCO0FBQ2xCLHNCQUFrQixRQUFRO0FBQUEsRUFDNUI7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLGVBQWUsS0FBSywyQkFBMkIsTUFBTTtBQUM5RSxNQUFJLFFBQVEsYUFBYSxHQUFHO0FBQzFCLG9CQUFnQixnQkFBZ0IsYUFBYTtBQUFBLEVBQy9DO0FBQ0EsYUFBVyxPQUFPLGVBQWU7QUFDL0IsVUFBTSxNQUFNLGNBQWMsR0FBRztBQUM3QixRQUFJO0FBQ0osUUFBSSxTQUFTLEdBQUcsR0FBRztBQUNqQixVQUFJLGFBQWEsS0FBSztBQUNwQixtQkFBVztBQUFBLFVBQ1QsSUFBSSxRQUFRO0FBQUEsVUFDWixJQUFJO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTCxtQkFBVyxPQUFPLElBQUksUUFBUSxHQUFHO0FBQUEsTUFDbkM7QUFBQSxJQUNGLE9BQU87QUFDTCxpQkFBVyxPQUFPLEdBQUc7QUFBQSxJQUN2QjtBQUNBLFFBQUksTUFBTSxRQUFRLEdBQUc7QUFDbkIsYUFBTyxlQUFlLEtBQUssS0FBSztBQUFBLFFBQzlCLFlBQVk7QUFBQSxRQUNaLGNBQWM7QUFBQSxRQUNkLEtBQUssTUFBTSxTQUFTO0FBQUEsUUFDcEIsS0FBSyxDQUFDLE1BQU0sU0FBUyxRQUFRO0FBQUEsTUFDL0IsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFVBQUksR0FBRyxJQUFJO0FBQUEsSUFDYjtBQUNBLFFBQUksTUFBMkM7QUFDN0MsK0JBQXlCLFVBQXVCLEdBQUc7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsU0FBUyxNQUFNLFVBQVUsTUFBTTtBQUN0QztBQUFBLElBQ0UsUUFBUSxJQUFJLElBQUksS0FBSyxJQUFJLENBQUNFLE9BQU1BLEdBQUUsS0FBSyxTQUFTLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxTQUFTLEtBQUs7QUFBQSxJQUNsRjtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsS0FBSyxLQUFLLFlBQVksS0FBSztBQUNoRCxNQUFJLFNBQVMsSUFBSSxTQUFTLEdBQUcsSUFBSSxpQkFBaUIsWUFBWSxHQUFHLElBQUksTUFBTSxXQUFXLEdBQUc7QUFDekYsTUFBSSxTQUFTLEdBQUcsR0FBRztBQUNqQixVQUFNLFVBQVUsSUFBSSxHQUFHO0FBQ3ZCLFFBQUksV0FBVyxPQUFPLEdBQUc7QUFDdkI7QUFDRSxjQUFNLFFBQVEsT0FBTztBQUFBLE1BQ3ZCO0FBQUEsSUFDRixXQUFXLE1BQTJDO0FBQ3BELGFBQU8sMkNBQTJDLEdBQUcsS0FBSyxPQUFPO0FBQUEsSUFDbkU7QUFBQSxFQUNGLFdBQVcsV0FBVyxHQUFHLEdBQUc7QUFDMUI7QUFDRSxZQUFNLFFBQVEsSUFBSSxLQUFLLFVBQVUsQ0FBQztBQUFBLElBQ3BDO0FBQUEsRUFDRixXQUFXLFNBQVMsR0FBRyxHQUFHO0FBQ3hCLFFBQUksUUFBUSxHQUFHLEdBQUc7QUFDaEIsVUFBSSxRQUFRLENBQUMsTUFBTSxjQUFjLEdBQUcsS0FBSyxZQUFZLEdBQUcsQ0FBQztBQUFBLElBQzNELE9BQU87QUFDTCxZQUFNLFVBQVUsV0FBVyxJQUFJLE9BQU8sSUFBSSxJQUFJLFFBQVEsS0FBSyxVQUFVLElBQUksSUFBSSxJQUFJLE9BQU87QUFDeEYsVUFBSSxXQUFXLE9BQU8sR0FBRztBQUN2QixjQUFNLFFBQVEsU0FBUyxHQUFHO0FBQUEsTUFDNUIsV0FBVyxNQUEyQztBQUNwRCxlQUFPLDJDQUEyQyxJQUFJLE9BQU8sS0FBSyxPQUFPO0FBQUEsTUFDM0U7QUFBQSxJQUNGO0FBQUEsRUFDRixXQUFXLE1BQTJDO0FBQ3BELFdBQU8sMEJBQTBCLEdBQUcsS0FBSyxHQUFHO0FBQUEsRUFDOUM7QUFDRjtBQUNBLFNBQVMscUJBQXFCLFVBQVU7QUFDdEMsUUFBTSxPQUFPLFNBQVM7QUFDdEIsUUFBTSxFQUFFLFFBQVEsU0FBUyxlQUFlLElBQUk7QUFDNUMsUUFBTTtBQUFBLElBQ0osUUFBUTtBQUFBLElBQ1IsY0FBYztBQUFBLElBQ2QsUUFBUSxFQUFFLHNCQUFzQjtBQUFBLEVBQ2xDLElBQUksU0FBUztBQUNiLFFBQU0sU0FBUyxNQUFNLElBQUksSUFBSTtBQUM3QixNQUFJO0FBQ0osTUFBSSxRQUFRO0FBQ1YsZUFBVztBQUFBLEVBQ2IsV0FBVyxDQUFDLGFBQWEsVUFBVSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0I7QUFDN0Q7QUFDRSxpQkFBVztBQUFBLElBQ2I7QUFBQSxFQUNGLE9BQU87QUFDTCxlQUFXLENBQUM7QUFDWixRQUFJLGFBQWEsUUFBUTtBQUN2QixtQkFBYTtBQUFBLFFBQ1gsQ0FBQyxNQUFNLGFBQWEsVUFBVSxHQUFHLHVCQUF1QixJQUFJO0FBQUEsTUFDOUQ7QUFBQSxJQUNGO0FBQ0EsaUJBQWEsVUFBVSxNQUFNLHFCQUFxQjtBQUFBLEVBQ3BEO0FBQ0EsTUFBSSxTQUFTLElBQUksR0FBRztBQUNsQixVQUFNLElBQUksTUFBTSxRQUFRO0FBQUEsRUFDMUI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGFBQWEsSUFBSSxNQUFNLFFBQVEsVUFBVSxPQUFPO0FBQ3ZELFFBQU0sRUFBRSxRQUFRLFNBQVMsZUFBZSxJQUFJO0FBQzVDLE1BQUksZ0JBQWdCO0FBQ2xCLGlCQUFhLElBQUksZ0JBQWdCLFFBQVEsSUFBSTtBQUFBLEVBQy9DO0FBQ0EsTUFBSSxRQUFRO0FBQ1YsV0FBTztBQUFBLE1BQ0wsQ0FBQyxNQUFNLGFBQWEsSUFBSSxHQUFHLFFBQVEsSUFBSTtBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUNBLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksV0FBVyxRQUFRLFVBQVU7QUFDL0IsTUFBNkM7QUFBQSxRQUMzQztBQUFBLE1BQ0Y7QUFBQSxJQUNGLE9BQU87QUFDTCxZQUFNLFFBQVEsMEJBQTBCLEdBQUcsS0FBSyxVQUFVLE9BQU8sR0FBRztBQUNwRSxTQUFHLEdBQUcsSUFBSSxRQUFRLE1BQU0sR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLENBQUMsSUFBSSxLQUFLLEdBQUc7QUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxNQUFNLDRCQUE0QjtBQUFBLEVBQ2hDLE1BQU07QUFBQSxFQUNOLE9BQU87QUFBQSxFQUNQLE9BQU87QUFBQTtBQUFBLEVBRVAsU0FBUztBQUFBLEVBQ1QsVUFBVTtBQUFBO0FBQUEsRUFFVixjQUFjO0FBQUEsRUFDZCxTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixTQUFTO0FBQUEsRUFDVCxjQUFjO0FBQUEsRUFDZCxTQUFTO0FBQUEsRUFDVCxlQUFlO0FBQUEsRUFDZixlQUFlO0FBQUEsRUFDZixXQUFXO0FBQUEsRUFDWCxXQUFXO0FBQUEsRUFDWCxXQUFXO0FBQUEsRUFDWCxhQUFhO0FBQUEsRUFDYixlQUFlO0FBQUEsRUFDZixnQkFBZ0I7QUFBQTtBQUFBLEVBRWhCLFlBQVk7QUFBQSxFQUNaLFlBQVk7QUFBQTtBQUFBLEVBRVosT0FBTztBQUFBO0FBQUEsRUFFUCxTQUFTO0FBQUEsRUFDVCxRQUFRO0FBQ1Y7QUFDQSxTQUFTLFlBQVksSUFBSSxNQUFNO0FBQzdCLE1BQUksQ0FBQyxNQUFNO0FBQ1QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLENBQUMsSUFBSTtBQUNQLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTyxTQUFTLGVBQWU7QUFDN0IsV0FBUTtBQUFBLE1BQ04sV0FBVyxFQUFFLElBQUksR0FBRyxLQUFLLE1BQU0sSUFBSSxJQUFJO0FBQUEsTUFDdkMsV0FBVyxJQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxJQUFJO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLFlBQVksSUFBSSxNQUFNO0FBQzdCLFNBQU8sbUJBQW1CLGdCQUFnQixFQUFFLEdBQUcsZ0JBQWdCLElBQUksQ0FBQztBQUN0RTtBQUNBLFNBQVMsZ0JBQWdCLEtBQUs7QUFDNUIsTUFBSSxRQUFRLEdBQUcsR0FBRztBQUNoQixVQUFNLE1BQU0sQ0FBQztBQUNiLGFBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7QUFDbkMsVUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUFBLElBQ3JCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGFBQWEsSUFBSSxNQUFNO0FBQzlCLFNBQU8sS0FBSyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsRUFBRSxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsSUFBSTtBQUNsRDtBQUNBLFNBQVMsbUJBQW1CLElBQUksTUFBTTtBQUNwQyxTQUFPLEtBQUssT0FBdUIsdUJBQU8sT0FBTyxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUk7QUFDdEU7QUFDQSxTQUFTLHlCQUF5QixJQUFJLE1BQU07QUFDMUMsTUFBSSxJQUFJO0FBQ04sUUFBSSxRQUFRLEVBQUUsS0FBSyxRQUFRLElBQUksR0FBRztBQUNoQyxhQUFPLENBQUMsR0FBbUIsb0JBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO0FBQUEsSUFDdEQ7QUFDQSxXQUFPO0FBQUEsTUFDVyx1QkFBTyxPQUFPLElBQUk7QUFBQSxNQUNsQyxzQkFBc0IsRUFBRTtBQUFBLE1BQ3hCLHNCQUFzQixRQUFRLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFBQSxJQUNoRDtBQUFBLEVBQ0YsT0FBTztBQUNMLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixJQUFJLE1BQU07QUFDbkMsTUFBSSxDQUFDLEdBQUksUUFBTztBQUNoQixNQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLFFBQU0sU0FBUyxPQUF1Qix1QkFBTyxPQUFPLElBQUksR0FBRyxFQUFFO0FBQzdELGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFdBQU8sR0FBRyxJQUFJLGFBQWEsR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLENBQUM7QUFBQSxFQUMvQztBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsbUJBQW1CO0FBQzFCLFNBQU87QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLFFBQVE7QUFBQSxNQUNOLGFBQWE7QUFBQSxNQUNiLGFBQWE7QUFBQSxNQUNiLGtCQUFrQixDQUFDO0FBQUEsTUFDbkIsdUJBQXVCLENBQUM7QUFBQSxNQUN4QixjQUFjO0FBQUEsTUFDZCxhQUFhO0FBQUEsTUFDYixpQkFBaUIsQ0FBQztBQUFBLElBQ3BCO0FBQUEsSUFDQSxRQUFRLENBQUM7QUFBQSxJQUNULFlBQVksQ0FBQztBQUFBLElBQ2IsWUFBWSxDQUFDO0FBQUEsSUFDYixVQUEwQix1QkFBTyxPQUFPLElBQUk7QUFBQSxJQUM1QyxjQUE4QixvQkFBSSxRQUFRO0FBQUEsSUFDMUMsWUFBNEIsb0JBQUksUUFBUTtBQUFBLElBQ3hDLFlBQTRCLG9CQUFJLFFBQVE7QUFBQSxFQUMxQztBQUNGO0FBQ0EsSUFBSSxRQUFRO0FBQ1osU0FBUyxhQUFhLFFBQVEsU0FBUztBQUNyQyxTQUFPLFNBQVMsVUFBVSxlQUFlLFlBQVksTUFBTTtBQUN6RCxRQUFJLENBQUMsV0FBVyxhQUFhLEdBQUc7QUFDOUIsc0JBQWdCLE9BQU8sQ0FBQyxHQUFHLGFBQWE7QUFBQSxJQUMxQztBQUNBLFFBQUksYUFBYSxRQUFRLENBQUMsU0FBUyxTQUFTLEdBQUc7QUFDN0MsTUFBNkMsT0FBTyxxREFBcUQ7QUFDekcsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsVUFBTSxVQUFVLGlCQUFpQjtBQUNqQyxVQUFNLG1CQUFtQyxvQkFBSSxRQUFRO0FBQ3JELFVBQU0sbUJBQW1CLENBQUM7QUFDMUIsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sTUFBTSxRQUFRLE1BQU07QUFBQSxNQUN4QixNQUFNO0FBQUEsTUFDTixZQUFZO0FBQUEsTUFDWixRQUFRO0FBQUEsTUFDUixZQUFZO0FBQUEsTUFDWixVQUFVO0FBQUEsTUFDVixXQUFXO0FBQUEsTUFDWDtBQUFBLE1BQ0EsSUFBSSxTQUFTO0FBQ1gsZUFBTyxRQUFRO0FBQUEsTUFDakI7QUFBQSxNQUNBLElBQUksT0FBTyxHQUFHO0FBQ1osWUFBSSxNQUEyQztBQUM3QztBQUFBLFlBQ0U7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLElBQUksV0FBVyxTQUFTO0FBQ3RCLFlBQUksaUJBQWlCLElBQUksTUFBTSxHQUFHO0FBQ2hDLFVBQTZDLE9BQU8sZ0RBQWdEO0FBQUEsUUFDdEcsV0FBVyxVQUFVLFdBQVcsT0FBTyxPQUFPLEdBQUc7QUFDL0MsMkJBQWlCLElBQUksTUFBTTtBQUMzQixpQkFBTyxRQUFRLEtBQUssR0FBRyxPQUFPO0FBQUEsUUFDaEMsV0FBVyxXQUFXLE1BQU0sR0FBRztBQUM3QiwyQkFBaUIsSUFBSSxNQUFNO0FBQzNCLGlCQUFPLEtBQUssR0FBRyxPQUFPO0FBQUEsUUFDeEIsV0FBVyxNQUEyQztBQUNwRDtBQUFBLFlBQ0U7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFDQSxNQUFNLE9BQU87QUFDWCxZQUFJLHFCQUFxQjtBQUN2QixjQUFJLENBQUMsUUFBUSxPQUFPLFNBQVMsS0FBSyxHQUFHO0FBQ25DLG9CQUFRLE9BQU8sS0FBSyxLQUFLO0FBQUEsVUFDM0IsV0FBVyxNQUEyQztBQUNwRDtBQUFBLGNBQ0Usa0RBQWtELE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxLQUFLO0FBQUEsWUFDckY7QUFBQSxVQUNGO0FBQUEsUUFDRixXQUFXLE1BQTJDO0FBQ3BELGlCQUFPLDREQUE0RDtBQUFBLFFBQ3JFO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBLFVBQVUsTUFBTSxXQUFXO0FBQ3pCLFlBQUksTUFBMkM7QUFDN0MsZ0NBQXNCLE1BQU0sUUFBUSxNQUFNO0FBQUEsUUFDNUM7QUFDQSxZQUFJLENBQUMsV0FBVztBQUNkLGlCQUFPLFFBQVEsV0FBVyxJQUFJO0FBQUEsUUFDaEM7QUFDQSxZQUFpRCxRQUFRLFdBQVcsSUFBSSxHQUFHO0FBQ3pFLGlCQUFPLGNBQWMsSUFBSSw4Q0FBOEM7QUFBQSxRQUN6RTtBQUNBLGdCQUFRLFdBQVcsSUFBSSxJQUFJO0FBQzNCLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFDQSxVQUFVLE1BQU0sV0FBVztBQUN6QixZQUFJLE1BQTJDO0FBQzdDLGdDQUFzQixJQUFJO0FBQUEsUUFDNUI7QUFDQSxZQUFJLENBQUMsV0FBVztBQUNkLGlCQUFPLFFBQVEsV0FBVyxJQUFJO0FBQUEsUUFDaEM7QUFDQSxZQUFpRCxRQUFRLFdBQVcsSUFBSSxHQUFHO0FBQ3pFLGlCQUFPLGNBQWMsSUFBSSw4Q0FBOEM7QUFBQSxRQUN6RTtBQUNBLGdCQUFRLFdBQVcsSUFBSSxJQUFJO0FBQzNCLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFDQSxNQUFNLGVBQWUsV0FBVyxXQUFXO0FBQ3pDLFlBQUksQ0FBQyxXQUFXO0FBQ2QsY0FBaUQsY0FBYyxhQUFhO0FBQzFFO0FBQUEsY0FDRTtBQUFBO0FBQUEsWUFFRjtBQUFBLFVBQ0Y7QUFDQSxnQkFBTSxRQUFRLElBQUksWUFBWSxZQUFZLGVBQWUsU0FBUztBQUNsRSxnQkFBTSxhQUFhO0FBQ25CLGNBQUksY0FBYyxNQUFNO0FBQ3RCLHdCQUFZO0FBQUEsVUFDZCxXQUFXLGNBQWMsT0FBTztBQUM5Qix3QkFBWTtBQUFBLFVBQ2Q7QUFDQSxjQUFJLE1BQTJDO0FBQzdDLG9CQUFRLFNBQVMsTUFBTTtBQUNyQixvQkFBTSxTQUFTLFdBQVcsS0FBSztBQUMvQixxQkFBTyxLQUFLO0FBQ1oscUJBQU8sUUFBUSxlQUFlLFNBQVM7QUFBQSxZQUN6QztBQUFBLFVBQ0Y7QUFDQSxjQUFJLGFBQWEsU0FBUztBQUN4QixvQkFBUSxPQUFPLGFBQWE7QUFBQSxVQUM5QixPQUFPO0FBQ0wsbUJBQU8sT0FBTyxlQUFlLFNBQVM7QUFBQSxVQUN4QztBQUNBLHNCQUFZO0FBQ1osY0FBSSxhQUFhO0FBQ2pCLHdCQUFjLGNBQWM7QUFDNUIsY0FBSSxNQUFvRTtBQUN0RSxnQkFBSSxZQUFZLE1BQU07QUFDdEIsNEJBQWdCLEtBQUssT0FBTztBQUFBLFVBQzlCO0FBQ0EsaUJBQU8sMkJBQTJCLE1BQU0sU0FBUztBQUFBLFFBQ25ELFdBQVcsTUFBMkM7QUFDcEQ7QUFBQSxZQUNFO0FBQUE7QUFBQSxVQUVGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFVBQVUsV0FBVztBQUNuQixZQUFpRCxPQUFPLGNBQWMsWUFBWTtBQUNoRjtBQUFBLFlBQ0UsbUVBQW1FLE9BQU8sU0FBUztBQUFBLFVBQ3JGO0FBQUEsUUFDRjtBQUNBLHlCQUFpQixLQUFLLFNBQVM7QUFBQSxNQUNqQztBQUFBLE1BQ0EsVUFBVTtBQUNSLFlBQUksV0FBVztBQUNiO0FBQUEsWUFDRTtBQUFBLFlBQ0EsSUFBSTtBQUFBLFlBQ0o7QUFBQSxVQUNGO0FBQ0EsaUJBQU8sTUFBTSxJQUFJLFVBQVU7QUFDM0IsY0FBSSxNQUFvRTtBQUN0RSxnQkFBSSxZQUFZO0FBQ2hCLCtCQUFtQixHQUFHO0FBQUEsVUFDeEI7QUFDQSxpQkFBTyxJQUFJLFdBQVc7QUFBQSxRQUN4QixXQUFXLE1BQTJDO0FBQ3BELGlCQUFPLDRDQUE0QztBQUFBLFFBQ3JEO0FBQUEsTUFDRjtBQUFBLE1BQ0EsUUFBUSxLQUFLLE9BQU87QUFDbEIsWUFBaUQsT0FBTyxRQUFRLFVBQVU7QUFDeEUsY0FBSSxPQUFPLFFBQVEsVUFBVSxHQUFHLEdBQUc7QUFDakM7QUFBQSxjQUNFLDJDQUEyQyxPQUFPLEdBQUcsQ0FBQztBQUFBLFlBQ3hEO0FBQUEsVUFDRixPQUFPO0FBQ0w7QUFBQSxjQUNFLDJDQUEyQyxPQUFPLEdBQUcsQ0FBQztBQUFBLFlBQ3hEO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxnQkFBUSxTQUFTLEdBQUcsSUFBSTtBQUN4QixlQUFPO0FBQUEsTUFDVDtBQUFBLE1BQ0EsZUFBZSxJQUFJO0FBQ2pCLGNBQU0sVUFBVTtBQUNoQixxQkFBYTtBQUNiLFlBQUk7QUFDRixpQkFBTyxHQUFHO0FBQUEsUUFDWixVQUFFO0FBQ0EsdUJBQWE7QUFBQSxRQUNmO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsSUFBSSxhQUFhO0FBRWpCLFNBQVMsU0FBUyxPQUFPLE1BQU0sVUFBVSxXQUFXO0FBQ2xELFFBQU0sSUFBSSxtQkFBbUI7QUFDN0IsTUFBaUQsQ0FBQyxHQUFHO0FBQ25ELFdBQU8sNENBQTRDO0FBQ25ELFdBQU8sSUFBSTtBQUFBLEVBQ2I7QUFDQSxRQUFNLGdCQUFnQixTQUFTLElBQUk7QUFDbkMsTUFBaUQsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxFQUFFLGFBQWEsR0FBRztBQUNsRixXQUFPLGdDQUFnQyxJQUFJLDBCQUEwQjtBQUNyRSxXQUFPLElBQUk7QUFBQSxFQUNiO0FBQ0EsUUFBTSxpQkFBaUIsVUFBVSxJQUFJO0FBQ3JDLFFBQU0sWUFBWSxrQkFBa0IsT0FBTyxhQUFhO0FBQ3hELFFBQU0sTUFBTSxVQUFVLENBQUNDLFFBQU9DLGFBQVk7QUFDeEMsUUFBSTtBQUNKLFFBQUksZUFBZTtBQUNuQixRQUFJO0FBQ0osb0JBQWdCLE1BQU07QUFDcEIsWUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxVQUFJLFdBQVcsWUFBWSxTQUFTLEdBQUc7QUFDckMscUJBQWE7QUFDYixRQUFBQSxTQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU87QUFBQSxNQUNMLE1BQU07QUFDSixRQUFBRCxPQUFNO0FBQ04sZUFBTyxRQUFRLE1BQU0sUUFBUSxJQUFJLFVBQVUsSUFBSTtBQUFBLE1BQ2pEO0FBQUEsTUFDQSxJQUFJLE9BQU87QUFDVCxjQUFNLGVBQWUsUUFBUSxNQUFNLFFBQVEsSUFBSSxLQUFLLElBQUk7QUFDeEQsWUFBSSxDQUFDLFdBQVcsY0FBYyxVQUFVLEtBQUssRUFBRSxpQkFBaUIsYUFBYSxXQUFXLE9BQU8sWUFBWSxJQUFJO0FBQzdHO0FBQUEsUUFDRjtBQUNBLGNBQU0sV0FBVyxFQUFFLE1BQU07QUFDekIsY0FBTSxZQUFZLENBQUMsRUFBRTtBQUFBLFNBQ3BCLFFBQVEsWUFBWSxpQkFBaUIsWUFBWSxrQkFBa0IsY0FBYyxZQUFZLElBQUksTUFBTSxZQUFZLFlBQVksYUFBYSxNQUFNLFlBQVksWUFBWSxjQUFjLE1BQU07QUFDL0wsWUFBSSxDQUFDLFdBQVc7QUFDZCx1QkFBYTtBQUNiLFVBQUFDLFNBQVE7QUFBQSxRQUNWO0FBQ0EsVUFBRSxLQUFLLFVBQVUsSUFBSSxJQUFJLFlBQVk7QUFDckMsWUFBSSxXQUFXLE9BQU8sWUFBWSxNQUFNLFdBQVcsT0FBTyxZQUFZLEtBQUssQ0FBQyxXQUFXLGNBQWMsZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXJILGFBQWEsaUJBQWlCLGFBQWEsQ0FBQyxXQUFXLGNBQWMsVUFBVSxJQUFJO0FBQ2pGLFVBQUFBLFNBQVE7QUFBQSxRQUNWO0FBQ0EsdUJBQWU7QUFDZiwyQkFBbUI7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFDRCxNQUFJLE9BQU8sUUFBUSxJQUFJLE1BQU07QUFDM0IsUUFBSSxLQUFLO0FBQ1QsV0FBTztBQUFBLE1BQ0wsT0FBTztBQUNMLFlBQUksS0FBSyxHQUFHO0FBQ1YsaUJBQU8sRUFBRSxPQUFPLE9BQU8sYUFBYSxZQUFZLEtBQUssTUFBTSxNQUFNO0FBQUEsUUFDbkUsT0FBTztBQUNMLGlCQUFPLEVBQUUsTUFBTSxLQUFLO0FBQUEsUUFDdEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxNQUFNLG9CQUFvQixDQUFDLE9BQU8sY0FBYztBQUM5QyxTQUFPLGNBQWMsZ0JBQWdCLGNBQWMsZ0JBQWdCLE1BQU0saUJBQWlCLE1BQU0sR0FBRyxTQUFTLFdBQVcsS0FBSyxNQUFNLEdBQUcsU0FBUyxTQUFTLENBQUMsV0FBVyxLQUFLLE1BQU0sR0FBRyxVQUFVLFNBQVMsQ0FBQyxXQUFXO0FBQ2xOO0FBRUEsU0FBUyxLQUFLLFVBQVUsVUFBVSxTQUFTO0FBQ3pDLE1BQUksU0FBUyxZQUFhO0FBQzFCLFFBQU0sUUFBUSxTQUFTLE1BQU0sU0FBUztBQUN0QyxNQUFJLE1BQTJDO0FBQzdDLFVBQU07QUFBQSxNQUNKO0FBQUEsTUFDQSxjQUFjLENBQUMsWUFBWTtBQUFBLElBQzdCLElBQUk7QUFDSixRQUFJLGNBQWM7QUFDaEIsVUFBSSxFQUFFLFNBQVMsaUJBQWlCLE1BQU07QUFDcEMsWUFBSSxDQUFDLGdCQUFnQixFQUFFLGFBQWEsU0FBUyxLQUFLLENBQUMsS0FBSyxlQUFlO0FBQ3JFO0FBQUEsWUFDRSw0QkFBNEIsS0FBSywrREFBK0QsYUFBYSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUEsVUFDL0g7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxZQUFZLGFBQWEsS0FBSztBQUNwQyxZQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLGdCQUFNLFVBQVUsVUFBVSxHQUFHLE9BQU87QUFDcEMsY0FBSSxDQUFDLFNBQVM7QUFDWjtBQUFBLGNBQ0UsK0RBQStELEtBQUs7QUFBQSxZQUN0RTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxPQUFPO0FBQ1gsUUFBTUMsbUJBQWtCLE1BQU0sV0FBVyxTQUFTO0FBQ2xELFFBQU0sWUFBWUEsb0JBQW1CLGtCQUFrQixPQUFPLE1BQU0sTUFBTSxDQUFDLENBQUM7QUFDNUUsTUFBSSxXQUFXO0FBQ2IsUUFBSSxVQUFVLE1BQU07QUFDbEIsYUFBTyxRQUFRLElBQUksQ0FBQyxNQUFNLFNBQVMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxJQUN0RDtBQUNBLFFBQUksVUFBVSxRQUFRO0FBQ3BCLGFBQU8sUUFBUSxJQUFJLGFBQWE7QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFDQSxNQUFJLE1BQW9FO0FBQ3RFLDBCQUFzQixVQUFVLE9BQU8sSUFBSTtBQUFBLEVBQzdDO0FBQ0EsTUFBSSxNQUEyQztBQUM3QyxVQUFNLGlCQUFpQixNQUFNLFlBQVk7QUFDekMsUUFBSSxtQkFBbUIsU0FBUyxNQUFNLGFBQWEsY0FBYyxDQUFDLEdBQUc7QUFDbkU7QUFBQSxRQUNFLFVBQVUsY0FBYyw2QkFBNkI7QUFBQSxVQUNuRDtBQUFBLFVBQ0EsU0FBUztBQUFBLFFBQ1gsQ0FBQyx1Q0FBdUMsS0FBSyxpS0FBaUs7QUFBQSxVQUM1TTtBQUFBLFFBQ0YsQ0FBQyxpQkFBaUIsS0FBSztBQUFBLE1BQ3pCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0osTUFBSSxVQUFVLE1BQU0sY0FBYyxhQUFhLEtBQUssQ0FBQztBQUFBLEVBQ3JELE1BQU0sY0FBYyxhQUFhLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFDakQsTUFBSSxDQUFDLFdBQVdBLGtCQUFpQjtBQUMvQixjQUFVLE1BQU0sY0FBYyxhQUFhLFVBQVUsS0FBSyxDQUFDLENBQUM7QUFBQSxFQUM5RDtBQUNBLE1BQUksU0FBUztBQUNYO0FBQUEsTUFDRTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxjQUFjLE1BQU0sY0FBYyxNQUFNO0FBQzlDLE1BQUksYUFBYTtBQUNmLFFBQUksQ0FBQyxTQUFTLFNBQVM7QUFDckIsZUFBUyxVQUFVLENBQUM7QUFBQSxJQUN0QixXQUFXLFNBQVMsUUFBUSxXQUFXLEdBQUc7QUFDeEM7QUFBQSxJQUNGO0FBQ0EsYUFBUyxRQUFRLFdBQVcsSUFBSTtBQUNoQztBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxrQkFBa0Msb0JBQUksUUFBUTtBQUNwRCxTQUFTLHNCQUFzQixNQUFNLFlBQVksVUFBVSxPQUFPO0FBQ2hFLFFBQU0sUUFBUSx1QkFBdUIsVUFBVSxrQkFBa0IsV0FBVztBQUM1RSxRQUFNLFNBQVMsTUFBTSxJQUFJLElBQUk7QUFDN0IsTUFBSSxXQUFXLFFBQVE7QUFDckIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE1BQU0sS0FBSztBQUNqQixNQUFJLGFBQWEsQ0FBQztBQUNsQixNQUFJLGFBQWE7QUFDakIsTUFBSSx1QkFBdUIsQ0FBQyxXQUFXLElBQUksR0FBRztBQUM1QyxVQUFNLGNBQWMsQ0FBQyxTQUFTO0FBQzVCLFlBQU0sdUJBQXVCLHNCQUFzQixNQUFNLFlBQVksSUFBSTtBQUN6RSxVQUFJLHNCQUFzQjtBQUN4QixxQkFBYTtBQUNiLGVBQU8sWUFBWSxvQkFBb0I7QUFBQSxNQUN6QztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsV0FBVyxXQUFXLE9BQU8sUUFBUTtBQUN4QyxpQkFBVyxPQUFPLFFBQVEsV0FBVztBQUFBLElBQ3ZDO0FBQ0EsUUFBSSxLQUFLLFNBQVM7QUFDaEIsa0JBQVksS0FBSyxPQUFPO0FBQUEsSUFDMUI7QUFDQSxRQUFJLEtBQUssUUFBUTtBQUNmLFdBQUssT0FBTyxRQUFRLFdBQVc7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7QUFDdkIsUUFBSSxTQUFTLElBQUksR0FBRztBQUNsQixZQUFNLElBQUksTUFBTSxJQUFJO0FBQUEsSUFDdEI7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksUUFBUSxHQUFHLEdBQUc7QUFDaEIsUUFBSSxRQUFRLENBQUMsUUFBUSxXQUFXLEdBQUcsSUFBSSxJQUFJO0FBQUEsRUFDN0MsT0FBTztBQUNMLFdBQU8sWUFBWSxHQUFHO0FBQUEsRUFDeEI7QUFDQSxNQUFJLFNBQVMsSUFBSSxHQUFHO0FBQ2xCLFVBQU0sSUFBSSxNQUFNLFVBQVU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxTQUFTLEtBQUs7QUFDcEMsTUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsR0FBRztBQUMxQixXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sSUFBSSxNQUFNLENBQUM7QUFDakIsUUFBTSxRQUFRLFNBQVMsTUFBTSxJQUFJLFFBQVEsU0FBUyxFQUFFO0FBQ3BELFNBQU8sT0FBTyxTQUFTLElBQUksQ0FBQyxFQUFFLFlBQVksSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLEtBQUssT0FBTyxTQUFTLFVBQVUsR0FBRyxDQUFDLEtBQUssT0FBTyxTQUFTLEdBQUc7QUFDdkg7QUFFQSxJQUFJLGdCQUFnQjtBQUNwQixTQUFTLG9CQUFvQjtBQUMzQixrQkFBZ0I7QUFDbEI7QUFDQSxTQUFTLG9CQUFvQixVQUFVO0FBQ3JDLFFBQU07QUFBQSxJQUNKLE1BQU07QUFBQSxJQUNOO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLGNBQWMsQ0FBQyxZQUFZO0FBQUEsSUFDM0I7QUFBQSxJQUNBO0FBQUEsSUFDQSxNQUFBQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGLElBQUk7QUFDSixRQUFNLE9BQU8sNEJBQTRCLFFBQVE7QUFDakQsTUFBSTtBQUNKLE1BQUk7QUFDSixNQUFJLE1BQTJDO0FBQzdDLG9CQUFnQjtBQUFBLEVBQ2xCO0FBQ0EsTUFBSTtBQUNGLFFBQUksTUFBTSxZQUFZLEdBQUc7QUFDdkIsWUFBTSxhQUFhLGFBQWE7QUFDaEMsWUFBTSxZQUF5RCxXQUFXLGtCQUFrQixJQUFJLE1BQU0sWUFBWTtBQUFBLFFBQ2hILElBQUksUUFBUSxLQUFLLFVBQVU7QUFDekI7QUFBQSxZQUNFLGFBQWE7QUFBQSxjQUNYO0FBQUEsWUFDRixDQUFDO0FBQUEsVUFDSDtBQUNBLGlCQUFPLFFBQVEsSUFBSSxRQUFRLEtBQUssUUFBUTtBQUFBLFFBQzFDO0FBQUEsTUFDRixDQUFDLElBQUk7QUFDTCxlQUFTO0FBQUEsUUFDUCxPQUFPO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxPQUE0QyxnQkFBZ0IsS0FBSyxJQUFJO0FBQUEsVUFDckU7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EseUJBQW1CO0FBQUEsSUFDckIsT0FBTztBQUNMLFlBQU0sVUFBVTtBQUNoQixVQUFpRCxVQUFVLE9BQU87QUFDaEUsMEJBQWtCO0FBQUEsTUFDcEI7QUFDQSxlQUFTO0FBQUEsUUFDUCxRQUFRLFNBQVMsSUFBSTtBQUFBLFVBQ25CLE9BQTRDLGdCQUFnQixLQUFLLElBQUk7QUFBQSxVQUNyRSxPQUE0QztBQUFBLFlBQzFDLElBQUksUUFBUTtBQUNWLGdDQUFrQjtBQUNsQixxQkFBTyxnQkFBZ0IsS0FBSztBQUFBLFlBQzlCO0FBQUEsWUFDQTtBQUFBLFlBQ0EsTUFBQUE7QUFBQSxVQUNGLElBQUksRUFBRSxPQUFPLE9BQU8sTUFBQUEsTUFBSztBQUFBLFFBQzNCLElBQUk7QUFBQSxVQUNGLE9BQTRDLGdCQUFnQixLQUFLLElBQUk7QUFBQSxVQUNyRTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EseUJBQW1CLFVBQVUsUUFBUSxRQUFRLHlCQUF5QixLQUFLO0FBQUEsSUFDN0U7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLGVBQVcsU0FBUztBQUNwQixnQkFBWSxLQUFLLFVBQVUsQ0FBQztBQUM1QixhQUFTLFlBQVksT0FBTztBQUFBLEVBQzlCO0FBQ0EsTUFBSSxPQUFPO0FBQ1gsTUFBSSxVQUFVO0FBQ2QsTUFBaUQsT0FBTyxZQUFZLEtBQUssT0FBTyxZQUFZLE1BQU07QUFDaEcsS0FBQyxNQUFNLE9BQU8sSUFBSSxhQUFhLE1BQU07QUFBQSxFQUN2QztBQUNBLE1BQUksb0JBQW9CLGlCQUFpQixPQUFPO0FBQzlDLFVBQU0sT0FBTyxPQUFPLEtBQUssZ0JBQWdCO0FBQ3pDLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFDdEIsUUFBSSxLQUFLLFFBQVE7QUFDZixVQUFJLGFBQWEsSUFBSSxJQUFJO0FBQ3ZCLFlBQUksZ0JBQWdCLEtBQUssS0FBSyxlQUFlLEdBQUc7QUFDOUMsNkJBQW1CO0FBQUEsWUFDakI7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxlQUFPLFdBQVcsTUFBTSxrQkFBa0IsT0FBTyxJQUFJO0FBQUEsTUFDdkQsV0FBd0QsQ0FBQyxpQkFBaUIsS0FBSyxTQUFTLFNBQVM7QUFDL0YsY0FBTSxXQUFXLE9BQU8sS0FBSyxLQUFLO0FBQ2xDLGNBQU0sYUFBYSxDQUFDO0FBQ3BCLGNBQU0sYUFBYSxDQUFDO0FBQ3BCLGlCQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxJQUFJLEdBQUcsS0FBSztBQUMvQyxnQkFBTSxNQUFNLFNBQVMsQ0FBQztBQUN0QixjQUFJLEtBQUssR0FBRyxHQUFHO0FBQ2IsZ0JBQUksQ0FBQyxnQkFBZ0IsR0FBRyxHQUFHO0FBQ3pCLHlCQUFXLEtBQUssSUFBSSxDQUFDLEVBQUUsWUFBWSxJQUFJLElBQUksTUFBTSxDQUFDLENBQUM7QUFBQSxZQUNyRDtBQUFBLFVBQ0YsT0FBTztBQUNMLHVCQUFXLEtBQUssR0FBRztBQUFBLFVBQ3JCO0FBQUEsUUFDRjtBQUNBLFlBQUksV0FBVyxRQUFRO0FBQ3JCO0FBQUEsWUFDRSxvQ0FBb0MsV0FBVyxLQUFLLElBQUksQ0FBQztBQUFBLFVBQzNEO0FBQUEsUUFDRjtBQUNBLFlBQUksV0FBVyxRQUFRO0FBQ3JCO0FBQUEsWUFDRSx5Q0FBeUMsV0FBVyxLQUFLLElBQUksQ0FBQztBQUFBLFVBQ2hFO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLE1BQUksTUFBTSxNQUFNO0FBQ2QsUUFBaUQsQ0FBQyxjQUFjLElBQUksR0FBRztBQUNyRTtBQUFBLFFBQ0U7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU8sV0FBVyxNQUFNLE1BQU0sT0FBTyxJQUFJO0FBQ3pDLFNBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxLQUFLLE9BQU8sTUFBTSxJQUFJLElBQUksTUFBTTtBQUFBLEVBQy9EO0FBQ0EsTUFBSSxNQUFNLFlBQVk7QUFDcEIsVUFBTSxRQUFRLFdBQVcsS0FBSyxJQUFJLElBQUksZ0JBQWdCLElBQUksS0FBSyxPQUFPO0FBQ3RFLFFBQWlELENBQUMsY0FBYyxLQUFLLEdBQUc7QUFDdEU7QUFBQSxRQUNFO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSx1QkFBbUIsT0FBTyxNQUFNLFVBQVU7QUFBQSxFQUM1QztBQUNBLE1BQWlELFNBQVM7QUFDeEQsWUFBUSxJQUFJO0FBQUEsRUFDZCxPQUFPO0FBQ0wsYUFBUztBQUFBLEVBQ1g7QUFDQSw4QkFBNEIsSUFBSTtBQUNoQyxTQUFPO0FBQ1Q7QUFDQSxNQUFNLGVBQWUsQ0FBQyxVQUFVO0FBQzlCLFFBQU0sY0FBYyxNQUFNO0FBQzFCLFFBQU0sa0JBQWtCLE1BQU07QUFDOUIsUUFBTSxZQUFZLGlCQUFpQixhQUFhLEtBQUs7QUFDckQsTUFBSSxDQUFDLFdBQVc7QUFDZCxXQUFPLENBQUMsT0FBTyxNQUFNO0FBQUEsRUFDdkIsV0FBd0QsVUFBVSxZQUFZLEtBQUssVUFBVSxZQUFZLE1BQU07QUFDN0csV0FBTyxhQUFhLFNBQVM7QUFBQSxFQUMvQjtBQUNBLFFBQU0sUUFBUSxZQUFZLFFBQVEsU0FBUztBQUMzQyxRQUFNLGVBQWUsa0JBQWtCLGdCQUFnQixRQUFRLFNBQVMsSUFBSTtBQUM1RSxRQUFNLFVBQVUsQ0FBQyxnQkFBZ0I7QUFDL0IsZ0JBQVksS0FBSyxJQUFJO0FBQ3JCLFFBQUksaUJBQWlCO0FBQ25CLFVBQUksZUFBZSxJQUFJO0FBQ3JCLHdCQUFnQixZQUFZLElBQUk7QUFBQSxNQUNsQyxXQUFXLFlBQVksWUFBWSxHQUFHO0FBQ3BDLGNBQU0sa0JBQWtCLENBQUMsR0FBRyxpQkFBaUIsV0FBVztBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLENBQUMsZUFBZSxTQUFTLEdBQUcsT0FBTztBQUM1QztBQUNBLFNBQVMsaUJBQWlCLFVBQVUsVUFBVSxNQUFNO0FBQ2xELE1BQUk7QUFDSixXQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3hDLFVBQU0sUUFBUSxTQUFTLENBQUM7QUFDeEIsUUFBSSxRQUFRLEtBQUssR0FBRztBQUNsQixVQUFJLE1BQU0sU0FBUyxXQUFXLE1BQU0sYUFBYSxRQUFRO0FBQ3ZELFlBQUksWUFBWTtBQUNkO0FBQUEsUUFDRixPQUFPO0FBQ0wsdUJBQWE7QUFDYixjQUFpRCxXQUFXLFdBQVcsWUFBWSxLQUFLLFdBQVcsWUFBWSxNQUFNO0FBQ25ILG1CQUFPLGlCQUFpQixXQUFXLFFBQVE7QUFBQSxVQUM3QztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0w7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLE1BQU0sMkJBQTJCLENBQUMsVUFBVTtBQUMxQyxNQUFJO0FBQ0osYUFBVyxPQUFPLE9BQU87QUFDdkIsUUFBSSxRQUFRLFdBQVcsUUFBUSxXQUFXLEtBQUssR0FBRyxHQUFHO0FBQ25ELE9BQUMsUUFBUSxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksTUFBTSxHQUFHO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsTUFBTSx1QkFBdUIsQ0FBQyxPQUFPLFVBQVU7QUFDN0MsUUFBTSxNQUFNLENBQUM7QUFDYixhQUFXLE9BQU8sT0FBTztBQUN2QixRQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxFQUFFLElBQUksTUFBTSxDQUFDLEtBQUssUUFBUTtBQUNyRCxVQUFJLEdBQUcsSUFBSSxNQUFNLEdBQUc7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxNQUFNLGdCQUFnQixDQUFDLFVBQVU7QUFDL0IsU0FBTyxNQUFNLGFBQWEsSUFBSSxNQUFNLE1BQU0sU0FBUztBQUNyRDtBQUNBLFNBQVMsc0JBQXNCLFdBQVcsV0FBVyxXQUFXO0FBQzlELFFBQU0sRUFBRSxPQUFPLFdBQVcsVUFBVSxjQUFjLFVBQVUsSUFBSTtBQUNoRSxRQUFNLEVBQUUsT0FBTyxXQUFXLFVBQVUsY0FBYyxVQUFVLElBQUk7QUFDaEUsUUFBTSxRQUFRLFVBQVU7QUFDeEIsT0FBa0QsZ0JBQWdCLGlCQUFpQixlQUFlO0FBQ2hHLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxVQUFVLFFBQVEsVUFBVSxZQUFZO0FBQzFDLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxhQUFhLGFBQWEsR0FBRztBQUMvQixRQUFJLFlBQVksTUFBTTtBQUNwQixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksWUFBWSxJQUFJO0FBQ2xCLFVBQUksQ0FBQyxXQUFXO0FBQ2QsZUFBTyxDQUFDLENBQUM7QUFBQSxNQUNYO0FBQ0EsYUFBTyxnQkFBZ0IsV0FBVyxXQUFXLEtBQUs7QUFBQSxJQUNwRCxXQUFXLFlBQVksR0FBRztBQUN4QixZQUFNLGVBQWUsVUFBVTtBQUMvQixlQUFTLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLO0FBQzVDLGNBQU0sTUFBTSxhQUFhLENBQUM7QUFDMUIsWUFBSSxvQkFBb0IsV0FBVyxXQUFXLEdBQUcsS0FBSyxDQUFDLGVBQWUsT0FBTyxHQUFHLEdBQUc7QUFDakYsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGLE9BQU87QUFDTCxRQUFJLGdCQUFnQixjQUFjO0FBQ2hDLFVBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLFNBQVM7QUFDMUMsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsUUFBSSxjQUFjLFdBQVc7QUFDM0IsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLENBQUMsV0FBVztBQUNkLGFBQU8sQ0FBQyxDQUFDO0FBQUEsSUFDWDtBQUNBLFFBQUksQ0FBQyxXQUFXO0FBQ2QsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLGdCQUFnQixXQUFXLFdBQVcsS0FBSztBQUFBLEVBQ3BEO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsV0FBVyxXQUFXLGNBQWM7QUFDM0QsUUFBTSxXQUFXLE9BQU8sS0FBSyxTQUFTO0FBQ3RDLE1BQUksU0FBUyxXQUFXLE9BQU8sS0FBSyxTQUFTLEVBQUUsUUFBUTtBQUNyRCxXQUFPO0FBQUEsRUFDVDtBQUNBLFdBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDeEMsVUFBTSxNQUFNLFNBQVMsQ0FBQztBQUN0QixRQUFJLG9CQUFvQixXQUFXLFdBQVcsR0FBRyxLQUFLLENBQUMsZUFBZSxjQUFjLEdBQUcsR0FBRztBQUN4RixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLG9CQUFvQixXQUFXLFdBQVcsS0FBSztBQUN0RCxRQUFNLFdBQVcsVUFBVSxHQUFHO0FBQzlCLFFBQU0sV0FBVyxVQUFVLEdBQUc7QUFDOUIsTUFBSSxRQUFRLFdBQVcsU0FBUyxRQUFRLEtBQUssU0FBUyxRQUFRLEdBQUc7QUFDL0QsV0FBTyxDQUFDLFdBQVcsVUFBVSxRQUFRO0FBQUEsRUFDdkM7QUFDQSxTQUFPLGFBQWE7QUFDdEI7QUFDQSxTQUFTLGdCQUFnQixFQUFFLE9BQU8sUUFBUSxTQUFTLEdBQUcsSUFBSTtBQUN4RCxTQUFPLFFBQVE7QUFDYixVQUFNLE9BQU8sT0FBTztBQUNwQixRQUFJLEtBQUssWUFBWSxLQUFLLFNBQVMsaUJBQWlCLE9BQU87QUFDekQsV0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLEtBQUs7QUFDbkMsY0FBUTtBQUFBLElBQ1Y7QUFDQSxRQUFJLFNBQVMsT0FBTztBQUNsQixPQUFDLFFBQVEsT0FBTyxPQUFPLEtBQUs7QUFDNUIsZUFBUyxPQUFPO0FBQUEsSUFDbEIsT0FBTztBQUNMO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFlBQVksU0FBUyxpQkFBaUIsT0FBTztBQUMvQyxhQUFTLE1BQU0sS0FBSztBQUFBLEVBQ3RCO0FBQ0Y7QUFFQSxNQUFNLHNCQUFzQixDQUFDO0FBQzdCLE1BQU0sdUJBQXVCLE1BQU0sT0FBTyxPQUFPLG1CQUFtQjtBQUNwRSxNQUFNLG1CQUFtQixDQUFDLFFBQVEsT0FBTyxlQUFlLEdBQUcsTUFBTTtBQUVqRSxTQUFTLFVBQVUsVUFBVSxVQUFVLFlBQVksUUFBUSxPQUFPO0FBQ2hFLFFBQU0sUUFBUSxDQUFDO0FBQ2YsUUFBTSxRQUFRLHFCQUFxQjtBQUNuQyxXQUFTLGdCQUFnQyx1QkFBTyxPQUFPLElBQUk7QUFDM0QsZUFBYSxVQUFVLFVBQVUsT0FBTyxLQUFLO0FBQzdDLGFBQVcsT0FBTyxTQUFTLGFBQWEsQ0FBQyxHQUFHO0FBQzFDLFFBQUksRUFBRSxPQUFPLFFBQVE7QUFDbkIsWUFBTSxHQUFHLElBQUk7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLE1BQUksTUFBMkM7QUFDN0Msa0JBQWMsWUFBWSxDQUFDLEdBQUcsT0FBTyxRQUFRO0FBQUEsRUFDL0M7QUFDQSxNQUFJLFlBQVk7QUFDZCxhQUFTLFFBQVEsUUFBUSxRQUFRLGdCQUFnQixLQUFLO0FBQUEsRUFDeEQsT0FBTztBQUNMLFFBQUksQ0FBQyxTQUFTLEtBQUssT0FBTztBQUN4QixlQUFTLFFBQVE7QUFBQSxJQUNuQixPQUFPO0FBQ0wsZUFBUyxRQUFRO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsV0FBUyxRQUFRO0FBQ25CO0FBQ0EsU0FBUyxlQUFlLFVBQVU7QUFDaEMsU0FBTyxVQUFVO0FBQ2YsUUFBSSxTQUFTLEtBQUssUUFBUyxRQUFPO0FBQ2xDLGVBQVcsU0FBUztBQUFBLEVBQ3RCO0FBQ0Y7QUFDQSxTQUFTLFlBQVksVUFBVSxVQUFVLGNBQWMsV0FBVztBQUNoRSxRQUFNO0FBQUEsSUFDSjtBQUFBLElBQ0E7QUFBQSxJQUNBLE9BQU8sRUFBRSxVQUFVO0FBQUEsRUFDckIsSUFBSTtBQUNKLFFBQU0sa0JBQWtCLE1BQU0sS0FBSztBQUNuQyxRQUFNLENBQUMsT0FBTyxJQUFJLFNBQVM7QUFDM0IsTUFBSSxrQkFBa0I7QUFDdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlFLENBQStDLGVBQWUsUUFBUSxNQUFPLGFBQWEsWUFBWSxNQUFNLEVBQUUsWUFBWTtBQUFBLElBQzFIO0FBQ0EsUUFBSSxZQUFZLEdBQUc7QUFDakIsWUFBTSxnQkFBZ0IsU0FBUyxNQUFNO0FBQ3JDLGVBQVMsSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQUs7QUFDN0MsWUFBSSxNQUFNLGNBQWMsQ0FBQztBQUN6QixZQUFJLGVBQWUsU0FBUyxjQUFjLEdBQUcsR0FBRztBQUM5QztBQUFBLFFBQ0Y7QUFDQSxjQUFNLFFBQVEsU0FBUyxHQUFHO0FBQzFCLFlBQUksU0FBUztBQUNYLGNBQUksT0FBTyxPQUFPLEdBQUcsR0FBRztBQUN0QixnQkFBSSxVQUFVLE1BQU0sR0FBRyxHQUFHO0FBQ3hCLG9CQUFNLEdBQUcsSUFBSTtBQUNiLGdDQUFrQjtBQUFBLFlBQ3BCO0FBQUEsVUFDRixPQUFPO0FBQ0wsa0JBQU0sZUFBZSxTQUFTLEdBQUc7QUFDakMsa0JBQU0sWUFBWSxJQUFJO0FBQUEsY0FDcEI7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRixPQUFPO0FBQ0wsY0FBSSxVQUFVLE1BQU0sR0FBRyxHQUFHO0FBQ3hCLGtCQUFNLEdBQUcsSUFBSTtBQUNiLDhCQUFrQjtBQUFBLFVBQ3BCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixPQUFPO0FBQ0wsUUFBSSxhQUFhLFVBQVUsVUFBVSxPQUFPLEtBQUssR0FBRztBQUNsRCx3QkFBa0I7QUFBQSxJQUNwQjtBQUNBLFFBQUk7QUFDSixlQUFXLE9BQU8saUJBQWlCO0FBQ2pDLFVBQUksQ0FBQztBQUFBLE1BQ0wsQ0FBQyxPQUFPLFVBQVUsR0FBRztBQUFBO0FBQUEsUUFFbkIsV0FBVyxVQUFVLEdBQUcsT0FBTyxPQUFPLENBQUMsT0FBTyxVQUFVLFFBQVEsSUFBSTtBQUNwRSxZQUFJLFNBQVM7QUFDWCxjQUFJO0FBQUEsV0FDSCxhQUFhLEdBQUcsTUFBTTtBQUFBLFVBQ3ZCLGFBQWEsUUFBUSxNQUFNLFNBQVM7QUFDbEMsa0JBQU0sR0FBRyxJQUFJO0FBQUEsY0FDWDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLE9BQU87QUFDTCxpQkFBTyxNQUFNLEdBQUc7QUFBQSxRQUNsQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxVQUFVLGlCQUFpQjtBQUM3QixpQkFBVyxPQUFPLE9BQU87QUFDdkIsWUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLFVBQVUsR0FBRyxLQUFLLE1BQU07QUFDL0MsaUJBQU8sTUFBTSxHQUFHO0FBQ2hCLDRCQUFrQjtBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxpQkFBaUI7QUFDbkIsWUFBUSxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBQUEsRUFDbkM7QUFDQSxNQUFJLE1BQTJDO0FBQzdDLGtCQUFjLFlBQVksQ0FBQyxHQUFHLE9BQU8sUUFBUTtBQUFBLEVBQy9DO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsVUFBVSxVQUFVLE9BQU8sT0FBTztBQUN0RCxRQUFNLENBQUMsU0FBUyxZQUFZLElBQUksU0FBUztBQUN6QyxNQUFJLGtCQUFrQjtBQUN0QixNQUFJO0FBQ0osTUFBSSxVQUFVO0FBQ1osYUFBUyxPQUFPLFVBQVU7QUFDeEIsVUFBSSxlQUFlLEdBQUcsR0FBRztBQUN2QjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLFFBQVEsU0FBUyxHQUFHO0FBQzFCLFVBQUk7QUFDSixVQUFJLFdBQVcsT0FBTyxTQUFTLFdBQVcsU0FBUyxHQUFHLENBQUMsR0FBRztBQUN4RCxZQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxTQUFTLFFBQVEsR0FBRztBQUNyRCxnQkFBTSxRQUFRLElBQUk7QUFBQSxRQUNwQixPQUFPO0FBQ0wsV0FBQyxrQkFBa0IsZ0JBQWdCLENBQUMsSUFBSSxRQUFRLElBQUk7QUFBQSxRQUN0RDtBQUFBLE1BQ0YsV0FBVyxDQUFDLGVBQWUsU0FBUyxjQUFjLEdBQUcsR0FBRztBQUN0RCxZQUFJLEVBQUUsT0FBTyxVQUFVLFVBQVUsTUFBTSxHQUFHLEdBQUc7QUFDM0MsZ0JBQU0sR0FBRyxJQUFJO0FBQ2IsNEJBQWtCO0FBQUEsUUFDcEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGNBQWM7QUFDaEIsVUFBTSxrQkFBa0IsTUFBTSxLQUFLO0FBQ25DLFVBQU0sYUFBYSxpQkFBaUI7QUFDcEMsYUFBUyxJQUFJLEdBQUcsSUFBSSxhQUFhLFFBQVEsS0FBSztBQUM1QyxZQUFNLE1BQU0sYUFBYSxDQUFDO0FBQzFCLFlBQU0sR0FBRyxJQUFJO0FBQUEsUUFDWDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxXQUFXLEdBQUc7QUFBQSxRQUNkO0FBQUEsUUFDQSxDQUFDLE9BQU8sWUFBWSxHQUFHO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLFNBQVMsT0FBTyxLQUFLLE9BQU8sVUFBVSxVQUFVO0FBQ3hFLFFBQU0sTUFBTSxRQUFRLEdBQUc7QUFDdkIsTUFBSSxPQUFPLE1BQU07QUFDZixVQUFNLGFBQWEsT0FBTyxLQUFLLFNBQVM7QUFDeEMsUUFBSSxjQUFjLFVBQVUsUUFBUTtBQUNsQyxZQUFNLGVBQWUsSUFBSTtBQUN6QixVQUFJLElBQUksU0FBUyxZQUFZLENBQUMsSUFBSSxlQUFlLFdBQVcsWUFBWSxHQUFHO0FBQ3pFLGNBQU0sRUFBRSxjQUFjLElBQUk7QUFDMUIsWUFBSSxPQUFPLGVBQWU7QUFDeEIsa0JBQVEsY0FBYyxHQUFHO0FBQUEsUUFDM0IsT0FBTztBQUNMLGdCQUFNLFFBQVEsbUJBQW1CLFFBQVE7QUFDekMsa0JBQVEsY0FBYyxHQUFHLElBQUksYUFBYTtBQUFBLFlBQ3hDO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQSxnQkFBTTtBQUFBLFFBQ1I7QUFBQSxNQUNGLE9BQU87QUFDTCxnQkFBUTtBQUFBLE1BQ1Y7QUFDQSxVQUFJLFNBQVMsSUFBSTtBQUNmLGlCQUFTLEdBQUcsU0FBUyxLQUFLLEtBQUs7QUFBQSxNQUNqQztBQUFBLElBQ0Y7QUFDQSxRQUFJO0FBQUEsTUFBSTtBQUFBO0FBQUEsSUFBa0IsR0FBRztBQUMzQixVQUFJLFlBQVksQ0FBQyxZQUFZO0FBQzNCLGdCQUFRO0FBQUEsTUFDVixXQUFXO0FBQUEsUUFBSTtBQUFBO0FBQUEsTUFBc0IsTUFBTSxVQUFVLE1BQU0sVUFBVSxVQUFVLEdBQUcsSUFBSTtBQUNwRixnQkFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLE1BQU0sa0JBQWtDLG9CQUFJLFFBQVE7QUFDcEQsU0FBUyxzQkFBc0IsTUFBTSxZQUFZLFVBQVUsT0FBTztBQUNoRSxRQUFNLFFBQVEsdUJBQXVCLFVBQVUsa0JBQWtCLFdBQVc7QUFDNUUsUUFBTSxTQUFTLE1BQU0sSUFBSSxJQUFJO0FBQzdCLE1BQUksUUFBUTtBQUNWLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxNQUFNLEtBQUs7QUFDakIsUUFBTSxhQUFhLENBQUM7QUFDcEIsUUFBTSxlQUFlLENBQUM7QUFDdEIsTUFBSSxhQUFhO0FBQ2pCLE1BQUksdUJBQXVCLENBQUMsV0FBVyxJQUFJLEdBQUc7QUFDNUMsVUFBTSxjQUFjLENBQUMsU0FBUztBQUM1QixtQkFBYTtBQUNiLFlBQU0sQ0FBQyxPQUFPLElBQUksSUFBSSxzQkFBc0IsTUFBTSxZQUFZLElBQUk7QUFDbEUsYUFBTyxZQUFZLEtBQUs7QUFDeEIsVUFBSSxLQUFNLGNBQWEsS0FBSyxHQUFHLElBQUk7QUFBQSxJQUNyQztBQUNBLFFBQUksQ0FBQyxXQUFXLFdBQVcsT0FBTyxRQUFRO0FBQ3hDLGlCQUFXLE9BQU8sUUFBUSxXQUFXO0FBQUEsSUFDdkM7QUFDQSxRQUFJLEtBQUssU0FBUztBQUNoQixrQkFBWSxLQUFLLE9BQU87QUFBQSxJQUMxQjtBQUNBLFFBQUksS0FBSyxRQUFRO0FBQ2YsV0FBSyxPQUFPLFFBQVEsV0FBVztBQUFBLElBQ2pDO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtBQUN2QixRQUFJLFNBQVMsSUFBSSxHQUFHO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLFNBQVM7QUFBQSxJQUMzQjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxRQUFRLEdBQUcsR0FBRztBQUNoQixhQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0FBQ25DLFVBQWlELENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxHQUFHO0FBQ2xFLGVBQU8sa0RBQWtELElBQUksQ0FBQyxDQUFDO0FBQUEsTUFDakU7QUFDQSxZQUFNLGdCQUFnQixTQUFTLElBQUksQ0FBQyxDQUFDO0FBQ3JDLFVBQUksaUJBQWlCLGFBQWEsR0FBRztBQUNuQyxtQkFBVyxhQUFhLElBQUk7QUFBQSxNQUM5QjtBQUFBLElBQ0Y7QUFBQSxFQUNGLFdBQVcsS0FBSztBQUNkLFFBQWlELENBQUMsU0FBUyxHQUFHLEdBQUc7QUFDL0QsYUFBTyx5QkFBeUIsR0FBRztBQUFBLElBQ3JDO0FBQ0EsZUFBVyxPQUFPLEtBQUs7QUFDckIsWUFBTSxnQkFBZ0IsU0FBUyxHQUFHO0FBQ2xDLFVBQUksaUJBQWlCLGFBQWEsR0FBRztBQUNuQyxjQUFNLE1BQU0sSUFBSSxHQUFHO0FBQ25CLGNBQU0sT0FBTyxXQUFXLGFBQWEsSUFBSSxRQUFRLEdBQUcsS0FBSyxXQUFXLEdBQUcsSUFBSSxFQUFFLE1BQU0sSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEdBQUc7QUFDekcsY0FBTSxXQUFXLEtBQUs7QUFDdEIsWUFBSSxhQUFhO0FBQ2pCLFlBQUksaUJBQWlCO0FBQ3JCLFlBQUksUUFBUSxRQUFRLEdBQUc7QUFDckIsbUJBQVMsUUFBUSxHQUFHLFFBQVEsU0FBUyxRQUFRLEVBQUUsT0FBTztBQUNwRCxrQkFBTSxPQUFPLFNBQVMsS0FBSztBQUMzQixrQkFBTSxXQUFXLFdBQVcsSUFBSSxLQUFLLEtBQUs7QUFDMUMsZ0JBQUksYUFBYSxXQUFXO0FBQzFCLDJCQUFhO0FBQ2I7QUFBQSxZQUNGLFdBQVcsYUFBYSxVQUFVO0FBQ2hDLCtCQUFpQjtBQUFBLFlBQ25CO0FBQUEsVUFDRjtBQUFBLFFBQ0YsT0FBTztBQUNMLHVCQUFhLFdBQVcsUUFBUSxLQUFLLFNBQVMsU0FBUztBQUFBLFFBQ3pEO0FBQ0E7QUFBQSxVQUFLO0FBQUE7QUFBQSxRQUFrQixJQUFJO0FBQzNCO0FBQUEsVUFBSztBQUFBO0FBQUEsUUFBc0IsSUFBSTtBQUMvQixZQUFJLGNBQWMsT0FBTyxNQUFNLFNBQVMsR0FBRztBQUN6Qyx1QkFBYSxLQUFLLGFBQWE7QUFBQSxRQUNqQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0sTUFBTSxDQUFDLFlBQVksWUFBWTtBQUNyQyxNQUFJLFNBQVMsSUFBSSxHQUFHO0FBQ2xCLFVBQU0sSUFBSSxNQUFNLEdBQUc7QUFBQSxFQUNyQjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLEtBQUs7QUFDN0IsTUFBSSxJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsZUFBZSxHQUFHLEdBQUc7QUFDMUMsV0FBTztBQUFBLEVBQ1QsV0FBVyxNQUEyQztBQUNwRCxXQUFPLHVCQUF1QixHQUFHLDJCQUEyQjtBQUFBLEVBQzlEO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxRQUFRLE1BQU07QUFDckIsTUFBSSxTQUFTLE1BQU07QUFDakIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLE9BQU8sU0FBUyxZQUFZO0FBQzlCLFdBQU8sS0FBSyxRQUFRO0FBQUEsRUFDdEIsV0FBVyxPQUFPLFNBQVMsVUFBVTtBQUNuQyxVQUFNLE9BQU8sS0FBSyxlQUFlLEtBQUssWUFBWTtBQUNsRCxXQUFPLFFBQVE7QUFBQSxFQUNqQjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxVQUFVLE9BQU8sVUFBVTtBQUNoRCxRQUFNLGlCQUFpQixNQUFNLEtBQUs7QUFDbEMsUUFBTSxVQUFVLFNBQVMsYUFBYSxDQUFDO0FBQ3ZDLFFBQU0sbUJBQW1CLE9BQU8sS0FBSyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsU0FBUyxHQUFHLENBQUM7QUFDekUsYUFBVyxPQUFPLFNBQVM7QUFDekIsUUFBSSxNQUFNLFFBQVEsR0FBRztBQUNyQixRQUFJLE9BQU8sS0FBTTtBQUNqQjtBQUFBLE1BQ0U7QUFBQSxNQUNBLGVBQWUsR0FBRztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxPQUE0QyxnQkFBZ0IsY0FBYyxJQUFJO0FBQUEsTUFDOUUsQ0FBQyxpQkFBaUIsU0FBUyxHQUFHO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsTUFBTSxPQUFPLE1BQU0sT0FBTyxVQUFVO0FBQ3hELFFBQU0sRUFBRSxNQUFNLFVBQVUsV0FBVyxVQUFVLElBQUk7QUFDakQsTUFBSSxZQUFZLFVBQVU7QUFDeEIsV0FBTyw2QkFBNkIsT0FBTyxHQUFHO0FBQzlDO0FBQUEsRUFDRjtBQUNBLE1BQUksU0FBUyxRQUFRLENBQUMsVUFBVTtBQUM5QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVEsUUFBUSxTQUFTLFFBQVEsQ0FBQyxXQUFXO0FBQy9DLFFBQUksVUFBVTtBQUNkLFVBQU0sUUFBUSxRQUFRLElBQUksSUFBSSxPQUFPLENBQUMsSUFBSTtBQUMxQyxVQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLGFBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxVQUFVLENBQUMsU0FBUyxLQUFLO0FBQ2pELFlBQU0sRUFBRSxPQUFPLGFBQWEsSUFBSSxXQUFXLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFDMUQsb0JBQWMsS0FBSyxnQkFBZ0IsRUFBRTtBQUNyQyxnQkFBVTtBQUFBLElBQ1o7QUFDQSxRQUFJLENBQUMsU0FBUztBQUNaLGFBQU8sc0JBQXNCLE1BQU0sT0FBTyxhQUFhLENBQUM7QUFDeEQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLE1BQUksYUFBYSxDQUFDLFVBQVUsT0FBTyxLQUFLLEdBQUc7QUFDekMsV0FBTywyREFBMkQsT0FBTyxJQUFJO0FBQUEsRUFDL0U7QUFDRjtBQUNBLE1BQU0sZUFBK0I7QUFBQSxFQUNuQztBQUNGO0FBQ0EsU0FBUyxXQUFXLE9BQU8sTUFBTTtBQUMvQixNQUFJO0FBQ0osUUFBTSxlQUFlLFFBQVEsSUFBSTtBQUNqQyxNQUFJLGlCQUFpQixRQUFRO0FBQzNCLFlBQVEsVUFBVTtBQUFBLEVBQ3BCLFdBQVcsYUFBYSxZQUFZLEdBQUc7QUFDckMsVUFBTSxJQUFJLE9BQU87QUFDakIsWUFBUSxNQUFNLGFBQWEsWUFBWTtBQUN2QyxRQUFJLENBQUMsU0FBUyxNQUFNLFVBQVU7QUFDNUIsY0FBUSxpQkFBaUI7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsV0FBVyxpQkFBaUIsVUFBVTtBQUNwQyxZQUFRLFNBQVMsS0FBSztBQUFBLEVBQ3hCLFdBQVcsaUJBQWlCLFNBQVM7QUFDbkMsWUFBUSxRQUFRLEtBQUs7QUFBQSxFQUN2QixPQUFPO0FBQ0wsWUFBUSxpQkFBaUI7QUFBQSxFQUMzQjtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLE1BQU0sT0FBTyxlQUFlO0FBQ3pELE1BQUksY0FBYyxXQUFXLEdBQUc7QUFDOUIsV0FBTywwQkFBMEIsSUFBSTtBQUFBLEVBQ3ZDO0FBQ0EsTUFBSSxVQUFVLDZDQUE2QyxJQUFJLGVBQWUsY0FBYyxJQUFJLFVBQVUsRUFBRSxLQUFLLEtBQUssQ0FBQztBQUN2SCxRQUFNLGVBQWUsY0FBYyxDQUFDO0FBQ3BDLFFBQU0sZUFBZSxVQUFVLEtBQUs7QUFDcEMsUUFBTSxnQkFBZ0IsV0FBVyxPQUFPLFlBQVk7QUFDcEQsUUFBTSxnQkFBZ0IsV0FBVyxPQUFPLFlBQVk7QUFDcEQsTUFBSSxjQUFjLFdBQVcsS0FBSyxhQUFhLFlBQVksS0FBSyxZQUFZLGNBQWMsWUFBWSxHQUFHO0FBQ3ZHLGVBQVcsZUFBZSxhQUFhO0FBQUEsRUFDekM7QUFDQSxhQUFXLFNBQVMsWUFBWTtBQUNoQyxNQUFJLGFBQWEsWUFBWSxHQUFHO0FBQzlCLGVBQVcsY0FBYyxhQUFhO0FBQUEsRUFDeEM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsT0FBTyxNQUFNO0FBQy9CLE1BQUksU0FBUyxLQUFLLEdBQUc7QUFDbkIsV0FBTyxNQUFNLFNBQVM7QUFBQSxFQUN4QixXQUFXLFNBQVMsVUFBVTtBQUM1QixXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCLFdBQVcsU0FBUyxVQUFVO0FBQzVCLFdBQU8sR0FBRyxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQ3pCLE9BQU87QUFDTCxXQUFPLEdBQUcsS0FBSztBQUFBLEVBQ2pCO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsTUFBTTtBQUMxQixRQUFNLGdCQUFnQixDQUFDLFVBQVUsVUFBVSxTQUFTO0FBQ3BELFNBQU8sY0FBYyxLQUFLLENBQUMsU0FBUyxLQUFLLFlBQVksTUFBTSxJQUFJO0FBQ2pFO0FBQ0EsU0FBUyxlQUFlLE1BQU07QUFDNUIsU0FBTyxLQUFLLE1BQU0sQ0FBQyxTQUFTO0FBQzFCLFVBQU0sUUFBUSxLQUFLLFlBQVk7QUFDL0IsV0FBTyxVQUFVLGFBQWEsVUFBVTtBQUFBLEVBQzFDLENBQUM7QUFDSDtBQUVBLE1BQU0sZ0JBQWdCLENBQUMsUUFBUSxRQUFRLE9BQU8sUUFBUSxVQUFVLFFBQVE7QUFDeEUsTUFBTSxxQkFBcUIsQ0FBQyxVQUFVLFFBQVEsS0FBSyxJQUFJLE1BQU0sSUFBSSxjQUFjLElBQUksQ0FBQyxlQUFlLEtBQUssQ0FBQztBQUN6RyxNQUFNLGdCQUFnQixDQUFDLEtBQUssU0FBUyxRQUFRO0FBQzNDLE1BQUksUUFBUSxJQUFJO0FBQ2QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGFBQWEsUUFBUSxJQUFJLFNBQVM7QUFDdEMsUUFBaUQsbUJBQW1CLEVBQUUsUUFBUSxRQUFRLDZCQUE2QixFQUFFLE9BQU8sSUFBSSxTQUFTLGdCQUFnQixPQUFPO0FBQzlKO0FBQUEsUUFDRSxTQUFTLEdBQUc7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUNBLFdBQU8sbUJBQW1CLFFBQVEsR0FBRyxJQUFJLENBQUM7QUFBQSxFQUM1QyxHQUFHLEdBQUc7QUFDTixhQUFXLEtBQUs7QUFDaEIsU0FBTztBQUNUO0FBQ0EsTUFBTSx1QkFBdUIsQ0FBQyxVQUFVLE9BQU8sYUFBYTtBQUMxRCxRQUFNLE1BQU0sU0FBUztBQUNyQixhQUFXLE9BQU8sVUFBVTtBQUMxQixRQUFJLGNBQWMsR0FBRyxFQUFHO0FBQ3hCLFVBQU0sUUFBUSxTQUFTLEdBQUc7QUFDMUIsUUFBSSxXQUFXLEtBQUssR0FBRztBQUNyQixZQUFNLEdBQUcsSUFBSSxjQUFjLEtBQUssT0FBTyxHQUFHO0FBQUEsSUFDNUMsV0FBVyxTQUFTLE1BQU07QUFDeEIsVUFBaUQsTUFBTTtBQUNyRDtBQUFBLFVBQ0UsNENBQTRDLEdBQUc7QUFBQSxRQUNqRDtBQUFBLE1BQ0Y7QUFDQSxZQUFNLGFBQWEsbUJBQW1CLEtBQUs7QUFDM0MsWUFBTSxHQUFHLElBQUksTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxzQkFBc0IsQ0FBQyxVQUFVLGFBQWE7QUFDbEQsTUFBaUQsQ0FBQyxZQUFZLFNBQVMsS0FBSyxLQUFLLE1BQU07QUFDckY7QUFBQSxNQUNFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsbUJBQW1CLFFBQVE7QUFDOUMsV0FBUyxNQUFNLFVBQVUsTUFBTTtBQUNqQztBQUNBLE1BQU0sY0FBYyxDQUFDLE9BQU8sVUFBVSxjQUFjO0FBQ2xELGFBQVcsT0FBTyxVQUFVO0FBQzFCLFFBQUksYUFBYSxDQUFDLGNBQWMsR0FBRyxHQUFHO0FBQ3BDLFlBQU0sR0FBRyxJQUFJLFNBQVMsR0FBRztBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxZQUFZLENBQUMsVUFBVSxVQUFVLGNBQWM7QUFDbkQsUUFBTSxRQUFRLFNBQVMsUUFBUSxxQkFBcUI7QUFDcEQsTUFBSSxTQUFTLE1BQU0sWUFBWSxJQUFJO0FBQ2pDLFVBQU0sT0FBTyxTQUFTO0FBQ3RCLFFBQUksTUFBTTtBQUNSLGtCQUFZLE9BQU8sVUFBVSxTQUFTO0FBQ3RDLFVBQUksV0FBVztBQUNiLFlBQUksT0FBTyxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQzVCO0FBQUEsSUFDRixPQUFPO0FBQ0wsMkJBQXFCLFVBQVUsS0FBSztBQUFBLElBQ3RDO0FBQUEsRUFDRixXQUFXLFVBQVU7QUFDbkIsd0JBQW9CLFVBQVUsUUFBUTtBQUFBLEVBQ3hDO0FBQ0Y7QUFDQSxNQUFNLGNBQWMsQ0FBQyxVQUFVLFVBQVUsY0FBYztBQUNyRCxRQUFNLEVBQUUsT0FBTyxNQUFNLElBQUk7QUFDekIsTUFBSSxvQkFBb0I7QUFDeEIsTUFBSSwyQkFBMkI7QUFDL0IsTUFBSSxNQUFNLFlBQVksSUFBSTtBQUN4QixVQUFNLE9BQU8sU0FBUztBQUN0QixRQUFJLE1BQU07QUFDUixVQUFpRCxlQUFlO0FBQzlELG9CQUFZLE9BQU8sVUFBVSxTQUFTO0FBQ3RDLGdCQUFRLFVBQVUsT0FBTyxRQUFRO0FBQUEsTUFDbkMsV0FBVyxhQUFhLFNBQVMsR0FBRztBQUNsQyw0QkFBb0I7QUFBQSxNQUN0QixPQUFPO0FBQ0wsb0JBQVksT0FBTyxVQUFVLFNBQVM7QUFBQSxNQUN4QztBQUFBLElBQ0YsT0FBTztBQUNMLDBCQUFvQixDQUFDLFNBQVM7QUFDOUIsMkJBQXFCLFVBQVUsS0FBSztBQUFBLElBQ3RDO0FBQ0EsK0JBQTJCO0FBQUEsRUFDN0IsV0FBVyxVQUFVO0FBQ25CLHdCQUFvQixVQUFVLFFBQVE7QUFDdEMsK0JBQTJCLEVBQUUsU0FBUyxFQUFFO0FBQUEsRUFDMUM7QUFDQSxNQUFJLG1CQUFtQjtBQUNyQixlQUFXLE9BQU8sT0FBTztBQUN2QixVQUFJLENBQUMsY0FBYyxHQUFHLEtBQUsseUJBQXlCLEdBQUcsS0FBSyxNQUFNO0FBQ2hFLGVBQU8sTUFBTSxHQUFHO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBRUEsSUFBSTtBQUNKLElBQUk7QUFDSixTQUFTLGFBQWEsVUFBVSxNQUFNO0FBQ3BDLE1BQUksU0FBUyxXQUFXLE9BQU8sZUFBZSxZQUFZLEdBQUc7QUFDM0QsU0FBSyxLQUFLLE9BQU8sSUFBSSxJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQUEsRUFDekM7QUFDQSxNQUFJLE1BQW9FO0FBQ3RFLHNCQUFrQixVQUFVLE1BQU0sWUFBWSxJQUFJLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDO0FBQUEsRUFDM0U7QUFDRjtBQUNBLFNBQVMsV0FBVyxVQUFVLE1BQU07QUFDbEMsTUFBSSxTQUFTLFdBQVcsT0FBTyxlQUFlLFlBQVksR0FBRztBQUMzRCxVQUFNLFdBQVcsT0FBTyxJQUFJLElBQUksU0FBUyxHQUFHO0FBQzVDLFVBQU0sU0FBUyxXQUFXO0FBQzFCLFVBQU0sY0FBYyxJQUFJLG9CQUFvQixVQUFVLFNBQVMsSUFBSSxDQUFDLEtBQUssSUFBSTtBQUM3RSxTQUFLLEtBQUssTUFBTTtBQUNoQixTQUFLLFFBQVEsYUFBYSxVQUFVLE1BQU07QUFDMUMsU0FBSyxjQUFjLFdBQVc7QUFDOUIsU0FBSyxXQUFXLFFBQVE7QUFDeEIsU0FBSyxXQUFXLE1BQU07QUFBQSxFQUN4QjtBQUNBLE1BQUksTUFBb0U7QUFDdEUsb0JBQWdCLFVBQVUsTUFBTSxZQUFZLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLENBQUM7QUFBQSxFQUN6RTtBQUNGO0FBQ0EsU0FBUyxjQUFjO0FBQ3JCLE1BQUksY0FBYyxRQUFRO0FBQ3hCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLGFBQWE7QUFDdkQsZ0JBQVk7QUFDWixXQUFPLE9BQU87QUFBQSxFQUNoQixPQUFPO0FBQ0wsZ0JBQVk7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBbUI7QUFDMUIsUUFBTSxXQUFXLENBQUM7QUFDbEIsTUFBSSxPQUFPLHdCQUF3QixXQUFXO0FBQzVDLElBQTZDLFNBQVMsS0FBSyxxQkFBcUI7QUFDaEYsa0JBQWMsRUFBRSxzQkFBc0I7QUFBQSxFQUN4QztBQUNBLE1BQUksT0FBTywwQkFBMEIsV0FBVztBQUM5QyxJQUE2QyxTQUFTLEtBQUssdUJBQXVCO0FBQ2xGLGtCQUFjLEVBQUUsd0JBQXdCO0FBQUEsRUFDMUM7QUFDQSxNQUFJLE9BQU8sNENBQTRDLFdBQVc7QUFDaEUsSUFBNkMsU0FBUyxLQUFLLHlDQUF5QztBQUNwRyxrQkFBYyxFQUFFLDBDQUEwQztBQUFBLEVBQzVEO0FBQ0EsTUFBaUQsU0FBUyxRQUFRO0FBQ2hFLFVBQU0sUUFBUSxTQUFTLFNBQVM7QUFDaEMsWUFBUTtBQUFBLE1BQ04sZUFBZSxRQUFRLE1BQU0sRUFBRSxJQUFJLFNBQVMsS0FBSyxJQUFJLENBQUMsSUFBSSxRQUFRLFFBQVEsSUFBSTtBQUFBO0FBQUE7QUFBQSxJQUdoRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLE1BQU0sd0JBQXdCO0FBQzlCLFNBQVMsZUFBZSxTQUFTO0FBQy9CLFNBQU8sbUJBQW1CLE9BQU87QUFDbkM7QUFDQSxTQUFTLHdCQUF3QixTQUFTO0FBQ3hDLFNBQU8sbUJBQW1CLFNBQVMsd0JBQXdCO0FBQzdEO0FBQ0EsU0FBUyxtQkFBbUIsU0FBUyxvQkFBb0I7QUFDdkQ7QUFDRSxxQkFBaUI7QUFBQSxFQUNuQjtBQUNBLFFBQU0sU0FBUyxjQUFjO0FBQzdCLFNBQU8sVUFBVTtBQUNqQixNQUFJLE1BQW9FO0FBQ3RFLHNCQUFrQixPQUFPLDhCQUE4QixNQUFNO0FBQUEsRUFDL0Q7QUFDQSxRQUFNO0FBQUEsSUFDSixRQUFRO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixXQUFXO0FBQUEsSUFDWCxlQUFlO0FBQUEsSUFDZixZQUFZO0FBQUEsSUFDWixlQUFlO0FBQUEsSUFDZixTQUFTO0FBQUEsSUFDVCxnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixhQUFhO0FBQUEsSUFDYixZQUFZLGlCQUFpQjtBQUFBLElBQzdCLHFCQUFxQjtBQUFBLEVBQ3ZCLElBQUk7QUFDSixRQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksV0FBVyxTQUFTLE1BQU0sa0JBQWtCLE1BQU0saUJBQWlCLE1BQU0sWUFBWSxRQUFRLGVBQWUsTUFBTSxZQUF5RCxnQkFBZ0IsUUFBUSxDQUFDLENBQUMsR0FBRyxvQkFBb0I7QUFDalAsUUFBSSxPQUFPLElBQUk7QUFDYjtBQUFBLElBQ0Y7QUFDQSxRQUFJLE1BQU0sQ0FBQyxnQkFBZ0IsSUFBSSxFQUFFLEdBQUc7QUFDbEMsZUFBUyxnQkFBZ0IsRUFBRTtBQUMzQixjQUFRLElBQUksaUJBQWlCLGdCQUFnQixJQUFJO0FBQ2pELFdBQUs7QUFBQSxJQUNQO0FBQ0EsUUFBSSxHQUFHLGNBQWMsSUFBSTtBQUN2QixrQkFBWTtBQUNaLFNBQUcsa0JBQWtCO0FBQUEsSUFDdkI7QUFDQSxVQUFNLEVBQUUsTUFBTSxLQUFBUCxNQUFLLFVBQVUsSUFBSTtBQUNqQyxZQUFRLE1BQU07QUFBQSxNQUNaLEtBQUs7QUFDSCxvQkFBWSxJQUFJLElBQUksV0FBVyxNQUFNO0FBQ3JDO0FBQUEsTUFDRixLQUFLO0FBQ0gsMkJBQW1CLElBQUksSUFBSSxXQUFXLE1BQU07QUFDNUM7QUFBQSxNQUNGLEtBQUs7QUFDSCxZQUFJLE1BQU0sTUFBTTtBQUNkLDBCQUFnQixJQUFJLFdBQVcsUUFBUSxTQUFTO0FBQUEsUUFDbEQsV0FBVyxNQUEyQztBQUNwRCwwQkFBZ0IsSUFBSSxJQUFJLFdBQVcsU0FBUztBQUFBLFFBQzlDO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSDtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQTtBQUFBLE1BQ0Y7QUFDRSxZQUFJLFlBQVksR0FBRztBQUNqQjtBQUFBLFlBQ0U7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsWUFBWSxHQUFHO0FBQ3hCO0FBQUEsWUFDRTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0YsV0FBVyxZQUFZLElBQUk7QUFDekIsZUFBSztBQUFBLFlBQ0g7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRixXQUFXLFlBQVksS0FBSztBQUMxQixlQUFLO0FBQUEsWUFDSDtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsTUFBMkM7QUFDcEQsaUJBQU8sdUJBQXVCLE1BQU0sSUFBSSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hEO0FBQUEsSUFDSjtBQUNBLFFBQUlBLFFBQU8sUUFBUSxpQkFBaUI7QUFDbEMsYUFBT0EsTUFBSyxNQUFNLEdBQUcsS0FBSyxnQkFBZ0IsTUFBTSxJQUFJLENBQUMsRUFBRTtBQUFBLElBQ3pELFdBQVdBLFFBQU8sUUFBUSxNQUFNLEdBQUcsT0FBTyxNQUFNO0FBQzlDLGFBQU8sR0FBRyxLQUFLLE1BQU0sZ0JBQWdCLElBQUksSUFBSTtBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUNBLFFBQU0sY0FBYyxDQUFDLElBQUksSUFBSSxXQUFXLFdBQVc7QUFDakQsUUFBSSxNQUFNLE1BQU07QUFDZDtBQUFBLFFBQ0UsR0FBRyxLQUFLLGVBQWUsR0FBRyxRQUFRO0FBQUEsUUFDbEM7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMLFlBQU0sS0FBSyxHQUFHLEtBQUssR0FBRztBQUN0QixVQUFJLEdBQUcsYUFBYSxHQUFHLFVBQVU7QUFDL0Isb0JBQVksSUFBSSxHQUFHLFFBQVE7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxxQkFBcUIsQ0FBQyxJQUFJLElBQUksV0FBVyxXQUFXO0FBQ3hELFFBQUksTUFBTSxNQUFNO0FBQ2Q7QUFBQSxRQUNFLEdBQUcsS0FBSyxrQkFBa0IsR0FBRyxZQUFZLEVBQUU7QUFBQSxRQUMzQztBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0wsU0FBRyxLQUFLLEdBQUc7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sa0JBQWtCLENBQUMsSUFBSSxXQUFXLFFBQVEsY0FBYztBQUM1RCxLQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sSUFBSTtBQUFBLE1BQ25CLEdBQUc7QUFBQSxNQUNIO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILEdBQUc7QUFBQSxJQUNMO0FBQUEsRUFDRjtBQUNBLFFBQU0sa0JBQWtCLENBQUMsSUFBSSxJQUFJLFdBQVcsY0FBYztBQUN4RCxRQUFJLEdBQUcsYUFBYSxHQUFHLFVBQVU7QUFDL0IsWUFBTSxTQUFTLGdCQUFnQixHQUFHLE1BQU07QUFDeEMsdUJBQWlCLEVBQUU7QUFDbkIsT0FBQyxHQUFHLElBQUksR0FBRyxNQUFNLElBQUk7QUFBQSxRQUNuQixHQUFHO0FBQUEsUUFDSDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMLFNBQUcsS0FBSyxHQUFHO0FBQ1gsU0FBRyxTQUFTLEdBQUc7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGlCQUFpQixDQUFDLEVBQUUsSUFBSSxPQUFPLEdBQUcsV0FBVyxnQkFBZ0I7QUFDakUsUUFBSTtBQUNKLFdBQU8sTUFBTSxPQUFPLFFBQVE7QUFDMUIsYUFBTyxnQkFBZ0IsRUFBRTtBQUN6QixpQkFBVyxJQUFJLFdBQVcsV0FBVztBQUNyQyxXQUFLO0FBQUEsSUFDUDtBQUNBLGVBQVcsUUFBUSxXQUFXLFdBQVc7QUFBQSxFQUMzQztBQUNBLFFBQU0sbUJBQW1CLENBQUMsRUFBRSxJQUFJLE9BQU8sTUFBTTtBQUMzQyxRQUFJO0FBQ0osV0FBTyxNQUFNLE9BQU8sUUFBUTtBQUMxQixhQUFPLGdCQUFnQixFQUFFO0FBQ3pCLGlCQUFXLEVBQUU7QUFDYixXQUFLO0FBQUEsSUFDUDtBQUNBLGVBQVcsTUFBTTtBQUFBLEVBQ25CO0FBQ0EsUUFBTSxpQkFBaUIsQ0FBQyxJQUFJLElBQUksV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLGNBQWM7QUFDekgsUUFBSSxHQUFHLFNBQVMsT0FBTztBQUNyQixrQkFBWTtBQUFBLElBQ2QsV0FBVyxHQUFHLFNBQVMsUUFBUTtBQUM3QixrQkFBWTtBQUFBLElBQ2Q7QUFDQSxRQUFJLE1BQU0sTUFBTTtBQUNkO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0wsWUFBTSxnQkFBZ0IsR0FBRyxNQUFNLEdBQUcsR0FBRyxXQUFXLEdBQUcsS0FBSztBQUN4RCxVQUFJO0FBQ0YsWUFBSSxlQUFlO0FBQ2pCLHdCQUFjLFlBQVk7QUFBQSxRQUM1QjtBQUNBO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFVBQUU7QUFDQSxZQUFJLGVBQWU7QUFDakIsd0JBQWMsVUFBVTtBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlLENBQUMsT0FBTyxXQUFXLFFBQVEsaUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsY0FBYztBQUN0SCxRQUFJO0FBQ0osUUFBSTtBQUNKLFVBQU0sRUFBRSxPQUFPLFdBQVcsWUFBWSxLQUFLLElBQUk7QUFDL0MsU0FBSyxNQUFNLEtBQUs7QUFBQSxNQUNkLE1BQU07QUFBQSxNQUNOO0FBQUEsTUFDQSxTQUFTLE1BQU07QUFBQSxNQUNmO0FBQUEsSUFDRjtBQUNBLFFBQUksWUFBWSxHQUFHO0FBQ2pCLHlCQUFtQixJQUFJLE1BQU0sUUFBUTtBQUFBLElBQ3ZDLFdBQVcsWUFBWSxJQUFJO0FBQ3pCO0FBQUEsUUFDRSxNQUFNO0FBQUEsUUFDTjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EseUJBQXlCLE9BQU8sU0FBUztBQUFBLFFBQ3pDO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxNQUFNO0FBQ1IsMEJBQW9CLE9BQU8sTUFBTSxpQkFBaUIsU0FBUztBQUFBLElBQzdEO0FBQ0EsZUFBVyxJQUFJLE9BQU8sTUFBTSxTQUFTLGNBQWMsZUFBZTtBQUNsRSxRQUFJLE9BQU87QUFDVCxpQkFBVyxPQUFPLE9BQU87QUFDdkIsWUFBSSxRQUFRLFdBQVcsQ0FBQyxlQUFlLEdBQUcsR0FBRztBQUMzQyx3QkFBYyxJQUFJLEtBQUssTUFBTSxNQUFNLEdBQUcsR0FBRyxXQUFXLGVBQWU7QUFBQSxRQUNyRTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFdBQVcsT0FBTztBQUNwQixzQkFBYyxJQUFJLFNBQVMsTUFBTSxNQUFNLE9BQU8sU0FBUztBQUFBLE1BQ3pEO0FBQ0EsVUFBSSxZQUFZLE1BQU0sb0JBQW9CO0FBQ3hDLHdCQUFnQixXQUFXLGlCQUFpQixLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0EsUUFBSSxNQUFvRTtBQUN0RSxVQUFJLElBQUksV0FBVyxPQUFPLElBQUk7QUFDOUIsVUFBSSxJQUFJLHdCQUF3QixpQkFBaUIsSUFBSTtBQUFBLElBQ3ZEO0FBQ0EsUUFBSSxNQUFNO0FBQ1IsMEJBQW9CLE9BQU8sTUFBTSxpQkFBaUIsYUFBYTtBQUFBLElBQ2pFO0FBQ0EsVUFBTSwwQkFBMEIsZUFBZSxnQkFBZ0IsVUFBVTtBQUN6RSxRQUFJLHlCQUF5QjtBQUMzQixpQkFBVyxZQUFZLEVBQUU7QUFBQSxJQUMzQjtBQUNBLGVBQVcsSUFBSSxXQUFXLE1BQU07QUFDaEMsU0FBSyxZQUFZLFNBQVMsTUFBTSxtQkFBbUIsMkJBQTJCLE1BQU07QUFDbEYsWUFBTSxRQUFxRDtBQUMzRCw0QkFBc0IsTUFBTTtBQUMxQixZQUFJO0FBQ0osWUFBSSxLQUEyQyxRQUFPLGVBQWUsS0FBSztBQUMxRSxZQUFJO0FBQ0YsdUJBQWEsZ0JBQWdCLFdBQVcsaUJBQWlCLEtBQUs7QUFDOUQscUNBQTJCLFdBQVcsTUFBTSxFQUFFO0FBQzlDLGtCQUFRLG9CQUFvQixPQUFPLE1BQU0saUJBQWlCLFNBQVM7QUFBQSxRQUNyRSxVQUFFO0FBQ0EsY0FBSSxLQUEyQyxnQkFBZSxJQUFJO0FBQUEsUUFDcEU7QUFBQSxNQUNGLEdBQUcsY0FBYztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxDQUFDLElBQUksT0FBTyxTQUFTLGNBQWMsb0JBQW9CO0FBQ3hFLFFBQUksU0FBUztBQUNYLHFCQUFlLElBQUksT0FBTztBQUFBLElBQzVCO0FBQ0EsUUFBSSxjQUFjO0FBQ2hCLGVBQVMsSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUs7QUFDNUMsdUJBQWUsSUFBSSxhQUFhLENBQUMsQ0FBQztBQUFBLE1BQ3BDO0FBQUEsSUFDRjtBQUNBLFFBQUksaUJBQWlCO0FBQ25CLFVBQUksVUFBVSxnQkFBZ0I7QUFDOUIsVUFBaUQsUUFBUSxZQUFZLEtBQUssUUFBUSxZQUFZLE1BQU07QUFDbEcsa0JBQVUsaUJBQWlCLFFBQVEsUUFBUSxLQUFLO0FBQUEsTUFDbEQ7QUFDQSxVQUFJLFVBQVUsV0FBVyxXQUFXLFFBQVEsSUFBSSxNQUFNLFFBQVEsY0FBYyxTQUFTLFFBQVEsZUFBZSxRQUFRO0FBQ2xILGNBQU0sY0FBYyxnQkFBZ0I7QUFDcEM7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0EsWUFBWTtBQUFBLFVBQ1osWUFBWTtBQUFBLFVBQ1osZ0JBQWdCO0FBQUEsUUFDbEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGdCQUFnQixDQUFDLFVBQVUsV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLFdBQVcsUUFBUSxNQUFNO0FBQ3JJLGFBQVMsSUFBSSxPQUFPLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDNUMsWUFBTSxRQUFRLFNBQVMsQ0FBQyxJQUFJLFlBQVksZUFBZSxTQUFTLENBQUMsQ0FBQyxJQUFJLGVBQWUsU0FBUyxDQUFDLENBQUM7QUFDaEc7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGVBQWUsQ0FBQyxJQUFJLElBQUksaUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsY0FBYztBQUNwRyxVQUFNLEtBQUssR0FBRyxLQUFLLEdBQUc7QUFDdEIsUUFBSSxNQUFvRTtBQUN0RSxTQUFHLFVBQVU7QUFBQSxJQUNmO0FBQ0EsUUFBSSxFQUFFLFdBQVcsaUJBQWlCLEtBQUssSUFBSTtBQUMzQyxpQkFBYSxHQUFHLFlBQVk7QUFDNUIsVUFBTSxXQUFXLEdBQUcsU0FBUztBQUM3QixVQUFNLFdBQVcsR0FBRyxTQUFTO0FBQzdCLFFBQUk7QUFDSix1QkFBbUIsY0FBYyxpQkFBaUIsS0FBSztBQUN2RCxRQUFJLFlBQVksU0FBUyxxQkFBcUI7QUFDNUMsc0JBQWdCLFdBQVcsaUJBQWlCLElBQUksRUFBRTtBQUFBLElBQ3BEO0FBQ0EsUUFBSSxNQUFNO0FBQ1IsMEJBQW9CLElBQUksSUFBSSxpQkFBaUIsY0FBYztBQUFBLElBQzdEO0FBQ0EsdUJBQW1CLGNBQWMsaUJBQWlCLElBQUk7QUFDdEQ7QUFBQTtBQUFBLE1BRStDO0FBQUE7QUFBQSxNQUU3QyxvQkFBb0IsQ0FBQyxHQUFHLG1CQUFtQixHQUFHLGdCQUFnQixXQUFXLGdCQUFnQjtBQUFBLE1BQ3pGO0FBQ0Esa0JBQVk7QUFDWixrQkFBWTtBQUNaLHdCQUFrQjtBQUFBLElBQ3BCO0FBQ0EsUUFBSSxTQUFTLGFBQWEsU0FBUyxhQUFhLFFBQVEsU0FBUyxlQUFlLFNBQVMsZUFBZSxNQUFNO0FBQzVHLHlCQUFtQixJQUFJLEVBQUU7QUFBQSxJQUMzQjtBQUNBLFFBQUksaUJBQWlCO0FBQ25CO0FBQUEsUUFDRSxHQUFHO0FBQUEsUUFDSDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EseUJBQXlCLElBQUksU0FBUztBQUFBLFFBQ3RDO0FBQUEsTUFDRjtBQUNBLFVBQUksTUFBMkM7QUFDN0MsK0JBQXVCLElBQUksRUFBRTtBQUFBLE1BQy9CO0FBQUEsSUFDRixXQUFXLENBQUMsV0FBVztBQUNyQjtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EseUJBQXlCLElBQUksU0FBUztBQUFBLFFBQ3RDO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxZQUFZLEdBQUc7QUFDakIsVUFBSSxZQUFZLElBQUk7QUFDbEIsbUJBQVcsSUFBSSxVQUFVLFVBQVUsaUJBQWlCLFNBQVM7QUFBQSxNQUMvRCxPQUFPO0FBQ0wsWUFBSSxZQUFZLEdBQUc7QUFDakIsY0FBSSxTQUFTLFVBQVUsU0FBUyxPQUFPO0FBQ3JDLDBCQUFjLElBQUksU0FBUyxNQUFNLFNBQVMsT0FBTyxTQUFTO0FBQUEsVUFDNUQ7QUFBQSxRQUNGO0FBQ0EsWUFBSSxZQUFZLEdBQUc7QUFDakIsd0JBQWMsSUFBSSxTQUFTLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUztBQUFBLFFBQ3RFO0FBQ0EsWUFBSSxZQUFZLEdBQUc7QUFDakIsZ0JBQU0sZ0JBQWdCLEdBQUc7QUFDekIsbUJBQVMsSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQUs7QUFDN0Msa0JBQU0sTUFBTSxjQUFjLENBQUM7QUFDM0Isa0JBQU0sT0FBTyxTQUFTLEdBQUc7QUFDekIsa0JBQU0sT0FBTyxTQUFTLEdBQUc7QUFDekIsZ0JBQUksU0FBUyxRQUFRLFFBQVEsU0FBUztBQUNwQyw0QkFBYyxJQUFJLEtBQUssTUFBTSxNQUFNLFdBQVcsZUFBZTtBQUFBLFlBQy9EO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxZQUFZLEdBQUc7QUFDakIsWUFBSSxHQUFHLGFBQWEsR0FBRyxVQUFVO0FBQy9CLDZCQUFtQixJQUFJLEdBQUcsUUFBUTtBQUFBLFFBQ3BDO0FBQUEsTUFDRjtBQUFBLElBQ0YsV0FBVyxDQUFDLGFBQWEsbUJBQW1CLE1BQU07QUFDaEQsaUJBQVcsSUFBSSxVQUFVLFVBQVUsaUJBQWlCLFNBQVM7QUFBQSxJQUMvRDtBQUNBLFNBQUssWUFBWSxTQUFTLG1CQUFtQixNQUFNO0FBQ2pELDRCQUFzQixNQUFNO0FBQzFCLHFCQUFhLGdCQUFnQixXQUFXLGlCQUFpQixJQUFJLEVBQUU7QUFDL0QsZ0JBQVEsb0JBQW9CLElBQUksSUFBSSxpQkFBaUIsU0FBUztBQUFBLE1BQ2hFLEdBQUcsY0FBYztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLFFBQU0scUJBQXFCLENBQUMsYUFBYSxhQUFhLG1CQUFtQixpQkFBaUIsZ0JBQWdCLFdBQVcsaUJBQWlCO0FBQ3BJLGFBQVMsSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLEtBQUs7QUFDM0MsWUFBTSxXQUFXLFlBQVksQ0FBQztBQUM5QixZQUFNLFdBQVcsWUFBWSxDQUFDO0FBQzlCLFlBQU07QUFBQTtBQUFBO0FBQUEsUUFHSixTQUFTO0FBQUE7QUFBQSxTQUVSLFNBQVMsU0FBUztBQUFBO0FBQUEsUUFFbkIsQ0FBQyxnQkFBZ0IsVUFBVSxRQUFRO0FBQUEsUUFDbkMsU0FBUyxhQUFhLElBQUksS0FBSyxRQUFRLGVBQWUsU0FBUyxFQUFFO0FBQUE7QUFBQTtBQUFBLFVBRy9EO0FBQUE7QUFBQTtBQUdKO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLENBQUMsSUFBSSxVQUFVLFVBQVUsaUJBQWlCLGNBQWM7QUFDekUsUUFBSSxhQUFhLFVBQVU7QUFDekIsVUFBSSxhQUFhLFdBQVc7QUFDMUIsbUJBQVcsT0FBTyxVQUFVO0FBQzFCLGNBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxFQUFFLE9BQU8sV0FBVztBQUM5QztBQUFBLGNBQ0U7QUFBQSxjQUNBO0FBQUEsY0FDQSxTQUFTLEdBQUc7QUFBQSxjQUNaO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsT0FBTyxVQUFVO0FBQzFCLFlBQUksZUFBZSxHQUFHLEVBQUc7QUFDekIsY0FBTSxPQUFPLFNBQVMsR0FBRztBQUN6QixjQUFNLE9BQU8sU0FBUyxHQUFHO0FBQ3pCLFlBQUksU0FBUyxRQUFRLFFBQVEsU0FBUztBQUNwQyx3QkFBYyxJQUFJLEtBQUssTUFBTSxNQUFNLFdBQVcsZUFBZTtBQUFBLFFBQy9EO0FBQUEsTUFDRjtBQUNBLFVBQUksV0FBVyxVQUFVO0FBQ3ZCLHNCQUFjLElBQUksU0FBUyxTQUFTLE9BQU8sU0FBUyxPQUFPLFNBQVM7QUFBQSxNQUN0RTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxrQkFBa0IsQ0FBQyxJQUFJLElBQUksV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLGNBQWM7QUFDMUgsVUFBTSxzQkFBc0IsR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLGVBQWUsRUFBRTtBQUNsRSxVQUFNLG9CQUFvQixHQUFHLFNBQVMsS0FBSyxHQUFHLFNBQVMsZUFBZSxFQUFFO0FBQ3hFLFFBQUksRUFBRSxXQUFXLGlCQUFpQixjQUFjLHFCQUFxQixJQUFJO0FBQ3pFO0FBQUE7QUFBQSxNQUNDLGlCQUFpQixZQUFZO0FBQUEsTUFBTztBQUNuQyxrQkFBWTtBQUNaLGtCQUFZO0FBQ1osd0JBQWtCO0FBQUEsSUFDcEI7QUFDQSxRQUFJLHNCQUFzQjtBQUN4QixxQkFBZSxlQUFlLGFBQWEsT0FBTyxvQkFBb0IsSUFBSTtBQUFBLElBQzVFO0FBQ0EsUUFBSSxNQUFNLE1BQU07QUFDZCxpQkFBVyxxQkFBcUIsV0FBVyxNQUFNO0FBQ2pELGlCQUFXLG1CQUFtQixXQUFXLE1BQU07QUFDL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0UsR0FBRyxZQUFZLENBQUM7QUFBQSxRQUNoQjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGLE9BQU87QUFDTCxVQUFJLFlBQVksS0FBSyxZQUFZLE1BQU07QUFBQTtBQUFBLE1BRXZDLEdBQUcsbUJBQW1CLEdBQUcsZ0JBQWdCLFdBQVcsZ0JBQWdCLFFBQVE7QUFDMUU7QUFBQSxVQUNFLEdBQUc7QUFBQSxVQUNIO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsWUFBSSxNQUEyQztBQUM3QyxpQ0FBdUIsSUFBSSxFQUFFO0FBQUEsUUFDL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0UsR0FBRyxPQUFPLFFBQVEsbUJBQW1CLE9BQU8sZ0JBQWdCO0FBQUEsVUFDNUQ7QUFDQTtBQUFBLFlBQ0U7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBO0FBQUEsVUFFRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTDtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLG1CQUFtQixDQUFDLElBQUksSUFBSSxXQUFXLFFBQVEsaUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsY0FBYztBQUMzSCxPQUFHLGVBQWU7QUFDbEIsUUFBSSxNQUFNLE1BQU07QUFDZCxVQUFJLEdBQUcsWUFBWSxLQUFLO0FBQ3RCLHdCQUFnQixJQUFJO0FBQUEsVUFDbEI7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0wsc0JBQWdCLElBQUksSUFBSSxTQUFTO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxpQkFBaUIsQ0FBQyxjQUFjLFdBQVcsUUFBUSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYztBQUNqSCxVQUFNLFdBQVksYUFBYSxZQUFZO0FBQUEsTUFDekM7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFpRCxTQUFTLEtBQUssU0FBUztBQUN0RSxrQkFBWSxRQUFRO0FBQUEsSUFDdEI7QUFDQSxRQUFJLE1BQTJDO0FBQzdDLHlCQUFtQixZQUFZO0FBQy9CLG1CQUFhLFVBQVUsT0FBTztBQUFBLElBQ2hDO0FBQ0EsUUFBSSxZQUFZLFlBQVksR0FBRztBQUM3QixlQUFTLElBQUksV0FBVztBQUFBLElBQzFCO0FBQ0E7QUFDRSxVQUFJLE1BQTJDO0FBQzdDLHFCQUFhLFVBQVUsTUFBTTtBQUFBLE1BQy9CO0FBQ0EscUJBQWUsVUFBVSxPQUFPLFNBQVM7QUFDekMsVUFBSSxNQUEyQztBQUM3QyxtQkFBVyxVQUFVLE1BQU07QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFDQSxRQUFpRCxjQUFlLGNBQWEsS0FBSztBQUNsRixRQUFJLFNBQVMsVUFBVTtBQUNyQix3QkFBa0IsZUFBZSxZQUFZLFVBQVUsbUJBQW1CLFNBQVM7QUFDbkYsVUFBSSxDQUFDLGFBQWEsSUFBSTtBQUNwQixjQUFNLGNBQWMsU0FBUyxVQUFVLFlBQVksT0FBTztBQUMxRCwyQkFBbUIsTUFBTSxhQUFhLFdBQVcsTUFBTTtBQUN2RCxxQkFBYSxjQUFjLFlBQVk7QUFBQSxNQUN6QztBQUFBLElBQ0YsT0FBTztBQUNMO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxNQUEyQztBQUM3Qyx3QkFBa0I7QUFDbEIsaUJBQVcsVUFBVSxPQUFPO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxrQkFBa0IsQ0FBQyxJQUFJLElBQUksY0FBYztBQUM3QyxVQUFNLFdBQVcsR0FBRyxZQUFZLEdBQUc7QUFDbkMsUUFBSSxzQkFBc0IsSUFBSSxJQUFJLFNBQVMsR0FBRztBQUM1QyxVQUFJLFNBQVMsWUFBWSxDQUFDLFNBQVMsZUFBZTtBQUNoRCxZQUFJLE1BQTJDO0FBQzdDLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFDQSxpQ0FBeUIsVUFBVSxJQUFJLFNBQVM7QUFDaEQsWUFBSSxNQUEyQztBQUM3Qyw0QkFBa0I7QUFBQSxRQUNwQjtBQUNBO0FBQUEsTUFDRixPQUFPO0FBQ0wsaUJBQVMsT0FBTztBQUNoQixpQkFBUyxPQUFPO0FBQUEsTUFDbEI7QUFBQSxJQUNGLE9BQU87QUFDTCxTQUFHLEtBQUssR0FBRztBQUNYLGVBQVMsUUFBUTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLFFBQU0sb0JBQW9CLENBQUMsVUFBVSxjQUFjLFdBQVcsUUFBUSxnQkFBZ0IsV0FBVyxjQUFjO0FBQzdHLFVBQU0sb0JBQW9CLE1BQU07QUFDOUIsVUFBSSxDQUFDLFNBQVMsV0FBVztBQUN2QixZQUFJO0FBQ0osY0FBTSxFQUFFLElBQUksTUFBTSxJQUFJO0FBQ3RCLGNBQU0sRUFBRSxJQUFJLEdBQUcsUUFBUSxNQUFNLEtBQUssSUFBSTtBQUN0QyxjQUFNLHNCQUFzQixlQUFlLFlBQVk7QUFDdkQsc0JBQWMsVUFBVSxLQUFLO0FBQzdCLFlBQUksSUFBSTtBQUNOLHlCQUFlLEVBQUU7QUFBQSxRQUNuQjtBQUNBLFlBQUksQ0FBQyx3QkFBd0IsWUFBWSxTQUFTLE1BQU0scUJBQXFCO0FBQzNFLDBCQUFnQixXQUFXLFFBQVEsWUFBWTtBQUFBLFFBQ2pEO0FBQ0Esc0JBQWMsVUFBVSxJQUFJO0FBQzVCLFlBQUksTUFBTSxhQUFhO0FBQ3JCLGdCQUFNLGlCQUFpQixNQUFNO0FBQzNCLGdCQUFJLE1BQTJDO0FBQzdDLDJCQUFhLFVBQVUsUUFBUTtBQUFBLFlBQ2pDO0FBQ0EscUJBQVMsVUFBVSxvQkFBb0IsUUFBUTtBQUMvQyxnQkFBSSxNQUEyQztBQUM3Qyx5QkFBVyxVQUFVLFFBQVE7QUFBQSxZQUMvQjtBQUNBLGdCQUFJLE1BQTJDO0FBQzdDLDJCQUFhLFVBQVUsU0FBUztBQUFBLFlBQ2xDO0FBQ0E7QUFBQSxjQUNFO0FBQUEsY0FDQSxTQUFTO0FBQUEsY0FDVDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUNBLGdCQUFJLE1BQTJDO0FBQzdDLHlCQUFXLFVBQVUsU0FBUztBQUFBLFlBQ2hDO0FBQUEsVUFDRjtBQUNBLGNBQUksdUJBQXVCLEtBQUssZ0JBQWdCO0FBQzlDLGlCQUFLO0FBQUEsY0FDSDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUFBLFVBQ0YsT0FBTztBQUNMLDJCQUFlO0FBQUEsVUFDakI7QUFBQSxRQUNGLE9BQU87QUFDTCxjQUFJLEtBQUssTUFBTSxLQUFLLEdBQUcsZUFBZSxHQUFHO0FBQ3ZDLGlCQUFLLEdBQUc7QUFBQSxjQUNOO0FBQUEsY0FDQSxTQUFTLFNBQVMsU0FBUyxPQUFPLE9BQU87QUFBQSxZQUMzQztBQUFBLFVBQ0Y7QUFDQSxjQUFJLE1BQTJDO0FBQzdDLHlCQUFhLFVBQVUsUUFBUTtBQUFBLFVBQ2pDO0FBQ0EsZ0JBQU0sVUFBVSxTQUFTLFVBQVUsb0JBQW9CLFFBQVE7QUFDL0QsY0FBSSxNQUEyQztBQUM3Qyx1QkFBVyxVQUFVLFFBQVE7QUFBQSxVQUMvQjtBQUNBLGNBQUksTUFBMkM7QUFDN0MseUJBQWEsVUFBVSxPQUFPO0FBQUEsVUFDaEM7QUFDQTtBQUFBLFlBQ0U7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsY0FBSSxNQUEyQztBQUM3Qyx1QkFBVyxVQUFVLE9BQU87QUFBQSxVQUM5QjtBQUNBLHVCQUFhLEtBQUssUUFBUTtBQUFBLFFBQzVCO0FBQ0EsWUFBSSxHQUFHO0FBQ0wsZ0NBQXNCLEdBQUcsY0FBYztBQUFBLFFBQ3pDO0FBQ0EsWUFBSSxDQUFDLHdCQUF3QixZQUFZLFNBQVMsTUFBTSxpQkFBaUI7QUFDdkUsZ0JBQU0scUJBQXFCO0FBQzNCO0FBQUEsWUFDRSxNQUFNLGdCQUFnQixXQUFXLFFBQVEsa0JBQWtCO0FBQUEsWUFDM0Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLFlBQUksYUFBYSxZQUFZLE9BQU8sVUFBVSxlQUFlLE9BQU8sS0FBSyxLQUFLLE9BQU8sTUFBTSxZQUFZLEtBQUs7QUFDMUcsbUJBQVMsS0FBSyxzQkFBc0IsU0FBUyxHQUFHLGNBQWM7QUFBQSxRQUNoRTtBQUNBLGlCQUFTLFlBQVk7QUFDckIsWUFBSSxNQUFvRTtBQUN0RSxpQ0FBdUIsUUFBUTtBQUFBLFFBQ2pDO0FBQ0EsdUJBQWUsWUFBWSxTQUFTO0FBQUEsTUFDdEMsT0FBTztBQUNMLFlBQUksRUFBRSxNQUFNLElBQUksR0FBRyxRQUFRLE1BQU0sSUFBSTtBQUNyQztBQUNFLGdCQUFNLHVCQUF1QiwyQkFBMkIsUUFBUTtBQUNoRSxjQUFJLHNCQUFzQjtBQUN4QixnQkFBSSxNQUFNO0FBQ1IsbUJBQUssS0FBSyxNQUFNO0FBQ2hCLHVDQUF5QixVQUFVLE1BQU0sU0FBUztBQUFBLFlBQ3BEO0FBQ0EsaUNBQXFCLFNBQVMsS0FBSyxNQUFNO0FBQ3ZDLG9DQUFzQixNQUFNO0FBQzFCLG9CQUFJLENBQUMsU0FBUyxZQUFhLFFBQU87QUFBQSxjQUNwQyxHQUFHLGNBQWM7QUFBQSxZQUNuQixDQUFDO0FBQ0Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLFlBQUksYUFBYTtBQUNqQixZQUFJO0FBQ0osWUFBSSxNQUEyQztBQUM3Qyw2QkFBbUIsUUFBUSxTQUFTLEtBQUs7QUFBQSxRQUMzQztBQUNBLHNCQUFjLFVBQVUsS0FBSztBQUM3QixZQUFJLE1BQU07QUFDUixlQUFLLEtBQUssTUFBTTtBQUNoQixtQ0FBeUIsVUFBVSxNQUFNLFNBQVM7QUFBQSxRQUNwRCxPQUFPO0FBQ0wsaUJBQU87QUFBQSxRQUNUO0FBQ0EsWUFBSSxJQUFJO0FBQ04seUJBQWUsRUFBRTtBQUFBLFFBQ25CO0FBQ0EsWUFBSSxZQUFZLEtBQUssU0FBUyxLQUFLLE1BQU0scUJBQXFCO0FBQzVELDBCQUFnQixXQUFXLFFBQVEsTUFBTSxLQUFLO0FBQUEsUUFDaEQ7QUFDQSxzQkFBYyxVQUFVLElBQUk7QUFDNUIsWUFBSSxNQUEyQztBQUM3Qyx1QkFBYSxVQUFVLFFBQVE7QUFBQSxRQUNqQztBQUNBLGNBQU0sV0FBVyxvQkFBb0IsUUFBUTtBQUM3QyxZQUFJLE1BQTJDO0FBQzdDLHFCQUFXLFVBQVUsUUFBUTtBQUFBLFFBQy9CO0FBQ0EsY0FBTSxXQUFXLFNBQVM7QUFDMUIsaUJBQVMsVUFBVTtBQUNuQixZQUFJLE1BQTJDO0FBQzdDLHVCQUFhLFVBQVUsT0FBTztBQUFBLFFBQ2hDO0FBQ0E7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBO0FBQUEsVUFFQSxlQUFlLFNBQVMsRUFBRTtBQUFBO0FBQUEsVUFFMUIsZ0JBQWdCLFFBQVE7QUFBQSxVQUN4QjtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLFlBQUksTUFBMkM7QUFDN0MscUJBQVcsVUFBVSxPQUFPO0FBQUEsUUFDOUI7QUFDQSxhQUFLLEtBQUssU0FBUztBQUNuQixZQUFJLGVBQWUsTUFBTTtBQUN2QiwwQkFBZ0IsVUFBVSxTQUFTLEVBQUU7QUFBQSxRQUN2QztBQUNBLFlBQUksR0FBRztBQUNMLGdDQUFzQixHQUFHLGNBQWM7QUFBQSxRQUN6QztBQUNBLFlBQUksWUFBWSxLQUFLLFNBQVMsS0FBSyxNQUFNLGdCQUFnQjtBQUN2RDtBQUFBLFlBQ0UsTUFBTSxnQkFBZ0IsV0FBVyxRQUFRLE1BQU0sS0FBSztBQUFBLFlBQ3BEO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLE1BQW9FO0FBQ3RFLG1DQUF5QixRQUFRO0FBQUEsUUFDbkM7QUFDQSxZQUFJLE1BQTJDO0FBQzdDLDRCQUFrQjtBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxhQUFTLE1BQU0sR0FBRztBQUNsQixVQUFNSCxVQUFTLFNBQVMsU0FBUyxJQUFJLGVBQWUsaUJBQWlCO0FBQ3JFLGFBQVMsTUFBTSxJQUFJO0FBQ25CLFVBQU0sU0FBUyxTQUFTLFNBQVNBLFFBQU8sSUFBSSxLQUFLQSxPQUFNO0FBQ3ZELFVBQU0sTUFBTSxTQUFTLE1BQU1BLFFBQU8sV0FBVyxLQUFLQSxPQUFNO0FBQ3hELFFBQUksSUFBSTtBQUNSLFFBQUksS0FBSyxTQUFTO0FBQ2xCLElBQUFBLFFBQU8sWUFBWSxNQUFNLFNBQVMsR0FBRztBQUNyQyxrQkFBYyxVQUFVLElBQUk7QUFDNUIsUUFBSSxNQUEyQztBQUM3QyxNQUFBQSxRQUFPLFVBQVUsU0FBUyxNQUFNLENBQUMsTUFBTSxlQUFlLFNBQVMsS0FBSyxDQUFDLElBQUk7QUFDekUsTUFBQUEsUUFBTyxZQUFZLFNBQVMsTUFBTSxDQUFDLE1BQU0sZUFBZSxTQUFTLEtBQUssQ0FBQyxJQUFJO0FBQUEsSUFDN0U7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sMkJBQTJCLENBQUMsVUFBVSxXQUFXLGNBQWM7QUFDbkUsY0FBVSxZQUFZO0FBQ3RCLFVBQU0sWUFBWSxTQUFTLE1BQU07QUFDakMsYUFBUyxRQUFRO0FBQ2pCLGFBQVMsT0FBTztBQUNoQixnQkFBWSxVQUFVLFVBQVUsT0FBTyxXQUFXLFNBQVM7QUFDM0QsZ0JBQVksVUFBVSxVQUFVLFVBQVUsU0FBUztBQUNuRCxrQkFBYztBQUNkLHFCQUFpQixRQUFRO0FBQ3pCLGtCQUFjO0FBQUEsRUFDaEI7QUFDQSxRQUFNLGdCQUFnQixDQUFDLElBQUksSUFBSSxXQUFXLFFBQVEsaUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsWUFBWSxVQUFVO0FBQ2hJLFVBQU0sS0FBSyxNQUFNLEdBQUc7QUFDcEIsVUFBTSxnQkFBZ0IsS0FBSyxHQUFHLFlBQVk7QUFDMUMsVUFBTSxLQUFLLEdBQUc7QUFDZCxVQUFNLEVBQUUsV0FBVyxVQUFVLElBQUk7QUFDakMsUUFBSSxZQUFZLEdBQUc7QUFDakIsVUFBSSxZQUFZLEtBQUs7QUFDbkI7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGLFdBQVcsWUFBWSxLQUFLO0FBQzFCO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFlBQVksR0FBRztBQUNqQixVQUFJLGdCQUFnQixJQUFJO0FBQ3RCLHdCQUFnQixJQUFJLGlCQUFpQixjQUFjO0FBQUEsTUFDckQ7QUFDQSxVQUFJLE9BQU8sSUFBSTtBQUNiLDJCQUFtQixXQUFXLEVBQUU7QUFBQSxNQUNsQztBQUFBLElBQ0YsT0FBTztBQUNMLFVBQUksZ0JBQWdCLElBQUk7QUFDdEIsWUFBSSxZQUFZLElBQUk7QUFDbEI7QUFBQSxZQUNFO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRixPQUFPO0FBQ0wsMEJBQWdCLElBQUksaUJBQWlCLGdCQUFnQixJQUFJO0FBQUEsUUFDM0Q7QUFBQSxNQUNGLE9BQU87QUFDTCxZQUFJLGdCQUFnQixHQUFHO0FBQ3JCLDZCQUFtQixXQUFXLEVBQUU7QUFBQSxRQUNsQztBQUNBLFlBQUksWUFBWSxJQUFJO0FBQ2xCO0FBQUEsWUFDRTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0sdUJBQXVCLENBQUMsSUFBSSxJQUFJLFdBQVcsUUFBUSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxjQUFjO0FBQy9ILFNBQUssTUFBTTtBQUNYLFNBQUssTUFBTTtBQUNYLFVBQU0sWUFBWSxHQUFHO0FBQ3JCLFVBQU0sWUFBWSxHQUFHO0FBQ3JCLFVBQU0sZUFBZSxLQUFLLElBQUksV0FBVyxTQUFTO0FBQ2xELFFBQUk7QUFDSixTQUFLLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSztBQUNqQyxZQUFNLFlBQVksR0FBRyxDQUFDLElBQUksWUFBWSxlQUFlLEdBQUcsQ0FBQyxDQUFDLElBQUksZUFBZSxHQUFHLENBQUMsQ0FBQztBQUNsRjtBQUFBLFFBQ0UsR0FBRyxDQUFDO0FBQUEsUUFDSjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksWUFBWSxXQUFXO0FBQ3pCO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxxQkFBcUIsQ0FBQyxJQUFJLElBQUksV0FBVyxjQUFjLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLGNBQWM7QUFDbkksUUFBSSxJQUFJO0FBQ1IsVUFBTSxLQUFLLEdBQUc7QUFDZCxRQUFJLEtBQUssR0FBRyxTQUFTO0FBQ3JCLFFBQUksS0FBSyxLQUFLO0FBQ2QsV0FBTyxLQUFLLE1BQU0sS0FBSyxJQUFJO0FBQ3pCLFlBQU0sS0FBSyxHQUFHLENBQUM7QUFDZixZQUFNLEtBQUssR0FBRyxDQUFDLElBQUksWUFBWSxlQUFlLEdBQUcsQ0FBQyxDQUFDLElBQUksZUFBZSxHQUFHLENBQUMsQ0FBQztBQUMzRSxVQUFJLGdCQUFnQixJQUFJLEVBQUUsR0FBRztBQUMzQjtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTDtBQUFBLE1BQ0Y7QUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLEtBQUssTUFBTSxLQUFLLElBQUk7QUFDekIsWUFBTSxLQUFLLEdBQUcsRUFBRTtBQUNoQixZQUFNLEtBQUssR0FBRyxFQUFFLElBQUksWUFBWSxlQUFlLEdBQUcsRUFBRSxDQUFDLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQztBQUM5RSxVQUFJLGdCQUFnQixJQUFJLEVBQUUsR0FBRztBQUMzQjtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTDtBQUFBLE1BQ0Y7QUFDQTtBQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksSUFBSSxJQUFJO0FBQ1YsVUFBSSxLQUFLLElBQUk7QUFDWCxjQUFNLFVBQVUsS0FBSztBQUNyQixjQUFNLFNBQVMsVUFBVSxLQUFLLEdBQUcsT0FBTyxFQUFFLEtBQUs7QUFDL0MsZUFBTyxLQUFLLElBQUk7QUFDZDtBQUFBLFlBQ0U7QUFBQSxZQUNBLEdBQUcsQ0FBQyxJQUFJLFlBQVksZUFBZSxHQUFHLENBQUMsQ0FBQyxJQUFJLGVBQWUsR0FBRyxDQUFDLENBQUM7QUFBQSxZQUNoRTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixXQUFXLElBQUksSUFBSTtBQUNqQixhQUFPLEtBQUssSUFBSTtBQUNkLGdCQUFRLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixnQkFBZ0IsSUFBSTtBQUNwRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLE9BQU87QUFDTCxZQUFNLEtBQUs7QUFDWCxZQUFNLEtBQUs7QUFDWCxZQUFNLG1CQUFtQyxvQkFBSSxJQUFJO0FBQ2pELFdBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLO0FBQ3pCLGNBQU0sWUFBWSxHQUFHLENBQUMsSUFBSSxZQUFZLGVBQWUsR0FBRyxDQUFDLENBQUMsSUFBSSxlQUFlLEdBQUcsQ0FBQyxDQUFDO0FBQ2xGLFlBQUksVUFBVSxPQUFPLE1BQU07QUFDekIsY0FBaUQsaUJBQWlCLElBQUksVUFBVSxHQUFHLEdBQUc7QUFDcEY7QUFBQSxjQUNFO0FBQUEsY0FDQSxLQUFLLFVBQVUsVUFBVSxHQUFHO0FBQUEsY0FDNUI7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLDJCQUFpQixJQUFJLFVBQVUsS0FBSyxDQUFDO0FBQUEsUUFDdkM7QUFBQSxNQUNGO0FBQ0EsVUFBSTtBQUNKLFVBQUksVUFBVTtBQUNkLFlBQU0sY0FBYyxLQUFLLEtBQUs7QUFDOUIsVUFBSSxRQUFRO0FBQ1osVUFBSSxtQkFBbUI7QUFDdkIsWUFBTSx3QkFBd0IsSUFBSSxNQUFNLFdBQVc7QUFDbkQsV0FBSyxJQUFJLEdBQUcsSUFBSSxhQUFhLElBQUssdUJBQXNCLENBQUMsSUFBSTtBQUM3RCxXQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztBQUN6QixjQUFNLFlBQVksR0FBRyxDQUFDO0FBQ3RCLFlBQUksV0FBVyxhQUFhO0FBQzFCLGtCQUFRLFdBQVcsaUJBQWlCLGdCQUFnQixJQUFJO0FBQ3hEO0FBQUEsUUFDRjtBQUNBLFlBQUk7QUFDSixZQUFJLFVBQVUsT0FBTyxNQUFNO0FBQ3pCLHFCQUFXLGlCQUFpQixJQUFJLFVBQVUsR0FBRztBQUFBLFFBQy9DLE9BQU87QUFDTCxlQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztBQUN6QixnQkFBSSxzQkFBc0IsSUFBSSxFQUFFLE1BQU0sS0FBSyxnQkFBZ0IsV0FBVyxHQUFHLENBQUMsQ0FBQyxHQUFHO0FBQzVFLHlCQUFXO0FBQ1g7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLGFBQWEsUUFBUTtBQUN2QixrQkFBUSxXQUFXLGlCQUFpQixnQkFBZ0IsSUFBSTtBQUFBLFFBQzFELE9BQU87QUFDTCxnQ0FBc0IsV0FBVyxFQUFFLElBQUksSUFBSTtBQUMzQyxjQUFJLFlBQVksa0JBQWtCO0FBQ2hDLCtCQUFtQjtBQUFBLFVBQ3JCLE9BQU87QUFDTCxvQkFBUTtBQUFBLFVBQ1Y7QUFDQTtBQUFBLFlBQ0U7QUFBQSxZQUNBLEdBQUcsUUFBUTtBQUFBLFlBQ1g7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFlBQU0sNkJBQTZCLFFBQVEsWUFBWSxxQkFBcUIsSUFBSTtBQUNoRixVQUFJLDJCQUEyQixTQUFTO0FBQ3hDLFdBQUssSUFBSSxjQUFjLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDckMsY0FBTSxZQUFZLEtBQUs7QUFDdkIsY0FBTSxZQUFZLEdBQUcsU0FBUztBQUM5QixjQUFNLGNBQWMsR0FBRyxZQUFZLENBQUM7QUFDcEMsY0FBTSxTQUFTLFlBQVksSUFBSTtBQUFBO0FBQUEsVUFFN0IsWUFBWSxNQUFNLGlDQUFpQyxXQUFXO0FBQUEsWUFDNUQ7QUFDSixZQUFJLHNCQUFzQixDQUFDLE1BQU0sR0FBRztBQUNsQztBQUFBLFlBQ0U7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsT0FBTztBQUNoQixjQUFJLElBQUksS0FBSyxNQUFNLDJCQUEyQixDQUFDLEdBQUc7QUFDaEQsaUJBQUssV0FBVyxXQUFXLFFBQVEsQ0FBQztBQUFBLFVBQ3RDLE9BQU87QUFDTDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLENBQUMsT0FBTyxXQUFXLFFBQVEsVUFBVSxpQkFBaUIsU0FBUztBQUMxRSxVQUFNLEVBQUUsSUFBSSxNQUFNLFlBQVksVUFBVSxVQUFVLElBQUk7QUFDdEQsUUFBSSxZQUFZLEdBQUc7QUFDakIsV0FBSyxNQUFNLFVBQVUsU0FBUyxXQUFXLFFBQVEsUUFBUTtBQUN6RDtBQUFBLElBQ0Y7QUFDQSxRQUFJLFlBQVksS0FBSztBQUNuQixZQUFNLFNBQVMsS0FBSyxXQUFXLFFBQVEsUUFBUTtBQUMvQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFlBQVksSUFBSTtBQUNsQixXQUFLLEtBQUssT0FBTyxXQUFXLFFBQVEsU0FBUztBQUM3QztBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsVUFBVTtBQUNyQixpQkFBVyxJQUFJLFdBQVcsTUFBTTtBQUNoQyxlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3hDLGFBQUssU0FBUyxDQUFDLEdBQUcsV0FBVyxRQUFRLFFBQVE7QUFBQSxNQUMvQztBQUNBLGlCQUFXLE1BQU0sUUFBUSxXQUFXLE1BQU07QUFDMUM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxTQUFTLFFBQVE7QUFDbkIscUJBQWUsT0FBTyxXQUFXLE1BQU07QUFDdkM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxrQkFBa0IsYUFBYSxLQUFLLFlBQVksS0FBSztBQUMzRCxRQUFJLGlCQUFpQjtBQUNuQixVQUFJLGFBQWEsR0FBRztBQUNsQixZQUFJLFdBQVcsYUFBYSxDQUFDLEdBQUcsVUFBVSxHQUFHO0FBQzNDLHFCQUFXLElBQUksV0FBVyxNQUFNO0FBQUEsUUFDbEMsT0FBTztBQUNMLHFCQUFXLFlBQVksRUFBRTtBQUN6QixxQkFBVyxJQUFJLFdBQVcsTUFBTTtBQUNoQyxnQ0FBc0IsTUFBTSxXQUFXLE1BQU0sRUFBRSxHQUFHLGNBQWM7QUFBQSxRQUNsRTtBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU0sRUFBRSxPQUFPLFlBQVksV0FBVyxJQUFJO0FBQzFDLGNBQU1XLFdBQVUsTUFBTTtBQUNwQixjQUFJLE1BQU0sSUFBSSxhQUFhO0FBQ3pCLHVCQUFXLEVBQUU7QUFBQSxVQUNmLE9BQU87QUFDTCx1QkFBVyxJQUFJLFdBQVcsTUFBTTtBQUFBLFVBQ2xDO0FBQUEsUUFDRjtBQUNBLGNBQU0sZUFBZSxNQUFNO0FBQ3pCLGdCQUFNLGFBQWEsR0FBRyxjQUFjLENBQUMsQ0FBQyxHQUFHLFVBQVU7QUFDbkQsY0FBSSxHQUFHLFlBQVk7QUFDakIsZUFBRyxVQUFVO0FBQUEsY0FDWDtBQUFBO0FBQUEsWUFFRjtBQUFBLFVBQ0Y7QUFDQSxjQUFJLFdBQVcsYUFBYSxDQUFDLFlBQVk7QUFDdkMsWUFBQUEsU0FBUTtBQUFBLFVBQ1YsT0FBTztBQUNMLGtCQUFNLElBQUksTUFBTTtBQUNkLGNBQUFBLFNBQVE7QUFDUiw0QkFBYyxXQUFXO0FBQUEsWUFDM0IsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGO0FBQ0EsWUFBSSxZQUFZO0FBQ2QscUJBQVcsSUFBSUEsVUFBUyxZQUFZO0FBQUEsUUFDdEMsT0FBTztBQUNMLHVCQUFhO0FBQUEsUUFDZjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLE9BQU87QUFDTCxpQkFBVyxJQUFJLFdBQVcsTUFBTTtBQUFBLElBQ2xDO0FBQUEsRUFDRjtBQUNBLFFBQU0sVUFBVSxDQUFDLE9BQU8saUJBQWlCLGdCQUFnQixXQUFXLE9BQU8sWUFBWSxVQUFVO0FBQy9GLFVBQU07QUFBQSxNQUNKO0FBQUEsTUFDQTtBQUFBLE1BQ0EsS0FBQVI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixJQUFJO0FBQ0osUUFBSSxjQUFjLElBQUk7QUFDcEIsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsUUFBSUEsUUFBTyxNQUFNO0FBQ2Ysb0JBQWM7QUFDZCxhQUFPQSxNQUFLLE1BQU0sZ0JBQWdCLE9BQU8sSUFBSTtBQUM3QyxvQkFBYztBQUFBLElBQ2hCO0FBQ0EsUUFBSSxjQUFjLE1BQU07QUFDdEIsc0JBQWdCLFlBQVksVUFBVSxJQUFJO0FBQUEsSUFDNUM7QUFDQSxRQUFJLFlBQVksS0FBSztBQUNuQixzQkFBZ0IsSUFBSSxXQUFXLEtBQUs7QUFDcEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxtQkFBbUIsWUFBWSxLQUFLO0FBQzFDLFVBQU0sd0JBQXdCLENBQUMsZUFBZSxLQUFLO0FBQ25ELFFBQUk7QUFDSixRQUFJLDBCQUEwQixZQUFZLFNBQVMsTUFBTSx1QkFBdUI7QUFDOUUsc0JBQWdCLFdBQVcsaUJBQWlCLEtBQUs7QUFBQSxJQUNuRDtBQUNBLFFBQUksWUFBWSxHQUFHO0FBQ2pCLHVCQUFpQixNQUFNLFdBQVcsZ0JBQWdCLFFBQVE7QUFBQSxJQUM1RCxPQUFPO0FBQ0wsVUFBSSxZQUFZLEtBQUs7QUFDbkIsY0FBTSxTQUFTLFFBQVEsZ0JBQWdCLFFBQVE7QUFDL0M7QUFBQSxNQUNGO0FBQ0EsVUFBSSxrQkFBa0I7QUFDcEIsNEJBQW9CLE9BQU8sTUFBTSxpQkFBaUIsZUFBZTtBQUFBLE1BQ25FO0FBQ0EsVUFBSSxZQUFZLElBQUk7QUFDbEIsY0FBTSxLQUFLO0FBQUEsVUFDVDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRixXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtYLENBQUMsZ0JBQWdCO0FBQUEsT0FDaEIsU0FBUyxZQUFZLFlBQVksS0FBSyxZQUFZLEtBQUs7QUFDdEQ7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFdBQVcsU0FBUyxZQUFZLGFBQWEsTUFBTSxRQUFRLENBQUMsYUFBYSxZQUFZLElBQUk7QUFDdkYsd0JBQWdCLFVBQVUsaUJBQWlCLGNBQWM7QUFBQSxNQUMzRDtBQUNBLFVBQUksVUFBVTtBQUNaLFFBQUFELFFBQU8sS0FBSztBQUFBLE1BQ2Q7QUFBQSxJQUNGO0FBQ0EsVUFBTSx1QkFBdUIsUUFBUSxRQUFRLGNBQWM7QUFDM0QsUUFBSSwwQkFBMEIsWUFBWSxTQUFTLE1BQU0scUJBQXFCLG9CQUFvQixzQkFBc0I7QUFDdEgsNEJBQXNCLE1BQU07QUFDMUIscUJBQWEsZ0JBQWdCLFdBQVcsaUJBQWlCLEtBQUs7QUFDOUQsNEJBQW9CLG9CQUFvQixPQUFPLE1BQU0saUJBQWlCLFdBQVc7QUFDakYsWUFBSSxzQkFBc0I7QUFDeEIsZ0JBQU0sS0FBSztBQUFBLFFBQ2I7QUFBQSxNQUNGLEdBQUcsY0FBYztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLFFBQU1BLFVBQVMsQ0FBQyxVQUFVO0FBQ3hCLFVBQU0sRUFBRSxNQUFNLElBQUksUUFBUSxXQUFXLElBQUk7QUFDekMsUUFBSSxTQUFTLFVBQVU7QUFDckIsVUFBaUQsTUFBTSxZQUFZLEtBQUssTUFBTSxZQUFZLFFBQVEsY0FBYyxDQUFDLFdBQVcsV0FBVztBQUNySSxjQUFNLFNBQVMsUUFBUSxDQUFDLFVBQVU7QUFDaEMsY0FBSSxNQUFNLFNBQVMsU0FBUztBQUMxQix1QkFBVyxNQUFNLEVBQUU7QUFBQSxVQUNyQixPQUFPO0FBQ0wsWUFBQUEsUUFBTyxLQUFLO0FBQUEsVUFDZDtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLHVCQUFlLElBQUksTUFBTTtBQUFBLE1BQzNCO0FBQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBSSxTQUFTLFFBQVE7QUFDbkIsdUJBQWlCLEtBQUs7QUFDdEI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxnQkFBZ0IsTUFBTTtBQUMxQixpQkFBVyxFQUFFO0FBQ2IsVUFBSSxjQUFjLENBQUMsV0FBVyxhQUFhLFdBQVcsWUFBWTtBQUNoRSxtQkFBVyxXQUFXO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBQ0EsUUFBSSxNQUFNLFlBQVksS0FBSyxjQUFjLENBQUMsV0FBVyxXQUFXO0FBQzlELFlBQU0sRUFBRSxPQUFPLFdBQVcsSUFBSTtBQUM5QixZQUFNLGVBQWUsTUFBTSxNQUFNLElBQUksYUFBYTtBQUNsRCxVQUFJLFlBQVk7QUFDZCxtQkFBVyxNQUFNLElBQUksZUFBZSxZQUFZO0FBQUEsTUFDbEQsT0FBTztBQUNMLHFCQUFhO0FBQUEsTUFDZjtBQUFBLElBQ0YsT0FBTztBQUNMLG9CQUFjO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxpQkFBaUIsQ0FBQyxLQUFLLFFBQVE7QUFDbkMsUUFBSTtBQUNKLFdBQU8sUUFBUSxLQUFLO0FBQ2xCLGFBQU8sZ0JBQWdCLEdBQUc7QUFDMUIsaUJBQVcsR0FBRztBQUNkLFlBQU07QUFBQSxJQUNSO0FBQ0EsZUFBVyxHQUFHO0FBQUEsRUFDaEI7QUFDQSxRQUFNLG1CQUFtQixDQUFDLFVBQVUsZ0JBQWdCLGFBQWE7QUFDL0QsUUFBaUQsU0FBUyxLQUFLLFNBQVM7QUFDdEUsb0JBQWMsUUFBUTtBQUFBLElBQ3hCO0FBQ0EsVUFBTSxFQUFFLEtBQUssT0FBTyxLQUFLLFNBQVMsSUFBSSxHQUFHLEVBQUUsSUFBSTtBQUMvQyxvQkFBZ0IsQ0FBQztBQUNqQixvQkFBZ0IsQ0FBQztBQUNqQixRQUFJLEtBQUs7QUFDUCxxQkFBZSxHQUFHO0FBQUEsSUFDcEI7QUFDQSxVQUFNLEtBQUs7QUFDWCxRQUFJLEtBQUs7QUFDUCxVQUFJLFNBQVM7QUFDYixjQUFRLFNBQVMsVUFBVSxnQkFBZ0IsUUFBUTtBQUFBLElBQ3JEO0FBQ0EsUUFBSSxJQUFJO0FBQ04sNEJBQXNCLElBQUksY0FBYztBQUFBLElBQzFDO0FBQ0EsMEJBQXNCLE1BQU07QUFDMUIsZUFBUyxjQUFjO0FBQUEsSUFDekIsR0FBRyxjQUFjO0FBQ2pCLFFBQUksTUFBb0U7QUFDdEUsK0JBQXlCLFFBQVE7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLGtCQUFrQixDQUFDLFVBQVUsaUJBQWlCLGdCQUFnQixXQUFXLE9BQU8sWUFBWSxPQUFPLFFBQVEsTUFBTTtBQUNySCxhQUFTLElBQUksT0FBTyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQzVDLGNBQVEsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLGdCQUFnQixVQUFVLFNBQVM7QUFBQSxJQUMzRTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGtCQUFrQixDQUFDLFVBQVU7QUFDakMsUUFBSSxNQUFNLFlBQVksR0FBRztBQUN2QixhQUFPLGdCQUFnQixNQUFNLFVBQVUsT0FBTztBQUFBLElBQ2hEO0FBQ0EsUUFBSSxNQUFNLFlBQVksS0FBSztBQUN6QixhQUFPLE1BQU0sU0FBUyxLQUFLO0FBQUEsSUFDN0I7QUFDQSxVQUFNLEtBQUssZ0JBQWdCLE1BQU0sVUFBVSxNQUFNLEVBQUU7QUFDbkQsVUFBTSxjQUFjLE1BQU0sR0FBRyxjQUFjO0FBQzNDLFdBQU8sY0FBYyxnQkFBZ0IsV0FBVyxJQUFJO0FBQUEsRUFDdEQ7QUFDQSxNQUFJLGFBQWE7QUFDakIsUUFBTSxTQUFTLENBQUMsT0FBTyxXQUFXLGNBQWM7QUFDOUMsUUFBSTtBQUNKLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFVBQUksVUFBVSxRQUFRO0FBQ3BCLGdCQUFRLFVBQVUsUUFBUSxNQUFNLE1BQU0sSUFBSTtBQUMxQyxtQkFBVyxVQUFVLE9BQU87QUFBQSxNQUM5QjtBQUFBLElBQ0YsT0FBTztBQUNMO0FBQUEsUUFDRSxVQUFVLFVBQVU7QUFBQSxRQUNwQjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxjQUFVLFNBQVM7QUFDbkIsUUFBSSxDQUFDLFlBQVk7QUFDZixtQkFBYTtBQUNiLHVCQUFpQixRQUFRO0FBQ3pCLHdCQUFrQjtBQUNsQixtQkFBYTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZO0FBQUEsSUFDaEIsR0FBRztBQUFBLElBQ0gsSUFBSTtBQUFBLElBQ0osR0FBRztBQUFBLElBQ0gsR0FBR0E7QUFBQSxJQUNILElBQUk7QUFBQSxJQUNKLElBQUk7QUFBQSxJQUNKLElBQUk7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxFQUNMO0FBQ0EsTUFBSTtBQUNKLE1BQUk7QUFDSixNQUFJLG9CQUFvQjtBQUN0QixLQUFDLFNBQVMsV0FBVyxJQUFJO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVyxhQUFhLFFBQVEsT0FBTztBQUFBLEVBQ3pDO0FBQ0Y7QUFDQSxTQUFTLHlCQUF5QixFQUFFLE1BQU0sTUFBTSxHQUFHLGtCQUFrQjtBQUNuRSxTQUFPLHFCQUFxQixTQUFTLFNBQVMsbUJBQW1CLHFCQUFxQixZQUFZLFNBQVMsb0JBQW9CLFNBQVMsTUFBTSxZQUFZLE1BQU0sU0FBUyxTQUFTLE1BQU0sSUFBSSxTQUFTO0FBQ3ZNO0FBQ0EsU0FBUyxjQUFjLEVBQUUsUUFBQUYsU0FBUSxJQUFJLEdBQUcsU0FBUztBQUMvQyxNQUFJLFNBQVM7QUFDWCxJQUFBQSxRQUFPLFNBQVM7QUFDaEIsUUFBSSxTQUFTO0FBQUEsRUFDZixPQUFPO0FBQ0wsSUFBQUEsUUFBTyxTQUFTO0FBQ2hCLFFBQUksU0FBUztBQUFBLEVBQ2Y7QUFDRjtBQUNBLFNBQVMsZUFBZSxnQkFBZ0IsWUFBWTtBQUNsRCxVQUFRLENBQUMsa0JBQWtCLGtCQUFrQixDQUFDLGVBQWUsa0JBQWtCLGNBQWMsQ0FBQyxXQUFXO0FBQzNHO0FBQ0EsU0FBUyx1QkFBdUIsSUFBSSxJQUFJLFVBQVUsT0FBTztBQUN2RCxRQUFNLE1BQU0sR0FBRztBQUNmLFFBQU0sTUFBTSxHQUFHO0FBQ2YsTUFBSSxRQUFRLEdBQUcsS0FBSyxRQUFRLEdBQUcsR0FBRztBQUNoQyxhQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0FBQ25DLFlBQU0sS0FBSyxJQUFJLENBQUM7QUFDaEIsVUFBSSxLQUFLLElBQUksQ0FBQztBQUNkLFVBQUksR0FBRyxZQUFZLEtBQUssQ0FBQyxHQUFHLGlCQUFpQjtBQUMzQyxZQUFJLEdBQUcsYUFBYSxLQUFLLEdBQUcsY0FBYyxJQUFJO0FBQzVDLGVBQUssSUFBSSxDQUFDLElBQUksZUFBZSxJQUFJLENBQUMsQ0FBQztBQUNuQyxhQUFHLEtBQUssR0FBRztBQUFBLFFBQ2I7QUFDQSxZQUFJLENBQUMsV0FBVyxHQUFHLGNBQWM7QUFDL0IsaUNBQXVCLElBQUksRUFBRTtBQUFBLE1BQ2pDO0FBQ0EsVUFBSSxHQUFHLFNBQVMsTUFBTTtBQUNwQixZQUFJLEdBQUcsY0FBYyxJQUFJO0FBQ3ZCLGVBQUssSUFBSSxDQUFDLElBQUksZUFBZSxFQUFFO0FBQUEsUUFDakM7QUFDQSxXQUFHLEtBQUssR0FBRztBQUFBLE1BQ2I7QUFDQSxVQUFJLEdBQUcsU0FBUyxXQUFXLENBQUMsR0FBRyxJQUFJO0FBQ2pDLFdBQUcsS0FBSyxHQUFHO0FBQUEsTUFDYjtBQUNBLFVBQUksTUFBMkM7QUFDN0MsV0FBRyxPQUFPLEdBQUcsR0FBRyxVQUFVO0FBQUEsTUFDNUI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxZQUFZLEtBQUs7QUFDeEIsUUFBTSxJQUFJLElBQUksTUFBTTtBQUNwQixRQUFNLFNBQVMsQ0FBQyxDQUFDO0FBQ2pCLE1BQUksR0FBRyxHQUFHLEdBQUcsR0FBRztBQUNoQixRQUFNLE1BQU0sSUFBSTtBQUNoQixPQUFLLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztBQUN4QixVQUFNLE9BQU8sSUFBSSxDQUFDO0FBQ2xCLFFBQUksU0FBUyxHQUFHO0FBQ2QsVUFBSSxPQUFPLE9BQU8sU0FBUyxDQUFDO0FBQzVCLFVBQUksSUFBSSxDQUFDLElBQUksTUFBTTtBQUNqQixVQUFFLENBQUMsSUFBSTtBQUNQLGVBQU8sS0FBSyxDQUFDO0FBQ2I7QUFBQSxNQUNGO0FBQ0EsVUFBSTtBQUNKLFVBQUksT0FBTyxTQUFTO0FBQ3BCLGFBQU8sSUFBSSxHQUFHO0FBQ1osWUFBSSxJQUFJLEtBQUs7QUFDYixZQUFJLElBQUksT0FBTyxDQUFDLENBQUMsSUFBSSxNQUFNO0FBQ3pCLGNBQUksSUFBSTtBQUFBLFFBQ1YsT0FBTztBQUNMLGNBQUk7QUFBQSxRQUNOO0FBQUEsTUFDRjtBQUNBLFVBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLEdBQUc7QUFDekIsWUFBSSxJQUFJLEdBQUc7QUFDVCxZQUFFLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQztBQUFBLFFBQ3JCO0FBQ0EsZUFBTyxDQUFDLElBQUk7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLE9BQU87QUFDWCxNQUFJLE9BQU8sSUFBSSxDQUFDO0FBQ2hCLFNBQU8sTUFBTSxHQUFHO0FBQ2QsV0FBTyxDQUFDLElBQUk7QUFDWixRQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLDJCQUEyQixVQUFVO0FBQzVDLFFBQU0sZUFBZSxTQUFTLFFBQVE7QUFDdEMsTUFBSSxjQUFjO0FBQ2hCLFFBQUksYUFBYSxZQUFZLENBQUMsYUFBYSxlQUFlO0FBQ3hELGFBQU87QUFBQSxJQUNULE9BQU87QUFDTCxhQUFPLDJCQUEyQixZQUFZO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixPQUFPO0FBQzlCLE1BQUksT0FBTztBQUNULGFBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRO0FBQ2hDLFlBQU0sQ0FBQyxFQUFFLFNBQVM7QUFBQSxFQUN0QjtBQUNGO0FBQ0EsU0FBUyxpQ0FBaUMsYUFBYTtBQUNyRCxNQUFJLFlBQVksYUFBYTtBQUMzQixXQUFPLFlBQVk7QUFBQSxFQUNyQjtBQUNBLFFBQU0sV0FBVyxZQUFZO0FBQzdCLE1BQUksVUFBVTtBQUNaLFdBQU8saUNBQWlDLFNBQVMsT0FBTztBQUFBLEVBQzFEO0FBQ0EsU0FBTztBQUNUO0FBRUEsTUFBTSxhQUFhLENBQUMsU0FBUyxLQUFLO0FBQ2xDLElBQUksYUFBYTtBQUNqQixNQUFNLGVBQWU7QUFBQSxFQUNuQixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtOLGNBQWM7QUFBQSxFQUNkLFFBQVEsSUFBSSxJQUFJLFdBQVcsUUFBUSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxXQUFXLG1CQUFtQjtBQUN6SCxRQUFJLE1BQU0sTUFBTTtBQUNkO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMLFVBQUksa0JBQWtCLGVBQWUsT0FBTyxLQUFLLENBQUMsR0FBRyxTQUFTLGNBQWM7QUFDMUUsV0FBRyxXQUFXLEdBQUc7QUFDakIsV0FBRyxTQUFTLFFBQVE7QUFDcEIsV0FBRyxLQUFLLEdBQUc7QUFDWDtBQUFBLE1BQ0Y7QUFDQTtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsU0FBUztBQUFBLEVBQ1QsV0FBVztBQUNiO0FBQ0EsTUFBTSxXQUFXO0FBQ2pCLFNBQVMsYUFBYSxPQUFPLE1BQU07QUFDakMsUUFBTSxnQkFBZ0IsTUFBTSxTQUFTLE1BQU0sTUFBTSxJQUFJO0FBQ3JELE1BQUksV0FBVyxhQUFhLEdBQUc7QUFDN0Isa0JBQWM7QUFBQSxFQUNoQjtBQUNGO0FBQ0EsU0FBUyxjQUFjLE9BQU8sV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLFdBQVcsbUJBQW1CO0FBQ3ZJLFFBQU07QUFBQSxJQUNKLEdBQUc7QUFBQSxJQUNILEdBQUcsRUFBRSxjQUFjO0FBQUEsRUFDckIsSUFBSTtBQUNKLFFBQU0sa0JBQWtCLGNBQWMsS0FBSztBQUMzQyxRQUFNLFdBQVcsTUFBTSxXQUFXO0FBQUEsSUFDaEM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQSxTQUFTLGdCQUFnQixNQUFNO0FBQUEsSUFDL0I7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFNBQVMsT0FBTyxHQUFHO0FBQ3JCLGlCQUFhLE9BQU8sV0FBVztBQUMvQixpQkFBYSxPQUFPLFlBQVk7QUFDaEM7QUFBQSxNQUNFO0FBQUEsTUFDQSxNQUFNO0FBQUEsTUFDTjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBO0FBQUEsTUFFQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0Esb0JBQWdCLFVBQVUsTUFBTSxVQUFVO0FBQUEsRUFDNUMsT0FBTztBQUNMLGFBQVMsUUFBUSxPQUFPLElBQUk7QUFBQSxFQUM5QjtBQUNGO0FBQ0EsU0FBUyxjQUFjLElBQUksSUFBSSxXQUFXLFFBQVEsaUJBQWlCLFdBQVcsY0FBYyxXQUFXLEVBQUUsR0FBRyxPQUFPLElBQUksU0FBUyxHQUFHLEVBQUUsY0FBYyxFQUFFLEdBQUc7QUFDdEosUUFBTSxXQUFXLEdBQUcsV0FBVyxHQUFHO0FBQ2xDLFdBQVMsUUFBUTtBQUNqQixLQUFHLEtBQUssR0FBRztBQUNYLFFBQU0sWUFBWSxHQUFHO0FBQ3JCLFFBQU0sY0FBYyxHQUFHO0FBQ3ZCLFFBQU0sRUFBRSxjQUFjLGVBQWUsY0FBYyxZQUFZLElBQUk7QUFDbkUsTUFBSSxlQUFlO0FBQ2pCLGFBQVMsZ0JBQWdCO0FBQ3pCLFFBQUksZ0JBQWdCLGVBQWUsU0FBUyxHQUFHO0FBQzdDO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBLFNBQVM7QUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsVUFBSSxTQUFTLFFBQVEsR0FBRztBQUN0QixpQkFBUyxRQUFRO0FBQUEsTUFDbkIsV0FBVyxjQUFjO0FBQ3ZCLFlBQUksQ0FBQyxhQUFhO0FBQ2hCO0FBQUEsWUFDRTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUE7QUFBQSxZQUVBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsMEJBQWdCLFVBQVUsV0FBVztBQUFBLFFBQ3ZDO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMLGVBQVMsWUFBWTtBQUNyQixVQUFJLGFBQWE7QUFDZixpQkFBUyxjQUFjO0FBQ3ZCLGlCQUFTLGVBQWU7QUFBQSxNQUMxQixPQUFPO0FBQ0wsZ0JBQVEsZUFBZSxpQkFBaUIsUUFBUTtBQUFBLE1BQ2xEO0FBQ0EsZUFBUyxPQUFPO0FBQ2hCLGVBQVMsUUFBUSxTQUFTO0FBQzFCLGVBQVMsa0JBQWtCLGNBQWMsS0FBSztBQUM5QyxVQUFJLGNBQWM7QUFDaEI7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBUztBQUFBLFVBQ1Q7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxZQUFJLFNBQVMsUUFBUSxHQUFHO0FBQ3RCLG1CQUFTLFFBQVE7QUFBQSxRQUNuQixPQUFPO0FBQ0w7QUFBQSxZQUNFO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQTtBQUFBLFlBRUE7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQSwwQkFBZ0IsVUFBVSxXQUFXO0FBQUEsUUFDdkM7QUFBQSxNQUNGLFdBQVcsZ0JBQWdCLGdCQUFnQixjQUFjLFNBQVMsR0FBRztBQUNuRTtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxpQkFBUyxRQUFRLElBQUk7QUFBQSxNQUN2QixPQUFPO0FBQ0w7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBUztBQUFBLFVBQ1Q7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxZQUFJLFNBQVMsUUFBUSxHQUFHO0FBQ3RCLG1CQUFTLFFBQVE7QUFBQSxRQUNuQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixPQUFPO0FBQ0wsUUFBSSxnQkFBZ0IsZ0JBQWdCLGNBQWMsU0FBUyxHQUFHO0FBQzVEO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLHNCQUFnQixVQUFVLFNBQVM7QUFBQSxJQUNyQyxPQUFPO0FBQ0wsbUJBQWEsSUFBSSxXQUFXO0FBQzVCLGVBQVMsZ0JBQWdCO0FBQ3pCLFVBQUksVUFBVSxZQUFZLEtBQUs7QUFDN0IsaUJBQVMsWUFBWSxVQUFVLFVBQVU7QUFBQSxNQUMzQyxPQUFPO0FBQ0wsaUJBQVMsWUFBWTtBQUFBLE1BQ3ZCO0FBQ0E7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0EsU0FBUztBQUFBLFFBQ1Q7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFNBQVMsUUFBUSxHQUFHO0FBQ3RCLGlCQUFTLFFBQVE7QUFBQSxNQUNuQixPQUFPO0FBQ0wsY0FBTSxFQUFFLFNBQVMsVUFBVSxJQUFJO0FBQy9CLFlBQUksVUFBVSxHQUFHO0FBQ2YscUJBQVcsTUFBTTtBQUNmLGdCQUFJLFNBQVMsY0FBYyxXQUFXO0FBQ3BDLHVCQUFTLFNBQVMsV0FBVztBQUFBLFlBQy9CO0FBQUEsVUFDRixHQUFHLE9BQU87QUFBQSxRQUNaLFdBQVcsWUFBWSxHQUFHO0FBQ3hCLG1CQUFTLFNBQVMsV0FBVztBQUFBLFFBQy9CO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxJQUFJLFlBQVk7QUFDaEIsU0FBUyx1QkFBdUIsT0FBTyxnQkFBZ0IsaUJBQWlCLFdBQVcsaUJBQWlCLFFBQVEsV0FBVyxjQUFjLFdBQVcsbUJBQW1CLGNBQWMsT0FBTztBQUN0TCxNQUF5RCxDQUFDLFdBQVc7QUFDbkUsZ0JBQVk7QUFDWixZQUFRLFFBQVEsT0FBTyxTQUFTLEtBQUs7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTtBQUFBLElBQ0osR0FBRztBQUFBLElBQ0gsR0FBRztBQUFBLElBQ0gsSUFBSTtBQUFBLElBQ0osR0FBRztBQUFBLElBQ0gsR0FBRyxFQUFFLFlBQVksUUFBQUUsUUFBTztBQUFBLEVBQzFCLElBQUk7QUFDSixNQUFJO0FBQ0osUUFBTSxnQkFBZ0IsbUJBQW1CLEtBQUs7QUFDOUMsTUFBSSxlQUFlO0FBQ2pCLFFBQUksa0JBQWtCLGVBQWUsZUFBZTtBQUNsRCx5QkFBbUIsZUFBZTtBQUNsQyxxQkFBZTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUNBLFFBQU0sVUFBVSxNQUFNLFFBQVEsU0FBUyxNQUFNLE1BQU0sT0FBTyxJQUFJO0FBQzlELE1BQUksTUFBMkM7QUFDN0MsaUJBQWEsU0FBUyxrQkFBa0I7QUFBQSxFQUMxQztBQUNBLFFBQU0sZ0JBQWdCO0FBQ3RCLFFBQU0sV0FBVztBQUFBLElBQ2Y7QUFBQSxJQUNBLFFBQVE7QUFBQSxJQUNSO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxNQUFNO0FBQUEsSUFDTixXQUFXO0FBQUEsSUFDWCxTQUFTLE9BQU8sWUFBWSxXQUFXLFVBQVU7QUFBQSxJQUNqRCxjQUFjO0FBQUEsSUFDZCx3QkFBd0I7QUFBQSxJQUN4QixlQUFlO0FBQUEsSUFDZixjQUFjLENBQUM7QUFBQSxJQUNmO0FBQUEsSUFDQSxhQUFhO0FBQUEsSUFDYixTQUFTLENBQUM7QUFBQSxJQUNWLFFBQVEsU0FBUyxPQUFPLE9BQU8sT0FBTztBQUNwQyxVQUFJLE1BQTJDO0FBQzdDLFlBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxlQUFlO0FBQ3RDLGdCQUFNLElBQUk7QUFBQSxZQUNSO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLFNBQVMsYUFBYTtBQUN4QixnQkFBTSxJQUFJO0FBQUEsWUFDUjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFlBQU07QUFBQSxRQUNKLE9BQU87QUFBQSxRQUNQO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxpQkFBaUI7QUFBQSxRQUNqQixXQUFXO0FBQUEsUUFDWDtBQUFBLE1BQ0YsSUFBSTtBQUNKLFVBQUksYUFBYTtBQUNqQixVQUFJLFNBQVMsYUFBYTtBQUN4QixpQkFBUyxjQUFjO0FBQUEsTUFDekIsV0FBVyxDQUFDLFFBQVE7QUFDbEIscUJBQWEsZ0JBQWdCLGNBQWMsY0FBYyxjQUFjLFdBQVcsU0FBUztBQUMzRixZQUFJLG1CQUFtQjtBQUN2QixZQUFJLFlBQVk7QUFDZCx1QkFBYSxXQUFXLGFBQWEsTUFBTTtBQUN6QyxnQkFBSSxjQUFjLFNBQVMsV0FBVztBQUNwQztBQUFBLGdCQUNFO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxXQUFXLGlCQUFpQixDQUFDLG1CQUFtQixLQUFLLFlBQVksSUFBSTtBQUFBLGdCQUNyRTtBQUFBLGNBQ0Y7QUFDQSwrQkFBaUIsT0FBTztBQUN4QixrQkFBSSxnQkFBZ0IsT0FBTyxZQUFZO0FBQ3JDLHVCQUFPLFdBQVcsS0FBSztBQUFBLGNBQ3pCO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsWUFBSSxnQkFBZ0IsQ0FBQyxTQUFTLHdCQUF3QjtBQUNwRCxjQUFJLFdBQVcsYUFBYSxFQUFFLE1BQU0sWUFBWTtBQUM5QyxxQkFBUyxLQUFLLFlBQVk7QUFDMUIsK0JBQW1CO0FBQUEsVUFDckI7QUFDQSxrQkFBUSxjQUFjLGtCQUFrQixVQUFVLElBQUk7QUFDdEQsY0FBSSxDQUFDLGNBQWMsZ0JBQWdCLE9BQU8sWUFBWTtBQUNwRCxrQ0FBc0IsTUFBTSxPQUFPLFdBQVcsS0FBSyxNQUFNLFFBQVE7QUFBQSxVQUNuRTtBQUFBLFFBQ0Y7QUFDQSxZQUFJLENBQUMsWUFBWTtBQUNmLGVBQUssZUFBZSxZQUFZLFFBQVEsQ0FBQztBQUFBLFFBQzNDO0FBQUEsTUFDRjtBQUNBLGVBQVMseUJBQXlCO0FBQ2xDLHNCQUFnQixVQUFVLGFBQWE7QUFDdkMsZUFBUyxnQkFBZ0I7QUFDekIsZUFBUyxlQUFlO0FBQ3hCLFVBQUksU0FBUyxTQUFTO0FBQ3RCLFVBQUksd0JBQXdCO0FBQzVCLGFBQU8sUUFBUTtBQUNiLFlBQUksT0FBTyxlQUFlO0FBQ3hCLG1CQUFTLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0FBQ3ZDLG1CQUFPLFFBQVEsS0FBSyxRQUFRLENBQUMsQ0FBQztBQUFBLFVBQ2hDO0FBQ0Esa0NBQXdCO0FBQ3hCO0FBQUEsUUFDRjtBQUNBLGlCQUFTLE9BQU87QUFBQSxNQUNsQjtBQUNBLFVBQUksQ0FBQyx5QkFBeUIsQ0FBQyxZQUFZO0FBQ3pDLHlCQUFpQixPQUFPO0FBQUEsTUFDMUI7QUFDQSxlQUFTLFVBQVUsQ0FBQztBQUNwQixVQUFJLGVBQWU7QUFDakIsWUFBSSxrQkFBa0IsZUFBZSxpQkFBaUIscUJBQXFCLGVBQWUsV0FBVztBQUNuRyx5QkFBZTtBQUNmLGNBQUksZUFBZSxTQUFTLEtBQUssQ0FBQyxNQUFNO0FBQ3RDLDJCQUFlLFFBQVE7QUFBQSxVQUN6QjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsbUJBQWEsUUFBUSxXQUFXO0FBQUEsSUFDbEM7QUFBQSxJQUNBLFNBQVMsZUFBZTtBQUN0QixVQUFJLENBQUMsU0FBUyxlQUFlO0FBQzNCO0FBQUEsTUFDRjtBQUNBLFlBQU0sRUFBRSxPQUFPLFFBQVEsY0FBYyxpQkFBaUIsa0JBQWtCLFdBQVcsWUFBWSxXQUFXLFdBQVcsSUFBSTtBQUN6SCxtQkFBYSxRQUFRLFlBQVk7QUFDakMsWUFBTSxVQUFVLEtBQUssWUFBWTtBQUNqQyxZQUFNLGdCQUFnQixNQUFNO0FBQzFCLGlCQUFTLHlCQUF5QjtBQUNsQyxZQUFJLENBQUMsU0FBUyxjQUFjO0FBQzFCO0FBQUEsUUFDRjtBQUNBO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUE7QUFBQSxVQUVBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0Esd0JBQWdCLFVBQVUsYUFBYTtBQUFBLE1BQ3pDO0FBQ0EsWUFBTSxhQUFhLGNBQWMsY0FBYyxjQUFjLFdBQVcsU0FBUztBQUNqRixVQUFJLFlBQVk7QUFDZCxpQkFBUyx5QkFBeUI7QUFDbEMscUJBQWEsV0FBVyxhQUFhO0FBQUEsTUFDdkM7QUFDQSxlQUFTLGVBQWU7QUFDeEI7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQTtBQUFBLFFBRUE7QUFBQTtBQUFBLE1BRUY7QUFDQSxVQUFJLENBQUMsWUFBWTtBQUNmLHNCQUFjO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLFlBQVksU0FBUyxNQUFNO0FBQzlCLGVBQVMsZ0JBQWdCLEtBQUssU0FBUyxjQUFjLFlBQVksU0FBUyxJQUFJO0FBQzlFLGVBQVMsWUFBWTtBQUFBLElBQ3ZCO0FBQUEsSUFDQSxPQUFPO0FBQ0wsYUFBTyxTQUFTLGdCQUFnQixLQUFLLFNBQVMsWUFBWTtBQUFBLElBQzVEO0FBQUEsSUFDQSxZQUFZLFVBQVUsbUJBQW1CLFlBQVk7QUFDbkQsWUFBTSxzQkFBc0IsQ0FBQyxDQUFDLFNBQVM7QUFDdkMsVUFBSSxxQkFBcUI7QUFDdkIsaUJBQVM7QUFBQSxNQUNYO0FBQ0EsWUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNsQyxlQUFTLFNBQVMsTUFBTSxDQUFDLFFBQVE7QUFDL0Isb0JBQVksS0FBSyxVQUFVLENBQUM7QUFBQSxNQUM5QixDQUFDLEVBQUUsS0FBSyxDQUFDLHFCQUFxQjtBQUM1QixZQUFJLFNBQVMsZUFBZSxTQUFTLGVBQWUsU0FBUyxjQUFjLFNBQVMsWUFBWTtBQUM5RjtBQUFBLFFBQ0Y7QUFDQSw2QkFBcUI7QUFDckIsaUJBQVMsZ0JBQWdCO0FBQ3pCLGNBQU0sRUFBRSxPQUFPLE9BQU8sSUFBSTtBQUMxQixZQUFJLE1BQTJDO0FBQzdDLDZCQUFtQixNQUFNO0FBQUEsUUFDM0I7QUFDQSwwQkFBa0IsVUFBVSxrQkFBa0IsS0FBSztBQUNuRCxZQUFJLFlBQVk7QUFDZCxpQkFBTyxLQUFLO0FBQUEsUUFDZDtBQUNBLGNBQU0sY0FBYyxDQUFDLGNBQWMsU0FBUyxRQUFRO0FBQ3BEO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlBLFdBQVcsY0FBYyxTQUFTLFFBQVEsRUFBRTtBQUFBO0FBQUE7QUFBQSxVQUc1QyxhQUFhLE9BQU8sS0FBSyxTQUFTLE9BQU87QUFBQSxVQUN6QztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLFlBQUksYUFBYTtBQUNmLGlCQUFPLGNBQWM7QUFDckIsVUFBQUEsUUFBTyxXQUFXO0FBQUEsUUFDcEI7QUFDQSx3QkFBZ0IsVUFBVSxPQUFPLEVBQUU7QUFDbkMsWUFBSSxNQUEyQztBQUM3Qyw0QkFBa0I7QUFBQSxRQUNwQjtBQUNBLFlBQUksdUJBQXVCLEVBQUUsU0FBUyxTQUFTLEdBQUc7QUFDaEQsbUJBQVMsUUFBUTtBQUFBLFFBQ25CO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLElBQ0EsUUFBUSxpQkFBaUIsVUFBVTtBQUNqQyxlQUFTLGNBQWM7QUFDdkIsVUFBSSxTQUFTLGNBQWM7QUFDekI7QUFBQSxVQUNFLFNBQVM7QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFVBQUksU0FBUyxlQUFlO0FBQzFCO0FBQUEsVUFDRSxTQUFTO0FBQUEsVUFDVDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLE1BQU0sT0FBTyxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxXQUFXLG1CQUFtQixhQUFhO0FBQ3pJLFFBQU0sV0FBVyxNQUFNLFdBQVc7QUFBQSxJQUNoQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxLQUFLO0FBQUE7QUFBQSxJQUVMLFNBQVMsY0FBYyxLQUFLO0FBQUEsSUFDNUI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVM7QUFBQSxJQUNiO0FBQUEsSUFDQSxTQUFTLGdCQUFnQixNQUFNO0FBQUEsSUFDL0I7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBSSxTQUFTLFNBQVMsR0FBRztBQUN2QixhQUFTLFFBQVEsT0FBTyxJQUFJO0FBQUEsRUFDOUI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLDBCQUEwQixPQUFPO0FBQ3hDLFFBQU0sRUFBRSxXQUFXLFNBQVMsSUFBSTtBQUNoQyxRQUFNLGlCQUFpQixZQUFZO0FBQ25DLFFBQU0sWUFBWTtBQUFBLElBQ2hCLGlCQUFpQixTQUFTLFVBQVU7QUFBQSxFQUN0QztBQUNBLFFBQU0sYUFBYSxpQkFBaUIsc0JBQXNCLFNBQVMsUUFBUSxJQUFJLFlBQVksT0FBTztBQUNwRztBQUNBLFNBQVMsc0JBQXNCLEdBQUc7QUFDaEMsTUFBSTtBQUNKLE1BQUksV0FBVyxDQUFDLEdBQUc7QUFDakIsVUFBTSxhQUFhLHNCQUFzQixFQUFFO0FBQzNDLFFBQUksWUFBWTtBQUNkLFFBQUUsS0FBSztBQUNQLGdCQUFVO0FBQUEsSUFDWjtBQUNBLFFBQUksRUFBRTtBQUNOLFFBQUksWUFBWTtBQUNkLFFBQUUsS0FBSztBQUNQLGNBQVE7QUFDUixpQkFBVztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFRLENBQUMsR0FBRztBQUNkLFVBQU0sY0FBYyxpQkFBaUIsQ0FBQztBQUN0QyxRQUFpRCxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUMsVUFBVSxVQUFVLHNCQUFzQixFQUFFLFNBQVMsR0FBRztBQUNqSSxhQUFPLDZDQUE2QztBQUFBLElBQ3REO0FBQ0EsUUFBSTtBQUFBLEVBQ047QUFDQSxNQUFJLGVBQWUsQ0FBQztBQUNwQixNQUFJLFNBQVMsQ0FBQyxFQUFFLGlCQUFpQjtBQUMvQixNQUFFLGtCQUFrQixNQUFNLE9BQU8sQ0FBQyxNQUFNLE1BQU0sQ0FBQztBQUFBLEVBQ2pEO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyx3QkFBd0IsSUFBSSxVQUFVO0FBQzdDLE1BQUksWUFBWSxTQUFTLGVBQWU7QUFDdEMsUUFBSSxRQUFRLEVBQUUsR0FBRztBQUNmLGVBQVMsUUFBUSxLQUFLLEdBQUcsRUFBRTtBQUFBLElBQzdCLE9BQU87QUFDTCxlQUFTLFFBQVEsS0FBSyxFQUFFO0FBQUEsSUFDMUI7QUFBQSxFQUNGLE9BQU87QUFDTCxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixVQUFVLFFBQVE7QUFDekMsV0FBUyxlQUFlO0FBQ3hCLFFBQU0sRUFBRSxPQUFPLGdCQUFnQixJQUFJO0FBQ25DLE1BQUksS0FBSyxPQUFPO0FBQ2hCLFNBQU8sQ0FBQyxNQUFNLE9BQU8sV0FBVztBQUM5QixhQUFTLE9BQU8sVUFBVTtBQUMxQixTQUFLLE9BQU87QUFBQSxFQUNkO0FBQ0EsUUFBTSxLQUFLO0FBQ1gsTUFBSSxtQkFBbUIsZ0JBQWdCLFlBQVksT0FBTztBQUN4RCxvQkFBZ0IsTUFBTSxLQUFLO0FBQzNCLG9CQUFnQixpQkFBaUIsRUFBRTtBQUFBLEVBQ3JDO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0FBQ2pDLFFBQU0sY0FBYyxNQUFNLFNBQVMsTUFBTSxNQUFNO0FBQy9DLFNBQU8sZUFBZSxRQUFRLGdCQUFnQjtBQUNoRDtBQUVBLE1BQU0sV0FBMkIsdUJBQU8sSUFBSSxPQUFPO0FBQ25ELE1BQU0sT0FBdUIsdUJBQU8sSUFBSSxPQUFPO0FBQy9DLE1BQU0sVUFBMEIsdUJBQU8sSUFBSSxPQUFPO0FBQ2xELE1BQU0sU0FBeUIsdUJBQU8sSUFBSSxPQUFPO0FBQ2pELE1BQU0sYUFBYSxDQUFDO0FBQ3BCLElBQUksZUFBZTtBQUNuQixTQUFTLFVBQVUsa0JBQWtCLE9BQU87QUFDMUMsYUFBVyxLQUFLLGVBQWUsa0JBQWtCLE9BQU8sQ0FBQyxDQUFDO0FBQzVEO0FBQ0EsU0FBUyxhQUFhO0FBQ3BCLGFBQVcsSUFBSTtBQUNmLGlCQUFlLFdBQVcsV0FBVyxTQUFTLENBQUMsS0FBSztBQUN0RDtBQUNBLElBQUkscUJBQXFCO0FBQ3pCLFNBQVMsaUJBQWlCLE9BQU8sVUFBVSxPQUFPO0FBQ2hELHdCQUFzQjtBQUN0QixNQUFJLFFBQVEsS0FBSyxnQkFBZ0IsU0FBUztBQUN4QyxpQkFBYSxVQUFVO0FBQUEsRUFDekI7QUFDRjtBQUNBLFNBQVMsV0FBVyxPQUFPO0FBQ3pCLFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLGdCQUFnQixZQUFZO0FBQzdFLGFBQVc7QUFDWCxNQUFJLHFCQUFxQixLQUFLLGNBQWM7QUFDMUMsaUJBQWEsS0FBSyxLQUFLO0FBQUEsRUFDekI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLG1CQUFtQixNQUFNLE9BQU8sVUFBVSxXQUFXLGNBQWMsV0FBVztBQUNyRixTQUFPO0FBQUEsSUFDTDtBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxZQUFZLE1BQU0sT0FBTyxVQUFVLFdBQVcsY0FBYztBQUNuRSxTQUFPO0FBQUEsSUFDTDtBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLFFBQVEsT0FBTztBQUN0QixTQUFPLFFBQVEsTUFBTSxnQkFBZ0IsT0FBTztBQUM5QztBQUNBLFNBQVMsZ0JBQWdCLElBQUksSUFBSTtBQUMvQixNQUFpRCxHQUFHLFlBQVksS0FBSyxHQUFHLFdBQVc7QUFDakYsVUFBTSxpQkFBaUIsbUJBQW1CLElBQUksR0FBRyxJQUFJO0FBQ3JELFFBQUksa0JBQWtCLGVBQWUsSUFBSSxHQUFHLFNBQVMsR0FBRztBQUN0RCxTQUFHLGFBQWE7QUFDaEIsU0FBRyxhQUFhO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU8sR0FBRyxTQUFTLEdBQUcsUUFBUSxHQUFHLFFBQVEsR0FBRztBQUM5QztBQUNBLElBQUk7QUFDSixTQUFTLG1CQUFtQixhQUFhO0FBQ3ZDLHlCQUF1QjtBQUN6QjtBQUNBLE1BQU0sK0JBQStCLElBQUksU0FBUztBQUNoRCxTQUFPO0FBQUEsSUFDTCxHQUFHLHVCQUF1QixxQkFBcUIsTUFBTSx3QkFBd0IsSUFBSTtBQUFBLEVBQ25GO0FBQ0Y7QUFDQSxNQUFNLGVBQWUsQ0FBQyxFQUFFLElBQUksTUFBTSxPQUFPLE9BQU8sTUFBTTtBQUN0RCxNQUFNLGVBQWUsQ0FBQztBQUFBLEVBQ3BCLEtBQUFDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixNQUFNO0FBQ0osTUFBSSxPQUFPQSxTQUFRLFVBQVU7QUFDM0IsSUFBQUEsT0FBTSxLQUFLQTtBQUFBLEVBQ2I7QUFDQSxTQUFPQSxRQUFPLE9BQU8sU0FBU0EsSUFBRyxLQUFLLE1BQU1BLElBQUcsS0FBSyxXQUFXQSxJQUFHLElBQUksRUFBRSxHQUFHLDBCQUEwQixHQUFHQSxNQUFLLEdBQUcsU0FBUyxHQUFHLENBQUMsQ0FBQyxRQUFRLElBQUlBLE9BQU07QUFDbEo7QUFDQSxTQUFTLGdCQUFnQixNQUFNLFFBQVEsTUFBTSxXQUFXLE1BQU0sWUFBWSxHQUFHLGVBQWUsTUFBTSxZQUFZLFNBQVMsV0FBVyxJQUFJLEdBQUcsY0FBYyxPQUFPLGdDQUFnQyxPQUFPO0FBQ25NLFFBQU0sUUFBUTtBQUFBLElBQ1osYUFBYTtBQUFBLElBQ2IsVUFBVTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsSUFDQSxLQUFLLFNBQVMsYUFBYSxLQUFLO0FBQUEsSUFDaEMsS0FBSyxTQUFTLGFBQWEsS0FBSztBQUFBLElBQ2hDLFNBQVM7QUFBQSxJQUNULGNBQWM7QUFBQSxJQUNkO0FBQUEsSUFDQSxXQUFXO0FBQUEsSUFDWCxVQUFVO0FBQUEsSUFDVixXQUFXO0FBQUEsSUFDWCxZQUFZO0FBQUEsSUFDWixNQUFNO0FBQUEsSUFDTixZQUFZO0FBQUEsSUFDWixJQUFJO0FBQUEsSUFDSixRQUFRO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixhQUFhO0FBQUEsSUFDYixjQUFjO0FBQUEsSUFDZCxhQUFhO0FBQUEsSUFDYjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxJQUNqQixZQUFZO0FBQUEsSUFDWixLQUFLO0FBQUEsRUFDUDtBQUNBLE1BQUksK0JBQStCO0FBQ2pDLHNCQUFrQixPQUFPLFFBQVE7QUFDakMsUUFBSSxZQUFZLEtBQUs7QUFDbkIsV0FBSyxVQUFVLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0YsV0FBVyxVQUFVO0FBQ25CLFVBQU0sYUFBYSxTQUFTLFFBQVEsSUFBSSxJQUFJO0FBQUEsRUFDOUM7QUFDQSxNQUFpRCxNQUFNLFFBQVEsTUFBTSxLQUFLO0FBQ3hFLFdBQU8scURBQXFELE1BQU0sSUFBSTtBQUFBLEVBQ3hFO0FBQ0EsTUFBaUQsU0FBUyxNQUFNLFlBQVksR0FBRztBQUM3RSxVQUFNLGtCQUFrQixNQUFNLGFBQWEsT0FBTyxjQUFjLE1BQU0sZUFBZSxPQUFPLGdCQUFnQjtBQUM1RyxRQUFJLG1CQUFtQixtQkFBbUIsTUFBTSxRQUFRLEdBQUc7QUFDekQ7QUFBQSxRQUNFLFNBQVMsZUFBZSxlQUFlLE1BQU0sSUFBSSxxREFBcUQsZUFBZTtBQUFBLE1BQ3ZIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLHFCQUFxQjtBQUFBLEVBQ3pCLENBQUM7QUFBQSxFQUNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FJQyxNQUFNLFlBQVksS0FBSyxZQUFZO0FBQUE7QUFBQSxFQUVwQyxNQUFNLGNBQWMsSUFBSTtBQUN0QixpQkFBYSxLQUFLLEtBQUs7QUFBQSxFQUN6QjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsbUJBQW1CLFVBQVU7QUFDcEMsTUFBSSxTQUFTLFFBQVEsRUFBRyxRQUFPLGFBQWE7QUFDNUMsTUFBSSxRQUFRLFFBQVEsRUFBRyxRQUFPLFNBQVMsU0FBUztBQUNoRCxTQUFPO0FBQ1Q7QUFDQSxNQUFNLGNBQWMsT0FBNEMsK0JBQStCO0FBQy9GLFNBQVMsYUFBYSxNQUFNLFFBQVEsTUFBTSxXQUFXLE1BQU0sWUFBWSxHQUFHLGVBQWUsTUFBTSxjQUFjLE9BQU87QUFDbEgsTUFBSSxDQUFDLFFBQVEsU0FBUyx3QkFBd0I7QUFDNUMsUUFBaUQsQ0FBQyxNQUFNO0FBQ3RELGFBQU8sMkNBQTJDLElBQUksR0FBRztBQUFBLElBQzNEO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFFBQVEsSUFBSSxHQUFHO0FBQ2pCLFVBQU0sU0FBUztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBO0FBQUEsSUFFRjtBQUNBLFFBQUksVUFBVTtBQUNaLHdCQUFrQixRQUFRLFFBQVE7QUFBQSxJQUNwQztBQUNBLFFBQUkscUJBQXFCLEtBQUssQ0FBQyxlQUFlLGNBQWM7QUFDMUQsVUFBSSxPQUFPLFlBQVksR0FBRztBQUN4QixxQkFBYSxhQUFhLFFBQVEsSUFBSSxDQUFDLElBQUk7QUFBQSxNQUM3QyxPQUFPO0FBQ0wscUJBQWEsS0FBSyxNQUFNO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBQ0EsV0FBTyxZQUFZO0FBQ25CLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxpQkFBaUIsSUFBSSxHQUFHO0FBQzFCLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxNQUFJLE9BQU87QUFDVCxZQUFRLG1CQUFtQixLQUFLO0FBQ2hDLFFBQUksRUFBRSxPQUFPLE9BQU8sTUFBTSxJQUFJO0FBQzlCLFFBQUksU0FBUyxDQUFDLFNBQVMsS0FBSyxHQUFHO0FBQzdCLFlBQU0sUUFBUSxlQUFlLEtBQUs7QUFBQSxJQUNwQztBQUNBLFFBQUksU0FBUyxLQUFLLEdBQUc7QUFDbkIsVUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLFFBQVEsS0FBSyxHQUFHO0FBQ3JDLGdCQUFRLE9BQU8sQ0FBQyxHQUFHLEtBQUs7QUFBQSxNQUMxQjtBQUNBLFlBQU0sUUFBUSxlQUFlLEtBQUs7QUFBQSxJQUNwQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLFlBQVksU0FBUyxJQUFJLElBQUksSUFBSSxXQUFXLElBQUksSUFBSSxNQUFNLFdBQVcsSUFBSSxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksSUFBSSxXQUFXLElBQUksSUFBSSxJQUFJO0FBQ3BJLE1BQWlELFlBQVksS0FBSyxRQUFRLElBQUksR0FBRztBQUMvRSxXQUFPLE1BQU0sSUFBSTtBQUNqQjtBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUE7QUFBQSxNQUVBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0FBQ2pDLE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsU0FBTyxRQUFRLEtBQUssS0FBSyxpQkFBaUIsS0FBSyxJQUFJLE9BQU8sQ0FBQyxHQUFHLEtBQUssSUFBSTtBQUN6RTtBQUNBLFNBQVMsV0FBVyxPQUFPLFlBQVksV0FBVyxPQUFPLGtCQUFrQixPQUFPO0FBQ2hGLFFBQU0sRUFBRSxPQUFPLEtBQUFBLE1BQUssV0FBVyxVQUFVLFdBQVcsSUFBSTtBQUN4RCxRQUFNLGNBQWMsYUFBYSxXQUFXLFNBQVMsQ0FBQyxHQUFHLFVBQVUsSUFBSTtBQUN2RSxRQUFNLFNBQVM7QUFBQSxJQUNiLGFBQWE7QUFBQSxJQUNiLFVBQVU7QUFBQSxJQUNWLE1BQU0sTUFBTTtBQUFBLElBQ1osT0FBTztBQUFBLElBQ1AsS0FBSyxlQUFlLGFBQWEsV0FBVztBQUFBLElBQzVDLEtBQUssY0FBYyxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJNUIsWUFBWUEsT0FBTSxRQUFRQSxJQUFHLElBQUlBLEtBQUksT0FBTyxhQUFhLFVBQVUsQ0FBQyxJQUFJLENBQUNBLE1BQUssYUFBYSxVQUFVLENBQUMsSUFBSSxhQUFhLFVBQVU7QUFBQSxRQUMvSEE7QUFBQSxJQUNKLFNBQVMsTUFBTTtBQUFBLElBQ2YsY0FBYyxNQUFNO0FBQUEsSUFDcEIsVUFBdUQsY0FBYyxNQUFNLFFBQVEsUUFBUSxJQUFJLFNBQVMsSUFBSSxjQUFjLElBQUk7QUFBQSxJQUM5SCxRQUFRLE1BQU07QUFBQSxJQUNkLGFBQWEsTUFBTTtBQUFBLElBQ25CLGNBQWMsTUFBTTtBQUFBLElBQ3BCLGFBQWEsTUFBTTtBQUFBLElBQ25CLFdBQVcsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLakIsV0FBVyxjQUFjLE1BQU0sU0FBUyxXQUFXLGNBQWMsS0FBSyxLQUFLLFlBQVksS0FBSztBQUFBLElBQzVGLGNBQWMsTUFBTTtBQUFBLElBQ3BCLGlCQUFpQixNQUFNO0FBQUEsSUFDdkIsWUFBWSxNQUFNO0FBQUEsSUFDbEIsTUFBTSxNQUFNO0FBQUEsSUFDWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQSxXQUFXLE1BQU07QUFBQSxJQUNqQixVQUFVLE1BQU07QUFBQSxJQUNoQixXQUFXLE1BQU0sYUFBYSxXQUFXLE1BQU0sU0FBUztBQUFBLElBQ3hELFlBQVksTUFBTSxjQUFjLFdBQVcsTUFBTSxVQUFVO0FBQUEsSUFDM0QsYUFBYSxNQUFNO0FBQUEsSUFDbkIsSUFBSSxNQUFNO0FBQUEsSUFDVixRQUFRLE1BQU07QUFBQSxJQUNkLEtBQUssTUFBTTtBQUFBLElBQ1gsSUFBSSxNQUFNO0FBQUEsRUFDWjtBQUNBLE1BQUksY0FBYyxpQkFBaUI7QUFDakM7QUFBQSxNQUNFO0FBQUEsTUFDQSxXQUFXLE1BQU0sTUFBTTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxPQUFPO0FBQzdCLFFBQU0sU0FBUyxXQUFXLEtBQUs7QUFDL0IsTUFBSSxRQUFRLE1BQU0sUUFBUSxHQUFHO0FBQzNCLFdBQU8sV0FBVyxNQUFNLFNBQVMsSUFBSSxjQUFjO0FBQUEsRUFDckQ7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQixPQUFPLEtBQUssT0FBTyxHQUFHO0FBQzdDLFNBQU8sWUFBWSxNQUFNLE1BQU0sTUFBTSxJQUFJO0FBQzNDO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUyxlQUFlO0FBQ2pELFFBQU0sUUFBUSxZQUFZLFFBQVEsTUFBTSxPQUFPO0FBQy9DLFFBQU0sY0FBYztBQUNwQixTQUFPO0FBQ1Q7QUFDQSxTQUFTLG1CQUFtQixPQUFPLElBQUksVUFBVSxPQUFPO0FBQ3RELFNBQU8sV0FBVyxVQUFVLEdBQUcsWUFBWSxTQUFTLE1BQU0sSUFBSSxLQUFLLFlBQVksU0FBUyxNQUFNLElBQUk7QUFDcEc7QUFDQSxTQUFTLGVBQWUsT0FBTztBQUM3QixNQUFJLFNBQVMsUUFBUSxPQUFPLFVBQVUsV0FBVztBQUMvQyxXQUFPLFlBQVksT0FBTztBQUFBLEVBQzVCLFdBQVcsUUFBUSxLQUFLLEdBQUc7QUFDekIsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUE7QUFBQSxNQUVBLE1BQU0sTUFBTTtBQUFBLElBQ2Q7QUFBQSxFQUNGLFdBQVcsUUFBUSxLQUFLLEdBQUc7QUFDekIsV0FBTyxlQUFlLEtBQUs7QUFBQSxFQUM3QixPQUFPO0FBQ0wsV0FBTyxZQUFZLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQzlDO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsT0FBTztBQUM3QixTQUFPLE1BQU0sT0FBTyxRQUFRLE1BQU0sY0FBYyxNQUFNLE1BQU0sT0FBTyxRQUFRLFdBQVcsS0FBSztBQUM3RjtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sVUFBVTtBQUMxQyxNQUFJLE9BQU87QUFDWCxRQUFNLEVBQUUsVUFBVSxJQUFJO0FBQ3RCLE1BQUksWUFBWSxNQUFNO0FBQ3BCLGVBQVc7QUFBQSxFQUNiLFdBQVcsUUFBUSxRQUFRLEdBQUc7QUFDNUIsV0FBTztBQUFBLEVBQ1QsV0FBVyxPQUFPLGFBQWEsVUFBVTtBQUN2QyxRQUFJLGFBQWEsSUFBSSxLQUFLO0FBQ3hCLFlBQU0sT0FBTyxTQUFTO0FBQ3RCLFVBQUksTUFBTTtBQUNSLGFBQUssT0FBTyxLQUFLLEtBQUs7QUFDdEIsMEJBQWtCLE9BQU8sS0FBSyxDQUFDO0FBQy9CLGFBQUssT0FBTyxLQUFLLEtBQUs7QUFBQSxNQUN4QjtBQUNBO0FBQUEsSUFDRixPQUFPO0FBQ0wsYUFBTztBQUNQLFlBQU0sV0FBVyxTQUFTO0FBQzFCLFVBQUksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLFFBQVEsR0FBRztBQUM1QyxpQkFBUyxPQUFPO0FBQUEsTUFDbEIsV0FBVyxhQUFhLEtBQUssMEJBQTBCO0FBQ3JELFlBQUkseUJBQXlCLE1BQU0sTUFBTSxHQUFHO0FBQzFDLG1CQUFTLElBQUk7QUFBQSxRQUNmLE9BQU87QUFDTCxtQkFBUyxJQUFJO0FBQ2IsZ0JBQU0sYUFBYTtBQUFBLFFBQ3JCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGLFdBQVcsV0FBVyxRQUFRLEdBQUc7QUFDL0IsUUFBSSxhQUFhLElBQUksS0FBSztBQUN4Qix3QkFBa0IsT0FBTyxFQUFFLFNBQVMsU0FBUyxDQUFDO0FBQzlDO0FBQUEsSUFDRjtBQUNBLGVBQVcsRUFBRSxTQUFTLFVBQVUsTUFBTSx5QkFBeUI7QUFDL0QsV0FBTztBQUFBLEVBQ1QsT0FBTztBQUNMLGVBQVcsT0FBTyxRQUFRO0FBQzFCLFFBQUksWUFBWSxJQUFJO0FBQ2xCLGFBQU87QUFDUCxpQkFBVyxDQUFDLGdCQUFnQixRQUFRLENBQUM7QUFBQSxJQUN2QyxPQUFPO0FBQ0wsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxXQUFXO0FBQ2pCLFFBQU0sYUFBYTtBQUNyQjtBQUNBLFNBQVMsY0FBYyxNQUFNO0FBQzNCLFFBQU0sTUFBTSxDQUFDO0FBQ2IsV0FBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztBQUNwQyxVQUFNLFVBQVUsS0FBSyxDQUFDO0FBQ3RCLGVBQVcsT0FBTyxTQUFTO0FBQ3pCLFVBQUksUUFBUSxTQUFTO0FBQ25CLFlBQUksSUFBSSxVQUFVLFFBQVEsT0FBTztBQUMvQixjQUFJLFFBQVEsZUFBZSxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUFBLFFBQ3ZEO0FBQUEsTUFDRixXQUFXLFFBQVEsU0FBUztBQUMxQixZQUFJLFFBQVEsZUFBZSxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUFBLE1BQ3ZELFdBQVcsS0FBSyxHQUFHLEdBQUc7QUFDcEIsY0FBTSxXQUFXLElBQUksR0FBRztBQUN4QixjQUFNLFdBQVcsUUFBUSxHQUFHO0FBQzVCLFlBQUksWUFBWSxhQUFhLFlBQVksRUFBRSxRQUFRLFFBQVEsS0FBSyxTQUFTLFNBQVMsUUFBUSxJQUFJO0FBQzVGLGNBQUksR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFFLE9BQU8sVUFBVSxRQUFRLElBQUk7QUFBQSxRQUN4RCxXQUFXLFlBQVksUUFBUSxZQUFZO0FBQUE7QUFBQSxRQUUzQyxDQUFDLGdCQUFnQixHQUFHLEdBQUc7QUFDckIsY0FBSSxHQUFHLElBQUk7QUFBQSxRQUNiO0FBQUEsTUFDRixXQUFXLFFBQVEsSUFBSTtBQUNyQixZQUFJLEdBQUcsSUFBSSxRQUFRLEdBQUc7QUFBQSxNQUN4QjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxVQUFVLE9BQU8sWUFBWSxNQUFNO0FBQ2hFLDZCQUEyQixNQUFNLFVBQVUsR0FBRztBQUFBLElBQzVDO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsTUFBTSxrQkFBa0IsaUJBQWlCO0FBQ3pDLElBQUksTUFBTTtBQUNWLFNBQVMsd0JBQXdCLE9BQU8sUUFBUSxVQUFVO0FBQ3hELFFBQU0sT0FBTyxNQUFNO0FBQ25CLFFBQU0sY0FBYyxTQUFTLE9BQU8sYUFBYSxNQUFNLGVBQWU7QUFDdEUsUUFBTSxXQUFXO0FBQUEsSUFDZixLQUFLO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsTUFBTTtBQUFBO0FBQUEsSUFFTixNQUFNO0FBQUEsSUFDTixTQUFTO0FBQUE7QUFBQSxJQUVULFFBQVE7QUFBQSxJQUNSLFFBQVE7QUFBQTtBQUFBLElBRVIsS0FBSztBQUFBLElBQ0wsT0FBTyxJQUFJO0FBQUEsTUFDVDtBQUFBO0FBQUEsSUFFRjtBQUFBLElBQ0EsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsU0FBUztBQUFBLElBQ1QsYUFBYTtBQUFBLElBQ2IsV0FBVztBQUFBLElBQ1gsVUFBVSxTQUFTLE9BQU8sV0FBVyxPQUFPLE9BQU8sV0FBVyxRQUFRO0FBQUEsSUFDdEUsS0FBSyxTQUFTLE9BQU8sTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDO0FBQUEsSUFDcEMsYUFBYTtBQUFBLElBQ2IsYUFBYSxDQUFDO0FBQUE7QUFBQSxJQUVkLFlBQVk7QUFBQSxJQUNaLFlBQVk7QUFBQTtBQUFBLElBRVosY0FBYyxzQkFBc0IsTUFBTSxVQUFVO0FBQUEsSUFDcEQsY0FBYyxzQkFBc0IsTUFBTSxVQUFVO0FBQUE7QUFBQSxJQUVwRCxNQUFNO0FBQUE7QUFBQSxJQUVOLFNBQVM7QUFBQTtBQUFBLElBRVQsZUFBZTtBQUFBO0FBQUEsSUFFZixjQUFjLEtBQUs7QUFBQTtBQUFBLElBRW5CLEtBQUs7QUFBQSxJQUNMLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQTtBQUFBLElBRWQ7QUFBQSxJQUNBLFlBQVksV0FBVyxTQUFTLFlBQVk7QUFBQSxJQUM1QyxVQUFVO0FBQUEsSUFDVixlQUFlO0FBQUE7QUFBQTtBQUFBLElBR2YsV0FBVztBQUFBLElBQ1gsYUFBYTtBQUFBLElBQ2IsZUFBZTtBQUFBLElBQ2YsSUFBSTtBQUFBLElBQ0osR0FBRztBQUFBLElBQ0gsSUFBSTtBQUFBLElBQ0osR0FBRztBQUFBLElBQ0gsSUFBSTtBQUFBLElBQ0osR0FBRztBQUFBLElBQ0gsSUFBSTtBQUFBLElBQ0osS0FBSztBQUFBLElBQ0wsSUFBSTtBQUFBLElBQ0osR0FBRztBQUFBLElBQ0gsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsSUFBSTtBQUFBLElBQ0osSUFBSTtBQUFBLEVBQ047QUFDQSxNQUFJLE1BQTJDO0FBQzdDLGFBQVMsTUFBTSx1QkFBdUIsUUFBUTtBQUFBLEVBQ2hELE9BQU87QUFDTCxhQUFTLE1BQU0sRUFBRSxHQUFHLFNBQVM7QUFBQSxFQUMvQjtBQUNBLFdBQVMsT0FBTyxTQUFTLE9BQU8sT0FBTztBQUN2QyxXQUFTLE9BQU8sS0FBSyxLQUFLLE1BQU0sUUFBUTtBQUN4QyxNQUFJLE1BQU0sSUFBSTtBQUNaLFVBQU0sR0FBRyxRQUFRO0FBQUEsRUFDbkI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxJQUFJLGtCQUFrQjtBQUN0QixNQUFNLHFCQUFxQixNQUFNLG1CQUFtQjtBQUNwRCxJQUFJO0FBQ0osSUFBSTtBQUNKO0FBQ0UsUUFBTSxJQUFJLGNBQWM7QUFDeEIsUUFBTSx1QkFBdUIsQ0FBQyxLQUFLLFdBQVc7QUFDNUMsUUFBSTtBQUNKLFFBQUksRUFBRSxVQUFVLEVBQUUsR0FBRyxHQUFJLFdBQVUsRUFBRSxHQUFHLElBQUksQ0FBQztBQUM3QyxZQUFRLEtBQUssTUFBTTtBQUNuQixXQUFPLENBQUMsTUFBTTtBQUNaLFVBQUksUUFBUSxTQUFTLEVBQUcsU0FBUSxRQUFRLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQztBQUFBLFVBQ2xELFNBQVEsQ0FBQyxFQUFFLENBQUM7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDQSwrQkFBNkI7QUFBQSxJQUMzQjtBQUFBLElBQ0EsQ0FBQyxNQUFNLGtCQUFrQjtBQUFBLEVBQzNCO0FBQ0EsdUJBQXFCO0FBQUEsSUFDbkI7QUFBQSxJQUNBLENBQUMsTUFBTSx3QkFBd0I7QUFBQSxFQUNqQztBQUNGO0FBQ0EsTUFBTSxxQkFBcUIsQ0FBQyxhQUFhO0FBQ3ZDLFFBQU0sT0FBTztBQUNiLDZCQUEyQixRQUFRO0FBQ25DLFdBQVMsTUFBTSxHQUFHO0FBQ2xCLFNBQU8sTUFBTTtBQUNYLGFBQVMsTUFBTSxJQUFJO0FBQ25CLCtCQUEyQixJQUFJO0FBQUEsRUFDakM7QUFDRjtBQUNBLE1BQU0sdUJBQXVCLE1BQU07QUFDakMscUJBQW1CLGdCQUFnQixNQUFNLElBQUk7QUFDN0MsNkJBQTJCLElBQUk7QUFDakM7QUFDQSxNQUFNLGVBQStCLHdCQUFRLGdCQUFnQjtBQUM3RCxTQUFTLHNCQUFzQixNQUFNLEVBQUUsWUFBWSxHQUFHO0FBQ3BELE1BQUksYUFBYSxJQUFJLEtBQUssWUFBWSxJQUFJLEdBQUc7QUFDM0M7QUFBQSxNQUNFLG9FQUFvRTtBQUFBLElBQ3RFO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxvQkFBb0IsVUFBVTtBQUNyQyxTQUFPLFNBQVMsTUFBTSxZQUFZO0FBQ3BDO0FBQ0EsSUFBSSx3QkFBd0I7QUFDNUIsU0FBUyxlQUFlLFVBQVUsUUFBUSxPQUFPLFlBQVksT0FBTztBQUNsRSxXQUFTLG1CQUFtQixLQUFLO0FBQ2pDLFFBQU0sRUFBRSxPQUFPLFNBQVMsSUFBSSxTQUFTO0FBQ3JDLFFBQU0sYUFBYSxvQkFBb0IsUUFBUTtBQUMvQyxZQUFVLFVBQVUsT0FBTyxZQUFZLEtBQUs7QUFDNUMsWUFBVSxVQUFVLFVBQVUsYUFBYSxLQUFLO0FBQ2hELFFBQU0sY0FBYyxhQUFhLHVCQUF1QixVQUFVLEtBQUssSUFBSTtBQUMzRSxXQUFTLG1CQUFtQixLQUFLO0FBQ2pDLFNBQU87QUFDVDtBQUNBLFNBQVMsdUJBQXVCLFVBQVUsT0FBTztBQUMvQyxRQUFNLFlBQVksU0FBUztBQUMzQixNQUFJLE1BQTJDO0FBQzdDLFFBQUksVUFBVSxNQUFNO0FBQ2xCLDRCQUFzQixVQUFVLE1BQU0sU0FBUyxXQUFXLE1BQU07QUFBQSxJQUNsRTtBQUNBLFFBQUksVUFBVSxZQUFZO0FBQ3hCLFlBQU0sUUFBUSxPQUFPLEtBQUssVUFBVSxVQUFVO0FBQzlDLGVBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDckMsOEJBQXNCLE1BQU0sQ0FBQyxHQUFHLFNBQVMsV0FBVyxNQUFNO0FBQUEsTUFDNUQ7QUFBQSxJQUNGO0FBQ0EsUUFBSSxVQUFVLFlBQVk7QUFDeEIsWUFBTSxRQUFRLE9BQU8sS0FBSyxVQUFVLFVBQVU7QUFDOUMsZUFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQyw4QkFBc0IsTUFBTSxDQUFDLENBQUM7QUFBQSxNQUNoQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFVBQVUsbUJBQW1CLGNBQWMsR0FBRztBQUNoRDtBQUFBLFFBQ0U7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxXQUFTLGNBQThCLHVCQUFPLE9BQU8sSUFBSTtBQUN6RCxXQUFTLFFBQVEsSUFBSSxNQUFNLFNBQVMsS0FBSywyQkFBMkI7QUFDcEUsTUFBSSxNQUEyQztBQUM3QywrQkFBMkIsUUFBUTtBQUFBLEVBQ3JDO0FBQ0EsUUFBTSxFQUFFLE1BQU0sSUFBSTtBQUNsQixNQUFJLE9BQU87QUFDVCxrQkFBYztBQUNkLFVBQU0sZUFBZSxTQUFTLGVBQWUsTUFBTSxTQUFTLElBQUksbUJBQW1CLFFBQVEsSUFBSTtBQUMvRixVQUFNLFFBQVEsbUJBQW1CLFFBQVE7QUFDekMsVUFBTSxjQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxRQUNFLE9BQTRDLGdCQUFnQixTQUFTLEtBQUssSUFBSSxTQUFTO0FBQUEsUUFDdkY7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU0sZUFBZSxVQUFVLFdBQVc7QUFDMUMsa0JBQWM7QUFDZCxVQUFNO0FBQ04sU0FBSyxnQkFBZ0IsU0FBUyxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUc7QUFDOUQsd0JBQWtCLFFBQVE7QUFBQSxJQUM1QjtBQUNBLFFBQUksY0FBYztBQUNoQixrQkFBWSxLQUFLLHNCQUFzQixvQkFBb0I7QUFDM0QsVUFBSSxPQUFPO0FBQ1QsZUFBTyxZQUFZLEtBQUssQ0FBQyxtQkFBbUI7QUFDMUMsNkJBQW1CLElBQUk7QUFDdkIsY0FBSTtBQUNGLDhCQUFrQixVQUFVLGdCQUFnQixLQUFLO0FBQUEsVUFDbkQsVUFBRTtBQUNBLCtCQUFtQixLQUFLO0FBQUEsVUFDMUI7QUFBQSxRQUNGLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNkLHNCQUFZLEdBQUcsVUFBVSxDQUFDO0FBQUEsUUFDNUIsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLGlCQUFTLFdBQVc7QUFDcEIsWUFBaUQsQ0FBQyxTQUFTLFVBQVU7QUFDbkUsZ0JBQU0sT0FBTyxvQkFBb0IsVUFBVSxTQUFTO0FBQ3BEO0FBQUEsWUFDRSxjQUFjLElBQUk7QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0wsd0JBQWtCLFVBQVUsYUFBYSxLQUFLO0FBQUEsSUFDaEQ7QUFBQSxFQUNGLE9BQU87QUFDTCx5QkFBcUIsVUFBVSxLQUFLO0FBQUEsRUFDdEM7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLFVBQVUsYUFBYSxPQUFPO0FBQ3ZELE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsUUFBSSxTQUFTLEtBQUssbUJBQW1CO0FBQ25DLGVBQVMsWUFBWTtBQUFBLElBQ3ZCLE9BQU87QUFDTCxlQUFTLFNBQVM7QUFBQSxJQUNwQjtBQUFBLEVBQ0YsV0FBVyxTQUFTLFdBQVcsR0FBRztBQUNoQyxRQUFpRCxRQUFRLFdBQVcsR0FBRztBQUNyRTtBQUFBLFFBQ0U7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksTUFBb0U7QUFDdEUsZUFBUyx3QkFBd0I7QUFBQSxJQUNuQztBQUNBLGFBQVMsYUFBYSxVQUFVLFdBQVc7QUFDM0MsUUFBSSxNQUEyQztBQUM3QyxzQ0FBZ0MsUUFBUTtBQUFBLElBQzFDO0FBQUEsRUFDRixXQUF3RCxnQkFBZ0IsUUFBUTtBQUM5RTtBQUFBLE1BQ0UsOENBQThDLGdCQUFnQixPQUFPLFNBQVMsT0FBTyxXQUFXO0FBQUEsSUFDbEc7QUFBQSxFQUNGO0FBQ0EsdUJBQXFCLFVBQVUsS0FBSztBQUN0QztBQUNBLElBQUk7QUFDSixJQUFJO0FBQ0osU0FBUyx3QkFBd0IsVUFBVTtBQUN6QyxZQUFVO0FBQ1YscUJBQW1CLENBQUMsTUFBTTtBQUN4QixRQUFJLEVBQUUsT0FBTyxLQUFLO0FBQ2hCLFFBQUUsWUFBWSxJQUFJLE1BQU0sRUFBRSxLQUFLLDBDQUEwQztBQUFBLElBQzNFO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxnQkFBZ0IsTUFBTSxDQUFDO0FBQzdCLFNBQVMscUJBQXFCLFVBQVUsT0FBTyxhQUFhO0FBQzFELFFBQU0sWUFBWSxTQUFTO0FBQzNCLE1BQUksQ0FBQyxTQUFTLFFBQVE7QUFDcEIsUUFBSSxDQUFDLFNBQVMsV0FBVyxDQUFDLFVBQVUsUUFBUTtBQUMxQyxZQUFNLFdBQVcsVUFBVSxZQUFZLHVCQUF1QixxQkFBcUIsUUFBUSxFQUFFO0FBQzdGLFVBQUksVUFBVTtBQUNaLFlBQUksTUFBMkM7QUFDN0MsdUJBQWEsVUFBVSxTQUFTO0FBQUEsUUFDbEM7QUFDQSxjQUFNLEVBQUUsaUJBQWlCLGdCQUFnQixJQUFJLFNBQVMsV0FBVztBQUNqRSxjQUFNLEVBQUUsWUFBWSxpQkFBaUIseUJBQXlCLElBQUk7QUFDbEUsY0FBTSx1QkFBdUI7QUFBQSxVQUMzQjtBQUFBLFlBQ0U7QUFBQSxjQUNFO0FBQUEsY0FDQTtBQUFBLFlBQ0Y7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0Esa0JBQVUsU0FBUyxRQUFRLFVBQVUsb0JBQW9CO0FBQ3pELFlBQUksTUFBMkM7QUFDN0MscUJBQVcsVUFBVSxTQUFTO0FBQUEsUUFDaEM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLGFBQVMsU0FBUyxVQUFVLFVBQVU7QUFDdEMsUUFBSSxrQkFBa0I7QUFDcEIsdUJBQWlCLFFBQVE7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLHVCQUF1QixNQUFNO0FBQy9CLFVBQU0sUUFBUSxtQkFBbUIsUUFBUTtBQUN6QyxrQkFBYztBQUNkLFFBQUk7QUFDRixtQkFBYSxRQUFRO0FBQUEsSUFDdkIsVUFBRTtBQUNBLG9CQUFjO0FBQ2QsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQ0EsTUFBaUQsQ0FBQyxVQUFVLFVBQVUsU0FBUyxXQUFXLFFBQVEsQ0FBQyxPQUFPO0FBQ3hHLFFBQUksQ0FBQyxXQUFXLFVBQVUsVUFBVTtBQUNsQztBQUFBLFFBQ0U7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0wsYUFBTyxzREFBc0QsU0FBUztBQUFBLElBQ3hFO0FBQUEsRUFDRjtBQUNGO0FBQ0EsTUFBTSxxQkFBcUIsT0FBNEM7QUFBQSxFQUNyRSxJQUFJLFFBQVEsS0FBSztBQUNmLHNCQUFrQjtBQUNsQixVQUFNLFFBQVEsT0FBTyxFQUFFO0FBQ3ZCLFdBQU8sT0FBTyxHQUFHO0FBQUEsRUFDbkI7QUFBQSxFQUNBLE1BQU07QUFDSixXQUFPLGlDQUFpQztBQUN4QyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsaUJBQWlCO0FBQ2YsV0FBTyxpQ0FBaUM7QUFDeEMsV0FBTztBQUFBLEVBQ1Q7QUFDRixJQUFJO0FBQUEsRUFDRixJQUFJLFFBQVEsS0FBSztBQUNmLFVBQU0sUUFBUSxPQUFPLEVBQUU7QUFDdkIsV0FBTyxPQUFPLEdBQUc7QUFBQSxFQUNuQjtBQUNGO0FBQ0EsU0FBUyxjQUFjLFVBQVU7QUFDL0IsU0FBTyxJQUFJLE1BQU0sU0FBUyxPQUFPO0FBQUEsSUFDL0IsSUFBSSxRQUFRLEtBQUs7QUFDZixZQUFNLFVBQVUsT0FBTyxRQUFRO0FBQy9CLGFBQU8sT0FBTyxHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsbUJBQW1CLFVBQVU7QUFDcEMsUUFBTSxTQUFTLENBQUMsWUFBWTtBQUMxQixRQUFJLE1BQTJDO0FBQzdDLFVBQUksU0FBUyxTQUFTO0FBQ3BCLGVBQU8sa0RBQWtEO0FBQUEsTUFDM0Q7QUFDQSxVQUFJLFdBQVcsTUFBTTtBQUNuQixZQUFJLGNBQWMsT0FBTztBQUN6QixZQUFJLGdCQUFnQixVQUFVO0FBQzVCLGNBQUksUUFBUSxPQUFPLEdBQUc7QUFDcEIsMEJBQWM7QUFBQSxVQUNoQixXQUFXLE1BQU0sT0FBTyxHQUFHO0FBQ3pCLDBCQUFjO0FBQUEsVUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxnQkFBZ0IsVUFBVTtBQUM1QjtBQUFBLFlBQ0Usc0RBQXNELFdBQVc7QUFBQSxVQUNuRTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLGFBQVMsVUFBVSxXQUFXLENBQUM7QUFBQSxFQUNqQztBQUNBLE1BQUksTUFBMkM7QUFDN0MsUUFBSTtBQUNKLFFBQUk7QUFDSixXQUFPLE9BQU8sT0FBTztBQUFBLE1BQ25CLElBQUksUUFBUTtBQUNWLGVBQU8sZUFBZSxhQUFhLElBQUksTUFBTSxTQUFTLE9BQU8sa0JBQWtCO0FBQUEsTUFDakY7QUFBQSxNQUNBLElBQUksUUFBUTtBQUNWLGVBQU8sZUFBZSxhQUFhLGNBQWMsUUFBUTtBQUFBLE1BQzNEO0FBQUEsTUFDQSxJQUFJLE9BQU87QUFDVCxlQUFPLENBQUMsVUFBVSxTQUFTLFNBQVMsS0FBSyxPQUFPLEdBQUcsSUFBSTtBQUFBLE1BQ3pEO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFdBQU87QUFBQSxNQUNMLE9BQU8sSUFBSSxNQUFNLFNBQVMsT0FBTyxrQkFBa0I7QUFBQSxNQUNuRCxPQUFPLFNBQVM7QUFBQSxNQUNoQixNQUFNLFNBQVM7QUFBQSxNQUNmO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsMkJBQTJCLFVBQVU7QUFDNUMsTUFBSSxTQUFTLFNBQVM7QUFDcEIsV0FBTyxTQUFTLGdCQUFnQixTQUFTLGNBQWMsSUFBSSxNQUFNLFVBQVUsUUFBUSxTQUFTLE9BQU8sQ0FBQyxHQUFHO0FBQUEsTUFDckcsSUFBSSxRQUFRLEtBQUs7QUFDZixZQUFJLE9BQU8sUUFBUTtBQUNqQixpQkFBTyxPQUFPLEdBQUc7QUFBQSxRQUNuQixXQUFXLE9BQU8scUJBQXFCO0FBQ3JDLGlCQUFPLG9CQUFvQixHQUFHLEVBQUUsUUFBUTtBQUFBLFFBQzFDO0FBQUEsTUFDRjtBQUFBLE1BQ0EsSUFBSSxRQUFRLEtBQUs7QUFDZixlQUFPLE9BQU8sVUFBVSxPQUFPO0FBQUEsTUFDakM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILE9BQU87QUFDTCxXQUFPLFNBQVM7QUFBQSxFQUNsQjtBQUNGO0FBQ0EsTUFBTSxhQUFhO0FBQ25CLE1BQU0sV0FBVyxDQUFDLFFBQVEsSUFBSSxRQUFRLFlBQVksQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLEVBQUUsUUFBUSxTQUFTLEVBQUU7QUFDN0YsU0FBUyxpQkFBaUIsV0FBVyxrQkFBa0IsTUFBTTtBQUMzRCxTQUFPLFdBQVcsU0FBUyxJQUFJLFVBQVUsZUFBZSxVQUFVLE9BQU8sVUFBVSxRQUFRLG1CQUFtQixVQUFVO0FBQzFIO0FBQ0EsU0FBUyxvQkFBb0IsVUFBVSxXQUFXLFNBQVMsT0FBTztBQUNoRSxNQUFJLE9BQU8saUJBQWlCLFNBQVM7QUFDckMsTUFBSSxDQUFDLFFBQVEsVUFBVSxRQUFRO0FBQzdCLFVBQU0sUUFBUSxVQUFVLE9BQU8sTUFBTSxpQkFBaUI7QUFDdEQsUUFBSSxPQUFPO0FBQ1QsYUFBTyxNQUFNLENBQUM7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsUUFBUSxVQUFVO0FBQ3JCLFVBQU0sb0JBQW9CLENBQUMsYUFBYTtBQUN0QyxpQkFBVyxPQUFPLFVBQVU7QUFDMUIsWUFBSSxTQUFTLEdBQUcsTUFBTSxXQUFXO0FBQy9CLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTyxrQkFBa0IsU0FBUyxVQUFVLEtBQUssU0FBUyxVQUFVO0FBQUEsTUFDbEUsU0FBUyxPQUFPLEtBQUs7QUFBQSxJQUN2QixLQUFLLGtCQUFrQixTQUFTLFdBQVcsVUFBVTtBQUFBLEVBQ3ZEO0FBQ0EsU0FBTyxPQUFPLFNBQVMsSUFBSSxJQUFJLFNBQVMsUUFBUTtBQUNsRDtBQUNBLFNBQVMsaUJBQWlCLE9BQU87QUFDL0IsU0FBTyxXQUFXLEtBQUssS0FBSyxlQUFlO0FBQzdDO0FBRUEsTUFBTSxXQUFXLENBQUMsaUJBQWlCLGlCQUFpQjtBQUNsRCxRQUFNLElBQUksV0FBVyxpQkFBaUIsY0FBYyxxQkFBcUI7QUFDekUsTUFBSSxNQUEyQztBQUM3QyxVQUFNLElBQUksbUJBQW1CO0FBQzdCLFFBQUksS0FBSyxFQUFFLFdBQVcsT0FBTyx1QkFBdUI7QUFDbEQsUUFBRSxpQkFBaUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLEVBQUUsTUFBTSxpQkFBaUIsVUFBVTtBQUMxQyxNQUFJO0FBQ0YscUJBQWlCLEVBQUU7QUFDbkIsVUFBTSxJQUFJLFVBQVU7QUFDcEIsUUFBSSxNQUFNLEdBQUc7QUFDWCxVQUFJLFNBQVMsZUFBZSxLQUFLLENBQUMsUUFBUSxlQUFlLEdBQUc7QUFDMUQsWUFBSSxRQUFRLGVBQWUsR0FBRztBQUM1QixpQkFBTyxZQUFZLE1BQU0sTUFBTSxDQUFDLGVBQWUsQ0FBQztBQUFBLFFBQ2xEO0FBQ0EsZUFBTyxZQUFZLE1BQU0sZUFBZTtBQUFBLE1BQzFDLE9BQU87QUFDTCxlQUFPLFlBQVksTUFBTSxNQUFNLGVBQWU7QUFBQSxNQUNoRDtBQUFBLElBQ0YsT0FBTztBQUNMLFVBQUksSUFBSSxHQUFHO0FBQ1QsbUJBQVcsTUFBTSxVQUFVLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxNQUNwRCxXQUFXLE1BQU0sS0FBSyxRQUFRLFFBQVEsR0FBRztBQUN2QyxtQkFBVyxDQUFDLFFBQVE7QUFBQSxNQUN0QjtBQUNBLGFBQU8sWUFBWSxNQUFNLGlCQUFpQixRQUFRO0FBQUEsSUFDcEQ7QUFBQSxFQUNGLFVBQUU7QUFDQSxxQkFBaUIsQ0FBQztBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLHNCQUFzQjtBQUM3QixNQUFrRCxPQUFPLFdBQVcsYUFBYTtBQUMvRTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFdBQVcsRUFBRSxPQUFPLGdCQUFnQjtBQUMxQyxRQUFNLGNBQWMsRUFBRSxPQUFPLGdCQUFnQjtBQUM3QyxRQUFNLGNBQWMsRUFBRSxPQUFPLGdCQUFnQjtBQUM3QyxRQUFNLGVBQWUsRUFBRSxPQUFPLGdCQUFnQjtBQUM5QyxRQUFNLFlBQVk7QUFBQSxJQUNoQix3QkFBd0I7QUFBQSxJQUN4QixPQUFPLEtBQUs7QUFDVixVQUFJLENBQUMsU0FBUyxHQUFHLEdBQUc7QUFDbEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLElBQUksU0FBUztBQUNmLGVBQU8sQ0FBQyxPQUFPLFVBQVUsYUFBYTtBQUFBLE1BQ3hDLFdBQVcsTUFBTSxHQUFHLEdBQUc7QUFDckIsc0JBQWM7QUFDZCxjQUFNLFFBQVEsSUFBSTtBQUNsQixzQkFBYztBQUNkLGVBQU87QUFBQSxVQUNMO0FBQUEsVUFDQSxDQUFDO0FBQUEsVUFDRCxDQUFDLFFBQVEsVUFBVSxXQUFXLEdBQUcsQ0FBQztBQUFBLFVBQ2xDO0FBQUEsVUFDQSxZQUFZLEtBQUs7QUFBQSxVQUNqQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFdBQVcsV0FBVyxHQUFHLEdBQUc7QUFDMUIsZUFBTztBQUFBLFVBQ0w7QUFBQSxVQUNBLENBQUM7QUFBQSxVQUNELENBQUMsUUFBUSxVQUFVLFVBQVUsR0FBRyxJQUFJLG9CQUFvQixVQUFVO0FBQUEsVUFDbEU7QUFBQSxVQUNBLFlBQVksR0FBRztBQUFBLFVBQ2YsSUFBSSxXQUFXLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRTtBQUFBLFFBQzFDO0FBQUEsTUFDRixXQUFXLFdBQVcsR0FBRyxHQUFHO0FBQzFCLGVBQU87QUFBQSxVQUNMO0FBQUEsVUFDQSxDQUFDO0FBQUEsVUFDRCxDQUFDLFFBQVEsVUFBVSxVQUFVLEdBQUcsSUFBSSxvQkFBb0IsVUFBVTtBQUFBLFVBQ2xFO0FBQUEsVUFDQSxZQUFZLEdBQUc7QUFBQSxVQUNmO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsUUFBUSxLQUFLO0FBQ1gsYUFBTyxPQUFPLElBQUk7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSyxLQUFLO0FBQ1IsVUFBSSxPQUFPLElBQUksU0FBUztBQUN0QixlQUFPO0FBQUEsVUFDTDtBQUFBLFVBQ0EsQ0FBQztBQUFBLFVBQ0QsR0FBRyxlQUFlLElBQUksQ0FBQztBQUFBLFFBQ3pCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsV0FBUyxlQUFlLFVBQVU7QUFDaEMsVUFBTSxTQUFTLENBQUM7QUFDaEIsUUFBSSxTQUFTLEtBQUssU0FBUyxTQUFTLE9BQU87QUFDekMsYUFBTyxLQUFLLG9CQUFvQixTQUFTLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLElBQ2pFO0FBQ0EsUUFBSSxTQUFTLGVBQWUsV0FBVztBQUNyQyxhQUFPLEtBQUssb0JBQW9CLFNBQVMsU0FBUyxVQUFVLENBQUM7QUFBQSxJQUMvRDtBQUNBLFFBQUksU0FBUyxTQUFTLFdBQVc7QUFDL0IsYUFBTyxLQUFLLG9CQUFvQixRQUFRLE1BQU0sU0FBUyxJQUFJLENBQUMsQ0FBQztBQUFBLElBQy9EO0FBQ0EsVUFBTVMsWUFBVyxZQUFZLFVBQVUsVUFBVTtBQUNqRCxRQUFJQSxXQUFVO0FBQ1osYUFBTyxLQUFLLG9CQUFvQixZQUFZQSxTQUFRLENBQUM7QUFBQSxJQUN2RDtBQUNBLFVBQU0sV0FBVyxZQUFZLFVBQVUsUUFBUTtBQUMvQyxRQUFJLFVBQVU7QUFDWixhQUFPLEtBQUssb0JBQW9CLFlBQVksUUFBUSxDQUFDO0FBQUEsSUFDdkQ7QUFDQSxXQUFPLEtBQUs7QUFBQSxNQUNWO0FBQUEsTUFDQSxDQUFDO0FBQUEsTUFDRDtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsVUFDRSxPQUFPLGFBQWEsUUFBUTtBQUFBLFFBQzlCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxNQUNBLENBQUMsVUFBVSxFQUFFLFFBQVEsU0FBUyxDQUFDO0FBQUEsSUFDakMsQ0FBQztBQUNELFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxvQkFBb0IsTUFBTSxRQUFRO0FBQ3pDLGFBQVMsT0FBTyxDQUFDLEdBQUcsTUFBTTtBQUMxQixRQUFJLENBQUMsT0FBTyxLQUFLLE1BQU0sRUFBRSxRQUFRO0FBQy9CLGFBQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUFBLElBQ3BCO0FBQ0EsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBLEVBQUUsT0FBTyx5Q0FBeUM7QUFBQSxNQUNsRDtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsTUFDQTtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLFFBQ0EsR0FBRyxPQUFPLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQyxRQUFRO0FBQ2xDLGlCQUFPO0FBQUEsWUFDTDtBQUFBLFlBQ0EsQ0FBQztBQUFBLFlBQ0QsQ0FBQyxRQUFRLGNBQWMsTUFBTSxJQUFJO0FBQUEsWUFDakMsWUFBWSxPQUFPLEdBQUcsR0FBRyxLQUFLO0FBQUEsVUFDaEM7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxXQUFTLFlBQVksR0FBRyxRQUFRLE1BQU07QUFDcEMsUUFBSSxPQUFPLE1BQU0sVUFBVTtBQUN6QixhQUFPLENBQUMsUUFBUSxhQUFhLENBQUM7QUFBQSxJQUNoQyxXQUFXLE9BQU8sTUFBTSxVQUFVO0FBQ2hDLGFBQU8sQ0FBQyxRQUFRLGFBQWEsS0FBSyxVQUFVLENBQUMsQ0FBQztBQUFBLElBQ2hELFdBQVcsT0FBTyxNQUFNLFdBQVc7QUFDakMsYUFBTyxDQUFDLFFBQVEsY0FBYyxDQUFDO0FBQUEsSUFDakMsV0FBVyxTQUFTLENBQUMsR0FBRztBQUN0QixhQUFPLENBQUMsVUFBVSxFQUFFLFFBQVEsUUFBUSxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7QUFBQSxJQUNwRCxPQUFPO0FBQ0wsYUFBTyxDQUFDLFFBQVEsYUFBYSxPQUFPLENBQUMsQ0FBQztBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLFdBQVMsWUFBWSxVQUFVLE1BQU07QUFDbkMsVUFBTSxPQUFPLFNBQVM7QUFDdEIsUUFBSSxXQUFXLElBQUksR0FBRztBQUNwQjtBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksQ0FBQztBQUNuQixlQUFXLE9BQU8sU0FBUyxLQUFLO0FBQzlCLFVBQUksWUFBWSxNQUFNLEtBQUssSUFBSSxHQUFHO0FBQ2hDLGtCQUFVLEdBQUcsSUFBSSxTQUFTLElBQUksR0FBRztBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxZQUFZLE1BQU0sS0FBSyxNQUFNO0FBQ3BDLFVBQU0sT0FBTyxLQUFLLElBQUk7QUFDdEIsUUFBSSxRQUFRLElBQUksS0FBSyxLQUFLLFNBQVMsR0FBRyxLQUFLLFNBQVMsSUFBSSxLQUFLLE9BQU8sTUFBTTtBQUN4RSxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksS0FBSyxXQUFXLFlBQVksS0FBSyxTQUFTLEtBQUssSUFBSSxHQUFHO0FBQ3hELGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxLQUFLLFVBQVUsS0FBSyxPQUFPLEtBQUssQ0FBQyxNQUFNLFlBQVksR0FBRyxLQUFLLElBQUksQ0FBQyxHQUFHO0FBQ3JFLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFdBQVMsV0FBVyxHQUFHO0FBQ3JCLFFBQUksVUFBVSxDQUFDLEdBQUc7QUFDaEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLEVBQUUsUUFBUTtBQUNaLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLE9BQU8sb0JBQW9CO0FBQzdCLFdBQU8sbUJBQW1CLEtBQUssU0FBUztBQUFBLEVBQzFDLE9BQU87QUFDTCxXQUFPLHFCQUFxQixDQUFDLFNBQVM7QUFBQSxFQUN4QztBQUNGO0FBRUEsU0FBUyxTQUFTLE1BQU0sUUFBUSxPQUFPLE9BQU87QUFDNUMsUUFBTSxTQUFTLE1BQU0sS0FBSztBQUMxQixNQUFJLFVBQVUsV0FBVyxRQUFRLElBQUksR0FBRztBQUN0QyxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sTUFBTSxPQUFPO0FBQ25CLE1BQUksT0FBTyxLQUFLLE1BQU07QUFDdEIsTUFBSSxhQUFhO0FBQ2pCLFNBQU8sTUFBTSxLQUFLLElBQUk7QUFDeEI7QUFDQSxTQUFTLFdBQVcsUUFBUSxNQUFNO0FBQ2hDLFFBQU0sT0FBTyxPQUFPO0FBQ3BCLE1BQUksS0FBSyxVQUFVLEtBQUssUUFBUTtBQUM5QixXQUFPO0FBQUEsRUFDVDtBQUNBLFdBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7QUFDcEMsUUFBSSxXQUFXLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLEdBQUc7QUFDaEMsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxxQkFBcUIsS0FBSyxjQUFjO0FBQzFDLGlCQUFhLEtBQUssTUFBTTtBQUFBLEVBQzFCO0FBQ0EsU0FBTztBQUNUO0FBRUEsTUFBTSxVQUFVO0FBQ2hCLE1BQU0sT0FBTyxPQUE0QyxTQUFTO0FBQ2xFLE1BQU0sbUJBQW1CO0FBQ3pCLE1BQU0sV0FBVyxPQUFvRCxhQUFhO0FBQ2xGLE1BQU0sa0JBQWtCLE9BQW9ELG9CQUFvQjtBQUNoRyxNQUFNLFlBQVk7QUFBQSxFQUNoQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGO0FBQ0EsTUFBTSxXQUFXO0FBQ2pCLE1BQU0sZ0JBQWdCO0FBQ3RCLE1BQU0sY0FBYztBQUNwQixNQUFNLG1CQUFtQjtBQUV6QixTQUFTLGdCQUFnQiwrQkFBK0IsU0FBUyxrQkFBa0IsWUFBWSxrQkFBa0IsVUFBVSxXQUFXLFFBQVEsVUFBVSxVQUFVLE1BQU0sY0FBYyw0QkFBNEIsdUJBQXVCLFlBQVksYUFBYSxVQUFVLGFBQWEsb0JBQW9CLG9CQUFvQixtQkFBbUIsb0JBQW9CLHlCQUF5QixzQkFBc0IsZ0JBQWdCLGFBQWEsbUJBQW1CLGlCQUFpQixhQUFhLHNCQUFzQixpQkFBaUIsYUFBYSxjQUFjLGFBQWEsZUFBZSxhQUFhLGFBQWEsVUFBVSxvQkFBb0IsMEJBQTBCLG9CQUFvQixHQUFHLGFBQWEscUJBQXFCLGVBQWUsc0JBQXNCLHFCQUFxQixrQkFBa0IscUJBQXFCLFFBQVEsWUFBWSxlQUFlLFNBQVMsZUFBZSxhQUFhLFlBQVksVUFBVSxhQUFhLGVBQWUsaUJBQWlCLGdCQUFnQixlQUFlLGlCQUFpQixXQUFXLGlCQUFpQixtQkFBbUIsa0JBQWtCLGFBQWEsV0FBVyxXQUFXLFlBQVksU0FBUyxhQUFhLGtCQUFrQix5QkFBeUIsWUFBWSxZQUFZLGtCQUFrQixrQkFBa0IseUJBQXlCLGVBQWUsd0JBQXdCLGtCQUFrQixpQkFBaUIsb0JBQW9CLGVBQWUsVUFBVSxZQUFZLG9CQUFvQixVQUFVLE9BQU8sVUFBVSxlQUFlLFVBQVUsZ0JBQWdCLG9CQUFvQixTQUFTLE1BQU0sT0FBTyxhQUFhLGlCQUFpQixpQkFBaUIsa0JBQWtCLFNBQVMsY0FBYyxnQkFBZ0IsVUFBVTsiLCJuYW1lcyI6WyJ2ZXJzaW9uIiwiZWZmZWN0IiwiY2FsbEhvb2siLCJyZW1vdmUiLCJyZWYiLCJyZWYyIiwicmVzb2x2ZSIsImgiLCJ0cmFjayIsInRyaWdnZXIiLCJpc01vZGVsTGlzdGVuZXIiLCJlbWl0IiwicmVtb3ZlMiIsImNvbXB1dGVkIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=