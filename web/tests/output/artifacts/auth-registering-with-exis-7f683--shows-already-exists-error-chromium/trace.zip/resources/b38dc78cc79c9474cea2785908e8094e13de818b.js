import { basename, camelize, classify, deepClone, isBrowser, isNuxtApp, isUrlString, kebabize, target } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@vue+devtools-shared@8.1.3/node_modules/@vue/devtools-shared/dist/index.js?v=583078ff";
import { debounce } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/perfect-debounce@2.1.0/node_modules/perfect-debounce/dist/index.mjs?v=583078ff";
import { createHooks } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/hookable@5.5.3/node_modules/hookable/dist/index.mjs?v=583078ff";
import { createBirpc, createBirpcGroup } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/birpc@2.9.0/node_modules/birpc/dist/index.mjs?v=583078ff";
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region src/compat/index.ts
function onLegacyDevToolsPluginApiAvailable(cb) {
	if (target.__VUE_DEVTOOLS_PLUGIN_API_AVAILABLE__) {
		cb();
		return;
	}
	Object.defineProperty(target, "__VUE_DEVTOOLS_PLUGIN_API_AVAILABLE__", {
		set(value) {
			if (value) cb();
		},
		configurable: true
	});
}
//#endregion
//#region src/core/component/utils/index.ts
function getComponentTypeName(options) {
	if (typeof options === "function") return options.displayName || options.name || options.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ || "";
	const name = options.name || options._componentTag || options.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ || options.__name;
	if (name === "index" && options.__file?.endsWith("index.vue")) return "";
	return name;
}
function getComponentFileName(options) {
	const file = options.__file;
	if (file) return classify(basename(file, ".vue"));
}
function getComponentName(options) {
	const name = options.displayName || options.name || options._componentTag;
	if (name) return name;
	return getComponentFileName(options);
}
function saveComponentGussedName(instance, name) {
	instance.type.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ = name;
	return name;
}
function getAppRecord(instance) {
	if (instance.__VUE_DEVTOOLS_NEXT_APP_RECORD__) return instance.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
	else if (instance.root) return instance.appContext.app.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
}
async function getComponentId(options) {
	const { app, uid, instance } = options;
	try {
		if (instance.__VUE_DEVTOOLS_NEXT_UID__) return instance.__VUE_DEVTOOLS_NEXT_UID__;
		const appRecord = await getAppRecord(app);
		if (!appRecord) return null;
		const isRoot = appRecord.rootInstance === instance;
		return `${appRecord.id}:${isRoot ? "root" : uid}`;
	} catch (e) {}
}
function isFragment(instance) {
	const subTreeType = instance.subTree?.type;
	const appRecord = getAppRecord(instance);
	if (appRecord) return appRecord?.types?.Fragment === subTreeType;
	return false;
}
function isBeingDestroyed(instance) {
	return instance._isBeingDestroyed || instance.isUnmounted;
}
/**
* Get the appropriate display name for an instance.
*
* @param {Vue} instance
* @return {string}
*/
function getInstanceName(instance) {
	const name = getComponentTypeName(instance?.type || {});
	if (name) return name;
	if (instance?.root === instance) return "Root";
	for (const key in instance.parent?.type?.components) if (instance.parent.type.components[key] === instance?.type) return saveComponentGussedName(instance, key);
	for (const key in instance.appContext?.components) if (instance.appContext.components[key] === instance?.type) return saveComponentGussedName(instance, key);
	const fileName = getComponentFileName(instance?.type || {});
	if (fileName) return fileName;
	return "Anonymous Component";
}
/**
* Returns a devtools unique id for instance.
* @param {Vue} instance
*/
function getUniqueComponentId(instance) {
	return `${instance?.appContext?.app?.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__ ?? 0}:${instance === instance?.root ? "root" : instance.uid}`;
}
function getRenderKey(value) {
	if (value == null) return "";
	if (typeof value === "number") return value;
	else if (typeof value === "string") return `'${value}'`;
	else if (Array.isArray(value)) return "Array";
	else return "Object";
}
function returnError(cb) {
	try {
		return cb();
	} catch (e) {
		return e;
	}
}
function getComponentInstance(appRecord, instanceId) {
	instanceId = instanceId || `${appRecord.id}:root`;
	return appRecord.instanceMap.get(instanceId) || appRecord.instanceMap.get(":root");
}
function ensurePropertyExists(obj, key, skipObjCheck = false) {
	return skipObjCheck ? key in obj : typeof obj === "object" && obj !== null ? key in obj : false;
}
//#endregion
//#region src/core/component/state/bounding-rect.ts
function createRect() {
	const rect = {
		top: 0,
		bottom: 0,
		left: 0,
		right: 0,
		get width() {
			return rect.right - rect.left;
		},
		get height() {
			return rect.bottom - rect.top;
		}
	};
	return rect;
}
let range;
function getTextRect(node) {
	if (!range) range = document.createRange();
	range.selectNode(node);
	return range.getBoundingClientRect();
}
function getFragmentRect(vnode) {
	const rect = createRect();
	if (!vnode.children) return rect;
	for (let i = 0, l = vnode.children.length; i < l; i++) {
		const childVnode = vnode.children[i];
		let childRect;
		if (childVnode.component) childRect = getComponentBoundingRect(childVnode.component);
		else if (childVnode.el) {
			const el = childVnode.el;
			if (el.nodeType === 1 || el.getBoundingClientRect) childRect = el.getBoundingClientRect();
			else if (el.nodeType === 3 && el.data.trim()) childRect = getTextRect(el);
		}
		if (childRect) mergeRects(rect, childRect);
	}
	return rect;
}
function mergeRects(a, b) {
	if (!a.top || b.top < a.top) a.top = b.top;
	if (!a.bottom || b.bottom > a.bottom) a.bottom = b.bottom;
	if (!a.left || b.left < a.left) a.left = b.left;
	if (!a.right || b.right > a.right) a.right = b.right;
	return a;
}
const DEFAULT_RECT = {
	top: 0,
	left: 0,
	right: 0,
	bottom: 0,
	width: 0,
	height: 0
};
function getComponentBoundingRect(instance) {
	const el = instance.subTree.el;
	if (typeof window === "undefined") return DEFAULT_RECT;
	if (isFragment(instance)) return getFragmentRect(instance.subTree);
	else if (el?.nodeType === 1) return el?.getBoundingClientRect();
	else if (instance.subTree.component) return getComponentBoundingRect(instance.subTree.component);
	else return DEFAULT_RECT;
}
//#endregion
//#region src/core/component/tree/el.ts
function getRootElementsFromComponentInstance(instance) {
	if (isFragment(instance)) return getFragmentRootElements(instance.subTree);
	if (!instance.subTree) return [];
	return [instance.subTree.el];
}
function getFragmentRootElements(vnode) {
	if (!vnode.children) return [];
	const list = [];
	vnode.children.forEach((childVnode) => {
		if (childVnode.component) list.push(...getRootElementsFromComponentInstance(childVnode.component));
		else if (childVnode?.el) list.push(childVnode.el);
	});
	return list;
}
//#endregion
//#region src/core/component-highlighter/index.ts
const CONTAINER_ELEMENT_ID = "__vue-devtools-component-inspector__";
const CARD_ELEMENT_ID = "__vue-devtools-component-inspector__card__";
const COMPONENT_NAME_ELEMENT_ID = "__vue-devtools-component-inspector__name__";
const INDICATOR_ELEMENT_ID = "__vue-devtools-component-inspector__indicator__";
const containerStyles = {
	display: "block",
	zIndex: 2147483640,
	position: "fixed",
	backgroundColor: "#42b88325",
	border: "1px solid #42b88350",
	borderRadius: "5px",
	transition: "all 0.1s ease-in",
	pointerEvents: "none"
};
const cardStyles = {
	fontFamily: "Arial, Helvetica, sans-serif",
	padding: "5px 8px",
	borderRadius: "4px",
	textAlign: "left",
	position: "absolute",
	left: 0,
	color: "#e9e9e9",
	fontSize: "14px",
	fontWeight: 600,
	lineHeight: "24px",
	backgroundColor: "#42b883",
	boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1)"
};
const indicatorStyles = {
	display: "inline-block",
	fontWeight: 400,
	fontStyle: "normal",
	fontSize: "12px",
	opacity: .7
};
function getContainerElement() {
	return document.getElementById(CONTAINER_ELEMENT_ID);
}
function getCardElement() {
	return document.getElementById(CARD_ELEMENT_ID);
}
function getIndicatorElement() {
	return document.getElementById(INDICATOR_ELEMENT_ID);
}
function getNameElement() {
	return document.getElementById(COMPONENT_NAME_ELEMENT_ID);
}
function getStyles(bounds) {
	return {
		left: `${Math.round(bounds.left * 100) / 100}px`,
		top: `${Math.round(bounds.top * 100) / 100}px`,
		width: `${Math.round(bounds.width * 100) / 100}px`,
		height: `${Math.round(bounds.height * 100) / 100}px`
	};
}
function create(options) {
	const containerEl = document.createElement("div");
	containerEl.id = options.elementId ?? CONTAINER_ELEMENT_ID;
	Object.assign(containerEl.style, {
		...containerStyles,
		...getStyles(options.bounds),
		...options.style
	});
	const cardEl = document.createElement("span");
	cardEl.id = CARD_ELEMENT_ID;
	Object.assign(cardEl.style, {
		...cardStyles,
		top: options.bounds.top < 35 ? 0 : "-35px"
	});
	const nameEl = document.createElement("span");
	nameEl.id = COMPONENT_NAME_ELEMENT_ID;
	nameEl.innerHTML = `&lt;${options.name}&gt;&nbsp;&nbsp;`;
	const indicatorEl = document.createElement("i");
	indicatorEl.id = INDICATOR_ELEMENT_ID;
	indicatorEl.innerHTML = `${Math.round(options.bounds.width * 100) / 100} x ${Math.round(options.bounds.height * 100) / 100}`;
	Object.assign(indicatorEl.style, indicatorStyles);
	cardEl.appendChild(nameEl);
	cardEl.appendChild(indicatorEl);
	containerEl.appendChild(cardEl);
	document.body.appendChild(containerEl);
	return containerEl;
}
function update(options) {
	const containerEl = getContainerElement();
	const cardEl = getCardElement();
	const nameEl = getNameElement();
	const indicatorEl = getIndicatorElement();
	if (containerEl) {
		Object.assign(containerEl.style, {
			...containerStyles,
			...getStyles(options.bounds)
		});
		Object.assign(cardEl.style, { top: options.bounds.top < 35 ? 0 : "-35px" });
		nameEl.innerHTML = `&lt;${options.name}&gt;&nbsp;&nbsp;`;
		indicatorEl.innerHTML = `${Math.round(options.bounds.width * 100) / 100} x ${Math.round(options.bounds.height * 100) / 100}`;
	}
}
function highlight(instance) {
	const bounds = getComponentBoundingRect(instance);
	if (!bounds.width && !bounds.height) return;
	const name = getInstanceName(instance);
	getContainerElement() ? update({
		bounds,
		name
	}) : create({
		bounds,
		name
	});
}
function unhighlight() {
	const el = getContainerElement();
	if (el) el.style.display = "none";
}
let inspectInstance = null;
function inspectFn(e) {
	const target = e.target;
	if (target) {
		const instance = target.__vueParentComponent;
		if (instance) {
			inspectInstance = instance;
			if (instance.vnode.el) {
				const bounds = getComponentBoundingRect(instance);
				const name = getInstanceName(instance);
				getContainerElement() ? update({
					bounds,
					name
				}) : create({
					bounds,
					name
				});
			}
		}
	}
}
function selectComponentFn(e, cb) {
	e.preventDefault();
	e.stopPropagation();
	if (inspectInstance) cb(getUniqueComponentId(inspectInstance));
}
let inspectComponentHighLighterSelectFn = null;
function cancelInspectComponentHighLighter() {
	unhighlight();
	window.removeEventListener("mouseover", inspectFn);
	window.removeEventListener("click", inspectComponentHighLighterSelectFn, true);
	inspectComponentHighLighterSelectFn = null;
}
function inspectComponentHighLighter() {
	window.addEventListener("mouseover", inspectFn);
	return new Promise((resolve) => {
		function onSelect(e) {
			e.preventDefault();
			e.stopPropagation();
			selectComponentFn(e, (id) => {
				window.removeEventListener("click", onSelect, true);
				inspectComponentHighLighterSelectFn = null;
				window.removeEventListener("mouseover", inspectFn);
				const el = getContainerElement();
				if (el) el.style.display = "none";
				resolve(JSON.stringify({ id }));
			});
		}
		inspectComponentHighLighterSelectFn = onSelect;
		window.addEventListener("click", onSelect, true);
	});
}
function scrollToComponent(options) {
	const instance = getComponentInstance(activeAppRecord.value, options.id);
	if (instance) {
		const [el] = getRootElementsFromComponentInstance(instance);
		if (typeof el.scrollIntoView === "function") el.scrollIntoView({ behavior: "smooth" });
		else {
			const bounds = getComponentBoundingRect(instance);
			const scrollTarget = document.createElement("div");
			const styles = {
				...getStyles(bounds),
				position: "absolute"
			};
			Object.assign(scrollTarget.style, styles);
			document.body.appendChild(scrollTarget);
			scrollTarget.scrollIntoView({ behavior: "smooth" });
			setTimeout(() => {
				document.body.removeChild(scrollTarget);
			}, 2e3);
		}
		setTimeout(() => {
			const bounds = getComponentBoundingRect(instance);
			if (bounds.width || bounds.height) {
				const name = getInstanceName(instance);
				const el = getContainerElement();
				el ? update({
					...options,
					name,
					bounds
				}) : create({
					...options,
					name,
					bounds
				});
				setTimeout(() => {
					if (el) el.style.display = "none";
				}, 1500);
			}
		}, 1200);
	}
}
//#endregion
//#region src/core/component-inspector/index.ts
target.__VUE_DEVTOOLS_COMPONENT_INSPECTOR_ENABLED__ ??= true;
function toggleComponentInspectorEnabled(enabled) {
	target.__VUE_DEVTOOLS_COMPONENT_INSPECTOR_ENABLED__ = enabled;
}
function waitForInspectorInit(cb) {
	let total = 0;
	const timer = setInterval(() => {
		if (target.__VUE_INSPECTOR__) {
			clearInterval(timer);
			total += 30;
			cb();
		}
		if (total >= 5e3) clearInterval(timer);
	}, 30);
}
function setupInspector() {
	const inspector = target.__VUE_INSPECTOR__;
	const _openInEditor = inspector.openInEditor;
	inspector.openInEditor = async (...params) => {
		inspector.disable();
		_openInEditor(...params);
	};
}
function getComponentInspector() {
	return new Promise((resolve) => {
		function setup() {
			setupInspector();
			resolve(target.__VUE_INSPECTOR__);
		}
		if (!target.__VUE_INSPECTOR__) waitForInspectorInit(() => {
			setup();
		});
		else setup();
	});
}
//#endregion
//#region src/shared/stub-vue.ts
/**
* To prevent include a **HUGE** vue package in the final bundle of chrome ext / electron
* we stub the necessary vue module.
* This implementation is based on the 1c3327a0fa5983aa9078e3f7bb2330f572435425 commit
*/
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/constants.ts#L17-L23)
*/
let ReactiveFlags = /* @__PURE__ */ function(ReactiveFlags) {
	ReactiveFlags["SKIP"] = "__v_skip";
	ReactiveFlags["IS_REACTIVE"] = "__v_isReactive";
	ReactiveFlags["IS_READONLY"] = "__v_isReadonly";
	ReactiveFlags["IS_SHALLOW"] = "__v_isShallow";
	ReactiveFlags["RAW"] = "__v_raw";
	return ReactiveFlags;
}({});
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L330-L332)
*/
function isReadonly(value) {
	return !!(value && value[ReactiveFlags.IS_READONLY]);
}
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L312-L317)
*/
function isReactive$1(value) {
	if (isReadonly(value)) return isReactive$1(value[ReactiveFlags.RAW]);
	return !!(value && value[ReactiveFlags.IS_REACTIVE]);
}
function isRef$1(r) {
	return !!(r && r.__v_isRef === true);
}
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L372-L375)
*/
function toRaw$1(observed) {
	const raw = observed && observed[ReactiveFlags.RAW];
	return raw ? toRaw$1(raw) : observed;
}
//#endregion
//#region src/core/component/state/editor.ts
var StateEditor = class {
	constructor() {
		this.refEditor = new RefStateEditor();
	}
	set(object, path, value, cb) {
		const sections = Array.isArray(path) ? path : path.split(".");
		while (sections.length > 1) {
			const section = sections.shift();
			if (object instanceof Map) object = object.get(section);
			else if (object instanceof Set) object = Array.from(object.values())[section];
			else object = object[section];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
		}
		const field = sections[0];
		const item = this.refEditor.get(object)[field];
		if (cb) cb(object, field, value);
		else if (this.refEditor.isRef(item)) this.refEditor.set(item, value);
		else object[field] = value;
	}
	get(object, path) {
		const sections = Array.isArray(path) ? path : path.split(".");
		for (let i = 0; i < sections.length; i++) {
			if (object instanceof Map) object = object.get(sections[i]);
			else object = object[sections[i]];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
			if (!object) return void 0;
		}
		return object;
	}
	has(object, path, parent = false) {
		if (typeof object === "undefined") return false;
		const sections = Array.isArray(path) ? path.slice() : path.split(".");
		const size = !parent ? 1 : 2;
		while (object && sections.length > size) {
			const section = sections.shift();
			object = object[section];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
		}
		return object != null && Object.prototype.hasOwnProperty.call(object, sections[0]);
	}
	createDefaultSetCallback(state) {
		return (object, field, value) => {
			if (state.remove || state.newKey) if (Array.isArray(object)) object.splice(field, 1);
			else if (toRaw$1(object) instanceof Map) object.delete(field);
			else if (toRaw$1(object) instanceof Set) object.delete(Array.from(object.values())[field]);
			else Reflect.deleteProperty(object, field);
			if (!state.remove) {
				const target = object[state.newKey || field];
				if (this.refEditor.isRef(target)) this.refEditor.set(target, value);
				else if (toRaw$1(object) instanceof Map) object.set(state.newKey || field, value);
				else if (toRaw$1(object) instanceof Set) object.add(value);
				else object[state.newKey || field] = value;
			}
		};
	}
};
var RefStateEditor = class {
	set(ref, value) {
		if (isRef$1(ref)) ref.value = value;
		else {
			if (ref instanceof Set && Array.isArray(value)) {
				ref.clear();
				value.forEach((v) => ref.add(v));
				return;
			}
			const currentKeys = Object.keys(value);
			if (ref instanceof Map) {
				const previousKeysSet = new Set(ref.keys());
				currentKeys.forEach((key) => {
					ref.set(key, Reflect.get(value, key));
					previousKeysSet.delete(key);
				});
				previousKeysSet.forEach((key) => ref.delete(key));
				return;
			}
			const previousKeysSet = new Set(Object.keys(ref));
			currentKeys.forEach((key) => {
				Reflect.set(ref, key, Reflect.get(value, key));
				previousKeysSet.delete(key);
			});
			previousKeysSet.forEach((key) => Reflect.deleteProperty(ref, key));
		}
	}
	get(ref) {
		return isRef$1(ref) ? ref.value : ref;
	}
	isRef(ref) {
		return isRef$1(ref) || isReactive$1(ref);
	}
};
async function editComponentState(payload, stateEditor) {
	const { path, nodeId, state, type } = payload;
	const instance = getComponentInstance(activeAppRecord.value, nodeId);
	if (!instance) return;
	const targetPath = path.slice();
	let target;
	if (Object.keys(instance.props).includes(path[0])) target = instance.props;
	else if (instance.devtoolsRawSetupState && Object.keys(instance.devtoolsRawSetupState).includes(path[0])) target = instance.devtoolsRawSetupState;
	else if (instance.data && Object.keys(instance.data).includes(path[0])) target = instance.data;
	else target = instance.proxy;
	if (target && targetPath) {
		if (state.type === "object" && type === "reactive") {}
		stateEditor.set(target, targetPath, state.value, stateEditor.createDefaultSetCallback(state));
	}
}
const stateEditor = new StateEditor();
async function editState(payload) {
	editComponentState(payload, stateEditor);
}
//#endregion
//#region src/core/timeline/storage.ts
const TIMELINE_LAYERS_STATE_STORAGE_ID = "__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS_STATE__";
function addTimelineLayersStateToStorage(state) {
	if (!isBrowser || typeof localStorage === "undefined" || localStorage === null) return;
	localStorage.setItem(TIMELINE_LAYERS_STATE_STORAGE_ID, JSON.stringify(state));
}
function getTimelineLayersStateFromStorage() {
	if (typeof window === "undefined" || !isBrowser || typeof localStorage === "undefined" || localStorage === null) return {
		recordingState: false,
		mouseEventEnabled: false,
		keyboardEventEnabled: false,
		componentEventEnabled: false,
		performanceEventEnabled: false,
		selected: ""
	};
	const state = typeof localStorage.getItem !== "undefined" ? localStorage.getItem(TIMELINE_LAYERS_STATE_STORAGE_ID) : null;
	return state ? JSON.parse(state) : {
		recordingState: false,
		mouseEventEnabled: false,
		keyboardEventEnabled: false,
		componentEventEnabled: false,
		performanceEventEnabled: false,
		selected: ""
	};
}
//#endregion
//#region src/ctx/timeline.ts
target.__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS ??= [];
const devtoolsTimelineLayers = new Proxy(target.__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
function addTimelineLayer(options, descriptor) {
	devtoolsState.timelineLayersState[descriptor.id] = false;
	devtoolsTimelineLayers.push({
		...options,
		descriptorId: descriptor.id,
		appRecord: getAppRecord(descriptor.app)
	});
}
function updateTimelineLayersState(state) {
	const updatedState = {
		...devtoolsState.timelineLayersState,
		...state
	};
	addTimelineLayersStateToStorage(updatedState);
	updateDevToolsState({ timelineLayersState: updatedState });
}
//#endregion
//#region src/ctx/inspector.ts
target.__VUE_DEVTOOLS_KIT_INSPECTOR__ ??= [];
const devtoolsInspector = new Proxy(target.__VUE_DEVTOOLS_KIT_INSPECTOR__, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
const callInspectorUpdatedHook = debounce(() => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.SEND_INSPECTOR_TO_CLIENT, getActiveInspectors());
});
function addInspector(inspector, descriptor) {
	devtoolsInspector.push({
		options: inspector,
		descriptor,
		treeFilterPlaceholder: inspector.treeFilterPlaceholder ?? "Search tree...",
		stateFilterPlaceholder: inspector.stateFilterPlaceholder ?? "Search state...",
		treeFilter: "",
		selectedNodeId: "",
		appRecord: getAppRecord(descriptor.app)
	});
	callInspectorUpdatedHook();
}
function getActiveInspectors() {
	return devtoolsInspector.filter((inspector) => inspector.descriptor.app === activeAppRecord.value.app).filter((inspector) => inspector.descriptor.id !== "components").map((inspector) => {
		const descriptor = inspector.descriptor;
		const options = inspector.options;
		return {
			id: options.id,
			label: options.label,
			logo: descriptor.logo,
			icon: `custom-ic-baseline-${options?.icon?.replace(/_/g, "-")}`,
			packageName: descriptor.packageName,
			homepage: descriptor.homepage,
			pluginId: descriptor.id
		};
	});
}
function getInspectorInfo(id) {
	const inspector = getInspector(id, activeAppRecord.value.app);
	if (!inspector) return;
	const descriptor = inspector.descriptor;
	const options = inspector.options;
	const timelineLayers = devtoolsTimelineLayers.filter((layer) => layer.descriptorId === descriptor.id).map((item) => ({
		id: item.id,
		label: item.label,
		color: item.color
	}));
	return {
		id: options.id,
		label: options.label,
		logo: descriptor.logo,
		packageName: descriptor.packageName,
		homepage: descriptor.homepage,
		timelineLayers,
		treeFilterPlaceholder: inspector.treeFilterPlaceholder,
		stateFilterPlaceholder: inspector.stateFilterPlaceholder
	};
}
function getInspector(id, app) {
	return devtoolsInspector.find((inspector) => inspector.options.id === id && (app ? inspector.descriptor.app === app : true));
}
function getInspectorActions(id) {
	return getInspector(id)?.options.actions;
}
function getInspectorNodeActions(id) {
	return getInspector(id)?.options.nodeActions;
}
//#endregion
//#region src/ctx/hook.ts
let DevToolsV6PluginAPIHookKeys = /* @__PURE__ */ function(DevToolsV6PluginAPIHookKeys) {
	DevToolsV6PluginAPIHookKeys["VISIT_COMPONENT_TREE"] = "visitComponentTree";
	DevToolsV6PluginAPIHookKeys["INSPECT_COMPONENT"] = "inspectComponent";
	DevToolsV6PluginAPIHookKeys["EDIT_COMPONENT_STATE"] = "editComponentState";
	DevToolsV6PluginAPIHookKeys["GET_INSPECTOR_TREE"] = "getInspectorTree";
	DevToolsV6PluginAPIHookKeys["GET_INSPECTOR_STATE"] = "getInspectorState";
	DevToolsV6PluginAPIHookKeys["EDIT_INSPECTOR_STATE"] = "editInspectorState";
	DevToolsV6PluginAPIHookKeys["INSPECT_TIMELINE_EVENT"] = "inspectTimelineEvent";
	DevToolsV6PluginAPIHookKeys["TIMELINE_CLEARED"] = "timelineCleared";
	DevToolsV6PluginAPIHookKeys["SET_PLUGIN_SETTINGS"] = "setPluginSettings";
	return DevToolsV6PluginAPIHookKeys;
}({});
let DevToolsContextHookKeys = /* @__PURE__ */ function(DevToolsContextHookKeys) {
	DevToolsContextHookKeys["ADD_INSPECTOR"] = "addInspector";
	DevToolsContextHookKeys["SEND_INSPECTOR_TREE"] = "sendInspectorTree";
	DevToolsContextHookKeys["SEND_INSPECTOR_STATE"] = "sendInspectorState";
	DevToolsContextHookKeys["CUSTOM_INSPECTOR_SELECT_NODE"] = "customInspectorSelectNode";
	DevToolsContextHookKeys["TIMELINE_LAYER_ADDED"] = "timelineLayerAdded";
	DevToolsContextHookKeys["TIMELINE_EVENT_ADDED"] = "timelineEventAdded";
	DevToolsContextHookKeys["GET_COMPONENT_INSTANCES"] = "getComponentInstances";
	DevToolsContextHookKeys["GET_COMPONENT_BOUNDS"] = "getComponentBounds";
	DevToolsContextHookKeys["GET_COMPONENT_NAME"] = "getComponentName";
	DevToolsContextHookKeys["COMPONENT_HIGHLIGHT"] = "componentHighlight";
	DevToolsContextHookKeys["COMPONENT_UNHIGHLIGHT"] = "componentUnhighlight";
	return DevToolsContextHookKeys;
}({});
let DevToolsMessagingHookKeys = /* @__PURE__ */ function(DevToolsMessagingHookKeys) {
	DevToolsMessagingHookKeys["SEND_INSPECTOR_TREE_TO_CLIENT"] = "sendInspectorTreeToClient";
	DevToolsMessagingHookKeys["SEND_INSPECTOR_STATE_TO_CLIENT"] = "sendInspectorStateToClient";
	DevToolsMessagingHookKeys["SEND_TIMELINE_EVENT_TO_CLIENT"] = "sendTimelineEventToClient";
	DevToolsMessagingHookKeys["SEND_INSPECTOR_TO_CLIENT"] = "sendInspectorToClient";
	DevToolsMessagingHookKeys["SEND_ACTIVE_APP_UNMOUNTED_TO_CLIENT"] = "sendActiveAppUpdatedToClient";
	DevToolsMessagingHookKeys["DEVTOOLS_STATE_UPDATED"] = "devtoolsStateUpdated";
	DevToolsMessagingHookKeys["DEVTOOLS_CONNECTED_UPDATED"] = "devtoolsConnectedUpdated";
	DevToolsMessagingHookKeys["ROUTER_INFO_UPDATED"] = "routerInfoUpdated";
	return DevToolsMessagingHookKeys;
}({});
function createDevToolsCtxHooks() {
	const hooks = createHooks();
	hooks.hook(DevToolsContextHookKeys.ADD_INSPECTOR, ({ inspector, plugin }) => {
		addInspector(inspector, plugin.descriptor);
	});
	const debounceSendInspectorTree = debounce(async ({ inspectorId, plugin }) => {
		if (!inspectorId || !plugin?.descriptor?.app || devtoolsState.highPerfModeEnabled) return;
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		const _payload = {
			app: plugin.descriptor.app,
			inspectorId,
			filter: inspector?.treeFilter || "",
			rootNodes: []
		};
		await new Promise((resolve) => {
			hooks.callHookWith(async (callbacks) => {
				await Promise.all(callbacks.map((cb) => cb(_payload)));
				resolve();
			}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE);
		});
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb({
				inspectorId,
				rootNodes: _payload.rootNodes
			})));
		}, DevToolsMessagingHookKeys.SEND_INSPECTOR_TREE_TO_CLIENT);
	}, 120);
	hooks.hook(DevToolsContextHookKeys.SEND_INSPECTOR_TREE, debounceSendInspectorTree);
	const debounceSendInspectorState = debounce(async ({ inspectorId, plugin }) => {
		if (!inspectorId || !plugin?.descriptor?.app || devtoolsState.highPerfModeEnabled) return;
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		const _payload = {
			app: plugin.descriptor.app,
			inspectorId,
			nodeId: inspector?.selectedNodeId || "",
			state: null
		};
		const ctx = { currentTab: `custom-inspector:${inspectorId}` };
		if (_payload.nodeId) await new Promise((resolve) => {
			hooks.callHookWith(async (callbacks) => {
				await Promise.all(callbacks.map((cb) => cb(_payload, ctx)));
				resolve();
			}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE);
		});
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb({
				inspectorId,
				nodeId: _payload.nodeId,
				state: _payload.state
			})));
		}, DevToolsMessagingHookKeys.SEND_INSPECTOR_STATE_TO_CLIENT);
	}, 120);
	hooks.hook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, debounceSendInspectorState);
	hooks.hook(DevToolsContextHookKeys.CUSTOM_INSPECTOR_SELECT_NODE, ({ inspectorId, nodeId, plugin }) => {
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		if (!inspector) return;
		inspector.selectedNodeId = nodeId;
	});
	hooks.hook(DevToolsContextHookKeys.TIMELINE_LAYER_ADDED, ({ options, plugin }) => {
		addTimelineLayer(options, plugin.descriptor);
	});
	hooks.hook(DevToolsContextHookKeys.TIMELINE_EVENT_ADDED, ({ options, plugin }) => {
		if (devtoolsState.highPerfModeEnabled || !devtoolsState.timelineLayersState?.[plugin.descriptor.id] && ![
			"performance",
			"component-event",
			"keyboard",
			"mouse"
		].includes(options.layerId)) return;
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb(options)));
		}, DevToolsMessagingHookKeys.SEND_TIMELINE_EVENT_TO_CLIENT);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_INSTANCES, async ({ app }) => {
		const appRecord = app.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
		if (!appRecord) return null;
		const appId = appRecord.id.toString();
		return [...appRecord.instanceMap].filter(([key]) => key.split(":")[0] === appId).map(([, instance]) => instance);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_BOUNDS, async ({ instance }) => {
		return getComponentBoundingRect(instance);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_NAME, ({ instance }) => {
		return getInstanceName(instance);
	});
	hooks.hook(DevToolsContextHookKeys.COMPONENT_HIGHLIGHT, ({ uid }) => {
		const instance = activeAppRecord.value.instanceMap.get(uid);
		if (instance) highlight(instance);
	});
	hooks.hook(DevToolsContextHookKeys.COMPONENT_UNHIGHLIGHT, () => {
		unhighlight();
	});
	return hooks;
}
//#endregion
//#region src/ctx/state.ts
target.__VUE_DEVTOOLS_KIT_APP_RECORDS__ ??= [];
target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__ ??= {};
target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__ ??= "";
target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__ ??= [];
target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__ ??= [];
const STATE_KEY = "__VUE_DEVTOOLS_KIT_GLOBAL_STATE__";
function initStateFactory() {
	return {
		connected: false,
		clientConnected: false,
		vitePluginDetected: true,
		appRecords: [],
		activeAppRecordId: "",
		tabs: [],
		commands: [],
		highPerfModeEnabled: true,
		devtoolsClientDetected: {},
		perfUniqueGroupId: 0,
		timelineLayersState: getTimelineLayersStateFromStorage()
	};
}
target[STATE_KEY] ??= initStateFactory();
const callStateUpdatedHook = debounce((state) => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.DEVTOOLS_STATE_UPDATED, { state });
});
const callConnectedUpdatedHook = debounce((state, oldState) => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.DEVTOOLS_CONNECTED_UPDATED, {
		state,
		oldState
	});
});
const devtoolsAppRecords = new Proxy(target.__VUE_DEVTOOLS_KIT_APP_RECORDS__, { get(_target, prop, receiver) {
	if (prop === "value") return target.__VUE_DEVTOOLS_KIT_APP_RECORDS__;
	return target.__VUE_DEVTOOLS_KIT_APP_RECORDS__[prop];
} });
const addDevToolsAppRecord = (app) => {
	target.__VUE_DEVTOOLS_KIT_APP_RECORDS__ = [...target.__VUE_DEVTOOLS_KIT_APP_RECORDS__, app];
};
const removeDevToolsAppRecord = (app) => {
	target.__VUE_DEVTOOLS_KIT_APP_RECORDS__ = devtoolsAppRecords.value.filter((record) => record.app !== app);
};
const activeAppRecord = new Proxy(target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__, { get(_target, prop, receiver) {
	if (prop === "value") return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__;
	else if (prop === "id") return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__;
	return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__[prop];
} });
function updateAllStates() {
	callStateUpdatedHook({
		...target[STATE_KEY],
		appRecords: devtoolsAppRecords.value,
		activeAppRecordId: activeAppRecord.id,
		tabs: target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__,
		commands: target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__
	});
}
function setActiveAppRecord(app) {
	target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__ = app;
	updateAllStates();
}
function setActiveAppRecordId(id) {
	target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__ = id;
	updateAllStates();
}
const devtoolsState = new Proxy(target[STATE_KEY], {
	get(target$3, property) {
		if (property === "appRecords") return devtoolsAppRecords;
		else if (property === "activeAppRecordId") return activeAppRecord.id;
		else if (property === "tabs") return target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__;
		else if (property === "commands") return target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__;
		return target[STATE_KEY][property];
	},
	deleteProperty(target, property) {
		delete target[property];
		return true;
	},
	set(target$4, property, value) {
		target$4[property] = value;
		target[STATE_KEY][property] = value;
		return true;
	}
});
function resetDevToolsState() {
	Object.assign(target[STATE_KEY], initStateFactory());
}
function updateDevToolsState(state) {
	const oldState = {
		...target[STATE_KEY],
		appRecords: devtoolsAppRecords.value,
		activeAppRecordId: activeAppRecord.id
	};
	if (oldState.connected !== state.connected && state.connected || oldState.clientConnected !== state.clientConnected && state.clientConnected) callConnectedUpdatedHook(target[STATE_KEY], oldState);
	Object.assign(target[STATE_KEY], state);
	updateAllStates();
}
function onDevToolsConnected(fn) {
	return new Promise((resolve) => {
		if (devtoolsState.connected) {
			fn();
			resolve();
		}
		devtoolsContext.hooks.hook(DevToolsMessagingHookKeys.DEVTOOLS_CONNECTED_UPDATED, ({ state }) => {
			if (state.connected) {
				fn();
				resolve();
			}
		});
	});
}
const resolveIcon = (icon) => {
	if (!icon) return;
	if (icon.startsWith("baseline-")) return `custom-ic-${icon}`;
	if (icon.startsWith("i-") || isUrlString(icon)) return icon;
	return `custom-ic-baseline-${icon}`;
};
function addCustomTab(tab) {
	const tabs = target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__;
	if (tabs.some((t) => t.name === tab.name)) return;
	tabs.push({
		...tab,
		icon: resolveIcon(tab.icon)
	});
	updateAllStates();
}
function addCustomCommand(action) {
	const commands = target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__;
	if (commands.some((t) => t.id === action.id)) return;
	commands.push({
		...action,
		icon: resolveIcon(action.icon),
		children: action.children ? action.children.map((child) => ({
			...child,
			icon: resolveIcon(child.icon)
		})) : void 0
	});
	updateAllStates();
}
function removeCustomCommand(actionId) {
	const commands = target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__;
	const index = commands.findIndex((t) => t.id === actionId);
	if (index === -1) return;
	commands.splice(index, 1);
	updateAllStates();
}
function toggleClientConnected(state) {
	updateDevToolsState({ clientConnected: state });
}
//#endregion
//#region src/core/open-in-editor/index.ts
function setOpenInEditorBaseUrl(url) {
	target.__VUE_DEVTOOLS_OPEN_IN_EDITOR_BASE_URL__ = url;
}
function openInEditor(options = {}) {
	const { file, host, baseUrl = window.location.origin, line = 0, column = 0 } = options;
	if (file) {
		if (host === "chrome-extension") {
			const fileName = file.replace(/\\/g, "\\\\");
			const _baseUrl = window.VUE_DEVTOOLS_CONFIG?.openInEditorHost ?? "/";
			fetch(`${_baseUrl}__open-in-editor?file=${encodeURI(file)}`).then((response) => {
				if (!response.ok) {
					const msg = `Opening component ${fileName} failed`;
					console.log(`%c${msg}`, "color:red");
				}
			});
		} else if (devtoolsState.vitePluginDetected) {
			const _baseUrl = target.__VUE_DEVTOOLS_OPEN_IN_EDITOR_BASE_URL__ ?? baseUrl;
			target.__VUE_INSPECTOR__.openInEditor(_baseUrl, file, line, column);
		}
	}
}
//#endregion
//#region src/ctx/plugin.ts
target.__VUE_DEVTOOLS_KIT_PLUGIN_BUFFER__ ??= [];
const devtoolsPluginBuffer = new Proxy(target.__VUE_DEVTOOLS_KIT_PLUGIN_BUFFER__, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
function addDevToolsPluginToBuffer(pluginDescriptor, setupFn) {
	devtoolsPluginBuffer.push([pluginDescriptor, setupFn]);
}
//#endregion
//#region src/core/plugin/plugin-settings.ts
function _getSettings(settings) {
	const _settings = {};
	Object.keys(settings).forEach((key) => {
		_settings[key] = settings[key].defaultValue;
	});
	return _settings;
}
function getPluginLocalKey(pluginId) {
	return `__VUE_DEVTOOLS_NEXT_PLUGIN_SETTINGS__${pluginId}__`;
}
function getPluginSettingsOptions(pluginId) {
	return (devtoolsPluginBuffer.find((item) => item[0].id === pluginId && !!item[0]?.settings)?.[0] ?? null)?.settings ?? null;
}
function getPluginSettings(pluginId, fallbackValue) {
	const localKey = getPluginLocalKey(pluginId);
	if (localKey) {
		const localSettings = localStorage.getItem(localKey);
		if (localSettings) return JSON.parse(localSettings);
	}
	if (pluginId) return _getSettings((devtoolsPluginBuffer.find((item) => item[0].id === pluginId)?.[0] ?? null)?.settings ?? {});
	return _getSettings(fallbackValue);
}
function initPluginSettings(pluginId, settings) {
	const localKey = getPluginLocalKey(pluginId);
	if (!localStorage.getItem(localKey)) localStorage.setItem(localKey, JSON.stringify(_getSettings(settings)));
}
function setPluginSettings(pluginId, key, value) {
	const localKey = getPluginLocalKey(pluginId);
	const localSettings = localStorage.getItem(localKey);
	const parsedLocalSettings = JSON.parse(localSettings || "{}");
	const updated = {
		...parsedLocalSettings,
		[key]: value
	};
	localStorage.setItem(localKey, JSON.stringify(updated));
	devtoolsContext.hooks.callHookWith((callbacks) => {
		callbacks.forEach((cb) => cb({
			pluginId,
			key,
			oldValue: parsedLocalSettings[key],
			newValue: value,
			settings: updated
		}));
	}, DevToolsV6PluginAPIHookKeys.SET_PLUGIN_SETTINGS);
}
//#endregion
//#region src/types/hook.ts
let DevToolsHooks = /* @__PURE__ */ function(DevToolsHooks) {
	DevToolsHooks["APP_INIT"] = "app:init";
	DevToolsHooks["APP_UNMOUNT"] = "app:unmount";
	DevToolsHooks["COMPONENT_UPDATED"] = "component:updated";
	DevToolsHooks["COMPONENT_ADDED"] = "component:added";
	DevToolsHooks["COMPONENT_REMOVED"] = "component:removed";
	DevToolsHooks["COMPONENT_EMIT"] = "component:emit";
	DevToolsHooks["PERFORMANCE_START"] = "perf:start";
	DevToolsHooks["PERFORMANCE_END"] = "perf:end";
	DevToolsHooks["ADD_ROUTE"] = "router:add-route";
	DevToolsHooks["REMOVE_ROUTE"] = "router:remove-route";
	DevToolsHooks["RENDER_TRACKED"] = "render:tracked";
	DevToolsHooks["RENDER_TRIGGERED"] = "render:triggered";
	DevToolsHooks["APP_CONNECTED"] = "app:connected";
	DevToolsHooks["SETUP_DEVTOOLS_PLUGIN"] = "devtools-plugin:setup";
	return DevToolsHooks;
}({});
//#endregion
//#region src/hook/index.ts
const devtoolsHooks = target.__VUE_DEVTOOLS_HOOK ??= createHooks();
const on = {
	vueAppInit(fn) {
		devtoolsHooks.hook(DevToolsHooks.APP_INIT, fn);
	},
	vueAppUnmount(fn) {
		devtoolsHooks.hook(DevToolsHooks.APP_UNMOUNT, fn);
	},
	vueAppConnected(fn) {
		devtoolsHooks.hook(DevToolsHooks.APP_CONNECTED, fn);
	},
	componentAdded(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_ADDED, fn);
	},
	componentEmit(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_EMIT, fn);
	},
	componentUpdated(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_UPDATED, fn);
	},
	componentRemoved(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_REMOVED, fn);
	},
	setupDevtoolsPlugin(fn) {
		devtoolsHooks.hook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, fn);
	},
	perfStart(fn) {
		return devtoolsHooks.hook(DevToolsHooks.PERFORMANCE_START, fn);
	},
	perfEnd(fn) {
		return devtoolsHooks.hook(DevToolsHooks.PERFORMANCE_END, fn);
	}
};
function createDevToolsHook() {
	return {
		id: "vue-devtools-next",
		devtoolsVersion: "7.0",
		enabled: false,
		appRecords: [],
		apps: [],
		events: /* @__PURE__ */ new Map(),
		on(event, fn) {
			if (!this.events.has(event)) this.events.set(event, []);
			this.events.get(event)?.push(fn);
			return () => this.off(event, fn);
		},
		once(event, fn) {
			const onceFn = (...args) => {
				this.off(event, onceFn);
				fn(...args);
			};
			this.on(event, onceFn);
			return [event, onceFn];
		},
		off(event, fn) {
			if (this.events.has(event)) {
				const eventCallbacks = this.events.get(event);
				const index = eventCallbacks.indexOf(fn);
				if (index !== -1) eventCallbacks.splice(index, 1);
			}
		},
		emit(event, ...payload) {
			if (this.events.has(event)) this.events.get(event).forEach((fn) => fn(...payload));
		}
	};
}
function subscribeDevToolsHook(hook) {
	hook.on(DevToolsHooks.APP_INIT, (app, version, types) => {
		if (app?._instance?.type?.devtools?.hide) return;
		devtoolsHooks.callHook(DevToolsHooks.APP_INIT, app, version, types);
	});
	hook.on(DevToolsHooks.APP_UNMOUNT, (app) => {
		devtoolsHooks.callHook(DevToolsHooks.APP_UNMOUNT, app);
	});
	hook.on(DevToolsHooks.COMPONENT_ADDED, async (app, uid, parentUid, component) => {
		if (app?._instance?.type?.devtools?.hide || devtoolsState.highPerfModeEnabled) return;
		if (!app || typeof uid !== "number" && !uid || !component) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_ADDED, app, uid, parentUid, component);
	});
	hook.on(DevToolsHooks.COMPONENT_UPDATED, (app, uid, parentUid, component) => {
		if (!app || typeof uid !== "number" && !uid || !component || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED, app, uid, parentUid, component);
	});
	hook.on(DevToolsHooks.COMPONENT_REMOVED, async (app, uid, parentUid, component) => {
		if (!app || typeof uid !== "number" && !uid || !component || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_REMOVED, app, uid, parentUid, component);
	});
	hook.on(DevToolsHooks.COMPONENT_EMIT, async (app, instance, event, params) => {
		if (!app || !instance || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_EMIT, app, instance, event, params);
	});
	hook.on(DevToolsHooks.PERFORMANCE_START, (app, uid, vm, type, time) => {
		if (!app || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.PERFORMANCE_START, app, uid, vm, type, time);
	});
	hook.on(DevToolsHooks.PERFORMANCE_END, (app, uid, vm, type, time) => {
		if (!app || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.PERFORMANCE_END, app, uid, vm, type, time);
	});
	hook.on(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, (pluginDescriptor, setupFn, options) => {
		if (options?.target === "legacy") return;
		devtoolsHooks.callHook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, pluginDescriptor, setupFn);
	});
}
const hook = {
	on,
	setupDevToolsPlugin(pluginDescriptor, setupFn) {
		return devtoolsHooks.callHook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, pluginDescriptor, setupFn);
	}
};
//#endregion
//#region src/api/v6/index.ts
var DevToolsV6PluginAPI = class {
	constructor({ plugin, ctx }) {
		this.hooks = ctx.hooks;
		this.plugin = plugin;
	}
	get on() {
		return {
			visitComponentTree: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.VISIT_COMPONENT_TREE, handler);
			},
			inspectComponent: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.INSPECT_COMPONENT, handler);
			},
			editComponentState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.EDIT_COMPONENT_STATE, handler);
			},
			getInspectorTree: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE, handler);
			},
			getInspectorState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE, handler);
			},
			editInspectorState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.EDIT_INSPECTOR_STATE, handler);
			},
			inspectTimelineEvent: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.INSPECT_TIMELINE_EVENT, handler);
			},
			timelineCleared: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.TIMELINE_CLEARED, handler);
			},
			setPluginSettings: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.SET_PLUGIN_SETTINGS, handler);
			}
		};
	}
	notifyComponentUpdate(instance) {
		if (devtoolsState.highPerfModeEnabled) return;
		const inspector = getActiveInspectors().find((i) => i.packageName === this.plugin.descriptor.packageName);
		if (inspector?.id) {
			if (instance) {
				const args = [
					instance.appContext.app,
					instance.uid,
					instance.parent?.uid,
					instance
				];
				devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED, ...args);
			} else devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED);
			this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
				inspectorId: inspector.id,
				plugin: this.plugin
			});
		}
	}
	addInspector(options) {
		this.hooks.callHook(DevToolsContextHookKeys.ADD_INSPECTOR, {
			inspector: options,
			plugin: this.plugin
		});
		if (this.plugin.descriptor.settings) initPluginSettings(options.id, this.plugin.descriptor.settings);
	}
	sendInspectorTree(inspectorId) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_TREE, {
			inspectorId,
			plugin: this.plugin
		});
	}
	sendInspectorState(inspectorId) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
			inspectorId,
			plugin: this.plugin
		});
	}
	selectInspectorNode(inspectorId, nodeId) {
		this.hooks.callHook(DevToolsContextHookKeys.CUSTOM_INSPECTOR_SELECT_NODE, {
			inspectorId,
			nodeId,
			plugin: this.plugin
		});
	}
	visitComponentTree(payload) {
		return this.hooks.callHook(DevToolsV6PluginAPIHookKeys.VISIT_COMPONENT_TREE, payload);
	}
	now() {
		if (devtoolsState.highPerfModeEnabled) return 0;
		return Date.now();
	}
	addTimelineLayer(options) {
		this.hooks.callHook(DevToolsContextHookKeys.TIMELINE_LAYER_ADDED, {
			options,
			plugin: this.plugin
		});
	}
	addTimelineEvent(options) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.TIMELINE_EVENT_ADDED, {
			options,
			plugin: this.plugin
		});
	}
	getSettings(pluginId) {
		return getPluginSettings(pluginId ?? this.plugin.descriptor.id, this.plugin.descriptor.settings);
	}
	getComponentInstances(app) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_INSTANCES, { app });
	}
	getComponentBounds(instance) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_BOUNDS, { instance });
	}
	getComponentName(instance) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_NAME, { instance });
	}
	highlightElement(instance) {
		const uid = instance.__VUE_DEVTOOLS_NEXT_UID__;
		return this.hooks.callHook(DevToolsContextHookKeys.COMPONENT_HIGHLIGHT, { uid });
	}
	unhighlightElement() {
		return this.hooks.callHook(DevToolsContextHookKeys.COMPONENT_UNHIGHLIGHT);
	}
};
//#endregion
//#region src/api/index.ts
const DevToolsPluginAPI = DevToolsV6PluginAPI;
//#endregion
//#region src/core/component/state/constants.ts
const vueBuiltins = new Set([
	"nextTick",
	"defineComponent",
	"defineAsyncComponent",
	"defineCustomElement",
	"ref",
	"computed",
	"reactive",
	"readonly",
	"watchEffect",
	"watchPostEffect",
	"watchSyncEffect",
	"watch",
	"isRef",
	"unref",
	"toRef",
	"toRefs",
	"isProxy",
	"isReactive",
	"isReadonly",
	"shallowRef",
	"triggerRef",
	"customRef",
	"shallowReactive",
	"shallowReadonly",
	"toRaw",
	"markRaw",
	"effectScope",
	"getCurrentScope",
	"onScopeDispose",
	"onMounted",
	"onUpdated",
	"onUnmounted",
	"onBeforeMount",
	"onBeforeUpdate",
	"onBeforeUnmount",
	"onErrorCaptured",
	"onRenderTracked",
	"onRenderTriggered",
	"onActivated",
	"onDeactivated",
	"onServerPrefetch",
	"provide",
	"inject",
	"h",
	"mergeProps",
	"cloneVNode",
	"isVNode",
	"resolveComponent",
	"resolveDirective",
	"withDirectives",
	"withModifiers"
]);
const symbolRE = /^\[native Symbol Symbol\((.*)\)\]$/;
const rawTypeRE = /^\[object (\w+)\]$/;
const specialTypeRE = /^\[native (\w+) (.*?)(<>(([\s\S])*))?\]$/;
const fnTypeRE = /^(?:function|class) (\w+)/;
const MAX_STRING_SIZE = 1e4;
const MAX_ARRAY_SIZE = 5e3;
const UNDEFINED = "__vue_devtool_undefined__";
const INFINITY = "__vue_devtool_infinity__";
const NEGATIVE_INFINITY = "__vue_devtool_negative_infinity__";
const NAN = "__vue_devtool_nan__";
const ESC = {
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"&": "&amp;"
};
//#endregion
//#region src/core/component/state/is.ts
function isVueInstance(value) {
	if (!ensurePropertyExists(value, "_")) return false;
	if (!isPlainObject(value._)) return false;
	return Object.keys(value._).includes("vnode");
}
function isPlainObject(obj) {
	return Object.prototype.toString.call(obj) === "[object Object]";
}
function isPrimitive$1(data) {
	if (data == null) return true;
	const type = typeof data;
	return type === "string" || type === "number" || type === "boolean";
}
function isRef(raw) {
	return !!raw.__v_isRef;
}
function isComputed(raw) {
	return isRef(raw) && !!raw.effect;
}
function isReactive(raw) {
	return !!raw.__v_isReactive;
}
function isReadOnly(raw) {
	return !!raw.__v_isReadonly;
}
//#endregion
//#region src/core/component/state/util.ts
const tokenMap = {
	[UNDEFINED]: "undefined",
	[NAN]: "NaN",
	[INFINITY]: "Infinity",
	[NEGATIVE_INFINITY]: "-Infinity"
};
const reversedTokenMap = Object.entries(tokenMap).reduce((acc, [key, value]) => {
	acc[value] = key;
	return acc;
}, {});
function internalStateTokenToString(value) {
	if (value === null) return "null";
	return typeof value === "string" && tokenMap[value] || false;
}
function replaceTokenToString(value) {
	const replaceRegex = new RegExp(`"(${Object.keys(tokenMap).join("|")})"`, "g");
	return value.replace(replaceRegex, (_, g1) => tokenMap[g1]);
}
function replaceStringToToken(value) {
	const literalValue = reversedTokenMap[value.trim()];
	if (literalValue) return `"${literalValue}"`;
	const replaceRegex = new RegExp(`:\\s*(${Object.keys(reversedTokenMap).join("|")})`, "g");
	return value.replace(replaceRegex, (_, g1) => `:"${reversedTokenMap[g1]}"`);
}
/**
* Convert prop type constructor to string.
*/
function getPropType(type) {
	if (Array.isArray(type)) return type.map((t) => getPropType(t)).join(" or ");
	if (type == null) return "null";
	const match = type.toString().match(fnTypeRE);
	return typeof type === "function" ? match && match[1] || "any" : "any";
}
/**
* Sanitize data to be posted to the other side.
* Since the message posted is sent with structured clone,
* we need to filter out any types that might cause an error.
*/
function sanitize(data) {
	if (!isPrimitive$1(data) && !Array.isArray(data) && !isPlainObject(data)) return Object.prototype.toString.call(data);
	else return data;
}
function getSetupStateType(raw) {
	try {
		return {
			ref: isRef(raw),
			computed: isComputed(raw),
			reactive: isReactive(raw),
			readonly: isReadOnly(raw)
		};
	} catch {
		return {
			ref: false,
			computed: false,
			reactive: false,
			readonly: false
		};
	}
}
function toRaw(value) {
	if (value?.__v_raw) return value.__v_raw;
	return value;
}
function escape(s) {
	return s.replace(/[<>"&]/g, (s) => {
		return ESC[s] || s;
	});
}
//#endregion
//#region src/core/component/state/process.ts
function mergeOptions(to, from, instance) {
	if (typeof from === "function") from = from.options;
	if (!from) return to;
	const { mixins, extends: extendsOptions } = from;
	extendsOptions && mergeOptions(to, extendsOptions, instance);
	mixins && mixins.forEach((m) => mergeOptions(to, m, instance));
	for (const key of ["computed", "inject"]) if (Object.prototype.hasOwnProperty.call(from, key)) {
		to[key] ??= {};
		Object.assign(to[key], from[key]);
	}
	return to;
}
function resolveMergedOptions(instance) {
	const raw = instance?.type;
	if (!raw) return {};
	const { mixins, extends: extendsOptions } = raw;
	const globalMixins = instance.appContext.mixins;
	if (!globalMixins.length && !mixins && !extendsOptions) return raw;
	const options = {};
	globalMixins.forEach((m) => mergeOptions(options, m, instance));
	mergeOptions(options, raw, instance);
	return options;
}
/**
* Process the props of an instance.
* Make sure return a plain object because window.postMessage()
* will throw an Error if the passed object contains Functions.
*
*/
function processProps(instance) {
	const props = [];
	const propDefinitions = instance?.type?.props;
	for (const key in instance?.props) {
		const propDefinition = propDefinitions ? propDefinitions[key] : null;
		const camelizeKey = camelize(key);
		props.push({
			type: "props",
			key: camelizeKey,
			value: returnError(() => instance.props[key]),
			editable: true,
			meta: propDefinition ? {
				type: propDefinition.type ? getPropType(propDefinition.type) : "any",
				required: !!propDefinition.required,
				...propDefinition.default ? { default: propDefinition.default.toString() } : {}
			} : { type: "invalid" }
		});
	}
	return props;
}
/**
* Process state, filtering out props and "clean" the result
* with a JSON dance. This removes functions which can cause
* errors during structured clone used by window.postMessage.
*
*/
function processState(instance) {
	const type = instance.type;
	const props = type?.props;
	const getters = type.vuex && type.vuex.getters;
	const computedDefs = type.computed;
	const data = {
		...instance.data,
		...instance.renderContext
	};
	return Object.keys(data).filter((key) => !(props && key in props) && !(getters && key in getters) && !(computedDefs && key in computedDefs)).map((key) => ({
		key,
		type: "data",
		value: returnError(() => data[key]),
		editable: true
	}));
}
function getStateTypeAndName(info) {
	const stateType = info.computed ? "computed" : info.ref ? "ref" : info.reactive ? "reactive" : null;
	return {
		stateType,
		stateTypeName: stateType ? `${stateType.charAt(0).toUpperCase()}${stateType.slice(1)}` : null
	};
}
function processSetupState(instance) {
	const raw = instance.devtoolsRawSetupState || {};
	return Object.keys(instance.setupState).filter((key) => !vueBuiltins.has(key) && key.split(/(?=[A-Z])/)[0] !== "use").map((key) => {
		const value = returnError(() => toRaw(instance.setupState[key]));
		const accessError = value instanceof Error;
		const rawData = raw[key];
		let result;
		let isOtherType = accessError || typeof value === "function" || ensurePropertyExists(value, "render") && typeof value.render === "function" || ensurePropertyExists(value, "__asyncLoader") && typeof value.__asyncLoader === "function" || typeof value === "object" && value && ("setup" in value || "props" in value) || /^v[A-Z]/.test(key);
		if (rawData && !accessError) {
			const info = getSetupStateType(rawData);
			const { stateType, stateTypeName } = getStateTypeAndName(info);
			const isState = info.ref || info.computed || info.reactive;
			const raw = ensurePropertyExists(rawData, "effect") ? rawData.effect?.raw?.toString() || rawData.effect?.fn?.toString() : null;
			if (stateType) isOtherType = false;
			result = {
				...stateType ? {
					stateType,
					stateTypeName
				} : {},
				...raw ? { raw } : {},
				editable: isState && !info.readonly
			};
		}
		return {
			key,
			value,
			type: isOtherType ? "setup (other)" : "setup",
			...result
		};
	});
}
/**
* Process the computed properties of an instance.
*/
function processComputed(instance, mergedType) {
	const type = mergedType;
	const computed = [];
	const defs = type.computed || {};
	for (const key in defs) {
		const def = defs[key];
		const type = typeof def === "function" && def.vuex ? "vuex bindings" : "computed";
		computed.push({
			type,
			key,
			value: returnError(() => instance?.proxy?.[key]),
			editable: typeof def.set === "function"
		});
	}
	return computed;
}
function processAttrs(instance) {
	return Object.keys(instance.attrs).map((key) => ({
		type: "attrs",
		key,
		value: returnError(() => instance.attrs[key])
	}));
}
function processProvide(instance) {
	return Reflect.ownKeys(instance.provides).map((key) => ({
		type: "provided",
		key: key.toString(),
		value: returnError(() => instance.provides[key])
	}));
}
function processInject(instance, mergedType) {
	if (!mergedType?.inject) return [];
	let keys = [];
	let defaultValue;
	if (Array.isArray(mergedType.inject)) keys = mergedType.inject.map((key) => ({
		key,
		originalKey: key
	}));
	else keys = Reflect.ownKeys(mergedType.inject).map((key) => {
		const value = mergedType.inject[key];
		let originalKey;
		if (typeof value === "string" || typeof value === "symbol") originalKey = value;
		else {
			originalKey = value.from;
			defaultValue = value.default;
		}
		return {
			key,
			originalKey
		};
	});
	return keys.map(({ key, originalKey }) => ({
		type: "injected",
		key: originalKey && key !== originalKey ? `${originalKey.toString()} ➞ ${key.toString()}` : key.toString(),
		value: returnError(() => instance.ctx.hasOwnProperty(key) ? instance.ctx[key] : instance.provides.hasOwnProperty(originalKey) ? instance.provides[originalKey] : defaultValue)
	}));
}
function processRefs(instance) {
	return Object.keys(instance.refs).map((key) => ({
		type: "template refs",
		key,
		value: returnError(() => instance.refs[key])
	}));
}
const vnodeEvents = new Set([
	"vnode-before-mount",
	"vnode-mounted",
	"vnode-before-update",
	"vnode-updated",
	"vnode-before-unmount",
	"vnode-unmounted"
]);
function processEventListeners(instance) {
	const emitsDefinition = instance.type.emits;
	const declaredEmits = Array.isArray(emitsDefinition) ? emitsDefinition : Object.keys(emitsDefinition ?? {});
	const keys = Object.keys(instance?.vnode?.props ?? {});
	const result = [];
	for (const key of keys) {
		const [prefix, ...eventNameParts] = key.split(/(?=[A-Z])/);
		if (prefix === "on") {
			const eventName = eventNameParts.join("-").toLowerCase();
			const isBuiltIn = vnodeEvents.has(eventName);
			const isDeclared = declaredEmits.includes(eventName) || declaredEmits.includes(camelize(eventName));
			const text = isBuiltIn ? "✅ Built-in" : isDeclared ? "✅ Declared" : "⚠️ Not declared";
			result.push({
				type: "event listeners",
				key: eventName,
				value: { _custom: {
					displayText: text,
					key: text,
					value: text,
					tooltipText: isBuiltIn ? `The event <code>${escape(eventName)}</code> is part of Vue and doesn't need to be declared by the component` : !isDeclared ? `The event <code>${escape(eventName)}</code> is not declared in the <code>emits</code> option. It will leak into the component's attributes (<code>$attrs</code>).` : null
				} }
			});
		}
	}
	return result;
}
function processInstanceState(instance) {
	const mergedType = resolveMergedOptions(instance);
	return processProps(instance).concat(processState(instance), processSetupState(instance), processComputed(instance, mergedType), processAttrs(instance), processProvide(instance), processInject(instance, mergedType), processRefs(instance), processEventListeners(instance));
}
//#endregion
//#region src/core/component/state/index.ts
function getInstanceState(params) {
	const instance = getComponentInstance(activeAppRecord.value, params.instanceId);
	return {
		id: getUniqueComponentId(instance),
		name: getInstanceName(instance),
		file: instance?.type?.__file,
		state: processInstanceState(instance),
		instance
	};
}
//#endregion
//#region src/core/component/tree/filter.ts
var ComponentFilter = class {
	constructor(filter) {
		this.filter = filter || "";
	}
	/**
	* Check if an instance is qualified.
	*
	* @param {Vue|Vnode} instance
	* @return {boolean}
	*/
	isQualified(instance) {
		const name = getInstanceName(instance);
		return classify(name).toLowerCase().includes(this.filter) || kebabize(name).toLowerCase().includes(this.filter);
	}
};
function createComponentFilter(filterText) {
	return new ComponentFilter(filterText);
}
//#endregion
//#region src/core/component/tree/walker.ts
var ComponentWalker = class {
	constructor(options) {
		this.captureIds = /* @__PURE__ */ new Map();
		const { filterText = "", maxDepth, recursively, api } = options;
		this.componentFilter = createComponentFilter(filterText);
		this.maxDepth = maxDepth;
		this.recursively = recursively;
		this.api = api;
	}
	getComponentTree(instance) {
		this.captureIds = /* @__PURE__ */ new Map();
		return this.findQualifiedChildren(instance, 0);
	}
	getComponentParents(instance) {
		this.captureIds = /* @__PURE__ */ new Map();
		const parents = [];
		this.captureId(instance);
		let parent = instance;
		while (parent = parent.parent) {
			this.captureId(parent);
			parents.push(parent);
		}
		return parents;
	}
	captureId(instance) {
		if (!instance) return null;
		const id = instance.__VUE_DEVTOOLS_NEXT_UID__ != null ? instance.__VUE_DEVTOOLS_NEXT_UID__ : getUniqueComponentId(instance);
		instance.__VUE_DEVTOOLS_NEXT_UID__ = id;
		if (this.captureIds.has(id)) return null;
		else this.captureIds.set(id, void 0);
		this.mark(instance);
		return id;
	}
	/**
	* Capture the meta information of an instance. (recursive)
	*
	* @param {Vue} instance
	* @return {object}
	*/
	async capture(instance, depth) {
		if (!instance) return null;
		const id = this.captureId(instance);
		const name = getInstanceName(instance);
		const children = this.getInternalInstanceChildren(instance.subTree).filter((child) => !isBeingDestroyed(child));
		const parents = this.getComponentParents(instance) || [];
		const inactive = !!instance.isDeactivated || parents.some((parent) => parent.isDeactivated);
		const treeNode = {
			uid: instance.uid,
			id,
			name,
			renderKey: getRenderKey(instance.vnode ? instance.vnode.key : null),
			inactive,
			children: [],
			hasChildren: !!children.length,
			isFragment: isFragment(instance),
			tags: typeof instance.type !== "function" ? [] : [{
				label: "functional",
				textColor: 5592405,
				backgroundColor: 15658734
			}],
			autoOpen: this.recursively,
			file: instance.type.__file || ""
		};
		if (depth < this.maxDepth || instance.type.__isKeepAlive || parents.some((parent) => parent.type.__isKeepAlive)) treeNode.children = await Promise.all(children.map((child) => this.capture(child, depth + 1)).filter(Boolean));
		if (this.isKeepAlive(instance)) {
			const cachedComponents = this.getKeepAliveCachedInstances(instance);
			const childrenIds = children.map((child) => child.__VUE_DEVTOOLS_NEXT_UID__);
			for (const cachedChild of cachedComponents) if (!childrenIds.includes(cachedChild.__VUE_DEVTOOLS_NEXT_UID__)) {
				const node = await this.capture({
					...cachedChild,
					isDeactivated: true
				}, depth + 1);
				if (node) treeNode.children.push(node);
			}
		}
		const firstElement = getRootElementsFromComponentInstance(instance)[0];
		if (firstElement?.parentElement) {
			const parentInstance = instance.parent;
			const parentRootElements = parentInstance ? getRootElementsFromComponentInstance(parentInstance) : [];
			let el = firstElement;
			const indexList = [];
			do {
				indexList.push(Array.from(el.parentElement.childNodes).indexOf(el));
				el = el.parentElement;
			} while (el.parentElement && parentRootElements.length && !parentRootElements.includes(el));
			treeNode.domOrder = indexList.reverse();
		} else treeNode.domOrder = [-1];
		if (instance.suspense?.suspenseKey) {
			treeNode.tags.push({
				label: instance.suspense.suspenseKey,
				backgroundColor: 14979812,
				textColor: 16777215
			});
			this.mark(instance, true);
		}
		this.api.visitComponentTree({
			treeNode,
			componentInstance: instance,
			app: instance.appContext.app,
			filter: this.componentFilter.filter
		});
		return treeNode;
	}
	/**
	* Find qualified children from a single instance.
	* If the instance itself is qualified, just return itself.
	* This is ok because [].concat works in both cases.
	*
	* @param {Vue|Vnode} instance
	* @return {Vue|Array}
	*/
	async findQualifiedChildren(instance, depth) {
		if (this.componentFilter.isQualified(instance) && !instance.type.devtools?.hide) return [await this.capture(instance, depth)];
		else if (instance.subTree) {
			const list = this.isKeepAlive(instance) ? this.getKeepAliveCachedInstances(instance) : this.getInternalInstanceChildren(instance.subTree);
			return this.findQualifiedChildrenFromList(list, depth);
		} else return [];
	}
	/**
	* Iterate through an array of instances and flatten it into
	* an array of qualified instances. This is a depth-first
	* traversal - e.g. if an instance is not matched, we will
	* recursively go deeper until a qualified child is found.
	*
	* @param {Array} instances
	* @return {Array}
	*/
	async findQualifiedChildrenFromList(instances, depth) {
		instances = instances.filter((child) => !isBeingDestroyed(child) && !child.type.devtools?.hide);
		if (!this.componentFilter.filter) return Promise.all(instances.map((child) => this.capture(child, depth)));
		else return Array.prototype.concat.apply([], await Promise.all(instances.map((i) => this.findQualifiedChildren(i, depth))));
	}
	/**
	* Get children from a component instance.
	*/
	getInternalInstanceChildren(subTree, suspense = null) {
		const list = [];
		if (subTree) {
			if (subTree.component) !suspense ? list.push(subTree.component) : list.push({
				...subTree.component,
				suspense
			});
			else if (subTree.suspense) {
				const suspenseKey = !subTree.suspense.isInFallback ? "suspense default" : "suspense fallback";
				list.push(...this.getInternalInstanceChildren(subTree.suspense.activeBranch, {
					...subTree.suspense,
					suspenseKey
				}));
			} else if (Array.isArray(subTree.children)) subTree.children.forEach((childSubTree) => {
				if (childSubTree.component) !suspense ? list.push(childSubTree.component) : list.push({
					...childSubTree.component,
					suspense
				});
				else list.push(...this.getInternalInstanceChildren(childSubTree, suspense));
			});
		}
		return list.filter((child) => !isBeingDestroyed(child) && !child.type.devtools?.hide);
	}
	/**
	* Mark an instance as captured and store it in the instance map.
	*
	* @param {Vue} instance
	*/
	mark(instance, force = false) {
		const instanceMap = getAppRecord(instance).instanceMap;
		if (force || !instanceMap.has(instance.__VUE_DEVTOOLS_NEXT_UID__)) {
			instanceMap.set(instance.__VUE_DEVTOOLS_NEXT_UID__, instance);
			activeAppRecord.value.instanceMap = instanceMap;
		}
	}
	isKeepAlive(instance) {
		return instance.type.__isKeepAlive && instance.__v_cache;
	}
	getKeepAliveCachedInstances(instance) {
		return Array.from(instance.__v_cache.values()).map((vnode) => vnode.component).filter(Boolean);
	}
};
//#endregion
//#region src/core/timeline/perf.ts
const markEndQueue = /* @__PURE__ */ new Map();
const PERFORMANCE_EVENT_LAYER_ID = "performance";
async function performanceMarkStart(api, app, uid, vm, type, time) {
	const appRecord = await getAppRecord(app);
	if (!appRecord) return;
	const componentName = getInstanceName(vm) || "Unknown Component";
	const groupId = devtoolsState.perfUniqueGroupId++;
	const groupKey = `${uid}-${type}`;
	appRecord.perfGroupIds.set(groupKey, {
		groupId,
		time
	});
	await api.addTimelineEvent({
		layerId: PERFORMANCE_EVENT_LAYER_ID,
		event: {
			time: Date.now(),
			data: {
				component: componentName,
				type,
				measure: "start"
			},
			title: componentName,
			subtitle: type,
			groupId
		}
	});
	if (markEndQueue.has(groupKey)) {
		const { app, uid, instance, type, time } = markEndQueue.get(groupKey);
		markEndQueue.delete(groupKey);
		await performanceMarkEnd(api, app, uid, instance, type, time);
	}
}
function performanceMarkEnd(api, app, uid, vm, type, time) {
	const appRecord = getAppRecord(app);
	if (!appRecord) return;
	const componentName = getInstanceName(vm) || "Unknown Component";
	const groupKey = `${uid}-${type}`;
	const groupInfo = appRecord.perfGroupIds.get(groupKey);
	if (groupInfo) {
		const groupId = groupInfo.groupId;
		const duration = time - groupInfo.time;
		api.addTimelineEvent({
			layerId: PERFORMANCE_EVENT_LAYER_ID,
			event: {
				time: Date.now(),
				data: {
					component: componentName,
					type,
					measure: "end",
					duration: { _custom: {
						type: "Duration",
						value: duration,
						display: `${duration} ms`
					} }
				},
				title: componentName,
				subtitle: type,
				groupId
			}
		});
	} else markEndQueue.set(groupKey, {
		app,
		uid,
		instance: vm,
		type,
		time
	});
}
//#endregion
//#region src/core/timeline/index.ts
const COMPONENT_EVENT_LAYER_ID = "component-event";
function setupBuiltinTimelineLayers(api) {
	if (!isBrowser) return;
	api.addTimelineLayer({
		id: "mouse",
		label: "Mouse",
		color: 10768815
	});
	[
		"mousedown",
		"mouseup",
		"click",
		"dblclick"
	].forEach((eventType) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.mouseEventEnabled) return;
		window.addEventListener(eventType, async (event) => {
			await api.addTimelineEvent({
				layerId: "mouse",
				event: {
					time: Date.now(),
					data: {
						type: eventType,
						x: event.clientX,
						y: event.clientY
					},
					title: eventType
				}
			});
		}, {
			capture: true,
			passive: true
		});
	});
	api.addTimelineLayer({
		id: "keyboard",
		label: "Keyboard",
		color: 8475055
	});
	[
		"keyup",
		"keydown",
		"keypress"
	].forEach((eventType) => {
		window.addEventListener(eventType, async (event) => {
			if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.keyboardEventEnabled) return;
			await api.addTimelineEvent({
				layerId: "keyboard",
				event: {
					time: Date.now(),
					data: {
						type: eventType,
						key: event.key,
						ctrlKey: event.ctrlKey,
						shiftKey: event.shiftKey,
						altKey: event.altKey,
						metaKey: event.metaKey
					},
					title: event.key
				}
			});
		}, {
			capture: true,
			passive: true
		});
	});
	api.addTimelineLayer({
		id: COMPONENT_EVENT_LAYER_ID,
		label: "Component events",
		color: 5226637
	});
	hook.on.componentEmit(async (app, instance, event, params) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.componentEventEnabled) return;
		const appRecord = await getAppRecord(app);
		if (!appRecord) return;
		const componentId = `${appRecord.id}:${instance.uid}`;
		const componentName = getInstanceName(instance) || "Unknown Component";
		api.addTimelineEvent({
			layerId: COMPONENT_EVENT_LAYER_ID,
			event: {
				time: Date.now(),
				data: {
					component: { _custom: {
						type: "component-definition",
						display: componentName
					} },
					event,
					params
				},
				title: event,
				subtitle: `by ${componentName}`,
				meta: { componentId }
			}
		});
	});
	api.addTimelineLayer({
		id: "performance",
		label: PERFORMANCE_EVENT_LAYER_ID,
		color: 4307050
	});
	hook.on.perfStart((app, uid, vm, type, time) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.performanceEventEnabled) return;
		performanceMarkStart(api, app, uid, vm, type, time);
	});
	hook.on.perfEnd((app, uid, vm, type, time) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.performanceEventEnabled) return;
		performanceMarkEnd(api, app, uid, vm, type, time);
	});
}
//#endregion
//#region src/core/vm/index.ts
const MAX_$VM = 10;
const $vmQueue = [];
function exposeInstanceToWindow(componentInstance) {
	if (typeof window === "undefined") return;
	const win = window;
	if (!componentInstance) return;
	win.$vm = componentInstance;
	if ($vmQueue[0] !== componentInstance) {
		if ($vmQueue.length >= MAX_$VM) $vmQueue.pop();
		for (let i = $vmQueue.length; i > 0; i--) win[`$vm${i}`] = $vmQueue[i] = $vmQueue[i - 1];
		win.$vm0 = $vmQueue[0] = componentInstance;
	}
}
//#endregion
//#region src/core/plugin/components.ts
const INSPECTOR_ID = "components";
function createComponentsDevToolsPlugin(app) {
	const descriptor = {
		id: INSPECTOR_ID,
		label: "Components",
		app
	};
	const setupFn = (api) => {
		api.addInspector({
			id: INSPECTOR_ID,
			label: "Components",
			treeFilterPlaceholder: "Search components"
		});
		setupBuiltinTimelineLayers(api);
		api.on.getInspectorTree(async (payload) => {
			if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
				const instance = getComponentInstance(activeAppRecord.value, payload.instanceId);
				if (instance) payload.rootNodes = await new ComponentWalker({
					filterText: payload.filter,
					maxDepth: 100,
					recursively: false,
					api
				}).getComponentTree(instance);
			}
		});
		api.on.getInspectorState(async (payload) => {
			if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
				const result = getInstanceState({ instanceId: payload.nodeId });
				const componentInstance = result.instance;
				const _payload = {
					componentInstance,
					app: result.instance?.appContext.app,
					instanceData: result
				};
				devtoolsContext.hooks.callHookWith((callbacks) => {
					callbacks.forEach((cb) => cb(_payload));
				}, DevToolsV6PluginAPIHookKeys.INSPECT_COMPONENT);
				payload.state = result;
				exposeInstanceToWindow(componentInstance);
			}
		});
		api.on.editInspectorState(async (payload) => {
			if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
				editState(payload);
				await api.sendInspectorState("components");
			}
		});
		const debounceSendInspectorTree = debounce(() => {
			api.sendInspectorTree(INSPECTOR_ID);
		}, 120);
		const debounceSendInspectorState = debounce(() => {
			api.sendInspectorState(INSPECTOR_ID);
		}, 120);
		hook.on.componentAdded(async (app, uid, parentUid, component) => {
			if (devtoolsState.highPerfModeEnabled) return;
			if (app?._instance?.type?.devtools?.hide) return;
			if (!app || typeof uid !== "number" && !uid || !component) return;
			const id = await getComponentId({
				app,
				uid,
				instance: component
			});
			const appRecord = await getAppRecord(app);
			if (component) {
				if (component.__VUE_DEVTOOLS_NEXT_UID__ == null) component.__VUE_DEVTOOLS_NEXT_UID__ = id;
				if (!appRecord?.instanceMap.has(id)) {
					appRecord?.instanceMap.set(id, component);
					if (activeAppRecord.value.id === appRecord?.id) activeAppRecord.value.instanceMap = appRecord.instanceMap;
				}
			}
			if (!appRecord) return;
			debounceSendInspectorTree();
		});
		hook.on.componentUpdated(async (app, uid, parentUid, component) => {
			if (devtoolsState.highPerfModeEnabled) return;
			if (app?._instance?.type?.devtools?.hide) return;
			if (!app || typeof uid !== "number" && !uid || !component) return;
			const id = await getComponentId({
				app,
				uid,
				instance: component
			});
			const appRecord = await getAppRecord(app);
			if (component) {
				if (component.__VUE_DEVTOOLS_NEXT_UID__ == null) component.__VUE_DEVTOOLS_NEXT_UID__ = id;
				if (!appRecord?.instanceMap.has(id)) {
					appRecord?.instanceMap.set(id, component);
					if (activeAppRecord.value.id === appRecord?.id) activeAppRecord.value.instanceMap = appRecord.instanceMap;
				}
			}
			if (!appRecord) return;
			debounceSendInspectorTree();
			debounceSendInspectorState();
		});
		hook.on.componentRemoved(async (app, uid, parentUid, component) => {
			if (devtoolsState.highPerfModeEnabled) return;
			if (app?._instance?.type?.devtools?.hide) return;
			if (!app || typeof uid !== "number" && !uid || !component) return;
			const appRecord = await getAppRecord(app);
			if (!appRecord) return;
			const id = await getComponentId({
				app,
				uid,
				instance: component
			});
			appRecord?.instanceMap.delete(id);
			if (activeAppRecord.value.id === appRecord?.id) activeAppRecord.value.instanceMap = appRecord.instanceMap;
			debounceSendInspectorTree();
		});
	};
	return [descriptor, setupFn];
}
//#endregion
//#region src/core/plugin/index.ts
target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__ ??= /* @__PURE__ */ new Set();
function setupDevToolsPlugin(pluginDescriptor, setupFn) {
	return hook.setupDevToolsPlugin(pluginDescriptor, setupFn);
}
function callDevToolsPluginSetupFn(plugin, app) {
	const [pluginDescriptor, setupFn] = plugin;
	if (pluginDescriptor.app !== app) return;
	const api = new DevToolsPluginAPI({
		plugin: {
			setupFn,
			descriptor: pluginDescriptor
		},
		ctx: devtoolsContext
	});
	if (pluginDescriptor.packageName === "vuex") api.on.editInspectorState((payload) => {
		api.sendInspectorState(payload.inspectorId);
	});
	setupFn(api);
}
function removeRegisteredPluginApp(app) {
	target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.delete(app);
}
function registerDevToolsPlugin(app, options) {
	if (target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.has(app)) return;
	if (devtoolsState.highPerfModeEnabled && !options?.inspectingComponent) return;
	target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.add(app);
	devtoolsPluginBuffer.forEach((plugin) => {
		callDevToolsPluginSetupFn(plugin, app);
	});
}
//#endregion
//#region src/ctx/router.ts
const ROUTER_KEY = "__VUE_DEVTOOLS_ROUTER__";
const ROUTER_INFO_KEY = "__VUE_DEVTOOLS_ROUTER_INFO__";
target[ROUTER_INFO_KEY] ??= {
	currentRoute: null,
	routes: []
};
target[ROUTER_KEY] ??= {};
const devtoolsRouterInfo = new Proxy(target[ROUTER_INFO_KEY], { get(target$1, property) {
	return target[ROUTER_INFO_KEY][property];
} });
const devtoolsRouter = new Proxy(target[ROUTER_KEY], { get(target$2, property) {
	if (property === "value") return target[ROUTER_KEY];
} });
//#endregion
//#region src/core/router/index.ts
function getRoutes(router) {
	const routesMap = /* @__PURE__ */ new Map();
	return (router?.getRoutes() || []).filter((i) => !routesMap.has(i.path) && routesMap.set(i.path, 1));
}
function filterRoutes(routes) {
	return routes.map((item) => {
		let { path, name, children, meta } = item;
		if (children?.length) children = filterRoutes(children);
		return {
			path,
			name,
			children,
			meta
		};
	});
}
function filterCurrentRoute(route) {
	if (route) {
		const { fullPath, hash, href, path, name, matched, params, query } = route;
		return {
			fullPath,
			hash,
			href,
			path,
			name,
			params,
			query,
			matched: filterRoutes(matched)
		};
	}
	return route;
}
function normalizeRouterInfo(appRecord, activeAppRecord) {
	function init() {
		const router = appRecord.app?.config.globalProperties.$router;
		const currentRoute = filterCurrentRoute(router?.currentRoute.value);
		const routes = filterRoutes(getRoutes(router));
		const c = console.warn;
		console.warn = () => {};
		target[ROUTER_INFO_KEY] = {
			currentRoute: currentRoute ? deepClone(currentRoute) : {},
			routes: deepClone(routes)
		};
		target[ROUTER_KEY] = router;
		console.warn = c;
	}
	init();
	hook.on.componentUpdated(debounce(() => {
		if (activeAppRecord.value?.app !== appRecord.app) return;
		init();
		if (devtoolsState.highPerfModeEnabled) return;
		devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.ROUTER_INFO_UPDATED, { state: target[ROUTER_INFO_KEY] });
	}, 200));
}
//#endregion
//#region src/ctx/api.ts
function createDevToolsApi(hooks) {
	return {
		async getInspectorTree(payload) {
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				rootNodes: []
			};
			await new Promise((resolve) => {
				hooks.callHookWith(async (callbacks) => {
					await Promise.all(callbacks.map((cb) => cb(_payload)));
					resolve();
				}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE);
			});
			return _payload.rootNodes;
		},
		async getInspectorState(payload) {
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				state: null
			};
			const ctx = { currentTab: `custom-inspector:${payload.inspectorId}` };
			await new Promise((resolve) => {
				hooks.callHookWith(async (callbacks) => {
					await Promise.all(callbacks.map((cb) => cb(_payload, ctx)));
					resolve();
				}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE);
			});
			return _payload.state;
		},
		editInspectorState(payload) {
			const stateEditor = new StateEditor();
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				set: (obj, path = payload.path, value = payload.state.value, cb) => {
					stateEditor.set(obj, path, value, cb || stateEditor.createDefaultSetCallback(payload.state));
				}
			};
			hooks.callHookWith((callbacks) => {
				callbacks.forEach((cb) => cb(_payload));
			}, DevToolsV6PluginAPIHookKeys.EDIT_INSPECTOR_STATE);
		},
		sendInspectorState(inspectorId) {
			const inspector = getInspector(inspectorId);
			hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
				inspectorId,
				plugin: {
					descriptor: inspector.descriptor,
					setupFn: () => ({})
				}
			});
		},
		inspectComponentInspector() {
			return inspectComponentHighLighter();
		},
		cancelInspectComponentInspector() {
			return cancelInspectComponentHighLighter();
		},
		getComponentRenderCode(id) {
			const instance = getComponentInstance(activeAppRecord.value, id);
			if (instance) return !(typeof instance?.type === "function") ? instance.render.toString() : instance.type.toString();
		},
		scrollToComponent(id) {
			return scrollToComponent({ id });
		},
		openInEditor,
		getVueInspector: getComponentInspector,
		toggleApp(id, options) {
			const appRecord = devtoolsAppRecords.value.find((record) => record.id === id);
			if (appRecord) {
				setActiveAppRecordId(id);
				setActiveAppRecord(appRecord);
				normalizeRouterInfo(appRecord, activeAppRecord);
				callInspectorUpdatedHook();
				registerDevToolsPlugin(appRecord.app, options);
			}
		},
		inspectDOM(instanceId) {
			const instance = getComponentInstance(activeAppRecord.value, instanceId);
			if (instance) {
				const [el] = getRootElementsFromComponentInstance(instance);
				if (el) target.__VUE_DEVTOOLS_INSPECT_DOM_TARGET__ = el;
			}
		},
		updatePluginSettings(pluginId, key, value) {
			setPluginSettings(pluginId, key, value);
		},
		getPluginSettings(pluginId) {
			return {
				options: getPluginSettingsOptions(pluginId),
				values: getPluginSettings(pluginId)
			};
		}
	};
}
//#endregion
//#region src/ctx/env.ts
target.__VUE_DEVTOOLS_ENV__ ??= { vitePluginDetected: false };
function getDevToolsEnv() {
	return target.__VUE_DEVTOOLS_ENV__;
}
function setDevToolsEnv(env) {
	target.__VUE_DEVTOOLS_ENV__ = {
		...target.__VUE_DEVTOOLS_ENV__,
		...env
	};
}
//#endregion
//#region src/ctx/index.ts
const hooks = createDevToolsCtxHooks();
target.__VUE_DEVTOOLS_KIT_CONTEXT__ ??= {
	hooks,
	get state() {
		return {
			...devtoolsState,
			activeAppRecordId: activeAppRecord.id,
			activeAppRecord: activeAppRecord.value,
			appRecords: devtoolsAppRecords.value
		};
	},
	api: createDevToolsApi(hooks)
};
const devtoolsContext = target.__VUE_DEVTOOLS_KIT_CONTEXT__;
//#endregion
//#region ../../node_modules/.pnpm/speakingurl@14.0.1/node_modules/speakingurl/lib/speakingurl.js
var require_speakingurl$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(root) {
		"use strict";
		/**
		* charMap
		* @type {Object}
		*/
		var charMap = {
			"À": "A",
			"Á": "A",
			"Â": "A",
			"Ã": "A",
			"Ä": "Ae",
			"Å": "A",
			"Æ": "AE",
			"Ç": "C",
			"È": "E",
			"É": "E",
			"Ê": "E",
			"Ë": "E",
			"Ì": "I",
			"Í": "I",
			"Î": "I",
			"Ï": "I",
			"Ð": "D",
			"Ñ": "N",
			"Ò": "O",
			"Ó": "O",
			"Ô": "O",
			"Õ": "O",
			"Ö": "Oe",
			"Ő": "O",
			"Ø": "O",
			"Ù": "U",
			"Ú": "U",
			"Û": "U",
			"Ü": "Ue",
			"Ű": "U",
			"Ý": "Y",
			"Þ": "TH",
			"ß": "ss",
			"à": "a",
			"á": "a",
			"â": "a",
			"ã": "a",
			"ä": "ae",
			"å": "a",
			"æ": "ae",
			"ç": "c",
			"è": "e",
			"é": "e",
			"ê": "e",
			"ë": "e",
			"ì": "i",
			"í": "i",
			"î": "i",
			"ï": "i",
			"ð": "d",
			"ñ": "n",
			"ò": "o",
			"ó": "o",
			"ô": "o",
			"õ": "o",
			"ö": "oe",
			"ő": "o",
			"ø": "o",
			"ù": "u",
			"ú": "u",
			"û": "u",
			"ü": "ue",
			"ű": "u",
			"ý": "y",
			"þ": "th",
			"ÿ": "y",
			"ẞ": "SS",
			"ا": "a",
			"أ": "a",
			"إ": "i",
			"آ": "aa",
			"ؤ": "u",
			"ئ": "e",
			"ء": "a",
			"ب": "b",
			"ت": "t",
			"ث": "th",
			"ج": "j",
			"ح": "h",
			"خ": "kh",
			"د": "d",
			"ذ": "th",
			"ر": "r",
			"ز": "z",
			"س": "s",
			"ش": "sh",
			"ص": "s",
			"ض": "dh",
			"ط": "t",
			"ظ": "z",
			"ع": "a",
			"غ": "gh",
			"ف": "f",
			"ق": "q",
			"ك": "k",
			"ل": "l",
			"م": "m",
			"ن": "n",
			"ه": "h",
			"و": "w",
			"ي": "y",
			"ى": "a",
			"ة": "h",
			"ﻻ": "la",
			"ﻷ": "laa",
			"ﻹ": "lai",
			"ﻵ": "laa",
			"گ": "g",
			"چ": "ch",
			"پ": "p",
			"ژ": "zh",
			"ک": "k",
			"ی": "y",
			"َ": "a",
			"ً": "an",
			"ِ": "e",
			"ٍ": "en",
			"ُ": "u",
			"ٌ": "on",
			"ْ": "",
			"٠": "0",
			"١": "1",
			"٢": "2",
			"٣": "3",
			"٤": "4",
			"٥": "5",
			"٦": "6",
			"٧": "7",
			"٨": "8",
			"٩": "9",
			"۰": "0",
			"۱": "1",
			"۲": "2",
			"۳": "3",
			"۴": "4",
			"۵": "5",
			"۶": "6",
			"۷": "7",
			"۸": "8",
			"۹": "9",
			"က": "k",
			"ခ": "kh",
			"ဂ": "g",
			"ဃ": "ga",
			"င": "ng",
			"စ": "s",
			"ဆ": "sa",
			"ဇ": "z",
			"စျ": "za",
			"ည": "ny",
			"ဋ": "t",
			"ဌ": "ta",
			"ဍ": "d",
			"ဎ": "da",
			"ဏ": "na",
			"တ": "t",
			"ထ": "ta",
			"ဒ": "d",
			"ဓ": "da",
			"န": "n",
			"ပ": "p",
			"ဖ": "pa",
			"ဗ": "b",
			"ဘ": "ba",
			"မ": "m",
			"ယ": "y",
			"ရ": "ya",
			"လ": "l",
			"ဝ": "w",
			"သ": "th",
			"ဟ": "h",
			"ဠ": "la",
			"အ": "a",
			"ြ": "y",
			"ျ": "ya",
			"ွ": "w",
			"ြွ": "yw",
			"ျွ": "ywa",
			"ှ": "h",
			"ဧ": "e",
			"၏": "-e",
			"ဣ": "i",
			"ဤ": "-i",
			"ဉ": "u",
			"ဦ": "-u",
			"ဩ": "aw",
			"သြော": "aw",
			"ဪ": "aw",
			"၀": "0",
			"၁": "1",
			"၂": "2",
			"၃": "3",
			"၄": "4",
			"၅": "5",
			"၆": "6",
			"၇": "7",
			"၈": "8",
			"၉": "9",
			"္": "",
			"့": "",
			"း": "",
			"č": "c",
			"ď": "d",
			"ě": "e",
			"ň": "n",
			"ř": "r",
			"š": "s",
			"ť": "t",
			"ů": "u",
			"ž": "z",
			"Č": "C",
			"Ď": "D",
			"Ě": "E",
			"Ň": "N",
			"Ř": "R",
			"Š": "S",
			"Ť": "T",
			"Ů": "U",
			"Ž": "Z",
			"ހ": "h",
			"ށ": "sh",
			"ނ": "n",
			"ރ": "r",
			"ބ": "b",
			"ޅ": "lh",
			"ކ": "k",
			"އ": "a",
			"ވ": "v",
			"މ": "m",
			"ފ": "f",
			"ދ": "dh",
			"ތ": "th",
			"ލ": "l",
			"ގ": "g",
			"ޏ": "gn",
			"ސ": "s",
			"ޑ": "d",
			"ޒ": "z",
			"ޓ": "t",
			"ޔ": "y",
			"ޕ": "p",
			"ޖ": "j",
			"ޗ": "ch",
			"ޘ": "tt",
			"ޙ": "hh",
			"ޚ": "kh",
			"ޛ": "th",
			"ޜ": "z",
			"ޝ": "sh",
			"ޞ": "s",
			"ޟ": "d",
			"ޠ": "t",
			"ޡ": "z",
			"ޢ": "a",
			"ޣ": "gh",
			"ޤ": "q",
			"ޥ": "w",
			"ަ": "a",
			"ާ": "aa",
			"ި": "i",
			"ީ": "ee",
			"ު": "u",
			"ޫ": "oo",
			"ެ": "e",
			"ޭ": "ey",
			"ޮ": "o",
			"ޯ": "oa",
			"ް": "",
			"ა": "a",
			"ბ": "b",
			"გ": "g",
			"დ": "d",
			"ე": "e",
			"ვ": "v",
			"ზ": "z",
			"თ": "t",
			"ი": "i",
			"კ": "k",
			"ლ": "l",
			"მ": "m",
			"ნ": "n",
			"ო": "o",
			"პ": "p",
			"ჟ": "zh",
			"რ": "r",
			"ს": "s",
			"ტ": "t",
			"უ": "u",
			"ფ": "p",
			"ქ": "k",
			"ღ": "gh",
			"ყ": "q",
			"შ": "sh",
			"ჩ": "ch",
			"ც": "ts",
			"ძ": "dz",
			"წ": "ts",
			"ჭ": "ch",
			"ხ": "kh",
			"ჯ": "j",
			"ჰ": "h",
			"α": "a",
			"β": "v",
			"γ": "g",
			"δ": "d",
			"ε": "e",
			"ζ": "z",
			"η": "i",
			"θ": "th",
			"ι": "i",
			"κ": "k",
			"λ": "l",
			"μ": "m",
			"ν": "n",
			"ξ": "ks",
			"ο": "o",
			"π": "p",
			"ρ": "r",
			"σ": "s",
			"τ": "t",
			"υ": "y",
			"φ": "f",
			"χ": "x",
			"ψ": "ps",
			"ω": "o",
			"ά": "a",
			"έ": "e",
			"ί": "i",
			"ό": "o",
			"ύ": "y",
			"ή": "i",
			"ώ": "o",
			"ς": "s",
			"ϊ": "i",
			"ΰ": "y",
			"ϋ": "y",
			"ΐ": "i",
			"Α": "A",
			"Β": "B",
			"Γ": "G",
			"Δ": "D",
			"Ε": "E",
			"Ζ": "Z",
			"Η": "I",
			"Θ": "TH",
			"Ι": "I",
			"Κ": "K",
			"Λ": "L",
			"Μ": "M",
			"Ν": "N",
			"Ξ": "KS",
			"Ο": "O",
			"Π": "P",
			"Ρ": "R",
			"Σ": "S",
			"Τ": "T",
			"Υ": "Y",
			"Φ": "F",
			"Χ": "X",
			"Ψ": "PS",
			"Ω": "O",
			"Ά": "A",
			"Έ": "E",
			"Ί": "I",
			"Ό": "O",
			"Ύ": "Y",
			"Ή": "I",
			"Ώ": "O",
			"Ϊ": "I",
			"Ϋ": "Y",
			"ā": "a",
			"ē": "e",
			"ģ": "g",
			"ī": "i",
			"ķ": "k",
			"ļ": "l",
			"ņ": "n",
			"ū": "u",
			"Ā": "A",
			"Ē": "E",
			"Ģ": "G",
			"Ī": "I",
			"Ķ": "k",
			"Ļ": "L",
			"Ņ": "N",
			"Ū": "U",
			"Ќ": "Kj",
			"ќ": "kj",
			"Љ": "Lj",
			"љ": "lj",
			"Њ": "Nj",
			"њ": "nj",
			"Тс": "Ts",
			"тс": "ts",
			"ą": "a",
			"ć": "c",
			"ę": "e",
			"ł": "l",
			"ń": "n",
			"ś": "s",
			"ź": "z",
			"ż": "z",
			"Ą": "A",
			"Ć": "C",
			"Ę": "E",
			"Ł": "L",
			"Ń": "N",
			"Ś": "S",
			"Ź": "Z",
			"Ż": "Z",
			"Є": "Ye",
			"І": "I",
			"Ї": "Yi",
			"Ґ": "G",
			"є": "ye",
			"і": "i",
			"ї": "yi",
			"ґ": "g",
			"ă": "a",
			"Ă": "A",
			"ș": "s",
			"Ș": "S",
			"ț": "t",
			"Ț": "T",
			"ţ": "t",
			"Ţ": "T",
			"а": "a",
			"б": "b",
			"в": "v",
			"г": "g",
			"д": "d",
			"е": "e",
			"ё": "yo",
			"ж": "zh",
			"з": "z",
			"и": "i",
			"й": "i",
			"к": "k",
			"л": "l",
			"м": "m",
			"н": "n",
			"о": "o",
			"п": "p",
			"р": "r",
			"с": "s",
			"т": "t",
			"у": "u",
			"ф": "f",
			"х": "kh",
			"ц": "c",
			"ч": "ch",
			"ш": "sh",
			"щ": "sh",
			"ъ": "",
			"ы": "y",
			"ь": "",
			"э": "e",
			"ю": "yu",
			"я": "ya",
			"А": "A",
			"Б": "B",
			"В": "V",
			"Г": "G",
			"Д": "D",
			"Е": "E",
			"Ё": "Yo",
			"Ж": "Zh",
			"З": "Z",
			"И": "I",
			"Й": "I",
			"К": "K",
			"Л": "L",
			"М": "M",
			"Н": "N",
			"О": "O",
			"П": "P",
			"Р": "R",
			"С": "S",
			"Т": "T",
			"У": "U",
			"Ф": "F",
			"Х": "Kh",
			"Ц": "C",
			"Ч": "Ch",
			"Ш": "Sh",
			"Щ": "Sh",
			"Ъ": "",
			"Ы": "Y",
			"Ь": "",
			"Э": "E",
			"Ю": "Yu",
			"Я": "Ya",
			"ђ": "dj",
			"ј": "j",
			"ћ": "c",
			"џ": "dz",
			"Ђ": "Dj",
			"Ј": "j",
			"Ћ": "C",
			"Џ": "Dz",
			"ľ": "l",
			"ĺ": "l",
			"ŕ": "r",
			"Ľ": "L",
			"Ĺ": "L",
			"Ŕ": "R",
			"ş": "s",
			"Ş": "S",
			"ı": "i",
			"İ": "I",
			"ğ": "g",
			"Ğ": "G",
			"ả": "a",
			"Ả": "A",
			"ẳ": "a",
			"Ẳ": "A",
			"ẩ": "a",
			"Ẩ": "A",
			"đ": "d",
			"Đ": "D",
			"ẹ": "e",
			"Ẹ": "E",
			"ẽ": "e",
			"Ẽ": "E",
			"ẻ": "e",
			"Ẻ": "E",
			"ế": "e",
			"Ế": "E",
			"ề": "e",
			"Ề": "E",
			"ệ": "e",
			"Ệ": "E",
			"ễ": "e",
			"Ễ": "E",
			"ể": "e",
			"Ể": "E",
			"ỏ": "o",
			"ọ": "o",
			"Ọ": "o",
			"ố": "o",
			"Ố": "O",
			"ồ": "o",
			"Ồ": "O",
			"ổ": "o",
			"Ổ": "O",
			"ộ": "o",
			"Ộ": "O",
			"ỗ": "o",
			"Ỗ": "O",
			"ơ": "o",
			"Ơ": "O",
			"ớ": "o",
			"Ớ": "O",
			"ờ": "o",
			"Ờ": "O",
			"ợ": "o",
			"Ợ": "O",
			"ỡ": "o",
			"Ỡ": "O",
			"Ở": "o",
			"ở": "o",
			"ị": "i",
			"Ị": "I",
			"ĩ": "i",
			"Ĩ": "I",
			"ỉ": "i",
			"Ỉ": "i",
			"ủ": "u",
			"Ủ": "U",
			"ụ": "u",
			"Ụ": "U",
			"ũ": "u",
			"Ũ": "U",
			"ư": "u",
			"Ư": "U",
			"ứ": "u",
			"Ứ": "U",
			"ừ": "u",
			"Ừ": "U",
			"ự": "u",
			"Ự": "U",
			"ữ": "u",
			"Ữ": "U",
			"ử": "u",
			"Ử": "ư",
			"ỷ": "y",
			"Ỷ": "y",
			"ỳ": "y",
			"Ỳ": "Y",
			"ỵ": "y",
			"Ỵ": "Y",
			"ỹ": "y",
			"Ỹ": "Y",
			"ạ": "a",
			"Ạ": "A",
			"ấ": "a",
			"Ấ": "A",
			"ầ": "a",
			"Ầ": "A",
			"ậ": "a",
			"Ậ": "A",
			"ẫ": "a",
			"Ẫ": "A",
			"ắ": "a",
			"Ắ": "A",
			"ằ": "a",
			"Ằ": "A",
			"ặ": "a",
			"Ặ": "A",
			"ẵ": "a",
			"Ẵ": "A",
			"⓪": "0",
			"①": "1",
			"②": "2",
			"③": "3",
			"④": "4",
			"⑤": "5",
			"⑥": "6",
			"⑦": "7",
			"⑧": "8",
			"⑨": "9",
			"⑩": "10",
			"⑪": "11",
			"⑫": "12",
			"⑬": "13",
			"⑭": "14",
			"⑮": "15",
			"⑯": "16",
			"⑰": "17",
			"⑱": "18",
			"⑲": "18",
			"⑳": "18",
			"⓵": "1",
			"⓶": "2",
			"⓷": "3",
			"⓸": "4",
			"⓹": "5",
			"⓺": "6",
			"⓻": "7",
			"⓼": "8",
			"⓽": "9",
			"⓾": "10",
			"⓿": "0",
			"⓫": "11",
			"⓬": "12",
			"⓭": "13",
			"⓮": "14",
			"⓯": "15",
			"⓰": "16",
			"⓱": "17",
			"⓲": "18",
			"⓳": "19",
			"⓴": "20",
			"Ⓐ": "A",
			"Ⓑ": "B",
			"Ⓒ": "C",
			"Ⓓ": "D",
			"Ⓔ": "E",
			"Ⓕ": "F",
			"Ⓖ": "G",
			"Ⓗ": "H",
			"Ⓘ": "I",
			"Ⓙ": "J",
			"Ⓚ": "K",
			"Ⓛ": "L",
			"Ⓜ": "M",
			"Ⓝ": "N",
			"Ⓞ": "O",
			"Ⓟ": "P",
			"Ⓠ": "Q",
			"Ⓡ": "R",
			"Ⓢ": "S",
			"Ⓣ": "T",
			"Ⓤ": "U",
			"Ⓥ": "V",
			"Ⓦ": "W",
			"Ⓧ": "X",
			"Ⓨ": "Y",
			"Ⓩ": "Z",
			"ⓐ": "a",
			"ⓑ": "b",
			"ⓒ": "c",
			"ⓓ": "d",
			"ⓔ": "e",
			"ⓕ": "f",
			"ⓖ": "g",
			"ⓗ": "h",
			"ⓘ": "i",
			"ⓙ": "j",
			"ⓚ": "k",
			"ⓛ": "l",
			"ⓜ": "m",
			"ⓝ": "n",
			"ⓞ": "o",
			"ⓟ": "p",
			"ⓠ": "q",
			"ⓡ": "r",
			"ⓢ": "s",
			"ⓣ": "t",
			"ⓤ": "u",
			"ⓦ": "v",
			"ⓥ": "w",
			"ⓧ": "x",
			"ⓨ": "y",
			"ⓩ": "z",
			"“": "\"",
			"”": "\"",
			"‘": "'",
			"’": "'",
			"∂": "d",
			"ƒ": "f",
			"™": "(TM)",
			"©": "(C)",
			"œ": "oe",
			"Œ": "OE",
			"®": "(R)",
			"†": "+",
			"℠": "(SM)",
			"…": "...",
			"˚": "o",
			"º": "o",
			"ª": "a",
			"•": "*",
			"၊": ",",
			"။": ".",
			"$": "USD",
			"€": "EUR",
			"₢": "BRN",
			"₣": "FRF",
			"£": "GBP",
			"₤": "ITL",
			"₦": "NGN",
			"₧": "ESP",
			"₩": "KRW",
			"₪": "ILS",
			"₫": "VND",
			"₭": "LAK",
			"₮": "MNT",
			"₯": "GRD",
			"₱": "ARS",
			"₲": "PYG",
			"₳": "ARA",
			"₴": "UAH",
			"₵": "GHS",
			"¢": "cent",
			"¥": "CNY",
			"元": "CNY",
			"円": "YEN",
			"﷼": "IRR",
			"₠": "EWE",
			"฿": "THB",
			"₨": "INR",
			"₹": "INR",
			"₰": "PF",
			"₺": "TRY",
			"؋": "AFN",
			"₼": "AZN",
			"лв": "BGN",
			"៛": "KHR",
			"₡": "CRC",
			"₸": "KZT",
			"ден": "MKD",
			"zł": "PLN",
			"₽": "RUB",
			"₾": "GEL"
		};
		/**
		* special look ahead character array
		* These characters form with consonants to become 'single'/consonant combo
		* @type [Array]
		*/
		var lookAheadCharArray = ["်", "ް"];
		/**
		* diatricMap for languages where transliteration changes entirely as more diatrics are added
		* @type {Object}
		*/
		var diatricMap = {
			"ာ": "a",
			"ါ": "a",
			"ေ": "e",
			"ဲ": "e",
			"ိ": "i",
			"ီ": "i",
			"ို": "o",
			"ု": "u",
			"ူ": "u",
			"ေါင်": "aung",
			"ော": "aw",
			"ော်": "aw",
			"ေါ": "aw",
			"ေါ်": "aw",
			"်": "်",
			"က်": "et",
			"ိုက်": "aik",
			"ောက်": "auk",
			"င်": "in",
			"ိုင်": "aing",
			"ောင်": "aung",
			"စ်": "it",
			"ည်": "i",
			"တ်": "at",
			"ိတ်": "eik",
			"ုတ်": "ok",
			"ွတ်": "ut",
			"ေတ်": "it",
			"ဒ်": "d",
			"ိုဒ်": "ok",
			"ုဒ်": "ait",
			"န်": "an",
			"ာန်": "an",
			"ိန်": "ein",
			"ုန်": "on",
			"ွန်": "un",
			"ပ်": "at",
			"ိပ်": "eik",
			"ုပ်": "ok",
			"ွပ်": "ut",
			"န်ုပ်": "nub",
			"မ်": "an",
			"ိမ်": "ein",
			"ုမ်": "on",
			"ွမ်": "un",
			"ယ်": "e",
			"ိုလ်": "ol",
			"ဉ်": "in",
			"ံ": "an",
			"ိံ": "ein",
			"ုံ": "on",
			"ައް": "ah",
			"ަށް": "ah"
		};
		/**
		* langCharMap language specific characters translations
		* @type   {Object}
		*/
		var langCharMap = {
			"en": {},
			"az": {
				"ç": "c",
				"ə": "e",
				"ğ": "g",
				"ı": "i",
				"ö": "o",
				"ş": "s",
				"ü": "u",
				"Ç": "C",
				"Ə": "E",
				"Ğ": "G",
				"İ": "I",
				"Ö": "O",
				"Ş": "S",
				"Ü": "U"
			},
			"cs": {
				"č": "c",
				"ď": "d",
				"ě": "e",
				"ň": "n",
				"ř": "r",
				"š": "s",
				"ť": "t",
				"ů": "u",
				"ž": "z",
				"Č": "C",
				"Ď": "D",
				"Ě": "E",
				"Ň": "N",
				"Ř": "R",
				"Š": "S",
				"Ť": "T",
				"Ů": "U",
				"Ž": "Z"
			},
			"fi": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O"
			},
			"hu": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O",
				"ü": "u",
				"Ü": "U",
				"ű": "u",
				"Ű": "U"
			},
			"lt": {
				"ą": "a",
				"č": "c",
				"ę": "e",
				"ė": "e",
				"į": "i",
				"š": "s",
				"ų": "u",
				"ū": "u",
				"ž": "z",
				"Ą": "A",
				"Č": "C",
				"Ę": "E",
				"Ė": "E",
				"Į": "I",
				"Š": "S",
				"Ų": "U",
				"Ū": "U"
			},
			"lv": {
				"ā": "a",
				"č": "c",
				"ē": "e",
				"ģ": "g",
				"ī": "i",
				"ķ": "k",
				"ļ": "l",
				"ņ": "n",
				"š": "s",
				"ū": "u",
				"ž": "z",
				"Ā": "A",
				"Č": "C",
				"Ē": "E",
				"Ģ": "G",
				"Ī": "i",
				"Ķ": "k",
				"Ļ": "L",
				"Ņ": "N",
				"Š": "S",
				"Ū": "u",
				"Ž": "Z"
			},
			"pl": {
				"ą": "a",
				"ć": "c",
				"ę": "e",
				"ł": "l",
				"ń": "n",
				"ó": "o",
				"ś": "s",
				"ź": "z",
				"ż": "z",
				"Ą": "A",
				"Ć": "C",
				"Ę": "e",
				"Ł": "L",
				"Ń": "N",
				"Ó": "O",
				"Ś": "S",
				"Ź": "Z",
				"Ż": "Z"
			},
			"sv": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O"
			},
			"sk": {
				"ä": "a",
				"Ä": "A"
			},
			"sr": {
				"љ": "lj",
				"њ": "nj",
				"Љ": "Lj",
				"Њ": "Nj",
				"đ": "dj",
				"Đ": "Dj"
			},
			"tr": {
				"Ü": "U",
				"Ö": "O",
				"ü": "u",
				"ö": "o"
			}
		};
		/**
		* symbolMap language specific symbol translations
		* translations must be transliterated already
		* @type   {Object}
		*/
		var symbolMap = {
			"ar": {
				"∆": "delta",
				"∞": "la-nihaya",
				"♥": "hob",
				"&": "wa",
				"|": "aw",
				"<": "aqal-men",
				">": "akbar-men",
				"∑": "majmou",
				"¤": "omla"
			},
			"az": {},
			"ca": {
				"∆": "delta",
				"∞": "infinit",
				"♥": "amor",
				"&": "i",
				"|": "o",
				"<": "menys que",
				">": "mes que",
				"∑": "suma dels",
				"¤": "moneda"
			},
			"cs": {
				"∆": "delta",
				"∞": "nekonecno",
				"♥": "laska",
				"&": "a",
				"|": "nebo",
				"<": "mensi nez",
				">": "vetsi nez",
				"∑": "soucet",
				"¤": "mena"
			},
			"de": {
				"∆": "delta",
				"∞": "unendlich",
				"♥": "Liebe",
				"&": "und",
				"|": "oder",
				"<": "kleiner als",
				">": "groesser als",
				"∑": "Summe von",
				"¤": "Waehrung"
			},
			"dv": {
				"∆": "delta",
				"∞": "kolunulaa",
				"♥": "loabi",
				"&": "aai",
				"|": "noonee",
				"<": "ah vure kuda",
				">": "ah vure bodu",
				"∑": "jumula",
				"¤": "faisaa"
			},
			"en": {
				"∆": "delta",
				"∞": "infinity",
				"♥": "love",
				"&": "and",
				"|": "or",
				"<": "less than",
				">": "greater than",
				"∑": "sum",
				"¤": "currency"
			},
			"es": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amor",
				"&": "y",
				"|": "u",
				"<": "menos que",
				">": "mas que",
				"∑": "suma de los",
				"¤": "moneda"
			},
			"fa": {
				"∆": "delta",
				"∞": "bi-nahayat",
				"♥": "eshgh",
				"&": "va",
				"|": "ya",
				"<": "kamtar-az",
				">": "bishtar-az",
				"∑": "majmooe",
				"¤": "vahed"
			},
			"fi": {
				"∆": "delta",
				"∞": "aarettomyys",
				"♥": "rakkaus",
				"&": "ja",
				"|": "tai",
				"<": "pienempi kuin",
				">": "suurempi kuin",
				"∑": "summa",
				"¤": "valuutta"
			},
			"fr": {
				"∆": "delta",
				"∞": "infiniment",
				"♥": "Amour",
				"&": "et",
				"|": "ou",
				"<": "moins que",
				">": "superieure a",
				"∑": "somme des",
				"¤": "monnaie"
			},
			"ge": {
				"∆": "delta",
				"∞": "usasruloba",
				"♥": "siqvaruli",
				"&": "da",
				"|": "an",
				"<": "naklebi",
				">": "meti",
				"∑": "jami",
				"¤": "valuta"
			},
			"gr": {},
			"hu": {
				"∆": "delta",
				"∞": "vegtelen",
				"♥": "szerelem",
				"&": "es",
				"|": "vagy",
				"<": "kisebb mint",
				">": "nagyobb mint",
				"∑": "szumma",
				"¤": "penznem"
			},
			"it": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amore",
				"&": "e",
				"|": "o",
				"<": "minore di",
				">": "maggiore di",
				"∑": "somma",
				"¤": "moneta"
			},
			"lt": {
				"∆": "delta",
				"∞": "begalybe",
				"♥": "meile",
				"&": "ir",
				"|": "ar",
				"<": "maziau nei",
				">": "daugiau nei",
				"∑": "suma",
				"¤": "valiuta"
			},
			"lv": {
				"∆": "delta",
				"∞": "bezgaliba",
				"♥": "milestiba",
				"&": "un",
				"|": "vai",
				"<": "mazak neka",
				">": "lielaks neka",
				"∑": "summa",
				"¤": "valuta"
			},
			"my": {
				"∆": "kwahkhyaet",
				"∞": "asaonasme",
				"♥": "akhyait",
				"&": "nhin",
				"|": "tho",
				"<": "ngethaw",
				">": "kyithaw",
				"∑": "paungld",
				"¤": "ngwekye"
			},
			"mk": {},
			"nl": {
				"∆": "delta",
				"∞": "oneindig",
				"♥": "liefde",
				"&": "en",
				"|": "of",
				"<": "kleiner dan",
				">": "groter dan",
				"∑": "som",
				"¤": "valuta"
			},
			"pl": {
				"∆": "delta",
				"∞": "nieskonczonosc",
				"♥": "milosc",
				"&": "i",
				"|": "lub",
				"<": "mniejsze niz",
				">": "wieksze niz",
				"∑": "suma",
				"¤": "waluta"
			},
			"pt": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amor",
				"&": "e",
				"|": "ou",
				"<": "menor que",
				">": "maior que",
				"∑": "soma",
				"¤": "moeda"
			},
			"ro": {
				"∆": "delta",
				"∞": "infinit",
				"♥": "dragoste",
				"&": "si",
				"|": "sau",
				"<": "mai mic ca",
				">": "mai mare ca",
				"∑": "suma",
				"¤": "valuta"
			},
			"ru": {
				"∆": "delta",
				"∞": "beskonechno",
				"♥": "lubov",
				"&": "i",
				"|": "ili",
				"<": "menshe",
				">": "bolshe",
				"∑": "summa",
				"¤": "valjuta"
			},
			"sk": {
				"∆": "delta",
				"∞": "nekonecno",
				"♥": "laska",
				"&": "a",
				"|": "alebo",
				"<": "menej ako",
				">": "viac ako",
				"∑": "sucet",
				"¤": "mena"
			},
			"sr": {},
			"tr": {
				"∆": "delta",
				"∞": "sonsuzluk",
				"♥": "ask",
				"&": "ve",
				"|": "veya",
				"<": "kucuktur",
				">": "buyuktur",
				"∑": "toplam",
				"¤": "para birimi"
			},
			"uk": {
				"∆": "delta",
				"∞": "bezkinechnist",
				"♥": "lubov",
				"&": "i",
				"|": "abo",
				"<": "menshe",
				">": "bilshe",
				"∑": "suma",
				"¤": "valjuta"
			},
			"vn": {
				"∆": "delta",
				"∞": "vo cuc",
				"♥": "yeu",
				"&": "va",
				"|": "hoac",
				"<": "nho hon",
				">": "lon hon",
				"∑": "tong",
				"¤": "tien te"
			}
		};
		var uricChars = [
			";",
			"?",
			":",
			"@",
			"&",
			"=",
			"+",
			"$",
			",",
			"/"
		].join("");
		var uricNoSlashChars = [
			";",
			"?",
			":",
			"@",
			"&",
			"=",
			"+",
			"$",
			","
		].join("");
		var markChars = [
			".",
			"!",
			"~",
			"*",
			"'",
			"(",
			")"
		].join("");
		/**
		* getSlug
		* @param  {string} input input string
		* @param  {object|string} opts config object or separator string/char
		* @api    public
		* @return {string}  sluggified string
		*/
		var getSlug = function getSlug(input, opts) {
			var separator = "-";
			var result = "";
			var diatricString = "";
			var convertSymbols = true;
			var customReplacements = {};
			var maintainCase;
			var titleCase;
			var truncate;
			var uricFlag;
			var uricNoSlashFlag;
			var markFlag;
			var symbol;
			var langChar;
			var lucky;
			var i;
			var ch;
			var l;
			var lastCharWasSymbol;
			var lastCharWasDiatric;
			var allowedChars = "";
			if (typeof input !== "string") return "";
			if (typeof opts === "string") separator = opts;
			symbol = symbolMap.en;
			langChar = langCharMap.en;
			if (typeof opts === "object") {
				maintainCase = opts.maintainCase || false;
				customReplacements = opts.custom && typeof opts.custom === "object" ? opts.custom : customReplacements;
				truncate = +opts.truncate > 1 && opts.truncate || false;
				uricFlag = opts.uric || false;
				uricNoSlashFlag = opts.uricNoSlash || false;
				markFlag = opts.mark || false;
				convertSymbols = opts.symbols === false || opts.lang === false ? false : true;
				separator = opts.separator || separator;
				if (uricFlag) allowedChars += uricChars;
				if (uricNoSlashFlag) allowedChars += uricNoSlashChars;
				if (markFlag) allowedChars += markChars;
				symbol = opts.lang && symbolMap[opts.lang] && convertSymbols ? symbolMap[opts.lang] : convertSymbols ? symbolMap.en : {};
				langChar = opts.lang && langCharMap[opts.lang] ? langCharMap[opts.lang] : opts.lang === false || opts.lang === true ? {} : langCharMap.en;
				if (opts.titleCase && typeof opts.titleCase.length === "number" && Array.prototype.toString.call(opts.titleCase)) {
					opts.titleCase.forEach(function(v) {
						customReplacements[v + ""] = v + "";
					});
					titleCase = true;
				} else titleCase = !!opts.titleCase;
				if (opts.custom && typeof opts.custom.length === "number" && Array.prototype.toString.call(opts.custom)) opts.custom.forEach(function(v) {
					customReplacements[v + ""] = v + "";
				});
				Object.keys(customReplacements).forEach(function(v) {
					var r;
					if (v.length > 1) r = new RegExp("\\b" + escapeChars(v) + "\\b", "gi");
					else r = new RegExp(escapeChars(v), "gi");
					input = input.replace(r, customReplacements[v]);
				});
				for (ch in customReplacements) allowedChars += ch;
			}
			allowedChars += separator;
			allowedChars = escapeChars(allowedChars);
			input = input.replace(/(^\s+|\s+$)/g, "");
			lastCharWasSymbol = false;
			lastCharWasDiatric = false;
			for (i = 0, l = input.length; i < l; i++) {
				ch = input[i];
				if (isReplacedCustomChar(ch, customReplacements)) lastCharWasSymbol = false;
				else if (langChar[ch]) {
					ch = lastCharWasSymbol && langChar[ch].match(/[A-Za-z0-9]/) ? " " + langChar[ch] : langChar[ch];
					lastCharWasSymbol = false;
				} else if (ch in charMap) {
					if (i + 1 < l && lookAheadCharArray.indexOf(input[i + 1]) >= 0) {
						diatricString += ch;
						ch = "";
					} else if (lastCharWasDiatric === true) {
						ch = diatricMap[diatricString] + charMap[ch];
						diatricString = "";
					} else ch = lastCharWasSymbol && charMap[ch].match(/[A-Za-z0-9]/) ? " " + charMap[ch] : charMap[ch];
					lastCharWasSymbol = false;
					lastCharWasDiatric = false;
				} else if (ch in diatricMap) {
					diatricString += ch;
					ch = "";
					if (i === l - 1) ch = diatricMap[diatricString];
					lastCharWasDiatric = true;
				} else if (symbol[ch] && !(uricFlag && uricChars.indexOf(ch) !== -1) && !(uricNoSlashFlag && uricNoSlashChars.indexOf(ch) !== -1)) {
					ch = lastCharWasSymbol || result.substr(-1).match(/[A-Za-z0-9]/) ? separator + symbol[ch] : symbol[ch];
					ch += input[i + 1] !== void 0 && input[i + 1].match(/[A-Za-z0-9]/) ? separator : "";
					lastCharWasSymbol = true;
				} else {
					if (lastCharWasDiatric === true) {
						ch = diatricMap[diatricString] + ch;
						diatricString = "";
						lastCharWasDiatric = false;
					} else if (lastCharWasSymbol && (/[A-Za-z0-9]/.test(ch) || result.substr(-1).match(/A-Za-z0-9]/))) ch = " " + ch;
					lastCharWasSymbol = false;
				}
				result += ch.replace(new RegExp("[^\\w\\s" + allowedChars + "_-]", "g"), separator);
			}
			if (titleCase) result = result.replace(/(\w)(\S*)/g, function(_, i, r) {
				var j = i.toUpperCase() + (r !== null ? r : "");
				return Object.keys(customReplacements).indexOf(j.toLowerCase()) < 0 ? j : j.toLowerCase();
			});
			result = result.replace(/\s+/g, separator).replace(new RegExp("\\" + separator + "+", "g"), separator).replace(new RegExp("(^\\" + separator + "+|\\" + separator + "+$)", "g"), "");
			if (truncate && result.length > truncate) {
				lucky = result.charAt(truncate) === separator;
				result = result.slice(0, truncate);
				if (!lucky) result = result.slice(0, result.lastIndexOf(separator));
			}
			if (!maintainCase && !titleCase) result = result.toLowerCase();
			return result;
		};
		/**
		* createSlug curried(opts)(input)
		* @param   {object|string} opts config object or input string
		* @return  {Function} function getSlugWithConfig()
		**/
		var createSlug = function createSlug(opts) {
			/**
			* getSlugWithConfig
			* @param   {string} input string
			* @return  {string} slug string
			*/
			return function getSlugWithConfig(input) {
				return getSlug(input, opts);
			};
		};
		/**
		* escape Chars
		* @param   {string} input string
		*/
		var escapeChars = function escapeChars(input) {
			return input.replace(/[-\\^$*+?.()|[\]{}\/]/g, "\\$&");
		};
		/**
		* check if the char is an already converted char from custom list
		* @param   {char} ch character to check
		* @param   {object} customReplacements custom translation map
		*/
		var isReplacedCustomChar = function(ch, customReplacements) {
			for (var c in customReplacements) if (customReplacements[c] === ch) return true;
		};
		if (typeof module !== "undefined" && module.exports) {
			module.exports = getSlug;
			module.exports.createSlug = createSlug;
		} else if (typeof define !== "undefined" && define.amd) define([], function() {
			return getSlug;
		});
		else try {
			if (root.getSlug || root.createSlug) throw "speakingurl: globals exists /(getSlug|createSlug)/";
			else {
				root.getSlug = getSlug;
				root.createSlug = createSlug;
			}
		} catch (e) {}
	})(exports);
}));
//#endregion
//#region src/core/app/index.ts
var import_speakingurl = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_speakingurl$1();
})))(), 1);
const appRecordInfo = target.__VUE_DEVTOOLS_NEXT_APP_RECORD_INFO__ ??= {
	id: 0,
	appIds: /* @__PURE__ */ new Set()
};
function getAppRecordName(app, fallbackName) {
	return app?._component?.name || `App ${fallbackName}`;
}
function getAppRootInstance(app) {
	if (app._instance) return app._instance;
	else if (app._container?._vnode?.component) return app._container?._vnode?.component;
}
function removeAppRecordId(app) {
	const id = app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__;
	if (id != null) {
		appRecordInfo.appIds.delete(id);
		appRecordInfo.id--;
	}
}
function getAppRecordId(app, defaultId) {
	if (app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__ != null) return app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__;
	let id = defaultId ?? (appRecordInfo.id++).toString();
	if (defaultId && appRecordInfo.appIds.has(id)) {
		let count = 1;
		while (appRecordInfo.appIds.has(`${defaultId}_${count}`)) count++;
		id = `${defaultId}_${count}`;
	}
	appRecordInfo.appIds.add(id);
	app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__ = id;
	return id;
}
function createAppRecord(app, types) {
	const rootInstance = getAppRootInstance(app);
	if (rootInstance) {
		appRecordInfo.id++;
		const name = getAppRecordName(app, appRecordInfo.id.toString());
		const id = getAppRecordId(app, (0, import_speakingurl.default)(name));
		const [el] = getRootElementsFromComponentInstance(rootInstance);
		const record = {
			id,
			name,
			types,
			instanceMap: /* @__PURE__ */ new Map(),
			perfGroupIds: /* @__PURE__ */ new Map(),
			rootInstance,
			iframe: isBrowser && document !== el?.ownerDocument ? el?.ownerDocument?.location?.pathname : void 0
		};
		app.__VUE_DEVTOOLS_NEXT_APP_RECORD__ = record;
		const rootId = `${record.id}:root`;
		record.instanceMap.set(rootId, record.rootInstance);
		record.rootInstance.__VUE_DEVTOOLS_NEXT_UID__ = rootId;
		return record;
	} else return {};
}
//#endregion
//#region src/core/iframe/index.ts
function detectIframeApp(target, inIframe = false) {
	if (inIframe) {
		function sendEventToParent(cb) {
			try {
				const hook = window.parent.__VUE_DEVTOOLS_GLOBAL_HOOK__;
				if (hook) cb(hook);
			} catch (e) {}
		}
		const hook = {
			id: "vue-devtools-next",
			devtoolsVersion: "7.0",
			on: (event, cb) => {
				sendEventToParent((hook) => {
					hook.on(event, cb);
				});
			},
			once: (event, cb) => {
				sendEventToParent((hook) => {
					hook.once(event, cb);
				});
			},
			off: (event, cb) => {
				sendEventToParent((hook) => {
					hook.off(event, cb);
				});
			},
			emit: (event, ...payload) => {
				sendEventToParent((hook) => {
					hook.emit(event, ...payload);
				});
			}
		};
		Object.defineProperty(target, "__VUE_DEVTOOLS_GLOBAL_HOOK__", {
			get() {
				return hook;
			},
			configurable: true
		});
	}
	function injectVueHookToIframe(iframe) {
		if (iframe.__vdevtools__injected) return;
		try {
			iframe.__vdevtools__injected = true;
			const inject = () => {
				try {
					iframe.contentWindow.__VUE_DEVTOOLS_IFRAME__ = iframe;
					const script = iframe.contentDocument.createElement("script");
					script.textContent = `;(${detectIframeApp.toString()})(window, true)`;
					iframe.contentDocument.documentElement.appendChild(script);
					script.parentNode.removeChild(script);
				} catch (e) {}
			};
			inject();
			iframe.addEventListener("load", () => inject());
		} catch (e) {}
	}
	function injectVueHookToIframes() {
		if (typeof window === "undefined") return;
		const iframes = Array.from(document.querySelectorAll("iframe:not([data-vue-devtools-ignore])"));
		for (const iframe of iframes) injectVueHookToIframe(iframe);
	}
	injectVueHookToIframes();
	let iframeAppChecks = 0;
	const iframeAppCheckTimer = setInterval(() => {
		injectVueHookToIframes();
		iframeAppChecks++;
		if (iframeAppChecks >= 5) clearInterval(iframeAppCheckTimer);
	}, 1e3);
}
//#endregion
//#region src/core/index.ts
function initDevTools() {
	detectIframeApp(target);
	updateDevToolsState({ vitePluginDetected: getDevToolsEnv().vitePluginDetected });
	const isDevToolsNext = target.__VUE_DEVTOOLS_GLOBAL_HOOK__?.id === "vue-devtools-next";
	if (target.__VUE_DEVTOOLS_GLOBAL_HOOK__ && isDevToolsNext) return;
	const _devtoolsHook = createDevToolsHook();
	if (target.__VUE_DEVTOOLS_HOOK_REPLAY__) try {
		target.__VUE_DEVTOOLS_HOOK_REPLAY__.forEach((cb) => cb(_devtoolsHook));
		target.__VUE_DEVTOOLS_HOOK_REPLAY__ = [];
	} catch (e) {
		console.error("[vue-devtools] Error during hook replay", e);
	}
	_devtoolsHook.once("init", (Vue) => {
		target.__VUE_DEVTOOLS_VUE2_APP_DETECTED__ = true;
		console.log("%c[_____Vue DevTools v7 log_____]", "color: red; font-bold: 600; font-size: 16px;");
		console.log("%cVue DevTools v7 detected in your Vue2 project. v7 only supports Vue3 and will not work.", "font-bold: 500; font-size: 14px;");
		const legacyChromeUrl = "https://chromewebstore.google.com/detail/vuejs-devtools/iaajmlceplecbljialhhkmedjlpdblhp";
		const legacyFirefoxUrl = "https://addons.mozilla.org/firefox/addon/vue-js-devtools-v6-legacy";
		console.log(`%cThe legacy version of chrome extension that supports both Vue 2 and Vue 3 has been moved to %c ${legacyChromeUrl}`, "font-size: 14px;", "text-decoration: underline; cursor: pointer;font-size: 14px;");
		console.log(`%cThe legacy version of firefox extension that supports both Vue 2 and Vue 3 has been moved to %c ${legacyFirefoxUrl}`, "font-size: 14px;", "text-decoration: underline; cursor: pointer;font-size: 14px;");
		console.log("%cPlease install and enable only the legacy version for your Vue2 app.", "font-bold: 500; font-size: 14px;");
		console.log("%c[_____Vue DevTools v7 log_____]", "color: red; font-bold: 600; font-size: 16px;");
	});
	hook.on.setupDevtoolsPlugin((pluginDescriptor, setupFn) => {
		addDevToolsPluginToBuffer(pluginDescriptor, setupFn);
		const { app } = activeAppRecord ?? {};
		if (pluginDescriptor.settings) initPluginSettings(pluginDescriptor.id, pluginDescriptor.settings);
		if (!app) return;
		callDevToolsPluginSetupFn([pluginDescriptor, setupFn], app);
	});
	onLegacyDevToolsPluginApiAvailable(() => {
		devtoolsPluginBuffer.filter(([item]) => item.id !== "components").forEach(([pluginDescriptor, setupFn]) => {
			_devtoolsHook.emit(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, pluginDescriptor, setupFn, { target: "legacy" });
		});
	});
	hook.on.vueAppInit(async (app, version, types) => {
		const normalizedAppRecord = {
			...createAppRecord(app, types),
			app,
			version
		};
		addDevToolsAppRecord(normalizedAppRecord);
		if (devtoolsAppRecords.value.length === 1) {
			setActiveAppRecord(normalizedAppRecord);
			setActiveAppRecordId(normalizedAppRecord.id);
			normalizeRouterInfo(normalizedAppRecord, activeAppRecord);
			registerDevToolsPlugin(normalizedAppRecord.app);
		}
		setupDevToolsPlugin(...createComponentsDevToolsPlugin(normalizedAppRecord.app));
		updateDevToolsState({ connected: true });
		_devtoolsHook.apps.push(app);
	});
	hook.on.vueAppUnmount(async (app) => {
		const activeRecords = devtoolsAppRecords.value.filter((appRecord) => appRecord.app !== app);
		if (activeRecords.length === 0) updateDevToolsState({ connected: false });
		removeDevToolsAppRecord(app);
		removeAppRecordId(app);
		if (activeAppRecord.value.app === app) {
			setActiveAppRecord(activeRecords[0]);
			devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.SEND_ACTIVE_APP_UNMOUNTED_TO_CLIENT);
		}
		target.__VUE_DEVTOOLS_GLOBAL_HOOK__.apps.splice(target.__VUE_DEVTOOLS_GLOBAL_HOOK__.apps.indexOf(app), 1);
		removeRegisteredPluginApp(app);
	});
	subscribeDevToolsHook(_devtoolsHook);
	if (!target.__VUE_DEVTOOLS_GLOBAL_HOOK__) Object.defineProperty(target, "__VUE_DEVTOOLS_GLOBAL_HOOK__", {
		get() {
			return _devtoolsHook;
		},
		configurable: true
	});
	else if (!isNuxtApp) Object.assign(__VUE_DEVTOOLS_GLOBAL_HOOK__, _devtoolsHook);
}
function onDevToolsClientConnected(fn) {
	return new Promise((resolve) => {
		if (devtoolsState.connected && devtoolsState.clientConnected) {
			fn();
			resolve();
			return;
		}
		devtoolsContext.hooks.hook(DevToolsMessagingHookKeys.DEVTOOLS_CONNECTED_UPDATED, ({ state }) => {
			if (state.connected && state.clientConnected) {
				fn();
				resolve();
			}
		});
	});
}
//#endregion
//#region src/core/high-perf-mode/index.ts
function toggleHighPerfMode(state) {
	devtoolsState.highPerfModeEnabled = state ?? !devtoolsState.highPerfModeEnabled;
	if (!state && activeAppRecord.value) registerDevToolsPlugin(activeAppRecord.value.app);
}
//#endregion
//#region src/core/component/state/reviver.ts
function reviveSet(val) {
	const result = /* @__PURE__ */ new Set();
	const list = val._custom.value;
	for (let i = 0; i < list.length; i++) {
		const value = list[i];
		result.add(revive(value));
	}
	return result;
}
function reviveMap(val) {
	const result = /* @__PURE__ */ new Map();
	const list = val._custom.value;
	for (let i = 0; i < list.length; i++) {
		const { key, value } = list[i];
		result.set(key, revive(value));
	}
	return result;
}
function revive(val) {
	if (val === "__vue_devtool_undefined__") return;
	else if (val === "__vue_devtool_infinity__") return Number.POSITIVE_INFINITY;
	else if (val === "__vue_devtool_negative_infinity__") return Number.NEGATIVE_INFINITY;
	else if (val === "__vue_devtool_nan__") return NaN;
	else if (val && val._custom) {
		const { _custom: custom } = val;
		if (custom.type === "component") return activeAppRecord.value.instanceMap.get(custom.id);
		else if (custom.type === "map") return reviveMap(val);
		else if (custom.type === "set") return reviveSet(val);
		else if (custom.type === "bigint") return BigInt(custom.value);
		else return revive(custom.value);
	} else if (symbolRE.test(val)) {
		const [, string] = symbolRE.exec(val);
		return Symbol.for(string);
	} else if (specialTypeRE.test(val)) {
		const [, type, string, , details] = specialTypeRE.exec(val);
		const result = new target[type](string);
		if (type === "Error" && details) result.stack = details;
		return result;
	} else return val;
}
function reviver(key, value) {
	return revive(value);
}
//#endregion
//#region src/core/component/state/format.ts
function getInspectorStateValueType(value, raw = true) {
	const type = typeof value;
	if (value == null || value === "__vue_devtool_undefined__" || value === "undefined") return "null";
	else if (type === "boolean" || type === "number" || value === "__vue_devtool_infinity__" || value === "__vue_devtool_negative_infinity__" || value === "__vue_devtool_nan__") return "literal";
	else if (value?._custom) if (raw || value._custom.display != null || value._custom.displayText != null) return "custom";
	else return getInspectorStateValueType(value._custom.value);
	else if (typeof value === "string") {
		const typeMatch = specialTypeRE.exec(value);
		if (typeMatch) {
			const [, type] = typeMatch;
			return `native ${type}`;
		} else return "string";
	} else if (Array.isArray(value) || value?._isArray) return "array";
	else if (isPlainObject(value)) return "plain-object";
	else return "unknown";
}
function formatInspectorStateValue(value, quotes = false, options) {
	const { customClass } = options ?? {};
	let result;
	const type = getInspectorStateValueType(value, false);
	if (type !== "custom" && value?._custom) value = value._custom.value;
	if (result = internalStateTokenToString(value)) return result;
	else if (type === "custom") return value._custom.value?._custom && formatInspectorStateValue(value._custom.value, quotes, options) || value._custom.displayText || value._custom.display;
	else if (type === "array") return `Array[${value.length}]`;
	else if (type === "plain-object") return `Object${Object.keys(value).length ? "" : " (empty)"}`;
	else if (type?.includes("native")) return escape(specialTypeRE.exec(value)?.[2]);
	else if (typeof value === "string") {
		const typeMatch = value.match(rawTypeRE);
		if (typeMatch) value = escapeString(typeMatch[1]);
		else if (quotes) value = `<span>"</span>${customClass?.string ? `<span class=${customClass.string}>${escapeString(value)}</span>` : escapeString(value)}<span>"</span>`;
		else value = customClass?.string ? `<span class="${customClass?.string ?? ""}">${escapeString(value)}</span>` : escapeString(value);
	}
	return value;
}
function escapeString(value) {
	return escape(value).replace(/ /g, "&nbsp;").replace(/\n/g, "<span>\\n</span>");
}
function getRaw(value) {
	let customType;
	const isCustom = getInspectorStateValueType(value) === "custom";
	let inherit = {};
	if (isCustom) {
		const data = value;
		const customValue = data._custom?.value;
		const currentCustomType = data._custom?.type;
		const nestedCustom = typeof customValue === "object" && customValue !== null && "_custom" in customValue ? getRaw(customValue) : {
			inherit: void 0,
			value: void 0,
			customType: void 0
		};
		inherit = nestedCustom.inherit || data._custom?.fields || {};
		value = nestedCustom.value || customValue;
		customType = nestedCustom.customType || currentCustomType;
	}
	if (value && value._isArray) value = value.items;
	return {
		value,
		inherit,
		customType
	};
}
function toEdit(value, customType) {
	if (customType === "bigint") return value;
	if (customType === "date") return value;
	return replaceTokenToString(JSON.stringify(value));
}
function toSubmit(value, customType) {
	if (customType === "bigint") return BigInt(value);
	if (customType === "date") return new Date(value);
	return JSON.parse(replaceStringToToken(value), reviver);
}
//#endregion
//#region src/core/devtools-client/detected.ts
function updateDevToolsClientDetected(params) {
	devtoolsState.devtoolsClientDetected = {
		...devtoolsState.devtoolsClientDetected,
		...params
	};
	toggleHighPerfMode(!Object.values(devtoolsState.devtoolsClientDetected).some(Boolean));
}
target.__VUE_DEVTOOLS_UPDATE_CLIENT_DETECTED__ ??= updateDevToolsClientDetected;
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/double-indexed-kv.js
var DoubleIndexedKV = class {
	constructor() {
		this.keyToValue = /* @__PURE__ */ new Map();
		this.valueToKey = /* @__PURE__ */ new Map();
	}
	set(key, value) {
		this.keyToValue.set(key, value);
		this.valueToKey.set(value, key);
	}
	getByKey(key) {
		return this.keyToValue.get(key);
	}
	getByValue(value) {
		return this.valueToKey.get(value);
	}
	clear() {
		this.keyToValue.clear();
		this.valueToKey.clear();
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/registry.js
var Registry = class {
	constructor(generateIdentifier) {
		this.generateIdentifier = generateIdentifier;
		this.kv = new DoubleIndexedKV();
	}
	register(value, identifier) {
		if (this.kv.getByValue(value)) return;
		if (!identifier) identifier = this.generateIdentifier(value);
		this.kv.set(identifier, value);
	}
	clear() {
		this.kv.clear();
	}
	getIdentifier(value) {
		return this.kv.getByValue(value);
	}
	getValue(identifier) {
		return this.kv.getByKey(identifier);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/class-registry.js
var ClassRegistry = class extends Registry {
	constructor() {
		super((c) => c.name);
		this.classToAllowedProps = /* @__PURE__ */ new Map();
	}
	register(value, options) {
		if (typeof options === "object") {
			if (options.allowProps) this.classToAllowedProps.set(value, options.allowProps);
			super.register(value, options.identifier);
		} else super.register(value, options);
	}
	getAllowedProps(value) {
		return this.classToAllowedProps.get(value);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/util.js
function valuesOfObj(record) {
	if ("values" in Object) return Object.values(record);
	const values = [];
	for (const key in record) if (record.hasOwnProperty(key)) values.push(record[key]);
	return values;
}
function find(record, predicate) {
	const values = valuesOfObj(record);
	if ("find" in values) return values.find(predicate);
	const valuesNotNever = values;
	for (let i = 0; i < valuesNotNever.length; i++) {
		const value = valuesNotNever[i];
		if (predicate(value)) return value;
	}
}
function forEach(record, run) {
	Object.entries(record).forEach(([key, value]) => run(value, key));
}
function includes(arr, value) {
	return arr.indexOf(value) !== -1;
}
function findArr(record, predicate) {
	for (let i = 0; i < record.length; i++) {
		const value = record[i];
		if (predicate(value)) return value;
	}
}
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/custom-transformer-registry.js
var CustomTransformerRegistry = class {
	constructor() {
		this.transfomers = {};
	}
	register(transformer) {
		this.transfomers[transformer.name] = transformer;
	}
	findApplicable(v) {
		return find(this.transfomers, (transformer) => transformer.isApplicable(v));
	}
	findByName(name) {
		return this.transfomers[name];
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/is.js
const getType$1 = (payload) => Object.prototype.toString.call(payload).slice(8, -1);
const isUndefined$1 = (payload) => typeof payload === "undefined";
const isNull$1 = (payload) => payload === null;
const isPlainObject$2 = (payload) => {
	if (typeof payload !== "object" || payload === null) return false;
	if (payload === Object.prototype) return false;
	if (Object.getPrototypeOf(payload) === null) return true;
	return Object.getPrototypeOf(payload) === Object.prototype;
};
const isEmptyObject = (payload) => isPlainObject$2(payload) && Object.keys(payload).length === 0;
const isArray$2 = (payload) => Array.isArray(payload);
const isString = (payload) => typeof payload === "string";
const isNumber = (payload) => typeof payload === "number" && !isNaN(payload);
const isBoolean = (payload) => typeof payload === "boolean";
const isRegExp = (payload) => payload instanceof RegExp;
const isMap = (payload) => payload instanceof Map;
const isSet = (payload) => payload instanceof Set;
const isSymbol = (payload) => getType$1(payload) === "Symbol";
const isDate = (payload) => payload instanceof Date && !isNaN(payload.valueOf());
const isError = (payload) => payload instanceof Error;
const isNaNValue = (payload) => typeof payload === "number" && isNaN(payload);
const isPrimitive = (payload) => isBoolean(payload) || isNull$1(payload) || isUndefined$1(payload) || isNumber(payload) || isString(payload) || isSymbol(payload);
const isBigint = (payload) => typeof payload === "bigint";
const isInfinite = (payload) => payload === Infinity || payload === -Infinity;
const isTypedArray = (payload) => ArrayBuffer.isView(payload) && !(payload instanceof DataView);
const isURL = (payload) => payload instanceof URL;
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/pathstringifier.js
const escapeKey = (key) => key.replace(/\./g, "\\.");
const stringifyPath = (path) => path.map(String).map(escapeKey).join(".");
const parsePath = (string) => {
	const result = [];
	let segment = "";
	for (let i = 0; i < string.length; i++) {
		let char = string.charAt(i);
		if (char === "\\" && string.charAt(i + 1) === ".") {
			segment += ".";
			i++;
			continue;
		}
		if (char === ".") {
			result.push(segment);
			segment = "";
			continue;
		}
		segment += char;
	}
	const lastSegment = segment;
	result.push(lastSegment);
	return result;
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/transformer.js
function simpleTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
const simpleRules = [
	simpleTransformation(isUndefined$1, "undefined", () => null, () => void 0),
	simpleTransformation(isBigint, "bigint", (v) => v.toString(), (v) => {
		if (typeof BigInt !== "undefined") return BigInt(v);
		console.error("Please add a BigInt polyfill.");
		return v;
	}),
	simpleTransformation(isDate, "Date", (v) => v.toISOString(), (v) => new Date(v)),
	simpleTransformation(isError, "Error", (v, superJson) => {
		const baseError = {
			name: v.name,
			message: v.message
		};
		superJson.allowedErrorProps.forEach((prop) => {
			baseError[prop] = v[prop];
		});
		return baseError;
	}, (v, superJson) => {
		const e = new Error(v.message);
		e.name = v.name;
		e.stack = v.stack;
		superJson.allowedErrorProps.forEach((prop) => {
			e[prop] = v[prop];
		});
		return e;
	}),
	simpleTransformation(isRegExp, "regexp", (v) => "" + v, (regex) => {
		const body = regex.slice(1, regex.lastIndexOf("/"));
		const flags = regex.slice(regex.lastIndexOf("/") + 1);
		return new RegExp(body, flags);
	}),
	simpleTransformation(isSet, "set", (v) => [...v.values()], (v) => new Set(v)),
	simpleTransformation(isMap, "map", (v) => [...v.entries()], (v) => new Map(v)),
	simpleTransformation((v) => isNaNValue(v) || isInfinite(v), "number", (v) => {
		if (isNaNValue(v)) return "NaN";
		if (v > 0) return "Infinity";
		else return "-Infinity";
	}, Number),
	simpleTransformation((v) => v === 0 && 1 / v === -Infinity, "number", () => {
		return "-0";
	}, Number),
	simpleTransformation(isURL, "URL", (v) => v.toString(), (v) => new URL(v))
];
function compositeTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
const symbolRule = compositeTransformation((s, superJson) => {
	if (isSymbol(s)) return !!superJson.symbolRegistry.getIdentifier(s);
	return false;
}, (s, superJson) => {
	return ["symbol", superJson.symbolRegistry.getIdentifier(s)];
}, (v) => v.description, (_, a, superJson) => {
	const value = superJson.symbolRegistry.getValue(a[1]);
	if (!value) throw new Error("Trying to deserialize unknown symbol");
	return value;
});
const constructorToName = [
	Int8Array,
	Uint8Array,
	Int16Array,
	Uint16Array,
	Int32Array,
	Uint32Array,
	Float32Array,
	Float64Array,
	Uint8ClampedArray
].reduce((obj, ctor) => {
	obj[ctor.name] = ctor;
	return obj;
}, {});
const typedArrayRule = compositeTransformation(isTypedArray, (v) => ["typed-array", v.constructor.name], (v) => [...v], (v, a) => {
	const ctor = constructorToName[a[1]];
	if (!ctor) throw new Error("Trying to deserialize unknown typed array");
	return new ctor(v);
});
function isInstanceOfRegisteredClass(potentialClass, superJson) {
	if (potentialClass?.constructor) return !!superJson.classRegistry.getIdentifier(potentialClass.constructor);
	return false;
}
const classRule = compositeTransformation(isInstanceOfRegisteredClass, (clazz, superJson) => {
	return ["class", superJson.classRegistry.getIdentifier(clazz.constructor)];
}, (clazz, superJson) => {
	const allowedProps = superJson.classRegistry.getAllowedProps(clazz.constructor);
	if (!allowedProps) return { ...clazz };
	const result = {};
	allowedProps.forEach((prop) => {
		result[prop] = clazz[prop];
	});
	return result;
}, (v, a, superJson) => {
	const clazz = superJson.classRegistry.getValue(a[1]);
	if (!clazz) throw new Error(`Trying to deserialize unknown class '${a[1]}' - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564`);
	return Object.assign(Object.create(clazz.prototype), v);
});
const customRule = compositeTransformation((value, superJson) => {
	return !!superJson.customTransformerRegistry.findApplicable(value);
}, (value, superJson) => {
	return ["custom", superJson.customTransformerRegistry.findApplicable(value).name];
}, (value, superJson) => {
	return superJson.customTransformerRegistry.findApplicable(value).serialize(value);
}, (v, a, superJson) => {
	const transformer = superJson.customTransformerRegistry.findByName(a[1]);
	if (!transformer) throw new Error("Trying to deserialize unknown custom value");
	return transformer.deserialize(v);
});
const compositeRules = [
	classRule,
	symbolRule,
	customRule,
	typedArrayRule
];
const transformValue = (value, superJson) => {
	const applicableCompositeRule = findArr(compositeRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableCompositeRule) return {
		value: applicableCompositeRule.transform(value, superJson),
		type: applicableCompositeRule.annotation(value, superJson)
	};
	const applicableSimpleRule = findArr(simpleRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableSimpleRule) return {
		value: applicableSimpleRule.transform(value, superJson),
		type: applicableSimpleRule.annotation
	};
};
const simpleRulesByAnnotation = {};
simpleRules.forEach((rule) => {
	simpleRulesByAnnotation[rule.annotation] = rule;
});
const untransformValue = (json, type, superJson) => {
	if (isArray$2(type)) switch (type[0]) {
		case "symbol": return symbolRule.untransform(json, type, superJson);
		case "class": return classRule.untransform(json, type, superJson);
		case "custom": return customRule.untransform(json, type, superJson);
		case "typed-array": return typedArrayRule.untransform(json, type, superJson);
		default: throw new Error("Unknown transformation: " + type);
	}
	else {
		const transformation = simpleRulesByAnnotation[type];
		if (!transformation) throw new Error("Unknown transformation: " + type);
		return transformation.untransform(json, superJson);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/accessDeep.js
const getNthKey = (value, n) => {
	if (n > value.size) throw new Error("index out of bounds");
	const keys = value.keys();
	while (n > 0) {
		keys.next();
		n--;
	}
	return keys.next().value;
};
function validatePath(path) {
	if (includes(path, "__proto__")) throw new Error("__proto__ is not allowed as a property");
	if (includes(path, "prototype")) throw new Error("prototype is not allowed as a property");
	if (includes(path, "constructor")) throw new Error("constructor is not allowed as a property");
}
const getDeep = (object, path) => {
	validatePath(path);
	for (let i = 0; i < path.length; i++) {
		const key = path[i];
		if (isSet(object)) object = getNthKey(object, +key);
		else if (isMap(object)) {
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(object, row);
			switch (type) {
				case "key":
					object = keyOfRow;
					break;
				case "value":
					object = object.get(keyOfRow);
					break;
			}
		} else object = object[key];
	}
	return object;
};
const setDeep = (object, path, mapper) => {
	validatePath(path);
	if (path.length === 0) return mapper(object);
	let parent = object;
	for (let i = 0; i < path.length - 1; i++) {
		const key = path[i];
		if (isArray$2(parent)) {
			const index = +key;
			parent = parent[index];
		} else if (isPlainObject$2(parent)) parent = parent[key];
		else if (isSet(parent)) {
			const row = +key;
			parent = getNthKey(parent, row);
		} else if (isMap(parent)) {
			if (i === path.length - 2) break;
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(parent, row);
			switch (type) {
				case "key":
					parent = keyOfRow;
					break;
				case "value":
					parent = parent.get(keyOfRow);
					break;
			}
		}
	}
	const lastKey = path[path.length - 1];
	if (isArray$2(parent)) parent[+lastKey] = mapper(parent[+lastKey]);
	else if (isPlainObject$2(parent)) parent[lastKey] = mapper(parent[lastKey]);
	if (isSet(parent)) {
		const oldValue = getNthKey(parent, +lastKey);
		const newValue = mapper(oldValue);
		if (oldValue !== newValue) {
			parent.delete(oldValue);
			parent.add(newValue);
		}
	}
	if (isMap(parent)) {
		const row = +path[path.length - 2];
		const keyToRow = getNthKey(parent, row);
		switch (+lastKey === 0 ? "key" : "value") {
			case "key": {
				const newKey = mapper(keyToRow);
				parent.set(newKey, parent.get(keyToRow));
				if (newKey !== keyToRow) parent.delete(keyToRow);
				break;
			}
			case "value":
				parent.set(keyToRow, mapper(parent.get(keyToRow)));
				break;
		}
	}
	return object;
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/plainer.js
function traverse(tree, walker, origin = []) {
	if (!tree) return;
	if (!isArray$2(tree)) {
		forEach(tree, (subtree, key) => traverse(subtree, walker, [...origin, ...parsePath(key)]));
		return;
	}
	const [nodeValue, children] = tree;
	if (children) forEach(children, (child, key) => {
		traverse(child, walker, [...origin, ...parsePath(key)]);
	});
	walker(nodeValue, origin);
}
function applyValueAnnotations(plain, annotations, superJson) {
	traverse(annotations, (type, path) => {
		plain = setDeep(plain, path, (v) => untransformValue(v, type, superJson));
	});
	return plain;
}
function applyReferentialEqualityAnnotations(plain, annotations) {
	function apply(identicalPaths, path) {
		const object = getDeep(plain, parsePath(path));
		identicalPaths.map(parsePath).forEach((identicalObjectPath) => {
			plain = setDeep(plain, identicalObjectPath, () => object);
		});
	}
	if (isArray$2(annotations)) {
		const [root, other] = annotations;
		root.forEach((identicalPath) => {
			plain = setDeep(plain, parsePath(identicalPath), () => plain);
		});
		if (other) forEach(other, apply);
	} else forEach(annotations, apply);
	return plain;
}
const isDeep = (object, superJson) => isPlainObject$2(object) || isArray$2(object) || isMap(object) || isSet(object) || isInstanceOfRegisteredClass(object, superJson);
function addIdentity(object, path, identities) {
	const existingSet = identities.get(object);
	if (existingSet) existingSet.push(path);
	else identities.set(object, [path]);
}
function generateReferentialEqualityAnnotations(identitites, dedupe) {
	const result = {};
	let rootEqualityPaths = void 0;
	identitites.forEach((paths) => {
		if (paths.length <= 1) return;
		if (!dedupe) paths = paths.map((path) => path.map(String)).sort((a, b) => a.length - b.length);
		const [representativePath, ...identicalPaths] = paths;
		if (representativePath.length === 0) rootEqualityPaths = identicalPaths.map(stringifyPath);
		else result[stringifyPath(representativePath)] = identicalPaths.map(stringifyPath);
	});
	if (rootEqualityPaths) if (isEmptyObject(result)) return [rootEqualityPaths];
	else return [rootEqualityPaths, result];
	else return isEmptyObject(result) ? void 0 : result;
}
const walker = (object, identities, superJson, dedupe, path = [], objectsInThisPath = [], seenObjects = /* @__PURE__ */ new Map()) => {
	const primitive = isPrimitive(object);
	if (!primitive) {
		addIdentity(object, path, identities);
		const seen = seenObjects.get(object);
		if (seen) return dedupe ? { transformedValue: null } : seen;
	}
	if (!isDeep(object, superJson)) {
		const transformed = transformValue(object, superJson);
		const result = transformed ? {
			transformedValue: transformed.value,
			annotations: [transformed.type]
		} : { transformedValue: object };
		if (!primitive) seenObjects.set(object, result);
		return result;
	}
	if (includes(objectsInThisPath, object)) return { transformedValue: null };
	const transformationResult = transformValue(object, superJson);
	const transformed = transformationResult?.value ?? object;
	const transformedValue = isArray$2(transformed) ? [] : {};
	const innerAnnotations = {};
	forEach(transformed, (value, index) => {
		if (index === "__proto__" || index === "constructor" || index === "prototype") throw new Error(`Detected property ${index}. This is a prototype pollution risk, please remove it from your object.`);
		const recursiveResult = walker(value, identities, superJson, dedupe, [...path, index], [...objectsInThisPath, object], seenObjects);
		transformedValue[index] = recursiveResult.transformedValue;
		if (isArray$2(recursiveResult.annotations)) innerAnnotations[index] = recursiveResult.annotations;
		else if (isPlainObject$2(recursiveResult.annotations)) forEach(recursiveResult.annotations, (tree, key) => {
			innerAnnotations[escapeKey(index) + "." + key] = tree;
		});
	});
	const result = isEmptyObject(innerAnnotations) ? {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type] : void 0
	} : {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type, innerAnnotations] : innerAnnotations
	};
	if (!primitive) seenObjects.set(object, result);
	return result;
};
//#endregion
//#region ../../node_modules/.pnpm/is-what@4.1.16/node_modules/is-what/dist/index.js
function getType(payload) {
	return Object.prototype.toString.call(payload).slice(8, -1);
}
function isArray$1(payload) {
	return getType(payload) === "Array";
}
function isPlainObject$1(payload) {
	if (getType(payload) !== "Object") return false;
	const prototype = Object.getPrototypeOf(payload);
	return !!prototype && prototype.constructor === Object && prototype === Object.prototype;
}
function isNull(payload) {
	return getType(payload) === "Null";
}
function isOneOf(a, b, c, d, e) {
	return (value) => a(value) || b(value) || !!c && c(value) || !!d && d(value) || !!e && e(value);
}
function isUndefined(payload) {
	return getType(payload) === "Undefined";
}
isOneOf(isNull, isUndefined);
//#endregion
//#region ../../node_modules/.pnpm/copy-anything@3.0.5/node_modules/copy-anything/dist/index.js
function assignProp(carry, key, newVal, originalObject, includeNonenumerable) {
	const propType = {}.propertyIsEnumerable.call(originalObject, key) ? "enumerable" : "nonenumerable";
	if (propType === "enumerable") carry[key] = newVal;
	if (includeNonenumerable && propType === "nonenumerable") Object.defineProperty(carry, key, {
		value: newVal,
		enumerable: false,
		writable: true,
		configurable: true
	});
}
function copy(target, options = {}) {
	if (isArray$1(target)) return target.map((item) => copy(item, options));
	if (!isPlainObject$1(target)) return target;
	const props = Object.getOwnPropertyNames(target);
	const symbols = Object.getOwnPropertySymbols(target);
	return [...props, ...symbols].reduce((carry, key) => {
		if (isArray$1(options.props) && !options.props.includes(key)) return carry;
		const val = target[key];
		assignProp(carry, key, copy(val, options), target, options.nonenumerable);
		return carry;
	}, {});
}
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/index.js
var SuperJSON = class {
	/**
	* @param dedupeReferentialEqualities  If true, SuperJSON will make sure only one instance of referentially equal objects are serialized and the rest are replaced with `null`.
	*/
	constructor({ dedupe = false } = {}) {
		this.classRegistry = new ClassRegistry();
		this.symbolRegistry = new Registry((s) => s.description ?? "");
		this.customTransformerRegistry = new CustomTransformerRegistry();
		this.allowedErrorProps = [];
		this.dedupe = dedupe;
	}
	serialize(object) {
		const identities = /* @__PURE__ */ new Map();
		const output = walker(object, identities, this, this.dedupe);
		const res = { json: output.transformedValue };
		if (output.annotations) res.meta = {
			...res.meta,
			values: output.annotations
		};
		const equalityAnnotations = generateReferentialEqualityAnnotations(identities, this.dedupe);
		if (equalityAnnotations) res.meta = {
			...res.meta,
			referentialEqualities: equalityAnnotations
		};
		return res;
	}
	deserialize(payload) {
		const { json, meta } = payload;
		let result = copy(json);
		if (meta?.values) result = applyValueAnnotations(result, meta.values, this);
		if (meta?.referentialEqualities) result = applyReferentialEqualityAnnotations(result, meta.referentialEqualities);
		return result;
	}
	stringify(object) {
		return JSON.stringify(this.serialize(object));
	}
	parse(string) {
		return this.deserialize(JSON.parse(string));
	}
	registerClass(v, options) {
		this.classRegistry.register(v, options);
	}
	registerSymbol(v, identifier) {
		this.symbolRegistry.register(v, identifier);
	}
	registerCustom(transformer, name) {
		this.customTransformerRegistry.register({
			name,
			...transformer
		});
	}
	allowErrorProps(...props) {
		this.allowedErrorProps.push(...props);
	}
};
SuperJSON.defaultInstance = new SuperJSON();
SuperJSON.serialize = SuperJSON.defaultInstance.serialize.bind(SuperJSON.defaultInstance);
SuperJSON.deserialize = SuperJSON.defaultInstance.deserialize.bind(SuperJSON.defaultInstance);
SuperJSON.stringify = SuperJSON.defaultInstance.stringify.bind(SuperJSON.defaultInstance);
SuperJSON.parse = SuperJSON.defaultInstance.parse.bind(SuperJSON.defaultInstance);
SuperJSON.registerClass = SuperJSON.defaultInstance.registerClass.bind(SuperJSON.defaultInstance);
SuperJSON.registerSymbol = SuperJSON.defaultInstance.registerSymbol.bind(SuperJSON.defaultInstance);
SuperJSON.registerCustom = SuperJSON.defaultInstance.registerCustom.bind(SuperJSON.defaultInstance);
SuperJSON.allowErrorProps = SuperJSON.defaultInstance.allowErrorProps.bind(SuperJSON.defaultInstance);
SuperJSON.serialize;
SuperJSON.deserialize;
SuperJSON.stringify;
SuperJSON.parse;
SuperJSON.registerClass;
SuperJSON.registerCustom;
SuperJSON.registerSymbol;
SuperJSON.allowErrorProps;
//#endregion
//#region src/messaging/presets/broadcast-channel/context.ts
const __DEVTOOLS_KIT_BROADCAST_MESSAGING_EVENT_KEY = "__devtools-kit-broadcast-messaging-event-key__";
//#endregion
//#region src/messaging/presets/broadcast-channel/index.ts
const BROADCAST_CHANNEL_NAME = "__devtools-kit:broadcast-channel__";
function createBroadcastChannel() {
	const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
	return {
		post: (data) => {
			channel.postMessage(SuperJSON.stringify({
				event: __DEVTOOLS_KIT_BROADCAST_MESSAGING_EVENT_KEY,
				data
			}));
		},
		on: (handler) => {
			channel.onmessage = (event) => {
				const parsed = SuperJSON.parse(event.data);
				if (parsed.event === "__devtools-kit-broadcast-messaging-event-key__") handler(parsed.data);
			};
		}
	};
}
//#endregion
//#region src/messaging/presets/electron/context.ts
const __ELECTRON_CLIENT_CONTEXT__ = "electron:client-context";
const __ELECTRON_RPOXY_CONTEXT__ = "electron:proxy-context";
const __ELECTRON_SERVER_CONTEXT__ = "electron:server-context";
const __DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__ = {
	CLIENT_TO_PROXY: "client->proxy",
	PROXY_TO_CLIENT: "proxy->client",
	PROXY_TO_SERVER: "proxy->server",
	SERVER_TO_PROXY: "server->proxy"
};
function getElectronClientContext() {
	return target[__ELECTRON_CLIENT_CONTEXT__];
}
function setElectronClientContext(context) {
	target[__ELECTRON_CLIENT_CONTEXT__] = context;
}
function getElectronProxyContext() {
	return target[__ELECTRON_RPOXY_CONTEXT__];
}
function setElectronProxyContext(context) {
	target[__ELECTRON_RPOXY_CONTEXT__] = context;
}
function getElectronServerContext() {
	return target[__ELECTRON_SERVER_CONTEXT__];
}
function setElectronServerContext(context) {
	target[__ELECTRON_SERVER_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/electron/client.ts
function createElectronClientChannel() {
	const socket = getElectronClientContext();
	return {
		post: (data) => {
			socket.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.CLIENT_TO_PROXY, SuperJSON.stringify(data));
		},
		on: (handler) => {
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_CLIENT, (e) => {
				handler(SuperJSON.parse(e));
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/electron/proxy.ts
function createElectronProxyChannel() {
	const socket = getElectronProxyContext();
	return {
		post: (data) => {},
		on: (handler) => {
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY, (data) => {
				socket.broadcast.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_CLIENT, data);
			});
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.CLIENT_TO_PROXY, (data) => {
				socket.broadcast.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER, data);
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/electron/server.ts
function createElectronServerChannel() {
	const socket = getElectronServerContext();
	return {
		post: (data) => {
			socket.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY, SuperJSON.stringify(data));
		},
		on: (handler) => {
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER, (data) => {
				handler(SuperJSON.parse(data));
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/extension/context.ts
const __EXTENSION_CLIENT_CONTEXT__ = "electron:client-context";
const __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__ = {
	CLIENT_TO_PROXY: "client->proxy",
	PROXY_TO_CLIENT: "proxy->client",
	PROXY_TO_SERVER: "proxy->server",
	SERVER_TO_PROXY: "server->proxy"
};
function getExtensionClientContext() {
	return target[__EXTENSION_CLIENT_CONTEXT__];
}
function setExtensionClientContext(context) {
	target[__EXTENSION_CLIENT_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/extension/client.ts
function createExtensionClientChannel() {
	let disconnected = false;
	let port = null;
	let reconnectTimer = null;
	let onMessageHandler = null;
	function connect() {
		try {
			clearTimeout(reconnectTimer);
			port = chrome.runtime.connect({ name: `${chrome.devtools.inspectedWindow.tabId}` });
			setExtensionClientContext(port);
			disconnected = false;
			port?.onMessage.addListener(onMessageHandler);
			port.onDisconnect.addListener(() => {
				disconnected = true;
				port?.onMessage.removeListener(onMessageHandler);
				reconnectTimer = setTimeout(connect, 1e3);
			});
		} catch (e) {
			disconnected = true;
		}
	}
	connect();
	return {
		post: (data) => {
			if (disconnected) return;
			port?.postMessage(SuperJSON.stringify(data));
		},
		on: (handler) => {
			onMessageHandler = (data) => {
				if (disconnected) return;
				handler(SuperJSON.parse(data));
			};
			port?.onMessage.addListener(onMessageHandler);
		}
	};
}
//#endregion
//#region src/messaging/presets/extension/proxy.ts
function createExtensionProxyChannel() {
	const port = chrome.runtime.connect({ name: "content-script" });
	function sendMessageToUserApp(payload) {
		window.postMessage({
			source: __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER,
			payload
		}, "*");
	}
	function sendMessageToDevToolsClient(e) {
		if (e.data && e.data.source === __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY) try {
			port.postMessage(e.data.payload);
		} catch (e) {}
	}
	port.onMessage.addListener(sendMessageToUserApp);
	window.addEventListener("message", sendMessageToDevToolsClient);
	port.onDisconnect.addListener(() => {
		window.removeEventListener("message", sendMessageToDevToolsClient);
		sendMessageToUserApp(SuperJSON.stringify({ event: "shutdown" }));
	});
	sendMessageToUserApp(SuperJSON.stringify({ event: "init" }));
	return {
		post: (data) => {},
		on: (handler) => {}
	};
}
//#endregion
//#region src/messaging/presets/extension/server.ts
function createExtensionServerChannel() {
	return {
		post: (data) => {
			window.postMessage({
				source: __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY,
				payload: SuperJSON.stringify(data)
			}, "*");
		},
		on: (handler) => {
			const listener = (event) => {
				if (event.data.source === __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER && event.data.payload) handler(SuperJSON.parse(event.data.payload));
			};
			window.addEventListener("message", listener);
			return () => {
				window.removeEventListener("message", listener);
			};
		}
	};
}
//#endregion
//#region src/messaging/presets/iframe/context.ts
const __DEVTOOLS_KIT_IFRAME_MESSAGING_EVENT_KEY = "__devtools-kit-iframe-messaging-event-key__";
const __IFRAME_SERVER_CONTEXT__ = "iframe:server-context";
function getIframeServerContext() {
	return target[__IFRAME_SERVER_CONTEXT__];
}
function setIframeServerContext(context) {
	target[__IFRAME_SERVER_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/iframe/client.ts
function createIframeClientChannel() {
	if (!isBrowser) return {
		post: (data) => {},
		on: (handler) => {}
	};
	return {
		post: (data) => window.parent.postMessage(SuperJSON.stringify({
			event: __DEVTOOLS_KIT_IFRAME_MESSAGING_EVENT_KEY,
			data
		}), "*"),
		on: (handler) => window.addEventListener("message", (event) => {
			try {
				const parsed = SuperJSON.parse(event.data);
				if (event.source === window.parent && parsed.event === "__devtools-kit-iframe-messaging-event-key__") handler(parsed.data);
			} catch (e) {}
		})
	};
}
//#endregion
//#region src/messaging/presets/iframe/server.ts
function createIframeServerChannel() {
	if (!isBrowser) return {
		post: (data) => {},
		on: (handler) => {}
	};
	return {
		post: (data) => {
			getIframeServerContext()?.contentWindow?.postMessage(SuperJSON.stringify({
				event: __DEVTOOLS_KIT_IFRAME_MESSAGING_EVENT_KEY,
				data
			}), "*");
		},
		on: (handler) => {
			window.addEventListener("message", (event) => {
				const iframe = getIframeServerContext();
				try {
					const parsed = SuperJSON.parse(event.data);
					if (event.source === iframe?.contentWindow && parsed.event === "__devtools-kit-iframe-messaging-event-key__") handler(parsed.data);
				} catch (e) {}
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/vite/context.ts
const __DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY = "__devtools-kit-vite-messaging-event-key__";
const __VITE_CLIENT_CONTEXT__ = "vite:client-context";
const __VITE_SERVER_CONTEXT__ = "vite:server-context";
function getViteClientContext() {
	return target[__VITE_CLIENT_CONTEXT__];
}
function setViteClientContext(context) {
	target[__VITE_CLIENT_CONTEXT__] = context;
}
function getViteServerContext() {
	return target[__VITE_SERVER_CONTEXT__];
}
function setViteServerContext(context) {
	target[__VITE_SERVER_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/vite/client.ts
function createViteClientChannel() {
	const client = getViteClientContext();
	return {
		post: (data) => {
			client?.send(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, SuperJSON.stringify(data));
		},
		on: (handler) => {
			client?.on(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, (event) => {
				handler(SuperJSON.parse(event));
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/vite/server.ts
function createViteServerChannel() {
	const viteServer = getViteServerContext();
	const ws = viteServer.hot ?? viteServer.ws;
	return {
		post: (data) => ws?.send(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, SuperJSON.stringify(data)),
		on: (handler) => ws?.on(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, (event) => {
			handler(SuperJSON.parse(event));
		})
	};
}
//#endregion
//#region src/messaging/index.ts
target.__VUE_DEVTOOLS_KIT_MESSAGE_CHANNELS__ ??= [];
target.__VUE_DEVTOOLS_KIT_RPC_CLIENT__ ??= null;
target.__VUE_DEVTOOLS_KIT_RPC_SERVER__ ??= null;
target.__VUE_DEVTOOLS_KIT_VITE_RPC_CLIENT__ ??= null;
target.__VUE_DEVTOOLS_KIT_VITE_RPC_SERVER__ ??= null;
target.__VUE_DEVTOOLS_KIT_BROADCAST_RPC_SERVER__ ??= null;
function setRpcClientToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_RPC_CLIENT__ = rpc;
}
function setRpcServerToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_RPC_SERVER__ = rpc;
}
function getRpcClient() {
	return target.__VUE_DEVTOOLS_KIT_RPC_CLIENT__;
}
function getRpcServer() {
	return target.__VUE_DEVTOOLS_KIT_RPC_SERVER__;
}
function setViteRpcClientToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_VITE_RPC_CLIENT__ = rpc;
}
function setViteRpcServerToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_VITE_RPC_SERVER__ = rpc;
}
function getViteRpcClient() {
	return target.__VUE_DEVTOOLS_KIT_VITE_RPC_CLIENT__;
}
function getViteRpcServer() {
	return target.__VUE_DEVTOOLS_KIT_VITE_RPC_SERVER__;
}
function getChannel(preset, host = "client") {
	const channel = {
		iframe: {
			client: createIframeClientChannel,
			server: createIframeServerChannel
		}[host],
		electron: {
			client: createElectronClientChannel,
			proxy: createElectronProxyChannel,
			server: createElectronServerChannel
		}[host],
		vite: {
			client: createViteClientChannel,
			server: createViteServerChannel
		}[host],
		broadcast: {
			client: createBroadcastChannel,
			server: createBroadcastChannel
		}[host],
		extension: {
			client: createExtensionClientChannel,
			proxy: createExtensionProxyChannel,
			server: createExtensionServerChannel
		}[host]
	}[preset];
	return channel();
}
function createRpcClient(functions, options = {}) {
	const { channel: _channel, options: _options, preset } = options;
	const channel = preset ? getChannel(preset) : _channel;
	const rpc = createBirpc(functions, {
		..._options,
		...channel,
		timeout: -1
	});
	if (preset === "vite") {
		setViteRpcClientToGlobal(rpc);
		return;
	}
	setRpcClientToGlobal(rpc);
	return rpc;
}
function createRpcServer(functions, options = {}) {
	const { channel: _channel, options: _options, preset } = options;
	const channel = preset ? getChannel(preset, "server") : _channel;
	const rpcServer = getRpcServer();
	if (!rpcServer) {
		const group = createBirpcGroup(functions, [channel], {
			..._options,
			timeout: -1
		});
		if (preset === "vite") {
			setViteRpcServerToGlobal(group);
			return;
		}
		setRpcServerToGlobal(group);
	} else rpcServer.updateChannels((channels) => {
		channels.push(channel);
	});
}
function createRpcProxy(options = {}) {
	const { channel: _channel, options: _options, preset } = options;
	const channel = preset ? getChannel(preset, "proxy") : _channel;
	return createBirpc({}, {
		..._options,
		...channel,
		timeout: -1
	});
}
//#endregion
//#region src/core/component/state/custom.ts
function getFunctionDetails(func) {
	let string = "";
	let matches = null;
	try {
		string = Function.prototype.toString.call(func);
		matches = String.prototype.match.call(string, /\([\s\S]*?\)/);
	} catch (e) {}
	const match = matches && matches[0];
	const args = typeof match === "string" ? match : "(?)";
	return { _custom: {
		type: "function",
		displayText: `<span style="opacity:.8;margin-right:5px;">function</span> <span style="white-space:nowrap;">${escape(typeof func.name === "string" ? func.name : "")}${args}</span>`,
		tooltipText: string.trim() ? `<pre>${escape(string)}</pre>` : null
	} };
}
function getBigIntDetails(val) {
	const stringifiedBigInt = BigInt.prototype.toString.call(val);
	return { _custom: {
		type: "bigint",
		displayText: `BigInt(${stringifiedBigInt})`,
		value: stringifiedBigInt
	} };
}
function getDateDetails(val) {
	const date = new Date(val.getTime());
	date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
	return { _custom: {
		type: "date",
		displayText: Date.prototype.toString.call(val),
		value: date.toISOString().slice(0, -1)
	} };
}
function getMapDetails(val) {
	return { _custom: {
		type: "map",
		displayText: "Map",
		value: Object.fromEntries(val),
		readOnly: true,
		fields: { abstract: true }
	} };
}
function getSetDetails(val) {
	const list = Array.from(val);
	return { _custom: {
		type: "set",
		displayText: `Set[${list.length}]`,
		value: list,
		readOnly: true
	} };
}
function getCaughtGetters(store) {
	const getters = {};
	const origGetters = store.getters || {};
	const keys = Object.keys(origGetters);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		Object.defineProperty(getters, key, {
			enumerable: true,
			get: () => {
				try {
					return origGetters[key];
				} catch (e) {
					return e;
				}
			}
		});
	}
	return getters;
}
function reduceStateList(list) {
	if (!list.length) return void 0;
	return list.reduce((map, item) => {
		const key = item.type || "data";
		const obj = map[key] = map[key] || {};
		obj[item.key] = item.value;
		return map;
	}, {});
}
function namedNodeMapToObject(map) {
	const result = {};
	const l = map.length;
	for (let i = 0; i < l; i++) {
		const node = map.item(i);
		result[node.name] = node.value;
	}
	return result;
}
function getStoreDetails(store) {
	return { _custom: {
		type: "store",
		displayText: "Store",
		value: {
			state: store.state,
			getters: getCaughtGetters(store)
		},
		fields: { abstract: true }
	} };
}
function getInstanceDetails(instance) {
	if (instance._) instance = instance._;
	const state = processInstanceState(instance);
	return { _custom: {
		type: "component",
		id: instance.__VUE_DEVTOOLS_NEXT_UID__,
		displayText: getInstanceName(instance),
		tooltipText: "Component instance",
		value: reduceStateList(state),
		fields: { abstract: true }
	} };
}
function getComponentDefinitionDetails(definition) {
	let display = getComponentName(definition);
	if (display) {
		if (definition.name && definition.__file) display += ` <span>(${definition.__file})</span>`;
	} else display = "<i>Unknown Component</i>";
	return { _custom: {
		type: "component-definition",
		displayText: display,
		tooltipText: "Component definition",
		...definition.__file ? { file: definition.__file } : {}
	} };
}
function getHTMLElementDetails(value) {
	try {
		return { _custom: {
			type: "HTMLElement",
			displayText: `<span class="opacity-30">&lt;</span><span class="text-blue-500">${value.tagName.toLowerCase()}</span><span class="opacity-30">&gt;</span>`,
			value: namedNodeMapToObject(value.attributes)
		} };
	} catch (e) {
		return { _custom: {
			type: "HTMLElement",
			displayText: `<span class="text-blue-500">${String(value)}</span>`
		} };
	}
}
/**
* - ObjectRefImpl, toRef({ foo: 'foo' }, 'foo'), `_value` is the actual value, (since 3.5.0)
* - GetterRefImpl, toRef(() => state.foo), `_value` is the actual value, (since 3.5.0)
* - RefImpl, ref('foo') / computed(() => 'foo'), `_value` is the actual value
*/
function tryGetRefValue(ref) {
	if (ensurePropertyExists(ref, "_value", true)) return ref._value;
	if (ensurePropertyExists(ref, "value", true)) return ref.value;
}
function getObjectDetails(object) {
	const info = getSetupStateType(object);
	if (info.ref || info.computed || info.reactive) {
		const stateTypeName = info.computed ? "Computed" : info.ref ? "Ref" : info.reactive ? "Reactive" : null;
		const value = toRaw(info.reactive ? object : tryGetRefValue(object));
		const raw = ensurePropertyExists(object, "effect") ? object.effect?.raw?.toString() || object.effect?.fn?.toString() : null;
		return { _custom: {
			type: stateTypeName?.toLowerCase(),
			stateTypeName,
			value,
			...raw ? { tooltipText: `<pre>${escape(raw)}</pre>` } : {}
		} };
	}
	if (ensurePropertyExists(object, "__asyncLoader") && typeof object.__asyncLoader === "function") return { _custom: {
		type: "component-definition",
		display: "Async component definition"
	} };
}
//#endregion
//#region src/core/component/state/replacer.ts
function stringifyReplacer(key, _value, depth, seenInstance) {
	if (key === "compilerOptions") return;
	const val = this[key];
	const type = typeof val;
	if (Array.isArray(val)) {
		const l = val.length;
		if (l > 5e3) return {
			_isArray: true,
			length: l,
			items: val.slice(0, MAX_ARRAY_SIZE)
		};
		return val;
	} else if (typeof val === "string") if (val.length > 1e4) return `${val.substring(0, MAX_STRING_SIZE)}... (${val.length} total length)`;
	else return val;
	else if (type === "undefined") return UNDEFINED;
	else if (val === Number.POSITIVE_INFINITY) return INFINITY;
	else if (val === Number.NEGATIVE_INFINITY) return NEGATIVE_INFINITY;
	else if (typeof val === "function") return getFunctionDetails(val);
	else if (type === "symbol") return `[native Symbol ${Symbol.prototype.toString.call(val)}]`;
	else if (typeof val === "bigint") return getBigIntDetails(val);
	else if (val !== null && typeof val === "object") {
		const proto = Object.prototype.toString.call(val);
		if (proto === "[object Map]") return getMapDetails(val);
		else if (proto === "[object Set]") return getSetDetails(val);
		else if (proto === "[object RegExp]") return `[native RegExp ${RegExp.prototype.toString.call(val)}]`;
		else if (proto === "[object Date]") return getDateDetails(val);
		else if (proto === "[object Error]") return `[native Error ${val.message}<>${val.stack}]`;
		else if (ensurePropertyExists(val, "state", true) && ensurePropertyExists(val, "_vm", true)) return getStoreDetails(val);
		else if (isVueInstance(val)) {
			const componentVal = getInstanceDetails(val);
			const parentInstanceDepth = seenInstance?.get(val);
			if (parentInstanceDepth && parentInstanceDepth < depth) return `[[CircularRef]] <${componentVal._custom.displayText}>`;
			seenInstance?.set(val, depth);
			return componentVal;
		} else if (ensurePropertyExists(val, "render", true) && typeof val.render === "function") return getComponentDefinitionDetails(val);
		else if (val.constructor && val.constructor.name === "VNode") return `[native VNode <${val.tag}>]`;
		else if (typeof HTMLElement !== "undefined" && val instanceof HTMLElement) return getHTMLElementDetails(val);
		else if (val.constructor?.name === "Store" && "_wrappedGetters" in val) return "[object Store]";
		const customDetails = getObjectDetails(val);
		if (customDetails != null) return customDetails;
	} else if (Number.isNaN(val)) return NAN;
	return sanitize(val);
}
//#endregion
//#region src/shared/transfer.ts
const MAX_SERIALIZED_SIZE = 2 * 1024 * 1024;
function isObject(_data, proto) {
	return proto === "[object Object]";
}
function isArray(_data, proto) {
	return proto === "[object Array]";
}
function isVueReactiveLinkNode(node) {
	const constructorName = node?.constructor?.name;
	return constructorName === "Dep" && "activeLink" in node || constructorName === "Link" && "dep" in node;
}
/**
* This function is used to serialize object with handling circular references.
*
* ```ts
* const obj = { a: 1, b: { c: 2 }, d: obj }
* const result = stringifyCircularAutoChunks(obj) // call `encode` inside
* console.log(result) // [{"a":1,"b":2,"d":0},1,{"c":4},2]
* ```
*
* Each object is stored in a list and the index is used to reference the object.
* With seen map, we can check if the object is already stored in the list to avoid circular references.
*
* Note: here we have a special case for Vue instance.
* We check if a vue instance includes itself in its properties and skip it
* by using `seenVueInstance` and `depth` to avoid infinite loop.
*/
function encode(data, replacer, list, seen, depth = 0, seenVueInstance = /* @__PURE__ */ new Map()) {
	let stored;
	let key;
	let value;
	let i;
	let l;
	const seenIndex = seen.get(data);
	if (seenIndex != null) return seenIndex;
	const index = list.length;
	const proto = Object.prototype.toString.call(data);
	if (isObject(data, proto)) {
		if (isVueReactiveLinkNode(data)) return index;
		stored = {};
		seen.set(data, index);
		list.push(stored);
		const keys = Object.keys(data);
		for (i = 0, l = keys.length; i < l; i++) {
			key = keys[i];
			if (key === "compilerOptions") return index;
			value = data[key];
			const isVm = value != null && isObject(value, Object.prototype.toString.call(data)) && isVueInstance(value);
			try {
				if (replacer) value = replacer.call(data, key, value, depth, seenVueInstance);
			} catch (e) {
				value = e;
			}
			stored[key] = encode(value, replacer, list, seen, depth + 1, seenVueInstance);
			if (isVm) seenVueInstance.delete(value);
		}
	} else if (isArray(data, proto)) {
		stored = [];
		seen.set(data, index);
		list.push(stored);
		for (i = 0, l = data.length; i < l; i++) {
			try {
				value = data[i];
				if (replacer) value = replacer.call(data, i, value, depth, seenVueInstance);
			} catch (e) {
				value = e;
			}
			stored[i] = encode(value, replacer, list, seen, depth + 1, seenVueInstance);
		}
	} else list.push(data);
	return index;
}
function decode(list, reviver = null) {
	let i = list.length;
	let j, k, data, key, value, proto;
	while (i--) {
		data = list[i];
		proto = Object.prototype.toString.call(data);
		if (proto === "[object Object]") {
			const keys = Object.keys(data);
			for (j = 0, k = keys.length; j < k; j++) {
				key = keys[j];
				value = list[data[key]];
				if (reviver) value = reviver.call(data, key, value);
				data[key] = value;
			}
		} else if (proto === "[object Array]") for (j = 0, k = data.length; j < k; j++) {
			value = list[data[j]];
			if (reviver) value = reviver.call(data, j, value);
			data[j] = value;
		}
	}
}
function stringifyCircularAutoChunks(data, replacer = null, space = null) {
	let result;
	try {
		result = arguments.length === 1 ? JSON.stringify(data) : JSON.stringify(data, (k, v) => replacer?.(k, v)?.call(this), space);
	} catch (e) {
		result = stringifyStrictCircularAutoChunks(data, replacer, space);
	}
	if (result.length > MAX_SERIALIZED_SIZE) {
		const chunkCount = Math.ceil(result.length / MAX_SERIALIZED_SIZE);
		const chunks = [];
		for (let i = 0; i < chunkCount; i++) chunks.push(result.slice(i * MAX_SERIALIZED_SIZE, (i + 1) * MAX_SERIALIZED_SIZE));
		return chunks;
	}
	return result;
}
function stringifyStrictCircularAutoChunks(data, replacer = null, space = null) {
	const list = [];
	encode(data, replacer, list, /* @__PURE__ */ new Map());
	return space ? ` ${JSON.stringify(list, null, space)}` : ` ${JSON.stringify(list)}`;
}
function parseCircularAutoChunks(data, reviver = null) {
	if (Array.isArray(data)) data = data.join("");
	if (!/^\s/.test(data)) return arguments.length === 1 ? JSON.parse(data) : JSON.parse(data, reviver);
	else {
		const list = JSON.parse(data);
		decode(list, reviver);
		return list[0];
	}
}
//#endregion
//#region src/shared/util.ts
function stringify(data) {
	return stringifyCircularAutoChunks(data, stringifyReplacer);
}
function parse(data, revive = false) {
	if (data == void 0) return {};
	return revive ? parseCircularAutoChunks(data, reviver) : parseCircularAutoChunks(data);
}
//#endregion
//#region src/index.ts
const devtools = {
	hook,
	init: () => {
		initDevTools();
	},
	get ctx() {
		return devtoolsContext;
	},
	get api() {
		return devtoolsContext.api;
	}
};
//#endregion
export { DevToolsContextHookKeys, DevToolsMessagingHookKeys, DevToolsV6PluginAPIHookKeys, INFINITY, NAN, NEGATIVE_INFINITY, ROUTER_INFO_KEY, ROUTER_KEY, UNDEFINED, activeAppRecord, addCustomCommand, addCustomTab, addDevToolsAppRecord, addDevToolsPluginToBuffer, addInspector, callConnectedUpdatedHook, callDevToolsPluginSetupFn, callInspectorUpdatedHook, callStateUpdatedHook, createComponentsDevToolsPlugin, createDevToolsApi, createDevToolsCtxHooks, createRpcClient, createRpcProxy, createRpcServer, devtools, devtoolsAppRecords, devtoolsContext, devtoolsInspector, devtoolsPluginBuffer, devtoolsRouter, devtoolsRouterInfo, devtoolsState, escape, formatInspectorStateValue, getActiveInspectors, getDevToolsEnv, getExtensionClientContext, getInspector, getInspectorActions, getInspectorInfo, getInspectorNodeActions, getInspectorStateValueType, getRaw, getRpcClient, getRpcServer, getViteRpcClient, getViteRpcServer, initDevTools, isPlainObject, onDevToolsClientConnected, onDevToolsConnected, parse, registerDevToolsPlugin, removeCustomCommand, removeDevToolsAppRecord, removeRegisteredPluginApp, resetDevToolsState, setActiveAppRecord, setActiveAppRecordId, setDevToolsEnv, setElectronClientContext, setElectronProxyContext, setElectronServerContext, setExtensionClientContext, setIframeServerContext, setOpenInEditorBaseUrl, setRpcServerToGlobal, setViteClientContext, setViteRpcClientToGlobal, setViteRpcServerToGlobal, setViteServerContext, setupDevToolsPlugin, stringify, toEdit, toSubmit, toggleClientConnected, toggleComponentInspectorEnabled, toggleHighPerfMode, updateDevToolsClientDetected, updateDevToolsState, updateTimelineLayersState };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzP3Y9NTgzMDc4ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYmFzZW5hbWUsIGNhbWVsaXplLCBjbGFzc2lmeSwgZGVlcENsb25lLCBpc0Jyb3dzZXIsIGlzTnV4dEFwcCwgaXNVcmxTdHJpbmcsIGtlYmFiaXplLCB0YXJnZXQgfSBmcm9tIFwiL19udXh0L0Bmcy9tbnQva2lyZS9QZXJzb25hbC9Qcm9ncmFtbWluZy9Qcm9qZWN0cy9NRUlDL3dlYi9ub2RlX21vZHVsZXMvLnBucG0vQHZ1ZStkZXZ0b29scy1zaGFyZWRAOC4xLjMvbm9kZV9tb2R1bGVzL0B2dWUvZGV2dG9vbHMtc2hhcmVkL2Rpc3QvaW5kZXguanM/dj01ODMwNzhmZlwiO1xuaW1wb3J0IHsgZGVib3VuY2UgfSBmcm9tIFwiL19udXh0L0Bmcy9tbnQva2lyZS9QZXJzb25hbC9Qcm9ncmFtbWluZy9Qcm9qZWN0cy9NRUlDL3dlYi9ub2RlX21vZHVsZXMvLnBucG0vcGVyZmVjdC1kZWJvdW5jZUAyLjEuMC9ub2RlX21vZHVsZXMvcGVyZmVjdC1kZWJvdW5jZS9kaXN0L2luZGV4Lm1qcz92PTU4MzA3OGZmXCI7XG5pbXBvcnQgeyBjcmVhdGVIb29rcyB9IGZyb20gXCIvX251eHQvQGZzL21udC9raXJlL1BlcnNvbmFsL1Byb2dyYW1taW5nL1Byb2plY3RzL01FSUMvd2ViL25vZGVfbW9kdWxlcy8ucG5wbS9ob29rYWJsZUA1LjUuMy9ub2RlX21vZHVsZXMvaG9va2FibGUvZGlzdC9pbmRleC5tanM/dj01ODMwNzhmZlwiO1xuaW1wb3J0IHsgY3JlYXRlQmlycGMsIGNyZWF0ZUJpcnBjR3JvdXAgfSBmcm9tIFwiL19udXh0L0Bmcy9tbnQva2lyZS9QZXJzb25hbC9Qcm9ncmFtbWluZy9Qcm9qZWN0cy9NRUlDL3dlYi9ub2RlX21vZHVsZXMvLnBucG0vYmlycGNAMi45LjAvbm9kZV9tb2R1bGVzL2JpcnBjL2Rpc3QvaW5kZXgubWpzP3Y9NTgzMDc4ZmZcIjtcbi8vI3JlZ2lvbiBcXDByb2xsZG93bi9ydW50aW1lLmpzXG52YXIgX19jcmVhdGUgPSBPYmplY3QuY3JlYXRlO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX2dldE93blByb3BEZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcbnZhciBfX2dldE93blByb3BOYW1lcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzO1xudmFyIF9fZ2V0UHJvdG9PZiA9IE9iamVjdC5nZXRQcm90b3R5cGVPZjtcbnZhciBfX2hhc093blByb3AgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xudmFyIF9fY29tbW9uSlNNaW4gPSAoY2IsIG1vZCkgPT4gKCkgPT4gKG1vZCB8fCBjYigobW9kID0geyBleHBvcnRzOiB7fSB9KS5leHBvcnRzLCBtb2QpLCBtb2QuZXhwb3J0cyk7XG52YXIgX19jb3B5UHJvcHMgPSAodG8sIGZyb20sIGV4Y2VwdCwgZGVzYykgPT4ge1xuXHRpZiAoZnJvbSAmJiB0eXBlb2YgZnJvbSA9PT0gXCJvYmplY3RcIiB8fCB0eXBlb2YgZnJvbSA9PT0gXCJmdW5jdGlvblwiKSBmb3IgKHZhciBrZXlzID0gX19nZXRPd25Qcm9wTmFtZXMoZnJvbSksIGkgPSAwLCBuID0ga2V5cy5sZW5ndGgsIGtleTsgaSA8IG47IGkrKykge1xuXHRcdGtleSA9IGtleXNbaV07XG5cdFx0aWYgKCFfX2hhc093blByb3AuY2FsbCh0bywga2V5KSAmJiBrZXkgIT09IGV4Y2VwdCkgX19kZWZQcm9wKHRvLCBrZXksIHtcblx0XHRcdGdldDogKChrKSA9PiBmcm9tW2tdKS5iaW5kKG51bGwsIGtleSksXG5cdFx0XHRlbnVtZXJhYmxlOiAhKGRlc2MgPSBfX2dldE93blByb3BEZXNjKGZyb20sIGtleSkpIHx8IGRlc2MuZW51bWVyYWJsZVxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiB0bztcbn07XG52YXIgX190b0VTTSA9IChtb2QsIGlzTm9kZU1vZGUsIHRhcmdldCkgPT4gKHRhcmdldCA9IG1vZCAhPSBudWxsID8gX19jcmVhdGUoX19nZXRQcm90b09mKG1vZCkpIDoge30sIF9fY29weVByb3BzKGlzTm9kZU1vZGUgfHwgIW1vZCB8fCAhbW9kLl9fZXNNb2R1bGUgPyBfX2RlZlByb3AodGFyZ2V0LCBcImRlZmF1bHRcIiwge1xuXHR2YWx1ZTogbW9kLFxuXHRlbnVtZXJhYmxlOiB0cnVlXG59KSA6IHRhcmdldCwgbW9kKSk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29tcGF0L2luZGV4LnRzXG5mdW5jdGlvbiBvbkxlZ2FjeURldlRvb2xzUGx1Z2luQXBpQXZhaWxhYmxlKGNiKSB7XG5cdGlmICh0YXJnZXQuX19WVUVfREVWVE9PTFNfUExVR0lOX0FQSV9BVkFJTEFCTEVfXykge1xuXHRcdGNiKCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIFwiX19WVUVfREVWVE9PTFNfUExVR0lOX0FQSV9BVkFJTEFCTEVfX1wiLCB7XG5cdFx0c2V0KHZhbHVlKSB7XG5cdFx0XHRpZiAodmFsdWUpIGNiKCk7XG5cdFx0fSxcblx0XHRjb25maWd1cmFibGU6IHRydWVcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvdXRpbHMvaW5kZXgudHNcbmZ1bmN0aW9uIGdldENvbXBvbmVudFR5cGVOYW1lKG9wdGlvbnMpIHtcblx0aWYgKHR5cGVvZiBvcHRpb25zID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBvcHRpb25zLmRpc3BsYXlOYW1lIHx8IG9wdGlvbnMubmFtZSB8fCBvcHRpb25zLl9fVlVFX0RFVlRPT0xTX0NPTVBPTkVOVF9HVVNTRURfTkFNRV9fIHx8IFwiXCI7XG5cdGNvbnN0IG5hbWUgPSBvcHRpb25zLm5hbWUgfHwgb3B0aW9ucy5fY29tcG9uZW50VGFnIHx8IG9wdGlvbnMuX19WVUVfREVWVE9PTFNfQ09NUE9ORU5UX0dVU1NFRF9OQU1FX18gfHwgb3B0aW9ucy5fX25hbWU7XG5cdGlmIChuYW1lID09PSBcImluZGV4XCIgJiYgb3B0aW9ucy5fX2ZpbGU/LmVuZHNXaXRoKFwiaW5kZXgudnVlXCIpKSByZXR1cm4gXCJcIjtcblx0cmV0dXJuIG5hbWU7XG59XG5mdW5jdGlvbiBnZXRDb21wb25lbnRGaWxlTmFtZShvcHRpb25zKSB7XG5cdGNvbnN0IGZpbGUgPSBvcHRpb25zLl9fZmlsZTtcblx0aWYgKGZpbGUpIHJldHVybiBjbGFzc2lmeShiYXNlbmFtZShmaWxlLCBcIi52dWVcIikpO1xufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50TmFtZShvcHRpb25zKSB7XG5cdGNvbnN0IG5hbWUgPSBvcHRpb25zLmRpc3BsYXlOYW1lIHx8IG9wdGlvbnMubmFtZSB8fCBvcHRpb25zLl9jb21wb25lbnRUYWc7XG5cdGlmIChuYW1lKSByZXR1cm4gbmFtZTtcblx0cmV0dXJuIGdldENvbXBvbmVudEZpbGVOYW1lKG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gc2F2ZUNvbXBvbmVudEd1c3NlZE5hbWUoaW5zdGFuY2UsIG5hbWUpIHtcblx0aW5zdGFuY2UudHlwZS5fX1ZVRV9ERVZUT09MU19DT01QT05FTlRfR1VTU0VEX05BTUVfXyA9IG5hbWU7XG5cdHJldHVybiBuYW1lO1xufVxuZnVuY3Rpb24gZ2V0QXBwUmVjb3JkKGluc3RhbmNlKSB7XG5cdGlmIChpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfXykgcmV0dXJuIGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9fO1xuXHRlbHNlIGlmIChpbnN0YW5jZS5yb290KSByZXR1cm4gaW5zdGFuY2UuYXBwQ29udGV4dC5hcHAuX19WVUVfREVWVE9PTFNfTkVYVF9BUFBfUkVDT1JEX187XG59XG5hc3luYyBmdW5jdGlvbiBnZXRDb21wb25lbnRJZChvcHRpb25zKSB7XG5cdGNvbnN0IHsgYXBwLCB1aWQsIGluc3RhbmNlIH0gPSBvcHRpb25zO1xuXHR0cnkge1xuXHRcdGlmIChpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fKSByZXR1cm4gaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXztcblx0XHRjb25zdCBhcHBSZWNvcmQgPSBhd2FpdCBnZXRBcHBSZWNvcmQoYXBwKTtcblx0XHRpZiAoIWFwcFJlY29yZCkgcmV0dXJuIG51bGw7XG5cdFx0Y29uc3QgaXNSb290ID0gYXBwUmVjb3JkLnJvb3RJbnN0YW5jZSA9PT0gaW5zdGFuY2U7XG5cdFx0cmV0dXJuIGAke2FwcFJlY29yZC5pZH06JHtpc1Jvb3QgPyBcInJvb3RcIiA6IHVpZH1gO1xuXHR9IGNhdGNoIChlKSB7fVxufVxuZnVuY3Rpb24gaXNGcmFnbWVudChpbnN0YW5jZSkge1xuXHRjb25zdCBzdWJUcmVlVHlwZSA9IGluc3RhbmNlLnN1YlRyZWU/LnR5cGU7XG5cdGNvbnN0IGFwcFJlY29yZCA9IGdldEFwcFJlY29yZChpbnN0YW5jZSk7XG5cdGlmIChhcHBSZWNvcmQpIHJldHVybiBhcHBSZWNvcmQ/LnR5cGVzPy5GcmFnbWVudCA9PT0gc3ViVHJlZVR5cGU7XG5cdHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzQmVpbmdEZXN0cm95ZWQoaW5zdGFuY2UpIHtcblx0cmV0dXJuIGluc3RhbmNlLl9pc0JlaW5nRGVzdHJveWVkIHx8IGluc3RhbmNlLmlzVW5tb3VudGVkO1xufVxuLyoqXG4qIEdldCB0aGUgYXBwcm9wcmlhdGUgZGlzcGxheSBuYW1lIGZvciBhbiBpbnN0YW5jZS5cbipcbiogQHBhcmFtIHtWdWV9IGluc3RhbmNlXG4qIEByZXR1cm4ge3N0cmluZ31cbiovXG5mdW5jdGlvbiBnZXRJbnN0YW5jZU5hbWUoaW5zdGFuY2UpIHtcblx0Y29uc3QgbmFtZSA9IGdldENvbXBvbmVudFR5cGVOYW1lKGluc3RhbmNlPy50eXBlIHx8IHt9KTtcblx0aWYgKG5hbWUpIHJldHVybiBuYW1lO1xuXHRpZiAoaW5zdGFuY2U/LnJvb3QgPT09IGluc3RhbmNlKSByZXR1cm4gXCJSb290XCI7XG5cdGZvciAoY29uc3Qga2V5IGluIGluc3RhbmNlLnBhcmVudD8udHlwZT8uY29tcG9uZW50cykgaWYgKGluc3RhbmNlLnBhcmVudC50eXBlLmNvbXBvbmVudHNba2V5XSA9PT0gaW5zdGFuY2U/LnR5cGUpIHJldHVybiBzYXZlQ29tcG9uZW50R3Vzc2VkTmFtZShpbnN0YW5jZSwga2V5KTtcblx0Zm9yIChjb25zdCBrZXkgaW4gaW5zdGFuY2UuYXBwQ29udGV4dD8uY29tcG9uZW50cykgaWYgKGluc3RhbmNlLmFwcENvbnRleHQuY29tcG9uZW50c1trZXldID09PSBpbnN0YW5jZT8udHlwZSkgcmV0dXJuIHNhdmVDb21wb25lbnRHdXNzZWROYW1lKGluc3RhbmNlLCBrZXkpO1xuXHRjb25zdCBmaWxlTmFtZSA9IGdldENvbXBvbmVudEZpbGVOYW1lKGluc3RhbmNlPy50eXBlIHx8IHt9KTtcblx0aWYgKGZpbGVOYW1lKSByZXR1cm4gZmlsZU5hbWU7XG5cdHJldHVybiBcIkFub255bW91cyBDb21wb25lbnRcIjtcbn1cbi8qKlxuKiBSZXR1cm5zIGEgZGV2dG9vbHMgdW5pcXVlIGlkIGZvciBpbnN0YW5jZS5cbiogQHBhcmFtIHtWdWV9IGluc3RhbmNlXG4qL1xuZnVuY3Rpb24gZ2V0VW5pcXVlQ29tcG9uZW50SWQoaW5zdGFuY2UpIHtcblx0cmV0dXJuIGAke2luc3RhbmNlPy5hcHBDb250ZXh0Py5hcHA/Ll9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9JRF9fID8/IDB9OiR7aW5zdGFuY2UgPT09IGluc3RhbmNlPy5yb290ID8gXCJyb290XCIgOiBpbnN0YW5jZS51aWR9YDtcbn1cbmZ1bmN0aW9uIGdldFJlbmRlcktleSh2YWx1ZSkge1xuXHRpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIFwiXCI7XG5cdGlmICh0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIpIHJldHVybiB2YWx1ZTtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSByZXR1cm4gYCcke3ZhbHVlfSdgO1xuXHRlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIFwiQXJyYXlcIjtcblx0ZWxzZSByZXR1cm4gXCJPYmplY3RcIjtcbn1cbmZ1bmN0aW9uIHJldHVybkVycm9yKGNiKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIGNiKCk7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRyZXR1cm4gZTtcblx0fVxufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYXBwUmVjb3JkLCBpbnN0YW5jZUlkKSB7XG5cdGluc3RhbmNlSWQgPSBpbnN0YW5jZUlkIHx8IGAke2FwcFJlY29yZC5pZH06cm9vdGA7XG5cdHJldHVybiBhcHBSZWNvcmQuaW5zdGFuY2VNYXAuZ2V0KGluc3RhbmNlSWQpIHx8IGFwcFJlY29yZC5pbnN0YW5jZU1hcC5nZXQoXCI6cm9vdFwiKTtcbn1cbmZ1bmN0aW9uIGVuc3VyZVByb3BlcnR5RXhpc3RzKG9iaiwga2V5LCBza2lwT2JqQ2hlY2sgPSBmYWxzZSkge1xuXHRyZXR1cm4gc2tpcE9iakNoZWNrID8ga2V5IGluIG9iaiA6IHR5cGVvZiBvYmogPT09IFwib2JqZWN0XCIgJiYgb2JqICE9PSBudWxsID8ga2V5IGluIG9iaiA6IGZhbHNlO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL2JvdW5kaW5nLXJlY3QudHNcbmZ1bmN0aW9uIGNyZWF0ZVJlY3QoKSB7XG5cdGNvbnN0IHJlY3QgPSB7XG5cdFx0dG9wOiAwLFxuXHRcdGJvdHRvbTogMCxcblx0XHRsZWZ0OiAwLFxuXHRcdHJpZ2h0OiAwLFxuXHRcdGdldCB3aWR0aCgpIHtcblx0XHRcdHJldHVybiByZWN0LnJpZ2h0IC0gcmVjdC5sZWZ0O1xuXHRcdH0sXG5cdFx0Z2V0IGhlaWdodCgpIHtcblx0XHRcdHJldHVybiByZWN0LmJvdHRvbSAtIHJlY3QudG9wO1xuXHRcdH1cblx0fTtcblx0cmV0dXJuIHJlY3Q7XG59XG5sZXQgcmFuZ2U7XG5mdW5jdGlvbiBnZXRUZXh0UmVjdChub2RlKSB7XG5cdGlmICghcmFuZ2UpIHJhbmdlID0gZG9jdW1lbnQuY3JlYXRlUmFuZ2UoKTtcblx0cmFuZ2Uuc2VsZWN0Tm9kZShub2RlKTtcblx0cmV0dXJuIHJhbmdlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xufVxuZnVuY3Rpb24gZ2V0RnJhZ21lbnRSZWN0KHZub2RlKSB7XG5cdGNvbnN0IHJlY3QgPSBjcmVhdGVSZWN0KCk7XG5cdGlmICghdm5vZGUuY2hpbGRyZW4pIHJldHVybiByZWN0O1xuXHRmb3IgKGxldCBpID0gMCwgbCA9IHZub2RlLmNoaWxkcmVuLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuXHRcdGNvbnN0IGNoaWxkVm5vZGUgPSB2bm9kZS5jaGlsZHJlbltpXTtcblx0XHRsZXQgY2hpbGRSZWN0O1xuXHRcdGlmIChjaGlsZFZub2RlLmNvbXBvbmVudCkgY2hpbGRSZWN0ID0gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGNoaWxkVm5vZGUuY29tcG9uZW50KTtcblx0XHRlbHNlIGlmIChjaGlsZFZub2RlLmVsKSB7XG5cdFx0XHRjb25zdCBlbCA9IGNoaWxkVm5vZGUuZWw7XG5cdFx0XHRpZiAoZWwubm9kZVR5cGUgPT09IDEgfHwgZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KSBjaGlsZFJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblx0XHRcdGVsc2UgaWYgKGVsLm5vZGVUeXBlID09PSAzICYmIGVsLmRhdGEudHJpbSgpKSBjaGlsZFJlY3QgPSBnZXRUZXh0UmVjdChlbCk7XG5cdFx0fVxuXHRcdGlmIChjaGlsZFJlY3QpIG1lcmdlUmVjdHMocmVjdCwgY2hpbGRSZWN0KTtcblx0fVxuXHRyZXR1cm4gcmVjdDtcbn1cbmZ1bmN0aW9uIG1lcmdlUmVjdHMoYSwgYikge1xuXHRpZiAoIWEudG9wIHx8IGIudG9wIDwgYS50b3ApIGEudG9wID0gYi50b3A7XG5cdGlmICghYS5ib3R0b20gfHwgYi5ib3R0b20gPiBhLmJvdHRvbSkgYS5ib3R0b20gPSBiLmJvdHRvbTtcblx0aWYgKCFhLmxlZnQgfHwgYi5sZWZ0IDwgYS5sZWZ0KSBhLmxlZnQgPSBiLmxlZnQ7XG5cdGlmICghYS5yaWdodCB8fCBiLnJpZ2h0ID4gYS5yaWdodCkgYS5yaWdodCA9IGIucmlnaHQ7XG5cdHJldHVybiBhO1xufVxuY29uc3QgREVGQVVMVF9SRUNUID0ge1xuXHR0b3A6IDAsXG5cdGxlZnQ6IDAsXG5cdHJpZ2h0OiAwLFxuXHRib3R0b206IDAsXG5cdHdpZHRoOiAwLFxuXHRoZWlnaHQ6IDBcbn07XG5mdW5jdGlvbiBnZXRDb21wb25lbnRCb3VuZGluZ1JlY3QoaW5zdGFuY2UpIHtcblx0Y29uc3QgZWwgPSBpbnN0YW5jZS5zdWJUcmVlLmVsO1xuXHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIERFRkFVTFRfUkVDVDtcblx0aWYgKGlzRnJhZ21lbnQoaW5zdGFuY2UpKSByZXR1cm4gZ2V0RnJhZ21lbnRSZWN0KGluc3RhbmNlLnN1YlRyZWUpO1xuXHRlbHNlIGlmIChlbD8ubm9kZVR5cGUgPT09IDEpIHJldHVybiBlbD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdGVsc2UgaWYgKGluc3RhbmNlLnN1YlRyZWUuY29tcG9uZW50KSByZXR1cm4gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlLnN1YlRyZWUuY29tcG9uZW50KTtcblx0ZWxzZSByZXR1cm4gREVGQVVMVF9SRUNUO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3RyZWUvZWwudHNcbmZ1bmN0aW9uIGdldFJvb3RFbGVtZW50c0Zyb21Db21wb25lbnRJbnN0YW5jZShpbnN0YW5jZSkge1xuXHRpZiAoaXNGcmFnbWVudChpbnN0YW5jZSkpIHJldHVybiBnZXRGcmFnbWVudFJvb3RFbGVtZW50cyhpbnN0YW5jZS5zdWJUcmVlKTtcblx0aWYgKCFpbnN0YW5jZS5zdWJUcmVlKSByZXR1cm4gW107XG5cdHJldHVybiBbaW5zdGFuY2Uuc3ViVHJlZS5lbF07XG59XG5mdW5jdGlvbiBnZXRGcmFnbWVudFJvb3RFbGVtZW50cyh2bm9kZSkge1xuXHRpZiAoIXZub2RlLmNoaWxkcmVuKSByZXR1cm4gW107XG5cdGNvbnN0IGxpc3QgPSBbXTtcblx0dm5vZGUuY2hpbGRyZW4uZm9yRWFjaCgoY2hpbGRWbm9kZSkgPT4ge1xuXHRcdGlmIChjaGlsZFZub2RlLmNvbXBvbmVudCkgbGlzdC5wdXNoKC4uLmdldFJvb3RFbGVtZW50c0Zyb21Db21wb25lbnRJbnN0YW5jZShjaGlsZFZub2RlLmNvbXBvbmVudCkpO1xuXHRcdGVsc2UgaWYgKGNoaWxkVm5vZGU/LmVsKSBsaXN0LnB1c2goY2hpbGRWbm9kZS5lbCk7XG5cdH0pO1xuXHRyZXR1cm4gbGlzdDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC1oaWdobGlnaHRlci9pbmRleC50c1xuY29uc3QgQ09OVEFJTkVSX0VMRU1FTlRfSUQgPSBcIl9fdnVlLWRldnRvb2xzLWNvbXBvbmVudC1pbnNwZWN0b3JfX1wiO1xuY29uc3QgQ0FSRF9FTEVNRU5UX0lEID0gXCJfX3Z1ZS1kZXZ0b29scy1jb21wb25lbnQtaW5zcGVjdG9yX19jYXJkX19cIjtcbmNvbnN0IENPTVBPTkVOVF9OQU1FX0VMRU1FTlRfSUQgPSBcIl9fdnVlLWRldnRvb2xzLWNvbXBvbmVudC1pbnNwZWN0b3JfX25hbWVfX1wiO1xuY29uc3QgSU5ESUNBVE9SX0VMRU1FTlRfSUQgPSBcIl9fdnVlLWRldnRvb2xzLWNvbXBvbmVudC1pbnNwZWN0b3JfX2luZGljYXRvcl9fXCI7XG5jb25zdCBjb250YWluZXJTdHlsZXMgPSB7XG5cdGRpc3BsYXk6IFwiYmxvY2tcIixcblx0ekluZGV4OiAyMTQ3NDgzNjQwLFxuXHRwb3NpdGlvbjogXCJmaXhlZFwiLFxuXHRiYWNrZ3JvdW5kQ29sb3I6IFwiIzQyYjg4MzI1XCIsXG5cdGJvcmRlcjogXCIxcHggc29saWQgIzQyYjg4MzUwXCIsXG5cdGJvcmRlclJhZGl1czogXCI1cHhcIixcblx0dHJhbnNpdGlvbjogXCJhbGwgMC4xcyBlYXNlLWluXCIsXG5cdHBvaW50ZXJFdmVudHM6IFwibm9uZVwiXG59O1xuY29uc3QgY2FyZFN0eWxlcyA9IHtcblx0Zm9udEZhbWlseTogXCJBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmXCIsXG5cdHBhZGRpbmc6IFwiNXB4IDhweFwiLFxuXHRib3JkZXJSYWRpdXM6IFwiNHB4XCIsXG5cdHRleHRBbGlnbjogXCJsZWZ0XCIsXG5cdHBvc2l0aW9uOiBcImFic29sdXRlXCIsXG5cdGxlZnQ6IDAsXG5cdGNvbG9yOiBcIiNlOWU5ZTlcIixcblx0Zm9udFNpemU6IFwiMTRweFwiLFxuXHRmb250V2VpZ2h0OiA2MDAsXG5cdGxpbmVIZWlnaHQ6IFwiMjRweFwiLFxuXHRiYWNrZ3JvdW5kQ29sb3I6IFwiIzQyYjg4M1wiLFxuXHRib3hTaGFkb3c6IFwiMCAxcHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjEpLCAwIDFweCAycHggLTFweCByZ2JhKDAsIDAsIDAsIDAuMSlcIlxufTtcbmNvbnN0IGluZGljYXRvclN0eWxlcyA9IHtcblx0ZGlzcGxheTogXCJpbmxpbmUtYmxvY2tcIixcblx0Zm9udFdlaWdodDogNDAwLFxuXHRmb250U3R5bGU6IFwibm9ybWFsXCIsXG5cdGZvbnRTaXplOiBcIjEycHhcIixcblx0b3BhY2l0eTogLjdcbn07XG5mdW5jdGlvbiBnZXRDb250YWluZXJFbGVtZW50KCkge1xuXHRyZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoQ09OVEFJTkVSX0VMRU1FTlRfSUQpO1xufVxuZnVuY3Rpb24gZ2V0Q2FyZEVsZW1lbnQoKSB7XG5cdHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChDQVJEX0VMRU1FTlRfSUQpO1xufVxuZnVuY3Rpb24gZ2V0SW5kaWNhdG9yRWxlbWVudCgpIHtcblx0cmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKElORElDQVRPUl9FTEVNRU5UX0lEKTtcbn1cbmZ1bmN0aW9uIGdldE5hbWVFbGVtZW50KCkge1xuXHRyZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoQ09NUE9ORU5UX05BTUVfRUxFTUVOVF9JRCk7XG59XG5mdW5jdGlvbiBnZXRTdHlsZXMoYm91bmRzKSB7XG5cdHJldHVybiB7XG5cdFx0bGVmdDogYCR7TWF0aC5yb3VuZChib3VuZHMubGVmdCAqIDEwMCkgLyAxMDB9cHhgLFxuXHRcdHRvcDogYCR7TWF0aC5yb3VuZChib3VuZHMudG9wICogMTAwKSAvIDEwMH1weGAsXG5cdFx0d2lkdGg6IGAke01hdGgucm91bmQoYm91bmRzLndpZHRoICogMTAwKSAvIDEwMH1weGAsXG5cdFx0aGVpZ2h0OiBgJHtNYXRoLnJvdW5kKGJvdW5kcy5oZWlnaHQgKiAxMDApIC8gMTAwfXB4YFxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlKG9wdGlvbnMpIHtcblx0Y29uc3QgY29udGFpbmVyRWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuXHRjb250YWluZXJFbC5pZCA9IG9wdGlvbnMuZWxlbWVudElkID8/IENPTlRBSU5FUl9FTEVNRU5UX0lEO1xuXHRPYmplY3QuYXNzaWduKGNvbnRhaW5lckVsLnN0eWxlLCB7XG5cdFx0Li4uY29udGFpbmVyU3R5bGVzLFxuXHRcdC4uLmdldFN0eWxlcyhvcHRpb25zLmJvdW5kcyksXG5cdFx0Li4ub3B0aW9ucy5zdHlsZVxuXHR9KTtcblx0Y29uc3QgY2FyZEVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG5cdGNhcmRFbC5pZCA9IENBUkRfRUxFTUVOVF9JRDtcblx0T2JqZWN0LmFzc2lnbihjYXJkRWwuc3R5bGUsIHtcblx0XHQuLi5jYXJkU3R5bGVzLFxuXHRcdHRvcDogb3B0aW9ucy5ib3VuZHMudG9wIDwgMzUgPyAwIDogXCItMzVweFwiXG5cdH0pO1xuXHRjb25zdCBuYW1lRWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcblx0bmFtZUVsLmlkID0gQ09NUE9ORU5UX05BTUVfRUxFTUVOVF9JRDtcblx0bmFtZUVsLmlubmVySFRNTCA9IGAmbHQ7JHtvcHRpb25zLm5hbWV9Jmd0OyZuYnNwOyZuYnNwO2A7XG5cdGNvbnN0IGluZGljYXRvckVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImlcIik7XG5cdGluZGljYXRvckVsLmlkID0gSU5ESUNBVE9SX0VMRU1FTlRfSUQ7XG5cdGluZGljYXRvckVsLmlubmVySFRNTCA9IGAke01hdGgucm91bmQob3B0aW9ucy5ib3VuZHMud2lkdGggKiAxMDApIC8gMTAwfSB4ICR7TWF0aC5yb3VuZChvcHRpb25zLmJvdW5kcy5oZWlnaHQgKiAxMDApIC8gMTAwfWA7XG5cdE9iamVjdC5hc3NpZ24oaW5kaWNhdG9yRWwuc3R5bGUsIGluZGljYXRvclN0eWxlcyk7XG5cdGNhcmRFbC5hcHBlbmRDaGlsZChuYW1lRWwpO1xuXHRjYXJkRWwuYXBwZW5kQ2hpbGQoaW5kaWNhdG9yRWwpO1xuXHRjb250YWluZXJFbC5hcHBlbmRDaGlsZChjYXJkRWwpO1xuXHRkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGNvbnRhaW5lckVsKTtcblx0cmV0dXJuIGNvbnRhaW5lckVsO1xufVxuZnVuY3Rpb24gdXBkYXRlKG9wdGlvbnMpIHtcblx0Y29uc3QgY29udGFpbmVyRWwgPSBnZXRDb250YWluZXJFbGVtZW50KCk7XG5cdGNvbnN0IGNhcmRFbCA9IGdldENhcmRFbGVtZW50KCk7XG5cdGNvbnN0IG5hbWVFbCA9IGdldE5hbWVFbGVtZW50KCk7XG5cdGNvbnN0IGluZGljYXRvckVsID0gZ2V0SW5kaWNhdG9yRWxlbWVudCgpO1xuXHRpZiAoY29udGFpbmVyRWwpIHtcblx0XHRPYmplY3QuYXNzaWduKGNvbnRhaW5lckVsLnN0eWxlLCB7XG5cdFx0XHQuLi5jb250YWluZXJTdHlsZXMsXG5cdFx0XHQuLi5nZXRTdHlsZXMob3B0aW9ucy5ib3VuZHMpXG5cdFx0fSk7XG5cdFx0T2JqZWN0LmFzc2lnbihjYXJkRWwuc3R5bGUsIHsgdG9wOiBvcHRpb25zLmJvdW5kcy50b3AgPCAzNSA/IDAgOiBcIi0zNXB4XCIgfSk7XG5cdFx0bmFtZUVsLmlubmVySFRNTCA9IGAmbHQ7JHtvcHRpb25zLm5hbWV9Jmd0OyZuYnNwOyZuYnNwO2A7XG5cdFx0aW5kaWNhdG9yRWwuaW5uZXJIVE1MID0gYCR7TWF0aC5yb3VuZChvcHRpb25zLmJvdW5kcy53aWR0aCAqIDEwMCkgLyAxMDB9IHggJHtNYXRoLnJvdW5kKG9wdGlvbnMuYm91bmRzLmhlaWdodCAqIDEwMCkgLyAxMDB9YDtcblx0fVxufVxuZnVuY3Rpb24gaGlnaGxpZ2h0KGluc3RhbmNlKSB7XG5cdGNvbnN0IGJvdW5kcyA9IGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChpbnN0YW5jZSk7XG5cdGlmICghYm91bmRzLndpZHRoICYmICFib3VuZHMuaGVpZ2h0KSByZXR1cm47XG5cdGNvbnN0IG5hbWUgPSBnZXRJbnN0YW5jZU5hbWUoaW5zdGFuY2UpO1xuXHRnZXRDb250YWluZXJFbGVtZW50KCkgPyB1cGRhdGUoe1xuXHRcdGJvdW5kcyxcblx0XHRuYW1lXG5cdH0pIDogY3JlYXRlKHtcblx0XHRib3VuZHMsXG5cdFx0bmFtZVxuXHR9KTtcbn1cbmZ1bmN0aW9uIHVuaGlnaGxpZ2h0KCkge1xuXHRjb25zdCBlbCA9IGdldENvbnRhaW5lckVsZW1lbnQoKTtcblx0aWYgKGVsKSBlbC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG59XG5sZXQgaW5zcGVjdEluc3RhbmNlID0gbnVsbDtcbmZ1bmN0aW9uIGluc3BlY3RGbihlKSB7XG5cdGNvbnN0IHRhcmdldCA9IGUudGFyZ2V0O1xuXHRpZiAodGFyZ2V0KSB7XG5cdFx0Y29uc3QgaW5zdGFuY2UgPSB0YXJnZXQuX192dWVQYXJlbnRDb21wb25lbnQ7XG5cdFx0aWYgKGluc3RhbmNlKSB7XG5cdFx0XHRpbnNwZWN0SW5zdGFuY2UgPSBpbnN0YW5jZTtcblx0XHRcdGlmIChpbnN0YW5jZS52bm9kZS5lbCkge1xuXHRcdFx0XHRjb25zdCBib3VuZHMgPSBnZXRDb21wb25lbnRCb3VuZGluZ1JlY3QoaW5zdGFuY2UpO1xuXHRcdFx0XHRjb25zdCBuYW1lID0gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKTtcblx0XHRcdFx0Z2V0Q29udGFpbmVyRWxlbWVudCgpID8gdXBkYXRlKHtcblx0XHRcdFx0XHRib3VuZHMsXG5cdFx0XHRcdFx0bmFtZVxuXHRcdFx0XHR9KSA6IGNyZWF0ZSh7XG5cdFx0XHRcdFx0Ym91bmRzLFxuXHRcdFx0XHRcdG5hbWVcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59XG5mdW5jdGlvbiBzZWxlY3RDb21wb25lbnRGbihlLCBjYikge1xuXHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdGUuc3RvcFByb3BhZ2F0aW9uKCk7XG5cdGlmIChpbnNwZWN0SW5zdGFuY2UpIGNiKGdldFVuaXF1ZUNvbXBvbmVudElkKGluc3BlY3RJbnN0YW5jZSkpO1xufVxubGV0IGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlclNlbGVjdEZuID0gbnVsbDtcbmZ1bmN0aW9uIGNhbmNlbEluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlcigpIHtcblx0dW5oaWdobGlnaHQoKTtcblx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgaW5zcGVjdEZuKTtcblx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBpbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXJTZWxlY3RGbiwgdHJ1ZSk7XG5cdGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlclNlbGVjdEZuID0gbnVsbDtcbn1cbmZ1bmN0aW9uIGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlcigpIHtcblx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgaW5zcGVjdEZuKTtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0ZnVuY3Rpb24gb25TZWxlY3QoZSkge1xuXHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblx0XHRcdHNlbGVjdENvbXBvbmVudEZuKGUsIChpZCkgPT4ge1xuXHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIG9uU2VsZWN0LCB0cnVlKTtcblx0XHRcdFx0aW5zcGVjdENvbXBvbmVudEhpZ2hMaWdodGVyU2VsZWN0Rm4gPSBudWxsO1xuXHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1vdXNlb3ZlclwiLCBpbnNwZWN0Rm4pO1xuXHRcdFx0XHRjb25zdCBlbCA9IGdldENvbnRhaW5lckVsZW1lbnQoKTtcblx0XHRcdFx0aWYgKGVsKSBlbC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG5cdFx0XHRcdHJlc29sdmUoSlNPTi5zdHJpbmdpZnkoeyBpZCB9KSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0aW5zcGVjdENvbXBvbmVudEhpZ2hMaWdodGVyU2VsZWN0Rm4gPSBvblNlbGVjdDtcblx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIG9uU2VsZWN0LCB0cnVlKTtcblx0fSk7XG59XG5mdW5jdGlvbiBzY3JvbGxUb0NvbXBvbmVudChvcHRpb25zKSB7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBvcHRpb25zLmlkKTtcblx0aWYgKGluc3RhbmNlKSB7XG5cdFx0Y29uc3QgW2VsXSA9IGdldFJvb3RFbGVtZW50c0Zyb21Db21wb25lbnRJbnN0YW5jZShpbnN0YW5jZSk7XG5cdFx0aWYgKHR5cGVvZiBlbC5zY3JvbGxJbnRvVmlldyA9PT0gXCJmdW5jdGlvblwiKSBlbC5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiBcInNtb290aFwiIH0pO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgYm91bmRzID0gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlKTtcblx0XHRcdGNvbnN0IHNjcm9sbFRhcmdldCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG5cdFx0XHRjb25zdCBzdHlsZXMgPSB7XG5cdFx0XHRcdC4uLmdldFN0eWxlcyhib3VuZHMpLFxuXHRcdFx0XHRwb3NpdGlvbjogXCJhYnNvbHV0ZVwiXG5cdFx0XHR9O1xuXHRcdFx0T2JqZWN0LmFzc2lnbihzY3JvbGxUYXJnZXQuc3R5bGUsIHN0eWxlcyk7XG5cdFx0XHRkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNjcm9sbFRhcmdldCk7XG5cdFx0XHRzY3JvbGxUYXJnZXQuc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcblx0XHRcdHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHRkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHNjcm9sbFRhcmdldCk7XG5cdFx0XHR9LCAyZTMpO1xuXHRcdH1cblx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdGNvbnN0IGJvdW5kcyA9IGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChpbnN0YW5jZSk7XG5cdFx0XHRpZiAoYm91bmRzLndpZHRoIHx8IGJvdW5kcy5oZWlnaHQpIHtcblx0XHRcdFx0Y29uc3QgbmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdFx0XHRcdGNvbnN0IGVsID0gZ2V0Q29udGFpbmVyRWxlbWVudCgpO1xuXHRcdFx0XHRlbCA/IHVwZGF0ZSh7XG5cdFx0XHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdFx0XHRuYW1lLFxuXHRcdFx0XHRcdGJvdW5kc1xuXHRcdFx0XHR9KSA6IGNyZWF0ZSh7XG5cdFx0XHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdFx0XHRuYW1lLFxuXHRcdFx0XHRcdGJvdW5kc1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0c2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVsKSBlbC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG5cdFx0XHRcdH0sIDE1MDApO1xuXHRcdFx0fVxuXHRcdH0sIDEyMDApO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQtaW5zcGVjdG9yL2luZGV4LnRzXG50YXJnZXQuX19WVUVfREVWVE9PTFNfQ09NUE9ORU5UX0lOU1BFQ1RPUl9FTkFCTEVEX18gPz89IHRydWU7XG5mdW5jdGlvbiB0b2dnbGVDb21wb25lbnRJbnNwZWN0b3JFbmFibGVkKGVuYWJsZWQpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0NPTVBPTkVOVF9JTlNQRUNUT1JfRU5BQkxFRF9fID0gZW5hYmxlZDtcbn1cbmZ1bmN0aW9uIHdhaXRGb3JJbnNwZWN0b3JJbml0KGNiKSB7XG5cdGxldCB0b3RhbCA9IDA7XG5cdGNvbnN0IHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuXHRcdGlmICh0YXJnZXQuX19WVUVfSU5TUEVDVE9SX18pIHtcblx0XHRcdGNsZWFySW50ZXJ2YWwodGltZXIpO1xuXHRcdFx0dG90YWwgKz0gMzA7XG5cdFx0XHRjYigpO1xuXHRcdH1cblx0XHRpZiAodG90YWwgPj0gNWUzKSBjbGVhckludGVydmFsKHRpbWVyKTtcblx0fSwgMzApO1xufVxuZnVuY3Rpb24gc2V0dXBJbnNwZWN0b3IoKSB7XG5cdGNvbnN0IGluc3BlY3RvciA9IHRhcmdldC5fX1ZVRV9JTlNQRUNUT1JfXztcblx0Y29uc3QgX29wZW5JbkVkaXRvciA9IGluc3BlY3Rvci5vcGVuSW5FZGl0b3I7XG5cdGluc3BlY3Rvci5vcGVuSW5FZGl0b3IgPSBhc3luYyAoLi4ucGFyYW1zKSA9PiB7XG5cdFx0aW5zcGVjdG9yLmRpc2FibGUoKTtcblx0XHRfb3BlbkluRWRpdG9yKC4uLnBhcmFtcyk7XG5cdH07XG59XG5mdW5jdGlvbiBnZXRDb21wb25lbnRJbnNwZWN0b3IoKSB7XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdGZ1bmN0aW9uIHNldHVwKCkge1xuXHRcdFx0c2V0dXBJbnNwZWN0b3IoKTtcblx0XHRcdHJlc29sdmUodGFyZ2V0Ll9fVlVFX0lOU1BFQ1RPUl9fKTtcblx0XHR9XG5cdFx0aWYgKCF0YXJnZXQuX19WVUVfSU5TUEVDVE9SX18pIHdhaXRGb3JJbnNwZWN0b3JJbml0KCgpID0+IHtcblx0XHRcdHNldHVwKCk7XG5cdFx0fSk7XG5cdFx0ZWxzZSBzZXR1cCgpO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zaGFyZWQvc3R1Yi12dWUudHNcbi8qKlxuKiBUbyBwcmV2ZW50IGluY2x1ZGUgYSAqKkhVR0UqKiB2dWUgcGFja2FnZSBpbiB0aGUgZmluYWwgYnVuZGxlIG9mIGNocm9tZSBleHQgLyBlbGVjdHJvblxuKiB3ZSBzdHViIHRoZSBuZWNlc3NhcnkgdnVlIG1vZHVsZS5cbiogVGhpcyBpbXBsZW1lbnRhdGlvbiBpcyBiYXNlZCBvbiB0aGUgMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNSBjb21taXRcbiovXG4vKipcbiogQGZyb20gW0B2dWUvcmVhY3Rpdml0eV0oaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL2NvcmUvYmxvYi8xYzMzMjdhMGZhNTk4M2FhOTA3OGUzZjdiYjIzMzBmNTcyNDM1NDI1L3BhY2thZ2VzL3JlYWN0aXZpdHkvc3JjL2NvbnN0YW50cy50cyNMMTctTDIzKVxuKi9cbmxldCBSZWFjdGl2ZUZsYWdzID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKFJlYWN0aXZlRmxhZ3MpIHtcblx0UmVhY3RpdmVGbGFnc1tcIlNLSVBcIl0gPSBcIl9fdl9za2lwXCI7XG5cdFJlYWN0aXZlRmxhZ3NbXCJJU19SRUFDVElWRVwiXSA9IFwiX192X2lzUmVhY3RpdmVcIjtcblx0UmVhY3RpdmVGbGFnc1tcIklTX1JFQURPTkxZXCJdID0gXCJfX3ZfaXNSZWFkb25seVwiO1xuXHRSZWFjdGl2ZUZsYWdzW1wiSVNfU0hBTExPV1wiXSA9IFwiX192X2lzU2hhbGxvd1wiO1xuXHRSZWFjdGl2ZUZsYWdzW1wiUkFXXCJdID0gXCJfX3ZfcmF3XCI7XG5cdHJldHVybiBSZWFjdGl2ZUZsYWdzO1xufSh7fSk7XG4vKipcbiogQGZyb20gW0B2dWUvcmVhY3Rpdml0eV0oaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL2NvcmUvYmxvYi8xYzMzMjdhMGZhNTk4M2FhOTA3OGUzZjdiYjIzMzBmNTcyNDM1NDI1L3BhY2thZ2VzL3JlYWN0aXZpdHkvc3JjL3JlYWN0aXZlLnRzI0wzMzAtTDMzMilcbiovXG5mdW5jdGlvbiBpc1JlYWRvbmx5KHZhbHVlKSB7XG5cdHJldHVybiAhISh2YWx1ZSAmJiB2YWx1ZVtSZWFjdGl2ZUZsYWdzLklTX1JFQURPTkxZXSk7XG59XG4vKipcbiogQGZyb20gW0B2dWUvcmVhY3Rpdml0eV0oaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL2NvcmUvYmxvYi8xYzMzMjdhMGZhNTk4M2FhOTA3OGUzZjdiYjIzMzBmNTcyNDM1NDI1L3BhY2thZ2VzL3JlYWN0aXZpdHkvc3JjL3JlYWN0aXZlLnRzI0wzMTItTDMxNylcbiovXG5mdW5jdGlvbiBpc1JlYWN0aXZlJDEodmFsdWUpIHtcblx0aWYgKGlzUmVhZG9ubHkodmFsdWUpKSByZXR1cm4gaXNSZWFjdGl2ZSQxKHZhbHVlW1JlYWN0aXZlRmxhZ3MuUkFXXSk7XG5cdHJldHVybiAhISh2YWx1ZSAmJiB2YWx1ZVtSZWFjdGl2ZUZsYWdzLklTX1JFQUNUSVZFXSk7XG59XG5mdW5jdGlvbiBpc1JlZiQxKHIpIHtcblx0cmV0dXJuICEhKHIgJiYgci5fX3ZfaXNSZWYgPT09IHRydWUpO1xufVxuLyoqXG4qIEBmcm9tIFtAdnVlL3JlYWN0aXZpdHldKGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9jb3JlL2Jsb2IvMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNS9wYWNrYWdlcy9yZWFjdGl2aXR5L3NyYy9yZWFjdGl2ZS50cyNMMzcyLUwzNzUpXG4qL1xuZnVuY3Rpb24gdG9SYXckMShvYnNlcnZlZCkge1xuXHRjb25zdCByYXcgPSBvYnNlcnZlZCAmJiBvYnNlcnZlZFtSZWFjdGl2ZUZsYWdzLlJBV107XG5cdHJldHVybiByYXcgPyB0b1JhdyQxKHJhdykgOiBvYnNlcnZlZDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9lZGl0b3IudHNcbnZhciBTdGF0ZUVkaXRvciA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy5yZWZFZGl0b3IgPSBuZXcgUmVmU3RhdGVFZGl0b3IoKTtcblx0fVxuXHRzZXQob2JqZWN0LCBwYXRoLCB2YWx1ZSwgY2IpIHtcblx0XHRjb25zdCBzZWN0aW9ucyA9IEFycmF5LmlzQXJyYXkocGF0aCkgPyBwYXRoIDogcGF0aC5zcGxpdChcIi5cIik7XG5cdFx0d2hpbGUgKHNlY3Rpb25zLmxlbmd0aCA+IDEpIHtcblx0XHRcdGNvbnN0IHNlY3Rpb24gPSBzZWN0aW9ucy5zaGlmdCgpO1xuXHRcdFx0aWYgKG9iamVjdCBpbnN0YW5jZW9mIE1hcCkgb2JqZWN0ID0gb2JqZWN0LmdldChzZWN0aW9uKTtcblx0XHRcdGVsc2UgaWYgKG9iamVjdCBpbnN0YW5jZW9mIFNldCkgb2JqZWN0ID0gQXJyYXkuZnJvbShvYmplY3QudmFsdWVzKCkpW3NlY3Rpb25dO1xuXHRcdFx0ZWxzZSBvYmplY3QgPSBvYmplY3Rbc2VjdGlvbl07XG5cdFx0XHRpZiAodGhpcy5yZWZFZGl0b3IuaXNSZWYob2JqZWN0KSkgb2JqZWN0ID0gdGhpcy5yZWZFZGl0b3IuZ2V0KG9iamVjdCk7XG5cdFx0fVxuXHRcdGNvbnN0IGZpZWxkID0gc2VjdGlvbnNbMF07XG5cdFx0Y29uc3QgaXRlbSA9IHRoaXMucmVmRWRpdG9yLmdldChvYmplY3QpW2ZpZWxkXTtcblx0XHRpZiAoY2IpIGNiKG9iamVjdCwgZmllbGQsIHZhbHVlKTtcblx0XHRlbHNlIGlmICh0aGlzLnJlZkVkaXRvci5pc1JlZihpdGVtKSkgdGhpcy5yZWZFZGl0b3Iuc2V0KGl0ZW0sIHZhbHVlKTtcblx0XHRlbHNlIG9iamVjdFtmaWVsZF0gPSB2YWx1ZTtcblx0fVxuXHRnZXQob2JqZWN0LCBwYXRoKSB7XG5cdFx0Y29uc3Qgc2VjdGlvbnMgPSBBcnJheS5pc0FycmF5KHBhdGgpID8gcGF0aCA6IHBhdGguc3BsaXQoXCIuXCIpO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgc2VjdGlvbnMubGVuZ3RoOyBpKyspIHtcblx0XHRcdGlmIChvYmplY3QgaW5zdGFuY2VvZiBNYXApIG9iamVjdCA9IG9iamVjdC5nZXQoc2VjdGlvbnNbaV0pO1xuXHRcdFx0ZWxzZSBvYmplY3QgPSBvYmplY3Rbc2VjdGlvbnNbaV1dO1xuXHRcdFx0aWYgKHRoaXMucmVmRWRpdG9yLmlzUmVmKG9iamVjdCkpIG9iamVjdCA9IHRoaXMucmVmRWRpdG9yLmdldChvYmplY3QpO1xuXHRcdFx0aWYgKCFvYmplY3QpIHJldHVybiB2b2lkIDA7XG5cdFx0fVxuXHRcdHJldHVybiBvYmplY3Q7XG5cdH1cblx0aGFzKG9iamVjdCwgcGF0aCwgcGFyZW50ID0gZmFsc2UpIHtcblx0XHRpZiAodHlwZW9mIG9iamVjdCA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIGZhbHNlO1xuXHRcdGNvbnN0IHNlY3Rpb25zID0gQXJyYXkuaXNBcnJheShwYXRoKSA/IHBhdGguc2xpY2UoKSA6IHBhdGguc3BsaXQoXCIuXCIpO1xuXHRcdGNvbnN0IHNpemUgPSAhcGFyZW50ID8gMSA6IDI7XG5cdFx0d2hpbGUgKG9iamVjdCAmJiBzZWN0aW9ucy5sZW5ndGggPiBzaXplKSB7XG5cdFx0XHRjb25zdCBzZWN0aW9uID0gc2VjdGlvbnMuc2hpZnQoKTtcblx0XHRcdG9iamVjdCA9IG9iamVjdFtzZWN0aW9uXTtcblx0XHRcdGlmICh0aGlzLnJlZkVkaXRvci5pc1JlZihvYmplY3QpKSBvYmplY3QgPSB0aGlzLnJlZkVkaXRvci5nZXQob2JqZWN0KTtcblx0XHR9XG5cdFx0cmV0dXJuIG9iamVjdCAhPSBudWxsICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHNlY3Rpb25zWzBdKTtcblx0fVxuXHRjcmVhdGVEZWZhdWx0U2V0Q2FsbGJhY2soc3RhdGUpIHtcblx0XHRyZXR1cm4gKG9iamVjdCwgZmllbGQsIHZhbHVlKSA9PiB7XG5cdFx0XHRpZiAoc3RhdGUucmVtb3ZlIHx8IHN0YXRlLm5ld0tleSkgaWYgKEFycmF5LmlzQXJyYXkob2JqZWN0KSkgb2JqZWN0LnNwbGljZShmaWVsZCwgMSk7XG5cdFx0XHRlbHNlIGlmICh0b1JhdyQxKG9iamVjdCkgaW5zdGFuY2VvZiBNYXApIG9iamVjdC5kZWxldGUoZmllbGQpO1xuXHRcdFx0ZWxzZSBpZiAodG9SYXckMShvYmplY3QpIGluc3RhbmNlb2YgU2V0KSBvYmplY3QuZGVsZXRlKEFycmF5LmZyb20ob2JqZWN0LnZhbHVlcygpKVtmaWVsZF0pO1xuXHRcdFx0ZWxzZSBSZWZsZWN0LmRlbGV0ZVByb3BlcnR5KG9iamVjdCwgZmllbGQpO1xuXHRcdFx0aWYgKCFzdGF0ZS5yZW1vdmUpIHtcblx0XHRcdFx0Y29uc3QgdGFyZ2V0ID0gb2JqZWN0W3N0YXRlLm5ld0tleSB8fCBmaWVsZF07XG5cdFx0XHRcdGlmICh0aGlzLnJlZkVkaXRvci5pc1JlZih0YXJnZXQpKSB0aGlzLnJlZkVkaXRvci5zZXQodGFyZ2V0LCB2YWx1ZSk7XG5cdFx0XHRcdGVsc2UgaWYgKHRvUmF3JDEob2JqZWN0KSBpbnN0YW5jZW9mIE1hcCkgb2JqZWN0LnNldChzdGF0ZS5uZXdLZXkgfHwgZmllbGQsIHZhbHVlKTtcblx0XHRcdFx0ZWxzZSBpZiAodG9SYXckMShvYmplY3QpIGluc3RhbmNlb2YgU2V0KSBvYmplY3QuYWRkKHZhbHVlKTtcblx0XHRcdFx0ZWxzZSBvYmplY3Rbc3RhdGUubmV3S2V5IHx8IGZpZWxkXSA9IHZhbHVlO1xuXHRcdFx0fVxuXHRcdH07XG5cdH1cbn07XG52YXIgUmVmU3RhdGVFZGl0b3IgPSBjbGFzcyB7XG5cdHNldChyZWYsIHZhbHVlKSB7XG5cdFx0aWYgKGlzUmVmJDEocmVmKSkgcmVmLnZhbHVlID0gdmFsdWU7XG5cdFx0ZWxzZSB7XG5cdFx0XHRpZiAocmVmIGluc3RhbmNlb2YgU2V0ICYmIEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG5cdFx0XHRcdHJlZi5jbGVhcigpO1xuXHRcdFx0XHR2YWx1ZS5mb3JFYWNoKCh2KSA9PiByZWYuYWRkKHYpKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgY3VycmVudEtleXMgPSBPYmplY3Qua2V5cyh2YWx1ZSk7XG5cdFx0XHRpZiAocmVmIGluc3RhbmNlb2YgTWFwKSB7XG5cdFx0XHRcdGNvbnN0IHByZXZpb3VzS2V5c1NldCA9IG5ldyBTZXQocmVmLmtleXMoKSk7XG5cdFx0XHRcdGN1cnJlbnRLZXlzLmZvckVhY2goKGtleSkgPT4ge1xuXHRcdFx0XHRcdHJlZi5zZXQoa2V5LCBSZWZsZWN0LmdldCh2YWx1ZSwga2V5KSk7XG5cdFx0XHRcdFx0cHJldmlvdXNLZXlzU2V0LmRlbGV0ZShrZXkpO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0cHJldmlvdXNLZXlzU2V0LmZvckVhY2goKGtleSkgPT4gcmVmLmRlbGV0ZShrZXkpKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcHJldmlvdXNLZXlzU2V0ID0gbmV3IFNldChPYmplY3Qua2V5cyhyZWYpKTtcblx0XHRcdGN1cnJlbnRLZXlzLmZvckVhY2goKGtleSkgPT4ge1xuXHRcdFx0XHRSZWZsZWN0LnNldChyZWYsIGtleSwgUmVmbGVjdC5nZXQodmFsdWUsIGtleSkpO1xuXHRcdFx0XHRwcmV2aW91c0tleXNTZXQuZGVsZXRlKGtleSk7XG5cdFx0XHR9KTtcblx0XHRcdHByZXZpb3VzS2V5c1NldC5mb3JFYWNoKChrZXkpID0+IFJlZmxlY3QuZGVsZXRlUHJvcGVydHkocmVmLCBrZXkpKTtcblx0XHR9XG5cdH1cblx0Z2V0KHJlZikge1xuXHRcdHJldHVybiBpc1JlZiQxKHJlZikgPyByZWYudmFsdWUgOiByZWY7XG5cdH1cblx0aXNSZWYocmVmKSB7XG5cdFx0cmV0dXJuIGlzUmVmJDEocmVmKSB8fCBpc1JlYWN0aXZlJDEocmVmKTtcblx0fVxufTtcbmFzeW5jIGZ1bmN0aW9uIGVkaXRDb21wb25lbnRTdGF0ZShwYXlsb2FkLCBzdGF0ZUVkaXRvcikge1xuXHRjb25zdCB7IHBhdGgsIG5vZGVJZCwgc3RhdGUsIHR5cGUgfSA9IHBheWxvYWQ7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBub2RlSWQpO1xuXHRpZiAoIWluc3RhbmNlKSByZXR1cm47XG5cdGNvbnN0IHRhcmdldFBhdGggPSBwYXRoLnNsaWNlKCk7XG5cdGxldCB0YXJnZXQ7XG5cdGlmIChPYmplY3Qua2V5cyhpbnN0YW5jZS5wcm9wcykuaW5jbHVkZXMocGF0aFswXSkpIHRhcmdldCA9IGluc3RhbmNlLnByb3BzO1xuXHRlbHNlIGlmIChpbnN0YW5jZS5kZXZ0b29sc1Jhd1NldHVwU3RhdGUgJiYgT2JqZWN0LmtleXMoaW5zdGFuY2UuZGV2dG9vbHNSYXdTZXR1cFN0YXRlKS5pbmNsdWRlcyhwYXRoWzBdKSkgdGFyZ2V0ID0gaW5zdGFuY2UuZGV2dG9vbHNSYXdTZXR1cFN0YXRlO1xuXHRlbHNlIGlmIChpbnN0YW5jZS5kYXRhICYmIE9iamVjdC5rZXlzKGluc3RhbmNlLmRhdGEpLmluY2x1ZGVzKHBhdGhbMF0pKSB0YXJnZXQgPSBpbnN0YW5jZS5kYXRhO1xuXHRlbHNlIHRhcmdldCA9IGluc3RhbmNlLnByb3h5O1xuXHRpZiAodGFyZ2V0ICYmIHRhcmdldFBhdGgpIHtcblx0XHRpZiAoc3RhdGUudHlwZSA9PT0gXCJvYmplY3RcIiAmJiB0eXBlID09PSBcInJlYWN0aXZlXCIpIHt9XG5cdFx0c3RhdGVFZGl0b3Iuc2V0KHRhcmdldCwgdGFyZ2V0UGF0aCwgc3RhdGUudmFsdWUsIHN0YXRlRWRpdG9yLmNyZWF0ZURlZmF1bHRTZXRDYWxsYmFjayhzdGF0ZSkpO1xuXHR9XG59XG5jb25zdCBzdGF0ZUVkaXRvciA9IG5ldyBTdGF0ZUVkaXRvcigpO1xuYXN5bmMgZnVuY3Rpb24gZWRpdFN0YXRlKHBheWxvYWQpIHtcblx0ZWRpdENvbXBvbmVudFN0YXRlKHBheWxvYWQsIHN0YXRlRWRpdG9yKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3RpbWVsaW5lL3N0b3JhZ2UudHNcbmNvbnN0IFRJTUVMSU5FX0xBWUVSU19TVEFURV9TVE9SQUdFX0lEID0gXCJfX1ZVRV9ERVZUT09MU19LSVRfVElNRUxJTkVfTEFZRVJTX1NUQVRFX19cIjtcbmZ1bmN0aW9uIGFkZFRpbWVsaW5lTGF5ZXJzU3RhdGVUb1N0b3JhZ2Uoc3RhdGUpIHtcblx0aWYgKCFpc0Jyb3dzZXIgfHwgdHlwZW9mIGxvY2FsU3RvcmFnZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBsb2NhbFN0b3JhZ2UgPT09IG51bGwpIHJldHVybjtcblx0bG9jYWxTdG9yYWdlLnNldEl0ZW0oVElNRUxJTkVfTEFZRVJTX1NUQVRFX1NUT1JBR0VfSUQsIEpTT04uc3RyaW5naWZ5KHN0YXRlKSk7XG59XG5mdW5jdGlvbiBnZXRUaW1lbGluZUxheWVyc1N0YXRlRnJvbVN0b3JhZ2UoKSB7XG5cdGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiIHx8ICFpc0Jyb3dzZXIgfHwgdHlwZW9mIGxvY2FsU3RvcmFnZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBsb2NhbFN0b3JhZ2UgPT09IG51bGwpIHJldHVybiB7XG5cdFx0cmVjb3JkaW5nU3RhdGU6IGZhbHNlLFxuXHRcdG1vdXNlRXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRrZXlib2FyZEV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0Y29tcG9uZW50RXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRwZXJmb3JtYW5jZUV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0c2VsZWN0ZWQ6IFwiXCJcblx0fTtcblx0Y29uc3Qgc3RhdGUgPSB0eXBlb2YgbG9jYWxTdG9yYWdlLmdldEl0ZW0gIT09IFwidW5kZWZpbmVkXCIgPyBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShUSU1FTElORV9MQVlFUlNfU1RBVEVfU1RPUkFHRV9JRCkgOiBudWxsO1xuXHRyZXR1cm4gc3RhdGUgPyBKU09OLnBhcnNlKHN0YXRlKSA6IHtcblx0XHRyZWNvcmRpbmdTdGF0ZTogZmFsc2UsXG5cdFx0bW91c2VFdmVudEVuYWJsZWQ6IGZhbHNlLFxuXHRcdGtleWJvYXJkRXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRjb21wb25lbnRFdmVudEVuYWJsZWQ6IGZhbHNlLFxuXHRcdHBlcmZvcm1hbmNlRXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRzZWxlY3RlZDogXCJcIlxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC90aW1lbGluZS50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9USU1FTElORV9MQVlFUlMgPz89IFtdO1xuY29uc3QgZGV2dG9vbHNUaW1lbGluZUxheWVycyA9IG5ldyBQcm94eSh0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1RJTUVMSU5FX0xBWUVSUywgeyBnZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuXHRyZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG59IH0pO1xuZnVuY3Rpb24gYWRkVGltZWxpbmVMYXllcihvcHRpb25zLCBkZXNjcmlwdG9yKSB7XG5cdGRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZVtkZXNjcmlwdG9yLmlkXSA9IGZhbHNlO1xuXHRkZXZ0b29sc1RpbWVsaW5lTGF5ZXJzLnB1c2goe1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0ZGVzY3JpcHRvcklkOiBkZXNjcmlwdG9yLmlkLFxuXHRcdGFwcFJlY29yZDogZ2V0QXBwUmVjb3JkKGRlc2NyaXB0b3IuYXBwKVxuXHR9KTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZVRpbWVsaW5lTGF5ZXJzU3RhdGUoc3RhdGUpIHtcblx0Y29uc3QgdXBkYXRlZFN0YXRlID0ge1xuXHRcdC4uLmRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZSxcblx0XHQuLi5zdGF0ZVxuXHR9O1xuXHRhZGRUaW1lbGluZUxheWVyc1N0YXRlVG9TdG9yYWdlKHVwZGF0ZWRTdGF0ZSk7XG5cdHVwZGF0ZURldlRvb2xzU3RhdGUoeyB0aW1lbGluZUxheWVyc1N0YXRlOiB1cGRhdGVkU3RhdGUgfSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L2luc3BlY3Rvci50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9JTlNQRUNUT1JfXyA/Pz0gW107XG5jb25zdCBkZXZ0b29sc0luc3BlY3RvciA9IG5ldyBQcm94eSh0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0lOU1BFQ1RPUl9fLCB7IGdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG5cdHJldHVybiBSZWZsZWN0LmdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKTtcbn0gfSk7XG5jb25zdCBjYWxsSW5zcGVjdG9yVXBkYXRlZEhvb2sgPSBkZWJvdW5jZSgoKSA9PiB7XG5cdGRldnRvb2xzQ29udGV4dC5ob29rcy5jYWxsSG9vayhEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1RPX0NMSUVOVCwgZ2V0QWN0aXZlSW5zcGVjdG9ycygpKTtcbn0pO1xuZnVuY3Rpb24gYWRkSW5zcGVjdG9yKGluc3BlY3RvciwgZGVzY3JpcHRvcikge1xuXHRkZXZ0b29sc0luc3BlY3Rvci5wdXNoKHtcblx0XHRvcHRpb25zOiBpbnNwZWN0b3IsXG5cdFx0ZGVzY3JpcHRvcixcblx0XHR0cmVlRmlsdGVyUGxhY2Vob2xkZXI6IGluc3BlY3Rvci50cmVlRmlsdGVyUGxhY2Vob2xkZXIgPz8gXCJTZWFyY2ggdHJlZS4uLlwiLFxuXHRcdHN0YXRlRmlsdGVyUGxhY2Vob2xkZXI6IGluc3BlY3Rvci5zdGF0ZUZpbHRlclBsYWNlaG9sZGVyID8/IFwiU2VhcmNoIHN0YXRlLi4uXCIsXG5cdFx0dHJlZUZpbHRlcjogXCJcIixcblx0XHRzZWxlY3RlZE5vZGVJZDogXCJcIixcblx0XHRhcHBSZWNvcmQ6IGdldEFwcFJlY29yZChkZXNjcmlwdG9yLmFwcClcblx0fSk7XG5cdGNhbGxJbnNwZWN0b3JVcGRhdGVkSG9vaygpO1xufVxuZnVuY3Rpb24gZ2V0QWN0aXZlSW5zcGVjdG9ycygpIHtcblx0cmV0dXJuIGRldnRvb2xzSW5zcGVjdG9yLmZpbHRlcigoaW5zcGVjdG9yKSA9PiBpbnNwZWN0b3IuZGVzY3JpcHRvci5hcHAgPT09IGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHApLmZpbHRlcigoaW5zcGVjdG9yKSA9PiBpbnNwZWN0b3IuZGVzY3JpcHRvci5pZCAhPT0gXCJjb21wb25lbnRzXCIpLm1hcCgoaW5zcGVjdG9yKSA9PiB7XG5cdFx0Y29uc3QgZGVzY3JpcHRvciA9IGluc3BlY3Rvci5kZXNjcmlwdG9yO1xuXHRcdGNvbnN0IG9wdGlvbnMgPSBpbnNwZWN0b3Iub3B0aW9ucztcblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6IG9wdGlvbnMuaWQsXG5cdFx0XHRsYWJlbDogb3B0aW9ucy5sYWJlbCxcblx0XHRcdGxvZ286IGRlc2NyaXB0b3IubG9nbyxcblx0XHRcdGljb246IGBjdXN0b20taWMtYmFzZWxpbmUtJHtvcHRpb25zPy5pY29uPy5yZXBsYWNlKC9fL2csIFwiLVwiKX1gLFxuXHRcdFx0cGFja2FnZU5hbWU6IGRlc2NyaXB0b3IucGFja2FnZU5hbWUsXG5cdFx0XHRob21lcGFnZTogZGVzY3JpcHRvci5ob21lcGFnZSxcblx0XHRcdHBsdWdpbklkOiBkZXNjcmlwdG9yLmlkXG5cdFx0fTtcblx0fSk7XG59XG5mdW5jdGlvbiBnZXRJbnNwZWN0b3JJbmZvKGlkKSB7XG5cdGNvbnN0IGluc3BlY3RvciA9IGdldEluc3BlY3RvcihpZCwgYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmFwcCk7XG5cdGlmICghaW5zcGVjdG9yKSByZXR1cm47XG5cdGNvbnN0IGRlc2NyaXB0b3IgPSBpbnNwZWN0b3IuZGVzY3JpcHRvcjtcblx0Y29uc3Qgb3B0aW9ucyA9IGluc3BlY3Rvci5vcHRpb25zO1xuXHRjb25zdCB0aW1lbGluZUxheWVycyA9IGRldnRvb2xzVGltZWxpbmVMYXllcnMuZmlsdGVyKChsYXllcikgPT4gbGF5ZXIuZGVzY3JpcHRvcklkID09PSBkZXNjcmlwdG9yLmlkKS5tYXAoKGl0ZW0pID0+ICh7XG5cdFx0aWQ6IGl0ZW0uaWQsXG5cdFx0bGFiZWw6IGl0ZW0ubGFiZWwsXG5cdFx0Y29sb3I6IGl0ZW0uY29sb3Jcblx0fSkpO1xuXHRyZXR1cm4ge1xuXHRcdGlkOiBvcHRpb25zLmlkLFxuXHRcdGxhYmVsOiBvcHRpb25zLmxhYmVsLFxuXHRcdGxvZ286IGRlc2NyaXB0b3IubG9nbyxcblx0XHRwYWNrYWdlTmFtZTogZGVzY3JpcHRvci5wYWNrYWdlTmFtZSxcblx0XHRob21lcGFnZTogZGVzY3JpcHRvci5ob21lcGFnZSxcblx0XHR0aW1lbGluZUxheWVycyxcblx0XHR0cmVlRmlsdGVyUGxhY2Vob2xkZXI6IGluc3BlY3Rvci50cmVlRmlsdGVyUGxhY2Vob2xkZXIsXG5cdFx0c3RhdGVGaWx0ZXJQbGFjZWhvbGRlcjogaW5zcGVjdG9yLnN0YXRlRmlsdGVyUGxhY2Vob2xkZXJcblx0fTtcbn1cbmZ1bmN0aW9uIGdldEluc3BlY3RvcihpZCwgYXBwKSB7XG5cdHJldHVybiBkZXZ0b29sc0luc3BlY3Rvci5maW5kKChpbnNwZWN0b3IpID0+IGluc3BlY3Rvci5vcHRpb25zLmlkID09PSBpZCAmJiAoYXBwID8gaW5zcGVjdG9yLmRlc2NyaXB0b3IuYXBwID09PSBhcHAgOiB0cnVlKSk7XG59XG5mdW5jdGlvbiBnZXRJbnNwZWN0b3JBY3Rpb25zKGlkKSB7XG5cdHJldHVybiBnZXRJbnNwZWN0b3IoaWQpPy5vcHRpb25zLmFjdGlvbnM7XG59XG5mdW5jdGlvbiBnZXRJbnNwZWN0b3JOb2RlQWN0aW9ucyhpZCkge1xuXHRyZXR1cm4gZ2V0SW5zcGVjdG9yKGlkKT8ub3B0aW9ucy5ub2RlQWN0aW9ucztcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvaG9vay50c1xubGV0IERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMpIHtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiVklTSVRfQ09NUE9ORU5UX1RSRUVcIl0gPSBcInZpc2l0Q29tcG9uZW50VHJlZVwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJJTlNQRUNUX0NPTVBPTkVOVFwiXSA9IFwiaW5zcGVjdENvbXBvbmVudFwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJFRElUX0NPTVBPTkVOVF9TVEFURVwiXSA9IFwiZWRpdENvbXBvbmVudFN0YXRlXCI7XG5cdERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5c1tcIkdFVF9JTlNQRUNUT1JfVFJFRVwiXSA9IFwiZ2V0SW5zcGVjdG9yVHJlZVwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJHRVRfSU5TUEVDVE9SX1NUQVRFXCJdID0gXCJnZXRJbnNwZWN0b3JTdGF0ZVwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJFRElUX0lOU1BFQ1RPUl9TVEFURVwiXSA9IFwiZWRpdEluc3BlY3RvclN0YXRlXCI7XG5cdERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5c1tcIklOU1BFQ1RfVElNRUxJTkVfRVZFTlRcIl0gPSBcImluc3BlY3RUaW1lbGluZUV2ZW50XCI7XG5cdERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5c1tcIlRJTUVMSU5FX0NMRUFSRURcIl0gPSBcInRpbWVsaW5lQ2xlYXJlZFwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJTRVRfUExVR0lOX1NFVFRJTkdTXCJdID0gXCJzZXRQbHVnaW5TZXR0aW5nc1wiO1xuXHRyZXR1cm4gRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzO1xufSh7fSk7XG5sZXQgRGV2VG9vbHNDb250ZXh0SG9va0tleXMgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oRGV2VG9vbHNDb250ZXh0SG9va0tleXMpIHtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJBRERfSU5TUEVDVE9SXCJdID0gXCJhZGRJbnNwZWN0b3JcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJTRU5EX0lOU1BFQ1RPUl9UUkVFXCJdID0gXCJzZW5kSW5zcGVjdG9yVHJlZVwiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIlNFTkRfSU5TUEVDVE9SX1NUQVRFXCJdID0gXCJzZW5kSW5zcGVjdG9yU3RhdGVcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJDVVNUT01fSU5TUEVDVE9SX1NFTEVDVF9OT0RFXCJdID0gXCJjdXN0b21JbnNwZWN0b3JTZWxlY3ROb2RlXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiVElNRUxJTkVfTEFZRVJfQURERURcIl0gPSBcInRpbWVsaW5lTGF5ZXJBZGRlZFwiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIlRJTUVMSU5FX0VWRU5UX0FEREVEXCJdID0gXCJ0aW1lbGluZUV2ZW50QWRkZWRcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJHRVRfQ09NUE9ORU5UX0lOU1RBTkNFU1wiXSA9IFwiZ2V0Q29tcG9uZW50SW5zdGFuY2VzXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiR0VUX0NPTVBPTkVOVF9CT1VORFNcIl0gPSBcImdldENvbXBvbmVudEJvdW5kc1wiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIkdFVF9DT01QT05FTlRfTkFNRVwiXSA9IFwiZ2V0Q29tcG9uZW50TmFtZVwiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIkNPTVBPTkVOVF9ISUdITElHSFRcIl0gPSBcImNvbXBvbmVudEhpZ2hsaWdodFwiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIkNPTVBPTkVOVF9VTkhJR0hMSUdIVFwiXSA9IFwiY29tcG9uZW50VW5oaWdobGlnaHRcIjtcblx0cmV0dXJuIERldlRvb2xzQ29udGV4dEhvb2tLZXlzO1xufSh7fSk7XG5sZXQgRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzKSB7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJTRU5EX0lOU1BFQ1RPUl9UUkVFX1RPX0NMSUVOVFwiXSA9IFwic2VuZEluc3BlY3RvclRyZWVUb0NsaWVudFwiO1xuXHREZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzW1wiU0VORF9JTlNQRUNUT1JfU1RBVEVfVE9fQ0xJRU5UXCJdID0gXCJzZW5kSW5zcGVjdG9yU3RhdGVUb0NsaWVudFwiO1xuXHREZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzW1wiU0VORF9USU1FTElORV9FVkVOVF9UT19DTElFTlRcIl0gPSBcInNlbmRUaW1lbGluZUV2ZW50VG9DbGllbnRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIlNFTkRfSU5TUEVDVE9SX1RPX0NMSUVOVFwiXSA9IFwic2VuZEluc3BlY3RvclRvQ2xpZW50XCI7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJTRU5EX0FDVElWRV9BUFBfVU5NT1VOVEVEX1RPX0NMSUVOVFwiXSA9IFwic2VuZEFjdGl2ZUFwcFVwZGF0ZWRUb0NsaWVudFwiO1xuXHREZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzW1wiREVWVE9PTFNfU1RBVEVfVVBEQVRFRFwiXSA9IFwiZGV2dG9vbHNTdGF0ZVVwZGF0ZWRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIkRFVlRPT0xTX0NPTk5FQ1RFRF9VUERBVEVEXCJdID0gXCJkZXZ0b29sc0Nvbm5lY3RlZFVwZGF0ZWRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIlJPVVRFUl9JTkZPX1VQREFURURcIl0gPSBcInJvdXRlckluZm9VcGRhdGVkXCI7XG5cdHJldHVybiBEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzO1xufSh7fSk7XG5mdW5jdGlvbiBjcmVhdGVEZXZUb29sc0N0eEhvb2tzKCkge1xuXHRjb25zdCBob29rcyA9IGNyZWF0ZUhvb2tzKCk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuQUREX0lOU1BFQ1RPUiwgKHsgaW5zcGVjdG9yLCBwbHVnaW4gfSkgPT4ge1xuXHRcdGFkZEluc3BlY3RvcihpbnNwZWN0b3IsIHBsdWdpbi5kZXNjcmlwdG9yKTtcblx0fSk7XG5cdGNvbnN0IGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUgPSBkZWJvdW5jZShhc3luYyAoeyBpbnNwZWN0b3JJZCwgcGx1Z2luIH0pID0+IHtcblx0XHRpZiAoIWluc3BlY3RvcklkIHx8ICFwbHVnaW4/LmRlc2NyaXB0b3I/LmFwcCB8fCBkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRjb25zdCBpbnNwZWN0b3IgPSBnZXRJbnNwZWN0b3IoaW5zcGVjdG9ySWQsIHBsdWdpbi5kZXNjcmlwdG9yLmFwcCk7XG5cdFx0Y29uc3QgX3BheWxvYWQgPSB7XG5cdFx0XHRhcHA6IHBsdWdpbi5kZXNjcmlwdG9yLmFwcCxcblx0XHRcdGluc3BlY3RvcklkLFxuXHRcdFx0ZmlsdGVyOiBpbnNwZWN0b3I/LnRyZWVGaWx0ZXIgfHwgXCJcIixcblx0XHRcdHJvb3ROb2RlczogW11cblx0XHR9O1xuXHRcdGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRob29rcy5jYWxsSG9va1dpdGgoYXN5bmMgKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2IoX3BheWxvYWQpKSk7XG5cdFx0XHRcdHJlc29sdmUoKTtcblx0XHRcdH0sIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5HRVRfSU5TUEVDVE9SX1RSRUUpO1xuXHRcdH0pO1xuXHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2Ioe1xuXHRcdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdFx0cm9vdE5vZGVzOiBfcGF5bG9hZC5yb290Tm9kZXNcblx0XHRcdH0pKSk7XG5cdFx0fSwgRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9UUkVFX1RPX0NMSUVOVCk7XG5cdH0sIDEyMCk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuU0VORF9JTlNQRUNUT1JfVFJFRSwgZGVib3VuY2VTZW5kSW5zcGVjdG9yVHJlZSk7XG5cdGNvbnN0IGRlYm91bmNlU2VuZEluc3BlY3RvclN0YXRlID0gZGVib3VuY2UoYXN5bmMgKHsgaW5zcGVjdG9ySWQsIHBsdWdpbiB9KSA9PiB7XG5cdFx0aWYgKCFpbnNwZWN0b3JJZCB8fCAhcGx1Z2luPy5kZXNjcmlwdG9yPy5hcHAgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0Y29uc3QgaW5zcGVjdG9yID0gZ2V0SW5zcGVjdG9yKGluc3BlY3RvcklkLCBwbHVnaW4uZGVzY3JpcHRvci5hcHApO1xuXHRcdGNvbnN0IF9wYXlsb2FkID0ge1xuXHRcdFx0YXBwOiBwbHVnaW4uZGVzY3JpcHRvci5hcHAsXG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdG5vZGVJZDogaW5zcGVjdG9yPy5zZWxlY3RlZE5vZGVJZCB8fCBcIlwiLFxuXHRcdFx0c3RhdGU6IG51bGxcblx0XHR9O1xuXHRcdGNvbnN0IGN0eCA9IHsgY3VycmVudFRhYjogYGN1c3RvbS1pbnNwZWN0b3I6JHtpbnNwZWN0b3JJZH1gIH07XG5cdFx0aWYgKF9wYXlsb2FkLm5vZGVJZCkgYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRcdGF3YWl0IFByb21pc2UuYWxsKGNhbGxiYWNrcy5tYXAoKGNiKSA9PiBjYihfcGF5bG9hZCwgY3R4KSkpO1xuXHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9TVEFURSk7XG5cdFx0fSk7XG5cdFx0aG9va3MuY2FsbEhvb2tXaXRoKGFzeW5jIChjYWxsYmFja3MpID0+IHtcblx0XHRcdGF3YWl0IFByb21pc2UuYWxsKGNhbGxiYWNrcy5tYXAoKGNiKSA9PiBjYih7XG5cdFx0XHRcdGluc3BlY3RvcklkLFxuXHRcdFx0XHRub2RlSWQ6IF9wYXlsb2FkLm5vZGVJZCxcblx0XHRcdFx0c3RhdGU6IF9wYXlsb2FkLnN0YXRlXG5cdFx0XHR9KSkpO1xuXHRcdH0sIERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuU0VORF9JTlNQRUNUT1JfU1RBVEVfVE9fQ0xJRU5UKTtcblx0fSwgMTIwKTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9TVEFURSwgZGVib3VuY2VTZW5kSW5zcGVjdG9yU3RhdGUpO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNVU1RPTV9JTlNQRUNUT1JfU0VMRUNUX05PREUsICh7IGluc3BlY3RvcklkLCBub2RlSWQsIHBsdWdpbiB9KSA9PiB7XG5cdFx0Y29uc3QgaW5zcGVjdG9yID0gZ2V0SW5zcGVjdG9yKGluc3BlY3RvcklkLCBwbHVnaW4uZGVzY3JpcHRvci5hcHApO1xuXHRcdGlmICghaW5zcGVjdG9yKSByZXR1cm47XG5cdFx0aW5zcGVjdG9yLnNlbGVjdGVkTm9kZUlkID0gbm9kZUlkO1xuXHR9KTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5USU1FTElORV9MQVlFUl9BRERFRCwgKHsgb3B0aW9ucywgcGx1Z2luIH0pID0+IHtcblx0XHRhZGRUaW1lbGluZUxheWVyKG9wdGlvbnMsIHBsdWdpbi5kZXNjcmlwdG9yKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuVElNRUxJTkVfRVZFTlRfQURERUQsICh7IG9wdGlvbnMsIHBsdWdpbiB9KSA9PiB7XG5cdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCB8fCAhZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlPy5bcGx1Z2luLmRlc2NyaXB0b3IuaWRdICYmICFbXG5cdFx0XHRcInBlcmZvcm1hbmNlXCIsXG5cdFx0XHRcImNvbXBvbmVudC1ldmVudFwiLFxuXHRcdFx0XCJrZXlib2FyZFwiLFxuXHRcdFx0XCJtb3VzZVwiXG5cdFx0XS5pbmNsdWRlcyhvcHRpb25zLmxheWVySWQpKSByZXR1cm47XG5cdFx0aG9va3MuY2FsbEhvb2tXaXRoKGFzeW5jIChjYWxsYmFja3MpID0+IHtcblx0XHRcdGF3YWl0IFByb21pc2UuYWxsKGNhbGxiYWNrcy5tYXAoKGNiKSA9PiBjYihvcHRpb25zKSkpO1xuXHRcdH0sIERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuU0VORF9USU1FTElORV9FVkVOVF9UT19DTElFTlQpO1xuXHR9KTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5HRVRfQ09NUE9ORU5UX0lOU1RBTkNFUywgYXN5bmMgKHsgYXBwIH0pID0+IHtcblx0XHRjb25zdCBhcHBSZWNvcmQgPSBhcHAuX19WVUVfREVWVE9PTFNfTkVYVF9BUFBfUkVDT1JEX187XG5cdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybiBudWxsO1xuXHRcdGNvbnN0IGFwcElkID0gYXBwUmVjb3JkLmlkLnRvU3RyaW5nKCk7XG5cdFx0cmV0dXJuIFsuLi5hcHBSZWNvcmQuaW5zdGFuY2VNYXBdLmZpbHRlcigoW2tleV0pID0+IGtleS5zcGxpdChcIjpcIilbMF0gPT09IGFwcElkKS5tYXAoKFssIGluc3RhbmNlXSkgPT4gaW5zdGFuY2UpO1xuXHR9KTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5HRVRfQ09NUE9ORU5UX0JPVU5EUywgYXN5bmMgKHsgaW5zdGFuY2UgfSkgPT4ge1xuXHRcdHJldHVybiBnZXRDb21wb25lbnRCb3VuZGluZ1JlY3QoaW5zdGFuY2UpO1xuXHR9KTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5HRVRfQ09NUE9ORU5UX05BTUUsICh7IGluc3RhbmNlIH0pID0+IHtcblx0XHRyZXR1cm4gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuQ09NUE9ORU5UX0hJR0hMSUdIVCwgKHsgdWlkIH0pID0+IHtcblx0XHRjb25zdCBpbnN0YW5jZSA9IGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5pbnN0YW5jZU1hcC5nZXQodWlkKTtcblx0XHRpZiAoaW5zdGFuY2UpIGhpZ2hsaWdodChpbnN0YW5jZSk7XG5cdH0pO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNPTVBPTkVOVF9VTkhJR0hMSUdIVCwgKCkgPT4ge1xuXHRcdHVuaGlnaGxpZ2h0KCk7XG5cdH0pO1xuXHRyZXR1cm4gaG9va3M7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L3N0YXRlLnRzXG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX18gPz89IFtdO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9fID8/PSB7fTtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfSURfXyA/Pz0gXCJcIjtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX1RBQlNfXyA/Pz0gW107XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9DT01NQU5EU19fID8/PSBbXTtcbmNvbnN0IFNUQVRFX0tFWSA9IFwiX19WVUVfREVWVE9PTFNfS0lUX0dMT0JBTF9TVEFURV9fXCI7XG5mdW5jdGlvbiBpbml0U3RhdGVGYWN0b3J5KCkge1xuXHRyZXR1cm4ge1xuXHRcdGNvbm5lY3RlZDogZmFsc2UsXG5cdFx0Y2xpZW50Q29ubmVjdGVkOiBmYWxzZSxcblx0XHR2aXRlUGx1Z2luRGV0ZWN0ZWQ6IHRydWUsXG5cdFx0YXBwUmVjb3JkczogW10sXG5cdFx0YWN0aXZlQXBwUmVjb3JkSWQ6IFwiXCIsXG5cdFx0dGFiczogW10sXG5cdFx0Y29tbWFuZHM6IFtdLFxuXHRcdGhpZ2hQZXJmTW9kZUVuYWJsZWQ6IHRydWUsXG5cdFx0ZGV2dG9vbHNDbGllbnREZXRlY3RlZDoge30sXG5cdFx0cGVyZlVuaXF1ZUdyb3VwSWQ6IDAsXG5cdFx0dGltZWxpbmVMYXllcnNTdGF0ZTogZ2V0VGltZWxpbmVMYXllcnNTdGF0ZUZyb21TdG9yYWdlKClcblx0fTtcbn1cbnRhcmdldFtTVEFURV9LRVldID8/PSBpbml0U3RhdGVGYWN0b3J5KCk7XG5jb25zdCBjYWxsU3RhdGVVcGRhdGVkSG9vayA9IGRlYm91bmNlKChzdGF0ZSkgPT4ge1xuXHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5ERVZUT09MU19TVEFURV9VUERBVEVELCB7IHN0YXRlIH0pO1xufSk7XG5jb25zdCBjYWxsQ29ubmVjdGVkVXBkYXRlZEhvb2sgPSBkZWJvdW5jZSgoc3RhdGUsIG9sZFN0YXRlKSA9PiB7XG5cdGRldnRvb2xzQ29udGV4dC5ob29rcy5jYWxsSG9vayhEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLkRFVlRPT0xTX0NPTk5FQ1RFRF9VUERBVEVELCB7XG5cdFx0c3RhdGUsXG5cdFx0b2xkU3RhdGVcblx0fSk7XG59KTtcbmNvbnN0IGRldnRvb2xzQXBwUmVjb3JkcyA9IG5ldyBQcm94eSh0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX18sIHsgZ2V0KF90YXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG5cdGlmIChwcm9wID09PSBcInZhbHVlXCIpIHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX187XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX19bcHJvcF07XG59IH0pO1xuY29uc3QgYWRkRGV2VG9vbHNBcHBSZWNvcmQgPSAoYXBwKSA9PiB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQVBQX1JFQ09SRFNfXyA9IFsuLi50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX18sIGFwcF07XG59O1xuY29uc3QgcmVtb3ZlRGV2VG9vbHNBcHBSZWNvcmQgPSAoYXBwKSA9PiB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQVBQX1JFQ09SRFNfXyA9IGRldnRvb2xzQXBwUmVjb3Jkcy52YWx1ZS5maWx0ZXIoKHJlY29yZCkgPT4gcmVjb3JkLmFwcCAhPT0gYXBwKTtcbn07XG5jb25zdCBhY3RpdmVBcHBSZWNvcmQgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9fLCB7IGdldChfdGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuXHRpZiAocHJvcCA9PT0gXCJ2YWx1ZVwiKSByZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9fO1xuXHRlbHNlIGlmIChwcm9wID09PSBcImlkXCIpIHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FDVElWRV9BUFBfUkVDT1JEX0lEX187XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FDVElWRV9BUFBfUkVDT1JEX19bcHJvcF07XG59IH0pO1xuZnVuY3Rpb24gdXBkYXRlQWxsU3RhdGVzKCkge1xuXHRjYWxsU3RhdGVVcGRhdGVkSG9vayh7XG5cdFx0Li4udGFyZ2V0W1NUQVRFX0tFWV0sXG5cdFx0YXBwUmVjb3JkczogZGV2dG9vbHNBcHBSZWNvcmRzLnZhbHVlLFxuXHRcdGFjdGl2ZUFwcFJlY29yZElkOiBhY3RpdmVBcHBSZWNvcmQuaWQsXG5cdFx0dGFiczogdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fVEFCU19fLFxuXHRcdGNvbW1hbmRzOiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9DT01NQU5EU19fXG5cdH0pO1xufVxuZnVuY3Rpb24gc2V0QWN0aXZlQXBwUmVjb3JkKGFwcCkge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FDVElWRV9BUFBfUkVDT1JEX18gPSBhcHA7XG5cdHVwZGF0ZUFsbFN0YXRlcygpO1xufVxuZnVuY3Rpb24gc2V0QWN0aXZlQXBwUmVjb3JkSWQoaWQpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9JRF9fID0gaWQ7XG5cdHVwZGF0ZUFsbFN0YXRlcygpO1xufVxuY29uc3QgZGV2dG9vbHNTdGF0ZSA9IG5ldyBQcm94eSh0YXJnZXRbU1RBVEVfS0VZXSwge1xuXHRnZXQodGFyZ2V0JDMsIHByb3BlcnR5KSB7XG5cdFx0aWYgKHByb3BlcnR5ID09PSBcImFwcFJlY29yZHNcIikgcmV0dXJuIGRldnRvb2xzQXBwUmVjb3Jkcztcblx0XHRlbHNlIGlmIChwcm9wZXJ0eSA9PT0gXCJhY3RpdmVBcHBSZWNvcmRJZFwiKSByZXR1cm4gYWN0aXZlQXBwUmVjb3JkLmlkO1xuXHRcdGVsc2UgaWYgKHByb3BlcnR5ID09PSBcInRhYnNcIikgcmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX1RBQlNfXztcblx0XHRlbHNlIGlmIChwcm9wZXJ0eSA9PT0gXCJjb21tYW5kc1wiKSByZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfXztcblx0XHRyZXR1cm4gdGFyZ2V0W1NUQVRFX0tFWV1bcHJvcGVydHldO1xuXHR9LFxuXHRkZWxldGVQcm9wZXJ0eSh0YXJnZXQsIHByb3BlcnR5KSB7XG5cdFx0ZGVsZXRlIHRhcmdldFtwcm9wZXJ0eV07XG5cdFx0cmV0dXJuIHRydWU7XG5cdH0sXG5cdHNldCh0YXJnZXQkNCwgcHJvcGVydHksIHZhbHVlKSB7XG5cdFx0dGFyZ2V0JDRbcHJvcGVydHldID0gdmFsdWU7XG5cdFx0dGFyZ2V0W1NUQVRFX0tFWV1bcHJvcGVydHldID0gdmFsdWU7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cbn0pO1xuZnVuY3Rpb24gcmVzZXREZXZUb29sc1N0YXRlKCkge1xuXHRPYmplY3QuYXNzaWduKHRhcmdldFtTVEFURV9LRVldLCBpbml0U3RhdGVGYWN0b3J5KCkpO1xufVxuZnVuY3Rpb24gdXBkYXRlRGV2VG9vbHNTdGF0ZShzdGF0ZSkge1xuXHRjb25zdCBvbGRTdGF0ZSA9IHtcblx0XHQuLi50YXJnZXRbU1RBVEVfS0VZXSxcblx0XHRhcHBSZWNvcmRzOiBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWUsXG5cdFx0YWN0aXZlQXBwUmVjb3JkSWQ6IGFjdGl2ZUFwcFJlY29yZC5pZFxuXHR9O1xuXHRpZiAob2xkU3RhdGUuY29ubmVjdGVkICE9PSBzdGF0ZS5jb25uZWN0ZWQgJiYgc3RhdGUuY29ubmVjdGVkIHx8IG9sZFN0YXRlLmNsaWVudENvbm5lY3RlZCAhPT0gc3RhdGUuY2xpZW50Q29ubmVjdGVkICYmIHN0YXRlLmNsaWVudENvbm5lY3RlZCkgY2FsbENvbm5lY3RlZFVwZGF0ZWRIb29rKHRhcmdldFtTVEFURV9LRVldLCBvbGRTdGF0ZSk7XG5cdE9iamVjdC5hc3NpZ24odGFyZ2V0W1NUQVRFX0tFWV0sIHN0YXRlKTtcblx0dXBkYXRlQWxsU3RhdGVzKCk7XG59XG5mdW5jdGlvbiBvbkRldlRvb2xzQ29ubmVjdGVkKGZuKSB7XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmNvbm5lY3RlZCkge1xuXHRcdFx0Zm4oKTtcblx0XHRcdHJlc29sdmUoKTtcblx0XHR9XG5cdFx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5ERVZUT09MU19DT05ORUNURURfVVBEQVRFRCwgKHsgc3RhdGUgfSkgPT4ge1xuXHRcdFx0aWYgKHN0YXRlLmNvbm5lY3RlZCkge1xuXHRcdFx0XHRmbigpO1xuXHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH0pO1xufVxuY29uc3QgcmVzb2x2ZUljb24gPSAoaWNvbikgPT4ge1xuXHRpZiAoIWljb24pIHJldHVybjtcblx0aWYgKGljb24uc3RhcnRzV2l0aChcImJhc2VsaW5lLVwiKSkgcmV0dXJuIGBjdXN0b20taWMtJHtpY29ufWA7XG5cdGlmIChpY29uLnN0YXJ0c1dpdGgoXCJpLVwiKSB8fCBpc1VybFN0cmluZyhpY29uKSkgcmV0dXJuIGljb247XG5cdHJldHVybiBgY3VzdG9tLWljLWJhc2VsaW5lLSR7aWNvbn1gO1xufTtcbmZ1bmN0aW9uIGFkZEN1c3RvbVRhYih0YWIpIHtcblx0Y29uc3QgdGFicyA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX1RBQlNfXztcblx0aWYgKHRhYnMuc29tZSgodCkgPT4gdC5uYW1lID09PSB0YWIubmFtZSkpIHJldHVybjtcblx0dGFicy5wdXNoKHtcblx0XHQuLi50YWIsXG5cdFx0aWNvbjogcmVzb2x2ZUljb24odGFiLmljb24pXG5cdH0pO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmZ1bmN0aW9uIGFkZEN1c3RvbUNvbW1hbmQoYWN0aW9uKSB7XG5cdGNvbnN0IGNvbW1hbmRzID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfXztcblx0aWYgKGNvbW1hbmRzLnNvbWUoKHQpID0+IHQuaWQgPT09IGFjdGlvbi5pZCkpIHJldHVybjtcblx0Y29tbWFuZHMucHVzaCh7XG5cdFx0Li4uYWN0aW9uLFxuXHRcdGljb246IHJlc29sdmVJY29uKGFjdGlvbi5pY29uKSxcblx0XHRjaGlsZHJlbjogYWN0aW9uLmNoaWxkcmVuID8gYWN0aW9uLmNoaWxkcmVuLm1hcCgoY2hpbGQpID0+ICh7XG5cdFx0XHQuLi5jaGlsZCxcblx0XHRcdGljb246IHJlc29sdmVJY29uKGNoaWxkLmljb24pXG5cdFx0fSkpIDogdm9pZCAwXG5cdH0pO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmZ1bmN0aW9uIHJlbW92ZUN1c3RvbUNvbW1hbmQoYWN0aW9uSWQpIHtcblx0Y29uc3QgY29tbWFuZHMgPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9DT01NQU5EU19fO1xuXHRjb25zdCBpbmRleCA9IGNvbW1hbmRzLmZpbmRJbmRleCgodCkgPT4gdC5pZCA9PT0gYWN0aW9uSWQpO1xuXHRpZiAoaW5kZXggPT09IC0xKSByZXR1cm47XG5cdGNvbW1hbmRzLnNwbGljZShpbmRleCwgMSk7XG5cdHVwZGF0ZUFsbFN0YXRlcygpO1xufVxuZnVuY3Rpb24gdG9nZ2xlQ2xpZW50Q29ubmVjdGVkKHN0YXRlKSB7XG5cdHVwZGF0ZURldlRvb2xzU3RhdGUoeyBjbGllbnRDb25uZWN0ZWQ6IHN0YXRlIH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvb3Blbi1pbi1lZGl0b3IvaW5kZXgudHNcbmZ1bmN0aW9uIHNldE9wZW5JbkVkaXRvckJhc2VVcmwodXJsKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19PUEVOX0lOX0VESVRPUl9CQVNFX1VSTF9fID0gdXJsO1xufVxuZnVuY3Rpb24gb3BlbkluRWRpdG9yKG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGZpbGUsIGhvc3QsIGJhc2VVcmwgPSB3aW5kb3cubG9jYXRpb24ub3JpZ2luLCBsaW5lID0gMCwgY29sdW1uID0gMCB9ID0gb3B0aW9ucztcblx0aWYgKGZpbGUpIHtcblx0XHRpZiAoaG9zdCA9PT0gXCJjaHJvbWUtZXh0ZW5zaW9uXCIpIHtcblx0XHRcdGNvbnN0IGZpbGVOYW1lID0gZmlsZS5yZXBsYWNlKC9cXFxcL2csIFwiXFxcXFxcXFxcIik7XG5cdFx0XHRjb25zdCBfYmFzZVVybCA9IHdpbmRvdy5WVUVfREVWVE9PTFNfQ09ORklHPy5vcGVuSW5FZGl0b3JIb3N0ID8/IFwiL1wiO1xuXHRcdFx0ZmV0Y2goYCR7X2Jhc2VVcmx9X19vcGVuLWluLWVkaXRvcj9maWxlPSR7ZW5jb2RlVVJJKGZpbGUpfWApLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG5cdFx0XHRcdGlmICghcmVzcG9uc2Uub2spIHtcblx0XHRcdFx0XHRjb25zdCBtc2cgPSBgT3BlbmluZyBjb21wb25lbnQgJHtmaWxlTmFtZX0gZmFpbGVkYDtcblx0XHRcdFx0XHRjb25zb2xlLmxvZyhgJWMke21zZ31gLCBcImNvbG9yOnJlZFwiKTtcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSBlbHNlIGlmIChkZXZ0b29sc1N0YXRlLnZpdGVQbHVnaW5EZXRlY3RlZCkge1xuXHRcdFx0Y29uc3QgX2Jhc2VVcmwgPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfT1BFTl9JTl9FRElUT1JfQkFTRV9VUkxfXyA/PyBiYXNlVXJsO1xuXHRcdFx0dGFyZ2V0Ll9fVlVFX0lOU1BFQ1RPUl9fLm9wZW5JbkVkaXRvcihfYmFzZVVybCwgZmlsZSwgbGluZSwgY29sdW1uKTtcblx0XHR9XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvcGx1Z2luLnRzXG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1BMVUdJTl9CVUZGRVJfXyA/Pz0gW107XG5jb25zdCBkZXZ0b29sc1BsdWdpbkJ1ZmZlciA9IG5ldyBQcm94eSh0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1BMVUdJTl9CVUZGRVJfXywgeyBnZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuXHRyZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG59IH0pO1xuZnVuY3Rpb24gYWRkRGV2VG9vbHNQbHVnaW5Ub0J1ZmZlcihwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKSB7XG5cdGRldnRvb2xzUGx1Z2luQnVmZmVyLnB1c2goW3BsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm5dKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3BsdWdpbi9wbHVnaW4tc2V0dGluZ3MudHNcbmZ1bmN0aW9uIF9nZXRTZXR0aW5ncyhzZXR0aW5ncykge1xuXHRjb25zdCBfc2V0dGluZ3MgPSB7fTtcblx0T2JqZWN0LmtleXMoc2V0dGluZ3MpLmZvckVhY2goKGtleSkgPT4ge1xuXHRcdF9zZXR0aW5nc1trZXldID0gc2V0dGluZ3Nba2V5XS5kZWZhdWx0VmFsdWU7XG5cdH0pO1xuXHRyZXR1cm4gX3NldHRpbmdzO1xufVxuZnVuY3Rpb24gZ2V0UGx1Z2luTG9jYWxLZXkocGx1Z2luSWQpIHtcblx0cmV0dXJuIGBfX1ZVRV9ERVZUT09MU19ORVhUX1BMVUdJTl9TRVRUSU5HU19fJHtwbHVnaW5JZH1fX2A7XG59XG5mdW5jdGlvbiBnZXRQbHVnaW5TZXR0aW5nc09wdGlvbnMocGx1Z2luSWQpIHtcblx0cmV0dXJuIChkZXZ0b29sc1BsdWdpbkJ1ZmZlci5maW5kKChpdGVtKSA9PiBpdGVtWzBdLmlkID09PSBwbHVnaW5JZCAmJiAhIWl0ZW1bMF0/LnNldHRpbmdzKT8uWzBdID8/IG51bGwpPy5zZXR0aW5ncyA/PyBudWxsO1xufVxuZnVuY3Rpb24gZ2V0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQsIGZhbGxiYWNrVmFsdWUpIHtcblx0Y29uc3QgbG9jYWxLZXkgPSBnZXRQbHVnaW5Mb2NhbEtleShwbHVnaW5JZCk7XG5cdGlmIChsb2NhbEtleSkge1xuXHRcdGNvbnN0IGxvY2FsU2V0dGluZ3MgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShsb2NhbEtleSk7XG5cdFx0aWYgKGxvY2FsU2V0dGluZ3MpIHJldHVybiBKU09OLnBhcnNlKGxvY2FsU2V0dGluZ3MpO1xuXHR9XG5cdGlmIChwbHVnaW5JZCkgcmV0dXJuIF9nZXRTZXR0aW5ncygoZGV2dG9vbHNQbHVnaW5CdWZmZXIuZmluZCgoaXRlbSkgPT4gaXRlbVswXS5pZCA9PT0gcGx1Z2luSWQpPy5bMF0gPz8gbnVsbCk/LnNldHRpbmdzID8/IHt9KTtcblx0cmV0dXJuIF9nZXRTZXR0aW5ncyhmYWxsYmFja1ZhbHVlKTtcbn1cbmZ1bmN0aW9uIGluaXRQbHVnaW5TZXR0aW5ncyhwbHVnaW5JZCwgc2V0dGluZ3MpIHtcblx0Y29uc3QgbG9jYWxLZXkgPSBnZXRQbHVnaW5Mb2NhbEtleShwbHVnaW5JZCk7XG5cdGlmICghbG9jYWxTdG9yYWdlLmdldEl0ZW0obG9jYWxLZXkpKSBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShsb2NhbEtleSwgSlNPTi5zdHJpbmdpZnkoX2dldFNldHRpbmdzKHNldHRpbmdzKSkpO1xufVxuZnVuY3Rpb24gc2V0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQsIGtleSwgdmFsdWUpIHtcblx0Y29uc3QgbG9jYWxLZXkgPSBnZXRQbHVnaW5Mb2NhbEtleShwbHVnaW5JZCk7XG5cdGNvbnN0IGxvY2FsU2V0dGluZ3MgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShsb2NhbEtleSk7XG5cdGNvbnN0IHBhcnNlZExvY2FsU2V0dGluZ3MgPSBKU09OLnBhcnNlKGxvY2FsU2V0dGluZ3MgfHwgXCJ7fVwiKTtcblx0Y29uc3QgdXBkYXRlZCA9IHtcblx0XHQuLi5wYXJzZWRMb2NhbFNldHRpbmdzLFxuXHRcdFtrZXldOiB2YWx1ZVxuXHR9O1xuXHRsb2NhbFN0b3JhZ2Uuc2V0SXRlbShsb2NhbEtleSwgSlNPTi5zdHJpbmdpZnkodXBkYXRlZCkpO1xuXHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2tXaXRoKChjYWxsYmFja3MpID0+IHtcblx0XHRjYWxsYmFja3MuZm9yRWFjaCgoY2IpID0+IGNiKHtcblx0XHRcdHBsdWdpbklkLFxuXHRcdFx0a2V5LFxuXHRcdFx0b2xkVmFsdWU6IHBhcnNlZExvY2FsU2V0dGluZ3Nba2V5XSxcblx0XHRcdG5ld1ZhbHVlOiB2YWx1ZSxcblx0XHRcdHNldHRpbmdzOiB1cGRhdGVkXG5cdFx0fSkpO1xuXHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuU0VUX1BMVUdJTl9TRVRUSU5HUyk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdHlwZXMvaG9vay50c1xubGV0IERldlRvb2xzSG9va3MgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oRGV2VG9vbHNIb29rcykge1xuXHREZXZUb29sc0hvb2tzW1wiQVBQX0lOSVRcIl0gPSBcImFwcDppbml0XCI7XG5cdERldlRvb2xzSG9va3NbXCJBUFBfVU5NT1VOVFwiXSA9IFwiYXBwOnVubW91bnRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkNPTVBPTkVOVF9VUERBVEVEXCJdID0gXCJjb21wb25lbnQ6dXBkYXRlZFwiO1xuXHREZXZUb29sc0hvb2tzW1wiQ09NUE9ORU5UX0FEREVEXCJdID0gXCJjb21wb25lbnQ6YWRkZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkNPTVBPTkVOVF9SRU1PVkVEXCJdID0gXCJjb21wb25lbnQ6cmVtb3ZlZFwiO1xuXHREZXZUb29sc0hvb2tzW1wiQ09NUE9ORU5UX0VNSVRcIl0gPSBcImNvbXBvbmVudDplbWl0XCI7XG5cdERldlRvb2xzSG9va3NbXCJQRVJGT1JNQU5DRV9TVEFSVFwiXSA9IFwicGVyZjpzdGFydFwiO1xuXHREZXZUb29sc0hvb2tzW1wiUEVSRk9STUFOQ0VfRU5EXCJdID0gXCJwZXJmOmVuZFwiO1xuXHREZXZUb29sc0hvb2tzW1wiQUREX1JPVVRFXCJdID0gXCJyb3V0ZXI6YWRkLXJvdXRlXCI7XG5cdERldlRvb2xzSG9va3NbXCJSRU1PVkVfUk9VVEVcIl0gPSBcInJvdXRlcjpyZW1vdmUtcm91dGVcIjtcblx0RGV2VG9vbHNIb29rc1tcIlJFTkRFUl9UUkFDS0VEXCJdID0gXCJyZW5kZXI6dHJhY2tlZFwiO1xuXHREZXZUb29sc0hvb2tzW1wiUkVOREVSX1RSSUdHRVJFRFwiXSA9IFwicmVuZGVyOnRyaWdnZXJlZFwiO1xuXHREZXZUb29sc0hvb2tzW1wiQVBQX0NPTk5FQ1RFRFwiXSA9IFwiYXBwOmNvbm5lY3RlZFwiO1xuXHREZXZUb29sc0hvb2tzW1wiU0VUVVBfREVWVE9PTFNfUExVR0lOXCJdID0gXCJkZXZ0b29scy1wbHVnaW46c2V0dXBcIjtcblx0cmV0dXJuIERldlRvb2xzSG9va3M7XG59KHt9KTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9ob29rL2luZGV4LnRzXG5jb25zdCBkZXZ0b29sc0hvb2tzID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0hPT0sgPz89IGNyZWF0ZUhvb2tzKCk7XG5jb25zdCBvbiA9IHtcblx0dnVlQXBwSW5pdChmbikge1xuXHRcdGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLkFQUF9JTklULCBmbik7XG5cdH0sXG5cdHZ1ZUFwcFVubW91bnQoZm4pIHtcblx0XHRkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5BUFBfVU5NT1VOVCwgZm4pO1xuXHR9LFxuXHR2dWVBcHBDb25uZWN0ZWQoZm4pIHtcblx0XHRkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5BUFBfQ09OTkVDVEVELCBmbik7XG5cdH0sXG5cdGNvbXBvbmVudEFkZGVkKGZuKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9BRERFRCwgZm4pO1xuXHR9LFxuXHRjb21wb25lbnRFbWl0KGZuKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9FTUlULCBmbik7XG5cdH0sXG5cdGNvbXBvbmVudFVwZGF0ZWQoZm4pIHtcblx0XHRyZXR1cm4gZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuQ09NUE9ORU5UX1VQREFURUQsIGZuKTtcblx0fSxcblx0Y29tcG9uZW50UmVtb3ZlZChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfUkVNT1ZFRCwgZm4pO1xuXHR9LFxuXHRzZXR1cERldnRvb2xzUGx1Z2luKGZuKSB7XG5cdFx0ZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuU0VUVVBfREVWVE9PTFNfUExVR0lOLCBmbik7XG5cdH0sXG5cdHBlcmZTdGFydChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9TVEFSVCwgZm4pO1xuXHR9LFxuXHRwZXJmRW5kKGZuKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLlBFUkZPUk1BTkNFX0VORCwgZm4pO1xuXHR9XG59O1xuZnVuY3Rpb24gY3JlYXRlRGV2VG9vbHNIb29rKCkge1xuXHRyZXR1cm4ge1xuXHRcdGlkOiBcInZ1ZS1kZXZ0b29scy1uZXh0XCIsXG5cdFx0ZGV2dG9vbHNWZXJzaW9uOiBcIjcuMFwiLFxuXHRcdGVuYWJsZWQ6IGZhbHNlLFxuXHRcdGFwcFJlY29yZHM6IFtdLFxuXHRcdGFwcHM6IFtdLFxuXHRcdGV2ZW50czogLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSxcblx0XHRvbihldmVudCwgZm4pIHtcblx0XHRcdGlmICghdGhpcy5ldmVudHMuaGFzKGV2ZW50KSkgdGhpcy5ldmVudHMuc2V0KGV2ZW50LCBbXSk7XG5cdFx0XHR0aGlzLmV2ZW50cy5nZXQoZXZlbnQpPy5wdXNoKGZuKTtcblx0XHRcdHJldHVybiAoKSA9PiB0aGlzLm9mZihldmVudCwgZm4pO1xuXHRcdH0sXG5cdFx0b25jZShldmVudCwgZm4pIHtcblx0XHRcdGNvbnN0IG9uY2VGbiA9ICguLi5hcmdzKSA9PiB7XG5cdFx0XHRcdHRoaXMub2ZmKGV2ZW50LCBvbmNlRm4pO1xuXHRcdFx0XHRmbiguLi5hcmdzKTtcblx0XHRcdH07XG5cdFx0XHR0aGlzLm9uKGV2ZW50LCBvbmNlRm4pO1xuXHRcdFx0cmV0dXJuIFtldmVudCwgb25jZUZuXTtcblx0XHR9LFxuXHRcdG9mZihldmVudCwgZm4pIHtcblx0XHRcdGlmICh0aGlzLmV2ZW50cy5oYXMoZXZlbnQpKSB7XG5cdFx0XHRcdGNvbnN0IGV2ZW50Q2FsbGJhY2tzID0gdGhpcy5ldmVudHMuZ2V0KGV2ZW50KTtcblx0XHRcdFx0Y29uc3QgaW5kZXggPSBldmVudENhbGxiYWNrcy5pbmRleE9mKGZuKTtcblx0XHRcdFx0aWYgKGluZGV4ICE9PSAtMSkgZXZlbnRDYWxsYmFja3Muc3BsaWNlKGluZGV4LCAxKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdGVtaXQoZXZlbnQsIC4uLnBheWxvYWQpIHtcblx0XHRcdGlmICh0aGlzLmV2ZW50cy5oYXMoZXZlbnQpKSB0aGlzLmV2ZW50cy5nZXQoZXZlbnQpLmZvckVhY2goKGZuKSA9PiBmbiguLi5wYXlsb2FkKSk7XG5cdFx0fVxuXHR9O1xufVxuZnVuY3Rpb24gc3Vic2NyaWJlRGV2VG9vbHNIb29rKGhvb2spIHtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLkFQUF9JTklULCAoYXBwLCB2ZXJzaW9uLCB0eXBlcykgPT4ge1xuXHRcdGlmIChhcHA/Ll9pbnN0YW5jZT8udHlwZT8uZGV2dG9vbHM/LmhpZGUpIHJldHVybjtcblx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuQVBQX0lOSVQsIGFwcCwgdmVyc2lvbiwgdHlwZXMpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLkFQUF9VTk1PVU5ULCAoYXBwKSA9PiB7XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkFQUF9VTk1PVU5ULCBhcHApO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9BRERFRCwgYXN5bmMgKGFwcCwgdWlkLCBwYXJlbnRVaWQsIGNvbXBvbmVudCkgPT4ge1xuXHRcdGlmIChhcHA/Ll9pbnN0YW5jZT8udHlwZT8uZGV2dG9vbHM/LmhpZGUgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0aWYgKCFhcHAgfHwgdHlwZW9mIHVpZCAhPT0gXCJudW1iZXJcIiAmJiAhdWlkIHx8ICFjb21wb25lbnQpIHJldHVybjtcblx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuQ09NUE9ORU5UX0FEREVELCBhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9VUERBVEVELCAoYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KSA9PiB7XG5cdFx0aWYgKCFhcHAgfHwgdHlwZW9mIHVpZCAhPT0gXCJudW1iZXJcIiAmJiAhdWlkIHx8ICFjb21wb25lbnQgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9VUERBVEVELCBhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9SRU1PVkVELCBhc3luYyAoYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KSA9PiB7XG5cdFx0aWYgKCFhcHAgfHwgdHlwZW9mIHVpZCAhPT0gXCJudW1iZXJcIiAmJiAhdWlkIHx8ICFjb21wb25lbnQgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9SRU1PVkVELCBhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9FTUlULCBhc3luYyAoYXBwLCBpbnN0YW5jZSwgZXZlbnQsIHBhcmFtcykgPT4ge1xuXHRcdGlmICghYXBwIHx8ICFpbnN0YW5jZSB8fCBkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuQ09NUE9ORU5UX0VNSVQsIGFwcCwgaW5zdGFuY2UsIGV2ZW50LCBwYXJhbXMpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLlBFUkZPUk1BTkNFX1NUQVJULCAoYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKSA9PiB7XG5cdFx0aWYgKCFhcHAgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLlBFUkZPUk1BTkNFX1NUQVJULCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLlBFUkZPUk1BTkNFX0VORCwgKGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkgPT4ge1xuXHRcdGlmICghYXBwIHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9FTkQsIGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSk7XG5cdH0pO1xuXHRob29rLm9uKERldlRvb2xzSG9va3MuU0VUVVBfREVWVE9PTFNfUExVR0lOLCAocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbiwgb3B0aW9ucykgPT4ge1xuXHRcdGlmIChvcHRpb25zPy50YXJnZXQgPT09IFwibGVnYWN5XCIpIHJldHVybjtcblx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuU0VUVVBfREVWVE9PTFNfUExVR0lOLCBwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKTtcblx0fSk7XG59XG5jb25zdCBob29rID0ge1xuXHRvbixcblx0c2V0dXBEZXZUb29sc1BsdWdpbihwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5TRVRVUF9ERVZUT09MU19QTFVHSU4sIHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FwaS92Ni9pbmRleC50c1xudmFyIERldlRvb2xzVjZQbHVnaW5BUEkgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKHsgcGx1Z2luLCBjdHggfSkge1xuXHRcdHRoaXMuaG9va3MgPSBjdHguaG9va3M7XG5cdFx0dGhpcy5wbHVnaW4gPSBwbHVnaW47XG5cdH1cblx0Z2V0IG9uKCkge1xuXHRcdHJldHVybiB7XG5cdFx0XHR2aXNpdENvbXBvbmVudFRyZWU6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuVklTSVRfQ09NUE9ORU5UX1RSRUUsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGluc3BlY3RDb21wb25lbnQ6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuSU5TUEVDVF9DT01QT05FTlQsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGVkaXRDb21wb25lbnRTdGF0ZTogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5FRElUX0NPTVBPTkVOVF9TVEFURSwgaGFuZGxlcik7XG5cdFx0XHR9LFxuXHRcdFx0Z2V0SW5zcGVjdG9yVHJlZTogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5HRVRfSU5TUEVDVE9SX1RSRUUsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGdldEluc3BlY3RvclN0YXRlOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLkdFVF9JTlNQRUNUT1JfU1RBVEUsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGVkaXRJbnNwZWN0b3JTdGF0ZTogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5FRElUX0lOU1BFQ1RPUl9TVEFURSwgaGFuZGxlcik7XG5cdFx0XHR9LFxuXHRcdFx0aW5zcGVjdFRpbWVsaW5lRXZlbnQ6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuSU5TUEVDVF9USU1FTElORV9FVkVOVCwgaGFuZGxlcik7XG5cdFx0XHR9LFxuXHRcdFx0dGltZWxpbmVDbGVhcmVkOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLlRJTUVMSU5FX0NMRUFSRUQsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdHNldFBsdWdpblNldHRpbmdzOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLlNFVF9QTFVHSU5fU0VUVElOR1MsIGhhbmRsZXIpO1xuXHRcdFx0fVxuXHRcdH07XG5cdH1cblx0bm90aWZ5Q29tcG9uZW50VXBkYXRlKGluc3RhbmNlKSB7XG5cdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGNvbnN0IGluc3BlY3RvciA9IGdldEFjdGl2ZUluc3BlY3RvcnMoKS5maW5kKChpKSA9PiBpLnBhY2thZ2VOYW1lID09PSB0aGlzLnBsdWdpbi5kZXNjcmlwdG9yLnBhY2thZ2VOYW1lKTtcblx0XHRpZiAoaW5zcGVjdG9yPy5pZCkge1xuXHRcdFx0aWYgKGluc3RhbmNlKSB7XG5cdFx0XHRcdGNvbnN0IGFyZ3MgPSBbXG5cdFx0XHRcdFx0aW5zdGFuY2UuYXBwQ29udGV4dC5hcHAsXG5cdFx0XHRcdFx0aW5zdGFuY2UudWlkLFxuXHRcdFx0XHRcdGluc3RhbmNlLnBhcmVudD8udWlkLFxuXHRcdFx0XHRcdGluc3RhbmNlXG5cdFx0XHRcdF07XG5cdFx0XHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfVVBEQVRFRCwgLi4uYXJncyk7XG5cdFx0XHR9IGVsc2UgZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9VUERBVEVEKTtcblx0XHRcdHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuU0VORF9JTlNQRUNUT1JfU1RBVEUsIHtcblx0XHRcdFx0aW5zcGVjdG9ySWQ6IGluc3BlY3Rvci5pZCxcblx0XHRcdFx0cGx1Z2luOiB0aGlzLnBsdWdpblxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdGFkZEluc3BlY3RvcihvcHRpb25zKSB7XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5BRERfSU5TUEVDVE9SLCB7XG5cdFx0XHRpbnNwZWN0b3I6IG9wdGlvbnMsXG5cdFx0XHRwbHVnaW46IHRoaXMucGx1Z2luXG5cdFx0fSk7XG5cdFx0aWYgKHRoaXMucGx1Z2luLmRlc2NyaXB0b3Iuc2V0dGluZ3MpIGluaXRQbHVnaW5TZXR0aW5ncyhvcHRpb25zLmlkLCB0aGlzLnBsdWdpbi5kZXNjcmlwdG9yLnNldHRpbmdzKTtcblx0fVxuXHRzZW5kSW5zcGVjdG9yVHJlZShpbnNwZWN0b3JJZCkge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHR0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1RSRUUsIHtcblx0XHRcdGluc3BlY3RvcklkLFxuXHRcdFx0cGx1Z2luOiB0aGlzLnBsdWdpblxuXHRcdH0pO1xuXHR9XG5cdHNlbmRJbnNwZWN0b3JTdGF0ZShpbnNwZWN0b3JJZCkge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHR0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1NUQVRFLCB7XG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHR9KTtcblx0fVxuXHRzZWxlY3RJbnNwZWN0b3JOb2RlKGluc3BlY3RvcklkLCBub2RlSWQpIHtcblx0XHR0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNVU1RPTV9JTlNQRUNUT1JfU0VMRUNUX05PREUsIHtcblx0XHRcdGluc3BlY3RvcklkLFxuXHRcdFx0bm9kZUlkLFxuXHRcdFx0cGx1Z2luOiB0aGlzLnBsdWdpblxuXHRcdH0pO1xuXHR9XG5cdHZpc2l0Q29tcG9uZW50VHJlZShwYXlsb2FkKSB7XG5cdFx0cmV0dXJuIHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLlZJU0lUX0NPTVBPTkVOVF9UUkVFLCBwYXlsb2FkKTtcblx0fVxuXHRub3coKSB7XG5cdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuIDA7XG5cdFx0cmV0dXJuIERhdGUubm93KCk7XG5cdH1cblx0YWRkVGltZWxpbmVMYXllcihvcHRpb25zKSB7XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5USU1FTElORV9MQVlFUl9BRERFRCwge1xuXHRcdFx0b3B0aW9ucyxcblx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHR9KTtcblx0fVxuXHRhZGRUaW1lbGluZUV2ZW50KG9wdGlvbnMpIHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5USU1FTElORV9FVkVOVF9BRERFRCwge1xuXHRcdFx0b3B0aW9ucyxcblx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHR9KTtcblx0fVxuXHRnZXRTZXR0aW5ncyhwbHVnaW5JZCkge1xuXHRcdHJldHVybiBnZXRQbHVnaW5TZXR0aW5ncyhwbHVnaW5JZCA/PyB0aGlzLnBsdWdpbi5kZXNjcmlwdG9yLmlkLCB0aGlzLnBsdWdpbi5kZXNjcmlwdG9yLnNldHRpbmdzKTtcblx0fVxuXHRnZXRDb21wb25lbnRJbnN0YW5jZXMoYXBwKSB7XG5cdFx0cmV0dXJuIHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9JTlNUQU5DRVMsIHsgYXBwIH0pO1xuXHR9XG5cdGdldENvbXBvbmVudEJvdW5kcyhpbnN0YW5jZSkge1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkdFVF9DT01QT05FTlRfQk9VTkRTLCB7IGluc3RhbmNlIH0pO1xuXHR9XG5cdGdldENvbXBvbmVudE5hbWUoaW5zdGFuY2UpIHtcblx0XHRyZXR1cm4gdGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5HRVRfQ09NUE9ORU5UX05BTUUsIHsgaW5zdGFuY2UgfSk7XG5cdH1cblx0aGlnaGxpZ2h0RWxlbWVudChpbnN0YW5jZSkge1xuXHRcdGNvbnN0IHVpZCA9IGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX187XG5cdFx0cmV0dXJuIHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuQ09NUE9ORU5UX0hJR0hMSUdIVCwgeyB1aWQgfSk7XG5cdH1cblx0dW5oaWdobGlnaHRFbGVtZW50KCkge1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNPTVBPTkVOVF9VTkhJR0hMSUdIVCk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYXBpL2luZGV4LnRzXG5jb25zdCBEZXZUb29sc1BsdWdpbkFQSSA9IERldlRvb2xzVjZQbHVnaW5BUEk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvY29uc3RhbnRzLnRzXG5jb25zdCB2dWVCdWlsdGlucyA9IG5ldyBTZXQoW1xuXHRcIm5leHRUaWNrXCIsXG5cdFwiZGVmaW5lQ29tcG9uZW50XCIsXG5cdFwiZGVmaW5lQXN5bmNDb21wb25lbnRcIixcblx0XCJkZWZpbmVDdXN0b21FbGVtZW50XCIsXG5cdFwicmVmXCIsXG5cdFwiY29tcHV0ZWRcIixcblx0XCJyZWFjdGl2ZVwiLFxuXHRcInJlYWRvbmx5XCIsXG5cdFwid2F0Y2hFZmZlY3RcIixcblx0XCJ3YXRjaFBvc3RFZmZlY3RcIixcblx0XCJ3YXRjaFN5bmNFZmZlY3RcIixcblx0XCJ3YXRjaFwiLFxuXHRcImlzUmVmXCIsXG5cdFwidW5yZWZcIixcblx0XCJ0b1JlZlwiLFxuXHRcInRvUmVmc1wiLFxuXHRcImlzUHJveHlcIixcblx0XCJpc1JlYWN0aXZlXCIsXG5cdFwiaXNSZWFkb25seVwiLFxuXHRcInNoYWxsb3dSZWZcIixcblx0XCJ0cmlnZ2VyUmVmXCIsXG5cdFwiY3VzdG9tUmVmXCIsXG5cdFwic2hhbGxvd1JlYWN0aXZlXCIsXG5cdFwic2hhbGxvd1JlYWRvbmx5XCIsXG5cdFwidG9SYXdcIixcblx0XCJtYXJrUmF3XCIsXG5cdFwiZWZmZWN0U2NvcGVcIixcblx0XCJnZXRDdXJyZW50U2NvcGVcIixcblx0XCJvblNjb3BlRGlzcG9zZVwiLFxuXHRcIm9uTW91bnRlZFwiLFxuXHRcIm9uVXBkYXRlZFwiLFxuXHRcIm9uVW5tb3VudGVkXCIsXG5cdFwib25CZWZvcmVNb3VudFwiLFxuXHRcIm9uQmVmb3JlVXBkYXRlXCIsXG5cdFwib25CZWZvcmVVbm1vdW50XCIsXG5cdFwib25FcnJvckNhcHR1cmVkXCIsXG5cdFwib25SZW5kZXJUcmFja2VkXCIsXG5cdFwib25SZW5kZXJUcmlnZ2VyZWRcIixcblx0XCJvbkFjdGl2YXRlZFwiLFxuXHRcIm9uRGVhY3RpdmF0ZWRcIixcblx0XCJvblNlcnZlclByZWZldGNoXCIsXG5cdFwicHJvdmlkZVwiLFxuXHRcImluamVjdFwiLFxuXHRcImhcIixcblx0XCJtZXJnZVByb3BzXCIsXG5cdFwiY2xvbmVWTm9kZVwiLFxuXHRcImlzVk5vZGVcIixcblx0XCJyZXNvbHZlQ29tcG9uZW50XCIsXG5cdFwicmVzb2x2ZURpcmVjdGl2ZVwiLFxuXHRcIndpdGhEaXJlY3RpdmVzXCIsXG5cdFwid2l0aE1vZGlmaWVyc1wiXG5dKTtcbmNvbnN0IHN5bWJvbFJFID0gL15cXFtuYXRpdmUgU3ltYm9sIFN5bWJvbFxcKCguKilcXClcXF0kLztcbmNvbnN0IHJhd1R5cGVSRSA9IC9eXFxbb2JqZWN0IChcXHcrKVxcXSQvO1xuY29uc3Qgc3BlY2lhbFR5cGVSRSA9IC9eXFxbbmF0aXZlIChcXHcrKSAoLio/KSg8PigoW1xcc1xcU10pKikpP1xcXSQvO1xuY29uc3QgZm5UeXBlUkUgPSAvXig/OmZ1bmN0aW9ufGNsYXNzKSAoXFx3KykvO1xuY29uc3QgTUFYX1NUUklOR19TSVpFID0gMWU0O1xuY29uc3QgTUFYX0FSUkFZX1NJWkUgPSA1ZTM7XG5jb25zdCBVTkRFRklORUQgPSBcIl9fdnVlX2RldnRvb2xfdW5kZWZpbmVkX19cIjtcbmNvbnN0IElORklOSVRZID0gXCJfX3Z1ZV9kZXZ0b29sX2luZmluaXR5X19cIjtcbmNvbnN0IE5FR0FUSVZFX0lORklOSVRZID0gXCJfX3Z1ZV9kZXZ0b29sX25lZ2F0aXZlX2luZmluaXR5X19cIjtcbmNvbnN0IE5BTiA9IFwiX192dWVfZGV2dG9vbF9uYW5fX1wiO1xuY29uc3QgRVNDID0ge1xuXHRcIjxcIjogXCImbHQ7XCIsXG5cdFwiPlwiOiBcIiZndDtcIixcblx0XCJcXFwiXCI6IFwiJnF1b3Q7XCIsXG5cdFwiJlwiOiBcIiZhbXA7XCJcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvaXMudHNcbmZ1bmN0aW9uIGlzVnVlSW5zdGFuY2UodmFsdWUpIHtcblx0aWYgKCFlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWx1ZSwgXCJfXCIpKSByZXR1cm4gZmFsc2U7XG5cdGlmICghaXNQbGFpbk9iamVjdCh2YWx1ZS5fKSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gT2JqZWN0LmtleXModmFsdWUuXykuaW5jbHVkZXMoXCJ2bm9kZVwiKTtcbn1cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qob2JqKSB7XG5cdHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob2JqKSA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbn1cbmZ1bmN0aW9uIGlzUHJpbWl0aXZlJDEoZGF0YSkge1xuXHRpZiAoZGF0YSA9PSBudWxsKSByZXR1cm4gdHJ1ZTtcblx0Y29uc3QgdHlwZSA9IHR5cGVvZiBkYXRhO1xuXHRyZXR1cm4gdHlwZSA9PT0gXCJzdHJpbmdcIiB8fCB0eXBlID09PSBcIm51bWJlclwiIHx8IHR5cGUgPT09IFwiYm9vbGVhblwiO1xufVxuZnVuY3Rpb24gaXNSZWYocmF3KSB7XG5cdHJldHVybiAhIXJhdy5fX3ZfaXNSZWY7XG59XG5mdW5jdGlvbiBpc0NvbXB1dGVkKHJhdykge1xuXHRyZXR1cm4gaXNSZWYocmF3KSAmJiAhIXJhdy5lZmZlY3Q7XG59XG5mdW5jdGlvbiBpc1JlYWN0aXZlKHJhdykge1xuXHRyZXR1cm4gISFyYXcuX192X2lzUmVhY3RpdmU7XG59XG5mdW5jdGlvbiBpc1JlYWRPbmx5KHJhdykge1xuXHRyZXR1cm4gISFyYXcuX192X2lzUmVhZG9ubHk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvdXRpbC50c1xuY29uc3QgdG9rZW5NYXAgPSB7XG5cdFtVTkRFRklORURdOiBcInVuZGVmaW5lZFwiLFxuXHRbTkFOXTogXCJOYU5cIixcblx0W0lORklOSVRZXTogXCJJbmZpbml0eVwiLFxuXHRbTkVHQVRJVkVfSU5GSU5JVFldOiBcIi1JbmZpbml0eVwiXG59O1xuY29uc3QgcmV2ZXJzZWRUb2tlbk1hcCA9IE9iamVjdC5lbnRyaWVzKHRva2VuTWFwKS5yZWR1Y2UoKGFjYywgW2tleSwgdmFsdWVdKSA9PiB7XG5cdGFjY1t2YWx1ZV0gPSBrZXk7XG5cdHJldHVybiBhY2M7XG59LCB7fSk7XG5mdW5jdGlvbiBpbnRlcm5hbFN0YXRlVG9rZW5Ub1N0cmluZyh2YWx1ZSkge1xuXHRpZiAodmFsdWUgPT09IG51bGwpIHJldHVybiBcIm51bGxcIjtcblx0cmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIiAmJiB0b2tlbk1hcFt2YWx1ZV0gfHwgZmFsc2U7XG59XG5mdW5jdGlvbiByZXBsYWNlVG9rZW5Ub1N0cmluZyh2YWx1ZSkge1xuXHRjb25zdCByZXBsYWNlUmVnZXggPSBuZXcgUmVnRXhwKGBcIigke09iamVjdC5rZXlzKHRva2VuTWFwKS5qb2luKFwifFwiKX0pXCJgLCBcImdcIik7XG5cdHJldHVybiB2YWx1ZS5yZXBsYWNlKHJlcGxhY2VSZWdleCwgKF8sIGcxKSA9PiB0b2tlbk1hcFtnMV0pO1xufVxuZnVuY3Rpb24gcmVwbGFjZVN0cmluZ1RvVG9rZW4odmFsdWUpIHtcblx0Y29uc3QgbGl0ZXJhbFZhbHVlID0gcmV2ZXJzZWRUb2tlbk1hcFt2YWx1ZS50cmltKCldO1xuXHRpZiAobGl0ZXJhbFZhbHVlKSByZXR1cm4gYFwiJHtsaXRlcmFsVmFsdWV9XCJgO1xuXHRjb25zdCByZXBsYWNlUmVnZXggPSBuZXcgUmVnRXhwKGA6XFxcXHMqKCR7T2JqZWN0LmtleXMocmV2ZXJzZWRUb2tlbk1hcCkuam9pbihcInxcIil9KWAsIFwiZ1wiKTtcblx0cmV0dXJuIHZhbHVlLnJlcGxhY2UocmVwbGFjZVJlZ2V4LCAoXywgZzEpID0+IGA6XCIke3JldmVyc2VkVG9rZW5NYXBbZzFdfVwiYCk7XG59XG4vKipcbiogQ29udmVydCBwcm9wIHR5cGUgY29uc3RydWN0b3IgdG8gc3RyaW5nLlxuKi9cbmZ1bmN0aW9uIGdldFByb3BUeXBlKHR5cGUpIHtcblx0aWYgKEFycmF5LmlzQXJyYXkodHlwZSkpIHJldHVybiB0eXBlLm1hcCgodCkgPT4gZ2V0UHJvcFR5cGUodCkpLmpvaW4oXCIgb3IgXCIpO1xuXHRpZiAodHlwZSA9PSBudWxsKSByZXR1cm4gXCJudWxsXCI7XG5cdGNvbnN0IG1hdGNoID0gdHlwZS50b1N0cmluZygpLm1hdGNoKGZuVHlwZVJFKTtcblx0cmV0dXJuIHR5cGVvZiB0eXBlID09PSBcImZ1bmN0aW9uXCIgPyBtYXRjaCAmJiBtYXRjaFsxXSB8fCBcImFueVwiIDogXCJhbnlcIjtcbn1cbi8qKlxuKiBTYW5pdGl6ZSBkYXRhIHRvIGJlIHBvc3RlZCB0byB0aGUgb3RoZXIgc2lkZS5cbiogU2luY2UgdGhlIG1lc3NhZ2UgcG9zdGVkIGlzIHNlbnQgd2l0aCBzdHJ1Y3R1cmVkIGNsb25lLFxuKiB3ZSBuZWVkIHRvIGZpbHRlciBvdXQgYW55IHR5cGVzIHRoYXQgbWlnaHQgY2F1c2UgYW4gZXJyb3IuXG4qL1xuZnVuY3Rpb24gc2FuaXRpemUoZGF0YSkge1xuXHRpZiAoIWlzUHJpbWl0aXZlJDEoZGF0YSkgJiYgIUFycmF5LmlzQXJyYXkoZGF0YSkgJiYgIWlzUGxhaW5PYmplY3QoZGF0YSkpIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoZGF0YSk7XG5cdGVsc2UgcmV0dXJuIGRhdGE7XG59XG5mdW5jdGlvbiBnZXRTZXR1cFN0YXRlVHlwZShyYXcpIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0cmVmOiBpc1JlZihyYXcpLFxuXHRcdFx0Y29tcHV0ZWQ6IGlzQ29tcHV0ZWQocmF3KSxcblx0XHRcdHJlYWN0aXZlOiBpc1JlYWN0aXZlKHJhdyksXG5cdFx0XHRyZWFkb25seTogaXNSZWFkT25seShyYXcpXG5cdFx0fTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHJlZjogZmFsc2UsXG5cdFx0XHRjb21wdXRlZDogZmFsc2UsXG5cdFx0XHRyZWFjdGl2ZTogZmFsc2UsXG5cdFx0XHRyZWFkb25seTogZmFsc2Vcblx0XHR9O1xuXHR9XG59XG5mdW5jdGlvbiB0b1Jhdyh2YWx1ZSkge1xuXHRpZiAodmFsdWU/Ll9fdl9yYXcpIHJldHVybiB2YWx1ZS5fX3ZfcmF3O1xuXHRyZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiBlc2NhcGUocykge1xuXHRyZXR1cm4gcy5yZXBsYWNlKC9bPD5cIiZdL2csIChzKSA9PiB7XG5cdFx0cmV0dXJuIEVTQ1tzXSB8fCBzO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9wcm9jZXNzLnRzXG5mdW5jdGlvbiBtZXJnZU9wdGlvbnModG8sIGZyb20sIGluc3RhbmNlKSB7XG5cdGlmICh0eXBlb2YgZnJvbSA9PT0gXCJmdW5jdGlvblwiKSBmcm9tID0gZnJvbS5vcHRpb25zO1xuXHRpZiAoIWZyb20pIHJldHVybiB0bztcblx0Y29uc3QgeyBtaXhpbnMsIGV4dGVuZHM6IGV4dGVuZHNPcHRpb25zIH0gPSBmcm9tO1xuXHRleHRlbmRzT3B0aW9ucyAmJiBtZXJnZU9wdGlvbnModG8sIGV4dGVuZHNPcHRpb25zLCBpbnN0YW5jZSk7XG5cdG1peGlucyAmJiBtaXhpbnMuZm9yRWFjaCgobSkgPT4gbWVyZ2VPcHRpb25zKHRvLCBtLCBpbnN0YW5jZSkpO1xuXHRmb3IgKGNvbnN0IGtleSBvZiBbXCJjb21wdXRlZFwiLCBcImluamVjdFwiXSkgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChmcm9tLCBrZXkpKSB7XG5cdFx0dG9ba2V5XSA/Pz0ge307XG5cdFx0T2JqZWN0LmFzc2lnbih0b1trZXldLCBmcm9tW2tleV0pO1xuXHR9XG5cdHJldHVybiB0bztcbn1cbmZ1bmN0aW9uIHJlc29sdmVNZXJnZWRPcHRpb25zKGluc3RhbmNlKSB7XG5cdGNvbnN0IHJhdyA9IGluc3RhbmNlPy50eXBlO1xuXHRpZiAoIXJhdykgcmV0dXJuIHt9O1xuXHRjb25zdCB7IG1peGlucywgZXh0ZW5kczogZXh0ZW5kc09wdGlvbnMgfSA9IHJhdztcblx0Y29uc3QgZ2xvYmFsTWl4aW5zID0gaW5zdGFuY2UuYXBwQ29udGV4dC5taXhpbnM7XG5cdGlmICghZ2xvYmFsTWl4aW5zLmxlbmd0aCAmJiAhbWl4aW5zICYmICFleHRlbmRzT3B0aW9ucykgcmV0dXJuIHJhdztcblx0Y29uc3Qgb3B0aW9ucyA9IHt9O1xuXHRnbG9iYWxNaXhpbnMuZm9yRWFjaCgobSkgPT4gbWVyZ2VPcHRpb25zKG9wdGlvbnMsIG0sIGluc3RhbmNlKSk7XG5cdG1lcmdlT3B0aW9ucyhvcHRpb25zLCByYXcsIGluc3RhbmNlKTtcblx0cmV0dXJuIG9wdGlvbnM7XG59XG4vKipcbiogUHJvY2VzcyB0aGUgcHJvcHMgb2YgYW4gaW5zdGFuY2UuXG4qIE1ha2Ugc3VyZSByZXR1cm4gYSBwbGFpbiBvYmplY3QgYmVjYXVzZSB3aW5kb3cucG9zdE1lc3NhZ2UoKVxuKiB3aWxsIHRocm93IGFuIEVycm9yIGlmIHRoZSBwYXNzZWQgb2JqZWN0IGNvbnRhaW5zIEZ1bmN0aW9ucy5cbipcbiovXG5mdW5jdGlvbiBwcm9jZXNzUHJvcHMoaW5zdGFuY2UpIHtcblx0Y29uc3QgcHJvcHMgPSBbXTtcblx0Y29uc3QgcHJvcERlZmluaXRpb25zID0gaW5zdGFuY2U/LnR5cGU/LnByb3BzO1xuXHRmb3IgKGNvbnN0IGtleSBpbiBpbnN0YW5jZT8ucHJvcHMpIHtcblx0XHRjb25zdCBwcm9wRGVmaW5pdGlvbiA9IHByb3BEZWZpbml0aW9ucyA/IHByb3BEZWZpbml0aW9uc1trZXldIDogbnVsbDtcblx0XHRjb25zdCBjYW1lbGl6ZUtleSA9IGNhbWVsaXplKGtleSk7XG5cdFx0cHJvcHMucHVzaCh7XG5cdFx0XHR0eXBlOiBcInByb3BzXCIsXG5cdFx0XHRrZXk6IGNhbWVsaXplS2V5LFxuXHRcdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGluc3RhbmNlLnByb3BzW2tleV0pLFxuXHRcdFx0ZWRpdGFibGU6IHRydWUsXG5cdFx0XHRtZXRhOiBwcm9wRGVmaW5pdGlvbiA/IHtcblx0XHRcdFx0dHlwZTogcHJvcERlZmluaXRpb24udHlwZSA/IGdldFByb3BUeXBlKHByb3BEZWZpbml0aW9uLnR5cGUpIDogXCJhbnlcIixcblx0XHRcdFx0cmVxdWlyZWQ6ICEhcHJvcERlZmluaXRpb24ucmVxdWlyZWQsXG5cdFx0XHRcdC4uLnByb3BEZWZpbml0aW9uLmRlZmF1bHQgPyB7IGRlZmF1bHQ6IHByb3BEZWZpbml0aW9uLmRlZmF1bHQudG9TdHJpbmcoKSB9IDoge31cblx0XHRcdH0gOiB7IHR5cGU6IFwiaW52YWxpZFwiIH1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gcHJvcHM7XG59XG4vKipcbiogUHJvY2VzcyBzdGF0ZSwgZmlsdGVyaW5nIG91dCBwcm9wcyBhbmQgXCJjbGVhblwiIHRoZSByZXN1bHRcbiogd2l0aCBhIEpTT04gZGFuY2UuIFRoaXMgcmVtb3ZlcyBmdW5jdGlvbnMgd2hpY2ggY2FuIGNhdXNlXG4qIGVycm9ycyBkdXJpbmcgc3RydWN0dXJlZCBjbG9uZSB1c2VkIGJ5IHdpbmRvdy5wb3N0TWVzc2FnZS5cbipcbiovXG5mdW5jdGlvbiBwcm9jZXNzU3RhdGUoaW5zdGFuY2UpIHtcblx0Y29uc3QgdHlwZSA9IGluc3RhbmNlLnR5cGU7XG5cdGNvbnN0IHByb3BzID0gdHlwZT8ucHJvcHM7XG5cdGNvbnN0IGdldHRlcnMgPSB0eXBlLnZ1ZXggJiYgdHlwZS52dWV4LmdldHRlcnM7XG5cdGNvbnN0IGNvbXB1dGVkRGVmcyA9IHR5cGUuY29tcHV0ZWQ7XG5cdGNvbnN0IGRhdGEgPSB7XG5cdFx0Li4uaW5zdGFuY2UuZGF0YSxcblx0XHQuLi5pbnN0YW5jZS5yZW5kZXJDb250ZXh0XG5cdH07XG5cdHJldHVybiBPYmplY3Qua2V5cyhkYXRhKS5maWx0ZXIoKGtleSkgPT4gIShwcm9wcyAmJiBrZXkgaW4gcHJvcHMpICYmICEoZ2V0dGVycyAmJiBrZXkgaW4gZ2V0dGVycykgJiYgIShjb21wdXRlZERlZnMgJiYga2V5IGluIGNvbXB1dGVkRGVmcykpLm1hcCgoa2V5KSA9PiAoe1xuXHRcdGtleSxcblx0XHR0eXBlOiBcImRhdGFcIixcblx0XHR2YWx1ZTogcmV0dXJuRXJyb3IoKCkgPT4gZGF0YVtrZXldKSxcblx0XHRlZGl0YWJsZTogdHJ1ZVxuXHR9KSk7XG59XG5mdW5jdGlvbiBnZXRTdGF0ZVR5cGVBbmROYW1lKGluZm8pIHtcblx0Y29uc3Qgc3RhdGVUeXBlID0gaW5mby5jb21wdXRlZCA/IFwiY29tcHV0ZWRcIiA6IGluZm8ucmVmID8gXCJyZWZcIiA6IGluZm8ucmVhY3RpdmUgPyBcInJlYWN0aXZlXCIgOiBudWxsO1xuXHRyZXR1cm4ge1xuXHRcdHN0YXRlVHlwZSxcblx0XHRzdGF0ZVR5cGVOYW1lOiBzdGF0ZVR5cGUgPyBgJHtzdGF0ZVR5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9JHtzdGF0ZVR5cGUuc2xpY2UoMSl9YCA6IG51bGxcblx0fTtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NTZXR1cFN0YXRlKGluc3RhbmNlKSB7XG5cdGNvbnN0IHJhdyA9IGluc3RhbmNlLmRldnRvb2xzUmF3U2V0dXBTdGF0ZSB8fCB7fTtcblx0cmV0dXJuIE9iamVjdC5rZXlzKGluc3RhbmNlLnNldHVwU3RhdGUpLmZpbHRlcigoa2V5KSA9PiAhdnVlQnVpbHRpbnMuaGFzKGtleSkgJiYga2V5LnNwbGl0KC8oPz1bQS1aXSkvKVswXSAhPT0gXCJ1c2VcIikubWFwKChrZXkpID0+IHtcblx0XHRjb25zdCB2YWx1ZSA9IHJldHVybkVycm9yKCgpID0+IHRvUmF3KGluc3RhbmNlLnNldHVwU3RhdGVba2V5XSkpO1xuXHRcdGNvbnN0IGFjY2Vzc0Vycm9yID0gdmFsdWUgaW5zdGFuY2VvZiBFcnJvcjtcblx0XHRjb25zdCByYXdEYXRhID0gcmF3W2tleV07XG5cdFx0bGV0IHJlc3VsdDtcblx0XHRsZXQgaXNPdGhlclR5cGUgPSBhY2Nlc3NFcnJvciB8fCB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiB8fCBlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWx1ZSwgXCJyZW5kZXJcIikgJiYgdHlwZW9mIHZhbHVlLnJlbmRlciA9PT0gXCJmdW5jdGlvblwiIHx8IGVuc3VyZVByb3BlcnR5RXhpc3RzKHZhbHVlLCBcIl9fYXN5bmNMb2FkZXJcIikgJiYgdHlwZW9mIHZhbHVlLl9fYXN5bmNMb2FkZXIgPT09IFwiZnVuY3Rpb25cIiB8fCB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgJiYgKFwic2V0dXBcIiBpbiB2YWx1ZSB8fCBcInByb3BzXCIgaW4gdmFsdWUpIHx8IC9edltBLVpdLy50ZXN0KGtleSk7XG5cdFx0aWYgKHJhd0RhdGEgJiYgIWFjY2Vzc0Vycm9yKSB7XG5cdFx0XHRjb25zdCBpbmZvID0gZ2V0U2V0dXBTdGF0ZVR5cGUocmF3RGF0YSk7XG5cdFx0XHRjb25zdCB7IHN0YXRlVHlwZSwgc3RhdGVUeXBlTmFtZSB9ID0gZ2V0U3RhdGVUeXBlQW5kTmFtZShpbmZvKTtcblx0XHRcdGNvbnN0IGlzU3RhdGUgPSBpbmZvLnJlZiB8fCBpbmZvLmNvbXB1dGVkIHx8IGluZm8ucmVhY3RpdmU7XG5cdFx0XHRjb25zdCByYXcgPSBlbnN1cmVQcm9wZXJ0eUV4aXN0cyhyYXdEYXRhLCBcImVmZmVjdFwiKSA/IHJhd0RhdGEuZWZmZWN0Py5yYXc/LnRvU3RyaW5nKCkgfHwgcmF3RGF0YS5lZmZlY3Q/LmZuPy50b1N0cmluZygpIDogbnVsbDtcblx0XHRcdGlmIChzdGF0ZVR5cGUpIGlzT3RoZXJUeXBlID0gZmFsc2U7XG5cdFx0XHRyZXN1bHQgPSB7XG5cdFx0XHRcdC4uLnN0YXRlVHlwZSA/IHtcblx0XHRcdFx0XHRzdGF0ZVR5cGUsXG5cdFx0XHRcdFx0c3RhdGVUeXBlTmFtZVxuXHRcdFx0XHR9IDoge30sXG5cdFx0XHRcdC4uLnJhdyA/IHsgcmF3IH0gOiB7fSxcblx0XHRcdFx0ZWRpdGFibGU6IGlzU3RhdGUgJiYgIWluZm8ucmVhZG9ubHlcblx0XHRcdH07XG5cdFx0fVxuXHRcdHJldHVybiB7XG5cdFx0XHRrZXksXG5cdFx0XHR2YWx1ZSxcblx0XHRcdHR5cGU6IGlzT3RoZXJUeXBlID8gXCJzZXR1cCAob3RoZXIpXCIgOiBcInNldHVwXCIsXG5cdFx0XHQuLi5yZXN1bHRcblx0XHR9O1xuXHR9KTtcbn1cbi8qKlxuKiBQcm9jZXNzIHRoZSBjb21wdXRlZCBwcm9wZXJ0aWVzIG9mIGFuIGluc3RhbmNlLlxuKi9cbmZ1bmN0aW9uIHByb2Nlc3NDb21wdXRlZChpbnN0YW5jZSwgbWVyZ2VkVHlwZSkge1xuXHRjb25zdCB0eXBlID0gbWVyZ2VkVHlwZTtcblx0Y29uc3QgY29tcHV0ZWQgPSBbXTtcblx0Y29uc3QgZGVmcyA9IHR5cGUuY29tcHV0ZWQgfHwge307XG5cdGZvciAoY29uc3Qga2V5IGluIGRlZnMpIHtcblx0XHRjb25zdCBkZWYgPSBkZWZzW2tleV07XG5cdFx0Y29uc3QgdHlwZSA9IHR5cGVvZiBkZWYgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWYudnVleCA/IFwidnVleCBiaW5kaW5nc1wiIDogXCJjb21wdXRlZFwiO1xuXHRcdGNvbXB1dGVkLnB1c2goe1xuXHRcdFx0dHlwZSxcblx0XHRcdGtleSxcblx0XHRcdHZhbHVlOiByZXR1cm5FcnJvcigoKSA9PiBpbnN0YW5jZT8ucHJveHk/LltrZXldKSxcblx0XHRcdGVkaXRhYmxlOiB0eXBlb2YgZGVmLnNldCA9PT0gXCJmdW5jdGlvblwiXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIGNvbXB1dGVkO1xufVxuZnVuY3Rpb24gcHJvY2Vzc0F0dHJzKGluc3RhbmNlKSB7XG5cdHJldHVybiBPYmplY3Qua2V5cyhpbnN0YW5jZS5hdHRycykubWFwKChrZXkpID0+ICh7XG5cdFx0dHlwZTogXCJhdHRyc1wiLFxuXHRcdGtleSxcblx0XHR2YWx1ZTogcmV0dXJuRXJyb3IoKCkgPT4gaW5zdGFuY2UuYXR0cnNba2V5XSlcblx0fSkpO1xufVxuZnVuY3Rpb24gcHJvY2Vzc1Byb3ZpZGUoaW5zdGFuY2UpIHtcblx0cmV0dXJuIFJlZmxlY3Qub3duS2V5cyhpbnN0YW5jZS5wcm92aWRlcykubWFwKChrZXkpID0+ICh7XG5cdFx0dHlwZTogXCJwcm92aWRlZFwiLFxuXHRcdGtleToga2V5LnRvU3RyaW5nKCksXG5cdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGluc3RhbmNlLnByb3ZpZGVzW2tleV0pXG5cdH0pKTtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NJbmplY3QoaW5zdGFuY2UsIG1lcmdlZFR5cGUpIHtcblx0aWYgKCFtZXJnZWRUeXBlPy5pbmplY3QpIHJldHVybiBbXTtcblx0bGV0IGtleXMgPSBbXTtcblx0bGV0IGRlZmF1bHRWYWx1ZTtcblx0aWYgKEFycmF5LmlzQXJyYXkobWVyZ2VkVHlwZS5pbmplY3QpKSBrZXlzID0gbWVyZ2VkVHlwZS5pbmplY3QubWFwKChrZXkpID0+ICh7XG5cdFx0a2V5LFxuXHRcdG9yaWdpbmFsS2V5OiBrZXlcblx0fSkpO1xuXHRlbHNlIGtleXMgPSBSZWZsZWN0Lm93bktleXMobWVyZ2VkVHlwZS5pbmplY3QpLm1hcCgoa2V5KSA9PiB7XG5cdFx0Y29uc3QgdmFsdWUgPSBtZXJnZWRUeXBlLmluamVjdFtrZXldO1xuXHRcdGxldCBvcmlnaW5hbEtleTtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJzeW1ib2xcIikgb3JpZ2luYWxLZXkgPSB2YWx1ZTtcblx0XHRlbHNlIHtcblx0XHRcdG9yaWdpbmFsS2V5ID0gdmFsdWUuZnJvbTtcblx0XHRcdGRlZmF1bHRWYWx1ZSA9IHZhbHVlLmRlZmF1bHQ7XG5cdFx0fVxuXHRcdHJldHVybiB7XG5cdFx0XHRrZXksXG5cdFx0XHRvcmlnaW5hbEtleVxuXHRcdH07XG5cdH0pO1xuXHRyZXR1cm4ga2V5cy5tYXAoKHsga2V5LCBvcmlnaW5hbEtleSB9KSA9PiAoe1xuXHRcdHR5cGU6IFwiaW5qZWN0ZWRcIixcblx0XHRrZXk6IG9yaWdpbmFsS2V5ICYmIGtleSAhPT0gb3JpZ2luYWxLZXkgPyBgJHtvcmlnaW5hbEtleS50b1N0cmluZygpfSDinp4gJHtrZXkudG9TdHJpbmcoKX1gIDoga2V5LnRvU3RyaW5nKCksXG5cdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGluc3RhbmNlLmN0eC5oYXNPd25Qcm9wZXJ0eShrZXkpID8gaW5zdGFuY2UuY3R4W2tleV0gOiBpbnN0YW5jZS5wcm92aWRlcy5oYXNPd25Qcm9wZXJ0eShvcmlnaW5hbEtleSkgPyBpbnN0YW5jZS5wcm92aWRlc1tvcmlnaW5hbEtleV0gOiBkZWZhdWx0VmFsdWUpXG5cdH0pKTtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NSZWZzKGluc3RhbmNlKSB7XG5cdHJldHVybiBPYmplY3Qua2V5cyhpbnN0YW5jZS5yZWZzKS5tYXAoKGtleSkgPT4gKHtcblx0XHR0eXBlOiBcInRlbXBsYXRlIHJlZnNcIixcblx0XHRrZXksXG5cdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGluc3RhbmNlLnJlZnNba2V5XSlcblx0fSkpO1xufVxuY29uc3Qgdm5vZGVFdmVudHMgPSBuZXcgU2V0KFtcblx0XCJ2bm9kZS1iZWZvcmUtbW91bnRcIixcblx0XCJ2bm9kZS1tb3VudGVkXCIsXG5cdFwidm5vZGUtYmVmb3JlLXVwZGF0ZVwiLFxuXHRcInZub2RlLXVwZGF0ZWRcIixcblx0XCJ2bm9kZS1iZWZvcmUtdW5tb3VudFwiLFxuXHRcInZub2RlLXVubW91bnRlZFwiXG5dKTtcbmZ1bmN0aW9uIHByb2Nlc3NFdmVudExpc3RlbmVycyhpbnN0YW5jZSkge1xuXHRjb25zdCBlbWl0c0RlZmluaXRpb24gPSBpbnN0YW5jZS50eXBlLmVtaXRzO1xuXHRjb25zdCBkZWNsYXJlZEVtaXRzID0gQXJyYXkuaXNBcnJheShlbWl0c0RlZmluaXRpb24pID8gZW1pdHNEZWZpbml0aW9uIDogT2JqZWN0LmtleXMoZW1pdHNEZWZpbml0aW9uID8/IHt9KTtcblx0Y29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGluc3RhbmNlPy52bm9kZT8ucHJvcHMgPz8ge30pO1xuXHRjb25zdCByZXN1bHQgPSBbXTtcblx0Zm9yIChjb25zdCBrZXkgb2Yga2V5cykge1xuXHRcdGNvbnN0IFtwcmVmaXgsIC4uLmV2ZW50TmFtZVBhcnRzXSA9IGtleS5zcGxpdCgvKD89W0EtWl0pLyk7XG5cdFx0aWYgKHByZWZpeCA9PT0gXCJvblwiKSB7XG5cdFx0XHRjb25zdCBldmVudE5hbWUgPSBldmVudE5hbWVQYXJ0cy5qb2luKFwiLVwiKS50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0Y29uc3QgaXNCdWlsdEluID0gdm5vZGVFdmVudHMuaGFzKGV2ZW50TmFtZSk7XG5cdFx0XHRjb25zdCBpc0RlY2xhcmVkID0gZGVjbGFyZWRFbWl0cy5pbmNsdWRlcyhldmVudE5hbWUpIHx8IGRlY2xhcmVkRW1pdHMuaW5jbHVkZXMoY2FtZWxpemUoZXZlbnROYW1lKSk7XG5cdFx0XHRjb25zdCB0ZXh0ID0gaXNCdWlsdEluID8gXCLinIUgQnVpbHQtaW5cIiA6IGlzRGVjbGFyZWQgPyBcIuKchSBEZWNsYXJlZFwiIDogXCLimqDvuI8gTm90IGRlY2xhcmVkXCI7XG5cdFx0XHRyZXN1bHQucHVzaCh7XG5cdFx0XHRcdHR5cGU6IFwiZXZlbnQgbGlzdGVuZXJzXCIsXG5cdFx0XHRcdGtleTogZXZlbnROYW1lLFxuXHRcdFx0XHR2YWx1ZTogeyBfY3VzdG9tOiB7XG5cdFx0XHRcdFx0ZGlzcGxheVRleHQ6IHRleHQsXG5cdFx0XHRcdFx0a2V5OiB0ZXh0LFxuXHRcdFx0XHRcdHZhbHVlOiB0ZXh0LFxuXHRcdFx0XHRcdHRvb2x0aXBUZXh0OiBpc0J1aWx0SW4gPyBgVGhlIGV2ZW50IDxjb2RlPiR7ZXNjYXBlKGV2ZW50TmFtZSl9PC9jb2RlPiBpcyBwYXJ0IG9mIFZ1ZSBhbmQgZG9lc24ndCBuZWVkIHRvIGJlIGRlY2xhcmVkIGJ5IHRoZSBjb21wb25lbnRgIDogIWlzRGVjbGFyZWQgPyBgVGhlIGV2ZW50IDxjb2RlPiR7ZXNjYXBlKGV2ZW50TmFtZSl9PC9jb2RlPiBpcyBub3QgZGVjbGFyZWQgaW4gdGhlIDxjb2RlPmVtaXRzPC9jb2RlPiBvcHRpb24uIEl0IHdpbGwgbGVhayBpbnRvIHRoZSBjb21wb25lbnQncyBhdHRyaWJ1dGVzICg8Y29kZT4kYXR0cnM8L2NvZGU+KS5gIDogbnVsbFxuXHRcdFx0XHR9IH1cblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gcHJvY2Vzc0luc3RhbmNlU3RhdGUoaW5zdGFuY2UpIHtcblx0Y29uc3QgbWVyZ2VkVHlwZSA9IHJlc29sdmVNZXJnZWRPcHRpb25zKGluc3RhbmNlKTtcblx0cmV0dXJuIHByb2Nlc3NQcm9wcyhpbnN0YW5jZSkuY29uY2F0KHByb2Nlc3NTdGF0ZShpbnN0YW5jZSksIHByb2Nlc3NTZXR1cFN0YXRlKGluc3RhbmNlKSwgcHJvY2Vzc0NvbXB1dGVkKGluc3RhbmNlLCBtZXJnZWRUeXBlKSwgcHJvY2Vzc0F0dHJzKGluc3RhbmNlKSwgcHJvY2Vzc1Byb3ZpZGUoaW5zdGFuY2UpLCBwcm9jZXNzSW5qZWN0KGluc3RhbmNlLCBtZXJnZWRUeXBlKSwgcHJvY2Vzc1JlZnMoaW5zdGFuY2UpLCBwcm9jZXNzRXZlbnRMaXN0ZW5lcnMoaW5zdGFuY2UpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9pbmRleC50c1xuZnVuY3Rpb24gZ2V0SW5zdGFuY2VTdGF0ZShwYXJhbXMpIHtcblx0Y29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRJbnN0YW5jZShhY3RpdmVBcHBSZWNvcmQudmFsdWUsIHBhcmFtcy5pbnN0YW5jZUlkKTtcblx0cmV0dXJuIHtcblx0XHRpZDogZ2V0VW5pcXVlQ29tcG9uZW50SWQoaW5zdGFuY2UpLFxuXHRcdG5hbWU6IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSksXG5cdFx0ZmlsZTogaW5zdGFuY2U/LnR5cGU/Ll9fZmlsZSxcblx0XHRzdGF0ZTogcHJvY2Vzc0luc3RhbmNlU3RhdGUoaW5zdGFuY2UpLFxuXHRcdGluc3RhbmNlXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvdHJlZS9maWx0ZXIudHNcbnZhciBDb21wb25lbnRGaWx0ZXIgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKGZpbHRlcikge1xuXHRcdHRoaXMuZmlsdGVyID0gZmlsdGVyIHx8IFwiXCI7XG5cdH1cblx0LyoqXG5cdCogQ2hlY2sgaWYgYW4gaW5zdGFuY2UgaXMgcXVhbGlmaWVkLlxuXHQqXG5cdCogQHBhcmFtIHtWdWV8Vm5vZGV9IGluc3RhbmNlXG5cdCogQHJldHVybiB7Ym9vbGVhbn1cblx0Ki9cblx0aXNRdWFsaWZpZWQoaW5zdGFuY2UpIHtcblx0XHRjb25zdCBuYW1lID0gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKTtcblx0XHRyZXR1cm4gY2xhc3NpZnkobmFtZSkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0aGlzLmZpbHRlcikgfHwga2ViYWJpemUobmFtZSkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0aGlzLmZpbHRlcik7XG5cdH1cbn07XG5mdW5jdGlvbiBjcmVhdGVDb21wb25lbnRGaWx0ZXIoZmlsdGVyVGV4dCkge1xuXHRyZXR1cm4gbmV3IENvbXBvbmVudEZpbHRlcihmaWx0ZXJUZXh0KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC90cmVlL3dhbGtlci50c1xudmFyIENvbXBvbmVudFdhbGtlciA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHRoaXMuY2FwdHVyZUlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0Y29uc3QgeyBmaWx0ZXJUZXh0ID0gXCJcIiwgbWF4RGVwdGgsIHJlY3Vyc2l2ZWx5LCBhcGkgfSA9IG9wdGlvbnM7XG5cdFx0dGhpcy5jb21wb25lbnRGaWx0ZXIgPSBjcmVhdGVDb21wb25lbnRGaWx0ZXIoZmlsdGVyVGV4dCk7XG5cdFx0dGhpcy5tYXhEZXB0aCA9IG1heERlcHRoO1xuXHRcdHRoaXMucmVjdXJzaXZlbHkgPSByZWN1cnNpdmVseTtcblx0XHR0aGlzLmFwaSA9IGFwaTtcblx0fVxuXHRnZXRDb21wb25lbnRUcmVlKGluc3RhbmNlKSB7XG5cdFx0dGhpcy5jYXB0dXJlSWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRyZXR1cm4gdGhpcy5maW5kUXVhbGlmaWVkQ2hpbGRyZW4oaW5zdGFuY2UsIDApO1xuXHR9XG5cdGdldENvbXBvbmVudFBhcmVudHMoaW5zdGFuY2UpIHtcblx0XHR0aGlzLmNhcHR1cmVJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdGNvbnN0IHBhcmVudHMgPSBbXTtcblx0XHR0aGlzLmNhcHR1cmVJZChpbnN0YW5jZSk7XG5cdFx0bGV0IHBhcmVudCA9IGluc3RhbmNlO1xuXHRcdHdoaWxlIChwYXJlbnQgPSBwYXJlbnQucGFyZW50KSB7XG5cdFx0XHR0aGlzLmNhcHR1cmVJZChwYXJlbnQpO1xuXHRcdFx0cGFyZW50cy5wdXNoKHBhcmVudCk7XG5cdFx0fVxuXHRcdHJldHVybiBwYXJlbnRzO1xuXHR9XG5cdGNhcHR1cmVJZChpbnN0YW5jZSkge1xuXHRcdGlmICghaW5zdGFuY2UpIHJldHVybiBudWxsO1xuXHRcdGNvbnN0IGlkID0gaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyAhPSBudWxsID8gaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA6IGdldFVuaXF1ZUNvbXBvbmVudElkKGluc3RhbmNlKTtcblx0XHRpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fID0gaWQ7XG5cdFx0aWYgKHRoaXMuY2FwdHVyZUlkcy5oYXMoaWQpKSByZXR1cm4gbnVsbDtcblx0XHRlbHNlIHRoaXMuY2FwdHVyZUlkcy5zZXQoaWQsIHZvaWQgMCk7XG5cdFx0dGhpcy5tYXJrKGluc3RhbmNlKTtcblx0XHRyZXR1cm4gaWQ7XG5cdH1cblx0LyoqXG5cdCogQ2FwdHVyZSB0aGUgbWV0YSBpbmZvcm1hdGlvbiBvZiBhbiBpbnN0YW5jZS4gKHJlY3Vyc2l2ZSlcblx0KlxuXHQqIEBwYXJhbSB7VnVlfSBpbnN0YW5jZVxuXHQqIEByZXR1cm4ge29iamVjdH1cblx0Ki9cblx0YXN5bmMgY2FwdHVyZShpbnN0YW5jZSwgZGVwdGgpIHtcblx0XHRpZiAoIWluc3RhbmNlKSByZXR1cm4gbnVsbDtcblx0XHRjb25zdCBpZCA9IHRoaXMuY2FwdHVyZUlkKGluc3RhbmNlKTtcblx0XHRjb25zdCBuYW1lID0gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKTtcblx0XHRjb25zdCBjaGlsZHJlbiA9IHRoaXMuZ2V0SW50ZXJuYWxJbnN0YW5jZUNoaWxkcmVuKGluc3RhbmNlLnN1YlRyZWUpLmZpbHRlcigoY2hpbGQpID0+ICFpc0JlaW5nRGVzdHJveWVkKGNoaWxkKSk7XG5cdFx0Y29uc3QgcGFyZW50cyA9IHRoaXMuZ2V0Q29tcG9uZW50UGFyZW50cyhpbnN0YW5jZSkgfHwgW107XG5cdFx0Y29uc3QgaW5hY3RpdmUgPSAhIWluc3RhbmNlLmlzRGVhY3RpdmF0ZWQgfHwgcGFyZW50cy5zb21lKChwYXJlbnQpID0+IHBhcmVudC5pc0RlYWN0aXZhdGVkKTtcblx0XHRjb25zdCB0cmVlTm9kZSA9IHtcblx0XHRcdHVpZDogaW5zdGFuY2UudWlkLFxuXHRcdFx0aWQsXG5cdFx0XHRuYW1lLFxuXHRcdFx0cmVuZGVyS2V5OiBnZXRSZW5kZXJLZXkoaW5zdGFuY2Uudm5vZGUgPyBpbnN0YW5jZS52bm9kZS5rZXkgOiBudWxsKSxcblx0XHRcdGluYWN0aXZlLFxuXHRcdFx0Y2hpbGRyZW46IFtdLFxuXHRcdFx0aGFzQ2hpbGRyZW46ICEhY2hpbGRyZW4ubGVuZ3RoLFxuXHRcdFx0aXNGcmFnbWVudDogaXNGcmFnbWVudChpbnN0YW5jZSksXG5cdFx0XHR0YWdzOiB0eXBlb2YgaW5zdGFuY2UudHlwZSAhPT0gXCJmdW5jdGlvblwiID8gW10gOiBbe1xuXHRcdFx0XHRsYWJlbDogXCJmdW5jdGlvbmFsXCIsXG5cdFx0XHRcdHRleHRDb2xvcjogNTU5MjQwNSxcblx0XHRcdFx0YmFja2dyb3VuZENvbG9yOiAxNTY1ODczNFxuXHRcdFx0fV0sXG5cdFx0XHRhdXRvT3BlbjogdGhpcy5yZWN1cnNpdmVseSxcblx0XHRcdGZpbGU6IGluc3RhbmNlLnR5cGUuX19maWxlIHx8IFwiXCJcblx0XHR9O1xuXHRcdGlmIChkZXB0aCA8IHRoaXMubWF4RGVwdGggfHwgaW5zdGFuY2UudHlwZS5fX2lzS2VlcEFsaXZlIHx8IHBhcmVudHMuc29tZSgocGFyZW50KSA9PiBwYXJlbnQudHlwZS5fX2lzS2VlcEFsaXZlKSkgdHJlZU5vZGUuY2hpbGRyZW4gPSBhd2FpdCBQcm9taXNlLmFsbChjaGlsZHJlbi5tYXAoKGNoaWxkKSA9PiB0aGlzLmNhcHR1cmUoY2hpbGQsIGRlcHRoICsgMSkpLmZpbHRlcihCb29sZWFuKSk7XG5cdFx0aWYgKHRoaXMuaXNLZWVwQWxpdmUoaW5zdGFuY2UpKSB7XG5cdFx0XHRjb25zdCBjYWNoZWRDb21wb25lbnRzID0gdGhpcy5nZXRLZWVwQWxpdmVDYWNoZWRJbnN0YW5jZXMoaW5zdGFuY2UpO1xuXHRcdFx0Y29uc3QgY2hpbGRyZW5JZHMgPSBjaGlsZHJlbi5tYXAoKGNoaWxkKSA9PiBjaGlsZC5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fKTtcblx0XHRcdGZvciAoY29uc3QgY2FjaGVkQ2hpbGQgb2YgY2FjaGVkQ29tcG9uZW50cykgaWYgKCFjaGlsZHJlbklkcy5pbmNsdWRlcyhjYWNoZWRDaGlsZC5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fKSkge1xuXHRcdFx0XHRjb25zdCBub2RlID0gYXdhaXQgdGhpcy5jYXB0dXJlKHtcblx0XHRcdFx0XHQuLi5jYWNoZWRDaGlsZCxcblx0XHRcdFx0XHRpc0RlYWN0aXZhdGVkOiB0cnVlXG5cdFx0XHRcdH0sIGRlcHRoICsgMSk7XG5cdFx0XHRcdGlmIChub2RlKSB0cmVlTm9kZS5jaGlsZHJlbi5wdXNoKG5vZGUpO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRjb25zdCBmaXJzdEVsZW1lbnQgPSBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoaW5zdGFuY2UpWzBdO1xuXHRcdGlmIChmaXJzdEVsZW1lbnQ/LnBhcmVudEVsZW1lbnQpIHtcblx0XHRcdGNvbnN0IHBhcmVudEluc3RhbmNlID0gaW5zdGFuY2UucGFyZW50O1xuXHRcdFx0Y29uc3QgcGFyZW50Um9vdEVsZW1lbnRzID0gcGFyZW50SW5zdGFuY2UgPyBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UocGFyZW50SW5zdGFuY2UpIDogW107XG5cdFx0XHRsZXQgZWwgPSBmaXJzdEVsZW1lbnQ7XG5cdFx0XHRjb25zdCBpbmRleExpc3QgPSBbXTtcblx0XHRcdGRvIHtcblx0XHRcdFx0aW5kZXhMaXN0LnB1c2goQXJyYXkuZnJvbShlbC5wYXJlbnRFbGVtZW50LmNoaWxkTm9kZXMpLmluZGV4T2YoZWwpKTtcblx0XHRcdFx0ZWwgPSBlbC5wYXJlbnRFbGVtZW50O1xuXHRcdFx0fSB3aGlsZSAoZWwucGFyZW50RWxlbWVudCAmJiBwYXJlbnRSb290RWxlbWVudHMubGVuZ3RoICYmICFwYXJlbnRSb290RWxlbWVudHMuaW5jbHVkZXMoZWwpKTtcblx0XHRcdHRyZWVOb2RlLmRvbU9yZGVyID0gaW5kZXhMaXN0LnJldmVyc2UoKTtcblx0XHR9IGVsc2UgdHJlZU5vZGUuZG9tT3JkZXIgPSBbLTFdO1xuXHRcdGlmIChpbnN0YW5jZS5zdXNwZW5zZT8uc3VzcGVuc2VLZXkpIHtcblx0XHRcdHRyZWVOb2RlLnRhZ3MucHVzaCh7XG5cdFx0XHRcdGxhYmVsOiBpbnN0YW5jZS5zdXNwZW5zZS5zdXNwZW5zZUtleSxcblx0XHRcdFx0YmFja2dyb3VuZENvbG9yOiAxNDk3OTgxMixcblx0XHRcdFx0dGV4dENvbG9yOiAxNjc3NzIxNVxuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLm1hcmsoaW5zdGFuY2UsIHRydWUpO1xuXHRcdH1cblx0XHR0aGlzLmFwaS52aXNpdENvbXBvbmVudFRyZWUoe1xuXHRcdFx0dHJlZU5vZGUsXG5cdFx0XHRjb21wb25lbnRJbnN0YW5jZTogaW5zdGFuY2UsXG5cdFx0XHRhcHA6IGluc3RhbmNlLmFwcENvbnRleHQuYXBwLFxuXHRcdFx0ZmlsdGVyOiB0aGlzLmNvbXBvbmVudEZpbHRlci5maWx0ZXJcblx0XHR9KTtcblx0XHRyZXR1cm4gdHJlZU5vZGU7XG5cdH1cblx0LyoqXG5cdCogRmluZCBxdWFsaWZpZWQgY2hpbGRyZW4gZnJvbSBhIHNpbmdsZSBpbnN0YW5jZS5cblx0KiBJZiB0aGUgaW5zdGFuY2UgaXRzZWxmIGlzIHF1YWxpZmllZCwganVzdCByZXR1cm4gaXRzZWxmLlxuXHQqIFRoaXMgaXMgb2sgYmVjYXVzZSBbXS5jb25jYXQgd29ya3MgaW4gYm90aCBjYXNlcy5cblx0KlxuXHQqIEBwYXJhbSB7VnVlfFZub2RlfSBpbnN0YW5jZVxuXHQqIEByZXR1cm4ge1Z1ZXxBcnJheX1cblx0Ki9cblx0YXN5bmMgZmluZFF1YWxpZmllZENoaWxkcmVuKGluc3RhbmNlLCBkZXB0aCkge1xuXHRcdGlmICh0aGlzLmNvbXBvbmVudEZpbHRlci5pc1F1YWxpZmllZChpbnN0YW5jZSkgJiYgIWluc3RhbmNlLnR5cGUuZGV2dG9vbHM/LmhpZGUpIHJldHVybiBbYXdhaXQgdGhpcy5jYXB0dXJlKGluc3RhbmNlLCBkZXB0aCldO1xuXHRcdGVsc2UgaWYgKGluc3RhbmNlLnN1YlRyZWUpIHtcblx0XHRcdGNvbnN0IGxpc3QgPSB0aGlzLmlzS2VlcEFsaXZlKGluc3RhbmNlKSA/IHRoaXMuZ2V0S2VlcEFsaXZlQ2FjaGVkSW5zdGFuY2VzKGluc3RhbmNlKSA6IHRoaXMuZ2V0SW50ZXJuYWxJbnN0YW5jZUNoaWxkcmVuKGluc3RhbmNlLnN1YlRyZWUpO1xuXHRcdFx0cmV0dXJuIHRoaXMuZmluZFF1YWxpZmllZENoaWxkcmVuRnJvbUxpc3QobGlzdCwgZGVwdGgpO1xuXHRcdH0gZWxzZSByZXR1cm4gW107XG5cdH1cblx0LyoqXG5cdCogSXRlcmF0ZSB0aHJvdWdoIGFuIGFycmF5IG9mIGluc3RhbmNlcyBhbmQgZmxhdHRlbiBpdCBpbnRvXG5cdCogYW4gYXJyYXkgb2YgcXVhbGlmaWVkIGluc3RhbmNlcy4gVGhpcyBpcyBhIGRlcHRoLWZpcnN0XG5cdCogdHJhdmVyc2FsIC0gZS5nLiBpZiBhbiBpbnN0YW5jZSBpcyBub3QgbWF0Y2hlZCwgd2Ugd2lsbFxuXHQqIHJlY3Vyc2l2ZWx5IGdvIGRlZXBlciB1bnRpbCBhIHF1YWxpZmllZCBjaGlsZCBpcyBmb3VuZC5cblx0KlxuXHQqIEBwYXJhbSB7QXJyYXl9IGluc3RhbmNlc1xuXHQqIEByZXR1cm4ge0FycmF5fVxuXHQqL1xuXHRhc3luYyBmaW5kUXVhbGlmaWVkQ2hpbGRyZW5Gcm9tTGlzdChpbnN0YW5jZXMsIGRlcHRoKSB7XG5cdFx0aW5zdGFuY2VzID0gaW5zdGFuY2VzLmZpbHRlcigoY2hpbGQpID0+ICFpc0JlaW5nRGVzdHJveWVkKGNoaWxkKSAmJiAhY2hpbGQudHlwZS5kZXZ0b29scz8uaGlkZSk7XG5cdFx0aWYgKCF0aGlzLmNvbXBvbmVudEZpbHRlci5maWx0ZXIpIHJldHVybiBQcm9taXNlLmFsbChpbnN0YW5jZXMubWFwKChjaGlsZCkgPT4gdGhpcy5jYXB0dXJlKGNoaWxkLCBkZXB0aCkpKTtcblx0XHRlbHNlIHJldHVybiBBcnJheS5wcm90b3R5cGUuY29uY2F0LmFwcGx5KFtdLCBhd2FpdCBQcm9taXNlLmFsbChpbnN0YW5jZXMubWFwKChpKSA9PiB0aGlzLmZpbmRRdWFsaWZpZWRDaGlsZHJlbihpLCBkZXB0aCkpKSk7XG5cdH1cblx0LyoqXG5cdCogR2V0IGNoaWxkcmVuIGZyb20gYSBjb21wb25lbnQgaW5zdGFuY2UuXG5cdCovXG5cdGdldEludGVybmFsSW5zdGFuY2VDaGlsZHJlbihzdWJUcmVlLCBzdXNwZW5zZSA9IG51bGwpIHtcblx0XHRjb25zdCBsaXN0ID0gW107XG5cdFx0aWYgKHN1YlRyZWUpIHtcblx0XHRcdGlmIChzdWJUcmVlLmNvbXBvbmVudCkgIXN1c3BlbnNlID8gbGlzdC5wdXNoKHN1YlRyZWUuY29tcG9uZW50KSA6IGxpc3QucHVzaCh7XG5cdFx0XHRcdC4uLnN1YlRyZWUuY29tcG9uZW50LFxuXHRcdFx0XHRzdXNwZW5zZVxuXHRcdFx0fSk7XG5cdFx0XHRlbHNlIGlmIChzdWJUcmVlLnN1c3BlbnNlKSB7XG5cdFx0XHRcdGNvbnN0IHN1c3BlbnNlS2V5ID0gIXN1YlRyZWUuc3VzcGVuc2UuaXNJbkZhbGxiYWNrID8gXCJzdXNwZW5zZSBkZWZhdWx0XCIgOiBcInN1c3BlbnNlIGZhbGxiYWNrXCI7XG5cdFx0XHRcdGxpc3QucHVzaCguLi50aGlzLmdldEludGVybmFsSW5zdGFuY2VDaGlsZHJlbihzdWJUcmVlLnN1c3BlbnNlLmFjdGl2ZUJyYW5jaCwge1xuXHRcdFx0XHRcdC4uLnN1YlRyZWUuc3VzcGVuc2UsXG5cdFx0XHRcdFx0c3VzcGVuc2VLZXlcblx0XHRcdFx0fSkpO1xuXHRcdFx0fSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHN1YlRyZWUuY2hpbGRyZW4pKSBzdWJUcmVlLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkU3ViVHJlZSkgPT4ge1xuXHRcdFx0XHRpZiAoY2hpbGRTdWJUcmVlLmNvbXBvbmVudCkgIXN1c3BlbnNlID8gbGlzdC5wdXNoKGNoaWxkU3ViVHJlZS5jb21wb25lbnQpIDogbGlzdC5wdXNoKHtcblx0XHRcdFx0XHQuLi5jaGlsZFN1YlRyZWUuY29tcG9uZW50LFxuXHRcdFx0XHRcdHN1c3BlbnNlXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRlbHNlIGxpc3QucHVzaCguLi50aGlzLmdldEludGVybmFsSW5zdGFuY2VDaGlsZHJlbihjaGlsZFN1YlRyZWUsIHN1c3BlbnNlKSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0cmV0dXJuIGxpc3QuZmlsdGVyKChjaGlsZCkgPT4gIWlzQmVpbmdEZXN0cm95ZWQoY2hpbGQpICYmICFjaGlsZC50eXBlLmRldnRvb2xzPy5oaWRlKTtcblx0fVxuXHQvKipcblx0KiBNYXJrIGFuIGluc3RhbmNlIGFzIGNhcHR1cmVkIGFuZCBzdG9yZSBpdCBpbiB0aGUgaW5zdGFuY2UgbWFwLlxuXHQqXG5cdCogQHBhcmFtIHtWdWV9IGluc3RhbmNlXG5cdCovXG5cdG1hcmsoaW5zdGFuY2UsIGZvcmNlID0gZmFsc2UpIHtcblx0XHRjb25zdCBpbnN0YW5jZU1hcCA9IGdldEFwcFJlY29yZChpbnN0YW5jZSkuaW5zdGFuY2VNYXA7XG5cdFx0aWYgKGZvcmNlIHx8ICFpbnN0YW5jZU1hcC5oYXMoaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXykpIHtcblx0XHRcdGluc3RhbmNlTWFwLnNldChpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fLCBpbnN0YW5jZSk7XG5cdFx0XHRhY3RpdmVBcHBSZWNvcmQudmFsdWUuaW5zdGFuY2VNYXAgPSBpbnN0YW5jZU1hcDtcblx0XHR9XG5cdH1cblx0aXNLZWVwQWxpdmUoaW5zdGFuY2UpIHtcblx0XHRyZXR1cm4gaW5zdGFuY2UudHlwZS5fX2lzS2VlcEFsaXZlICYmIGluc3RhbmNlLl9fdl9jYWNoZTtcblx0fVxuXHRnZXRLZWVwQWxpdmVDYWNoZWRJbnN0YW5jZXMoaW5zdGFuY2UpIHtcblx0XHRyZXR1cm4gQXJyYXkuZnJvbShpbnN0YW5jZS5fX3ZfY2FjaGUudmFsdWVzKCkpLm1hcCgodm5vZGUpID0+IHZub2RlLmNvbXBvbmVudCkuZmlsdGVyKEJvb2xlYW4pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdGltZWxpbmUvcGVyZi50c1xuY29uc3QgbWFya0VuZFF1ZXVlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbmNvbnN0IFBFUkZPUk1BTkNFX0VWRU5UX0xBWUVSX0lEID0gXCJwZXJmb3JtYW5jZVwiO1xuYXN5bmMgZnVuY3Rpb24gcGVyZm9ybWFuY2VNYXJrU3RhcnQoYXBpLCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpIHtcblx0Y29uc3QgYXBwUmVjb3JkID0gYXdhaXQgZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdGNvbnN0IGNvbXBvbmVudE5hbWUgPSBnZXRJbnN0YW5jZU5hbWUodm0pIHx8IFwiVW5rbm93biBDb21wb25lbnRcIjtcblx0Y29uc3QgZ3JvdXBJZCA9IGRldnRvb2xzU3RhdGUucGVyZlVuaXF1ZUdyb3VwSWQrKztcblx0Y29uc3QgZ3JvdXBLZXkgPSBgJHt1aWR9LSR7dHlwZX1gO1xuXHRhcHBSZWNvcmQucGVyZkdyb3VwSWRzLnNldChncm91cEtleSwge1xuXHRcdGdyb3VwSWQsXG5cdFx0dGltZVxuXHR9KTtcblx0YXdhaXQgYXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdGxheWVySWQ6IFBFUkZPUk1BTkNFX0VWRU5UX0xBWUVSX0lELFxuXHRcdGV2ZW50OiB7XG5cdFx0XHR0aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0ZGF0YToge1xuXHRcdFx0XHRjb21wb25lbnQ6IGNvbXBvbmVudE5hbWUsXG5cdFx0XHRcdHR5cGUsXG5cdFx0XHRcdG1lYXN1cmU6IFwic3RhcnRcIlxuXHRcdFx0fSxcblx0XHRcdHRpdGxlOiBjb21wb25lbnROYW1lLFxuXHRcdFx0c3VidGl0bGU6IHR5cGUsXG5cdFx0XHRncm91cElkXG5cdFx0fVxuXHR9KTtcblx0aWYgKG1hcmtFbmRRdWV1ZS5oYXMoZ3JvdXBLZXkpKSB7XG5cdFx0Y29uc3QgeyBhcHAsIHVpZCwgaW5zdGFuY2UsIHR5cGUsIHRpbWUgfSA9IG1hcmtFbmRRdWV1ZS5nZXQoZ3JvdXBLZXkpO1xuXHRcdG1hcmtFbmRRdWV1ZS5kZWxldGUoZ3JvdXBLZXkpO1xuXHRcdGF3YWl0IHBlcmZvcm1hbmNlTWFya0VuZChhcGksIGFwcCwgdWlkLCBpbnN0YW5jZSwgdHlwZSwgdGltZSk7XG5cdH1cbn1cbmZ1bmN0aW9uIHBlcmZvcm1hbmNlTWFya0VuZChhcGksIGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkge1xuXHRjb25zdCBhcHBSZWNvcmQgPSBnZXRBcHBSZWNvcmQoYXBwKTtcblx0aWYgKCFhcHBSZWNvcmQpIHJldHVybjtcblx0Y29uc3QgY29tcG9uZW50TmFtZSA9IGdldEluc3RhbmNlTmFtZSh2bSkgfHwgXCJVbmtub3duIENvbXBvbmVudFwiO1xuXHRjb25zdCBncm91cEtleSA9IGAke3VpZH0tJHt0eXBlfWA7XG5cdGNvbnN0IGdyb3VwSW5mbyA9IGFwcFJlY29yZC5wZXJmR3JvdXBJZHMuZ2V0KGdyb3VwS2V5KTtcblx0aWYgKGdyb3VwSW5mbykge1xuXHRcdGNvbnN0IGdyb3VwSWQgPSBncm91cEluZm8uZ3JvdXBJZDtcblx0XHRjb25zdCBkdXJhdGlvbiA9IHRpbWUgLSBncm91cEluZm8udGltZTtcblx0XHRhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRsYXllcklkOiBQRVJGT1JNQU5DRV9FVkVOVF9MQVlFUl9JRCxcblx0XHRcdGV2ZW50OiB7XG5cdFx0XHRcdHRpbWU6IERhdGUubm93KCksXG5cdFx0XHRcdGRhdGE6IHtcblx0XHRcdFx0XHRjb21wb25lbnQ6IGNvbXBvbmVudE5hbWUsXG5cdFx0XHRcdFx0dHlwZSxcblx0XHRcdFx0XHRtZWFzdXJlOiBcImVuZFwiLFxuXHRcdFx0XHRcdGR1cmF0aW9uOiB7IF9jdXN0b206IHtcblx0XHRcdFx0XHRcdHR5cGU6IFwiRHVyYXRpb25cIixcblx0XHRcdFx0XHRcdHZhbHVlOiBkdXJhdGlvbixcblx0XHRcdFx0XHRcdGRpc3BsYXk6IGAke2R1cmF0aW9ufSBtc2Bcblx0XHRcdFx0XHR9IH1cblx0XHRcdFx0fSxcblx0XHRcdFx0dGl0bGU6IGNvbXBvbmVudE5hbWUsXG5cdFx0XHRcdHN1YnRpdGxlOiB0eXBlLFxuXHRcdFx0XHRncm91cElkXG5cdFx0XHR9XG5cdFx0fSk7XG5cdH0gZWxzZSBtYXJrRW5kUXVldWUuc2V0KGdyb3VwS2V5LCB7XG5cdFx0YXBwLFxuXHRcdHVpZCxcblx0XHRpbnN0YW5jZTogdm0sXG5cdFx0dHlwZSxcblx0XHR0aW1lXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdGltZWxpbmUvaW5kZXgudHNcbmNvbnN0IENPTVBPTkVOVF9FVkVOVF9MQVlFUl9JRCA9IFwiY29tcG9uZW50LWV2ZW50XCI7XG5mdW5jdGlvbiBzZXR1cEJ1aWx0aW5UaW1lbGluZUxheWVycyhhcGkpIHtcblx0aWYgKCFpc0Jyb3dzZXIpIHJldHVybjtcblx0YXBpLmFkZFRpbWVsaW5lTGF5ZXIoe1xuXHRcdGlkOiBcIm1vdXNlXCIsXG5cdFx0bGFiZWw6IFwiTW91c2VcIixcblx0XHRjb2xvcjogMTA3Njg4MTVcblx0fSk7XG5cdFtcblx0XHRcIm1vdXNlZG93blwiLFxuXHRcdFwibW91c2V1cFwiLFxuXHRcdFwiY2xpY2tcIixcblx0XHRcImRibGNsaWNrXCJcblx0XS5mb3JFYWNoKChldmVudFR5cGUpID0+IHtcblx0XHRpZiAoIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5yZWNvcmRpbmdTdGF0ZSB8fCAhZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLm1vdXNlRXZlbnRFbmFibGVkKSByZXR1cm47XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnRUeXBlLCBhc3luYyAoZXZlbnQpID0+IHtcblx0XHRcdGF3YWl0IGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRcdFx0bGF5ZXJJZDogXCJtb3VzZVwiLFxuXHRcdFx0XHRldmVudDoge1xuXHRcdFx0XHRcdHRpbWU6IERhdGUubm93KCksXG5cdFx0XHRcdFx0ZGF0YToge1xuXHRcdFx0XHRcdFx0dHlwZTogZXZlbnRUeXBlLFxuXHRcdFx0XHRcdFx0eDogZXZlbnQuY2xpZW50WCxcblx0XHRcdFx0XHRcdHk6IGV2ZW50LmNsaWVudFlcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdHRpdGxlOiBldmVudFR5cGVcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSwge1xuXHRcdFx0Y2FwdHVyZTogdHJ1ZSxcblx0XHRcdHBhc3NpdmU6IHRydWVcblx0XHR9KTtcblx0fSk7XG5cdGFwaS5hZGRUaW1lbGluZUxheWVyKHtcblx0XHRpZDogXCJrZXlib2FyZFwiLFxuXHRcdGxhYmVsOiBcIktleWJvYXJkXCIsXG5cdFx0Y29sb3I6IDg0NzUwNTVcblx0fSk7XG5cdFtcblx0XHRcImtleXVwXCIsXG5cdFx0XCJrZXlkb3duXCIsXG5cdFx0XCJrZXlwcmVzc1wiXG5cdF0uZm9yRWFjaCgoZXZlbnRUeXBlKSA9PiB7XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnRUeXBlLCBhc3luYyAoZXZlbnQpID0+IHtcblx0XHRcdGlmICghZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLnJlY29yZGluZ1N0YXRlIHx8ICFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUua2V5Ym9hcmRFdmVudEVuYWJsZWQpIHJldHVybjtcblx0XHRcdGF3YWl0IGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRcdFx0bGF5ZXJJZDogXCJrZXlib2FyZFwiLFxuXHRcdFx0XHRldmVudDoge1xuXHRcdFx0XHRcdHRpbWU6IERhdGUubm93KCksXG5cdFx0XHRcdFx0ZGF0YToge1xuXHRcdFx0XHRcdFx0dHlwZTogZXZlbnRUeXBlLFxuXHRcdFx0XHRcdFx0a2V5OiBldmVudC5rZXksXG5cdFx0XHRcdFx0XHRjdHJsS2V5OiBldmVudC5jdHJsS2V5LFxuXHRcdFx0XHRcdFx0c2hpZnRLZXk6IGV2ZW50LnNoaWZ0S2V5LFxuXHRcdFx0XHRcdFx0YWx0S2V5OiBldmVudC5hbHRLZXksXG5cdFx0XHRcdFx0XHRtZXRhS2V5OiBldmVudC5tZXRhS2V5XG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHR0aXRsZTogZXZlbnQua2V5XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0sIHtcblx0XHRcdGNhcHR1cmU6IHRydWUsXG5cdFx0XHRwYXNzaXZlOiB0cnVlXG5cdFx0fSk7XG5cdH0pO1xuXHRhcGkuYWRkVGltZWxpbmVMYXllcih7XG5cdFx0aWQ6IENPTVBPTkVOVF9FVkVOVF9MQVlFUl9JRCxcblx0XHRsYWJlbDogXCJDb21wb25lbnQgZXZlbnRzXCIsXG5cdFx0Y29sb3I6IDUyMjY2Mzdcblx0fSk7XG5cdGhvb2sub24uY29tcG9uZW50RW1pdChhc3luYyAoYXBwLCBpbnN0YW5jZSwgZXZlbnQsIHBhcmFtcykgPT4ge1xuXHRcdGlmICghZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLnJlY29yZGluZ1N0YXRlIHx8ICFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUuY29tcG9uZW50RXZlbnRFbmFibGVkKSByZXR1cm47XG5cdFx0Y29uc3QgYXBwUmVjb3JkID0gYXdhaXQgZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybjtcblx0XHRjb25zdCBjb21wb25lbnRJZCA9IGAke2FwcFJlY29yZC5pZH06JHtpbnN0YW5jZS51aWR9YDtcblx0XHRjb25zdCBjb21wb25lbnROYW1lID0gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKSB8fCBcIlVua25vd24gQ29tcG9uZW50XCI7XG5cdFx0YXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdFx0bGF5ZXJJZDogQ09NUE9ORU5UX0VWRU5UX0xBWUVSX0lELFxuXHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0dGltZTogRGF0ZS5ub3coKSxcblx0XHRcdFx0ZGF0YToge1xuXHRcdFx0XHRcdGNvbXBvbmVudDogeyBfY3VzdG9tOiB7XG5cdFx0XHRcdFx0XHR0eXBlOiBcImNvbXBvbmVudC1kZWZpbml0aW9uXCIsXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBjb21wb25lbnROYW1lXG5cdFx0XHRcdFx0fSB9LFxuXHRcdFx0XHRcdGV2ZW50LFxuXHRcdFx0XHRcdHBhcmFtc1xuXHRcdFx0XHR9LFxuXHRcdFx0XHR0aXRsZTogZXZlbnQsXG5cdFx0XHRcdHN1YnRpdGxlOiBgYnkgJHtjb21wb25lbnROYW1lfWAsXG5cdFx0XHRcdG1ldGE6IHsgY29tcG9uZW50SWQgfVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9KTtcblx0YXBpLmFkZFRpbWVsaW5lTGF5ZXIoe1xuXHRcdGlkOiBcInBlcmZvcm1hbmNlXCIsXG5cdFx0bGFiZWw6IFBFUkZPUk1BTkNFX0VWRU5UX0xBWUVSX0lELFxuXHRcdGNvbG9yOiA0MzA3MDUwXG5cdH0pO1xuXHRob29rLm9uLnBlcmZTdGFydCgoYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKSA9PiB7XG5cdFx0aWYgKCFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucmVjb3JkaW5nU3RhdGUgfHwgIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5wZXJmb3JtYW5jZUV2ZW50RW5hYmxlZCkgcmV0dXJuO1xuXHRcdHBlcmZvcm1hbmNlTWFya1N0YXJ0KGFwaSwgYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKTtcblx0fSk7XG5cdGhvb2sub24ucGVyZkVuZCgoYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKSA9PiB7XG5cdFx0aWYgKCFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucmVjb3JkaW5nU3RhdGUgfHwgIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5wZXJmb3JtYW5jZUV2ZW50RW5hYmxlZCkgcmV0dXJuO1xuXHRcdHBlcmZvcm1hbmNlTWFya0VuZChhcGksIGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSk7XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdm0vaW5kZXgudHNcbmNvbnN0IE1BWF8kVk0gPSAxMDtcbmNvbnN0ICR2bVF1ZXVlID0gW107XG5mdW5jdGlvbiBleHBvc2VJbnN0YW5jZVRvV2luZG93KGNvbXBvbmVudEluc3RhbmNlKSB7XG5cdGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG5cdGNvbnN0IHdpbiA9IHdpbmRvdztcblx0aWYgKCFjb21wb25lbnRJbnN0YW5jZSkgcmV0dXJuO1xuXHR3aW4uJHZtID0gY29tcG9uZW50SW5zdGFuY2U7XG5cdGlmICgkdm1RdWV1ZVswXSAhPT0gY29tcG9uZW50SW5zdGFuY2UpIHtcblx0XHRpZiAoJHZtUXVldWUubGVuZ3RoID49IE1BWF8kVk0pICR2bVF1ZXVlLnBvcCgpO1xuXHRcdGZvciAobGV0IGkgPSAkdm1RdWV1ZS5sZW5ndGg7IGkgPiAwOyBpLS0pIHdpbltgJHZtJHtpfWBdID0gJHZtUXVldWVbaV0gPSAkdm1RdWV1ZVtpIC0gMV07XG5cdFx0d2luLiR2bTAgPSAkdm1RdWV1ZVswXSA9IGNvbXBvbmVudEluc3RhbmNlO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9wbHVnaW4vY29tcG9uZW50cy50c1xuY29uc3QgSU5TUEVDVE9SX0lEID0gXCJjb21wb25lbnRzXCI7XG5mdW5jdGlvbiBjcmVhdGVDb21wb25lbnRzRGV2VG9vbHNQbHVnaW4oYXBwKSB7XG5cdGNvbnN0IGRlc2NyaXB0b3IgPSB7XG5cdFx0aWQ6IElOU1BFQ1RPUl9JRCxcblx0XHRsYWJlbDogXCJDb21wb25lbnRzXCIsXG5cdFx0YXBwXG5cdH07XG5cdGNvbnN0IHNldHVwRm4gPSAoYXBpKSA9PiB7XG5cdFx0YXBpLmFkZEluc3BlY3Rvcih7XG5cdFx0XHRpZDogSU5TUEVDVE9SX0lELFxuXHRcdFx0bGFiZWw6IFwiQ29tcG9uZW50c1wiLFxuXHRcdFx0dHJlZUZpbHRlclBsYWNlaG9sZGVyOiBcIlNlYXJjaCBjb21wb25lbnRzXCJcblx0XHR9KTtcblx0XHRzZXR1cEJ1aWx0aW5UaW1lbGluZUxheWVycyhhcGkpO1xuXHRcdGFwaS5vbi5nZXRJbnNwZWN0b3JUcmVlKGFzeW5jIChwYXlsb2FkKSA9PiB7XG5cdFx0XHRpZiAocGF5bG9hZC5hcHAgPT09IGFwcCAmJiBwYXlsb2FkLmluc3BlY3RvcklkID09PSBJTlNQRUNUT1JfSUQpIHtcblx0XHRcdFx0Y29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRJbnN0YW5jZShhY3RpdmVBcHBSZWNvcmQudmFsdWUsIHBheWxvYWQuaW5zdGFuY2VJZCk7XG5cdFx0XHRcdGlmIChpbnN0YW5jZSkgcGF5bG9hZC5yb290Tm9kZXMgPSBhd2FpdCBuZXcgQ29tcG9uZW50V2Fsa2VyKHtcblx0XHRcdFx0XHRmaWx0ZXJUZXh0OiBwYXlsb2FkLmZpbHRlcixcblx0XHRcdFx0XHRtYXhEZXB0aDogMTAwLFxuXHRcdFx0XHRcdHJlY3Vyc2l2ZWx5OiBmYWxzZSxcblx0XHRcdFx0XHRhcGlcblx0XHRcdFx0fSkuZ2V0Q29tcG9uZW50VHJlZShpbnN0YW5jZSk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0YXBpLm9uLmdldEluc3BlY3RvclN0YXRlKGFzeW5jIChwYXlsb2FkKSA9PiB7XG5cdFx0XHRpZiAocGF5bG9hZC5hcHAgPT09IGFwcCAmJiBwYXlsb2FkLmluc3BlY3RvcklkID09PSBJTlNQRUNUT1JfSUQpIHtcblx0XHRcdFx0Y29uc3QgcmVzdWx0ID0gZ2V0SW5zdGFuY2VTdGF0ZSh7IGluc3RhbmNlSWQ6IHBheWxvYWQubm9kZUlkIH0pO1xuXHRcdFx0XHRjb25zdCBjb21wb25lbnRJbnN0YW5jZSA9IHJlc3VsdC5pbnN0YW5jZTtcblx0XHRcdFx0Y29uc3QgX3BheWxvYWQgPSB7XG5cdFx0XHRcdFx0Y29tcG9uZW50SW5zdGFuY2UsXG5cdFx0XHRcdFx0YXBwOiByZXN1bHQuaW5zdGFuY2U/LmFwcENvbnRleHQuYXBwLFxuXHRcdFx0XHRcdGluc3RhbmNlRGF0YTogcmVzdWx0XG5cdFx0XHRcdH07XG5cdFx0XHRcdGRldnRvb2xzQ29udGV4dC5ob29rcy5jYWxsSG9va1dpdGgoKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0XHRcdGNhbGxiYWNrcy5mb3JFYWNoKChjYikgPT4gY2IoX3BheWxvYWQpKTtcblx0XHRcdFx0fSwgRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLklOU1BFQ1RfQ09NUE9ORU5UKTtcblx0XHRcdFx0cGF5bG9hZC5zdGF0ZSA9IHJlc3VsdDtcblx0XHRcdFx0ZXhwb3NlSW5zdGFuY2VUb1dpbmRvdyhjb21wb25lbnRJbnN0YW5jZSk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0YXBpLm9uLmVkaXRJbnNwZWN0b3JTdGF0ZShhc3luYyAocGF5bG9hZCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gSU5TUEVDVE9SX0lEKSB7XG5cdFx0XHRcdGVkaXRTdGF0ZShwYXlsb2FkKTtcblx0XHRcdFx0YXdhaXQgYXBpLnNlbmRJbnNwZWN0b3JTdGF0ZShcImNvbXBvbmVudHNcIik7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0Y29uc3QgZGVib3VuY2VTZW5kSW5zcGVjdG9yVHJlZSA9IGRlYm91bmNlKCgpID0+IHtcblx0XHRcdGFwaS5zZW5kSW5zcGVjdG9yVHJlZShJTlNQRUNUT1JfSUQpO1xuXHRcdH0sIDEyMCk7XG5cdFx0Y29uc3QgZGVib3VuY2VTZW5kSW5zcGVjdG9yU3RhdGUgPSBkZWJvdW5jZSgoKSA9PiB7XG5cdFx0XHRhcGkuc2VuZEluc3BlY3RvclN0YXRlKElOU1BFQ1RPUl9JRCk7XG5cdFx0fSwgMTIwKTtcblx0XHRob29rLm9uLmNvbXBvbmVudEFkZGVkKGFzeW5jIChhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpID0+IHtcblx0XHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRcdGlmIChhcHA/Ll9pbnN0YW5jZT8udHlwZT8uZGV2dG9vbHM/LmhpZGUpIHJldHVybjtcblx0XHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50KSByZXR1cm47XG5cdFx0XHRjb25zdCBpZCA9IGF3YWl0IGdldENvbXBvbmVudElkKHtcblx0XHRcdFx0YXBwLFxuXHRcdFx0XHR1aWQsXG5cdFx0XHRcdGluc3RhbmNlOiBjb21wb25lbnRcblx0XHRcdH0pO1xuXHRcdFx0Y29uc3QgYXBwUmVjb3JkID0gYXdhaXQgZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdFx0XHRpZiAoY29tcG9uZW50KSB7XG5cdFx0XHRcdGlmIChjb21wb25lbnQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9PSBudWxsKSBjb21wb25lbnQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9IGlkO1xuXHRcdFx0XHRpZiAoIWFwcFJlY29yZD8uaW5zdGFuY2VNYXAuaGFzKGlkKSkge1xuXHRcdFx0XHRcdGFwcFJlY29yZD8uaW5zdGFuY2VNYXAuc2V0KGlkLCBjb21wb25lbnQpO1xuXHRcdFx0XHRcdGlmIChhY3RpdmVBcHBSZWNvcmQudmFsdWUuaWQgPT09IGFwcFJlY29yZD8uaWQpIGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5pbnN0YW5jZU1hcCA9IGFwcFJlY29yZC5pbnN0YW5jZU1hcDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybjtcblx0XHRcdGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUoKTtcblx0XHR9KTtcblx0XHRob29rLm9uLmNvbXBvbmVudFVwZGF0ZWQoYXN5bmMgKGFwcCwgdWlkLCBwYXJlbnRVaWQsIGNvbXBvbmVudCkgPT4ge1xuXHRcdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdFx0aWYgKGFwcD8uX2luc3RhbmNlPy50eXBlPy5kZXZ0b29scz8uaGlkZSkgcmV0dXJuO1xuXHRcdFx0aWYgKCFhcHAgfHwgdHlwZW9mIHVpZCAhPT0gXCJudW1iZXJcIiAmJiAhdWlkIHx8ICFjb21wb25lbnQpIHJldHVybjtcblx0XHRcdGNvbnN0IGlkID0gYXdhaXQgZ2V0Q29tcG9uZW50SWQoe1xuXHRcdFx0XHRhcHAsXG5cdFx0XHRcdHVpZCxcblx0XHRcdFx0aW5zdGFuY2U6IGNvbXBvbmVudFxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCBhcHBSZWNvcmQgPSBhd2FpdCBnZXRBcHBSZWNvcmQoYXBwKTtcblx0XHRcdGlmIChjb21wb25lbnQpIHtcblx0XHRcdFx0aWYgKGNvbXBvbmVudC5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fID09IG51bGwpIGNvbXBvbmVudC5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fID0gaWQ7XG5cdFx0XHRcdGlmICghYXBwUmVjb3JkPy5pbnN0YW5jZU1hcC5oYXMoaWQpKSB7XG5cdFx0XHRcdFx0YXBwUmVjb3JkPy5pbnN0YW5jZU1hcC5zZXQoaWQsIGNvbXBvbmVudCk7XG5cdFx0XHRcdFx0aWYgKGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5pZCA9PT0gYXBwUmVjb3JkPy5pZCkgYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmluc3RhbmNlTWFwID0gYXBwUmVjb3JkLmluc3RhbmNlTWFwO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoIWFwcFJlY29yZCkgcmV0dXJuO1xuXHRcdFx0ZGVib3VuY2VTZW5kSW5zcGVjdG9yVHJlZSgpO1xuXHRcdFx0ZGVib3VuY2VTZW5kSW5zcGVjdG9yU3RhdGUoKTtcblx0XHR9KTtcblx0XHRob29rLm9uLmNvbXBvbmVudFJlbW92ZWQoYXN5bmMgKGFwcCwgdWlkLCBwYXJlbnRVaWQsIGNvbXBvbmVudCkgPT4ge1xuXHRcdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdFx0aWYgKGFwcD8uX2luc3RhbmNlPy50eXBlPy5kZXZ0b29scz8uaGlkZSkgcmV0dXJuO1xuXHRcdFx0aWYgKCFhcHAgfHwgdHlwZW9mIHVpZCAhPT0gXCJudW1iZXJcIiAmJiAhdWlkIHx8ICFjb21wb25lbnQpIHJldHVybjtcblx0XHRcdGNvbnN0IGFwcFJlY29yZCA9IGF3YWl0IGdldEFwcFJlY29yZChhcHApO1xuXHRcdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybjtcblx0XHRcdGNvbnN0IGlkID0gYXdhaXQgZ2V0Q29tcG9uZW50SWQoe1xuXHRcdFx0XHRhcHAsXG5cdFx0XHRcdHVpZCxcblx0XHRcdFx0aW5zdGFuY2U6IGNvbXBvbmVudFxuXHRcdFx0fSk7XG5cdFx0XHRhcHBSZWNvcmQ/Lmluc3RhbmNlTWFwLmRlbGV0ZShpZCk7XG5cdFx0XHRpZiAoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmlkID09PSBhcHBSZWNvcmQ/LmlkKSBhY3RpdmVBcHBSZWNvcmQudmFsdWUuaW5zdGFuY2VNYXAgPSBhcHBSZWNvcmQuaW5zdGFuY2VNYXA7XG5cdFx0XHRkZWJvdW5jZVNlbmRJbnNwZWN0b3JUcmVlKCk7XG5cdFx0fSk7XG5cdH07XG5cdHJldHVybiBbZGVzY3JpcHRvciwgc2V0dXBGbl07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9wbHVnaW4vaW5kZXgudHNcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfX1JFR0lTVEVSRURfUExVR0lOX0FQUFNfXyA/Pz0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbmZ1bmN0aW9uIHNldHVwRGV2VG9vbHNQbHVnaW4ocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbikge1xuXHRyZXR1cm4gaG9vay5zZXR1cERldlRvb2xzUGx1Z2luKHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4pO1xufVxuZnVuY3Rpb24gY2FsbERldlRvb2xzUGx1Z2luU2V0dXBGbihwbHVnaW4sIGFwcCkge1xuXHRjb25zdCBbcGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbl0gPSBwbHVnaW47XG5cdGlmIChwbHVnaW5EZXNjcmlwdG9yLmFwcCAhPT0gYXBwKSByZXR1cm47XG5cdGNvbnN0IGFwaSA9IG5ldyBEZXZUb29sc1BsdWdpbkFQSSh7XG5cdFx0cGx1Z2luOiB7XG5cdFx0XHRzZXR1cEZuLFxuXHRcdFx0ZGVzY3JpcHRvcjogcGx1Z2luRGVzY3JpcHRvclxuXHRcdH0sXG5cdFx0Y3R4OiBkZXZ0b29sc0NvbnRleHRcblx0fSk7XG5cdGlmIChwbHVnaW5EZXNjcmlwdG9yLnBhY2thZ2VOYW1lID09PSBcInZ1ZXhcIikgYXBpLm9uLmVkaXRJbnNwZWN0b3JTdGF0ZSgocGF5bG9hZCkgPT4ge1xuXHRcdGFwaS5zZW5kSW5zcGVjdG9yU3RhdGUocGF5bG9hZC5pbnNwZWN0b3JJZCk7XG5cdH0pO1xuXHRzZXR1cEZuKGFwaSk7XG59XG5mdW5jdGlvbiByZW1vdmVSZWdpc3RlcmVkUGx1Z2luQXBwKGFwcCkge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX19SRUdJU1RFUkVEX1BMVUdJTl9BUFBTX18uZGVsZXRlKGFwcCk7XG59XG5mdW5jdGlvbiByZWdpc3RlckRldlRvb2xzUGx1Z2luKGFwcCwgb3B0aW9ucykge1xuXHRpZiAodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9fUkVHSVNURVJFRF9QTFVHSU5fQVBQU19fLmhhcyhhcHApKSByZXR1cm47XG5cdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQgJiYgIW9wdGlvbnM/Lmluc3BlY3RpbmdDb21wb25lbnQpIHJldHVybjtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9fUkVHSVNURVJFRF9QTFVHSU5fQVBQU19fLmFkZChhcHApO1xuXHRkZXZ0b29sc1BsdWdpbkJ1ZmZlci5mb3JFYWNoKChwbHVnaW4pID0+IHtcblx0XHRjYWxsRGV2VG9vbHNQbHVnaW5TZXR1cEZuKHBsdWdpbiwgYXBwKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L3JvdXRlci50c1xuY29uc3QgUk9VVEVSX0tFWSA9IFwiX19WVUVfREVWVE9PTFNfUk9VVEVSX19cIjtcbmNvbnN0IFJPVVRFUl9JTkZPX0tFWSA9IFwiX19WVUVfREVWVE9PTFNfUk9VVEVSX0lORk9fX1wiO1xudGFyZ2V0W1JPVVRFUl9JTkZPX0tFWV0gPz89IHtcblx0Y3VycmVudFJvdXRlOiBudWxsLFxuXHRyb3V0ZXM6IFtdXG59O1xudGFyZ2V0W1JPVVRFUl9LRVldID8/PSB7fTtcbmNvbnN0IGRldnRvb2xzUm91dGVySW5mbyA9IG5ldyBQcm94eSh0YXJnZXRbUk9VVEVSX0lORk9fS0VZXSwgeyBnZXQodGFyZ2V0JDEsIHByb3BlcnR5KSB7XG5cdHJldHVybiB0YXJnZXRbUk9VVEVSX0lORk9fS0VZXVtwcm9wZXJ0eV07XG59IH0pO1xuY29uc3QgZGV2dG9vbHNSb3V0ZXIgPSBuZXcgUHJveHkodGFyZ2V0W1JPVVRFUl9LRVldLCB7IGdldCh0YXJnZXQkMiwgcHJvcGVydHkpIHtcblx0aWYgKHByb3BlcnR5ID09PSBcInZhbHVlXCIpIHJldHVybiB0YXJnZXRbUk9VVEVSX0tFWV07XG59IH0pO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvcm91dGVyL2luZGV4LnRzXG5mdW5jdGlvbiBnZXRSb3V0ZXMocm91dGVyKSB7XG5cdGNvbnN0IHJvdXRlc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdHJldHVybiAocm91dGVyPy5nZXRSb3V0ZXMoKSB8fCBbXSkuZmlsdGVyKChpKSA9PiAhcm91dGVzTWFwLmhhcyhpLnBhdGgpICYmIHJvdXRlc01hcC5zZXQoaS5wYXRoLCAxKSk7XG59XG5mdW5jdGlvbiBmaWx0ZXJSb3V0ZXMocm91dGVzKSB7XG5cdHJldHVybiByb3V0ZXMubWFwKChpdGVtKSA9PiB7XG5cdFx0bGV0IHsgcGF0aCwgbmFtZSwgY2hpbGRyZW4sIG1ldGEgfSA9IGl0ZW07XG5cdFx0aWYgKGNoaWxkcmVuPy5sZW5ndGgpIGNoaWxkcmVuID0gZmlsdGVyUm91dGVzKGNoaWxkcmVuKTtcblx0XHRyZXR1cm4ge1xuXHRcdFx0cGF0aCxcblx0XHRcdG5hbWUsXG5cdFx0XHRjaGlsZHJlbixcblx0XHRcdG1ldGFcblx0XHR9O1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGZpbHRlckN1cnJlbnRSb3V0ZShyb3V0ZSkge1xuXHRpZiAocm91dGUpIHtcblx0XHRjb25zdCB7IGZ1bGxQYXRoLCBoYXNoLCBocmVmLCBwYXRoLCBuYW1lLCBtYXRjaGVkLCBwYXJhbXMsIHF1ZXJ5IH0gPSByb3V0ZTtcblx0XHRyZXR1cm4ge1xuXHRcdFx0ZnVsbFBhdGgsXG5cdFx0XHRoYXNoLFxuXHRcdFx0aHJlZixcblx0XHRcdHBhdGgsXG5cdFx0XHRuYW1lLFxuXHRcdFx0cGFyYW1zLFxuXHRcdFx0cXVlcnksXG5cdFx0XHRtYXRjaGVkOiBmaWx0ZXJSb3V0ZXMobWF0Y2hlZClcblx0XHR9O1xuXHR9XG5cdHJldHVybiByb3V0ZTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJvdXRlckluZm8oYXBwUmVjb3JkLCBhY3RpdmVBcHBSZWNvcmQpIHtcblx0ZnVuY3Rpb24gaW5pdCgpIHtcblx0XHRjb25zdCByb3V0ZXIgPSBhcHBSZWNvcmQuYXBwPy5jb25maWcuZ2xvYmFsUHJvcGVydGllcy4kcm91dGVyO1xuXHRcdGNvbnN0IGN1cnJlbnRSb3V0ZSA9IGZpbHRlckN1cnJlbnRSb3V0ZShyb3V0ZXI/LmN1cnJlbnRSb3V0ZS52YWx1ZSk7XG5cdFx0Y29uc3Qgcm91dGVzID0gZmlsdGVyUm91dGVzKGdldFJvdXRlcyhyb3V0ZXIpKTtcblx0XHRjb25zdCBjID0gY29uc29sZS53YXJuO1xuXHRcdGNvbnNvbGUud2FybiA9ICgpID0+IHt9O1xuXHRcdHRhcmdldFtST1VURVJfSU5GT19LRVldID0ge1xuXHRcdFx0Y3VycmVudFJvdXRlOiBjdXJyZW50Um91dGUgPyBkZWVwQ2xvbmUoY3VycmVudFJvdXRlKSA6IHt9LFxuXHRcdFx0cm91dGVzOiBkZWVwQ2xvbmUocm91dGVzKVxuXHRcdH07XG5cdFx0dGFyZ2V0W1JPVVRFUl9LRVldID0gcm91dGVyO1xuXHRcdGNvbnNvbGUud2FybiA9IGM7XG5cdH1cblx0aW5pdCgpO1xuXHRob29rLm9uLmNvbXBvbmVudFVwZGF0ZWQoZGVib3VuY2UoKCkgPT4ge1xuXHRcdGlmIChhY3RpdmVBcHBSZWNvcmQudmFsdWU/LmFwcCAhPT0gYXBwUmVjb3JkLmFwcCkgcmV0dXJuO1xuXHRcdGluaXQoKTtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmNhbGxIb29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuUk9VVEVSX0lORk9fVVBEQVRFRCwgeyBzdGF0ZTogdGFyZ2V0W1JPVVRFUl9JTkZPX0tFWV0gfSk7XG5cdH0sIDIwMCkpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC9hcGkudHNcbmZ1bmN0aW9uIGNyZWF0ZURldlRvb2xzQXBpKGhvb2tzKSB7XG5cdHJldHVybiB7XG5cdFx0YXN5bmMgZ2V0SW5zcGVjdG9yVHJlZShwYXlsb2FkKSB7XG5cdFx0XHRjb25zdCBfcGF5bG9hZCA9IHtcblx0XHRcdFx0Li4ucGF5bG9hZCxcblx0XHRcdFx0YXBwOiBhY3RpdmVBcHBSZWNvcmQudmFsdWUuYXBwLFxuXHRcdFx0XHRyb290Tm9kZXM6IFtdXG5cdFx0XHR9O1xuXHRcdFx0YXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdFx0aG9va3MuY2FsbEhvb2tXaXRoKGFzeW5jIChjYWxsYmFja3MpID0+IHtcblx0XHRcdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2IoX3BheWxvYWQpKSk7XG5cdFx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9UUkVFKTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIF9wYXlsb2FkLnJvb3ROb2Rlcztcblx0XHR9LFxuXHRcdGFzeW5jIGdldEluc3BlY3RvclN0YXRlKHBheWxvYWQpIHtcblx0XHRcdGNvbnN0IF9wYXlsb2FkID0ge1xuXHRcdFx0XHQuLi5wYXlsb2FkLFxuXHRcdFx0XHRhcHA6IGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHAsXG5cdFx0XHRcdHN0YXRlOiBudWxsXG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgY3R4ID0geyBjdXJyZW50VGFiOiBgY3VzdG9tLWluc3BlY3Rvcjoke3BheWxvYWQuaW5zcGVjdG9ySWR9YCB9O1xuXHRcdFx0YXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdFx0aG9va3MuY2FsbEhvb2tXaXRoKGFzeW5jIChjYWxsYmFja3MpID0+IHtcblx0XHRcdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2IoX3BheWxvYWQsIGN0eCkpKTtcblx0XHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHRcdH0sIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5HRVRfSU5TUEVDVE9SX1NUQVRFKTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIF9wYXlsb2FkLnN0YXRlO1xuXHRcdH0sXG5cdFx0ZWRpdEluc3BlY3RvclN0YXRlKHBheWxvYWQpIHtcblx0XHRcdGNvbnN0IHN0YXRlRWRpdG9yID0gbmV3IFN0YXRlRWRpdG9yKCk7XG5cdFx0XHRjb25zdCBfcGF5bG9hZCA9IHtcblx0XHRcdFx0Li4ucGF5bG9hZCxcblx0XHRcdFx0YXBwOiBhY3RpdmVBcHBSZWNvcmQudmFsdWUuYXBwLFxuXHRcdFx0XHRzZXQ6IChvYmosIHBhdGggPSBwYXlsb2FkLnBhdGgsIHZhbHVlID0gcGF5bG9hZC5zdGF0ZS52YWx1ZSwgY2IpID0+IHtcblx0XHRcdFx0XHRzdGF0ZUVkaXRvci5zZXQob2JqLCBwYXRoLCB2YWx1ZSwgY2IgfHwgc3RhdGVFZGl0b3IuY3JlYXRlRGVmYXVsdFNldENhbGxiYWNrKHBheWxvYWQuc3RhdGUpKTtcblx0XHRcdFx0fVxuXHRcdFx0fTtcblx0XHRcdGhvb2tzLmNhbGxIb29rV2l0aCgoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRcdGNhbGxiYWNrcy5mb3JFYWNoKChjYikgPT4gY2IoX3BheWxvYWQpKTtcblx0XHRcdH0sIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5FRElUX0lOU1BFQ1RPUl9TVEFURSk7XG5cdFx0fSxcblx0XHRzZW5kSW5zcGVjdG9yU3RhdGUoaW5zcGVjdG9ySWQpIHtcblx0XHRcdGNvbnN0IGluc3BlY3RvciA9IGdldEluc3BlY3RvcihpbnNwZWN0b3JJZCk7XG5cdFx0XHRob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9TVEFURSwge1xuXHRcdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdFx0cGx1Z2luOiB7XG5cdFx0XHRcdFx0ZGVzY3JpcHRvcjogaW5zcGVjdG9yLmRlc2NyaXB0b3IsXG5cdFx0XHRcdFx0c2V0dXBGbjogKCkgPT4gKHt9KVxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9LFxuXHRcdGluc3BlY3RDb21wb25lbnRJbnNwZWN0b3IoKSB7XG5cdFx0XHRyZXR1cm4gaW5zcGVjdENvbXBvbmVudEhpZ2hMaWdodGVyKCk7XG5cdFx0fSxcblx0XHRjYW5jZWxJbnNwZWN0Q29tcG9uZW50SW5zcGVjdG9yKCkge1xuXHRcdFx0cmV0dXJuIGNhbmNlbEluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlcigpO1xuXHRcdH0sXG5cdFx0Z2V0Q29tcG9uZW50UmVuZGVyQ29kZShpZCkge1xuXHRcdFx0Y29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRJbnN0YW5jZShhY3RpdmVBcHBSZWNvcmQudmFsdWUsIGlkKTtcblx0XHRcdGlmIChpbnN0YW5jZSkgcmV0dXJuICEodHlwZW9mIGluc3RhbmNlPy50eXBlID09PSBcImZ1bmN0aW9uXCIpID8gaW5zdGFuY2UucmVuZGVyLnRvU3RyaW5nKCkgOiBpbnN0YW5jZS50eXBlLnRvU3RyaW5nKCk7XG5cdFx0fSxcblx0XHRzY3JvbGxUb0NvbXBvbmVudChpZCkge1xuXHRcdFx0cmV0dXJuIHNjcm9sbFRvQ29tcG9uZW50KHsgaWQgfSk7XG5cdFx0fSxcblx0XHRvcGVuSW5FZGl0b3IsXG5cdFx0Z2V0VnVlSW5zcGVjdG9yOiBnZXRDb21wb25lbnRJbnNwZWN0b3IsXG5cdFx0dG9nZ2xlQXBwKGlkLCBvcHRpb25zKSB7XG5cdFx0XHRjb25zdCBhcHBSZWNvcmQgPSBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWUuZmluZCgocmVjb3JkKSA9PiByZWNvcmQuaWQgPT09IGlkKTtcblx0XHRcdGlmIChhcHBSZWNvcmQpIHtcblx0XHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkSWQoaWQpO1xuXHRcdFx0XHRzZXRBY3RpdmVBcHBSZWNvcmQoYXBwUmVjb3JkKTtcblx0XHRcdFx0bm9ybWFsaXplUm91dGVySW5mbyhhcHBSZWNvcmQsIGFjdGl2ZUFwcFJlY29yZCk7XG5cdFx0XHRcdGNhbGxJbnNwZWN0b3JVcGRhdGVkSG9vaygpO1xuXHRcdFx0XHRyZWdpc3RlckRldlRvb2xzUGx1Z2luKGFwcFJlY29yZC5hcHAsIG9wdGlvbnMpO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0aW5zcGVjdERPTShpbnN0YW5jZUlkKSB7XG5cdFx0XHRjb25zdCBpbnN0YW5jZSA9IGdldENvbXBvbmVudEluc3RhbmNlKGFjdGl2ZUFwcFJlY29yZC52YWx1ZSwgaW5zdGFuY2VJZCk7XG5cdFx0XHRpZiAoaW5zdGFuY2UpIHtcblx0XHRcdFx0Y29uc3QgW2VsXSA9IGdldFJvb3RFbGVtZW50c0Zyb21Db21wb25lbnRJbnN0YW5jZShpbnN0YW5jZSk7XG5cdFx0XHRcdGlmIChlbCkgdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0lOU1BFQ1RfRE9NX1RBUkdFVF9fID0gZWw7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHR1cGRhdGVQbHVnaW5TZXR0aW5ncyhwbHVnaW5JZCwga2V5LCB2YWx1ZSkge1xuXHRcdFx0c2V0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQsIGtleSwgdmFsdWUpO1xuXHRcdH0sXG5cdFx0Z2V0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdG9wdGlvbnM6IGdldFBsdWdpblNldHRpbmdzT3B0aW9ucyhwbHVnaW5JZCksXG5cdFx0XHRcdHZhbHVlczogZ2V0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQpXG5cdFx0XHR9O1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvZW52LnRzXG50YXJnZXQuX19WVUVfREVWVE9PTFNfRU5WX18gPz89IHsgdml0ZVBsdWdpbkRldGVjdGVkOiBmYWxzZSB9O1xuZnVuY3Rpb24gZ2V0RGV2VG9vbHNFbnYoKSB7XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfRU5WX187XG59XG5mdW5jdGlvbiBzZXREZXZUb29sc0VudihlbnYpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0VOVl9fID0ge1xuXHRcdC4uLnRhcmdldC5fX1ZVRV9ERVZUT09MU19FTlZfXyxcblx0XHQuLi5lbnZcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvaW5kZXgudHNcbmNvbnN0IGhvb2tzID0gY3JlYXRlRGV2VG9vbHNDdHhIb29rcygpO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DT05URVhUX18gPz89IHtcblx0aG9va3MsXG5cdGdldCBzdGF0ZSgpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0Li4uZGV2dG9vbHNTdGF0ZSxcblx0XHRcdGFjdGl2ZUFwcFJlY29yZElkOiBhY3RpdmVBcHBSZWNvcmQuaWQsXG5cdFx0XHRhY3RpdmVBcHBSZWNvcmQ6IGFjdGl2ZUFwcFJlY29yZC52YWx1ZSxcblx0XHRcdGFwcFJlY29yZHM6IGRldnRvb2xzQXBwUmVjb3Jkcy52YWx1ZVxuXHRcdH07XG5cdH0sXG5cdGFwaTogY3JlYXRlRGV2VG9vbHNBcGkoaG9va3MpXG59O1xuY29uc3QgZGV2dG9vbHNDb250ZXh0ID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DT05URVhUX187XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3BlYWtpbmd1cmxAMTQuMC4xL25vZGVfbW9kdWxlcy9zcGVha2luZ3VybC9saWIvc3BlYWtpbmd1cmwuanNcbnZhciByZXF1aXJlX3NwZWFraW5ndXJsJDEgPSAvKiBAX19QVVJFX18gKi8gX19jb21tb25KU01pbigoKGV4cG9ydHMsIG1vZHVsZSkgPT4ge1xuXHQoZnVuY3Rpb24ocm9vdCkge1xuXHRcdFwidXNlIHN0cmljdFwiO1xuXHRcdC8qKlxuXHRcdCogY2hhck1hcFxuXHRcdCogQHR5cGUge09iamVjdH1cblx0XHQqL1xuXHRcdHZhciBjaGFyTWFwID0ge1xuXHRcdFx0XCLDgFwiOiBcIkFcIixcblx0XHRcdFwiw4FcIjogXCJBXCIsXG5cdFx0XHRcIsOCXCI6IFwiQVwiLFxuXHRcdFx0XCLDg1wiOiBcIkFcIixcblx0XHRcdFwiw4RcIjogXCJBZVwiLFxuXHRcdFx0XCLDhVwiOiBcIkFcIixcblx0XHRcdFwiw4ZcIjogXCJBRVwiLFxuXHRcdFx0XCLDh1wiOiBcIkNcIixcblx0XHRcdFwiw4hcIjogXCJFXCIsXG5cdFx0XHRcIsOJXCI6IFwiRVwiLFxuXHRcdFx0XCLDilwiOiBcIkVcIixcblx0XHRcdFwiw4tcIjogXCJFXCIsXG5cdFx0XHRcIsOMXCI6IFwiSVwiLFxuXHRcdFx0XCLDjVwiOiBcIklcIixcblx0XHRcdFwiw45cIjogXCJJXCIsXG5cdFx0XHRcIsOPXCI6IFwiSVwiLFxuXHRcdFx0XCLDkFwiOiBcIkRcIixcblx0XHRcdFwiw5FcIjogXCJOXCIsXG5cdFx0XHRcIsOSXCI6IFwiT1wiLFxuXHRcdFx0XCLDk1wiOiBcIk9cIixcblx0XHRcdFwiw5RcIjogXCJPXCIsXG5cdFx0XHRcIsOVXCI6IFwiT1wiLFxuXHRcdFx0XCLDllwiOiBcIk9lXCIsXG5cdFx0XHRcIsWQXCI6IFwiT1wiLFxuXHRcdFx0XCLDmFwiOiBcIk9cIixcblx0XHRcdFwiw5lcIjogXCJVXCIsXG5cdFx0XHRcIsOaXCI6IFwiVVwiLFxuXHRcdFx0XCLDm1wiOiBcIlVcIixcblx0XHRcdFwiw5xcIjogXCJVZVwiLFxuXHRcdFx0XCLFsFwiOiBcIlVcIixcblx0XHRcdFwiw51cIjogXCJZXCIsXG5cdFx0XHRcIsOeXCI6IFwiVEhcIixcblx0XHRcdFwiw59cIjogXCJzc1wiLFxuXHRcdFx0XCLDoFwiOiBcImFcIixcblx0XHRcdFwiw6FcIjogXCJhXCIsXG5cdFx0XHRcIsOiXCI6IFwiYVwiLFxuXHRcdFx0XCLDo1wiOiBcImFcIixcblx0XHRcdFwiw6RcIjogXCJhZVwiLFxuXHRcdFx0XCLDpVwiOiBcImFcIixcblx0XHRcdFwiw6ZcIjogXCJhZVwiLFxuXHRcdFx0XCLDp1wiOiBcImNcIixcblx0XHRcdFwiw6hcIjogXCJlXCIsXG5cdFx0XHRcIsOpXCI6IFwiZVwiLFxuXHRcdFx0XCLDqlwiOiBcImVcIixcblx0XHRcdFwiw6tcIjogXCJlXCIsXG5cdFx0XHRcIsOsXCI6IFwiaVwiLFxuXHRcdFx0XCLDrVwiOiBcImlcIixcblx0XHRcdFwiw65cIjogXCJpXCIsXG5cdFx0XHRcIsOvXCI6IFwiaVwiLFxuXHRcdFx0XCLDsFwiOiBcImRcIixcblx0XHRcdFwiw7FcIjogXCJuXCIsXG5cdFx0XHRcIsOyXCI6IFwib1wiLFxuXHRcdFx0XCLDs1wiOiBcIm9cIixcblx0XHRcdFwiw7RcIjogXCJvXCIsXG5cdFx0XHRcIsO1XCI6IFwib1wiLFxuXHRcdFx0XCLDtlwiOiBcIm9lXCIsXG5cdFx0XHRcIsWRXCI6IFwib1wiLFxuXHRcdFx0XCLDuFwiOiBcIm9cIixcblx0XHRcdFwiw7lcIjogXCJ1XCIsXG5cdFx0XHRcIsO6XCI6IFwidVwiLFxuXHRcdFx0XCLDu1wiOiBcInVcIixcblx0XHRcdFwiw7xcIjogXCJ1ZVwiLFxuXHRcdFx0XCLFsVwiOiBcInVcIixcblx0XHRcdFwiw71cIjogXCJ5XCIsXG5cdFx0XHRcIsO+XCI6IFwidGhcIixcblx0XHRcdFwiw79cIjogXCJ5XCIsXG5cdFx0XHRcIuG6nlwiOiBcIlNTXCIsXG5cdFx0XHRcItinXCI6IFwiYVwiLFxuXHRcdFx0XCLYo1wiOiBcImFcIixcblx0XHRcdFwi2KVcIjogXCJpXCIsXG5cdFx0XHRcItiiXCI6IFwiYWFcIixcblx0XHRcdFwi2KRcIjogXCJ1XCIsXG5cdFx0XHRcItimXCI6IFwiZVwiLFxuXHRcdFx0XCLYoVwiOiBcImFcIixcblx0XHRcdFwi2KhcIjogXCJiXCIsXG5cdFx0XHRcItiqXCI6IFwidFwiLFxuXHRcdFx0XCLYq1wiOiBcInRoXCIsXG5cdFx0XHRcItisXCI6IFwialwiLFxuXHRcdFx0XCLYrVwiOiBcImhcIixcblx0XHRcdFwi2K5cIjogXCJraFwiLFxuXHRcdFx0XCLYr1wiOiBcImRcIixcblx0XHRcdFwi2LBcIjogXCJ0aFwiLFxuXHRcdFx0XCLYsVwiOiBcInJcIixcblx0XHRcdFwi2LJcIjogXCJ6XCIsXG5cdFx0XHRcItizXCI6IFwic1wiLFxuXHRcdFx0XCLYtFwiOiBcInNoXCIsXG5cdFx0XHRcIti1XCI6IFwic1wiLFxuXHRcdFx0XCLYtlwiOiBcImRoXCIsXG5cdFx0XHRcIti3XCI6IFwidFwiLFxuXHRcdFx0XCLYuFwiOiBcInpcIixcblx0XHRcdFwi2LlcIjogXCJhXCIsXG5cdFx0XHRcIti6XCI6IFwiZ2hcIixcblx0XHRcdFwi2YFcIjogXCJmXCIsXG5cdFx0XHRcItmCXCI6IFwicVwiLFxuXHRcdFx0XCLZg1wiOiBcImtcIixcblx0XHRcdFwi2YRcIjogXCJsXCIsXG5cdFx0XHRcItmFXCI6IFwibVwiLFxuXHRcdFx0XCLZhlwiOiBcIm5cIixcblx0XHRcdFwi2YdcIjogXCJoXCIsXG5cdFx0XHRcItmIXCI6IFwid1wiLFxuXHRcdFx0XCLZilwiOiBcInlcIixcblx0XHRcdFwi2YlcIjogXCJhXCIsXG5cdFx0XHRcItipXCI6IFwiaFwiLFxuXHRcdFx0XCLvu7tcIjogXCJsYVwiLFxuXHRcdFx0XCLvu7dcIjogXCJsYWFcIixcblx0XHRcdFwi77u5XCI6IFwibGFpXCIsXG5cdFx0XHRcIu+7tVwiOiBcImxhYVwiLFxuXHRcdFx0XCLar1wiOiBcImdcIixcblx0XHRcdFwi2oZcIjogXCJjaFwiLFxuXHRcdFx0XCLZvlwiOiBcInBcIixcblx0XHRcdFwi2phcIjogXCJ6aFwiLFxuXHRcdFx0XCLaqVwiOiBcImtcIixcblx0XHRcdFwi24xcIjogXCJ5XCIsXG5cdFx0XHRcItmOXCI6IFwiYVwiLFxuXHRcdFx0XCLZi1wiOiBcImFuXCIsXG5cdFx0XHRcItmQXCI6IFwiZVwiLFxuXHRcdFx0XCLZjVwiOiBcImVuXCIsXG5cdFx0XHRcItmPXCI6IFwidVwiLFxuXHRcdFx0XCLZjFwiOiBcIm9uXCIsXG5cdFx0XHRcItmSXCI6IFwiXCIsXG5cdFx0XHRcItmgXCI6IFwiMFwiLFxuXHRcdFx0XCLZoVwiOiBcIjFcIixcblx0XHRcdFwi2aJcIjogXCIyXCIsXG5cdFx0XHRcItmjXCI6IFwiM1wiLFxuXHRcdFx0XCLZpFwiOiBcIjRcIixcblx0XHRcdFwi2aVcIjogXCI1XCIsXG5cdFx0XHRcItmmXCI6IFwiNlwiLFxuXHRcdFx0XCLZp1wiOiBcIjdcIixcblx0XHRcdFwi2ahcIjogXCI4XCIsXG5cdFx0XHRcItmpXCI6IFwiOVwiLFxuXHRcdFx0XCLbsFwiOiBcIjBcIixcblx0XHRcdFwi27FcIjogXCIxXCIsXG5cdFx0XHRcItuyXCI6IFwiMlwiLFxuXHRcdFx0XCLbs1wiOiBcIjNcIixcblx0XHRcdFwi27RcIjogXCI0XCIsXG5cdFx0XHRcItu1XCI6IFwiNVwiLFxuXHRcdFx0XCLbtlwiOiBcIjZcIixcblx0XHRcdFwi27dcIjogXCI3XCIsXG5cdFx0XHRcItu4XCI6IFwiOFwiLFxuXHRcdFx0XCLbuVwiOiBcIjlcIixcblx0XHRcdFwi4YCAXCI6IFwia1wiLFxuXHRcdFx0XCLhgIFcIjogXCJraFwiLFxuXHRcdFx0XCLhgIJcIjogXCJnXCIsXG5cdFx0XHRcIuGAg1wiOiBcImdhXCIsXG5cdFx0XHRcIuGAhFwiOiBcIm5nXCIsXG5cdFx0XHRcIuGAhVwiOiBcInNcIixcblx0XHRcdFwi4YCGXCI6IFwic2FcIixcblx0XHRcdFwi4YCHXCI6IFwielwiLFxuXHRcdFx0XCLhgIXhgLtcIjogXCJ6YVwiLFxuXHRcdFx0XCLhgIpcIjogXCJueVwiLFxuXHRcdFx0XCLhgItcIjogXCJ0XCIsXG5cdFx0XHRcIuGAjFwiOiBcInRhXCIsXG5cdFx0XHRcIuGAjVwiOiBcImRcIixcblx0XHRcdFwi4YCOXCI6IFwiZGFcIixcblx0XHRcdFwi4YCPXCI6IFwibmFcIixcblx0XHRcdFwi4YCQXCI6IFwidFwiLFxuXHRcdFx0XCLhgJFcIjogXCJ0YVwiLFxuXHRcdFx0XCLhgJJcIjogXCJkXCIsXG5cdFx0XHRcIuGAk1wiOiBcImRhXCIsXG5cdFx0XHRcIuGAlFwiOiBcIm5cIixcblx0XHRcdFwi4YCVXCI6IFwicFwiLFxuXHRcdFx0XCLhgJZcIjogXCJwYVwiLFxuXHRcdFx0XCLhgJdcIjogXCJiXCIsXG5cdFx0XHRcIuGAmFwiOiBcImJhXCIsXG5cdFx0XHRcIuGAmVwiOiBcIm1cIixcblx0XHRcdFwi4YCaXCI6IFwieVwiLFxuXHRcdFx0XCLhgJtcIjogXCJ5YVwiLFxuXHRcdFx0XCLhgJxcIjogXCJsXCIsXG5cdFx0XHRcIuGAnVwiOiBcIndcIixcblx0XHRcdFwi4YCeXCI6IFwidGhcIixcblx0XHRcdFwi4YCfXCI6IFwiaFwiLFxuXHRcdFx0XCLhgKBcIjogXCJsYVwiLFxuXHRcdFx0XCLhgKFcIjogXCJhXCIsXG5cdFx0XHRcIuGAvFwiOiBcInlcIixcblx0XHRcdFwi4YC7XCI6IFwieWFcIixcblx0XHRcdFwi4YC9XCI6IFwid1wiLFxuXHRcdFx0XCLhgLzhgL1cIjogXCJ5d1wiLFxuXHRcdFx0XCLhgLvhgL1cIjogXCJ5d2FcIixcblx0XHRcdFwi4YC+XCI6IFwiaFwiLFxuXHRcdFx0XCLhgKdcIjogXCJlXCIsXG5cdFx0XHRcIuGBj1wiOiBcIi1lXCIsXG5cdFx0XHRcIuGAo1wiOiBcImlcIixcblx0XHRcdFwi4YCkXCI6IFwiLWlcIixcblx0XHRcdFwi4YCJXCI6IFwidVwiLFxuXHRcdFx0XCLhgKZcIjogXCItdVwiLFxuXHRcdFx0XCLhgKlcIjogXCJhd1wiLFxuXHRcdFx0XCLhgJ7hgLzhgLHhgKxcIjogXCJhd1wiLFxuXHRcdFx0XCLhgKpcIjogXCJhd1wiLFxuXHRcdFx0XCLhgYBcIjogXCIwXCIsXG5cdFx0XHRcIuGBgVwiOiBcIjFcIixcblx0XHRcdFwi4YGCXCI6IFwiMlwiLFxuXHRcdFx0XCLhgYNcIjogXCIzXCIsXG5cdFx0XHRcIuGBhFwiOiBcIjRcIixcblx0XHRcdFwi4YGFXCI6IFwiNVwiLFxuXHRcdFx0XCLhgYZcIjogXCI2XCIsXG5cdFx0XHRcIuGBh1wiOiBcIjdcIixcblx0XHRcdFwi4YGIXCI6IFwiOFwiLFxuXHRcdFx0XCLhgYlcIjogXCI5XCIsXG5cdFx0XHRcIuGAuVwiOiBcIlwiLFxuXHRcdFx0XCLhgLdcIjogXCJcIixcblx0XHRcdFwi4YC4XCI6IFwiXCIsXG5cdFx0XHRcIsSNXCI6IFwiY1wiLFxuXHRcdFx0XCLEj1wiOiBcImRcIixcblx0XHRcdFwixJtcIjogXCJlXCIsXG5cdFx0XHRcIsWIXCI6IFwiblwiLFxuXHRcdFx0XCLFmVwiOiBcInJcIixcblx0XHRcdFwixaFcIjogXCJzXCIsXG5cdFx0XHRcIsWlXCI6IFwidFwiLFxuXHRcdFx0XCLFr1wiOiBcInVcIixcblx0XHRcdFwixb5cIjogXCJ6XCIsXG5cdFx0XHRcIsSMXCI6IFwiQ1wiLFxuXHRcdFx0XCLEjlwiOiBcIkRcIixcblx0XHRcdFwixJpcIjogXCJFXCIsXG5cdFx0XHRcIsWHXCI6IFwiTlwiLFxuXHRcdFx0XCLFmFwiOiBcIlJcIixcblx0XHRcdFwixaBcIjogXCJTXCIsXG5cdFx0XHRcIsWkXCI6IFwiVFwiLFxuXHRcdFx0XCLFrlwiOiBcIlVcIixcblx0XHRcdFwixb1cIjogXCJaXCIsXG5cdFx0XHRcIt6AXCI6IFwiaFwiLFxuXHRcdFx0XCLegVwiOiBcInNoXCIsXG5cdFx0XHRcIt6CXCI6IFwiblwiLFxuXHRcdFx0XCLeg1wiOiBcInJcIixcblx0XHRcdFwi3oRcIjogXCJiXCIsXG5cdFx0XHRcIt6FXCI6IFwibGhcIixcblx0XHRcdFwi3oZcIjogXCJrXCIsXG5cdFx0XHRcIt6HXCI6IFwiYVwiLFxuXHRcdFx0XCLeiFwiOiBcInZcIixcblx0XHRcdFwi3olcIjogXCJtXCIsXG5cdFx0XHRcIt6KXCI6IFwiZlwiLFxuXHRcdFx0XCLei1wiOiBcImRoXCIsXG5cdFx0XHRcIt6MXCI6IFwidGhcIixcblx0XHRcdFwi3o1cIjogXCJsXCIsXG5cdFx0XHRcIt6OXCI6IFwiZ1wiLFxuXHRcdFx0XCLej1wiOiBcImduXCIsXG5cdFx0XHRcIt6QXCI6IFwic1wiLFxuXHRcdFx0XCLekVwiOiBcImRcIixcblx0XHRcdFwi3pJcIjogXCJ6XCIsXG5cdFx0XHRcIt6TXCI6IFwidFwiLFxuXHRcdFx0XCLelFwiOiBcInlcIixcblx0XHRcdFwi3pVcIjogXCJwXCIsXG5cdFx0XHRcIt6WXCI6IFwialwiLFxuXHRcdFx0XCLel1wiOiBcImNoXCIsXG5cdFx0XHRcIt6YXCI6IFwidHRcIixcblx0XHRcdFwi3plcIjogXCJoaFwiLFxuXHRcdFx0XCLemlwiOiBcImtoXCIsXG5cdFx0XHRcIt6bXCI6IFwidGhcIixcblx0XHRcdFwi3pxcIjogXCJ6XCIsXG5cdFx0XHRcIt6dXCI6IFwic2hcIixcblx0XHRcdFwi3p5cIjogXCJzXCIsXG5cdFx0XHRcIt6fXCI6IFwiZFwiLFxuXHRcdFx0XCLeoFwiOiBcInRcIixcblx0XHRcdFwi3qFcIjogXCJ6XCIsXG5cdFx0XHRcIt6iXCI6IFwiYVwiLFxuXHRcdFx0XCLeo1wiOiBcImdoXCIsXG5cdFx0XHRcIt6kXCI6IFwicVwiLFxuXHRcdFx0XCLepVwiOiBcIndcIixcblx0XHRcdFwi3qZcIjogXCJhXCIsXG5cdFx0XHRcIt6nXCI6IFwiYWFcIixcblx0XHRcdFwi3qhcIjogXCJpXCIsXG5cdFx0XHRcIt6pXCI6IFwiZWVcIixcblx0XHRcdFwi3qpcIjogXCJ1XCIsXG5cdFx0XHRcIt6rXCI6IFwib29cIixcblx0XHRcdFwi3qxcIjogXCJlXCIsXG5cdFx0XHRcIt6tXCI6IFwiZXlcIixcblx0XHRcdFwi3q5cIjogXCJvXCIsXG5cdFx0XHRcIt6vXCI6IFwib2FcIixcblx0XHRcdFwi3rBcIjogXCJcIixcblx0XHRcdFwi4YOQXCI6IFwiYVwiLFxuXHRcdFx0XCLhg5FcIjogXCJiXCIsXG5cdFx0XHRcIuGDklwiOiBcImdcIixcblx0XHRcdFwi4YOTXCI6IFwiZFwiLFxuXHRcdFx0XCLhg5RcIjogXCJlXCIsXG5cdFx0XHRcIuGDlVwiOiBcInZcIixcblx0XHRcdFwi4YOWXCI6IFwielwiLFxuXHRcdFx0XCLhg5dcIjogXCJ0XCIsXG5cdFx0XHRcIuGDmFwiOiBcImlcIixcblx0XHRcdFwi4YOZXCI6IFwia1wiLFxuXHRcdFx0XCLhg5pcIjogXCJsXCIsXG5cdFx0XHRcIuGDm1wiOiBcIm1cIixcblx0XHRcdFwi4YOcXCI6IFwiblwiLFxuXHRcdFx0XCLhg51cIjogXCJvXCIsXG5cdFx0XHRcIuGDnlwiOiBcInBcIixcblx0XHRcdFwi4YOfXCI6IFwiemhcIixcblx0XHRcdFwi4YOgXCI6IFwiclwiLFxuXHRcdFx0XCLhg6FcIjogXCJzXCIsXG5cdFx0XHRcIuGDolwiOiBcInRcIixcblx0XHRcdFwi4YOjXCI6IFwidVwiLFxuXHRcdFx0XCLhg6RcIjogXCJwXCIsXG5cdFx0XHRcIuGDpVwiOiBcImtcIixcblx0XHRcdFwi4YOmXCI6IFwiZ2hcIixcblx0XHRcdFwi4YOnXCI6IFwicVwiLFxuXHRcdFx0XCLhg6hcIjogXCJzaFwiLFxuXHRcdFx0XCLhg6lcIjogXCJjaFwiLFxuXHRcdFx0XCLhg6pcIjogXCJ0c1wiLFxuXHRcdFx0XCLhg6tcIjogXCJkelwiLFxuXHRcdFx0XCLhg6xcIjogXCJ0c1wiLFxuXHRcdFx0XCLhg61cIjogXCJjaFwiLFxuXHRcdFx0XCLhg65cIjogXCJraFwiLFxuXHRcdFx0XCLhg69cIjogXCJqXCIsXG5cdFx0XHRcIuGDsFwiOiBcImhcIixcblx0XHRcdFwizrFcIjogXCJhXCIsXG5cdFx0XHRcIs6yXCI6IFwidlwiLFxuXHRcdFx0XCLOs1wiOiBcImdcIixcblx0XHRcdFwizrRcIjogXCJkXCIsXG5cdFx0XHRcIs61XCI6IFwiZVwiLFxuXHRcdFx0XCLOtlwiOiBcInpcIixcblx0XHRcdFwizrdcIjogXCJpXCIsXG5cdFx0XHRcIs64XCI6IFwidGhcIixcblx0XHRcdFwizrlcIjogXCJpXCIsXG5cdFx0XHRcIs66XCI6IFwia1wiLFxuXHRcdFx0XCLOu1wiOiBcImxcIixcblx0XHRcdFwizrxcIjogXCJtXCIsXG5cdFx0XHRcIs69XCI6IFwiblwiLFxuXHRcdFx0XCLOvlwiOiBcImtzXCIsXG5cdFx0XHRcIs6/XCI6IFwib1wiLFxuXHRcdFx0XCLPgFwiOiBcInBcIixcblx0XHRcdFwiz4FcIjogXCJyXCIsXG5cdFx0XHRcIs+DXCI6IFwic1wiLFxuXHRcdFx0XCLPhFwiOiBcInRcIixcblx0XHRcdFwiz4VcIjogXCJ5XCIsXG5cdFx0XHRcIs+GXCI6IFwiZlwiLFxuXHRcdFx0XCLPh1wiOiBcInhcIixcblx0XHRcdFwiz4hcIjogXCJwc1wiLFxuXHRcdFx0XCLPiVwiOiBcIm9cIixcblx0XHRcdFwizqxcIjogXCJhXCIsXG5cdFx0XHRcIs6tXCI6IFwiZVwiLFxuXHRcdFx0XCLOr1wiOiBcImlcIixcblx0XHRcdFwiz4xcIjogXCJvXCIsXG5cdFx0XHRcIs+NXCI6IFwieVwiLFxuXHRcdFx0XCLOrlwiOiBcImlcIixcblx0XHRcdFwiz45cIjogXCJvXCIsXG5cdFx0XHRcIs+CXCI6IFwic1wiLFxuXHRcdFx0XCLPilwiOiBcImlcIixcblx0XHRcdFwizrBcIjogXCJ5XCIsXG5cdFx0XHRcIs+LXCI6IFwieVwiLFxuXHRcdFx0XCLOkFwiOiBcImlcIixcblx0XHRcdFwizpFcIjogXCJBXCIsXG5cdFx0XHRcIs6SXCI6IFwiQlwiLFxuXHRcdFx0XCLOk1wiOiBcIkdcIixcblx0XHRcdFwizpRcIjogXCJEXCIsXG5cdFx0XHRcIs6VXCI6IFwiRVwiLFxuXHRcdFx0XCLOllwiOiBcIlpcIixcblx0XHRcdFwizpdcIjogXCJJXCIsXG5cdFx0XHRcIs6YXCI6IFwiVEhcIixcblx0XHRcdFwizplcIjogXCJJXCIsXG5cdFx0XHRcIs6aXCI6IFwiS1wiLFxuXHRcdFx0XCLOm1wiOiBcIkxcIixcblx0XHRcdFwizpxcIjogXCJNXCIsXG5cdFx0XHRcIs6dXCI6IFwiTlwiLFxuXHRcdFx0XCLOnlwiOiBcIktTXCIsXG5cdFx0XHRcIs6fXCI6IFwiT1wiLFxuXHRcdFx0XCLOoFwiOiBcIlBcIixcblx0XHRcdFwizqFcIjogXCJSXCIsXG5cdFx0XHRcIs6jXCI6IFwiU1wiLFxuXHRcdFx0XCLOpFwiOiBcIlRcIixcblx0XHRcdFwizqVcIjogXCJZXCIsXG5cdFx0XHRcIs6mXCI6IFwiRlwiLFxuXHRcdFx0XCLOp1wiOiBcIlhcIixcblx0XHRcdFwizqhcIjogXCJQU1wiLFxuXHRcdFx0XCLOqVwiOiBcIk9cIixcblx0XHRcdFwizoZcIjogXCJBXCIsXG5cdFx0XHRcIs6IXCI6IFwiRVwiLFxuXHRcdFx0XCLOilwiOiBcIklcIixcblx0XHRcdFwizoxcIjogXCJPXCIsXG5cdFx0XHRcIs6OXCI6IFwiWVwiLFxuXHRcdFx0XCLOiVwiOiBcIklcIixcblx0XHRcdFwizo9cIjogXCJPXCIsXG5cdFx0XHRcIs6qXCI6IFwiSVwiLFxuXHRcdFx0XCLOq1wiOiBcIllcIixcblx0XHRcdFwixIFcIjogXCJhXCIsXG5cdFx0XHRcIsSTXCI6IFwiZVwiLFxuXHRcdFx0XCLEo1wiOiBcImdcIixcblx0XHRcdFwixKtcIjogXCJpXCIsXG5cdFx0XHRcIsS3XCI6IFwia1wiLFxuXHRcdFx0XCLEvFwiOiBcImxcIixcblx0XHRcdFwixYZcIjogXCJuXCIsXG5cdFx0XHRcIsWrXCI6IFwidVwiLFxuXHRcdFx0XCLEgFwiOiBcIkFcIixcblx0XHRcdFwixJJcIjogXCJFXCIsXG5cdFx0XHRcIsSiXCI6IFwiR1wiLFxuXHRcdFx0XCLEqlwiOiBcIklcIixcblx0XHRcdFwixLZcIjogXCJrXCIsXG5cdFx0XHRcIsS7XCI6IFwiTFwiLFxuXHRcdFx0XCLFhVwiOiBcIk5cIixcblx0XHRcdFwixapcIjogXCJVXCIsXG5cdFx0XHRcItCMXCI6IFwiS2pcIixcblx0XHRcdFwi0ZxcIjogXCJralwiLFxuXHRcdFx0XCLQiVwiOiBcIkxqXCIsXG5cdFx0XHRcItGZXCI6IFwibGpcIixcblx0XHRcdFwi0IpcIjogXCJOalwiLFxuXHRcdFx0XCLRmlwiOiBcIm5qXCIsXG5cdFx0XHRcItCi0YFcIjogXCJUc1wiLFxuXHRcdFx0XCLRgtGBXCI6IFwidHNcIixcblx0XHRcdFwixIVcIjogXCJhXCIsXG5cdFx0XHRcIsSHXCI6IFwiY1wiLFxuXHRcdFx0XCLEmVwiOiBcImVcIixcblx0XHRcdFwixYJcIjogXCJsXCIsXG5cdFx0XHRcIsWEXCI6IFwiblwiLFxuXHRcdFx0XCLFm1wiOiBcInNcIixcblx0XHRcdFwixbpcIjogXCJ6XCIsXG5cdFx0XHRcIsW8XCI6IFwielwiLFxuXHRcdFx0XCLEhFwiOiBcIkFcIixcblx0XHRcdFwixIZcIjogXCJDXCIsXG5cdFx0XHRcIsSYXCI6IFwiRVwiLFxuXHRcdFx0XCLFgVwiOiBcIkxcIixcblx0XHRcdFwixYNcIjogXCJOXCIsXG5cdFx0XHRcIsWaXCI6IFwiU1wiLFxuXHRcdFx0XCLFuVwiOiBcIlpcIixcblx0XHRcdFwixbtcIjogXCJaXCIsXG5cdFx0XHRcItCEXCI6IFwiWWVcIixcblx0XHRcdFwi0IZcIjogXCJJXCIsXG5cdFx0XHRcItCHXCI6IFwiWWlcIixcblx0XHRcdFwi0pBcIjogXCJHXCIsXG5cdFx0XHRcItGUXCI6IFwieWVcIixcblx0XHRcdFwi0ZZcIjogXCJpXCIsXG5cdFx0XHRcItGXXCI6IFwieWlcIixcblx0XHRcdFwi0pFcIjogXCJnXCIsXG5cdFx0XHRcIsSDXCI6IFwiYVwiLFxuXHRcdFx0XCLEglwiOiBcIkFcIixcblx0XHRcdFwiyJlcIjogXCJzXCIsXG5cdFx0XHRcIsiYXCI6IFwiU1wiLFxuXHRcdFx0XCLIm1wiOiBcInRcIixcblx0XHRcdFwiyJpcIjogXCJUXCIsXG5cdFx0XHRcIsWjXCI6IFwidFwiLFxuXHRcdFx0XCLFolwiOiBcIlRcIixcblx0XHRcdFwi0LBcIjogXCJhXCIsXG5cdFx0XHRcItCxXCI6IFwiYlwiLFxuXHRcdFx0XCLQslwiOiBcInZcIixcblx0XHRcdFwi0LNcIjogXCJnXCIsXG5cdFx0XHRcItC0XCI6IFwiZFwiLFxuXHRcdFx0XCLQtVwiOiBcImVcIixcblx0XHRcdFwi0ZFcIjogXCJ5b1wiLFxuXHRcdFx0XCLQtlwiOiBcInpoXCIsXG5cdFx0XHRcItC3XCI6IFwielwiLFxuXHRcdFx0XCLQuFwiOiBcImlcIixcblx0XHRcdFwi0LlcIjogXCJpXCIsXG5cdFx0XHRcItC6XCI6IFwia1wiLFxuXHRcdFx0XCLQu1wiOiBcImxcIixcblx0XHRcdFwi0LxcIjogXCJtXCIsXG5cdFx0XHRcItC9XCI6IFwiblwiLFxuXHRcdFx0XCLQvlwiOiBcIm9cIixcblx0XHRcdFwi0L9cIjogXCJwXCIsXG5cdFx0XHRcItGAXCI6IFwiclwiLFxuXHRcdFx0XCLRgVwiOiBcInNcIixcblx0XHRcdFwi0YJcIjogXCJ0XCIsXG5cdFx0XHRcItGDXCI6IFwidVwiLFxuXHRcdFx0XCLRhFwiOiBcImZcIixcblx0XHRcdFwi0YVcIjogXCJraFwiLFxuXHRcdFx0XCLRhlwiOiBcImNcIixcblx0XHRcdFwi0YdcIjogXCJjaFwiLFxuXHRcdFx0XCLRiFwiOiBcInNoXCIsXG5cdFx0XHRcItGJXCI6IFwic2hcIixcblx0XHRcdFwi0YpcIjogXCJcIixcblx0XHRcdFwi0YtcIjogXCJ5XCIsXG5cdFx0XHRcItGMXCI6IFwiXCIsXG5cdFx0XHRcItGNXCI6IFwiZVwiLFxuXHRcdFx0XCLRjlwiOiBcInl1XCIsXG5cdFx0XHRcItGPXCI6IFwieWFcIixcblx0XHRcdFwi0JBcIjogXCJBXCIsXG5cdFx0XHRcItCRXCI6IFwiQlwiLFxuXHRcdFx0XCLQklwiOiBcIlZcIixcblx0XHRcdFwi0JNcIjogXCJHXCIsXG5cdFx0XHRcItCUXCI6IFwiRFwiLFxuXHRcdFx0XCLQlVwiOiBcIkVcIixcblx0XHRcdFwi0IFcIjogXCJZb1wiLFxuXHRcdFx0XCLQllwiOiBcIlpoXCIsXG5cdFx0XHRcItCXXCI6IFwiWlwiLFxuXHRcdFx0XCLQmFwiOiBcIklcIixcblx0XHRcdFwi0JlcIjogXCJJXCIsXG5cdFx0XHRcItCaXCI6IFwiS1wiLFxuXHRcdFx0XCLQm1wiOiBcIkxcIixcblx0XHRcdFwi0JxcIjogXCJNXCIsXG5cdFx0XHRcItCdXCI6IFwiTlwiLFxuXHRcdFx0XCLQnlwiOiBcIk9cIixcblx0XHRcdFwi0J9cIjogXCJQXCIsXG5cdFx0XHRcItCgXCI6IFwiUlwiLFxuXHRcdFx0XCLQoVwiOiBcIlNcIixcblx0XHRcdFwi0KJcIjogXCJUXCIsXG5cdFx0XHRcItCjXCI6IFwiVVwiLFxuXHRcdFx0XCLQpFwiOiBcIkZcIixcblx0XHRcdFwi0KVcIjogXCJLaFwiLFxuXHRcdFx0XCLQplwiOiBcIkNcIixcblx0XHRcdFwi0KdcIjogXCJDaFwiLFxuXHRcdFx0XCLQqFwiOiBcIlNoXCIsXG5cdFx0XHRcItCpXCI6IFwiU2hcIixcblx0XHRcdFwi0KpcIjogXCJcIixcblx0XHRcdFwi0KtcIjogXCJZXCIsXG5cdFx0XHRcItCsXCI6IFwiXCIsXG5cdFx0XHRcItCtXCI6IFwiRVwiLFxuXHRcdFx0XCLQrlwiOiBcIll1XCIsXG5cdFx0XHRcItCvXCI6IFwiWWFcIixcblx0XHRcdFwi0ZJcIjogXCJkalwiLFxuXHRcdFx0XCLRmFwiOiBcImpcIixcblx0XHRcdFwi0ZtcIjogXCJjXCIsXG5cdFx0XHRcItGfXCI6IFwiZHpcIixcblx0XHRcdFwi0IJcIjogXCJEalwiLFxuXHRcdFx0XCLQiFwiOiBcImpcIixcblx0XHRcdFwi0ItcIjogXCJDXCIsXG5cdFx0XHRcItCPXCI6IFwiRHpcIixcblx0XHRcdFwixL5cIjogXCJsXCIsXG5cdFx0XHRcIsS6XCI6IFwibFwiLFxuXHRcdFx0XCLFlVwiOiBcInJcIixcblx0XHRcdFwixL1cIjogXCJMXCIsXG5cdFx0XHRcIsS5XCI6IFwiTFwiLFxuXHRcdFx0XCLFlFwiOiBcIlJcIixcblx0XHRcdFwixZ9cIjogXCJzXCIsXG5cdFx0XHRcIsWeXCI6IFwiU1wiLFxuXHRcdFx0XCLEsVwiOiBcImlcIixcblx0XHRcdFwixLBcIjogXCJJXCIsXG5cdFx0XHRcIsSfXCI6IFwiZ1wiLFxuXHRcdFx0XCLEnlwiOiBcIkdcIixcblx0XHRcdFwi4bqjXCI6IFwiYVwiLFxuXHRcdFx0XCLhuqJcIjogXCJBXCIsXG5cdFx0XHRcIuG6s1wiOiBcImFcIixcblx0XHRcdFwi4bqyXCI6IFwiQVwiLFxuXHRcdFx0XCLhuqlcIjogXCJhXCIsXG5cdFx0XHRcIuG6qFwiOiBcIkFcIixcblx0XHRcdFwixJFcIjogXCJkXCIsXG5cdFx0XHRcIsSQXCI6IFwiRFwiLFxuXHRcdFx0XCLhurlcIjogXCJlXCIsXG5cdFx0XHRcIuG6uFwiOiBcIkVcIixcblx0XHRcdFwi4bq9XCI6IFwiZVwiLFxuXHRcdFx0XCLhurxcIjogXCJFXCIsXG5cdFx0XHRcIuG6u1wiOiBcImVcIixcblx0XHRcdFwi4bq6XCI6IFwiRVwiLFxuXHRcdFx0XCLhur9cIjogXCJlXCIsXG5cdFx0XHRcIuG6vlwiOiBcIkVcIixcblx0XHRcdFwi4buBXCI6IFwiZVwiLFxuXHRcdFx0XCLhu4BcIjogXCJFXCIsXG5cdFx0XHRcIuG7h1wiOiBcImVcIixcblx0XHRcdFwi4buGXCI6IFwiRVwiLFxuXHRcdFx0XCLhu4VcIjogXCJlXCIsXG5cdFx0XHRcIuG7hFwiOiBcIkVcIixcblx0XHRcdFwi4buDXCI6IFwiZVwiLFxuXHRcdFx0XCLhu4JcIjogXCJFXCIsXG5cdFx0XHRcIuG7j1wiOiBcIm9cIixcblx0XHRcdFwi4buNXCI6IFwib1wiLFxuXHRcdFx0XCLhu4xcIjogXCJvXCIsXG5cdFx0XHRcIuG7kVwiOiBcIm9cIixcblx0XHRcdFwi4buQXCI6IFwiT1wiLFxuXHRcdFx0XCLhu5NcIjogXCJvXCIsXG5cdFx0XHRcIuG7klwiOiBcIk9cIixcblx0XHRcdFwi4buVXCI6IFwib1wiLFxuXHRcdFx0XCLhu5RcIjogXCJPXCIsXG5cdFx0XHRcIuG7mVwiOiBcIm9cIixcblx0XHRcdFwi4buYXCI6IFwiT1wiLFxuXHRcdFx0XCLhu5dcIjogXCJvXCIsXG5cdFx0XHRcIuG7llwiOiBcIk9cIixcblx0XHRcdFwixqFcIjogXCJvXCIsXG5cdFx0XHRcIsagXCI6IFwiT1wiLFxuXHRcdFx0XCLhu5tcIjogXCJvXCIsXG5cdFx0XHRcIuG7mlwiOiBcIk9cIixcblx0XHRcdFwi4budXCI6IFwib1wiLFxuXHRcdFx0XCLhu5xcIjogXCJPXCIsXG5cdFx0XHRcIuG7o1wiOiBcIm9cIixcblx0XHRcdFwi4buiXCI6IFwiT1wiLFxuXHRcdFx0XCLhu6FcIjogXCJvXCIsXG5cdFx0XHRcIuG7oFwiOiBcIk9cIixcblx0XHRcdFwi4bueXCI6IFwib1wiLFxuXHRcdFx0XCLhu59cIjogXCJvXCIsXG5cdFx0XHRcIuG7i1wiOiBcImlcIixcblx0XHRcdFwi4buKXCI6IFwiSVwiLFxuXHRcdFx0XCLEqVwiOiBcImlcIixcblx0XHRcdFwixKhcIjogXCJJXCIsXG5cdFx0XHRcIuG7iVwiOiBcImlcIixcblx0XHRcdFwi4buIXCI6IFwiaVwiLFxuXHRcdFx0XCLhu6dcIjogXCJ1XCIsXG5cdFx0XHRcIuG7plwiOiBcIlVcIixcblx0XHRcdFwi4bulXCI6IFwidVwiLFxuXHRcdFx0XCLhu6RcIjogXCJVXCIsXG5cdFx0XHRcIsWpXCI6IFwidVwiLFxuXHRcdFx0XCLFqFwiOiBcIlVcIixcblx0XHRcdFwixrBcIjogXCJ1XCIsXG5cdFx0XHRcIsavXCI6IFwiVVwiLFxuXHRcdFx0XCLhu6lcIjogXCJ1XCIsXG5cdFx0XHRcIuG7qFwiOiBcIlVcIixcblx0XHRcdFwi4burXCI6IFwidVwiLFxuXHRcdFx0XCLhu6pcIjogXCJVXCIsXG5cdFx0XHRcIuG7sVwiOiBcInVcIixcblx0XHRcdFwi4buwXCI6IFwiVVwiLFxuXHRcdFx0XCLhu69cIjogXCJ1XCIsXG5cdFx0XHRcIuG7rlwiOiBcIlVcIixcblx0XHRcdFwi4butXCI6IFwidVwiLFxuXHRcdFx0XCLhu6xcIjogXCLGsFwiLFxuXHRcdFx0XCLhu7dcIjogXCJ5XCIsXG5cdFx0XHRcIuG7tlwiOiBcInlcIixcblx0XHRcdFwi4buzXCI6IFwieVwiLFxuXHRcdFx0XCLhu7JcIjogXCJZXCIsXG5cdFx0XHRcIuG7tVwiOiBcInlcIixcblx0XHRcdFwi4bu0XCI6IFwiWVwiLFxuXHRcdFx0XCLhu7lcIjogXCJ5XCIsXG5cdFx0XHRcIuG7uFwiOiBcIllcIixcblx0XHRcdFwi4bqhXCI6IFwiYVwiLFxuXHRcdFx0XCLhuqBcIjogXCJBXCIsXG5cdFx0XHRcIuG6pVwiOiBcImFcIixcblx0XHRcdFwi4bqkXCI6IFwiQVwiLFxuXHRcdFx0XCLhuqdcIjogXCJhXCIsXG5cdFx0XHRcIuG6plwiOiBcIkFcIixcblx0XHRcdFwi4bqtXCI6IFwiYVwiLFxuXHRcdFx0XCLhuqxcIjogXCJBXCIsXG5cdFx0XHRcIuG6q1wiOiBcImFcIixcblx0XHRcdFwi4bqqXCI6IFwiQVwiLFxuXHRcdFx0XCLhuq9cIjogXCJhXCIsXG5cdFx0XHRcIuG6rlwiOiBcIkFcIixcblx0XHRcdFwi4bqxXCI6IFwiYVwiLFxuXHRcdFx0XCLhurBcIjogXCJBXCIsXG5cdFx0XHRcIuG6t1wiOiBcImFcIixcblx0XHRcdFwi4bq2XCI6IFwiQVwiLFxuXHRcdFx0XCLhurVcIjogXCJhXCIsXG5cdFx0XHRcIuG6tFwiOiBcIkFcIixcblx0XHRcdFwi4pOqXCI6IFwiMFwiLFxuXHRcdFx0XCLikaBcIjogXCIxXCIsXG5cdFx0XHRcIuKRoVwiOiBcIjJcIixcblx0XHRcdFwi4pGiXCI6IFwiM1wiLFxuXHRcdFx0XCLikaNcIjogXCI0XCIsXG5cdFx0XHRcIuKRpFwiOiBcIjVcIixcblx0XHRcdFwi4pGlXCI6IFwiNlwiLFxuXHRcdFx0XCLikaZcIjogXCI3XCIsXG5cdFx0XHRcIuKRp1wiOiBcIjhcIixcblx0XHRcdFwi4pGoXCI6IFwiOVwiLFxuXHRcdFx0XCLikalcIjogXCIxMFwiLFxuXHRcdFx0XCLikapcIjogXCIxMVwiLFxuXHRcdFx0XCLikatcIjogXCIxMlwiLFxuXHRcdFx0XCLikaxcIjogXCIxM1wiLFxuXHRcdFx0XCLika1cIjogXCIxNFwiLFxuXHRcdFx0XCLika5cIjogXCIxNVwiLFxuXHRcdFx0XCLika9cIjogXCIxNlwiLFxuXHRcdFx0XCLikbBcIjogXCIxN1wiLFxuXHRcdFx0XCLikbFcIjogXCIxOFwiLFxuXHRcdFx0XCLikbJcIjogXCIxOFwiLFxuXHRcdFx0XCLikbNcIjogXCIxOFwiLFxuXHRcdFx0XCLik7VcIjogXCIxXCIsXG5cdFx0XHRcIuKTtlwiOiBcIjJcIixcblx0XHRcdFwi4pO3XCI6IFwiM1wiLFxuXHRcdFx0XCLik7hcIjogXCI0XCIsXG5cdFx0XHRcIuKTuVwiOiBcIjVcIixcblx0XHRcdFwi4pO6XCI6IFwiNlwiLFxuXHRcdFx0XCLik7tcIjogXCI3XCIsXG5cdFx0XHRcIuKTvFwiOiBcIjhcIixcblx0XHRcdFwi4pO9XCI6IFwiOVwiLFxuXHRcdFx0XCLik75cIjogXCIxMFwiLFxuXHRcdFx0XCLik79cIjogXCIwXCIsXG5cdFx0XHRcIuKTq1wiOiBcIjExXCIsXG5cdFx0XHRcIuKTrFwiOiBcIjEyXCIsXG5cdFx0XHRcIuKTrVwiOiBcIjEzXCIsXG5cdFx0XHRcIuKTrlwiOiBcIjE0XCIsXG5cdFx0XHRcIuKTr1wiOiBcIjE1XCIsXG5cdFx0XHRcIuKTsFwiOiBcIjE2XCIsXG5cdFx0XHRcIuKTsVwiOiBcIjE3XCIsXG5cdFx0XHRcIuKTslwiOiBcIjE4XCIsXG5cdFx0XHRcIuKTs1wiOiBcIjE5XCIsXG5cdFx0XHRcIuKTtFwiOiBcIjIwXCIsXG5cdFx0XHRcIuKStlwiOiBcIkFcIixcblx0XHRcdFwi4pK3XCI6IFwiQlwiLFxuXHRcdFx0XCLikrhcIjogXCJDXCIsXG5cdFx0XHRcIuKSuVwiOiBcIkRcIixcblx0XHRcdFwi4pK6XCI6IFwiRVwiLFxuXHRcdFx0XCLikrtcIjogXCJGXCIsXG5cdFx0XHRcIuKSvFwiOiBcIkdcIixcblx0XHRcdFwi4pK9XCI6IFwiSFwiLFxuXHRcdFx0XCLikr5cIjogXCJJXCIsXG5cdFx0XHRcIuKSv1wiOiBcIkpcIixcblx0XHRcdFwi4pOAXCI6IFwiS1wiLFxuXHRcdFx0XCLik4FcIjogXCJMXCIsXG5cdFx0XHRcIuKTglwiOiBcIk1cIixcblx0XHRcdFwi4pODXCI6IFwiTlwiLFxuXHRcdFx0XCLik4RcIjogXCJPXCIsXG5cdFx0XHRcIuKThVwiOiBcIlBcIixcblx0XHRcdFwi4pOGXCI6IFwiUVwiLFxuXHRcdFx0XCLik4dcIjogXCJSXCIsXG5cdFx0XHRcIuKTiFwiOiBcIlNcIixcblx0XHRcdFwi4pOJXCI6IFwiVFwiLFxuXHRcdFx0XCLik4pcIjogXCJVXCIsXG5cdFx0XHRcIuKTi1wiOiBcIlZcIixcblx0XHRcdFwi4pOMXCI6IFwiV1wiLFxuXHRcdFx0XCLik41cIjogXCJYXCIsXG5cdFx0XHRcIuKTjlwiOiBcIllcIixcblx0XHRcdFwi4pOPXCI6IFwiWlwiLFxuXHRcdFx0XCLik5BcIjogXCJhXCIsXG5cdFx0XHRcIuKTkVwiOiBcImJcIixcblx0XHRcdFwi4pOSXCI6IFwiY1wiLFxuXHRcdFx0XCLik5NcIjogXCJkXCIsXG5cdFx0XHRcIuKTlFwiOiBcImVcIixcblx0XHRcdFwi4pOVXCI6IFwiZlwiLFxuXHRcdFx0XCLik5ZcIjogXCJnXCIsXG5cdFx0XHRcIuKTl1wiOiBcImhcIixcblx0XHRcdFwi4pOYXCI6IFwiaVwiLFxuXHRcdFx0XCLik5lcIjogXCJqXCIsXG5cdFx0XHRcIuKTmlwiOiBcImtcIixcblx0XHRcdFwi4pObXCI6IFwibFwiLFxuXHRcdFx0XCLik5xcIjogXCJtXCIsXG5cdFx0XHRcIuKTnVwiOiBcIm5cIixcblx0XHRcdFwi4pOeXCI6IFwib1wiLFxuXHRcdFx0XCLik59cIjogXCJwXCIsXG5cdFx0XHRcIuKToFwiOiBcInFcIixcblx0XHRcdFwi4pOhXCI6IFwiclwiLFxuXHRcdFx0XCLik6JcIjogXCJzXCIsXG5cdFx0XHRcIuKTo1wiOiBcInRcIixcblx0XHRcdFwi4pOkXCI6IFwidVwiLFxuXHRcdFx0XCLik6ZcIjogXCJ2XCIsXG5cdFx0XHRcIuKTpVwiOiBcIndcIixcblx0XHRcdFwi4pOnXCI6IFwieFwiLFxuXHRcdFx0XCLik6hcIjogXCJ5XCIsXG5cdFx0XHRcIuKTqVwiOiBcInpcIixcblx0XHRcdFwi4oCcXCI6IFwiXFxcIlwiLFxuXHRcdFx0XCLigJ1cIjogXCJcXFwiXCIsXG5cdFx0XHRcIuKAmFwiOiBcIidcIixcblx0XHRcdFwi4oCZXCI6IFwiJ1wiLFxuXHRcdFx0XCLiiIJcIjogXCJkXCIsXG5cdFx0XHRcIsaSXCI6IFwiZlwiLFxuXHRcdFx0XCLihKJcIjogXCIoVE0pXCIsXG5cdFx0XHRcIsKpXCI6IFwiKEMpXCIsXG5cdFx0XHRcIsWTXCI6IFwib2VcIixcblx0XHRcdFwixZJcIjogXCJPRVwiLFxuXHRcdFx0XCLCrlwiOiBcIihSKVwiLFxuXHRcdFx0XCLigKBcIjogXCIrXCIsXG5cdFx0XHRcIuKEoFwiOiBcIihTTSlcIixcblx0XHRcdFwi4oCmXCI6IFwiLi4uXCIsXG5cdFx0XHRcIsuaXCI6IFwib1wiLFxuXHRcdFx0XCLCulwiOiBcIm9cIixcblx0XHRcdFwiwqpcIjogXCJhXCIsXG5cdFx0XHRcIuKAolwiOiBcIipcIixcblx0XHRcdFwi4YGKXCI6IFwiLFwiLFxuXHRcdFx0XCLhgYtcIjogXCIuXCIsXG5cdFx0XHRcIiRcIjogXCJVU0RcIixcblx0XHRcdFwi4oKsXCI6IFwiRVVSXCIsXG5cdFx0XHRcIuKColwiOiBcIkJSTlwiLFxuXHRcdFx0XCLigqNcIjogXCJGUkZcIixcblx0XHRcdFwiwqNcIjogXCJHQlBcIixcblx0XHRcdFwi4oKkXCI6IFwiSVRMXCIsXG5cdFx0XHRcIuKCplwiOiBcIk5HTlwiLFxuXHRcdFx0XCLigqdcIjogXCJFU1BcIixcblx0XHRcdFwi4oKpXCI6IFwiS1JXXCIsXG5cdFx0XHRcIuKCqlwiOiBcIklMU1wiLFxuXHRcdFx0XCLigqtcIjogXCJWTkRcIixcblx0XHRcdFwi4oKtXCI6IFwiTEFLXCIsXG5cdFx0XHRcIuKCrlwiOiBcIk1OVFwiLFxuXHRcdFx0XCLigq9cIjogXCJHUkRcIixcblx0XHRcdFwi4oKxXCI6IFwiQVJTXCIsXG5cdFx0XHRcIuKCslwiOiBcIlBZR1wiLFxuXHRcdFx0XCLigrNcIjogXCJBUkFcIixcblx0XHRcdFwi4oK0XCI6IFwiVUFIXCIsXG5cdFx0XHRcIuKCtVwiOiBcIkdIU1wiLFxuXHRcdFx0XCLColwiOiBcImNlbnRcIixcblx0XHRcdFwiwqVcIjogXCJDTllcIixcblx0XHRcdFwi5YWDXCI6IFwiQ05ZXCIsXG5cdFx0XHRcIuWGhlwiOiBcIllFTlwiLFxuXHRcdFx0XCLvt7xcIjogXCJJUlJcIixcblx0XHRcdFwi4oKgXCI6IFwiRVdFXCIsXG5cdFx0XHRcIuC4v1wiOiBcIlRIQlwiLFxuXHRcdFx0XCLigqhcIjogXCJJTlJcIixcblx0XHRcdFwi4oK5XCI6IFwiSU5SXCIsXG5cdFx0XHRcIuKCsFwiOiBcIlBGXCIsXG5cdFx0XHRcIuKCulwiOiBcIlRSWVwiLFxuXHRcdFx0XCLYi1wiOiBcIkFGTlwiLFxuXHRcdFx0XCLigrxcIjogXCJBWk5cIixcblx0XHRcdFwi0LvQslwiOiBcIkJHTlwiLFxuXHRcdFx0XCLhn5tcIjogXCJLSFJcIixcblx0XHRcdFwi4oKhXCI6IFwiQ1JDXCIsXG5cdFx0XHRcIuKCuFwiOiBcIktaVFwiLFxuXHRcdFx0XCLQtNC10L1cIjogXCJNS0RcIixcblx0XHRcdFwiesWCXCI6IFwiUExOXCIsXG5cdFx0XHRcIuKCvVwiOiBcIlJVQlwiLFxuXHRcdFx0XCLigr5cIjogXCJHRUxcIlxuXHRcdH07XG5cdFx0LyoqXG5cdFx0KiBzcGVjaWFsIGxvb2sgYWhlYWQgY2hhcmFjdGVyIGFycmF5XG5cdFx0KiBUaGVzZSBjaGFyYWN0ZXJzIGZvcm0gd2l0aCBjb25zb25hbnRzIHRvIGJlY29tZSAnc2luZ2xlJy9jb25zb25hbnQgY29tYm9cblx0XHQqIEB0eXBlIFtBcnJheV1cblx0XHQqL1xuXHRcdHZhciBsb29rQWhlYWRDaGFyQXJyYXkgPSBbXCLhgLpcIiwgXCLesFwiXTtcblx0XHQvKipcblx0XHQqIGRpYXRyaWNNYXAgZm9yIGxhbmd1YWdlcyB3aGVyZSB0cmFuc2xpdGVyYXRpb24gY2hhbmdlcyBlbnRpcmVseSBhcyBtb3JlIGRpYXRyaWNzIGFyZSBhZGRlZFxuXHRcdCogQHR5cGUge09iamVjdH1cblx0XHQqL1xuXHRcdHZhciBkaWF0cmljTWFwID0ge1xuXHRcdFx0XCLhgKxcIjogXCJhXCIsXG5cdFx0XHRcIuGAq1wiOiBcImFcIixcblx0XHRcdFwi4YCxXCI6IFwiZVwiLFxuXHRcdFx0XCLhgLJcIjogXCJlXCIsXG5cdFx0XHRcIuGArVwiOiBcImlcIixcblx0XHRcdFwi4YCuXCI6IFwiaVwiLFxuXHRcdFx0XCLhgK3hgK9cIjogXCJvXCIsXG5cdFx0XHRcIuGAr1wiOiBcInVcIixcblx0XHRcdFwi4YCwXCI6IFwidVwiLFxuXHRcdFx0XCLhgLHhgKvhgIThgLpcIjogXCJhdW5nXCIsXG5cdFx0XHRcIuGAseGArFwiOiBcImF3XCIsXG5cdFx0XHRcIuGAseGArOGAulwiOiBcImF3XCIsXG5cdFx0XHRcIuGAseGAq1wiOiBcImF3XCIsXG5cdFx0XHRcIuGAseGAq+GAulwiOiBcImF3XCIsXG5cdFx0XHRcIuGAulwiOiBcIuGAulwiLFxuXHRcdFx0XCLhgIDhgLpcIjogXCJldFwiLFxuXHRcdFx0XCLhgK3hgK/hgIDhgLpcIjogXCJhaWtcIixcblx0XHRcdFwi4YCx4YCs4YCA4YC6XCI6IFwiYXVrXCIsXG5cdFx0XHRcIuGAhOGAulwiOiBcImluXCIsXG5cdFx0XHRcIuGAreGAr+GAhOGAulwiOiBcImFpbmdcIixcblx0XHRcdFwi4YCx4YCs4YCE4YC6XCI6IFwiYXVuZ1wiLFxuXHRcdFx0XCLhgIXhgLpcIjogXCJpdFwiLFxuXHRcdFx0XCLhgIrhgLpcIjogXCJpXCIsXG5cdFx0XHRcIuGAkOGAulwiOiBcImF0XCIsXG5cdFx0XHRcIuGAreGAkOGAulwiOiBcImVpa1wiLFxuXHRcdFx0XCLhgK/hgJDhgLpcIjogXCJva1wiLFxuXHRcdFx0XCLhgL3hgJDhgLpcIjogXCJ1dFwiLFxuXHRcdFx0XCLhgLHhgJDhgLpcIjogXCJpdFwiLFxuXHRcdFx0XCLhgJLhgLpcIjogXCJkXCIsXG5cdFx0XHRcIuGAreGAr+GAkuGAulwiOiBcIm9rXCIsXG5cdFx0XHRcIuGAr+GAkuGAulwiOiBcImFpdFwiLFxuXHRcdFx0XCLhgJThgLpcIjogXCJhblwiLFxuXHRcdFx0XCLhgKzhgJThgLpcIjogXCJhblwiLFxuXHRcdFx0XCLhgK3hgJThgLpcIjogXCJlaW5cIixcblx0XHRcdFwi4YCv4YCU4YC6XCI6IFwib25cIixcblx0XHRcdFwi4YC94YCU4YC6XCI6IFwidW5cIixcblx0XHRcdFwi4YCV4YC6XCI6IFwiYXRcIixcblx0XHRcdFwi4YCt4YCV4YC6XCI6IFwiZWlrXCIsXG5cdFx0XHRcIuGAr+GAleGAulwiOiBcIm9rXCIsXG5cdFx0XHRcIuGAveGAleGAulwiOiBcInV0XCIsXG5cdFx0XHRcIuGAlOGAuuGAr+GAleGAulwiOiBcIm51YlwiLFxuXHRcdFx0XCLhgJnhgLpcIjogXCJhblwiLFxuXHRcdFx0XCLhgK3hgJnhgLpcIjogXCJlaW5cIixcblx0XHRcdFwi4YCv4YCZ4YC6XCI6IFwib25cIixcblx0XHRcdFwi4YC94YCZ4YC6XCI6IFwidW5cIixcblx0XHRcdFwi4YCa4YC6XCI6IFwiZVwiLFxuXHRcdFx0XCLhgK3hgK/hgJzhgLpcIjogXCJvbFwiLFxuXHRcdFx0XCLhgInhgLpcIjogXCJpblwiLFxuXHRcdFx0XCLhgLZcIjogXCJhblwiLFxuXHRcdFx0XCLhgK3hgLZcIjogXCJlaW5cIixcblx0XHRcdFwi4YCv4YC2XCI6IFwib25cIixcblx0XHRcdFwi3qbeh96wXCI6IFwiYWhcIixcblx0XHRcdFwi3qbegd6wXCI6IFwiYWhcIlxuXHRcdH07XG5cdFx0LyoqXG5cdFx0KiBsYW5nQ2hhck1hcCBsYW5ndWFnZSBzcGVjaWZpYyBjaGFyYWN0ZXJzIHRyYW5zbGF0aW9uc1xuXHRcdCogQHR5cGUgICB7T2JqZWN0fVxuXHRcdCovXG5cdFx0dmFyIGxhbmdDaGFyTWFwID0ge1xuXHRcdFx0XCJlblwiOiB7fSxcblx0XHRcdFwiYXpcIjoge1xuXHRcdFx0XHRcIsOnXCI6IFwiY1wiLFxuXHRcdFx0XHRcIsmZXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsSfXCI6IFwiZ1wiLFxuXHRcdFx0XHRcIsSxXCI6IFwiaVwiLFxuXHRcdFx0XHRcIsO2XCI6IFwib1wiLFxuXHRcdFx0XHRcIsWfXCI6IFwic1wiLFxuXHRcdFx0XHRcIsO8XCI6IFwidVwiLFxuXHRcdFx0XHRcIsOHXCI6IFwiQ1wiLFxuXHRcdFx0XHRcIsaPXCI6IFwiRVwiLFxuXHRcdFx0XHRcIsSeXCI6IFwiR1wiLFxuXHRcdFx0XHRcIsSwXCI6IFwiSVwiLFxuXHRcdFx0XHRcIsOWXCI6IFwiT1wiLFxuXHRcdFx0XHRcIsWeXCI6IFwiU1wiLFxuXHRcdFx0XHRcIsOcXCI6IFwiVVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJjc1wiOiB7XG5cdFx0XHRcdFwixI1cIjogXCJjXCIsXG5cdFx0XHRcdFwixI9cIjogXCJkXCIsXG5cdFx0XHRcdFwixJtcIjogXCJlXCIsXG5cdFx0XHRcdFwixYhcIjogXCJuXCIsXG5cdFx0XHRcdFwixZlcIjogXCJyXCIsXG5cdFx0XHRcdFwixaFcIjogXCJzXCIsXG5cdFx0XHRcdFwixaVcIjogXCJ0XCIsXG5cdFx0XHRcdFwixa9cIjogXCJ1XCIsXG5cdFx0XHRcdFwixb5cIjogXCJ6XCIsXG5cdFx0XHRcdFwixIxcIjogXCJDXCIsXG5cdFx0XHRcdFwixI5cIjogXCJEXCIsXG5cdFx0XHRcdFwixJpcIjogXCJFXCIsXG5cdFx0XHRcdFwixYdcIjogXCJOXCIsXG5cdFx0XHRcdFwixZhcIjogXCJSXCIsXG5cdFx0XHRcdFwixaBcIjogXCJTXCIsXG5cdFx0XHRcdFwixaRcIjogXCJUXCIsXG5cdFx0XHRcdFwixa5cIjogXCJVXCIsXG5cdFx0XHRcdFwixb1cIjogXCJaXCJcblx0XHRcdH0sXG5cdFx0XHRcImZpXCI6IHtcblx0XHRcdFx0XCLDpFwiOiBcImFcIixcblx0XHRcdFx0XCLDhFwiOiBcIkFcIixcblx0XHRcdFx0XCLDtlwiOiBcIm9cIixcblx0XHRcdFx0XCLDllwiOiBcIk9cIlxuXHRcdFx0fSxcblx0XHRcdFwiaHVcIjoge1xuXHRcdFx0XHRcIsOkXCI6IFwiYVwiLFxuXHRcdFx0XHRcIsOEXCI6IFwiQVwiLFxuXHRcdFx0XHRcIsO2XCI6IFwib1wiLFxuXHRcdFx0XHRcIsOWXCI6IFwiT1wiLFxuXHRcdFx0XHRcIsO8XCI6IFwidVwiLFxuXHRcdFx0XHRcIsOcXCI6IFwiVVwiLFxuXHRcdFx0XHRcIsWxXCI6IFwidVwiLFxuXHRcdFx0XHRcIsWwXCI6IFwiVVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJsdFwiOiB7XG5cdFx0XHRcdFwixIVcIjogXCJhXCIsXG5cdFx0XHRcdFwixI1cIjogXCJjXCIsXG5cdFx0XHRcdFwixJlcIjogXCJlXCIsXG5cdFx0XHRcdFwixJdcIjogXCJlXCIsXG5cdFx0XHRcdFwixK9cIjogXCJpXCIsXG5cdFx0XHRcdFwixaFcIjogXCJzXCIsXG5cdFx0XHRcdFwixbNcIjogXCJ1XCIsXG5cdFx0XHRcdFwixatcIjogXCJ1XCIsXG5cdFx0XHRcdFwixb5cIjogXCJ6XCIsXG5cdFx0XHRcdFwixIRcIjogXCJBXCIsXG5cdFx0XHRcdFwixIxcIjogXCJDXCIsXG5cdFx0XHRcdFwixJhcIjogXCJFXCIsXG5cdFx0XHRcdFwixJZcIjogXCJFXCIsXG5cdFx0XHRcdFwixK5cIjogXCJJXCIsXG5cdFx0XHRcdFwixaBcIjogXCJTXCIsXG5cdFx0XHRcdFwixbJcIjogXCJVXCIsXG5cdFx0XHRcdFwixapcIjogXCJVXCJcblx0XHRcdH0sXG5cdFx0XHRcImx2XCI6IHtcblx0XHRcdFx0XCLEgVwiOiBcImFcIixcblx0XHRcdFx0XCLEjVwiOiBcImNcIixcblx0XHRcdFx0XCLEk1wiOiBcImVcIixcblx0XHRcdFx0XCLEo1wiOiBcImdcIixcblx0XHRcdFx0XCLEq1wiOiBcImlcIixcblx0XHRcdFx0XCLEt1wiOiBcImtcIixcblx0XHRcdFx0XCLEvFwiOiBcImxcIixcblx0XHRcdFx0XCLFhlwiOiBcIm5cIixcblx0XHRcdFx0XCLFoVwiOiBcInNcIixcblx0XHRcdFx0XCLFq1wiOiBcInVcIixcblx0XHRcdFx0XCLFvlwiOiBcInpcIixcblx0XHRcdFx0XCLEgFwiOiBcIkFcIixcblx0XHRcdFx0XCLEjFwiOiBcIkNcIixcblx0XHRcdFx0XCLEklwiOiBcIkVcIixcblx0XHRcdFx0XCLEolwiOiBcIkdcIixcblx0XHRcdFx0XCLEqlwiOiBcImlcIixcblx0XHRcdFx0XCLEtlwiOiBcImtcIixcblx0XHRcdFx0XCLEu1wiOiBcIkxcIixcblx0XHRcdFx0XCLFhVwiOiBcIk5cIixcblx0XHRcdFx0XCLFoFwiOiBcIlNcIixcblx0XHRcdFx0XCLFqlwiOiBcInVcIixcblx0XHRcdFx0XCLFvVwiOiBcIlpcIlxuXHRcdFx0fSxcblx0XHRcdFwicGxcIjoge1xuXHRcdFx0XHRcIsSFXCI6IFwiYVwiLFxuXHRcdFx0XHRcIsSHXCI6IFwiY1wiLFxuXHRcdFx0XHRcIsSZXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsWCXCI6IFwibFwiLFxuXHRcdFx0XHRcIsWEXCI6IFwiblwiLFxuXHRcdFx0XHRcIsOzXCI6IFwib1wiLFxuXHRcdFx0XHRcIsWbXCI6IFwic1wiLFxuXHRcdFx0XHRcIsW6XCI6IFwielwiLFxuXHRcdFx0XHRcIsW8XCI6IFwielwiLFxuXHRcdFx0XHRcIsSEXCI6IFwiQVwiLFxuXHRcdFx0XHRcIsSGXCI6IFwiQ1wiLFxuXHRcdFx0XHRcIsSYXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsWBXCI6IFwiTFwiLFxuXHRcdFx0XHRcIsWDXCI6IFwiTlwiLFxuXHRcdFx0XHRcIsOTXCI6IFwiT1wiLFxuXHRcdFx0XHRcIsWaXCI6IFwiU1wiLFxuXHRcdFx0XHRcIsW5XCI6IFwiWlwiLFxuXHRcdFx0XHRcIsW7XCI6IFwiWlwiXG5cdFx0XHR9LFxuXHRcdFx0XCJzdlwiOiB7XG5cdFx0XHRcdFwiw6RcIjogXCJhXCIsXG5cdFx0XHRcdFwiw4RcIjogXCJBXCIsXG5cdFx0XHRcdFwiw7ZcIjogXCJvXCIsXG5cdFx0XHRcdFwiw5ZcIjogXCJPXCJcblx0XHRcdH0sXG5cdFx0XHRcInNrXCI6IHtcblx0XHRcdFx0XCLDpFwiOiBcImFcIixcblx0XHRcdFx0XCLDhFwiOiBcIkFcIlxuXHRcdFx0fSxcblx0XHRcdFwic3JcIjoge1xuXHRcdFx0XHRcItGZXCI6IFwibGpcIixcblx0XHRcdFx0XCLRmlwiOiBcIm5qXCIsXG5cdFx0XHRcdFwi0IlcIjogXCJMalwiLFxuXHRcdFx0XHRcItCKXCI6IFwiTmpcIixcblx0XHRcdFx0XCLEkVwiOiBcImRqXCIsXG5cdFx0XHRcdFwixJBcIjogXCJEalwiXG5cdFx0XHR9LFxuXHRcdFx0XCJ0clwiOiB7XG5cdFx0XHRcdFwiw5xcIjogXCJVXCIsXG5cdFx0XHRcdFwiw5ZcIjogXCJPXCIsXG5cdFx0XHRcdFwiw7xcIjogXCJ1XCIsXG5cdFx0XHRcdFwiw7ZcIjogXCJvXCJcblx0XHRcdH1cblx0XHR9O1xuXHRcdC8qKlxuXHRcdCogc3ltYm9sTWFwIGxhbmd1YWdlIHNwZWNpZmljIHN5bWJvbCB0cmFuc2xhdGlvbnNcblx0XHQqIHRyYW5zbGF0aW9ucyBtdXN0IGJlIHRyYW5zbGl0ZXJhdGVkIGFscmVhZHlcblx0XHQqIEB0eXBlICAge09iamVjdH1cblx0XHQqL1xuXHRcdHZhciBzeW1ib2xNYXAgPSB7XG5cdFx0XHRcImFyXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImxhLW5paGF5YVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImhvYlwiLFxuXHRcdFx0XHRcIiZcIjogXCJ3YVwiLFxuXHRcdFx0XHRcInxcIjogXCJhd1wiLFxuXHRcdFx0XHRcIjxcIjogXCJhcWFsLW1lblwiLFxuXHRcdFx0XHRcIj5cIjogXCJha2Jhci1tZW5cIixcblx0XHRcdFx0XCLiiJFcIjogXCJtYWptb3VcIixcblx0XHRcdFx0XCLCpFwiOiBcIm9tbGFcIlxuXHRcdFx0fSxcblx0XHRcdFwiYXpcIjoge30sXG5cdFx0XHRcImNhXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImluZmluaXRcIixcblx0XHRcdFx0XCLimaVcIjogXCJhbW9yXCIsXG5cdFx0XHRcdFwiJlwiOiBcImlcIixcblx0XHRcdFx0XCJ8XCI6IFwib1wiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW55cyBxdWVcIixcblx0XHRcdFx0XCI+XCI6IFwibWVzIHF1ZVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bWEgZGVsc1wiLFxuXHRcdFx0XHRcIsKkXCI6IFwibW9uZWRhXCJcblx0XHRcdH0sXG5cdFx0XHRcImNzXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcIm5la29uZWNub1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImxhc2thXCIsXG5cdFx0XHRcdFwiJlwiOiBcImFcIixcblx0XHRcdFx0XCJ8XCI6IFwibmVib1wiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5zaSBuZXpcIixcblx0XHRcdFx0XCI+XCI6IFwidmV0c2kgbmV6XCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic291Y2V0XCIsXG5cdFx0XHRcdFwiwqRcIjogXCJtZW5hXCJcblx0XHRcdH0sXG5cdFx0XHRcImRlXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcInVuZW5kbGljaFwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIkxpZWJlXCIsXG5cdFx0XHRcdFwiJlwiOiBcInVuZFwiLFxuXHRcdFx0XHRcInxcIjogXCJvZGVyXCIsXG5cdFx0XHRcdFwiPFwiOiBcImtsZWluZXIgYWxzXCIsXG5cdFx0XHRcdFwiPlwiOiBcImdyb2Vzc2VyIGFsc1wiLFxuXHRcdFx0XHRcIuKIkVwiOiBcIlN1bW1lIHZvblwiLFxuXHRcdFx0XHRcIsKkXCI6IFwiV2FlaHJ1bmdcIlxuXHRcdFx0fSxcblx0XHRcdFwiZHZcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwia29sdW51bGFhXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibG9hYmlcIixcblx0XHRcdFx0XCImXCI6IFwiYWFpXCIsXG5cdFx0XHRcdFwifFwiOiBcIm5vb25lZVwiLFxuXHRcdFx0XHRcIjxcIjogXCJhaCB2dXJlIGt1ZGFcIixcblx0XHRcdFx0XCI+XCI6IFwiYWggdnVyZSBib2R1XCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwianVtdWxhXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJmYWlzYWFcIlxuXHRcdFx0fSxcblx0XHRcdFwiZW5cIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pdHlcIixcblx0XHRcdFx0XCLimaVcIjogXCJsb3ZlXCIsXG5cdFx0XHRcdFwiJlwiOiBcImFuZFwiLFxuXHRcdFx0XHRcInxcIjogXCJvclwiLFxuXHRcdFx0XHRcIjxcIjogXCJsZXNzIHRoYW5cIixcblx0XHRcdFx0XCI+XCI6IFwiZ3JlYXRlciB0aGFuXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJjdXJyZW5jeVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJlc1wiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJpbmZpbml0b1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImFtb3JcIixcblx0XHRcdFx0XCImXCI6IFwieVwiLFxuXHRcdFx0XHRcInxcIjogXCJ1XCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1lbm9zIHF1ZVwiLFxuXHRcdFx0XHRcIj5cIjogXCJtYXMgcXVlXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtYSBkZSBsb3NcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vbmVkYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJmYVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJiaS1uYWhheWF0XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiZXNoZ2hcIixcblx0XHRcdFx0XCImXCI6IFwidmFcIixcblx0XHRcdFx0XCJ8XCI6IFwieWFcIixcblx0XHRcdFx0XCI8XCI6IFwia2FtdGFyLWF6XCIsXG5cdFx0XHRcdFwiPlwiOiBcImJpc2h0YXItYXpcIixcblx0XHRcdFx0XCLiiJFcIjogXCJtYWptb29lXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWhlZFwiXG5cdFx0XHR9LFxuXHRcdFx0XCJmaVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJhYXJldHRvbXl5c1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcInJha2thdXNcIixcblx0XHRcdFx0XCImXCI6IFwiamFcIixcblx0XHRcdFx0XCJ8XCI6IFwidGFpXCIsXG5cdFx0XHRcdFwiPFwiOiBcInBpZW5lbXBpIGt1aW5cIixcblx0XHRcdFx0XCI+XCI6IFwic3V1cmVtcGkga3VpblwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dXR0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJmclwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJpbmZpbmltZW50XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiQW1vdXJcIixcblx0XHRcdFx0XCImXCI6IFwiZXRcIixcblx0XHRcdFx0XCJ8XCI6IFwib3VcIixcblx0XHRcdFx0XCI8XCI6IFwibW9pbnMgcXVlXCIsXG5cdFx0XHRcdFwiPlwiOiBcInN1cGVyaWV1cmUgYVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInNvbW1lIGRlc1wiLFxuXHRcdFx0XHRcIsKkXCI6IFwibW9ubmFpZVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJnZVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJ1c2FzcnVsb2JhXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwic2lxdmFydWxpXCIsXG5cdFx0XHRcdFwiJlwiOiBcImRhXCIsXG5cdFx0XHRcdFwifFwiOiBcImFuXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm5ha2xlYmlcIixcblx0XHRcdFx0XCI+XCI6IFwibWV0aVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcImphbWlcIixcblx0XHRcdFx0XCLCpFwiOiBcInZhbHV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJnclwiOiB7fSxcblx0XHRcdFwiaHVcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwidmVndGVsZW5cIixcblx0XHRcdFx0XCLimaVcIjogXCJzemVyZWxlbVwiLFxuXHRcdFx0XHRcIiZcIjogXCJlc1wiLFxuXHRcdFx0XHRcInxcIjogXCJ2YWd5XCIsXG5cdFx0XHRcdFwiPFwiOiBcImtpc2ViYiBtaW50XCIsXG5cdFx0XHRcdFwiPlwiOiBcIm5hZ3lvYmIgbWludFwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN6dW1tYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwicGVuem5lbVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJpdFwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJpbmZpbml0b1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImFtb3JlXCIsXG5cdFx0XHRcdFwiJlwiOiBcImVcIixcblx0XHRcdFx0XCJ8XCI6IFwib1wiLFxuXHRcdFx0XHRcIjxcIjogXCJtaW5vcmUgZGlcIixcblx0XHRcdFx0XCI+XCI6IFwibWFnZ2lvcmUgZGlcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzb21tYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwibW9uZXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcImx0XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImJlZ2FseWJlXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibWVpbGVcIixcblx0XHRcdFx0XCImXCI6IFwiaXJcIixcblx0XHRcdFx0XCJ8XCI6IFwiYXJcIixcblx0XHRcdFx0XCI8XCI6IFwibWF6aWF1IG5laVwiLFxuXHRcdFx0XHRcIj5cIjogXCJkYXVnaWF1IG5laVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bWFcIixcblx0XHRcdFx0XCLCpFwiOiBcInZhbGl1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwibHZcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYmV6Z2FsaWJhXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibWlsZXN0aWJhXCIsXG5cdFx0XHRcdFwiJlwiOiBcInVuXCIsXG5cdFx0XHRcdFwifFwiOiBcInZhaVwiLFxuXHRcdFx0XHRcIjxcIjogXCJtYXphayBuZWthXCIsXG5cdFx0XHRcdFwiPlwiOiBcImxpZWxha3MgbmVrYVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwibXlcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImt3YWhraHlhZXRcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJhc2FvbmFzbWVcIixcblx0XHRcdFx0XCLimaVcIjogXCJha2h5YWl0XCIsXG5cdFx0XHRcdFwiJlwiOiBcIm5oaW5cIixcblx0XHRcdFx0XCJ8XCI6IFwidGhvXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm5nZXRoYXdcIixcblx0XHRcdFx0XCI+XCI6IFwia3lpdGhhd1wiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInBhdW5nbGRcIixcblx0XHRcdFx0XCLCpFwiOiBcIm5nd2VreWVcIlxuXHRcdFx0fSxcblx0XHRcdFwibWtcIjoge30sXG5cdFx0XHRcIm5sXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcIm9uZWluZGlnXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibGllZmRlXCIsXG5cdFx0XHRcdFwiJlwiOiBcImVuXCIsXG5cdFx0XHRcdFwifFwiOiBcIm9mXCIsXG5cdFx0XHRcdFwiPFwiOiBcImtsZWluZXIgZGFuXCIsXG5cdFx0XHRcdFwiPlwiOiBcImdyb3RlciBkYW5cIixcblx0XHRcdFx0XCLiiJFcIjogXCJzb21cIixcblx0XHRcdFx0XCLCpFwiOiBcInZhbHV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJwbFwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJuaWVza29uY3pvbm9zY1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIm1pbG9zY1wiLFxuXHRcdFx0XHRcIiZcIjogXCJpXCIsXG5cdFx0XHRcdFwifFwiOiBcImx1YlwiLFxuXHRcdFx0XHRcIjxcIjogXCJtbmllanN6ZSBuaXpcIixcblx0XHRcdFx0XCI+XCI6IFwid2lla3N6ZSBuaXpcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ3YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwicHRcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pdG9cIixcblx0XHRcdFx0XCLimaVcIjogXCJhbW9yXCIsXG5cdFx0XHRcdFwiJlwiOiBcImVcIixcblx0XHRcdFx0XCJ8XCI6IFwib3VcIixcblx0XHRcdFx0XCI8XCI6IFwibWVub3IgcXVlXCIsXG5cdFx0XHRcdFwiPlwiOiBcIm1haW9yIHF1ZVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInNvbWFcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vZWRhXCJcblx0XHRcdH0sXG5cdFx0XHRcInJvXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImluZmluaXRcIixcblx0XHRcdFx0XCLimaVcIjogXCJkcmFnb3N0ZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJzaVwiLFxuXHRcdFx0XHRcInxcIjogXCJzYXVcIixcblx0XHRcdFx0XCI8XCI6IFwibWFpIG1pYyBjYVwiLFxuXHRcdFx0XHRcIj5cIjogXCJtYWkgbWFyZSBjYVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bWFcIixcblx0XHRcdFx0XCLCpFwiOiBcInZhbHV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJydVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJiZXNrb25lY2hub1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImx1Ym92XCIsXG5cdFx0XHRcdFwiJlwiOiBcImlcIixcblx0XHRcdFx0XCJ8XCI6IFwiaWxpXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1lbnNoZVwiLFxuXHRcdFx0XHRcIj5cIjogXCJib2xzaGVcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1tYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFsanV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJza1wiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJuZWtvbmVjbm9cIixcblx0XHRcdFx0XCLimaVcIjogXCJsYXNrYVwiLFxuXHRcdFx0XHRcIiZcIjogXCJhXCIsXG5cdFx0XHRcdFwifFwiOiBcImFsZWJvXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1lbmVqIGFrb1wiLFxuXHRcdFx0XHRcIj5cIjogXCJ2aWFjIGFrb1wiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1Y2V0XCIsXG5cdFx0XHRcdFwiwqRcIjogXCJtZW5hXCJcblx0XHRcdH0sXG5cdFx0XHRcInNyXCI6IHt9LFxuXHRcdFx0XCJ0clwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJzb25zdXpsdWtcIixcblx0XHRcdFx0XCLimaVcIjogXCJhc2tcIixcblx0XHRcdFx0XCImXCI6IFwidmVcIixcblx0XHRcdFx0XCJ8XCI6IFwidmV5YVwiLFxuXHRcdFx0XHRcIjxcIjogXCJrdWN1a3R1clwiLFxuXHRcdFx0XHRcIj5cIjogXCJidXl1a3R1clwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInRvcGxhbVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwicGFyYSBiaXJpbWlcIlxuXHRcdFx0fSxcblx0XHRcdFwidWtcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYmV6a2luZWNobmlzdFwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImx1Ym92XCIsXG5cdFx0XHRcdFwiJlwiOiBcImlcIixcblx0XHRcdFx0XCJ8XCI6IFwiYWJvXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1lbnNoZVwiLFxuXHRcdFx0XHRcIj5cIjogXCJiaWxzaGVcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWxqdXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcInZuXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcInZvIGN1Y1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcInlldVwiLFxuXHRcdFx0XHRcIiZcIjogXCJ2YVwiLFxuXHRcdFx0XHRcInxcIjogXCJob2FjXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm5obyBob25cIixcblx0XHRcdFx0XCI+XCI6IFwibG9uIGhvblwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInRvbmdcIixcblx0XHRcdFx0XCLCpFwiOiBcInRpZW4gdGVcIlxuXHRcdFx0fVxuXHRcdH07XG5cdFx0dmFyIHVyaWNDaGFycyA9IFtcblx0XHRcdFwiO1wiLFxuXHRcdFx0XCI/XCIsXG5cdFx0XHRcIjpcIixcblx0XHRcdFwiQFwiLFxuXHRcdFx0XCImXCIsXG5cdFx0XHRcIj1cIixcblx0XHRcdFwiK1wiLFxuXHRcdFx0XCIkXCIsXG5cdFx0XHRcIixcIixcblx0XHRcdFwiL1wiXG5cdFx0XS5qb2luKFwiXCIpO1xuXHRcdHZhciB1cmljTm9TbGFzaENoYXJzID0gW1xuXHRcdFx0XCI7XCIsXG5cdFx0XHRcIj9cIixcblx0XHRcdFwiOlwiLFxuXHRcdFx0XCJAXCIsXG5cdFx0XHRcIiZcIixcblx0XHRcdFwiPVwiLFxuXHRcdFx0XCIrXCIsXG5cdFx0XHRcIiRcIixcblx0XHRcdFwiLFwiXG5cdFx0XS5qb2luKFwiXCIpO1xuXHRcdHZhciBtYXJrQ2hhcnMgPSBbXG5cdFx0XHRcIi5cIixcblx0XHRcdFwiIVwiLFxuXHRcdFx0XCJ+XCIsXG5cdFx0XHRcIipcIixcblx0XHRcdFwiJ1wiLFxuXHRcdFx0XCIoXCIsXG5cdFx0XHRcIilcIlxuXHRcdF0uam9pbihcIlwiKTtcblx0XHQvKipcblx0XHQqIGdldFNsdWdcblx0XHQqIEBwYXJhbSAge3N0cmluZ30gaW5wdXQgaW5wdXQgc3RyaW5nXG5cdFx0KiBAcGFyYW0gIHtvYmplY3R8c3RyaW5nfSBvcHRzIGNvbmZpZyBvYmplY3Qgb3Igc2VwYXJhdG9yIHN0cmluZy9jaGFyXG5cdFx0KiBAYXBpICAgIHB1YmxpY1xuXHRcdCogQHJldHVybiB7c3RyaW5nfSAgc2x1Z2dpZmllZCBzdHJpbmdcblx0XHQqL1xuXHRcdHZhciBnZXRTbHVnID0gZnVuY3Rpb24gZ2V0U2x1ZyhpbnB1dCwgb3B0cykge1xuXHRcdFx0dmFyIHNlcGFyYXRvciA9IFwiLVwiO1xuXHRcdFx0dmFyIHJlc3VsdCA9IFwiXCI7XG5cdFx0XHR2YXIgZGlhdHJpY1N0cmluZyA9IFwiXCI7XG5cdFx0XHR2YXIgY29udmVydFN5bWJvbHMgPSB0cnVlO1xuXHRcdFx0dmFyIGN1c3RvbVJlcGxhY2VtZW50cyA9IHt9O1xuXHRcdFx0dmFyIG1haW50YWluQ2FzZTtcblx0XHRcdHZhciB0aXRsZUNhc2U7XG5cdFx0XHR2YXIgdHJ1bmNhdGU7XG5cdFx0XHR2YXIgdXJpY0ZsYWc7XG5cdFx0XHR2YXIgdXJpY05vU2xhc2hGbGFnO1xuXHRcdFx0dmFyIG1hcmtGbGFnO1xuXHRcdFx0dmFyIHN5bWJvbDtcblx0XHRcdHZhciBsYW5nQ2hhcjtcblx0XHRcdHZhciBsdWNreTtcblx0XHRcdHZhciBpO1xuXHRcdFx0dmFyIGNoO1xuXHRcdFx0dmFyIGw7XG5cdFx0XHR2YXIgbGFzdENoYXJXYXNTeW1ib2w7XG5cdFx0XHR2YXIgbGFzdENoYXJXYXNEaWF0cmljO1xuXHRcdFx0dmFyIGFsbG93ZWRDaGFycyA9IFwiXCI7XG5cdFx0XHRpZiAodHlwZW9mIGlucHV0ICE9PSBcInN0cmluZ1wiKSByZXR1cm4gXCJcIjtcblx0XHRcdGlmICh0eXBlb2Ygb3B0cyA9PT0gXCJzdHJpbmdcIikgc2VwYXJhdG9yID0gb3B0cztcblx0XHRcdHN5bWJvbCA9IHN5bWJvbE1hcC5lbjtcblx0XHRcdGxhbmdDaGFyID0gbGFuZ0NoYXJNYXAuZW47XG5cdFx0XHRpZiAodHlwZW9mIG9wdHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHRcdFx0bWFpbnRhaW5DYXNlID0gb3B0cy5tYWludGFpbkNhc2UgfHwgZmFsc2U7XG5cdFx0XHRcdGN1c3RvbVJlcGxhY2VtZW50cyA9IG9wdHMuY3VzdG9tICYmIHR5cGVvZiBvcHRzLmN1c3RvbSA9PT0gXCJvYmplY3RcIiA/IG9wdHMuY3VzdG9tIDogY3VzdG9tUmVwbGFjZW1lbnRzO1xuXHRcdFx0XHR0cnVuY2F0ZSA9ICtvcHRzLnRydW5jYXRlID4gMSAmJiBvcHRzLnRydW5jYXRlIHx8IGZhbHNlO1xuXHRcdFx0XHR1cmljRmxhZyA9IG9wdHMudXJpYyB8fCBmYWxzZTtcblx0XHRcdFx0dXJpY05vU2xhc2hGbGFnID0gb3B0cy51cmljTm9TbGFzaCB8fCBmYWxzZTtcblx0XHRcdFx0bWFya0ZsYWcgPSBvcHRzLm1hcmsgfHwgZmFsc2U7XG5cdFx0XHRcdGNvbnZlcnRTeW1ib2xzID0gb3B0cy5zeW1ib2xzID09PSBmYWxzZSB8fCBvcHRzLmxhbmcgPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xuXHRcdFx0XHRzZXBhcmF0b3IgPSBvcHRzLnNlcGFyYXRvciB8fCBzZXBhcmF0b3I7XG5cdFx0XHRcdGlmICh1cmljRmxhZykgYWxsb3dlZENoYXJzICs9IHVyaWNDaGFycztcblx0XHRcdFx0aWYgKHVyaWNOb1NsYXNoRmxhZykgYWxsb3dlZENoYXJzICs9IHVyaWNOb1NsYXNoQ2hhcnM7XG5cdFx0XHRcdGlmIChtYXJrRmxhZykgYWxsb3dlZENoYXJzICs9IG1hcmtDaGFycztcblx0XHRcdFx0c3ltYm9sID0gb3B0cy5sYW5nICYmIHN5bWJvbE1hcFtvcHRzLmxhbmddICYmIGNvbnZlcnRTeW1ib2xzID8gc3ltYm9sTWFwW29wdHMubGFuZ10gOiBjb252ZXJ0U3ltYm9scyA/IHN5bWJvbE1hcC5lbiA6IHt9O1xuXHRcdFx0XHRsYW5nQ2hhciA9IG9wdHMubGFuZyAmJiBsYW5nQ2hhck1hcFtvcHRzLmxhbmddID8gbGFuZ0NoYXJNYXBbb3B0cy5sYW5nXSA6IG9wdHMubGFuZyA9PT0gZmFsc2UgfHwgb3B0cy5sYW5nID09PSB0cnVlID8ge30gOiBsYW5nQ2hhck1hcC5lbjtcblx0XHRcdFx0aWYgKG9wdHMudGl0bGVDYXNlICYmIHR5cGVvZiBvcHRzLnRpdGxlQ2FzZS5sZW5ndGggPT09IFwibnVtYmVyXCIgJiYgQXJyYXkucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob3B0cy50aXRsZUNhc2UpKSB7XG5cdFx0XHRcdFx0b3B0cy50aXRsZUNhc2UuZm9yRWFjaChmdW5jdGlvbih2KSB7XG5cdFx0XHRcdFx0XHRjdXN0b21SZXBsYWNlbWVudHNbdiArIFwiXCJdID0gdiArIFwiXCI7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0dGl0bGVDYXNlID0gdHJ1ZTtcblx0XHRcdFx0fSBlbHNlIHRpdGxlQ2FzZSA9ICEhb3B0cy50aXRsZUNhc2U7XG5cdFx0XHRcdGlmIChvcHRzLmN1c3RvbSAmJiB0eXBlb2Ygb3B0cy5jdXN0b20ubGVuZ3RoID09PSBcIm51bWJlclwiICYmIEFycmF5LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9wdHMuY3VzdG9tKSkgb3B0cy5jdXN0b20uZm9yRWFjaChmdW5jdGlvbih2KSB7XG5cdFx0XHRcdFx0Y3VzdG9tUmVwbGFjZW1lbnRzW3YgKyBcIlwiXSA9IHYgKyBcIlwiO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0T2JqZWN0LmtleXMoY3VzdG9tUmVwbGFjZW1lbnRzKS5mb3JFYWNoKGZ1bmN0aW9uKHYpIHtcblx0XHRcdFx0XHR2YXIgcjtcblx0XHRcdFx0XHRpZiAodi5sZW5ndGggPiAxKSByID0gbmV3IFJlZ0V4cChcIlxcXFxiXCIgKyBlc2NhcGVDaGFycyh2KSArIFwiXFxcXGJcIiwgXCJnaVwiKTtcblx0XHRcdFx0XHRlbHNlIHIgPSBuZXcgUmVnRXhwKGVzY2FwZUNoYXJzKHYpLCBcImdpXCIpO1xuXHRcdFx0XHRcdGlucHV0ID0gaW5wdXQucmVwbGFjZShyLCBjdXN0b21SZXBsYWNlbWVudHNbdl0pO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0Zm9yIChjaCBpbiBjdXN0b21SZXBsYWNlbWVudHMpIGFsbG93ZWRDaGFycyArPSBjaDtcblx0XHRcdH1cblx0XHRcdGFsbG93ZWRDaGFycyArPSBzZXBhcmF0b3I7XG5cdFx0XHRhbGxvd2VkQ2hhcnMgPSBlc2NhcGVDaGFycyhhbGxvd2VkQ2hhcnMpO1xuXHRcdFx0aW5wdXQgPSBpbnB1dC5yZXBsYWNlKC8oXlxccyt8XFxzKyQpL2csIFwiXCIpO1xuXHRcdFx0bGFzdENoYXJXYXNTeW1ib2wgPSBmYWxzZTtcblx0XHRcdGxhc3RDaGFyV2FzRGlhdHJpYyA9IGZhbHNlO1xuXHRcdFx0Zm9yIChpID0gMCwgbCA9IGlucHV0Lmxlbmd0aDsgaSA8IGw7IGkrKykge1xuXHRcdFx0XHRjaCA9IGlucHV0W2ldO1xuXHRcdFx0XHRpZiAoaXNSZXBsYWNlZEN1c3RvbUNoYXIoY2gsIGN1c3RvbVJlcGxhY2VtZW50cykpIGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRcdGVsc2UgaWYgKGxhbmdDaGFyW2NoXSkge1xuXHRcdFx0XHRcdGNoID0gbGFzdENoYXJXYXNTeW1ib2wgJiYgbGFuZ0NoYXJbY2hdLm1hdGNoKC9bQS1aYS16MC05XS8pID8gXCIgXCIgKyBsYW5nQ2hhcltjaF0gOiBsYW5nQ2hhcltjaF07XG5cdFx0XHRcdFx0bGFzdENoYXJXYXNTeW1ib2wgPSBmYWxzZTtcblx0XHRcdFx0fSBlbHNlIGlmIChjaCBpbiBjaGFyTWFwKSB7XG5cdFx0XHRcdFx0aWYgKGkgKyAxIDwgbCAmJiBsb29rQWhlYWRDaGFyQXJyYXkuaW5kZXhPZihpbnB1dFtpICsgMV0pID49IDApIHtcblx0XHRcdFx0XHRcdGRpYXRyaWNTdHJpbmcgKz0gY2g7XG5cdFx0XHRcdFx0XHRjaCA9IFwiXCI7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChsYXN0Q2hhcldhc0RpYXRyaWMgPT09IHRydWUpIHtcblx0XHRcdFx0XHRcdGNoID0gZGlhdHJpY01hcFtkaWF0cmljU3RyaW5nXSArIGNoYXJNYXBbY2hdO1xuXHRcdFx0XHRcdFx0ZGlhdHJpY1N0cmluZyA9IFwiXCI7XG5cdFx0XHRcdFx0fSBlbHNlIGNoID0gbGFzdENoYXJXYXNTeW1ib2wgJiYgY2hhck1hcFtjaF0ubWF0Y2goL1tBLVphLXowLTldLykgPyBcIiBcIiArIGNoYXJNYXBbY2hdIDogY2hhck1hcFtjaF07XG5cdFx0XHRcdFx0bGFzdENoYXJXYXNTeW1ib2wgPSBmYWxzZTtcblx0XHRcdFx0XHRsYXN0Q2hhcldhc0RpYXRyaWMgPSBmYWxzZTtcblx0XHRcdFx0fSBlbHNlIGlmIChjaCBpbiBkaWF0cmljTWFwKSB7XG5cdFx0XHRcdFx0ZGlhdHJpY1N0cmluZyArPSBjaDtcblx0XHRcdFx0XHRjaCA9IFwiXCI7XG5cdFx0XHRcdFx0aWYgKGkgPT09IGwgLSAxKSBjaCA9IGRpYXRyaWNNYXBbZGlhdHJpY1N0cmluZ107XG5cdFx0XHRcdFx0bGFzdENoYXJXYXNEaWF0cmljID0gdHJ1ZTtcblx0XHRcdFx0fSBlbHNlIGlmIChzeW1ib2xbY2hdICYmICEodXJpY0ZsYWcgJiYgdXJpY0NoYXJzLmluZGV4T2YoY2gpICE9PSAtMSkgJiYgISh1cmljTm9TbGFzaEZsYWcgJiYgdXJpY05vU2xhc2hDaGFycy5pbmRleE9mKGNoKSAhPT0gLTEpKSB7XG5cdFx0XHRcdFx0Y2ggPSBsYXN0Q2hhcldhc1N5bWJvbCB8fCByZXN1bHQuc3Vic3RyKC0xKS5tYXRjaCgvW0EtWmEtejAtOV0vKSA/IHNlcGFyYXRvciArIHN5bWJvbFtjaF0gOiBzeW1ib2xbY2hdO1xuXHRcdFx0XHRcdGNoICs9IGlucHV0W2kgKyAxXSAhPT0gdm9pZCAwICYmIGlucHV0W2kgKyAxXS5tYXRjaCgvW0EtWmEtejAtOV0vKSA/IHNlcGFyYXRvciA6IFwiXCI7XG5cdFx0XHRcdFx0bGFzdENoYXJXYXNTeW1ib2wgPSB0cnVlO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGlmIChsYXN0Q2hhcldhc0RpYXRyaWMgPT09IHRydWUpIHtcblx0XHRcdFx0XHRcdGNoID0gZGlhdHJpY01hcFtkaWF0cmljU3RyaW5nXSArIGNoO1xuXHRcdFx0XHRcdFx0ZGlhdHJpY1N0cmluZyA9IFwiXCI7XG5cdFx0XHRcdFx0XHRsYXN0Q2hhcldhc0RpYXRyaWMgPSBmYWxzZTtcblx0XHRcdFx0XHR9IGVsc2UgaWYgKGxhc3RDaGFyV2FzU3ltYm9sICYmICgvW0EtWmEtejAtOV0vLnRlc3QoY2gpIHx8IHJlc3VsdC5zdWJzdHIoLTEpLm1hdGNoKC9BLVphLXowLTldLykpKSBjaCA9IFwiIFwiICsgY2g7XG5cdFx0XHRcdFx0bGFzdENoYXJXYXNTeW1ib2wgPSBmYWxzZTtcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXN1bHQgKz0gY2gucmVwbGFjZShuZXcgUmVnRXhwKFwiW15cXFxcd1xcXFxzXCIgKyBhbGxvd2VkQ2hhcnMgKyBcIl8tXVwiLCBcImdcIiksIHNlcGFyYXRvcik7XG5cdFx0XHR9XG5cdFx0XHRpZiAodGl0bGVDYXNlKSByZXN1bHQgPSByZXN1bHQucmVwbGFjZSgvKFxcdykoXFxTKikvZywgZnVuY3Rpb24oXywgaSwgcikge1xuXHRcdFx0XHR2YXIgaiA9IGkudG9VcHBlckNhc2UoKSArIChyICE9PSBudWxsID8gciA6IFwiXCIpO1xuXHRcdFx0XHRyZXR1cm4gT2JqZWN0LmtleXMoY3VzdG9tUmVwbGFjZW1lbnRzKS5pbmRleE9mKGoudG9Mb3dlckNhc2UoKSkgPCAwID8gaiA6IGoudG9Mb3dlckNhc2UoKTtcblx0XHRcdH0pO1xuXHRcdFx0cmVzdWx0ID0gcmVzdWx0LnJlcGxhY2UoL1xccysvZywgc2VwYXJhdG9yKS5yZXBsYWNlKG5ldyBSZWdFeHAoXCJcXFxcXCIgKyBzZXBhcmF0b3IgKyBcIitcIiwgXCJnXCIpLCBzZXBhcmF0b3IpLnJlcGxhY2UobmV3IFJlZ0V4cChcIiheXFxcXFwiICsgc2VwYXJhdG9yICsgXCIrfFxcXFxcIiArIHNlcGFyYXRvciArIFwiKyQpXCIsIFwiZ1wiKSwgXCJcIik7XG5cdFx0XHRpZiAodHJ1bmNhdGUgJiYgcmVzdWx0Lmxlbmd0aCA+IHRydW5jYXRlKSB7XG5cdFx0XHRcdGx1Y2t5ID0gcmVzdWx0LmNoYXJBdCh0cnVuY2F0ZSkgPT09IHNlcGFyYXRvcjtcblx0XHRcdFx0cmVzdWx0ID0gcmVzdWx0LnNsaWNlKDAsIHRydW5jYXRlKTtcblx0XHRcdFx0aWYgKCFsdWNreSkgcmVzdWx0ID0gcmVzdWx0LnNsaWNlKDAsIHJlc3VsdC5sYXN0SW5kZXhPZihzZXBhcmF0b3IpKTtcblx0XHRcdH1cblx0XHRcdGlmICghbWFpbnRhaW5DYXNlICYmICF0aXRsZUNhc2UpIHJlc3VsdCA9IHJlc3VsdC50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9O1xuXHRcdC8qKlxuXHRcdCogY3JlYXRlU2x1ZyBjdXJyaWVkKG9wdHMpKGlucHV0KVxuXHRcdCogQHBhcmFtICAge29iamVjdHxzdHJpbmd9IG9wdHMgY29uZmlnIG9iamVjdCBvciBpbnB1dCBzdHJpbmdcblx0XHQqIEByZXR1cm4gIHtGdW5jdGlvbn0gZnVuY3Rpb24gZ2V0U2x1Z1dpdGhDb25maWcoKVxuXHRcdCoqL1xuXHRcdHZhciBjcmVhdGVTbHVnID0gZnVuY3Rpb24gY3JlYXRlU2x1ZyhvcHRzKSB7XG5cdFx0XHQvKipcblx0XHRcdCogZ2V0U2x1Z1dpdGhDb25maWdcblx0XHRcdCogQHBhcmFtICAge3N0cmluZ30gaW5wdXQgc3RyaW5nXG5cdFx0XHQqIEByZXR1cm4gIHtzdHJpbmd9IHNsdWcgc3RyaW5nXG5cdFx0XHQqL1xuXHRcdFx0cmV0dXJuIGZ1bmN0aW9uIGdldFNsdWdXaXRoQ29uZmlnKGlucHV0KSB7XG5cdFx0XHRcdHJldHVybiBnZXRTbHVnKGlucHV0LCBvcHRzKTtcblx0XHRcdH07XG5cdFx0fTtcblx0XHQvKipcblx0XHQqIGVzY2FwZSBDaGFyc1xuXHRcdCogQHBhcmFtICAge3N0cmluZ30gaW5wdXQgc3RyaW5nXG5cdFx0Ki9cblx0XHR2YXIgZXNjYXBlQ2hhcnMgPSBmdW5jdGlvbiBlc2NhcGVDaGFycyhpbnB1dCkge1xuXHRcdFx0cmV0dXJuIGlucHV0LnJlcGxhY2UoL1stXFxcXF4kKis/LigpfFtcXF17fVxcL10vZywgXCJcXFxcJCZcIik7XG5cdFx0fTtcblx0XHQvKipcblx0XHQqIGNoZWNrIGlmIHRoZSBjaGFyIGlzIGFuIGFscmVhZHkgY29udmVydGVkIGNoYXIgZnJvbSBjdXN0b20gbGlzdFxuXHRcdCogQHBhcmFtICAge2NoYXJ9IGNoIGNoYXJhY3RlciB0byBjaGVja1xuXHRcdCogQHBhcmFtICAge29iamVjdH0gY3VzdG9tUmVwbGFjZW1lbnRzIGN1c3RvbSB0cmFuc2xhdGlvbiBtYXBcblx0XHQqL1xuXHRcdHZhciBpc1JlcGxhY2VkQ3VzdG9tQ2hhciA9IGZ1bmN0aW9uKGNoLCBjdXN0b21SZXBsYWNlbWVudHMpIHtcblx0XHRcdGZvciAodmFyIGMgaW4gY3VzdG9tUmVwbGFjZW1lbnRzKSBpZiAoY3VzdG9tUmVwbGFjZW1lbnRzW2NdID09PSBjaCkgcmV0dXJuIHRydWU7XG5cdFx0fTtcblx0XHRpZiAodHlwZW9mIG1vZHVsZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBtb2R1bGUuZXhwb3J0cykge1xuXHRcdFx0bW9kdWxlLmV4cG9ydHMgPSBnZXRTbHVnO1xuXHRcdFx0bW9kdWxlLmV4cG9ydHMuY3JlYXRlU2x1ZyA9IGNyZWF0ZVNsdWc7XG5cdFx0fSBlbHNlIGlmICh0eXBlb2YgZGVmaW5lICE9PSBcInVuZGVmaW5lZFwiICYmIGRlZmluZS5hbWQpIGRlZmluZShbXSwgZnVuY3Rpb24oKSB7XG5cdFx0XHRyZXR1cm4gZ2V0U2x1Zztcblx0XHR9KTtcblx0XHRlbHNlIHRyeSB7XG5cdFx0XHRpZiAocm9vdC5nZXRTbHVnIHx8IHJvb3QuY3JlYXRlU2x1ZykgdGhyb3cgXCJzcGVha2luZ3VybDogZ2xvYmFscyBleGlzdHMgLyhnZXRTbHVnfGNyZWF0ZVNsdWcpL1wiO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdHJvb3QuZ2V0U2x1ZyA9IGdldFNsdWc7XG5cdFx0XHRcdHJvb3QuY3JlYXRlU2x1ZyA9IGNyZWF0ZVNsdWc7XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoZSkge31cblx0fSkoZXhwb3J0cyk7XG59KSk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9hcHAvaW5kZXgudHNcbnZhciBpbXBvcnRfc3BlYWtpbmd1cmwgPSAvKiBAX19QVVJFX18gKi8gX190b0VTTSgoLyogQF9fUFVSRV9fICovIF9fY29tbW9uSlNNaW4oKChleHBvcnRzLCBtb2R1bGUpID0+IHtcblx0bW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlX3NwZWFraW5ndXJsJDEoKTtcbn0pKSkoKSwgMSk7XG5jb25zdCBhcHBSZWNvcmRJbmZvID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9JTkZPX18gPz89IHtcblx0aWQ6IDAsXG5cdGFwcElkczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKVxufTtcbmZ1bmN0aW9uIGdldEFwcFJlY29yZE5hbWUoYXBwLCBmYWxsYmFja05hbWUpIHtcblx0cmV0dXJuIGFwcD8uX2NvbXBvbmVudD8ubmFtZSB8fCBgQXBwICR7ZmFsbGJhY2tOYW1lfWA7XG59XG5mdW5jdGlvbiBnZXRBcHBSb290SW5zdGFuY2UoYXBwKSB7XG5cdGlmIChhcHAuX2luc3RhbmNlKSByZXR1cm4gYXBwLl9pbnN0YW5jZTtcblx0ZWxzZSBpZiAoYXBwLl9jb250YWluZXI/Ll92bm9kZT8uY29tcG9uZW50KSByZXR1cm4gYXBwLl9jb250YWluZXI/Ll92bm9kZT8uY29tcG9uZW50O1xufVxuZnVuY3Rpb24gcmVtb3ZlQXBwUmVjb3JkSWQoYXBwKSB7XG5cdGNvbnN0IGlkID0gYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9JRF9fO1xuXHRpZiAoaWQgIT0gbnVsbCkge1xuXHRcdGFwcFJlY29yZEluZm8uYXBwSWRzLmRlbGV0ZShpZCk7XG5cdFx0YXBwUmVjb3JkSW5mby5pZC0tO1xuXHR9XG59XG5mdW5jdGlvbiBnZXRBcHBSZWNvcmRJZChhcHAsIGRlZmF1bHRJZCkge1xuXHRpZiAoYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9JRF9fICE9IG51bGwpIHJldHVybiBhcHAuX19WVUVfREVWVE9PTFNfTkVYVF9BUFBfUkVDT1JEX0lEX187XG5cdGxldCBpZCA9IGRlZmF1bHRJZCA/PyAoYXBwUmVjb3JkSW5mby5pZCsrKS50b1N0cmluZygpO1xuXHRpZiAoZGVmYXVsdElkICYmIGFwcFJlY29yZEluZm8uYXBwSWRzLmhhcyhpZCkpIHtcblx0XHRsZXQgY291bnQgPSAxO1xuXHRcdHdoaWxlIChhcHBSZWNvcmRJbmZvLmFwcElkcy5oYXMoYCR7ZGVmYXVsdElkfV8ke2NvdW50fWApKSBjb3VudCsrO1xuXHRcdGlkID0gYCR7ZGVmYXVsdElkfV8ke2NvdW50fWA7XG5cdH1cblx0YXBwUmVjb3JkSW5mby5hcHBJZHMuYWRkKGlkKTtcblx0YXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9JRF9fID0gaWQ7XG5cdHJldHVybiBpZDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUFwcFJlY29yZChhcHAsIHR5cGVzKSB7XG5cdGNvbnN0IHJvb3RJbnN0YW5jZSA9IGdldEFwcFJvb3RJbnN0YW5jZShhcHApO1xuXHRpZiAocm9vdEluc3RhbmNlKSB7XG5cdFx0YXBwUmVjb3JkSW5mby5pZCsrO1xuXHRcdGNvbnN0IG5hbWUgPSBnZXRBcHBSZWNvcmROYW1lKGFwcCwgYXBwUmVjb3JkSW5mby5pZC50b1N0cmluZygpKTtcblx0XHRjb25zdCBpZCA9IGdldEFwcFJlY29yZElkKGFwcCwgKDAsIGltcG9ydF9zcGVha2luZ3VybC5kZWZhdWx0KShuYW1lKSk7XG5cdFx0Y29uc3QgW2VsXSA9IGdldFJvb3RFbGVtZW50c0Zyb21Db21wb25lbnRJbnN0YW5jZShyb290SW5zdGFuY2UpO1xuXHRcdGNvbnN0IHJlY29yZCA9IHtcblx0XHRcdGlkLFxuXHRcdFx0bmFtZSxcblx0XHRcdHR5cGVzLFxuXHRcdFx0aW5zdGFuY2VNYXA6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksXG5cdFx0XHRwZXJmR3JvdXBJZHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksXG5cdFx0XHRyb290SW5zdGFuY2UsXG5cdFx0XHRpZnJhbWU6IGlzQnJvd3NlciAmJiBkb2N1bWVudCAhPT0gZWw/Lm93bmVyRG9jdW1lbnQgPyBlbD8ub3duZXJEb2N1bWVudD8ubG9jYXRpb24/LnBhdGhuYW1lIDogdm9pZCAwXG5cdFx0fTtcblx0XHRhcHAuX19WVUVfREVWVE9PTFNfTkVYVF9BUFBfUkVDT1JEX18gPSByZWNvcmQ7XG5cdFx0Y29uc3Qgcm9vdElkID0gYCR7cmVjb3JkLmlkfTpyb290YDtcblx0XHRyZWNvcmQuaW5zdGFuY2VNYXAuc2V0KHJvb3RJZCwgcmVjb3JkLnJvb3RJbnN0YW5jZSk7XG5cdFx0cmVjb3JkLnJvb3RJbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fID0gcm9vdElkO1xuXHRcdHJldHVybiByZWNvcmQ7XG5cdH0gZWxzZSByZXR1cm4ge307XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9pZnJhbWUvaW5kZXgudHNcbmZ1bmN0aW9uIGRldGVjdElmcmFtZUFwcCh0YXJnZXQsIGluSWZyYW1lID0gZmFsc2UpIHtcblx0aWYgKGluSWZyYW1lKSB7XG5cdFx0ZnVuY3Rpb24gc2VuZEV2ZW50VG9QYXJlbnQoY2IpIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGhvb2sgPSB3aW5kb3cucGFyZW50Ll9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX187XG5cdFx0XHRcdGlmIChob29rKSBjYihob29rKTtcblx0XHRcdH0gY2F0Y2ggKGUpIHt9XG5cdFx0fVxuXHRcdGNvbnN0IGhvb2sgPSB7XG5cdFx0XHRpZDogXCJ2dWUtZGV2dG9vbHMtbmV4dFwiLFxuXHRcdFx0ZGV2dG9vbHNWZXJzaW9uOiBcIjcuMFwiLFxuXHRcdFx0b246IChldmVudCwgY2IpID0+IHtcblx0XHRcdFx0c2VuZEV2ZW50VG9QYXJlbnQoKGhvb2spID0+IHtcblx0XHRcdFx0XHRob29rLm9uKGV2ZW50LCBjYik7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdG9uY2U6IChldmVudCwgY2IpID0+IHtcblx0XHRcdFx0c2VuZEV2ZW50VG9QYXJlbnQoKGhvb2spID0+IHtcblx0XHRcdFx0XHRob29rLm9uY2UoZXZlbnQsIGNiKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9LFxuXHRcdFx0b2ZmOiAoZXZlbnQsIGNiKSA9PiB7XG5cdFx0XHRcdHNlbmRFdmVudFRvUGFyZW50KChob29rKSA9PiB7XG5cdFx0XHRcdFx0aG9vay5vZmYoZXZlbnQsIGNiKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9LFxuXHRcdFx0ZW1pdDogKGV2ZW50LCAuLi5wYXlsb2FkKSA9PiB7XG5cdFx0XHRcdHNlbmRFdmVudFRvUGFyZW50KChob29rKSA9PiB7XG5cdFx0XHRcdFx0aG9vay5lbWl0KGV2ZW50LCAuLi5wYXlsb2FkKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBcIl9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX19cIiwge1xuXHRcdFx0Z2V0KCkge1xuXHRcdFx0XHRyZXR1cm4gaG9vaztcblx0XHRcdH0sXG5cdFx0XHRjb25maWd1cmFibGU6IHRydWVcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBpbmplY3RWdWVIb29rVG9JZnJhbWUoaWZyYW1lKSB7XG5cdFx0aWYgKGlmcmFtZS5fX3ZkZXZ0b29sc19faW5qZWN0ZWQpIHJldHVybjtcblx0XHR0cnkge1xuXHRcdFx0aWZyYW1lLl9fdmRldnRvb2xzX19pbmplY3RlZCA9IHRydWU7XG5cdFx0XHRjb25zdCBpbmplY3QgPSAoKSA9PiB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0aWZyYW1lLmNvbnRlbnRXaW5kb3cuX19WVUVfREVWVE9PTFNfSUZSQU1FX18gPSBpZnJhbWU7XG5cdFx0XHRcdFx0Y29uc3Qgc2NyaXB0ID0gaWZyYW1lLmNvbnRlbnREb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuXHRcdFx0XHRcdHNjcmlwdC50ZXh0Q29udGVudCA9IGA7KCR7ZGV0ZWN0SWZyYW1lQXBwLnRvU3RyaW5nKCl9KSh3aW5kb3csIHRydWUpYDtcblx0XHRcdFx0XHRpZnJhbWUuY29udGVudERvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZChzY3JpcHQpO1xuXHRcdFx0XHRcdHNjcmlwdC5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdCk7XG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHt9XG5cdFx0XHR9O1xuXHRcdFx0aW5qZWN0KCk7XG5cdFx0XHRpZnJhbWUuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRcIiwgKCkgPT4gaW5qZWN0KCkpO1xuXHRcdH0gY2F0Y2ggKGUpIHt9XG5cdH1cblx0ZnVuY3Rpb24gaW5qZWN0VnVlSG9va1RvSWZyYW1lcygpIHtcblx0XHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuXHRcdGNvbnN0IGlmcmFtZXMgPSBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJpZnJhbWU6bm90KFtkYXRhLXZ1ZS1kZXZ0b29scy1pZ25vcmVdKVwiKSk7XG5cdFx0Zm9yIChjb25zdCBpZnJhbWUgb2YgaWZyYW1lcykgaW5qZWN0VnVlSG9va1RvSWZyYW1lKGlmcmFtZSk7XG5cdH1cblx0aW5qZWN0VnVlSG9va1RvSWZyYW1lcygpO1xuXHRsZXQgaWZyYW1lQXBwQ2hlY2tzID0gMDtcblx0Y29uc3QgaWZyYW1lQXBwQ2hlY2tUaW1lciA9IHNldEludGVydmFsKCgpID0+IHtcblx0XHRpbmplY3RWdWVIb29rVG9JZnJhbWVzKCk7XG5cdFx0aWZyYW1lQXBwQ2hlY2tzKys7XG5cdFx0aWYgKGlmcmFtZUFwcENoZWNrcyA+PSA1KSBjbGVhckludGVydmFsKGlmcmFtZUFwcENoZWNrVGltZXIpO1xuXHR9LCAxZTMpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvaW5kZXgudHNcbmZ1bmN0aW9uIGluaXREZXZUb29scygpIHtcblx0ZGV0ZWN0SWZyYW1lQXBwKHRhcmdldCk7XG5cdHVwZGF0ZURldlRvb2xzU3RhdGUoeyB2aXRlUGx1Z2luRGV0ZWN0ZWQ6IGdldERldlRvb2xzRW52KCkudml0ZVBsdWdpbkRldGVjdGVkIH0pO1xuXHRjb25zdCBpc0RldlRvb2xzTmV4dCA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fPy5pZCA9PT0gXCJ2dWUtZGV2dG9vbHMtbmV4dFwiO1xuXHRpZiAodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX18gJiYgaXNEZXZUb29sc05leHQpIHJldHVybjtcblx0Y29uc3QgX2RldnRvb2xzSG9vayA9IGNyZWF0ZURldlRvb2xzSG9vaygpO1xuXHRpZiAodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0hPT0tfUkVQTEFZX18pIHRyeSB7XG5cdFx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0hPT0tfUkVQTEFZX18uZm9yRWFjaCgoY2IpID0+IGNiKF9kZXZ0b29sc0hvb2spKTtcblx0XHR0YXJnZXQuX19WVUVfREVWVE9PTFNfSE9PS19SRVBMQVlfXyA9IFtdO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0Y29uc29sZS5lcnJvcihcIlt2dWUtZGV2dG9vbHNdIEVycm9yIGR1cmluZyBob29rIHJlcGxheVwiLCBlKTtcblx0fVxuXHRfZGV2dG9vbHNIb29rLm9uY2UoXCJpbml0XCIsIChWdWUpID0+IHtcblx0XHR0YXJnZXQuX19WVUVfREVWVE9PTFNfVlVFMl9BUFBfREVURUNURURfXyA9IHRydWU7XG5cdFx0Y29uc29sZS5sb2coXCIlY1tfX19fX1Z1ZSBEZXZUb29scyB2NyBsb2dfX19fX11cIiwgXCJjb2xvcjogcmVkOyBmb250LWJvbGQ6IDYwMDsgZm9udC1zaXplOiAxNnB4O1wiKTtcblx0XHRjb25zb2xlLmxvZyhcIiVjVnVlIERldlRvb2xzIHY3IGRldGVjdGVkIGluIHlvdXIgVnVlMiBwcm9qZWN0LiB2NyBvbmx5IHN1cHBvcnRzIFZ1ZTMgYW5kIHdpbGwgbm90IHdvcmsuXCIsIFwiZm9udC1ib2xkOiA1MDA7IGZvbnQtc2l6ZTogMTRweDtcIik7XG5cdFx0Y29uc3QgbGVnYWN5Q2hyb21lVXJsID0gXCJodHRwczovL2Nocm9tZXdlYnN0b3JlLmdvb2dsZS5jb20vZGV0YWlsL3Z1ZWpzLWRldnRvb2xzL2lhYWptbGNlcGxlY2JsamlhbGhoa21lZGpscGRibGhwXCI7XG5cdFx0Y29uc3QgbGVnYWN5RmlyZWZveFVybCA9IFwiaHR0cHM6Ly9hZGRvbnMubW96aWxsYS5vcmcvZmlyZWZveC9hZGRvbi92dWUtanMtZGV2dG9vbHMtdjYtbGVnYWN5XCI7XG5cdFx0Y29uc29sZS5sb2coYCVjVGhlIGxlZ2FjeSB2ZXJzaW9uIG9mIGNocm9tZSBleHRlbnNpb24gdGhhdCBzdXBwb3J0cyBib3RoIFZ1ZSAyIGFuZCBWdWUgMyBoYXMgYmVlbiBtb3ZlZCB0byAlYyAke2xlZ2FjeUNocm9tZVVybH1gLCBcImZvbnQtc2l6ZTogMTRweDtcIiwgXCJ0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgY3Vyc29yOiBwb2ludGVyO2ZvbnQtc2l6ZTogMTRweDtcIik7XG5cdFx0Y29uc29sZS5sb2coYCVjVGhlIGxlZ2FjeSB2ZXJzaW9uIG9mIGZpcmVmb3ggZXh0ZW5zaW9uIHRoYXQgc3VwcG9ydHMgYm90aCBWdWUgMiBhbmQgVnVlIDMgaGFzIGJlZW4gbW92ZWQgdG8gJWMgJHtsZWdhY3lGaXJlZm94VXJsfWAsIFwiZm9udC1zaXplOiAxNHB4O1wiLCBcInRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lOyBjdXJzb3I6IHBvaW50ZXI7Zm9udC1zaXplOiAxNHB4O1wiKTtcblx0XHRjb25zb2xlLmxvZyhcIiVjUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSBvbmx5IHRoZSBsZWdhY3kgdmVyc2lvbiBmb3IgeW91ciBWdWUyIGFwcC5cIiwgXCJmb250LWJvbGQ6IDUwMDsgZm9udC1zaXplOiAxNHB4O1wiKTtcblx0XHRjb25zb2xlLmxvZyhcIiVjW19fX19fVnVlIERldlRvb2xzIHY3IGxvZ19fX19fXVwiLCBcImNvbG9yOiByZWQ7IGZvbnQtYm9sZDogNjAwOyBmb250LXNpemU6IDE2cHg7XCIpO1xuXHR9KTtcblx0aG9vay5vbi5zZXR1cERldnRvb2xzUGx1Z2luKChwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKSA9PiB7XG5cdFx0YWRkRGV2VG9vbHNQbHVnaW5Ub0J1ZmZlcihwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKTtcblx0XHRjb25zdCB7IGFwcCB9ID0gYWN0aXZlQXBwUmVjb3JkID8/IHt9O1xuXHRcdGlmIChwbHVnaW5EZXNjcmlwdG9yLnNldHRpbmdzKSBpbml0UGx1Z2luU2V0dGluZ3MocGx1Z2luRGVzY3JpcHRvci5pZCwgcGx1Z2luRGVzY3JpcHRvci5zZXR0aW5ncyk7XG5cdFx0aWYgKCFhcHApIHJldHVybjtcblx0XHRjYWxsRGV2VG9vbHNQbHVnaW5TZXR1cEZuKFtwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuXSwgYXBwKTtcblx0fSk7XG5cdG9uTGVnYWN5RGV2VG9vbHNQbHVnaW5BcGlBdmFpbGFibGUoKCkgPT4ge1xuXHRcdGRldnRvb2xzUGx1Z2luQnVmZmVyLmZpbHRlcigoW2l0ZW1dKSA9PiBpdGVtLmlkICE9PSBcImNvbXBvbmVudHNcIikuZm9yRWFjaCgoW3BsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm5dKSA9PiB7XG5cdFx0XHRfZGV2dG9vbHNIb29rLmVtaXQoRGV2VG9vbHNIb29rcy5TRVRVUF9ERVZUT09MU19QTFVHSU4sIHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4sIHsgdGFyZ2V0OiBcImxlZ2FjeVwiIH0pO1xuXHRcdH0pO1xuXHR9KTtcblx0aG9vay5vbi52dWVBcHBJbml0KGFzeW5jIChhcHAsIHZlcnNpb24sIHR5cGVzKSA9PiB7XG5cdFx0Y29uc3Qgbm9ybWFsaXplZEFwcFJlY29yZCA9IHtcblx0XHRcdC4uLmNyZWF0ZUFwcFJlY29yZChhcHAsIHR5cGVzKSxcblx0XHRcdGFwcCxcblx0XHRcdHZlcnNpb25cblx0XHR9O1xuXHRcdGFkZERldlRvb2xzQXBwUmVjb3JkKG5vcm1hbGl6ZWRBcHBSZWNvcmQpO1xuXHRcdGlmIChkZXZ0b29sc0FwcFJlY29yZHMudmFsdWUubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRzZXRBY3RpdmVBcHBSZWNvcmQobm9ybWFsaXplZEFwcFJlY29yZCk7XG5cdFx0XHRzZXRBY3RpdmVBcHBSZWNvcmRJZChub3JtYWxpemVkQXBwUmVjb3JkLmlkKTtcblx0XHRcdG5vcm1hbGl6ZVJvdXRlckluZm8obm9ybWFsaXplZEFwcFJlY29yZCwgYWN0aXZlQXBwUmVjb3JkKTtcblx0XHRcdHJlZ2lzdGVyRGV2VG9vbHNQbHVnaW4obm9ybWFsaXplZEFwcFJlY29yZC5hcHApO1xuXHRcdH1cblx0XHRzZXR1cERldlRvb2xzUGx1Z2luKC4uLmNyZWF0ZUNvbXBvbmVudHNEZXZUb29sc1BsdWdpbihub3JtYWxpemVkQXBwUmVjb3JkLmFwcCkpO1xuXHRcdHVwZGF0ZURldlRvb2xzU3RhdGUoeyBjb25uZWN0ZWQ6IHRydWUgfSk7XG5cdFx0X2RldnRvb2xzSG9vay5hcHBzLnB1c2goYXBwKTtcblx0fSk7XG5cdGhvb2sub24udnVlQXBwVW5tb3VudChhc3luYyAoYXBwKSA9PiB7XG5cdFx0Y29uc3QgYWN0aXZlUmVjb3JkcyA9IGRldnRvb2xzQXBwUmVjb3Jkcy52YWx1ZS5maWx0ZXIoKGFwcFJlY29yZCkgPT4gYXBwUmVjb3JkLmFwcCAhPT0gYXBwKTtcblx0XHRpZiAoYWN0aXZlUmVjb3Jkcy5sZW5ndGggPT09IDApIHVwZGF0ZURldlRvb2xzU3RhdGUoeyBjb25uZWN0ZWQ6IGZhbHNlIH0pO1xuXHRcdHJlbW92ZURldlRvb2xzQXBwUmVjb3JkKGFwcCk7XG5cdFx0cmVtb3ZlQXBwUmVjb3JkSWQoYXBwKTtcblx0XHRpZiAoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmFwcCA9PT0gYXBwKSB7XG5cdFx0XHRzZXRBY3RpdmVBcHBSZWNvcmQoYWN0aXZlUmVjb3Jkc1swXSk7XG5cdFx0XHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5TRU5EX0FDVElWRV9BUFBfVU5NT1VOVEVEX1RPX0NMSUVOVCk7XG5cdFx0fVxuXHRcdHRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fLmFwcHMuc3BsaWNlKHRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fLmFwcHMuaW5kZXhPZihhcHApLCAxKTtcblx0XHRyZW1vdmVSZWdpc3RlcmVkUGx1Z2luQXBwKGFwcCk7XG5cdH0pO1xuXHRzdWJzY3JpYmVEZXZUb29sc0hvb2soX2RldnRvb2xzSG9vayk7XG5cdGlmICghdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX18pIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIFwiX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfX1wiLCB7XG5cdFx0Z2V0KCkge1xuXHRcdFx0cmV0dXJuIF9kZXZ0b29sc0hvb2s7XG5cdFx0fSxcblx0XHRjb25maWd1cmFibGU6IHRydWVcblx0fSk7XG5cdGVsc2UgaWYgKCFpc051eHRBcHApIE9iamVjdC5hc3NpZ24oX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXywgX2RldnRvb2xzSG9vayk7XG59XG5mdW5jdGlvbiBvbkRldlRvb2xzQ2xpZW50Q29ubmVjdGVkKGZuKSB7XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmNvbm5lY3RlZCAmJiBkZXZ0b29sc1N0YXRlLmNsaWVudENvbm5lY3RlZCkge1xuXHRcdFx0Zm4oKTtcblx0XHRcdHJlc29sdmUoKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5ERVZUT09MU19DT05ORUNURURfVVBEQVRFRCwgKHsgc3RhdGUgfSkgPT4ge1xuXHRcdFx0aWYgKHN0YXRlLmNvbm5lY3RlZCAmJiBzdGF0ZS5jbGllbnRDb25uZWN0ZWQpIHtcblx0XHRcdFx0Zm4oKTtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2hpZ2gtcGVyZi1tb2RlL2luZGV4LnRzXG5mdW5jdGlvbiB0b2dnbGVIaWdoUGVyZk1vZGUoc3RhdGUpIHtcblx0ZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkID0gc3RhdGUgPz8gIWRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZDtcblx0aWYgKCFzdGF0ZSAmJiBhY3RpdmVBcHBSZWNvcmQudmFsdWUpIHJlZ2lzdGVyRGV2VG9vbHNQbHVnaW4oYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmFwcCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvcmV2aXZlci50c1xuZnVuY3Rpb24gcmV2aXZlU2V0KHZhbCkge1xuXHRjb25zdCByZXN1bHQgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRjb25zdCBsaXN0ID0gdmFsLl9jdXN0b20udmFsdWU7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IHZhbHVlID0gbGlzdFtpXTtcblx0XHRyZXN1bHQuYWRkKHJldml2ZSh2YWx1ZSkpO1xuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiByZXZpdmVNYXAodmFsKSB7XG5cdGNvbnN0IHJlc3VsdCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGNvbnN0IGxpc3QgPSB2YWwuX2N1c3RvbS52YWx1ZTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgeyBrZXksIHZhbHVlIH0gPSBsaXN0W2ldO1xuXHRcdHJlc3VsdC5zZXQoa2V5LCByZXZpdmUodmFsdWUpKTtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gcmV2aXZlKHZhbCkge1xuXHRpZiAodmFsID09PSBcIl9fdnVlX2RldnRvb2xfdW5kZWZpbmVkX19cIikgcmV0dXJuO1xuXHRlbHNlIGlmICh2YWwgPT09IFwiX192dWVfZGV2dG9vbF9pbmZpbml0eV9fXCIpIHJldHVybiBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFk7XG5cdGVsc2UgaWYgKHZhbCA9PT0gXCJfX3Z1ZV9kZXZ0b29sX25lZ2F0aXZlX2luZmluaXR5X19cIikgcmV0dXJuIE51bWJlci5ORUdBVElWRV9JTkZJTklUWTtcblx0ZWxzZSBpZiAodmFsID09PSBcIl9fdnVlX2RldnRvb2xfbmFuX19cIikgcmV0dXJuIE5hTjtcblx0ZWxzZSBpZiAodmFsICYmIHZhbC5fY3VzdG9tKSB7XG5cdFx0Y29uc3QgeyBfY3VzdG9tOiBjdXN0b20gfSA9IHZhbDtcblx0XHRpZiAoY3VzdG9tLnR5cGUgPT09IFwiY29tcG9uZW50XCIpIHJldHVybiBhY3RpdmVBcHBSZWNvcmQudmFsdWUuaW5zdGFuY2VNYXAuZ2V0KGN1c3RvbS5pZCk7XG5cdFx0ZWxzZSBpZiAoY3VzdG9tLnR5cGUgPT09IFwibWFwXCIpIHJldHVybiByZXZpdmVNYXAodmFsKTtcblx0XHRlbHNlIGlmIChjdXN0b20udHlwZSA9PT0gXCJzZXRcIikgcmV0dXJuIHJldml2ZVNldCh2YWwpO1xuXHRcdGVsc2UgaWYgKGN1c3RvbS50eXBlID09PSBcImJpZ2ludFwiKSByZXR1cm4gQmlnSW50KGN1c3RvbS52YWx1ZSk7XG5cdFx0ZWxzZSByZXR1cm4gcmV2aXZlKGN1c3RvbS52YWx1ZSk7XG5cdH0gZWxzZSBpZiAoc3ltYm9sUkUudGVzdCh2YWwpKSB7XG5cdFx0Y29uc3QgWywgc3RyaW5nXSA9IHN5bWJvbFJFLmV4ZWModmFsKTtcblx0XHRyZXR1cm4gU3ltYm9sLmZvcihzdHJpbmcpO1xuXHR9IGVsc2UgaWYgKHNwZWNpYWxUeXBlUkUudGVzdCh2YWwpKSB7XG5cdFx0Y29uc3QgWywgdHlwZSwgc3RyaW5nLCAsIGRldGFpbHNdID0gc3BlY2lhbFR5cGVSRS5leGVjKHZhbCk7XG5cdFx0Y29uc3QgcmVzdWx0ID0gbmV3IHRhcmdldFt0eXBlXShzdHJpbmcpO1xuXHRcdGlmICh0eXBlID09PSBcIkVycm9yXCIgJiYgZGV0YWlscykgcmVzdWx0LnN0YWNrID0gZGV0YWlscztcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9IGVsc2UgcmV0dXJuIHZhbDtcbn1cbmZ1bmN0aW9uIHJldml2ZXIoa2V5LCB2YWx1ZSkge1xuXHRyZXR1cm4gcmV2aXZlKHZhbHVlKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9mb3JtYXQudHNcbmZ1bmN0aW9uIGdldEluc3BlY3RvclN0YXRlVmFsdWVUeXBlKHZhbHVlLCByYXcgPSB0cnVlKSB7XG5cdGNvbnN0IHR5cGUgPSB0eXBlb2YgdmFsdWU7XG5cdGlmICh2YWx1ZSA9PSBudWxsIHx8IHZhbHVlID09PSBcIl9fdnVlX2RldnRvb2xfdW5kZWZpbmVkX19cIiB8fCB2YWx1ZSA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIFwibnVsbFwiO1xuXHRlbHNlIGlmICh0eXBlID09PSBcImJvb2xlYW5cIiB8fCB0eXBlID09PSBcIm51bWJlclwiIHx8IHZhbHVlID09PSBcIl9fdnVlX2RldnRvb2xfaW5maW5pdHlfX1wiIHx8IHZhbHVlID09PSBcIl9fdnVlX2RldnRvb2xfbmVnYXRpdmVfaW5maW5pdHlfX1wiIHx8IHZhbHVlID09PSBcIl9fdnVlX2RldnRvb2xfbmFuX19cIikgcmV0dXJuIFwibGl0ZXJhbFwiO1xuXHRlbHNlIGlmICh2YWx1ZT8uX2N1c3RvbSkgaWYgKHJhdyB8fCB2YWx1ZS5fY3VzdG9tLmRpc3BsYXkgIT0gbnVsbCB8fCB2YWx1ZS5fY3VzdG9tLmRpc3BsYXlUZXh0ICE9IG51bGwpIHJldHVybiBcImN1c3RvbVwiO1xuXHRlbHNlIHJldHVybiBnZXRJbnNwZWN0b3JTdGF0ZVZhbHVlVHlwZSh2YWx1ZS5fY3VzdG9tLnZhbHVlKTtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0Y29uc3QgdHlwZU1hdGNoID0gc3BlY2lhbFR5cGVSRS5leGVjKHZhbHVlKTtcblx0XHRpZiAodHlwZU1hdGNoKSB7XG5cdFx0XHRjb25zdCBbLCB0eXBlXSA9IHR5cGVNYXRjaDtcblx0XHRcdHJldHVybiBgbmF0aXZlICR7dHlwZX1gO1xuXHRcdH0gZWxzZSByZXR1cm4gXCJzdHJpbmdcIjtcblx0fSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSB8fCB2YWx1ZT8uX2lzQXJyYXkpIHJldHVybiBcImFycmF5XCI7XG5cdGVsc2UgaWYgKGlzUGxhaW5PYmplY3QodmFsdWUpKSByZXR1cm4gXCJwbGFpbi1vYmplY3RcIjtcblx0ZWxzZSByZXR1cm4gXCJ1bmtub3duXCI7XG59XG5mdW5jdGlvbiBmb3JtYXRJbnNwZWN0b3JTdGF0ZVZhbHVlKHZhbHVlLCBxdW90ZXMgPSBmYWxzZSwgb3B0aW9ucykge1xuXHRjb25zdCB7IGN1c3RvbUNsYXNzIH0gPSBvcHRpb25zID8/IHt9O1xuXHRsZXQgcmVzdWx0O1xuXHRjb25zdCB0eXBlID0gZ2V0SW5zcGVjdG9yU3RhdGVWYWx1ZVR5cGUodmFsdWUsIGZhbHNlKTtcblx0aWYgKHR5cGUgIT09IFwiY3VzdG9tXCIgJiYgdmFsdWU/Ll9jdXN0b20pIHZhbHVlID0gdmFsdWUuX2N1c3RvbS52YWx1ZTtcblx0aWYgKHJlc3VsdCA9IGludGVybmFsU3RhdGVUb2tlblRvU3RyaW5nKHZhbHVlKSkgcmV0dXJuIHJlc3VsdDtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJjdXN0b21cIikgcmV0dXJuIHZhbHVlLl9jdXN0b20udmFsdWU/Ll9jdXN0b20gJiYgZm9ybWF0SW5zcGVjdG9yU3RhdGVWYWx1ZSh2YWx1ZS5fY3VzdG9tLnZhbHVlLCBxdW90ZXMsIG9wdGlvbnMpIHx8IHZhbHVlLl9jdXN0b20uZGlzcGxheVRleHQgfHwgdmFsdWUuX2N1c3RvbS5kaXNwbGF5O1xuXHRlbHNlIGlmICh0eXBlID09PSBcImFycmF5XCIpIHJldHVybiBgQXJyYXlbJHt2YWx1ZS5sZW5ndGh9XWA7XG5cdGVsc2UgaWYgKHR5cGUgPT09IFwicGxhaW4tb2JqZWN0XCIpIHJldHVybiBgT2JqZWN0JHtPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoID8gXCJcIiA6IFwiIChlbXB0eSlcIn1gO1xuXHRlbHNlIGlmICh0eXBlPy5pbmNsdWRlcyhcIm5hdGl2ZVwiKSkgcmV0dXJuIGVzY2FwZShzcGVjaWFsVHlwZVJFLmV4ZWModmFsdWUpPy5bMl0pO1xuXHRlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHtcblx0XHRjb25zdCB0eXBlTWF0Y2ggPSB2YWx1ZS5tYXRjaChyYXdUeXBlUkUpO1xuXHRcdGlmICh0eXBlTWF0Y2gpIHZhbHVlID0gZXNjYXBlU3RyaW5nKHR5cGVNYXRjaFsxXSk7XG5cdFx0ZWxzZSBpZiAocXVvdGVzKSB2YWx1ZSA9IGA8c3Bhbj5cIjwvc3Bhbj4ke2N1c3RvbUNsYXNzPy5zdHJpbmcgPyBgPHNwYW4gY2xhc3M9JHtjdXN0b21DbGFzcy5zdHJpbmd9PiR7ZXNjYXBlU3RyaW5nKHZhbHVlKX08L3NwYW4+YCA6IGVzY2FwZVN0cmluZyh2YWx1ZSl9PHNwYW4+XCI8L3NwYW4+YDtcblx0XHRlbHNlIHZhbHVlID0gY3VzdG9tQ2xhc3M/LnN0cmluZyA/IGA8c3BhbiBjbGFzcz1cIiR7Y3VzdG9tQ2xhc3M/LnN0cmluZyA/PyBcIlwifVwiPiR7ZXNjYXBlU3RyaW5nKHZhbHVlKX08L3NwYW4+YCA6IGVzY2FwZVN0cmluZyh2YWx1ZSk7XG5cdH1cblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gZXNjYXBlU3RyaW5nKHZhbHVlKSB7XG5cdHJldHVybiBlc2NhcGUodmFsdWUpLnJlcGxhY2UoLyAvZywgXCImbmJzcDtcIikucmVwbGFjZSgvXFxuL2csIFwiPHNwYW4+XFxcXG48L3NwYW4+XCIpO1xufVxuZnVuY3Rpb24gZ2V0UmF3KHZhbHVlKSB7XG5cdGxldCBjdXN0b21UeXBlO1xuXHRjb25zdCBpc0N1c3RvbSA9IGdldEluc3BlY3RvclN0YXRlVmFsdWVUeXBlKHZhbHVlKSA9PT0gXCJjdXN0b21cIjtcblx0bGV0IGluaGVyaXQgPSB7fTtcblx0aWYgKGlzQ3VzdG9tKSB7XG5cdFx0Y29uc3QgZGF0YSA9IHZhbHVlO1xuXHRcdGNvbnN0IGN1c3RvbVZhbHVlID0gZGF0YS5fY3VzdG9tPy52YWx1ZTtcblx0XHRjb25zdCBjdXJyZW50Q3VzdG9tVHlwZSA9IGRhdGEuX2N1c3RvbT8udHlwZTtcblx0XHRjb25zdCBuZXN0ZWRDdXN0b20gPSB0eXBlb2YgY3VzdG9tVmFsdWUgPT09IFwib2JqZWN0XCIgJiYgY3VzdG9tVmFsdWUgIT09IG51bGwgJiYgXCJfY3VzdG9tXCIgaW4gY3VzdG9tVmFsdWUgPyBnZXRSYXcoY3VzdG9tVmFsdWUpIDoge1xuXHRcdFx0aW5oZXJpdDogdm9pZCAwLFxuXHRcdFx0dmFsdWU6IHZvaWQgMCxcblx0XHRcdGN1c3RvbVR5cGU6IHZvaWQgMFxuXHRcdH07XG5cdFx0aW5oZXJpdCA9IG5lc3RlZEN1c3RvbS5pbmhlcml0IHx8IGRhdGEuX2N1c3RvbT8uZmllbGRzIHx8IHt9O1xuXHRcdHZhbHVlID0gbmVzdGVkQ3VzdG9tLnZhbHVlIHx8IGN1c3RvbVZhbHVlO1xuXHRcdGN1c3RvbVR5cGUgPSBuZXN0ZWRDdXN0b20uY3VzdG9tVHlwZSB8fCBjdXJyZW50Q3VzdG9tVHlwZTtcblx0fVxuXHRpZiAodmFsdWUgJiYgdmFsdWUuX2lzQXJyYXkpIHZhbHVlID0gdmFsdWUuaXRlbXM7XG5cdHJldHVybiB7XG5cdFx0dmFsdWUsXG5cdFx0aW5oZXJpdCxcblx0XHRjdXN0b21UeXBlXG5cdH07XG59XG5mdW5jdGlvbiB0b0VkaXQodmFsdWUsIGN1c3RvbVR5cGUpIHtcblx0aWYgKGN1c3RvbVR5cGUgPT09IFwiYmlnaW50XCIpIHJldHVybiB2YWx1ZTtcblx0aWYgKGN1c3RvbVR5cGUgPT09IFwiZGF0ZVwiKSByZXR1cm4gdmFsdWU7XG5cdHJldHVybiByZXBsYWNlVG9rZW5Ub1N0cmluZyhKU09OLnN0cmluZ2lmeSh2YWx1ZSkpO1xufVxuZnVuY3Rpb24gdG9TdWJtaXQodmFsdWUsIGN1c3RvbVR5cGUpIHtcblx0aWYgKGN1c3RvbVR5cGUgPT09IFwiYmlnaW50XCIpIHJldHVybiBCaWdJbnQodmFsdWUpO1xuXHRpZiAoY3VzdG9tVHlwZSA9PT0gXCJkYXRlXCIpIHJldHVybiBuZXcgRGF0ZSh2YWx1ZSk7XG5cdHJldHVybiBKU09OLnBhcnNlKHJlcGxhY2VTdHJpbmdUb1Rva2VuKHZhbHVlKSwgcmV2aXZlcik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9kZXZ0b29scy1jbGllbnQvZGV0ZWN0ZWQudHNcbmZ1bmN0aW9uIHVwZGF0ZURldlRvb2xzQ2xpZW50RGV0ZWN0ZWQocGFyYW1zKSB7XG5cdGRldnRvb2xzU3RhdGUuZGV2dG9vbHNDbGllbnREZXRlY3RlZCA9IHtcblx0XHQuLi5kZXZ0b29sc1N0YXRlLmRldnRvb2xzQ2xpZW50RGV0ZWN0ZWQsXG5cdFx0Li4ucGFyYW1zXG5cdH07XG5cdHRvZ2dsZUhpZ2hQZXJmTW9kZSghT2JqZWN0LnZhbHVlcyhkZXZ0b29sc1N0YXRlLmRldnRvb2xzQ2xpZW50RGV0ZWN0ZWQpLnNvbWUoQm9vbGVhbikpO1xufVxudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX1VQREFURV9DTElFTlRfREVURUNURURfXyA/Pz0gdXBkYXRlRGV2VG9vbHNDbGllbnREZXRlY3RlZDtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L2RvdWJsZS1pbmRleGVkLWt2LmpzXG52YXIgRG91YmxlSW5kZXhlZEtWID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHR0aGlzLmtleVRvVmFsdWUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMudmFsdWVUb0tleSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdH1cblx0c2V0KGtleSwgdmFsdWUpIHtcblx0XHR0aGlzLmtleVRvVmFsdWUuc2V0KGtleSwgdmFsdWUpO1xuXHRcdHRoaXMudmFsdWVUb0tleS5zZXQodmFsdWUsIGtleSk7XG5cdH1cblx0Z2V0QnlLZXkoa2V5KSB7XG5cdFx0cmV0dXJuIHRoaXMua2V5VG9WYWx1ZS5nZXQoa2V5KTtcblx0fVxuXHRnZXRCeVZhbHVlKHZhbHVlKSB7XG5cdFx0cmV0dXJuIHRoaXMudmFsdWVUb0tleS5nZXQodmFsdWUpO1xuXHR9XG5cdGNsZWFyKCkge1xuXHRcdHRoaXMua2V5VG9WYWx1ZS5jbGVhcigpO1xuXHRcdHRoaXMudmFsdWVUb0tleS5jbGVhcigpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvcmVnaXN0cnkuanNcbnZhciBSZWdpc3RyeSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoZ2VuZXJhdGVJZGVudGlmaWVyKSB7XG5cdFx0dGhpcy5nZW5lcmF0ZUlkZW50aWZpZXIgPSBnZW5lcmF0ZUlkZW50aWZpZXI7XG5cdFx0dGhpcy5rdiA9IG5ldyBEb3VibGVJbmRleGVkS1YoKTtcblx0fVxuXHRyZWdpc3Rlcih2YWx1ZSwgaWRlbnRpZmllcikge1xuXHRcdGlmICh0aGlzLmt2LmdldEJ5VmFsdWUodmFsdWUpKSByZXR1cm47XG5cdFx0aWYgKCFpZGVudGlmaWVyKSBpZGVudGlmaWVyID0gdGhpcy5nZW5lcmF0ZUlkZW50aWZpZXIodmFsdWUpO1xuXHRcdHRoaXMua3Yuc2V0KGlkZW50aWZpZXIsIHZhbHVlKTtcblx0fVxuXHRjbGVhcigpIHtcblx0XHR0aGlzLmt2LmNsZWFyKCk7XG5cdH1cblx0Z2V0SWRlbnRpZmllcih2YWx1ZSkge1xuXHRcdHJldHVybiB0aGlzLmt2LmdldEJ5VmFsdWUodmFsdWUpO1xuXHR9XG5cdGdldFZhbHVlKGlkZW50aWZpZXIpIHtcblx0XHRyZXR1cm4gdGhpcy5rdi5nZXRCeUtleShpZGVudGlmaWVyKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L2NsYXNzLXJlZ2lzdHJ5LmpzXG52YXIgQ2xhc3NSZWdpc3RyeSA9IGNsYXNzIGV4dGVuZHMgUmVnaXN0cnkge1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRzdXBlcigoYykgPT4gYy5uYW1lKTtcblx0XHR0aGlzLmNsYXNzVG9BbGxvd2VkUHJvcHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHR9XG5cdHJlZ2lzdGVyKHZhbHVlLCBvcHRpb25zKSB7XG5cdFx0aWYgKHR5cGVvZiBvcHRpb25zID09PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRpZiAob3B0aW9ucy5hbGxvd1Byb3BzKSB0aGlzLmNsYXNzVG9BbGxvd2VkUHJvcHMuc2V0KHZhbHVlLCBvcHRpb25zLmFsbG93UHJvcHMpO1xuXHRcdFx0c3VwZXIucmVnaXN0ZXIodmFsdWUsIG9wdGlvbnMuaWRlbnRpZmllcik7XG5cdFx0fSBlbHNlIHN1cGVyLnJlZ2lzdGVyKHZhbHVlLCBvcHRpb25zKTtcblx0fVxuXHRnZXRBbGxvd2VkUHJvcHModmFsdWUpIHtcblx0XHRyZXR1cm4gdGhpcy5jbGFzc1RvQWxsb3dlZFByb3BzLmdldCh2YWx1ZSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC91dGlsLmpzXG5mdW5jdGlvbiB2YWx1ZXNPZk9iaihyZWNvcmQpIHtcblx0aWYgKFwidmFsdWVzXCIgaW4gT2JqZWN0KSByZXR1cm4gT2JqZWN0LnZhbHVlcyhyZWNvcmQpO1xuXHRjb25zdCB2YWx1ZXMgPSBbXTtcblx0Zm9yIChjb25zdCBrZXkgaW4gcmVjb3JkKSBpZiAocmVjb3JkLmhhc093blByb3BlcnR5KGtleSkpIHZhbHVlcy5wdXNoKHJlY29yZFtrZXldKTtcblx0cmV0dXJuIHZhbHVlcztcbn1cbmZ1bmN0aW9uIGZpbmQocmVjb3JkLCBwcmVkaWNhdGUpIHtcblx0Y29uc3QgdmFsdWVzID0gdmFsdWVzT2ZPYmoocmVjb3JkKTtcblx0aWYgKFwiZmluZFwiIGluIHZhbHVlcykgcmV0dXJuIHZhbHVlcy5maW5kKHByZWRpY2F0ZSk7XG5cdGNvbnN0IHZhbHVlc05vdE5ldmVyID0gdmFsdWVzO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlc05vdE5ldmVyLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgdmFsdWUgPSB2YWx1ZXNOb3ROZXZlcltpXTtcblx0XHRpZiAocHJlZGljYXRlKHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuXHR9XG59XG5mdW5jdGlvbiBmb3JFYWNoKHJlY29yZCwgcnVuKSB7XG5cdE9iamVjdC5lbnRyaWVzKHJlY29yZCkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiBydW4odmFsdWUsIGtleSkpO1xufVxuZnVuY3Rpb24gaW5jbHVkZXMoYXJyLCB2YWx1ZSkge1xuXHRyZXR1cm4gYXJyLmluZGV4T2YodmFsdWUpICE9PSAtMTtcbn1cbmZ1bmN0aW9uIGZpbmRBcnIocmVjb3JkLCBwcmVkaWNhdGUpIHtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCByZWNvcmQubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCB2YWx1ZSA9IHJlY29yZFtpXTtcblx0XHRpZiAocHJlZGljYXRlKHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9jdXN0b20tdHJhbnNmb3JtZXItcmVnaXN0cnkuanNcbnZhciBDdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5ID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHR0aGlzLnRyYW5zZm9tZXJzID0ge307XG5cdH1cblx0cmVnaXN0ZXIodHJhbnNmb3JtZXIpIHtcblx0XHR0aGlzLnRyYW5zZm9tZXJzW3RyYW5zZm9ybWVyLm5hbWVdID0gdHJhbnNmb3JtZXI7XG5cdH1cblx0ZmluZEFwcGxpY2FibGUodikge1xuXHRcdHJldHVybiBmaW5kKHRoaXMudHJhbnNmb21lcnMsICh0cmFuc2Zvcm1lcikgPT4gdHJhbnNmb3JtZXIuaXNBcHBsaWNhYmxlKHYpKTtcblx0fVxuXHRmaW5kQnlOYW1lKG5hbWUpIHtcblx0XHRyZXR1cm4gdGhpcy50cmFuc2ZvbWVyc1tuYW1lXTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L2lzLmpzXG5jb25zdCBnZXRUeXBlJDEgPSAocGF5bG9hZCkgPT4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHBheWxvYWQpLnNsaWNlKDgsIC0xKTtcbmNvbnN0IGlzVW5kZWZpbmVkJDEgPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwidW5kZWZpbmVkXCI7XG5jb25zdCBpc051bGwkMSA9IChwYXlsb2FkKSA9PiBwYXlsb2FkID09PSBudWxsO1xuY29uc3QgaXNQbGFpbk9iamVjdCQyID0gKHBheWxvYWQpID0+IHtcblx0aWYgKHR5cGVvZiBwYXlsb2FkICE9PSBcIm9iamVjdFwiIHx8IHBheWxvYWQgPT09IG51bGwpIHJldHVybiBmYWxzZTtcblx0aWYgKHBheWxvYWQgPT09IE9iamVjdC5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcblx0aWYgKE9iamVjdC5nZXRQcm90b3R5cGVPZihwYXlsb2FkKSA9PT0gbnVsbCkgcmV0dXJuIHRydWU7XG5cdHJldHVybiBPYmplY3QuZ2V0UHJvdG90eXBlT2YocGF5bG9hZCkgPT09IE9iamVjdC5wcm90b3R5cGU7XG59O1xuY29uc3QgaXNFbXB0eU9iamVjdCA9IChwYXlsb2FkKSA9PiBpc1BsYWluT2JqZWN0JDIocGF5bG9hZCkgJiYgT2JqZWN0LmtleXMocGF5bG9hZCkubGVuZ3RoID09PSAwO1xuY29uc3QgaXNBcnJheSQyID0gKHBheWxvYWQpID0+IEFycmF5LmlzQXJyYXkocGF5bG9hZCk7XG5jb25zdCBpc1N0cmluZyA9IChwYXlsb2FkKSA9PiB0eXBlb2YgcGF5bG9hZCA9PT0gXCJzdHJpbmdcIjtcbmNvbnN0IGlzTnVtYmVyID0gKHBheWxvYWQpID0+IHR5cGVvZiBwYXlsb2FkID09PSBcIm51bWJlclwiICYmICFpc05hTihwYXlsb2FkKTtcbmNvbnN0IGlzQm9vbGVhbiA9IChwYXlsb2FkKSA9PiB0eXBlb2YgcGF5bG9hZCA9PT0gXCJib29sZWFuXCI7XG5jb25zdCBpc1JlZ0V4cCA9IChwYXlsb2FkKSA9PiBwYXlsb2FkIGluc3RhbmNlb2YgUmVnRXhwO1xuY29uc3QgaXNNYXAgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCBpbnN0YW5jZW9mIE1hcDtcbmNvbnN0IGlzU2V0ID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBTZXQ7XG5jb25zdCBpc1N5bWJvbCA9IChwYXlsb2FkKSA9PiBnZXRUeXBlJDEocGF5bG9hZCkgPT09IFwiU3ltYm9sXCI7XG5jb25zdCBpc0RhdGUgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCBpbnN0YW5jZW9mIERhdGUgJiYgIWlzTmFOKHBheWxvYWQudmFsdWVPZigpKTtcbmNvbnN0IGlzRXJyb3IgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCBpbnN0YW5jZW9mIEVycm9yO1xuY29uc3QgaXNOYU5WYWx1ZSA9IChwYXlsb2FkKSA9PiB0eXBlb2YgcGF5bG9hZCA9PT0gXCJudW1iZXJcIiAmJiBpc05hTihwYXlsb2FkKTtcbmNvbnN0IGlzUHJpbWl0aXZlID0gKHBheWxvYWQpID0+IGlzQm9vbGVhbihwYXlsb2FkKSB8fCBpc051bGwkMShwYXlsb2FkKSB8fCBpc1VuZGVmaW5lZCQxKHBheWxvYWQpIHx8IGlzTnVtYmVyKHBheWxvYWQpIHx8IGlzU3RyaW5nKHBheWxvYWQpIHx8IGlzU3ltYm9sKHBheWxvYWQpO1xuY29uc3QgaXNCaWdpbnQgPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwiYmlnaW50XCI7XG5jb25zdCBpc0luZmluaXRlID0gKHBheWxvYWQpID0+IHBheWxvYWQgPT09IEluZmluaXR5IHx8IHBheWxvYWQgPT09IC1JbmZpbml0eTtcbmNvbnN0IGlzVHlwZWRBcnJheSA9IChwYXlsb2FkKSA9PiBBcnJheUJ1ZmZlci5pc1ZpZXcocGF5bG9hZCkgJiYgIShwYXlsb2FkIGluc3RhbmNlb2YgRGF0YVZpZXcpO1xuY29uc3QgaXNVUkwgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCBpbnN0YW5jZW9mIFVSTDtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L3BhdGhzdHJpbmdpZmllci5qc1xuY29uc3QgZXNjYXBlS2V5ID0gKGtleSkgPT4ga2V5LnJlcGxhY2UoL1xcLi9nLCBcIlxcXFwuXCIpO1xuY29uc3Qgc3RyaW5naWZ5UGF0aCA9IChwYXRoKSA9PiBwYXRoLm1hcChTdHJpbmcpLm1hcChlc2NhcGVLZXkpLmpvaW4oXCIuXCIpO1xuY29uc3QgcGFyc2VQYXRoID0gKHN0cmluZykgPT4ge1xuXHRjb25zdCByZXN1bHQgPSBbXTtcblx0bGV0IHNlZ21lbnQgPSBcIlwiO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHN0cmluZy5sZW5ndGg7IGkrKykge1xuXHRcdGxldCBjaGFyID0gc3RyaW5nLmNoYXJBdChpKTtcblx0XHRpZiAoY2hhciA9PT0gXCJcXFxcXCIgJiYgc3RyaW5nLmNoYXJBdChpICsgMSkgPT09IFwiLlwiKSB7XG5cdFx0XHRzZWdtZW50ICs9IFwiLlwiO1xuXHRcdFx0aSsrO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChjaGFyID09PSBcIi5cIikge1xuXHRcdFx0cmVzdWx0LnB1c2goc2VnbWVudCk7XG5cdFx0XHRzZWdtZW50ID0gXCJcIjtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRzZWdtZW50ICs9IGNoYXI7XG5cdH1cblx0Y29uc3QgbGFzdFNlZ21lbnQgPSBzZWdtZW50O1xuXHRyZXN1bHQucHVzaChsYXN0U2VnbWVudCk7XG5cdHJldHVybiByZXN1bHQ7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvdHJhbnNmb3JtZXIuanNcbmZ1bmN0aW9uIHNpbXBsZVRyYW5zZm9ybWF0aW9uKGlzQXBwbGljYWJsZSwgYW5ub3RhdGlvbiwgdHJhbnNmb3JtLCB1bnRyYW5zZm9ybSkge1xuXHRyZXR1cm4ge1xuXHRcdGlzQXBwbGljYWJsZSxcblx0XHRhbm5vdGF0aW9uLFxuXHRcdHRyYW5zZm9ybSxcblx0XHR1bnRyYW5zZm9ybVxuXHR9O1xufVxuY29uc3Qgc2ltcGxlUnVsZXMgPSBbXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKGlzVW5kZWZpbmVkJDEsIFwidW5kZWZpbmVkXCIsICgpID0+IG51bGwsICgpID0+IHZvaWQgMCksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKGlzQmlnaW50LCBcImJpZ2ludFwiLCAodikgPT4gdi50b1N0cmluZygpLCAodikgPT4ge1xuXHRcdGlmICh0eXBlb2YgQmlnSW50ICE9PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gQmlnSW50KHYpO1xuXHRcdGNvbnNvbGUuZXJyb3IoXCJQbGVhc2UgYWRkIGEgQmlnSW50IHBvbHlmaWxsLlwiKTtcblx0XHRyZXR1cm4gdjtcblx0fSksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKGlzRGF0ZSwgXCJEYXRlXCIsICh2KSA9PiB2LnRvSVNPU3RyaW5nKCksICh2KSA9PiBuZXcgRGF0ZSh2KSksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKGlzRXJyb3IsIFwiRXJyb3JcIiwgKHYsIHN1cGVySnNvbikgPT4ge1xuXHRcdGNvbnN0IGJhc2VFcnJvciA9IHtcblx0XHRcdG5hbWU6IHYubmFtZSxcblx0XHRcdG1lc3NhZ2U6IHYubWVzc2FnZVxuXHRcdH07XG5cdFx0c3VwZXJKc29uLmFsbG93ZWRFcnJvclByb3BzLmZvckVhY2goKHByb3ApID0+IHtcblx0XHRcdGJhc2VFcnJvcltwcm9wXSA9IHZbcHJvcF07XG5cdFx0fSk7XG5cdFx0cmV0dXJuIGJhc2VFcnJvcjtcblx0fSwgKHYsIHN1cGVySnNvbikgPT4ge1xuXHRcdGNvbnN0IGUgPSBuZXcgRXJyb3Iodi5tZXNzYWdlKTtcblx0XHRlLm5hbWUgPSB2Lm5hbWU7XG5cdFx0ZS5zdGFjayA9IHYuc3RhY2s7XG5cdFx0c3VwZXJKc29uLmFsbG93ZWRFcnJvclByb3BzLmZvckVhY2goKHByb3ApID0+IHtcblx0XHRcdGVbcHJvcF0gPSB2W3Byb3BdO1xuXHRcdH0pO1xuXHRcdHJldHVybiBlO1xuXHR9KSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oaXNSZWdFeHAsIFwicmVnZXhwXCIsICh2KSA9PiBcIlwiICsgdiwgKHJlZ2V4KSA9PiB7XG5cdFx0Y29uc3QgYm9keSA9IHJlZ2V4LnNsaWNlKDEsIHJlZ2V4Lmxhc3RJbmRleE9mKFwiL1wiKSk7XG5cdFx0Y29uc3QgZmxhZ3MgPSByZWdleC5zbGljZShyZWdleC5sYXN0SW5kZXhPZihcIi9cIikgKyAxKTtcblx0XHRyZXR1cm4gbmV3IFJlZ0V4cChib2R5LCBmbGFncyk7XG5cdH0pLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc1NldCwgXCJzZXRcIiwgKHYpID0+IFsuLi52LnZhbHVlcygpXSwgKHYpID0+IG5ldyBTZXQodikpLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc01hcCwgXCJtYXBcIiwgKHYpID0+IFsuLi52LmVudHJpZXMoKV0sICh2KSA9PiBuZXcgTWFwKHYpKSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oKHYpID0+IGlzTmFOVmFsdWUodikgfHwgaXNJbmZpbml0ZSh2KSwgXCJudW1iZXJcIiwgKHYpID0+IHtcblx0XHRpZiAoaXNOYU5WYWx1ZSh2KSkgcmV0dXJuIFwiTmFOXCI7XG5cdFx0aWYgKHYgPiAwKSByZXR1cm4gXCJJbmZpbml0eVwiO1xuXHRcdGVsc2UgcmV0dXJuIFwiLUluZmluaXR5XCI7XG5cdH0sIE51bWJlciksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKCh2KSA9PiB2ID09PSAwICYmIDEgLyB2ID09PSAtSW5maW5pdHksIFwibnVtYmVyXCIsICgpID0+IHtcblx0XHRyZXR1cm4gXCItMFwiO1xuXHR9LCBOdW1iZXIpLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc1VSTCwgXCJVUkxcIiwgKHYpID0+IHYudG9TdHJpbmcoKSwgKHYpID0+IG5ldyBVUkwodikpXG5dO1xuZnVuY3Rpb24gY29tcG9zaXRlVHJhbnNmb3JtYXRpb24oaXNBcHBsaWNhYmxlLCBhbm5vdGF0aW9uLCB0cmFuc2Zvcm0sIHVudHJhbnNmb3JtKSB7XG5cdHJldHVybiB7XG5cdFx0aXNBcHBsaWNhYmxlLFxuXHRcdGFubm90YXRpb24sXG5cdFx0dHJhbnNmb3JtLFxuXHRcdHVudHJhbnNmb3JtXG5cdH07XG59XG5jb25zdCBzeW1ib2xSdWxlID0gY29tcG9zaXRlVHJhbnNmb3JtYXRpb24oKHMsIHN1cGVySnNvbikgPT4ge1xuXHRpZiAoaXNTeW1ib2wocykpIHJldHVybiAhIXN1cGVySnNvbi5zeW1ib2xSZWdpc3RyeS5nZXRJZGVudGlmaWVyKHMpO1xuXHRyZXR1cm4gZmFsc2U7XG59LCAocywgc3VwZXJKc29uKSA9PiB7XG5cdHJldHVybiBbXCJzeW1ib2xcIiwgc3VwZXJKc29uLnN5bWJvbFJlZ2lzdHJ5LmdldElkZW50aWZpZXIocyldO1xufSwgKHYpID0+IHYuZGVzY3JpcHRpb24sIChfLCBhLCBzdXBlckpzb24pID0+IHtcblx0Y29uc3QgdmFsdWUgPSBzdXBlckpzb24uc3ltYm9sUmVnaXN0cnkuZ2V0VmFsdWUoYVsxXSk7XG5cdGlmICghdmFsdWUpIHRocm93IG5ldyBFcnJvcihcIlRyeWluZyB0byBkZXNlcmlhbGl6ZSB1bmtub3duIHN5bWJvbFwiKTtcblx0cmV0dXJuIHZhbHVlO1xufSk7XG5jb25zdCBjb25zdHJ1Y3RvclRvTmFtZSA9IFtcblx0SW50OEFycmF5LFxuXHRVaW50OEFycmF5LFxuXHRJbnQxNkFycmF5LFxuXHRVaW50MTZBcnJheSxcblx0SW50MzJBcnJheSxcblx0VWludDMyQXJyYXksXG5cdEZsb2F0MzJBcnJheSxcblx0RmxvYXQ2NEFycmF5LFxuXHRVaW50OENsYW1wZWRBcnJheVxuXS5yZWR1Y2UoKG9iaiwgY3RvcikgPT4ge1xuXHRvYmpbY3Rvci5uYW1lXSA9IGN0b3I7XG5cdHJldHVybiBvYmo7XG59LCB7fSk7XG5jb25zdCB0eXBlZEFycmF5UnVsZSA9IGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKGlzVHlwZWRBcnJheSwgKHYpID0+IFtcInR5cGVkLWFycmF5XCIsIHYuY29uc3RydWN0b3IubmFtZV0sICh2KSA9PiBbLi4udl0sICh2LCBhKSA9PiB7XG5cdGNvbnN0IGN0b3IgPSBjb25zdHJ1Y3RvclRvTmFtZVthWzFdXTtcblx0aWYgKCFjdG9yKSB0aHJvdyBuZXcgRXJyb3IoXCJUcnlpbmcgdG8gZGVzZXJpYWxpemUgdW5rbm93biB0eXBlZCBhcnJheVwiKTtcblx0cmV0dXJuIG5ldyBjdG9yKHYpO1xufSk7XG5mdW5jdGlvbiBpc0luc3RhbmNlT2ZSZWdpc3RlcmVkQ2xhc3MocG90ZW50aWFsQ2xhc3MsIHN1cGVySnNvbikge1xuXHRpZiAocG90ZW50aWFsQ2xhc3M/LmNvbnN0cnVjdG9yKSByZXR1cm4gISFzdXBlckpzb24uY2xhc3NSZWdpc3RyeS5nZXRJZGVudGlmaWVyKHBvdGVudGlhbENsYXNzLmNvbnN0cnVjdG9yKTtcblx0cmV0dXJuIGZhbHNlO1xufVxuY29uc3QgY2xhc3NSdWxlID0gY29tcG9zaXRlVHJhbnNmb3JtYXRpb24oaXNJbnN0YW5jZU9mUmVnaXN0ZXJlZENsYXNzLCAoY2xhenosIHN1cGVySnNvbikgPT4ge1xuXHRyZXR1cm4gW1wiY2xhc3NcIiwgc3VwZXJKc29uLmNsYXNzUmVnaXN0cnkuZ2V0SWRlbnRpZmllcihjbGF6ei5jb25zdHJ1Y3RvcildO1xufSwgKGNsYXp6LCBzdXBlckpzb24pID0+IHtcblx0Y29uc3QgYWxsb3dlZFByb3BzID0gc3VwZXJKc29uLmNsYXNzUmVnaXN0cnkuZ2V0QWxsb3dlZFByb3BzKGNsYXp6LmNvbnN0cnVjdG9yKTtcblx0aWYgKCFhbGxvd2VkUHJvcHMpIHJldHVybiB7IC4uLmNsYXp6IH07XG5cdGNvbnN0IHJlc3VsdCA9IHt9O1xuXHRhbGxvd2VkUHJvcHMuZm9yRWFjaCgocHJvcCkgPT4ge1xuXHRcdHJlc3VsdFtwcm9wXSA9IGNsYXp6W3Byb3BdO1xuXHR9KTtcblx0cmV0dXJuIHJlc3VsdDtcbn0sICh2LCBhLCBzdXBlckpzb24pID0+IHtcblx0Y29uc3QgY2xhenogPSBzdXBlckpzb24uY2xhc3NSZWdpc3RyeS5nZXRWYWx1ZShhWzFdKTtcblx0aWYgKCFjbGF6eikgdGhyb3cgbmV3IEVycm9yKGBUcnlpbmcgdG8gZGVzZXJpYWxpemUgdW5rbm93biBjbGFzcyAnJHthWzFdfScgLSBjaGVjayBodHRwczovL2dpdGh1Yi5jb20vYmxpdHotanMvc3VwZXJqc29uL2lzc3Vlcy8xMTYjaXNzdWVjb21tZW50LTc3Mzk5NjU2NGApO1xuXHRyZXR1cm4gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKGNsYXp6LnByb3RvdHlwZSksIHYpO1xufSk7XG5jb25zdCBjdXN0b21SdWxlID0gY29tcG9zaXRlVHJhbnNmb3JtYXRpb24oKHZhbHVlLCBzdXBlckpzb24pID0+IHtcblx0cmV0dXJuICEhc3VwZXJKc29uLmN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkuZmluZEFwcGxpY2FibGUodmFsdWUpO1xufSwgKHZhbHVlLCBzdXBlckpzb24pID0+IHtcblx0cmV0dXJuIFtcImN1c3RvbVwiLCBzdXBlckpzb24uY3VzdG9tVHJhbnNmb3JtZXJSZWdpc3RyeS5maW5kQXBwbGljYWJsZSh2YWx1ZSkubmFtZV07XG59LCAodmFsdWUsIHN1cGVySnNvbikgPT4ge1xuXHRyZXR1cm4gc3VwZXJKc29uLmN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkuZmluZEFwcGxpY2FibGUodmFsdWUpLnNlcmlhbGl6ZSh2YWx1ZSk7XG59LCAodiwgYSwgc3VwZXJKc29uKSA9PiB7XG5cdGNvbnN0IHRyYW5zZm9ybWVyID0gc3VwZXJKc29uLmN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkuZmluZEJ5TmFtZShhWzFdKTtcblx0aWYgKCF0cmFuc2Zvcm1lcikgdGhyb3cgbmV3IEVycm9yKFwiVHJ5aW5nIHRvIGRlc2VyaWFsaXplIHVua25vd24gY3VzdG9tIHZhbHVlXCIpO1xuXHRyZXR1cm4gdHJhbnNmb3JtZXIuZGVzZXJpYWxpemUodik7XG59KTtcbmNvbnN0IGNvbXBvc2l0ZVJ1bGVzID0gW1xuXHRjbGFzc1J1bGUsXG5cdHN5bWJvbFJ1bGUsXG5cdGN1c3RvbVJ1bGUsXG5cdHR5cGVkQXJyYXlSdWxlXG5dO1xuY29uc3QgdHJhbnNmb3JtVmFsdWUgPSAodmFsdWUsIHN1cGVySnNvbikgPT4ge1xuXHRjb25zdCBhcHBsaWNhYmxlQ29tcG9zaXRlUnVsZSA9IGZpbmRBcnIoY29tcG9zaXRlUnVsZXMsIChydWxlKSA9PiBydWxlLmlzQXBwbGljYWJsZSh2YWx1ZSwgc3VwZXJKc29uKSk7XG5cdGlmIChhcHBsaWNhYmxlQ29tcG9zaXRlUnVsZSkgcmV0dXJuIHtcblx0XHR2YWx1ZTogYXBwbGljYWJsZUNvbXBvc2l0ZVJ1bGUudHJhbnNmb3JtKHZhbHVlLCBzdXBlckpzb24pLFxuXHRcdHR5cGU6IGFwcGxpY2FibGVDb21wb3NpdGVSdWxlLmFubm90YXRpb24odmFsdWUsIHN1cGVySnNvbilcblx0fTtcblx0Y29uc3QgYXBwbGljYWJsZVNpbXBsZVJ1bGUgPSBmaW5kQXJyKHNpbXBsZVJ1bGVzLCAocnVsZSkgPT4gcnVsZS5pc0FwcGxpY2FibGUodmFsdWUsIHN1cGVySnNvbikpO1xuXHRpZiAoYXBwbGljYWJsZVNpbXBsZVJ1bGUpIHJldHVybiB7XG5cdFx0dmFsdWU6IGFwcGxpY2FibGVTaW1wbGVSdWxlLnRyYW5zZm9ybSh2YWx1ZSwgc3VwZXJKc29uKSxcblx0XHR0eXBlOiBhcHBsaWNhYmxlU2ltcGxlUnVsZS5hbm5vdGF0aW9uXG5cdH07XG59O1xuY29uc3Qgc2ltcGxlUnVsZXNCeUFubm90YXRpb24gPSB7fTtcbnNpbXBsZVJ1bGVzLmZvckVhY2goKHJ1bGUpID0+IHtcblx0c2ltcGxlUnVsZXNCeUFubm90YXRpb25bcnVsZS5hbm5vdGF0aW9uXSA9IHJ1bGU7XG59KTtcbmNvbnN0IHVudHJhbnNmb3JtVmFsdWUgPSAoanNvbiwgdHlwZSwgc3VwZXJKc29uKSA9PiB7XG5cdGlmIChpc0FycmF5JDIodHlwZSkpIHN3aXRjaCAodHlwZVswXSkge1xuXHRcdGNhc2UgXCJzeW1ib2xcIjogcmV0dXJuIHN5bWJvbFJ1bGUudW50cmFuc2Zvcm0oanNvbiwgdHlwZSwgc3VwZXJKc29uKTtcblx0XHRjYXNlIFwiY2xhc3NcIjogcmV0dXJuIGNsYXNzUnVsZS51bnRyYW5zZm9ybShqc29uLCB0eXBlLCBzdXBlckpzb24pO1xuXHRcdGNhc2UgXCJjdXN0b21cIjogcmV0dXJuIGN1c3RvbVJ1bGUudW50cmFuc2Zvcm0oanNvbiwgdHlwZSwgc3VwZXJKc29uKTtcblx0XHRjYXNlIFwidHlwZWQtYXJyYXlcIjogcmV0dXJuIHR5cGVkQXJyYXlSdWxlLnVudHJhbnNmb3JtKGpzb24sIHR5cGUsIHN1cGVySnNvbik7XG5cdFx0ZGVmYXVsdDogdGhyb3cgbmV3IEVycm9yKFwiVW5rbm93biB0cmFuc2Zvcm1hdGlvbjogXCIgKyB0eXBlKTtcblx0fVxuXHRlbHNlIHtcblx0XHRjb25zdCB0cmFuc2Zvcm1hdGlvbiA9IHNpbXBsZVJ1bGVzQnlBbm5vdGF0aW9uW3R5cGVdO1xuXHRcdGlmICghdHJhbnNmb3JtYXRpb24pIHRocm93IG5ldyBFcnJvcihcIlVua25vd24gdHJhbnNmb3JtYXRpb246IFwiICsgdHlwZSk7XG5cdFx0cmV0dXJuIHRyYW5zZm9ybWF0aW9uLnVudHJhbnNmb3JtKGpzb24sIHN1cGVySnNvbik7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9hY2Nlc3NEZWVwLmpzXG5jb25zdCBnZXROdGhLZXkgPSAodmFsdWUsIG4pID0+IHtcblx0aWYgKG4gPiB2YWx1ZS5zaXplKSB0aHJvdyBuZXcgRXJyb3IoXCJpbmRleCBvdXQgb2YgYm91bmRzXCIpO1xuXHRjb25zdCBrZXlzID0gdmFsdWUua2V5cygpO1xuXHR3aGlsZSAobiA+IDApIHtcblx0XHRrZXlzLm5leHQoKTtcblx0XHRuLS07XG5cdH1cblx0cmV0dXJuIGtleXMubmV4dCgpLnZhbHVlO1xufTtcbmZ1bmN0aW9uIHZhbGlkYXRlUGF0aChwYXRoKSB7XG5cdGlmIChpbmNsdWRlcyhwYXRoLCBcIl9fcHJvdG9fX1wiKSkgdGhyb3cgbmV3IEVycm9yKFwiX19wcm90b19fIGlzIG5vdCBhbGxvd2VkIGFzIGEgcHJvcGVydHlcIik7XG5cdGlmIChpbmNsdWRlcyhwYXRoLCBcInByb3RvdHlwZVwiKSkgdGhyb3cgbmV3IEVycm9yKFwicHJvdG90eXBlIGlzIG5vdCBhbGxvd2VkIGFzIGEgcHJvcGVydHlcIik7XG5cdGlmIChpbmNsdWRlcyhwYXRoLCBcImNvbnN0cnVjdG9yXCIpKSB0aHJvdyBuZXcgRXJyb3IoXCJjb25zdHJ1Y3RvciBpcyBub3QgYWxsb3dlZCBhcyBhIHByb3BlcnR5XCIpO1xufVxuY29uc3QgZ2V0RGVlcCA9IChvYmplY3QsIHBhdGgpID0+IHtcblx0dmFsaWRhdGVQYXRoKHBhdGgpO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHBhdGgubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBrZXkgPSBwYXRoW2ldO1xuXHRcdGlmIChpc1NldChvYmplY3QpKSBvYmplY3QgPSBnZXROdGhLZXkob2JqZWN0LCAra2V5KTtcblx0XHRlbHNlIGlmIChpc01hcChvYmplY3QpKSB7XG5cdFx0XHRjb25zdCByb3cgPSAra2V5O1xuXHRcdFx0Y29uc3QgdHlwZSA9ICtwYXRoWysraV0gPT09IDAgPyBcImtleVwiIDogXCJ2YWx1ZVwiO1xuXHRcdFx0Y29uc3Qga2V5T2ZSb3cgPSBnZXROdGhLZXkob2JqZWN0LCByb3cpO1xuXHRcdFx0c3dpdGNoICh0eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJrZXlcIjpcblx0XHRcdFx0XHRvYmplY3QgPSBrZXlPZlJvdztcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0Y2FzZSBcInZhbHVlXCI6XG5cdFx0XHRcdFx0b2JqZWN0ID0gb2JqZWN0LmdldChrZXlPZlJvdyk7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIG9iamVjdCA9IG9iamVjdFtrZXldO1xuXHR9XG5cdHJldHVybiBvYmplY3Q7XG59O1xuY29uc3Qgc2V0RGVlcCA9IChvYmplY3QsIHBhdGgsIG1hcHBlcikgPT4ge1xuXHR2YWxpZGF0ZVBhdGgocGF0aCk7XG5cdGlmIChwYXRoLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG1hcHBlcihvYmplY3QpO1xuXHRsZXQgcGFyZW50ID0gb2JqZWN0O1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHBhdGgubGVuZ3RoIC0gMTsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gcGF0aFtpXTtcblx0XHRpZiAoaXNBcnJheSQyKHBhcmVudCkpIHtcblx0XHRcdGNvbnN0IGluZGV4ID0gK2tleTtcblx0XHRcdHBhcmVudCA9IHBhcmVudFtpbmRleF07XG5cdFx0fSBlbHNlIGlmIChpc1BsYWluT2JqZWN0JDIocGFyZW50KSkgcGFyZW50ID0gcGFyZW50W2tleV07XG5cdFx0ZWxzZSBpZiAoaXNTZXQocGFyZW50KSkge1xuXHRcdFx0Y29uc3Qgcm93ID0gK2tleTtcblx0XHRcdHBhcmVudCA9IGdldE50aEtleShwYXJlbnQsIHJvdyk7XG5cdFx0fSBlbHNlIGlmIChpc01hcChwYXJlbnQpKSB7XG5cdFx0XHRpZiAoaSA9PT0gcGF0aC5sZW5ndGggLSAyKSBicmVhaztcblx0XHRcdGNvbnN0IHJvdyA9ICtrZXk7XG5cdFx0XHRjb25zdCB0eXBlID0gK3BhdGhbKytpXSA9PT0gMCA/IFwia2V5XCIgOiBcInZhbHVlXCI7XG5cdFx0XHRjb25zdCBrZXlPZlJvdyA9IGdldE50aEtleShwYXJlbnQsIHJvdyk7XG5cdFx0XHRzd2l0Y2ggKHR5cGUpIHtcblx0XHRcdFx0Y2FzZSBcImtleVwiOlxuXHRcdFx0XHRcdHBhcmVudCA9IGtleU9mUm93O1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRjYXNlIFwidmFsdWVcIjpcblx0XHRcdFx0XHRwYXJlbnQgPSBwYXJlbnQuZ2V0KGtleU9mUm93KTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0Y29uc3QgbGFzdEtleSA9IHBhdGhbcGF0aC5sZW5ndGggLSAxXTtcblx0aWYgKGlzQXJyYXkkMihwYXJlbnQpKSBwYXJlbnRbK2xhc3RLZXldID0gbWFwcGVyKHBhcmVudFsrbGFzdEtleV0pO1xuXHRlbHNlIGlmIChpc1BsYWluT2JqZWN0JDIocGFyZW50KSkgcGFyZW50W2xhc3RLZXldID0gbWFwcGVyKHBhcmVudFtsYXN0S2V5XSk7XG5cdGlmIChpc1NldChwYXJlbnQpKSB7XG5cdFx0Y29uc3Qgb2xkVmFsdWUgPSBnZXROdGhLZXkocGFyZW50LCArbGFzdEtleSk7XG5cdFx0Y29uc3QgbmV3VmFsdWUgPSBtYXBwZXIob2xkVmFsdWUpO1xuXHRcdGlmIChvbGRWYWx1ZSAhPT0gbmV3VmFsdWUpIHtcblx0XHRcdHBhcmVudC5kZWxldGUob2xkVmFsdWUpO1xuXHRcdFx0cGFyZW50LmFkZChuZXdWYWx1ZSk7XG5cdFx0fVxuXHR9XG5cdGlmIChpc01hcChwYXJlbnQpKSB7XG5cdFx0Y29uc3Qgcm93ID0gK3BhdGhbcGF0aC5sZW5ndGggLSAyXTtcblx0XHRjb25zdCBrZXlUb1JvdyA9IGdldE50aEtleShwYXJlbnQsIHJvdyk7XG5cdFx0c3dpdGNoICgrbGFzdEtleSA9PT0gMCA/IFwia2V5XCIgOiBcInZhbHVlXCIpIHtcblx0XHRcdGNhc2UgXCJrZXlcIjoge1xuXHRcdFx0XHRjb25zdCBuZXdLZXkgPSBtYXBwZXIoa2V5VG9Sb3cpO1xuXHRcdFx0XHRwYXJlbnQuc2V0KG5ld0tleSwgcGFyZW50LmdldChrZXlUb1JvdykpO1xuXHRcdFx0XHRpZiAobmV3S2V5ICE9PSBrZXlUb1JvdykgcGFyZW50LmRlbGV0ZShrZXlUb1Jvdyk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdFx0Y2FzZSBcInZhbHVlXCI6XG5cdFx0XHRcdHBhcmVudC5zZXQoa2V5VG9Sb3csIG1hcHBlcihwYXJlbnQuZ2V0KGtleVRvUm93KSkpO1xuXHRcdFx0XHRicmVhaztcblx0XHR9XG5cdH1cblx0cmV0dXJuIG9iamVjdDtcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9wbGFpbmVyLmpzXG5mdW5jdGlvbiB0cmF2ZXJzZSh0cmVlLCB3YWxrZXIsIG9yaWdpbiA9IFtdKSB7XG5cdGlmICghdHJlZSkgcmV0dXJuO1xuXHRpZiAoIWlzQXJyYXkkMih0cmVlKSkge1xuXHRcdGZvckVhY2godHJlZSwgKHN1YnRyZWUsIGtleSkgPT4gdHJhdmVyc2Uoc3VidHJlZSwgd2Fsa2VyLCBbLi4ub3JpZ2luLCAuLi5wYXJzZVBhdGgoa2V5KV0pKTtcblx0XHRyZXR1cm47XG5cdH1cblx0Y29uc3QgW25vZGVWYWx1ZSwgY2hpbGRyZW5dID0gdHJlZTtcblx0aWYgKGNoaWxkcmVuKSBmb3JFYWNoKGNoaWxkcmVuLCAoY2hpbGQsIGtleSkgPT4ge1xuXHRcdHRyYXZlcnNlKGNoaWxkLCB3YWxrZXIsIFsuLi5vcmlnaW4sIC4uLnBhcnNlUGF0aChrZXkpXSk7XG5cdH0pO1xuXHR3YWxrZXIobm9kZVZhbHVlLCBvcmlnaW4pO1xufVxuZnVuY3Rpb24gYXBwbHlWYWx1ZUFubm90YXRpb25zKHBsYWluLCBhbm5vdGF0aW9ucywgc3VwZXJKc29uKSB7XG5cdHRyYXZlcnNlKGFubm90YXRpb25zLCAodHlwZSwgcGF0aCkgPT4ge1xuXHRcdHBsYWluID0gc2V0RGVlcChwbGFpbiwgcGF0aCwgKHYpID0+IHVudHJhbnNmb3JtVmFsdWUodiwgdHlwZSwgc3VwZXJKc29uKSk7XG5cdH0pO1xuXHRyZXR1cm4gcGxhaW47XG59XG5mdW5jdGlvbiBhcHBseVJlZmVyZW50aWFsRXF1YWxpdHlBbm5vdGF0aW9ucyhwbGFpbiwgYW5ub3RhdGlvbnMpIHtcblx0ZnVuY3Rpb24gYXBwbHkoaWRlbnRpY2FsUGF0aHMsIHBhdGgpIHtcblx0XHRjb25zdCBvYmplY3QgPSBnZXREZWVwKHBsYWluLCBwYXJzZVBhdGgocGF0aCkpO1xuXHRcdGlkZW50aWNhbFBhdGhzLm1hcChwYXJzZVBhdGgpLmZvckVhY2goKGlkZW50aWNhbE9iamVjdFBhdGgpID0+IHtcblx0XHRcdHBsYWluID0gc2V0RGVlcChwbGFpbiwgaWRlbnRpY2FsT2JqZWN0UGF0aCwgKCkgPT4gb2JqZWN0KTtcblx0XHR9KTtcblx0fVxuXHRpZiAoaXNBcnJheSQyKGFubm90YXRpb25zKSkge1xuXHRcdGNvbnN0IFtyb290LCBvdGhlcl0gPSBhbm5vdGF0aW9ucztcblx0XHRyb290LmZvckVhY2goKGlkZW50aWNhbFBhdGgpID0+IHtcblx0XHRcdHBsYWluID0gc2V0RGVlcChwbGFpbiwgcGFyc2VQYXRoKGlkZW50aWNhbFBhdGgpLCAoKSA9PiBwbGFpbik7XG5cdFx0fSk7XG5cdFx0aWYgKG90aGVyKSBmb3JFYWNoKG90aGVyLCBhcHBseSk7XG5cdH0gZWxzZSBmb3JFYWNoKGFubm90YXRpb25zLCBhcHBseSk7XG5cdHJldHVybiBwbGFpbjtcbn1cbmNvbnN0IGlzRGVlcCA9IChvYmplY3QsIHN1cGVySnNvbikgPT4gaXNQbGFpbk9iamVjdCQyKG9iamVjdCkgfHwgaXNBcnJheSQyKG9iamVjdCkgfHwgaXNNYXAob2JqZWN0KSB8fCBpc1NldChvYmplY3QpIHx8IGlzSW5zdGFuY2VPZlJlZ2lzdGVyZWRDbGFzcyhvYmplY3QsIHN1cGVySnNvbik7XG5mdW5jdGlvbiBhZGRJZGVudGl0eShvYmplY3QsIHBhdGgsIGlkZW50aXRpZXMpIHtcblx0Y29uc3QgZXhpc3RpbmdTZXQgPSBpZGVudGl0aWVzLmdldChvYmplY3QpO1xuXHRpZiAoZXhpc3RpbmdTZXQpIGV4aXN0aW5nU2V0LnB1c2gocGF0aCk7XG5cdGVsc2UgaWRlbnRpdGllcy5zZXQob2JqZWN0LCBbcGF0aF0pO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVSZWZlcmVudGlhbEVxdWFsaXR5QW5ub3RhdGlvbnMoaWRlbnRpdGl0ZXMsIGRlZHVwZSkge1xuXHRjb25zdCByZXN1bHQgPSB7fTtcblx0bGV0IHJvb3RFcXVhbGl0eVBhdGhzID0gdm9pZCAwO1xuXHRpZGVudGl0aXRlcy5mb3JFYWNoKChwYXRocykgPT4ge1xuXHRcdGlmIChwYXRocy5sZW5ndGggPD0gMSkgcmV0dXJuO1xuXHRcdGlmICghZGVkdXBlKSBwYXRocyA9IHBhdGhzLm1hcCgocGF0aCkgPT4gcGF0aC5tYXAoU3RyaW5nKSkuc29ydCgoYSwgYikgPT4gYS5sZW5ndGggLSBiLmxlbmd0aCk7XG5cdFx0Y29uc3QgW3JlcHJlc2VudGF0aXZlUGF0aCwgLi4uaWRlbnRpY2FsUGF0aHNdID0gcGF0aHM7XG5cdFx0aWYgKHJlcHJlc2VudGF0aXZlUGF0aC5sZW5ndGggPT09IDApIHJvb3RFcXVhbGl0eVBhdGhzID0gaWRlbnRpY2FsUGF0aHMubWFwKHN0cmluZ2lmeVBhdGgpO1xuXHRcdGVsc2UgcmVzdWx0W3N0cmluZ2lmeVBhdGgocmVwcmVzZW50YXRpdmVQYXRoKV0gPSBpZGVudGljYWxQYXRocy5tYXAoc3RyaW5naWZ5UGF0aCk7XG5cdH0pO1xuXHRpZiAocm9vdEVxdWFsaXR5UGF0aHMpIGlmIChpc0VtcHR5T2JqZWN0KHJlc3VsdCkpIHJldHVybiBbcm9vdEVxdWFsaXR5UGF0aHNdO1xuXHRlbHNlIHJldHVybiBbcm9vdEVxdWFsaXR5UGF0aHMsIHJlc3VsdF07XG5cdGVsc2UgcmV0dXJuIGlzRW1wdHlPYmplY3QocmVzdWx0KSA/IHZvaWQgMCA6IHJlc3VsdDtcbn1cbmNvbnN0IHdhbGtlciA9IChvYmplY3QsIGlkZW50aXRpZXMsIHN1cGVySnNvbiwgZGVkdXBlLCBwYXRoID0gW10sIG9iamVjdHNJblRoaXNQYXRoID0gW10sIHNlZW5PYmplY3RzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkgPT4ge1xuXHRjb25zdCBwcmltaXRpdmUgPSBpc1ByaW1pdGl2ZShvYmplY3QpO1xuXHRpZiAoIXByaW1pdGl2ZSkge1xuXHRcdGFkZElkZW50aXR5KG9iamVjdCwgcGF0aCwgaWRlbnRpdGllcyk7XG5cdFx0Y29uc3Qgc2VlbiA9IHNlZW5PYmplY3RzLmdldChvYmplY3QpO1xuXHRcdGlmIChzZWVuKSByZXR1cm4gZGVkdXBlID8geyB0cmFuc2Zvcm1lZFZhbHVlOiBudWxsIH0gOiBzZWVuO1xuXHR9XG5cdGlmICghaXNEZWVwKG9iamVjdCwgc3VwZXJKc29uKSkge1xuXHRcdGNvbnN0IHRyYW5zZm9ybWVkID0gdHJhbnNmb3JtVmFsdWUob2JqZWN0LCBzdXBlckpzb24pO1xuXHRcdGNvbnN0IHJlc3VsdCA9IHRyYW5zZm9ybWVkID8ge1xuXHRcdFx0dHJhbnNmb3JtZWRWYWx1ZTogdHJhbnNmb3JtZWQudmFsdWUsXG5cdFx0XHRhbm5vdGF0aW9uczogW3RyYW5zZm9ybWVkLnR5cGVdXG5cdFx0fSA6IHsgdHJhbnNmb3JtZWRWYWx1ZTogb2JqZWN0IH07XG5cdFx0aWYgKCFwcmltaXRpdmUpIHNlZW5PYmplY3RzLnNldChvYmplY3QsIHJlc3VsdCk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXHRpZiAoaW5jbHVkZXMob2JqZWN0c0luVGhpc1BhdGgsIG9iamVjdCkpIHJldHVybiB7IHRyYW5zZm9ybWVkVmFsdWU6IG51bGwgfTtcblx0Y29uc3QgdHJhbnNmb3JtYXRpb25SZXN1bHQgPSB0cmFuc2Zvcm1WYWx1ZShvYmplY3QsIHN1cGVySnNvbik7XG5cdGNvbnN0IHRyYW5zZm9ybWVkID0gdHJhbnNmb3JtYXRpb25SZXN1bHQ/LnZhbHVlID8/IG9iamVjdDtcblx0Y29uc3QgdHJhbnNmb3JtZWRWYWx1ZSA9IGlzQXJyYXkkMih0cmFuc2Zvcm1lZCkgPyBbXSA6IHt9O1xuXHRjb25zdCBpbm5lckFubm90YXRpb25zID0ge307XG5cdGZvckVhY2godHJhbnNmb3JtZWQsICh2YWx1ZSwgaW5kZXgpID0+IHtcblx0XHRpZiAoaW5kZXggPT09IFwiX19wcm90b19fXCIgfHwgaW5kZXggPT09IFwiY29uc3RydWN0b3JcIiB8fCBpbmRleCA9PT0gXCJwcm90b3R5cGVcIikgdGhyb3cgbmV3IEVycm9yKGBEZXRlY3RlZCBwcm9wZXJ0eSAke2luZGV4fS4gVGhpcyBpcyBhIHByb3RvdHlwZSBwb2xsdXRpb24gcmlzaywgcGxlYXNlIHJlbW92ZSBpdCBmcm9tIHlvdXIgb2JqZWN0LmApO1xuXHRcdGNvbnN0IHJlY3Vyc2l2ZVJlc3VsdCA9IHdhbGtlcih2YWx1ZSwgaWRlbnRpdGllcywgc3VwZXJKc29uLCBkZWR1cGUsIFsuLi5wYXRoLCBpbmRleF0sIFsuLi5vYmplY3RzSW5UaGlzUGF0aCwgb2JqZWN0XSwgc2Vlbk9iamVjdHMpO1xuXHRcdHRyYW5zZm9ybWVkVmFsdWVbaW5kZXhdID0gcmVjdXJzaXZlUmVzdWx0LnRyYW5zZm9ybWVkVmFsdWU7XG5cdFx0aWYgKGlzQXJyYXkkMihyZWN1cnNpdmVSZXN1bHQuYW5ub3RhdGlvbnMpKSBpbm5lckFubm90YXRpb25zW2luZGV4XSA9IHJlY3Vyc2l2ZVJlc3VsdC5hbm5vdGF0aW9ucztcblx0XHRlbHNlIGlmIChpc1BsYWluT2JqZWN0JDIocmVjdXJzaXZlUmVzdWx0LmFubm90YXRpb25zKSkgZm9yRWFjaChyZWN1cnNpdmVSZXN1bHQuYW5ub3RhdGlvbnMsICh0cmVlLCBrZXkpID0+IHtcblx0XHRcdGlubmVyQW5ub3RhdGlvbnNbZXNjYXBlS2V5KGluZGV4KSArIFwiLlwiICsga2V5XSA9IHRyZWU7XG5cdFx0fSk7XG5cdH0pO1xuXHRjb25zdCByZXN1bHQgPSBpc0VtcHR5T2JqZWN0KGlubmVyQW5ub3RhdGlvbnMpID8ge1xuXHRcdHRyYW5zZm9ybWVkVmFsdWUsXG5cdFx0YW5ub3RhdGlvbnM6ICEhdHJhbnNmb3JtYXRpb25SZXN1bHQgPyBbdHJhbnNmb3JtYXRpb25SZXN1bHQudHlwZV0gOiB2b2lkIDBcblx0fSA6IHtcblx0XHR0cmFuc2Zvcm1lZFZhbHVlLFxuXHRcdGFubm90YXRpb25zOiAhIXRyYW5zZm9ybWF0aW9uUmVzdWx0ID8gW3RyYW5zZm9ybWF0aW9uUmVzdWx0LnR5cGUsIGlubmVyQW5ub3RhdGlvbnNdIDogaW5uZXJBbm5vdGF0aW9uc1xuXHR9O1xuXHRpZiAoIXByaW1pdGl2ZSkgc2Vlbk9iamVjdHMuc2V0KG9iamVjdCwgcmVzdWx0KTtcblx0cmV0dXJuIHJlc3VsdDtcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vaXMtd2hhdEA0LjEuMTYvbm9kZV9tb2R1bGVzL2lzLXdoYXQvZGlzdC9pbmRleC5qc1xuZnVuY3Rpb24gZ2V0VHlwZShwYXlsb2FkKSB7XG5cdHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwocGF5bG9hZCkuc2xpY2UoOCwgLTEpO1xufVxuZnVuY3Rpb24gaXNBcnJheSQxKHBheWxvYWQpIHtcblx0cmV0dXJuIGdldFR5cGUocGF5bG9hZCkgPT09IFwiQXJyYXlcIjtcbn1cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3QkMShwYXlsb2FkKSB7XG5cdGlmIChnZXRUeXBlKHBheWxvYWQpICE9PSBcIk9iamVjdFwiKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihwYXlsb2FkKTtcblx0cmV0dXJuICEhcHJvdG90eXBlICYmIHByb3RvdHlwZS5jb25zdHJ1Y3RvciA9PT0gT2JqZWN0ICYmIHByb3RvdHlwZSA9PT0gT2JqZWN0LnByb3RvdHlwZTtcbn1cbmZ1bmN0aW9uIGlzTnVsbChwYXlsb2FkKSB7XG5cdHJldHVybiBnZXRUeXBlKHBheWxvYWQpID09PSBcIk51bGxcIjtcbn1cbmZ1bmN0aW9uIGlzT25lT2YoYSwgYiwgYywgZCwgZSkge1xuXHRyZXR1cm4gKHZhbHVlKSA9PiBhKHZhbHVlKSB8fCBiKHZhbHVlKSB8fCAhIWMgJiYgYyh2YWx1ZSkgfHwgISFkICYmIGQodmFsdWUpIHx8ICEhZSAmJiBlKHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGlzVW5kZWZpbmVkKHBheWxvYWQpIHtcblx0cmV0dXJuIGdldFR5cGUocGF5bG9hZCkgPT09IFwiVW5kZWZpbmVkXCI7XG59XG5pc09uZU9mKGlzTnVsbCwgaXNVbmRlZmluZWQpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcHktYW55dGhpbmdAMy4wLjUvbm9kZV9tb2R1bGVzL2NvcHktYW55dGhpbmcvZGlzdC9pbmRleC5qc1xuZnVuY3Rpb24gYXNzaWduUHJvcChjYXJyeSwga2V5LCBuZXdWYWwsIG9yaWdpbmFsT2JqZWN0LCBpbmNsdWRlTm9uZW51bWVyYWJsZSkge1xuXHRjb25zdCBwcm9wVHlwZSA9IHt9LnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwob3JpZ2luYWxPYmplY3QsIGtleSkgPyBcImVudW1lcmFibGVcIiA6IFwibm9uZW51bWVyYWJsZVwiO1xuXHRpZiAocHJvcFR5cGUgPT09IFwiZW51bWVyYWJsZVwiKSBjYXJyeVtrZXldID0gbmV3VmFsO1xuXHRpZiAoaW5jbHVkZU5vbmVudW1lcmFibGUgJiYgcHJvcFR5cGUgPT09IFwibm9uZW51bWVyYWJsZVwiKSBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2FycnksIGtleSwge1xuXHRcdHZhbHVlOiBuZXdWYWwsXG5cdFx0ZW51bWVyYWJsZTogZmFsc2UsXG5cdFx0d3JpdGFibGU6IHRydWUsXG5cdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdH0pO1xufVxuZnVuY3Rpb24gY29weSh0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuXHRpZiAoaXNBcnJheSQxKHRhcmdldCkpIHJldHVybiB0YXJnZXQubWFwKChpdGVtKSA9PiBjb3B5KGl0ZW0sIG9wdGlvbnMpKTtcblx0aWYgKCFpc1BsYWluT2JqZWN0JDEodGFyZ2V0KSkgcmV0dXJuIHRhcmdldDtcblx0Y29uc3QgcHJvcHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0YXJnZXQpO1xuXHRjb25zdCBzeW1ib2xzID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyh0YXJnZXQpO1xuXHRyZXR1cm4gWy4uLnByb3BzLCAuLi5zeW1ib2xzXS5yZWR1Y2UoKGNhcnJ5LCBrZXkpID0+IHtcblx0XHRpZiAoaXNBcnJheSQxKG9wdGlvbnMucHJvcHMpICYmICFvcHRpb25zLnByb3BzLmluY2x1ZGVzKGtleSkpIHJldHVybiBjYXJyeTtcblx0XHRjb25zdCB2YWwgPSB0YXJnZXRba2V5XTtcblx0XHRhc3NpZ25Qcm9wKGNhcnJ5LCBrZXksIGNvcHkodmFsLCBvcHRpb25zKSwgdGFyZ2V0LCBvcHRpb25zLm5vbmVudW1lcmFibGUpO1xuXHRcdHJldHVybiBjYXJyeTtcblx0fSwge30pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvaW5kZXguanNcbnZhciBTdXBlckpTT04gPSBjbGFzcyB7XG5cdC8qKlxuXHQqIEBwYXJhbSBkZWR1cGVSZWZlcmVudGlhbEVxdWFsaXRpZXMgIElmIHRydWUsIFN1cGVySlNPTiB3aWxsIG1ha2Ugc3VyZSBvbmx5IG9uZSBpbnN0YW5jZSBvZiByZWZlcmVudGlhbGx5IGVxdWFsIG9iamVjdHMgYXJlIHNlcmlhbGl6ZWQgYW5kIHRoZSByZXN0IGFyZSByZXBsYWNlZCB3aXRoIGBudWxsYC5cblx0Ki9cblx0Y29uc3RydWN0b3IoeyBkZWR1cGUgPSBmYWxzZSB9ID0ge30pIHtcblx0XHR0aGlzLmNsYXNzUmVnaXN0cnkgPSBuZXcgQ2xhc3NSZWdpc3RyeSgpO1xuXHRcdHRoaXMuc3ltYm9sUmVnaXN0cnkgPSBuZXcgUmVnaXN0cnkoKHMpID0+IHMuZGVzY3JpcHRpb24gPz8gXCJcIik7XG5cdFx0dGhpcy5jdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5ID0gbmV3IEN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkoKTtcblx0XHR0aGlzLmFsbG93ZWRFcnJvclByb3BzID0gW107XG5cdFx0dGhpcy5kZWR1cGUgPSBkZWR1cGU7XG5cdH1cblx0c2VyaWFsaXplKG9iamVjdCkge1xuXHRcdGNvbnN0IGlkZW50aXRpZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdGNvbnN0IG91dHB1dCA9IHdhbGtlcihvYmplY3QsIGlkZW50aXRpZXMsIHRoaXMsIHRoaXMuZGVkdXBlKTtcblx0XHRjb25zdCByZXMgPSB7IGpzb246IG91dHB1dC50cmFuc2Zvcm1lZFZhbHVlIH07XG5cdFx0aWYgKG91dHB1dC5hbm5vdGF0aW9ucykgcmVzLm1ldGEgPSB7XG5cdFx0XHQuLi5yZXMubWV0YSxcblx0XHRcdHZhbHVlczogb3V0cHV0LmFubm90YXRpb25zXG5cdFx0fTtcblx0XHRjb25zdCBlcXVhbGl0eUFubm90YXRpb25zID0gZ2VuZXJhdGVSZWZlcmVudGlhbEVxdWFsaXR5QW5ub3RhdGlvbnMoaWRlbnRpdGllcywgdGhpcy5kZWR1cGUpO1xuXHRcdGlmIChlcXVhbGl0eUFubm90YXRpb25zKSByZXMubWV0YSA9IHtcblx0XHRcdC4uLnJlcy5tZXRhLFxuXHRcdFx0cmVmZXJlbnRpYWxFcXVhbGl0aWVzOiBlcXVhbGl0eUFubm90YXRpb25zXG5cdFx0fTtcblx0XHRyZXR1cm4gcmVzO1xuXHR9XG5cdGRlc2VyaWFsaXplKHBheWxvYWQpIHtcblx0XHRjb25zdCB7IGpzb24sIG1ldGEgfSA9IHBheWxvYWQ7XG5cdFx0bGV0IHJlc3VsdCA9IGNvcHkoanNvbik7XG5cdFx0aWYgKG1ldGE/LnZhbHVlcykgcmVzdWx0ID0gYXBwbHlWYWx1ZUFubm90YXRpb25zKHJlc3VsdCwgbWV0YS52YWx1ZXMsIHRoaXMpO1xuXHRcdGlmIChtZXRhPy5yZWZlcmVudGlhbEVxdWFsaXRpZXMpIHJlc3VsdCA9IGFwcGx5UmVmZXJlbnRpYWxFcXVhbGl0eUFubm90YXRpb25zKHJlc3VsdCwgbWV0YS5yZWZlcmVudGlhbEVxdWFsaXRpZXMpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0c3RyaW5naWZ5KG9iamVjdCkge1xuXHRcdHJldHVybiBKU09OLnN0cmluZ2lmeSh0aGlzLnNlcmlhbGl6ZShvYmplY3QpKTtcblx0fVxuXHRwYXJzZShzdHJpbmcpIHtcblx0XHRyZXR1cm4gdGhpcy5kZXNlcmlhbGl6ZShKU09OLnBhcnNlKHN0cmluZykpO1xuXHR9XG5cdHJlZ2lzdGVyQ2xhc3Modiwgb3B0aW9ucykge1xuXHRcdHRoaXMuY2xhc3NSZWdpc3RyeS5yZWdpc3Rlcih2LCBvcHRpb25zKTtcblx0fVxuXHRyZWdpc3RlclN5bWJvbCh2LCBpZGVudGlmaWVyKSB7XG5cdFx0dGhpcy5zeW1ib2xSZWdpc3RyeS5yZWdpc3Rlcih2LCBpZGVudGlmaWVyKTtcblx0fVxuXHRyZWdpc3RlckN1c3RvbSh0cmFuc2Zvcm1lciwgbmFtZSkge1xuXHRcdHRoaXMuY3VzdG9tVHJhbnNmb3JtZXJSZWdpc3RyeS5yZWdpc3Rlcih7XG5cdFx0XHRuYW1lLFxuXHRcdFx0Li4udHJhbnNmb3JtZXJcblx0XHR9KTtcblx0fVxuXHRhbGxvd0Vycm9yUHJvcHMoLi4ucHJvcHMpIHtcblx0XHR0aGlzLmFsbG93ZWRFcnJvclByb3BzLnB1c2goLi4ucHJvcHMpO1xuXHR9XG59O1xuU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZSA9IG5ldyBTdXBlckpTT04oKTtcblN1cGVySlNPTi5zZXJpYWxpemUgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLnNlcmlhbGl6ZS5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLmRlc2VyaWFsaXplID0gU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZS5kZXNlcmlhbGl6ZS5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnN0cmluZ2lmeSA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2Uuc3RyaW5naWZ5LmJpbmQoU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZSk7XG5TdXBlckpTT04ucGFyc2UgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLnBhcnNlLmJpbmQoU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZSk7XG5TdXBlckpTT04ucmVnaXN0ZXJDbGFzcyA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UucmVnaXN0ZXJDbGFzcy5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnJlZ2lzdGVyU3ltYm9sID0gU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZS5yZWdpc3RlclN5bWJvbC5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnJlZ2lzdGVyQ3VzdG9tID0gU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZS5yZWdpc3RlckN1c3RvbS5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLmFsbG93RXJyb3JQcm9wcyA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UuYWxsb3dFcnJvclByb3BzLmJpbmQoU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZSk7XG5TdXBlckpTT04uc2VyaWFsaXplO1xuU3VwZXJKU09OLmRlc2VyaWFsaXplO1xuU3VwZXJKU09OLnN0cmluZ2lmeTtcblN1cGVySlNPTi5wYXJzZTtcblN1cGVySlNPTi5yZWdpc3RlckNsYXNzO1xuU3VwZXJKU09OLnJlZ2lzdGVyQ3VzdG9tO1xuU3VwZXJKU09OLnJlZ2lzdGVyU3ltYm9sO1xuU3VwZXJKU09OLmFsbG93RXJyb3JQcm9wcztcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9icm9hZGNhc3QtY2hhbm5lbC9jb250ZXh0LnRzXG5jb25zdCBfX0RFVlRPT0xTX0tJVF9CUk9BRENBU1RfTUVTU0FHSU5HX0VWRU5UX0tFWSA9IFwiX19kZXZ0b29scy1raXQtYnJvYWRjYXN0LW1lc3NhZ2luZy1ldmVudC1rZXlfX1wiO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2Jyb2FkY2FzdC1jaGFubmVsL2luZGV4LnRzXG5jb25zdCBCUk9BRENBU1RfQ0hBTk5FTF9OQU1FID0gXCJfX2RldnRvb2xzLWtpdDpicm9hZGNhc3QtY2hhbm5lbF9fXCI7XG5mdW5jdGlvbiBjcmVhdGVCcm9hZGNhc3RDaGFubmVsKCkge1xuXHRjb25zdCBjaGFubmVsID0gbmV3IEJyb2FkY2FzdENoYW5uZWwoQlJPQURDQVNUX0NIQU5ORUxfTkFNRSk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdGNoYW5uZWwucG9zdE1lc3NhZ2UoU3VwZXJKU09OLnN0cmluZ2lmeSh7XG5cdFx0XHRcdGV2ZW50OiBfX0RFVlRPT0xTX0tJVF9CUk9BRENBU1RfTUVTU0FHSU5HX0VWRU5UX0tFWSxcblx0XHRcdFx0ZGF0YVxuXHRcdFx0fSkpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRjaGFubmVsLm9ubWVzc2FnZSA9IChldmVudCkgPT4ge1xuXHRcdFx0XHRjb25zdCBwYXJzZWQgPSBTdXBlckpTT04ucGFyc2UoZXZlbnQuZGF0YSk7XG5cdFx0XHRcdGlmIChwYXJzZWQuZXZlbnQgPT09IFwiX19kZXZ0b29scy1raXQtYnJvYWRjYXN0LW1lc3NhZ2luZy1ldmVudC1rZXlfX1wiKSBoYW5kbGVyKHBhcnNlZC5kYXRhKTtcblx0XHRcdH07XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2VsZWN0cm9uL2NvbnRleHQudHNcbmNvbnN0IF9fRUxFQ1RST05fQ0xJRU5UX0NPTlRFWFRfXyA9IFwiZWxlY3Ryb246Y2xpZW50LWNvbnRleHRcIjtcbmNvbnN0IF9fRUxFQ1RST05fUlBPWFlfQ09OVEVYVF9fID0gXCJlbGVjdHJvbjpwcm94eS1jb250ZXh0XCI7XG5jb25zdCBfX0VMRUNUUk9OX1NFUlZFUl9DT05URVhUX18gPSBcImVsZWN0cm9uOnNlcnZlci1jb250ZXh0XCI7XG5jb25zdCBfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18gPSB7XG5cdENMSUVOVF9UT19QUk9YWTogXCJjbGllbnQtPnByb3h5XCIsXG5cdFBST1hZX1RPX0NMSUVOVDogXCJwcm94eS0+Y2xpZW50XCIsXG5cdFBST1hZX1RPX1NFUlZFUjogXCJwcm94eS0+c2VydmVyXCIsXG5cdFNFUlZFUl9UT19QUk9YWTogXCJzZXJ2ZXItPnByb3h5XCJcbn07XG5mdW5jdGlvbiBnZXRFbGVjdHJvbkNsaWVudENvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19FTEVDVFJPTl9DTElFTlRfQ09OVEVYVF9fXTtcbn1cbmZ1bmN0aW9uIHNldEVsZWN0cm9uQ2xpZW50Q29udGV4dChjb250ZXh0KSB7XG5cdHRhcmdldFtfX0VMRUNUUk9OX0NMSUVOVF9DT05URVhUX19dID0gY29udGV4dDtcbn1cbmZ1bmN0aW9uIGdldEVsZWN0cm9uUHJveHlDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fRUxFQ1RST05fUlBPWFlfQ09OVEVYVF9fXTtcbn1cbmZ1bmN0aW9uIHNldEVsZWN0cm9uUHJveHlDb250ZXh0KGNvbnRleHQpIHtcblx0dGFyZ2V0W19fRUxFQ1RST05fUlBPWFlfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG5mdW5jdGlvbiBnZXRFbGVjdHJvblNlcnZlckNvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19FTEVDVFJPTl9TRVJWRVJfQ09OVEVYVF9fXTtcbn1cbmZ1bmN0aW9uIHNldEVsZWN0cm9uU2VydmVyQ29udGV4dChjb250ZXh0KSB7XG5cdHRhcmdldFtfX0VMRUNUUk9OX1NFUlZFUl9DT05URVhUX19dID0gY29udGV4dDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9lbGVjdHJvbi9jbGllbnQudHNcbmZ1bmN0aW9uIGNyZWF0ZUVsZWN0cm9uQ2xpZW50Q2hhbm5lbCgpIHtcblx0Y29uc3Qgc29ja2V0ID0gZ2V0RWxlY3Ryb25DbGllbnRDb250ZXh0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdHNvY2tldC5lbWl0KF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5DTElFTlRfVE9fUFJPWFksIFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRzb2NrZXQub24oX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlBST1hZX1RPX0NMSUVOVCwgKGUpID0+IHtcblx0XHRcdFx0aGFuZGxlcihTdXBlckpTT04ucGFyc2UoZSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2VsZWN0cm9uL3Byb3h5LnRzXG5mdW5jdGlvbiBjcmVhdGVFbGVjdHJvblByb3h5Q2hhbm5lbCgpIHtcblx0Y29uc3Qgc29ja2V0ID0gZ2V0RWxlY3Ryb25Qcm94eUNvbnRleHQoKTtcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4ge30sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRzb2NrZXQub24oX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlNFUlZFUl9UT19QUk9YWSwgKGRhdGEpID0+IHtcblx0XHRcdFx0c29ja2V0LmJyb2FkY2FzdC5lbWl0KF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5QUk9YWV9UT19DTElFTlQsIGRhdGEpO1xuXHRcdFx0fSk7XG5cdFx0XHRzb2NrZXQub24oX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLkNMSUVOVF9UT19QUk9YWSwgKGRhdGEpID0+IHtcblx0XHRcdFx0c29ja2V0LmJyb2FkY2FzdC5lbWl0KF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5QUk9YWV9UT19TRVJWRVIsIGRhdGEpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2VsZWN0cm9uL3NlcnZlci50c1xuZnVuY3Rpb24gY3JlYXRlRWxlY3Ryb25TZXJ2ZXJDaGFubmVsKCkge1xuXHRjb25zdCBzb2NrZXQgPSBnZXRFbGVjdHJvblNlcnZlckNvbnRleHQoKTtcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4ge1xuXHRcdFx0c29ja2V0LmVtaXQoX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlNFUlZFUl9UT19QUk9YWSwgU3VwZXJKU09OLnN0cmluZ2lmeShkYXRhKSk7XG5cdFx0fSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHtcblx0XHRcdHNvY2tldC5vbihfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uUFJPWFlfVE9fU0VSVkVSLCAoZGF0YSkgPT4ge1xuXHRcdFx0XHRoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShkYXRhKSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvZXh0ZW5zaW9uL2NvbnRleHQudHNcbmNvbnN0IF9fRVhURU5TSU9OX0NMSUVOVF9DT05URVhUX18gPSBcImVsZWN0cm9uOmNsaWVudC1jb250ZXh0XCI7XG5jb25zdCBfX0RFVlRPT0xTX0tJVF9FWFRFTlNJT05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fID0ge1xuXHRDTElFTlRfVE9fUFJPWFk6IFwiY2xpZW50LT5wcm94eVwiLFxuXHRQUk9YWV9UT19DTElFTlQ6IFwicHJveHktPmNsaWVudFwiLFxuXHRQUk9YWV9UT19TRVJWRVI6IFwicHJveHktPnNlcnZlclwiLFxuXHRTRVJWRVJfVE9fUFJPWFk6IFwic2VydmVyLT5wcm94eVwiXG59O1xuZnVuY3Rpb24gZ2V0RXh0ZW5zaW9uQ2xpZW50Q29udGV4dCgpIHtcblx0cmV0dXJuIHRhcmdldFtfX0VYVEVOU0lPTl9DTElFTlRfQ09OVEVYVF9fXTtcbn1cbmZ1bmN0aW9uIHNldEV4dGVuc2lvbkNsaWVudENvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19FWFRFTlNJT05fQ0xJRU5UX0NPTlRFWFRfX10gPSBjb250ZXh0O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2V4dGVuc2lvbi9jbGllbnQudHNcbmZ1bmN0aW9uIGNyZWF0ZUV4dGVuc2lvbkNsaWVudENoYW5uZWwoKSB7XG5cdGxldCBkaXNjb25uZWN0ZWQgPSBmYWxzZTtcblx0bGV0IHBvcnQgPSBudWxsO1xuXHRsZXQgcmVjb25uZWN0VGltZXIgPSBudWxsO1xuXHRsZXQgb25NZXNzYWdlSGFuZGxlciA9IG51bGw7XG5cdGZ1bmN0aW9uIGNvbm5lY3QoKSB7XG5cdFx0dHJ5IHtcblx0XHRcdGNsZWFyVGltZW91dChyZWNvbm5lY3RUaW1lcik7XG5cdFx0XHRwb3J0ID0gY2hyb21lLnJ1bnRpbWUuY29ubmVjdCh7IG5hbWU6IGAke2Nocm9tZS5kZXZ0b29scy5pbnNwZWN0ZWRXaW5kb3cudGFiSWR9YCB9KTtcblx0XHRcdHNldEV4dGVuc2lvbkNsaWVudENvbnRleHQocG9ydCk7XG5cdFx0XHRkaXNjb25uZWN0ZWQgPSBmYWxzZTtcblx0XHRcdHBvcnQ/Lm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihvbk1lc3NhZ2VIYW5kbGVyKTtcblx0XHRcdHBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKCgpID0+IHtcblx0XHRcdFx0ZGlzY29ubmVjdGVkID0gdHJ1ZTtcblx0XHRcdFx0cG9ydD8ub25NZXNzYWdlLnJlbW92ZUxpc3RlbmVyKG9uTWVzc2FnZUhhbmRsZXIpO1xuXHRcdFx0XHRyZWNvbm5lY3RUaW1lciA9IHNldFRpbWVvdXQoY29ubmVjdCwgMWUzKTtcblx0XHRcdH0pO1xuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdGRpc2Nvbm5lY3RlZCA9IHRydWU7XG5cdFx0fVxuXHR9XG5cdGNvbm5lY3QoKTtcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4ge1xuXHRcdFx0aWYgKGRpc2Nvbm5lY3RlZCkgcmV0dXJuO1xuXHRcdFx0cG9ydD8ucG9zdE1lc3NhZ2UoU3VwZXJKU09OLnN0cmluZ2lmeShkYXRhKSk7XG5cdFx0fSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHtcblx0XHRcdG9uTWVzc2FnZUhhbmRsZXIgPSAoZGF0YSkgPT4ge1xuXHRcdFx0XHRpZiAoZGlzY29ubmVjdGVkKSByZXR1cm47XG5cdFx0XHRcdGhhbmRsZXIoU3VwZXJKU09OLnBhcnNlKGRhdGEpKTtcblx0XHRcdH07XG5cdFx0XHRwb3J0Py5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlSGFuZGxlcik7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2V4dGVuc2lvbi9wcm94eS50c1xuZnVuY3Rpb24gY3JlYXRlRXh0ZW5zaW9uUHJveHlDaGFubmVsKCkge1xuXHRjb25zdCBwb3J0ID0gY2hyb21lLnJ1bnRpbWUuY29ubmVjdCh7IG5hbWU6IFwiY29udGVudC1zY3JpcHRcIiB9KTtcblx0ZnVuY3Rpb24gc2VuZE1lc3NhZ2VUb1VzZXJBcHAocGF5bG9hZCkge1xuXHRcdHdpbmRvdy5wb3N0TWVzc2FnZSh7XG5cdFx0XHRzb3VyY2U6IF9fREVWVE9PTFNfS0lUX0VYVEVOU0lPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uUFJPWFlfVE9fU0VSVkVSLFxuXHRcdFx0cGF5bG9hZFxuXHRcdH0sIFwiKlwiKTtcblx0fVxuXHRmdW5jdGlvbiBzZW5kTWVzc2FnZVRvRGV2VG9vbHNDbGllbnQoZSkge1xuXHRcdGlmIChlLmRhdGEgJiYgZS5kYXRhLnNvdXJjZSA9PT0gX19ERVZUT09MU19LSVRfRVhURU5TSU9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5TRVJWRVJfVE9fUFJPWFkpIHRyeSB7XG5cdFx0XHRwb3J0LnBvc3RNZXNzYWdlKGUuZGF0YS5wYXlsb2FkKTtcblx0XHR9IGNhdGNoIChlKSB7fVxuXHR9XG5cdHBvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKHNlbmRNZXNzYWdlVG9Vc2VyQXBwKTtcblx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHNlbmRNZXNzYWdlVG9EZXZUb29sc0NsaWVudCk7XG5cdHBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKCgpID0+IHtcblx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgc2VuZE1lc3NhZ2VUb0RldlRvb2xzQ2xpZW50KTtcblx0XHRzZW5kTWVzc2FnZVRvVXNlckFwcChTdXBlckpTT04uc3RyaW5naWZ5KHsgZXZlbnQ6IFwic2h1dGRvd25cIiB9KSk7XG5cdH0pO1xuXHRzZW5kTWVzc2FnZVRvVXNlckFwcChTdXBlckpTT04uc3RyaW5naWZ5KHsgZXZlbnQ6IFwiaW5pdFwiIH0pKTtcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4ge30sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2V4dGVuc2lvbi9zZXJ2ZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZUV4dGVuc2lvblNlcnZlckNoYW5uZWwoKSB7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdHdpbmRvdy5wb3N0TWVzc2FnZSh7XG5cdFx0XHRcdHNvdXJjZTogX19ERVZUT09MU19LSVRfRVhURU5TSU9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5TRVJWRVJfVE9fUFJPWFksXG5cdFx0XHRcdHBheWxvYWQ6IFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSlcblx0XHRcdH0sIFwiKlwiKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0Y29uc3QgbGlzdGVuZXIgPSAoZXZlbnQpID0+IHtcblx0XHRcdFx0aWYgKGV2ZW50LmRhdGEuc291cmNlID09PSBfX0RFVlRPT0xTX0tJVF9FWFRFTlNJT05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlBST1hZX1RPX1NFUlZFUiAmJiBldmVudC5kYXRhLnBheWxvYWQpIGhhbmRsZXIoU3VwZXJKU09OLnBhcnNlKGV2ZW50LmRhdGEucGF5bG9hZCkpO1xuXHRcdFx0fTtcblx0XHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBsaXN0ZW5lcik7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgbGlzdGVuZXIpO1xuXHRcdFx0fTtcblx0XHR9XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvaWZyYW1lL2NvbnRleHQudHNcbmNvbnN0IF9fREVWVE9PTFNfS0lUX0lGUkFNRV9NRVNTQUdJTkdfRVZFTlRfS0VZID0gXCJfX2RldnRvb2xzLWtpdC1pZnJhbWUtbWVzc2FnaW5nLWV2ZW50LWtleV9fXCI7XG5jb25zdCBfX0lGUkFNRV9TRVJWRVJfQ09OVEVYVF9fID0gXCJpZnJhbWU6c2VydmVyLWNvbnRleHRcIjtcbmZ1bmN0aW9uIGdldElmcmFtZVNlcnZlckNvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19JRlJBTUVfU0VSVkVSX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRJZnJhbWVTZXJ2ZXJDb250ZXh0KGNvbnRleHQpIHtcblx0dGFyZ2V0W19fSUZSQU1FX1NFUlZFUl9DT05URVhUX19dID0gY29udGV4dDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9pZnJhbWUvY2xpZW50LnRzXG5mdW5jdGlvbiBjcmVhdGVJZnJhbWVDbGllbnRDaGFubmVsKCkge1xuXHRpZiAoIWlzQnJvd3NlcikgcmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4ge30sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7fVxuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB3aW5kb3cucGFyZW50LnBvc3RNZXNzYWdlKFN1cGVySlNPTi5zdHJpbmdpZnkoe1xuXHRcdFx0ZXZlbnQ6IF9fREVWVE9PTFNfS0lUX0lGUkFNRV9NRVNTQUdJTkdfRVZFTlRfS0VZLFxuXHRcdFx0ZGF0YVxuXHRcdH0pLCBcIipcIiksXG5cdFx0b246IChoYW5kbGVyKSA9PiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBwYXJzZWQgPSBTdXBlckpTT04ucGFyc2UoZXZlbnQuZGF0YSk7XG5cdFx0XHRcdGlmIChldmVudC5zb3VyY2UgPT09IHdpbmRvdy5wYXJlbnQgJiYgcGFyc2VkLmV2ZW50ID09PSBcIl9fZGV2dG9vbHMta2l0LWlmcmFtZS1tZXNzYWdpbmctZXZlbnQta2V5X19cIikgaGFuZGxlcihwYXJzZWQuZGF0YSk7XG5cdFx0XHR9IGNhdGNoIChlKSB7fVxuXHRcdH0pXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvaWZyYW1lL3NlcnZlci50c1xuZnVuY3Rpb24gY3JlYXRlSWZyYW1lU2VydmVyQ2hhbm5lbCgpIHtcblx0aWYgKCFpc0Jyb3dzZXIpIHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHt9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge31cblx0fTtcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4ge1xuXHRcdFx0Z2V0SWZyYW1lU2VydmVyQ29udGV4dCgpPy5jb250ZW50V2luZG93Py5wb3N0TWVzc2FnZShTdXBlckpTT04uc3RyaW5naWZ5KHtcblx0XHRcdFx0ZXZlbnQ6IF9fREVWVE9PTFNfS0lUX0lGUkFNRV9NRVNTQUdJTkdfRVZFTlRfS0VZLFxuXHRcdFx0XHRkYXRhXG5cdFx0XHR9KSwgXCIqXCIpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlmcmFtZSA9IGdldElmcmFtZVNlcnZlckNvbnRleHQoKTtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBwYXJzZWQgPSBTdXBlckpTT04ucGFyc2UoZXZlbnQuZGF0YSk7XG5cdFx0XHRcdFx0aWYgKGV2ZW50LnNvdXJjZSA9PT0gaWZyYW1lPy5jb250ZW50V2luZG93ICYmIHBhcnNlZC5ldmVudCA9PT0gXCJfX2RldnRvb2xzLWtpdC1pZnJhbWUtbWVzc2FnaW5nLWV2ZW50LWtleV9fXCIpIGhhbmRsZXIocGFyc2VkLmRhdGEpO1xuXHRcdFx0XHR9IGNhdGNoIChlKSB7fVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL3ZpdGUvY29udGV4dC50c1xuY29uc3QgX19ERVZUT09MU19LSVRfVklURV9NRVNTQUdJTkdfRVZFTlRfS0VZID0gXCJfX2RldnRvb2xzLWtpdC12aXRlLW1lc3NhZ2luZy1ldmVudC1rZXlfX1wiO1xuY29uc3QgX19WSVRFX0NMSUVOVF9DT05URVhUX18gPSBcInZpdGU6Y2xpZW50LWNvbnRleHRcIjtcbmNvbnN0IF9fVklURV9TRVJWRVJfQ09OVEVYVF9fID0gXCJ2aXRlOnNlcnZlci1jb250ZXh0XCI7XG5mdW5jdGlvbiBnZXRWaXRlQ2xpZW50Q29udGV4dCgpIHtcblx0cmV0dXJuIHRhcmdldFtfX1ZJVEVfQ0xJRU5UX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRWaXRlQ2xpZW50Q29udGV4dChjb250ZXh0KSB7XG5cdHRhcmdldFtfX1ZJVEVfQ0xJRU5UX0NPTlRFWFRfX10gPSBjb250ZXh0O1xufVxuZnVuY3Rpb24gZ2V0Vml0ZVNlcnZlckNvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19WSVRFX1NFUlZFUl9DT05URVhUX19dO1xufVxuZnVuY3Rpb24gc2V0Vml0ZVNlcnZlckNvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19WSVRFX1NFUlZFUl9DT05URVhUX19dID0gY29udGV4dDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy92aXRlL2NsaWVudC50c1xuZnVuY3Rpb24gY3JlYXRlVml0ZUNsaWVudENoYW5uZWwoKSB7XG5cdGNvbnN0IGNsaWVudCA9IGdldFZpdGVDbGllbnRDb250ZXh0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdGNsaWVudD8uc2VuZChfX0RFVlRPT0xTX0tJVF9WSVRFX01FU1NBR0lOR19FVkVOVF9LRVksIFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRjbGllbnQ/Lm9uKF9fREVWVE9PTFNfS0lUX1ZJVEVfTUVTU0FHSU5HX0VWRU5UX0tFWSwgKGV2ZW50KSA9PiB7XG5cdFx0XHRcdGhhbmRsZXIoU3VwZXJKU09OLnBhcnNlKGV2ZW50KSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvdml0ZS9zZXJ2ZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZVZpdGVTZXJ2ZXJDaGFubmVsKCkge1xuXHRjb25zdCB2aXRlU2VydmVyID0gZ2V0Vml0ZVNlcnZlckNvbnRleHQoKTtcblx0Y29uc3Qgd3MgPSB2aXRlU2VydmVyLmhvdCA/PyB2aXRlU2VydmVyLndzO1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB3cz8uc2VuZChfX0RFVlRPT0xTX0tJVF9WSVRFX01FU1NBR0lOR19FVkVOVF9LRVksIFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSkpLFxuXHRcdG9uOiAoaGFuZGxlcikgPT4gd3M/Lm9uKF9fREVWVE9PTFNfS0lUX1ZJVEVfTUVTU0FHSU5HX0VWRU5UX0tFWSwgKGV2ZW50KSA9PiB7XG5cdFx0XHRoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShldmVudCkpO1xuXHRcdH0pXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL2luZGV4LnRzXG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX01FU1NBR0VfQ0hBTk5FTFNfXyA/Pz0gW107XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1JQQ19DTElFTlRfXyA/Pz0gbnVsbDtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfUlBDX1NFUlZFUl9fID8/PSBudWxsO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9WSVRFX1JQQ19DTElFTlRfXyA/Pz0gbnVsbDtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVklURV9SUENfU0VSVkVSX18gPz89IG51bGw7XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0JST0FEQ0FTVF9SUENfU0VSVkVSX18gPz89IG51bGw7XG5mdW5jdGlvbiBzZXRScGNDbGllbnRUb0dsb2JhbChycGMpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9SUENfQ0xJRU5UX18gPSBycGM7XG59XG5mdW5jdGlvbiBzZXRScGNTZXJ2ZXJUb0dsb2JhbChycGMpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9SUENfU0VSVkVSX18gPSBycGM7XG59XG5mdW5jdGlvbiBnZXRScGNDbGllbnQoKSB7XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1JQQ19DTElFTlRfXztcbn1cbmZ1bmN0aW9uIGdldFJwY1NlcnZlcigpIHtcblx0cmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfUlBDX1NFUlZFUl9fO1xufVxuZnVuY3Rpb24gc2V0Vml0ZVJwY0NsaWVudFRvR2xvYmFsKHJwYykge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1ZJVEVfUlBDX0NMSUVOVF9fID0gcnBjO1xufVxuZnVuY3Rpb24gc2V0Vml0ZVJwY1NlcnZlclRvR2xvYmFsKHJwYykge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1ZJVEVfUlBDX1NFUlZFUl9fID0gcnBjO1xufVxuZnVuY3Rpb24gZ2V0Vml0ZVJwY0NsaWVudCgpIHtcblx0cmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVklURV9SUENfQ0xJRU5UX187XG59XG5mdW5jdGlvbiBnZXRWaXRlUnBjU2VydmVyKCkge1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9WSVRFX1JQQ19TRVJWRVJfXztcbn1cbmZ1bmN0aW9uIGdldENoYW5uZWwocHJlc2V0LCBob3N0ID0gXCJjbGllbnRcIikge1xuXHRjb25zdCBjaGFubmVsID0ge1xuXHRcdGlmcmFtZToge1xuXHRcdFx0Y2xpZW50OiBjcmVhdGVJZnJhbWVDbGllbnRDaGFubmVsLFxuXHRcdFx0c2VydmVyOiBjcmVhdGVJZnJhbWVTZXJ2ZXJDaGFubmVsXG5cdFx0fVtob3N0XSxcblx0XHRlbGVjdHJvbjoge1xuXHRcdFx0Y2xpZW50OiBjcmVhdGVFbGVjdHJvbkNsaWVudENoYW5uZWwsXG5cdFx0XHRwcm94eTogY3JlYXRlRWxlY3Ryb25Qcm94eUNoYW5uZWwsXG5cdFx0XHRzZXJ2ZXI6IGNyZWF0ZUVsZWN0cm9uU2VydmVyQ2hhbm5lbFxuXHRcdH1baG9zdF0sXG5cdFx0dml0ZToge1xuXHRcdFx0Y2xpZW50OiBjcmVhdGVWaXRlQ2xpZW50Q2hhbm5lbCxcblx0XHRcdHNlcnZlcjogY3JlYXRlVml0ZVNlcnZlckNoYW5uZWxcblx0XHR9W2hvc3RdLFxuXHRcdGJyb2FkY2FzdDoge1xuXHRcdFx0Y2xpZW50OiBjcmVhdGVCcm9hZGNhc3RDaGFubmVsLFxuXHRcdFx0c2VydmVyOiBjcmVhdGVCcm9hZGNhc3RDaGFubmVsXG5cdFx0fVtob3N0XSxcblx0XHRleHRlbnNpb246IHtcblx0XHRcdGNsaWVudDogY3JlYXRlRXh0ZW5zaW9uQ2xpZW50Q2hhbm5lbCxcblx0XHRcdHByb3h5OiBjcmVhdGVFeHRlbnNpb25Qcm94eUNoYW5uZWwsXG5cdFx0XHRzZXJ2ZXI6IGNyZWF0ZUV4dGVuc2lvblNlcnZlckNoYW5uZWxcblx0XHR9W2hvc3RdXG5cdH1bcHJlc2V0XTtcblx0cmV0dXJuIGNoYW5uZWwoKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJwY0NsaWVudChmdW5jdGlvbnMsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGNoYW5uZWw6IF9jaGFubmVsLCBvcHRpb25zOiBfb3B0aW9ucywgcHJlc2V0IH0gPSBvcHRpb25zO1xuXHRjb25zdCBjaGFubmVsID0gcHJlc2V0ID8gZ2V0Q2hhbm5lbChwcmVzZXQpIDogX2NoYW5uZWw7XG5cdGNvbnN0IHJwYyA9IGNyZWF0ZUJpcnBjKGZ1bmN0aW9ucywge1xuXHRcdC4uLl9vcHRpb25zLFxuXHRcdC4uLmNoYW5uZWwsXG5cdFx0dGltZW91dDogLTFcblx0fSk7XG5cdGlmIChwcmVzZXQgPT09IFwidml0ZVwiKSB7XG5cdFx0c2V0Vml0ZVJwY0NsaWVudFRvR2xvYmFsKHJwYyk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHNldFJwY0NsaWVudFRvR2xvYmFsKHJwYyk7XG5cdHJldHVybiBycGM7XG59XG5mdW5jdGlvbiBjcmVhdGVScGNTZXJ2ZXIoZnVuY3Rpb25zLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBjaGFubmVsOiBfY2hhbm5lbCwgb3B0aW9uczogX29wdGlvbnMsIHByZXNldCB9ID0gb3B0aW9ucztcblx0Y29uc3QgY2hhbm5lbCA9IHByZXNldCA/IGdldENoYW5uZWwocHJlc2V0LCBcInNlcnZlclwiKSA6IF9jaGFubmVsO1xuXHRjb25zdCBycGNTZXJ2ZXIgPSBnZXRScGNTZXJ2ZXIoKTtcblx0aWYgKCFycGNTZXJ2ZXIpIHtcblx0XHRjb25zdCBncm91cCA9IGNyZWF0ZUJpcnBjR3JvdXAoZnVuY3Rpb25zLCBbY2hhbm5lbF0sIHtcblx0XHRcdC4uLl9vcHRpb25zLFxuXHRcdFx0dGltZW91dDogLTFcblx0XHR9KTtcblx0XHRpZiAocHJlc2V0ID09PSBcInZpdGVcIikge1xuXHRcdFx0c2V0Vml0ZVJwY1NlcnZlclRvR2xvYmFsKGdyb3VwKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0c2V0UnBjU2VydmVyVG9HbG9iYWwoZ3JvdXApO1xuXHR9IGVsc2UgcnBjU2VydmVyLnVwZGF0ZUNoYW5uZWxzKChjaGFubmVscykgPT4ge1xuXHRcdGNoYW5uZWxzLnB1c2goY2hhbm5lbCk7XG5cdH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlUnBjUHJveHkob3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHsgY2hhbm5lbDogX2NoYW5uZWwsIG9wdGlvbnM6IF9vcHRpb25zLCBwcmVzZXQgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IGNoYW5uZWwgPSBwcmVzZXQgPyBnZXRDaGFubmVsKHByZXNldCwgXCJwcm94eVwiKSA6IF9jaGFubmVsO1xuXHRyZXR1cm4gY3JlYXRlQmlycGMoe30sIHtcblx0XHQuLi5fb3B0aW9ucyxcblx0XHQuLi5jaGFubmVsLFxuXHRcdHRpbWVvdXQ6IC0xXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL2N1c3RvbS50c1xuZnVuY3Rpb24gZ2V0RnVuY3Rpb25EZXRhaWxzKGZ1bmMpIHtcblx0bGV0IHN0cmluZyA9IFwiXCI7XG5cdGxldCBtYXRjaGVzID0gbnVsbDtcblx0dHJ5IHtcblx0XHRzdHJpbmcgPSBGdW5jdGlvbi5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChmdW5jKTtcblx0XHRtYXRjaGVzID0gU3RyaW5nLnByb3RvdHlwZS5tYXRjaC5jYWxsKHN0cmluZywgL1xcKFtcXHNcXFNdKj9cXCkvKTtcblx0fSBjYXRjaCAoZSkge31cblx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzICYmIG1hdGNoZXNbMF07XG5cdGNvbnN0IGFyZ3MgPSB0eXBlb2YgbWF0Y2ggPT09IFwic3RyaW5nXCIgPyBtYXRjaCA6IFwiKD8pXCI7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImZ1bmN0aW9uXCIsXG5cdFx0ZGlzcGxheVRleHQ6IGA8c3BhbiBzdHlsZT1cIm9wYWNpdHk6Ljg7bWFyZ2luLXJpZ2h0OjVweDtcIj5mdW5jdGlvbjwvc3Bhbj4gPHNwYW4gc3R5bGU9XCJ3aGl0ZS1zcGFjZTpub3dyYXA7XCI+JHtlc2NhcGUodHlwZW9mIGZ1bmMubmFtZSA9PT0gXCJzdHJpbmdcIiA/IGZ1bmMubmFtZSA6IFwiXCIpfSR7YXJnc308L3NwYW4+YCxcblx0XHR0b29sdGlwVGV4dDogc3RyaW5nLnRyaW0oKSA/IGA8cHJlPiR7ZXNjYXBlKHN0cmluZyl9PC9wcmU+YCA6IG51bGxcblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0QmlnSW50RGV0YWlscyh2YWwpIHtcblx0Y29uc3Qgc3RyaW5naWZpZWRCaWdJbnQgPSBCaWdJbnQucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsKTtcblx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdHR5cGU6IFwiYmlnaW50XCIsXG5cdFx0ZGlzcGxheVRleHQ6IGBCaWdJbnQoJHtzdHJpbmdpZmllZEJpZ0ludH0pYCxcblx0XHR2YWx1ZTogc3RyaW5naWZpZWRCaWdJbnRcblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0RGF0ZURldGFpbHModmFsKSB7XG5cdGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh2YWwuZ2V0VGltZSgpKTtcblx0ZGF0ZS5zZXRNaW51dGVzKGRhdGUuZ2V0TWludXRlcygpIC0gZGF0ZS5nZXRUaW1lem9uZU9mZnNldCgpKTtcblx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdHR5cGU6IFwiZGF0ZVwiLFxuXHRcdGRpc3BsYXlUZXh0OiBEYXRlLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCksXG5cdFx0dmFsdWU6IGRhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAtMSlcblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0TWFwRGV0YWlscyh2YWwpIHtcblx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdHR5cGU6IFwibWFwXCIsXG5cdFx0ZGlzcGxheVRleHQ6IFwiTWFwXCIsXG5cdFx0dmFsdWU6IE9iamVjdC5mcm9tRW50cmllcyh2YWwpLFxuXHRcdHJlYWRPbmx5OiB0cnVlLFxuXHRcdGZpZWxkczogeyBhYnN0cmFjdDogdHJ1ZSB9XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldFNldERldGFpbHModmFsKSB7XG5cdGNvbnN0IGxpc3QgPSBBcnJheS5mcm9tKHZhbCk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcInNldFwiLFxuXHRcdGRpc3BsYXlUZXh0OiBgU2V0WyR7bGlzdC5sZW5ndGh9XWAsXG5cdFx0dmFsdWU6IGxpc3QsXG5cdFx0cmVhZE9ubHk6IHRydWVcblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0Q2F1Z2h0R2V0dGVycyhzdG9yZSkge1xuXHRjb25zdCBnZXR0ZXJzID0ge307XG5cdGNvbnN0IG9yaWdHZXR0ZXJzID0gc3RvcmUuZ2V0dGVycyB8fCB7fTtcblx0Y29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG9yaWdHZXR0ZXJzKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0ga2V5c1tpXTtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZ2V0dGVycywga2V5LCB7XG5cdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0Z2V0OiAoKSA9PiB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0cmV0dXJuIG9yaWdHZXR0ZXJzW2tleV07XG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRyZXR1cm4gZTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiBnZXR0ZXJzO1xufVxuZnVuY3Rpb24gcmVkdWNlU3RhdGVMaXN0KGxpc3QpIHtcblx0aWYgKCFsaXN0Lmxlbmd0aCkgcmV0dXJuIHZvaWQgMDtcblx0cmV0dXJuIGxpc3QucmVkdWNlKChtYXAsIGl0ZW0pID0+IHtcblx0XHRjb25zdCBrZXkgPSBpdGVtLnR5cGUgfHwgXCJkYXRhXCI7XG5cdFx0Y29uc3Qgb2JqID0gbWFwW2tleV0gPSBtYXBba2V5XSB8fCB7fTtcblx0XHRvYmpbaXRlbS5rZXldID0gaXRlbS52YWx1ZTtcblx0XHRyZXR1cm4gbWFwO1xuXHR9LCB7fSk7XG59XG5mdW5jdGlvbiBuYW1lZE5vZGVNYXBUb09iamVjdChtYXApIHtcblx0Y29uc3QgcmVzdWx0ID0ge307XG5cdGNvbnN0IGwgPSBtYXAubGVuZ3RoO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGw7IGkrKykge1xuXHRcdGNvbnN0IG5vZGUgPSBtYXAuaXRlbShpKTtcblx0XHRyZXN1bHRbbm9kZS5uYW1lXSA9IG5vZGUudmFsdWU7XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGdldFN0b3JlRGV0YWlscyhzdG9yZSkge1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJzdG9yZVwiLFxuXHRcdGRpc3BsYXlUZXh0OiBcIlN0b3JlXCIsXG5cdFx0dmFsdWU6IHtcblx0XHRcdHN0YXRlOiBzdG9yZS5zdGF0ZSxcblx0XHRcdGdldHRlcnM6IGdldENhdWdodEdldHRlcnMoc3RvcmUpXG5cdFx0fSxcblx0XHRmaWVsZHM6IHsgYWJzdHJhY3Q6IHRydWUgfVxuXHR9IH07XG59XG5mdW5jdGlvbiBnZXRJbnN0YW5jZURldGFpbHMoaW5zdGFuY2UpIHtcblx0aWYgKGluc3RhbmNlLl8pIGluc3RhbmNlID0gaW5zdGFuY2UuXztcblx0Y29uc3Qgc3RhdGUgPSBwcm9jZXNzSW5zdGFuY2VTdGF0ZShpbnN0YW5jZSk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImNvbXBvbmVudFwiLFxuXHRcdGlkOiBpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fLFxuXHRcdGRpc3BsYXlUZXh0OiBnZXRJbnN0YW5jZU5hbWUoaW5zdGFuY2UpLFxuXHRcdHRvb2x0aXBUZXh0OiBcIkNvbXBvbmVudCBpbnN0YW5jZVwiLFxuXHRcdHZhbHVlOiByZWR1Y2VTdGF0ZUxpc3Qoc3RhdGUpLFxuXHRcdGZpZWxkczogeyBhYnN0cmFjdDogdHJ1ZSB9XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldENvbXBvbmVudERlZmluaXRpb25EZXRhaWxzKGRlZmluaXRpb24pIHtcblx0bGV0IGRpc3BsYXkgPSBnZXRDb21wb25lbnROYW1lKGRlZmluaXRpb24pO1xuXHRpZiAoZGlzcGxheSkge1xuXHRcdGlmIChkZWZpbml0aW9uLm5hbWUgJiYgZGVmaW5pdGlvbi5fX2ZpbGUpIGRpc3BsYXkgKz0gYCA8c3Bhbj4oJHtkZWZpbml0aW9uLl9fZmlsZX0pPC9zcGFuPmA7XG5cdH0gZWxzZSBkaXNwbGF5ID0gXCI8aT5Vbmtub3duIENvbXBvbmVudDwvaT5cIjtcblx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdHR5cGU6IFwiY29tcG9uZW50LWRlZmluaXRpb25cIixcblx0XHRkaXNwbGF5VGV4dDogZGlzcGxheSxcblx0XHR0b29sdGlwVGV4dDogXCJDb21wb25lbnQgZGVmaW5pdGlvblwiLFxuXHRcdC4uLmRlZmluaXRpb24uX19maWxlID8geyBmaWxlOiBkZWZpbml0aW9uLl9fZmlsZSB9IDoge31cblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0SFRNTEVsZW1lbnREZXRhaWxzKHZhbHVlKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdFx0dHlwZTogXCJIVE1MRWxlbWVudFwiLFxuXHRcdFx0ZGlzcGxheVRleHQ6IGA8c3BhbiBjbGFzcz1cIm9wYWNpdHktMzBcIj4mbHQ7PC9zcGFuPjxzcGFuIGNsYXNzPVwidGV4dC1ibHVlLTUwMFwiPiR7dmFsdWUudGFnTmFtZS50b0xvd2VyQ2FzZSgpfTwvc3Bhbj48c3BhbiBjbGFzcz1cIm9wYWNpdHktMzBcIj4mZ3Q7PC9zcGFuPmAsXG5cdFx0XHR2YWx1ZTogbmFtZWROb2RlTWFwVG9PYmplY3QodmFsdWUuYXR0cmlidXRlcylcblx0XHR9IH07XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0XHR0eXBlOiBcIkhUTUxFbGVtZW50XCIsXG5cdFx0XHRkaXNwbGF5VGV4dDogYDxzcGFuIGNsYXNzPVwidGV4dC1ibHVlLTUwMFwiPiR7U3RyaW5nKHZhbHVlKX08L3NwYW4+YFxuXHRcdH0gfTtcblx0fVxufVxuLyoqXG4qIC0gT2JqZWN0UmVmSW1wbCwgdG9SZWYoeyBmb286ICdmb28nIH0sICdmb28nKSwgYF92YWx1ZWAgaXMgdGhlIGFjdHVhbCB2YWx1ZSwgKHNpbmNlIDMuNS4wKVxuKiAtIEdldHRlclJlZkltcGwsIHRvUmVmKCgpID0+IHN0YXRlLmZvbyksIGBfdmFsdWVgIGlzIHRoZSBhY3R1YWwgdmFsdWUsIChzaW5jZSAzLjUuMClcbiogLSBSZWZJbXBsLCByZWYoJ2ZvbycpIC8gY29tcHV0ZWQoKCkgPT4gJ2ZvbycpLCBgX3ZhbHVlYCBpcyB0aGUgYWN0dWFsIHZhbHVlXG4qL1xuZnVuY3Rpb24gdHJ5R2V0UmVmVmFsdWUocmVmKSB7XG5cdGlmIChlbnN1cmVQcm9wZXJ0eUV4aXN0cyhyZWYsIFwiX3ZhbHVlXCIsIHRydWUpKSByZXR1cm4gcmVmLl92YWx1ZTtcblx0aWYgKGVuc3VyZVByb3BlcnR5RXhpc3RzKHJlZiwgXCJ2YWx1ZVwiLCB0cnVlKSkgcmV0dXJuIHJlZi52YWx1ZTtcbn1cbmZ1bmN0aW9uIGdldE9iamVjdERldGFpbHMob2JqZWN0KSB7XG5cdGNvbnN0IGluZm8gPSBnZXRTZXR1cFN0YXRlVHlwZShvYmplY3QpO1xuXHRpZiAoaW5mby5yZWYgfHwgaW5mby5jb21wdXRlZCB8fCBpbmZvLnJlYWN0aXZlKSB7XG5cdFx0Y29uc3Qgc3RhdGVUeXBlTmFtZSA9IGluZm8uY29tcHV0ZWQgPyBcIkNvbXB1dGVkXCIgOiBpbmZvLnJlZiA/IFwiUmVmXCIgOiBpbmZvLnJlYWN0aXZlID8gXCJSZWFjdGl2ZVwiIDogbnVsbDtcblx0XHRjb25zdCB2YWx1ZSA9IHRvUmF3KGluZm8ucmVhY3RpdmUgPyBvYmplY3QgOiB0cnlHZXRSZWZWYWx1ZShvYmplY3QpKTtcblx0XHRjb25zdCByYXcgPSBlbnN1cmVQcm9wZXJ0eUV4aXN0cyhvYmplY3QsIFwiZWZmZWN0XCIpID8gb2JqZWN0LmVmZmVjdD8ucmF3Py50b1N0cmluZygpIHx8IG9iamVjdC5lZmZlY3Q/LmZuPy50b1N0cmluZygpIDogbnVsbDtcblx0XHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0XHR0eXBlOiBzdGF0ZVR5cGVOYW1lPy50b0xvd2VyQ2FzZSgpLFxuXHRcdFx0c3RhdGVUeXBlTmFtZSxcblx0XHRcdHZhbHVlLFxuXHRcdFx0Li4ucmF3ID8geyB0b29sdGlwVGV4dDogYDxwcmU+JHtlc2NhcGUocmF3KX08L3ByZT5gIH0gOiB7fVxuXHRcdH0gfTtcblx0fVxuXHRpZiAoZW5zdXJlUHJvcGVydHlFeGlzdHMob2JqZWN0LCBcIl9fYXN5bmNMb2FkZXJcIikgJiYgdHlwZW9mIG9iamVjdC5fX2FzeW5jTG9hZGVyID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImNvbXBvbmVudC1kZWZpbml0aW9uXCIsXG5cdFx0ZGlzcGxheTogXCJBc3luYyBjb21wb25lbnQgZGVmaW5pdGlvblwiXG5cdH0gfTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9yZXBsYWNlci50c1xuZnVuY3Rpb24gc3RyaW5naWZ5UmVwbGFjZXIoa2V5LCBfdmFsdWUsIGRlcHRoLCBzZWVuSW5zdGFuY2UpIHtcblx0aWYgKGtleSA9PT0gXCJjb21waWxlck9wdGlvbnNcIikgcmV0dXJuO1xuXHRjb25zdCB2YWwgPSB0aGlzW2tleV07XG5cdGNvbnN0IHR5cGUgPSB0eXBlb2YgdmFsO1xuXHRpZiAoQXJyYXkuaXNBcnJheSh2YWwpKSB7XG5cdFx0Y29uc3QgbCA9IHZhbC5sZW5ndGg7XG5cdFx0aWYgKGwgPiA1ZTMpIHJldHVybiB7XG5cdFx0XHRfaXNBcnJheTogdHJ1ZSxcblx0XHRcdGxlbmd0aDogbCxcblx0XHRcdGl0ZW1zOiB2YWwuc2xpY2UoMCwgTUFYX0FSUkFZX1NJWkUpXG5cdFx0fTtcblx0XHRyZXR1cm4gdmFsO1xuXHR9IGVsc2UgaWYgKHR5cGVvZiB2YWwgPT09IFwic3RyaW5nXCIpIGlmICh2YWwubGVuZ3RoID4gMWU0KSByZXR1cm4gYCR7dmFsLnN1YnN0cmluZygwLCBNQVhfU1RSSU5HX1NJWkUpfS4uLiAoJHt2YWwubGVuZ3RofSB0b3RhbCBsZW5ndGgpYDtcblx0ZWxzZSByZXR1cm4gdmFsO1xuXHRlbHNlIGlmICh0eXBlID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gVU5ERUZJTkVEO1xuXHRlbHNlIGlmICh2YWwgPT09IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSkgcmV0dXJuIElORklOSVRZO1xuXHRlbHNlIGlmICh2YWwgPT09IE51bWJlci5ORUdBVElWRV9JTkZJTklUWSkgcmV0dXJuIE5FR0FUSVZFX0lORklOSVRZO1xuXHRlbHNlIGlmICh0eXBlb2YgdmFsID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBnZXRGdW5jdGlvbkRldGFpbHModmFsKTtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJzeW1ib2xcIikgcmV0dXJuIGBbbmF0aXZlIFN5bWJvbCAke1N5bWJvbC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpfV1gO1xuXHRlbHNlIGlmICh0eXBlb2YgdmFsID09PSBcImJpZ2ludFwiKSByZXR1cm4gZ2V0QmlnSW50RGV0YWlscyh2YWwpO1xuXHRlbHNlIGlmICh2YWwgIT09IG51bGwgJiYgdHlwZW9mIHZhbCA9PT0gXCJvYmplY3RcIikge1xuXHRcdGNvbnN0IHByb3RvID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCk7XG5cdFx0aWYgKHByb3RvID09PSBcIltvYmplY3QgTWFwXVwiKSByZXR1cm4gZ2V0TWFwRGV0YWlscyh2YWwpO1xuXHRcdGVsc2UgaWYgKHByb3RvID09PSBcIltvYmplY3QgU2V0XVwiKSByZXR1cm4gZ2V0U2V0RGV0YWlscyh2YWwpO1xuXHRcdGVsc2UgaWYgKHByb3RvID09PSBcIltvYmplY3QgUmVnRXhwXVwiKSByZXR1cm4gYFtuYXRpdmUgUmVnRXhwICR7UmVnRXhwLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCl9XWA7XG5cdFx0ZWxzZSBpZiAocHJvdG8gPT09IFwiW29iamVjdCBEYXRlXVwiKSByZXR1cm4gZ2V0RGF0ZURldGFpbHModmFsKTtcblx0XHRlbHNlIGlmIChwcm90byA9PT0gXCJbb2JqZWN0IEVycm9yXVwiKSByZXR1cm4gYFtuYXRpdmUgRXJyb3IgJHt2YWwubWVzc2FnZX08PiR7dmFsLnN0YWNrfV1gO1xuXHRcdGVsc2UgaWYgKGVuc3VyZVByb3BlcnR5RXhpc3RzKHZhbCwgXCJzdGF0ZVwiLCB0cnVlKSAmJiBlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWwsIFwiX3ZtXCIsIHRydWUpKSByZXR1cm4gZ2V0U3RvcmVEZXRhaWxzKHZhbCk7XG5cdFx0ZWxzZSBpZiAoaXNWdWVJbnN0YW5jZSh2YWwpKSB7XG5cdFx0XHRjb25zdCBjb21wb25lbnRWYWwgPSBnZXRJbnN0YW5jZURldGFpbHModmFsKTtcblx0XHRcdGNvbnN0IHBhcmVudEluc3RhbmNlRGVwdGggPSBzZWVuSW5zdGFuY2U/LmdldCh2YWwpO1xuXHRcdFx0aWYgKHBhcmVudEluc3RhbmNlRGVwdGggJiYgcGFyZW50SW5zdGFuY2VEZXB0aCA8IGRlcHRoKSByZXR1cm4gYFtbQ2lyY3VsYXJSZWZdXSA8JHtjb21wb25lbnRWYWwuX2N1c3RvbS5kaXNwbGF5VGV4dH0+YDtcblx0XHRcdHNlZW5JbnN0YW5jZT8uc2V0KHZhbCwgZGVwdGgpO1xuXHRcdFx0cmV0dXJuIGNvbXBvbmVudFZhbDtcblx0XHR9IGVsc2UgaWYgKGVuc3VyZVByb3BlcnR5RXhpc3RzKHZhbCwgXCJyZW5kZXJcIiwgdHJ1ZSkgJiYgdHlwZW9mIHZhbC5yZW5kZXIgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIGdldENvbXBvbmVudERlZmluaXRpb25EZXRhaWxzKHZhbCk7XG5cdFx0ZWxzZSBpZiAodmFsLmNvbnN0cnVjdG9yICYmIHZhbC5jb25zdHJ1Y3Rvci5uYW1lID09PSBcIlZOb2RlXCIpIHJldHVybiBgW25hdGl2ZSBWTm9kZSA8JHt2YWwudGFnfT5dYDtcblx0XHRlbHNlIGlmICh0eXBlb2YgSFRNTEVsZW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgdmFsIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpIHJldHVybiBnZXRIVE1MRWxlbWVudERldGFpbHModmFsKTtcblx0XHRlbHNlIGlmICh2YWwuY29uc3RydWN0b3I/Lm5hbWUgPT09IFwiU3RvcmVcIiAmJiBcIl93cmFwcGVkR2V0dGVyc1wiIGluIHZhbCkgcmV0dXJuIFwiW29iamVjdCBTdG9yZV1cIjtcblx0XHRjb25zdCBjdXN0b21EZXRhaWxzID0gZ2V0T2JqZWN0RGV0YWlscyh2YWwpO1xuXHRcdGlmIChjdXN0b21EZXRhaWxzICE9IG51bGwpIHJldHVybiBjdXN0b21EZXRhaWxzO1xuXHR9IGVsc2UgaWYgKE51bWJlci5pc05hTih2YWwpKSByZXR1cm4gTkFOO1xuXHRyZXR1cm4gc2FuaXRpemUodmFsKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zaGFyZWQvdHJhbnNmZXIudHNcbmNvbnN0IE1BWF9TRVJJQUxJWkVEX1NJWkUgPSAyICogMTAyNCAqIDEwMjQ7XG5mdW5jdGlvbiBpc09iamVjdChfZGF0YSwgcHJvdG8pIHtcblx0cmV0dXJuIHByb3RvID09PSBcIltvYmplY3QgT2JqZWN0XVwiO1xufVxuZnVuY3Rpb24gaXNBcnJheShfZGF0YSwgcHJvdG8pIHtcblx0cmV0dXJuIHByb3RvID09PSBcIltvYmplY3QgQXJyYXldXCI7XG59XG5mdW5jdGlvbiBpc1Z1ZVJlYWN0aXZlTGlua05vZGUobm9kZSkge1xuXHRjb25zdCBjb25zdHJ1Y3Rvck5hbWUgPSBub2RlPy5jb25zdHJ1Y3Rvcj8ubmFtZTtcblx0cmV0dXJuIGNvbnN0cnVjdG9yTmFtZSA9PT0gXCJEZXBcIiAmJiBcImFjdGl2ZUxpbmtcIiBpbiBub2RlIHx8IGNvbnN0cnVjdG9yTmFtZSA9PT0gXCJMaW5rXCIgJiYgXCJkZXBcIiBpbiBub2RlO1xufVxuLyoqXG4qIFRoaXMgZnVuY3Rpb24gaXMgdXNlZCB0byBzZXJpYWxpemUgb2JqZWN0IHdpdGggaGFuZGxpbmcgY2lyY3VsYXIgcmVmZXJlbmNlcy5cbipcbiogYGBgdHNcbiogY29uc3Qgb2JqID0geyBhOiAxLCBiOiB7IGM6IDIgfSwgZDogb2JqIH1cbiogY29uc3QgcmVzdWx0ID0gc3RyaW5naWZ5Q2lyY3VsYXJBdXRvQ2h1bmtzKG9iaikgLy8gY2FsbCBgZW5jb2RlYCBpbnNpZGVcbiogY29uc29sZS5sb2cocmVzdWx0KSAvLyBbe1wiYVwiOjEsXCJiXCI6MixcImRcIjowfSwxLHtcImNcIjo0fSwyXVxuKiBgYGBcbipcbiogRWFjaCBvYmplY3QgaXMgc3RvcmVkIGluIGEgbGlzdCBhbmQgdGhlIGluZGV4IGlzIHVzZWQgdG8gcmVmZXJlbmNlIHRoZSBvYmplY3QuXG4qIFdpdGggc2VlbiBtYXAsIHdlIGNhbiBjaGVjayBpZiB0aGUgb2JqZWN0IGlzIGFscmVhZHkgc3RvcmVkIGluIHRoZSBsaXN0IHRvIGF2b2lkIGNpcmN1bGFyIHJlZmVyZW5jZXMuXG4qXG4qIE5vdGU6IGhlcmUgd2UgaGF2ZSBhIHNwZWNpYWwgY2FzZSBmb3IgVnVlIGluc3RhbmNlLlxuKiBXZSBjaGVjayBpZiBhIHZ1ZSBpbnN0YW5jZSBpbmNsdWRlcyBpdHNlbGYgaW4gaXRzIHByb3BlcnRpZXMgYW5kIHNraXAgaXRcbiogYnkgdXNpbmcgYHNlZW5WdWVJbnN0YW5jZWAgYW5kIGBkZXB0aGAgdG8gYXZvaWQgaW5maW5pdGUgbG9vcC5cbiovXG5mdW5jdGlvbiBlbmNvZGUoZGF0YSwgcmVwbGFjZXIsIGxpc3QsIHNlZW4sIGRlcHRoID0gMCwgc2VlblZ1ZUluc3RhbmNlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkge1xuXHRsZXQgc3RvcmVkO1xuXHRsZXQga2V5O1xuXHRsZXQgdmFsdWU7XG5cdGxldCBpO1xuXHRsZXQgbDtcblx0Y29uc3Qgc2VlbkluZGV4ID0gc2Vlbi5nZXQoZGF0YSk7XG5cdGlmIChzZWVuSW5kZXggIT0gbnVsbCkgcmV0dXJuIHNlZW5JbmRleDtcblx0Y29uc3QgaW5kZXggPSBsaXN0Lmxlbmd0aDtcblx0Y29uc3QgcHJvdG8gPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoZGF0YSk7XG5cdGlmIChpc09iamVjdChkYXRhLCBwcm90bykpIHtcblx0XHRpZiAoaXNWdWVSZWFjdGl2ZUxpbmtOb2RlKGRhdGEpKSByZXR1cm4gaW5kZXg7XG5cdFx0c3RvcmVkID0ge307XG5cdFx0c2Vlbi5zZXQoZGF0YSwgaW5kZXgpO1xuXHRcdGxpc3QucHVzaChzdG9yZWQpO1xuXHRcdGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhkYXRhKTtcblx0XHRmb3IgKGkgPSAwLCBsID0ga2V5cy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRcdGtleSA9IGtleXNbaV07XG5cdFx0XHRpZiAoa2V5ID09PSBcImNvbXBpbGVyT3B0aW9uc1wiKSByZXR1cm4gaW5kZXg7XG5cdFx0XHR2YWx1ZSA9IGRhdGFba2V5XTtcblx0XHRcdGNvbnN0IGlzVm0gPSB2YWx1ZSAhPSBudWxsICYmIGlzT2JqZWN0KHZhbHVlLCBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoZGF0YSkpICYmIGlzVnVlSW5zdGFuY2UodmFsdWUpO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0aWYgKHJlcGxhY2VyKSB2YWx1ZSA9IHJlcGxhY2VyLmNhbGwoZGF0YSwga2V5LCB2YWx1ZSwgZGVwdGgsIHNlZW5WdWVJbnN0YW5jZSk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdHZhbHVlID0gZTtcblx0XHRcdH1cblx0XHRcdHN0b3JlZFtrZXldID0gZW5jb2RlKHZhbHVlLCByZXBsYWNlciwgbGlzdCwgc2VlbiwgZGVwdGggKyAxLCBzZWVuVnVlSW5zdGFuY2UpO1xuXHRcdFx0aWYgKGlzVm0pIHNlZW5WdWVJbnN0YW5jZS5kZWxldGUodmFsdWUpO1xuXHRcdH1cblx0fSBlbHNlIGlmIChpc0FycmF5KGRhdGEsIHByb3RvKSkge1xuXHRcdHN0b3JlZCA9IFtdO1xuXHRcdHNlZW4uc2V0KGRhdGEsIGluZGV4KTtcblx0XHRsaXN0LnB1c2goc3RvcmVkKTtcblx0XHRmb3IgKGkgPSAwLCBsID0gZGF0YS5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHZhbHVlID0gZGF0YVtpXTtcblx0XHRcdFx0aWYgKHJlcGxhY2VyKSB2YWx1ZSA9IHJlcGxhY2VyLmNhbGwoZGF0YSwgaSwgdmFsdWUsIGRlcHRoLCBzZWVuVnVlSW5zdGFuY2UpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHR2YWx1ZSA9IGU7XG5cdFx0XHR9XG5cdFx0XHRzdG9yZWRbaV0gPSBlbmNvZGUodmFsdWUsIHJlcGxhY2VyLCBsaXN0LCBzZWVuLCBkZXB0aCArIDEsIHNlZW5WdWVJbnN0YW5jZSk7XG5cdFx0fVxuXHR9IGVsc2UgbGlzdC5wdXNoKGRhdGEpO1xuXHRyZXR1cm4gaW5kZXg7XG59XG5mdW5jdGlvbiBkZWNvZGUobGlzdCwgcmV2aXZlciA9IG51bGwpIHtcblx0bGV0IGkgPSBsaXN0Lmxlbmd0aDtcblx0bGV0IGosIGssIGRhdGEsIGtleSwgdmFsdWUsIHByb3RvO1xuXHR3aGlsZSAoaS0tKSB7XG5cdFx0ZGF0YSA9IGxpc3RbaV07XG5cdFx0cHJvdG8gPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoZGF0YSk7XG5cdFx0aWYgKHByb3RvID09PSBcIltvYmplY3QgT2JqZWN0XVwiKSB7XG5cdFx0XHRjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoZGF0YSk7XG5cdFx0XHRmb3IgKGogPSAwLCBrID0ga2V5cy5sZW5ndGg7IGogPCBrOyBqKyspIHtcblx0XHRcdFx0a2V5ID0ga2V5c1tqXTtcblx0XHRcdFx0dmFsdWUgPSBsaXN0W2RhdGFba2V5XV07XG5cdFx0XHRcdGlmIChyZXZpdmVyKSB2YWx1ZSA9IHJldml2ZXIuY2FsbChkYXRhLCBrZXksIHZhbHVlKTtcblx0XHRcdFx0ZGF0YVtrZXldID0gdmFsdWU7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIGlmIChwcm90byA9PT0gXCJbb2JqZWN0IEFycmF5XVwiKSBmb3IgKGogPSAwLCBrID0gZGF0YS5sZW5ndGg7IGogPCBrOyBqKyspIHtcblx0XHRcdHZhbHVlID0gbGlzdFtkYXRhW2pdXTtcblx0XHRcdGlmIChyZXZpdmVyKSB2YWx1ZSA9IHJldml2ZXIuY2FsbChkYXRhLCBqLCB2YWx1ZSk7XG5cdFx0XHRkYXRhW2pdID0gdmFsdWU7XG5cdFx0fVxuXHR9XG59XG5mdW5jdGlvbiBzdHJpbmdpZnlDaXJjdWxhckF1dG9DaHVua3MoZGF0YSwgcmVwbGFjZXIgPSBudWxsLCBzcGFjZSA9IG51bGwpIHtcblx0bGV0IHJlc3VsdDtcblx0dHJ5IHtcblx0XHRyZXN1bHQgPSBhcmd1bWVudHMubGVuZ3RoID09PSAxID8gSlNPTi5zdHJpbmdpZnkoZGF0YSkgOiBKU09OLnN0cmluZ2lmeShkYXRhLCAoaywgdikgPT4gcmVwbGFjZXI/LihrLCB2KT8uY2FsbCh0aGlzKSwgc3BhY2UpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0cmVzdWx0ID0gc3RyaW5naWZ5U3RyaWN0Q2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEsIHJlcGxhY2VyLCBzcGFjZSk7XG5cdH1cblx0aWYgKHJlc3VsdC5sZW5ndGggPiBNQVhfU0VSSUFMSVpFRF9TSVpFKSB7XG5cdFx0Y29uc3QgY2h1bmtDb3VudCA9IE1hdGguY2VpbChyZXN1bHQubGVuZ3RoIC8gTUFYX1NFUklBTElaRURfU0laRSk7XG5cdFx0Y29uc3QgY2h1bmtzID0gW107XG5cdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBjaHVua0NvdW50OyBpKyspIGNodW5rcy5wdXNoKHJlc3VsdC5zbGljZShpICogTUFYX1NFUklBTElaRURfU0laRSwgKGkgKyAxKSAqIE1BWF9TRVJJQUxJWkVEX1NJWkUpKTtcblx0XHRyZXR1cm4gY2h1bmtzO1xuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBzdHJpbmdpZnlTdHJpY3RDaXJjdWxhckF1dG9DaHVua3MoZGF0YSwgcmVwbGFjZXIgPSBudWxsLCBzcGFjZSA9IG51bGwpIHtcblx0Y29uc3QgbGlzdCA9IFtdO1xuXHRlbmNvZGUoZGF0YSwgcmVwbGFjZXIsIGxpc3QsIC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpO1xuXHRyZXR1cm4gc3BhY2UgPyBgICR7SlNPTi5zdHJpbmdpZnkobGlzdCwgbnVsbCwgc3BhY2UpfWAgOiBgICR7SlNPTi5zdHJpbmdpZnkobGlzdCl9YDtcbn1cbmZ1bmN0aW9uIHBhcnNlQ2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEsIHJldml2ZXIgPSBudWxsKSB7XG5cdGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSBkYXRhID0gZGF0YS5qb2luKFwiXCIpO1xuXHRpZiAoIS9eXFxzLy50ZXN0KGRhdGEpKSByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA9PT0gMSA/IEpTT04ucGFyc2UoZGF0YSkgOiBKU09OLnBhcnNlKGRhdGEsIHJldml2ZXIpO1xuXHRlbHNlIHtcblx0XHRjb25zdCBsaXN0ID0gSlNPTi5wYXJzZShkYXRhKTtcblx0XHRkZWNvZGUobGlzdCwgcmV2aXZlcik7XG5cdFx0cmV0dXJuIGxpc3RbMF07XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zaGFyZWQvdXRpbC50c1xuZnVuY3Rpb24gc3RyaW5naWZ5KGRhdGEpIHtcblx0cmV0dXJuIHN0cmluZ2lmeUNpcmN1bGFyQXV0b0NodW5rcyhkYXRhLCBzdHJpbmdpZnlSZXBsYWNlcik7XG59XG5mdW5jdGlvbiBwYXJzZShkYXRhLCByZXZpdmUgPSBmYWxzZSkge1xuXHRpZiAoZGF0YSA9PSB2b2lkIDApIHJldHVybiB7fTtcblx0cmV0dXJuIHJldml2ZSA/IHBhcnNlQ2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEsIHJldml2ZXIpIDogcGFyc2VDaXJjdWxhckF1dG9DaHVua3MoZGF0YSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW5kZXgudHNcbmNvbnN0IGRldnRvb2xzID0ge1xuXHRob29rLFxuXHRpbml0OiAoKSA9PiB7XG5cdFx0aW5pdERldlRvb2xzKCk7XG5cdH0sXG5cdGdldCBjdHgoKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzQ29udGV4dDtcblx0fSxcblx0Z2V0IGFwaSgpIHtcblx0XHRyZXR1cm4gZGV2dG9vbHNDb250ZXh0LmFwaTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgRGV2VG9vbHNDb250ZXh0SG9va0tleXMsIERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMsIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cywgSU5GSU5JVFksIE5BTiwgTkVHQVRJVkVfSU5GSU5JVFksIFJPVVRFUl9JTkZPX0tFWSwgUk9VVEVSX0tFWSwgVU5ERUZJTkVELCBhY3RpdmVBcHBSZWNvcmQsIGFkZEN1c3RvbUNvbW1hbmQsIGFkZEN1c3RvbVRhYiwgYWRkRGV2VG9vbHNBcHBSZWNvcmQsIGFkZERldlRvb2xzUGx1Z2luVG9CdWZmZXIsIGFkZEluc3BlY3RvciwgY2FsbENvbm5lY3RlZFVwZGF0ZWRIb29rLCBjYWxsRGV2VG9vbHNQbHVnaW5TZXR1cEZuLCBjYWxsSW5zcGVjdG9yVXBkYXRlZEhvb2ssIGNhbGxTdGF0ZVVwZGF0ZWRIb29rLCBjcmVhdGVDb21wb25lbnRzRGV2VG9vbHNQbHVnaW4sIGNyZWF0ZURldlRvb2xzQXBpLCBjcmVhdGVEZXZUb29sc0N0eEhvb2tzLCBjcmVhdGVScGNDbGllbnQsIGNyZWF0ZVJwY1Byb3h5LCBjcmVhdGVScGNTZXJ2ZXIsIGRldnRvb2xzLCBkZXZ0b29sc0FwcFJlY29yZHMsIGRldnRvb2xzQ29udGV4dCwgZGV2dG9vbHNJbnNwZWN0b3IsIGRldnRvb2xzUGx1Z2luQnVmZmVyLCBkZXZ0b29sc1JvdXRlciwgZGV2dG9vbHNSb3V0ZXJJbmZvLCBkZXZ0b29sc1N0YXRlLCBlc2NhcGUsIGZvcm1hdEluc3BlY3RvclN0YXRlVmFsdWUsIGdldEFjdGl2ZUluc3BlY3RvcnMsIGdldERldlRvb2xzRW52LCBnZXRFeHRlbnNpb25DbGllbnRDb250ZXh0LCBnZXRJbnNwZWN0b3IsIGdldEluc3BlY3RvckFjdGlvbnMsIGdldEluc3BlY3RvckluZm8sIGdldEluc3BlY3Rvck5vZGVBY3Rpb25zLCBnZXRJbnNwZWN0b3JTdGF0ZVZhbHVlVHlwZSwgZ2V0UmF3LCBnZXRScGNDbGllbnQsIGdldFJwY1NlcnZlciwgZ2V0Vml0ZVJwY0NsaWVudCwgZ2V0Vml0ZVJwY1NlcnZlciwgaW5pdERldlRvb2xzLCBpc1BsYWluT2JqZWN0LCBvbkRldlRvb2xzQ2xpZW50Q29ubmVjdGVkLCBvbkRldlRvb2xzQ29ubmVjdGVkLCBwYXJzZSwgcmVnaXN0ZXJEZXZUb29sc1BsdWdpbiwgcmVtb3ZlQ3VzdG9tQ29tbWFuZCwgcmVtb3ZlRGV2VG9vbHNBcHBSZWNvcmQsIHJlbW92ZVJlZ2lzdGVyZWRQbHVnaW5BcHAsIHJlc2V0RGV2VG9vbHNTdGF0ZSwgc2V0QWN0aXZlQXBwUmVjb3JkLCBzZXRBY3RpdmVBcHBSZWNvcmRJZCwgc2V0RGV2VG9vbHNFbnYsIHNldEVsZWN0cm9uQ2xpZW50Q29udGV4dCwgc2V0RWxlY3Ryb25Qcm94eUNvbnRleHQsIHNldEVsZWN0cm9uU2VydmVyQ29udGV4dCwgc2V0RXh0ZW5zaW9uQ2xpZW50Q29udGV4dCwgc2V0SWZyYW1lU2VydmVyQ29udGV4dCwgc2V0T3BlbkluRWRpdG9yQmFzZVVybCwgc2V0UnBjU2VydmVyVG9HbG9iYWwsIHNldFZpdGVDbGllbnRDb250ZXh0LCBzZXRWaXRlUnBjQ2xpZW50VG9HbG9iYWwsIHNldFZpdGVScGNTZXJ2ZXJUb0dsb2JhbCwgc2V0Vml0ZVNlcnZlckNvbnRleHQsIHNldHVwRGV2VG9vbHNQbHVnaW4sIHN0cmluZ2lmeSwgdG9FZGl0LCB0b1N1Ym1pdCwgdG9nZ2xlQ2xpZW50Q29ubmVjdGVkLCB0b2dnbGVDb21wb25lbnRJbnNwZWN0b3JFbmFibGVkLCB0b2dnbGVIaWdoUGVyZk1vZGUsIHVwZGF0ZURldlRvb2xzQ2xpZW50RGV0ZWN0ZWQsIHVwZGF0ZURldlRvb2xzU3RhdGUsIHVwZGF0ZVRpbWVsaW5lTGF5ZXJzU3RhdGUgfTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbFIsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3ZMLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDMUssTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3RMLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDN0IsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDNUIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWM7QUFDckMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCO0FBQ3RELEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQjtBQUNsRCxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYztBQUN4QyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWM7QUFDbEQsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7QUFDckcsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2SixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ1YsQ0FBQztBQUNELEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN0TCxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUc7QUFDWCxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQzNCLFFBQVEsQ0FBQyxrQ0FBa0MsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDekMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLHNDQUFzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQ3ZILENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3pFLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2QyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQzVCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDbEQ7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWE7QUFDMUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUN0QixDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUM7QUFDckM7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakQsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHNDQUFzQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzVELENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdDQUFnQztBQUNoRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLGdDQUFnQztBQUN4RjtBQUNBLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ3ZDLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMseUJBQXlCO0FBQ25GLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQztBQUMzQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUM3QixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDcEQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkO0FBQ0EsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJO0FBQzNDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2pFLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVc7QUFDMUQ7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVE7QUFDbEQ7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU07QUFDakIsQ0FBQztBQUNELFFBQVEsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMvQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2hLLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUM3SixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQzlCLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQztBQUM3QjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2YsQ0FBQztBQUNELFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4QyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdkk7QUFDQSxRQUFRLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQzVDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzlDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyQjtBQUNBLFFBQVEsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDekIsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDckQsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuRjtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzlELENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDaEc7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUNqRCxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUk7QUFDaEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFDaEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNaO0FBQ0EsR0FBRyxDQUFDLEtBQUs7QUFDVCxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUMzQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0FBQ3JDO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzFCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDakMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUztBQUNmLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO0FBQ3RGLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFO0FBQzNCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUM1RixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7QUFDNUUsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDNUMsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMxRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDaEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3JELENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVDtBQUNBLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVCxDQUFDO0FBQ0QsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO0FBQy9CLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUN2RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUNuRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUNoRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztBQUNqRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUN6QjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDckMsUUFBUSxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3hELENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDM0UsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDN0I7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3BHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNaO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztBQUMvQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDO0FBQ25FLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUM7QUFDcEUsS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDO0FBQzlFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQztBQUM5RSxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pCLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVTtBQUNuQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2xCLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM3QixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM5QixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQy9CLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3JCLENBQUM7QUFDRCxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUMzQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNuQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbEIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNyQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqQixDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUc7QUFDaEIsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNuQixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDM0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUUsQ0FBQztBQUNELEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3hCLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRztBQUNoQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3BCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQztBQUNELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQztBQUNyRDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDO0FBQ2hEO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDO0FBQ3JEO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyx5QkFBeUIsQ0FBQztBQUMxRDtBQUNBLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDM0IsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUNsRCxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUNwRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDckQsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2xELENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7QUFDM0QsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZTtBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxlQUFlO0FBQzVCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDZixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzlDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMseUJBQXlCO0FBQ3RDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pELENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsb0JBQW9CO0FBQ3RDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdILENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7QUFDM0IsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQztBQUNoQyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO0FBQ2hDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLFdBQVc7QUFDbkI7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUMxQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQzFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWU7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDOUgsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3QixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQztBQUNsRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNO0FBQzVDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUN2QyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE1BQU07QUFDUixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xDO0FBQ0EsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMxQixRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDeEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CO0FBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDN0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDL0Q7QUFDQSxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDOUMsUUFBUSxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNuRCxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDL0UsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQztBQUNBLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNoRCxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hELENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDekUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsUUFBUSxDQUFDO0FBQzdELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RixDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNWLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDVixDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQzdDLE1BQU0sQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDNUQsUUFBUSxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLDRDQUE0QyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzlEO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ2QsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDUDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQjtBQUMzQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxZQUFZO0FBQzdDLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDO0FBQ3BDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzlCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDbEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDO0FBQy9FLENBQUM7QUFDRCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsd0NBQXdDLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRztBQUNsSixDQUFDO0FBQ0QsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzVELENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNoRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ2hELENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDOUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNqQyxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx3Q0FBd0MsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJO0FBQ25KLENBQUM7QUFDRCxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3JEO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUk7QUFDbkosQ0FBQztBQUNELFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNyRDtBQUNBLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3JDO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUk7QUFDbkosQ0FBQztBQUNELFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzNCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDO0FBQ3BELENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNyQztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFDMUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3hCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDdkMsQ0FBQztBQUNELENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0FBQ3hFLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN0RSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM1QixDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN4RSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZixDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN4RSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRixDQUFDO0FBQ0QsQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNyRixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM5QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDM0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JFLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRztBQUN2QyxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDMUMsQ0FBQztBQUNELENBQUM7QUFDRCxLQUFLLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3hELENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzlDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTTtBQUN0QixDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQyxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQ1gsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLO0FBQzNFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHFCQUFxQjtBQUNsSixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUk7QUFDL0YsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSztBQUM3QixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvRixDQUFDO0FBQ0Q7QUFDQSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDckMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDekM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDcEMsS0FBSyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUEwQyxDQUFDO0FBQ3JGLFFBQVEsQ0FBQywrQkFBK0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU07QUFDdkYsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5RTtBQUNBLFFBQVEsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDekgsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUs7QUFDdkIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsS0FBSztBQUMxQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLO0FBQzdCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsS0FBSztBQUNoQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDMUgsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsS0FBSztBQUN2QixDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLO0FBQzFCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEtBQUs7QUFDN0IsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsS0FBSztBQUM5QixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxLQUFLO0FBQ2hDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUMzQixNQUFNLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbEgsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMvQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDekQsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUU7QUFDN0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsR0FBRztBQUN4QyxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUI7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQywrQkFBK0IsQ0FBQyxZQUFZLENBQUM7QUFDOUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQzNEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7QUFDNUIsTUFBTSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3pHLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLHdCQUF3QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0FBQzFHLENBQUMsQ0FBQztBQUNGLFFBQVEsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUM7QUFDeEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVM7QUFDcEIsQ0FBQyxDQUFDLFVBQVU7QUFDWixDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVFLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDeEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDM0I7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzTCxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVU7QUFDekMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPO0FBQ25DLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRTtBQUNqQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUN2QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSTtBQUN4QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsVUFBVSxDQUFDLFdBQVc7QUFDdEMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVE7QUFDaEMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUM5RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN2QixDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVO0FBQ3hDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU87QUFDbEMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEgsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLO0FBQ25CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7QUFDaEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQ3RCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSTtBQUN2QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsVUFBVSxDQUFDLFdBQVc7QUFDckMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRO0FBQy9CLENBQUMsQ0FBQyxjQUFjO0FBQ2hCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxxQkFBcUI7QUFDeEQsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BDLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdIO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPO0FBQ3pDO0FBQ0EsUUFBUSxDQUFDLHVCQUF1QixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7QUFDdkIsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQztBQUN4RixDQUFDLDJCQUEyQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO0FBQzNFLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDdEUsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUMzRSxDQUFDLDJCQUEyQixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ3ZFLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDekUsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUMzRSxDQUFDLDJCQUEyQixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDO0FBQy9FLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ3BFLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDekUsQ0FBQyxNQUFNLENBQUMsMkJBQTJCO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFDaEYsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQzFELENBQUMsdUJBQXVCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDckUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUN2RSxDQUFDLHVCQUF1QixDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDO0FBQ3RGLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUM7QUFDdkUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUN2RSxDQUFDLHVCQUF1QixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO0FBQzdFLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUM7QUFDdkUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNuRSxDQUFDLHVCQUF1QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO0FBQ3RFLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUM7QUFDMUUsQ0FBQyxNQUFNLENBQUMsdUJBQXVCO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDcEYsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQztBQUN6RixDQUFDLHlCQUF5QixDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDO0FBQzNGLENBQUMseUJBQXlCLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUM7QUFDekYsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztBQUNoRixDQUFDLHlCQUF5QixDQUFDLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDO0FBQ2xHLENBQUMseUJBQXlCLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUM7QUFDN0UsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQztBQUNyRixDQUFDLHlCQUF5QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO0FBQ3ZFLENBQUMsTUFBTSxDQUFDLHlCQUF5QjtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxRQUFRLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RSxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDM0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztBQUNwRSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHO0FBQzdCLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLGtCQUFrQixDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsNkJBQTZCLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQztBQUNuRixDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDM0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztBQUNwRSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHO0FBQzdCLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxtQkFBbUIsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsOEJBQThCLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztBQUNyRixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztBQUNwRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3hCLENBQUMsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ25DLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25GLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25GLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3JDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsNkJBQTZCLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0FBQ3hELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEgsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xGLENBQUMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFFLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUM3RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDeEIsTUFBTSxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxNQUFNLENBQUMseUNBQXlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsTUFBTSxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRCxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDO0FBQ3JELFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSztBQUNsQixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsS0FBSztBQUN4QixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJO0FBQzFCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSTtBQUMzQixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQztBQUN6RCxDQUFDLENBQUM7QUFDRjtBQUNBLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDeEMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDNUYsQ0FBQyxDQUFDO0FBQ0YsS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFDdEYsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzdHLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0NBQWdDO0FBQ3JFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxJQUFJLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDNUYsQ0FBQztBQUNELEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDMUcsQ0FBQztBQUNELEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLHNDQUFzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoSCxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHNDQUFzQztBQUMzRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx5Q0FBeUM7QUFDaEYsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHNDQUFzQyxDQUFDLElBQUksQ0FBQztBQUMzRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxvQkFBb0IsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztBQUN0QixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsa0JBQWtCLENBQUMsS0FBSztBQUN0QyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRTtBQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLGdDQUFnQztBQUMvQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsc0NBQXNDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDcEQsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNsQjtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNsQyxDQUFDLE1BQU0sQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUN0RCxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ2xCO0FBQ0EsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCO0FBQzFELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxFQUFFO0FBQ3RFLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0NBQWdDO0FBQzlFLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsb0NBQW9DO0FBQ3RGLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNwQyxDQUFDLENBQUM7QUFDRixDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDekIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzVCLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDckMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQztBQUNELENBQUMsQ0FBQztBQUNGLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztBQUNyRDtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLO0FBQ3RDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUNyQyxDQUFDLENBQUM7QUFDRixDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNwTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3hDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDbEI7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUNsQixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDNUQsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsQ0FBQztBQUNELFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0NBQWdDO0FBQ3JELENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2xELENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUM1QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsZUFBZSxDQUFDLENBQUM7QUFDbEI7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsb0NBQW9DO0FBQzdELENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3JELENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1gsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNYLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ2xCO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG9DQUFvQztBQUM3RCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzNELENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3pCLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNsQjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ2hEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDeEMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsTUFBTSxDQUFDLHdDQUF3QyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ3REO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUN2RixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsd0NBQXdDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUM5RSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN0RSxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN6QixNQUFNLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEgsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlELENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2RDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDMUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVk7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ2pCO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsTUFBTSxDQUFDLENBQUMscUNBQXFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO0FBQzVEO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVDLENBQUMsTUFBTSxDQUFDLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDNUg7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDcEQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztBQUN0RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDO0FBQ3JELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ILENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUM7QUFDbkM7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDNUc7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7QUFDN0MsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztBQUNyRCxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQjtBQUN4QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDWCxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ04sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDbEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDO0FBQ3BEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDekIsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzVELENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ3ZDLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO0FBQzdDLENBQUMsYUFBYSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDekQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDckQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztBQUN6RCxDQUFDLGFBQWEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztBQUNuRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ2xELENBQUMsYUFBYSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzlDLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUNoRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDdEQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDbkQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztBQUN2RCxDQUFDLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUNqRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNqRSxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ3pCLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2xFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNoRCxDQUFDLENBQUM7QUFDRixDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ25ELENBQUMsQ0FBQztBQUNGLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDckQsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDOUQsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDN0QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2hFLENBQUMsQ0FBQztBQUNGLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNoRSxDQUFDLENBQUM7QUFDRixDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM3RCxDQUFDLENBQUM7QUFDRixDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDaEUsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM5RCxDQUFDO0FBQ0QsQ0FBQztBQUNELFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUN6QixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLO0FBQ2hCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDckYsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0FBQ2xELENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN4RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ3ZGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDbkUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN2RixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ3hHLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN6RixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUN4RyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDekYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ3BFLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDcEYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUN2RCxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDdkQsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3hGLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsRUFBRTtBQUNILENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDL0YsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDM0IsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDdEIsQ0FBQztBQUNELENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDOUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM5RSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDNUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzdFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM5RSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDN0UsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQy9DLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztBQUMzRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUc7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzdELENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU87QUFDckIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztBQUN0RyxDQUFDO0FBQ0QsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsNEJBQTRCLENBQUMsQ0FBQztBQUM1RSxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNULENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN2RixDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25CLENBQUM7QUFDRCxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDVixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQy9DLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDVixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7QUFDbEcsQ0FBQztBQUNELENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLENBQUM7QUFDRCxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBQ0QsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDdEYsQ0FBQztBQUNELENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUI7QUFDaEQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2xGLENBQUM7QUFDRCxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLHFCQUFxQixDQUFDO0FBQzNFLENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDeEIsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxtQkFBbUI7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUM3QyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDWCxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztBQUN2QixDQUFDLENBQUMsbUJBQW1CLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNOLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDWCxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNYLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDZCxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNSLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDUixDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNSLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNiLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDYixDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNiLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDWixDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNSLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDVixDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUNsQixDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDWixDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ1osQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNkLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNqQixDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDbEIsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUNsQixDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDcEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNkLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ25CLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDVixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDYixDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNWLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNuQixDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDbkIsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNqQixDQUFDLENBQUMsYUFBYTtBQUNmLENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQzNCLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDMUIsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQztBQUM3QyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDO0FBQzNDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQztBQUM3RCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQ2pDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1osQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFDdEMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDcEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUMxQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5QztBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNqRTtBQUNBLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQzlCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3BFO0FBQ0EsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNwQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVM7QUFDdkI7QUFDQSxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDbEM7QUFDQSxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYztBQUM1QjtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDekIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjO0FBQzVCO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUN4QyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN6QixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDaEMsQ0FBQztBQUNELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDakIsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sUUFBUSxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzdEO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDNUQ7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVFO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsTUFBTTtBQUN6QyxDQUFDO0FBQ0QsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO0FBQzlDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3ZFO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUM5QyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLO0FBQ3hELENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUs7QUFDM0QsQ0FBQztBQUNELFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDdEgsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDakI7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDM0IsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSztBQUNiLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDbEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSztBQUNsQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTztBQUN6QyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQ3BELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTtBQUNyQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqRCxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzdELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0QsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNoRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNuQyxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsRUFBRTtBQUNWO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSTtBQUMzQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNoRCxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTTtBQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ25FLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDckMsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUNmO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUTtBQUNsQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFDN0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVM7QUFDN0Q7QUFDQSxDQUFDO0FBQ0QsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUs7QUFDOUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdEUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDakIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVztBQUMzRDtBQUNBLENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUk7QUFDM0IsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLO0FBQzFCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87QUFDL0MsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUTtBQUNuQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDZCxDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1SixDQUFDLENBQUMsR0FBRztBQUNMLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDcEcsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsU0FBUztBQUNYLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BJLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNsRSxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLO0FBQzVDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNaLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDalYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQztBQUNqRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7QUFDN0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDckMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDTixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFFBQVE7QUFDaEQsQ0FBQztBQUNELFFBQVEsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDL0MsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQ3hCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUN2QixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25GLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDUCxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ04sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQ2hCO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQyxHQUFHO0FBQ0wsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzdDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxHQUFHLENBQUMsWUFBWTtBQUNqQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUUsQ0FBQyxDQUFDLEdBQUc7QUFDTCxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDdEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXO0FBQ2pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNqRixDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUMzQixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPO0FBQy9CLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1RyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUMvSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQy9CLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsR0FBRztBQUNMLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUM1QixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDaEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUN2QixDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVM7QUFDakIsQ0FBQyxDQUFDO0FBQ0YsUUFBUSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLO0FBQzVDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN0RyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0FBQ3hGLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUk7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUk7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4QyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQztBQUNsRCxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaFI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQ3pDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNsQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO0FBQ2hGLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQztBQUNwQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDO0FBQ3ZDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUN6QyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxTQUFTO0FBQ3BDLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU87QUFDbkIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDeEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ2pILENBQUM7QUFDRCxDQUFDO0FBQ0QsUUFBUSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzNDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO0FBQ3ZDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUN6QyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqRSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDO0FBQzFELENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQzFCLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2hDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ2hCLENBQUM7QUFDRCxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUM7QUFDRCxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUNoQixDQUFDO0FBQ0QsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDO0FBQzdILENBQUMsQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDekMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUNyQixDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDWCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDMUQsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNO0FBQ2xCLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUM1QixDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDeEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqSCxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7QUFDN0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1AsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdEUsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtBQUNqQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU87QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVztBQUM3QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDak8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUM7QUFDdEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQztBQUMvRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDO0FBQ2pILENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtBQUN6QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUN2RSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLGFBQWE7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzlGLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFdBQVc7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM1QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ1gsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxRQUFRO0FBQzlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRztBQUMvQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVE7QUFDakIsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNqRCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUMxRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDbkQsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDckIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvSCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQzVJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUs7QUFDekQsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLO0FBQ2pCLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLDZCQUE2QixDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQzVHLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdILENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUTtBQUN6QyxDQUFDLENBQUM7QUFDRixDQUFDLDJCQUEyQixDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQy9FLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDO0FBQ2pHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNqRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVE7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUMxRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdkYsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHO0FBQ2hFLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQztBQUNGLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXO0FBQ3hELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDbEQsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVM7QUFDMUQsQ0FBQztBQUNELENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ2hHLENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ2pDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM5QyxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ2hELEtBQUssQ0FBQyxRQUFRLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQztBQUMxQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN2QixDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7QUFDakUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNsRCxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7QUFDNUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLDBCQUEwQjtBQUNyQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGFBQWE7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWE7QUFDdkIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSTtBQUNqQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7QUFDdkUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQy9CLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQy9ELENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzRCxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7QUFDcEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDdkIsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0FBQ2pFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0FBQ3ZELENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPO0FBQ25DLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO0FBQ3hDLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsMEJBQTBCO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxhQUFhO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUTtBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWE7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsR0FBRztBQUNMLENBQUMsQ0FBQyxHQUFHO0FBQ0wsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUU7QUFDZCxDQUFDLENBQUMsSUFBSTtBQUNOLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7QUFDbEMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDbEQsUUFBUSxDQUFDLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3ZCLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ1gsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU07QUFDdkgsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ1gsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxNQUFNO0FBQzNILENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUk7QUFDaEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUN0QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsd0JBQXdCO0FBQzlCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFDM0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMscUJBQXFCLENBQUMsQ0FBQyxNQUFNO0FBQzNILENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQztBQUMzQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3hCLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztBQUN4RSxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLHdCQUF3QjtBQUNwQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNuQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsMEJBQTBCO0FBQ25DLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxNQUFNO0FBQzdILENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE1BQU07QUFDN0gsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQzVCLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ2xCLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ25ELENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNuQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNO0FBQy9CLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7QUFDNUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUYsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQjtBQUM1QyxDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7QUFDckMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDakMsUUFBUSxDQUFDLDhCQUE4QixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVk7QUFDbEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3JCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLDBCQUEwQixDQUFDLEdBQUcsQ0FBQztBQUNqQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO0FBQ3BGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsaUJBQWlCLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDcEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDVCxDQUFDLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDaEQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUNuRCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDcEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQzdGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsV0FBVztBQUM5RyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDekIsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUNoRCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0FBQ25ELENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUNwRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDN0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxXQUFXO0FBQzlHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN6QixDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDaEQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUNuRCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDcEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxXQUFXO0FBQzVHLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzdCO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ2hDLE1BQU0sQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqRixRQUFRLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN4RCxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDM0Q7QUFDQSxRQUFRLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTTtBQUN6QyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQztBQUNuQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1YsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxFQUFFLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JGLENBQUMsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztBQUNiO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsTUFBTSxDQUFDLDRDQUE0QyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDaEU7QUFDQSxRQUFRLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsNENBQTRDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN6RSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUMvRSxDQUFDLE1BQU0sQ0FBQyw0Q0FBNEMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQzdELENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDekIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQztBQUM1QyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDO0FBQ3RELE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSTtBQUNuQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDO0FBQ0QsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4RixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQy9FLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDaEMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMzQixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM1QyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JHO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDO0FBQ3pELENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1AsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNQLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDWCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM1RSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDUCxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1AsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNQLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDUCxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPO0FBQ2hDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUN6RCxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsTUFBTTtBQUMvRCxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztBQUNyRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUk7QUFDeEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNO0FBQzNCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUM3QixDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDO0FBQ0QsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNQLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTTtBQUMxRCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUMvQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuSCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ1Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUN0QixRQUFRLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxHQUFHO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLGtCQUFrQixDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUztBQUM1QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxtQkFBbUIsQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUs7QUFDeEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxHQUFHO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyx3QkFBd0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLG9CQUFvQixDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVU7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDbkUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdkgsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLFlBQVk7QUFDZCxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMscUJBQXFCO0FBQ3hDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUMzRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGlCQUFpQixDQUFDLFFBQVE7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDdEIsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0QsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLG9CQUFvQjtBQUNuQztBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUN0QyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLEtBQUs7QUFDTixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWE7QUFDbkIsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRTtBQUN4QyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSztBQUN6QyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsaUJBQWlCLENBQUMsS0FBSztBQUM3QixDQUFDO0FBQ0QsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLDRCQUE0QjtBQUMzRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztBQUMvRixHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU07QUFDakIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNaLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLO0FBQ2hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDO0FBQ3pGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0FBQ2pCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNiLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNuQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDbkIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU07QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2pCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDNUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVk7QUFDbkIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVE7QUFDZixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUTtBQUNmLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRO0FBQ2YsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDYixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUTtBQUNmLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1osQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtBQUNULENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGlCQUFpQjtBQUN4QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsa0JBQWtCO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDakQsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtBQUN4QixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxFQUFFO0FBQzVCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsa0JBQWtCO0FBQzFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pGLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0I7QUFDekQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUgsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUU7QUFDN0ksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ3RILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3SSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDM0UsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDckQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUM1QixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDNUIsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDN0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMvRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztBQUNwRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDeEcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUMzRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNySCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDdkYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDN0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZMLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN2RSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDaEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUs7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztBQUM1RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQzlELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNsRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTztBQUMzQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNoRixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUNsRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQ2hDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUM3QixHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2pDLENBQUM7QUFDRCxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUN0RDtBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVM7QUFDeEMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUztBQUNyRjtBQUNBLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUM7QUFDbkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUNqQyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3BCLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUM7QUFDcEcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3RELENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5QixDQUFDO0FBQ0QsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7QUFDN0IsQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDN0MsQ0FBQyxNQUFNLENBQUMsRUFBRTtBQUNWO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNyQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQztBQUM3QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxZQUFZLENBQUM7QUFDakUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1AsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUNmLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3RHLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMvQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztBQUNyRCxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN4RCxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNqQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNoQyxRQUFRLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLDRCQUE0QjtBQUMzRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLE1BQU07QUFDMUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN0QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzFELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzNDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDO0FBQzdELENBQUM7QUFDRCxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDekIsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDO0FBQzlELENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1I7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUN6QixRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUM7QUFDeEIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztBQUNqRixDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7QUFDdkYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTTtBQUNsRSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDM0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDOUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDeEUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDO0FBQ0QsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxNQUFNLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDbEQsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzlJLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsZ0NBQWdDLENBQUM7QUFDcEgsQ0FBQyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUMvRixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3hOLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMxTixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDM0gsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN0RCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUM7QUFDbkcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTTtBQUNsQixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzdELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0csQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNOLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsb0JBQW9CLENBQUMsbUJBQW1CLENBQUM7QUFDM0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDNUQsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDO0FBQ2xELENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqRixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzdGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDM0UsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLEdBQUcsQ0FBQztBQUM5QixDQUFDLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxtQ0FBbUMsQ0FBQztBQUNoRyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0csQ0FBQyxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMscUJBQXFCLENBQUMsYUFBYSxDQUFDO0FBQ3JDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDO0FBQ3pHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWE7QUFDdkIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDaEY7QUFDQSxRQUFRLENBQUMseUJBQXlCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDdkMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUN4QyxRQUFRLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUI7QUFDaEYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsc0JBQXNCLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDdkY7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQzNDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDekMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUs7QUFDL0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNCLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQy9CLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hDLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNoRCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQjtBQUM3RSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQjtBQUN0RixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNuRCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDakMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0FBQzFGLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztBQUN2RCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFDdkQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNoRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDN0QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDekQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM3QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3JCO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUMxQyxRQUFRLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN2RCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQzFCLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNuRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDL0wsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDeEgsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQzVELENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ25FLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFDckQsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3RCO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNYLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3RELENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSztBQUNyRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUM5RCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPO0FBQ3pMLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzNELENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakYsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7QUFDMUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQ3JJLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxRQUFRLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hGO0FBQ0EsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN2QixDQUFDLEdBQUcsQ0FBQyxVQUFVO0FBQ2YsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUs7QUFDekMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUk7QUFDOUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDM0MsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7QUFDM0QsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQ2pELENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNuQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUMxQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUN4QyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25EO0FBQ0EsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNsRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDbEQsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN4RDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDNUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzlDLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLHNCQUFzQjtBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLGtCQUFrQixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkY7QUFDQSxNQUFNLENBQUMsdUNBQXVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyw0QkFBNEI7QUFDL0UsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUNqRyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdDLENBQUM7QUFDRCxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDakMsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDakMsQ0FBQztBQUNELENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ25DLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN6QixDQUFDO0FBQ0QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0FBQ3hGLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNyQixDQUFDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUM5QyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ2pDLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3ZDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztBQUM5RCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hDLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQixDQUFDO0FBQ0QsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7QUFDbEMsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDO0FBQ3JDLENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO0FBQzlGLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO0FBQzNDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN0RCxDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUNsRixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdkMsQ0FBQztBQUNELENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDNUMsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNwRixRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQ3JELENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25GLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDakMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO0FBQ25DLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQ3BELENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUM5QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDcEMsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsRTtBQUNBLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQztBQUNBLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ3BDLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUM7QUFDM0csR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdEMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2xELENBQUM7QUFDRCxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdFLENBQUM7QUFDRCxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO0FBQy9CLENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDbEYsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRixLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDakUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM5QyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2xFLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQy9DLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ3pELENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUztBQUMzRCxDQUFDO0FBQ0QsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUNyRCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN6RCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUM1RSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMzRCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsTUFBTTtBQUN2RCxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRztBQUNqRCxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRztBQUNqRCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUM3RCxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLO0FBQ3JELEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUM3RSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQ2pLLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3pELEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUM3RSxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO0FBQy9GLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHO0FBQ2pELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO0FBQy9GLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BELEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ1gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDNUIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUN6QixDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO0FBQzNGLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNoRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxZQUFZO0FBQ2QsQ0FBQyxDQUFDLFVBQVU7QUFDWixDQUFDLENBQUMsU0FBUztBQUNYLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDM0UsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakYsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDZixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNuQixDQUFDLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDOUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNYLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNYLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQzFFLENBQUM7QUFDRCxRQUFRLENBQUMsdUJBQXVCLENBQUMsWUFBWSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDbkYsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsWUFBWTtBQUNkLENBQUMsQ0FBQyxVQUFVO0FBQ1osQ0FBQyxDQUFDLFNBQVM7QUFDWCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUNwRSxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNwRSxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2IsQ0FBQyxDQUFDO0FBQ0YsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLFNBQVM7QUFDVixDQUFDLFVBQVU7QUFDWCxDQUFDLFVBQVU7QUFDWCxDQUFDLFdBQVc7QUFDWixDQUFDLFVBQVU7QUFDWCxDQUFDLFdBQVc7QUFDWixDQUFDLFlBQVk7QUFDYixDQUFDLFlBQVk7QUFDYixDQUFDO0FBQ0QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN0QixDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3hFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQztBQUNGLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNoRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztBQUM1RyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0YsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO0FBQ2hGLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDN0osQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUM7QUFDRixLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xGLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQ2xGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hGLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsU0FBUztBQUNWLENBQUMsVUFBVTtBQUNYLENBQUMsVUFBVTtBQUNYLENBQUM7QUFDRCxDQUFDO0FBQ0QsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN2RyxDQUFDLEVBQUUsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQzVELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUztBQUMzRCxDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNqRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztBQUM3QixDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2hELENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDckUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNyRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM3RCxDQUFDO0FBQ0QsQ0FBQyxJQUFJLENBQUM7QUFDTixDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDO0FBQ3RELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3pFLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDcEQsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUMxRixLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMzRCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDekIsQ0FBQztBQUNELFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDNUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMzRixDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzNGLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0Y7QUFDQSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztBQUNuQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDbkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDN0IsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZCxDQUFDO0FBQ0QsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7QUFDbkIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7QUFDN0MsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3BCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDckIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDbkIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbkMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25FLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUN2QixDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNULENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQ3ZGLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0FBQ2xCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUYsQ0FBQyxDQUFDLE1BQU07QUFDUixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNuQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUMxQjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUM5RCxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsUUFBUSxDQUFDLG1DQUFtQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ25DLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNuQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN0SyxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQy9DLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDM0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN4QyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEM7QUFDQSxRQUFRLENBQUMsc0NBQXNDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDckUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9CLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDL0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDaEcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDdkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQztBQUM1RixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQztBQUNwRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztBQUM3RSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN4QyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3BEO0FBQ0EsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztBQUN0QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzdELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDdkQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSztBQUN0QyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pELENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNmLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNFLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQy9ELENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMxRCxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3RNLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNySSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0I7QUFDNUQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxXQUFXO0FBQ25HLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0csQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN4RCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRCxDQUFDLENBQUMsZ0JBQWdCO0FBQ2xCLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsZ0JBQWdCO0FBQ2xCLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEYsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hELENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUNsRixRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzFCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUQ7QUFDQSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNwQztBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2hELENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUM7QUFDakQsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ3pGO0FBQ0EsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6QixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNuQztBQUNBLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoRztBQUNBLFFBQVEsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDeEM7QUFDQSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDN0YsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQzlFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztBQUNwRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDbkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3RixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTTtBQUNmLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLO0FBQ25CLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQ2hCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUM1QyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDO0FBQ3JELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUM1RSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUN6QixDQUFDLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7QUFDM0UsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDckYsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzlLLENBQUMsQ0FBQztBQUNGLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3RCLENBQUM7QUFDRCxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUM5RCxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUk7QUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxzQ0FBc0MsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQzdGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNaLENBQUM7QUFDRCxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2hDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0UsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7QUFDbkgsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2YsQ0FBQztBQUNELENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQy9DLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdDLENBQUM7QUFDRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3pDLENBQUM7QUFDRCxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQzdDLENBQUM7QUFDRCxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLFFBQVEsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN2QyxDQUFDO0FBQ0QsQ0FBQztBQUNELFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUMzQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUN6RixTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUM3RixTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUN6RixTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUNqRixTQUFTLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUNqRyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUNuRyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUNuRyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztBQUNyRyxTQUFTLENBQUMsU0FBUztBQUNuQixTQUFTLENBQUMsV0FBVztBQUNyQixTQUFTLENBQUMsU0FBUztBQUNuQixTQUFTLENBQUMsS0FBSztBQUNmLFNBQVMsQ0FBQyxhQUFhO0FBQ3ZCLFNBQVMsQ0FBQyxjQUFjO0FBQ3hCLFNBQVMsQ0FBQyxjQUFjO0FBQ3hCLFNBQVMsQ0FBQyxlQUFlO0FBQ3pCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQzFELEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUNyRyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztBQUN4RCxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDO0FBQ25FLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUM7QUFDN0QsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyw0Q0FBNEM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQy9GLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDakQsS0FBSyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzdELEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUMzRCxLQUFLLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDN0QsS0FBSyxDQUFDLDZDQUE2QyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSztBQUNoQyxDQUFDO0FBQ0QsUUFBUSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUM7QUFDM0M7QUFDQSxRQUFRLENBQUMsd0JBQXdCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUM5QztBQUNBLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLDBCQUEwQixDQUFDO0FBQzFDO0FBQ0EsUUFBUSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzFDLENBQUMsTUFBTSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDN0M7QUFDQSxRQUFRLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztBQUMzQztBQUNBLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMzQyxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzlDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztBQUNoRCxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUMxQyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsZUFBZSxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN4RyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsNkNBQTZDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztBQUMvQyxRQUFRLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUN6QyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLDZDQUE2QyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyw2Q0FBNkMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDOUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyw2Q0FBNkMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsZUFBZSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzlGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztBQUNoRCxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUMxQyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsZUFBZSxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN4RyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsNkNBQTZDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztBQUNsRCxLQUFLLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDOUQsS0FBSyxDQUFDLDhDQUE4QyxDQUFDLENBQUMsQ0FBQztBQUN2RCxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSztBQUNoQyxDQUFDO0FBQ0QsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUM7QUFDNUM7QUFDQSxRQUFRLENBQUMseUJBQXlCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUMvQztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFDakQsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDekIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2hCLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMxQixDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM1QixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDdkIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN0QixDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNWLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTTtBQUMzQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTTtBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDO0FBQ2hELENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUNoRCxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyw4Q0FBOEMsQ0FBQyxlQUFlO0FBQ3pFLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyw4Q0FBOEMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDdEcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDO0FBQ0QsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQztBQUNqRCxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUM7QUFDaEUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQztBQUNwRSxDQUFDLENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUNqRCxRQUFRLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLDhDQUE4QyxDQUFDLGVBQWU7QUFDMUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLElBQUk7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsOENBQThDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMvQyxLQUFLLENBQUMseUNBQXlDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDL0YsS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3pELFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHlCQUF5QixDQUFDO0FBQ3pDO0FBQ0EsUUFBUSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pDLENBQUMsTUFBTSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDNUM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQzlDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMseUNBQXlDO0FBQ25ELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztBQUM5SCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztBQUM5QyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQztBQUM1RSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHlDQUF5QztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDdkksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDN0MsS0FBSyxDQUFDLHVDQUF1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQzNGLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNyRCxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDckQsUUFBUSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUM7QUFDdkM7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUMxQztBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDO0FBQ3ZDO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDMUM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQzVDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLHVDQUF1QyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDNUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDMUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFO0FBQzNDLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLHVDQUF1QyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5RixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsdUNBQXVDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUM5QixNQUFNLENBQUMscUNBQXFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsTUFBTSxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMvQyxNQUFNLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQy9DLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDcEQsTUFBTSxDQUFDLG9DQUFvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNwRCxNQUFNLENBQUMseUNBQXlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3pELFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNuQyxDQUFDLE1BQU0sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUM3QztBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNuQyxDQUFDLE1BQU0sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUM3QztBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQywrQkFBK0I7QUFDOUM7QUFDQSxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsK0JBQStCO0FBQzlDO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ2xEO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ2xEO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsb0NBQW9DO0FBQ25EO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsb0NBQW9DO0FBQ25EO0FBQ0EsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLHlCQUF5QjtBQUNwQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsMkJBQTJCO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLDBCQUEwQjtBQUNwQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsdUJBQXVCO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDVCxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxzQkFBc0I7QUFDakMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNULENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLDRCQUE0QjtBQUN2QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQywyQkFBMkI7QUFDckMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDUixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqQjtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2pFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdkQsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNaLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQztBQUNELENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDWDtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2pFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2pFLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDakMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNkLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2pFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQzFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDbkIsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ2pELENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RCxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JMLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDOUQsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUM7QUFDaEMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDaEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM1QixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzdCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJO0FBQ2IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2pDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUN0QyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQ2Y7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9CLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSztBQUM1QixDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1A7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNyQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDaEMsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN0QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSztBQUNyQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLO0FBQ2xDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUM7QUFDN0MsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNuQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLHlCQUF5QjtBQUN4QyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUN4QyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyw2QkFBNkIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNuRCxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQztBQUMzQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3RixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztBQUM5QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBTztBQUN0QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RDLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNKLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxVQUFVO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRixDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0FBQ3hFLENBQUM7QUFDRCxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQ2pFLENBQUMsRUFBRSxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQy9EO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2xDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDO0FBQ3ZDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN6RyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzdILENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLGFBQWE7QUFDaEIsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEgsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztBQUM5QixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQVU7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztBQUM1QyxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDN0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN0QyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDdEIsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUN4QixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDdEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDakIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUNyQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNaLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN4SSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNoQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVM7QUFDaEQsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVE7QUFDM0QsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQjtBQUNwRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7QUFDbkUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUM7QUFDL0QsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDbkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUM7QUFDOUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQztBQUNoRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQzNGLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDO0FBQzFILENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3pILENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVk7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsQ0FBQyxHQUFHLENBQUM7QUFDckksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDO0FBQzlHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQztBQUM3QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ2pELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDekMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUNyQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQzlCLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDM0MsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ25DO0FBQ0EsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xDO0FBQ0EsUUFBUSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSTtBQUNoRCxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUk7QUFDeEc7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFVBQVU7QUFDN0U7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDL0UsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVTtBQUN0RztBQUNBLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVE7QUFDcEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUN4RSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUk7QUFDL0QsQ0FBQztBQUNELFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEcsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNYLENBQUMsR0FBRyxDQUFDLEdBQUc7QUFDUixDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNOLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDTixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ2pDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ3hDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU07QUFDMUIsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ25ELENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDL0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNuQixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDaEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUM5QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztBQUM5RyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDakYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQzFDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUMvRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDOUUsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQ3BCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUs7QUFDbEMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDOUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3JCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxRSxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQ1gsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUM5SCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNuRSxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQ25FLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3hILENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNmLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsaUNBQWlDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hGLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ3hELENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDcEY7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN2RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNwRyxDQUFDLElBQUksQ0FBQztBQUNOLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUMvQixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN2QixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDMUIsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QixDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztBQUM1RDtBQUNBLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUM7QUFDdkY7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ3BCLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsSUFBSTtBQUNMLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZTtBQUN4QixDQUFDLENBQUM7QUFDRixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRztBQUM1QixDQUFDO0FBQ0QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQzsifQ==