/*
  This file draws heavily from https://github.com/phoenixframework/phoenix/blob/d344ec0a732ab4ee204215b31de69cf4be72e3bf/assets/js/phoenix/presence.js
  License: https://github.com/phoenixframework/phoenix/blob/d344ec0a732ab4ee204215b31de69cf4be72e3bf/LICENSE.md
*/
import PresenceAdapter from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+realtime-js@2.108.1/node_modules/@supabase/realtime-js/dist/module/phoenix/presenceAdapter.js?v=583078ff";
export var REALTIME_PRESENCE_LISTEN_EVENTS;
(function (REALTIME_PRESENCE_LISTEN_EVENTS) {
    REALTIME_PRESENCE_LISTEN_EVENTS["SYNC"] = "sync";
    REALTIME_PRESENCE_LISTEN_EVENTS["JOIN"] = "join";
    REALTIME_PRESENCE_LISTEN_EVENTS["LEAVE"] = "leave";
})(REALTIME_PRESENCE_LISTEN_EVENTS || (REALTIME_PRESENCE_LISTEN_EVENTS = {}));
export default class RealtimePresence {
    get state() {
        return this.presenceAdapter.state;
    }
    /**
     * Creates a Presence helper that keeps the local presence state in sync with the server.
     *
     * @param channel - The realtime channel to bind to.
     * @param opts - Optional custom event names, e.g. `{ events: { state: 'state', diff: 'diff' } }`.
     *
     * @category Realtime
     *
     * @example Example for a presence channel
     * ```ts
     * const presence = new RealtimePresence(channel)
     *
     * channel.on('presence', ({ event, key }) => {
     *   console.log(`Presence ${event} on ${key}`)
     * })
     * ```
     */
    constructor(channel, opts) {
        this.channel = channel;
        this.presenceAdapter = new PresenceAdapter(this.channel.channelAdapter, opts);
    }
}
                                            
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVhbHRpbWVQcmVzZW5jZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9SZWFsdGltZVByZXNlbmNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7RUFHRTtBQUdGLE9BQU8sZUFBZSxNQUFNLDJCQUEyQixDQUFBO0FBd0J2RCxNQUFNLENBQU4sSUFBWSwrQkFJWDtBQUpELFdBQVksK0JBQStCO0lBQ3pDLGdEQUFhLENBQUE7SUFDYixnREFBYSxDQUFBO0lBQ2Isa0RBQWUsQ0FBQTtBQUNqQixDQUFDLEVBSlcsK0JBQStCLEtBQS9CLCtCQUErQixRQUkxQztBQU1ELE1BQU0sQ0FBQyxPQUFPLE9BQU8sZ0JBQWdCO0lBQ25DLElBQUksS0FBSztRQUNQLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUE7SUFDbkMsQ0FBQztJQUlEOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBQ0gsWUFDUyxPQUF3QixFQUMvQixJQUE4QjtRQUR2QixZQUFPLEdBQVAsT0FBTyxDQUFpQjtRQUcvQixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFBO0lBQy9FLENBQUM7Q0FDRiIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gIFRoaXMgZmlsZSBkcmF3cyBoZWF2aWx5IGZyb20gaHR0cHM6Ly9naXRodWIuY29tL3Bob2VuaXhmcmFtZXdvcmsvcGhvZW5peC9ibG9iL2QzNDRlYzBhNzMyYWI0ZWUyMDQyMTViMzFkZTY5Y2Y0YmU3MmUzYmYvYXNzZXRzL2pzL3Bob2VuaXgvcHJlc2VuY2UuanNcbiAgTGljZW5zZTogaHR0cHM6Ly9naXRodWIuY29tL3Bob2VuaXhmcmFtZXdvcmsvcGhvZW5peC9ibG9iL2QzNDRlYzBhNzMyYWI0ZWUyMDQyMTViMzFkZTY5Y2Y0YmU3MmUzYmYvTElDRU5TRS5tZFxuKi9cblxuaW1wb3J0IHR5cGUgUmVhbHRpbWVDaGFubmVsIGZyb20gJy4vUmVhbHRpbWVDaGFubmVsJ1xuaW1wb3J0IFByZXNlbmNlQWRhcHRlciBmcm9tICcuL3Bob2VuaXgvcHJlc2VuY2VBZGFwdGVyJ1xuXG5leHBvcnQgdHlwZSBQcmVzZW5jZTxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9PiA9IHtcbiAgcHJlc2VuY2VfcmVmOiBzdHJpbmdcbn0gJiBUXG5cbmV4cG9ydCB0eXBlIFJlYWx0aW1lUHJlc2VuY2VTdGF0ZTxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9PiA9IHtcbiAgW2tleTogc3RyaW5nXTogUHJlc2VuY2U8VD5bXVxufVxuXG5leHBvcnQgdHlwZSBSZWFsdGltZVByZXNlbmNlSm9pblBheWxvYWQ8VCBleHRlbmRzIHsgW2tleTogc3RyaW5nXTogYW55IH0+ID0ge1xuICBldmVudDogYCR7UkVBTFRJTUVfUFJFU0VOQ0VfTElTVEVOX0VWRU5UUy5KT0lOfWBcbiAga2V5OiBzdHJpbmdcbiAgY3VycmVudFByZXNlbmNlczogUHJlc2VuY2U8VD5bXVxuICBuZXdQcmVzZW5jZXM6IFByZXNlbmNlPFQ+W11cbn1cblxuZXhwb3J0IHR5cGUgUmVhbHRpbWVQcmVzZW5jZUxlYXZlUGF5bG9hZDxUIGV4dGVuZHMgeyBba2V5OiBzdHJpbmddOiBhbnkgfT4gPSB7XG4gIGV2ZW50OiBgJHtSRUFMVElNRV9QUkVTRU5DRV9MSVNURU5fRVZFTlRTLkxFQVZFfWBcbiAga2V5OiBzdHJpbmdcbiAgY3VycmVudFByZXNlbmNlczogUHJlc2VuY2U8VD5bXVxuICBsZWZ0UHJlc2VuY2VzOiBQcmVzZW5jZTxUPltdXG59XG5cbmV4cG9ydCBlbnVtIFJFQUxUSU1FX1BSRVNFTkNFX0xJU1RFTl9FVkVOVFMge1xuICBTWU5DID0gJ3N5bmMnLFxuICBKT0lOID0gJ2pvaW4nLFxuICBMRUFWRSA9ICdsZWF2ZScsXG59XG5cbmV4cG9ydCB0eXBlIFJlYWx0aW1lUHJlc2VuY2VPcHRpb25zID0ge1xuICBldmVudHM/OiB7IHN0YXRlOiBzdHJpbmc7IGRpZmY6IHN0cmluZyB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFJlYWx0aW1lUHJlc2VuY2Uge1xuICBnZXQgc3RhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMucHJlc2VuY2VBZGFwdGVyLnN0YXRlXG4gIH1cblxuICBwcml2YXRlIHByZXNlbmNlQWRhcHRlcjogUHJlc2VuY2VBZGFwdGVyXG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBQcmVzZW5jZSBoZWxwZXIgdGhhdCBrZWVwcyB0aGUgbG9jYWwgcHJlc2VuY2Ugc3RhdGUgaW4gc3luYyB3aXRoIHRoZSBzZXJ2ZXIuXG4gICAqXG4gICAqIEBwYXJhbSBjaGFubmVsIC0gVGhlIHJlYWx0aW1lIGNoYW5uZWwgdG8gYmluZCB0by5cbiAgICogQHBhcmFtIG9wdHMgLSBPcHRpb25hbCBjdXN0b20gZXZlbnQgbmFtZXMsIGUuZy4gYHsgZXZlbnRzOiB7IHN0YXRlOiAnc3RhdGUnLCBkaWZmOiAnZGlmZicgfSB9YC5cbiAgICpcbiAgICogQGNhdGVnb3J5IFJlYWx0aW1lXG4gICAqXG4gICAqIEBleGFtcGxlIEV4YW1wbGUgZm9yIGEgcHJlc2VuY2UgY2hhbm5lbFxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBwcmVzZW5jZSA9IG5ldyBSZWFsdGltZVByZXNlbmNlKGNoYW5uZWwpXG4gICAqXG4gICAqIGNoYW5uZWwub24oJ3ByZXNlbmNlJywgKHsgZXZlbnQsIGtleSB9KSA9PiB7XG4gICAqICAgY29uc29sZS5sb2coYFByZXNlbmNlICR7ZXZlbnR9IG9uICR7a2V5fWApXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgY29uc3RydWN0b3IoXG4gICAgcHVibGljIGNoYW5uZWw6IFJlYWx0aW1lQ2hhbm5lbCxcbiAgICBvcHRzPzogUmVhbHRpbWVQcmVzZW5jZU9wdGlvbnNcbiAgKSB7XG4gICAgdGhpcy5wcmVzZW5jZUFkYXB0ZXIgPSBuZXcgUHJlc2VuY2VBZGFwdGVyKHRoaXMuY2hhbm5lbC5jaGFubmVsQWRhcHRlciwgb3B0cylcbiAgfVxufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=