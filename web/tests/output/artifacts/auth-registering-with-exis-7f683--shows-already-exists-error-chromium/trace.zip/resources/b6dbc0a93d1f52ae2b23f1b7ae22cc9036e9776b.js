import { IcebergRestCatalog } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/iceberg-js@0.8.1/node_modules/iceberg-js/dist/index.mjs?v=583078ff";

//#region \0@oxc-project+runtime@0.103.0/helpers/typeof.js
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o$1) {
		return typeof o$1;
	} : function(o$1) {
		return o$1 && "function" == typeof Symbol && o$1.constructor === Symbol && o$1 !== Symbol.prototype ? "symbol" : typeof o$1;
	}, _typeof(o);
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/toPrimitive.js
function toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/toPropertyKey.js
function toPropertyKey(t) {
	var i = toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/defineProperty.js
function _defineProperty(e, r, t) {
	return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}

//#endregion
//#region \0@oxc-project+runtime@0.103.0/helpers/objectSpread2.js
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r$1) {
			return Object.getOwnPropertyDescriptor(e, r$1).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r$1) {
			_defineProperty(e, r$1, t[r$1]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r$1) {
			Object.defineProperty(e, r$1, Object.getOwnPropertyDescriptor(t, r$1));
		});
	}
	return e;
}

//#endregion
//#region src/lib/common/errors.ts
/**
* Base error class for all Storage errors
* Supports both 'storage' and 'vectors' namespaces
*/
var StorageError = class extends Error {
	constructor(message, namespace = "storage", status, statusCode) {
		super(message);
		this.__isStorageError = true;
		this.namespace = namespace;
		this.name = namespace === "vectors" ? "StorageVectorsError" : "StorageError";
		this.status = status;
		this.statusCode = statusCode;
	}
	toJSON() {
		return {
			name: this.name,
			message: this.message,
			status: this.status,
			statusCode: this.statusCode
		};
	}
};
/**
* Type guard to check if an error is a StorageError
* @param error - The error to check
* @returns True if the error is a StorageError
*/
function isStorageError(error) {
	return typeof error === "object" && error !== null && "__isStorageError" in error;
}
/**
* API error returned from Storage service
* Includes HTTP status code and service-specific error code
*/
var StorageApiError = class extends StorageError {
	constructor(message, status, statusCode, namespace = "storage") {
		super(message, namespace, status, statusCode);
		this.name = namespace === "vectors" ? "StorageVectorsApiError" : "StorageApiError";
		this.status = status;
		this.statusCode = statusCode;
	}
	toJSON() {
		return _objectSpread2({}, super.toJSON());
	}
};
/**
* Unknown error that doesn't match expected error patterns
* Wraps the original error for debugging
*/
var StorageUnknownError = class extends StorageError {
	constructor(message, originalError, namespace = "storage") {
		super(message, namespace);
		this.name = namespace === "vectors" ? "StorageVectorsUnknownError" : "StorageUnknownError";
		this.originalError = originalError;
	}
};
/**
* @deprecated Use StorageError with namespace='vectors' instead
* Alias for backward compatibility with existing vector storage code
*/
var StorageVectorsError = class extends StorageError {
	constructor(message) {
		super(message, "vectors");
	}
};
/**
* Type guard to check if an error is a StorageVectorsError
* @param error - The error to check
* @returns True if the error is a StorageVectorsError
*/
function isStorageVectorsError(error) {
	return isStorageError(error) && error["namespace"] === "vectors";
}
/**
* @deprecated Use StorageApiError with namespace='vectors' instead
* Alias for backward compatibility with existing vector storage code
*/
var StorageVectorsApiError = class extends StorageApiError {
	constructor(message, status, statusCode) {
		super(message, status, statusCode, "vectors");
	}
};
/**
* @deprecated Use StorageUnknownError with namespace='vectors' instead
* Alias for backward compatibility with existing vector storage code
*/
var StorageVectorsUnknownError = class extends StorageUnknownError {
	constructor(message, originalError) {
		super(message, originalError, "vectors");
	}
};
/**
* Error codes specific to S3 Vectors API
* Maps AWS service errors to application-friendly error codes
*/
let StorageVectorsErrorCode = /* @__PURE__ */ function(StorageVectorsErrorCode$1) {
	/** Internal server fault (HTTP 500) */
	StorageVectorsErrorCode$1["InternalError"] = "InternalError";
	/** Resource already exists / conflict (HTTP 409) */
	StorageVectorsErrorCode$1["S3VectorConflictException"] = "S3VectorConflictException";
	/** Resource not found (HTTP 404) */
	StorageVectorsErrorCode$1["S3VectorNotFoundException"] = "S3VectorNotFoundException";
	/** Delete bucket while not empty (HTTP 400) */
	StorageVectorsErrorCode$1["S3VectorBucketNotEmpty"] = "S3VectorBucketNotEmpty";
	/** Exceeds bucket quota/limit (HTTP 400) */
	StorageVectorsErrorCode$1["S3VectorMaxBucketsExceeded"] = "S3VectorMaxBucketsExceeded";
	/** Exceeds index quota/limit (HTTP 400) */
	StorageVectorsErrorCode$1["S3VectorMaxIndexesExceeded"] = "S3VectorMaxIndexesExceeded";
	return StorageVectorsErrorCode$1;
}({});

//#endregion
//#region src/lib/common/headers.ts
/**
* Sets a header with case-insensitive deduplication.
* Removes any existing headers whose name matches (case-insensitive),
* then sets the value under the lowercase key. Does not mutate the input object.
*
* @param headers - Existing headers object
* @param name - Header name to set (stored as lowercase)
* @param value - Header value
* @returns New headers object with the header set
*/
function setHeader(headers, name, value) {
	const result = _objectSpread2({}, headers);
	const nameLower = name.toLowerCase();
	for (const key of Object.keys(result)) if (key.toLowerCase() === nameLower) delete result[key];
	result[nameLower] = value;
	return result;
}
/**
* Normalizes all header keys to lowercase with case-insensitive deduplication.
* When duplicate keys exist (differing only in case), the last value wins.
* Does not mutate the input object.
*
* @param headers - Headers object to normalize
* @returns New headers object with all keys lowercased
*/
function normalizeHeaders(headers) {
	const result = {};
	for (const [key, value] of Object.entries(headers)) result[key.toLowerCase()] = value;
	return result;
}

//#endregion
//#region src/lib/common/helpers.ts
/**
* Resolves the fetch implementation to use
* Uses custom fetch if provided, otherwise uses native fetch
*
* @param customFetch - Optional custom fetch implementation
* @returns Resolved fetch function
*/
const resolveFetch = (customFetch) => {
	if (customFetch) return (...args) => customFetch(...args);
	return (...args) => fetch(...args);
};
/**
* Determine if input is a plain object
* An object is plain if it's created by either {}, new Object(), or Object.create(null)
*
* @param value - Value to check
* @returns True if value is a plain object
* @source https://github.com/sindresorhus/is-plain-obj
*/
const isPlainObject = (value) => {
	if (typeof value !== "object" || value === null) return false;
	const prototype = Object.getPrototypeOf(value);
	return (prototype === null || prototype === Object.prototype || Object.getPrototypeOf(prototype) === null) && !(Symbol.toStringTag in value) && !(Symbol.iterator in value);
};
/**
* Recursively converts object keys from snake_case to camelCase
* Used for normalizing API responses
*
* @param item - Object to convert
* @returns Converted object with camelCase keys
*/
const recursiveToCamel = (item) => {
	if (Array.isArray(item)) return item.map((el) => recursiveToCamel(el));
	else if (typeof item === "function" || item !== Object(item)) return item;
	const result = {};
	Object.entries(item).forEach(([key, value]) => {
		const newKey = key.replace(/([-_][a-z])/gi, (c) => c.toUpperCase().replace(/[-_]/g, ""));
		result[newKey] = recursiveToCamel(value);
	});
	return result;
};
/**
* Validates if a given bucket name is valid according to Supabase Storage API rules
* Mirrors backend validation from: storage/src/storage/limits.ts:isValidBucketName()
*
* Rules:
* - Length: 1-100 characters
* - Allowed characters: alphanumeric (a-z, A-Z, 0-9), underscore (_), and safe special characters
* - Safe special characters: ! - . * ' ( ) space & $ @ = ; : + , ?
* - Forbidden: path separators (/, \), path traversal (..), leading/trailing whitespace
*
* AWS S3 Reference: https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-keys.html
*
* @param bucketName - The bucket name to validate
* @returns true if valid, false otherwise
*/
const isValidBucketName = (bucketName) => {
	if (!bucketName || typeof bucketName !== "string") return false;
	if (bucketName.length === 0 || bucketName.length > 100) return false;
	if (bucketName.trim() !== bucketName) return false;
	if (bucketName.includes("/") || bucketName.includes("\\")) return false;
	return /^[\w!.\*'() &$@=;:+,?-]+$/.test(bucketName);
};

//#endregion
//#region src/lib/common/fetch.ts
/**
* Extracts error message from various error response formats
* @param err - Error object from API
* @returns Human-readable error message
*/
const _getErrorMessage = (err) => {
	if (typeof err === "object" && err !== null) {
		const e = err;
		if (typeof e.msg === "string") return e.msg;
		if (typeof e.message === "string") return e.message;
		if (typeof e.error_description === "string") return e.error_description;
		if (typeof e.error === "string") return e.error;
		if (typeof e.error === "object" && e.error !== null) {
			const nested = e.error;
			if (typeof nested.message === "string") return nested.message;
		}
	}
	return JSON.stringify(err);
};
/**
* Handles fetch errors and converts them to Storage error types
* @param error - The error caught from fetch
* @param reject - Promise rejection function
* @param options - Fetch options that may affect error handling
* @param namespace - Error namespace ('storage' or 'vectors')
*/
const handleError = async (error, reject, options, namespace) => {
	if (error !== null && typeof error === "object" && "json" in error && typeof error.json === "function") {
		const responseError = error;
		let status = parseInt(String(responseError.status), 10);
		if (!Number.isFinite(status)) status = 500;
		responseError.json().then((err) => {
			const statusCode = (err === null || err === void 0 ? void 0 : err.statusCode) || (err === null || err === void 0 ? void 0 : err.code) || status + "";
			reject(new StorageApiError(_getErrorMessage(err), status, statusCode, namespace));
		}).catch(() => {
			const statusCode = status + "";
			reject(new StorageApiError(responseError.statusText || `HTTP ${status} error`, status, statusCode, namespace));
		});
	} else reject(new StorageUnknownError(_getErrorMessage(error), error, namespace));
};
/**
* Builds request parameters for fetch calls
* @param method - HTTP method
* @param options - Custom fetch options
* @param parameters - Additional fetch parameters like AbortSignal
* @param body - Request body (will be JSON stringified if plain object)
* @returns Complete fetch request parameters
*/
const _getRequestParams = (method, options, parameters, body) => {
	const params = {
		method,
		headers: (options === null || options === void 0 ? void 0 : options.headers) || {}
	};
	if (method === "GET" || method === "HEAD" || !body) return _objectSpread2(_objectSpread2({}, params), parameters);
	if (isPlainObject(body)) {
		var _contentType;
		const headers = (options === null || options === void 0 ? void 0 : options.headers) || {};
		let contentType;
		for (const [key, value] of Object.entries(headers)) if (key.toLowerCase() === "content-type") contentType = value;
		params.headers = setHeader(headers, "Content-Type", (_contentType = contentType) !== null && _contentType !== void 0 ? _contentType : "application/json");
		params.body = JSON.stringify(body);
	} else params.body = body;
	if (options === null || options === void 0 ? void 0 : options.duplex) params.duplex = options.duplex;
	return _objectSpread2(_objectSpread2({}, params), parameters);
};
/**
* Internal request handler that wraps fetch with error handling
* @param fetcher - Fetch function to use
* @param method - HTTP method
* @param url - Request URL
* @param options - Custom fetch options
* @param parameters - Additional fetch parameters
* @param body - Request body
* @param namespace - Error namespace ('storage' or 'vectors')
* @returns Promise with parsed response or error
*/
async function _handleRequest(fetcher, method, url, options, parameters, body, namespace) {
	return new Promise((resolve, reject) => {
		fetcher(url, _getRequestParams(method, options, parameters, body)).then((result) => {
			if (!result.ok) throw result;
			if (options === null || options === void 0 ? void 0 : options.noResolveJson) return result;
			if (namespace === "vectors") {
				const contentType = result.headers.get("content-type");
				if (result.headers.get("content-length") === "0" || result.status === 204) return {};
				if (!contentType || !contentType.includes("application/json")) return {};
			}
			return result.json();
		}).then((data) => resolve(data)).catch((error) => handleError(error, reject, options, namespace));
	});
}
/**
* Creates a fetch API with the specified namespace
* @param namespace - Error namespace ('storage' or 'vectors')
* @returns Object with HTTP method functions
*/
function createFetchApi(namespace = "storage") {
	return {
		get: async (fetcher, url, options, parameters) => {
			return _handleRequest(fetcher, "GET", url, options, parameters, void 0, namespace);
		},
		post: async (fetcher, url, body, options, parameters) => {
			return _handleRequest(fetcher, "POST", url, options, parameters, body, namespace);
		},
		put: async (fetcher, url, body, options, parameters) => {
			return _handleRequest(fetcher, "PUT", url, options, parameters, body, namespace);
		},
		head: async (fetcher, url, options, parameters) => {
			return _handleRequest(fetcher, "HEAD", url, _objectSpread2(_objectSpread2({}, options), {}, { noResolveJson: true }), parameters, void 0, namespace);
		},
		remove: async (fetcher, url, body, options, parameters) => {
			return _handleRequest(fetcher, "DELETE", url, options, parameters, body, namespace);
		}
	};
}
const defaultApi = createFetchApi("storage");
const { get, post, put, head, remove } = defaultApi;
const vectorsApi = createFetchApi("vectors");

//#endregion
//#region src/lib/common/BaseApiClient.ts
/**
* @ignore
* Base API client class for all Storage API classes
* Provides common infrastructure for error handling and configuration
*
* @typeParam TError - The error type (StorageError or subclass)
*/
var BaseApiClient = class {
	/**
	* Creates a new BaseApiClient instance
	* @param url - Base URL for API requests
	* @param headers - Default headers for API requests
	* @param fetch - Optional custom fetch implementation
	* @param namespace - Error namespace ('storage' or 'vectors')
	*/
	constructor(url, headers = {}, fetch$1, namespace = "storage") {
		this.shouldThrowOnError = false;
		this.url = url;
		this.headers = normalizeHeaders(headers);
		this.fetch = resolveFetch(fetch$1);
		this.namespace = namespace;
	}
	/**
	* Enable throwing errors instead of returning them.
	* When enabled, errors are thrown instead of returned in { data, error } format.
	*
	* @returns this - For method chaining
	*/
	throwOnError() {
		this.shouldThrowOnError = true;
		return this;
	}
	/**
	* Set an HTTP header for the request.
	* Creates a shallow copy of headers to avoid mutating shared state.
	*
	* @param name - Header name
	* @param value - Header value
	* @returns this - For method chaining
	*/
	setHeader(name, value) {
		this.headers = setHeader(this.headers, name, value);
		return this;
	}
	/**
	* Handles API operation with standardized error handling
	* Eliminates repetitive try-catch blocks across all API methods
	*
	* This wrapper:
	* 1. Executes the operation
	* 2. Returns { data, error: null } on success
	* 3. Returns { data: null, error } on failure (if shouldThrowOnError is false)
	* 4. Throws error on failure (if shouldThrowOnError is true)
	*
	* @typeParam T - The expected data type from the operation
	* @param operation - Async function that performs the API call
	* @returns Promise with { data, error } tuple
	*
	* @example Handling an operation
	* ```typescript
	* async listBuckets() {
	*   return this.handleOperation(async () => {
	*     return await get(this.fetch, `${this.url}/bucket`, {
	*       headers: this.headers,
	*     })
	*   })
	* }
	* ```
	*/
	async handleOperation(operation) {
		var _this = this;
		try {
			return {
				data: await operation(),
				error: null
			};
		} catch (error) {
			if (_this.shouldThrowOnError) throw error;
			if (isStorageError(error)) return {
				data: null,
				error
			};
			throw error;
		}
	}
};

//#endregion
//#region src/packages/StreamDownloadBuilder.ts
let _Symbol$toStringTag$1;
_Symbol$toStringTag$1 = Symbol.toStringTag;
var StreamDownloadBuilder = class {
	constructor(downloadFn, shouldThrowOnError) {
		this.downloadFn = downloadFn;
		this.shouldThrowOnError = shouldThrowOnError;
		this[_Symbol$toStringTag$1] = "StreamDownloadBuilder";
		this.promise = null;
	}
	then(onfulfilled, onrejected) {
		return this.getPromise().then(onfulfilled, onrejected);
	}
	catch(onrejected) {
		return this.getPromise().catch(onrejected);
	}
	finally(onfinally) {
		return this.getPromise().finally(onfinally);
	}
	getPromise() {
		if (!this.promise) this.promise = this.execute();
		return this.promise;
	}
	async execute() {
		var _this = this;
		try {
			return {
				data: (await _this.downloadFn()).body,
				error: null
			};
		} catch (error) {
			if (_this.shouldThrowOnError) throw error;
			if (isStorageError(error)) return {
				data: null,
				error
			};
			throw error;
		}
	}
};

//#endregion
//#region src/packages/BlobDownloadBuilder.ts
let _Symbol$toStringTag;
_Symbol$toStringTag = Symbol.toStringTag;
var BlobDownloadBuilder = class {
	constructor(downloadFn, shouldThrowOnError) {
		this.downloadFn = downloadFn;
		this.shouldThrowOnError = shouldThrowOnError;
		this[_Symbol$toStringTag] = "BlobDownloadBuilder";
		this.promise = null;
	}
	asStream() {
		return new StreamDownloadBuilder(this.downloadFn, this.shouldThrowOnError);
	}
	then(onfulfilled, onrejected) {
		return this.getPromise().then(onfulfilled, onrejected);
	}
	catch(onrejected) {
		return this.getPromise().catch(onrejected);
	}
	finally(onfinally) {
		return this.getPromise().finally(onfinally);
	}
	getPromise() {
		if (!this.promise) this.promise = this.execute();
		return this.promise;
	}
	async execute() {
		var _this = this;
		try {
			return {
				data: await (await _this.downloadFn()).blob(),
				error: null
			};
		} catch (error) {
			if (_this.shouldThrowOnError) throw error;
			if (isStorageError(error)) return {
				data: null,
				error
			};
			throw error;
		}
	}
};

//#endregion
//#region src/packages/StorageFileApi.ts
const DEFAULT_SEARCH_OPTIONS = {
	limit: 100,
	offset: 0,
	sortBy: {
		column: "name",
		order: "asc"
	}
};
const DEFAULT_FILE_OPTIONS = {
	cacheControl: "3600",
	contentType: "text/plain;charset=UTF-8",
	upsert: false
};
var StorageFileApi = class extends BaseApiClient {
	constructor(url, headers = {}, bucketId, fetch$1) {
		super(url, headers, fetch$1, "storage");
		this.bucketId = bucketId;
	}
	/**
	* Uploads a file to an existing bucket or replaces an existing file at the specified path with a new one.
	*
	* @param method HTTP method.
	* @param path The relative file path. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
	* @param fileBody The body of the file to be stored in the bucket.
	*/
	async uploadOrUpdate(method, path, fileBody, fileOptions) {
		var _this = this;
		return _this.handleOperation(async () => {
			let body;
			const options = _objectSpread2(_objectSpread2({}, DEFAULT_FILE_OPTIONS), fileOptions);
			let headers = _objectSpread2(_objectSpread2({}, _this.headers), method === "POST" && { "x-upsert": String(options.upsert) });
			const metadata = options.metadata;
			if (typeof Blob !== "undefined" && fileBody instanceof Blob) {
				body = new FormData();
				body.append("cacheControl", options.cacheControl);
				if (metadata) body.append("metadata", _this.encodeMetadata(metadata));
				body.append("", fileBody);
			} else if (typeof FormData !== "undefined" && fileBody instanceof FormData) {
				body = fileBody;
				if (!body.has("cacheControl")) body.append("cacheControl", options.cacheControl);
				if (metadata && !body.has("metadata")) body.append("metadata", _this.encodeMetadata(metadata));
			} else {
				body = fileBody;
				headers["cache-control"] = `max-age=${options.cacheControl}`;
				headers["content-type"] = options.contentType;
				if (metadata) headers["x-metadata"] = _this.toBase64(_this.encodeMetadata(metadata));
				if ((typeof ReadableStream !== "undefined" && body instanceof ReadableStream || body && typeof body === "object" && "pipe" in body && typeof body.pipe === "function") && !options.duplex) options.duplex = "half";
			}
			if (fileOptions === null || fileOptions === void 0 ? void 0 : fileOptions.headers) for (const [key, value] of Object.entries(fileOptions.headers)) headers = setHeader(headers, key, value);
			const cleanPath = _this._removeEmptyFolders(path);
			const _path = _this._getFinalPath(cleanPath);
			const data = await (method == "PUT" ? put : post)(_this.fetch, `${_this.url}/object/${_path}`, body, _objectSpread2({ headers }, (options === null || options === void 0 ? void 0 : options.duplex) ? { duplex: options.duplex } : {}));
			return {
				path: cleanPath,
				id: data.Id,
				fullPath: data.Key
			};
		});
	}
	/**
	* Uploads a file to an existing bucket.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The file path, including the file name. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
	* @param fileBody The body of the file to be stored in the bucket.
	* @param fileOptions Optional file upload options including cacheControl, contentType, upsert, and metadata.
	* @returns Promise with response containing file path, id, and fullPath or error
	*
	* @example Upload file
	* ```js
	* const avatarFile = event.target.files[0]
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .upload('public/avatar1.png', avatarFile, {
	*     cacheControl: '3600',
	*     upsert: false
	*   })
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "path": "public/avatar1.png",
	*     "fullPath": "avatars/public/avatar1.png"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @example Upload file using `ArrayBuffer` from base64 file data
	* ```js
	* import { decode } from 'base64-arraybuffer'
	*
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .upload('public/avatar1.png', decode('base64FileData'), {
	*     contentType: 'image/png'
	*   })
	* ```
	*
	* @example Handling errors
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .upload('public/avatar1.png', avatarFile)
	*
	* if (error) {
	*   // Log the full error so fields like `statusCode` and `error` (the
	*   // Storage error name, e.g. "Duplicate") aren't hidden behind `error.message`.
	*   console.error(error)
	*   return
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: only `insert` when you are uploading new files and `select`, `insert` and `update` when you are upserting files
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	* - For React Native, using either `Blob`, `File` or `FormData` does not work as intended. Upload file using `ArrayBuffer` from base64 file data instead, see example below.
	*/
	async upload(path, fileBody, fileOptions) {
		return this.uploadOrUpdate("POST", path, fileBody, fileOptions);
	}
	/**
	* Upload a file with a token generated from `createSignedUploadUrl`.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The file path, including the file name. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
	* @param token The token generated from `createSignedUploadUrl`
	* @param fileBody The body of the file to be stored in the bucket.
	* @param fileOptions HTTP headers (cacheControl, contentType, etc.).
	* **Note:** The `upsert` option has no effect here. To enable upsert behavior,
	* pass `{ upsert: true }` when calling `createSignedUploadUrl()` instead.
	* @returns Promise with response containing file path and fullPath or error
	*
	* @example Upload to a signed URL
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .uploadToSignedUrl('folder/cat.jpg', 'token-from-createSignedUploadUrl', file)
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "path": "folder/cat.jpg",
	*     "fullPath": "avatars/folder/cat.jpg"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: none
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async uploadToSignedUrl(path, token, fileBody, fileOptions) {
		var _this3 = this;
		const cleanPath = _this3._removeEmptyFolders(path);
		const _path = _this3._getFinalPath(cleanPath);
		const url = new URL(_this3.url + `/object/upload/sign/${_path}`);
		url.searchParams.set("token", token);
		return _this3.handleOperation(async () => {
			let body;
			const options = _objectSpread2(_objectSpread2({}, DEFAULT_FILE_OPTIONS), fileOptions);
			let headers = _objectSpread2(_objectSpread2({}, _this3.headers), { "x-upsert": String(options.upsert) });
			const metadata = options.metadata;
			if (typeof Blob !== "undefined" && fileBody instanceof Blob) {
				body = new FormData();
				body.append("cacheControl", options.cacheControl);
				if (metadata) body.append("metadata", _this3.encodeMetadata(metadata));
				body.append("", fileBody);
			} else if (typeof FormData !== "undefined" && fileBody instanceof FormData) {
				body = fileBody;
				if (!body.has("cacheControl")) body.append("cacheControl", options.cacheControl);
				if (metadata && !body.has("metadata")) body.append("metadata", _this3.encodeMetadata(metadata));
			} else {
				body = fileBody;
				headers["cache-control"] = `max-age=${options.cacheControl}`;
				headers["content-type"] = options.contentType;
				if (metadata) headers["x-metadata"] = _this3.toBase64(_this3.encodeMetadata(metadata));
				if ((typeof ReadableStream !== "undefined" && body instanceof ReadableStream || body && typeof body === "object" && "pipe" in body && typeof body.pipe === "function") && !options.duplex) options.duplex = "half";
			}
			if (fileOptions === null || fileOptions === void 0 ? void 0 : fileOptions.headers) for (const [key, value] of Object.entries(fileOptions.headers)) headers = setHeader(headers, key, value);
			return {
				path: cleanPath,
				fullPath: (await put(_this3.fetch, url.toString(), body, _objectSpread2({ headers }, (options === null || options === void 0 ? void 0 : options.duplex) ? { duplex: options.duplex } : {}))).Key
			};
		});
	}
	/**
	* Creates a signed upload URL.
	* Signed upload URLs can be used to upload files to the bucket without further authentication.
	* They are valid for 2 hours.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The file path, including the current file name. For example `folder/image.png`.
	* @param options.upsert If set to true, allows the file to be overwritten if it already exists.
	* @returns Promise with response containing signed upload URL, token, and path or error
	*
	* @example Create Signed Upload URL
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .createSignedUploadUrl('folder/cat.jpg')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "signedUrl": "https://example.supabase.co/storage/v1/object/upload/sign/avatars/folder/cat.jpg?token=<TOKEN>",
	*     "path": "folder/cat.jpg",
	*     "token": "<TOKEN>"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `insert`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async createSignedUploadUrl(path, options) {
		var _this4 = this;
		return _this4.handleOperation(async () => {
			let _path = _this4._getFinalPath(path);
			const headers = _objectSpread2({}, _this4.headers);
			if (options === null || options === void 0 ? void 0 : options.upsert) headers["x-upsert"] = "true";
			const data = await post(_this4.fetch, `${_this4.url}/object/upload/sign/${_path}`, {}, { headers });
			const url = new URL(_this4.url + data.url);
			const token = url.searchParams.get("token");
			if (!token) throw new StorageError("No token returned by API");
			return {
				signedUrl: url.toString(),
				path,
				token
			};
		});
	}
	/**
	* Replaces an existing file at the specified path with a new one.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The relative file path. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to update.
	* @param fileBody The body of the file to be stored in the bucket.
	* @param fileOptions Optional file upload options including cacheControl, contentType, and metadata.
	* **Note:** The `upsert` option has no effect here. `update()` always replaces the
	* file at the given path, so the `x-upsert` header is not sent. To control upsert
	* behavior, use `upload()` instead.
	* @returns Promise with response containing file path, id, and fullPath or error
	*
	* @example Update file
	* ```js
	* const avatarFile = event.target.files[0]
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .update('public/avatar1.png', avatarFile, {
	*     cacheControl: '3600'
	*   })
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "path": "public/avatar1.png",
	*     "fullPath": "avatars/public/avatar1.png"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @example Update file using `ArrayBuffer` from base64 file data
	* ```js
	* import {decode} from 'base64-arraybuffer'
	*
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .update('public/avatar1.png', decode('base64FileData'), {
	*     contentType: 'image/png'
	*   })
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `update` and `select`
	* - `update()` always replaces the file at the given path regardless of the `upsert` option.
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	* - For React Native, using either `Blob`, `File` or `FormData` does not work as intended. Update file using `ArrayBuffer` from base64 file data instead, see example below.
	*/
	async update(path, fileBody, fileOptions) {
		return this.uploadOrUpdate("PUT", path, fileBody, fileOptions);
	}
	/**
	* Moves an existing file to a new path in the same bucket.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param fromPath The original file path, including the current file name. For example `folder/image.png`.
	* @param toPath The new file path, including the new file name. For example `folder/image-new.png`.
	* @param options The destination options.
	* @returns Promise with response containing success message or error
	*
	* @example Move file
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .move('public/avatar1.png', 'private/avatar2.png')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "message": "Successfully moved"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `update` and `select`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async move(fromPath, toPath, options) {
		var _this6 = this;
		return _this6.handleOperation(async () => {
			return await post(_this6.fetch, `${_this6.url}/object/move`, {
				bucketId: _this6.bucketId,
				sourceKey: fromPath,
				destinationKey: toPath,
				destinationBucket: options === null || options === void 0 ? void 0 : options.destinationBucket
			}, { headers: _this6.headers });
		});
	}
	/**
	* Copies an existing file to a new path in the same bucket.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param fromPath The original file path, including the current file name. For example `folder/image.png`.
	* @param toPath The new file path, including the new file name. For example `folder/image-copy.png`.
	* @param options The destination options.
	* @returns Promise with response containing copied file path or error
	*
	* @example Copy file
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .copy('public/avatar1.png', 'private/avatar2.png')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "path": "avatars/private/avatar2.png"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `insert` and `select`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async copy(fromPath, toPath, options) {
		var _this7 = this;
		return _this7.handleOperation(async () => {
			return { path: (await post(_this7.fetch, `${_this7.url}/object/copy`, {
				bucketId: _this7.bucketId,
				sourceKey: fromPath,
				destinationKey: toPath,
				destinationBucket: options === null || options === void 0 ? void 0 : options.destinationBucket
			}, { headers: _this7.headers })).Key };
		});
	}
	/**
	* Creates a signed URL. Use a signed URL to share a file for a fixed amount of time.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The file path, including the current file name. For example `folder/image.png`.
	* @param expiresIn The number of seconds until the signed URL expires. For example, `60` for a URL which is valid for one minute.
	* @param options.download triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
	* @param options.transform Transform the asset before serving it to the client.
	* @param options.cacheNonce Append a cache nonce parameter to the URL to invalidate the cache.
	* @returns Promise with response containing signed URL or error
	*
	* @example Create Signed URL
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .createSignedUrl('folder/avatar1.png', 60)
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar1.png?token=<TOKEN>"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @example Create a signed URL for an asset with transformations
	* ```js
	* const { data } = await supabase
	*   .storage
	*   .from('avatars')
	*   .createSignedUrl('folder/avatar1.png', 60, {
	*     transform: {
	*       width: 100,
	*       height: 100,
	*     }
	*   })
	* ```
	*
	* @example Create a signed URL which triggers the download of the asset
	* ```js
	* const { data } = await supabase
	*   .storage
	*   .from('avatars')
	*   .createSignedUrl('folder/avatar1.png', 60, {
	*     download: true,
	*   })
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `select`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async createSignedUrl(path, expiresIn, options) {
		var _this8 = this;
		return _this8.handleOperation(async () => {
			let _path = _this8._getFinalPath(path);
			const hasTransform = typeof (options === null || options === void 0 ? void 0 : options.transform) === "object" && options.transform !== null && Object.keys(options.transform).length > 0;
			let data = await post(_this8.fetch, `${_this8.url}/object/sign/${_path}`, _objectSpread2({ expiresIn }, hasTransform ? { transform: options.transform } : {}), { headers: _this8.headers });
			const query = new URLSearchParams();
			if (options === null || options === void 0 ? void 0 : options.download) query.set("download", options.download === true ? "" : options.download);
			if ((options === null || options === void 0 ? void 0 : options.cacheNonce) != null) query.set("cacheNonce", String(options.cacheNonce));
			const queryString = query.toString();
			return { signedUrl: encodeURI(`${_this8.url}${data.signedURL}${queryString ? `&${queryString}` : ""}`) };
		});
	}
	/**
	* Creates multiple signed URLs. Use a signed URL to share a file for a fixed amount of time.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param paths The file paths to be downloaded, including the current file names. For example `['folder/image.png', 'folder2/image2.png']`.
	* @param expiresIn The number of seconds until the signed URLs expire. For example, `60` for URLs which are valid for one minute.
	* @param options.download triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
	* @param options.cacheNonce Append a cache nonce parameter to the URL to invalidate the cache.
	* @returns Promise with response containing array of objects with signedUrl, path, and error or error
	*
	* @example Create Signed URLs
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .createSignedUrls(['folder/avatar1.png', 'folder/avatar2.png'], 60)
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": [
	*     {
	*       "error": null,
	*       "path": "folder/avatar1.png",
	*       "signedURL": "/object/sign/avatars/folder/avatar1.png?token=<TOKEN>",
	*       "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar1.png?token=<TOKEN>"
	*     },
	*     {
	*       "error": null,
	*       "path": "folder/avatar2.png",
	*       "signedURL": "/object/sign/avatars/folder/avatar2.png?token=<TOKEN>",
	*       "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar2.png?token=<TOKEN>"
	*     }
	*   ],
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `select`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async createSignedUrls(paths, expiresIn, options) {
		var _this9 = this;
		return _this9.handleOperation(async () => {
			const data = await post(_this9.fetch, `${_this9.url}/object/sign/${_this9.bucketId}`, {
				expiresIn,
				paths
			}, { headers: _this9.headers });
			const query = new URLSearchParams();
			if (options === null || options === void 0 ? void 0 : options.download) query.set("download", options.download === true ? "" : options.download);
			if ((options === null || options === void 0 ? void 0 : options.cacheNonce) != null) query.set("cacheNonce", String(options.cacheNonce));
			const queryString = query.toString();
			return data.map((datum) => _objectSpread2(_objectSpread2({}, datum), {}, { signedUrl: datum.signedURL ? encodeURI(`${_this9.url}${datum.signedURL}${queryString ? `&${queryString}` : ""}`) : null }));
		});
	}
	/**
	* Downloads a file from a private bucket. For public buckets, make a request to the URL returned from `getPublicUrl` instead.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The full path and file name of the file to be downloaded. For example `folder/image.png`.
	* @param options.transform Transform the asset before serving it to the client.
	* @param options.cacheNonce Append a cache nonce parameter to the URL to invalidate the cache.
	* @param parameters Additional fetch parameters like signal for cancellation. Supports standard fetch options including cache control.
	* @returns BlobDownloadBuilder instance for downloading the file
	*
	* @example Download file
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .download('folder/avatar1.png')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": <BLOB>,
	*   "error": null
	* }
	* ```
	*
	* @example Download file with transformations
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .download('folder/avatar1.png', {
	*     transform: {
	*       width: 100,
	*       height: 100,
	*       quality: 80
	*     }
	*   })
	* ```
	*
	* @example Download with cache control (useful in Edge Functions)
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .download('folder/avatar1.png', {}, { cache: 'no-store' })
	* ```
	*
	* @example Download with abort signal
	* ```js
	* const controller = new AbortController()
	* setTimeout(() => controller.abort(), 5000)
	*
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .download('folder/avatar1.png', {}, { signal: controller.signal })
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `select`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	download(path, options, parameters) {
		const renderPath = typeof (options === null || options === void 0 ? void 0 : options.transform) === "object" && options.transform !== null && Object.keys(options.transform).length > 0 ? "render/image/authenticated" : "object";
		const query = new URLSearchParams();
		if (options === null || options === void 0 ? void 0 : options.transform) this.applyTransformOptsToQuery(query, options.transform);
		if ((options === null || options === void 0 ? void 0 : options.cacheNonce) != null) query.set("cacheNonce", String(options.cacheNonce));
		const queryString = query.toString();
		const _path = this._getFinalPath(path);
		const downloadFn = () => get(this.fetch, `${this.url}/${renderPath}/${_path}${queryString ? `?${queryString}` : ""}`, {
			headers: this.headers,
			noResolveJson: true
		}, parameters);
		return new BlobDownloadBuilder(downloadFn, this.shouldThrowOnError);
	}
	/**
	* Retrieves the details of an existing file.
	*
	* Returns detailed file metadata including size, content type, and timestamps.
	* Note: The API returns `last_modified` field, not `updated_at`.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The file path, including the file name. For example `folder/image.png`.
	* @returns Promise with response containing file metadata or error
	*
	* @example Get file info
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .info('folder/avatar1.png')
	*
	* if (data) {
	*   console.log('Last modified:', data.lastModified)
	*   console.log('Size:', data.size)
	* }
	* ```
	*/
	async info(path) {
		var _this10 = this;
		const _path = _this10._getFinalPath(path);
		return _this10.handleOperation(async () => {
			return recursiveToCamel(await get(_this10.fetch, `${_this10.url}/object/info/${_path}`, { headers: _this10.headers }));
		});
	}
	/**
	* Checks the existence of a file.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The file path, including the file name. For example `folder/image.png`.
	* @returns Promise with response containing boolean indicating file existence or error
	*
	* @example Check file existence
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .exists('folder/avatar1.png')
	* ```
	*/
	async exists(path) {
		var _this11 = this;
		const _path = _this11._getFinalPath(path);
		try {
			await head(_this11.fetch, `${_this11.url}/object/${_path}`, { headers: _this11.headers });
			return {
				data: true,
				error: null
			};
		} catch (error) {
			if (_this11.shouldThrowOnError) throw error;
			if (isStorageError(error)) {
				var _error$originalError;
				const status = error instanceof StorageApiError ? error.status : error instanceof StorageUnknownError ? (_error$originalError = error.originalError) === null || _error$originalError === void 0 ? void 0 : _error$originalError.status : void 0;
				if (status !== void 0 && [400, 404].includes(status)) return {
					data: false,
					error
				};
			}
			throw error;
		}
	}
	/**
	* A simple convenience function to get the URL for an asset in a public bucket. If you do not want to use this function, you can construct the public URL by concatenating the bucket URL with the path to the asset.
	* This function does not verify if the bucket is public. If a public URL is created for a bucket which is not public, you will not be able to download the asset.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The path and name of the file to generate the public URL for. For example `folder/image.png`.
	* @param options.download Triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
	* @param options.transform Transform the asset before serving it to the client.
	* @param options.cacheNonce Append a cache nonce parameter to the URL to invalidate the cache.
	* @returns Object with public URL
	*
	* @example Returns the URL for an asset in a public bucket
	* ```js
	* const { data } = supabase
	*   .storage
	*   .from('public-bucket')
	*   .getPublicUrl('folder/avatar1.png')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "publicUrl": "https://example.supabase.co/storage/v1/object/public/public-bucket/folder/avatar1.png"
	*   }
	* }
	* ```
	*
	* @example Returns the URL for an asset in a public bucket with transformations
	* ```js
	* const { data } = supabase
	*   .storage
	*   .from('public-bucket')
	*   .getPublicUrl('folder/avatar1.png', {
	*     transform: {
	*       width: 100,
	*       height: 100,
	*     }
	*   })
	* ```
	*
	* @example Returns the URL which triggers the download of an asset in a public bucket
	* ```js
	* const { data } = supabase
	*   .storage
	*   .from('public-bucket')
	*   .getPublicUrl('folder/avatar1.png', {
	*     download: true,
	*   })
	* ```
	*
	* @remarks
	* - The bucket needs to be set to public, either via [updateBucket()](/docs/reference/javascript/storage-updatebucket) or by going to Storage on [supabase.com/dashboard](https://supabase.com/dashboard), clicking the overflow menu on a bucket and choosing "Make public"
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: none
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	getPublicUrl(path, options) {
		const _path = this._getFinalPath(path);
		const query = new URLSearchParams();
		if (options === null || options === void 0 ? void 0 : options.download) query.set("download", options.download === true ? "" : options.download);
		if (options === null || options === void 0 ? void 0 : options.transform) this.applyTransformOptsToQuery(query, options.transform);
		if ((options === null || options === void 0 ? void 0 : options.cacheNonce) != null) query.set("cacheNonce", String(options.cacheNonce));
		const queryString = query.toString();
		const renderPath = typeof (options === null || options === void 0 ? void 0 : options.transform) === "object" && options.transform !== null && Object.keys(options.transform).length > 0 ? "render/image" : "object";
		return { data: { publicUrl: encodeURI(`${this.url}/${renderPath}/public/${_path}`) + (queryString ? `?${queryString}` : "") } };
	}
	/**
	* Deletes files within the same bucket
	*
	* Returns an array of FileObject entries for the deleted files. Note that deprecated
	* fields like `bucket_id` may or may not be present in the response - do not rely on them.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param paths An array of files to delete, including the path and file name. For example [`'folder/image.png'`].
	* @returns Promise with response containing array of deleted file objects or error
	*
	* @example Delete file
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .remove(['folder/avatar1.png'])
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": [],
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `delete` and `select`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async remove(paths) {
		var _this12 = this;
		return _this12.handleOperation(async () => {
			return await remove(_this12.fetch, `${_this12.url}/object/${_this12.bucketId}`, { prefixes: paths }, { headers: _this12.headers });
		});
	}
	/**
	* Get file metadata
	* @param id the file id to retrieve metadata
	*/
	/**
	* Update file metadata
	* @param id the file id to update metadata
	* @param meta the new file metadata
	*/
	/**
	* Lists all the files and folders within a path of the bucket.
	*
	* **Important:** For folder entries, fields like `id`, `updated_at`, `created_at`,
	* `last_accessed_at`, and `metadata` will be `null`. Only files have these fields populated.
	* Additionally, deprecated fields like `bucket_id`, `owner`, and `buckets` are NOT returned
	* by this method.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param path The folder path.
	* @param options Search options including limit (defaults to 100), offset, sortBy, and search
	* @param parameters Optional fetch parameters including signal for cancellation
	* @returns Promise with response containing array of files/folders or error
	*
	* @example List files in a bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .list('folder', {
	*     limit: 100,
	*     offset: 0,
	*     sortBy: { column: 'name', order: 'asc' },
	*   })
	*
	* // Handle files vs folders
	* data?.forEach(item => {
	*   if (item.id !== null) {
	*     // It's a file
	*     console.log('File:', item.name, 'Size:', item.metadata?.size)
	*   } else {
	*     // It's a folder
	*     console.log('Folder:', item.name)
	*   }
	* })
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "avatar1.png",
	*       "id": "e668cf7f-821b-4a2f-9dce-7dfa5dd1cfd2",
	*       "updated_at": "2024-05-22T23:06:05.580Z",
	*       "created_at": "2024-05-22T23:04:34.443Z",
	*       "last_accessed_at": "2024-05-22T23:04:34.443Z",
	*       "metadata": {
	*         "eTag": "\"c5e8c553235d9af30ef4f6e280790b92\"",
	*         "size": 32175,
	*         "mimetype": "image/png",
	*         "cacheControl": "max-age=3600",
	*         "lastModified": "2024-05-22T23:06:05.574Z",
	*         "contentLength": 32175,
	*         "httpStatusCode": 200
	*       }
	*     }
	*   ],
	*   "error": null
	* }
	* ```
	*
	* @example Search files in a bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .list('folder', {
	*     limit: 100,
	*     offset: 0,
	*     sortBy: { column: 'name', order: 'asc' },
	*     search: 'jon'
	*   })
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: none
	*   - `objects` table permissions: `select`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async list(path, options, parameters) {
		var _this13 = this;
		return _this13.handleOperation(async () => {
			const body = _objectSpread2(_objectSpread2(_objectSpread2({}, DEFAULT_SEARCH_OPTIONS), options), {}, { prefix: path || "" });
			return await post(_this13.fetch, `${_this13.url}/object/list/${_this13.bucketId}`, body, { headers: _this13.headers }, parameters);
		});
	}
	/**
	* Lists all the files and folders within a bucket using the V2 API with pagination support.
	*
	* **Important:** Folder entries in the `folders` array only contain `name` and optionally `key` —
	* they have no `id`, timestamps, or `metadata` fields. Full file metadata is only available
	* on entries in the `objects` array.
	*
	* @experimental this method signature might change in the future
	*
	* @category Storage
	* @subcategory File Buckets
	* @param options Search options including prefix, cursor for pagination, limit, with_delimiter
	* @param parameters Optional fetch parameters including signal for cancellation
	* @returns Promise with response containing folders/objects arrays with pagination info or error
	*
	* @example List files with pagination
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .from('avatars')
	*   .listV2({
	*     prefix: 'folder/',
	*     limit: 100,
	*   })
	*
	* // Handle pagination
	* if (data?.hasNext) {
	*   const nextPage = await supabase
	*     .storage
	*     .from('avatars')
	*     .listV2({
	*       prefix: 'folder/',
	*       cursor: data.nextCursor,
	*     })
	* }
	*
	* // Handle files vs folders
	* data?.objects.forEach(file => {
	*   if (file.id !== null) {
	*     console.log('File:', file.name, 'Size:', file.metadata?.size)
	*   }
	* })
	* data?.folders.forEach(folder => {
	*   console.log('Folder:', folder.name)
	* })
	* ```
	*/
	async listV2(options, parameters) {
		var _this14 = this;
		return _this14.handleOperation(async () => {
			const body = _objectSpread2({}, options);
			return await post(_this14.fetch, `${_this14.url}/object/list-v2/${_this14.bucketId}`, body, { headers: _this14.headers }, parameters);
		});
	}
	encodeMetadata(metadata) {
		return JSON.stringify(metadata);
	}
	toBase64(data) {
		if (typeof Buffer !== "undefined") return Buffer.from(data).toString("base64");
		return btoa(data);
	}
	_getFinalPath(path) {
		return `${this.bucketId}/${path.replace(/^\/+/, "")}`;
	}
	_removeEmptyFolders(path) {
		return path.replace(/^\/|\/$/g, "").replace(/\/+/g, "/");
	}
	/** Modifies the `query`, appending values the from `transform` */
	applyTransformOptsToQuery(query, transform) {
		if (transform.width) query.set("width", transform.width.toString());
		if (transform.height) query.set("height", transform.height.toString());
		if (transform.resize) query.set("resize", transform.resize);
		if (transform.format) query.set("format", transform.format);
		if (transform.quality) query.set("quality", transform.quality.toString());
		return query;
	}
};

//#endregion
//#region src/lib/version.ts
const version = "2.108.1";

//#endregion
//#region src/lib/constants.ts
const DEFAULT_HEADERS = { "X-Client-Info": `storage-js/${version}` };

//#endregion
//#region src/packages/StorageBucketApi.ts
var StorageBucketApi = class extends BaseApiClient {
	constructor(url, headers = {}, fetch$1, opts) {
		const baseUrl = new URL(url);
		if (opts === null || opts === void 0 ? void 0 : opts.useNewHostname) {
			if (/supabase\.(co|in|red)$/.test(baseUrl.hostname) && !baseUrl.hostname.includes("storage.supabase.")) baseUrl.hostname = baseUrl.hostname.replace("supabase.", "storage.supabase.");
		}
		const finalUrl = baseUrl.href.replace(/\/$/, "");
		const finalHeaders = _objectSpread2(_objectSpread2({}, DEFAULT_HEADERS), headers);
		super(finalUrl, finalHeaders, fetch$1, "storage");
	}
	/**
	* Retrieves the details of all Storage buckets within an existing project.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param options Query parameters for listing buckets
	* @param options.limit Maximum number of buckets to return
	* @param options.offset Number of buckets to skip
	* @param options.sortColumn Column to sort by ('id', 'name', 'created_at', 'updated_at')
	* @param options.sortOrder Sort order ('asc' or 'desc')
	* @param options.search Search term to filter bucket names
	* @returns Promise with response containing array of buckets or error
	*
	* @example List buckets
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .listBuckets()
	* ```
	*
	* @example List buckets with options
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .listBuckets({
	*     limit: 10,
	*     offset: 0,
	*     sortColumn: 'created_at',
	*     sortOrder: 'desc',
	*     search: 'prod'
	*   })
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: `select`
	*   - `objects` table permissions: none
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async listBuckets(options) {
		var _this = this;
		return _this.handleOperation(async () => {
			const queryString = _this.listBucketOptionsToQueryString(options);
			return await get(_this.fetch, `${_this.url}/bucket${queryString}`, { headers: _this.headers });
		});
	}
	/**
	* Retrieves the details of an existing Storage bucket.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param id The unique identifier of the bucket you would like to retrieve.
	* @returns Promise with response containing bucket details or error
	*
	* @example Get bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .getBucket('avatars')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "id": "avatars",
	*     "name": "avatars",
	*     "owner": "",
	*     "public": false,
	*     "file_size_limit": 1024,
	*     "allowed_mime_types": [
	*       "image/png"
	*     ],
	*     "created_at": "2024-05-22T22:26:05.100Z",
	*     "updated_at": "2024-05-22T22:26:05.100Z"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: `select`
	*   - `objects` table permissions: none
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async getBucket(id) {
		var _this2 = this;
		return _this2.handleOperation(async () => {
			return await get(_this2.fetch, `${_this2.url}/bucket/${id}`, { headers: _this2.headers });
		});
	}
	/**
	* Creates a new Storage bucket
	*
	* @category Storage
	* @subcategory File Buckets
	* @param id A unique identifier for the bucket you are creating.
	* @param options.public The visibility of the bucket. Public buckets don't require an authorization token to download objects, but still require a valid token for all other operations. By default, buckets are private.
	* @param options.fileSizeLimit specifies the max file size in bytes that can be uploaded to this bucket.
	* The global file size limit takes precedence over this value.
	* The default value is null, which doesn't set a per bucket file size limit.
	* @param options.allowedMimeTypes specifies the allowed mime types that this bucket can accept during upload.
	* The default value is null, which allows files with all mime types to be uploaded.
	* Each mime type specified can be a wildcard, e.g. image/*, or a specific mime type, e.g. image/png.
	* @param options.type (private-beta) specifies the bucket type. see `BucketType` for more details.
	*   - default bucket type is `STANDARD`
	* @returns Promise with response containing newly created bucket name or error
	*
	* @example Create bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .createBucket('avatars', {
	*     public: false,
	*     allowedMimeTypes: ['image/png'],
	*     fileSizeLimit: 1024
	*   })
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "name": "avatars"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: `insert`
	*   - `objects` table permissions: none
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async createBucket(id, options = { public: false }) {
		var _this3 = this;
		return _this3.handleOperation(async () => {
			return await post(_this3.fetch, `${_this3.url}/bucket`, {
				id,
				name: id,
				type: options.type,
				public: options.public,
				file_size_limit: options.fileSizeLimit,
				allowed_mime_types: options.allowedMimeTypes
			}, { headers: _this3.headers });
		});
	}
	/**
	* Updates a Storage bucket
	*
	* @category Storage
	* @subcategory File Buckets
	* @param id A unique identifier for the bucket you are updating.
	* @param options.public The visibility of the bucket. Public buckets don't require an authorization token to download objects, but still require a valid token for all other operations.
	* @param options.fileSizeLimit specifies the max file size in bytes that can be uploaded to this bucket.
	* The global file size limit takes precedence over this value.
	* The default value is null, which doesn't set a per bucket file size limit.
	* @param options.allowedMimeTypes specifies the allowed mime types that this bucket can accept during upload.
	* The default value is null, which allows files with all mime types to be uploaded.
	* Each mime type specified can be a wildcard, e.g. image/*, or a specific mime type, e.g. image/png.
	* @returns Promise with response containing success message or error
	*
	* @example Update bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .updateBucket('avatars', {
	*     public: false,
	*     allowedMimeTypes: ['image/png'],
	*     fileSizeLimit: 1024
	*   })
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "message": "Successfully updated"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: `select` and `update`
	*   - `objects` table permissions: none
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async updateBucket(id, options) {
		var _this4 = this;
		return _this4.handleOperation(async () => {
			return await put(_this4.fetch, `${_this4.url}/bucket/${id}`, {
				id,
				name: id,
				public: options.public,
				file_size_limit: options.fileSizeLimit,
				allowed_mime_types: options.allowedMimeTypes
			}, { headers: _this4.headers });
		});
	}
	/**
	* Removes all objects inside a single bucket.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param id The unique identifier of the bucket you would like to empty.
	* @returns Promise with success message or error
	*
	* @example Empty bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .emptyBucket('avatars')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "message": "Successfully emptied"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: `select`
	*   - `objects` table permissions: `select` and `delete`
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async emptyBucket(id) {
		var _this5 = this;
		return _this5.handleOperation(async () => {
			return await post(_this5.fetch, `${_this5.url}/bucket/${id}/empty`, {}, { headers: _this5.headers });
		});
	}
	/**
	* Deletes an existing bucket. A bucket can't be deleted with existing objects inside it.
	* You must first `empty()` the bucket.
	*
	* @category Storage
	* @subcategory File Buckets
	* @param id The unique identifier of the bucket you would like to delete.
	* @returns Promise with success message or error
	*
	* @example Delete bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .deleteBucket('avatars')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "message": "Successfully deleted"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - RLS policy permissions required:
	*   - `buckets` table permissions: `select` and `delete`
	*   - `objects` table permissions: none
	* - Refer to the [Storage guide](/docs/guides/storage/security/access-control) on how access control works
	*/
	async deleteBucket(id) {
		var _this6 = this;
		return _this6.handleOperation(async () => {
			return await remove(_this6.fetch, `${_this6.url}/bucket/${id}`, {}, { headers: _this6.headers });
		});
	}
	listBucketOptionsToQueryString(options) {
		const params = {};
		if (options) {
			if ("limit" in options) params.limit = String(options.limit);
			if ("offset" in options) params.offset = String(options.offset);
			if (options.search) params.search = options.search;
			if (options.sortColumn) params.sortColumn = options.sortColumn;
			if (options.sortOrder) params.sortOrder = options.sortOrder;
		}
		return Object.keys(params).length > 0 ? "?" + new URLSearchParams(params).toString() : "";
	}
};

//#endregion
//#region src/packages/StorageAnalyticsClient.ts
/**
* Client class for managing Analytics Buckets using Iceberg tables
* Provides methods for creating, listing, and deleting analytics buckets
*/
var StorageAnalyticsClient = class extends BaseApiClient {
	/**
	* @alpha
	*
	* Creates a new StorageAnalyticsClient instance
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Analytics Buckets
	* @param url - The base URL for the storage API
	* @param headers - HTTP headers to include in requests
	* @param fetch - Optional custom fetch implementation
	*
	* @example Using supabase-js (recommended)
	* ```typescript
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	* const { data, error } = await supabase.storage.analytics.listBuckets()
	* ```
	*
	* @example Standalone import for bundle-sensitive environments
	* ```typescript
	* import { StorageAnalyticsClient } from '@supabase/storage-js'
	*
	* const client = new StorageAnalyticsClient(url, headers)
	* ```
	*/
	constructor(url, headers = {}, fetch$1) {
		const finalUrl = url.replace(/\/$/, "");
		const finalHeaders = _objectSpread2(_objectSpread2({}, DEFAULT_HEADERS), headers);
		super(finalUrl, finalHeaders, fetch$1, "storage");
	}
	/**
	* @alpha
	*
	* Creates a new analytics bucket using Iceberg tables
	* Analytics buckets are optimized for analytical queries and data processing
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Analytics Buckets
	* @param name A unique name for the bucket you are creating
	* @returns Promise with response containing newly created analytics bucket or error
	*
	* @example Create analytics bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .analytics
	*   .createBucket('analytics-data')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "name": "analytics-data",
	*     "type": "ANALYTICS",
	*     "format": "iceberg",
	*     "created_at": "2024-05-22T22:26:05.100Z",
	*     "updated_at": "2024-05-22T22:26:05.100Z"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - Creates a new analytics bucket using Iceberg tables
	* - Analytics buckets are optimized for analytical queries and data processing
	*/
	async createBucket(name) {
		var _this = this;
		return _this.handleOperation(async () => {
			return await post(_this.fetch, `${_this.url}/bucket`, { name }, { headers: _this.headers });
		});
	}
	/**
	* @alpha
	*
	* Retrieves the details of all Analytics Storage buckets within an existing project
	* Only returns buckets of type 'ANALYTICS'
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Analytics Buckets
	* @param options Query parameters for listing buckets
	* @param options.limit Maximum number of buckets to return
	* @param options.offset Number of buckets to skip
	* @param options.sortColumn Column to sort by ('name', 'created_at', 'updated_at')
	* @param options.sortOrder Sort order ('asc' or 'desc')
	* @param options.search Search term to filter bucket names
	* @returns Promise with response containing array of analytics buckets or error
	*
	* @example List analytics buckets
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .analytics
	*   .listBuckets({
	*     limit: 10,
	*     offset: 0,
	*     sortColumn: 'created_at',
	*     sortOrder: 'desc'
	*   })
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": [
	*     {
	*       "name": "analytics-data",
	*       "type": "ANALYTICS",
	*       "format": "iceberg",
	*       "created_at": "2024-05-22T22:26:05.100Z",
	*       "updated_at": "2024-05-22T22:26:05.100Z"
	*     }
	*   ],
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - Retrieves the details of all Analytics Storage buckets within an existing project
	* - Only returns buckets of type 'ANALYTICS'
	*/
	async listBuckets(options) {
		var _this2 = this;
		return _this2.handleOperation(async () => {
			const queryParams = new URLSearchParams();
			if ((options === null || options === void 0 ? void 0 : options.limit) !== void 0) queryParams.set("limit", options.limit.toString());
			if ((options === null || options === void 0 ? void 0 : options.offset) !== void 0) queryParams.set("offset", options.offset.toString());
			if (options === null || options === void 0 ? void 0 : options.sortColumn) queryParams.set("sortColumn", options.sortColumn);
			if (options === null || options === void 0 ? void 0 : options.sortOrder) queryParams.set("sortOrder", options.sortOrder);
			if (options === null || options === void 0 ? void 0 : options.search) queryParams.set("search", options.search);
			const queryString = queryParams.toString();
			const url = queryString ? `${_this2.url}/bucket?${queryString}` : `${_this2.url}/bucket`;
			return await get(_this2.fetch, url, { headers: _this2.headers });
		});
	}
	/**
	* @alpha
	*
	* Deletes an existing analytics bucket
	* A bucket can't be deleted with existing objects inside it
	* You must first empty the bucket before deletion
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Analytics Buckets
	* @param bucketName The unique identifier of the bucket you would like to delete
	* @returns Promise with response containing success message or error
	*
	* @example Delete analytics bucket
	* ```js
	* const { data, error } = await supabase
	*   .storage
	*   .analytics
	*   .deleteBucket('analytics-data')
	* ```
	*
	* Response:
	* ```json
	* {
	*   "data": {
	*     "message": "Successfully deleted"
	*   },
	*   "error": null
	* }
	* ```
	*
	* @remarks
	* - Deletes an analytics bucket
	*/
	async deleteBucket(bucketName) {
		var _this3 = this;
		return _this3.handleOperation(async () => {
			return await remove(_this3.fetch, `${_this3.url}/bucket/${bucketName}`, {}, { headers: _this3.headers });
		});
	}
	/**
	* @alpha
	*
	* Get an Iceberg REST Catalog client configured for a specific analytics bucket
	* Use this to perform advanced table and namespace operations within the bucket
	* The returned client provides full access to the Apache Iceberg REST Catalog API
	* with the Supabase `{ data, error }` pattern for consistent error handling on all operations.
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Analytics Buckets
	* @param bucketName - The name of the analytics bucket (warehouse) to connect to
	* @returns The wrapped Iceberg catalog client
	* @throws {StorageError} If the bucket name is invalid
	*
	* @example Get catalog and create table
	* ```js
	* // First, create an analytics bucket
	* const { data: bucket, error: bucketError } = await supabase
	*   .storage
	*   .analytics
	*   .createBucket('analytics-data')
	*
	* // Get the Iceberg catalog for that bucket
	* const catalog = supabase.storage.analytics.from('analytics-data')
	*
	* // Create a namespace
	* const { error: nsError } = await catalog.createNamespace({ namespace: ['default'] })
	*
	* // Create a table with schema
	* const { data: tableMetadata, error: tableError } = await catalog.createTable(
	*   { namespace: ['default'] },
	*   {
	*     name: 'events',
	*     schema: {
	*       type: 'struct',
	*       fields: [
	*         { id: 1, name: 'id', type: 'long', required: true },
	*         { id: 2, name: 'timestamp', type: 'timestamp', required: true },
	*         { id: 3, name: 'user_id', type: 'string', required: false }
	*       ],
	*       'schema-id': 0,
	*       'identifier-field-ids': [1]
	*     },
	*     'partition-spec': {
	*       'spec-id': 0,
	*       fields: []
	*     },
	*     'write-order': {
	*       'order-id': 0,
	*       fields: []
	*     },
	*     properties: {
	*       'write.format.default': 'parquet'
	*     }
	*   }
	* )
	* ```
	*
	* @example List tables in namespace
	* ```js
	* const catalog = supabase.storage.analytics.from('analytics-data')
	*
	* // List all tables in the default namespace
	* const { data: tables, error: listError } = await catalog.listTables({ namespace: ['default'] })
	* if (listError) {
	*   if (listError.isNotFound()) {
	*     console.log('Namespace not found')
	*   }
	*   return
	* }
	* console.log(tables) // [{ namespace: ['default'], name: 'events' }]
	* ```
	*
	* @example Working with namespaces
	* ```js
	* const catalog = supabase.storage.analytics.from('analytics-data')
	*
	* // List all namespaces
	* const { data: namespaces } = await catalog.listNamespaces()
	*
	* // Create namespace with properties
	* await catalog.createNamespace(
	*   { namespace: ['production'] },
	*   { properties: { owner: 'data-team', env: 'prod' } }
	* )
	* ```
	*
	* @example Cleanup operations
	* ```js
	* const catalog = supabase.storage.analytics.from('analytics-data')
	*
	* // Drop table with purge option (removes all data)
	* const { error: dropError } = await catalog.dropTable(
	*   { namespace: ['default'], name: 'events' },
	*   { purge: true }
	* )
	*
	* if (dropError?.isNotFound()) {
	*   console.log('Table does not exist')
	* }
	*
	* // Drop namespace (must be empty)
	* await catalog.dropNamespace({ namespace: ['default'] })
	* ```
	*
	* @remarks
	* This method provides a bridge between Supabase's bucket management and the standard
	* Apache Iceberg REST Catalog API. The bucket name maps to the Iceberg warehouse parameter.
	* All authentication and configuration is handled automatically using your Supabase credentials.
	*
	* **Error Handling**: Invalid bucket names throw immediately. All catalog
	* operations return `{ data, error }` where errors are `IcebergError` instances from iceberg-js.
	* Use helper methods like `error.isNotFound()` or check `error.status` for specific error handling.
	* Use `.throwOnError()` on the analytics client if you prefer exceptions for catalog operations.
	*
	* **Cleanup Operations**: When using `dropTable`, the `purge: true` option permanently
	* deletes all table data. Without it, the table is marked as deleted but data remains.
	*
	* **Library Dependency**: The returned catalog wraps `IcebergRestCatalog` from iceberg-js.
	* For complete API documentation and advanced usage, refer to the
	* [iceberg-js documentation](https://supabase.github.io/iceberg-js/).
	*/
	from(bucketName) {
		var _this4 = this;
		if (!isValidBucketName(bucketName)) throw new StorageError("Invalid bucket name: File, folder, and bucket names must follow AWS object key naming guidelines and should avoid the use of any other characters.");
		const catalog = new IcebergRestCatalog({
			baseUrl: this.url,
			catalogName: bucketName,
			auth: {
				type: "custom",
				getHeaders: async () => _this4.headers
			},
			fetch: this.fetch
		});
		const shouldThrowOnError = this.shouldThrowOnError;
		return new Proxy(catalog, { get(target, prop) {
			const value = target[prop];
			if (typeof value !== "function") return value;
			return async (...args) => {
				try {
					return {
						data: await value.apply(target, args),
						error: null
					};
				} catch (error) {
					if (shouldThrowOnError) throw error;
					return {
						data: null,
						error
					};
				}
			};
		} });
	}
};

//#endregion
//#region src/packages/VectorIndexApi.ts
/**
* @hidden
* Base implementation for vector index operations.
* Use {@link VectorBucketScope} via `supabase.storage.vectors.from('bucket')` instead.
*/
var VectorIndexApi = class extends BaseApiClient {
	/** Creates a new VectorIndexApi instance */
	constructor(url, headers = {}, fetch$1) {
		const finalUrl = url.replace(/\/$/, "");
		const finalHeaders = _objectSpread2(_objectSpread2({}, DEFAULT_HEADERS), {}, { "Content-Type": "application/json" }, headers);
		super(finalUrl, finalHeaders, fetch$1, "vectors");
	}
	/** Creates a new vector index within a bucket */
	async createIndex(options) {
		var _this = this;
		return _this.handleOperation(async () => {
			return await vectorsApi.post(_this.fetch, `${_this.url}/CreateIndex`, options, { headers: _this.headers }) || {};
		});
	}
	/** Retrieves metadata for a specific vector index */
	async getIndex(vectorBucketName, indexName) {
		var _this2 = this;
		return _this2.handleOperation(async () => {
			return await vectorsApi.post(_this2.fetch, `${_this2.url}/GetIndex`, {
				vectorBucketName,
				indexName
			}, { headers: _this2.headers });
		});
	}
	/** Lists vector indexes within a bucket with optional filtering and pagination */
	async listIndexes(options) {
		var _this3 = this;
		return _this3.handleOperation(async () => {
			return await vectorsApi.post(_this3.fetch, `${_this3.url}/ListIndexes`, options, { headers: _this3.headers });
		});
	}
	/** Deletes a vector index and all its data */
	async deleteIndex(vectorBucketName, indexName) {
		var _this4 = this;
		return _this4.handleOperation(async () => {
			return await vectorsApi.post(_this4.fetch, `${_this4.url}/DeleteIndex`, {
				vectorBucketName,
				indexName
			}, { headers: _this4.headers }) || {};
		});
	}
};

//#endregion
//#region src/packages/VectorDataApi.ts
/**
* @hidden
* Base implementation for vector data operations.
* Use {@link VectorIndexScope} via `supabase.storage.vectors.from('bucket').index('idx')` instead.
*/
var VectorDataApi = class extends BaseApiClient {
	/** Creates a new VectorDataApi instance */
	constructor(url, headers = {}, fetch$1) {
		const finalUrl = url.replace(/\/$/, "");
		const finalHeaders = _objectSpread2(_objectSpread2({}, DEFAULT_HEADERS), {}, { "Content-Type": "application/json" }, headers);
		super(finalUrl, finalHeaders, fetch$1, "vectors");
	}
	/** Inserts or updates vectors in batch (1-500 per request) */
	async putVectors(options) {
		var _this = this;
		if (options.vectors.length < 1 || options.vectors.length > 500) throw new Error("Vector batch size must be between 1 and 500 items");
		return _this.handleOperation(async () => {
			return await vectorsApi.post(_this.fetch, `${_this.url}/PutVectors`, options, { headers: _this.headers }) || {};
		});
	}
	/** Retrieves vectors by their keys in batch */
	async getVectors(options) {
		var _this2 = this;
		return _this2.handleOperation(async () => {
			return await vectorsApi.post(_this2.fetch, `${_this2.url}/GetVectors`, options, { headers: _this2.headers });
		});
	}
	/** Lists vectors in an index with pagination */
	async listVectors(options) {
		var _this3 = this;
		if (options.segmentCount !== void 0) {
			if (options.segmentCount < 1 || options.segmentCount > 16) throw new Error("segmentCount must be between 1 and 16");
			if (options.segmentIndex !== void 0) {
				if (options.segmentIndex < 0 || options.segmentIndex >= options.segmentCount) throw new Error(`segmentIndex must be between 0 and ${options.segmentCount - 1}`);
			}
		}
		return _this3.handleOperation(async () => {
			return await vectorsApi.post(_this3.fetch, `${_this3.url}/ListVectors`, options, { headers: _this3.headers });
		});
	}
	/** Queries for similar vectors using approximate nearest neighbor search */
	async queryVectors(options) {
		var _this4 = this;
		return _this4.handleOperation(async () => {
			return await vectorsApi.post(_this4.fetch, `${_this4.url}/QueryVectors`, options, { headers: _this4.headers });
		});
	}
	/** Deletes vectors by their keys in batch (1-500 per request) */
	async deleteVectors(options) {
		var _this5 = this;
		if (options.keys.length < 1 || options.keys.length > 500) throw new Error("Keys batch size must be between 1 and 500 items");
		return _this5.handleOperation(async () => {
			return await vectorsApi.post(_this5.fetch, `${_this5.url}/DeleteVectors`, options, { headers: _this5.headers }) || {};
		});
	}
};

//#endregion
//#region src/packages/VectorBucketApi.ts
/**
* @hidden
* Base implementation for vector bucket operations.
* Use {@link StorageVectorsClient} via `supabase.storage.vectors` instead.
*/
var VectorBucketApi = class extends BaseApiClient {
	/** Creates a new VectorBucketApi instance */
	constructor(url, headers = {}, fetch$1) {
		const finalUrl = url.replace(/\/$/, "");
		const finalHeaders = _objectSpread2(_objectSpread2({}, DEFAULT_HEADERS), {}, { "Content-Type": "application/json" }, headers);
		super(finalUrl, finalHeaders, fetch$1, "vectors");
	}
	/** Creates a new vector bucket */
	async createBucket(vectorBucketName) {
		var _this = this;
		return _this.handleOperation(async () => {
			return await vectorsApi.post(_this.fetch, `${_this.url}/CreateVectorBucket`, { vectorBucketName }, { headers: _this.headers }) || {};
		});
	}
	/** Retrieves metadata for a specific vector bucket */
	async getBucket(vectorBucketName) {
		var _this2 = this;
		return _this2.handleOperation(async () => {
			return await vectorsApi.post(_this2.fetch, `${_this2.url}/GetVectorBucket`, { vectorBucketName }, { headers: _this2.headers });
		});
	}
	/** Lists vector buckets with optional filtering and pagination */
	async listBuckets(options = {}) {
		var _this3 = this;
		return _this3.handleOperation(async () => {
			return await vectorsApi.post(_this3.fetch, `${_this3.url}/ListVectorBuckets`, options, { headers: _this3.headers });
		});
	}
	/** Deletes a vector bucket (must be empty first) */
	async deleteBucket(vectorBucketName) {
		var _this4 = this;
		return _this4.handleOperation(async () => {
			return await vectorsApi.post(_this4.fetch, `${_this4.url}/DeleteVectorBucket`, { vectorBucketName }, { headers: _this4.headers }) || {};
		});
	}
};

//#endregion
//#region src/packages/StorageVectorsClient.ts
/**
*
* @alpha
*
* Main client for interacting with S3 Vectors API
* Provides access to bucket, index, and vector data operations
*
* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
*
* **Usage Patterns:**
*
* ```typescript
* const { data, error } = await supabase
*  .storage
*  .vectors
*  .createBucket('embeddings-prod')
*
* // Access index operations via buckets
* const bucket = supabase.storage.vectors.from('embeddings-prod')
* await bucket.createIndex({
*   indexName: 'documents',
*   dataType: 'float32',
*   dimension: 1536,
*   distanceMetric: 'cosine'
* })
*
* // Access vector operations via index
* const index = bucket.index('documents')
* await index.putVectors({
*   vectors: [
*     { key: 'doc-1', data: { float32: [...] }, metadata: { title: 'Intro' } }
*   ]
* })
*
* // Query similar vectors
* const { data } = await index.queryVectors({
*   queryVector: { float32: [...] },
*   topK: 5,
*   returnDistance: true
* })
* ```
*/
var StorageVectorsClient = class extends VectorBucketApi {
	/**
	* @alpha
	*
	* Creates a StorageVectorsClient that can manage buckets, indexes, and vectors.
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param url - Base URL of the Storage Vectors REST API.
	* @param options.headers - Optional headers (for example `Authorization`) applied to every request.
	* @param options.fetch - Optional custom `fetch` implementation for non-browser runtimes.
	*
	* @example Using supabase-js (recommended)
	* ```typescript
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	* const bucket = supabase.storage.vectors.from('embeddings-prod')
	* ```
	*
	* @example Standalone import for bundle-sensitive environments
	* ```typescript
	* import { StorageVectorsClient } from '@supabase/storage-js'
	*
	* const client = new StorageVectorsClient(url, options)
	* ```
	*/
	constructor(url, options = {}) {
		super(url, options.headers || {}, options.fetch);
	}
	/**
	*
	* @alpha
	*
	* Access operations for a specific vector bucket
	* Returns a scoped client for index and vector operations within the bucket
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param vectorBucketName - Name of the vector bucket
	* @returns Bucket-scoped client with index and vector operations
	*
	* @example Accessing a vector bucket
	* ```typescript
	* const bucket = supabase.storage.vectors.from('embeddings-prod')
	* ```
	*/
	from(vectorBucketName) {
		return new VectorBucketScope(this.url, this.headers, vectorBucketName, this.fetch);
	}
	/**
	*
	* @alpha
	*
	* Creates a new vector bucket
	* Vector buckets are containers for vector indexes and their data
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param vectorBucketName - Unique name for the vector bucket
	* @returns Promise with empty response on success or error
	*
	* @example Creating a vector bucket
	* ```typescript
	* const { data, error } = await supabase
	*   .storage
	*   .vectors
	*   .createBucket('embeddings-prod')
	* ```
	*/
	async createBucket(vectorBucketName) {
		var _superprop_getCreateBucket = () => super.createBucket, _this = this;
		return _superprop_getCreateBucket().call(_this, vectorBucketName);
	}
	/**
	*
	* @alpha
	*
	* Retrieves metadata for a specific vector bucket
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param vectorBucketName - Name of the vector bucket
	* @returns Promise with bucket metadata or error
	*
	* @example Get bucket metadata
	* ```typescript
	* const { data, error } = await supabase
	*   .storage
	*   .vectors
	*   .getBucket('embeddings-prod')
	*
	* console.log('Bucket created:', data?.vectorBucket.creationTime)
	* ```
	*/
	async getBucket(vectorBucketName) {
		var _superprop_getGetBucket = () => super.getBucket, _this2 = this;
		return _superprop_getGetBucket().call(_this2, vectorBucketName);
	}
	/**
	*
	* @alpha
	*
	* Lists all vector buckets with optional filtering and pagination
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Optional filters (prefix, maxResults, nextToken)
	* @returns Promise with list of buckets or error
	*
	* @example List vector buckets
	* ```typescript
	* const { data, error } = await supabase
	*   .storage
	*   .vectors
	*   .listBuckets({ prefix: 'embeddings-' })
	*
	* data?.vectorBuckets.forEach(bucket => {
	*   console.log(bucket.vectorBucketName)
	* })
	* ```
	*/
	async listBuckets(options = {}) {
		var _superprop_getListBuckets = () => super.listBuckets, _this3 = this;
		return _superprop_getListBuckets().call(_this3, options);
	}
	/**
	*
	* @alpha
	*
	* Deletes a vector bucket (bucket must be empty)
	* All indexes must be deleted before deleting the bucket
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param vectorBucketName - Name of the vector bucket to delete
	* @returns Promise with empty response on success or error
	*
	* @example Delete a vector bucket
	* ```typescript
	* const { data, error } = await supabase
	*   .storage
	*   .vectors
	*   .deleteBucket('embeddings-old')
	* ```
	*/
	async deleteBucket(vectorBucketName) {
		var _superprop_getDeleteBucket = () => super.deleteBucket, _this4 = this;
		return _superprop_getDeleteBucket().call(_this4, vectorBucketName);
	}
};
/**
*
* @alpha
*
* Scoped client for operations within a specific vector bucket
* Provides index management and access to vector operations
*
* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
*/
var VectorBucketScope = class extends VectorIndexApi {
	/**
	* @alpha
	*
	* Creates a helper that automatically scopes all index operations to the provided bucket.
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @example Creating a vector bucket scope
	* ```typescript
	* const bucket = supabase.storage.vectors.from('embeddings-prod')
	* ```
	*/
	constructor(url, headers, vectorBucketName, fetch$1) {
		super(url, headers, fetch$1);
		this.vectorBucketName = vectorBucketName;
	}
	/**
	*
	* @alpha
	*
	* Creates a new vector index in this bucket
	* Convenience method that automatically includes the bucket name
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Index configuration (vectorBucketName is automatically set)
	* @returns Promise with empty response on success or error
	*
	* @example Creating a vector index
	* ```typescript
	* const bucket = supabase.storage.vectors.from('embeddings-prod')
	* await bucket.createIndex({
	*   indexName: 'documents-openai',
	*   dataType: 'float32',
	*   dimension: 1536,
	*   distanceMetric: 'cosine',
	*   metadataConfiguration: {
	*     nonFilterableMetadataKeys: ['raw_text']
	*   }
	* })
	* ```
	*/
	async createIndex(options) {
		var _superprop_getCreateIndex = () => super.createIndex, _this5 = this;
		return _superprop_getCreateIndex().call(_this5, _objectSpread2(_objectSpread2({}, options), {}, { vectorBucketName: _this5.vectorBucketName }));
	}
	/**
	*
	* @alpha
	*
	* Lists indexes in this bucket
	* Convenience method that automatically includes the bucket name
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Listing options (vectorBucketName is automatically set)
	* @returns Promise with response containing indexes array and pagination token or error
	*
	* @example List indexes
	* ```typescript
	* const bucket = supabase.storage.vectors.from('embeddings-prod')
	* const { data } = await bucket.listIndexes({ prefix: 'documents-' })
	* ```
	*/
	async listIndexes(options = {}) {
		var _superprop_getListIndexes = () => super.listIndexes, _this6 = this;
		return _superprop_getListIndexes().call(_this6, _objectSpread2(_objectSpread2({}, options), {}, { vectorBucketName: _this6.vectorBucketName }));
	}
	/**
	*
	* @alpha
	*
	* Retrieves metadata for a specific index in this bucket
	* Convenience method that automatically includes the bucket name
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param indexName - Name of the index to retrieve
	* @returns Promise with index metadata or error
	*
	* @example Get index metadata
	* ```typescript
	* const bucket = supabase.storage.vectors.from('embeddings-prod')
	* const { data } = await bucket.getIndex('documents-openai')
	* console.log('Dimension:', data?.index.dimension)
	* ```
	*/
	async getIndex(indexName) {
		var _superprop_getGetIndex = () => super.getIndex, _this7 = this;
		return _superprop_getGetIndex().call(_this7, _this7.vectorBucketName, indexName);
	}
	/**
	*
	* @alpha
	*
	* Deletes an index from this bucket
	* Convenience method that automatically includes the bucket name
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param indexName - Name of the index to delete
	* @returns Promise with empty response on success or error
	*
	* @example Delete an index
	* ```typescript
	* const bucket = supabase.storage.vectors.from('embeddings-prod')
	* await bucket.deleteIndex('old-index')
	* ```
	*/
	async deleteIndex(indexName) {
		var _superprop_getDeleteIndex = () => super.deleteIndex, _this8 = this;
		return _superprop_getDeleteIndex().call(_this8, _this8.vectorBucketName, indexName);
	}
	/**
	*
	* @alpha
	*
	* Access operations for a specific index within this bucket
	* Returns a scoped client for vector data operations
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param indexName - Name of the index
	* @returns Index-scoped client with vector data operations
	*
	* @example Accessing an index
	* ```typescript
	* const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
	*
	* // Insert vectors
	* await index.putVectors({
	*   vectors: [
	*     { key: 'doc-1', data: { float32: [...] }, metadata: { title: 'Intro' } }
	*   ]
	* })
	*
	* // Query similar vectors
	* const { data } = await index.queryVectors({
	*   queryVector: { float32: [...] },
	*   topK: 5
	* })
	* ```
	*/
	index(indexName) {
		return new VectorIndexScope(this.url, this.headers, this.vectorBucketName, indexName, this.fetch);
	}
};
/**
*
* @alpha
*
* Scoped client for operations within a specific vector index
* Provides vector data operations (put, get, list, query, delete)
*
* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
*/
var VectorIndexScope = class extends VectorDataApi {
	/**
	*
	* @alpha
	*
	* Creates a helper that automatically scopes all vector operations to the provided bucket/index names.
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @example Creating a vector index scope
	* ```typescript
	* const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
	* ```
	*/
	constructor(url, headers, vectorBucketName, indexName, fetch$1) {
		super(url, headers, fetch$1);
		this.vectorBucketName = vectorBucketName;
		this.indexName = indexName;
	}
	/**
	*
	* @alpha
	*
	* Inserts or updates vectors in this index
	* Convenience method that automatically includes bucket and index names
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Vector insertion options (bucket and index names automatically set)
	* @returns Promise with empty response on success or error
	*
	* @example Insert vectors into an index
	* ```typescript
	* const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
	* await index.putVectors({
	*   vectors: [
	*     {
	*       key: 'doc-1',
	*       data: { float32: [0.1, 0.2, ...] },
	*       metadata: { title: 'Introduction', page: 1 }
	*     }
	*   ]
	* })
	* ```
	*/
	async putVectors(options) {
		var _superprop_getPutVectors = () => super.putVectors, _this9 = this;
		return _superprop_getPutVectors().call(_this9, _objectSpread2(_objectSpread2({}, options), {}, {
			vectorBucketName: _this9.vectorBucketName,
			indexName: _this9.indexName
		}));
	}
	/**
	*
	* @alpha
	*
	* Retrieves vectors by keys from this index
	* Convenience method that automatically includes bucket and index names
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Vector retrieval options (bucket and index names automatically set)
	* @returns Promise with response containing vectors array or error
	*
	* @example Get vectors by keys
	* ```typescript
	* const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
	* const { data } = await index.getVectors({
	*   keys: ['doc-1', 'doc-2'],
	*   returnMetadata: true
	* })
	* ```
	*/
	async getVectors(options) {
		var _superprop_getGetVectors = () => super.getVectors, _this10 = this;
		return _superprop_getGetVectors().call(_this10, _objectSpread2(_objectSpread2({}, options), {}, {
			vectorBucketName: _this10.vectorBucketName,
			indexName: _this10.indexName
		}));
	}
	/**
	*
	* @alpha
	*
	* Lists vectors in this index with pagination
	* Convenience method that automatically includes bucket and index names
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Listing options (bucket and index names automatically set)
	* @returns Promise with response containing vectors array and pagination token or error
	*
	* @example List vectors with pagination
	* ```typescript
	* const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
	* const { data } = await index.listVectors({
	*   maxResults: 500,
	*   returnMetadata: true
	* })
	* ```
	*/
	async listVectors(options = {}) {
		var _superprop_getListVectors = () => super.listVectors, _this11 = this;
		return _superprop_getListVectors().call(_this11, _objectSpread2(_objectSpread2({}, options), {}, {
			vectorBucketName: _this11.vectorBucketName,
			indexName: _this11.indexName
		}));
	}
	/**
	*
	* @alpha
	*
	* Queries for similar vectors in this index
	* Convenience method that automatically includes bucket and index names
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Query options (bucket and index names automatically set)
	* @returns Promise with response containing matches array of similar vectors ordered by distance or error
	*
	* @example Query similar vectors
	* ```typescript
	* const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
	* const { data } = await index.queryVectors({
	*   queryVector: { float32: [0.1, 0.2, ...] },
	*   topK: 5,
	*   filter: { category: 'technical' },
	*   returnDistance: true,
	*   returnMetadata: true
	* })
	* ```
	*/
	async queryVectors(options) {
		var _superprop_getQueryVectors = () => super.queryVectors, _this12 = this;
		return _superprop_getQueryVectors().call(_this12, _objectSpread2(_objectSpread2({}, options), {}, {
			vectorBucketName: _this12.vectorBucketName,
			indexName: _this12.indexName
		}));
	}
	/**
	*
	* @alpha
	*
	* Deletes vectors by keys from this index
	* Convenience method that automatically includes bucket and index names
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	* @param options - Deletion options (bucket and index names automatically set)
	* @returns Promise with empty response on success or error
	*
	* @example Delete vectors by keys
	* ```typescript
	* const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
	* await index.deleteVectors({
	*   keys: ['doc-1', 'doc-2', 'doc-3']
	* })
	* ```
	*/
	async deleteVectors(options) {
		var _superprop_getDeleteVectors = () => super.deleteVectors, _this13 = this;
		return _superprop_getDeleteVectors().call(_this13, _objectSpread2(_objectSpread2({}, options), {}, {
			vectorBucketName: _this13.vectorBucketName,
			indexName: _this13.indexName
		}));
	}
};

//#endregion
//#region src/StorageClient.ts
var StorageClient = class extends StorageBucketApi {
	/**
	* Creates a client for Storage buckets, files, analytics, and vectors.
	*
	* @category Storage
	* @subcategory File Buckets
	*
	* @example Using supabase-js (recommended)
	* ```ts
	* import { createClient } from '@supabase/supabase-js'
	*
	* const supabase = createClient('https://xyzcompany.supabase.co', 'your-publishable-key')
	* const avatars = supabase.storage.from('avatars')
	* ```
	*
	* @example Standalone import for bundle-sensitive environments
	* ```ts
	* import { StorageClient } from '@supabase/storage-js'
	*
	* const storage = new StorageClient('https://xyzcompany.supabase.co/storage/v1', {
	*   apikey: 'your-publishable-key',
	* })
	* const avatars = storage.from('avatars')
	* ```
	*/
	constructor(url, headers = {}, fetch$1, opts) {
		super(url, headers, fetch$1, opts);
	}
	/**
	* Perform file operation in a bucket.
	*
	* @category Storage
	* @subcategory File Buckets
	*
	* @param id The bucket id to operate on.
	*
	* @example Accessing a bucket
	* ```typescript
	* const avatars = supabase.storage.from('avatars')
	* ```
	*/
	from(id) {
		return new StorageFileApi(this.url, this.headers, id, this.fetch);
	}
	/**
	*
	* @alpha
	*
	* Access vector storage operations.
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Vector Buckets
	*
	* @returns A StorageVectorsClient instance configured with the current storage settings.
	*/
	get vectors() {
		return new StorageVectorsClient(this.url + "/vector", {
			headers: this.headers,
			fetch: this.fetch
		});
	}
	/**
	*
	* @alpha
	*
	* Access analytics storage operations using Iceberg tables.
	*
	* **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
	*
	* @category Storage
	* @subcategory Analytics Buckets
	*
	* @returns A StorageAnalyticsClient instance configured with the current storage settings.
	*/
	get analytics() {
		return new StorageAnalyticsClient(this.url + "/iceberg", this.headers, this.fetch);
	}
};

//#endregion
export { StorageAnalyticsClient, StorageApiError, StorageClient, StorageError, StorageUnknownError, StorageVectorsApiError, StorageVectorsClient, StorageVectorsError, StorageVectorsErrorCode, StorageVectorsUnknownError, VectorBucketApi, VectorBucketScope, VectorDataApi, VectorIndexApi, VectorIndexScope, isStorageError, isStorageVectorsError };
                                  
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXgubWpzIiwibmFtZXMiOlsicmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IiwicmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCBhbnk+IiwicGFyYW1zOiB7IFtrOiBzdHJpbmddOiBhbnkgfSIsImNvbnRlbnRUeXBlOiBzdHJpbmcgfCB1bmRlZmluZWQiLCJmZXRjaCIsInNldEhlYWRlclV0aWwiLCJ0aGlzIiwiZG93bmxvYWRGbjogKCkgPT4gUHJvbWlzZTxSZXNwb25zZT4iLCJzaG91bGRUaHJvd09uRXJyb3I6IGJvb2xlYW4iLCJ0aGlzIiwiZG93bmxvYWRGbjogKCkgPT4gUHJvbWlzZTxSZXNwb25zZT4iLCJzaG91bGRUaHJvd09uRXJyb3I6IGJvb2xlYW4iLCJ0aGlzIiwiREVGQVVMVF9GSUxFX09QVElPTlM6IEZpbGVPcHRpb25zIiwiZmV0Y2giLCJ0aGlzIiwiaGVhZGVyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiIsImZldGNoIiwidGhpcyIsInBhcmFtczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiIsImZldGNoIiwidGhpcyIsImZldGNoIiwidGhpcyIsImZldGNoIiwidGhpcyIsImZldGNoIiwidGhpcyIsImZldGNoIiwidGhpcyIsImZldGNoIl0sInNvdXJjZXMiOlsiLi4vc3JjL2xpYi9jb21tb24vZXJyb3JzLnRzIiwiLi4vc3JjL2xpYi9jb21tb24vaGVhZGVycy50cyIsIi4uL3NyYy9saWIvY29tbW9uL2hlbHBlcnMudHMiLCIuLi9zcmMvbGliL2NvbW1vbi9mZXRjaC50cyIsIi4uL3NyYy9saWIvY29tbW9uL0Jhc2VBcGlDbGllbnQudHMiLCIuLi9zcmMvcGFja2FnZXMvU3RyZWFtRG93bmxvYWRCdWlsZGVyLnRzIiwiLi4vc3JjL3BhY2thZ2VzL0Jsb2JEb3dubG9hZEJ1aWxkZXIudHMiLCIuLi9zcmMvcGFja2FnZXMvU3RvcmFnZUZpbGVBcGkudHMiLCIuLi9zcmMvbGliL3ZlcnNpb24udHMiLCIuLi9zcmMvbGliL2NvbnN0YW50cy50cyIsIi4uL3NyYy9wYWNrYWdlcy9TdG9yYWdlQnVja2V0QXBpLnRzIiwiLi4vc3JjL3BhY2thZ2VzL1N0b3JhZ2VBbmFseXRpY3NDbGllbnQudHMiLCIuLi9zcmMvcGFja2FnZXMvVmVjdG9ySW5kZXhBcGkudHMiLCIuLi9zcmMvcGFja2FnZXMvVmVjdG9yRGF0YUFwaS50cyIsIi4uL3NyYy9wYWNrYWdlcy9WZWN0b3JCdWNrZXRBcGkudHMiLCIuLi9zcmMvcGFja2FnZXMvU3RvcmFnZVZlY3RvcnNDbGllbnQudHMiLCIuLi9zcmMvU3RvcmFnZUNsaWVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIE5hbWVzcGFjZSB0eXBlIGZvciBlcnJvciBjbGFzc2VzXG4gKiBEZXRlcm1pbmVzIHRoZSBlcnJvciBjbGFzcyBuYW1lcyBhbmQgdHlwZSBndWFyZHNcbiAqL1xuZXhwb3J0IHR5cGUgRXJyb3JOYW1lc3BhY2UgPSAnc3RvcmFnZScgfCAndmVjdG9ycydcblxuLyoqXG4gKiBCYXNlIGVycm9yIGNsYXNzIGZvciBhbGwgU3RvcmFnZSBlcnJvcnNcbiAqIFN1cHBvcnRzIGJvdGggJ3N0b3JhZ2UnIGFuZCAndmVjdG9ycycgbmFtZXNwYWNlc1xuICovXG5leHBvcnQgY2xhc3MgU3RvcmFnZUVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBwcm90ZWN0ZWQgX19pc1N0b3JhZ2VFcnJvciA9IHRydWVcbiAgcHJvdGVjdGVkIG5hbWVzcGFjZTogRXJyb3JOYW1lc3BhY2VcbiAgc3RhdHVzOiBudW1iZXIgfCB1bmRlZmluZWRcbiAgc3RhdHVzQ29kZTogc3RyaW5nIHwgdW5kZWZpbmVkXG5cbiAgY29uc3RydWN0b3IoXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIG5hbWVzcGFjZTogRXJyb3JOYW1lc3BhY2UgPSAnc3RvcmFnZScsXG4gICAgc3RhdHVzPzogbnVtYmVyLFxuICAgIHN0YXR1c0NvZGU/OiBzdHJpbmdcbiAgKSB7XG4gICAgc3VwZXIobWVzc2FnZSlcbiAgICB0aGlzLm5hbWVzcGFjZSA9IG5hbWVzcGFjZVxuICAgIHRoaXMubmFtZSA9IG5hbWVzcGFjZSA9PT0gJ3ZlY3RvcnMnID8gJ1N0b3JhZ2VWZWN0b3JzRXJyb3InIDogJ1N0b3JhZ2VFcnJvcidcbiAgICB0aGlzLnN0YXR1cyA9IHN0YXR1c1xuICAgIHRoaXMuc3RhdHVzQ29kZSA9IHN0YXR1c0NvZGVcbiAgfVxuXG4gIHRvSlNPTigpOiB7XG4gICAgbmFtZTogc3RyaW5nXG4gICAgbWVzc2FnZTogc3RyaW5nXG4gICAgc3RhdHVzOiBudW1iZXIgfCB1bmRlZmluZWRcbiAgICBzdGF0dXNDb2RlOiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgfSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgIG1lc3NhZ2U6IHRoaXMubWVzc2FnZSxcbiAgICAgIHN0YXR1czogdGhpcy5zdGF0dXMsXG4gICAgICBzdGF0dXNDb2RlOiB0aGlzLnN0YXR1c0NvZGUsXG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogVHlwZSBndWFyZCB0byBjaGVjayBpZiBhbiBlcnJvciBpcyBhIFN0b3JhZ2VFcnJvclxuICogQHBhcmFtIGVycm9yIC0gVGhlIGVycm9yIHRvIGNoZWNrXG4gKiBAcmV0dXJucyBUcnVlIGlmIHRoZSBlcnJvciBpcyBhIFN0b3JhZ2VFcnJvclxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNTdG9yYWdlRXJyb3IoZXJyb3I6IHVua25vd24pOiBlcnJvciBpcyBTdG9yYWdlRXJyb3Ige1xuICByZXR1cm4gdHlwZW9mIGVycm9yID09PSAnb2JqZWN0JyAmJiBlcnJvciAhPT0gbnVsbCAmJiAnX19pc1N0b3JhZ2VFcnJvcicgaW4gZXJyb3Jcbn1cblxuLyoqXG4gKiBBUEkgZXJyb3IgcmV0dXJuZWQgZnJvbSBTdG9yYWdlIHNlcnZpY2VcbiAqIEluY2x1ZGVzIEhUVFAgc3RhdHVzIGNvZGUgYW5kIHNlcnZpY2Utc3BlY2lmaWMgZXJyb3IgY29kZVxuICovXG5leHBvcnQgY2xhc3MgU3RvcmFnZUFwaUVycm9yIGV4dGVuZHMgU3RvcmFnZUVycm9yIHtcbiAgb3ZlcnJpZGUgc3RhdHVzOiBudW1iZXJcbiAgb3ZlcnJpZGUgc3RhdHVzQ29kZTogc3RyaW5nXG5cbiAgY29uc3RydWN0b3IoXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIHN0YXR1czogbnVtYmVyLFxuICAgIHN0YXR1c0NvZGU6IHN0cmluZyxcbiAgICBuYW1lc3BhY2U6IEVycm9yTmFtZXNwYWNlID0gJ3N0b3JhZ2UnXG4gICkge1xuICAgIHN1cGVyKG1lc3NhZ2UsIG5hbWVzcGFjZSwgc3RhdHVzLCBzdGF0dXNDb2RlKVxuICAgIHRoaXMubmFtZSA9IG5hbWVzcGFjZSA9PT0gJ3ZlY3RvcnMnID8gJ1N0b3JhZ2VWZWN0b3JzQXBpRXJyb3InIDogJ1N0b3JhZ2VBcGlFcnJvcidcbiAgICB0aGlzLnN0YXR1cyA9IHN0YXR1c1xuICAgIHRoaXMuc3RhdHVzQ29kZSA9IHN0YXR1c0NvZGVcbiAgfVxuXG4gIHRvSlNPTigpOiB7XG4gICAgbmFtZTogc3RyaW5nXG4gICAgbWVzc2FnZTogc3RyaW5nXG4gICAgc3RhdHVzOiBudW1iZXIgfCB1bmRlZmluZWRcbiAgICBzdGF0dXNDb2RlOiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgfSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLnN1cGVyLnRvSlNPTigpLFxuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIFVua25vd24gZXJyb3IgdGhhdCBkb2Vzbid0IG1hdGNoIGV4cGVjdGVkIGVycm9yIHBhdHRlcm5zXG4gKiBXcmFwcyB0aGUgb3JpZ2luYWwgZXJyb3IgZm9yIGRlYnVnZ2luZ1xuICovXG5leHBvcnQgY2xhc3MgU3RvcmFnZVVua25vd25FcnJvciBleHRlbmRzIFN0b3JhZ2VFcnJvciB7XG4gIG9yaWdpbmFsRXJyb3I6IHVua25vd25cblxuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcsIG9yaWdpbmFsRXJyb3I6IHVua25vd24sIG5hbWVzcGFjZTogRXJyb3JOYW1lc3BhY2UgPSAnc3RvcmFnZScpIHtcbiAgICBzdXBlcihtZXNzYWdlLCBuYW1lc3BhY2UpXG4gICAgdGhpcy5uYW1lID0gbmFtZXNwYWNlID09PSAndmVjdG9ycycgPyAnU3RvcmFnZVZlY3RvcnNVbmtub3duRXJyb3InIDogJ1N0b3JhZ2VVbmtub3duRXJyb3InXG4gICAgdGhpcy5vcmlnaW5hbEVycm9yID0gb3JpZ2luYWxFcnJvclxuICB9XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIEJhY2t3YXJkIENvbXBhdGliaWxpdHkgRXhwb3J0cyBmb3IgVmVjdG9yc1xuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4vKipcbiAqIEBkZXByZWNhdGVkIFVzZSBTdG9yYWdlRXJyb3Igd2l0aCBuYW1lc3BhY2U9J3ZlY3RvcnMnIGluc3RlYWRcbiAqIEFsaWFzIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5IHdpdGggZXhpc3RpbmcgdmVjdG9yIHN0b3JhZ2UgY29kZVxuICovXG5leHBvcnQgY2xhc3MgU3RvcmFnZVZlY3RvcnNFcnJvciBleHRlbmRzIFN0b3JhZ2VFcnJvciB7XG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHN1cGVyKG1lc3NhZ2UsICd2ZWN0b3JzJylcbiAgfVxufVxuXG4vKipcbiAqIFR5cGUgZ3VhcmQgdG8gY2hlY2sgaWYgYW4gZXJyb3IgaXMgYSBTdG9yYWdlVmVjdG9yc0Vycm9yXG4gKiBAcGFyYW0gZXJyb3IgLSBUaGUgZXJyb3IgdG8gY2hlY2tcbiAqIEByZXR1cm5zIFRydWUgaWYgdGhlIGVycm9yIGlzIGEgU3RvcmFnZVZlY3RvcnNFcnJvclxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNTdG9yYWdlVmVjdG9yc0Vycm9yKGVycm9yOiB1bmtub3duKTogZXJyb3IgaXMgU3RvcmFnZVZlY3RvcnNFcnJvciB7XG4gIHJldHVybiBpc1N0b3JhZ2VFcnJvcihlcnJvcikgJiYgKGVycm9yIGFzIFN0b3JhZ2VFcnJvcilbJ25hbWVzcGFjZSddID09PSAndmVjdG9ycydcbn1cblxuLyoqXG4gKiBAZGVwcmVjYXRlZCBVc2UgU3RvcmFnZUFwaUVycm9yIHdpdGggbmFtZXNwYWNlPSd2ZWN0b3JzJyBpbnN0ZWFkXG4gKiBBbGlhcyBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eSB3aXRoIGV4aXN0aW5nIHZlY3RvciBzdG9yYWdlIGNvZGVcbiAqL1xuZXhwb3J0IGNsYXNzIFN0b3JhZ2VWZWN0b3JzQXBpRXJyb3IgZXh0ZW5kcyBTdG9yYWdlQXBpRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcsIHN0YXR1czogbnVtYmVyLCBzdGF0dXNDb2RlOiBzdHJpbmcpIHtcbiAgICBzdXBlcihtZXNzYWdlLCBzdGF0dXMsIHN0YXR1c0NvZGUsICd2ZWN0b3JzJylcbiAgfVxufVxuXG4vKipcbiAqIEBkZXByZWNhdGVkIFVzZSBTdG9yYWdlVW5rbm93bkVycm9yIHdpdGggbmFtZXNwYWNlPSd2ZWN0b3JzJyBpbnN0ZWFkXG4gKiBBbGlhcyBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eSB3aXRoIGV4aXN0aW5nIHZlY3RvciBzdG9yYWdlIGNvZGVcbiAqL1xuZXhwb3J0IGNsYXNzIFN0b3JhZ2VWZWN0b3JzVW5rbm93bkVycm9yIGV4dGVuZHMgU3RvcmFnZVVua25vd25FcnJvciB7XG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZywgb3JpZ2luYWxFcnJvcjogdW5rbm93bikge1xuICAgIHN1cGVyKG1lc3NhZ2UsIG9yaWdpbmFsRXJyb3IsICd2ZWN0b3JzJylcbiAgfVxufVxuXG4vKipcbiAqIEVycm9yIGNvZGVzIHNwZWNpZmljIHRvIFMzIFZlY3RvcnMgQVBJXG4gKiBNYXBzIEFXUyBzZXJ2aWNlIGVycm9ycyB0byBhcHBsaWNhdGlvbi1mcmllbmRseSBlcnJvciBjb2Rlc1xuICovXG5leHBvcnQgZW51bSBTdG9yYWdlVmVjdG9yc0Vycm9yQ29kZSB7XG4gIC8qKiBJbnRlcm5hbCBzZXJ2ZXIgZmF1bHQgKEhUVFAgNTAwKSAqL1xuICBJbnRlcm5hbEVycm9yID0gJ0ludGVybmFsRXJyb3InLFxuICAvKiogUmVzb3VyY2UgYWxyZWFkeSBleGlzdHMgLyBjb25mbGljdCAoSFRUUCA0MDkpICovXG4gIFMzVmVjdG9yQ29uZmxpY3RFeGNlcHRpb24gPSAnUzNWZWN0b3JDb25mbGljdEV4Y2VwdGlvbicsXG4gIC8qKiBSZXNvdXJjZSBub3QgZm91bmQgKEhUVFAgNDA0KSAqL1xuICBTM1ZlY3Rvck5vdEZvdW5kRXhjZXB0aW9uID0gJ1MzVmVjdG9yTm90Rm91bmRFeGNlcHRpb24nLFxuICAvKiogRGVsZXRlIGJ1Y2tldCB3aGlsZSBub3QgZW1wdHkgKEhUVFAgNDAwKSAqL1xuICBTM1ZlY3RvckJ1Y2tldE5vdEVtcHR5ID0gJ1MzVmVjdG9yQnVja2V0Tm90RW1wdHknLFxuICAvKiogRXhjZWVkcyBidWNrZXQgcXVvdGEvbGltaXQgKEhUVFAgNDAwKSAqL1xuICBTM1ZlY3Rvck1heEJ1Y2tldHNFeGNlZWRlZCA9ICdTM1ZlY3Rvck1heEJ1Y2tldHNFeGNlZWRlZCcsXG4gIC8qKiBFeGNlZWRzIGluZGV4IHF1b3RhL2xpbWl0IChIVFRQIDQwMCkgKi9cbiAgUzNWZWN0b3JNYXhJbmRleGVzRXhjZWVkZWQgPSAnUzNWZWN0b3JNYXhJbmRleGVzRXhjZWVkZWQnLFxufVxuIiwiLyoqXG4gKiBTZXRzIGEgaGVhZGVyIHdpdGggY2FzZS1pbnNlbnNpdGl2ZSBkZWR1cGxpY2F0aW9uLlxuICogUmVtb3ZlcyBhbnkgZXhpc3RpbmcgaGVhZGVycyB3aG9zZSBuYW1lIG1hdGNoZXMgKGNhc2UtaW5zZW5zaXRpdmUpLFxuICogdGhlbiBzZXRzIHRoZSB2YWx1ZSB1bmRlciB0aGUgbG93ZXJjYXNlIGtleS4gRG9lcyBub3QgbXV0YXRlIHRoZSBpbnB1dCBvYmplY3QuXG4gKlxuICogQHBhcmFtIGhlYWRlcnMgLSBFeGlzdGluZyBoZWFkZXJzIG9iamVjdFxuICogQHBhcmFtIG5hbWUgLSBIZWFkZXIgbmFtZSB0byBzZXQgKHN0b3JlZCBhcyBsb3dlcmNhc2UpXG4gKiBAcGFyYW0gdmFsdWUgLSBIZWFkZXIgdmFsdWVcbiAqIEByZXR1cm5zIE5ldyBoZWFkZXJzIG9iamVjdCB3aXRoIHRoZSBoZWFkZXIgc2V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXRIZWFkZXIoXG4gIGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sXG4gIG5hbWU6IHN0cmluZyxcbiAgdmFsdWU6IHN0cmluZ1xuKTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB7XG4gIGNvbnN0IHJlc3VsdCA9IHsgLi4uaGVhZGVycyB9XG4gIGNvbnN0IG5hbWVMb3dlciA9IG5hbWUudG9Mb3dlckNhc2UoKVxuXG4gIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHJlc3VsdCkpIHtcbiAgICBpZiAoa2V5LnRvTG93ZXJDYXNlKCkgPT09IG5hbWVMb3dlcikge1xuICAgICAgZGVsZXRlIHJlc3VsdFtrZXldXG4gICAgfVxuICB9XG5cbiAgcmVzdWx0W25hbWVMb3dlcl0gPSB2YWx1ZVxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8qKlxuICogTm9ybWFsaXplcyBhbGwgaGVhZGVyIGtleXMgdG8gbG93ZXJjYXNlIHdpdGggY2FzZS1pbnNlbnNpdGl2ZSBkZWR1cGxpY2F0aW9uLlxuICogV2hlbiBkdXBsaWNhdGUga2V5cyBleGlzdCAoZGlmZmVyaW5nIG9ubHkgaW4gY2FzZSksIHRoZSBsYXN0IHZhbHVlIHdpbnMuXG4gKiBEb2VzIG5vdCBtdXRhdGUgdGhlIGlucHV0IG9iamVjdC5cbiAqXG4gKiBAcGFyYW0gaGVhZGVycyAtIEhlYWRlcnMgb2JqZWN0IHRvIG5vcm1hbGl6ZVxuICogQHJldHVybnMgTmV3IGhlYWRlcnMgb2JqZWN0IHdpdGggYWxsIGtleXMgbG93ZXJjYXNlZFxuICovXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplSGVhZGVycyhoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB7XG4gIGNvbnN0IHJlc3VsdDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9XG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGhlYWRlcnMpKSB7XG4gICAgcmVzdWx0W2tleS50b0xvd2VyQ2FzZSgpXSA9IHZhbHVlXG4gIH1cbiAgcmV0dXJuIHJlc3VsdFxufVxuIiwidHlwZSBGZXRjaCA9IHR5cGVvZiBmZXRjaFxuXG4vKipcbiAqIFJlc29sdmVzIHRoZSBmZXRjaCBpbXBsZW1lbnRhdGlvbiB0byB1c2VcbiAqIFVzZXMgY3VzdG9tIGZldGNoIGlmIHByb3ZpZGVkLCBvdGhlcndpc2UgdXNlcyBuYXRpdmUgZmV0Y2hcbiAqXG4gKiBAcGFyYW0gY3VzdG9tRmV0Y2ggLSBPcHRpb25hbCBjdXN0b20gZmV0Y2ggaW1wbGVtZW50YXRpb25cbiAqIEByZXR1cm5zIFJlc29sdmVkIGZldGNoIGZ1bmN0aW9uXG4gKi9cbmV4cG9ydCBjb25zdCByZXNvbHZlRmV0Y2ggPSAoY3VzdG9tRmV0Y2g/OiBGZXRjaCk6IEZldGNoID0+IHtcbiAgaWYgKGN1c3RvbUZldGNoKSB7XG4gICAgcmV0dXJuICguLi5hcmdzKSA9PiBjdXN0b21GZXRjaCguLi5hcmdzKVxuICB9XG4gIHJldHVybiAoLi4uYXJncykgPT4gZmV0Y2goLi4uYXJncylcbn1cblxuLyoqXG4gKiBSZXNvbHZlcyB0aGUgUmVzcG9uc2UgY29uc3RydWN0b3IgdG8gdXNlXG4gKiBSZXR1cm5zIG5hdGl2ZSBSZXNwb25zZSBjb25zdHJ1Y3RvclxuICpcbiAqIEByZXR1cm5zIFJlc3BvbnNlIGNvbnN0cnVjdG9yXG4gKi9cbmV4cG9ydCBjb25zdCByZXNvbHZlUmVzcG9uc2UgPSAoKTogdHlwZW9mIFJlc3BvbnNlID0+IHtcbiAgcmV0dXJuIFJlc3BvbnNlXG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGlucHV0IGlzIGEgcGxhaW4gb2JqZWN0XG4gKiBBbiBvYmplY3QgaXMgcGxhaW4gaWYgaXQncyBjcmVhdGVkIGJ5IGVpdGhlciB7fSwgbmV3IE9iamVjdCgpLCBvciBPYmplY3QuY3JlYXRlKG51bGwpXG4gKlxuICogQHBhcmFtIHZhbHVlIC0gVmFsdWUgdG8gY2hlY2tcbiAqIEByZXR1cm5zIFRydWUgaWYgdmFsdWUgaXMgYSBwbGFpbiBvYmplY3RcbiAqIEBzb3VyY2UgaHR0cHM6Ly9naXRodWIuY29tL3NpbmRyZXNvcmh1cy9pcy1wbGFpbi1vYmpcbiAqL1xuZXhwb3J0IGNvbnN0IGlzUGxhaW5PYmplY3QgPSAodmFsdWU6IG9iamVjdCk6IGJvb2xlYW4gPT4ge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JyB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgY29uc3QgcHJvdG90eXBlID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKHZhbHVlKVxuICByZXR1cm4gKFxuICAgIChwcm90b3R5cGUgPT09IG51bGwgfHxcbiAgICAgIHByb3RvdHlwZSA9PT0gT2JqZWN0LnByb3RvdHlwZSB8fFxuICAgICAgT2JqZWN0LmdldFByb3RvdHlwZU9mKHByb3RvdHlwZSkgPT09IG51bGwpICYmXG4gICAgIShTeW1ib2wudG9TdHJpbmdUYWcgaW4gdmFsdWUpICYmXG4gICAgIShTeW1ib2wuaXRlcmF0b3IgaW4gdmFsdWUpXG4gIClcbn1cblxuLyoqXG4gKiBSZWN1cnNpdmVseSBjb252ZXJ0cyBvYmplY3Qga2V5cyBmcm9tIHNuYWtlX2Nhc2UgdG8gY2FtZWxDYXNlXG4gKiBVc2VkIGZvciBub3JtYWxpemluZyBBUEkgcmVzcG9uc2VzXG4gKlxuICogQHBhcmFtIGl0ZW0gLSBPYmplY3QgdG8gY29udmVydFxuICogQHJldHVybnMgQ29udmVydGVkIG9iamVjdCB3aXRoIGNhbWVsQ2FzZSBrZXlzXG4gKi9cbmV4cG9ydCBjb25zdCByZWN1cnNpdmVUb0NhbWVsID0gKGl0ZW06IFJlY29yZDxzdHJpbmcsIGFueT4pOiB1bmtub3duID0+IHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoaXRlbSkpIHtcbiAgICByZXR1cm4gaXRlbS5tYXAoKGVsKSA9PiByZWN1cnNpdmVUb0NhbWVsKGVsKSlcbiAgfSBlbHNlIGlmICh0eXBlb2YgaXRlbSA9PT0gJ2Z1bmN0aW9uJyB8fCBpdGVtICE9PSBPYmplY3QoaXRlbSkpIHtcbiAgICByZXR1cm4gaXRlbVxuICB9XG5cbiAgY29uc3QgcmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cbiAgT2JqZWN0LmVudHJpZXMoaXRlbSkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgY29uc3QgbmV3S2V5ID0ga2V5LnJlcGxhY2UoLyhbLV9dW2Etel0pL2dpLCAoYykgPT4gYy50b1VwcGVyQ2FzZSgpLnJlcGxhY2UoL1stX10vZywgJycpKVxuICAgIHJlc3VsdFtuZXdLZXldID0gcmVjdXJzaXZlVG9DYW1lbCh2YWx1ZSlcbiAgfSlcblxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8qKlxuICogVmFsaWRhdGVzIGlmIGEgZ2l2ZW4gYnVja2V0IG5hbWUgaXMgdmFsaWQgYWNjb3JkaW5nIHRvIFN1cGFiYXNlIFN0b3JhZ2UgQVBJIHJ1bGVzXG4gKiBNaXJyb3JzIGJhY2tlbmQgdmFsaWRhdGlvbiBmcm9tOiBzdG9yYWdlL3NyYy9zdG9yYWdlL2xpbWl0cy50czppc1ZhbGlkQnVja2V0TmFtZSgpXG4gKlxuICogUnVsZXM6XG4gKiAtIExlbmd0aDogMS0xMDAgY2hhcmFjdGVyc1xuICogLSBBbGxvd2VkIGNoYXJhY3RlcnM6IGFscGhhbnVtZXJpYyAoYS16LCBBLVosIDAtOSksIHVuZGVyc2NvcmUgKF8pLCBhbmQgc2FmZSBzcGVjaWFsIGNoYXJhY3RlcnNcbiAqIC0gU2FmZSBzcGVjaWFsIGNoYXJhY3RlcnM6ICEgLSAuICogJyAoICkgc3BhY2UgJiAkIEAgPSA7IDogKyAsID9cbiAqIC0gRm9yYmlkZGVuOiBwYXRoIHNlcGFyYXRvcnMgKC8sIFxcKSwgcGF0aCB0cmF2ZXJzYWwgKC4uKSwgbGVhZGluZy90cmFpbGluZyB3aGl0ZXNwYWNlXG4gKlxuICogQVdTIFMzIFJlZmVyZW5jZTogaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL0FtYXpvblMzL2xhdGVzdC91c2VyZ3VpZGUvb2JqZWN0LWtleXMuaHRtbFxuICpcbiAqIEBwYXJhbSBidWNrZXROYW1lIC0gVGhlIGJ1Y2tldCBuYW1lIHRvIHZhbGlkYXRlXG4gKiBAcmV0dXJucyB0cnVlIGlmIHZhbGlkLCBmYWxzZSBvdGhlcndpc2VcbiAqL1xuZXhwb3J0IGNvbnN0IGlzVmFsaWRCdWNrZXROYW1lID0gKGJ1Y2tldE5hbWU6IHN0cmluZyk6IGJvb2xlYW4gPT4ge1xuICBpZiAoIWJ1Y2tldE5hbWUgfHwgdHlwZW9mIGJ1Y2tldE5hbWUgIT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICAvLyBDaGVjayBsZW5ndGggY29uc3RyYWludHMgKDEtMTAwIGNoYXJhY3RlcnMpXG4gIGlmIChidWNrZXROYW1lLmxlbmd0aCA9PT0gMCB8fCBidWNrZXROYW1lLmxlbmd0aCA+IDEwMCkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIGxlYWRpbmcvdHJhaWxpbmcgd2hpdGVzcGFjZVxuICBpZiAoYnVja2V0TmFtZS50cmltKCkgIT09IGJ1Y2tldE5hbWUpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIC8vIEV4cGxpY2l0bHkgcmVqZWN0IHBhdGggc2VwYXJhdG9ycyAoc2VjdXJpdHkpXG4gIC8vIE5vdGU6IENvbnNlY3V0aXZlIHBlcmlvZHMgKC4uKSBhcmUgYWxsb3dlZCBieSBiYWNrZW5kIC0gdGhlIEFXUyByZXN0cmljdGlvblxuICAvLyBvbiByZWxhdGl2ZSBwYXRocyBhcHBsaWVzIHRvIG9iamVjdCBrZXlzLCBub3QgYnVja2V0IG5hbWVzXG4gIGlmIChidWNrZXROYW1lLmluY2x1ZGVzKCcvJykgfHwgYnVja2V0TmFtZS5pbmNsdWRlcygnXFxcXCcpKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICAvLyBWYWxpZGF0ZSBhZ2FpbnN0IGFsbG93ZWQgY2hhcmFjdGVyIHNldFxuICAvLyBQYXR0ZXJuIG1hdGNoZXMgYmFja2VuZCByZWdleDogL14oXFx3fCF8LXxcXC58XFwqfCd8XFwofFxcKXwgfCZ8XFwkfEB8PXw7fDp8XFwrfCx8XFw/KSokL1xuICAvLyBUaGlzIGV4cGxpY2l0bHkgZXhjbHVkZXMgcGF0aCBzZXBhcmF0b3JzICgvLCBcXCkgYW5kIG90aGVyIHByb2JsZW1hdGljIGNoYXJhY3RlcnNcbiAgY29uc3QgYnVja2V0TmFtZVJlZ2V4ID0gL15bXFx3IS5cXConKCkgJiRAPTs6Kyw/LV0rJC9cbiAgcmV0dXJuIGJ1Y2tldE5hbWVSZWdleC50ZXN0KGJ1Y2tldE5hbWUpXG59XG5cbi8qKlxuICogTm9ybWFsaXplcyBhIG51bWJlciBhcnJheSB0byBmbG9hdDMyIGZvcm1hdFxuICogRW5zdXJlcyBhbGwgdmVjdG9yIHZhbHVlcyBhcmUgdmFsaWQgMzItYml0IGZsb2F0c1xuICpcbiAqIEBwYXJhbSB2YWx1ZXMgLSBBcnJheSBvZiBudW1iZXJzIHRvIG5vcm1hbGl6ZVxuICogQHJldHVybnMgTm9ybWFsaXplZCBmbG9hdDMyIGFycmF5XG4gKi9cbmV4cG9ydCBjb25zdCBub3JtYWxpemVUb0Zsb2F0MzIgPSAodmFsdWVzOiBudW1iZXJbXSk6IG51bWJlcltdID0+IHtcbiAgLy8gVXNlIEZsb2F0MzJBcnJheSB0byBlbnN1cmUgcHJvcGVyIHByZWNpc2lvblxuICByZXR1cm4gQXJyYXkuZnJvbShuZXcgRmxvYXQzMkFycmF5KHZhbHVlcykpXG59XG5cbi8qKlxuICogVmFsaWRhdGVzIHZlY3RvciBkaW1lbnNpb25zIG1hdGNoIGV4cGVjdGVkIGRpbWVuc2lvblxuICogVGhyb3dzIGVycm9yIGlmIGRpbWVuc2lvbnMgZG9uJ3QgbWF0Y2hcbiAqXG4gKiBAcGFyYW0gdmVjdG9yIC0gVmVjdG9yIGRhdGEgdG8gdmFsaWRhdGVcbiAqIEBwYXJhbSBleHBlY3RlZERpbWVuc2lvbiAtIEV4cGVjdGVkIHZlY3RvciBkaW1lbnNpb25cbiAqIEB0aHJvd3MgRXJyb3IgaWYgZGltZW5zaW9ucyBkb24ndCBtYXRjaFxuICovXG5leHBvcnQgY29uc3QgdmFsaWRhdGVWZWN0b3JEaW1lbnNpb24gPSAoXG4gIHZlY3RvcjogeyBmbG9hdDMyOiBudW1iZXJbXSB9LFxuICBleHBlY3RlZERpbWVuc2lvbj86IG51bWJlclxuKTogdm9pZCA9PiB7XG4gIGlmIChleHBlY3RlZERpbWVuc2lvbiAhPT0gdW5kZWZpbmVkICYmIHZlY3Rvci5mbG9hdDMyLmxlbmd0aCAhPT0gZXhwZWN0ZWREaW1lbnNpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgVmVjdG9yIGRpbWVuc2lvbiBtaXNtYXRjaDogZXhwZWN0ZWQgJHtleHBlY3RlZERpbWVuc2lvbn0sIGdvdCAke3ZlY3Rvci5mbG9hdDMyLmxlbmd0aH1gXG4gICAgKVxuICB9XG59XG4iLCJpbXBvcnQgeyBTdG9yYWdlQXBpRXJyb3IsIFN0b3JhZ2VFcnJvciwgU3RvcmFnZVVua25vd25FcnJvciwgRXJyb3JOYW1lc3BhY2UgfSBmcm9tICcuL2Vycm9ycydcbmltcG9ydCB7IHNldEhlYWRlciB9IGZyb20gJy4vaGVhZGVycydcbmltcG9ydCB7IGlzUGxhaW5PYmplY3QsIHJlc29sdmVSZXNwb25zZSB9IGZyb20gJy4vaGVscGVycydcbmltcG9ydCB7IEZldGNoUGFyYW1ldGVycyB9IGZyb20gJy4uL3R5cGVzJ1xuXG5leHBvcnQgdHlwZSBGZXRjaCA9IHR5cGVvZiBmZXRjaFxuXG4vKipcbiAqIE9wdGlvbnMgZm9yIGZldGNoIHJlcXVlc3RzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRmV0Y2hPcHRpb25zIHtcbiAgaGVhZGVycz86IHtcbiAgICBba2V5OiBzdHJpbmddOiBzdHJpbmdcbiAgfVxuICBkdXBsZXg/OiBzdHJpbmdcbiAgbm9SZXNvbHZlSnNvbj86IGJvb2xlYW5cbn1cblxuLyoqXG4gKiBIVFRQIG1ldGhvZHMgc3VwcG9ydGVkIGJ5IHRoZSBBUElcbiAqL1xuZXhwb3J0IHR5cGUgUmVxdWVzdE1ldGhvZFR5cGUgPSAnR0VUJyB8ICdQT1NUJyB8ICdQVVQnIHwgJ0RFTEVURScgfCAnSEVBRCdcblxuLyoqXG4gKiBFeHRyYWN0cyBlcnJvciBtZXNzYWdlIGZyb20gdmFyaW91cyBlcnJvciByZXNwb25zZSBmb3JtYXRzXG4gKiBAcGFyYW0gZXJyIC0gRXJyb3Igb2JqZWN0IGZyb20gQVBJXG4gKiBAcmV0dXJucyBIdW1hbi1yZWFkYWJsZSBlcnJvciBtZXNzYWdlXG4gKi9cbmNvbnN0IF9nZXRFcnJvck1lc3NhZ2UgPSAoZXJyOiB1bmtub3duKTogc3RyaW5nID0+IHtcbiAgaWYgKHR5cGVvZiBlcnIgPT09ICdvYmplY3QnICYmIGVyciAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGUgPSBlcnIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5cbiAgICBpZiAodHlwZW9mIGUubXNnID09PSAnc3RyaW5nJykgcmV0dXJuIGUubXNnXG4gICAgaWYgKHR5cGVvZiBlLm1lc3NhZ2UgPT09ICdzdHJpbmcnKSByZXR1cm4gZS5tZXNzYWdlXG4gICAgaWYgKHR5cGVvZiBlLmVycm9yX2Rlc2NyaXB0aW9uID09PSAnc3RyaW5nJykgcmV0dXJuIGUuZXJyb3JfZGVzY3JpcHRpb25cbiAgICBpZiAodHlwZW9mIGUuZXJyb3IgPT09ICdzdHJpbmcnKSByZXR1cm4gZS5lcnJvclxuICAgIGlmICh0eXBlb2YgZS5lcnJvciA9PT0gJ29iamVjdCcgJiYgZS5lcnJvciAhPT0gbnVsbCkge1xuICAgICAgY29uc3QgbmVzdGVkID0gZS5lcnJvciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuICAgICAgaWYgKHR5cGVvZiBuZXN0ZWQubWVzc2FnZSA9PT0gJ3N0cmluZycpIHJldHVybiBuZXN0ZWQubWVzc2FnZVxuICAgIH1cbiAgfVxuICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoZXJyKVxufVxuXG4vKipcbiAqIEhhbmRsZXMgZmV0Y2ggZXJyb3JzIGFuZCBjb252ZXJ0cyB0aGVtIHRvIFN0b3JhZ2UgZXJyb3IgdHlwZXNcbiAqIEBwYXJhbSBlcnJvciAtIFRoZSBlcnJvciBjYXVnaHQgZnJvbSBmZXRjaFxuICogQHBhcmFtIHJlamVjdCAtIFByb21pc2UgcmVqZWN0aW9uIGZ1bmN0aW9uXG4gKiBAcGFyYW0gb3B0aW9ucyAtIEZldGNoIG9wdGlvbnMgdGhhdCBtYXkgYWZmZWN0IGVycm9yIGhhbmRsaW5nXG4gKiBAcGFyYW0gbmFtZXNwYWNlIC0gRXJyb3IgbmFtZXNwYWNlICgnc3RvcmFnZScgb3IgJ3ZlY3RvcnMnKVxuICovXG5jb25zdCBoYW5kbGVFcnJvciA9IGFzeW5jIChcbiAgZXJyb3I6IHVua25vd24sXG4gIHJlamVjdDogKHJlYXNvbjogU3RvcmFnZUVycm9yKSA9PiB2b2lkLFxuICBvcHRpb25zOiBGZXRjaE9wdGlvbnMgfCB1bmRlZmluZWQsXG4gIG5hbWVzcGFjZTogRXJyb3JOYW1lc3BhY2VcbikgPT4ge1xuICAvLyBTdHJ1Y3R1cmFsIGRldGVjdGlvbiBvZiBqc29uKCkgbWV0aG9kLCBwcmVzZW50IGluIGFsbCBSZXNwb25zZSBpbXBsZW1lbnRhdGlvbnNcbiAgLy8gKG5hdGl2ZSwgbm9kZS1mZXRjaCwgY3Jvc3MtZmV0Y2gsIHVuZGljaSkgYW5kIGFic2VudCBmcm9tIHN0YW5kYXJkIEVycm9yIG9iamVjdHMuXG4gIC8vIENoZWNraW5nICdvaycgb3IgJ3N0YXR1cycgdmlhIGBpbmAgaXMgdW5yZWxpYWJsZSBhY3Jvc3MgZmV0Y2ggcG9seWZpbGxzL3JlYWxtcy5cbiAgY29uc3QgaXNSZXNwb25zZUxpa2UgPVxuICAgIGVycm9yICE9PSBudWxsICYmXG4gICAgdHlwZW9mIGVycm9yID09PSAnb2JqZWN0JyAmJlxuICAgICdqc29uJyBpbiBlcnJvciAmJlxuICAgIHR5cGVvZiAoZXJyb3IgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmpzb24gPT09ICdmdW5jdGlvbidcblxuICBpZiAoaXNSZXNwb25zZUxpa2UpIHtcbiAgICBjb25zdCByZXNwb25zZUVycm9yID0gZXJyb3IgYXMgUmVzcG9uc2VcbiAgICAvLyBEZWZlbnNpdmUgY29lcmNpb246IHNvbWUgZmV0Y2ggcG9seWZpbGxzIGhhdmUgaGlzdG9yaWNhbGx5IHJldHVybmVkIHN0YXR1cyBhcyBhIHN0cmluZy5cbiAgICBsZXQgc3RhdHVzID0gcGFyc2VJbnQoU3RyaW5nKHJlc3BvbnNlRXJyb3Iuc3RhdHVzKSwgMTApXG4gICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoc3RhdHVzKSkge1xuICAgICAgc3RhdHVzID0gNTAwXG4gICAgfVxuXG4gICAgcmVzcG9uc2VFcnJvclxuICAgICAgLmpzb24oKVxuICAgICAgLnRoZW4oXG4gICAgICAgIChlcnI6IHsgc3RhdHVzQ29kZT86IHN0cmluZzsgY29kZT86IHN0cmluZzsgZXJyb3I/OiBzdHJpbmc7IG1lc3NhZ2U/OiBzdHJpbmcgfSB8IG51bGwpID0+IHtcbiAgICAgICAgICBjb25zdCBzdGF0dXNDb2RlID0gZXJyPy5zdGF0dXNDb2RlIHx8IGVycj8uY29kZSB8fCBzdGF0dXMgKyAnJ1xuICAgICAgICAgIHJlamVjdChuZXcgU3RvcmFnZUFwaUVycm9yKF9nZXRFcnJvck1lc3NhZ2UoZXJyKSwgc3RhdHVzLCBzdGF0dXNDb2RlLCBuYW1lc3BhY2UpKVxuICAgICAgICB9XG4gICAgICApXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICBjb25zdCBzdGF0dXNDb2RlID0gc3RhdHVzICsgJydcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IHJlc3BvbnNlRXJyb3Iuc3RhdHVzVGV4dCB8fCBgSFRUUCAke3N0YXR1c30gZXJyb3JgXG4gICAgICAgIHJlamVjdChuZXcgU3RvcmFnZUFwaUVycm9yKG1lc3NhZ2UsIHN0YXR1cywgc3RhdHVzQ29kZSwgbmFtZXNwYWNlKSlcbiAgICAgIH0pXG4gIH0gZWxzZSB7XG4gICAgcmVqZWN0KG5ldyBTdG9yYWdlVW5rbm93bkVycm9yKF9nZXRFcnJvck1lc3NhZ2UoZXJyb3IpLCBlcnJvciwgbmFtZXNwYWNlKSlcbiAgfVxufVxuXG4vKipcbiAqIEJ1aWxkcyByZXF1ZXN0IHBhcmFtZXRlcnMgZm9yIGZldGNoIGNhbGxzXG4gKiBAcGFyYW0gbWV0aG9kIC0gSFRUUCBtZXRob2RcbiAqIEBwYXJhbSBvcHRpb25zIC0gQ3VzdG9tIGZldGNoIG9wdGlvbnNcbiAqIEBwYXJhbSBwYXJhbWV0ZXJzIC0gQWRkaXRpb25hbCBmZXRjaCBwYXJhbWV0ZXJzIGxpa2UgQWJvcnRTaWduYWxcbiAqIEBwYXJhbSBib2R5IC0gUmVxdWVzdCBib2R5ICh3aWxsIGJlIEpTT04gc3RyaW5naWZpZWQgaWYgcGxhaW4gb2JqZWN0KVxuICogQHJldHVybnMgQ29tcGxldGUgZmV0Y2ggcmVxdWVzdCBwYXJhbWV0ZXJzXG4gKi9cbmNvbnN0IF9nZXRSZXF1ZXN0UGFyYW1zID0gKFxuICBtZXRob2Q6IFJlcXVlc3RNZXRob2RUeXBlLFxuICBvcHRpb25zPzogRmV0Y2hPcHRpb25zLFxuICBwYXJhbWV0ZXJzPzogRmV0Y2hQYXJhbWV0ZXJzLFxuICBib2R5Pzogb2JqZWN0XG4pID0+IHtcbiAgY29uc3QgcGFyYW1zOiB7IFtrOiBzdHJpbmddOiBhbnkgfSA9IHsgbWV0aG9kLCBoZWFkZXJzOiBvcHRpb25zPy5oZWFkZXJzIHx8IHt9IH1cblxuICBpZiAobWV0aG9kID09PSAnR0VUJyB8fCBtZXRob2QgPT09ICdIRUFEJyB8fCAhYm9keSkge1xuICAgIHJldHVybiB7IC4uLnBhcmFtcywgLi4ucGFyYW1ldGVycyB9XG4gIH1cblxuICBpZiAoaXNQbGFpbk9iamVjdChib2R5KSkge1xuICAgIGNvbnN0IGhlYWRlcnMgPSBvcHRpb25zPy5oZWFkZXJzIHx8IHt9XG4gICAgbGV0IGNvbnRlbnRUeXBlOiBzdHJpbmcgfCB1bmRlZmluZWRcblxuICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGhlYWRlcnMpKSB7XG4gICAgICBpZiAoa2V5LnRvTG93ZXJDYXNlKCkgPT09ICdjb250ZW50LXR5cGUnKSB7XG4gICAgICAgIGNvbnRlbnRUeXBlID0gdmFsdWVcbiAgICAgIH1cbiAgICB9XG5cbiAgICBwYXJhbXMuaGVhZGVycyA9IHNldEhlYWRlcihoZWFkZXJzLCAnQ29udGVudC1UeXBlJywgY29udGVudFR5cGUgPz8gJ2FwcGxpY2F0aW9uL2pzb24nKVxuICAgIHBhcmFtcy5ib2R5ID0gSlNPTi5zdHJpbmdpZnkoYm9keSlcbiAgfSBlbHNlIHtcbiAgICBwYXJhbXMuYm9keSA9IGJvZHlcbiAgfVxuXG4gIGlmIChvcHRpb25zPy5kdXBsZXgpIHtcbiAgICBwYXJhbXMuZHVwbGV4ID0gb3B0aW9ucy5kdXBsZXhcbiAgfVxuXG4gIHJldHVybiB7IC4uLnBhcmFtcywgLi4ucGFyYW1ldGVycyB9XG59XG5cbi8qKlxuICogSW50ZXJuYWwgcmVxdWVzdCBoYW5kbGVyIHRoYXQgd3JhcHMgZmV0Y2ggd2l0aCBlcnJvciBoYW5kbGluZ1xuICogQHBhcmFtIGZldGNoZXIgLSBGZXRjaCBmdW5jdGlvbiB0byB1c2VcbiAqIEBwYXJhbSBtZXRob2QgLSBIVFRQIG1ldGhvZFxuICogQHBhcmFtIHVybCAtIFJlcXVlc3QgVVJMXG4gKiBAcGFyYW0gb3B0aW9ucyAtIEN1c3RvbSBmZXRjaCBvcHRpb25zXG4gKiBAcGFyYW0gcGFyYW1ldGVycyAtIEFkZGl0aW9uYWwgZmV0Y2ggcGFyYW1ldGVyc1xuICogQHBhcmFtIGJvZHkgLSBSZXF1ZXN0IGJvZHlcbiAqIEBwYXJhbSBuYW1lc3BhY2UgLSBFcnJvciBuYW1lc3BhY2UgKCdzdG9yYWdlJyBvciAndmVjdG9ycycpXG4gKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcGFyc2VkIHJlc3BvbnNlIG9yIGVycm9yXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIF9oYW5kbGVSZXF1ZXN0KFxuICBmZXRjaGVyOiBGZXRjaCxcbiAgbWV0aG9kOiBSZXF1ZXN0TWV0aG9kVHlwZSxcbiAgdXJsOiBzdHJpbmcsXG4gIG9wdGlvbnM6IEZldGNoT3B0aW9ucyB8IHVuZGVmaW5lZCxcbiAgcGFyYW1ldGVyczogRmV0Y2hQYXJhbWV0ZXJzIHwgdW5kZWZpbmVkLFxuICBib2R5OiBvYmplY3QgfCB1bmRlZmluZWQsXG4gIG5hbWVzcGFjZTogRXJyb3JOYW1lc3BhY2Vcbik6IFByb21pc2U8YW55PiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgZmV0Y2hlcih1cmwsIF9nZXRSZXF1ZXN0UGFyYW1zKG1ldGhvZCwgb3B0aW9ucywgcGFyYW1ldGVycywgYm9keSkpXG4gICAgICAudGhlbigocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmICghcmVzdWx0Lm9rKSB0aHJvdyByZXN1bHRcbiAgICAgICAgaWYgKG9wdGlvbnM/Lm5vUmVzb2x2ZUpzb24pIHJldHVybiByZXN1bHRcblxuICAgICAgICAvLyBBV1MgUzMgVmVjdG9ycyBBUEkgcmV0dXJucyAyMDAgT0sgd2l0aCBjb250ZW50LWxlbmd0aDogMCBmb3Igc3VjY2Vzc2Z1bCBtdXRhdGlvbnNcbiAgICAgICAgLy8gKHB1dFZlY3RvcnMsIGRlbGV0ZVZlY3RvcnMpIGluc3RlYWQgb2YgMjA0IG9yIEpTT04gcmVzcG9uc2UuIFRoaXMgaXMgQVdTJ3MgZGVzaWduIGNob2ljZVxuICAgICAgICAvLyBmb3IgcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9uIG9mIGJ1bGsgb3BlcmF0aW9ucyAodXAgdG8gNTAwIHZlY3RvcnMgcGVyIHJlcXVlc3QpLlxuICAgICAgICAvLyBXZSBoYW5kbGUgdGhpcyB0byBwcmV2ZW50IFwiVW5leHBlY3RlZCBlbmQgb2YgSlNPTiBpbnB1dFwiIGVycm9ycyB3aGVuIGNhbGxpbmcgcmVzdWx0Lmpzb24oKVxuICAgICAgICBpZiAobmFtZXNwYWNlID09PSAndmVjdG9ycycpIHtcbiAgICAgICAgICBjb25zdCBjb250ZW50VHlwZSA9IHJlc3VsdC5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJylcbiAgICAgICAgICBjb25zdCBjb250ZW50TGVuZ3RoID0gcmVzdWx0LmhlYWRlcnMuZ2V0KCdjb250ZW50LWxlbmd0aCcpXG5cbiAgICAgICAgICAvLyBSZXR1cm4gZW1wdHkgb2JqZWN0IGZvciBleHBsaWNpdGx5IGVtcHR5IHJlc3BvbnNlc1xuICAgICAgICAgIGlmIChjb250ZW50TGVuZ3RoID09PSAnMCcgfHwgcmVzdWx0LnN0YXR1cyA9PT0gMjA0KSB7XG4gICAgICAgICAgICByZXR1cm4ge31cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBSZXR1cm4gZW1wdHkgb2JqZWN0IGlmIG5vIEpTT04gY29udGVudCB0eXBlXG4gICAgICAgICAgaWYgKCFjb250ZW50VHlwZSB8fCAhY29udGVudFR5cGUuaW5jbHVkZXMoJ2FwcGxpY2F0aW9uL2pzb24nKSkge1xuICAgICAgICAgICAgcmV0dXJuIHt9XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdC5qc29uKClcbiAgICAgIH0pXG4gICAgICAudGhlbigoZGF0YSkgPT4gcmVzb2x2ZShkYXRhKSlcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+IGhhbmRsZUVycm9yKGVycm9yLCByZWplY3QsIG9wdGlvbnMsIG5hbWVzcGFjZSkpXG4gIH0pXG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIGZldGNoIEFQSSB3aXRoIHRoZSBzcGVjaWZpZWQgbmFtZXNwYWNlXG4gKiBAcGFyYW0gbmFtZXNwYWNlIC0gRXJyb3IgbmFtZXNwYWNlICgnc3RvcmFnZScgb3IgJ3ZlY3RvcnMnKVxuICogQHJldHVybnMgT2JqZWN0IHdpdGggSFRUUCBtZXRob2QgZnVuY3Rpb25zXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVGZXRjaEFwaShuYW1lc3BhY2U6IEVycm9yTmFtZXNwYWNlID0gJ3N0b3JhZ2UnKSB7XG4gIHJldHVybiB7XG4gICAgLyoqXG4gICAgICogUGVyZm9ybXMgYSBHRVQgcmVxdWVzdFxuICAgICAqIEBwYXJhbSBmZXRjaGVyIC0gRmV0Y2ggZnVuY3Rpb24gdG8gdXNlXG4gICAgICogQHBhcmFtIHVybCAtIFJlcXVlc3QgVVJMXG4gICAgICogQHBhcmFtIG9wdGlvbnMgLSBDdXN0b20gZmV0Y2ggb3B0aW9uc1xuICAgICAqIEBwYXJhbSBwYXJhbWV0ZXJzIC0gQWRkaXRpb25hbCBmZXRjaCBwYXJhbWV0ZXJzXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHBhcnNlZCByZXNwb25zZVxuICAgICAqL1xuICAgIGdldDogYXN5bmMgKFxuICAgICAgZmV0Y2hlcjogRmV0Y2gsXG4gICAgICB1cmw6IHN0cmluZyxcbiAgICAgIG9wdGlvbnM/OiBGZXRjaE9wdGlvbnMsXG4gICAgICBwYXJhbWV0ZXJzPzogRmV0Y2hQYXJhbWV0ZXJzXG4gICAgKTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgICAgIHJldHVybiBfaGFuZGxlUmVxdWVzdChmZXRjaGVyLCAnR0VUJywgdXJsLCBvcHRpb25zLCBwYXJhbWV0ZXJzLCB1bmRlZmluZWQsIG5hbWVzcGFjZSlcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogUGVyZm9ybXMgYSBQT1NUIHJlcXVlc3RcbiAgICAgKiBAcGFyYW0gZmV0Y2hlciAtIEZldGNoIGZ1bmN0aW9uIHRvIHVzZVxuICAgICAqIEBwYXJhbSB1cmwgLSBSZXF1ZXN0IFVSTFxuICAgICAqIEBwYXJhbSBib2R5IC0gUmVxdWVzdCBib2R5IHRvIGJlIEpTT04gc3RyaW5naWZpZWRcbiAgICAgKiBAcGFyYW0gb3B0aW9ucyAtIEN1c3RvbSBmZXRjaCBvcHRpb25zXG4gICAgICogQHBhcmFtIHBhcmFtZXRlcnMgLSBBZGRpdGlvbmFsIGZldGNoIHBhcmFtZXRlcnNcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcGFyc2VkIHJlc3BvbnNlXG4gICAgICovXG4gICAgcG9zdDogYXN5bmMgKFxuICAgICAgZmV0Y2hlcjogRmV0Y2gsXG4gICAgICB1cmw6IHN0cmluZyxcbiAgICAgIGJvZHk6IG9iamVjdCxcbiAgICAgIG9wdGlvbnM/OiBGZXRjaE9wdGlvbnMsXG4gICAgICBwYXJhbWV0ZXJzPzogRmV0Y2hQYXJhbWV0ZXJzXG4gICAgKTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgICAgIHJldHVybiBfaGFuZGxlUmVxdWVzdChmZXRjaGVyLCAnUE9TVCcsIHVybCwgb3B0aW9ucywgcGFyYW1ldGVycywgYm9keSwgbmFtZXNwYWNlKVxuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyBhIFBVVCByZXF1ZXN0XG4gICAgICogQHBhcmFtIGZldGNoZXIgLSBGZXRjaCBmdW5jdGlvbiB0byB1c2VcbiAgICAgKiBAcGFyYW0gdXJsIC0gUmVxdWVzdCBVUkxcbiAgICAgKiBAcGFyYW0gYm9keSAtIFJlcXVlc3QgYm9keSB0byBiZSBKU09OIHN0cmluZ2lmaWVkXG4gICAgICogQHBhcmFtIG9wdGlvbnMgLSBDdXN0b20gZmV0Y2ggb3B0aW9uc1xuICAgICAqIEBwYXJhbSBwYXJhbWV0ZXJzIC0gQWRkaXRpb25hbCBmZXRjaCBwYXJhbWV0ZXJzXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHBhcnNlZCByZXNwb25zZVxuICAgICAqL1xuICAgIHB1dDogYXN5bmMgKFxuICAgICAgZmV0Y2hlcjogRmV0Y2gsXG4gICAgICB1cmw6IHN0cmluZyxcbiAgICAgIGJvZHk6IG9iamVjdCxcbiAgICAgIG9wdGlvbnM/OiBGZXRjaE9wdGlvbnMsXG4gICAgICBwYXJhbWV0ZXJzPzogRmV0Y2hQYXJhbWV0ZXJzXG4gICAgKTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgICAgIHJldHVybiBfaGFuZGxlUmVxdWVzdChmZXRjaGVyLCAnUFVUJywgdXJsLCBvcHRpb25zLCBwYXJhbWV0ZXJzLCBib2R5LCBuYW1lc3BhY2UpXG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIFBlcmZvcm1zIGEgSEVBRCByZXF1ZXN0XG4gICAgICogQHBhcmFtIGZldGNoZXIgLSBGZXRjaCBmdW5jdGlvbiB0byB1c2VcbiAgICAgKiBAcGFyYW0gdXJsIC0gUmVxdWVzdCBVUkxcbiAgICAgKiBAcGFyYW0gb3B0aW9ucyAtIEN1c3RvbSBmZXRjaCBvcHRpb25zXG4gICAgICogQHBhcmFtIHBhcmFtZXRlcnMgLSBBZGRpdGlvbmFsIGZldGNoIHBhcmFtZXRlcnNcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggUmVzcG9uc2Ugb2JqZWN0IChub3QgSlNPTiBwYXJzZWQpXG4gICAgICovXG4gICAgaGVhZDogYXN5bmMgKFxuICAgICAgZmV0Y2hlcjogRmV0Y2gsXG4gICAgICB1cmw6IHN0cmluZyxcbiAgICAgIG9wdGlvbnM/OiBGZXRjaE9wdGlvbnMsXG4gICAgICBwYXJhbWV0ZXJzPzogRmV0Y2hQYXJhbWV0ZXJzXG4gICAgKTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgICAgIHJldHVybiBfaGFuZGxlUmVxdWVzdChcbiAgICAgICAgZmV0Y2hlcixcbiAgICAgICAgJ0hFQUQnLFxuICAgICAgICB1cmwsXG4gICAgICAgIHtcbiAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgIG5vUmVzb2x2ZUpzb246IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIHBhcmFtZXRlcnMsXG4gICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgbmFtZXNwYWNlXG4gICAgICApXG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIFBlcmZvcm1zIGEgREVMRVRFIHJlcXVlc3RcbiAgICAgKiBAcGFyYW0gZmV0Y2hlciAtIEZldGNoIGZ1bmN0aW9uIHRvIHVzZVxuICAgICAqIEBwYXJhbSB1cmwgLSBSZXF1ZXN0IFVSTFxuICAgICAqIEBwYXJhbSBib2R5IC0gUmVxdWVzdCBib2R5IHRvIGJlIEpTT04gc3RyaW5naWZpZWRcbiAgICAgKiBAcGFyYW0gb3B0aW9ucyAtIEN1c3RvbSBmZXRjaCBvcHRpb25zXG4gICAgICogQHBhcmFtIHBhcmFtZXRlcnMgLSBBZGRpdGlvbmFsIGZldGNoIHBhcmFtZXRlcnNcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcGFyc2VkIHJlc3BvbnNlXG4gICAgICovXG4gICAgcmVtb3ZlOiBhc3luYyAoXG4gICAgICBmZXRjaGVyOiBGZXRjaCxcbiAgICAgIHVybDogc3RyaW5nLFxuICAgICAgYm9keTogb2JqZWN0LFxuICAgICAgb3B0aW9ucz86IEZldGNoT3B0aW9ucyxcbiAgICAgIHBhcmFtZXRlcnM/OiBGZXRjaFBhcmFtZXRlcnNcbiAgICApOiBQcm9taXNlPGFueT4gPT4ge1xuICAgICAgcmV0dXJuIF9oYW5kbGVSZXF1ZXN0KGZldGNoZXIsICdERUxFVEUnLCB1cmwsIG9wdGlvbnMsIHBhcmFtZXRlcnMsIGJvZHksIG5hbWVzcGFjZSlcbiAgICB9LFxuICB9XG59XG5cbi8vIERlZmF1bHQgZXhwb3J0cyBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eSB3aXRoICdzdG9yYWdlJyBuYW1lc3BhY2VcbmNvbnN0IGRlZmF1bHRBcGkgPSBjcmVhdGVGZXRjaEFwaSgnc3RvcmFnZScpXG5leHBvcnQgY29uc3QgeyBnZXQsIHBvc3QsIHB1dCwgaGVhZCwgcmVtb3ZlIH0gPSBkZWZhdWx0QXBpXG5cbi8vIFZlY3RvcnMgQVBJIHdpdGggJ3ZlY3RvcnMnIG5hbWVzcGFjZSBmb3IgcHJvcGVyIGVycm9yIGhhbmRsaW5nXG5leHBvcnQgY29uc3QgdmVjdG9yc0FwaSA9IGNyZWF0ZUZldGNoQXBpKCd2ZWN0b3JzJylcbiIsImltcG9ydCB7IEVycm9yTmFtZXNwYWNlLCBpc1N0b3JhZ2VFcnJvciwgU3RvcmFnZUVycm9yIH0gZnJvbSAnLi9lcnJvcnMnXG5pbXBvcnQgeyBGZXRjaCB9IGZyb20gJy4vZmV0Y2gnXG5pbXBvcnQgeyBub3JtYWxpemVIZWFkZXJzLCBzZXRIZWFkZXIgYXMgc2V0SGVhZGVyVXRpbCB9IGZyb20gJy4vaGVhZGVycydcbmltcG9ydCB7IHJlc29sdmVGZXRjaCB9IGZyb20gJy4vaGVscGVycydcblxuLyoqXG4gKiBAaWdub3JlXG4gKiBCYXNlIEFQSSBjbGllbnQgY2xhc3MgZm9yIGFsbCBTdG9yYWdlIEFQSSBjbGFzc2VzXG4gKiBQcm92aWRlcyBjb21tb24gaW5mcmFzdHJ1Y3R1cmUgZm9yIGVycm9yIGhhbmRsaW5nIGFuZCBjb25maWd1cmF0aW9uXG4gKlxuICogQHR5cGVQYXJhbSBURXJyb3IgLSBUaGUgZXJyb3IgdHlwZSAoU3RvcmFnZUVycm9yIG9yIHN1YmNsYXNzKVxuICovXG5leHBvcnQgZGVmYXVsdCBhYnN0cmFjdCBjbGFzcyBCYXNlQXBpQ2xpZW50PFRFcnJvciBleHRlbmRzIFN0b3JhZ2VFcnJvciA9IFN0b3JhZ2VFcnJvcj4ge1xuICBwcm90ZWN0ZWQgdXJsOiBzdHJpbmdcbiAgcHJvdGVjdGVkIGhlYWRlcnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH1cbiAgcHJvdGVjdGVkIGZldGNoOiBGZXRjaFxuICBwcm90ZWN0ZWQgc2hvdWxkVGhyb3dPbkVycm9yID0gZmFsc2VcbiAgcHJvdGVjdGVkIG5hbWVzcGFjZTogRXJyb3JOYW1lc3BhY2VcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBCYXNlQXBpQ2xpZW50IGluc3RhbmNlXG4gICAqIEBwYXJhbSB1cmwgLSBCYXNlIFVSTCBmb3IgQVBJIHJlcXVlc3RzXG4gICAqIEBwYXJhbSBoZWFkZXJzIC0gRGVmYXVsdCBoZWFkZXJzIGZvciBBUEkgcmVxdWVzdHNcbiAgICogQHBhcmFtIGZldGNoIC0gT3B0aW9uYWwgY3VzdG9tIGZldGNoIGltcGxlbWVudGF0aW9uXG4gICAqIEBwYXJhbSBuYW1lc3BhY2UgLSBFcnJvciBuYW1lc3BhY2UgKCdzdG9yYWdlJyBvciAndmVjdG9ycycpXG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICB1cmw6IHN0cmluZyxcbiAgICBoZWFkZXJzOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge30sXG4gICAgZmV0Y2g/OiBGZXRjaCxcbiAgICBuYW1lc3BhY2U6IEVycm9yTmFtZXNwYWNlID0gJ3N0b3JhZ2UnXG4gICkge1xuICAgIHRoaXMudXJsID0gdXJsXG4gICAgdGhpcy5oZWFkZXJzID0gbm9ybWFsaXplSGVhZGVycyhoZWFkZXJzKVxuICAgIHRoaXMuZmV0Y2ggPSByZXNvbHZlRmV0Y2goZmV0Y2gpXG4gICAgdGhpcy5uYW1lc3BhY2UgPSBuYW1lc3BhY2VcbiAgfVxuXG4gIC8qKlxuICAgKiBFbmFibGUgdGhyb3dpbmcgZXJyb3JzIGluc3RlYWQgb2YgcmV0dXJuaW5nIHRoZW0uXG4gICAqIFdoZW4gZW5hYmxlZCwgZXJyb3JzIGFyZSB0aHJvd24gaW5zdGVhZCBvZiByZXR1cm5lZCBpbiB7IGRhdGEsIGVycm9yIH0gZm9ybWF0LlxuICAgKlxuICAgKiBAcmV0dXJucyB0aGlzIC0gRm9yIG1ldGhvZCBjaGFpbmluZ1xuICAgKi9cbiAgcHVibGljIHRocm93T25FcnJvcigpOiB0aGlzIHtcbiAgICB0aGlzLnNob3VsZFRocm93T25FcnJvciA9IHRydWVcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIFNldCBhbiBIVFRQIGhlYWRlciBmb3IgdGhlIHJlcXVlc3QuXG4gICAqIENyZWF0ZXMgYSBzaGFsbG93IGNvcHkgb2YgaGVhZGVycyB0byBhdm9pZCBtdXRhdGluZyBzaGFyZWQgc3RhdGUuXG4gICAqXG4gICAqIEBwYXJhbSBuYW1lIC0gSGVhZGVyIG5hbWVcbiAgICogQHBhcmFtIHZhbHVlIC0gSGVhZGVyIHZhbHVlXG4gICAqIEByZXR1cm5zIHRoaXMgLSBGb3IgbWV0aG9kIGNoYWluaW5nXG4gICAqL1xuICBwdWJsaWMgc2V0SGVhZGVyKG5hbWU6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHRoaXMge1xuICAgIHRoaXMuaGVhZGVycyA9IHNldEhlYWRlclV0aWwodGhpcy5oZWFkZXJzLCBuYW1lLCB2YWx1ZSlcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgLyoqXG4gICAqIEhhbmRsZXMgQVBJIG9wZXJhdGlvbiB3aXRoIHN0YW5kYXJkaXplZCBlcnJvciBoYW5kbGluZ1xuICAgKiBFbGltaW5hdGVzIHJlcGV0aXRpdmUgdHJ5LWNhdGNoIGJsb2NrcyBhY3Jvc3MgYWxsIEFQSSBtZXRob2RzXG4gICAqXG4gICAqIFRoaXMgd3JhcHBlcjpcbiAgICogMS4gRXhlY3V0ZXMgdGhlIG9wZXJhdGlvblxuICAgKiAyLiBSZXR1cm5zIHsgZGF0YSwgZXJyb3I6IG51bGwgfSBvbiBzdWNjZXNzXG4gICAqIDMuIFJldHVybnMgeyBkYXRhOiBudWxsLCBlcnJvciB9IG9uIGZhaWx1cmUgKGlmIHNob3VsZFRocm93T25FcnJvciBpcyBmYWxzZSlcbiAgICogNC4gVGhyb3dzIGVycm9yIG9uIGZhaWx1cmUgKGlmIHNob3VsZFRocm93T25FcnJvciBpcyB0cnVlKVxuICAgKlxuICAgKiBAdHlwZVBhcmFtIFQgLSBUaGUgZXhwZWN0ZWQgZGF0YSB0eXBlIGZyb20gdGhlIG9wZXJhdGlvblxuICAgKiBAcGFyYW0gb3BlcmF0aW9uIC0gQXN5bmMgZnVuY3Rpb24gdGhhdCBwZXJmb3JtcyB0aGUgQVBJIGNhbGxcbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHsgZGF0YSwgZXJyb3IgfSB0dXBsZVxuICAgKlxuICAgKiBAZXhhbXBsZSBIYW5kbGluZyBhbiBvcGVyYXRpb25cbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBhc3luYyBsaXN0QnVja2V0cygpIHtcbiAgICogICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgKiAgICAgcmV0dXJuIGF3YWl0IGdldCh0aGlzLmZldGNoLCBgJHt0aGlzLnVybH0vYnVja2V0YCwge1xuICAgKiAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAqICAgICB9KVxuICAgKiAgIH0pXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBwcm90ZWN0ZWQgYXN5bmMgaGFuZGxlT3BlcmF0aW9uPFQ+KFxuICAgIG9wZXJhdGlvbjogKCkgPT4gUHJvbWlzZTxUPlxuICApOiBQcm9taXNlPHsgZGF0YTogVDsgZXJyb3I6IG51bGwgfSB8IHsgZGF0YTogbnVsbDsgZXJyb3I6IFRFcnJvciB9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBvcGVyYXRpb24oKVxuICAgICAgcmV0dXJuIHsgZGF0YSwgZXJyb3I6IG51bGwgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAodGhpcy5zaG91bGRUaHJvd09uRXJyb3IpIHtcbiAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgIH1cbiAgICAgIGlmIChpc1N0b3JhZ2VFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3I6IGVycm9yIGFzIFRFcnJvciB9XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwiaW1wb3J0IHsgaXNTdG9yYWdlRXJyb3IgfSBmcm9tICcuLi9saWIvY29tbW9uL2Vycm9ycydcbmltcG9ydCB7IERvd25sb2FkUmVzdWx0IH0gZnJvbSAnLi4vbGliL3R5cGVzJ1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTdHJlYW1Eb3dubG9hZEJ1aWxkZXIgaW1wbGVtZW50cyBQcm9taXNlPERvd25sb2FkUmVzdWx0PFJlYWRhYmxlU3RyZWFtPj4ge1xuICByZWFkb25seSBbU3ltYm9sLnRvU3RyaW5nVGFnXTogc3RyaW5nID0gJ1N0cmVhbURvd25sb2FkQnVpbGRlcidcbiAgcHJpdmF0ZSBwcm9taXNlOiBQcm9taXNlPERvd25sb2FkUmVzdWx0PFJlYWRhYmxlU3RyZWFtPj4gfCBudWxsID0gbnVsbFxuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgZG93bmxvYWRGbjogKCkgPT4gUHJvbWlzZTxSZXNwb25zZT4sXG4gICAgcHJpdmF0ZSBzaG91bGRUaHJvd09uRXJyb3I6IGJvb2xlYW5cbiAgKSB7fVxuXG4gIHRoZW48VFJlc3VsdDEgPSBEb3dubG9hZFJlc3VsdDxSZWFkYWJsZVN0cmVhbT4sIFRSZXN1bHQyID0gbmV2ZXI+KFxuICAgIG9uZnVsZmlsbGVkPzpcbiAgICAgIHwgKCh2YWx1ZTogRG93bmxvYWRSZXN1bHQ8UmVhZGFibGVTdHJlYW0+KSA9PiBUUmVzdWx0MSB8IFByb21pc2VMaWtlPFRSZXN1bHQxPilcbiAgICAgIHwgbnVsbCxcbiAgICBvbnJlamVjdGVkPzogKChyZWFzb246IGFueSkgPT4gVFJlc3VsdDIgfCBQcm9taXNlTGlrZTxUUmVzdWx0Mj4pIHwgbnVsbFxuICApOiBQcm9taXNlPFRSZXN1bHQxIHwgVFJlc3VsdDI+IHtcbiAgICByZXR1cm4gdGhpcy5nZXRQcm9taXNlKCkudGhlbihvbmZ1bGZpbGxlZCwgb25yZWplY3RlZClcbiAgfVxuXG4gIGNhdGNoPFRSZXN1bHQgPSBuZXZlcj4oXG4gICAgb25yZWplY3RlZD86ICgocmVhc29uOiBhbnkpID0+IFRSZXN1bHQgfCBQcm9taXNlTGlrZTxUUmVzdWx0PikgfCBudWxsXG4gICk6IFByb21pc2U8RG93bmxvYWRSZXN1bHQ8UmVhZGFibGVTdHJlYW0+IHwgVFJlc3VsdD4ge1xuICAgIHJldHVybiB0aGlzLmdldFByb21pc2UoKS5jYXRjaChvbnJlamVjdGVkKVxuICB9XG5cbiAgZmluYWxseShvbmZpbmFsbHk/OiAoKCkgPT4gdm9pZCkgfCBudWxsKTogUHJvbWlzZTxEb3dubG9hZFJlc3VsdDxSZWFkYWJsZVN0cmVhbT4+IHtcbiAgICByZXR1cm4gdGhpcy5nZXRQcm9taXNlKCkuZmluYWxseShvbmZpbmFsbHkpXG4gIH1cblxuICBwcml2YXRlIGdldFByb21pc2UoKTogUHJvbWlzZTxEb3dubG9hZFJlc3VsdDxSZWFkYWJsZVN0cmVhbT4+IHtcbiAgICBpZiAoIXRoaXMucHJvbWlzZSkge1xuICAgICAgdGhpcy5wcm9taXNlID0gdGhpcy5leGVjdXRlKClcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucHJvbWlzZVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBleGVjdXRlKCk6IFByb21pc2U8RG93bmxvYWRSZXN1bHQ8UmVhZGFibGVTdHJlYW0+PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuZG93bmxvYWRGbigpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGE6IHJlc3VsdC5ib2R5IGFzIFJlYWRhYmxlU3RyZWFtLFxuICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKHRoaXMuc2hvdWxkVGhyb3dPbkVycm9yKSB7XG4gICAgICAgIHRocm93IGVycm9yXG4gICAgICB9XG5cbiAgICAgIGlmIChpc1N0b3JhZ2VFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3IgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwiaW1wb3J0IHsgaXNTdG9yYWdlRXJyb3IgfSBmcm9tICcuLi9saWIvY29tbW9uL2Vycm9ycydcbmltcG9ydCB7IERvd25sb2FkUmVzdWx0IH0gZnJvbSAnLi4vbGliL3R5cGVzJ1xuaW1wb3J0IFN0cmVhbURvd25sb2FkQnVpbGRlciBmcm9tICcuL1N0cmVhbURvd25sb2FkQnVpbGRlcidcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQmxvYkRvd25sb2FkQnVpbGRlciBpbXBsZW1lbnRzIFByb21pc2U8RG93bmxvYWRSZXN1bHQ8QmxvYj4+IHtcbiAgcmVhZG9ubHkgW1N5bWJvbC50b1N0cmluZ1RhZ106IHN0cmluZyA9ICdCbG9iRG93bmxvYWRCdWlsZGVyJ1xuICBwcml2YXRlIHByb21pc2U6IFByb21pc2U8RG93bmxvYWRSZXN1bHQ8QmxvYj4+IHwgbnVsbCA9IG51bGxcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGRvd25sb2FkRm46ICgpID0+IFByb21pc2U8UmVzcG9uc2U+LFxuICAgIHByaXZhdGUgc2hvdWxkVGhyb3dPbkVycm9yOiBib29sZWFuXG4gICkge31cblxuICBhc1N0cmVhbSgpOiBTdHJlYW1Eb3dubG9hZEJ1aWxkZXIge1xuICAgIHJldHVybiBuZXcgU3RyZWFtRG93bmxvYWRCdWlsZGVyKHRoaXMuZG93bmxvYWRGbiwgdGhpcy5zaG91bGRUaHJvd09uRXJyb3IpXG4gIH1cblxuICB0aGVuPFRSZXN1bHQxID0gRG93bmxvYWRSZXN1bHQ8QmxvYj4sIFRSZXN1bHQyID0gbmV2ZXI+KFxuICAgIG9uZnVsZmlsbGVkPzogKCh2YWx1ZTogRG93bmxvYWRSZXN1bHQ8QmxvYj4pID0+IFRSZXN1bHQxIHwgUHJvbWlzZUxpa2U8VFJlc3VsdDE+KSB8IG51bGwsXG4gICAgb25yZWplY3RlZD86ICgocmVhc29uOiBhbnkpID0+IFRSZXN1bHQyIHwgUHJvbWlzZUxpa2U8VFJlc3VsdDI+KSB8IG51bGxcbiAgKTogUHJvbWlzZTxUUmVzdWx0MSB8IFRSZXN1bHQyPiB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0UHJvbWlzZSgpLnRoZW4ob25mdWxmaWxsZWQsIG9ucmVqZWN0ZWQpXG4gIH1cblxuICBjYXRjaDxUUmVzdWx0ID0gbmV2ZXI+KFxuICAgIG9ucmVqZWN0ZWQ/OiAoKHJlYXNvbjogYW55KSA9PiBUUmVzdWx0IHwgUHJvbWlzZUxpa2U8VFJlc3VsdD4pIHwgbnVsbFxuICApOiBQcm9taXNlPERvd25sb2FkUmVzdWx0PEJsb2I+IHwgVFJlc3VsdD4ge1xuICAgIHJldHVybiB0aGlzLmdldFByb21pc2UoKS5jYXRjaChvbnJlamVjdGVkKVxuICB9XG5cbiAgZmluYWxseShvbmZpbmFsbHk/OiAoKCkgPT4gdm9pZCkgfCBudWxsKTogUHJvbWlzZTxEb3dubG9hZFJlc3VsdDxCbG9iPj4ge1xuICAgIHJldHVybiB0aGlzLmdldFByb21pc2UoKS5maW5hbGx5KG9uZmluYWxseSlcbiAgfVxuXG4gIHByaXZhdGUgZ2V0UHJvbWlzZSgpOiBQcm9taXNlPERvd25sb2FkUmVzdWx0PEJsb2I+PiB7XG4gICAgaWYgKCF0aGlzLnByb21pc2UpIHtcbiAgICAgIHRoaXMucHJvbWlzZSA9IHRoaXMuZXhlY3V0ZSgpXG4gICAgfVxuICAgIHJldHVybiB0aGlzLnByb21pc2VcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZXhlY3V0ZSgpOiBQcm9taXNlPERvd25sb2FkUmVzdWx0PEJsb2I+PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuZG93bmxvYWRGbigpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGE6IGF3YWl0IHJlc3VsdC5ibG9iKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAodGhpcy5zaG91bGRUaHJvd09uRXJyb3IpIHtcbiAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgIH1cblxuICAgICAgaWYgKGlzU3RvcmFnZUVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iLCJpbXBvcnQge1xuICBTdG9yYWdlQXBpRXJyb3IsXG4gIFN0b3JhZ2VFcnJvcixcbiAgU3RvcmFnZVVua25vd25FcnJvcixcbiAgaXNTdG9yYWdlRXJyb3IsXG59IGZyb20gJy4uL2xpYi9jb21tb24vZXJyb3JzJ1xuaW1wb3J0IHsgZ2V0LCBoZWFkLCBwb3N0LCBwdXQsIHJlbW92ZSwgRmV0Y2ggfSBmcm9tICcuLi9saWIvY29tbW9uL2ZldGNoJ1xuaW1wb3J0IHsgc2V0SGVhZGVyIH0gZnJvbSAnLi4vbGliL2NvbW1vbi9oZWFkZXJzJ1xuaW1wb3J0IHsgcmVjdXJzaXZlVG9DYW1lbCB9IGZyb20gJy4uL2xpYi9jb21tb24vaGVscGVycydcbmltcG9ydCBCYXNlQXBpQ2xpZW50IGZyb20gJy4uL2xpYi9jb21tb24vQmFzZUFwaUNsaWVudCdcbmltcG9ydCB7XG4gIEZpbGVPYmplY3QsXG4gIEZpbGVPcHRpb25zLFxuICBTZWFyY2hPcHRpb25zLFxuICBGZXRjaFBhcmFtZXRlcnMsXG4gIFRyYW5zZm9ybU9wdGlvbnMsXG4gIERlc3RpbmF0aW9uT3B0aW9ucyxcbiAgRmlsZU9iamVjdFYyLFxuICBDYW1lbGl6ZSxcbiAgU2VhcmNoVjJPcHRpb25zLFxuICBTZWFyY2hWMlJlc3VsdCxcbn0gZnJvbSAnLi4vbGliL3R5cGVzJ1xuaW1wb3J0IEJsb2JEb3dubG9hZEJ1aWxkZXIgZnJvbSAnLi9CbG9iRG93bmxvYWRCdWlsZGVyJ1xuXG5jb25zdCBERUZBVUxUX1NFQVJDSF9PUFRJT05TID0ge1xuICBsaW1pdDogMTAwLFxuICBvZmZzZXQ6IDAsXG4gIHNvcnRCeToge1xuICAgIGNvbHVtbjogJ25hbWUnLFxuICAgIG9yZGVyOiAnYXNjJyxcbiAgfSxcbn1cblxuY29uc3QgREVGQVVMVF9GSUxFX09QVElPTlM6IEZpbGVPcHRpb25zID0ge1xuICBjYWNoZUNvbnRyb2w6ICczNjAwJyxcbiAgY29udGVudFR5cGU6ICd0ZXh0L3BsYWluO2NoYXJzZXQ9VVRGLTgnLFxuICB1cHNlcnQ6IGZhbHNlLFxufVxuXG50eXBlIEZpbGVCb2R5ID1cbiAgfCBBcnJheUJ1ZmZlclxuICB8IEFycmF5QnVmZmVyVmlld1xuICB8IEJsb2JcbiAgfCBCdWZmZXJcbiAgfCBGaWxlXG4gIHwgRm9ybURhdGFcbiAgfCBOb2RlSlMuUmVhZGFibGVTdHJlYW1cbiAgfCBSZWFkYWJsZVN0cmVhbTxVaW50OEFycmF5PlxuICB8IFVSTFNlYXJjaFBhcmFtc1xuICB8IHN0cmluZ1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTdG9yYWdlRmlsZUFwaSBleHRlbmRzIEJhc2VBcGlDbGllbnQ8U3RvcmFnZUVycm9yPiB7XG4gIHByb3RlY3RlZCBidWNrZXRJZDogc3RyaW5nIHwgdW5kZWZpbmVkXG5cbiAgY29uc3RydWN0b3IoXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgaGVhZGVyczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9LFxuICAgIGJ1Y2tldElkPzogc3RyaW5nLFxuICAgIGZldGNoPzogRmV0Y2hcbiAgKSB7XG4gICAgc3VwZXIodXJsLCBoZWFkZXJzLCBmZXRjaCwgJ3N0b3JhZ2UnKVxuICAgIHRoaXMuYnVja2V0SWQgPSBidWNrZXRJZFxuICB9XG5cbiAgLyoqXG4gICAqIFVwbG9hZHMgYSBmaWxlIHRvIGFuIGV4aXN0aW5nIGJ1Y2tldCBvciByZXBsYWNlcyBhbiBleGlzdGluZyBmaWxlIGF0IHRoZSBzcGVjaWZpZWQgcGF0aCB3aXRoIGEgbmV3IG9uZS5cbiAgICpcbiAgICogQHBhcmFtIG1ldGhvZCBIVFRQIG1ldGhvZC5cbiAgICogQHBhcmFtIHBhdGggVGhlIHJlbGF0aXZlIGZpbGUgcGF0aC4gU2hvdWxkIGJlIG9mIHRoZSBmb3JtYXQgYGZvbGRlci9zdWJmb2xkZXIvZmlsZW5hbWUucG5nYC4gVGhlIGJ1Y2tldCBtdXN0IGFscmVhZHkgZXhpc3QgYmVmb3JlIGF0dGVtcHRpbmcgdG8gdXBsb2FkLlxuICAgKiBAcGFyYW0gZmlsZUJvZHkgVGhlIGJvZHkgb2YgdGhlIGZpbGUgdG8gYmUgc3RvcmVkIGluIHRoZSBidWNrZXQuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIHVwbG9hZE9yVXBkYXRlKFxuICAgIG1ldGhvZDogJ1BPU1QnIHwgJ1BVVCcsXG4gICAgcGF0aDogc3RyaW5nLFxuICAgIGZpbGVCb2R5OiBGaWxlQm9keSxcbiAgICBmaWxlT3B0aW9ucz86IEZpbGVPcHRpb25zXG4gICk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHsgaWQ6IHN0cmluZzsgcGF0aDogc3RyaW5nOyBmdWxsUGF0aDogc3RyaW5nIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gICAgICB9XG4gID4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICBsZXQgYm9keVxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHsgLi4uREVGQVVMVF9GSUxFX09QVElPTlMsIC4uLmZpbGVPcHRpb25zIH1cbiAgICAgIGxldCBoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgICAgICAuLi50aGlzLmhlYWRlcnMsXG4gICAgICAgIC4uLihtZXRob2QgPT09ICdQT1NUJyAmJiB7ICd4LXVwc2VydCc6IFN0cmluZyhvcHRpb25zLnVwc2VydCBhcyBib29sZWFuKSB9KSxcbiAgICAgIH1cblxuICAgICAgY29uc3QgbWV0YWRhdGEgPSBvcHRpb25zLm1ldGFkYXRhXG5cbiAgICAgIGlmICh0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgZmlsZUJvZHkgaW5zdGFuY2VvZiBCbG9iKSB7XG4gICAgICAgIGJvZHkgPSBuZXcgRm9ybURhdGEoKVxuICAgICAgICBib2R5LmFwcGVuZCgnY2FjaGVDb250cm9sJywgb3B0aW9ucy5jYWNoZUNvbnRyb2wgYXMgc3RyaW5nKVxuICAgICAgICBpZiAobWV0YWRhdGEpIHtcbiAgICAgICAgICBib2R5LmFwcGVuZCgnbWV0YWRhdGEnLCB0aGlzLmVuY29kZU1ldGFkYXRhKG1ldGFkYXRhKSlcbiAgICAgICAgfVxuICAgICAgICBib2R5LmFwcGVuZCgnJywgZmlsZUJvZHkpXG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBGb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiYgZmlsZUJvZHkgaW5zdGFuY2VvZiBGb3JtRGF0YSkge1xuICAgICAgICBib2R5ID0gZmlsZUJvZHlcbiAgICAgICAgLy8gT25seSBhcHBlbmQgaWYgbm90IGFscmVhZHkgcHJlc2VudFxuICAgICAgICBpZiAoIWJvZHkuaGFzKCdjYWNoZUNvbnRyb2wnKSkge1xuICAgICAgICAgIGJvZHkuYXBwZW5kKCdjYWNoZUNvbnRyb2wnLCBvcHRpb25zLmNhY2hlQ29udHJvbCBhcyBzdHJpbmcpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1ldGFkYXRhICYmICFib2R5LmhhcygnbWV0YWRhdGEnKSkge1xuICAgICAgICAgIGJvZHkuYXBwZW5kKCdtZXRhZGF0YScsIHRoaXMuZW5jb2RlTWV0YWRhdGEobWV0YWRhdGEpKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBib2R5ID0gZmlsZUJvZHlcbiAgICAgICAgaGVhZGVyc1snY2FjaGUtY29udHJvbCddID0gYG1heC1hZ2U9JHtvcHRpb25zLmNhY2hlQ29udHJvbH1gXG4gICAgICAgIGhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddID0gb3B0aW9ucy5jb250ZW50VHlwZSBhcyBzdHJpbmdcblxuICAgICAgICBpZiAobWV0YWRhdGEpIHtcbiAgICAgICAgICBoZWFkZXJzWyd4LW1ldGFkYXRhJ10gPSB0aGlzLnRvQmFzZTY0KHRoaXMuZW5jb2RlTWV0YWRhdGEobWV0YWRhdGEpKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gTm9kZS5qcyBzdHJlYW1zIHJlcXVpcmUgZHVwbGV4IG9wdGlvbiBmb3IgZmV0Y2ggaW4gTm9kZSAyMCtcbiAgICAgICAgLy8gQ2hlY2sgZm9yIGJvdGggd2ViIFJlYWRhYmxlU3RyZWFtIGFuZCBOb2RlLmpzIHN0cmVhbXNcbiAgICAgICAgY29uc3QgaXNTdHJlYW0gPVxuICAgICAgICAgICh0eXBlb2YgUmVhZGFibGVTdHJlYW0gIT09ICd1bmRlZmluZWQnICYmIGJvZHkgaW5zdGFuY2VvZiBSZWFkYWJsZVN0cmVhbSkgfHxcbiAgICAgICAgICAoYm9keSAmJiB0eXBlb2YgYm9keSA9PT0gJ29iamVjdCcgJiYgJ3BpcGUnIGluIGJvZHkgJiYgdHlwZW9mIGJvZHkucGlwZSA9PT0gJ2Z1bmN0aW9uJylcblxuICAgICAgICBpZiAoaXNTdHJlYW0gJiYgIW9wdGlvbnMuZHVwbGV4KSB7XG4gICAgICAgICAgb3B0aW9ucy5kdXBsZXggPSAnaGFsZidcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoZmlsZU9wdGlvbnM/LmhlYWRlcnMpIHtcbiAgICAgICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoZmlsZU9wdGlvbnMuaGVhZGVycykpIHtcbiAgICAgICAgICBoZWFkZXJzID0gc2V0SGVhZGVyKGhlYWRlcnMsIGtleSwgdmFsdWUpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgY2xlYW5QYXRoID0gdGhpcy5fcmVtb3ZlRW1wdHlGb2xkZXJzKHBhdGgpXG4gICAgICBjb25zdCBfcGF0aCA9IHRoaXMuX2dldEZpbmFsUGF0aChjbGVhblBhdGgpXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgKG1ldGhvZCA9PSAnUFVUJyA/IHB1dCA6IHBvc3QpKFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vb2JqZWN0LyR7X3BhdGh9YCxcbiAgICAgICAgYm9keSBhcyBvYmplY3QsXG4gICAgICAgIHsgaGVhZGVycywgLi4uKG9wdGlvbnM/LmR1cGxleCA/IHsgZHVwbGV4OiBvcHRpb25zLmR1cGxleCB9IDoge30pIH1cbiAgICAgIClcblxuICAgICAgcmV0dXJuIHsgcGF0aDogY2xlYW5QYXRoLCBpZDogZGF0YS5JZCwgZnVsbFBhdGg6IGRhdGEuS2V5IH1cbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIFVwbG9hZHMgYSBmaWxlIHRvIGFuIGV4aXN0aW5nIGJ1Y2tldC5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEZpbGUgQnVja2V0c1xuICAgKiBAcGFyYW0gcGF0aCBUaGUgZmlsZSBwYXRoLCBpbmNsdWRpbmcgdGhlIGZpbGUgbmFtZS4gU2hvdWxkIGJlIG9mIHRoZSBmb3JtYXQgYGZvbGRlci9zdWJmb2xkZXIvZmlsZW5hbWUucG5nYC4gVGhlIGJ1Y2tldCBtdXN0IGFscmVhZHkgZXhpc3QgYmVmb3JlIGF0dGVtcHRpbmcgdG8gdXBsb2FkLlxuICAgKiBAcGFyYW0gZmlsZUJvZHkgVGhlIGJvZHkgb2YgdGhlIGZpbGUgdG8gYmUgc3RvcmVkIGluIHRoZSBidWNrZXQuXG4gICAqIEBwYXJhbSBmaWxlT3B0aW9ucyBPcHRpb25hbCBmaWxlIHVwbG9hZCBvcHRpb25zIGluY2x1ZGluZyBjYWNoZUNvbnRyb2wsIGNvbnRlbnRUeXBlLCB1cHNlcnQsIGFuZCBtZXRhZGF0YS5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgZmlsZSBwYXRoLCBpZCwgYW5kIGZ1bGxQYXRoIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIFVwbG9hZCBmaWxlXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IGF2YXRhckZpbGUgPSBldmVudC50YXJnZXQuZmlsZXNbMF1cbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAudXBsb2FkKCdwdWJsaWMvYXZhdGFyMS5wbmcnLCBhdmF0YXJGaWxlLCB7XG4gICAqICAgICBjYWNoZUNvbnRyb2w6ICczNjAwJyxcbiAgICogICAgIHVwc2VydDogZmFsc2VcbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogUmVzcG9uc2U6XG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcInBhdGhcIjogXCJwdWJsaWMvYXZhdGFyMS5wbmdcIixcbiAgICogICAgIFwiZnVsbFBhdGhcIjogXCJhdmF0YXJzL3B1YmxpYy9hdmF0YXIxLnBuZ1wiXG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgVXBsb2FkIGZpbGUgdXNpbmcgYEFycmF5QnVmZmVyYCBmcm9tIGJhc2U2NCBmaWxlIGRhdGFcbiAgICogYGBganNcbiAgICogaW1wb3J0IHsgZGVjb2RlIH0gZnJvbSAnYmFzZTY0LWFycmF5YnVmZmVyJ1xuICAgKlxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC51cGxvYWQoJ3B1YmxpYy9hdmF0YXIxLnBuZycsIGRlY29kZSgnYmFzZTY0RmlsZURhdGEnKSwge1xuICAgKiAgICAgY29udGVudFR5cGU6ICdpbWFnZS9wbmcnXG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIEhhbmRsaW5nIGVycm9yc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC51cGxvYWQoJ3B1YmxpYy9hdmF0YXIxLnBuZycsIGF2YXRhckZpbGUpXG4gICAqXG4gICAqIGlmIChlcnJvcikge1xuICAgKiAgIC8vIExvZyB0aGUgZnVsbCBlcnJvciBzbyBmaWVsZHMgbGlrZSBgc3RhdHVzQ29kZWAgYW5kIGBlcnJvcmAgKHRoZVxuICAgKiAgIC8vIFN0b3JhZ2UgZXJyb3IgbmFtZSwgZS5nLiBcIkR1cGxpY2F0ZVwiKSBhcmVuJ3QgaGlkZGVuIGJlaGluZCBgZXJyb3IubWVzc2FnZWAuXG4gICAqICAgY29uc29sZS5lcnJvcihlcnJvcilcbiAgICogICByZXR1cm5cbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IG9ubHkgYGluc2VydGAgd2hlbiB5b3UgYXJlIHVwbG9hZGluZyBuZXcgZmlsZXMgYW5kIGBzZWxlY3RgLCBgaW5zZXJ0YCBhbmQgYHVwZGF0ZWAgd2hlbiB5b3UgYXJlIHVwc2VydGluZyBmaWxlc1xuICAgKiAtIFJlZmVyIHRvIHRoZSBbU3RvcmFnZSBndWlkZV0oL2RvY3MvZ3VpZGVzL3N0b3JhZ2Uvc2VjdXJpdHkvYWNjZXNzLWNvbnRyb2wpIG9uIGhvdyBhY2Nlc3MgY29udHJvbCB3b3Jrc1xuICAgKiAtIEZvciBSZWFjdCBOYXRpdmUsIHVzaW5nIGVpdGhlciBgQmxvYmAsIGBGaWxlYCBvciBgRm9ybURhdGFgIGRvZXMgbm90IHdvcmsgYXMgaW50ZW5kZWQuIFVwbG9hZCBmaWxlIHVzaW5nIGBBcnJheUJ1ZmZlcmAgZnJvbSBiYXNlNjQgZmlsZSBkYXRhIGluc3RlYWQsIHNlZSBleGFtcGxlIGJlbG93LlxuICAgKi9cbiAgYXN5bmMgdXBsb2FkKFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBmaWxlQm9keTogRmlsZUJvZHksXG4gICAgZmlsZU9wdGlvbnM/OiBGaWxlT3B0aW9uc1xuICApOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiB7IGlkOiBzdHJpbmc7IHBhdGg6IHN0cmluZzsgZnVsbFBhdGg6IHN0cmluZyB9XG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgICB9XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IG51bGxcbiAgICAgICAgZXJyb3I6IFN0b3JhZ2VFcnJvclxuICAgICAgfVxuICA+IHtcbiAgICByZXR1cm4gdGhpcy51cGxvYWRPclVwZGF0ZSgnUE9TVCcsIHBhdGgsIGZpbGVCb2R5LCBmaWxlT3B0aW9ucylcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGxvYWQgYSBmaWxlIHdpdGggYSB0b2tlbiBnZW5lcmF0ZWQgZnJvbSBgY3JlYXRlU2lnbmVkVXBsb2FkVXJsYC5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEZpbGUgQnVja2V0c1xuICAgKiBAcGFyYW0gcGF0aCBUaGUgZmlsZSBwYXRoLCBpbmNsdWRpbmcgdGhlIGZpbGUgbmFtZS4gU2hvdWxkIGJlIG9mIHRoZSBmb3JtYXQgYGZvbGRlci9zdWJmb2xkZXIvZmlsZW5hbWUucG5nYC4gVGhlIGJ1Y2tldCBtdXN0IGFscmVhZHkgZXhpc3QgYmVmb3JlIGF0dGVtcHRpbmcgdG8gdXBsb2FkLlxuICAgKiBAcGFyYW0gdG9rZW4gVGhlIHRva2VuIGdlbmVyYXRlZCBmcm9tIGBjcmVhdGVTaWduZWRVcGxvYWRVcmxgXG4gICAqIEBwYXJhbSBmaWxlQm9keSBUaGUgYm9keSBvZiB0aGUgZmlsZSB0byBiZSBzdG9yZWQgaW4gdGhlIGJ1Y2tldC5cbiAgICogQHBhcmFtIGZpbGVPcHRpb25zIEhUVFAgaGVhZGVycyAoY2FjaGVDb250cm9sLCBjb250ZW50VHlwZSwgZXRjLikuXG4gICAqICoqTm90ZToqKiBUaGUgYHVwc2VydGAgb3B0aW9uIGhhcyBubyBlZmZlY3QgaGVyZS4gVG8gZW5hYmxlIHVwc2VydCBiZWhhdmlvcixcbiAgICogcGFzcyBgeyB1cHNlcnQ6IHRydWUgfWAgd2hlbiBjYWxsaW5nIGBjcmVhdGVTaWduZWRVcGxvYWRVcmwoKWAgaW5zdGVhZC5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgZmlsZSBwYXRoIGFuZCBmdWxsUGF0aCBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBVcGxvYWQgdG8gYSBzaWduZWQgVVJMXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLnN0b3JhZ2VcbiAgICogICAuZnJvbSgnYXZhdGFycycpXG4gICAqICAgLnVwbG9hZFRvU2lnbmVkVXJsKCdmb2xkZXIvY2F0LmpwZycsICd0b2tlbi1mcm9tLWNyZWF0ZVNpZ25lZFVwbG9hZFVybCcsIGZpbGUpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwicGF0aFwiOiBcImZvbGRlci9jYXQuanBnXCIsXG4gICAqICAgICBcImZ1bGxQYXRoXCI6IFwiYXZhdGFycy9mb2xkZXIvY2F0LmpwZ1wiXG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IG5vbmVcbiAgICogLSBSZWZlciB0byB0aGUgW1N0b3JhZ2UgZ3VpZGVdKC9kb2NzL2d1aWRlcy9zdG9yYWdlL3NlY3VyaXR5L2FjY2Vzcy1jb250cm9sKSBvbiBob3cgYWNjZXNzIGNvbnRyb2wgd29ya3NcbiAgICovXG4gIGFzeW5jIHVwbG9hZFRvU2lnbmVkVXJsKFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICB0b2tlbjogc3RyaW5nLFxuICAgIGZpbGVCb2R5OiBGaWxlQm9keSxcbiAgICBmaWxlT3B0aW9ucz86IEZpbGVPcHRpb25zXG4gICkge1xuICAgIGNvbnN0IGNsZWFuUGF0aCA9IHRoaXMuX3JlbW92ZUVtcHR5Rm9sZGVycyhwYXRoKVxuICAgIGNvbnN0IF9wYXRoID0gdGhpcy5fZ2V0RmluYWxQYXRoKGNsZWFuUGF0aClcblxuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwodGhpcy51cmwgKyBgL29iamVjdC91cGxvYWQvc2lnbi8ke19wYXRofWApXG4gICAgdXJsLnNlYXJjaFBhcmFtcy5zZXQoJ3Rva2VuJywgdG9rZW4pXG5cbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgbGV0IGJvZHlcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7IC4uLkRFRkFVTFRfRklMRV9PUFRJT05TLCAuLi5maWxlT3B0aW9ucyB9XG4gICAgICBsZXQgaGVhZGVyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICAgICAgLi4udGhpcy5oZWFkZXJzLFxuICAgICAgICAuLi57ICd4LXVwc2VydCc6IFN0cmluZyhvcHRpb25zLnVwc2VydCBhcyBib29sZWFuKSB9LFxuICAgICAgfVxuXG4gICAgICBjb25zdCBtZXRhZGF0YSA9IG9wdGlvbnMubWV0YWRhdGFcblxuICAgICAgaWYgKHR5cGVvZiBCbG9iICE9PSAndW5kZWZpbmVkJyAmJiBmaWxlQm9keSBpbnN0YW5jZW9mIEJsb2IpIHtcbiAgICAgICAgYm9keSA9IG5ldyBGb3JtRGF0YSgpXG4gICAgICAgIGJvZHkuYXBwZW5kKCdjYWNoZUNvbnRyb2wnLCBvcHRpb25zLmNhY2hlQ29udHJvbCBhcyBzdHJpbmcpXG4gICAgICAgIGlmIChtZXRhZGF0YSkge1xuICAgICAgICAgIGJvZHkuYXBwZW5kKCdtZXRhZGF0YScsIHRoaXMuZW5jb2RlTWV0YWRhdGEobWV0YWRhdGEpKVxuICAgICAgICB9XG4gICAgICAgIGJvZHkuYXBwZW5kKCcnLCBmaWxlQm9keSlcbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIEZvcm1EYXRhICE9PSAndW5kZWZpbmVkJyAmJiBmaWxlQm9keSBpbnN0YW5jZW9mIEZvcm1EYXRhKSB7XG4gICAgICAgIGJvZHkgPSBmaWxlQm9keVxuICAgICAgICBpZiAoIWJvZHkuaGFzKCdjYWNoZUNvbnRyb2wnKSkge1xuICAgICAgICAgIGJvZHkuYXBwZW5kKCdjYWNoZUNvbnRyb2wnLCBvcHRpb25zLmNhY2hlQ29udHJvbCBhcyBzdHJpbmcpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1ldGFkYXRhICYmICFib2R5LmhhcygnbWV0YWRhdGEnKSkge1xuICAgICAgICAgIGJvZHkuYXBwZW5kKCdtZXRhZGF0YScsIHRoaXMuZW5jb2RlTWV0YWRhdGEobWV0YWRhdGEpKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBib2R5ID0gZmlsZUJvZHlcbiAgICAgICAgaGVhZGVyc1snY2FjaGUtY29udHJvbCddID0gYG1heC1hZ2U9JHtvcHRpb25zLmNhY2hlQ29udHJvbH1gXG4gICAgICAgIGhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddID0gb3B0aW9ucy5jb250ZW50VHlwZSBhcyBzdHJpbmdcbiAgICAgICAgaWYgKG1ldGFkYXRhKSB7XG4gICAgICAgICAgaGVhZGVyc1sneC1tZXRhZGF0YSddID0gdGhpcy50b0Jhc2U2NCh0aGlzLmVuY29kZU1ldGFkYXRhKG1ldGFkYXRhKSlcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGlzU3RyZWFtID1cbiAgICAgICAgICAodHlwZW9mIFJlYWRhYmxlU3RyZWFtICE9PSAndW5kZWZpbmVkJyAmJiBib2R5IGluc3RhbmNlb2YgUmVhZGFibGVTdHJlYW0pIHx8XG4gICAgICAgICAgKGJvZHkgJiYgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmICdwaXBlJyBpbiBib2R5ICYmIHR5cGVvZiBib2R5LnBpcGUgPT09ICdmdW5jdGlvbicpXG5cbiAgICAgICAgaWYgKGlzU3RyZWFtICYmICFvcHRpb25zLmR1cGxleCkge1xuICAgICAgICAgIG9wdGlvbnMuZHVwbGV4ID0gJ2hhbGYnXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGZpbGVPcHRpb25zPy5oZWFkZXJzKSB7XG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGZpbGVPcHRpb25zLmhlYWRlcnMpKSB7XG4gICAgICAgICAgaGVhZGVycyA9IHNldEhlYWRlcihoZWFkZXJzLCBrZXksIHZhbHVlKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwdXQodGhpcy5mZXRjaCwgdXJsLnRvU3RyaW5nKCksIGJvZHkgYXMgb2JqZWN0LCB7XG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIC4uLihvcHRpb25zPy5kdXBsZXggPyB7IGR1cGxleDogb3B0aW9ucy5kdXBsZXggfSA6IHt9KSxcbiAgICAgIH0pXG5cbiAgICAgIHJldHVybiB7IHBhdGg6IGNsZWFuUGF0aCwgZnVsbFBhdGg6IGRhdGEuS2V5IH1cbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBzaWduZWQgdXBsb2FkIFVSTC5cbiAgICogU2lnbmVkIHVwbG9hZCBVUkxzIGNhbiBiZSB1c2VkIHRvIHVwbG9hZCBmaWxlcyB0byB0aGUgYnVja2V0IHdpdGhvdXQgZnVydGhlciBhdXRoZW50aWNhdGlvbi5cbiAgICogVGhleSBhcmUgdmFsaWQgZm9yIDIgaG91cnMuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICogQHBhcmFtIHBhdGggVGhlIGZpbGUgcGF0aCwgaW5jbHVkaW5nIHRoZSBjdXJyZW50IGZpbGUgbmFtZS4gRm9yIGV4YW1wbGUgYGZvbGRlci9pbWFnZS5wbmdgLlxuICAgKiBAcGFyYW0gb3B0aW9ucy51cHNlcnQgSWYgc2V0IHRvIHRydWUsIGFsbG93cyB0aGUgZmlsZSB0byBiZSBvdmVyd3JpdHRlbiBpZiBpdCBhbHJlYWR5IGV4aXN0cy5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgc2lnbmVkIHVwbG9hZCBVUkwsIHRva2VuLCBhbmQgcGF0aCBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBDcmVhdGUgU2lnbmVkIFVwbG9hZCBVUkxcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAuY3JlYXRlU2lnbmVkVXBsb2FkVXJsKCdmb2xkZXIvY2F0LmpwZycpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwic2lnbmVkVXJsXCI6IFwiaHR0cHM6Ly9leGFtcGxlLnN1cGFiYXNlLmNvL3N0b3JhZ2UvdjEvb2JqZWN0L3VwbG9hZC9zaWduL2F2YXRhcnMvZm9sZGVyL2NhdC5qcGc/dG9rZW49PFRPS0VOPlwiLFxuICAgKiAgICAgXCJwYXRoXCI6IFwiZm9sZGVyL2NhdC5qcGdcIixcbiAgICogICAgIFwidG9rZW5cIjogXCI8VE9LRU4+XCJcbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFJMUyBwb2xpY3kgcGVybWlzc2lvbnMgcmVxdWlyZWQ6XG4gICAqICAgLSBgYnVja2V0c2AgdGFibGUgcGVybWlzc2lvbnM6IG5vbmVcbiAgICogICAtIGBvYmplY3RzYCB0YWJsZSBwZXJtaXNzaW9uczogYGluc2VydGBcbiAgICogLSBSZWZlciB0byB0aGUgW1N0b3JhZ2UgZ3VpZGVdKC9kb2NzL2d1aWRlcy9zdG9yYWdlL3NlY3VyaXR5L2FjY2Vzcy1jb250cm9sKSBvbiBob3cgYWNjZXNzIGNvbnRyb2wgd29ya3NcbiAgICovXG4gIGFzeW5jIGNyZWF0ZVNpZ25lZFVwbG9hZFVybChcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHsgdXBzZXJ0OiBib29sZWFuIH1cbiAgKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogeyBzaWduZWRVcmw6IHN0cmluZzsgdG9rZW46IHN0cmluZzsgcGF0aDogc3RyaW5nIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gICAgICB9XG4gID4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICBsZXQgX3BhdGggPSB0aGlzLl9nZXRGaW5hbFBhdGgocGF0aClcblxuICAgICAgY29uc3QgaGVhZGVycyA9IHsgLi4udGhpcy5oZWFkZXJzIH1cblxuICAgICAgaWYgKG9wdGlvbnM/LnVwc2VydCkge1xuICAgICAgICBoZWFkZXJzWyd4LXVwc2VydCddID0gJ3RydWUnXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb3N0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vb2JqZWN0L3VwbG9hZC9zaWduLyR7X3BhdGh9YCxcbiAgICAgICAge30sXG4gICAgICAgIHsgaGVhZGVycyB9XG4gICAgICApXG5cbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwodGhpcy51cmwgKyBkYXRhLnVybClcblxuICAgICAgY29uc3QgdG9rZW4gPSB1cmwuc2VhcmNoUGFyYW1zLmdldCgndG9rZW4nKVxuXG4gICAgICBpZiAoIXRva2VuKSB7XG4gICAgICAgIHRocm93IG5ldyBTdG9yYWdlRXJyb3IoJ05vIHRva2VuIHJldHVybmVkIGJ5IEFQSScpXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB7IHNpZ25lZFVybDogdXJsLnRvU3RyaW5nKCksIHBhdGgsIHRva2VuIH1cbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIFJlcGxhY2VzIGFuIGV4aXN0aW5nIGZpbGUgYXQgdGhlIHNwZWNpZmllZCBwYXRoIHdpdGggYSBuZXcgb25lLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBwYXRoIFRoZSByZWxhdGl2ZSBmaWxlIHBhdGguIFNob3VsZCBiZSBvZiB0aGUgZm9ybWF0IGBmb2xkZXIvc3ViZm9sZGVyL2ZpbGVuYW1lLnBuZ2AuIFRoZSBidWNrZXQgbXVzdCBhbHJlYWR5IGV4aXN0IGJlZm9yZSBhdHRlbXB0aW5nIHRvIHVwZGF0ZS5cbiAgICogQHBhcmFtIGZpbGVCb2R5IFRoZSBib2R5IG9mIHRoZSBmaWxlIHRvIGJlIHN0b3JlZCBpbiB0aGUgYnVja2V0LlxuICAgKiBAcGFyYW0gZmlsZU9wdGlvbnMgT3B0aW9uYWwgZmlsZSB1cGxvYWQgb3B0aW9ucyBpbmNsdWRpbmcgY2FjaGVDb250cm9sLCBjb250ZW50VHlwZSwgYW5kIG1ldGFkYXRhLlxuICAgKiAqKk5vdGU6KiogVGhlIGB1cHNlcnRgIG9wdGlvbiBoYXMgbm8gZWZmZWN0IGhlcmUuIGB1cGRhdGUoKWAgYWx3YXlzIHJlcGxhY2VzIHRoZVxuICAgKiBmaWxlIGF0IHRoZSBnaXZlbiBwYXRoLCBzbyB0aGUgYHgtdXBzZXJ0YCBoZWFkZXIgaXMgbm90IHNlbnQuIFRvIGNvbnRyb2wgdXBzZXJ0XG4gICAqIGJlaGF2aW9yLCB1c2UgYHVwbG9hZCgpYCBpbnN0ZWFkLlxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcmVzcG9uc2UgY29udGFpbmluZyBmaWxlIHBhdGgsIGlkLCBhbmQgZnVsbFBhdGggb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgVXBkYXRlIGZpbGVcbiAgICogYGBganNcbiAgICogY29uc3QgYXZhdGFyRmlsZSA9IGV2ZW50LnRhcmdldC5maWxlc1swXVxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC51cGRhdGUoJ3B1YmxpYy9hdmF0YXIxLnBuZycsIGF2YXRhckZpbGUsIHtcbiAgICogICAgIGNhY2hlQ29udHJvbDogJzM2MDAnXG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIFJlc3BvbnNlOlxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJwYXRoXCI6IFwicHVibGljL2F2YXRhcjEucG5nXCIsXG4gICAqICAgICBcImZ1bGxQYXRoXCI6IFwiYXZhdGFycy9wdWJsaWMvYXZhdGFyMS5wbmdcIlxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFVwZGF0ZSBmaWxlIHVzaW5nIGBBcnJheUJ1ZmZlcmAgZnJvbSBiYXNlNjQgZmlsZSBkYXRhXG4gICAqIGBgYGpzXG4gICAqIGltcG9ydCB7ZGVjb2RlfSBmcm9tICdiYXNlNjQtYXJyYXlidWZmZXInXG4gICAqXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLnN0b3JhZ2VcbiAgICogICAuZnJvbSgnYXZhdGFycycpXG4gICAqICAgLnVwZGF0ZSgncHVibGljL2F2YXRhcjEucG5nJywgZGVjb2RlKCdiYXNlNjRGaWxlRGF0YScpLCB7XG4gICAqICAgICBjb250ZW50VHlwZTogJ2ltYWdlL3BuZydcbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IGB1cGRhdGVgIGFuZCBgc2VsZWN0YFxuICAgKiAtIGB1cGRhdGUoKWAgYWx3YXlzIHJlcGxhY2VzIHRoZSBmaWxlIGF0IHRoZSBnaXZlbiBwYXRoIHJlZ2FyZGxlc3Mgb2YgdGhlIGB1cHNlcnRgIG9wdGlvbi5cbiAgICogLSBSZWZlciB0byB0aGUgW1N0b3JhZ2UgZ3VpZGVdKC9kb2NzL2d1aWRlcy9zdG9yYWdlL3NlY3VyaXR5L2FjY2Vzcy1jb250cm9sKSBvbiBob3cgYWNjZXNzIGNvbnRyb2wgd29ya3NcbiAgICogLSBGb3IgUmVhY3QgTmF0aXZlLCB1c2luZyBlaXRoZXIgYEJsb2JgLCBgRmlsZWAgb3IgYEZvcm1EYXRhYCBkb2VzIG5vdCB3b3JrIGFzIGludGVuZGVkLiBVcGRhdGUgZmlsZSB1c2luZyBgQXJyYXlCdWZmZXJgIGZyb20gYmFzZTY0IGZpbGUgZGF0YSBpbnN0ZWFkLCBzZWUgZXhhbXBsZSBiZWxvdy5cbiAgICovXG4gIGFzeW5jIHVwZGF0ZShcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgZmlsZUJvZHk6XG4gICAgICB8IEFycmF5QnVmZmVyXG4gICAgICB8IEFycmF5QnVmZmVyVmlld1xuICAgICAgfCBCbG9iXG4gICAgICB8IEJ1ZmZlclxuICAgICAgfCBGaWxlXG4gICAgICB8IEZvcm1EYXRhXG4gICAgICB8IE5vZGVKUy5SZWFkYWJsZVN0cmVhbVxuICAgICAgfCBSZWFkYWJsZVN0cmVhbTxVaW50OEFycmF5PlxuICAgICAgfCBVUkxTZWFyY2hQYXJhbXNcbiAgICAgIHwgc3RyaW5nLFxuICAgIGZpbGVPcHRpb25zPzogRmlsZU9wdGlvbnNcbiAgKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogeyBpZDogc3RyaW5nOyBwYXRoOiBzdHJpbmc7IGZ1bGxQYXRoOiBzdHJpbmcgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMudXBsb2FkT3JVcGRhdGUoJ1BVVCcsIHBhdGgsIGZpbGVCb2R5LCBmaWxlT3B0aW9ucylcbiAgfVxuXG4gIC8qKlxuICAgKiBNb3ZlcyBhbiBleGlzdGluZyBmaWxlIHRvIGEgbmV3IHBhdGggaW4gdGhlIHNhbWUgYnVja2V0LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBmcm9tUGF0aCBUaGUgb3JpZ2luYWwgZmlsZSBwYXRoLCBpbmNsdWRpbmcgdGhlIGN1cnJlbnQgZmlsZSBuYW1lLiBGb3IgZXhhbXBsZSBgZm9sZGVyL2ltYWdlLnBuZ2AuXG4gICAqIEBwYXJhbSB0b1BhdGggVGhlIG5ldyBmaWxlIHBhdGgsIGluY2x1ZGluZyB0aGUgbmV3IGZpbGUgbmFtZS4gRm9yIGV4YW1wbGUgYGZvbGRlci9pbWFnZS1uZXcucG5nYC5cbiAgICogQHBhcmFtIG9wdGlvbnMgVGhlIGRlc3RpbmF0aW9uIG9wdGlvbnMuXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIHN1Y2Nlc3MgbWVzc2FnZSBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBNb3ZlIGZpbGVcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAubW92ZSgncHVibGljL2F2YXRhcjEucG5nJywgJ3ByaXZhdGUvYXZhdGFyMi5wbmcnKVxuICAgKiBgYGBcbiAgICpcbiAgICogUmVzcG9uc2U6XG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcIm1lc3NhZ2VcIjogXCJTdWNjZXNzZnVsbHkgbW92ZWRcIlxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUkxTIHBvbGljeSBwZXJtaXNzaW9ucyByZXF1aXJlZDpcbiAgICogICAtIGBidWNrZXRzYCB0YWJsZSBwZXJtaXNzaW9uczogbm9uZVxuICAgKiAgIC0gYG9iamVjdHNgIHRhYmxlIHBlcm1pc3Npb25zOiBgdXBkYXRlYCBhbmQgYHNlbGVjdGBcbiAgICogLSBSZWZlciB0byB0aGUgW1N0b3JhZ2UgZ3VpZGVdKC9kb2NzL2d1aWRlcy9zdG9yYWdlL3NlY3VyaXR5L2FjY2Vzcy1jb250cm9sKSBvbiBob3cgYWNjZXNzIGNvbnRyb2wgd29ya3NcbiAgICovXG4gIGFzeW5jIG1vdmUoXG4gICAgZnJvbVBhdGg6IHN0cmluZyxcbiAgICB0b1BhdGg6IHN0cmluZyxcbiAgICBvcHRpb25zPzogRGVzdGluYXRpb25PcHRpb25zXG4gICk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHsgbWVzc2FnZTogc3RyaW5nIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gICAgICB9XG4gID4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gYXdhaXQgcG9zdChcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgYCR7dGhpcy51cmx9L29iamVjdC9tb3ZlYCxcbiAgICAgICAge1xuICAgICAgICAgIGJ1Y2tldElkOiB0aGlzLmJ1Y2tldElkLFxuICAgICAgICAgIHNvdXJjZUtleTogZnJvbVBhdGgsXG4gICAgICAgICAgZGVzdGluYXRpb25LZXk6IHRvUGF0aCxcbiAgICAgICAgICBkZXN0aW5hdGlvbkJ1Y2tldDogb3B0aW9ucz8uZGVzdGluYXRpb25CdWNrZXQsXG4gICAgICAgIH0sXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH1cbiAgICAgIClcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIENvcGllcyBhbiBleGlzdGluZyBmaWxlIHRvIGEgbmV3IHBhdGggaW4gdGhlIHNhbWUgYnVja2V0LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBmcm9tUGF0aCBUaGUgb3JpZ2luYWwgZmlsZSBwYXRoLCBpbmNsdWRpbmcgdGhlIGN1cnJlbnQgZmlsZSBuYW1lLiBGb3IgZXhhbXBsZSBgZm9sZGVyL2ltYWdlLnBuZ2AuXG4gICAqIEBwYXJhbSB0b1BhdGggVGhlIG5ldyBmaWxlIHBhdGgsIGluY2x1ZGluZyB0aGUgbmV3IGZpbGUgbmFtZS4gRm9yIGV4YW1wbGUgYGZvbGRlci9pbWFnZS1jb3B5LnBuZ2AuXG4gICAqIEBwYXJhbSBvcHRpb25zIFRoZSBkZXN0aW5hdGlvbiBvcHRpb25zLlxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcmVzcG9uc2UgY29udGFpbmluZyBjb3BpZWQgZmlsZSBwYXRoIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIENvcHkgZmlsZVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5jb3B5KCdwdWJsaWMvYXZhdGFyMS5wbmcnLCAncHJpdmF0ZS9hdmF0YXIyLnBuZycpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwicGF0aFwiOiBcImF2YXRhcnMvcHJpdmF0ZS9hdmF0YXIyLnBuZ1wiXG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IGBpbnNlcnRgIGFuZCBgc2VsZWN0YFxuICAgKiAtIFJlZmVyIHRvIHRoZSBbU3RvcmFnZSBndWlkZV0oL2RvY3MvZ3VpZGVzL3N0b3JhZ2Uvc2VjdXJpdHkvYWNjZXNzLWNvbnRyb2wpIG9uIGhvdyBhY2Nlc3MgY29udHJvbCB3b3Jrc1xuICAgKi9cbiAgYXN5bmMgY29weShcbiAgICBmcm9tUGF0aDogc3RyaW5nLFxuICAgIHRvUGF0aDogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiBEZXN0aW5hdGlvbk9wdGlvbnNcbiAgKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogeyBwYXRoOiBzdHJpbmcgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb3N0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vb2JqZWN0L2NvcHlgLFxuICAgICAgICB7XG4gICAgICAgICAgYnVja2V0SWQ6IHRoaXMuYnVja2V0SWQsXG4gICAgICAgICAgc291cmNlS2V5OiBmcm9tUGF0aCxcbiAgICAgICAgICBkZXN0aW5hdGlvbktleTogdG9QYXRoLFxuICAgICAgICAgIGRlc3RpbmF0aW9uQnVja2V0OiBvcHRpb25zPy5kZXN0aW5hdGlvbkJ1Y2tldCxcbiAgICAgICAgfSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgICAgcmV0dXJuIHsgcGF0aDogZGF0YS5LZXkgfVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIHNpZ25lZCBVUkwuIFVzZSBhIHNpZ25lZCBVUkwgdG8gc2hhcmUgYSBmaWxlIGZvciBhIGZpeGVkIGFtb3VudCBvZiB0aW1lLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBwYXRoIFRoZSBmaWxlIHBhdGgsIGluY2x1ZGluZyB0aGUgY3VycmVudCBmaWxlIG5hbWUuIEZvciBleGFtcGxlIGBmb2xkZXIvaW1hZ2UucG5nYC5cbiAgICogQHBhcmFtIGV4cGlyZXNJbiBUaGUgbnVtYmVyIG9mIHNlY29uZHMgdW50aWwgdGhlIHNpZ25lZCBVUkwgZXhwaXJlcy4gRm9yIGV4YW1wbGUsIGA2MGAgZm9yIGEgVVJMIHdoaWNoIGlzIHZhbGlkIGZvciBvbmUgbWludXRlLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5kb3dubG9hZCB0cmlnZ2VycyB0aGUgZmlsZSBhcyBhIGRvd25sb2FkIGlmIHNldCB0byB0cnVlLiBTZXQgdGhpcyBwYXJhbWV0ZXIgYXMgdGhlIG5hbWUgb2YgdGhlIGZpbGUgaWYgeW91IHdhbnQgdG8gdHJpZ2dlciB0aGUgZG93bmxvYWQgd2l0aCBhIGRpZmZlcmVudCBmaWxlbmFtZS5cbiAgICogQHBhcmFtIG9wdGlvbnMudHJhbnNmb3JtIFRyYW5zZm9ybSB0aGUgYXNzZXQgYmVmb3JlIHNlcnZpbmcgaXQgdG8gdGhlIGNsaWVudC5cbiAgICogQHBhcmFtIG9wdGlvbnMuY2FjaGVOb25jZSBBcHBlbmQgYSBjYWNoZSBub25jZSBwYXJhbWV0ZXIgdG8gdGhlIFVSTCB0byBpbnZhbGlkYXRlIHRoZSBjYWNoZS5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgc2lnbmVkIFVSTCBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBDcmVhdGUgU2lnbmVkIFVSTFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5jcmVhdGVTaWduZWRVcmwoJ2ZvbGRlci9hdmF0YXIxLnBuZycsIDYwKVxuICAgKiBgYGBcbiAgICpcbiAgICogUmVzcG9uc2U6XG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcInNpZ25lZFVybFwiOiBcImh0dHBzOi8vZXhhbXBsZS5zdXBhYmFzZS5jby9zdG9yYWdlL3YxL29iamVjdC9zaWduL2F2YXRhcnMvZm9sZGVyL2F2YXRhcjEucG5nP3Rva2VuPTxUT0tFTj5cIlxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIENyZWF0ZSBhIHNpZ25lZCBVUkwgZm9yIGFuIGFzc2V0IHdpdGggdHJhbnNmb3JtYXRpb25zXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAuY3JlYXRlU2lnbmVkVXJsKCdmb2xkZXIvYXZhdGFyMS5wbmcnLCA2MCwge1xuICAgKiAgICAgdHJhbnNmb3JtOiB7XG4gICAqICAgICAgIHdpZHRoOiAxMDAsXG4gICAqICAgICAgIGhlaWdodDogMTAwLFxuICAgKiAgICAgfVxuICAgKiAgIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBDcmVhdGUgYSBzaWduZWQgVVJMIHdoaWNoIHRyaWdnZXJzIHRoZSBkb3dubG9hZCBvZiB0aGUgYXNzZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5jcmVhdGVTaWduZWRVcmwoJ2ZvbGRlci9hdmF0YXIxLnBuZycsIDYwLCB7XG4gICAqICAgICBkb3dubG9hZDogdHJ1ZSxcbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IGBzZWxlY3RgXG4gICAqIC0gUmVmZXIgdG8gdGhlIFtTdG9yYWdlIGd1aWRlXSgvZG9jcy9ndWlkZXMvc3RvcmFnZS9zZWN1cml0eS9hY2Nlc3MtY29udHJvbCkgb24gaG93IGFjY2VzcyBjb250cm9sIHdvcmtzXG4gICAqL1xuICBhc3luYyBjcmVhdGVTaWduZWRVcmwoXG4gICAgcGF0aDogc3RyaW5nLFxuICAgIGV4cGlyZXNJbjogbnVtYmVyLFxuICAgIG9wdGlvbnM/OiB7XG4gICAgICBkb3dubG9hZD86IHN0cmluZyB8IGJvb2xlYW5cbiAgICAgIHRyYW5zZm9ybT86IFRyYW5zZm9ybU9wdGlvbnNcbiAgICAgIGNhY2hlTm9uY2U/OiBzdHJpbmdcbiAgICB9XG4gICk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHsgc2lnbmVkVXJsOiBzdHJpbmcgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGxldCBfcGF0aCA9IHRoaXMuX2dldEZpbmFsUGF0aChwYXRoKVxuXG4gICAgICBjb25zdCBoYXNUcmFuc2Zvcm0gPVxuICAgICAgICB0eXBlb2Ygb3B0aW9ucz8udHJhbnNmb3JtID09PSAnb2JqZWN0JyAmJlxuICAgICAgICBvcHRpb25zLnRyYW5zZm9ybSAhPT0gbnVsbCAmJlxuICAgICAgICBPYmplY3Qua2V5cyhvcHRpb25zLnRyYW5zZm9ybSkubGVuZ3RoID4gMFxuXG4gICAgICBsZXQgZGF0YSA9IGF3YWl0IHBvc3QoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgIGAke3RoaXMudXJsfS9vYmplY3Qvc2lnbi8ke19wYXRofWAsXG4gICAgICAgIHsgZXhwaXJlc0luLCAuLi4oaGFzVHJhbnNmb3JtID8geyB0cmFuc2Zvcm06IG9wdGlvbnMhLnRyYW5zZm9ybSB9IDoge30pIH0sXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH1cbiAgICAgIClcblxuICAgICAgY29uc3QgcXVlcnkgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKClcbiAgICAgIGlmIChvcHRpb25zPy5kb3dubG9hZClcbiAgICAgICAgcXVlcnkuc2V0KCdkb3dubG9hZCcsIG9wdGlvbnMuZG93bmxvYWQgPT09IHRydWUgPyAnJyA6IG9wdGlvbnMuZG93bmxvYWQpXG4gICAgICBpZiAob3B0aW9ucz8uY2FjaGVOb25jZSAhPSBudWxsKSBxdWVyeS5zZXQoJ2NhY2hlTm9uY2UnLCBTdHJpbmcob3B0aW9ucy5jYWNoZU5vbmNlKSlcbiAgICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gcXVlcnkudG9TdHJpbmcoKVxuXG4gICAgICAvLyBgZGF0YS5zaWduZWRVUkxgIGNvbnRhaW5zIGEgYHRva2VuYCBxdWVyeSBwYXJhbWV0ZXIsIHNvIGFwcGVuZCBleHRyYSBwYXJhbXMgd2l0aCBgJmBcbiAgICAgIC8vIG9ubHkgd2hlbiB3ZSBhY3R1YWxseSBoYXZlIHNvbWV0aGluZyB0byBhZGQuXG4gICAgICBjb25zdCBzaWduZWRVcmwgPSBlbmNvZGVVUkkoXG4gICAgICAgIGAke3RoaXMudXJsfSR7ZGF0YS5zaWduZWRVUkx9JHtxdWVyeVN0cmluZyA/IGAmJHtxdWVyeVN0cmluZ31gIDogJyd9YFxuICAgICAgKVxuXG4gICAgICByZXR1cm4geyBzaWduZWRVcmwgfVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBtdWx0aXBsZSBzaWduZWQgVVJMcy4gVXNlIGEgc2lnbmVkIFVSTCB0byBzaGFyZSBhIGZpbGUgZm9yIGEgZml4ZWQgYW1vdW50IG9mIHRpbWUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICogQHBhcmFtIHBhdGhzIFRoZSBmaWxlIHBhdGhzIHRvIGJlIGRvd25sb2FkZWQsIGluY2x1ZGluZyB0aGUgY3VycmVudCBmaWxlIG5hbWVzLiBGb3IgZXhhbXBsZSBgWydmb2xkZXIvaW1hZ2UucG5nJywgJ2ZvbGRlcjIvaW1hZ2UyLnBuZyddYC5cbiAgICogQHBhcmFtIGV4cGlyZXNJbiBUaGUgbnVtYmVyIG9mIHNlY29uZHMgdW50aWwgdGhlIHNpZ25lZCBVUkxzIGV4cGlyZS4gRm9yIGV4YW1wbGUsIGA2MGAgZm9yIFVSTHMgd2hpY2ggYXJlIHZhbGlkIGZvciBvbmUgbWludXRlLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5kb3dubG9hZCB0cmlnZ2VycyB0aGUgZmlsZSBhcyBhIGRvd25sb2FkIGlmIHNldCB0byB0cnVlLiBTZXQgdGhpcyBwYXJhbWV0ZXIgYXMgdGhlIG5hbWUgb2YgdGhlIGZpbGUgaWYgeW91IHdhbnQgdG8gdHJpZ2dlciB0aGUgZG93bmxvYWQgd2l0aCBhIGRpZmZlcmVudCBmaWxlbmFtZS5cbiAgICogQHBhcmFtIG9wdGlvbnMuY2FjaGVOb25jZSBBcHBlbmQgYSBjYWNoZSBub25jZSBwYXJhbWV0ZXIgdG8gdGhlIFVSTCB0byBpbnZhbGlkYXRlIHRoZSBjYWNoZS5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgYXJyYXkgb2Ygb2JqZWN0cyB3aXRoIHNpZ25lZFVybCwgcGF0aCwgYW5kIGVycm9yIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIENyZWF0ZSBTaWduZWQgVVJMc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5jcmVhdGVTaWduZWRVcmxzKFsnZm9sZGVyL2F2YXRhcjEucG5nJywgJ2ZvbGRlci9hdmF0YXIyLnBuZyddLCA2MClcbiAgICogYGBgXG4gICAqXG4gICAqIFJlc3BvbnNlOlxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcImVycm9yXCI6IG51bGwsXG4gICAqICAgICAgIFwicGF0aFwiOiBcImZvbGRlci9hdmF0YXIxLnBuZ1wiLFxuICAgKiAgICAgICBcInNpZ25lZFVSTFwiOiBcIi9vYmplY3Qvc2lnbi9hdmF0YXJzL2ZvbGRlci9hdmF0YXIxLnBuZz90b2tlbj08VE9LRU4+XCIsXG4gICAqICAgICAgIFwic2lnbmVkVXJsXCI6IFwiaHR0cHM6Ly9leGFtcGxlLnN1cGFiYXNlLmNvL3N0b3JhZ2UvdjEvb2JqZWN0L3NpZ24vYXZhdGFycy9mb2xkZXIvYXZhdGFyMS5wbmc/dG9rZW49PFRPS0VOPlwiXG4gICAqICAgICB9LFxuICAgKiAgICAge1xuICAgKiAgICAgICBcImVycm9yXCI6IG51bGwsXG4gICAqICAgICAgIFwicGF0aFwiOiBcImZvbGRlci9hdmF0YXIyLnBuZ1wiLFxuICAgKiAgICAgICBcInNpZ25lZFVSTFwiOiBcIi9vYmplY3Qvc2lnbi9hdmF0YXJzL2ZvbGRlci9hdmF0YXIyLnBuZz90b2tlbj08VE9LRU4+XCIsXG4gICAqICAgICAgIFwic2lnbmVkVXJsXCI6IFwiaHR0cHM6Ly9leGFtcGxlLnN1cGFiYXNlLmNvL3N0b3JhZ2UvdjEvb2JqZWN0L3NpZ24vYXZhdGFycy9mb2xkZXIvYXZhdGFyMi5wbmc/dG9rZW49PFRPS0VOPlwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IGBzZWxlY3RgXG4gICAqIC0gUmVmZXIgdG8gdGhlIFtTdG9yYWdlIGd1aWRlXSgvZG9jcy9ndWlkZXMvc3RvcmFnZS9zZWN1cml0eS9hY2Nlc3MtY29udHJvbCkgb24gaG93IGFjY2VzcyBjb250cm9sIHdvcmtzXG4gICAqL1xuICBhc3luYyBjcmVhdGVTaWduZWRVcmxzKFxuICAgIHBhdGhzOiBzdHJpbmdbXSxcbiAgICBleHBpcmVzSW46IG51bWJlcixcbiAgICBvcHRpb25zPzogeyBkb3dubG9hZD86IHN0cmluZyB8IGJvb2xlYW47IGNhY2hlTm9uY2U/OiBzdHJpbmcgfVxuICApOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiB7IGVycm9yOiBzdHJpbmcgfCBudWxsOyBwYXRoOiBzdHJpbmcgfCBudWxsOyBzaWduZWRVcmw6IHN0cmluZyB8IG51bGwgfVtdXG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgICB9XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IG51bGxcbiAgICAgICAgZXJyb3I6IFN0b3JhZ2VFcnJvclxuICAgICAgfVxuICA+IHtcbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgIGAke3RoaXMudXJsfS9vYmplY3Qvc2lnbi8ke3RoaXMuYnVja2V0SWR9YCxcbiAgICAgICAgeyBleHBpcmVzSW4sIHBhdGhzIH0sXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH1cbiAgICAgIClcblxuICAgICAgY29uc3QgcXVlcnkgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKClcblxuICAgICAgaWYgKG9wdGlvbnM/LmRvd25sb2FkKVxuICAgICAgICBxdWVyeS5zZXQoJ2Rvd25sb2FkJywgb3B0aW9ucy5kb3dubG9hZCA9PT0gdHJ1ZSA/ICcnIDogb3B0aW9ucy5kb3dubG9hZClcbiAgICAgIGlmIChvcHRpb25zPy5jYWNoZU5vbmNlICE9IG51bGwpIHF1ZXJ5LnNldCgnY2FjaGVOb25jZScsIFN0cmluZyhvcHRpb25zLmNhY2hlTm9uY2UpKVxuXG4gICAgICBjb25zdCBxdWVyeVN0cmluZyA9IHF1ZXJ5LnRvU3RyaW5nKClcblxuICAgICAgcmV0dXJuIGRhdGEubWFwKChkYXR1bTogeyBzaWduZWRVUkw6IHN0cmluZyB9KSA9PiAoe1xuICAgICAgICAuLi5kYXR1bSxcbiAgICAgICAgc2lnbmVkVXJsOiBkYXR1bS5zaWduZWRVUkxcbiAgICAgICAgICA/IGVuY29kZVVSSShgJHt0aGlzLnVybH0ke2RhdHVtLnNpZ25lZFVSTH0ke3F1ZXJ5U3RyaW5nID8gYCYke3F1ZXJ5U3RyaW5nfWAgOiAnJ31gKVxuICAgICAgICAgIDogbnVsbCxcbiAgICAgIH0pKVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogRG93bmxvYWRzIGEgZmlsZSBmcm9tIGEgcHJpdmF0ZSBidWNrZXQuIEZvciBwdWJsaWMgYnVja2V0cywgbWFrZSBhIHJlcXVlc3QgdG8gdGhlIFVSTCByZXR1cm5lZCBmcm9tIGBnZXRQdWJsaWNVcmxgIGluc3RlYWQuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICogQHBhcmFtIHBhdGggVGhlIGZ1bGwgcGF0aCBhbmQgZmlsZSBuYW1lIG9mIHRoZSBmaWxlIHRvIGJlIGRvd25sb2FkZWQuIEZvciBleGFtcGxlIGBmb2xkZXIvaW1hZ2UucG5nYC5cbiAgICogQHBhcmFtIG9wdGlvbnMudHJhbnNmb3JtIFRyYW5zZm9ybSB0aGUgYXNzZXQgYmVmb3JlIHNlcnZpbmcgaXQgdG8gdGhlIGNsaWVudC5cbiAgICogQHBhcmFtIG9wdGlvbnMuY2FjaGVOb25jZSBBcHBlbmQgYSBjYWNoZSBub25jZSBwYXJhbWV0ZXIgdG8gdGhlIFVSTCB0byBpbnZhbGlkYXRlIHRoZSBjYWNoZS5cbiAgICogQHBhcmFtIHBhcmFtZXRlcnMgQWRkaXRpb25hbCBmZXRjaCBwYXJhbWV0ZXJzIGxpa2Ugc2lnbmFsIGZvciBjYW5jZWxsYXRpb24uIFN1cHBvcnRzIHN0YW5kYXJkIGZldGNoIG9wdGlvbnMgaW5jbHVkaW5nIGNhY2hlIGNvbnRyb2wuXG4gICAqIEByZXR1cm5zIEJsb2JEb3dubG9hZEJ1aWxkZXIgaW5zdGFuY2UgZm9yIGRvd25sb2FkaW5nIHRoZSBmaWxlXG4gICAqXG4gICAqIEBleGFtcGxlIERvd25sb2FkIGZpbGVcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAuZG93bmxvYWQoJ2ZvbGRlci9hdmF0YXIxLnBuZycpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IDxCTE9CPixcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgRG93bmxvYWQgZmlsZSB3aXRoIHRyYW5zZm9ybWF0aW9uc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5kb3dubG9hZCgnZm9sZGVyL2F2YXRhcjEucG5nJywge1xuICAgKiAgICAgdHJhbnNmb3JtOiB7XG4gICAqICAgICAgIHdpZHRoOiAxMDAsXG4gICAqICAgICAgIGhlaWdodDogMTAwLFxuICAgKiAgICAgICBxdWFsaXR5OiA4MFxuICAgKiAgICAgfVxuICAgKiAgIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBEb3dubG9hZCB3aXRoIGNhY2hlIGNvbnRyb2wgKHVzZWZ1bCBpbiBFZGdlIEZ1bmN0aW9ucylcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAuZG93bmxvYWQoJ2ZvbGRlci9hdmF0YXIxLnBuZycsIHt9LCB7IGNhY2hlOiAnbm8tc3RvcmUnIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBEb3dubG9hZCB3aXRoIGFib3J0IHNpZ25hbFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXG4gICAqIHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCA1MDAwKVxuICAgKlxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5kb3dubG9hZCgnZm9sZGVyL2F2YXRhcjEucG5nJywge30sIHsgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IGBzZWxlY3RgXG4gICAqIC0gUmVmZXIgdG8gdGhlIFtTdG9yYWdlIGd1aWRlXSgvZG9jcy9ndWlkZXMvc3RvcmFnZS9zZWN1cml0eS9hY2Nlc3MtY29udHJvbCkgb24gaG93IGFjY2VzcyBjb250cm9sIHdvcmtzXG4gICAqL1xuICBkb3dubG9hZDxPcHRpb25zIGV4dGVuZHMgeyB0cmFuc2Zvcm0/OiBUcmFuc2Zvcm1PcHRpb25zOyBjYWNoZU5vbmNlPzogc3RyaW5nIH0+KFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBvcHRpb25zPzogT3B0aW9ucyxcbiAgICBwYXJhbWV0ZXJzPzogRmV0Y2hQYXJhbWV0ZXJzXG4gICk6IEJsb2JEb3dubG9hZEJ1aWxkZXIge1xuICAgIGNvbnN0IHdhbnRzVHJhbnNmb3JtYXRpb24gPVxuICAgICAgdHlwZW9mIG9wdGlvbnM/LnRyYW5zZm9ybSA9PT0gJ29iamVjdCcgJiZcbiAgICAgIG9wdGlvbnMudHJhbnNmb3JtICE9PSBudWxsICYmXG4gICAgICBPYmplY3Qua2V5cyhvcHRpb25zLnRyYW5zZm9ybSkubGVuZ3RoID4gMFxuICAgIGNvbnN0IHJlbmRlclBhdGggPSB3YW50c1RyYW5zZm9ybWF0aW9uID8gJ3JlbmRlci9pbWFnZS9hdXRoZW50aWNhdGVkJyA6ICdvYmplY3QnXG5cbiAgICBjb25zdCBxdWVyeSA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKVxuICAgIGlmIChvcHRpb25zPy50cmFuc2Zvcm0pIHRoaXMuYXBwbHlUcmFuc2Zvcm1PcHRzVG9RdWVyeShxdWVyeSwgb3B0aW9ucy50cmFuc2Zvcm0pXG4gICAgaWYgKG9wdGlvbnM/LmNhY2hlTm9uY2UgIT0gbnVsbCkgcXVlcnkuc2V0KCdjYWNoZU5vbmNlJywgU3RyaW5nKG9wdGlvbnMuY2FjaGVOb25jZSkpXG4gICAgY29uc3QgcXVlcnlTdHJpbmcgPSBxdWVyeS50b1N0cmluZygpXG5cbiAgICBjb25zdCBfcGF0aCA9IHRoaXMuX2dldEZpbmFsUGF0aChwYXRoKVxuICAgIGNvbnN0IGRvd25sb2FkRm4gPSAoKSA9PlxuICAgICAgZ2V0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vJHtyZW5kZXJQYXRofS8ke19wYXRofSR7cXVlcnlTdHJpbmcgPyBgPyR7cXVlcnlTdHJpbmd9YCA6ICcnfWAsXG4gICAgICAgIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgbm9SZXNvbHZlSnNvbjogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgcGFyYW1ldGVyc1xuICAgICAgKVxuICAgIHJldHVybiBuZXcgQmxvYkRvd25sb2FkQnVpbGRlcihkb3dubG9hZEZuLCB0aGlzLnNob3VsZFRocm93T25FcnJvcilcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgdGhlIGRldGFpbHMgb2YgYW4gZXhpc3RpbmcgZmlsZS5cbiAgICpcbiAgICogUmV0dXJucyBkZXRhaWxlZCBmaWxlIG1ldGFkYXRhIGluY2x1ZGluZyBzaXplLCBjb250ZW50IHR5cGUsIGFuZCB0aW1lc3RhbXBzLlxuICAgKiBOb3RlOiBUaGUgQVBJIHJldHVybnMgYGxhc3RfbW9kaWZpZWRgIGZpZWxkLCBub3QgYHVwZGF0ZWRfYXRgLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBwYXRoIFRoZSBmaWxlIHBhdGgsIGluY2x1ZGluZyB0aGUgZmlsZSBuYW1lLiBGb3IgZXhhbXBsZSBgZm9sZGVyL2ltYWdlLnBuZ2AuXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIGZpbGUgbWV0YWRhdGEgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgR2V0IGZpbGUgaW5mb1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5pbmZvKCdmb2xkZXIvYXZhdGFyMS5wbmcnKVxuICAgKlxuICAgKiBpZiAoZGF0YSkge1xuICAgKiAgIGNvbnNvbGUubG9nKCdMYXN0IG1vZGlmaWVkOicsIGRhdGEubGFzdE1vZGlmaWVkKVxuICAgKiAgIGNvbnNvbGUubG9nKCdTaXplOicsIGRhdGEuc2l6ZSlcbiAgICogfVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGluZm8ocGF0aDogc3RyaW5nKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogQ2FtZWxpemU8RmlsZU9iamVjdFYyPlxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgY29uc3QgX3BhdGggPSB0aGlzLl9nZXRGaW5hbFBhdGgocGF0aClcblxuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0KHRoaXMuZmV0Y2gsIGAke3RoaXMudXJsfS9vYmplY3QvaW5mby8ke19wYXRofWAsIHtcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgfSlcblxuICAgICAgcmV0dXJuIHJlY3Vyc2l2ZVRvQ2FtZWwoZGF0YSkgYXMgQ2FtZWxpemU8RmlsZU9iamVjdFYyPlxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIHRoZSBleGlzdGVuY2Ugb2YgYSBmaWxlLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBwYXRoIFRoZSBmaWxlIHBhdGgsIGluY2x1ZGluZyB0aGUgZmlsZSBuYW1lLiBGb3IgZXhhbXBsZSBgZm9sZGVyL2ltYWdlLnBuZ2AuXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIGJvb2xlYW4gaW5kaWNhdGluZyBmaWxlIGV4aXN0ZW5jZSBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBDaGVjayBmaWxlIGV4aXN0ZW5jZVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5leGlzdHMoJ2ZvbGRlci9hdmF0YXIxLnBuZycpXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgZXhpc3RzKHBhdGg6IHN0cmluZyk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IGJvb2xlYW5cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YTogYm9vbGVhblxuICAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gICAgICB9XG4gID4ge1xuICAgIGNvbnN0IF9wYXRoID0gdGhpcy5fZ2V0RmluYWxQYXRoKHBhdGgpXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgaGVhZCh0aGlzLmZldGNoLCBgJHt0aGlzLnVybH0vb2JqZWN0LyR7X3BhdGh9YCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICB9KVxuXG4gICAgICByZXR1cm4geyBkYXRhOiB0cnVlLCBlcnJvcjogbnVsbCB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmICh0aGlzLnNob3VsZFRocm93T25FcnJvcikge1xuICAgICAgICB0aHJvdyBlcnJvclxuICAgICAgfVxuICAgICAgaWYgKGlzU3RvcmFnZUVycm9yKGVycm9yKSkge1xuICAgICAgICAvLyBIRUFEIHJlcXVlc3RzIHByb2R1Y2UgU3RvcmFnZUFwaUVycm9yICh2aWEgaGFuZGxlRXJyb3IpIG9yIFN0b3JhZ2VVbmtub3duRXJyb3IgKGxlZ2FjeSlcbiAgICAgICAgY29uc3Qgc3RhdHVzID1cbiAgICAgICAgICBlcnJvciBpbnN0YW5jZW9mIFN0b3JhZ2VBcGlFcnJvclxuICAgICAgICAgICAgPyBlcnJvci5zdGF0dXNcbiAgICAgICAgICAgIDogZXJyb3IgaW5zdGFuY2VvZiBTdG9yYWdlVW5rbm93bkVycm9yXG4gICAgICAgICAgICAgID8gKGVycm9yLm9yaWdpbmFsRXJyb3IgYXMgeyBzdGF0dXM6IG51bWJlciB9KT8uc3RhdHVzXG4gICAgICAgICAgICAgIDogdW5kZWZpbmVkXG5cbiAgICAgICAgaWYgKHN0YXR1cyAhPT0gdW5kZWZpbmVkICYmIFs0MDAsIDQwNF0uaW5jbHVkZXMoc3RhdHVzKSkge1xuICAgICAgICAgIHJldHVybiB7IGRhdGE6IGZhbHNlLCBlcnJvciB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQSBzaW1wbGUgY29udmVuaWVuY2UgZnVuY3Rpb24gdG8gZ2V0IHRoZSBVUkwgZm9yIGFuIGFzc2V0IGluIGEgcHVibGljIGJ1Y2tldC4gSWYgeW91IGRvIG5vdCB3YW50IHRvIHVzZSB0aGlzIGZ1bmN0aW9uLCB5b3UgY2FuIGNvbnN0cnVjdCB0aGUgcHVibGljIFVSTCBieSBjb25jYXRlbmF0aW5nIHRoZSBidWNrZXQgVVJMIHdpdGggdGhlIHBhdGggdG8gdGhlIGFzc2V0LlxuICAgKiBUaGlzIGZ1bmN0aW9uIGRvZXMgbm90IHZlcmlmeSBpZiB0aGUgYnVja2V0IGlzIHB1YmxpYy4gSWYgYSBwdWJsaWMgVVJMIGlzIGNyZWF0ZWQgZm9yIGEgYnVja2V0IHdoaWNoIGlzIG5vdCBwdWJsaWMsIHlvdSB3aWxsIG5vdCBiZSBhYmxlIHRvIGRvd25sb2FkIHRoZSBhc3NldC5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEZpbGUgQnVja2V0c1xuICAgKiBAcGFyYW0gcGF0aCBUaGUgcGF0aCBhbmQgbmFtZSBvZiB0aGUgZmlsZSB0byBnZW5lcmF0ZSB0aGUgcHVibGljIFVSTCBmb3IuIEZvciBleGFtcGxlIGBmb2xkZXIvaW1hZ2UucG5nYC5cbiAgICogQHBhcmFtIG9wdGlvbnMuZG93bmxvYWQgVHJpZ2dlcnMgdGhlIGZpbGUgYXMgYSBkb3dubG9hZCBpZiBzZXQgdG8gdHJ1ZS4gU2V0IHRoaXMgcGFyYW1ldGVyIGFzIHRoZSBuYW1lIG9mIHRoZSBmaWxlIGlmIHlvdSB3YW50IHRvIHRyaWdnZXIgdGhlIGRvd25sb2FkIHdpdGggYSBkaWZmZXJlbnQgZmlsZW5hbWUuXG4gICAqIEBwYXJhbSBvcHRpb25zLnRyYW5zZm9ybSBUcmFuc2Zvcm0gdGhlIGFzc2V0IGJlZm9yZSBzZXJ2aW5nIGl0IHRvIHRoZSBjbGllbnQuXG4gICAqIEBwYXJhbSBvcHRpb25zLmNhY2hlTm9uY2UgQXBwZW5kIGEgY2FjaGUgbm9uY2UgcGFyYW1ldGVyIHRvIHRoZSBVUkwgdG8gaW52YWxpZGF0ZSB0aGUgY2FjaGUuXG4gICAqIEByZXR1cm5zIE9iamVjdCB3aXRoIHB1YmxpYyBVUkxcbiAgICpcbiAgICogQGV4YW1wbGUgUmV0dXJucyB0aGUgVVJMIGZvciBhbiBhc3NldCBpbiBhIHB1YmxpYyBidWNrZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhIH0gPSBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ3B1YmxpYy1idWNrZXQnKVxuICAgKiAgIC5nZXRQdWJsaWNVcmwoJ2ZvbGRlci9hdmF0YXIxLnBuZycpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwicHVibGljVXJsXCI6IFwiaHR0cHM6Ly9leGFtcGxlLnN1cGFiYXNlLmNvL3N0b3JhZ2UvdjEvb2JqZWN0L3B1YmxpYy9wdWJsaWMtYnVja2V0L2ZvbGRlci9hdmF0YXIxLnBuZ1wiXG4gICAqICAgfVxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBSZXR1cm5zIHRoZSBVUkwgZm9yIGFuIGFzc2V0IGluIGEgcHVibGljIGJ1Y2tldCB3aXRoIHRyYW5zZm9ybWF0aW9uc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEgfSA9IHN1cGFiYXNlXG4gICAqICAgLnN0b3JhZ2VcbiAgICogICAuZnJvbSgncHVibGljLWJ1Y2tldCcpXG4gICAqICAgLmdldFB1YmxpY1VybCgnZm9sZGVyL2F2YXRhcjEucG5nJywge1xuICAgKiAgICAgdHJhbnNmb3JtOiB7XG4gICAqICAgICAgIHdpZHRoOiAxMDAsXG4gICAqICAgICAgIGhlaWdodDogMTAwLFxuICAgKiAgICAgfVxuICAgKiAgIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBSZXR1cm5zIHRoZSBVUkwgd2hpY2ggdHJpZ2dlcnMgdGhlIGRvd25sb2FkIG9mIGFuIGFzc2V0IGluIGEgcHVibGljIGJ1Y2tldFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEgfSA9IHN1cGFiYXNlXG4gICAqICAgLnN0b3JhZ2VcbiAgICogICAuZnJvbSgncHVibGljLWJ1Y2tldCcpXG4gICAqICAgLmdldFB1YmxpY1VybCgnZm9sZGVyL2F2YXRhcjEucG5nJywge1xuICAgKiAgICAgZG93bmxvYWQ6IHRydWUsXG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVGhlIGJ1Y2tldCBuZWVkcyB0byBiZSBzZXQgdG8gcHVibGljLCBlaXRoZXIgdmlhIFt1cGRhdGVCdWNrZXQoKV0oL2RvY3MvcmVmZXJlbmNlL2phdmFzY3JpcHQvc3RvcmFnZS11cGRhdGVidWNrZXQpIG9yIGJ5IGdvaW5nIHRvIFN0b3JhZ2Ugb24gW3N1cGFiYXNlLmNvbS9kYXNoYm9hcmRdKGh0dHBzOi8vc3VwYWJhc2UuY29tL2Rhc2hib2FyZCksIGNsaWNraW5nIHRoZSBvdmVyZmxvdyBtZW51IG9uIGEgYnVja2V0IGFuZCBjaG9vc2luZyBcIk1ha2UgcHVibGljXCJcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IG5vbmVcbiAgICogLSBSZWZlciB0byB0aGUgW1N0b3JhZ2UgZ3VpZGVdKC9kb2NzL2d1aWRlcy9zdG9yYWdlL3NlY3VyaXR5L2FjY2Vzcy1jb250cm9sKSBvbiBob3cgYWNjZXNzIGNvbnRyb2wgd29ya3NcbiAgICovXG4gIGdldFB1YmxpY1VybChcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHtcbiAgICAgIGRvd25sb2FkPzogc3RyaW5nIHwgYm9vbGVhblxuICAgICAgdHJhbnNmb3JtPzogVHJhbnNmb3JtT3B0aW9uc1xuICAgICAgY2FjaGVOb25jZT86IHN0cmluZ1xuICAgIH1cbiAgKTogeyBkYXRhOiB7IHB1YmxpY1VybDogc3RyaW5nIH0gfSB7XG4gICAgY29uc3QgX3BhdGggPSB0aGlzLl9nZXRGaW5hbFBhdGgocGF0aClcblxuICAgIGNvbnN0IHF1ZXJ5ID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpXG4gICAgaWYgKG9wdGlvbnM/LmRvd25sb2FkKSBxdWVyeS5zZXQoJ2Rvd25sb2FkJywgb3B0aW9ucy5kb3dubG9hZCA9PT0gdHJ1ZSA/ICcnIDogb3B0aW9ucy5kb3dubG9hZClcbiAgICBpZiAob3B0aW9ucz8udHJhbnNmb3JtKSB0aGlzLmFwcGx5VHJhbnNmb3JtT3B0c1RvUXVlcnkocXVlcnksIG9wdGlvbnMudHJhbnNmb3JtKVxuICAgIGlmIChvcHRpb25zPy5jYWNoZU5vbmNlICE9IG51bGwpIHF1ZXJ5LnNldCgnY2FjaGVOb25jZScsIFN0cmluZyhvcHRpb25zLmNhY2hlTm9uY2UpKVxuICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gcXVlcnkudG9TdHJpbmcoKVxuXG4gICAgY29uc3Qgd2FudHNUcmFuc2Zvcm1hdGlvbiA9XG4gICAgICB0eXBlb2Ygb3B0aW9ucz8udHJhbnNmb3JtID09PSAnb2JqZWN0JyAmJlxuICAgICAgb3B0aW9ucy50cmFuc2Zvcm0gIT09IG51bGwgJiZcbiAgICAgIE9iamVjdC5rZXlzKG9wdGlvbnMudHJhbnNmb3JtKS5sZW5ndGggPiAwXG4gICAgY29uc3QgcmVuZGVyUGF0aCA9IHdhbnRzVHJhbnNmb3JtYXRpb24gPyAncmVuZGVyL2ltYWdlJyA6ICdvYmplY3QnXG5cbiAgICByZXR1cm4ge1xuICAgICAgZGF0YToge1xuICAgICAgICBwdWJsaWNVcmw6XG4gICAgICAgICAgZW5jb2RlVVJJKGAke3RoaXMudXJsfS8ke3JlbmRlclBhdGh9L3B1YmxpYy8ke19wYXRofWApICtcbiAgICAgICAgICAocXVlcnlTdHJpbmcgPyBgPyR7cXVlcnlTdHJpbmd9YCA6ICcnKSxcbiAgICAgIH0sXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZXMgZmlsZXMgd2l0aGluIHRoZSBzYW1lIGJ1Y2tldFxuICAgKlxuICAgKiBSZXR1cm5zIGFuIGFycmF5IG9mIEZpbGVPYmplY3QgZW50cmllcyBmb3IgdGhlIGRlbGV0ZWQgZmlsZXMuIE5vdGUgdGhhdCBkZXByZWNhdGVkXG4gICAqIGZpZWxkcyBsaWtlIGBidWNrZXRfaWRgIG1heSBvciBtYXkgbm90IGJlIHByZXNlbnQgaW4gdGhlIHJlc3BvbnNlIC0gZG8gbm90IHJlbHkgb24gdGhlbS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEZpbGUgQnVja2V0c1xuICAgKiBAcGFyYW0gcGF0aHMgQW4gYXJyYXkgb2YgZmlsZXMgdG8gZGVsZXRlLCBpbmNsdWRpbmcgdGhlIHBhdGggYW5kIGZpbGUgbmFtZS4gRm9yIGV4YW1wbGUgW2AnZm9sZGVyL2ltYWdlLnBuZydgXS5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgYXJyYXkgb2YgZGVsZXRlZCBmaWxlIG9iamVjdHMgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgRGVsZXRlIGZpbGVcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAucmVtb3ZlKFsnZm9sZGVyL2F2YXRhcjEucG5nJ10pXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtdLFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFJMUyBwb2xpY3kgcGVybWlzc2lvbnMgcmVxdWlyZWQ6XG4gICAqICAgLSBgYnVja2V0c2AgdGFibGUgcGVybWlzc2lvbnM6IG5vbmVcbiAgICogICAtIGBvYmplY3RzYCB0YWJsZSBwZXJtaXNzaW9uczogYGRlbGV0ZWAgYW5kIGBzZWxlY3RgXG4gICAqIC0gUmVmZXIgdG8gdGhlIFtTdG9yYWdlIGd1aWRlXSgvZG9jcy9ndWlkZXMvc3RvcmFnZS9zZWN1cml0eS9hY2Nlc3MtY29udHJvbCkgb24gaG93IGFjY2VzcyBjb250cm9sIHdvcmtzXG4gICAqL1xuICBhc3luYyByZW1vdmUocGF0aHM6IHN0cmluZ1tdKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogRmlsZU9iamVjdFtdXG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgICB9XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IG51bGxcbiAgICAgICAgZXJyb3I6IFN0b3JhZ2VFcnJvclxuICAgICAgfVxuICA+IHtcbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgcmV0dXJuIGF3YWl0IHJlbW92ZShcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgYCR7dGhpcy51cmx9L29iamVjdC8ke3RoaXMuYnVja2V0SWR9YCxcbiAgICAgICAgeyBwcmVmaXhlczogcGF0aHMgfSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogR2V0IGZpbGUgbWV0YWRhdGFcbiAgICogQHBhcmFtIGlkIHRoZSBmaWxlIGlkIHRvIHJldHJpZXZlIG1ldGFkYXRhXG4gICAqL1xuICAvLyBhc3luYyBnZXRNZXRhZGF0YShcbiAgLy8gICBpZDogc3RyaW5nXG4gIC8vICk6IFByb21pc2U8XG4gIC8vICAgfCB7XG4gIC8vICAgICAgIGRhdGE6IE1ldGFkYXRhXG4gIC8vICAgICAgIGVycm9yOiBudWxsXG4gIC8vICAgICB9XG4gIC8vICAgfCB7XG4gIC8vICAgICAgIGRhdGE6IG51bGxcbiAgLy8gICAgICAgZXJyb3I6IFN0b3JhZ2VFcnJvclxuICAvLyAgICAgfVxuICAvLyA+IHtcbiAgLy8gICB0cnkge1xuICAvLyAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldCh0aGlzLmZldGNoLCBgJHt0aGlzLnVybH0vbWV0YWRhdGEvJHtpZH1gLCB7IGhlYWRlcnM6IHRoaXMuaGVhZGVycyB9KVxuICAvLyAgICAgcmV0dXJuIHsgZGF0YSwgZXJyb3I6IG51bGwgfVxuICAvLyAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gIC8vICAgICBpZiAoaXNTdG9yYWdlRXJyb3IoZXJyb3IpKSB7XG4gIC8vICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yIH1cbiAgLy8gICAgIH1cblxuICAvLyAgICAgdGhyb3cgZXJyb3JcbiAgLy8gICB9XG4gIC8vIH1cblxuICAvKipcbiAgICogVXBkYXRlIGZpbGUgbWV0YWRhdGFcbiAgICogQHBhcmFtIGlkIHRoZSBmaWxlIGlkIHRvIHVwZGF0ZSBtZXRhZGF0YVxuICAgKiBAcGFyYW0gbWV0YSB0aGUgbmV3IGZpbGUgbWV0YWRhdGFcbiAgICovXG4gIC8vIGFzeW5jIHVwZGF0ZU1ldGFkYXRhKFxuICAvLyAgIGlkOiBzdHJpbmcsXG4gIC8vICAgbWV0YTogTWV0YWRhdGFcbiAgLy8gKTogUHJvbWlzZTxcbiAgLy8gICB8IHtcbiAgLy8gICAgICAgZGF0YTogTWV0YWRhdGFcbiAgLy8gICAgICAgZXJyb3I6IG51bGxcbiAgLy8gICAgIH1cbiAgLy8gICB8IHtcbiAgLy8gICAgICAgZGF0YTogbnVsbFxuICAvLyAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gIC8vICAgICB9XG4gIC8vID4ge1xuICAvLyAgIHRyeSB7XG4gIC8vICAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9zdChcbiAgLy8gICAgICAgdGhpcy5mZXRjaCxcbiAgLy8gICAgICAgYCR7dGhpcy51cmx9L21ldGFkYXRhLyR7aWR9YCxcbiAgLy8gICAgICAgeyAuLi5tZXRhIH0sXG4gIC8vICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH1cbiAgLy8gICAgIClcbiAgLy8gICAgIHJldHVybiB7IGRhdGEsIGVycm9yOiBudWxsIH1cbiAgLy8gICB9IGNhdGNoIChlcnJvcikge1xuICAvLyAgICAgaWYgKGlzU3RvcmFnZUVycm9yKGVycm9yKSkge1xuICAvLyAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gIC8vICAgICB9XG5cbiAgLy8gICAgIHRocm93IGVycm9yXG4gIC8vICAgfVxuICAvLyB9XG5cbiAgLyoqXG4gICAqIExpc3RzIGFsbCB0aGUgZmlsZXMgYW5kIGZvbGRlcnMgd2l0aGluIGEgcGF0aCBvZiB0aGUgYnVja2V0LlxuICAgKlxuICAgKiAqKkltcG9ydGFudDoqKiBGb3IgZm9sZGVyIGVudHJpZXMsIGZpZWxkcyBsaWtlIGBpZGAsIGB1cGRhdGVkX2F0YCwgYGNyZWF0ZWRfYXRgLFxuICAgKiBgbGFzdF9hY2Nlc3NlZF9hdGAsIGFuZCBgbWV0YWRhdGFgIHdpbGwgYmUgYG51bGxgLiBPbmx5IGZpbGVzIGhhdmUgdGhlc2UgZmllbGRzIHBvcHVsYXRlZC5cbiAgICogQWRkaXRpb25hbGx5LCBkZXByZWNhdGVkIGZpZWxkcyBsaWtlIGBidWNrZXRfaWRgLCBgb3duZXJgLCBhbmQgYGJ1Y2tldHNgIGFyZSBOT1QgcmV0dXJuZWRcbiAgICogYnkgdGhpcyBtZXRob2QuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICogQHBhcmFtIHBhdGggVGhlIGZvbGRlciBwYXRoLlxuICAgKiBAcGFyYW0gb3B0aW9ucyBTZWFyY2ggb3B0aW9ucyBpbmNsdWRpbmcgbGltaXQgKGRlZmF1bHRzIHRvIDEwMCksIG9mZnNldCwgc29ydEJ5LCBhbmQgc2VhcmNoXG4gICAqIEBwYXJhbSBwYXJhbWV0ZXJzIE9wdGlvbmFsIGZldGNoIHBhcmFtZXRlcnMgaW5jbHVkaW5nIHNpZ25hbCBmb3IgY2FuY2VsbGF0aW9uXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIGFycmF5IG9mIGZpbGVzL2ZvbGRlcnMgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdCBmaWxlcyBpbiBhIGJ1Y2tldFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgKiAgIC5saXN0KCdmb2xkZXInLCB7XG4gICAqICAgICBsaW1pdDogMTAwLFxuICAgKiAgICAgb2Zmc2V0OiAwLFxuICAgKiAgICAgc29ydEJ5OiB7IGNvbHVtbjogJ25hbWUnLCBvcmRlcjogJ2FzYycgfSxcbiAgICogICB9KVxuICAgKlxuICAgKiAvLyBIYW5kbGUgZmlsZXMgdnMgZm9sZGVyc1xuICAgKiBkYXRhPy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgKiAgIGlmIChpdGVtLmlkICE9PSBudWxsKSB7XG4gICAqICAgICAvLyBJdCdzIGEgZmlsZVxuICAgKiAgICAgY29uc29sZS5sb2coJ0ZpbGU6JywgaXRlbS5uYW1lLCAnU2l6ZTonLCBpdGVtLm1ldGFkYXRhPy5zaXplKVxuICAgKiAgIH0gZWxzZSB7XG4gICAqICAgICAvLyBJdCdzIGEgZm9sZGVyXG4gICAqICAgICBjb25zb2xlLmxvZygnRm9sZGVyOicsIGl0ZW0ubmFtZSlcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJuYW1lXCI6IFwiYXZhdGFyMS5wbmdcIixcbiAgICogICAgICAgXCJpZFwiOiBcImU2NjhjZjdmLTgyMWItNGEyZi05ZGNlLTdkZmE1ZGQxY2ZkMlwiLFxuICAgKiAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTA1LTIyVDIzOjA2OjA1LjU4MFpcIixcbiAgICogICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wNS0yMlQyMzowNDozNC40NDNaXCIsXG4gICAqICAgICAgIFwibGFzdF9hY2Nlc3NlZF9hdFwiOiBcIjIwMjQtMDUtMjJUMjM6MDQ6MzQuNDQzWlwiLFxuICAgKiAgICAgICBcIm1ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcImVUYWdcIjogXCJcXFwiYzVlOGM1NTMyMzVkOWFmMzBlZjRmNmUyODA3OTBiOTJcXFwiXCIsXG4gICAqICAgICAgICAgXCJzaXplXCI6IDMyMTc1LFxuICAgKiAgICAgICAgIFwibWltZXR5cGVcIjogXCJpbWFnZS9wbmdcIixcbiAgICogICAgICAgICBcImNhY2hlQ29udHJvbFwiOiBcIm1heC1hZ2U9MzYwMFwiLFxuICAgKiAgICAgICAgIFwibGFzdE1vZGlmaWVkXCI6IFwiMjAyNC0wNS0yMlQyMzowNjowNS41NzRaXCIsXG4gICAqICAgICAgICAgXCJjb250ZW50TGVuZ3RoXCI6IDMyMTc1LFxuICAgKiAgICAgICAgIFwiaHR0cFN0YXR1c0NvZGVcIjogMjAwXG4gICAqICAgICAgIH1cbiAgICogICAgIH1cbiAgICogICBdLFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTZWFyY2ggZmlsZXMgaW4gYSBidWNrZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAubGlzdCgnZm9sZGVyJywge1xuICAgKiAgICAgbGltaXQ6IDEwMCxcbiAgICogICAgIG9mZnNldDogMCxcbiAgICogICAgIHNvcnRCeTogeyBjb2x1bW46ICduYW1lJywgb3JkZXI6ICdhc2MnIH0sXG4gICAqICAgICBzZWFyY2g6ICdqb24nXG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUkxTIHBvbGljeSBwZXJtaXNzaW9ucyByZXF1aXJlZDpcbiAgICogICAtIGBidWNrZXRzYCB0YWJsZSBwZXJtaXNzaW9uczogbm9uZVxuICAgKiAgIC0gYG9iamVjdHNgIHRhYmxlIHBlcm1pc3Npb25zOiBgc2VsZWN0YFxuICAgKiAtIFJlZmVyIHRvIHRoZSBbU3RvcmFnZSBndWlkZV0oL2RvY3MvZ3VpZGVzL3N0b3JhZ2Uvc2VjdXJpdHkvYWNjZXNzLWNvbnRyb2wpIG9uIGhvdyBhY2Nlc3MgY29udHJvbCB3b3Jrc1xuICAgKi9cbiAgYXN5bmMgbGlzdChcbiAgICBwYXRoPzogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiBTZWFyY2hPcHRpb25zLFxuICAgIHBhcmFtZXRlcnM/OiBGZXRjaFBhcmFtZXRlcnNcbiAgKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogRmlsZU9iamVjdFtdXG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgICB9XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IG51bGxcbiAgICAgICAgZXJyb3I6IFN0b3JhZ2VFcnJvclxuICAgICAgfVxuICA+IHtcbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3QgYm9keSA9IHsgLi4uREVGQVVMVF9TRUFSQ0hfT1BUSU9OUywgLi4ub3B0aW9ucywgcHJlZml4OiBwYXRoIHx8ICcnIH1cbiAgICAgIHJldHVybiBhd2FpdCBwb3N0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vb2JqZWN0L2xpc3QvJHt0aGlzLmJ1Y2tldElkfWAsXG4gICAgICAgIGJvZHksXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH0sXG4gICAgICAgIHBhcmFtZXRlcnNcbiAgICAgIClcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIExpc3RzIGFsbCB0aGUgZmlsZXMgYW5kIGZvbGRlcnMgd2l0aGluIGEgYnVja2V0IHVzaW5nIHRoZSBWMiBBUEkgd2l0aCBwYWdpbmF0aW9uIHN1cHBvcnQuXG4gICAqXG4gICAqICoqSW1wb3J0YW50OioqIEZvbGRlciBlbnRyaWVzIGluIHRoZSBgZm9sZGVyc2AgYXJyYXkgb25seSBjb250YWluIGBuYW1lYCBhbmQgb3B0aW9uYWxseSBga2V5YCDigJRcbiAgICogdGhleSBoYXZlIG5vIGBpZGAsIHRpbWVzdGFtcHMsIG9yIGBtZXRhZGF0YWAgZmllbGRzLiBGdWxsIGZpbGUgbWV0YWRhdGEgaXMgb25seSBhdmFpbGFibGVcbiAgICogb24gZW50cmllcyBpbiB0aGUgYG9iamVjdHNgIGFycmF5LlxuICAgKlxuICAgKiBAZXhwZXJpbWVudGFsIHRoaXMgbWV0aG9kIHNpZ25hdHVyZSBtaWdodCBjaGFuZ2UgaW4gdGhlIGZ1dHVyZVxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBvcHRpb25zIFNlYXJjaCBvcHRpb25zIGluY2x1ZGluZyBwcmVmaXgsIGN1cnNvciBmb3IgcGFnaW5hdGlvbiwgbGltaXQsIHdpdGhfZGVsaW1pdGVyXG4gICAqIEBwYXJhbSBwYXJhbWV0ZXJzIE9wdGlvbmFsIGZldGNoIHBhcmFtZXRlcnMgaW5jbHVkaW5nIHNpZ25hbCBmb3IgY2FuY2VsbGF0aW9uXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIGZvbGRlcnMvb2JqZWN0cyBhcnJheXMgd2l0aCBwYWdpbmF0aW9uIGluZm8gb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdCBmaWxlcyB3aXRoIHBhZ2luYXRpb25cbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5mcm9tKCdhdmF0YXJzJylcbiAgICogICAubGlzdFYyKHtcbiAgICogICAgIHByZWZpeDogJ2ZvbGRlci8nLFxuICAgKiAgICAgbGltaXQ6IDEwMCxcbiAgICogICB9KVxuICAgKlxuICAgKiAvLyBIYW5kbGUgcGFnaW5hdGlvblxuICAgKiBpZiAoZGF0YT8uaGFzTmV4dCkge1xuICAgKiAgIGNvbnN0IG5leHRQYWdlID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAgIC5zdG9yYWdlXG4gICAqICAgICAuZnJvbSgnYXZhdGFycycpXG4gICAqICAgICAubGlzdFYyKHtcbiAgICogICAgICAgcHJlZml4OiAnZm9sZGVyLycsXG4gICAqICAgICAgIGN1cnNvcjogZGF0YS5uZXh0Q3Vyc29yLFxuICAgKiAgICAgfSlcbiAgICogfVxuICAgKlxuICAgKiAvLyBIYW5kbGUgZmlsZXMgdnMgZm9sZGVyc1xuICAgKiBkYXRhPy5vYmplY3RzLmZvckVhY2goZmlsZSA9PiB7XG4gICAqICAgaWYgKGZpbGUuaWQgIT09IG51bGwpIHtcbiAgICogICAgIGNvbnNvbGUubG9nKCdGaWxlOicsIGZpbGUubmFtZSwgJ1NpemU6JywgZmlsZS5tZXRhZGF0YT8uc2l6ZSlcbiAgICogICB9XG4gICAqIH0pXG4gICAqIGRhdGE/LmZvbGRlcnMuZm9yRWFjaChmb2xkZXIgPT4ge1xuICAgKiAgIGNvbnNvbGUubG9nKCdGb2xkZXI6JywgZm9sZGVyLm5hbWUpXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgbGlzdFYyKFxuICAgIG9wdGlvbnM/OiBTZWFyY2hWMk9wdGlvbnMsXG4gICAgcGFyYW1ldGVycz86IEZldGNoUGFyYW1ldGVyc1xuICApOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiBTZWFyY2hWMlJlc3VsdFxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGJvZHkgPSB7IC4uLm9wdGlvbnMgfVxuICAgICAgcmV0dXJuIGF3YWl0IHBvc3QoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgIGAke3RoaXMudXJsfS9vYmplY3QvbGlzdC12Mi8ke3RoaXMuYnVja2V0SWR9YCxcbiAgICAgICAgYm9keSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfSxcbiAgICAgICAgcGFyYW1ldGVyc1xuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICBwcm90ZWN0ZWQgZW5jb2RlTWV0YWRhdGEobWV0YWRhdGE6IFJlY29yZDxzdHJpbmcsIGFueT4pIHtcbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkobWV0YWRhdGEpXG4gIH1cblxuICB0b0Jhc2U2NChkYXRhOiBzdHJpbmcpIHtcbiAgICBpZiAodHlwZW9mIEJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHJldHVybiBCdWZmZXIuZnJvbShkYXRhKS50b1N0cmluZygnYmFzZTY0JylcbiAgICB9XG4gICAgcmV0dXJuIGJ0b2EoZGF0YSlcbiAgfVxuXG4gIHByaXZhdGUgX2dldEZpbmFsUGF0aChwYXRoOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gYCR7dGhpcy5idWNrZXRJZH0vJHtwYXRoLnJlcGxhY2UoL15cXC8rLywgJycpfWBcbiAgfVxuXG4gIHByaXZhdGUgX3JlbW92ZUVtcHR5Rm9sZGVycyhwYXRoOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gcGF0aC5yZXBsYWNlKC9eXFwvfFxcLyQvZywgJycpLnJlcGxhY2UoL1xcLysvZywgJy8nKVxuICB9XG5cbiAgLyoqIE1vZGlmaWVzIHRoZSBgcXVlcnlgLCBhcHBlbmRpbmcgdmFsdWVzIHRoZSBmcm9tIGB0cmFuc2Zvcm1gICovXG4gIHByaXZhdGUgYXBwbHlUcmFuc2Zvcm1PcHRzVG9RdWVyeShcbiAgICBxdWVyeTogVVJMU2VhcmNoUGFyYW1zLFxuICAgIHRyYW5zZm9ybTogVHJhbnNmb3JtT3B0aW9uc1xuICApOiBVUkxTZWFyY2hQYXJhbXMge1xuICAgIGlmICh0cmFuc2Zvcm0ud2lkdGgpIHF1ZXJ5LnNldCgnd2lkdGgnLCB0cmFuc2Zvcm0ud2lkdGgudG9TdHJpbmcoKSlcbiAgICBpZiAodHJhbnNmb3JtLmhlaWdodCkgcXVlcnkuc2V0KCdoZWlnaHQnLCB0cmFuc2Zvcm0uaGVpZ2h0LnRvU3RyaW5nKCkpXG4gICAgaWYgKHRyYW5zZm9ybS5yZXNpemUpIHF1ZXJ5LnNldCgncmVzaXplJywgdHJhbnNmb3JtLnJlc2l6ZSlcbiAgICBpZiAodHJhbnNmb3JtLmZvcm1hdCkgcXVlcnkuc2V0KCdmb3JtYXQnLCB0cmFuc2Zvcm0uZm9ybWF0KVxuICAgIGlmICh0cmFuc2Zvcm0ucXVhbGl0eSkgcXVlcnkuc2V0KCdxdWFsaXR5JywgdHJhbnNmb3JtLnF1YWxpdHkudG9TdHJpbmcoKSlcblxuICAgIHJldHVybiBxdWVyeVxuICB9XG59XG4iLCIvLyBHZW5lcmF0ZWQgYXV0b21hdGljYWxseSBkdXJpbmcgcmVsZWFzZXMgYnkgc2NyaXB0cy91cGRhdGUtdmVyc2lvbi1maWxlcy50c1xuLy8gVGhpcyBmaWxlIHByb3ZpZGVzIHJ1bnRpbWUgYWNjZXNzIHRvIHRoZSBwYWNrYWdlIHZlcnNpb24gZm9yOlxuLy8gLSBIVFRQIHJlcXVlc3QgaGVhZGVycyAoZS5nLiwgWC1DbGllbnQtSW5mbyBoZWFkZXIgZm9yIEFQSSByZXF1ZXN0cylcbi8vIC0gRGVidWdnaW5nIGFuZCBzdXBwb3J0IChpZGVudGlmeWluZyB3aGljaCB2ZXJzaW9uIGlzIHJ1bm5pbmcpXG4vLyAtIFRlbGVtZXRyeSBhbmQgbG9nZ2luZyAodmVyc2lvbiByZXBvcnRpbmcgaW4gZXJyb3JzL2FuYWx5dGljcylcbi8vIC0gRW5zdXJpbmcgYnVpbGQgYXJ0aWZhY3RzIG1hdGNoIHRoZSBwdWJsaXNoZWQgcGFja2FnZSB2ZXJzaW9uXG5leHBvcnQgY29uc3QgdmVyc2lvbiA9ICcyLjEwOC4xJ1xuIiwiaW1wb3J0IHsgdmVyc2lvbiB9IGZyb20gJy4vdmVyc2lvbidcbmV4cG9ydCBjb25zdCBERUZBVUxUX0hFQURFUlMgPSB7XG4gICdYLUNsaWVudC1JbmZvJzogYHN0b3JhZ2UtanMvJHt2ZXJzaW9ufWAsXG59XG4iLCJpbXBvcnQgeyBERUZBVUxUX0hFQURFUlMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHsgU3RvcmFnZUVycm9yIH0gZnJvbSAnLi4vbGliL2NvbW1vbi9lcnJvcnMnXG5pbXBvcnQgeyBGZXRjaCwgZ2V0LCBwb3N0LCBwdXQsIHJlbW92ZSB9IGZyb20gJy4uL2xpYi9jb21tb24vZmV0Y2gnXG5pbXBvcnQgQmFzZUFwaUNsaWVudCBmcm9tICcuLi9saWIvY29tbW9uL0Jhc2VBcGlDbGllbnQnXG5pbXBvcnQgeyBCdWNrZXQsIEJ1Y2tldFR5cGUsIExpc3RCdWNrZXRPcHRpb25zIH0gZnJvbSAnLi4vbGliL3R5cGVzJ1xuaW1wb3J0IHsgU3RvcmFnZUNsaWVudE9wdGlvbnMgfSBmcm9tICcuLi9TdG9yYWdlQ2xpZW50J1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTdG9yYWdlQnVja2V0QXBpIGV4dGVuZHMgQmFzZUFwaUNsaWVudDxTdG9yYWdlRXJyb3I+IHtcbiAgY29uc3RydWN0b3IoXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgaGVhZGVyczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9LFxuICAgIGZldGNoPzogRmV0Y2gsXG4gICAgb3B0cz86IFN0b3JhZ2VDbGllbnRPcHRpb25zXG4gICkge1xuICAgIGNvbnN0IGJhc2VVcmwgPSBuZXcgVVJMKHVybClcblxuICAgIC8vIGlmIGxlZ2FjeSB1cmkgaXMgdXNlZCwgcmVwbGFjZSB3aXRoIG5ldyBzdG9yYWdlIGhvc3QgKGRpc2FibGVzIHJlcXVlc3QgYnVmZmVyaW5nIHRvIGFsbG93ID4gNTBHQiB1cGxvYWRzKVxuICAgIC8vIFwicHJvamVjdC1yZWYuc3VwYWJhc2UuY29cIiBiZWNvbWVzIFwicHJvamVjdC1yZWYuc3RvcmFnZS5zdXBhYmFzZS5jb1wiXG4gICAgaWYgKG9wdHM/LnVzZU5ld0hvc3RuYW1lKSB7XG4gICAgICBjb25zdCBpc1N1cGFiYXNlSG9zdCA9IC9zdXBhYmFzZVxcLihjb3xpbnxyZWQpJC8udGVzdChiYXNlVXJsLmhvc3RuYW1lKVxuICAgICAgaWYgKGlzU3VwYWJhc2VIb3N0ICYmICFiYXNlVXJsLmhvc3RuYW1lLmluY2x1ZGVzKCdzdG9yYWdlLnN1cGFiYXNlLicpKSB7XG4gICAgICAgIGJhc2VVcmwuaG9zdG5hbWUgPSBiYXNlVXJsLmhvc3RuYW1lLnJlcGxhY2UoJ3N1cGFiYXNlLicsICdzdG9yYWdlLnN1cGFiYXNlLicpXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgZmluYWxVcmwgPSBiYXNlVXJsLmhyZWYucmVwbGFjZSgvXFwvJC8sICcnKVxuICAgIGNvbnN0IGZpbmFsSGVhZGVycyA9IHsgLi4uREVGQVVMVF9IRUFERVJTLCAuLi5oZWFkZXJzIH1cblxuICAgIHN1cGVyKGZpbmFsVXJsLCBmaW5hbEhlYWRlcnMsIGZldGNoLCAnc3RvcmFnZScpXG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmVzIHRoZSBkZXRhaWxzIG9mIGFsbCBTdG9yYWdlIGJ1Y2tldHMgd2l0aGluIGFuIGV4aXN0aW5nIHByb2plY3QuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICogQHBhcmFtIG9wdGlvbnMgUXVlcnkgcGFyYW1ldGVycyBmb3IgbGlzdGluZyBidWNrZXRzXG4gICAqIEBwYXJhbSBvcHRpb25zLmxpbWl0IE1heGltdW0gbnVtYmVyIG9mIGJ1Y2tldHMgdG8gcmV0dXJuXG4gICAqIEBwYXJhbSBvcHRpb25zLm9mZnNldCBOdW1iZXIgb2YgYnVja2V0cyB0byBza2lwXG4gICAqIEBwYXJhbSBvcHRpb25zLnNvcnRDb2x1bW4gQ29sdW1uIHRvIHNvcnQgYnkgKCdpZCcsICduYW1lJywgJ2NyZWF0ZWRfYXQnLCAndXBkYXRlZF9hdCcpXG4gICAqIEBwYXJhbSBvcHRpb25zLnNvcnRPcmRlciBTb3J0IG9yZGVyICgnYXNjJyBvciAnZGVzYycpXG4gICAqIEBwYXJhbSBvcHRpb25zLnNlYXJjaCBTZWFyY2ggdGVybSB0byBmaWx0ZXIgYnVja2V0IG5hbWVzXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIGFycmF5IG9mIGJ1Y2tldHMgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdCBidWNrZXRzXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLnN0b3JhZ2VcbiAgICogICAubGlzdEJ1Y2tldHMoKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdCBidWNrZXRzIHdpdGggb3B0aW9uc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmxpc3RCdWNrZXRzKHtcbiAgICogICAgIGxpbWl0OiAxMCxcbiAgICogICAgIG9mZnNldDogMCxcbiAgICogICAgIHNvcnRDb2x1bW46ICdjcmVhdGVkX2F0JyxcbiAgICogICAgIHNvcnRPcmRlcjogJ2Rlc2MnLFxuICAgKiAgICAgc2VhcmNoOiAncHJvZCdcbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBgc2VsZWN0YFxuICAgKiAgIC0gYG9iamVjdHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqIC0gUmVmZXIgdG8gdGhlIFtTdG9yYWdlIGd1aWRlXSgvZG9jcy9ndWlkZXMvc3RvcmFnZS9zZWN1cml0eS9hY2Nlc3MtY29udHJvbCkgb24gaG93IGFjY2VzcyBjb250cm9sIHdvcmtzXG4gICAqL1xuICBhc3luYyBsaXN0QnVja2V0cyhvcHRpb25zPzogTGlzdEJ1Y2tldE9wdGlvbnMpOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiBCdWNrZXRbXVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gdGhpcy5saXN0QnVja2V0T3B0aW9uc1RvUXVlcnlTdHJpbmcob3B0aW9ucylcbiAgICAgIHJldHVybiBhd2FpdCBnZXQodGhpcy5mZXRjaCwgYCR7dGhpcy51cmx9L2J1Y2tldCR7cXVlcnlTdHJpbmd9YCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICB9KVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmVzIHRoZSBkZXRhaWxzIG9mIGFuIGV4aXN0aW5nIFN0b3JhZ2UgYnVja2V0LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBpZCBUaGUgdW5pcXVlIGlkZW50aWZpZXIgb2YgdGhlIGJ1Y2tldCB5b3Ugd291bGQgbGlrZSB0byByZXRyaWV2ZS5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgYnVja2V0IGRldGFpbHMgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgR2V0IGJ1Y2tldFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLmdldEJ1Y2tldCgnYXZhdGFycycpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwiaWRcIjogXCJhdmF0YXJzXCIsXG4gICAqICAgICBcIm5hbWVcIjogXCJhdmF0YXJzXCIsXG4gICAqICAgICBcIm93bmVyXCI6IFwiXCIsXG4gICAqICAgICBcInB1YmxpY1wiOiBmYWxzZSxcbiAgICogICAgIFwiZmlsZV9zaXplX2xpbWl0XCI6IDEwMjQsXG4gICAqICAgICBcImFsbG93ZWRfbWltZV90eXBlc1wiOiBbXG4gICAqICAgICAgIFwiaW1hZ2UvcG5nXCJcbiAgICogICAgIF0sXG4gICAqICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTA1LTIyVDIyOjI2OjA1LjEwMFpcIixcbiAgICogICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDUtMjJUMjI6MjY6MDUuMTAwWlwiXG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBgc2VsZWN0YFxuICAgKiAgIC0gYG9iamVjdHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqIC0gUmVmZXIgdG8gdGhlIFtTdG9yYWdlIGd1aWRlXSgvZG9jcy9ndWlkZXMvc3RvcmFnZS9zZWN1cml0eS9hY2Nlc3MtY29udHJvbCkgb24gaG93IGFjY2VzcyBjb250cm9sIHdvcmtzXG4gICAqL1xuICBhc3luYyBnZXRCdWNrZXQoaWQ6IHN0cmluZyk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IEJ1Y2tldFxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIHJldHVybiBhd2FpdCBnZXQodGhpcy5mZXRjaCwgYCR7dGhpcy51cmx9L2J1Y2tldC8ke2lkfWAsIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH0pXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IFN0b3JhZ2UgYnVja2V0XG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICogQHBhcmFtIGlkIEEgdW5pcXVlIGlkZW50aWZpZXIgZm9yIHRoZSBidWNrZXQgeW91IGFyZSBjcmVhdGluZy5cbiAgICogQHBhcmFtIG9wdGlvbnMucHVibGljIFRoZSB2aXNpYmlsaXR5IG9mIHRoZSBidWNrZXQuIFB1YmxpYyBidWNrZXRzIGRvbid0IHJlcXVpcmUgYW4gYXV0aG9yaXphdGlvbiB0b2tlbiB0byBkb3dubG9hZCBvYmplY3RzLCBidXQgc3RpbGwgcmVxdWlyZSBhIHZhbGlkIHRva2VuIGZvciBhbGwgb3RoZXIgb3BlcmF0aW9ucy4gQnkgZGVmYXVsdCwgYnVja2V0cyBhcmUgcHJpdmF0ZS5cbiAgICogQHBhcmFtIG9wdGlvbnMuZmlsZVNpemVMaW1pdCBzcGVjaWZpZXMgdGhlIG1heCBmaWxlIHNpemUgaW4gYnl0ZXMgdGhhdCBjYW4gYmUgdXBsb2FkZWQgdG8gdGhpcyBidWNrZXQuXG4gICAqIFRoZSBnbG9iYWwgZmlsZSBzaXplIGxpbWl0IHRha2VzIHByZWNlZGVuY2Ugb3ZlciB0aGlzIHZhbHVlLlxuICAgKiBUaGUgZGVmYXVsdCB2YWx1ZSBpcyBudWxsLCB3aGljaCBkb2Vzbid0IHNldCBhIHBlciBidWNrZXQgZmlsZSBzaXplIGxpbWl0LlxuICAgKiBAcGFyYW0gb3B0aW9ucy5hbGxvd2VkTWltZVR5cGVzIHNwZWNpZmllcyB0aGUgYWxsb3dlZCBtaW1lIHR5cGVzIHRoYXQgdGhpcyBidWNrZXQgY2FuIGFjY2VwdCBkdXJpbmcgdXBsb2FkLlxuICAgKiBUaGUgZGVmYXVsdCB2YWx1ZSBpcyBudWxsLCB3aGljaCBhbGxvd3MgZmlsZXMgd2l0aCBhbGwgbWltZSB0eXBlcyB0byBiZSB1cGxvYWRlZC5cbiAgICogRWFjaCBtaW1lIHR5cGUgc3BlY2lmaWVkIGNhbiBiZSBhIHdpbGRjYXJkLCBlLmcuIGltYWdlLyosIG9yIGEgc3BlY2lmaWMgbWltZSB0eXBlLCBlLmcuIGltYWdlL3BuZy5cbiAgICogQHBhcmFtIG9wdGlvbnMudHlwZSAocHJpdmF0ZS1iZXRhKSBzcGVjaWZpZXMgdGhlIGJ1Y2tldCB0eXBlLiBzZWUgYEJ1Y2tldFR5cGVgIGZvciBtb3JlIGRldGFpbHMuXG4gICAqICAgLSBkZWZhdWx0IGJ1Y2tldCB0eXBlIGlzIGBTVEFOREFSRGBcbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgbmV3bHkgY3JlYXRlZCBidWNrZXQgbmFtZSBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBDcmVhdGUgYnVja2V0XG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAqICAgLnN0b3JhZ2VcbiAgICogICAuY3JlYXRlQnVja2V0KCdhdmF0YXJzJywge1xuICAgKiAgICAgcHVibGljOiBmYWxzZSxcbiAgICogICAgIGFsbG93ZWRNaW1lVHlwZXM6IFsnaW1hZ2UvcG5nJ10sXG4gICAqICAgICBmaWxlU2l6ZUxpbWl0OiAxMDI0XG4gICAqICAgfSlcbiAgICogYGBgXG4gICAqXG4gICAqIFJlc3BvbnNlOlxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJuYW1lXCI6IFwiYXZhdGFyc1wiXG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBgaW5zZXJ0YFxuICAgKiAgIC0gYG9iamVjdHNgIHRhYmxlIHBlcm1pc3Npb25zOiBub25lXG4gICAqIC0gUmVmZXIgdG8gdGhlIFtTdG9yYWdlIGd1aWRlXSgvZG9jcy9ndWlkZXMvc3RvcmFnZS9zZWN1cml0eS9hY2Nlc3MtY29udHJvbCkgb24gaG93IGFjY2VzcyBjb250cm9sIHdvcmtzXG4gICAqL1xuICBhc3luYyBjcmVhdGVCdWNrZXQoXG4gICAgaWQ6IHN0cmluZyxcbiAgICBvcHRpb25zOiB7XG4gICAgICBwdWJsaWM6IGJvb2xlYW5cbiAgICAgIGZpbGVTaXplTGltaXQ/OiBudW1iZXIgfCBzdHJpbmcgfCBudWxsXG4gICAgICBhbGxvd2VkTWltZVR5cGVzPzogc3RyaW5nW10gfCBudWxsXG4gICAgICB0eXBlPzogQnVja2V0VHlwZVxuICAgIH0gPSB7XG4gICAgICBwdWJsaWM6IGZhbHNlLFxuICAgIH1cbiAgKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogUGljazxCdWNrZXQsICduYW1lJz5cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gICAgICB9XG4gID4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gYXdhaXQgcG9zdChcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgYCR7dGhpcy51cmx9L2J1Y2tldGAsXG4gICAgICAgIHtcbiAgICAgICAgICBpZCxcbiAgICAgICAgICBuYW1lOiBpZCxcbiAgICAgICAgICB0eXBlOiBvcHRpb25zLnR5cGUsXG4gICAgICAgICAgcHVibGljOiBvcHRpb25zLnB1YmxpYyxcbiAgICAgICAgICBmaWxlX3NpemVfbGltaXQ6IG9wdGlvbnMuZmlsZVNpemVMaW1pdCxcbiAgICAgICAgICBhbGxvd2VkX21pbWVfdHlwZXM6IG9wdGlvbnMuYWxsb3dlZE1pbWVUeXBlcyxcbiAgICAgICAgfSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlcyBhIFN0b3JhZ2UgYnVja2V0XG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICogQHBhcmFtIGlkIEEgdW5pcXVlIGlkZW50aWZpZXIgZm9yIHRoZSBidWNrZXQgeW91IGFyZSB1cGRhdGluZy5cbiAgICogQHBhcmFtIG9wdGlvbnMucHVibGljIFRoZSB2aXNpYmlsaXR5IG9mIHRoZSBidWNrZXQuIFB1YmxpYyBidWNrZXRzIGRvbid0IHJlcXVpcmUgYW4gYXV0aG9yaXphdGlvbiB0b2tlbiB0byBkb3dubG9hZCBvYmplY3RzLCBidXQgc3RpbGwgcmVxdWlyZSBhIHZhbGlkIHRva2VuIGZvciBhbGwgb3RoZXIgb3BlcmF0aW9ucy5cbiAgICogQHBhcmFtIG9wdGlvbnMuZmlsZVNpemVMaW1pdCBzcGVjaWZpZXMgdGhlIG1heCBmaWxlIHNpemUgaW4gYnl0ZXMgdGhhdCBjYW4gYmUgdXBsb2FkZWQgdG8gdGhpcyBidWNrZXQuXG4gICAqIFRoZSBnbG9iYWwgZmlsZSBzaXplIGxpbWl0IHRha2VzIHByZWNlZGVuY2Ugb3ZlciB0aGlzIHZhbHVlLlxuICAgKiBUaGUgZGVmYXVsdCB2YWx1ZSBpcyBudWxsLCB3aGljaCBkb2Vzbid0IHNldCBhIHBlciBidWNrZXQgZmlsZSBzaXplIGxpbWl0LlxuICAgKiBAcGFyYW0gb3B0aW9ucy5hbGxvd2VkTWltZVR5cGVzIHNwZWNpZmllcyB0aGUgYWxsb3dlZCBtaW1lIHR5cGVzIHRoYXQgdGhpcyBidWNrZXQgY2FuIGFjY2VwdCBkdXJpbmcgdXBsb2FkLlxuICAgKiBUaGUgZGVmYXVsdCB2YWx1ZSBpcyBudWxsLCB3aGljaCBhbGxvd3MgZmlsZXMgd2l0aCBhbGwgbWltZSB0eXBlcyB0byBiZSB1cGxvYWRlZC5cbiAgICogRWFjaCBtaW1lIHR5cGUgc3BlY2lmaWVkIGNhbiBiZSBhIHdpbGRjYXJkLCBlLmcuIGltYWdlLyosIG9yIGEgc3BlY2lmaWMgbWltZSB0eXBlLCBlLmcuIGltYWdlL3BuZy5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgc3VjY2VzcyBtZXNzYWdlIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIFVwZGF0ZSBidWNrZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC51cGRhdGVCdWNrZXQoJ2F2YXRhcnMnLCB7XG4gICAqICAgICBwdWJsaWM6IGZhbHNlLFxuICAgKiAgICAgYWxsb3dlZE1pbWVUeXBlczogWydpbWFnZS9wbmcnXSxcbiAgICogICAgIGZpbGVTaXplTGltaXQ6IDEwMjRcbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogUmVzcG9uc2U6XG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcIm1lc3NhZ2VcIjogXCJTdWNjZXNzZnVsbHkgdXBkYXRlZFwiXG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBgc2VsZWN0YCBhbmQgYHVwZGF0ZWBcbiAgICogICAtIGBvYmplY3RzYCB0YWJsZSBwZXJtaXNzaW9uczogbm9uZVxuICAgKiAtIFJlZmVyIHRvIHRoZSBbU3RvcmFnZSBndWlkZV0oL2RvY3MvZ3VpZGVzL3N0b3JhZ2Uvc2VjdXJpdHkvYWNjZXNzLWNvbnRyb2wpIG9uIGhvdyBhY2Nlc3MgY29udHJvbCB3b3Jrc1xuICAgKi9cbiAgYXN5bmMgdXBkYXRlQnVja2V0KFxuICAgIGlkOiBzdHJpbmcsXG4gICAgb3B0aW9uczoge1xuICAgICAgcHVibGljOiBib29sZWFuXG4gICAgICBmaWxlU2l6ZUxpbWl0PzogbnVtYmVyIHwgc3RyaW5nIHwgbnVsbFxuICAgICAgYWxsb3dlZE1pbWVUeXBlcz86IHN0cmluZ1tdIHwgbnVsbFxuICAgIH1cbiAgKTogUHJvbWlzZTxcbiAgICB8IHtcbiAgICAgICAgZGF0YTogeyBtZXNzYWdlOiBzdHJpbmcgfVxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIHJldHVybiBhd2FpdCBwdXQoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgIGAke3RoaXMudXJsfS9idWNrZXQvJHtpZH1gLFxuICAgICAgICB7XG4gICAgICAgICAgaWQsXG4gICAgICAgICAgbmFtZTogaWQsXG4gICAgICAgICAgcHVibGljOiBvcHRpb25zLnB1YmxpYyxcbiAgICAgICAgICBmaWxlX3NpemVfbGltaXQ6IG9wdGlvbnMuZmlsZVNpemVMaW1pdCxcbiAgICAgICAgICBhbGxvd2VkX21pbWVfdHlwZXM6IG9wdGlvbnMuYWxsb3dlZE1pbWVUeXBlcyxcbiAgICAgICAgfSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogUmVtb3ZlcyBhbGwgb2JqZWN0cyBpbnNpZGUgYSBzaW5nbGUgYnVja2V0LlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgRmlsZSBCdWNrZXRzXG4gICAqIEBwYXJhbSBpZCBUaGUgdW5pcXVlIGlkZW50aWZpZXIgb2YgdGhlIGJ1Y2tldCB5b3Ugd291bGQgbGlrZSB0byBlbXB0eS5cbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHN1Y2Nlc3MgbWVzc2FnZSBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBFbXB0eSBidWNrZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5lbXB0eUJ1Y2tldCgnYXZhdGFycycpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwibWVzc2FnZVwiOiBcIlN1Y2Nlc3NmdWxseSBlbXB0aWVkXCJcbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFJMUyBwb2xpY3kgcGVybWlzc2lvbnMgcmVxdWlyZWQ6XG4gICAqICAgLSBgYnVja2V0c2AgdGFibGUgcGVybWlzc2lvbnM6IGBzZWxlY3RgXG4gICAqICAgLSBgb2JqZWN0c2AgdGFibGUgcGVybWlzc2lvbnM6IGBzZWxlY3RgIGFuZCBgZGVsZXRlYFxuICAgKiAtIFJlZmVyIHRvIHRoZSBbU3RvcmFnZSBndWlkZV0oL2RvY3MvZ3VpZGVzL3N0b3JhZ2Uvc2VjdXJpdHkvYWNjZXNzLWNvbnRyb2wpIG9uIGhvdyBhY2Nlc3MgY29udHJvbCB3b3Jrc1xuICAgKi9cbiAgYXN5bmMgZW1wdHlCdWNrZXQoaWQ6IHN0cmluZyk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHsgbWVzc2FnZTogc3RyaW5nIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gICAgICB9XG4gID4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gYXdhaXQgcG9zdCh0aGlzLmZldGNoLCBgJHt0aGlzLnVybH0vYnVja2V0LyR7aWR9L2VtcHR5YCwge30sIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH0pXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGVzIGFuIGV4aXN0aW5nIGJ1Y2tldC4gQSBidWNrZXQgY2FuJ3QgYmUgZGVsZXRlZCB3aXRoIGV4aXN0aW5nIG9iamVjdHMgaW5zaWRlIGl0LlxuICAgKiBZb3UgbXVzdCBmaXJzdCBgZW1wdHkoKWAgdGhlIGJ1Y2tldC5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEZpbGUgQnVja2V0c1xuICAgKiBAcGFyYW0gaWQgVGhlIHVuaXF1ZSBpZGVudGlmaWVyIG9mIHRoZSBidWNrZXQgeW91IHdvdWxkIGxpa2UgdG8gZGVsZXRlLlxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggc3VjY2VzcyBtZXNzYWdlIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIERlbGV0ZSBidWNrZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5kZWxldGVCdWNrZXQoJ2F2YXRhcnMnKVxuICAgKiBgYGBcbiAgICpcbiAgICogUmVzcG9uc2U6XG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcIm1lc3NhZ2VcIjogXCJTdWNjZXNzZnVsbHkgZGVsZXRlZFwiXG4gICAqICAgfSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSTFMgcG9saWN5IHBlcm1pc3Npb25zIHJlcXVpcmVkOlxuICAgKiAgIC0gYGJ1Y2tldHNgIHRhYmxlIHBlcm1pc3Npb25zOiBgc2VsZWN0YCBhbmQgYGRlbGV0ZWBcbiAgICogICAtIGBvYmplY3RzYCB0YWJsZSBwZXJtaXNzaW9uczogbm9uZVxuICAgKiAtIFJlZmVyIHRvIHRoZSBbU3RvcmFnZSBndWlkZV0oL2RvY3MvZ3VpZGVzL3N0b3JhZ2Uvc2VjdXJpdHkvYWNjZXNzLWNvbnRyb2wpIG9uIGhvdyBhY2Nlc3MgY29udHJvbCB3b3Jrc1xuICAgKi9cbiAgYXN5bmMgZGVsZXRlQnVja2V0KGlkOiBzdHJpbmcpOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiB7IG1lc3NhZ2U6IHN0cmluZyB9XG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgICB9XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IG51bGxcbiAgICAgICAgZXJyb3I6IFN0b3JhZ2VFcnJvclxuICAgICAgfVxuICA+IHtcbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgcmV0dXJuIGF3YWl0IHJlbW92ZSh0aGlzLmZldGNoLCBgJHt0aGlzLnVybH0vYnVja2V0LyR7aWR9YCwge30sIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH0pXG4gICAgfSlcbiAgfVxuXG4gIHByaXZhdGUgbGlzdEJ1Y2tldE9wdGlvbnNUb1F1ZXJ5U3RyaW5nKG9wdGlvbnM/OiBMaXN0QnVja2V0T3B0aW9ucyk6IHN0cmluZyB7XG4gICAgY29uc3QgcGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge31cbiAgICBpZiAob3B0aW9ucykge1xuICAgICAgaWYgKCdsaW1pdCcgaW4gb3B0aW9ucykge1xuICAgICAgICBwYXJhbXMubGltaXQgPSBTdHJpbmcob3B0aW9ucy5saW1pdClcbiAgICAgIH1cbiAgICAgIGlmICgnb2Zmc2V0JyBpbiBvcHRpb25zKSB7XG4gICAgICAgIHBhcmFtcy5vZmZzZXQgPSBTdHJpbmcob3B0aW9ucy5vZmZzZXQpXG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5zZWFyY2gpIHtcbiAgICAgICAgcGFyYW1zLnNlYXJjaCA9IG9wdGlvbnMuc2VhcmNoXG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5zb3J0Q29sdW1uKSB7XG4gICAgICAgIHBhcmFtcy5zb3J0Q29sdW1uID0gb3B0aW9ucy5zb3J0Q29sdW1uXG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5zb3J0T3JkZXIpIHtcbiAgICAgICAgcGFyYW1zLnNvcnRPcmRlciA9IG9wdGlvbnMuc29ydE9yZGVyXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBPYmplY3Qua2V5cyhwYXJhbXMpLmxlbmd0aCA+IDAgPyAnPycgKyBuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcykudG9TdHJpbmcoKSA6ICcnXG4gIH1cbn1cbiIsImltcG9ydCB7IEljZWJlcmdSZXN0Q2F0YWxvZywgSWNlYmVyZ0Vycm9yIH0gZnJvbSAnaWNlYmVyZy1qcydcbmltcG9ydCB7IERFRkFVTFRfSEVBREVSUyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBTdG9yYWdlRXJyb3IgfSBmcm9tICcuLi9saWIvY29tbW9uL2Vycm9ycydcbmltcG9ydCB7IEZldGNoLCBnZXQsIHBvc3QsIHJlbW92ZSB9IGZyb20gJy4uL2xpYi9jb21tb24vZmV0Y2gnXG5pbXBvcnQgeyBpc1ZhbGlkQnVja2V0TmFtZSB9IGZyb20gJy4uL2xpYi9jb21tb24vaGVscGVycydcbmltcG9ydCBCYXNlQXBpQ2xpZW50IGZyb20gJy4uL2xpYi9jb21tb24vQmFzZUFwaUNsaWVudCdcbmltcG9ydCB7IEFuYWx5dGljQnVja2V0IH0gZnJvbSAnLi4vbGliL3R5cGVzJ1xuXG50eXBlIFdyYXBBc3luY01ldGhvZDxUPiA9IFQgZXh0ZW5kcyAoLi4uYXJnczogaW5mZXIgQSkgPT4gUHJvbWlzZTxpbmZlciBSPlxuICA/ICguLi5hcmdzOiBBKSA9PiBQcm9taXNlPHsgZGF0YTogUjsgZXJyb3I6IG51bGwgfSB8IHsgZGF0YTogbnVsbDsgZXJyb3I6IEljZWJlcmdFcnJvciB9PlxuICA6IFRcblxuZXhwb3J0IHR5cGUgV3JhcHBlZEljZWJlcmdSZXN0Q2F0YWxvZyA9IHtcbiAgW0sgaW4ga2V5b2YgSWNlYmVyZ1Jlc3RDYXRhbG9nXTogV3JhcEFzeW5jTWV0aG9kPEljZWJlcmdSZXN0Q2F0YWxvZ1tLXT5cbn1cblxuLyoqXG4gKiBDbGllbnQgY2xhc3MgZm9yIG1hbmFnaW5nIEFuYWx5dGljcyBCdWNrZXRzIHVzaW5nIEljZWJlcmcgdGFibGVzXG4gKiBQcm92aWRlcyBtZXRob2RzIGZvciBjcmVhdGluZywgbGlzdGluZywgYW5kIGRlbGV0aW5nIGFuYWx5dGljcyBidWNrZXRzXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFN0b3JhZ2VBbmFseXRpY3NDbGllbnQgZXh0ZW5kcyBCYXNlQXBpQ2xpZW50PFN0b3JhZ2VFcnJvcj4ge1xuICAvKipcbiAgICogQGFscGhhXG4gICAqXG4gICAqIENyZWF0ZXMgYSBuZXcgU3RvcmFnZUFuYWx5dGljc0NsaWVudCBpbnN0YW5jZVxuICAgKlxuICAgKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgQW5hbHl0aWNzIEJ1Y2tldHNcbiAgICogQHBhcmFtIHVybCAtIFRoZSBiYXNlIFVSTCBmb3IgdGhlIHN0b3JhZ2UgQVBJXG4gICAqIEBwYXJhbSBoZWFkZXJzIC0gSFRUUCBoZWFkZXJzIHRvIGluY2x1ZGUgaW4gcmVxdWVzdHNcbiAgICogQHBhcmFtIGZldGNoIC0gT3B0aW9uYWwgY3VzdG9tIGZldGNoIGltcGxlbWVudGF0aW9uXG4gICAqXG4gICAqIEBleGFtcGxlIFVzaW5nIHN1cGFiYXNlLWpzIChyZWNvbW1lbmRlZClcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqXG4gICAqIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28nLCAneW91ci1wdWJsaXNoYWJsZS1rZXknKVxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlLmFuYWx5dGljcy5saXN0QnVja2V0cygpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTdGFuZGFsb25lIGltcG9ydCBmb3IgYnVuZGxlLXNlbnNpdGl2ZSBlbnZpcm9ubWVudHNcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBpbXBvcnQgeyBTdG9yYWdlQW5hbHl0aWNzQ2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3N0b3JhZ2UtanMnXG4gICAqXG4gICAqIGNvbnN0IGNsaWVudCA9IG5ldyBTdG9yYWdlQW5hbHl0aWNzQ2xpZW50KHVybCwgaGVhZGVycylcbiAgICogYGBgXG4gICAqL1xuICBjb25zdHJ1Y3Rvcih1cmw6IHN0cmluZywgaGVhZGVyczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9LCBmZXRjaD86IEZldGNoKSB7XG4gICAgY29uc3QgZmluYWxVcmwgPSB1cmwucmVwbGFjZSgvXFwvJC8sICcnKVxuICAgIGNvbnN0IGZpbmFsSGVhZGVycyA9IHsgLi4uREVGQVVMVF9IRUFERVJTLCAuLi5oZWFkZXJzIH1cbiAgICBzdXBlcihmaW5hbFVybCwgZmluYWxIZWFkZXJzLCBmZXRjaCwgJ3N0b3JhZ2UnKVxuICB9XG5cbiAgLyoqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBDcmVhdGVzIGEgbmV3IGFuYWx5dGljcyBidWNrZXQgdXNpbmcgSWNlYmVyZyB0YWJsZXNcbiAgICogQW5hbHl0aWNzIGJ1Y2tldHMgYXJlIG9wdGltaXplZCBmb3IgYW5hbHl0aWNhbCBxdWVyaWVzIGFuZCBkYXRhIHByb2Nlc3NpbmdcbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEFuYWx5dGljcyBCdWNrZXRzXG4gICAqIEBwYXJhbSBuYW1lIEEgdW5pcXVlIG5hbWUgZm9yIHRoZSBidWNrZXQgeW91IGFyZSBjcmVhdGluZ1xuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcmVzcG9uc2UgY29udGFpbmluZyBuZXdseSBjcmVhdGVkIGFuYWx5dGljcyBidWNrZXQgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgQ3JlYXRlIGFuYWx5dGljcyBidWNrZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5hbmFseXRpY3NcbiAgICogICAuY3JlYXRlQnVja2V0KCdhbmFseXRpY3MtZGF0YScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwibmFtZVwiOiBcImFuYWx5dGljcy1kYXRhXCIsXG4gICAqICAgICBcInR5cGVcIjogXCJBTkFMWVRJQ1NcIixcbiAgICogICAgIFwiZm9ybWF0XCI6IFwiaWNlYmVyZ1wiLFxuICAgKiAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wNS0yMlQyMjoyNjowNS4xMDBaXCIsXG4gICAqICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTA1LTIyVDIyOjI2OjA1LjEwMFpcIlxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gQ3JlYXRlcyBhIG5ldyBhbmFseXRpY3MgYnVja2V0IHVzaW5nIEljZWJlcmcgdGFibGVzXG4gICAqIC0gQW5hbHl0aWNzIGJ1Y2tldHMgYXJlIG9wdGltaXplZCBmb3IgYW5hbHl0aWNhbCBxdWVyaWVzIGFuZCBkYXRhIHByb2Nlc3NpbmdcbiAgICovXG4gIGFzeW5jIGNyZWF0ZUJ1Y2tldChuYW1lOiBzdHJpbmcpOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiBBbmFseXRpY0J1Y2tldFxuICAgICAgICBlcnJvcjogbnVsbFxuICAgICAgfVxuICAgIHwge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIGVycm9yOiBTdG9yYWdlRXJyb3JcbiAgICAgIH1cbiAgPiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIHJldHVybiBhd2FpdCBwb3N0KHRoaXMuZmV0Y2gsIGAke3RoaXMudXJsfS9idWNrZXRgLCB7IG5hbWUgfSwgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfSlcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBSZXRyaWV2ZXMgdGhlIGRldGFpbHMgb2YgYWxsIEFuYWx5dGljcyBTdG9yYWdlIGJ1Y2tldHMgd2l0aGluIGFuIGV4aXN0aW5nIHByb2plY3RcbiAgICogT25seSByZXR1cm5zIGJ1Y2tldHMgb2YgdHlwZSAnQU5BTFlUSUNTJ1xuICAgKlxuICAgKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgQW5hbHl0aWNzIEJ1Y2tldHNcbiAgICogQHBhcmFtIG9wdGlvbnMgUXVlcnkgcGFyYW1ldGVycyBmb3IgbGlzdGluZyBidWNrZXRzXG4gICAqIEBwYXJhbSBvcHRpb25zLmxpbWl0IE1heGltdW0gbnVtYmVyIG9mIGJ1Y2tldHMgdG8gcmV0dXJuXG4gICAqIEBwYXJhbSBvcHRpb25zLm9mZnNldCBOdW1iZXIgb2YgYnVja2V0cyB0byBza2lwXG4gICAqIEBwYXJhbSBvcHRpb25zLnNvcnRDb2x1bW4gQ29sdW1uIHRvIHNvcnQgYnkgKCduYW1lJywgJ2NyZWF0ZWRfYXQnLCAndXBkYXRlZF9hdCcpXG4gICAqIEBwYXJhbSBvcHRpb25zLnNvcnRPcmRlciBTb3J0IG9yZGVyICgnYXNjJyBvciAnZGVzYycpXG4gICAqIEBwYXJhbSBvcHRpb25zLnNlYXJjaCBTZWFyY2ggdGVybSB0byBmaWx0ZXIgYnVja2V0IG5hbWVzXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIGFycmF5IG9mIGFuYWx5dGljcyBidWNrZXRzIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3QgYW5hbHl0aWNzIGJ1Y2tldHNcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5hbmFseXRpY3NcbiAgICogICAubGlzdEJ1Y2tldHMoe1xuICAgKiAgICAgbGltaXQ6IDEwLFxuICAgKiAgICAgb2Zmc2V0OiAwLFxuICAgKiAgICAgc29ydENvbHVtbjogJ2NyZWF0ZWRfYXQnLFxuICAgKiAgICAgc29ydE9yZGVyOiAnZGVzYydcbiAgICogICB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogUmVzcG9uc2U6XG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwiZGF0YVwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwibmFtZVwiOiBcImFuYWx5dGljcy1kYXRhXCIsXG4gICAqICAgICAgIFwidHlwZVwiOiBcIkFOQUxZVElDU1wiLFxuICAgKiAgICAgICBcImZvcm1hdFwiOiBcImljZWJlcmdcIixcbiAgICogICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wNS0yMlQyMjoyNjowNS4xMDBaXCIsXG4gICAqICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDUtMjJUMjI6MjY6MDUuMTAwWlwiXG4gICAqICAgICB9XG4gICAqICAgXSxcbiAgICogICBcImVycm9yXCI6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBSZXRyaWV2ZXMgdGhlIGRldGFpbHMgb2YgYWxsIEFuYWx5dGljcyBTdG9yYWdlIGJ1Y2tldHMgd2l0aGluIGFuIGV4aXN0aW5nIHByb2plY3RcbiAgICogLSBPbmx5IHJldHVybnMgYnVja2V0cyBvZiB0eXBlICdBTkFMWVRJQ1MnXG4gICAqL1xuICBhc3luYyBsaXN0QnVja2V0cyhvcHRpb25zPzoge1xuICAgIGxpbWl0PzogbnVtYmVyXG4gICAgb2Zmc2V0PzogbnVtYmVyXG4gICAgc29ydENvbHVtbj86ICduYW1lJyB8ICdjcmVhdGVkX2F0JyB8ICd1cGRhdGVkX2F0J1xuICAgIHNvcnRPcmRlcj86ICdhc2MnIHwgJ2Rlc2MnXG4gICAgc2VhcmNoPzogc3RyaW5nXG4gIH0pOiBQcm9taXNlPFxuICAgIHwge1xuICAgICAgICBkYXRhOiBBbmFseXRpY0J1Y2tldFtdXG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgICB9XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IG51bGxcbiAgICAgICAgZXJyb3I6IFN0b3JhZ2VFcnJvclxuICAgICAgfVxuICA+IHtcbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgLy8gQnVpbGQgcXVlcnkgc3RyaW5nIGZyb20gb3B0aW9uc1xuICAgICAgY29uc3QgcXVlcnlQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKClcbiAgICAgIGlmIChvcHRpb25zPy5saW1pdCAhPT0gdW5kZWZpbmVkKSBxdWVyeVBhcmFtcy5zZXQoJ2xpbWl0Jywgb3B0aW9ucy5saW1pdC50b1N0cmluZygpKVxuICAgICAgaWYgKG9wdGlvbnM/Lm9mZnNldCAhPT0gdW5kZWZpbmVkKSBxdWVyeVBhcmFtcy5zZXQoJ29mZnNldCcsIG9wdGlvbnMub2Zmc2V0LnRvU3RyaW5nKCkpXG4gICAgICBpZiAob3B0aW9ucz8uc29ydENvbHVtbikgcXVlcnlQYXJhbXMuc2V0KCdzb3J0Q29sdW1uJywgb3B0aW9ucy5zb3J0Q29sdW1uKVxuICAgICAgaWYgKG9wdGlvbnM/LnNvcnRPcmRlcikgcXVlcnlQYXJhbXMuc2V0KCdzb3J0T3JkZXInLCBvcHRpb25zLnNvcnRPcmRlcilcbiAgICAgIGlmIChvcHRpb25zPy5zZWFyY2gpIHF1ZXJ5UGFyYW1zLnNldCgnc2VhcmNoJywgb3B0aW9ucy5zZWFyY2gpXG5cbiAgICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gcXVlcnlQYXJhbXMudG9TdHJpbmcoKVxuICAgICAgY29uc3QgdXJsID0gcXVlcnlTdHJpbmcgPyBgJHt0aGlzLnVybH0vYnVja2V0PyR7cXVlcnlTdHJpbmd9YCA6IGAke3RoaXMudXJsfS9idWNrZXRgXG5cbiAgICAgIHJldHVybiBhd2FpdCBnZXQodGhpcy5mZXRjaCwgdXJsLCB7IGhlYWRlcnM6IHRoaXMuaGVhZGVycyB9KVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQGFscGhhXG4gICAqXG4gICAqIERlbGV0ZXMgYW4gZXhpc3RpbmcgYW5hbHl0aWNzIGJ1Y2tldFxuICAgKiBBIGJ1Y2tldCBjYW4ndCBiZSBkZWxldGVkIHdpdGggZXhpc3Rpbmcgb2JqZWN0cyBpbnNpZGUgaXRcbiAgICogWW91IG11c3QgZmlyc3QgZW1wdHkgdGhlIGJ1Y2tldCBiZWZvcmUgZGVsZXRpb25cbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEFuYWx5dGljcyBCdWNrZXRzXG4gICAqIEBwYXJhbSBidWNrZXROYW1lIFRoZSB1bmlxdWUgaWRlbnRpZmllciBvZiB0aGUgYnVja2V0IHlvdSB3b3VsZCBsaWtlIHRvIGRlbGV0ZVxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcmVzcG9uc2UgY29udGFpbmluZyBzdWNjZXNzIG1lc3NhZ2Ugb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgRGVsZXRlIGFuYWx5dGljcyBidWNrZXRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5hbmFseXRpY3NcbiAgICogICAuZGVsZXRlQnVja2V0KCdhbmFseXRpY3MtZGF0YScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBSZXNwb25zZTpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwibWVzc2FnZVwiOiBcIlN1Y2Nlc3NmdWxseSBkZWxldGVkXCJcbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIERlbGV0ZXMgYW4gYW5hbHl0aWNzIGJ1Y2tldFxuICAgKi9cbiAgYXN5bmMgZGVsZXRlQnVja2V0KGJ1Y2tldE5hbWU6IHN0cmluZyk6IFByb21pc2U8XG4gICAgfCB7XG4gICAgICAgIGRhdGE6IHsgbWVzc2FnZTogc3RyaW5nIH1cbiAgICAgICAgZXJyb3I6IG51bGxcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICBlcnJvcjogU3RvcmFnZUVycm9yXG4gICAgICB9XG4gID4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gYXdhaXQgcmVtb3ZlKFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vYnVja2V0LyR7YnVja2V0TmFtZX1gLFxuICAgICAgICB7fSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQGFscGhhXG4gICAqXG4gICAqIEdldCBhbiBJY2ViZXJnIFJFU1QgQ2F0YWxvZyBjbGllbnQgY29uZmlndXJlZCBmb3IgYSBzcGVjaWZpYyBhbmFseXRpY3MgYnVja2V0XG4gICAqIFVzZSB0aGlzIHRvIHBlcmZvcm0gYWR2YW5jZWQgdGFibGUgYW5kIG5hbWVzcGFjZSBvcGVyYXRpb25zIHdpdGhpbiB0aGUgYnVja2V0XG4gICAqIFRoZSByZXR1cm5lZCBjbGllbnQgcHJvdmlkZXMgZnVsbCBhY2Nlc3MgdG8gdGhlIEFwYWNoZSBJY2ViZXJnIFJFU1QgQ2F0YWxvZyBBUElcbiAgICogd2l0aCB0aGUgU3VwYWJhc2UgYHsgZGF0YSwgZXJyb3IgfWAgcGF0dGVybiBmb3IgY29uc2lzdGVudCBlcnJvciBoYW5kbGluZyBvbiBhbGwgb3BlcmF0aW9ucy5cbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEFuYWx5dGljcyBCdWNrZXRzXG4gICAqIEBwYXJhbSBidWNrZXROYW1lIC0gVGhlIG5hbWUgb2YgdGhlIGFuYWx5dGljcyBidWNrZXQgKHdhcmVob3VzZSkgdG8gY29ubmVjdCB0b1xuICAgKiBAcmV0dXJucyBUaGUgd3JhcHBlZCBJY2ViZXJnIGNhdGFsb2cgY2xpZW50XG4gICAqIEB0aHJvd3Mge1N0b3JhZ2VFcnJvcn0gSWYgdGhlIGJ1Y2tldCBuYW1lIGlzIGludmFsaWRcbiAgICpcbiAgICogQGV4YW1wbGUgR2V0IGNhdGFsb2cgYW5kIGNyZWF0ZSB0YWJsZVxuICAgKiBgYGBqc1xuICAgKiAvLyBGaXJzdCwgY3JlYXRlIGFuIGFuYWx5dGljcyBidWNrZXRcbiAgICogY29uc3QgeyBkYXRhOiBidWNrZXQsIGVycm9yOiBidWNrZXRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC5hbmFseXRpY3NcbiAgICogICAuY3JlYXRlQnVja2V0KCdhbmFseXRpY3MtZGF0YScpXG4gICAqXG4gICAqIC8vIEdldCB0aGUgSWNlYmVyZyBjYXRhbG9nIGZvciB0aGF0IGJ1Y2tldFxuICAgKiBjb25zdCBjYXRhbG9nID0gc3VwYWJhc2Uuc3RvcmFnZS5hbmFseXRpY3MuZnJvbSgnYW5hbHl0aWNzLWRhdGEnKVxuICAgKlxuICAgKiAvLyBDcmVhdGUgYSBuYW1lc3BhY2VcbiAgICogY29uc3QgeyBlcnJvcjogbnNFcnJvciB9ID0gYXdhaXQgY2F0YWxvZy5jcmVhdGVOYW1lc3BhY2UoeyBuYW1lc3BhY2U6IFsnZGVmYXVsdCddIH0pXG4gICAqXG4gICAqIC8vIENyZWF0ZSBhIHRhYmxlIHdpdGggc2NoZW1hXG4gICAqIGNvbnN0IHsgZGF0YTogdGFibGVNZXRhZGF0YSwgZXJyb3I6IHRhYmxlRXJyb3IgfSA9IGF3YWl0IGNhdGFsb2cuY3JlYXRlVGFibGUoXG4gICAqICAgeyBuYW1lc3BhY2U6IFsnZGVmYXVsdCddIH0sXG4gICAqICAge1xuICAgKiAgICAgbmFtZTogJ2V2ZW50cycsXG4gICAqICAgICBzY2hlbWE6IHtcbiAgICogICAgICAgdHlwZTogJ3N0cnVjdCcsXG4gICAqICAgICAgIGZpZWxkczogW1xuICAgKiAgICAgICAgIHsgaWQ6IDEsIG5hbWU6ICdpZCcsIHR5cGU6ICdsb25nJywgcmVxdWlyZWQ6IHRydWUgfSxcbiAgICogICAgICAgICB7IGlkOiAyLCBuYW1lOiAndGltZXN0YW1wJywgdHlwZTogJ3RpbWVzdGFtcCcsIHJlcXVpcmVkOiB0cnVlIH0sXG4gICAqICAgICAgICAgeyBpZDogMywgbmFtZTogJ3VzZXJfaWQnLCB0eXBlOiAnc3RyaW5nJywgcmVxdWlyZWQ6IGZhbHNlIH1cbiAgICogICAgICAgXSxcbiAgICogICAgICAgJ3NjaGVtYS1pZCc6IDAsXG4gICAqICAgICAgICdpZGVudGlmaWVyLWZpZWxkLWlkcyc6IFsxXVxuICAgKiAgICAgfSxcbiAgICogICAgICdwYXJ0aXRpb24tc3BlYyc6IHtcbiAgICogICAgICAgJ3NwZWMtaWQnOiAwLFxuICAgKiAgICAgICBmaWVsZHM6IFtdXG4gICAqICAgICB9LFxuICAgKiAgICAgJ3dyaXRlLW9yZGVyJzoge1xuICAgKiAgICAgICAnb3JkZXItaWQnOiAwLFxuICAgKiAgICAgICBmaWVsZHM6IFtdXG4gICAqICAgICB9LFxuICAgKiAgICAgcHJvcGVydGllczoge1xuICAgKiAgICAgICAnd3JpdGUuZm9ybWF0LmRlZmF1bHQnOiAncGFycXVldCdcbiAgICogICAgIH1cbiAgICogICB9XG4gICAqIClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3QgdGFibGVzIGluIG5hbWVzcGFjZVxuICAgKiBgYGBqc1xuICAgKiBjb25zdCBjYXRhbG9nID0gc3VwYWJhc2Uuc3RvcmFnZS5hbmFseXRpY3MuZnJvbSgnYW5hbHl0aWNzLWRhdGEnKVxuICAgKlxuICAgKiAvLyBMaXN0IGFsbCB0YWJsZXMgaW4gdGhlIGRlZmF1bHQgbmFtZXNwYWNlXG4gICAqIGNvbnN0IHsgZGF0YTogdGFibGVzLCBlcnJvcjogbGlzdEVycm9yIH0gPSBhd2FpdCBjYXRhbG9nLmxpc3RUYWJsZXMoeyBuYW1lc3BhY2U6IFsnZGVmYXVsdCddIH0pXG4gICAqIGlmIChsaXN0RXJyb3IpIHtcbiAgICogICBpZiAobGlzdEVycm9yLmlzTm90Rm91bmQoKSkge1xuICAgKiAgICAgY29uc29sZS5sb2coJ05hbWVzcGFjZSBub3QgZm91bmQnKVxuICAgKiAgIH1cbiAgICogICByZXR1cm5cbiAgICogfVxuICAgKiBjb25zb2xlLmxvZyh0YWJsZXMpIC8vIFt7IG5hbWVzcGFjZTogWydkZWZhdWx0J10sIG5hbWU6ICdldmVudHMnIH1dXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBXb3JraW5nIHdpdGggbmFtZXNwYWNlc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCBjYXRhbG9nID0gc3VwYWJhc2Uuc3RvcmFnZS5hbmFseXRpY3MuZnJvbSgnYW5hbHl0aWNzLWRhdGEnKVxuICAgKlxuICAgKiAvLyBMaXN0IGFsbCBuYW1lc3BhY2VzXG4gICAqIGNvbnN0IHsgZGF0YTogbmFtZXNwYWNlcyB9ID0gYXdhaXQgY2F0YWxvZy5saXN0TmFtZXNwYWNlcygpXG4gICAqXG4gICAqIC8vIENyZWF0ZSBuYW1lc3BhY2Ugd2l0aCBwcm9wZXJ0aWVzXG4gICAqIGF3YWl0IGNhdGFsb2cuY3JlYXRlTmFtZXNwYWNlKFxuICAgKiAgIHsgbmFtZXNwYWNlOiBbJ3Byb2R1Y3Rpb24nXSB9LFxuICAgKiAgIHsgcHJvcGVydGllczogeyBvd25lcjogJ2RhdGEtdGVhbScsIGVudjogJ3Byb2QnIH0gfVxuICAgKiApXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBDbGVhbnVwIG9wZXJhdGlvbnNcbiAgICogYGBganNcbiAgICogY29uc3QgY2F0YWxvZyA9IHN1cGFiYXNlLnN0b3JhZ2UuYW5hbHl0aWNzLmZyb20oJ2FuYWx5dGljcy1kYXRhJylcbiAgICpcbiAgICogLy8gRHJvcCB0YWJsZSB3aXRoIHB1cmdlIG9wdGlvbiAocmVtb3ZlcyBhbGwgZGF0YSlcbiAgICogY29uc3QgeyBlcnJvcjogZHJvcEVycm9yIH0gPSBhd2FpdCBjYXRhbG9nLmRyb3BUYWJsZShcbiAgICogICB7IG5hbWVzcGFjZTogWydkZWZhdWx0J10sIG5hbWU6ICdldmVudHMnIH0sXG4gICAqICAgeyBwdXJnZTogdHJ1ZSB9XG4gICAqIClcbiAgICpcbiAgICogaWYgKGRyb3BFcnJvcj8uaXNOb3RGb3VuZCgpKSB7XG4gICAqICAgY29uc29sZS5sb2coJ1RhYmxlIGRvZXMgbm90IGV4aXN0JylcbiAgICogfVxuICAgKlxuICAgKiAvLyBEcm9wIG5hbWVzcGFjZSAobXVzdCBiZSBlbXB0eSlcbiAgICogYXdhaXQgY2F0YWxvZy5kcm9wTmFtZXNwYWNlKHsgbmFtZXNwYWNlOiBbJ2RlZmF1bHQnXSB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogVGhpcyBtZXRob2QgcHJvdmlkZXMgYSBicmlkZ2UgYmV0d2VlbiBTdXBhYmFzZSdzIGJ1Y2tldCBtYW5hZ2VtZW50IGFuZCB0aGUgc3RhbmRhcmRcbiAgICogQXBhY2hlIEljZWJlcmcgUkVTVCBDYXRhbG9nIEFQSS4gVGhlIGJ1Y2tldCBuYW1lIG1hcHMgdG8gdGhlIEljZWJlcmcgd2FyZWhvdXNlIHBhcmFtZXRlci5cbiAgICogQWxsIGF1dGhlbnRpY2F0aW9uIGFuZCBjb25maWd1cmF0aW9uIGlzIGhhbmRsZWQgYXV0b21hdGljYWxseSB1c2luZyB5b3VyIFN1cGFiYXNlIGNyZWRlbnRpYWxzLlxuICAgKlxuICAgKiAqKkVycm9yIEhhbmRsaW5nKio6IEludmFsaWQgYnVja2V0IG5hbWVzIHRocm93IGltbWVkaWF0ZWx5LiBBbGwgY2F0YWxvZ1xuICAgKiBvcGVyYXRpb25zIHJldHVybiBgeyBkYXRhLCBlcnJvciB9YCB3aGVyZSBlcnJvcnMgYXJlIGBJY2ViZXJnRXJyb3JgIGluc3RhbmNlcyBmcm9tIGljZWJlcmctanMuXG4gICAqIFVzZSBoZWxwZXIgbWV0aG9kcyBsaWtlIGBlcnJvci5pc05vdEZvdW5kKClgIG9yIGNoZWNrIGBlcnJvci5zdGF0dXNgIGZvciBzcGVjaWZpYyBlcnJvciBoYW5kbGluZy5cbiAgICogVXNlIGAudGhyb3dPbkVycm9yKClgIG9uIHRoZSBhbmFseXRpY3MgY2xpZW50IGlmIHlvdSBwcmVmZXIgZXhjZXB0aW9ucyBmb3IgY2F0YWxvZyBvcGVyYXRpb25zLlxuICAgKlxuICAgKiAqKkNsZWFudXAgT3BlcmF0aW9ucyoqOiBXaGVuIHVzaW5nIGBkcm9wVGFibGVgLCB0aGUgYHB1cmdlOiB0cnVlYCBvcHRpb24gcGVybWFuZW50bHlcbiAgICogZGVsZXRlcyBhbGwgdGFibGUgZGF0YS4gV2l0aG91dCBpdCwgdGhlIHRhYmxlIGlzIG1hcmtlZCBhcyBkZWxldGVkIGJ1dCBkYXRhIHJlbWFpbnMuXG4gICAqXG4gICAqICoqTGlicmFyeSBEZXBlbmRlbmN5Kio6IFRoZSByZXR1cm5lZCBjYXRhbG9nIHdyYXBzIGBJY2ViZXJnUmVzdENhdGFsb2dgIGZyb20gaWNlYmVyZy1qcy5cbiAgICogRm9yIGNvbXBsZXRlIEFQSSBkb2N1bWVudGF0aW9uIGFuZCBhZHZhbmNlZCB1c2FnZSwgcmVmZXIgdG8gdGhlXG4gICAqIFtpY2ViZXJnLWpzIGRvY3VtZW50YXRpb25dKGh0dHBzOi8vc3VwYWJhc2UuZ2l0aHViLmlvL2ljZWJlcmctanMvKS5cbiAgICovXG4gIGZyb20oYnVja2V0TmFtZTogc3RyaW5nKTogV3JhcHBlZEljZWJlcmdSZXN0Q2F0YWxvZyB7XG4gICAgLy8gVmFsaWRhdGUgYnVja2V0IG5hbWUgdXNpbmcgc2FtZSBydWxlcyBhcyBTdXBhYmFzZSBTdG9yYWdlIEFQSSBiYWNrZW5kXG4gICAgaWYgKCFpc1ZhbGlkQnVja2V0TmFtZShidWNrZXROYW1lKSkge1xuICAgICAgdGhyb3cgbmV3IFN0b3JhZ2VFcnJvcihcbiAgICAgICAgJ0ludmFsaWQgYnVja2V0IG5hbWU6IEZpbGUsIGZvbGRlciwgYW5kIGJ1Y2tldCBuYW1lcyBtdXN0IGZvbGxvdyBBV1Mgb2JqZWN0IGtleSBuYW1pbmcgZ3VpZGVsaW5lcyAnICtcbiAgICAgICAgICAnYW5kIHNob3VsZCBhdm9pZCB0aGUgdXNlIG9mIGFueSBvdGhlciBjaGFyYWN0ZXJzLidcbiAgICAgIClcbiAgICB9XG5cbiAgICAvLyBDb25zdHJ1Y3QgdGhlIEljZWJlcmcgUkVTVCBDYXRhbG9nIFVSTFxuICAgIC8vIFRoZSBiYXNlIFVSTCBpcyAvc3RvcmFnZS92MS9pY2ViZXJnXG4gICAgLy8gTm90ZTogSWNlYmVyZ1Jlc3RDYXRhbG9nIGZyb20gaWNlYmVyZy1qcyBhdXRvbWF0aWNhbGx5IGFkZHMgL3YxLyBwcmVmaXggdG8gQVBJIHBhdGhzXG4gICAgLy8gc28gd2Ugc2hvdWxkIE5PVCBhcHBlbmQgL3YxIGhlcmUgKGl0IHdvdWxkIGNhdXNlIGRvdWJsZSAvdjEvdjEvIGluIHRoZSBVUkwpXG4gICAgY29uc3QgY2F0YWxvZyA9IG5ldyBJY2ViZXJnUmVzdENhdGFsb2coe1xuICAgICAgYmFzZVVybDogdGhpcy51cmwsXG4gICAgICBjYXRhbG9nTmFtZTogYnVja2V0TmFtZSwgLy8gTWFwcyB0byB0aGUgd2FyZWhvdXNlIHBhcmFtZXRlciBpbiBTdXBhYmFzZSdzIGltcGxlbWVudGF0aW9uXG4gICAgICBhdXRoOiB7XG4gICAgICAgIHR5cGU6ICdjdXN0b20nLFxuICAgICAgICBnZXRIZWFkZXJzOiBhc3luYyAoKSA9PiB0aGlzLmhlYWRlcnMsXG4gICAgICB9LFxuICAgICAgZmV0Y2g6IHRoaXMuZmV0Y2gsXG4gICAgfSlcblxuICAgIGNvbnN0IHNob3VsZFRocm93T25FcnJvciA9IHRoaXMuc2hvdWxkVGhyb3dPbkVycm9yXG5cbiAgICBjb25zdCB3cmFwcGVkQ2F0YWxvZyA9IG5ldyBQcm94eShjYXRhbG9nLCB7XG4gICAgICBnZXQodGFyZ2V0LCBwcm9wOiBrZXlvZiBJY2ViZXJnUmVzdENhdGFsb2cpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSB0YXJnZXRbcHJvcF1cbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgIHJldHVybiB2YWx1ZVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGFzeW5jICguLi5hcmdzOiB1bmtub3duW10pID0+IHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0ICh2YWx1ZSBhcyBGdW5jdGlvbikuYXBwbHkodGFyZ2V0LCBhcmdzKVxuICAgICAgICAgICAgcmV0dXJuIHsgZGF0YSwgZXJyb3I6IG51bGwgfVxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBpZiAoc2hvdWxkVGhyb3dPbkVycm9yKSB7XG4gICAgICAgICAgICAgIHRocm93IGVycm9yXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvcjogZXJyb3IgYXMgSWNlYmVyZ0Vycm9yIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSkgYXMgdW5rbm93biBhcyBXcmFwcGVkSWNlYmVyZ1Jlc3RDYXRhbG9nXG5cbiAgICByZXR1cm4gd3JhcHBlZENhdGFsb2dcbiAgfVxufVxuIiwiaW1wb3J0IHsgREVGQVVMVF9IRUFERVJTIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcbmltcG9ydCB7IFN0b3JhZ2VFcnJvciB9IGZyb20gJy4uL2xpYi9jb21tb24vZXJyb3JzJ1xuaW1wb3J0IHsgRmV0Y2gsIHZlY3RvcnNBcGkgfSBmcm9tICcuLi9saWIvY29tbW9uL2ZldGNoJ1xuaW1wb3J0IEJhc2VBcGlDbGllbnQgZnJvbSAnLi4vbGliL2NvbW1vbi9CYXNlQXBpQ2xpZW50J1xuaW1wb3J0IHtcbiAgQXBpUmVzcG9uc2UsXG4gIFZlY3RvckluZGV4LFxuICBMaXN0SW5kZXhlc09wdGlvbnMsXG4gIExpc3RJbmRleGVzUmVzcG9uc2UsXG4gIFZlY3RvckRhdGFUeXBlLFxuICBEaXN0YW5jZU1ldHJpYyxcbiAgTWV0YWRhdGFDb25maWd1cmF0aW9uLFxufSBmcm9tICcuLi9saWIvdHlwZXMnXG5cbi8qKlxuICogQGFscGhhXG4gKlxuICogT3B0aW9ucyBmb3IgY3JlYXRpbmcgYSB2ZWN0b3IgaW5kZXhcbiAqXG4gKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENyZWF0ZUluZGV4T3B0aW9ucyB7XG4gIHZlY3RvckJ1Y2tldE5hbWU6IHN0cmluZ1xuICBpbmRleE5hbWU6IHN0cmluZ1xuICBkYXRhVHlwZTogVmVjdG9yRGF0YVR5cGVcbiAgZGltZW5zaW9uOiBudW1iZXJcbiAgZGlzdGFuY2VNZXRyaWM6IERpc3RhbmNlTWV0cmljXG4gIG1ldGFkYXRhQ29uZmlndXJhdGlvbj86IE1ldGFkYXRhQ29uZmlndXJhdGlvblxufVxuXG4vKipcbiAqIEBoaWRkZW5cbiAqIEJhc2UgaW1wbGVtZW50YXRpb24gZm9yIHZlY3RvciBpbmRleCBvcGVyYXRpb25zLlxuICogVXNlIHtAbGluayBWZWN0b3JCdWNrZXRTY29wZX0gdmlhIGBzdXBhYmFzZS5zdG9yYWdlLnZlY3RvcnMuZnJvbSgnYnVja2V0JylgIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFZlY3RvckluZGV4QXBpIGV4dGVuZHMgQmFzZUFwaUNsaWVudDxTdG9yYWdlRXJyb3I+IHtcbiAgLyoqIENyZWF0ZXMgYSBuZXcgVmVjdG9ySW5kZXhBcGkgaW5zdGFuY2UgKi9cbiAgY29uc3RydWN0b3IodXJsOiBzdHJpbmcsIGhlYWRlcnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fSwgZmV0Y2g/OiBGZXRjaCkge1xuICAgIGNvbnN0IGZpbmFsVXJsID0gdXJsLnJlcGxhY2UoL1xcLyQvLCAnJylcbiAgICBjb25zdCBmaW5hbEhlYWRlcnMgPSB7IC4uLkRFRkFVTFRfSEVBREVSUywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJywgLi4uaGVhZGVycyB9XG4gICAgc3VwZXIoZmluYWxVcmwsIGZpbmFsSGVhZGVycywgZmV0Y2gsICd2ZWN0b3JzJylcbiAgfVxuXG4gIC8qKiBDcmVhdGVzIGEgbmV3IHZlY3RvciBpbmRleCB3aXRoaW4gYSBidWNrZXQgKi9cbiAgYXN5bmMgY3JlYXRlSW5kZXgob3B0aW9uczogQ3JlYXRlSW5kZXhPcHRpb25zKTogUHJvbWlzZTxBcGlSZXNwb25zZTx1bmRlZmluZWQ+PiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB2ZWN0b3JzQXBpLnBvc3QodGhpcy5mZXRjaCwgYCR7dGhpcy51cmx9L0NyZWF0ZUluZGV4YCwgb3B0aW9ucywge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICB9KVxuICAgICAgcmV0dXJuIGRhdGEgfHwge31cbiAgICB9KVxuICB9XG5cbiAgLyoqIFJldHJpZXZlcyBtZXRhZGF0YSBmb3IgYSBzcGVjaWZpYyB2ZWN0b3IgaW5kZXggKi9cbiAgYXN5bmMgZ2V0SW5kZXgoXG4gICAgdmVjdG9yQnVja2V0TmFtZTogc3RyaW5nLFxuICAgIGluZGV4TmFtZTogc3RyaW5nXG4gICk6IFByb21pc2U8QXBpUmVzcG9uc2U8eyBpbmRleDogVmVjdG9ySW5kZXggfT4+IHtcbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgcmV0dXJuIGF3YWl0IHZlY3RvcnNBcGkucG9zdChcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgYCR7dGhpcy51cmx9L0dldEluZGV4YCxcbiAgICAgICAgeyB2ZWN0b3JCdWNrZXROYW1lLCBpbmRleE5hbWUgfSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICAvKiogTGlzdHMgdmVjdG9yIGluZGV4ZXMgd2l0aGluIGEgYnVja2V0IHdpdGggb3B0aW9uYWwgZmlsdGVyaW5nIGFuZCBwYWdpbmF0aW9uICovXG4gIGFzeW5jIGxpc3RJbmRleGVzKG9wdGlvbnM6IExpc3RJbmRleGVzT3B0aW9ucyk6IFByb21pc2U8QXBpUmVzcG9uc2U8TGlzdEluZGV4ZXNSZXNwb25zZT4+IHtcbiAgICByZXR1cm4gdGhpcy5oYW5kbGVPcGVyYXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgcmV0dXJuIGF3YWl0IHZlY3RvcnNBcGkucG9zdCh0aGlzLmZldGNoLCBgJHt0aGlzLnVybH0vTGlzdEluZGV4ZXNgLCBvcHRpb25zLCB7XG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxuXG4gIC8qKiBEZWxldGVzIGEgdmVjdG9yIGluZGV4IGFuZCBhbGwgaXRzIGRhdGEgKi9cbiAgYXN5bmMgZGVsZXRlSW5kZXgodmVjdG9yQnVja2V0TmFtZTogc3RyaW5nLCBpbmRleE5hbWU6IHN0cmluZyk6IFByb21pc2U8QXBpUmVzcG9uc2U8dW5kZWZpbmVkPj4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgdmVjdG9yc0FwaS5wb3N0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vRGVsZXRlSW5kZXhgLFxuICAgICAgICB7IHZlY3RvckJ1Y2tldE5hbWUsIGluZGV4TmFtZSB9LFxuICAgICAgICB7IGhlYWRlcnM6IHRoaXMuaGVhZGVycyB9XG4gICAgICApXG4gICAgICByZXR1cm4gZGF0YSB8fCB7fVxuICAgIH0pXG4gIH1cbn1cbiIsImltcG9ydCB7IERFRkFVTFRfSEVBREVSUyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBTdG9yYWdlRXJyb3IgfSBmcm9tICcuLi9saWIvY29tbW9uL2Vycm9ycydcbmltcG9ydCB7IEZldGNoLCB2ZWN0b3JzQXBpIH0gZnJvbSAnLi4vbGliL2NvbW1vbi9mZXRjaCdcbmltcG9ydCBCYXNlQXBpQ2xpZW50IGZyb20gJy4uL2xpYi9jb21tb24vQmFzZUFwaUNsaWVudCdcbmltcG9ydCB7XG4gIEFwaVJlc3BvbnNlLFxuICBQdXRWZWN0b3JzT3B0aW9ucyxcbiAgR2V0VmVjdG9yc09wdGlvbnMsXG4gIEdldFZlY3RvcnNSZXNwb25zZSxcbiAgRGVsZXRlVmVjdG9yc09wdGlvbnMsXG4gIExpc3RWZWN0b3JzT3B0aW9ucyxcbiAgTGlzdFZlY3RvcnNSZXNwb25zZSxcbiAgUXVlcnlWZWN0b3JzT3B0aW9ucyxcbiAgUXVlcnlWZWN0b3JzUmVzcG9uc2UsXG59IGZyb20gJy4uL2xpYi90eXBlcydcblxuLyoqXG4gKiBAaGlkZGVuXG4gKiBCYXNlIGltcGxlbWVudGF0aW9uIGZvciB2ZWN0b3IgZGF0YSBvcGVyYXRpb25zLlxuICogVXNlIHtAbGluayBWZWN0b3JJbmRleFNjb3BlfSB2aWEgYHN1cGFiYXNlLnN0b3JhZ2UudmVjdG9ycy5mcm9tKCdidWNrZXQnKS5pbmRleCgnaWR4JylgIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFZlY3RvckRhdGFBcGkgZXh0ZW5kcyBCYXNlQXBpQ2xpZW50PFN0b3JhZ2VFcnJvcj4ge1xuICAvKiogQ3JlYXRlcyBhIG5ldyBWZWN0b3JEYXRhQXBpIGluc3RhbmNlICovXG4gIGNvbnN0cnVjdG9yKHVybDogc3RyaW5nLCBoZWFkZXJzOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge30sIGZldGNoPzogRmV0Y2gpIHtcbiAgICBjb25zdCBmaW5hbFVybCA9IHVybC5yZXBsYWNlKC9cXC8kLywgJycpXG4gICAgY29uc3QgZmluYWxIZWFkZXJzID0geyAuLi5ERUZBVUxUX0hFQURFUlMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIC4uLmhlYWRlcnMgfVxuICAgIHN1cGVyKGZpbmFsVXJsLCBmaW5hbEhlYWRlcnMsIGZldGNoLCAndmVjdG9ycycpXG4gIH1cblxuICAvKiogSW5zZXJ0cyBvciB1cGRhdGVzIHZlY3RvcnMgaW4gYmF0Y2ggKDEtNTAwIHBlciByZXF1ZXN0KSAqL1xuICBhc3luYyBwdXRWZWN0b3JzKG9wdGlvbnM6IFB1dFZlY3RvcnNPcHRpb25zKTogUHJvbWlzZTxBcGlSZXNwb25zZTx1bmRlZmluZWQ+PiB7XG4gICAgLy8gVmFsaWRhdGUgYmF0Y2ggc2l6ZVxuICAgIGlmIChvcHRpb25zLnZlY3RvcnMubGVuZ3RoIDwgMSB8fCBvcHRpb25zLnZlY3RvcnMubGVuZ3RoID4gNTAwKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1ZlY3RvciBiYXRjaCBzaXplIG11c3QgYmUgYmV0d2VlbiAxIGFuZCA1MDAgaXRlbXMnKVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgdmVjdG9yc0FwaS5wb3N0KHRoaXMuZmV0Y2gsIGAke3RoaXMudXJsfS9QdXRWZWN0b3JzYCwgb3B0aW9ucywge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICB9KVxuICAgICAgcmV0dXJuIGRhdGEgfHwge31cbiAgICB9KVxuICB9XG5cbiAgLyoqIFJldHJpZXZlcyB2ZWN0b3JzIGJ5IHRoZWlyIGtleXMgaW4gYmF0Y2ggKi9cbiAgYXN5bmMgZ2V0VmVjdG9ycyhvcHRpb25zOiBHZXRWZWN0b3JzT3B0aW9ucyk6IFByb21pc2U8QXBpUmVzcG9uc2U8R2V0VmVjdG9yc1Jlc3BvbnNlPj4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gYXdhaXQgdmVjdG9yc0FwaS5wb3N0KHRoaXMuZmV0Y2gsIGAke3RoaXMudXJsfS9HZXRWZWN0b3JzYCwgb3B0aW9ucywge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICB9KVxuICAgIH0pXG4gIH1cblxuICAvKiogTGlzdHMgdmVjdG9ycyBpbiBhbiBpbmRleCB3aXRoIHBhZ2luYXRpb24gKi9cbiAgYXN5bmMgbGlzdFZlY3RvcnMob3B0aW9uczogTGlzdFZlY3RvcnNPcHRpb25zKTogUHJvbWlzZTxBcGlSZXNwb25zZTxMaXN0VmVjdG9yc1Jlc3BvbnNlPj4ge1xuICAgIC8vIFZhbGlkYXRlIHNlZ21lbnQgY29uZmlndXJhdGlvblxuICAgIGlmIChvcHRpb25zLnNlZ21lbnRDb3VudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAob3B0aW9ucy5zZWdtZW50Q291bnQgPCAxIHx8IG9wdGlvbnMuc2VnbWVudENvdW50ID4gMTYpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdzZWdtZW50Q291bnQgbXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDE2JylcbiAgICAgIH1cbiAgICAgIGlmIChvcHRpb25zLnNlZ21lbnRJbmRleCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmIChvcHRpb25zLnNlZ21lbnRJbmRleCA8IDAgfHwgb3B0aW9ucy5zZWdtZW50SW5kZXggPj0gb3B0aW9ucy5zZWdtZW50Q291bnQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHNlZ21lbnRJbmRleCBtdXN0IGJlIGJldHdlZW4gMCBhbmQgJHtvcHRpb25zLnNlZ21lbnRDb3VudCAtIDF9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gYXdhaXQgdmVjdG9yc0FwaS5wb3N0KHRoaXMuZmV0Y2gsIGAke3RoaXMudXJsfS9MaXN0VmVjdG9yc2AsIG9wdGlvbnMsIHtcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgLyoqIFF1ZXJpZXMgZm9yIHNpbWlsYXIgdmVjdG9ycyB1c2luZyBhcHByb3hpbWF0ZSBuZWFyZXN0IG5laWdoYm9yIHNlYXJjaCAqL1xuICBhc3luYyBxdWVyeVZlY3RvcnMob3B0aW9uczogUXVlcnlWZWN0b3JzT3B0aW9ucyk6IFByb21pc2U8QXBpUmVzcG9uc2U8UXVlcnlWZWN0b3JzUmVzcG9uc2U+PiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIHJldHVybiBhd2FpdCB2ZWN0b3JzQXBpLnBvc3QodGhpcy5mZXRjaCwgYCR7dGhpcy51cmx9L1F1ZXJ5VmVjdG9yc2AsIG9wdGlvbnMsIHtcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgLyoqIERlbGV0ZXMgdmVjdG9ycyBieSB0aGVpciBrZXlzIGluIGJhdGNoICgxLTUwMCBwZXIgcmVxdWVzdCkgKi9cbiAgYXN5bmMgZGVsZXRlVmVjdG9ycyhvcHRpb25zOiBEZWxldGVWZWN0b3JzT3B0aW9ucyk6IFByb21pc2U8QXBpUmVzcG9uc2U8dW5kZWZpbmVkPj4ge1xuICAgIC8vIFZhbGlkYXRlIGJhdGNoIHNpemVcbiAgICBpZiAob3B0aW9ucy5rZXlzLmxlbmd0aCA8IDEgfHwgb3B0aW9ucy5rZXlzLmxlbmd0aCA+IDUwMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdLZXlzIGJhdGNoIHNpemUgbXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDUwMCBpdGVtcycpXG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB2ZWN0b3JzQXBpLnBvc3QodGhpcy5mZXRjaCwgYCR7dGhpcy51cmx9L0RlbGV0ZVZlY3RvcnNgLCBvcHRpb25zLCB7XG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgIH0pXG4gICAgICByZXR1cm4gZGF0YSB8fCB7fVxuICAgIH0pXG4gIH1cbn1cbiIsImltcG9ydCB7IERFRkFVTFRfSEVBREVSUyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBTdG9yYWdlRXJyb3IgfSBmcm9tICcuLi9saWIvY29tbW9uL2Vycm9ycydcbmltcG9ydCB7IEZldGNoLCB2ZWN0b3JzQXBpIH0gZnJvbSAnLi4vbGliL2NvbW1vbi9mZXRjaCdcbmltcG9ydCBCYXNlQXBpQ2xpZW50IGZyb20gJy4uL2xpYi9jb21tb24vQmFzZUFwaUNsaWVudCdcbmltcG9ydCB7XG4gIEFwaVJlc3BvbnNlLFxuICBWZWN0b3JCdWNrZXQsXG4gIExpc3RWZWN0b3JCdWNrZXRzT3B0aW9ucyxcbiAgTGlzdFZlY3RvckJ1Y2tldHNSZXNwb25zZSxcbn0gZnJvbSAnLi4vbGliL3R5cGVzJ1xuXG4vKipcbiAqIEBoaWRkZW5cbiAqIEJhc2UgaW1wbGVtZW50YXRpb24gZm9yIHZlY3RvciBidWNrZXQgb3BlcmF0aW9ucy5cbiAqIFVzZSB7QGxpbmsgU3RvcmFnZVZlY3RvcnNDbGllbnR9IHZpYSBgc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzYCBpbnN0ZWFkLlxuICovXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBWZWN0b3JCdWNrZXRBcGkgZXh0ZW5kcyBCYXNlQXBpQ2xpZW50PFN0b3JhZ2VFcnJvcj4ge1xuICAvKiogQ3JlYXRlcyBhIG5ldyBWZWN0b3JCdWNrZXRBcGkgaW5zdGFuY2UgKi9cbiAgY29uc3RydWN0b3IodXJsOiBzdHJpbmcsIGhlYWRlcnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fSwgZmV0Y2g/OiBGZXRjaCkge1xuICAgIGNvbnN0IGZpbmFsVXJsID0gdXJsLnJlcGxhY2UoL1xcLyQvLCAnJylcbiAgICBjb25zdCBmaW5hbEhlYWRlcnMgPSB7IC4uLkRFRkFVTFRfSEVBREVSUywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJywgLi4uaGVhZGVycyB9XG4gICAgc3VwZXIoZmluYWxVcmwsIGZpbmFsSGVhZGVycywgZmV0Y2gsICd2ZWN0b3JzJylcbiAgfVxuXG4gIC8qKiBDcmVhdGVzIGEgbmV3IHZlY3RvciBidWNrZXQgKi9cbiAgYXN5bmMgY3JlYXRlQnVja2V0KHZlY3RvckJ1Y2tldE5hbWU6IHN0cmluZyk6IFByb21pc2U8QXBpUmVzcG9uc2U8dW5kZWZpbmVkPj4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgdmVjdG9yc0FwaS5wb3N0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICBgJHt0aGlzLnVybH0vQ3JlYXRlVmVjdG9yQnVja2V0YCxcbiAgICAgICAgeyB2ZWN0b3JCdWNrZXROYW1lIH0sXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH1cbiAgICAgIClcbiAgICAgIHJldHVybiBkYXRhIHx8IHt9XG4gICAgfSlcbiAgfVxuXG4gIC8qKiBSZXRyaWV2ZXMgbWV0YWRhdGEgZm9yIGEgc3BlY2lmaWMgdmVjdG9yIGJ1Y2tldCAqL1xuICBhc3luYyBnZXRCdWNrZXQodmVjdG9yQnVja2V0TmFtZTogc3RyaW5nKTogUHJvbWlzZTxBcGlSZXNwb25zZTx7IHZlY3RvckJ1Y2tldDogVmVjdG9yQnVja2V0IH0+PiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIHJldHVybiBhd2FpdCB2ZWN0b3JzQXBpLnBvc3QoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgIGAke3RoaXMudXJsfS9HZXRWZWN0b3JCdWNrZXRgLFxuICAgICAgICB7IHZlY3RvckJ1Y2tldE5hbWUgfSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICAvKiogTGlzdHMgdmVjdG9yIGJ1Y2tldHMgd2l0aCBvcHRpb25hbCBmaWx0ZXJpbmcgYW5kIHBhZ2luYXRpb24gKi9cbiAgYXN5bmMgbGlzdEJ1Y2tldHMoXG4gICAgb3B0aW9uczogTGlzdFZlY3RvckJ1Y2tldHNPcHRpb25zID0ge31cbiAgKTogUHJvbWlzZTxBcGlSZXNwb25zZTxMaXN0VmVjdG9yQnVja2V0c1Jlc3BvbnNlPj4ge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZU9wZXJhdGlvbihhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gYXdhaXQgdmVjdG9yc0FwaS5wb3N0KHRoaXMuZmV0Y2gsIGAke3RoaXMudXJsfS9MaXN0VmVjdG9yQnVja2V0c2AsIG9wdGlvbnMsIHtcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgLyoqIERlbGV0ZXMgYSB2ZWN0b3IgYnVja2V0IChtdXN0IGJlIGVtcHR5IGZpcnN0KSAqL1xuICBhc3luYyBkZWxldGVCdWNrZXQodmVjdG9yQnVja2V0TmFtZTogc3RyaW5nKTogUHJvbWlzZTxBcGlSZXNwb25zZTx1bmRlZmluZWQ+PiB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlT3BlcmF0aW9uKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB2ZWN0b3JzQXBpLnBvc3QoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgIGAke3RoaXMudXJsfS9EZWxldGVWZWN0b3JCdWNrZXRgLFxuICAgICAgICB7IHZlY3RvckJ1Y2tldE5hbWUgfSxcbiAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxuICAgICAgKVxuICAgICAgcmV0dXJuIGRhdGEgfHwge31cbiAgICB9KVxuICB9XG59XG4iLCJpbXBvcnQgVmVjdG9ySW5kZXhBcGksIHsgQ3JlYXRlSW5kZXhPcHRpb25zIH0gZnJvbSAnLi9WZWN0b3JJbmRleEFwaSdcbmltcG9ydCBWZWN0b3JEYXRhQXBpIGZyb20gJy4vVmVjdG9yRGF0YUFwaSdcbmltcG9ydCB7IEZldGNoIH0gZnJvbSAnLi4vbGliL2NvbW1vbi9mZXRjaCdcbmltcG9ydCBWZWN0b3JCdWNrZXRBcGkgZnJvbSAnLi9WZWN0b3JCdWNrZXRBcGknXG5pbXBvcnQge1xuICBBcGlSZXNwb25zZSxcbiAgRGVsZXRlVmVjdG9yc09wdGlvbnMsXG4gIEdldFZlY3RvcnNPcHRpb25zLFxuICBMaXN0SW5kZXhlc09wdGlvbnMsXG4gIExpc3RWZWN0b3JzT3B0aW9ucyxcbiAgTGlzdFZlY3RvckJ1Y2tldHNPcHRpb25zLFxuICBMaXN0VmVjdG9yQnVja2V0c1Jlc3BvbnNlLFxuICBQdXRWZWN0b3JzT3B0aW9ucyxcbiAgUXVlcnlWZWN0b3JzT3B0aW9ucyxcbiAgVmVjdG9yQnVja2V0LFxufSBmcm9tICcuLi9saWIvdHlwZXMnXG5cbi8qKlxuICpcbiAqIEBhbHBoYVxuICpcbiAqIENvbmZpZ3VyYXRpb24gb3B0aW9ucyBmb3IgdGhlIFN0b3JhZ2UgVmVjdG9ycyBjbGllbnRcbiAqXG4gKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0b3JhZ2VWZWN0b3JzQ2xpZW50T3B0aW9ucyB7XG4gIC8qKlxuICAgKiBDdXN0b20gaGVhZGVycyB0byBpbmNsdWRlIGluIGFsbCByZXF1ZXN0c1xuICAgKi9cbiAgaGVhZGVycz86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH1cbiAgLyoqXG4gICAqIEN1c3RvbSBmZXRjaCBpbXBsZW1lbnRhdGlvbiAob3B0aW9uYWwpXG4gICAqIFVzZWZ1bCBmb3IgdGVzdGluZyBvciBjdXN0b20gcmVxdWVzdCBoYW5kbGluZ1xuICAgKi9cbiAgZmV0Y2g/OiBGZXRjaFxufVxuXG4vKipcbiAqXG4gKiBAYWxwaGFcbiAqXG4gKiBNYWluIGNsaWVudCBmb3IgaW50ZXJhY3Rpbmcgd2l0aCBTMyBWZWN0b3JzIEFQSVxuICogUHJvdmlkZXMgYWNjZXNzIHRvIGJ1Y2tldCwgaW5kZXgsIGFuZCB2ZWN0b3IgZGF0YSBvcGVyYXRpb25zXG4gKlxuICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAqXG4gKiAqKlVzYWdlIFBhdHRlcm5zOioqXG4gKlxuICogYGBgdHlwZXNjcmlwdFxuICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAqICAuc3RvcmFnZVxuICogIC52ZWN0b3JzXG4gKiAgLmNyZWF0ZUJ1Y2tldCgnZW1iZWRkaW5ncy1wcm9kJylcbiAqXG4gKiAvLyBBY2Nlc3MgaW5kZXggb3BlcmF0aW9ucyB2aWEgYnVja2V0c1xuICogY29uc3QgYnVja2V0ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpXG4gKiBhd2FpdCBidWNrZXQuY3JlYXRlSW5kZXgoe1xuICogICBpbmRleE5hbWU6ICdkb2N1bWVudHMnLFxuICogICBkYXRhVHlwZTogJ2Zsb2F0MzInLFxuICogICBkaW1lbnNpb246IDE1MzYsXG4gKiAgIGRpc3RhbmNlTWV0cmljOiAnY29zaW5lJ1xuICogfSlcbiAqXG4gKiAvLyBBY2Nlc3MgdmVjdG9yIG9wZXJhdGlvbnMgdmlhIGluZGV4XG4gKiBjb25zdCBpbmRleCA9IGJ1Y2tldC5pbmRleCgnZG9jdW1lbnRzJylcbiAqIGF3YWl0IGluZGV4LnB1dFZlY3RvcnMoe1xuICogICB2ZWN0b3JzOiBbXG4gKiAgICAgeyBrZXk6ICdkb2MtMScsIGRhdGE6IHsgZmxvYXQzMjogWy4uLl0gfSwgbWV0YWRhdGE6IHsgdGl0bGU6ICdJbnRybycgfSB9XG4gKiAgIF1cbiAqIH0pXG4gKlxuICogLy8gUXVlcnkgc2ltaWxhciB2ZWN0b3JzXG4gKiBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGluZGV4LnF1ZXJ5VmVjdG9ycyh7XG4gKiAgIHF1ZXJ5VmVjdG9yOiB7IGZsb2F0MzI6IFsuLi5dIH0sXG4gKiAgIHRvcEs6IDUsXG4gKiAgIHJldHVybkRpc3RhbmNlOiB0cnVlXG4gKiB9KVxuICogYGBgXG4gKi9cbmV4cG9ydCBjbGFzcyBTdG9yYWdlVmVjdG9yc0NsaWVudCBleHRlbmRzIFZlY3RvckJ1Y2tldEFwaSB7XG4gIC8qKlxuICAgKiBAYWxwaGFcbiAgICpcbiAgICogQ3JlYXRlcyBhIFN0b3JhZ2VWZWN0b3JzQ2xpZW50IHRoYXQgY2FuIG1hbmFnZSBidWNrZXRzLCBpbmRleGVzLCBhbmQgdmVjdG9ycy5cbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBwYXJhbSB1cmwgLSBCYXNlIFVSTCBvZiB0aGUgU3RvcmFnZSBWZWN0b3JzIFJFU1QgQVBJLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5oZWFkZXJzIC0gT3B0aW9uYWwgaGVhZGVycyAoZm9yIGV4YW1wbGUgYEF1dGhvcml6YXRpb25gKSBhcHBsaWVkIHRvIGV2ZXJ5IHJlcXVlc3QuXG4gICAqIEBwYXJhbSBvcHRpb25zLmZldGNoIC0gT3B0aW9uYWwgY3VzdG9tIGBmZXRjaGAgaW1wbGVtZW50YXRpb24gZm9yIG5vbi1icm93c2VyIHJ1bnRpbWVzLlxuICAgKlxuICAgKiBAZXhhbXBsZSBVc2luZyBzdXBhYmFzZS1qcyAocmVjb21tZW5kZWQpXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQHN1cGFiYXNlL3N1cGFiYXNlLWpzJ1xuICAgKlxuICAgKiBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudCgnaHR0cHM6Ly94eXpjb21wYW55LnN1cGFiYXNlLmNvJywgJ3lvdXItcHVibGlzaGFibGUta2V5JylcbiAgICogY29uc3QgYnVja2V0ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBTdGFuZGFsb25lIGltcG9ydCBmb3IgYnVuZGxlLXNlbnNpdGl2ZSBlbnZpcm9ubWVudHNcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBpbXBvcnQgeyBTdG9yYWdlVmVjdG9yc0NsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdG9yYWdlLWpzJ1xuICAgKlxuICAgKiBjb25zdCBjbGllbnQgPSBuZXcgU3RvcmFnZVZlY3RvcnNDbGllbnQodXJsLCBvcHRpb25zKVxuICAgKiBgYGBcbiAgICovXG4gIGNvbnN0cnVjdG9yKHVybDogc3RyaW5nLCBvcHRpb25zOiBTdG9yYWdlVmVjdG9yc0NsaWVudE9wdGlvbnMgPSB7fSkge1xuICAgIHN1cGVyKHVybCwgb3B0aW9ucy5oZWFkZXJzIHx8IHt9LCBvcHRpb25zLmZldGNoKVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBBY2Nlc3Mgb3BlcmF0aW9ucyBmb3IgYSBzcGVjaWZpYyB2ZWN0b3IgYnVja2V0XG4gICAqIFJldHVybnMgYSBzY29wZWQgY2xpZW50IGZvciBpbmRleCBhbmQgdmVjdG9yIG9wZXJhdGlvbnMgd2l0aGluIHRoZSBidWNrZXRcbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBwYXJhbSB2ZWN0b3JCdWNrZXROYW1lIC0gTmFtZSBvZiB0aGUgdmVjdG9yIGJ1Y2tldFxuICAgKiBAcmV0dXJucyBCdWNrZXQtc2NvcGVkIGNsaWVudCB3aXRoIGluZGV4IGFuZCB2ZWN0b3Igb3BlcmF0aW9uc1xuICAgKlxuICAgKiBAZXhhbXBsZSBBY2Nlc3NpbmcgYSB2ZWN0b3IgYnVja2V0XG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgYnVja2V0ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpXG4gICAqIGBgYFxuICAgKi9cbiAgZnJvbSh2ZWN0b3JCdWNrZXROYW1lOiBzdHJpbmcpOiBWZWN0b3JCdWNrZXRTY29wZSB7XG4gICAgcmV0dXJuIG5ldyBWZWN0b3JCdWNrZXRTY29wZSh0aGlzLnVybCwgdGhpcy5oZWFkZXJzLCB2ZWN0b3JCdWNrZXROYW1lLCB0aGlzLmZldGNoKVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBDcmVhdGVzIGEgbmV3IHZlY3RvciBidWNrZXRcbiAgICogVmVjdG9yIGJ1Y2tldHMgYXJlIGNvbnRhaW5lcnMgZm9yIHZlY3RvciBpbmRleGVzIGFuZCB0aGVpciBkYXRhXG4gICAqXG4gICAqICoqUHVibGljIGFscGhhOioqIFRoaXMgQVBJIGlzIHBhcnQgb2YgYSBwdWJsaWMgYWxwaGEgcmVsZWFzZSBhbmQgbWF5IG5vdCBiZSBhdmFpbGFibGUgdG8geW91ciBhY2NvdW50IHR5cGUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBWZWN0b3IgQnVja2V0c1xuICAgKiBAcGFyYW0gdmVjdG9yQnVja2V0TmFtZSAtIFVuaXF1ZSBuYW1lIGZvciB0aGUgdmVjdG9yIGJ1Y2tldFxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggZW1wdHkgcmVzcG9uc2Ugb24gc3VjY2VzcyBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBDcmVhdGluZyBhIHZlY3RvciBidWNrZXRcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLnZlY3RvcnNcbiAgICogICAuY3JlYXRlQnVja2V0KCdlbWJlZGRpbmdzLXByb2QnKVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGNyZWF0ZUJ1Y2tldCh2ZWN0b3JCdWNrZXROYW1lOiBzdHJpbmcpOiBQcm9taXNlPEFwaVJlc3BvbnNlPHVuZGVmaW5lZD4+IHtcbiAgICByZXR1cm4gc3VwZXIuY3JlYXRlQnVja2V0KHZlY3RvckJ1Y2tldE5hbWUpXG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQGFscGhhXG4gICAqXG4gICAqIFJldHJpZXZlcyBtZXRhZGF0YSBmb3IgYSBzcGVjaWZpYyB2ZWN0b3IgYnVja2V0XG4gICAqXG4gICAqICoqUHVibGljIGFscGhhOioqIFRoaXMgQVBJIGlzIHBhcnQgb2YgYSBwdWJsaWMgYWxwaGEgcmVsZWFzZSBhbmQgbWF5IG5vdCBiZSBhdmFpbGFibGUgdG8geW91ciBhY2NvdW50IHR5cGUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBWZWN0b3IgQnVja2V0c1xuICAgKiBAcGFyYW0gdmVjdG9yQnVja2V0TmFtZSAtIE5hbWUgb2YgdGhlIHZlY3RvciBidWNrZXRcbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIGJ1Y2tldCBtZXRhZGF0YSBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBHZXQgYnVja2V0IG1ldGFkYXRhXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC52ZWN0b3JzXG4gICAqICAgLmdldEJ1Y2tldCgnZW1iZWRkaW5ncy1wcm9kJylcbiAgICpcbiAgICogY29uc29sZS5sb2coJ0J1Y2tldCBjcmVhdGVkOicsIGRhdGE/LnZlY3RvckJ1Y2tldC5jcmVhdGlvblRpbWUpXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgZ2V0QnVja2V0KHZlY3RvckJ1Y2tldE5hbWU6IHN0cmluZyk6IFByb21pc2U8QXBpUmVzcG9uc2U8eyB2ZWN0b3JCdWNrZXQ6IFZlY3RvckJ1Y2tldCB9Pj4ge1xuICAgIHJldHVybiBzdXBlci5nZXRCdWNrZXQodmVjdG9yQnVja2V0TmFtZSlcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAYWxwaGFcbiAgICpcbiAgICogTGlzdHMgYWxsIHZlY3RvciBidWNrZXRzIHdpdGggb3B0aW9uYWwgZmlsdGVyaW5nIGFuZCBwYWdpbmF0aW9uXG4gICAqXG4gICAqICoqUHVibGljIGFscGhhOioqIFRoaXMgQVBJIGlzIHBhcnQgb2YgYSBwdWJsaWMgYWxwaGEgcmVsZWFzZSBhbmQgbWF5IG5vdCBiZSBhdmFpbGFibGUgdG8geW91ciBhY2NvdW50IHR5cGUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBWZWN0b3IgQnVja2V0c1xuICAgKiBAcGFyYW0gb3B0aW9ucyAtIE9wdGlvbmFsIGZpbHRlcnMgKHByZWZpeCwgbWF4UmVzdWx0cywgbmV4dFRva2VuKVxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggbGlzdCBvZiBidWNrZXRzIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIExpc3QgdmVjdG9yIGJ1Y2tldHNcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgKiAgIC5zdG9yYWdlXG4gICAqICAgLnZlY3RvcnNcbiAgICogICAubGlzdEJ1Y2tldHMoeyBwcmVmaXg6ICdlbWJlZGRpbmdzLScgfSlcbiAgICpcbiAgICogZGF0YT8udmVjdG9yQnVja2V0cy5mb3JFYWNoKGJ1Y2tldCA9PiB7XG4gICAqICAgY29uc29sZS5sb2coYnVja2V0LnZlY3RvckJ1Y2tldE5hbWUpXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgbGlzdEJ1Y2tldHMoXG4gICAgb3B0aW9uczogTGlzdFZlY3RvckJ1Y2tldHNPcHRpb25zID0ge31cbiAgKTogUHJvbWlzZTxBcGlSZXNwb25zZTxMaXN0VmVjdG9yQnVja2V0c1Jlc3BvbnNlPj4ge1xuICAgIHJldHVybiBzdXBlci5saXN0QnVja2V0cyhvcHRpb25zKVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBEZWxldGVzIGEgdmVjdG9yIGJ1Y2tldCAoYnVja2V0IG11c3QgYmUgZW1wdHkpXG4gICAqIEFsbCBpbmRleGVzIG11c3QgYmUgZGVsZXRlZCBiZWZvcmUgZGVsZXRpbmcgdGhlIGJ1Y2tldFxuICAgKlxuICAgKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgVmVjdG9yIEJ1Y2tldHNcbiAgICogQHBhcmFtIHZlY3RvckJ1Y2tldE5hbWUgLSBOYW1lIG9mIHRoZSB2ZWN0b3IgYnVja2V0IHRvIGRlbGV0ZVxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggZW1wdHkgcmVzcG9uc2Ugb24gc3VjY2VzcyBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBEZWxldGUgYSB2ZWN0b3IgYnVja2V0XG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICogICAuc3RvcmFnZVxuICAgKiAgIC52ZWN0b3JzXG4gICAqICAgLmRlbGV0ZUJ1Y2tldCgnZW1iZWRkaW5ncy1vbGQnKVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGRlbGV0ZUJ1Y2tldCh2ZWN0b3JCdWNrZXROYW1lOiBzdHJpbmcpOiBQcm9taXNlPEFwaVJlc3BvbnNlPHVuZGVmaW5lZD4+IHtcbiAgICByZXR1cm4gc3VwZXIuZGVsZXRlQnVja2V0KHZlY3RvckJ1Y2tldE5hbWUpXG4gIH1cbn1cblxuLyoqXG4gKlxuICogQGFscGhhXG4gKlxuICogU2NvcGVkIGNsaWVudCBmb3Igb3BlcmF0aW9ucyB3aXRoaW4gYSBzcGVjaWZpYyB2ZWN0b3IgYnVja2V0XG4gKiBQcm92aWRlcyBpbmRleCBtYW5hZ2VtZW50IGFuZCBhY2Nlc3MgdG8gdmVjdG9yIG9wZXJhdGlvbnNcbiAqXG4gKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICovXG5leHBvcnQgY2xhc3MgVmVjdG9yQnVja2V0U2NvcGUgZXh0ZW5kcyBWZWN0b3JJbmRleEFwaSB7XG4gIHByaXZhdGUgdmVjdG9yQnVja2V0TmFtZTogc3RyaW5nXG5cbiAgLyoqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBDcmVhdGVzIGEgaGVscGVyIHRoYXQgYXV0b21hdGljYWxseSBzY29wZXMgYWxsIGluZGV4IG9wZXJhdGlvbnMgdG8gdGhlIHByb3ZpZGVkIGJ1Y2tldC5cbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBleGFtcGxlIENyZWF0aW5nIGEgdmVjdG9yIGJ1Y2tldCBzY29wZVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IGJ1Y2tldCA9IHN1cGFiYXNlLnN0b3JhZ2UudmVjdG9ycy5mcm9tKCdlbWJlZGRpbmdzLXByb2QnKVxuICAgKiBgYGBcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIHVybDogc3RyaW5nLFxuICAgIGhlYWRlcnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0sXG4gICAgdmVjdG9yQnVja2V0TmFtZTogc3RyaW5nLFxuICAgIGZldGNoPzogRmV0Y2hcbiAgKSB7XG4gICAgc3VwZXIodXJsLCBoZWFkZXJzLCBmZXRjaClcbiAgICB0aGlzLnZlY3RvckJ1Y2tldE5hbWUgPSB2ZWN0b3JCdWNrZXROYW1lXG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQGFscGhhXG4gICAqXG4gICAqIENyZWF0ZXMgYSBuZXcgdmVjdG9yIGluZGV4IGluIHRoaXMgYnVja2V0XG4gICAqIENvbnZlbmllbmNlIG1ldGhvZCB0aGF0IGF1dG9tYXRpY2FsbHkgaW5jbHVkZXMgdGhlIGJ1Y2tldCBuYW1lXG4gICAqXG4gICAqICoqUHVibGljIGFscGhhOioqIFRoaXMgQVBJIGlzIHBhcnQgb2YgYSBwdWJsaWMgYWxwaGEgcmVsZWFzZSBhbmQgbWF5IG5vdCBiZSBhdmFpbGFibGUgdG8geW91ciBhY2NvdW50IHR5cGUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBWZWN0b3IgQnVja2V0c1xuICAgKiBAcGFyYW0gb3B0aW9ucyAtIEluZGV4IGNvbmZpZ3VyYXRpb24gKHZlY3RvckJ1Y2tldE5hbWUgaXMgYXV0b21hdGljYWxseSBzZXQpXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCBlbXB0eSByZXNwb25zZSBvbiBzdWNjZXNzIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIENyZWF0aW5nIGEgdmVjdG9yIGluZGV4XG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgYnVja2V0ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpXG4gICAqIGF3YWl0IGJ1Y2tldC5jcmVhdGVJbmRleCh7XG4gICAqICAgaW5kZXhOYW1lOiAnZG9jdW1lbnRzLW9wZW5haScsXG4gICAqICAgZGF0YVR5cGU6ICdmbG9hdDMyJyxcbiAgICogICBkaW1lbnNpb246IDE1MzYsXG4gICAqICAgZGlzdGFuY2VNZXRyaWM6ICdjb3NpbmUnLFxuICAgKiAgIG1ldGFkYXRhQ29uZmlndXJhdGlvbjoge1xuICAgKiAgICAgbm9uRmlsdGVyYWJsZU1ldGFkYXRhS2V5czogWydyYXdfdGV4dCddXG4gICAqICAgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIG92ZXJyaWRlIGFzeW5jIGNyZWF0ZUluZGV4KG9wdGlvbnM6IE9taXQ8Q3JlYXRlSW5kZXhPcHRpb25zLCAndmVjdG9yQnVja2V0TmFtZSc+KSB7XG4gICAgcmV0dXJuIHN1cGVyLmNyZWF0ZUluZGV4KHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICB2ZWN0b3JCdWNrZXROYW1lOiB0aGlzLnZlY3RvckJ1Y2tldE5hbWUsXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAYWxwaGFcbiAgICpcbiAgICogTGlzdHMgaW5kZXhlcyBpbiB0aGlzIGJ1Y2tldFxuICAgKiBDb252ZW5pZW5jZSBtZXRob2QgdGhhdCBhdXRvbWF0aWNhbGx5IGluY2x1ZGVzIHRoZSBidWNrZXQgbmFtZVxuICAgKlxuICAgKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgVmVjdG9yIEJ1Y2tldHNcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBMaXN0aW5nIG9wdGlvbnMgKHZlY3RvckJ1Y2tldE5hbWUgaXMgYXV0b21hdGljYWxseSBzZXQpXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIGluZGV4ZXMgYXJyYXkgYW5kIHBhZ2luYXRpb24gdG9rZW4gb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdCBpbmRleGVzXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgYnVja2V0ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpXG4gICAqIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYnVja2V0Lmxpc3RJbmRleGVzKHsgcHJlZml4OiAnZG9jdW1lbnRzLScgfSlcbiAgICogYGBgXG4gICAqL1xuICBvdmVycmlkZSBhc3luYyBsaXN0SW5kZXhlcyhvcHRpb25zOiBPbWl0PExpc3RJbmRleGVzT3B0aW9ucywgJ3ZlY3RvckJ1Y2tldE5hbWUnPiA9IHt9KSB7XG4gICAgcmV0dXJuIHN1cGVyLmxpc3RJbmRleGVzKHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICB2ZWN0b3JCdWNrZXROYW1lOiB0aGlzLnZlY3RvckJ1Y2tldE5hbWUsXG4gICAgfSlcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAYWxwaGFcbiAgICpcbiAgICogUmV0cmlldmVzIG1ldGFkYXRhIGZvciBhIHNwZWNpZmljIGluZGV4IGluIHRoaXMgYnVja2V0XG4gICAqIENvbnZlbmllbmNlIG1ldGhvZCB0aGF0IGF1dG9tYXRpY2FsbHkgaW5jbHVkZXMgdGhlIGJ1Y2tldCBuYW1lXG4gICAqXG4gICAqICoqUHVibGljIGFscGhhOioqIFRoaXMgQVBJIGlzIHBhcnQgb2YgYSBwdWJsaWMgYWxwaGEgcmVsZWFzZSBhbmQgbWF5IG5vdCBiZSBhdmFpbGFibGUgdG8geW91ciBhY2NvdW50IHR5cGUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBWZWN0b3IgQnVja2V0c1xuICAgKiBAcGFyYW0gaW5kZXhOYW1lIC0gTmFtZSBvZiB0aGUgaW5kZXggdG8gcmV0cmlldmVcbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIGluZGV4IG1ldGFkYXRhIG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIEdldCBpbmRleCBtZXRhZGF0YVxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IGJ1Y2tldCA9IHN1cGFiYXNlLnN0b3JhZ2UudmVjdG9ycy5mcm9tKCdlbWJlZGRpbmdzLXByb2QnKVxuICAgKiBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGJ1Y2tldC5nZXRJbmRleCgnZG9jdW1lbnRzLW9wZW5haScpXG4gICAqIGNvbnNvbGUubG9nKCdEaW1lbnNpb246JywgZGF0YT8uaW5kZXguZGltZW5zaW9uKVxuICAgKiBgYGBcbiAgICovXG4gIG92ZXJyaWRlIGFzeW5jIGdldEluZGV4KGluZGV4TmFtZTogc3RyaW5nKSB7XG4gICAgcmV0dXJuIHN1cGVyLmdldEluZGV4KHRoaXMudmVjdG9yQnVja2V0TmFtZSwgaW5kZXhOYW1lKVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBEZWxldGVzIGFuIGluZGV4IGZyb20gdGhpcyBidWNrZXRcbiAgICogQ29udmVuaWVuY2UgbWV0aG9kIHRoYXQgYXV0b21hdGljYWxseSBpbmNsdWRlcyB0aGUgYnVja2V0IG5hbWVcbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBwYXJhbSBpbmRleE5hbWUgLSBOYW1lIG9mIHRoZSBpbmRleCB0byBkZWxldGVcbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIGVtcHR5IHJlc3BvbnNlIG9uIHN1Y2Nlc3Mgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgRGVsZXRlIGFuIGluZGV4XG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgYnVja2V0ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpXG4gICAqIGF3YWl0IGJ1Y2tldC5kZWxldGVJbmRleCgnb2xkLWluZGV4JylcbiAgICogYGBgXG4gICAqL1xuICBvdmVycmlkZSBhc3luYyBkZWxldGVJbmRleChpbmRleE5hbWU6IHN0cmluZykge1xuICAgIHJldHVybiBzdXBlci5kZWxldGVJbmRleCh0aGlzLnZlY3RvckJ1Y2tldE5hbWUsIGluZGV4TmFtZSlcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAYWxwaGFcbiAgICpcbiAgICogQWNjZXNzIG9wZXJhdGlvbnMgZm9yIGEgc3BlY2lmaWMgaW5kZXggd2l0aGluIHRoaXMgYnVja2V0XG4gICAqIFJldHVybnMgYSBzY29wZWQgY2xpZW50IGZvciB2ZWN0b3IgZGF0YSBvcGVyYXRpb25zXG4gICAqXG4gICAqICoqUHVibGljIGFscGhhOioqIFRoaXMgQVBJIGlzIHBhcnQgb2YgYSBwdWJsaWMgYWxwaGEgcmVsZWFzZSBhbmQgbWF5IG5vdCBiZSBhdmFpbGFibGUgdG8geW91ciBhY2NvdW50IHR5cGUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBWZWN0b3IgQnVja2V0c1xuICAgKiBAcGFyYW0gaW5kZXhOYW1lIC0gTmFtZSBvZiB0aGUgaW5kZXhcbiAgICogQHJldHVybnMgSW5kZXgtc2NvcGVkIGNsaWVudCB3aXRoIHZlY3RvciBkYXRhIG9wZXJhdGlvbnNcbiAgICpcbiAgICogQGV4YW1wbGUgQWNjZXNzaW5nIGFuIGluZGV4XG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgaW5kZXggPSBzdXBhYmFzZS5zdG9yYWdlLnZlY3RvcnMuZnJvbSgnZW1iZWRkaW5ncy1wcm9kJykuaW5kZXgoJ2RvY3VtZW50cy1vcGVuYWknKVxuICAgKlxuICAgKiAvLyBJbnNlcnQgdmVjdG9yc1xuICAgKiBhd2FpdCBpbmRleC5wdXRWZWN0b3JzKHtcbiAgICogICB2ZWN0b3JzOiBbXG4gICAqICAgICB7IGtleTogJ2RvYy0xJywgZGF0YTogeyBmbG9hdDMyOiBbLi4uXSB9LCBtZXRhZGF0YTogeyB0aXRsZTogJ0ludHJvJyB9IH1cbiAgICogICBdXG4gICAqIH0pXG4gICAqXG4gICAqIC8vIFF1ZXJ5IHNpbWlsYXIgdmVjdG9yc1xuICAgKiBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGluZGV4LnF1ZXJ5VmVjdG9ycyh7XG4gICAqICAgcXVlcnlWZWN0b3I6IHsgZmxvYXQzMjogWy4uLl0gfSxcbiAgICogICB0b3BLOiA1XG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgaW5kZXgoaW5kZXhOYW1lOiBzdHJpbmcpOiBWZWN0b3JJbmRleFNjb3BlIHtcbiAgICByZXR1cm4gbmV3IFZlY3RvckluZGV4U2NvcGUoXG4gICAgICB0aGlzLnVybCxcbiAgICAgIHRoaXMuaGVhZGVycyxcbiAgICAgIHRoaXMudmVjdG9yQnVja2V0TmFtZSxcbiAgICAgIGluZGV4TmFtZSxcbiAgICAgIHRoaXMuZmV0Y2hcbiAgICApXG4gIH1cbn1cblxuLyoqXG4gKlxuICogQGFscGhhXG4gKlxuICogU2NvcGVkIGNsaWVudCBmb3Igb3BlcmF0aW9ucyB3aXRoaW4gYSBzcGVjaWZpYyB2ZWN0b3IgaW5kZXhcbiAqIFByb3ZpZGVzIHZlY3RvciBkYXRhIG9wZXJhdGlvbnMgKHB1dCwgZ2V0LCBsaXN0LCBxdWVyeSwgZGVsZXRlKVxuICpcbiAqICoqUHVibGljIGFscGhhOioqIFRoaXMgQVBJIGlzIHBhcnQgb2YgYSBwdWJsaWMgYWxwaGEgcmVsZWFzZSBhbmQgbWF5IG5vdCBiZSBhdmFpbGFibGUgdG8geW91ciBhY2NvdW50IHR5cGUuXG4gKi9cbmV4cG9ydCBjbGFzcyBWZWN0b3JJbmRleFNjb3BlIGV4dGVuZHMgVmVjdG9yRGF0YUFwaSB7XG4gIHByaXZhdGUgdmVjdG9yQnVja2V0TmFtZTogc3RyaW5nXG4gIHByaXZhdGUgaW5kZXhOYW1lOiBzdHJpbmdcblxuICAvKipcbiAgICpcbiAgICogQGFscGhhXG4gICAqXG4gICAqIENyZWF0ZXMgYSBoZWxwZXIgdGhhdCBhdXRvbWF0aWNhbGx5IHNjb3BlcyBhbGwgdmVjdG9yIG9wZXJhdGlvbnMgdG8gdGhlIHByb3ZpZGVkIGJ1Y2tldC9pbmRleCBuYW1lcy5cbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBleGFtcGxlIENyZWF0aW5nIGEgdmVjdG9yIGluZGV4IHNjb3BlXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgaW5kZXggPSBzdXBhYmFzZS5zdG9yYWdlLnZlY3RvcnMuZnJvbSgnZW1iZWRkaW5ncy1wcm9kJykuaW5kZXgoJ2RvY3VtZW50cy1vcGVuYWknKVxuICAgKiBgYGBcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIHVybDogc3RyaW5nLFxuICAgIGhlYWRlcnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0sXG4gICAgdmVjdG9yQnVja2V0TmFtZTogc3RyaW5nLFxuICAgIGluZGV4TmFtZTogc3RyaW5nLFxuICAgIGZldGNoPzogRmV0Y2hcbiAgKSB7XG4gICAgc3VwZXIodXJsLCBoZWFkZXJzLCBmZXRjaClcbiAgICB0aGlzLnZlY3RvckJ1Y2tldE5hbWUgPSB2ZWN0b3JCdWNrZXROYW1lXG4gICAgdGhpcy5pbmRleE5hbWUgPSBpbmRleE5hbWVcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAYWxwaGFcbiAgICpcbiAgICogSW5zZXJ0cyBvciB1cGRhdGVzIHZlY3RvcnMgaW4gdGhpcyBpbmRleFxuICAgKiBDb252ZW5pZW5jZSBtZXRob2QgdGhhdCBhdXRvbWF0aWNhbGx5IGluY2x1ZGVzIGJ1Y2tldCBhbmQgaW5kZXggbmFtZXNcbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVmVjdG9yIGluc2VydGlvbiBvcHRpb25zIChidWNrZXQgYW5kIGluZGV4IG5hbWVzIGF1dG9tYXRpY2FsbHkgc2V0KVxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggZW1wdHkgcmVzcG9uc2Ugb24gc3VjY2VzcyBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBJbnNlcnQgdmVjdG9ycyBpbnRvIGFuIGluZGV4XG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgaW5kZXggPSBzdXBhYmFzZS5zdG9yYWdlLnZlY3RvcnMuZnJvbSgnZW1iZWRkaW5ncy1wcm9kJykuaW5kZXgoJ2RvY3VtZW50cy1vcGVuYWknKVxuICAgKiBhd2FpdCBpbmRleC5wdXRWZWN0b3JzKHtcbiAgICogICB2ZWN0b3JzOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIGtleTogJ2RvYy0xJyxcbiAgICogICAgICAgZGF0YTogeyBmbG9hdDMyOiBbMC4xLCAwLjIsIC4uLl0gfSxcbiAgICogICAgICAgbWV0YWRhdGE6IHsgdGl0bGU6ICdJbnRyb2R1Y3Rpb24nLCBwYWdlOiAxIH1cbiAgICogICAgIH1cbiAgICogICBdXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgb3ZlcnJpZGUgYXN5bmMgcHV0VmVjdG9ycyhvcHRpb25zOiBPbWl0PFB1dFZlY3RvcnNPcHRpb25zLCAndmVjdG9yQnVja2V0TmFtZScgfCAnaW5kZXhOYW1lJz4pIHtcbiAgICByZXR1cm4gc3VwZXIucHV0VmVjdG9ycyh7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgdmVjdG9yQnVja2V0TmFtZTogdGhpcy52ZWN0b3JCdWNrZXROYW1lLFxuICAgICAgaW5kZXhOYW1lOiB0aGlzLmluZGV4TmFtZSxcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBSZXRyaWV2ZXMgdmVjdG9ycyBieSBrZXlzIGZyb20gdGhpcyBpbmRleFxuICAgKiBDb252ZW5pZW5jZSBtZXRob2QgdGhhdCBhdXRvbWF0aWNhbGx5IGluY2x1ZGVzIGJ1Y2tldCBhbmQgaW5kZXggbmFtZXNcbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVmVjdG9yIHJldHJpZXZhbCBvcHRpb25zIChidWNrZXQgYW5kIGluZGV4IG5hbWVzIGF1dG9tYXRpY2FsbHkgc2V0KVxuICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggcmVzcG9uc2UgY29udGFpbmluZyB2ZWN0b3JzIGFycmF5IG9yIGVycm9yXG4gICAqXG4gICAqIEBleGFtcGxlIEdldCB2ZWN0b3JzIGJ5IGtleXNcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBjb25zdCBpbmRleCA9IHN1cGFiYXNlLnN0b3JhZ2UudmVjdG9ycy5mcm9tKCdlbWJlZGRpbmdzLXByb2QnKS5pbmRleCgnZG9jdW1lbnRzLW9wZW5haScpXG4gICAqIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgaW5kZXguZ2V0VmVjdG9ycyh7XG4gICAqICAga2V5czogWydkb2MtMScsICdkb2MtMiddLFxuICAgKiAgIHJldHVybk1ldGFkYXRhOiB0cnVlXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgb3ZlcnJpZGUgYXN5bmMgZ2V0VmVjdG9ycyhvcHRpb25zOiBPbWl0PEdldFZlY3RvcnNPcHRpb25zLCAndmVjdG9yQnVja2V0TmFtZScgfCAnaW5kZXhOYW1lJz4pIHtcbiAgICByZXR1cm4gc3VwZXIuZ2V0VmVjdG9ycyh7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgdmVjdG9yQnVja2V0TmFtZTogdGhpcy52ZWN0b3JCdWNrZXROYW1lLFxuICAgICAgaW5kZXhOYW1lOiB0aGlzLmluZGV4TmFtZSxcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBMaXN0cyB2ZWN0b3JzIGluIHRoaXMgaW5kZXggd2l0aCBwYWdpbmF0aW9uXG4gICAqIENvbnZlbmllbmNlIG1ldGhvZCB0aGF0IGF1dG9tYXRpY2FsbHkgaW5jbHVkZXMgYnVja2V0IGFuZCBpbmRleCBuYW1lc1xuICAgKlxuICAgKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgVmVjdG9yIEJ1Y2tldHNcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBMaXN0aW5nIG9wdGlvbnMgKGJ1Y2tldCBhbmQgaW5kZXggbmFtZXMgYXV0b21hdGljYWxseSBzZXQpXG4gICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCByZXNwb25zZSBjb250YWluaW5nIHZlY3RvcnMgYXJyYXkgYW5kIHBhZ2luYXRpb24gdG9rZW4gb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgTGlzdCB2ZWN0b3JzIHdpdGggcGFnaW5hdGlvblxuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IGluZGV4ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpLmluZGV4KCdkb2N1bWVudHMtb3BlbmFpJylcbiAgICogY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBpbmRleC5saXN0VmVjdG9ycyh7XG4gICAqICAgbWF4UmVzdWx0czogNTAwLFxuICAgKiAgIHJldHVybk1ldGFkYXRhOiB0cnVlXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgb3ZlcnJpZGUgYXN5bmMgbGlzdFZlY3RvcnMoXG4gICAgb3B0aW9uczogT21pdDxMaXN0VmVjdG9yc09wdGlvbnMsICd2ZWN0b3JCdWNrZXROYW1lJyB8ICdpbmRleE5hbWUnPiA9IHt9XG4gICkge1xuICAgIHJldHVybiBzdXBlci5saXN0VmVjdG9ycyh7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgdmVjdG9yQnVja2V0TmFtZTogdGhpcy52ZWN0b3JCdWNrZXROYW1lLFxuICAgICAgaW5kZXhOYW1lOiB0aGlzLmluZGV4TmFtZSxcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBRdWVyaWVzIGZvciBzaW1pbGFyIHZlY3RvcnMgaW4gdGhpcyBpbmRleFxuICAgKiBDb252ZW5pZW5jZSBtZXRob2QgdGhhdCBhdXRvbWF0aWNhbGx5IGluY2x1ZGVzIGJ1Y2tldCBhbmQgaW5kZXggbmFtZXNcbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gUXVlcnkgb3B0aW9ucyAoYnVja2V0IGFuZCBpbmRleCBuYW1lcyBhdXRvbWF0aWNhbGx5IHNldClcbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHJlc3BvbnNlIGNvbnRhaW5pbmcgbWF0Y2hlcyBhcnJheSBvZiBzaW1pbGFyIHZlY3RvcnMgb3JkZXJlZCBieSBkaXN0YW5jZSBvciBlcnJvclxuICAgKlxuICAgKiBAZXhhbXBsZSBRdWVyeSBzaW1pbGFyIHZlY3RvcnNcbiAgICogYGBgdHlwZXNjcmlwdFxuICAgKiBjb25zdCBpbmRleCA9IHN1cGFiYXNlLnN0b3JhZ2UudmVjdG9ycy5mcm9tKCdlbWJlZGRpbmdzLXByb2QnKS5pbmRleCgnZG9jdW1lbnRzLW9wZW5haScpXG4gICAqIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgaW5kZXgucXVlcnlWZWN0b3JzKHtcbiAgICogICBxdWVyeVZlY3RvcjogeyBmbG9hdDMyOiBbMC4xLCAwLjIsIC4uLl0gfSxcbiAgICogICB0b3BLOiA1LFxuICAgKiAgIGZpbHRlcjogeyBjYXRlZ29yeTogJ3RlY2huaWNhbCcgfSxcbiAgICogICByZXR1cm5EaXN0YW5jZTogdHJ1ZSxcbiAgICogICByZXR1cm5NZXRhZGF0YTogdHJ1ZVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIG92ZXJyaWRlIGFzeW5jIHF1ZXJ5VmVjdG9ycyhcbiAgICBvcHRpb25zOiBPbWl0PFF1ZXJ5VmVjdG9yc09wdGlvbnMsICd2ZWN0b3JCdWNrZXROYW1lJyB8ICdpbmRleE5hbWUnPlxuICApIHtcbiAgICByZXR1cm4gc3VwZXIucXVlcnlWZWN0b3JzKHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICB2ZWN0b3JCdWNrZXROYW1lOiB0aGlzLnZlY3RvckJ1Y2tldE5hbWUsXG4gICAgICBpbmRleE5hbWU6IHRoaXMuaW5kZXhOYW1lLFxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQGFscGhhXG4gICAqXG4gICAqIERlbGV0ZXMgdmVjdG9ycyBieSBrZXlzIGZyb20gdGhpcyBpbmRleFxuICAgKiBDb252ZW5pZW5jZSBtZXRob2QgdGhhdCBhdXRvbWF0aWNhbGx5IGluY2x1ZGVzIGJ1Y2tldCBhbmQgaW5kZXggbmFtZXNcbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IFZlY3RvciBCdWNrZXRzXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gRGVsZXRpb24gb3B0aW9ucyAoYnVja2V0IGFuZCBpbmRleCBuYW1lcyBhdXRvbWF0aWNhbGx5IHNldClcbiAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIGVtcHR5IHJlc3BvbnNlIG9uIHN1Y2Nlc3Mgb3IgZXJyb3JcbiAgICpcbiAgICogQGV4YW1wbGUgRGVsZXRlIHZlY3RvcnMgYnkga2V5c1xuICAgKiBgYGB0eXBlc2NyaXB0XG4gICAqIGNvbnN0IGluZGV4ID0gc3VwYWJhc2Uuc3RvcmFnZS52ZWN0b3JzLmZyb20oJ2VtYmVkZGluZ3MtcHJvZCcpLmluZGV4KCdkb2N1bWVudHMtb3BlbmFpJylcbiAgICogYXdhaXQgaW5kZXguZGVsZXRlVmVjdG9ycyh7XG4gICAqICAga2V5czogWydkb2MtMScsICdkb2MtMicsICdkb2MtMyddXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgb3ZlcnJpZGUgYXN5bmMgZGVsZXRlVmVjdG9ycyhcbiAgICBvcHRpb25zOiBPbWl0PERlbGV0ZVZlY3RvcnNPcHRpb25zLCAndmVjdG9yQnVja2V0TmFtZScgfCAnaW5kZXhOYW1lJz5cbiAgKSB7XG4gICAgcmV0dXJuIHN1cGVyLmRlbGV0ZVZlY3RvcnMoe1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIHZlY3RvckJ1Y2tldE5hbWU6IHRoaXMudmVjdG9yQnVja2V0TmFtZSxcbiAgICAgIGluZGV4TmFtZTogdGhpcy5pbmRleE5hbWUsXG4gICAgfSlcbiAgfVxufVxuIiwiaW1wb3J0IFN0b3JhZ2VGaWxlQXBpIGZyb20gJy4vcGFja2FnZXMvU3RvcmFnZUZpbGVBcGknXG5pbXBvcnQgU3RvcmFnZUJ1Y2tldEFwaSBmcm9tICcuL3BhY2thZ2VzL1N0b3JhZ2VCdWNrZXRBcGknXG5pbXBvcnQgU3RvcmFnZUFuYWx5dGljc0NsaWVudCBmcm9tICcuL3BhY2thZ2VzL1N0b3JhZ2VBbmFseXRpY3NDbGllbnQnXG5pbXBvcnQgeyBGZXRjaCB9IGZyb20gJy4vbGliL2NvbW1vbi9mZXRjaCdcbmltcG9ydCB7IFN0b3JhZ2VWZWN0b3JzQ2xpZW50IH0gZnJvbSAnLi9wYWNrYWdlcy9TdG9yYWdlVmVjdG9yc0NsaWVudCdcblxuZXhwb3J0IGludGVyZmFjZSBTdG9yYWdlQ2xpZW50T3B0aW9ucyB7XG4gIHVzZU5ld0hvc3RuYW1lPzogYm9vbGVhblxufVxuXG5leHBvcnQgY2xhc3MgU3RvcmFnZUNsaWVudCBleHRlbmRzIFN0b3JhZ2VCdWNrZXRBcGkge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIGNsaWVudCBmb3IgU3RvcmFnZSBidWNrZXRzLCBmaWxlcywgYW5hbHl0aWNzLCBhbmQgdmVjdG9ycy5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEZpbGUgQnVja2V0c1xuICAgKlxuICAgKiBAZXhhbXBsZSBVc2luZyBzdXBhYmFzZS1qcyAocmVjb21tZW5kZWQpXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcydcbiAgICpcbiAgICogY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoJ2h0dHBzOi8veHl6Y29tcGFueS5zdXBhYmFzZS5jbycsICd5b3VyLXB1Ymxpc2hhYmxlLWtleScpXG4gICAqIGNvbnN0IGF2YXRhcnMgPSBzdXBhYmFzZS5zdG9yYWdlLmZyb20oJ2F2YXRhcnMnKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU3RhbmRhbG9uZSBpbXBvcnQgZm9yIGJ1bmRsZS1zZW5zaXRpdmUgZW52aXJvbm1lbnRzXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IFN0b3JhZ2VDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3RvcmFnZS1qcydcbiAgICpcbiAgICogY29uc3Qgc3RvcmFnZSA9IG5ldyBTdG9yYWdlQ2xpZW50KCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28vc3RvcmFnZS92MScsIHtcbiAgICogICBhcGlrZXk6ICd5b3VyLXB1Ymxpc2hhYmxlLWtleScsXG4gICAqIH0pXG4gICAqIGNvbnN0IGF2YXRhcnMgPSBzdG9yYWdlLmZyb20oJ2F2YXRhcnMnKVxuICAgKiBgYGBcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIHVybDogc3RyaW5nLFxuICAgIGhlYWRlcnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fSxcbiAgICBmZXRjaD86IEZldGNoLFxuICAgIG9wdHM/OiBTdG9yYWdlQ2xpZW50T3B0aW9uc1xuICApIHtcbiAgICBzdXBlcih1cmwsIGhlYWRlcnMsIGZldGNoLCBvcHRzKVxuICB9XG5cbiAgLyoqXG4gICAqIFBlcmZvcm0gZmlsZSBvcGVyYXRpb24gaW4gYSBidWNrZXQuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBTdG9yYWdlXG4gICAqIEBzdWJjYXRlZ29yeSBGaWxlIEJ1Y2tldHNcbiAgICpcbiAgICogQHBhcmFtIGlkIFRoZSBidWNrZXQgaWQgdG8gb3BlcmF0ZSBvbi5cbiAgICpcbiAgICogQGV4YW1wbGUgQWNjZXNzaW5nIGEgYnVja2V0XG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogY29uc3QgYXZhdGFycyA9IHN1cGFiYXNlLnN0b3JhZ2UuZnJvbSgnYXZhdGFycycpXG4gICAqIGBgYFxuICAgKi9cbiAgZnJvbShpZDogc3RyaW5nKTogU3RvcmFnZUZpbGVBcGkge1xuICAgIHJldHVybiBuZXcgU3RvcmFnZUZpbGVBcGkodGhpcy51cmwsIHRoaXMuaGVhZGVycywgaWQsIHRoaXMuZmV0Y2gpXG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQGFscGhhXG4gICAqXG4gICAqIEFjY2VzcyB2ZWN0b3Igc3RvcmFnZSBvcGVyYXRpb25zLlxuICAgKlxuICAgKiAqKlB1YmxpYyBhbHBoYToqKiBUaGlzIEFQSSBpcyBwYXJ0IG9mIGEgcHVibGljIGFscGhhIHJlbGVhc2UgYW5kIG1heSBub3QgYmUgYXZhaWxhYmxlIHRvIHlvdXIgYWNjb3VudCB0eXBlLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgU3RvcmFnZVxuICAgKiBAc3ViY2F0ZWdvcnkgVmVjdG9yIEJ1Y2tldHNcbiAgICpcbiAgICogQHJldHVybnMgQSBTdG9yYWdlVmVjdG9yc0NsaWVudCBpbnN0YW5jZSBjb25maWd1cmVkIHdpdGggdGhlIGN1cnJlbnQgc3RvcmFnZSBzZXR0aW5ncy5cbiAgICovXG4gIGdldCB2ZWN0b3JzKCk6IFN0b3JhZ2VWZWN0b3JzQ2xpZW50IHtcbiAgICByZXR1cm4gbmV3IFN0b3JhZ2VWZWN0b3JzQ2xpZW50KHRoaXMudXJsICsgJy92ZWN0b3InLCB7XG4gICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICBmZXRjaDogdGhpcy5mZXRjaCxcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBhbHBoYVxuICAgKlxuICAgKiBBY2Nlc3MgYW5hbHl0aWNzIHN0b3JhZ2Ugb3BlcmF0aW9ucyB1c2luZyBJY2ViZXJnIHRhYmxlcy5cbiAgICpcbiAgICogKipQdWJsaWMgYWxwaGE6KiogVGhpcyBBUEkgaXMgcGFydCBvZiBhIHB1YmxpYyBhbHBoYSByZWxlYXNlIGFuZCBtYXkgbm90IGJlIGF2YWlsYWJsZSB0byB5b3VyIGFjY291bnQgdHlwZS5cbiAgICpcbiAgICogQGNhdGVnb3J5IFN0b3JhZ2VcbiAgICogQHN1YmNhdGVnb3J5IEFuYWx5dGljcyBCdWNrZXRzXG4gICAqXG4gICAqIEByZXR1cm5zIEEgU3RvcmFnZUFuYWx5dGljc0NsaWVudCBpbnN0YW5jZSBjb25maWd1cmVkIHdpdGggdGhlIGN1cnJlbnQgc3RvcmFnZSBzZXR0aW5ncy5cbiAgICovXG4gIGdldCBhbmFseXRpY3MoKTogU3RvcmFnZUFuYWx5dGljc0NsaWVudCB7XG4gICAgcmV0dXJuIG5ldyBTdG9yYWdlQW5hbHl0aWNzQ2xpZW50KHRoaXMudXJsICsgJy9pY2ViZXJnJywgdGhpcy5oZWFkZXJzLCB0aGlzLmZldGNoKVxuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFVQSxJQUFhLGVBQWIsY0FBa0MsTUFBTTtDQU10QyxZQUNFLFNBQ0EsWUFBNEIsV0FDNUIsUUFDQSxZQUNBO0FBQ0EsUUFBTSxRQUFRO09BWE4sbUJBQW1CO0FBWTNCLE9BQUssWUFBWTtBQUNqQixPQUFLLE9BQU8sY0FBYyxZQUFZLHdCQUF3QjtBQUM5RCxPQUFLLFNBQVM7QUFDZCxPQUFLLGFBQWE7O0NBR3BCLFNBS0U7QUFDQSxTQUFPO0dBQ0wsTUFBTSxLQUFLO0dBQ1gsU0FBUyxLQUFLO0dBQ2QsUUFBUSxLQUFLO0dBQ2IsWUFBWSxLQUFLO0dBQ2xCOzs7Ozs7OztBQVNMLFNBQWdCLGVBQWUsT0FBdUM7QUFDcEUsUUFBTyxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsc0JBQXNCOzs7Ozs7QUFPOUUsSUFBYSxrQkFBYixjQUFxQyxhQUFhO0NBSWhELFlBQ0UsU0FDQSxRQUNBLFlBQ0EsWUFBNEIsV0FDNUI7QUFDQSxRQUFNLFNBQVMsV0FBVyxRQUFRLFdBQVc7QUFDN0MsT0FBSyxPQUFPLGNBQWMsWUFBWSwyQkFBMkI7QUFDakUsT0FBSyxTQUFTO0FBQ2QsT0FBSyxhQUFhOztDQUdwQixTQUtFO0FBQ0EsNEJBQ0ssTUFBTSxRQUFROzs7Ozs7O0FBU3ZCLElBQWEsc0JBQWIsY0FBeUMsYUFBYTtDQUdwRCxZQUFZLFNBQWlCLGVBQXdCLFlBQTRCLFdBQVc7QUFDMUYsUUFBTSxTQUFTLFVBQVU7QUFDekIsT0FBSyxPQUFPLGNBQWMsWUFBWSwrQkFBK0I7QUFDckUsT0FBSyxnQkFBZ0I7Ozs7Ozs7QUFZekIsSUFBYSxzQkFBYixjQUF5QyxhQUFhO0NBQ3BELFlBQVksU0FBaUI7QUFDM0IsUUFBTSxTQUFTLFVBQVU7Ozs7Ozs7O0FBUzdCLFNBQWdCLHNCQUFzQixPQUE4QztBQUNsRixRQUFPLGVBQWUsTUFBTSxJQUFLLE1BQXVCLGlCQUFpQjs7Ozs7O0FBTzNFLElBQWEseUJBQWIsY0FBNEMsZ0JBQWdCO0NBQzFELFlBQVksU0FBaUIsUUFBZ0IsWUFBb0I7QUFDL0QsUUFBTSxTQUFTLFFBQVEsWUFBWSxVQUFVOzs7Ozs7O0FBUWpELElBQWEsNkJBQWIsY0FBZ0Qsb0JBQW9CO0NBQ2xFLFlBQVksU0FBaUIsZUFBd0I7QUFDbkQsUUFBTSxTQUFTLGVBQWUsVUFBVTs7Ozs7OztBQVE1QyxJQUFZLDhFQUFMOztBQUVMOztBQUVBOztBQUVBOztBQUVBOztBQUVBOztBQUVBOzs7Ozs7Ozs7Ozs7Ozs7O0FDcEpGLFNBQWdCLFVBQ2QsU0FDQSxNQUNBLE9BQ3dCO0NBQ3hCLE1BQU0sNEJBQWM7Q0FDcEIsTUFBTSxZQUFZLEtBQUssYUFBYTtBQUVwQyxNQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssT0FBTyxDQUNuQyxLQUFJLElBQUksYUFBYSxLQUFLLFVBQ3hCLFFBQU8sT0FBTztBQUlsQixRQUFPLGFBQWE7QUFDcEIsUUFBTzs7Ozs7Ozs7OztBQVdULFNBQWdCLGlCQUFpQixTQUF5RDtDQUN4RixNQUFNQSxTQUFpQyxFQUFFO0FBQ3pDLE1BQUssTUFBTSxDQUFDLEtBQUssVUFBVSxPQUFPLFFBQVEsUUFBUSxDQUNoRCxRQUFPLElBQUksYUFBYSxJQUFJO0FBRTlCLFFBQU87Ozs7Ozs7Ozs7OztBQ2hDVCxNQUFhLGdCQUFnQixnQkFBK0I7QUFDMUQsS0FBSSxZQUNGLFNBQVEsR0FBRyxTQUFTLFlBQVksR0FBRyxLQUFLO0FBRTFDLFNBQVEsR0FBRyxTQUFTLE1BQU0sR0FBRyxLQUFLOzs7Ozs7Ozs7O0FBcUJwQyxNQUFhLGlCQUFpQixVQUEyQjtBQUN2RCxLQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsS0FDekMsUUFBTztDQUdULE1BQU0sWUFBWSxPQUFPLGVBQWUsTUFBTTtBQUM5QyxTQUNHLGNBQWMsUUFDYixjQUFjLE9BQU8sYUFDckIsT0FBTyxlQUFlLFVBQVUsS0FBSyxTQUN2QyxFQUFFLE9BQU8sZUFBZSxVQUN4QixFQUFFLE9BQU8sWUFBWTs7Ozs7Ozs7O0FBV3pCLE1BQWEsb0JBQW9CLFNBQXVDO0FBQ3RFLEtBQUksTUFBTSxRQUFRLEtBQUssQ0FDckIsUUFBTyxLQUFLLEtBQUssT0FBTyxpQkFBaUIsR0FBRyxDQUFDO1VBQ3BDLE9BQU8sU0FBUyxjQUFjLFNBQVMsT0FBTyxLQUFLLENBQzVELFFBQU87Q0FHVCxNQUFNQyxTQUE4QixFQUFFO0FBQ3RDLFFBQU8sUUFBUSxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssV0FBVztFQUM3QyxNQUFNLFNBQVMsSUFBSSxRQUFRLGtCQUFrQixNQUFNLEVBQUUsYUFBYSxDQUFDLFFBQVEsU0FBUyxHQUFHLENBQUM7QUFDeEYsU0FBTyxVQUFVLGlCQUFpQixNQUFNO0dBQ3hDO0FBRUYsUUFBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQlQsTUFBYSxxQkFBcUIsZUFBZ0M7QUFDaEUsS0FBSSxDQUFDLGNBQWMsT0FBTyxlQUFlLFNBQ3ZDLFFBQU87QUFJVCxLQUFJLFdBQVcsV0FBVyxLQUFLLFdBQVcsU0FBUyxJQUNqRCxRQUFPO0FBSVQsS0FBSSxXQUFXLE1BQU0sS0FBSyxXQUN4QixRQUFPO0FBTVQsS0FBSSxXQUFXLFNBQVMsSUFBSSxJQUFJLFdBQVcsU0FBUyxLQUFLLENBQ3ZELFFBQU87QUFPVCxRQUR3Qiw0QkFDRCxLQUFLLFdBQVc7Ozs7Ozs7Ozs7QUNyRnpDLE1BQU0sb0JBQW9CLFFBQXlCO0FBQ2pELEtBQUksT0FBTyxRQUFRLFlBQVksUUFBUSxNQUFNO0VBQzNDLE1BQU0sSUFBSTtBQUNWLE1BQUksT0FBTyxFQUFFLFFBQVEsU0FBVSxRQUFPLEVBQUU7QUFDeEMsTUFBSSxPQUFPLEVBQUUsWUFBWSxTQUFVLFFBQU8sRUFBRTtBQUM1QyxNQUFJLE9BQU8sRUFBRSxzQkFBc0IsU0FBVSxRQUFPLEVBQUU7QUFDdEQsTUFBSSxPQUFPLEVBQUUsVUFBVSxTQUFVLFFBQU8sRUFBRTtBQUMxQyxNQUFJLE9BQU8sRUFBRSxVQUFVLFlBQVksRUFBRSxVQUFVLE1BQU07R0FDbkQsTUFBTSxTQUFTLEVBQUU7QUFDakIsT0FBSSxPQUFPLE9BQU8sWUFBWSxTQUFVLFFBQU8sT0FBTzs7O0FBRzFELFFBQU8sS0FBSyxVQUFVLElBQUk7Ozs7Ozs7OztBQVU1QixNQUFNLGNBQWMsT0FDbEIsT0FDQSxRQUNBLFNBQ0EsY0FDRztBQVVILEtBTEUsVUFBVSxRQUNWLE9BQU8sVUFBVSxZQUNqQixVQUFVLFNBQ1YsT0FBUSxNQUFrQyxTQUFTLFlBRWpDO0VBQ2xCLE1BQU0sZ0JBQWdCO0VBRXRCLElBQUksU0FBUyxTQUFTLE9BQU8sY0FBYyxPQUFPLEVBQUUsR0FBRztBQUN2RCxNQUFJLENBQUMsT0FBTyxTQUFTLE9BQU8sQ0FDMUIsVUFBUztBQUdYLGdCQUNHLE1BQU0sQ0FDTixNQUNFLFFBQXlGO0dBQ3hGLE1BQU0sd0RBQWEsSUFBSywwREFBYyxJQUFLLFNBQVEsU0FBUztBQUM1RCxVQUFPLElBQUksZ0JBQWdCLGlCQUFpQixJQUFJLEVBQUUsUUFBUSxZQUFZLFVBQVUsQ0FBQztJQUVwRixDQUNBLFlBQVk7R0FDWCxNQUFNLGFBQWEsU0FBUztBQUU1QixVQUFPLElBQUksZ0JBREssY0FBYyxjQUFjLFFBQVEsT0FBTyxTQUN2QixRQUFRLFlBQVksVUFBVSxDQUFDO0lBQ25FO09BRUosUUFBTyxJQUFJLG9CQUFvQixpQkFBaUIsTUFBTSxFQUFFLE9BQU8sVUFBVSxDQUFDOzs7Ozs7Ozs7O0FBWTlFLE1BQU0scUJBQ0osUUFDQSxTQUNBLFlBQ0EsU0FDRztDQUNILE1BQU1DLFNBQStCO0VBQUU7RUFBUSw0REFBUyxRQUFTLFlBQVcsRUFBRTtFQUFFO0FBRWhGLEtBQUksV0FBVyxTQUFTLFdBQVcsVUFBVSxDQUFDLEtBQzVDLDBDQUFZLFNBQVc7QUFHekIsS0FBSSxjQUFjLEtBQUssRUFBRTs7RUFDdkIsTUFBTSw2REFBVSxRQUFTLFlBQVcsRUFBRTtFQUN0QyxJQUFJQztBQUVKLE9BQUssTUFBTSxDQUFDLEtBQUssVUFBVSxPQUFPLFFBQVEsUUFBUSxDQUNoRCxLQUFJLElBQUksYUFBYSxLQUFLLGVBQ3hCLGVBQWM7QUFJbEIsU0FBTyxVQUFVLFVBQVUsU0FBUyxnQ0FBZ0Isa0VBQWUsbUJBQW1CO0FBQ3RGLFNBQU8sT0FBTyxLQUFLLFVBQVUsS0FBSztPQUVsQyxRQUFPLE9BQU87QUFHaEIsdURBQUksUUFBUyxPQUNYLFFBQU8sU0FBUyxRQUFRO0FBRzFCLDBDQUFZLFNBQVc7Ozs7Ozs7Ozs7Ozs7QUFjekIsZUFBZSxlQUNiLFNBQ0EsUUFDQSxLQUNBLFNBQ0EsWUFDQSxNQUNBLFdBQ2M7QUFDZCxRQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7QUFDdEMsVUFBUSxLQUFLLGtCQUFrQixRQUFRLFNBQVMsWUFBWSxLQUFLLENBQUMsQ0FDL0QsTUFBTSxXQUFXO0FBQ2hCLE9BQUksQ0FBQyxPQUFPLEdBQUksT0FBTTtBQUN0Qix5REFBSSxRQUFTLGNBQWUsUUFBTztBQU1uQyxPQUFJLGNBQWMsV0FBVztJQUMzQixNQUFNLGNBQWMsT0FBTyxRQUFRLElBQUksZUFBZTtBQUl0RCxRQUhzQixPQUFPLFFBQVEsSUFBSSxpQkFBaUIsS0FHcEMsT0FBTyxPQUFPLFdBQVcsSUFDN0MsUUFBTyxFQUFFO0FBSVgsUUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLFNBQVMsbUJBQW1CLENBQzNELFFBQU8sRUFBRTs7QUFJYixVQUFPLE9BQU8sTUFBTTtJQUNwQixDQUNELE1BQU0sU0FBUyxRQUFRLEtBQUssQ0FBQyxDQUM3QixPQUFPLFVBQVUsWUFBWSxPQUFPLFFBQVEsU0FBUyxVQUFVLENBQUM7R0FDbkU7Ozs7Ozs7QUFRSixTQUFnQixlQUFlLFlBQTRCLFdBQVc7QUFDcEUsUUFBTztFQVNMLEtBQUssT0FDSCxTQUNBLEtBQ0EsU0FDQSxlQUNpQjtBQUNqQixVQUFPLGVBQWUsU0FBUyxPQUFPLEtBQUssU0FBUyxZQUFZLFFBQVcsVUFBVTs7RUFZdkYsTUFBTSxPQUNKLFNBQ0EsS0FDQSxNQUNBLFNBQ0EsZUFDaUI7QUFDakIsVUFBTyxlQUFlLFNBQVMsUUFBUSxLQUFLLFNBQVMsWUFBWSxNQUFNLFVBQVU7O0VBWW5GLEtBQUssT0FDSCxTQUNBLEtBQ0EsTUFDQSxTQUNBLGVBQ2lCO0FBQ2pCLFVBQU8sZUFBZSxTQUFTLE9BQU8sS0FBSyxTQUFTLFlBQVksTUFBTSxVQUFVOztFQVdsRixNQUFNLE9BQ0osU0FDQSxLQUNBLFNBQ0EsZUFDaUI7QUFDakIsVUFBTyxlQUNMLFNBQ0EsUUFDQSx1Q0FFSyxnQkFDSCxlQUFlLFNBRWpCLFlBQ0EsUUFDQSxVQUNEOztFQVlILFFBQVEsT0FDTixTQUNBLEtBQ0EsTUFDQSxTQUNBLGVBQ2lCO0FBQ2pCLFVBQU8sZUFBZSxTQUFTLFVBQVUsS0FBSyxTQUFTLFlBQVksTUFBTSxVQUFVOztFQUV0Rjs7QUFJSCxNQUFNLGFBQWEsZUFBZSxVQUFVO0FBQzVDLE1BQWEsRUFBRSxLQUFLLE1BQU0sS0FBSyxNQUFNLFdBQVc7QUFHaEQsTUFBYSxhQUFhLGVBQWUsVUFBVTs7Ozs7Ozs7Ozs7QUNsU25ELElBQThCLGdCQUE5QixNQUF3Rjs7Ozs7Ozs7Q0FjdEYsWUFDRSxLQUNBLFVBQXFDLEVBQUUsRUFDdkMsU0FDQSxZQUE0QixXQUM1QjtPQWZRLHFCQUFxQjtBQWdCN0IsT0FBSyxNQUFNO0FBQ1gsT0FBSyxVQUFVLGlCQUFpQixRQUFRO0FBQ3hDLE9BQUssUUFBUSxhQUFhQyxRQUFNO0FBQ2hDLE9BQUssWUFBWTs7Ozs7Ozs7Q0FTbkIsQUFBTyxlQUFxQjtBQUMxQixPQUFLLHFCQUFxQjtBQUMxQixTQUFPOzs7Ozs7Ozs7O0NBV1QsQUFBTyxVQUFVLE1BQWMsT0FBcUI7QUFDbEQsT0FBSyxVQUFVQyxVQUFjLEtBQUssU0FBUyxNQUFNLE1BQU07QUFDdkQsU0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNEJULE1BQWdCLGdCQUNkLFdBQ21FOztBQUNuRSxNQUFJO0FBRUYsVUFBTztJQUFFLE1BREksTUFBTSxXQUFXO0lBQ2YsT0FBTztJQUFNO1dBQ3JCLE9BQU87QUFDZCxPQUFJQyxNQUFLLG1CQUNQLE9BQU07QUFFUixPQUFJLGVBQWUsTUFBTSxDQUN2QixRQUFPO0lBQUUsTUFBTTtJQUFhO0lBQWlCO0FBRS9DLFNBQU07Ozs7Ozs7O3dCQ2hHQSxPQUFPO0FBRG5CLElBQXFCLHdCQUFyQixNQUE4RjtDQUk1RixZQUNFLEFBQVFDLFlBQ1IsQUFBUUMsb0JBQ1I7RUFGUTtFQUNBO2dDQUw4QjtPQUNoQyxVQUEwRDs7Q0FPbEUsS0FDRSxhQUdBLFlBQzhCO0FBQzlCLFNBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxhQUFhLFdBQVc7O0NBR3hELE1BQ0UsWUFDbUQ7QUFDbkQsU0FBTyxLQUFLLFlBQVksQ0FBQyxNQUFNLFdBQVc7O0NBRzVDLFFBQVEsV0FBMEU7QUFDaEYsU0FBTyxLQUFLLFlBQVksQ0FBQyxRQUFRLFVBQVU7O0NBRzdDLEFBQVEsYUFBc0Q7QUFDNUQsTUFBSSxDQUFDLEtBQUssUUFDUixNQUFLLFVBQVUsS0FBSyxTQUFTO0FBRS9CLFNBQU8sS0FBSzs7Q0FHZCxNQUFjLFVBQW1EOztBQUMvRCxNQUFJO0FBR0YsVUFBTztJQUNMLE9BSGEsTUFBTUMsTUFBSyxZQUFZLEVBR3ZCO0lBQ2IsT0FBTztJQUNSO1dBQ00sT0FBTztBQUNkLE9BQUlBLE1BQUssbUJBQ1AsT0FBTTtBQUdSLE9BQUksZUFBZSxNQUFNLENBQ3ZCLFFBQU87SUFBRSxNQUFNO0lBQU07SUFBTztBQUc5QixTQUFNOzs7Ozs7OztzQkNsREEsT0FBTztBQURuQixJQUFxQixzQkFBckIsTUFBa0Y7Q0FJaEYsWUFDRSxBQUFRQyxZQUNSLEFBQVFDLG9CQUNSO0VBRlE7RUFDQTs4QkFMOEI7T0FDaEMsVUFBZ0Q7O0NBT3hELFdBQWtDO0FBQ2hDLFNBQU8sSUFBSSxzQkFBc0IsS0FBSyxZQUFZLEtBQUssbUJBQW1COztDQUc1RSxLQUNFLGFBQ0EsWUFDOEI7QUFDOUIsU0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLGFBQWEsV0FBVzs7Q0FHeEQsTUFDRSxZQUN5QztBQUN6QyxTQUFPLEtBQUssWUFBWSxDQUFDLE1BQU0sV0FBVzs7Q0FHNUMsUUFBUSxXQUFnRTtBQUN0RSxTQUFPLEtBQUssWUFBWSxDQUFDLFFBQVEsVUFBVTs7Q0FHN0MsQUFBUSxhQUE0QztBQUNsRCxNQUFJLENBQUMsS0FBSyxRQUNSLE1BQUssVUFBVSxLQUFLLFNBQVM7QUFFL0IsU0FBTyxLQUFLOztDQUdkLE1BQWMsVUFBeUM7O0FBQ3JELE1BQUk7QUFHRixVQUFPO0lBQ0wsTUFBTSxPQUhPLE1BQU1DLE1BQUssWUFBWSxFQUdqQixNQUFNO0lBQ3pCLE9BQU87SUFDUjtXQUNNLE9BQU87QUFDZCxPQUFJQSxNQUFLLG1CQUNQLE9BQU07QUFHUixPQUFJLGVBQWUsTUFBTSxDQUN2QixRQUFPO0lBQUUsTUFBTTtJQUFNO0lBQU87QUFHOUIsU0FBTTs7Ozs7OztBQ2xDWixNQUFNLHlCQUF5QjtDQUM3QixPQUFPO0NBQ1AsUUFBUTtDQUNSLFFBQVE7RUFDTixRQUFRO0VBQ1IsT0FBTztFQUNSO0NBQ0Y7QUFFRCxNQUFNQyx1QkFBb0M7Q0FDeEMsY0FBYztDQUNkLGFBQWE7Q0FDYixRQUFRO0NBQ1Q7QUFjRCxJQUFxQixpQkFBckIsY0FBNEMsY0FBNEI7Q0FHdEUsWUFDRSxLQUNBLFVBQXFDLEVBQUUsRUFDdkMsVUFDQSxTQUNBO0FBQ0EsUUFBTSxLQUFLLFNBQVNDLFNBQU8sVUFBVTtBQUNyQyxPQUFLLFdBQVc7Ozs7Ozs7OztDQVVsQixNQUFjLGVBQ1osUUFDQSxNQUNBLFVBQ0EsYUFVQTs7QUFDQSxTQUFPQyxNQUFLLGdCQUFnQixZQUFZO0dBQ3RDLElBQUk7R0FDSixNQUFNLDRDQUFlLHVCQUF5QjtHQUM5QyxJQUFJQyw0Q0FDQ0QsTUFBSyxVQUNKLFdBQVcsVUFBVSxFQUFFLFlBQVksT0FBTyxRQUFRLE9BQWtCLEVBQUU7R0FHNUUsTUFBTSxXQUFXLFFBQVE7QUFFekIsT0FBSSxPQUFPLFNBQVMsZUFBZSxvQkFBb0IsTUFBTTtBQUMzRCxXQUFPLElBQUksVUFBVTtBQUNyQixTQUFLLE9BQU8sZ0JBQWdCLFFBQVEsYUFBdUI7QUFDM0QsUUFBSSxTQUNGLE1BQUssT0FBTyxZQUFZQSxNQUFLLGVBQWUsU0FBUyxDQUFDO0FBRXhELFNBQUssT0FBTyxJQUFJLFNBQVM7Y0FDaEIsT0FBTyxhQUFhLGVBQWUsb0JBQW9CLFVBQVU7QUFDMUUsV0FBTztBQUVQLFFBQUksQ0FBQyxLQUFLLElBQUksZUFBZSxDQUMzQixNQUFLLE9BQU8sZ0JBQWdCLFFBQVEsYUFBdUI7QUFFN0QsUUFBSSxZQUFZLENBQUMsS0FBSyxJQUFJLFdBQVcsQ0FDbkMsTUFBSyxPQUFPLFlBQVlBLE1BQUssZUFBZSxTQUFTLENBQUM7VUFFbkQ7QUFDTCxXQUFPO0FBQ1AsWUFBUSxtQkFBbUIsV0FBVyxRQUFRO0FBQzlDLFlBQVEsa0JBQWtCLFFBQVE7QUFFbEMsUUFBSSxTQUNGLFNBQVEsZ0JBQWdCQSxNQUFLLFNBQVNBLE1BQUssZUFBZSxTQUFTLENBQUM7QUFTdEUsU0FIRyxPQUFPLG1CQUFtQixlQUFlLGdCQUFnQixrQkFDekQsUUFBUSxPQUFPLFNBQVMsWUFBWSxVQUFVLFFBQVEsT0FBTyxLQUFLLFNBQVMsZUFFOUQsQ0FBQyxRQUFRLE9BQ3ZCLFNBQVEsU0FBUzs7QUFJckIsaUVBQUksWUFBYSxRQUNmLE1BQUssTUFBTSxDQUFDLEtBQUssVUFBVSxPQUFPLFFBQVEsWUFBWSxRQUFRLENBQzVELFdBQVUsVUFBVSxTQUFTLEtBQUssTUFBTTtHQUk1QyxNQUFNLFlBQVlBLE1BQUssb0JBQW9CLEtBQUs7R0FDaEQsTUFBTSxRQUFRQSxNQUFLLGNBQWMsVUFBVTtHQUMzQyxNQUFNLE9BQU8sT0FBTyxVQUFVLFFBQVEsTUFBTSxNQUMxQ0EsTUFBSyxPQUNMLEdBQUdBLE1BQUssSUFBSSxVQUFVLFNBQ3RCLHVCQUNFLDhEQUFhLFFBQVMsVUFBUyxFQUFFLFFBQVEsUUFBUSxRQUFRLEdBQUcsRUFBRSxFQUNqRTtBQUVELFVBQU87SUFBRSxNQUFNO0lBQVcsSUFBSSxLQUFLO0lBQUksVUFBVSxLQUFLO0lBQUs7SUFDM0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNFSixNQUFNLE9BQ0osTUFDQSxVQUNBLGFBVUE7QUFDQSxjQUFZLGVBQWUsUUFBUSxNQUFNLFVBQVUsWUFBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlDakUsTUFBTSxrQkFDSixNQUNBLE9BQ0EsVUFDQSxhQUNBOztFQUNBLE1BQU0sWUFBWUEsT0FBSyxvQkFBb0IsS0FBSztFQUNoRCxNQUFNLFFBQVFBLE9BQUssY0FBYyxVQUFVO0VBRTNDLE1BQU0sTUFBTSxJQUFJLElBQUlBLE9BQUssTUFBTSx1QkFBdUIsUUFBUTtBQUM5RCxNQUFJLGFBQWEsSUFBSSxTQUFTLE1BQU07QUFFcEMsU0FBT0EsT0FBSyxnQkFBZ0IsWUFBWTtHQUN0QyxJQUFJO0dBQ0osTUFBTSw0Q0FBZSx1QkFBeUI7R0FDOUMsSUFBSUMsNENBQ0NELE9BQUssVUFDTCxFQUFFLFlBQVksT0FBTyxRQUFRLE9BQWtCLEVBQUU7R0FHdEQsTUFBTSxXQUFXLFFBQVE7QUFFekIsT0FBSSxPQUFPLFNBQVMsZUFBZSxvQkFBb0IsTUFBTTtBQUMzRCxXQUFPLElBQUksVUFBVTtBQUNyQixTQUFLLE9BQU8sZ0JBQWdCLFFBQVEsYUFBdUI7QUFDM0QsUUFBSSxTQUNGLE1BQUssT0FBTyxZQUFZQSxPQUFLLGVBQWUsU0FBUyxDQUFDO0FBRXhELFNBQUssT0FBTyxJQUFJLFNBQVM7Y0FDaEIsT0FBTyxhQUFhLGVBQWUsb0JBQW9CLFVBQVU7QUFDMUUsV0FBTztBQUNQLFFBQUksQ0FBQyxLQUFLLElBQUksZUFBZSxDQUMzQixNQUFLLE9BQU8sZ0JBQWdCLFFBQVEsYUFBdUI7QUFFN0QsUUFBSSxZQUFZLENBQUMsS0FBSyxJQUFJLFdBQVcsQ0FDbkMsTUFBSyxPQUFPLFlBQVlBLE9BQUssZUFBZSxTQUFTLENBQUM7VUFFbkQ7QUFDTCxXQUFPO0FBQ1AsWUFBUSxtQkFBbUIsV0FBVyxRQUFRO0FBQzlDLFlBQVEsa0JBQWtCLFFBQVE7QUFDbEMsUUFBSSxTQUNGLFNBQVEsZ0JBQWdCQSxPQUFLLFNBQVNBLE9BQUssZUFBZSxTQUFTLENBQUM7QUFPdEUsU0FIRyxPQUFPLG1CQUFtQixlQUFlLGdCQUFnQixrQkFDekQsUUFBUSxPQUFPLFNBQVMsWUFBWSxVQUFVLFFBQVEsT0FBTyxLQUFLLFNBQVMsZUFFOUQsQ0FBQyxRQUFRLE9BQ3ZCLFNBQVEsU0FBUzs7QUFJckIsaUVBQUksWUFBYSxRQUNmLE1BQUssTUFBTSxDQUFDLEtBQUssVUFBVSxPQUFPLFFBQVEsWUFBWSxRQUFRLENBQzVELFdBQVUsVUFBVSxTQUFTLEtBQUssTUFBTTtBQVM1QyxVQUFPO0lBQUUsTUFBTTtJQUFXLFdBTGIsTUFBTSxJQUFJQSxPQUFLLE9BQU8sSUFBSSxVQUFVLEVBQUUsdUJBQ2pELDhEQUNJLFFBQVMsVUFBUyxFQUFFLFFBQVEsUUFBUSxRQUFRLEdBQUcsRUFBRSxFQUNyRCxFQUV1QztJQUFLO0lBQzlDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3Q0osTUFBTSxzQkFDSixNQUNBLFNBVUE7O0FBQ0EsU0FBT0EsT0FBSyxnQkFBZ0IsWUFBWTtHQUN0QyxJQUFJLFFBQVFBLE9BQUssY0FBYyxLQUFLO0dBRXBDLE1BQU0sNkJBQWVBLE9BQUs7QUFFMUIseURBQUksUUFBUyxPQUNYLFNBQVEsY0FBYztHQUd4QixNQUFNLE9BQU8sTUFBTSxLQUNqQkEsT0FBSyxPQUNMLEdBQUdBLE9BQUssSUFBSSxzQkFBc0IsU0FDbEMsRUFBRSxFQUNGLEVBQUUsU0FBUyxDQUNaO0dBRUQsTUFBTSxNQUFNLElBQUksSUFBSUEsT0FBSyxNQUFNLEtBQUssSUFBSTtHQUV4QyxNQUFNLFFBQVEsSUFBSSxhQUFhLElBQUksUUFBUTtBQUUzQyxPQUFJLENBQUMsTUFDSCxPQUFNLElBQUksYUFBYSwyQkFBMkI7QUFHcEQsVUFBTztJQUFFLFdBQVcsSUFBSSxVQUFVO0lBQUU7SUFBTTtJQUFPO0lBQ2pEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwREosTUFBTSxPQUNKLE1BQ0EsVUFXQSxhQVVBO0FBQ0EsY0FBWSxlQUFlLE9BQU8sTUFBTSxVQUFVLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFDaEUsTUFBTSxLQUNKLFVBQ0EsUUFDQSxTQVVBOztBQUNBLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFDdEMsVUFBTyxNQUFNLEtBQ1hBLE9BQUssT0FDTCxHQUFHQSxPQUFLLElBQUksZUFDWjtJQUNFLFVBQVVBLE9BQUs7SUFDZixXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLHFFQUFtQixRQUFTO0lBQzdCLEVBQ0QsRUFBRSxTQUFTQSxPQUFLLFNBQVMsQ0FDMUI7SUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUNKLE1BQU0sS0FDSixVQUNBLFFBQ0EsU0FVQTs7QUFDQSxTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0FBWXRDLFVBQU8sRUFBRSxPQVhJLE1BQU0sS0FDakJBLE9BQUssT0FDTCxHQUFHQSxPQUFLLElBQUksZUFDWjtJQUNFLFVBQVVBLE9BQUs7SUFDZixXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLHFFQUFtQixRQUFTO0lBQzdCLEVBQ0QsRUFBRSxTQUFTQSxPQUFLLFNBQVMsQ0FDMUIsRUFDbUIsS0FBSztJQUN6Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQThESixNQUFNLGdCQUNKLE1BQ0EsV0FDQSxTQWNBOztBQUNBLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7R0FDdEMsSUFBSSxRQUFRQSxPQUFLLGNBQWMsS0FBSztHQUVwQyxNQUFNLGVBQ0osMERBQU8sUUFBUyxlQUFjLFlBQzlCLFFBQVEsY0FBYyxRQUN0QixPQUFPLEtBQUssUUFBUSxVQUFVLENBQUMsU0FBUztHQUUxQyxJQUFJLE9BQU8sTUFBTSxLQUNmQSxPQUFLLE9BQ0wsR0FBR0EsT0FBSyxJQUFJLGVBQWUsMEJBQ3pCLGFBQWUsZUFBZSxFQUFFLFdBQVcsUUFBUyxXQUFXLEdBQUcsRUFBRSxHQUN0RSxFQUFFLFNBQVNBLE9BQUssU0FBUyxDQUMxQjtHQUVELE1BQU0sUUFBUSxJQUFJLGlCQUFpQjtBQUNuQyx5REFBSSxRQUFTLFNBQ1gsT0FBTSxJQUFJLFlBQVksUUFBUSxhQUFhLE9BQU8sS0FBSyxRQUFRLFNBQVM7QUFDMUUsMERBQUksUUFBUyxlQUFjLEtBQU0sT0FBTSxJQUFJLGNBQWMsT0FBTyxRQUFRLFdBQVcsQ0FBQztHQUNwRixNQUFNLGNBQWMsTUFBTSxVQUFVO0FBUXBDLFVBQU8sRUFBRSxXQUpTLFVBQ2hCLEdBQUdBLE9BQUssTUFBTSxLQUFLLFlBQVksY0FBYyxJQUFJLGdCQUFnQixLQUNsRSxFQUVtQjtJQUNwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaURKLE1BQU0saUJBQ0osT0FDQSxXQUNBLFNBVUE7O0FBQ0EsU0FBT0EsT0FBSyxnQkFBZ0IsWUFBWTtHQUN0QyxNQUFNLE9BQU8sTUFBTSxLQUNqQkEsT0FBSyxPQUNMLEdBQUdBLE9BQUssSUFBSSxlQUFlQSxPQUFLLFlBQ2hDO0lBQUU7SUFBVztJQUFPLEVBQ3BCLEVBQUUsU0FBU0EsT0FBSyxTQUFTLENBQzFCO0dBRUQsTUFBTSxRQUFRLElBQUksaUJBQWlCO0FBRW5DLHlEQUFJLFFBQVMsU0FDWCxPQUFNLElBQUksWUFBWSxRQUFRLGFBQWEsT0FBTyxLQUFLLFFBQVEsU0FBUztBQUMxRSwwREFBSSxRQUFTLGVBQWMsS0FBTSxPQUFNLElBQUksY0FBYyxPQUFPLFFBQVEsV0FBVyxDQUFDO0dBRXBGLE1BQU0sY0FBYyxNQUFNLFVBQVU7QUFFcEMsVUFBTyxLQUFLLEtBQUssNENBQ1osY0FDSCxXQUFXLE1BQU0sWUFDYixVQUFVLEdBQUdBLE9BQUssTUFBTSxNQUFNLFlBQVksY0FBYyxJQUFJLGdCQUFnQixLQUFLLEdBQ2pGLFFBQ0g7SUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxRUosU0FDRSxNQUNBLFNBQ0EsWUFDcUI7RUFLckIsTUFBTSxhQUhKLDBEQUFPLFFBQVMsZUFBYyxZQUM5QixRQUFRLGNBQWMsUUFDdEIsT0FBTyxLQUFLLFFBQVEsVUFBVSxDQUFDLFNBQVMsSUFDRCwrQkFBK0I7RUFFeEUsTUFBTSxRQUFRLElBQUksaUJBQWlCO0FBQ25DLHdEQUFJLFFBQVMsVUFBVyxNQUFLLDBCQUEwQixPQUFPLFFBQVEsVUFBVTtBQUNoRix5REFBSSxRQUFTLGVBQWMsS0FBTSxPQUFNLElBQUksY0FBYyxPQUFPLFFBQVEsV0FBVyxDQUFDO0VBQ3BGLE1BQU0sY0FBYyxNQUFNLFVBQVU7RUFFcEMsTUFBTSxRQUFRLEtBQUssY0FBYyxLQUFLO0VBQ3RDLE1BQU0sbUJBQ0osSUFDRSxLQUFLLE9BQ0wsR0FBRyxLQUFLLElBQUksR0FBRyxXQUFXLEdBQUcsUUFBUSxjQUFjLElBQUksZ0JBQWdCLE1BQ3ZFO0dBQ0UsU0FBUyxLQUFLO0dBQ2QsZUFBZTtHQUNoQixFQUNELFdBQ0Q7QUFDSCxTQUFPLElBQUksb0JBQW9CLFlBQVksS0FBSyxtQkFBbUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkJyRSxNQUFNLEtBQUssTUFTVDs7RUFDQSxNQUFNLFFBQVFBLFFBQUssY0FBYyxLQUFLO0FBRXRDLFNBQU9BLFFBQUssZ0JBQWdCLFlBQVk7QUFLdEMsVUFBTyxpQkFKTSxNQUFNLElBQUlBLFFBQUssT0FBTyxHQUFHQSxRQUFLLElBQUksZUFBZSxTQUFTLEVBQ3JFLFNBQVNBLFFBQUssU0FDZixDQUFDLENBRTJCO0lBQzdCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkosTUFBTSxPQUFPLE1BU1g7O0VBQ0EsTUFBTSxRQUFRQSxRQUFLLGNBQWMsS0FBSztBQUV0QyxNQUFJO0FBQ0YsU0FBTSxLQUFLQSxRQUFLLE9BQU8sR0FBR0EsUUFBSyxJQUFJLFVBQVUsU0FBUyxFQUNwRCxTQUFTQSxRQUFLLFNBQ2YsQ0FBQztBQUVGLFVBQU87SUFBRSxNQUFNO0lBQU0sT0FBTztJQUFNO1dBQzNCLE9BQU87QUFDZCxPQUFJQSxRQUFLLG1CQUNQLE9BQU07QUFFUixPQUFJLGVBQWUsTUFBTSxFQUFFOztJQUV6QixNQUFNLFNBQ0osaUJBQWlCLGtCQUNiLE1BQU0sU0FDTixpQkFBaUIsOENBQ2QsTUFBTSwyRkFBc0MsU0FDN0M7QUFFUixRQUFJLFdBQVcsVUFBYSxDQUFDLEtBQUssSUFBSSxDQUFDLFNBQVMsT0FBTyxDQUNyRCxRQUFPO0tBQUUsTUFBTTtLQUFPO0tBQU87O0FBSWpDLFNBQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBK0RWLGFBQ0UsTUFDQSxTQUtpQztFQUNqQyxNQUFNLFFBQVEsS0FBSyxjQUFjLEtBQUs7RUFFdEMsTUFBTSxRQUFRLElBQUksaUJBQWlCO0FBQ25DLHdEQUFJLFFBQVMsU0FBVSxPQUFNLElBQUksWUFBWSxRQUFRLGFBQWEsT0FBTyxLQUFLLFFBQVEsU0FBUztBQUMvRix3REFBSSxRQUFTLFVBQVcsTUFBSywwQkFBMEIsT0FBTyxRQUFRLFVBQVU7QUFDaEYseURBQUksUUFBUyxlQUFjLEtBQU0sT0FBTSxJQUFJLGNBQWMsT0FBTyxRQUFRLFdBQVcsQ0FBQztFQUNwRixNQUFNLGNBQWMsTUFBTSxVQUFVO0VBTXBDLE1BQU0sYUFISiwwREFBTyxRQUFTLGVBQWMsWUFDOUIsUUFBUSxjQUFjLFFBQ3RCLE9BQU8sS0FBSyxRQUFRLFVBQVUsQ0FBQyxTQUFTLElBQ0QsaUJBQWlCO0FBRTFELFNBQU8sRUFDTCxNQUFNLEVBQ0osV0FDRSxVQUFVLEdBQUcsS0FBSyxJQUFJLEdBQUcsV0FBVyxVQUFVLFFBQVEsSUFDckQsY0FBYyxJQUFJLGdCQUFnQixLQUN0QyxFQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9DSCxNQUFNLE9BQU8sT0FTWDs7QUFDQSxTQUFPQSxRQUFLLGdCQUFnQixZQUFZO0FBQ3RDLFVBQU8sTUFBTSxPQUNYQSxRQUFLLE9BQ0wsR0FBR0EsUUFBSyxJQUFJLFVBQVVBLFFBQUssWUFDM0IsRUFBRSxVQUFVLE9BQU8sRUFDbkIsRUFBRSxTQUFTQSxRQUFLLFNBQVMsQ0FDMUI7SUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0pKLE1BQU0sS0FDSixNQUNBLFNBQ0EsWUFVQTs7QUFDQSxTQUFPQSxRQUFLLGdCQUFnQixZQUFZO0dBQ3RDLE1BQU0sd0RBQVkseUJBQTJCLGdCQUFTLFFBQVEsUUFBUTtBQUN0RSxVQUFPLE1BQU0sS0FDWEEsUUFBSyxPQUNMLEdBQUdBLFFBQUssSUFBSSxlQUFlQSxRQUFLLFlBQ2hDLE1BQ0EsRUFBRSxTQUFTQSxRQUFLLFNBQVMsRUFDekIsV0FDRDtJQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0RKLE1BQU0sT0FDSixTQUNBLFlBVUE7O0FBQ0EsU0FBT0EsUUFBSyxnQkFBZ0IsWUFBWTtHQUN0QyxNQUFNLDBCQUFZO0FBQ2xCLFVBQU8sTUFBTSxLQUNYQSxRQUFLLE9BQ0wsR0FBR0EsUUFBSyxJQUFJLGtCQUFrQkEsUUFBSyxZQUNuQyxNQUNBLEVBQUUsU0FBU0EsUUFBSyxTQUFTLEVBQ3pCLFdBQ0Q7SUFDRDs7Q0FHSixBQUFVLGVBQWUsVUFBK0I7QUFDdEQsU0FBTyxLQUFLLFVBQVUsU0FBUzs7Q0FHakMsU0FBUyxNQUFjO0FBQ3JCLE1BQUksT0FBTyxXQUFXLFlBQ3BCLFFBQU8sT0FBTyxLQUFLLEtBQUssQ0FBQyxTQUFTLFNBQVM7QUFFN0MsU0FBTyxLQUFLLEtBQUs7O0NBR25CLEFBQVEsY0FBYyxNQUFjO0FBQ2xDLFNBQU8sR0FBRyxLQUFLLFNBQVMsR0FBRyxLQUFLLFFBQVEsUUFBUSxHQUFHOztDQUdyRCxBQUFRLG9CQUFvQixNQUFjO0FBQ3hDLFNBQU8sS0FBSyxRQUFRLFlBQVksR0FBRyxDQUFDLFFBQVEsUUFBUSxJQUFJOzs7Q0FJMUQsQUFBUSwwQkFDTixPQUNBLFdBQ2lCO0FBQ2pCLE1BQUksVUFBVSxNQUFPLE9BQU0sSUFBSSxTQUFTLFVBQVUsTUFBTSxVQUFVLENBQUM7QUFDbkUsTUFBSSxVQUFVLE9BQVEsT0FBTSxJQUFJLFVBQVUsVUFBVSxPQUFPLFVBQVUsQ0FBQztBQUN0RSxNQUFJLFVBQVUsT0FBUSxPQUFNLElBQUksVUFBVSxVQUFVLE9BQU87QUFDM0QsTUFBSSxVQUFVLE9BQVEsT0FBTSxJQUFJLFVBQVUsVUFBVSxPQUFPO0FBQzNELE1BQUksVUFBVSxRQUFTLE9BQU0sSUFBSSxXQUFXLFVBQVUsUUFBUSxVQUFVLENBQUM7QUFFekUsU0FBTzs7Ozs7O0FDcjVDWCxNQUFhLFVBQVU7Ozs7QUNMdkIsTUFBYSxrQkFBa0IsRUFDN0IsaUJBQWlCLGNBQWMsV0FDaEM7Ozs7QUNJRCxJQUFxQixtQkFBckIsY0FBOEMsY0FBNEI7Q0FDeEUsWUFDRSxLQUNBLFVBQXFDLEVBQUUsRUFDdkMsU0FDQSxNQUNBO0VBQ0EsTUFBTSxVQUFVLElBQUksSUFBSSxJQUFJO0FBSTVCLGtEQUFJLEtBQU0sZ0JBRVI7T0FEdUIseUJBQXlCLEtBQUssUUFBUSxTQUFTLElBQ2hELENBQUMsUUFBUSxTQUFTLFNBQVMsb0JBQW9CLENBQ25FLFNBQVEsV0FBVyxRQUFRLFNBQVMsUUFBUSxhQUFhLG9CQUFvQjs7RUFJakYsTUFBTSxXQUFXLFFBQVEsS0FBSyxRQUFRLE9BQU8sR0FBRztFQUNoRCxNQUFNLGlEQUFvQixrQkFBb0I7QUFFOUMsUUFBTSxVQUFVLGNBQWNFLFNBQU8sVUFBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQ2pELE1BQU0sWUFBWSxTQVNoQjs7QUFDQSxTQUFPQyxNQUFLLGdCQUFnQixZQUFZO0dBQ3RDLE1BQU0sY0FBY0EsTUFBSywrQkFBK0IsUUFBUTtBQUNoRSxVQUFPLE1BQU0sSUFBSUEsTUFBSyxPQUFPLEdBQUdBLE1BQUssSUFBSSxTQUFTLGVBQWUsRUFDL0QsU0FBU0EsTUFBSyxTQUNmLENBQUM7SUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkNKLE1BQU0sVUFBVSxJQVNkOztBQUNBLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFDdEMsVUFBTyxNQUFNLElBQUlBLE9BQUssT0FBTyxHQUFHQSxPQUFLLElBQUksVUFBVSxNQUFNLEVBQUUsU0FBU0EsT0FBSyxTQUFTLENBQUM7SUFDbkY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0ErQ0osTUFBTSxhQUNKLElBQ0EsVUFLSSxFQUNGLFFBQVEsT0FDVCxFQVVEOztBQUNBLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFDdEMsVUFBTyxNQUFNLEtBQ1hBLE9BQUssT0FDTCxHQUFHQSxPQUFLLElBQUksVUFDWjtJQUNFO0lBQ0EsTUFBTTtJQUNOLE1BQU0sUUFBUTtJQUNkLFFBQVEsUUFBUTtJQUNoQixpQkFBaUIsUUFBUTtJQUN6QixvQkFBb0IsUUFBUTtJQUM3QixFQUNELEVBQUUsU0FBU0EsT0FBSyxTQUFTLENBQzFCO0lBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkNKLE1BQU0sYUFDSixJQUNBLFNBY0E7O0FBQ0EsU0FBT0EsT0FBSyxnQkFBZ0IsWUFBWTtBQUN0QyxVQUFPLE1BQU0sSUFDWEEsT0FBSyxPQUNMLEdBQUdBLE9BQUssSUFBSSxVQUFVLE1BQ3RCO0lBQ0U7SUFDQSxNQUFNO0lBQ04sUUFBUSxRQUFRO0lBQ2hCLGlCQUFpQixRQUFRO0lBQ3pCLG9CQUFvQixRQUFRO0lBQzdCLEVBQ0QsRUFBRSxTQUFTQSxPQUFLLFNBQVMsQ0FDMUI7SUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0NKLE1BQU0sWUFBWSxJQVNoQjs7QUFDQSxTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0FBQ3RDLFVBQU8sTUFBTSxLQUFLQSxPQUFLLE9BQU8sR0FBR0EsT0FBSyxJQUFJLFVBQVUsR0FBRyxTQUFTLEVBQUUsRUFBRSxFQUFFLFNBQVNBLE9BQUssU0FBUyxDQUFDO0lBQzlGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUNKLE1BQU0sYUFBYSxJQVNqQjs7QUFDQSxTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0FBQ3RDLFVBQU8sTUFBTSxPQUFPQSxPQUFLLE9BQU8sR0FBR0EsT0FBSyxJQUFJLFVBQVUsTUFBTSxFQUFFLEVBQUUsRUFBRSxTQUFTQSxPQUFLLFNBQVMsQ0FBQztJQUMxRjs7Q0FHSixBQUFRLCtCQUErQixTQUFxQztFQUMxRSxNQUFNQyxTQUFpQyxFQUFFO0FBQ3pDLE1BQUksU0FBUztBQUNYLE9BQUksV0FBVyxRQUNiLFFBQU8sUUFBUSxPQUFPLFFBQVEsTUFBTTtBQUV0QyxPQUFJLFlBQVksUUFDZCxRQUFPLFNBQVMsT0FBTyxRQUFRLE9BQU87QUFFeEMsT0FBSSxRQUFRLE9BQ1YsUUFBTyxTQUFTLFFBQVE7QUFFMUIsT0FBSSxRQUFRLFdBQ1YsUUFBTyxhQUFhLFFBQVE7QUFFOUIsT0FBSSxRQUFRLFVBQ1YsUUFBTyxZQUFZLFFBQVE7O0FBRy9CLFNBQU8sT0FBTyxLQUFLLE9BQU8sQ0FBQyxTQUFTLElBQUksTUFBTSxJQUFJLGdCQUFnQixPQUFPLENBQUMsVUFBVSxHQUFHOzs7Ozs7Ozs7O0FDdlkzRixJQUFxQix5QkFBckIsY0FBb0QsY0FBNEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkI5RSxZQUFZLEtBQWEsVUFBcUMsRUFBRSxFQUFFLFNBQWU7RUFDL0UsTUFBTSxXQUFXLElBQUksUUFBUSxPQUFPLEdBQUc7RUFDdkMsTUFBTSxpREFBb0Isa0JBQW9CO0FBQzlDLFFBQU0sVUFBVSxjQUFjQyxTQUFPLFVBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMENqRCxNQUFNLGFBQWEsTUFTakI7O0FBQ0EsU0FBT0MsTUFBSyxnQkFBZ0IsWUFBWTtBQUN0QyxVQUFPLE1BQU0sS0FBS0EsTUFBSyxPQUFPLEdBQUdBLE1BQUssSUFBSSxVQUFVLEVBQUUsTUFBTSxFQUFFLEVBQUUsU0FBU0EsTUFBSyxTQUFTLENBQUM7SUFDeEY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0RKLE1BQU0sWUFBWSxTQWVoQjs7QUFDQSxTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0dBRXRDLE1BQU0sY0FBYyxJQUFJLGlCQUFpQjtBQUN6QywwREFBSSxRQUFTLFdBQVUsT0FBVyxhQUFZLElBQUksU0FBUyxRQUFRLE1BQU0sVUFBVSxDQUFDO0FBQ3BGLDBEQUFJLFFBQVMsWUFBVyxPQUFXLGFBQVksSUFBSSxVQUFVLFFBQVEsT0FBTyxVQUFVLENBQUM7QUFDdkYseURBQUksUUFBUyxXQUFZLGFBQVksSUFBSSxjQUFjLFFBQVEsV0FBVztBQUMxRSx5REFBSSxRQUFTLFVBQVcsYUFBWSxJQUFJLGFBQWEsUUFBUSxVQUFVO0FBQ3ZFLHlEQUFJLFFBQVMsT0FBUSxhQUFZLElBQUksVUFBVSxRQUFRLE9BQU87R0FFOUQsTUFBTSxjQUFjLFlBQVksVUFBVTtHQUMxQyxNQUFNLE1BQU0sY0FBYyxHQUFHQSxPQUFLLElBQUksVUFBVSxnQkFBZ0IsR0FBR0EsT0FBSyxJQUFJO0FBRTVFLFVBQU8sTUFBTSxJQUFJQSxPQUFLLE9BQU8sS0FBSyxFQUFFLFNBQVNBLE9BQUssU0FBUyxDQUFDO0lBQzVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0NKLE1BQU0sYUFBYSxZQVNqQjs7QUFDQSxTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0FBQ3RDLFVBQU8sTUFBTSxPQUNYQSxPQUFLLE9BQ0wsR0FBR0EsT0FBSyxJQUFJLFVBQVUsY0FDdEIsRUFBRSxFQUNGLEVBQUUsU0FBU0EsT0FBSyxTQUFTLENBQzFCO0lBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQStISixLQUFLLFlBQStDOztBQUVsRCxNQUFJLENBQUMsa0JBQWtCLFdBQVcsQ0FDaEMsT0FBTSxJQUFJLGFBQ1IscUpBRUQ7RUFPSCxNQUFNLFVBQVUsSUFBSSxtQkFBbUI7R0FDckMsU0FBUyxLQUFLO0dBQ2QsYUFBYTtHQUNiLE1BQU07SUFDSixNQUFNO0lBQ04sWUFBWSxZQUFZQSxPQUFLO0lBQzlCO0dBQ0QsT0FBTyxLQUFLO0dBQ2IsQ0FBQztFQUVGLE1BQU0scUJBQXFCLEtBQUs7QUF1QmhDLFNBckJ1QixJQUFJLE1BQU0sU0FBUyxFQUN4QyxJQUFJLFFBQVEsTUFBZ0M7R0FDMUMsTUFBTSxRQUFRLE9BQU87QUFDckIsT0FBSSxPQUFPLFVBQVUsV0FDbkIsUUFBTztBQUdULFVBQU8sT0FBTyxHQUFHLFNBQW9CO0FBQ25DLFFBQUk7QUFFRixZQUFPO01BQUUsTUFESSxNQUFPLE1BQW1CLE1BQU0sUUFBUSxLQUFLO01BQzNDLE9BQU87TUFBTTthQUNyQixPQUFPO0FBQ2QsU0FBSSxtQkFDRixPQUFNO0FBRVIsWUFBTztNQUFFLE1BQU07TUFBYTtNQUF1Qjs7O0tBSTFELENBQUM7Ozs7Ozs7Ozs7O0FDNVhOLElBQXFCLGlCQUFyQixjQUE0QyxjQUE0Qjs7Q0FFdEUsWUFBWSxLQUFhLFVBQXFDLEVBQUUsRUFBRSxTQUFlO0VBQy9FLE1BQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxHQUFHO0VBQ3ZDLE1BQU0saURBQW9CLHdCQUFpQixnQkFBZ0Isc0JBQXVCO0FBQ2xGLFFBQU0sVUFBVSxjQUFjQyxTQUFPLFVBQVU7OztDQUlqRCxNQUFNLFlBQVksU0FBOEQ7O0FBQzlFLFNBQU9DLE1BQUssZ0JBQWdCLFlBQVk7QUFJdEMsVUFIYSxNQUFNLFdBQVcsS0FBS0EsTUFBSyxPQUFPLEdBQUdBLE1BQUssSUFBSSxlQUFlLFNBQVMsRUFDakYsU0FBU0EsTUFBSyxTQUNmLENBQUMsSUFDYSxFQUFFO0lBQ2pCOzs7Q0FJSixNQUFNLFNBQ0osa0JBQ0EsV0FDOEM7O0FBQzlDLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFDdEMsVUFBTyxNQUFNLFdBQVcsS0FDdEJBLE9BQUssT0FDTCxHQUFHQSxPQUFLLElBQUksWUFDWjtJQUFFO0lBQWtCO0lBQVcsRUFDL0IsRUFBRSxTQUFTQSxPQUFLLFNBQVMsQ0FDMUI7SUFDRDs7O0NBSUosTUFBTSxZQUFZLFNBQXdFOztBQUN4RixTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0FBQ3RDLFVBQU8sTUFBTSxXQUFXLEtBQUtBLE9BQUssT0FBTyxHQUFHQSxPQUFLLElBQUksZUFBZSxTQUFTLEVBQzNFLFNBQVNBLE9BQUssU0FDZixDQUFDO0lBQ0Y7OztDQUlKLE1BQU0sWUFBWSxrQkFBMEIsV0FBb0Q7O0FBQzlGLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFPdEMsVUFOYSxNQUFNLFdBQVcsS0FDNUJBLE9BQUssT0FDTCxHQUFHQSxPQUFLLElBQUksZUFDWjtJQUFFO0lBQWtCO0lBQVcsRUFDL0IsRUFBRSxTQUFTQSxPQUFLLFNBQVMsQ0FDMUIsSUFDYyxFQUFFO0lBQ2pCOzs7Ozs7Ozs7OztBQ2xFTixJQUFxQixnQkFBckIsY0FBMkMsY0FBNEI7O0NBRXJFLFlBQVksS0FBYSxVQUFxQyxFQUFFLEVBQUUsU0FBZTtFQUMvRSxNQUFNLFdBQVcsSUFBSSxRQUFRLE9BQU8sR0FBRztFQUN2QyxNQUFNLGlEQUFvQix3QkFBaUIsZ0JBQWdCLHNCQUF1QjtBQUNsRixRQUFNLFVBQVUsY0FBY0MsU0FBTyxVQUFVOzs7Q0FJakQsTUFBTSxXQUFXLFNBQTZEOztBQUU1RSxNQUFJLFFBQVEsUUFBUSxTQUFTLEtBQUssUUFBUSxRQUFRLFNBQVMsSUFDekQsT0FBTSxJQUFJLE1BQU0sb0RBQW9EO0FBR3RFLFNBQU9DLE1BQUssZ0JBQWdCLFlBQVk7QUFJdEMsVUFIYSxNQUFNLFdBQVcsS0FBS0EsTUFBSyxPQUFPLEdBQUdBLE1BQUssSUFBSSxjQUFjLFNBQVMsRUFDaEYsU0FBU0EsTUFBSyxTQUNmLENBQUMsSUFDYSxFQUFFO0lBQ2pCOzs7Q0FJSixNQUFNLFdBQVcsU0FBc0U7O0FBQ3JGLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFDdEMsVUFBTyxNQUFNLFdBQVcsS0FBS0EsT0FBSyxPQUFPLEdBQUdBLE9BQUssSUFBSSxjQUFjLFNBQVMsRUFDMUUsU0FBU0EsT0FBSyxTQUNmLENBQUM7SUFDRjs7O0NBSUosTUFBTSxZQUFZLFNBQXdFOztBQUV4RixNQUFJLFFBQVEsaUJBQWlCLFFBQVc7QUFDdEMsT0FBSSxRQUFRLGVBQWUsS0FBSyxRQUFRLGVBQWUsR0FDckQsT0FBTSxJQUFJLE1BQU0sd0NBQXdDO0FBRTFELE9BQUksUUFBUSxpQkFBaUIsUUFDM0I7UUFBSSxRQUFRLGVBQWUsS0FBSyxRQUFRLGdCQUFnQixRQUFRLGFBQzlELE9BQU0sSUFBSSxNQUFNLHNDQUFzQyxRQUFRLGVBQWUsSUFBSTs7O0FBS3ZGLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFDdEMsVUFBTyxNQUFNLFdBQVcsS0FBS0EsT0FBSyxPQUFPLEdBQUdBLE9BQUssSUFBSSxlQUFlLFNBQVMsRUFDM0UsU0FBU0EsT0FBSyxTQUNmLENBQUM7SUFDRjs7O0NBSUosTUFBTSxhQUFhLFNBQTBFOztBQUMzRixTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0FBQ3RDLFVBQU8sTUFBTSxXQUFXLEtBQUtBLE9BQUssT0FBTyxHQUFHQSxPQUFLLElBQUksZ0JBQWdCLFNBQVMsRUFDNUUsU0FBU0EsT0FBSyxTQUNmLENBQUM7SUFDRjs7O0NBSUosTUFBTSxjQUFjLFNBQWdFOztBQUVsRixNQUFJLFFBQVEsS0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLFNBQVMsSUFDbkQsT0FBTSxJQUFJLE1BQU0sa0RBQWtEO0FBR3BFLFNBQU9BLE9BQUssZ0JBQWdCLFlBQVk7QUFJdEMsVUFIYSxNQUFNLFdBQVcsS0FBS0EsT0FBSyxPQUFPLEdBQUdBLE9BQUssSUFBSSxpQkFBaUIsU0FBUyxFQUNuRixTQUFTQSxPQUFLLFNBQ2YsQ0FBQyxJQUNhLEVBQUU7SUFDakI7Ozs7Ozs7Ozs7O0FDL0VOLElBQXFCLGtCQUFyQixjQUE2QyxjQUE0Qjs7Q0FFdkUsWUFBWSxLQUFhLFVBQXFDLEVBQUUsRUFBRSxTQUFlO0VBQy9FLE1BQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxHQUFHO0VBQ3ZDLE1BQU0saURBQW9CLHdCQUFpQixnQkFBZ0Isc0JBQXVCO0FBQ2xGLFFBQU0sVUFBVSxjQUFjQyxTQUFPLFVBQVU7OztDQUlqRCxNQUFNLGFBQWEsa0JBQTJEOztBQUM1RSxTQUFPQyxNQUFLLGdCQUFnQixZQUFZO0FBT3RDLFVBTmEsTUFBTSxXQUFXLEtBQzVCQSxNQUFLLE9BQ0wsR0FBR0EsTUFBSyxJQUFJLHNCQUNaLEVBQUUsa0JBQWtCLEVBQ3BCLEVBQUUsU0FBU0EsTUFBSyxTQUFTLENBQzFCLElBQ2MsRUFBRTtJQUNqQjs7O0NBSUosTUFBTSxVQUFVLGtCQUFnRjs7QUFDOUYsU0FBT0EsT0FBSyxnQkFBZ0IsWUFBWTtBQUN0QyxVQUFPLE1BQU0sV0FBVyxLQUN0QkEsT0FBSyxPQUNMLEdBQUdBLE9BQUssSUFBSSxtQkFDWixFQUFFLGtCQUFrQixFQUNwQixFQUFFLFNBQVNBLE9BQUssU0FBUyxDQUMxQjtJQUNEOzs7Q0FJSixNQUFNLFlBQ0osVUFBb0MsRUFBRSxFQUNXOztBQUNqRCxTQUFPQSxPQUFLLGdCQUFnQixZQUFZO0FBQ3RDLFVBQU8sTUFBTSxXQUFXLEtBQUtBLE9BQUssT0FBTyxHQUFHQSxPQUFLLElBQUkscUJBQXFCLFNBQVMsRUFDakYsU0FBU0EsT0FBSyxTQUNmLENBQUM7SUFDRjs7O0NBSUosTUFBTSxhQUFhLGtCQUEyRDs7QUFDNUUsU0FBT0EsT0FBSyxnQkFBZ0IsWUFBWTtBQU90QyxVQU5hLE1BQU0sV0FBVyxLQUM1QkEsT0FBSyxPQUNMLEdBQUdBLE9BQUssSUFBSSxzQkFDWixFQUFFLGtCQUFrQixFQUNwQixFQUFFLFNBQVNBLE9BQUssU0FBUyxDQUMxQixJQUNjLEVBQUU7SUFDakI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1NOLElBQWEsdUJBQWIsY0FBMEMsZ0JBQWdCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTZCeEQsWUFBWSxLQUFhLFVBQXVDLEVBQUUsRUFBRTtBQUNsRSxRQUFNLEtBQUssUUFBUSxXQUFXLEVBQUUsRUFBRSxRQUFRLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCbEQsS0FBSyxrQkFBNkM7QUFDaEQsU0FBTyxJQUFJLGtCQUFrQixLQUFLLEtBQUssS0FBSyxTQUFTLGtCQUFrQixLQUFLLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCcEYsTUFBTSxhQUFhLGtCQUEyRDt5Q0FDckUsTUFBTTtBQUFiLGtEQUEwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBCNUIsTUFBTSxVQUFVLGtCQUFnRjtzQ0FDdkYsTUFBTTtBQUFiLGdEQUF1Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNEJ6QixNQUFNLFlBQ0osVUFBb0MsRUFBRSxFQUNXO3dDQUMxQyxNQUFNO0FBQWIsa0RBQXlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F5QjNCLE1BQU0sYUFBYSxrQkFBMkQ7eUNBQ3JFLE1BQU07QUFBYixtREFBMEI7Ozs7Ozs7Ozs7OztBQWE5QixJQUFhLG9CQUFiLGNBQXVDLGVBQWU7Ozs7Ozs7Ozs7Ozs7OztDQWlCcEQsWUFDRSxLQUNBLFNBQ0Esa0JBQ0EsU0FDQTtBQUNBLFFBQU0sS0FBSyxTQUFTQyxRQUFNO0FBQzFCLE9BQUssbUJBQW1COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0ErQjFCLE1BQWUsWUFBWSxTQUF1RDt3Q0FDekUsTUFBTTtBQUFiLG9GQUNLLGdCQUNILGtCQUFrQkMsT0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXdCM0IsTUFBZSxZQUFZLFVBQXdELEVBQUUsRUFBRTt3Q0FDOUUsTUFBTTtBQUFiLG9GQUNLLGdCQUNILGtCQUFrQkEsT0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F5QjNCLE1BQWUsU0FBUyxXQUFtQjtxQ0FDbEMsTUFBTTtBQUFiLCtDQUFzQkEsT0FBSyxrQkFBa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1Qi9DLE1BQWUsWUFBWSxXQUFtQjt3Q0FDckMsTUFBTTtBQUFiLGtEQUF5QkEsT0FBSyxrQkFBa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQ2xELE1BQU0sV0FBcUM7QUFDekMsU0FBTyxJQUFJLGlCQUNULEtBQUssS0FDTCxLQUFLLFNBQ0wsS0FBSyxrQkFDTCxXQUNBLEtBQUssTUFDTjs7Ozs7Ozs7Ozs7O0FBYUwsSUFBYSxtQkFBYixjQUFzQyxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7O0NBbUJsRCxZQUNFLEtBQ0EsU0FDQSxrQkFDQSxXQUNBLFNBQ0E7QUFDQSxRQUFNLEtBQUssU0FBU0QsUUFBTTtBQUMxQixPQUFLLG1CQUFtQjtBQUN4QixPQUFLLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQStCbkIsTUFBZSxXQUFXLFNBQW9FO3VDQUNyRixNQUFNO0FBQWIsbUZBQ0s7R0FDSCxrQkFBa0JDLE9BQUs7R0FDdkIsV0FBV0EsT0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EyQnBCLE1BQWUsV0FBVyxTQUFvRTt1Q0FDckYsTUFBTTtBQUFiLG9GQUNLO0dBQ0gsa0JBQWtCQSxRQUFLO0dBQ3ZCLFdBQVdBLFFBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkJwQixNQUFlLFlBQ2IsVUFBc0UsRUFBRSxFQUN4RTt3Q0FDTyxNQUFNO0FBQWIscUZBQ0s7R0FDSCxrQkFBa0JBLFFBQUs7R0FDdkIsV0FBV0EsUUFBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E4QnBCLE1BQWUsYUFDYixTQUNBO3lDQUNPLE1BQU07QUFBYixzRkFDSztHQUNILGtCQUFrQkEsUUFBSztHQUN2QixXQUFXQSxRQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJwQixNQUFlLGNBQ2IsU0FDQTswQ0FDTyxNQUFNO0FBQWIsdUZBQ0s7R0FDSCxrQkFBa0JBLFFBQUs7R0FDdkIsV0FBV0EsUUFBSzs7Ozs7OztBQ3RuQnRCLElBQWEsZ0JBQWIsY0FBbUMsaUJBQWlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBeUJsRCxZQUNFLEtBQ0EsVUFBcUMsRUFBRSxFQUN2QyxTQUNBLE1BQ0E7QUFDQSxRQUFNLEtBQUssU0FBU0MsU0FBTyxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7Q0FnQmxDLEtBQUssSUFBNEI7QUFDL0IsU0FBTyxJQUFJLGVBQWUsS0FBSyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssTUFBTTs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JuRSxJQUFJLFVBQWdDO0FBQ2xDLFNBQU8sSUFBSSxxQkFBcUIsS0FBSyxNQUFNLFdBQVc7R0FDcEQsU0FBUyxLQUFLO0dBQ2QsT0FBTyxLQUFLO0dBQ2IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JKLElBQUksWUFBb0M7QUFDdEMsU0FBTyxJQUFJLHVCQUF1QixLQUFLLE1BQU0sWUFBWSxLQUFLLFNBQVMsS0FBSyxNQUFNIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTZdfQ==