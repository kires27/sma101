import { __rest } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs?v=583078ff";
import { _generateLinkResponse, _noResolveJsonResponse, _request, _userResponse, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/fetch.js?v=583078ff";
import { assertPasskeyExperimentalEnabled, resolveFetch, validateUUID } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/helpers.js?v=583078ff";
import { SIGN_OUT_SCOPES, } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/types.js?v=583078ff";
import { isAuthError } from "/_nuxt/@fs/mnt/kire/Personal/Programming/Projects/MEIC/web/node_modules/.pnpm/@supabase+auth-js@2.108.1/node_modules/@supabase/auth-js/dist/module/lib/errors.js?v=583078ff";
export default class GoTrueAdminApi {
    /**
     * Creates an admin API client that can be used to manage users and OAuth clients.
     *
     * @example Using supabase-js (recommended)
     * ```ts
     * import { createClient } from '@supabase/supabase-js'
     *
     * const supabase = createClient('https://xyzcompany.supabase.co', 'your-secret-key')
     * const { data, error } = await supabase.auth.admin.listUsers()
     * ```
     *
     * @example Standalone import for bundle-sensitive environments
     * ```ts
     * import { GoTrueAdminApi } from '@supabase/auth-js'
     *
     * const admin = new GoTrueAdminApi({
     *   url: 'https://xyzcompany.supabase.co/auth/v1',
     *   headers: { Authorization: `Bearer ${process.env.SUPABASE_SECRET_KEY}` },
     * })
     * ```
     */
    constructor({ url = '', headers = {}, fetch, experimental, }) {
        this.url = url;
        this.headers = headers;
        this.fetch = resolveFetch(fetch);
        this.experimental = experimental !== null && experimental !== void 0 ? experimental : {};
        this.mfa = {
            listFactors: this._listFactors.bind(this),
            deleteFactor: this._deleteFactor.bind(this),
        };
        this.oauth = {
            listClients: this._listOAuthClients.bind(this),
            createClient: this._createOAuthClient.bind(this),
            getClient: this._getOAuthClient.bind(this),
            updateClient: this._updateOAuthClient.bind(this),
            deleteClient: this._deleteOAuthClient.bind(this),
            regenerateClientSecret: this._regenerateOAuthClientSecret.bind(this),
        };
        this.customProviders = {
            listProviders: this._listCustomProviders.bind(this),
            createProvider: this._createCustomProvider.bind(this),
            getProvider: this._getCustomProvider.bind(this),
            updateProvider: this._updateCustomProvider.bind(this),
            deleteProvider: this._deleteCustomProvider.bind(this),
        };
        this.passkey = {
            listPasskeys: this._adminListPasskeys.bind(this),
            deletePasskey: this._adminDeletePasskey.bind(this),
        };
    }
    /**
     * Removes a logged-in session.
     * @param jwt A valid, logged-in JWT.
     * @param scope The logout sope.
     *
     * @category Auth
     * @subcategory Auth Admin
     */
    async signOut(jwt, scope = SIGN_OUT_SCOPES[0]) {
        if (SIGN_OUT_SCOPES.indexOf(scope) < 0) {
            throw new Error(`@supabase/auth-js: Parameter scope must be one of ${SIGN_OUT_SCOPES.join(', ')}`);
        }
        try {
            await _request(this.fetch, 'POST', `${this.url}/logout?scope=${scope}`, {
                headers: this.headers,
                jwt,
                noResolveJson: true,
            });
            return { data: null, error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Sends an invite link to an email address.
     * @param email The email address of the user.
     * @param options Additional options to be included when inviting.
     *
     * @category Auth
     * @subcategory Auth Admin
     *
     * @remarks
     * - Sends an invite link to the user's email address.
     * - The `inviteUserByEmail()` method is typically used by administrators to invite users to join the application.
     * - Note that PKCE is not supported when using `inviteUserByEmail`. This is because the browser initiating the invite is often different from the browser accepting the invite which makes it difficult to provide the security guarantees required of the PKCE flow.
     *
     * @example Invite a user
     * ```js
     * const { data, error } = await supabase.auth.admin.inviteUserByEmail('email@example.com')
     * ```
     *
     * @exampleResponse Invite a user
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "example@email.com",
     *       "invited_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "confirmation_sent_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {},
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     }
     *   },
     *   "error": null
     * }
     * ```
     */
    async inviteUserByEmail(email, options = {}) {
        try {
            return await _request(this.fetch, 'POST', `${this.url}/invite`, {
                body: { email, data: options.data },
                headers: this.headers,
                redirectTo: options.redirectTo,
                xform: _userResponse,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { user: null }, error };
            }
            throw error;
        }
    }
    /**
     * Generates email links and OTPs to be sent via a custom email provider.
     * @param email The user's email.
     * @param options.password User password. For signup only.
     * @param options.data Optional user metadata. For signup only.
     * @param options.redirectTo The redirect url which should be appended to the generated link
     *
     * @category Auth
     * @subcategory Auth Admin
     *
     * @remarks
     * - The following types can be passed into `generateLink()`: `signup`, `magiclink`, `invite`, `recovery`, `email_change_current`, `email_change_new`, `phone_change`.
     * - `generateLink()` only generates the email link for `email_change_email` if the **Secure email change** is enabled in your project's [email auth provider settings](/dashboard/project/_/auth/providers).
     * - `generateLink()` handles the creation of the user for `signup`, `invite` and `magiclink`.
     *
     * @example Generate a signup link
     * ```js
     * const { data, error } = await supabase.auth.admin.generateLink({
     *   type: 'signup',
     *   email: 'email@example.com',
     *   password: 'secret'
     * })
     * ```
     *
     * @exampleResponse Generate a signup link
     * ```json
     * {
     *   "data": {
     *     "properties": {
     *       "action_link": "<LINK_TO_SEND_TO_USER>",
     *       "email_otp": "999999",
     *       "hashed_token": "<HASHED_TOKEN",
     *       "redirect_to": "<REDIRECT_URL>",
     *       "verification_type": "signup"
     *     },
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "email@example.com",
     *       "phone": "",
     *       "confirmation_sent_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {},
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "email@example.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "email@example.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Generate an invite link
     * ```js
     * const { data, error } = await supabase.auth.admin.generateLink({
     *   type: 'invite',
     *   email: 'email@example.com'
     * })
     * ```
     *
     * @example Generate a magic link
     * ```js
     * const { data, error } = await supabase.auth.admin.generateLink({
     *   type: 'magiclink',
     *   email: 'email@example.com'
     * })
     * ```
     *
     * @example Generate a recovery link
     * ```js
     * const { data, error } = await supabase.auth.admin.generateLink({
     *   type: 'recovery',
     *   email: 'email@example.com'
     * })
     * ```
     *
     * @example Generate links to change current email address
     * ```js
     * // generate an email change link to be sent to the current email address
     * const { data, error } = await supabase.auth.admin.generateLink({
     *   type: 'email_change_current',
     *   email: 'current.email@example.com',
     *   newEmail: 'new.email@example.com'
     * })
     *
     * // generate an email change link to be sent to the new email address
     * const { data, error } = await supabase.auth.admin.generateLink({
     *   type: 'email_change_new',
     *   email: 'current.email@example.com',
     *   newEmail: 'new.email@example.com'
     * })
     * ```
     */
    async generateLink(params) {
        try {
            const { options } = params, rest = __rest(params, ["options"]);
            const body = Object.assign(Object.assign({}, rest), options);
            if ('newEmail' in rest) {
                // replace newEmail with new_email in request body
                body.new_email = rest === null || rest === void 0 ? void 0 : rest.newEmail;
                delete body['newEmail'];
            }
            return await _request(this.fetch, 'POST', `${this.url}/admin/generate_link`, {
                body: body,
                headers: this.headers,
                xform: _generateLinkResponse,
                redirectTo: options === null || options === void 0 ? void 0 : options.redirectTo,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return {
                    data: {
                        properties: null,
                        user: null,
                    },
                    error,
                };
            }
            throw error;
        }
    }
    // User Admin API
    /**
     * Creates a new user.
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     *
     * @category Auth
     * @subcategory Auth Admin
     *
     * @remarks
     * - To confirm the user's email address or phone number, set `email_confirm` or `phone_confirm` to true. Both arguments default to false.
     * - `createUser()` will not send a confirmation email to the user. You can use [`inviteUserByEmail()`](/docs/reference/javascript/auth-admin-inviteuserbyemail) if you want to send them an email invite instead.
     * - If you are sure that the created user's email or phone number is legitimate and verified, you can set the `email_confirm` or `phone_confirm` param to `true`.
     *
     * @example With custom user metadata
     * ```js
     * const { data, error } = await supabase.auth.admin.createUser({
     *   email: 'user@email.com',
     *   password: 'password',
     *   user_metadata: { name: 'Yoda' }
     * })
     * ```
     *
     * @exampleResponse With custom user metadata
     * ```json
     * {
     *   data: {
     *     user: {
     *       id: '1',
     *       aud: 'authenticated',
     *       role: 'authenticated',
     *       email: 'example@email.com',
     *       email_confirmed_at: '2024-01-01T00:00:00Z',
     *       phone: '',
     *       confirmation_sent_at: '2024-01-01T00:00:00Z',
     *       confirmed_at: '2024-01-01T00:00:00Z',
     *       last_sign_in_at: '2024-01-01T00:00:00Z',
     *       app_metadata: {},
     *       user_metadata: {},
     *       identities: [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "1",
     *           "user_id": "1",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": true,
     *             "phone_verified": false,
     *             "sub": "1"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "email@example.com"
     *         },
     *       ],
     *       created_at: '2024-01-01T00:00:00Z',
     *       updated_at: '2024-01-01T00:00:00Z',
     *       is_anonymous: false,
     *     }
     *   }
     *   error: null
     * }
     * ```
     *
     * @example Auto-confirm the user's email
     * ```js
     * const { data, error } = await supabase.auth.admin.createUser({
     *   email: 'user@email.com',
     *   email_confirm: true
     * })
     * ```
     *
     * @example Auto-confirm the user's phone number
     * ```js
     * const { data, error } = await supabase.auth.admin.createUser({
     *   phone: '1234567890',
     *   phone_confirm: true
     * })
     * ```
     */
    async createUser(attributes) {
        try {
            return await _request(this.fetch, 'POST', `${this.url}/admin/users`, {
                body: attributes,
                headers: this.headers,
                xform: _userResponse,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { user: null }, error };
            }
            throw error;
        }
    }
    /**
     * Get a list of users.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     * @param params An object which supports `page` and `perPage` as numbers, to alter the paginated results.
     *
     * @category Auth
     * @subcategory Auth Admin
     *
     * @remarks
     * - Defaults to return 50 users per page.
     *
     * @example Get a page of users
     * ```js
     * const { data: { users }, error } = await supabase.auth.admin.listUsers()
     * ```
     *
     * @example Paginated list of users
     * ```js
     * const { data: { users }, error } = await supabase.auth.admin.listUsers({
     *   page: 1,
     *   perPage: 1000
     * })
     * ```
     */
    async listUsers(params) {
        var _a, _b, _c, _d, _e, _f, _g;
        try {
            const pagination = { nextPage: null, lastPage: 0, total: 0 };
            const response = await _request(this.fetch, 'GET', `${this.url}/admin/users`, {
                headers: this.headers,
                noResolveJson: true,
                query: {
                    page: (_b = (_a = params === null || params === void 0 ? void 0 : params.page) === null || _a === void 0 ? void 0 : _a.toString()) !== null && _b !== void 0 ? _b : '',
                    per_page: (_d = (_c = params === null || params === void 0 ? void 0 : params.perPage) === null || _c === void 0 ? void 0 : _c.toString()) !== null && _d !== void 0 ? _d : '',
                },
                xform: _noResolveJsonResponse,
            });
            if (response.error)
                throw response.error;
            const users = await response.json();
            const total = (_e = response.headers.get('x-total-count')) !== null && _e !== void 0 ? _e : 0;
            const links = (_g = (_f = response.headers.get('link')) === null || _f === void 0 ? void 0 : _f.split(',')) !== null && _g !== void 0 ? _g : [];
            if (links.length > 0) {
                links.forEach((link) => {
                    const page = parseInt(link.split(';')[0].split('=')[1].substring(0, 1));
                    const rel = JSON.parse(link.split(';')[1].split('=')[1]);
                    pagination[`${rel}Page`] = page;
                });
                pagination.total = parseInt(total);
            }
            return { data: Object.assign(Object.assign({}, users), pagination), error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { users: [] }, error };
            }
            throw error;
        }
    }
    /**
     * Get user by id.
     *
     * @param uid The user's unique identifier
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     *
     * @category Auth
     * @subcategory Auth Admin
     *
     * @remarks
     * - Fetches the user object from the database based on the user's id.
     * - The `getUserById()` method requires the user's id which maps to the `auth.users.id` column.
     *
     * @example Fetch the user object using the access_token jwt
     * ```js
     * const { data, error } = await supabase.auth.admin.getUserById(1)
     * ```
     *
     * @exampleResponse Fetch the user object using the access_token jwt
     * ```json
     * {
     *   data: {
     *     user: {
     *       id: '1',
     *       aud: 'authenticated',
     *       role: 'authenticated',
     *       email: 'example@email.com',
     *       email_confirmed_at: '2024-01-01T00:00:00Z',
     *       phone: '',
     *       confirmation_sent_at: '2024-01-01T00:00:00Z',
     *       confirmed_at: '2024-01-01T00:00:00Z',
     *       last_sign_in_at: '2024-01-01T00:00:00Z',
     *       app_metadata: {},
     *       user_metadata: {},
     *       identities: [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "1",
     *           "user_id": "1",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": true,
     *             "phone_verified": false,
     *             "sub": "1"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "email@example.com"
     *         },
     *       ],
     *       created_at: '2024-01-01T00:00:00Z',
     *       updated_at: '2024-01-01T00:00:00Z',
     *       is_anonymous: false,
     *     }
     *   }
     *   error: null
     * }
     * ```
     */
    async getUserById(uid) {
        validateUUID(uid);
        try {
            return await _request(this.fetch, 'GET', `${this.url}/admin/users/${uid}`, {
                headers: this.headers,
                xform: _userResponse,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { user: null }, error };
            }
            throw error;
        }
    }
    /**
     * Updates the user data. Changes are applied directly without confirmation flows.
     *
     * @param uid The user's unique identifier
     * @param attributes The data you want to update.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     *
     * @remarks
     * **Important:** This is a server-side operation and does **not** trigger client-side
     * `onAuthStateChange` listeners. The admin API has no connection to client state.
     *
     * To sync changes to the client after calling this method:
     * 1. On the client, call `supabase.auth.refreshSession()` to fetch the updated user data
     * 2. This will trigger the `TOKEN_REFRESHED` event and notify all listeners
     *
     * @example
     * ```typescript
     * // Server-side (Edge Function)
     * const { data, error } = await supabase.auth.admin.updateUserById(
     *   userId,
     *   { user_metadata: { preferences: { theme: 'dark' } } }
     * )
     *
     * // Client-side (to sync the changes)
     * const { data, error } = await supabase.auth.refreshSession()
     * // onAuthStateChange listeners will now be notified with updated user
     * ```
     *
     * @see {@link GoTrueClient.refreshSession} for syncing admin changes to the client
     * @see {@link GoTrueClient.updateUser} for client-side user updates (triggers listeners automatically)
     *
     * @category Auth
     * @subcategory Auth Admin
     *
     * @example Updates a user's email
     * ```js
     * const { data: user, error } = await supabase.auth.admin.updateUserById(
     *   '11111111-1111-1111-1111-111111111111',
     *   { email: 'new@email.com' }
     * )
     * ```
     *
     * @exampleResponse Updates a user's email
     * ```json
     * {
     *   "data": {
     *     "user": {
     *       "id": "11111111-1111-1111-1111-111111111111",
     *       "aud": "authenticated",
     *       "role": "authenticated",
     *       "email": "new@email.com",
     *       "email_confirmed_at": "2024-01-01T00:00:00Z",
     *       "phone": "",
     *       "confirmed_at": "2024-01-01T00:00:00Z",
     *       "recovery_sent_at": "2024-01-01T00:00:00Z",
     *       "last_sign_in_at": "2024-01-01T00:00:00Z",
     *       "app_metadata": {
     *         "provider": "email",
     *         "providers": [
     *           "email"
     *         ]
     *       },
     *       "user_metadata": {
     *         "email": "example@email.com",
     *         "email_verified": false,
     *         "phone_verified": false,
     *         "sub": "11111111-1111-1111-1111-111111111111"
     *       },
     *       "identities": [
     *         {
     *           "identity_id": "22222222-2222-2222-2222-222222222222",
     *           "id": "11111111-1111-1111-1111-111111111111",
     *           "user_id": "11111111-1111-1111-1111-111111111111",
     *           "identity_data": {
     *             "email": "example@email.com",
     *             "email_verified": false,
     *             "phone_verified": false,
     *             "sub": "11111111-1111-1111-1111-111111111111"
     *           },
     *           "provider": "email",
     *           "last_sign_in_at": "2024-01-01T00:00:00Z",
     *           "created_at": "2024-01-01T00:00:00Z",
     *           "updated_at": "2024-01-01T00:00:00Z",
     *           "email": "example@email.com"
     *         }
     *       ],
     *       "created_at": "2024-01-01T00:00:00Z",
     *       "updated_at": "2024-01-01T00:00:00Z",
     *       "is_anonymous": false
     *     }
     *   },
     *   "error": null
     * }
     * ```
     *
     * @example Updates a user's password
     * ```js
     * const { data: user, error } = await supabase.auth.admin.updateUserById(
     *   '6aa5d0d4-2a9f-4483-b6c8-0cf4c6c98ac4',
     *   { password: 'new_password' }
     * )
     * ```
     *
     * @example Updates a user's metadata
     * ```js
     * const { data: user, error } = await supabase.auth.admin.updateUserById(
     *   '6aa5d0d4-2a9f-4483-b6c8-0cf4c6c98ac4',
     *   { user_metadata: { hello: 'world' } }
     * )
     * ```
     *
     * @example Updates a user's app_metadata
     * ```js
     * const { data: user, error } = await supabase.auth.admin.updateUserById(
     *   '6aa5d0d4-2a9f-4483-b6c8-0cf4c6c98ac4',
     *   { app_metadata: { plan: 'trial' } }
     * )
     * ```
     *
     * @example Confirms a user's email address
     * ```js
     * const { data: user, error } = await supabase.auth.admin.updateUserById(
     *   '6aa5d0d4-2a9f-4483-b6c8-0cf4c6c98ac4',
     *   { email_confirm: true }
     * )
     * ```
     *
     * @example Confirms a user's phone number
     * ```js
     * const { data: user, error } = await supabase.auth.admin.updateUserById(
     *   '6aa5d0d4-2a9f-4483-b6c8-0cf4c6c98ac4',
     *   { phone_confirm: true }
     * )
     * ```
     *
     * @example Ban a user for 100 years
     * ```js
     * const { data: user, error } = await supabase.auth.admin.updateUserById(
     *   '6aa5d0d4-2a9f-4483-b6c8-0cf4c6c98ac4',
     *   { ban_duration: '876000h' }
     * )
     * ```
     */
    async updateUserById(uid, attributes) {
        validateUUID(uid);
        try {
            return await _request(this.fetch, 'PUT', `${this.url}/admin/users/${uid}`, {
                body: attributes,
                headers: this.headers,
                xform: _userResponse,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { user: null }, error };
            }
            throw error;
        }
    }
    /**
     * Delete a user. Requires a `service_role` key.
     *
     * @param id The user id you want to remove.
     * @param shouldSoftDelete If true, then the user will be soft-deleted from the auth schema. Soft deletion allows user identification from the hashed user ID but is not reversible.
     * Defaults to false for backward compatibility.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     *
     * @category Auth
     * @subcategory Auth Admin
     *
     * @remarks
     * - The `deleteUser()` method requires the user's ID, which maps to the `auth.users.id` column.
     *
     * @example Removes a user
     * ```js
     * const { data, error } = await supabase.auth.admin.deleteUser(
     *   '715ed5db-f090-4b8c-a067-640ecee36aa0'
     * )
     * ```
     *
     * @exampleResponse Removes a user
     * ```json
     * {
     *   "data": {
     *     "user": {}
     *   },
     *   "error": null
     * }
     * ```
     */
    async deleteUser(id, shouldSoftDelete = false) {
        validateUUID(id);
        try {
            return await _request(this.fetch, 'DELETE', `${this.url}/admin/users/${id}`, {
                headers: this.headers,
                body: {
                    should_soft_delete: shouldSoftDelete,
                },
                xform: _userResponse,
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { user: null }, error };
            }
            throw error;
        }
    }
    async _listFactors(params) {
        validateUUID(params.userId);
        try {
            const { data, error } = await _request(this.fetch, 'GET', `${this.url}/admin/users/${params.userId}/factors`, {
                headers: this.headers,
                xform: (factors) => {
                    return { data: { factors }, error: null };
                },
            });
            return { data, error };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    async _deleteFactor(params) {
        validateUUID(params.userId);
        validateUUID(params.id);
        try {
            const data = await _request(this.fetch, 'DELETE', `${this.url}/admin/users/${params.userId}/factors/${params.id}`, {
                headers: this.headers,
            });
            return { data, error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Lists all OAuth clients with optional pagination.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _listOAuthClients(params) {
        var _a, _b, _c, _d, _e, _f, _g;
        try {
            const pagination = { nextPage: null, lastPage: 0, total: 0 };
            const response = await _request(this.fetch, 'GET', `${this.url}/admin/oauth/clients`, {
                headers: this.headers,
                noResolveJson: true,
                query: {
                    page: (_b = (_a = params === null || params === void 0 ? void 0 : params.page) === null || _a === void 0 ? void 0 : _a.toString()) !== null && _b !== void 0 ? _b : '',
                    per_page: (_d = (_c = params === null || params === void 0 ? void 0 : params.perPage) === null || _c === void 0 ? void 0 : _c.toString()) !== null && _d !== void 0 ? _d : '',
                },
                xform: _noResolveJsonResponse,
            });
            if (response.error)
                throw response.error;
            const clients = await response.json();
            const total = (_e = response.headers.get('x-total-count')) !== null && _e !== void 0 ? _e : 0;
            const links = (_g = (_f = response.headers.get('link')) === null || _f === void 0 ? void 0 : _f.split(',')) !== null && _g !== void 0 ? _g : [];
            if (links.length > 0) {
                links.forEach((link) => {
                    const page = parseInt(link.split(';')[0].split('=')[1].substring(0, 1));
                    const rel = JSON.parse(link.split(';')[1].split('=')[1]);
                    pagination[`${rel}Page`] = page;
                });
                pagination.total = parseInt(total);
            }
            return { data: Object.assign(Object.assign({}, clients), pagination), error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { clients: [] }, error };
            }
            throw error;
        }
    }
    /**
     * Creates a new OAuth client.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _createOAuthClient(params) {
        try {
            return await _request(this.fetch, 'POST', `${this.url}/admin/oauth/clients`, {
                body: params,
                headers: this.headers,
                xform: (client) => {
                    return { data: client, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Gets details of a specific OAuth client.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _getOAuthClient(clientId) {
        try {
            return await _request(this.fetch, 'GET', `${this.url}/admin/oauth/clients/${clientId}`, {
                headers: this.headers,
                xform: (client) => {
                    return { data: client, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Updates an existing OAuth client.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _updateOAuthClient(clientId, params) {
        try {
            return await _request(this.fetch, 'PUT', `${this.url}/admin/oauth/clients/${clientId}`, {
                body: params,
                headers: this.headers,
                xform: (client) => {
                    return { data: client, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Deletes an OAuth client.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _deleteOAuthClient(clientId) {
        try {
            await _request(this.fetch, 'DELETE', `${this.url}/admin/oauth/clients/${clientId}`, {
                headers: this.headers,
                noResolveJson: true,
            });
            return { data: null, error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Regenerates the secret for an OAuth client.
     * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _regenerateOAuthClientSecret(clientId) {
        try {
            return await _request(this.fetch, 'POST', `${this.url}/admin/oauth/clients/${clientId}/regenerate_secret`, {
                headers: this.headers,
                xform: (client) => {
                    return { data: client, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Lists all custom providers with optional type filter.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _listCustomProviders(params) {
        try {
            const query = {};
            if (params === null || params === void 0 ? void 0 : params.type) {
                query.type = params.type;
            }
            return await _request(this.fetch, 'GET', `${this.url}/admin/custom-providers`, {
                headers: this.headers,
                query,
                xform: (data) => {
                    var _a;
                    return { data: { providers: (_a = data === null || data === void 0 ? void 0 : data.providers) !== null && _a !== void 0 ? _a : [] }, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: { providers: [] }, error };
            }
            throw error;
        }
    }
    /**
     * Creates a new custom OIDC/OAuth provider.
     *
     * For OIDC providers, the server fetches and validates the OpenID Connect discovery document
     * from the issuer's well-known endpoint (or the provided `discovery_url`) at creation time.
     * This may return a validation error (`error_code: "validation_failed"`) if the discovery
     * document is unreachable, not valid JSON, missing required fields, or if the issuer
     * in the document does not match the expected issuer.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _createCustomProvider(params) {
        try {
            return await _request(this.fetch, 'POST', `${this.url}/admin/custom-providers`, {
                body: params,
                headers: this.headers,
                xform: (provider) => {
                    return { data: provider, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Gets details of a specific custom provider by identifier.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _getCustomProvider(identifier) {
        try {
            return await _request(this.fetch, 'GET', `${this.url}/admin/custom-providers/${identifier}`, {
                headers: this.headers,
                xform: (provider) => {
                    return { data: provider, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Updates an existing custom provider.
     *
     * When `issuer` or `discovery_url` is changed on an OIDC provider, the server re-fetches and
     * validates the discovery document before persisting. This may return a validation error
     * (`error_code: "validation_failed"`) if the discovery document is unreachable, invalid, or
     * the issuer does not match.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _updateCustomProvider(identifier, params) {
        try {
            return await _request(this.fetch, 'PUT', `${this.url}/admin/custom-providers/${identifier}`, {
                body: params,
                headers: this.headers,
                xform: (provider) => {
                    return { data: provider, error: null };
                },
            });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Deletes a custom provider.
     *
     * This function should only be called on a server. Never expose your `service_role` key in the browser.
     */
    async _deleteCustomProvider(identifier) {
        try {
            await _request(this.fetch, 'DELETE', `${this.url}/admin/custom-providers/${identifier}`, {
                headers: this.headers,
                noResolveJson: true,
            });
            return { data: null, error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Lists all passkeys for a user.
     *
     * This function should only be called on a server. Never expose your secret key in the browser.
     *
     * Requires `auth.experimental.passkey: true`.
     */
    async _adminListPasskeys(params) {
        assertPasskeyExperimentalEnabled(this.experimental);
        validateUUID(params.userId);
        try {
            return await _request(this.fetch, 'GET', `${this.url}/admin/users/${params.userId}/passkeys`, { headers: this.headers, xform: (data) => ({ data, error: null }) });
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
    /**
     * Deletes a user's passkey.
     *
     * This function should only be called on a server. Never expose your secret key in the browser.
     *
     * Requires `auth.experimental.passkey: true`.
     */
    async _adminDeletePasskey(params) {
        assertPasskeyExperimentalEnabled(this.experimental);
        validateUUID(params.userId);
        validateUUID(params.passkeyId);
        try {
            await _request(this.fetch, 'DELETE', `${this.url}/admin/users/${params.userId}/passkeys/${params.passkeyId}`, { headers: this.headers, noResolveJson: true });
            return { data: null, error: null };
        }
        catch (error) {
            if (isAuthError(error)) {
                return { data: null, error };
            }
            throw error;
        }
    }
}
                                          
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR29UcnVlQWRtaW5BcGkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvR29UcnVlQWRtaW5BcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFFTCxxQkFBcUIsRUFDckIsc0JBQXNCLEVBQ3RCLFFBQVEsRUFDUixhQUFhLEdBQ2QsTUFBTSxhQUFhLENBQUE7QUFDcEIsT0FBTyxFQUFFLGdDQUFnQyxFQUFFLFlBQVksRUFBRSxZQUFZLEVBQUUsTUFBTSxlQUFlLENBQUE7QUFDNUYsT0FBTyxFQWFMLGVBQWUsR0FtQmhCLE1BQU0sYUFBYSxDQUFBO0FBQ3BCLE9BQU8sRUFBYSxXQUFXLEVBQUUsTUFBTSxjQUFjLENBQUE7QUFFckQsTUFBTSxDQUFDLE9BQU8sT0FBTyxjQUFjO0lBMkJqQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FvQkc7SUFDSCxZQUFZLEVBQ1YsR0FBRyxHQUFHLEVBQUUsRUFDUixPQUFPLEdBQUcsRUFBRSxFQUNaLEtBQUssRUFDTCxZQUFZLEdBUWI7UUFDQyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQTtRQUNkLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFBO1FBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxhQUFaLFlBQVksY0FBWixZQUFZLEdBQUksRUFBRSxDQUFBO1FBQ3RDLElBQUksQ0FBQyxHQUFHLEdBQUc7WUFDVCxXQUFXLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3pDLFlBQVksRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDNUMsQ0FBQTtRQUNELElBQUksQ0FBQyxLQUFLLEdBQUc7WUFDWCxXQUFXLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDOUMsWUFBWSxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2hELFNBQVMsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDMUMsWUFBWSxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2hELFlBQVksRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNoRCxzQkFBc0IsRUFBRSxJQUFJLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUNyRSxDQUFBO1FBQ0QsSUFBSSxDQUFDLGVBQWUsR0FBRztZQUNyQixhQUFhLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDbkQsY0FBYyxFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3JELFdBQVcsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUMvQyxjQUFjLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDckQsY0FBYyxFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ3RELENBQUE7UUFDRCxJQUFJLENBQUMsT0FBTyxHQUFHO1lBQ2IsWUFBWSxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2hELGFBQWEsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUNuRCxDQUFBO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxLQUFLLENBQUMsT0FBTyxDQUNYLEdBQVcsRUFDWCxRQUFzQixlQUFlLENBQUMsQ0FBQyxDQUFDO1FBRXhDLElBQUksZUFBZSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN2QyxNQUFNLElBQUksS0FBSyxDQUNiLHFEQUFxRCxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQ2xGLENBQUE7UUFDSCxDQUFDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxpQkFBaUIsS0FBSyxFQUFFLEVBQUU7Z0JBQ3RFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsR0FBRztnQkFDSCxhQUFhLEVBQUUsSUFBSTthQUNwQixDQUFDLENBQUE7WUFDRixPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7UUFDcEMsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQTtZQUM5QixDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0ErREc7SUFDSCxLQUFLLENBQUMsaUJBQWlCLENBQ3JCLEtBQWEsRUFDYixVQU1JLEVBQUU7UUFFTixJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsU0FBUyxFQUFFO2dCQUM5RCxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUU7Z0JBQ25DLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2dCQUM5QixLQUFLLEVBQUUsYUFBYTthQUNyQixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDeEMsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FvSEc7SUFDSCxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQTBCO1FBQzNDLElBQUksQ0FBQztZQUNILE1BQU0sRUFBRSxPQUFPLEtBQWMsTUFBTSxFQUFmLElBQUksVUFBSyxNQUFNLEVBQTdCLFdBQW9CLENBQVMsQ0FBQTtZQUNuQyxNQUFNLElBQUksbUNBQWEsSUFBSSxHQUFLLE9BQU8sQ0FBRSxDQUFBO1lBQ3pDLElBQUksVUFBVSxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUN2QixrREFBa0Q7Z0JBQ2xELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxhQUFKLElBQUksdUJBQUosSUFBSSxDQUFFLFFBQVEsQ0FBQTtnQkFDL0IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7WUFDekIsQ0FBQztZQUNELE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxzQkFBc0IsRUFBRTtnQkFDM0UsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixLQUFLLEVBQUUscUJBQXFCO2dCQUM1QixVQUFVLEVBQUUsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFVBQVU7YUFDaEMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPO29CQUNMLElBQUksRUFBRTt3QkFDSixVQUFVLEVBQUUsSUFBSTt3QkFDaEIsSUFBSSxFQUFFLElBQUk7cUJBQ1g7b0JBQ0QsS0FBSztpQkFDTixDQUFBO1lBQ0gsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRCxpQkFBaUI7SUFDakI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0ErRUc7SUFDSCxLQUFLLENBQUMsVUFBVSxDQUFDLFVBQStCO1FBQzlDLElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxjQUFjLEVBQUU7Z0JBQ25FLElBQUksRUFBRSxVQUFVO2dCQUNoQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLEtBQUssRUFBRSxhQUFhO2FBQ3JCLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQTtZQUN4QyxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0F3Qkc7SUFDSCxLQUFLLENBQUMsU0FBUyxDQUNiLE1BQW1COztRQUtuQixJQUFJLENBQUM7WUFDSCxNQUFNLFVBQVUsR0FBZSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUE7WUFDeEUsTUFBTSxRQUFRLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxjQUFjLEVBQUU7Z0JBQzVFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsYUFBYSxFQUFFLElBQUk7Z0JBQ25CLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsTUFBQSxNQUFBLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxJQUFJLDBDQUFFLFFBQVEsRUFBRSxtQ0FBSSxFQUFFO29CQUNwQyxRQUFRLEVBQUUsTUFBQSxNQUFBLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxPQUFPLDBDQUFFLFFBQVEsRUFBRSxtQ0FBSSxFQUFFO2lCQUM1QztnQkFDRCxLQUFLLEVBQUUsc0JBQXNCO2FBQzlCLENBQUMsQ0FBQTtZQUNGLElBQUksUUFBUSxDQUFDLEtBQUs7Z0JBQUUsTUFBTSxRQUFRLENBQUMsS0FBSyxDQUFBO1lBRXhDLE1BQU0sS0FBSyxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFBO1lBQ25DLE1BQU0sS0FBSyxHQUFHLE1BQUEsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG1DQUFJLENBQUMsQ0FBQTtZQUN4RCxNQUFNLEtBQUssR0FBRyxNQUFBLE1BQUEsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLDBDQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsbUNBQUksRUFBRSxDQUFBO1lBQzVELElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDckIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQVksRUFBRSxFQUFFO29CQUM3QixNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO29CQUN2RSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7b0JBQ3hELFVBQVUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFBO2dCQUNqQyxDQUFDLENBQUMsQ0FBQTtnQkFFRixVQUFVLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUNwQyxDQUFDO1lBQ0QsT0FBTyxFQUFFLElBQUksa0NBQU8sS0FBSyxHQUFLLFVBQVUsQ0FBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtRQUMzRCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDdkMsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTZERztJQUNILEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBVztRQUMzQixZQUFZLENBQUMsR0FBRyxDQUFDLENBQUE7UUFFakIsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLGdCQUFnQixHQUFHLEVBQUUsRUFBRTtnQkFDekUsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixLQUFLLEVBQUUsYUFBYTthQUNyQixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDeEMsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0ErSUc7SUFDSCxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQVcsRUFBRSxVQUErQjtRQUMvRCxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUE7UUFFakIsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLGdCQUFnQixHQUFHLEVBQUUsRUFBRTtnQkFDekUsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsS0FBSyxFQUFFLGFBQWE7YUFDckIsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQ3hDLENBQUM7WUFFRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0ErQkc7SUFDSCxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQVUsRUFBRSxnQkFBZ0IsR0FBRyxLQUFLO1FBQ25ELFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUVoQixJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsZ0JBQWdCLEVBQUUsRUFBRSxFQUFFO2dCQUMzRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLElBQUksRUFBRTtvQkFDSixrQkFBa0IsRUFBRSxnQkFBZ0I7aUJBQ3JDO2dCQUNELEtBQUssRUFBRSxhQUFhO2FBQ3JCLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQTtZQUN4QyxDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVPLEtBQUssQ0FBQyxZQUFZLENBQ3hCLE1BQXFDO1FBRXJDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUE7UUFFM0IsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVEsQ0FDcEMsSUFBSSxDQUFDLEtBQUssRUFDVixLQUFLLEVBQ0wsR0FBRyxJQUFJLENBQUMsR0FBRyxnQkFBZ0IsTUFBTSxDQUFDLE1BQU0sVUFBVSxFQUNsRDtnQkFDRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLEtBQUssRUFBRSxDQUFDLE9BQVksRUFBRSxFQUFFO29CQUN0QixPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO2dCQUMzQyxDQUFDO2FBQ0YsQ0FDRixDQUFBO1lBQ0QsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQTtRQUN4QixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQzlCLENBQUM7WUFFRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRU8sS0FBSyxDQUFDLGFBQWEsQ0FDekIsTUFBc0M7UUFFdEMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUMzQixZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRXZCLElBQUksQ0FBQztZQUNILE1BQU0sSUFBSSxHQUFHLE1BQU0sUUFBUSxDQUN6QixJQUFJLENBQUMsS0FBSyxFQUNWLFFBQVEsRUFDUixHQUFHLElBQUksQ0FBQyxHQUFHLGdCQUFnQixNQUFNLENBQUMsTUFBTSxZQUFZLE1BQU0sQ0FBQyxFQUFFLEVBQUUsRUFDL0Q7Z0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2FBQ3RCLENBQ0YsQ0FBQTtZQUVELE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO1FBQzlCLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDOUIsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFtQjs7UUFDakQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxVQUFVLEdBQWUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFBO1lBQ3hFLE1BQU0sUUFBUSxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsc0JBQXNCLEVBQUU7Z0JBQ3BGLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsYUFBYSxFQUFFLElBQUk7Z0JBQ25CLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsTUFBQSxNQUFBLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxJQUFJLDBDQUFFLFFBQVEsRUFBRSxtQ0FBSSxFQUFFO29CQUNwQyxRQUFRLEVBQUUsTUFBQSxNQUFBLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxPQUFPLDBDQUFFLFFBQVEsRUFBRSxtQ0FBSSxFQUFFO2lCQUM1QztnQkFDRCxLQUFLLEVBQUUsc0JBQXNCO2FBQzlCLENBQUMsQ0FBQTtZQUNGLElBQUksUUFBUSxDQUFDLEtBQUs7Z0JBQUUsTUFBTSxRQUFRLENBQUMsS0FBSyxDQUFBO1lBRXhDLE1BQU0sT0FBTyxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFBO1lBQ3JDLE1BQU0sS0FBSyxHQUFHLE1BQUEsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG1DQUFJLENBQUMsQ0FBQTtZQUN4RCxNQUFNLEtBQUssR0FBRyxNQUFBLE1BQUEsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLDBDQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsbUNBQUksRUFBRSxDQUFBO1lBQzVELElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDckIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQVksRUFBRSxFQUFFO29CQUM3QixNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO29CQUN2RSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7b0JBQ3hELFVBQVUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFBO2dCQUNqQyxDQUFDLENBQUMsQ0FBQTtnQkFFRixVQUFVLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUNwQyxDQUFDO1lBQ0QsT0FBTyxFQUFFLElBQUksa0NBQU8sT0FBTyxHQUFLLFVBQVUsQ0FBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtRQUM3RCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDekMsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxNQUErQjtRQUM5RCxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsc0JBQXNCLEVBQUU7Z0JBQzNFLElBQUksRUFBRSxNQUFNO2dCQUNaLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsS0FBSyxFQUFFLENBQUMsTUFBVyxFQUFFLEVBQUU7b0JBQ3JCLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtnQkFDdEMsQ0FBQzthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDOUIsQ0FBQztZQUVELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLEtBQUssQ0FBQyxlQUFlLENBQUMsUUFBZ0I7UUFDNUMsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLHdCQUF3QixRQUFRLEVBQUUsRUFBRTtnQkFDdEYsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixLQUFLLEVBQUUsQ0FBQyxNQUFXLEVBQUUsRUFBRTtvQkFDckIsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO2dCQUN0QyxDQUFDO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQTtZQUM5QixDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ssS0FBSyxDQUFDLGtCQUFrQixDQUM5QixRQUFnQixFQUNoQixNQUErQjtRQUUvQixJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsd0JBQXdCLFFBQVEsRUFBRSxFQUFFO2dCQUN0RixJQUFJLEVBQUUsTUFBTTtnQkFDWixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLEtBQUssRUFBRSxDQUFDLE1BQVcsRUFBRSxFQUFFO29CQUNyQixPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7Z0JBQ3RDLENBQUM7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQzlCLENBQUM7WUFFRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxLQUFLLENBQUMsa0JBQWtCLENBQzlCLFFBQWdCO1FBRWhCLElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsd0JBQXdCLFFBQVEsRUFBRSxFQUFFO2dCQUNsRixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLGFBQWEsRUFBRSxJQUFJO2FBQ3BCLENBQUMsQ0FBQTtZQUNGLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQTtRQUNwQyxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQzlCLENBQUM7WUFFRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxLQUFLLENBQUMsNEJBQTRCLENBQUMsUUFBZ0I7UUFDekQsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLFFBQVEsQ0FDbkIsSUFBSSxDQUFDLEtBQUssRUFDVixNQUFNLEVBQ04sR0FBRyxJQUFJLENBQUMsR0FBRyx3QkFBd0IsUUFBUSxvQkFBb0IsRUFDL0Q7Z0JBQ0UsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNyQixLQUFLLEVBQUUsQ0FBQyxNQUFXLEVBQUUsRUFBRTtvQkFDckIsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO2dCQUN0QyxDQUFDO2FBQ0YsQ0FDRixDQUFBO1FBQ0gsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQTtZQUM5QixDQUFDO1lBRUQsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxLQUFLLENBQUMsb0JBQW9CLENBQ2hDLE1BQWtDO1FBRWxDLElBQUksQ0FBQztZQUNILE1BQU0sS0FBSyxHQUEyQixFQUFFLENBQUE7WUFDeEMsSUFBSSxNQUFNLGFBQU4sTUFBTSx1QkFBTixNQUFNLENBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQ2pCLEtBQUssQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQTtZQUMxQixDQUFDO1lBQ0QsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLHlCQUF5QixFQUFFO2dCQUM3RSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLEtBQUs7Z0JBQ0wsS0FBSyxFQUFFLENBQUMsSUFBUyxFQUFFLEVBQUU7O29CQUNuQixPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQUEsSUFBSSxhQUFKLElBQUksdUJBQUosSUFBSSxDQUFFLFNBQVMsbUNBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO2dCQUNwRSxDQUFDO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQzNDLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNLLEtBQUssQ0FBQyxxQkFBcUIsQ0FDakMsTUFBa0M7UUFFbEMsSUFBSSxDQUFDO1lBQ0gsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLHlCQUF5QixFQUFFO2dCQUM5RSxJQUFJLEVBQUUsTUFBTTtnQkFDWixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLEtBQUssRUFBRSxDQUFDLFFBQWEsRUFBRSxFQUFFO29CQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7Z0JBQ3hDLENBQUM7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQzlCLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxVQUFrQjtRQUNqRCxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsMkJBQTJCLFVBQVUsRUFBRSxFQUFFO2dCQUMzRixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLEtBQUssRUFBRSxDQUFDLFFBQWEsRUFBRSxFQUFFO29CQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7Z0JBQ3hDLENBQUM7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQzlCLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0ssS0FBSyxDQUFDLHFCQUFxQixDQUNqQyxVQUFrQixFQUNsQixNQUFrQztRQUVsQyxJQUFJLENBQUM7WUFDSCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsMkJBQTJCLFVBQVUsRUFBRSxFQUFFO2dCQUMzRixJQUFJLEVBQUUsTUFBTTtnQkFDWixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLEtBQUssRUFBRSxDQUFDLFFBQWEsRUFBRSxFQUFFO29CQUN2QixPQUFPLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUE7Z0JBQ3hDLENBQUM7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFBO1lBQzlCLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQTtRQUNiLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLEtBQUssQ0FBQyxxQkFBcUIsQ0FDakMsVUFBa0I7UUFFbEIsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRywyQkFBMkIsVUFBVSxFQUFFLEVBQUU7Z0JBQ3ZGLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDckIsYUFBYSxFQUFFLElBQUk7YUFDcEIsQ0FBQyxDQUFBO1lBQ0YsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO1FBQ3BDLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDOUIsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxLQUFLLENBQUMsa0JBQWtCLENBQzlCLE1BQWtDO1FBRWxDLGdDQUFnQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQTtRQUNuRCxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBRTNCLElBQUksQ0FBQztZQUNILE9BQU8sTUFBTSxRQUFRLENBQ25CLElBQUksQ0FBQyxLQUFLLEVBQ1YsS0FBSyxFQUNMLEdBQUcsSUFBSSxDQUFDLEdBQUcsZ0JBQWdCLE1BQU0sQ0FBQyxNQUFNLFdBQVcsRUFDbkQsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxJQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FDekUsQ0FBQTtRQUNILENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDOUIsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxLQUFLLENBQUMsbUJBQW1CLENBQy9CLE1BQW9DO1FBRXBDLGdDQUFnQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQTtRQUNuRCxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQzNCLFlBQVksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFOUIsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLENBQ1osSUFBSSxDQUFDLEtBQUssRUFDVixRQUFRLEVBQ1IsR0FBRyxJQUFJLENBQUMsR0FBRyxnQkFBZ0IsTUFBTSxDQUFDLE1BQU0sYUFBYSxNQUFNLENBQUMsU0FBUyxFQUFFLEVBQ3ZFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxDQUMvQyxDQUFBO1lBQ0QsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFBO1FBQ3BDLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUE7WUFDOUIsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7Q0FDRiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEZldGNoLFxuICBfZ2VuZXJhdGVMaW5rUmVzcG9uc2UsXG4gIF9ub1Jlc29sdmVKc29uUmVzcG9uc2UsXG4gIF9yZXF1ZXN0LFxuICBfdXNlclJlc3BvbnNlLFxufSBmcm9tICcuL2xpYi9mZXRjaCdcbmltcG9ydCB7IGFzc2VydFBhc3NrZXlFeHBlcmltZW50YWxFbmFibGVkLCByZXNvbHZlRmV0Y2gsIHZhbGlkYXRlVVVJRCB9IGZyb20gJy4vbGliL2hlbHBlcnMnXG5pbXBvcnQge1xuICBBZG1pblVzZXJBdHRyaWJ1dGVzLFxuICBHZW5lcmF0ZUxpbmtQYXJhbXMsXG4gIEdlbmVyYXRlTGlua1Jlc3BvbnNlLFxuICBQYWdpbmF0aW9uLFxuICBVc2VyLFxuICBVc2VyUmVzcG9uc2UsXG4gIEdvVHJ1ZUFkbWluTUZBQXBpLFxuICBBdXRoTUZBQWRtaW5EZWxldGVGYWN0b3JQYXJhbXMsXG4gIEF1dGhNRkFBZG1pbkRlbGV0ZUZhY3RvclJlc3BvbnNlLFxuICBBdXRoTUZBQWRtaW5MaXN0RmFjdG9yc1BhcmFtcyxcbiAgQXV0aE1GQUFkbWluTGlzdEZhY3RvcnNSZXNwb25zZSxcbiAgUGFnZVBhcmFtcyxcbiAgU0lHTl9PVVRfU0NPUEVTLFxuICBTaWduT3V0U2NvcGUsXG4gIEdvVHJ1ZUFkbWluT0F1dGhBcGksXG4gIENyZWF0ZU9BdXRoQ2xpZW50UGFyYW1zLFxuICBVcGRhdGVPQXV0aENsaWVudFBhcmFtcyxcbiAgT0F1dGhDbGllbnRSZXNwb25zZSxcbiAgT0F1dGhDbGllbnRMaXN0UmVzcG9uc2UsXG4gIEdvVHJ1ZUFkbWluQ3VzdG9tUHJvdmlkZXJzQXBpLFxuICBDcmVhdGVDdXN0b21Qcm92aWRlclBhcmFtcyxcbiAgVXBkYXRlQ3VzdG9tUHJvdmlkZXJQYXJhbXMsXG4gIExpc3RDdXN0b21Qcm92aWRlcnNQYXJhbXMsXG4gIEN1c3RvbVByb3ZpZGVyUmVzcG9uc2UsXG4gIEN1c3RvbVByb3ZpZGVyTGlzdFJlc3BvbnNlLFxuICBHb1RydWVBZG1pblBhc3NrZXlBcGksXG4gIEF1dGhQYXNza2V5QWRtaW5MaXN0UGFyYW1zLFxuICBBdXRoUGFzc2tleUFkbWluRGVsZXRlUGFyYW1zLFxuICBBdXRoUGFzc2tleUxpc3RSZXNwb25zZSxcbiAgQXV0aFBhc3NrZXlEZWxldGVSZXNwb25zZSxcbiAgRXhwZXJpbWVudGFsRmVhdHVyZUZsYWdzLFxufSBmcm9tICcuL2xpYi90eXBlcydcbmltcG9ydCB7IEF1dGhFcnJvciwgaXNBdXRoRXJyb3IgfSBmcm9tICcuL2xpYi9lcnJvcnMnXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdvVHJ1ZUFkbWluQXBpIHtcbiAgLyoqIENvbnRhaW5zIGFsbCBNRkEgYWRtaW5pc3RyYXRpb24gbWV0aG9kcy4gKi9cbiAgbWZhOiBHb1RydWVBZG1pbk1GQUFwaVxuXG4gIC8qKlxuICAgKiBDb250YWlucyBhbGwgT0F1dGggY2xpZW50IGFkbWluaXN0cmF0aW9uIG1ldGhvZHMuXG4gICAqIE9ubHkgcmVsZXZhbnQgd2hlbiB0aGUgT0F1dGggMi4xIHNlcnZlciBpcyBlbmFibGVkIGluIFN1cGFiYXNlIEF1dGguXG4gICAqL1xuICBvYXV0aDogR29UcnVlQWRtaW5PQXV0aEFwaVxuXG4gIC8qKiBDb250YWlucyBhbGwgY3VzdG9tIE9JREMvT0F1dGggcHJvdmlkZXIgYWRtaW5pc3RyYXRpb24gbWV0aG9kcy4gKi9cbiAgY3VzdG9tUHJvdmlkZXJzOiBHb1RydWVBZG1pbkN1c3RvbVByb3ZpZGVyc0FwaVxuXG4gIC8qKlxuICAgKiBDb250YWlucyBhbGwgcGFzc2tleSBhZG1pbmlzdHJhdGlvbiBtZXRob2RzLlxuICAgKlxuICAgKiBSZXF1aXJlcyBgYXV0aC5leHBlcmltZW50YWwucGFzc2tleTogdHJ1ZWA7IG90aGVyd2lzZSBhbGwgbWV0aG9kcyB0aHJvdy5cbiAgICovXG4gIHBhc3NrZXk6IEdvVHJ1ZUFkbWluUGFzc2tleUFwaVxuXG4gIHByb3RlY3RlZCB1cmw6IHN0cmluZ1xuICBwcm90ZWN0ZWQgaGVhZGVyczoge1xuICAgIFtrZXk6IHN0cmluZ106IHN0cmluZ1xuICB9XG4gIHByb3RlY3RlZCBmZXRjaDogRmV0Y2hcbiAgcHJvdGVjdGVkIGV4cGVyaW1lbnRhbDogRXhwZXJpbWVudGFsRmVhdHVyZUZsYWdzXG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gYWRtaW4gQVBJIGNsaWVudCB0aGF0IGNhbiBiZSB1c2VkIHRvIG1hbmFnZSB1c2VycyBhbmQgT0F1dGggY2xpZW50cy5cbiAgICpcbiAgICogQGV4YW1wbGUgVXNpbmcgc3VwYWJhc2UtanMgKHJlY29tbWVuZGVkKVxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAc3VwYWJhc2Uvc3VwYWJhc2UtanMnXG4gICAqXG4gICAqIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KCdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28nLCAneW91ci1zZWNyZXQta2V5JylcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi5saXN0VXNlcnMoKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgU3RhbmRhbG9uZSBpbXBvcnQgZm9yIGJ1bmRsZS1zZW5zaXRpdmUgZW52aXJvbm1lbnRzXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IEdvVHJ1ZUFkbWluQXBpIH0gZnJvbSAnQHN1cGFiYXNlL2F1dGgtanMnXG4gICAqXG4gICAqIGNvbnN0IGFkbWluID0gbmV3IEdvVHJ1ZUFkbWluQXBpKHtcbiAgICogICB1cmw6ICdodHRwczovL3h5emNvbXBhbnkuc3VwYWJhc2UuY28vYXV0aC92MScsXG4gICAqICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7cHJvY2Vzcy5lbnYuU1VQQUJBU0VfU0VDUkVUX0tFWX1gIH0sXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKi9cbiAgY29uc3RydWN0b3Ioe1xuICAgIHVybCA9ICcnLFxuICAgIGhlYWRlcnMgPSB7fSxcbiAgICBmZXRjaCxcbiAgICBleHBlcmltZW50YWwsXG4gIH06IHtcbiAgICB1cmw6IHN0cmluZ1xuICAgIGhlYWRlcnM/OiB7XG4gICAgICBba2V5OiBzdHJpbmddOiBzdHJpbmdcbiAgICB9XG4gICAgZmV0Y2g/OiBGZXRjaFxuICAgIGV4cGVyaW1lbnRhbD86IEV4cGVyaW1lbnRhbEZlYXR1cmVGbGFnc1xuICB9KSB7XG4gICAgdGhpcy51cmwgPSB1cmxcbiAgICB0aGlzLmhlYWRlcnMgPSBoZWFkZXJzXG4gICAgdGhpcy5mZXRjaCA9IHJlc29sdmVGZXRjaChmZXRjaClcbiAgICB0aGlzLmV4cGVyaW1lbnRhbCA9IGV4cGVyaW1lbnRhbCA/PyB7fVxuICAgIHRoaXMubWZhID0ge1xuICAgICAgbGlzdEZhY3RvcnM6IHRoaXMuX2xpc3RGYWN0b3JzLmJpbmQodGhpcyksXG4gICAgICBkZWxldGVGYWN0b3I6IHRoaXMuX2RlbGV0ZUZhY3Rvci5iaW5kKHRoaXMpLFxuICAgIH1cbiAgICB0aGlzLm9hdXRoID0ge1xuICAgICAgbGlzdENsaWVudHM6IHRoaXMuX2xpc3RPQXV0aENsaWVudHMuYmluZCh0aGlzKSxcbiAgICAgIGNyZWF0ZUNsaWVudDogdGhpcy5fY3JlYXRlT0F1dGhDbGllbnQuYmluZCh0aGlzKSxcbiAgICAgIGdldENsaWVudDogdGhpcy5fZ2V0T0F1dGhDbGllbnQuYmluZCh0aGlzKSxcbiAgICAgIHVwZGF0ZUNsaWVudDogdGhpcy5fdXBkYXRlT0F1dGhDbGllbnQuYmluZCh0aGlzKSxcbiAgICAgIGRlbGV0ZUNsaWVudDogdGhpcy5fZGVsZXRlT0F1dGhDbGllbnQuYmluZCh0aGlzKSxcbiAgICAgIHJlZ2VuZXJhdGVDbGllbnRTZWNyZXQ6IHRoaXMuX3JlZ2VuZXJhdGVPQXV0aENsaWVudFNlY3JldC5iaW5kKHRoaXMpLFxuICAgIH1cbiAgICB0aGlzLmN1c3RvbVByb3ZpZGVycyA9IHtcbiAgICAgIGxpc3RQcm92aWRlcnM6IHRoaXMuX2xpc3RDdXN0b21Qcm92aWRlcnMuYmluZCh0aGlzKSxcbiAgICAgIGNyZWF0ZVByb3ZpZGVyOiB0aGlzLl9jcmVhdGVDdXN0b21Qcm92aWRlci5iaW5kKHRoaXMpLFxuICAgICAgZ2V0UHJvdmlkZXI6IHRoaXMuX2dldEN1c3RvbVByb3ZpZGVyLmJpbmQodGhpcyksXG4gICAgICB1cGRhdGVQcm92aWRlcjogdGhpcy5fdXBkYXRlQ3VzdG9tUHJvdmlkZXIuYmluZCh0aGlzKSxcbiAgICAgIGRlbGV0ZVByb3ZpZGVyOiB0aGlzLl9kZWxldGVDdXN0b21Qcm92aWRlci5iaW5kKHRoaXMpLFxuICAgIH1cbiAgICB0aGlzLnBhc3NrZXkgPSB7XG4gICAgICBsaXN0UGFzc2tleXM6IHRoaXMuX2FkbWluTGlzdFBhc3NrZXlzLmJpbmQodGhpcyksXG4gICAgICBkZWxldGVQYXNza2V5OiB0aGlzLl9hZG1pbkRlbGV0ZVBhc3NrZXkuYmluZCh0aGlzKSxcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmVtb3ZlcyBhIGxvZ2dlZC1pbiBzZXNzaW9uLlxuICAgKiBAcGFyYW0gand0IEEgdmFsaWQsIGxvZ2dlZC1pbiBKV1QuXG4gICAqIEBwYXJhbSBzY29wZSBUaGUgbG9nb3V0IHNvcGUuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqIEBzdWJjYXRlZ29yeSBBdXRoIEFkbWluXG4gICAqL1xuICBhc3luYyBzaWduT3V0KFxuICAgIGp3dDogc3RyaW5nLFxuICAgIHNjb3BlOiBTaWduT3V0U2NvcGUgPSBTSUdOX09VVF9TQ09QRVNbMF1cbiAgKTogUHJvbWlzZTx7IGRhdGE6IG51bGw7IGVycm9yOiBBdXRoRXJyb3IgfCBudWxsIH0+IHtcbiAgICBpZiAoU0lHTl9PVVRfU0NPUEVTLmluZGV4T2Yoc2NvcGUpIDwgMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgQHN1cGFiYXNlL2F1dGgtanM6IFBhcmFtZXRlciBzY29wZSBtdXN0IGJlIG9uZSBvZiAke1NJR05fT1VUX1NDT1BFUy5qb2luKCcsICcpfWBcbiAgICAgIClcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vbG9nb3V0P3Njb3BlPSR7c2NvcGV9YCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIGp3dCxcbiAgICAgICAgbm9SZXNvbHZlSnNvbjogdHJ1ZSxcbiAgICAgIH0pXG4gICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvcjogbnVsbCB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3IgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZW5kcyBhbiBpbnZpdGUgbGluayB0byBhbiBlbWFpbCBhZGRyZXNzLlxuICAgKiBAcGFyYW0gZW1haWwgVGhlIGVtYWlsIGFkZHJlc3Mgb2YgdGhlIHVzZXIuXG4gICAqIEBwYXJhbSBvcHRpb25zIEFkZGl0aW9uYWwgb3B0aW9ucyB0byBiZSBpbmNsdWRlZCB3aGVuIGludml0aW5nLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKiBAc3ViY2F0ZWdvcnkgQXV0aCBBZG1pblxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFNlbmRzIGFuIGludml0ZSBsaW5rIHRvIHRoZSB1c2VyJ3MgZW1haWwgYWRkcmVzcy5cbiAgICogLSBUaGUgYGludml0ZVVzZXJCeUVtYWlsKClgIG1ldGhvZCBpcyB0eXBpY2FsbHkgdXNlZCBieSBhZG1pbmlzdHJhdG9ycyB0byBpbnZpdGUgdXNlcnMgdG8gam9pbiB0aGUgYXBwbGljYXRpb24uXG4gICAqIC0gTm90ZSB0aGF0IFBLQ0UgaXMgbm90IHN1cHBvcnRlZCB3aGVuIHVzaW5nIGBpbnZpdGVVc2VyQnlFbWFpbGAuIFRoaXMgaXMgYmVjYXVzZSB0aGUgYnJvd3NlciBpbml0aWF0aW5nIHRoZSBpbnZpdGUgaXMgb2Z0ZW4gZGlmZmVyZW50IGZyb20gdGhlIGJyb3dzZXIgYWNjZXB0aW5nIHRoZSBpbnZpdGUgd2hpY2ggbWFrZXMgaXQgZGlmZmljdWx0IHRvIHByb3ZpZGUgdGhlIHNlY3VyaXR5IGd1YXJhbnRlZXMgcmVxdWlyZWQgb2YgdGhlIFBLQ0UgZmxvdy5cbiAgICpcbiAgICogQGV4YW1wbGUgSW52aXRlIGEgdXNlclxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLmludml0ZVVzZXJCeUVtYWlsKCdlbWFpbEBleGFtcGxlLmNvbScpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIEludml0ZSBhIHVzZXJcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7XG4gICAqICAgICAgIFwiaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgXCJhdWRcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwicm9sZVwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgIFwiaW52aXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwicGhvbmVcIjogXCJcIixcbiAgICogICAgICAgXCJjb25maXJtYXRpb25fc2VudF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICBcInByb3ZpZGVyc1wiOiBbXG4gICAqICAgICAgICAgICBcImVtYWlsXCJcbiAgICogICAgICAgICBdXG4gICAqICAgICAgIH0sXG4gICAqICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7fSxcbiAgICogICAgICAgXCJpZGVudGl0aWVzXCI6IFtcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjIyMjIyMjItMjIyMi0yMjIyLTIyMjItMjIyMjIyMjIyMjIyXCIsXG4gICAqICAgICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICBcInVzZXJfaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfZGF0YVwiOiB7XG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiXG4gICAqICAgICAgICAgfVxuICAgKiAgICAgICBdLFxuICAgKiAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcImlzX2Fub255bW91c1wiOiBmYWxzZVxuICAgKiAgICAgfVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBpbnZpdGVVc2VyQnlFbWFpbChcbiAgICBlbWFpbDogc3RyaW5nLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIC8qKiBBIGN1c3RvbSBkYXRhIG9iamVjdCB0byBzdG9yZSBhZGRpdGlvbmFsIG1ldGFkYXRhIGFib3V0IHRoZSB1c2VyLiBUaGlzIG1hcHMgdG8gdGhlIGBhdXRoLnVzZXJzLnVzZXJfbWV0YWRhdGFgIGNvbHVtbi4gKi9cbiAgICAgIGRhdGE/OiBvYmplY3RcblxuICAgICAgLyoqIFRoZSBVUkwgd2hpY2ggd2lsbCBiZSBhcHBlbmRlZCB0byB0aGUgZW1haWwgbGluayBzZW50IHRvIHRoZSB1c2VyJ3MgZW1haWwgYWRkcmVzcy4gT25jZSBjbGlja2VkIHRoZSB1c2VyIHdpbGwgZW5kIHVwIG9uIHRoaXMgVVJMLiAqL1xuICAgICAgcmVkaXJlY3RUbz86IHN0cmluZ1xuICAgIH0gPSB7fVxuICApOiBQcm9taXNlPFVzZXJSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vaW52aXRlYCwge1xuICAgICAgICBib2R5OiB7IGVtYWlsLCBkYXRhOiBvcHRpb25zLmRhdGEgfSxcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICByZWRpcmVjdFRvOiBvcHRpb25zLnJlZGlyZWN0VG8sXG4gICAgICAgIHhmb3JtOiBfdXNlclJlc3BvbnNlLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiB7IHVzZXI6IG51bGwgfSwgZXJyb3IgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZXMgZW1haWwgbGlua3MgYW5kIE9UUHMgdG8gYmUgc2VudCB2aWEgYSBjdXN0b20gZW1haWwgcHJvdmlkZXIuXG4gICAqIEBwYXJhbSBlbWFpbCBUaGUgdXNlcidzIGVtYWlsLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5wYXNzd29yZCBVc2VyIHBhc3N3b3JkLiBGb3Igc2lnbnVwIG9ubHkuXG4gICAqIEBwYXJhbSBvcHRpb25zLmRhdGEgT3B0aW9uYWwgdXNlciBtZXRhZGF0YS4gRm9yIHNpZ251cCBvbmx5LlxuICAgKiBAcGFyYW0gb3B0aW9ucy5yZWRpcmVjdFRvIFRoZSByZWRpcmVjdCB1cmwgd2hpY2ggc2hvdWxkIGJlIGFwcGVuZGVkIHRvIHRoZSBnZW5lcmF0ZWQgbGlua1xuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKiBAc3ViY2F0ZWdvcnkgQXV0aCBBZG1pblxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFRoZSBmb2xsb3dpbmcgdHlwZXMgY2FuIGJlIHBhc3NlZCBpbnRvIGBnZW5lcmF0ZUxpbmsoKWA6IGBzaWdudXBgLCBgbWFnaWNsaW5rYCwgYGludml0ZWAsIGByZWNvdmVyeWAsIGBlbWFpbF9jaGFuZ2VfY3VycmVudGAsIGBlbWFpbF9jaGFuZ2VfbmV3YCwgYHBob25lX2NoYW5nZWAuXG4gICAqIC0gYGdlbmVyYXRlTGluaygpYCBvbmx5IGdlbmVyYXRlcyB0aGUgZW1haWwgbGluayBmb3IgYGVtYWlsX2NoYW5nZV9lbWFpbGAgaWYgdGhlICoqU2VjdXJlIGVtYWlsIGNoYW5nZSoqIGlzIGVuYWJsZWQgaW4geW91ciBwcm9qZWN0J3MgW2VtYWlsIGF1dGggcHJvdmlkZXIgc2V0dGluZ3NdKC9kYXNoYm9hcmQvcHJvamVjdC9fL2F1dGgvcHJvdmlkZXJzKS5cbiAgICogLSBgZ2VuZXJhdGVMaW5rKClgIGhhbmRsZXMgdGhlIGNyZWF0aW9uIG9mIHRoZSB1c2VyIGZvciBgc2lnbnVwYCwgYGludml0ZWAgYW5kIGBtYWdpY2xpbmtgLlxuICAgKlxuICAgKiBAZXhhbXBsZSBHZW5lcmF0ZSBhIHNpZ251cCBsaW5rXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguYWRtaW4uZ2VuZXJhdGVMaW5rKHtcbiAgICogICB0eXBlOiAnc2lnbnVwJyxcbiAgICogICBlbWFpbDogJ2VtYWlsQGV4YW1wbGUuY29tJyxcbiAgICogICBwYXNzd29yZDogJ3NlY3JldCdcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgR2VuZXJhdGUgYSBzaWdudXAgbGlua1xuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJwcm9wZXJ0aWVzXCI6IHtcbiAgICogICAgICAgXCJhY3Rpb25fbGlua1wiOiBcIjxMSU5LX1RPX1NFTkRfVE9fVVNFUj5cIixcbiAgICogICAgICAgXCJlbWFpbF9vdHBcIjogXCI5OTk5OTlcIixcbiAgICogICAgICAgXCJoYXNoZWRfdG9rZW5cIjogXCI8SEFTSEVEX1RPS0VOXCIsXG4gICAqICAgICAgIFwicmVkaXJlY3RfdG9cIjogXCI8UkVESVJFQ1RfVVJMPlwiLFxuICAgKiAgICAgICBcInZlcmlmaWNhdGlvbl90eXBlXCI6IFwic2lnbnVwXCJcbiAgICogICAgIH0sXG4gICAqICAgICBcInVzZXJcIjoge1xuICAgKiAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgIFwiYXVkXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICBcInJvbGVcIjogXCJhdXRoZW50aWNhdGVkXCIsXG4gICAqICAgICAgIFwiZW1haWxcIjogXCJlbWFpbEBleGFtcGxlLmNvbVwiLFxuICAgKiAgICAgICBcInBob25lXCI6IFwiXCIsXG4gICAqICAgICAgIFwiY29uZmlybWF0aW9uX3NlbnRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcImFwcF9tZXRhZGF0YVwiOiB7XG4gICAqICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgXCJwcm92aWRlcnNcIjogW1xuICAgKiAgICAgICAgICAgXCJlbWFpbFwiXG4gICAqICAgICAgICAgXVxuICAgKiAgICAgICB9LFxuICAgKiAgICAgICBcInVzZXJfbWV0YWRhdGFcIjoge30sXG4gICAqICAgICAgIFwiaWRlbnRpdGllc1wiOiBbXG4gICAqICAgICAgICAge1xuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjIyMjIyMjIyLTIyMjItMjIyMi0yMjIyLTIyMjIyMjIyMjIyMlwiLFxuICAgKiAgICAgICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICAgICAgXCJ1c2VyX2lkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZW1haWxAZXhhbXBsZS5jb21cIixcbiAgICogICAgICAgICAgICAgXCJlbWFpbF92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgXCJwaG9uZV92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICAgICAgXCJzdWJcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIlxuICAgKiAgICAgICAgICAgfSxcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImVtYWlsXCI6IFwiZW1haWxAZXhhbXBsZS5jb21cIlxuICAgKiAgICAgICAgIH1cbiAgICogICAgICAgXSxcbiAgICogICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgXCJpc19hbm9ueW1vdXNcIjogZmFsc2VcbiAgICogICAgIH1cbiAgICogICB9LFxuICAgKiAgIFwiZXJyb3JcIjogbnVsbFxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBHZW5lcmF0ZSBhbiBpbnZpdGUgbGlua1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLmdlbmVyYXRlTGluayh7XG4gICAqICAgdHlwZTogJ2ludml0ZScsXG4gICAqICAgZW1haWw6ICdlbWFpbEBleGFtcGxlLmNvbSdcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIEdlbmVyYXRlIGEgbWFnaWMgbGlua1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLmdlbmVyYXRlTGluayh7XG4gICAqICAgdHlwZTogJ21hZ2ljbGluaycsXG4gICAqICAgZW1haWw6ICdlbWFpbEBleGFtcGxlLmNvbSdcbiAgICogfSlcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIEdlbmVyYXRlIGEgcmVjb3ZlcnkgbGlua1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLmdlbmVyYXRlTGluayh7XG4gICAqICAgdHlwZTogJ3JlY292ZXJ5JyxcbiAgICogICBlbWFpbDogJ2VtYWlsQGV4YW1wbGUuY29tJ1xuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgR2VuZXJhdGUgbGlua3MgdG8gY2hhbmdlIGN1cnJlbnQgZW1haWwgYWRkcmVzc1xuICAgKiBgYGBqc1xuICAgKiAvLyBnZW5lcmF0ZSBhbiBlbWFpbCBjaGFuZ2UgbGluayB0byBiZSBzZW50IHRvIHRoZSBjdXJyZW50IGVtYWlsIGFkZHJlc3NcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi5nZW5lcmF0ZUxpbmsoe1xuICAgKiAgIHR5cGU6ICdlbWFpbF9jaGFuZ2VfY3VycmVudCcsXG4gICAqICAgZW1haWw6ICdjdXJyZW50LmVtYWlsQGV4YW1wbGUuY29tJyxcbiAgICogICBuZXdFbWFpbDogJ25ldy5lbWFpbEBleGFtcGxlLmNvbSdcbiAgICogfSlcbiAgICpcbiAgICogLy8gZ2VuZXJhdGUgYW4gZW1haWwgY2hhbmdlIGxpbmsgdG8gYmUgc2VudCB0byB0aGUgbmV3IGVtYWlsIGFkZHJlc3NcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi5nZW5lcmF0ZUxpbmsoe1xuICAgKiAgIHR5cGU6ICdlbWFpbF9jaGFuZ2VfbmV3JyxcbiAgICogICBlbWFpbDogJ2N1cnJlbnQuZW1haWxAZXhhbXBsZS5jb20nLFxuICAgKiAgIG5ld0VtYWlsOiAnbmV3LmVtYWlsQGV4YW1wbGUuY29tJ1xuICAgKiB9KVxuICAgKiBgYGBcbiAgICovXG4gIGFzeW5jIGdlbmVyYXRlTGluayhwYXJhbXM6IEdlbmVyYXRlTGlua1BhcmFtcyk6IFByb21pc2U8R2VuZXJhdGVMaW5rUmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBvcHRpb25zLCAuLi5yZXN0IH0gPSBwYXJhbXNcbiAgICAgIGNvbnN0IGJvZHk6IGFueSA9IHsgLi4ucmVzdCwgLi4ub3B0aW9ucyB9XG4gICAgICBpZiAoJ25ld0VtYWlsJyBpbiByZXN0KSB7XG4gICAgICAgIC8vIHJlcGxhY2UgbmV3RW1haWwgd2l0aCBuZXdfZW1haWwgaW4gcmVxdWVzdCBib2R5XG4gICAgICAgIGJvZHkubmV3X2VtYWlsID0gcmVzdD8ubmV3RW1haWxcbiAgICAgICAgZGVsZXRlIGJvZHlbJ25ld0VtYWlsJ11cbiAgICAgIH1cbiAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnUE9TVCcsIGAke3RoaXMudXJsfS9hZG1pbi9nZW5lcmF0ZV9saW5rYCwge1xuICAgICAgICBib2R5OiBib2R5LFxuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIHhmb3JtOiBfZ2VuZXJhdGVMaW5rUmVzcG9uc2UsXG4gICAgICAgIHJlZGlyZWN0VG86IG9wdGlvbnM/LnJlZGlyZWN0VG8sXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgcHJvcGVydGllczogbnVsbCxcbiAgICAgICAgICAgIHVzZXI6IG51bGwsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBlcnJvcixcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvLyBVc2VyIEFkbWluIEFQSVxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyB1c2VyLlxuICAgKiBUaGlzIGZ1bmN0aW9uIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbiBhIHNlcnZlci4gTmV2ZXIgZXhwb3NlIHlvdXIgYHNlcnZpY2Vfcm9sZWAga2V5IGluIHRoZSBicm93c2VyLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKiBAc3ViY2F0ZWdvcnkgQXV0aCBBZG1pblxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFRvIGNvbmZpcm0gdGhlIHVzZXIncyBlbWFpbCBhZGRyZXNzIG9yIHBob25lIG51bWJlciwgc2V0IGBlbWFpbF9jb25maXJtYCBvciBgcGhvbmVfY29uZmlybWAgdG8gdHJ1ZS4gQm90aCBhcmd1bWVudHMgZGVmYXVsdCB0byBmYWxzZS5cbiAgICogLSBgY3JlYXRlVXNlcigpYCB3aWxsIG5vdCBzZW5kIGEgY29uZmlybWF0aW9uIGVtYWlsIHRvIHRoZSB1c2VyLiBZb3UgY2FuIHVzZSBbYGludml0ZVVzZXJCeUVtYWlsKClgXSgvZG9jcy9yZWZlcmVuY2UvamF2YXNjcmlwdC9hdXRoLWFkbWluLWludml0ZXVzZXJieWVtYWlsKSBpZiB5b3Ugd2FudCB0byBzZW5kIHRoZW0gYW4gZW1haWwgaW52aXRlIGluc3RlYWQuXG4gICAqIC0gSWYgeW91IGFyZSBzdXJlIHRoYXQgdGhlIGNyZWF0ZWQgdXNlcidzIGVtYWlsIG9yIHBob25lIG51bWJlciBpcyBsZWdpdGltYXRlIGFuZCB2ZXJpZmllZCwgeW91IGNhbiBzZXQgdGhlIGBlbWFpbF9jb25maXJtYCBvciBgcGhvbmVfY29uZmlybWAgcGFyYW0gdG8gYHRydWVgLlxuICAgKlxuICAgKiBAZXhhbXBsZSBXaXRoIGN1c3RvbSB1c2VyIG1ldGFkYXRhXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguYWRtaW4uY3JlYXRlVXNlcih7XG4gICAqICAgZW1haWw6ICd1c2VyQGVtYWlsLmNvbScsXG4gICAqICAgcGFzc3dvcmQ6ICdwYXNzd29yZCcsXG4gICAqICAgdXNlcl9tZXRhZGF0YTogeyBuYW1lOiAnWW9kYScgfVxuICAgKiB9KVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGVSZXNwb25zZSBXaXRoIGN1c3RvbSB1c2VyIG1ldGFkYXRhXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIGRhdGE6IHtcbiAgICogICAgIHVzZXI6IHtcbiAgICogICAgICAgaWQ6ICcxJyxcbiAgICogICAgICAgYXVkOiAnYXV0aGVudGljYXRlZCcsXG4gICAqICAgICAgIHJvbGU6ICdhdXRoZW50aWNhdGVkJyxcbiAgICogICAgICAgZW1haWw6ICdleGFtcGxlQGVtYWlsLmNvbScsXG4gICAqICAgICAgIGVtYWlsX2NvbmZpcm1lZF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgcGhvbmU6ICcnLFxuICAgKiAgICAgICBjb25maXJtYXRpb25fc2VudF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgY29uZmlybWVkX2F0OiAnMjAyNC0wMS0wMVQwMDowMDowMFonLFxuICAgKiAgICAgICBsYXN0X3NpZ25faW5fYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIGFwcF9tZXRhZGF0YToge30sXG4gICAqICAgICAgIHVzZXJfbWV0YWRhdGE6IHt9LFxuICAgKiAgICAgICBpZGVudGl0aWVzOiBbXG4gICAqICAgICAgICAge1xuICAgKiAgICAgICAgICAgXCJpZGVudGl0eV9pZFwiOiBcIjIyMjIyMjIyLTIyMjItMjIyMi0yMjIyLTIyMjIyMjIyMjIyMlwiLFxuICAgKiAgICAgICAgICAgXCJpZFwiOiBcIjFcIixcbiAgICogICAgICAgICAgIFwidXNlcl9pZFwiOiBcIjFcIixcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfZGF0YVwiOiB7XG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IHRydWUsXG4gICAqICAgICAgICAgICAgIFwicGhvbmVfdmVyaWZpZWRcIjogZmFsc2UsXG4gICAqICAgICAgICAgICAgIFwic3ViXCI6IFwiMVwiXG4gICAqICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiZW1haWxcIjogXCJlbWFpbEBleGFtcGxlLmNvbVwiXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgXSxcbiAgICogICAgICAgY3JlYXRlZF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgdXBkYXRlZF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgaXNfYW5vbnltb3VzOiBmYWxzZSxcbiAgICogICAgIH1cbiAgICogICB9XG4gICAqICAgZXJyb3I6IG51bGxcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgQXV0by1jb25maXJtIHRoZSB1c2VyJ3MgZW1haWxcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi5jcmVhdGVVc2VyKHtcbiAgICogICBlbWFpbDogJ3VzZXJAZW1haWwuY29tJyxcbiAgICogICBlbWFpbF9jb25maXJtOiB0cnVlXG4gICAqIH0pXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBBdXRvLWNvbmZpcm0gdGhlIHVzZXIncyBwaG9uZSBudW1iZXJcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi5jcmVhdGVVc2VyKHtcbiAgICogICBwaG9uZTogJzEyMzQ1Njc4OTAnLFxuICAgKiAgIHBob25lX2NvbmZpcm06IHRydWVcbiAgICogfSlcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBjcmVhdGVVc2VyKGF0dHJpYnV0ZXM6IEFkbWluVXNlckF0dHJpYnV0ZXMpOiBQcm9taXNlPFVzZXJSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vYWRtaW4vdXNlcnNgLCB7XG4gICAgICAgIGJvZHk6IGF0dHJpYnV0ZXMsXG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgeGZvcm06IF91c2VyUmVzcG9uc2UsXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IHsgdXNlcjogbnVsbCB9LCBlcnJvciB9XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldCBhIGxpc3Qgb2YgdXNlcnMuXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uIGEgc2VydmVyLiBOZXZlciBleHBvc2UgeW91ciBgc2VydmljZV9yb2xlYCBrZXkgaW4gdGhlIGJyb3dzZXIuXG4gICAqIEBwYXJhbSBwYXJhbXMgQW4gb2JqZWN0IHdoaWNoIHN1cHBvcnRzIGBwYWdlYCBhbmQgYHBlclBhZ2VgIGFzIG51bWJlcnMsIHRvIGFsdGVyIHRoZSBwYWdpbmF0ZWQgcmVzdWx0cy5cbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICogQHN1YmNhdGVnb3J5IEF1dGggQWRtaW5cbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogLSBEZWZhdWx0cyB0byByZXR1cm4gNTAgdXNlcnMgcGVyIHBhZ2UuXG4gICAqXG4gICAqIEBleGFtcGxlIEdldCBhIHBhZ2Ugb2YgdXNlcnNcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhOiB7IHVzZXJzIH0sIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLmxpc3RVc2VycygpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZSBQYWdpbmF0ZWQgbGlzdCBvZiB1c2Vyc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGE6IHsgdXNlcnMgfSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguYWRtaW4ubGlzdFVzZXJzKHtcbiAgICogICBwYWdlOiAxLFxuICAgKiAgIHBlclBhZ2U6IDEwMDBcbiAgICogfSlcbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBsaXN0VXNlcnMoXG4gICAgcGFyYW1zPzogUGFnZVBhcmFtc1xuICApOiBQcm9taXNlPFxuICAgIHwgeyBkYXRhOiB7IHVzZXJzOiBVc2VyW107IGF1ZDogc3RyaW5nIH0gJiBQYWdpbmF0aW9uOyBlcnJvcjogbnVsbCB9XG4gICAgfCB7IGRhdGE6IHsgdXNlcnM6IFtdIH07IGVycm9yOiBBdXRoRXJyb3IgfVxuICA+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGFnaW5hdGlvbjogUGFnaW5hdGlvbiA9IHsgbmV4dFBhZ2U6IG51bGwsIGxhc3RQYWdlOiAwLCB0b3RhbDogMCB9XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdHRVQnLCBgJHt0aGlzLnVybH0vYWRtaW4vdXNlcnNgLCB7XG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgbm9SZXNvbHZlSnNvbjogdHJ1ZSxcbiAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICBwYWdlOiBwYXJhbXM/LnBhZ2U/LnRvU3RyaW5nKCkgPz8gJycsXG4gICAgICAgICAgcGVyX3BhZ2U6IHBhcmFtcz8ucGVyUGFnZT8udG9TdHJpbmcoKSA/PyAnJyxcbiAgICAgICAgfSxcbiAgICAgICAgeGZvcm06IF9ub1Jlc29sdmVKc29uUmVzcG9uc2UsXG4gICAgICB9KVxuICAgICAgaWYgKHJlc3BvbnNlLmVycm9yKSB0aHJvdyByZXNwb25zZS5lcnJvclxuXG4gICAgICBjb25zdCB1c2VycyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKVxuICAgICAgY29uc3QgdG90YWwgPSByZXNwb25zZS5oZWFkZXJzLmdldCgneC10b3RhbC1jb3VudCcpID8/IDBcbiAgICAgIGNvbnN0IGxpbmtzID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2xpbmsnKT8uc3BsaXQoJywnKSA/PyBbXVxuICAgICAgaWYgKGxpbmtzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgbGlua3MuZm9yRWFjaCgobGluazogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgY29uc3QgcGFnZSA9IHBhcnNlSW50KGxpbmsuc3BsaXQoJzsnKVswXS5zcGxpdCgnPScpWzFdLnN1YnN0cmluZygwLCAxKSlcbiAgICAgICAgICBjb25zdCByZWwgPSBKU09OLnBhcnNlKGxpbmsuc3BsaXQoJzsnKVsxXS5zcGxpdCgnPScpWzFdKVxuICAgICAgICAgIHBhZ2luYXRpb25bYCR7cmVsfVBhZ2VgXSA9IHBhZ2VcbiAgICAgICAgfSlcblxuICAgICAgICBwYWdpbmF0aW9uLnRvdGFsID0gcGFyc2VJbnQodG90YWwpXG4gICAgICB9XG4gICAgICByZXR1cm4geyBkYXRhOiB7IC4uLnVzZXJzLCAuLi5wYWdpbmF0aW9uIH0sIGVycm9yOiBudWxsIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiB7IHVzZXJzOiBbXSB9LCBlcnJvciB9XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdXNlciBieSBpZC5cbiAgICpcbiAgICogQHBhcmFtIHVpZCBUaGUgdXNlcidzIHVuaXF1ZSBpZGVudGlmaWVyXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uIGEgc2VydmVyLiBOZXZlciBleHBvc2UgeW91ciBgc2VydmljZV9yb2xlYCBrZXkgaW4gdGhlIGJyb3dzZXIuXG4gICAqXG4gICAqIEBjYXRlZ29yeSBBdXRoXG4gICAqIEBzdWJjYXRlZ29yeSBBdXRoIEFkbWluXG4gICAqXG4gICAqIEByZW1hcmtzXG4gICAqIC0gRmV0Y2hlcyB0aGUgdXNlciBvYmplY3QgZnJvbSB0aGUgZGF0YWJhc2UgYmFzZWQgb24gdGhlIHVzZXIncyBpZC5cbiAgICogLSBUaGUgYGdldFVzZXJCeUlkKClgIG1ldGhvZCByZXF1aXJlcyB0aGUgdXNlcidzIGlkIHdoaWNoIG1hcHMgdG8gdGhlIGBhdXRoLnVzZXJzLmlkYCBjb2x1bW4uXG4gICAqXG4gICAqIEBleGFtcGxlIEZldGNoIHRoZSB1c2VyIG9iamVjdCB1c2luZyB0aGUgYWNjZXNzX3Rva2VuIGp3dFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLmdldFVzZXJCeUlkKDEpXG4gICAqIGBgYFxuICAgKlxuICAgKiBAZXhhbXBsZVJlc3BvbnNlIEZldGNoIHRoZSB1c2VyIG9iamVjdCB1c2luZyB0aGUgYWNjZXNzX3Rva2VuIGp3dFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBkYXRhOiB7XG4gICAqICAgICB1c2VyOiB7XG4gICAqICAgICAgIGlkOiAnMScsXG4gICAqICAgICAgIGF1ZDogJ2F1dGhlbnRpY2F0ZWQnLFxuICAgKiAgICAgICByb2xlOiAnYXV0aGVudGljYXRlZCcsXG4gICAqICAgICAgIGVtYWlsOiAnZXhhbXBsZUBlbWFpbC5jb20nLFxuICAgKiAgICAgICBlbWFpbF9jb25maXJtZWRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIHBob25lOiAnJyxcbiAgICogICAgICAgY29uZmlybWF0aW9uX3NlbnRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIGNvbmZpcm1lZF9hdDogJzIwMjQtMDEtMDFUMDA6MDA6MDBaJyxcbiAgICogICAgICAgbGFzdF9zaWduX2luX2F0OiAnMjAyNC0wMS0wMVQwMDowMDowMFonLFxuICAgKiAgICAgICBhcHBfbWV0YWRhdGE6IHt9LFxuICAgKiAgICAgICB1c2VyX21ldGFkYXRhOiB7fSxcbiAgICogICAgICAgaWRlbnRpdGllczogW1xuICAgKiAgICAgICAgIHtcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfaWRcIjogXCIyMjIyMjIyMi0yMjIyLTIyMjItMjIyMi0yMjIyMjIyMjIyMjJcIixcbiAgICogICAgICAgICAgIFwiaWRcIjogXCIxXCIsXG4gICAqICAgICAgICAgICBcInVzZXJfaWRcIjogXCIxXCIsXG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2RhdGFcIjoge1xuICAgKiAgICAgICAgICAgICBcImVtYWlsXCI6IFwiZXhhbXBsZUBlbWFpbC5jb21cIixcbiAgICogICAgICAgICAgICAgXCJlbWFpbF92ZXJpZmllZFwiOiB0cnVlLFxuICAgKiAgICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICBcInN1YlwiOiBcIjFcIlxuICAgKiAgICAgICAgICAgfSxcbiAgICogICAgICAgICAgIFwicHJvdmlkZXJcIjogXCJlbWFpbFwiLFxuICAgKiAgICAgICAgICAgXCJsYXN0X3NpZ25faW5fYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJjcmVhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwidXBkYXRlZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImVtYWlsXCI6IFwiZW1haWxAZXhhbXBsZS5jb21cIlxuICAgKiAgICAgICAgIH0sXG4gICAqICAgICAgIF0sXG4gICAqICAgICAgIGNyZWF0ZWRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIHVwZGF0ZWRfYXQ6ICcyMDI0LTAxLTAxVDAwOjAwOjAwWicsXG4gICAqICAgICAgIGlzX2Fub255bW91czogZmFsc2UsXG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiAgIGVycm9yOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBnZXRVc2VyQnlJZCh1aWQ6IHN0cmluZyk6IFByb21pc2U8VXNlclJlc3BvbnNlPiB7XG4gICAgdmFsaWRhdGVVVUlEKHVpZClcblxuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ0dFVCcsIGAke3RoaXMudXJsfS9hZG1pbi91c2Vycy8ke3VpZH1gLCB7XG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgeGZvcm06IF91c2VyUmVzcG9uc2UsXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IHsgdXNlcjogbnVsbCB9LCBlcnJvciB9XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIHVzZXIgZGF0YS4gQ2hhbmdlcyBhcmUgYXBwbGllZCBkaXJlY3RseSB3aXRob3V0IGNvbmZpcm1hdGlvbiBmbG93cy5cbiAgICpcbiAgICogQHBhcmFtIHVpZCBUaGUgdXNlcidzIHVuaXF1ZSBpZGVudGlmaWVyXG4gICAqIEBwYXJhbSBhdHRyaWJ1dGVzIFRoZSBkYXRhIHlvdSB3YW50IHRvIHVwZGF0ZS5cbiAgICpcbiAgICogVGhpcyBmdW5jdGlvbiBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gYSBzZXJ2ZXIuIE5ldmVyIGV4cG9zZSB5b3VyIGBzZXJ2aWNlX3JvbGVgIGtleSBpbiB0aGUgYnJvd3Nlci5cbiAgICpcbiAgICogQHJlbWFya3NcbiAgICogKipJbXBvcnRhbnQ6KiogVGhpcyBpcyBhIHNlcnZlci1zaWRlIG9wZXJhdGlvbiBhbmQgZG9lcyAqKm5vdCoqIHRyaWdnZXIgY2xpZW50LXNpZGVcbiAgICogYG9uQXV0aFN0YXRlQ2hhbmdlYCBsaXN0ZW5lcnMuIFRoZSBhZG1pbiBBUEkgaGFzIG5vIGNvbm5lY3Rpb24gdG8gY2xpZW50IHN0YXRlLlxuICAgKlxuICAgKiBUbyBzeW5jIGNoYW5nZXMgdG8gdGhlIGNsaWVudCBhZnRlciBjYWxsaW5nIHRoaXMgbWV0aG9kOlxuICAgKiAxLiBPbiB0aGUgY2xpZW50LCBjYWxsIGBzdXBhYmFzZS5hdXRoLnJlZnJlc2hTZXNzaW9uKClgIHRvIGZldGNoIHRoZSB1cGRhdGVkIHVzZXIgZGF0YVxuICAgKiAyLiBUaGlzIHdpbGwgdHJpZ2dlciB0aGUgYFRPS0VOX1JFRlJFU0hFRGAgZXZlbnQgYW5kIG5vdGlmeSBhbGwgbGlzdGVuZXJzXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICogLy8gU2VydmVyLXNpZGUgKEVkZ2UgRnVuY3Rpb24pXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguYWRtaW4udXBkYXRlVXNlckJ5SWQoXG4gICAqICAgdXNlcklkLFxuICAgKiAgIHsgdXNlcl9tZXRhZGF0YTogeyBwcmVmZXJlbmNlczogeyB0aGVtZTogJ2RhcmsnIH0gfSB9XG4gICAqIClcbiAgICpcbiAgICogLy8gQ2xpZW50LXNpZGUgKHRvIHN5bmMgdGhlIGNoYW5nZXMpXG4gICAqIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgucmVmcmVzaFNlc3Npb24oKVxuICAgKiAvLyBvbkF1dGhTdGF0ZUNoYW5nZSBsaXN0ZW5lcnMgd2lsbCBub3cgYmUgbm90aWZpZWQgd2l0aCB1cGRhdGVkIHVzZXJcbiAgICogYGBgXG4gICAqXG4gICAqIEBzZWUge0BsaW5rIEdvVHJ1ZUNsaWVudC5yZWZyZXNoU2Vzc2lvbn0gZm9yIHN5bmNpbmcgYWRtaW4gY2hhbmdlcyB0byB0aGUgY2xpZW50XG4gICAqIEBzZWUge0BsaW5rIEdvVHJ1ZUNsaWVudC51cGRhdGVVc2VyfSBmb3IgY2xpZW50LXNpZGUgdXNlciB1cGRhdGVzICh0cmlnZ2VycyBsaXN0ZW5lcnMgYXV0b21hdGljYWxseSlcbiAgICpcbiAgICogQGNhdGVnb3J5IEF1dGhcbiAgICogQHN1YmNhdGVnb3J5IEF1dGggQWRtaW5cbiAgICpcbiAgICogQGV4YW1wbGUgVXBkYXRlcyBhIHVzZXIncyBlbWFpbFxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGE6IHVzZXIsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLnVwZGF0ZVVzZXJCeUlkKFxuICAgKiAgICcxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTEnLFxuICAgKiAgIHsgZW1haWw6ICduZXdAZW1haWwuY29tJyB9XG4gICAqIClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgVXBkYXRlcyBhIHVzZXIncyBlbWFpbFxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJ1c2VyXCI6IHtcbiAgICogICAgICAgXCJpZFwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiLFxuICAgKiAgICAgICBcImF1ZFwiOiBcImF1dGhlbnRpY2F0ZWRcIixcbiAgICogICAgICAgXCJyb2xlXCI6IFwiYXV0aGVudGljYXRlZFwiLFxuICAgKiAgICAgICBcImVtYWlsXCI6IFwibmV3QGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICBcImVtYWlsX2NvbmZpcm1lZF9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwicGhvbmVcIjogXCJcIixcbiAgICogICAgICAgXCJjb25maXJtZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcInJlY292ZXJ5X3NlbnRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgIFwiYXBwX21ldGFkYXRhXCI6IHtcbiAgICogICAgICAgICBcInByb3ZpZGVyXCI6IFwiZW1haWxcIixcbiAgICogICAgICAgICBcInByb3ZpZGVyc1wiOiBbXG4gICAqICAgICAgICAgICBcImVtYWlsXCJcbiAgICogICAgICAgICBdXG4gICAqICAgICAgIH0sXG4gICAqICAgICAgIFwidXNlcl9tZXRhZGF0YVwiOiB7XG4gICAqICAgICAgICAgXCJlbWFpbFwiOiBcImV4YW1wbGVAZW1haWwuY29tXCIsXG4gICAqICAgICAgICAgXCJlbWFpbF92ZXJpZmllZFwiOiBmYWxzZSxcbiAgICogICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgIFwic3ViXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCJcbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJpZGVudGl0aWVzXCI6IFtcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICBcImlkZW50aXR5X2lkXCI6IFwiMjIyMjIyMjItMjIyMi0yMjIyLTIyMjItMjIyMjIyMjIyMjIyXCIsXG4gICAqICAgICAgICAgICBcImlkXCI6IFwiMTExMTExMTEtMTExMS0xMTExLTExMTEtMTExMTExMTExMTExXCIsXG4gICAqICAgICAgICAgICBcInVzZXJfaWRcIjogXCIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMTExMTFcIixcbiAgICogICAgICAgICAgIFwiaWRlbnRpdHlfZGF0YVwiOiB7XG4gICAqICAgICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiLFxuICAgKiAgICAgICAgICAgICBcImVtYWlsX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICBcInBob25lX3ZlcmlmaWVkXCI6IGZhbHNlLFxuICAgKiAgICAgICAgICAgICBcInN1YlwiOiBcIjExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMVwiXG4gICAqICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgXCJwcm92aWRlclwiOiBcImVtYWlsXCIsXG4gICAqICAgICAgICAgICBcImxhc3Rfc2lnbl9pbl9hdFwiOiBcIjIwMjQtMDEtMDFUMDA6MDA6MDBaXCIsXG4gICAqICAgICAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICAgICAgXCJ1cGRhdGVkX2F0XCI6IFwiMjAyNC0wMS0wMVQwMDowMDowMFpcIixcbiAgICogICAgICAgICAgIFwiZW1haWxcIjogXCJleGFtcGxlQGVtYWlsLmNvbVwiXG4gICAqICAgICAgICAgfVxuICAgKiAgICAgICBdLFxuICAgKiAgICAgICBcImNyZWF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcInVwZGF0ZWRfYXRcIjogXCIyMDI0LTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgKiAgICAgICBcImlzX2Fub255bW91c1wiOiBmYWxzZVxuICAgKiAgICAgfVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFVwZGF0ZXMgYSB1c2VyJ3MgcGFzc3dvcmRcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhOiB1c2VyLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi51cGRhdGVVc2VyQnlJZChcbiAgICogICAnNmFhNWQwZDQtMmE5Zi00NDgzLWI2YzgtMGNmNGM2Yzk4YWM0JyxcbiAgICogICB7IHBhc3N3b3JkOiAnbmV3X3Bhc3N3b3JkJyB9XG4gICAqIClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFVwZGF0ZXMgYSB1c2VyJ3MgbWV0YWRhdGFcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhOiB1c2VyLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi51cGRhdGVVc2VyQnlJZChcbiAgICogICAnNmFhNWQwZDQtMmE5Zi00NDgzLWI2YzgtMGNmNGM2Yzk4YWM0JyxcbiAgICogICB7IHVzZXJfbWV0YWRhdGE6IHsgaGVsbG86ICd3b3JsZCcgfSB9XG4gICAqIClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIFVwZGF0ZXMgYSB1c2VyJ3MgYXBwX21ldGFkYXRhXG4gICAqIGBgYGpzXG4gICAqIGNvbnN0IHsgZGF0YTogdXNlciwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguYWRtaW4udXBkYXRlVXNlckJ5SWQoXG4gICAqICAgJzZhYTVkMGQ0LTJhOWYtNDQ4My1iNmM4LTBjZjRjNmM5OGFjNCcsXG4gICAqICAgeyBhcHBfbWV0YWRhdGE6IHsgcGxhbjogJ3RyaWFsJyB9IH1cbiAgICogKVxuICAgKiBgYGBcbiAgICpcbiAgICogQGV4YW1wbGUgQ29uZmlybXMgYSB1c2VyJ3MgZW1haWwgYWRkcmVzc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGE6IHVzZXIsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLnVwZGF0ZVVzZXJCeUlkKFxuICAgKiAgICc2YWE1ZDBkNC0yYTlmLTQ0ODMtYjZjOC0wY2Y0YzZjOThhYzQnLFxuICAgKiAgIHsgZW1haWxfY29uZmlybTogdHJ1ZSB9XG4gICAqIClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIENvbmZpcm1zIGEgdXNlcidzIHBob25lIG51bWJlclxuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGE6IHVzZXIsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLnVwZGF0ZVVzZXJCeUlkKFxuICAgKiAgICc2YWE1ZDBkNC0yYTlmLTQ0ODMtYjZjOC0wY2Y0YzZjOThhYzQnLFxuICAgKiAgIHsgcGhvbmVfY29uZmlybTogdHJ1ZSB9XG4gICAqIClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlIEJhbiBhIHVzZXIgZm9yIDEwMCB5ZWFyc1xuICAgKiBgYGBqc1xuICAgKiBjb25zdCB7IGRhdGE6IHVzZXIsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmFkbWluLnVwZGF0ZVVzZXJCeUlkKFxuICAgKiAgICc2YWE1ZDBkNC0yYTlmLTQ0ODMtYjZjOC0wY2Y0YzZjOThhYzQnLFxuICAgKiAgIHsgYmFuX2R1cmF0aW9uOiAnODc2MDAwaCcgfVxuICAgKiApXG4gICAqIGBgYFxuICAgKi9cbiAgYXN5bmMgdXBkYXRlVXNlckJ5SWQodWlkOiBzdHJpbmcsIGF0dHJpYnV0ZXM6IEFkbWluVXNlckF0dHJpYnV0ZXMpOiBQcm9taXNlPFVzZXJSZXNwb25zZT4ge1xuICAgIHZhbGlkYXRlVVVJRCh1aWQpXG5cbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdQVVQnLCBgJHt0aGlzLnVybH0vYWRtaW4vdXNlcnMvJHt1aWR9YCwge1xuICAgICAgICBib2R5OiBhdHRyaWJ1dGVzLFxuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIHhmb3JtOiBfdXNlclJlc3BvbnNlLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiB7IHVzZXI6IG51bGwgfSwgZXJyb3IgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGUgYSB1c2VyLiBSZXF1aXJlcyBhIGBzZXJ2aWNlX3JvbGVgIGtleS5cbiAgICpcbiAgICogQHBhcmFtIGlkIFRoZSB1c2VyIGlkIHlvdSB3YW50IHRvIHJlbW92ZS5cbiAgICogQHBhcmFtIHNob3VsZFNvZnREZWxldGUgSWYgdHJ1ZSwgdGhlbiB0aGUgdXNlciB3aWxsIGJlIHNvZnQtZGVsZXRlZCBmcm9tIHRoZSBhdXRoIHNjaGVtYS4gU29mdCBkZWxldGlvbiBhbGxvd3MgdXNlciBpZGVudGlmaWNhdGlvbiBmcm9tIHRoZSBoYXNoZWQgdXNlciBJRCBidXQgaXMgbm90IHJldmVyc2libGUuXG4gICAqIERlZmF1bHRzIHRvIGZhbHNlIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LlxuICAgKlxuICAgKiBUaGlzIGZ1bmN0aW9uIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbiBhIHNlcnZlci4gTmV2ZXIgZXhwb3NlIHlvdXIgYHNlcnZpY2Vfcm9sZWAga2V5IGluIHRoZSBicm93c2VyLlxuICAgKlxuICAgKiBAY2F0ZWdvcnkgQXV0aFxuICAgKiBAc3ViY2F0ZWdvcnkgQXV0aCBBZG1pblxuICAgKlxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFRoZSBgZGVsZXRlVXNlcigpYCBtZXRob2QgcmVxdWlyZXMgdGhlIHVzZXIncyBJRCwgd2hpY2ggbWFwcyB0byB0aGUgYGF1dGgudXNlcnMuaWRgIGNvbHVtbi5cbiAgICpcbiAgICogQGV4YW1wbGUgUmVtb3ZlcyBhIHVzZXJcbiAgICogYGBganNcbiAgICogY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5hZG1pbi5kZWxldGVVc2VyKFxuICAgKiAgICc3MTVlZDVkYi1mMDkwLTRiOGMtYTA2Ny02NDBlY2VlMzZhYTAnXG4gICAqIClcbiAgICogYGBgXG4gICAqXG4gICAqIEBleGFtcGxlUmVzcG9uc2UgUmVtb3ZlcyBhIHVzZXJcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwidXNlclwiOiB7fVxuICAgKiAgIH0sXG4gICAqICAgXCJlcnJvclwiOiBudWxsXG4gICAqIH1cbiAgICogYGBgXG4gICAqL1xuICBhc3luYyBkZWxldGVVc2VyKGlkOiBzdHJpbmcsIHNob3VsZFNvZnREZWxldGUgPSBmYWxzZSk6IFByb21pc2U8VXNlclJlc3BvbnNlPiB7XG4gICAgdmFsaWRhdGVVVUlEKGlkKVxuXG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnREVMRVRFJywgYCR7dGhpcy51cmx9L2FkbWluL3VzZXJzLyR7aWR9YCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzaG91bGRfc29mdF9kZWxldGU6IHNob3VsZFNvZnREZWxldGUsXG4gICAgICAgIH0sXG4gICAgICAgIHhmb3JtOiBfdXNlclJlc3BvbnNlLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiB7IHVzZXI6IG51bGwgfSwgZXJyb3IgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2xpc3RGYWN0b3JzKFxuICAgIHBhcmFtczogQXV0aE1GQUFkbWluTGlzdEZhY3RvcnNQYXJhbXNcbiAgKTogUHJvbWlzZTxBdXRoTUZBQWRtaW5MaXN0RmFjdG9yc1Jlc3BvbnNlPiB7XG4gICAgdmFsaWRhdGVVVUlEKHBhcmFtcy51c2VySWQpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgX3JlcXVlc3QoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgICdHRVQnLFxuICAgICAgICBgJHt0aGlzLnVybH0vYWRtaW4vdXNlcnMvJHtwYXJhbXMudXNlcklkfS9mYWN0b3JzYCxcbiAgICAgICAge1xuICAgICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgICB4Zm9ybTogKGZhY3RvcnM6IGFueSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHsgZGF0YTogeyBmYWN0b3JzIH0sIGVycm9yOiBudWxsIH1cbiAgICAgICAgICB9LFxuICAgICAgICB9XG4gICAgICApXG4gICAgICByZXR1cm4geyBkYXRhLCBlcnJvciB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0F1dGhFcnJvcihlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3IgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2RlbGV0ZUZhY3RvcihcbiAgICBwYXJhbXM6IEF1dGhNRkFBZG1pbkRlbGV0ZUZhY3RvclBhcmFtc1xuICApOiBQcm9taXNlPEF1dGhNRkFBZG1pbkRlbGV0ZUZhY3RvclJlc3BvbnNlPiB7XG4gICAgdmFsaWRhdGVVVUlEKHBhcmFtcy51c2VySWQpXG4gICAgdmFsaWRhdGVVVUlEKHBhcmFtcy5pZClcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgX3JlcXVlc3QoXG4gICAgICAgIHRoaXMuZmV0Y2gsXG4gICAgICAgICdERUxFVEUnLFxuICAgICAgICBgJHt0aGlzLnVybH0vYWRtaW4vdXNlcnMvJHtwYXJhbXMudXNlcklkfS9mYWN0b3JzLyR7cGFyYW1zLmlkfWAsXG4gICAgICAgIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIH1cbiAgICAgIClcblxuICAgICAgcmV0dXJuIHsgZGF0YSwgZXJyb3I6IG51bGwgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogTGlzdHMgYWxsIE9BdXRoIGNsaWVudHMgd2l0aCBvcHRpb25hbCBwYWdpbmF0aW9uLlxuICAgKiBPbmx5IHJlbGV2YW50IHdoZW4gdGhlIE9BdXRoIDIuMSBzZXJ2ZXIgaXMgZW5hYmxlZCBpbiBTdXBhYmFzZSBBdXRoLlxuICAgKlxuICAgKiBUaGlzIGZ1bmN0aW9uIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbiBhIHNlcnZlci4gTmV2ZXIgZXhwb3NlIHlvdXIgYHNlcnZpY2Vfcm9sZWAga2V5IGluIHRoZSBicm93c2VyLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfbGlzdE9BdXRoQ2xpZW50cyhwYXJhbXM/OiBQYWdlUGFyYW1zKTogUHJvbWlzZTxPQXV0aENsaWVudExpc3RSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYWdpbmF0aW9uOiBQYWdpbmF0aW9uID0geyBuZXh0UGFnZTogbnVsbCwgbGFzdFBhZ2U6IDAsIHRvdGFsOiAwIH1cbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ0dFVCcsIGAke3RoaXMudXJsfS9hZG1pbi9vYXV0aC9jbGllbnRzYCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIG5vUmVzb2x2ZUpzb246IHRydWUsXG4gICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgcGFnZTogcGFyYW1zPy5wYWdlPy50b1N0cmluZygpID8/ICcnLFxuICAgICAgICAgIHBlcl9wYWdlOiBwYXJhbXM/LnBlclBhZ2U/LnRvU3RyaW5nKCkgPz8gJycsXG4gICAgICAgIH0sXG4gICAgICAgIHhmb3JtOiBfbm9SZXNvbHZlSnNvblJlc3BvbnNlLFxuICAgICAgfSlcbiAgICAgIGlmIChyZXNwb25zZS5lcnJvcikgdGhyb3cgcmVzcG9uc2UuZXJyb3JcblxuICAgICAgY29uc3QgY2xpZW50cyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKVxuICAgICAgY29uc3QgdG90YWwgPSByZXNwb25zZS5oZWFkZXJzLmdldCgneC10b3RhbC1jb3VudCcpID8/IDBcbiAgICAgIGNvbnN0IGxpbmtzID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2xpbmsnKT8uc3BsaXQoJywnKSA/PyBbXVxuICAgICAgaWYgKGxpbmtzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgbGlua3MuZm9yRWFjaCgobGluazogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgY29uc3QgcGFnZSA9IHBhcnNlSW50KGxpbmsuc3BsaXQoJzsnKVswXS5zcGxpdCgnPScpWzFdLnN1YnN0cmluZygwLCAxKSlcbiAgICAgICAgICBjb25zdCByZWwgPSBKU09OLnBhcnNlKGxpbmsuc3BsaXQoJzsnKVsxXS5zcGxpdCgnPScpWzFdKVxuICAgICAgICAgIHBhZ2luYXRpb25bYCR7cmVsfVBhZ2VgXSA9IHBhZ2VcbiAgICAgICAgfSlcblxuICAgICAgICBwYWdpbmF0aW9uLnRvdGFsID0gcGFyc2VJbnQodG90YWwpXG4gICAgICB9XG4gICAgICByZXR1cm4geyBkYXRhOiB7IC4uLmNsaWVudHMsIC4uLnBhZ2luYXRpb24gfSwgZXJyb3I6IG51bGwgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IHsgY2xpZW50czogW10gfSwgZXJyb3IgfVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBPQXV0aCBjbGllbnQuXG4gICAqIE9ubHkgcmVsZXZhbnQgd2hlbiB0aGUgT0F1dGggMi4xIHNlcnZlciBpcyBlbmFibGVkIGluIFN1cGFiYXNlIEF1dGguXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uIGEgc2VydmVyLiBOZXZlciBleHBvc2UgeW91ciBgc2VydmljZV9yb2xlYCBrZXkgaW4gdGhlIGJyb3dzZXIuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9jcmVhdGVPQXV0aENsaWVudChwYXJhbXM6IENyZWF0ZU9BdXRoQ2xpZW50UGFyYW1zKTogUHJvbWlzZTxPQXV0aENsaWVudFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnUE9TVCcsIGAke3RoaXMudXJsfS9hZG1pbi9vYXV0aC9jbGllbnRzYCwge1xuICAgICAgICBib2R5OiBwYXJhbXMsXG4gICAgICAgIGhlYWRlcnM6IHRoaXMuaGVhZGVycyxcbiAgICAgICAgeGZvcm06IChjbGllbnQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB7IGRhdGE6IGNsaWVudCwgZXJyb3I6IG51bGwgfVxuICAgICAgICB9LFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgZGV0YWlscyBvZiBhIHNwZWNpZmljIE9BdXRoIGNsaWVudC5cbiAgICogT25seSByZWxldmFudCB3aGVuIHRoZSBPQXV0aCAyLjEgc2VydmVyIGlzIGVuYWJsZWQgaW4gU3VwYWJhc2UgQXV0aC5cbiAgICpcbiAgICogVGhpcyBmdW5jdGlvbiBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gYSBzZXJ2ZXIuIE5ldmVyIGV4cG9zZSB5b3VyIGBzZXJ2aWNlX3JvbGVgIGtleSBpbiB0aGUgYnJvd3Nlci5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX2dldE9BdXRoQ2xpZW50KGNsaWVudElkOiBzdHJpbmcpOiBQcm9taXNlPE9BdXRoQ2xpZW50UmVzcG9uc2U+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdHRVQnLCBgJHt0aGlzLnVybH0vYWRtaW4vb2F1dGgvY2xpZW50cy8ke2NsaWVudElkfWAsIHtcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICB4Zm9ybTogKGNsaWVudDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHsgZGF0YTogY2xpZW50LCBlcnJvcjogbnVsbCB9XG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlcyBhbiBleGlzdGluZyBPQXV0aCBjbGllbnQuXG4gICAqIE9ubHkgcmVsZXZhbnQgd2hlbiB0aGUgT0F1dGggMi4xIHNlcnZlciBpcyBlbmFibGVkIGluIFN1cGFiYXNlIEF1dGguXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uIGEgc2VydmVyLiBOZXZlciBleHBvc2UgeW91ciBgc2VydmljZV9yb2xlYCBrZXkgaW4gdGhlIGJyb3dzZXIuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF91cGRhdGVPQXV0aENsaWVudChcbiAgICBjbGllbnRJZDogc3RyaW5nLFxuICAgIHBhcmFtczogVXBkYXRlT0F1dGhDbGllbnRQYXJhbXNcbiAgKTogUHJvbWlzZTxPQXV0aENsaWVudFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnUFVUJywgYCR7dGhpcy51cmx9L2FkbWluL29hdXRoL2NsaWVudHMvJHtjbGllbnRJZH1gLCB7XG4gICAgICAgIGJvZHk6IHBhcmFtcyxcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICB4Zm9ybTogKGNsaWVudDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHsgZGF0YTogY2xpZW50LCBlcnJvcjogbnVsbCB9XG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRGVsZXRlcyBhbiBPQXV0aCBjbGllbnQuXG4gICAqIE9ubHkgcmVsZXZhbnQgd2hlbiB0aGUgT0F1dGggMi4xIHNlcnZlciBpcyBlbmFibGVkIGluIFN1cGFiYXNlIEF1dGguXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uIGEgc2VydmVyLiBOZXZlciBleHBvc2UgeW91ciBgc2VydmljZV9yb2xlYCBrZXkgaW4gdGhlIGJyb3dzZXIuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9kZWxldGVPQXV0aENsaWVudChcbiAgICBjbGllbnRJZDogc3RyaW5nXG4gICk6IFByb21pc2U8eyBkYXRhOiBudWxsOyBlcnJvcjogQXV0aEVycm9yIHwgbnVsbCB9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdERUxFVEUnLCBgJHt0aGlzLnVybH0vYWRtaW4vb2F1dGgvY2xpZW50cy8ke2NsaWVudElkfWAsIHtcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICBub1Jlc29sdmVKc29uOiB0cnVlLFxuICAgICAgfSlcbiAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBudWxsIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJlZ2VuZXJhdGVzIHRoZSBzZWNyZXQgZm9yIGFuIE9BdXRoIGNsaWVudC5cbiAgICogT25seSByZWxldmFudCB3aGVuIHRoZSBPQXV0aCAyLjEgc2VydmVyIGlzIGVuYWJsZWQgaW4gU3VwYWJhc2UgQXV0aC5cbiAgICpcbiAgICogVGhpcyBmdW5jdGlvbiBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gYSBzZXJ2ZXIuIE5ldmVyIGV4cG9zZSB5b3VyIGBzZXJ2aWNlX3JvbGVgIGtleSBpbiB0aGUgYnJvd3Nlci5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3JlZ2VuZXJhdGVPQXV0aENsaWVudFNlY3JldChjbGllbnRJZDogc3RyaW5nKTogUHJvbWlzZTxPQXV0aENsaWVudFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdChcbiAgICAgICAgdGhpcy5mZXRjaCxcbiAgICAgICAgJ1BPU1QnLFxuICAgICAgICBgJHt0aGlzLnVybH0vYWRtaW4vb2F1dGgvY2xpZW50cy8ke2NsaWVudElkfS9yZWdlbmVyYXRlX3NlY3JldGAsXG4gICAgICAgIHtcbiAgICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgICAgeGZvcm06IChjbGllbnQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHsgZGF0YTogY2xpZW50LCBlcnJvcjogbnVsbCB9XG4gICAgICAgICAgfSxcbiAgICAgICAgfVxuICAgICAgKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogTGlzdHMgYWxsIGN1c3RvbSBwcm92aWRlcnMgd2l0aCBvcHRpb25hbCB0eXBlIGZpbHRlci5cbiAgICpcbiAgICogVGhpcyBmdW5jdGlvbiBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gYSBzZXJ2ZXIuIE5ldmVyIGV4cG9zZSB5b3VyIGBzZXJ2aWNlX3JvbGVgIGtleSBpbiB0aGUgYnJvd3Nlci5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX2xpc3RDdXN0b21Qcm92aWRlcnMoXG4gICAgcGFyYW1zPzogTGlzdEN1c3RvbVByb3ZpZGVyc1BhcmFtc1xuICApOiBQcm9taXNlPEN1c3RvbVByb3ZpZGVyTGlzdFJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHF1ZXJ5OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge31cbiAgICAgIGlmIChwYXJhbXM/LnR5cGUpIHtcbiAgICAgICAgcXVlcnkudHlwZSA9IHBhcmFtcy50eXBlXG4gICAgICB9XG4gICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ0dFVCcsIGAke3RoaXMudXJsfS9hZG1pbi9jdXN0b20tcHJvdmlkZXJzYCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIHF1ZXJ5LFxuICAgICAgICB4Zm9ybTogKGRhdGE6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB7IGRhdGE6IHsgcHJvdmlkZXJzOiBkYXRhPy5wcm92aWRlcnMgPz8gW10gfSwgZXJyb3I6IG51bGwgfVxuICAgICAgICB9LFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiB7IHByb3ZpZGVyczogW10gfSwgZXJyb3IgfVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBjdXN0b20gT0lEQy9PQXV0aCBwcm92aWRlci5cbiAgICpcbiAgICogRm9yIE9JREMgcHJvdmlkZXJzLCB0aGUgc2VydmVyIGZldGNoZXMgYW5kIHZhbGlkYXRlcyB0aGUgT3BlbklEIENvbm5lY3QgZGlzY292ZXJ5IGRvY3VtZW50XG4gICAqIGZyb20gdGhlIGlzc3VlcidzIHdlbGwta25vd24gZW5kcG9pbnQgKG9yIHRoZSBwcm92aWRlZCBgZGlzY292ZXJ5X3VybGApIGF0IGNyZWF0aW9uIHRpbWUuXG4gICAqIFRoaXMgbWF5IHJldHVybiBhIHZhbGlkYXRpb24gZXJyb3IgKGBlcnJvcl9jb2RlOiBcInZhbGlkYXRpb25fZmFpbGVkXCJgKSBpZiB0aGUgZGlzY292ZXJ5XG4gICAqIGRvY3VtZW50IGlzIHVucmVhY2hhYmxlLCBub3QgdmFsaWQgSlNPTiwgbWlzc2luZyByZXF1aXJlZCBmaWVsZHMsIG9yIGlmIHRoZSBpc3N1ZXJcbiAgICogaW4gdGhlIGRvY3VtZW50IGRvZXMgbm90IG1hdGNoIHRoZSBleHBlY3RlZCBpc3N1ZXIuXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uIGEgc2VydmVyLiBOZXZlciBleHBvc2UgeW91ciBgc2VydmljZV9yb2xlYCBrZXkgaW4gdGhlIGJyb3dzZXIuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9jcmVhdGVDdXN0b21Qcm92aWRlcihcbiAgICBwYXJhbXM6IENyZWF0ZUN1c3RvbVByb3ZpZGVyUGFyYW1zXG4gICk6IFByb21pc2U8Q3VzdG9tUHJvdmlkZXJSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BPU1QnLCBgJHt0aGlzLnVybH0vYWRtaW4vY3VzdG9tLXByb3ZpZGVyc2AsIHtcbiAgICAgICAgYm9keTogcGFyYW1zLFxuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIHhmb3JtOiAocHJvdmlkZXI6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB7IGRhdGE6IHByb3ZpZGVyLCBlcnJvcjogbnVsbCB9XG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yIH1cbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgZGV0YWlscyBvZiBhIHNwZWNpZmljIGN1c3RvbSBwcm92aWRlciBieSBpZGVudGlmaWVyLlxuICAgKlxuICAgKiBUaGlzIGZ1bmN0aW9uIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbiBhIHNlcnZlci4gTmV2ZXIgZXhwb3NlIHlvdXIgYHNlcnZpY2Vfcm9sZWAga2V5IGluIHRoZSBicm93c2VyLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZ2V0Q3VzdG9tUHJvdmlkZXIoaWRlbnRpZmllcjogc3RyaW5nKTogUHJvbWlzZTxDdXN0b21Qcm92aWRlclJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCBfcmVxdWVzdCh0aGlzLmZldGNoLCAnR0VUJywgYCR7dGhpcy51cmx9L2FkbWluL2N1c3RvbS1wcm92aWRlcnMvJHtpZGVudGlmaWVyfWAsIHtcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICB4Zm9ybTogKHByb3ZpZGVyOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4geyBkYXRhOiBwcm92aWRlciwgZXJyb3I6IG51bGwgfVxuICAgICAgICB9LFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGVzIGFuIGV4aXN0aW5nIGN1c3RvbSBwcm92aWRlci5cbiAgICpcbiAgICogV2hlbiBgaXNzdWVyYCBvciBgZGlzY292ZXJ5X3VybGAgaXMgY2hhbmdlZCBvbiBhbiBPSURDIHByb3ZpZGVyLCB0aGUgc2VydmVyIHJlLWZldGNoZXMgYW5kXG4gICAqIHZhbGlkYXRlcyB0aGUgZGlzY292ZXJ5IGRvY3VtZW50IGJlZm9yZSBwZXJzaXN0aW5nLiBUaGlzIG1heSByZXR1cm4gYSB2YWxpZGF0aW9uIGVycm9yXG4gICAqIChgZXJyb3JfY29kZTogXCJ2YWxpZGF0aW9uX2ZhaWxlZFwiYCkgaWYgdGhlIGRpc2NvdmVyeSBkb2N1bWVudCBpcyB1bnJlYWNoYWJsZSwgaW52YWxpZCwgb3JcbiAgICogdGhlIGlzc3VlciBkb2VzIG5vdCBtYXRjaC5cbiAgICpcbiAgICogVGhpcyBmdW5jdGlvbiBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gYSBzZXJ2ZXIuIE5ldmVyIGV4cG9zZSB5b3VyIGBzZXJ2aWNlX3JvbGVgIGtleSBpbiB0aGUgYnJvd3Nlci5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgX3VwZGF0ZUN1c3RvbVByb3ZpZGVyKFxuICAgIGlkZW50aWZpZXI6IHN0cmluZyxcbiAgICBwYXJhbXM6IFVwZGF0ZUN1c3RvbVByb3ZpZGVyUGFyYW1zXG4gICk6IFByb21pc2U8Q3VzdG9tUHJvdmlkZXJSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgX3JlcXVlc3QodGhpcy5mZXRjaCwgJ1BVVCcsIGAke3RoaXMudXJsfS9hZG1pbi9jdXN0b20tcHJvdmlkZXJzLyR7aWRlbnRpZmllcn1gLCB7XG4gICAgICAgIGJvZHk6IHBhcmFtcyxcbiAgICAgICAgaGVhZGVyczogdGhpcy5oZWFkZXJzLFxuICAgICAgICB4Zm9ybTogKHByb3ZpZGVyOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4geyBkYXRhOiBwcm92aWRlciwgZXJyb3I6IG51bGwgfVxuICAgICAgICB9LFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGVzIGEgY3VzdG9tIHByb3ZpZGVyLlxuICAgKlxuICAgKiBUaGlzIGZ1bmN0aW9uIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbiBhIHNlcnZlci4gTmV2ZXIgZXhwb3NlIHlvdXIgYHNlcnZpY2Vfcm9sZWAga2V5IGluIHRoZSBicm93c2VyLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZGVsZXRlQ3VzdG9tUHJvdmlkZXIoXG4gICAgaWRlbnRpZmllcjogc3RyaW5nXG4gICk6IFByb21pc2U8eyBkYXRhOiBudWxsOyBlcnJvcjogQXV0aEVycm9yIHwgbnVsbCB9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IF9yZXF1ZXN0KHRoaXMuZmV0Y2gsICdERUxFVEUnLCBgJHt0aGlzLnVybH0vYWRtaW4vY3VzdG9tLXByb3ZpZGVycy8ke2lkZW50aWZpZXJ9YCwge1xuICAgICAgICBoZWFkZXJzOiB0aGlzLmhlYWRlcnMsXG4gICAgICAgIG5vUmVzb2x2ZUpzb246IHRydWUsXG4gICAgICB9KVxuICAgICAgcmV0dXJuIHsgZGF0YTogbnVsbCwgZXJyb3I6IG51bGwgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoaXNBdXRoRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yIH1cbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIExpc3RzIGFsbCBwYXNza2V5cyBmb3IgYSB1c2VyLlxuICAgKlxuICAgKiBUaGlzIGZ1bmN0aW9uIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbiBhIHNlcnZlci4gTmV2ZXIgZXhwb3NlIHlvdXIgc2VjcmV0IGtleSBpbiB0aGUgYnJvd3Nlci5cbiAgICpcbiAgICogUmVxdWlyZXMgYGF1dGguZXhwZXJpbWVudGFsLnBhc3NrZXk6IHRydWVgLlxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfYWRtaW5MaXN0UGFzc2tleXMoXG4gICAgcGFyYW1zOiBBdXRoUGFzc2tleUFkbWluTGlzdFBhcmFtc1xuICApOiBQcm9taXNlPEF1dGhQYXNza2V5TGlzdFJlc3BvbnNlPiB7XG4gICAgYXNzZXJ0UGFzc2tleUV4cGVyaW1lbnRhbEVuYWJsZWQodGhpcy5leHBlcmltZW50YWwpXG4gICAgdmFsaWRhdGVVVUlEKHBhcmFtcy51c2VySWQpXG5cbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGF3YWl0IF9yZXF1ZXN0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYCR7dGhpcy51cmx9L2FkbWluL3VzZXJzLyR7cGFyYW1zLnVzZXJJZH0vcGFzc2tleXNgLFxuICAgICAgICB7IGhlYWRlcnM6IHRoaXMuaGVhZGVycywgeGZvcm06IChkYXRhOiBhbnkpID0+ICh7IGRhdGEsIGVycm9yOiBudWxsIH0pIH1cbiAgICAgIClcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGVzIGEgdXNlcidzIHBhc3NrZXkuXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uIGEgc2VydmVyLiBOZXZlciBleHBvc2UgeW91ciBzZWNyZXQga2V5IGluIHRoZSBicm93c2VyLlxuICAgKlxuICAgKiBSZXF1aXJlcyBgYXV0aC5leHBlcmltZW50YWwucGFzc2tleTogdHJ1ZWAuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIF9hZG1pbkRlbGV0ZVBhc3NrZXkoXG4gICAgcGFyYW1zOiBBdXRoUGFzc2tleUFkbWluRGVsZXRlUGFyYW1zXG4gICk6IFByb21pc2U8QXV0aFBhc3NrZXlEZWxldGVSZXNwb25zZT4ge1xuICAgIGFzc2VydFBhc3NrZXlFeHBlcmltZW50YWxFbmFibGVkKHRoaXMuZXhwZXJpbWVudGFsKVxuICAgIHZhbGlkYXRlVVVJRChwYXJhbXMudXNlcklkKVxuICAgIHZhbGlkYXRlVVVJRChwYXJhbXMucGFzc2tleUlkKVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IF9yZXF1ZXN0KFxuICAgICAgICB0aGlzLmZldGNoLFxuICAgICAgICAnREVMRVRFJyxcbiAgICAgICAgYCR7dGhpcy51cmx9L2FkbWluL3VzZXJzLyR7cGFyYW1zLnVzZXJJZH0vcGFzc2tleXMvJHtwYXJhbXMucGFzc2tleUlkfWAsXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzLCBub1Jlc29sdmVKc29uOiB0cnVlIH1cbiAgICAgIClcbiAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBudWxsIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGlzQXV0aEVycm9yKGVycm9yKSkge1xuICAgICAgICByZXR1cm4geyBkYXRhOiBudWxsLCBlcnJvciB9XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=